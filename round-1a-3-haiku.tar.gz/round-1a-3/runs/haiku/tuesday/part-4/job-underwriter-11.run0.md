# Two postings for Femi: one worth applying to on conditions, one not as written

WebSearch was refused permission in this session, so no research ran. Every statement about the two companies and the pay market below comes from the posting text and Femi's intake, and is labelled that way. The employer check is still open.

## 1. Operations Analyst, Duinvaart Cold Chain (Rotterdam)

### Decision snapshot

**Worth applying to, on conditions. Status: `conditional_go`.** The analytics core matches Femi's daily work. The employer check and the Rotterdam hybrid pattern need clearing before the effort is spent.

**Fit ledger.**

- `hard_gate` — unclear: DR1 (Hybrid, three days a week in the Rotterdam office)
- `must_have` — direct: DR2 (2+ years in logistics or operations analysis), DR3 (strong SQL), DR4 (Power BI or Tableau), DR5 (track on-time delivery), DR7 (weekly dashboards) · unclear: DR6 (temperature compliance across the refrigerated fleet)
- `important` — direct: DR8 (work with depot managers on route changes)
- `preferred` — adjacent: DR9 (Dutch, conversational not fluent)

DR2, DR3, DR4, DR5, DR7 and DR8 are backed by the intake's own account of daily SQL, Power BI and the depot-facing dashboard. DR6 is the only must-have with no evidence. DR9 is adjacent, with the limit named.

**Opportunity ledger.** The scope and both outcomes are concrete and measurable (DR-R3). Two entries are open: the employer is not established from attributable sources (DRR1, standing), and pay is not stated (DRR2).

- **Hard gates:** none failed; unconfirmed: DR1 (Hybrid, three days a week in the Rotterdam office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the role appears on the company's own careers page and the hiring contact is found there (DRR1); (2) the three-day Rotterdam pattern works for Femi (DR1); (3) Femi either can speak to temperature compliance honestly or the application says it is not their experience (DR6).

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; refrigerated fleet | `[grounded]` posting |
| Mandate | Track on-time delivery and temperature compliance; build weekly Power BI dashboards; work with depot managers on route changes | `[grounded]` posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Scope read | A defined analyst remit with depot-level influence, not a leadership role | `[inferred]` from the task list against the title |
| Market calibration | Not established. No pay band was researched, so no band is given | — |
| Unknowns | Pay; whether temperature data is in Femi's domain or learned on the job; the company's existence as described | — |
| Contradictions | None visible in the posting text | `[grounded]` posting |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| DR1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | Femi's home location and commute tolerance were not given, so the fit is unsettled | `[grounded]` posting; constraint not given | Ask Femi's location (Q1) |
| DR2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier; specific but not yet probed | `[grounded]` intake, self-reported | None |
| DR3 | Strong SQL | must_have | direct | medium | none | SQL daily, per intake; "strong" is a self-rating, so the band stays medium | `[grounded]` intake | None |
| DR4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, per intake | `[grounded]` intake | None |
| DR5 | Track on-time delivery | must_have | direct | medium | none | Owned the on-time dashboard depot managers use, per intake | `[grounded]` intake | None |
| DR6 | Temperature compliance across a refrigerated fleet | must_have | unclear | none | discovery | Intake is silent on temperature data or cold chain | `[grounded]` intake silence | Ask (Q2) |
| DR7 | Weekly dashboards in Power BI | must_have | direct | medium | none | Dashboard work is part of the daily job, per intake | `[grounded]` intake | None |
| DR8 | Work with depot managers on route changes | important | direct | medium | none | Ran the weekly route-performance review, per intake | `[grounded]` intake | None |
| DR9 | Dutch | preferred | adjacent | medium | transferability | Conversational, not fluent. Limit: not enough for the Rotterdam office day-to-day | `[grounded]` intake | Dutch closure path: a course or conversation practice |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (DR6, must_have) | discovery | Nothing in the intake on temperature data, cold chain or compliance thresholds | It is the one must-have with no evidence, and it is the posting's distinctive term | Any monitoring of thresholds or exceptions, even outside food; sensor or telemetry reporting; any compliance reporting to a regulator or client | A report, dashboard, or a description of the thresholds | `[grounded]` intake silence; `[inferred]` that this term is the posting's distinctive focus |
| G2 | Dutch (DR9, preferred) | transferability | Conversational, not fluent | Limits daily work in the office and with depot staff; a preferred item, not a gate | Working with Dutch-speaking colleagues in English-first settings, if that is what happened | Language certificate, if any | `[grounded]` intake |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| DRR1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | Research could not run this session, so the employer is unconfirmed. The entity may be too new or small to have a footprint, the posting stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | "Can you point me at this role on your own careers site, and who would I be interviewing with?" | unresolved |
| DRR2 | Pay not stated | unknown | — | (posting gives no pay) | The posting withholds pay; the figure may sit well below the market, or may simply be unpublished | `[grounded]` posting omits pay | "What is the salary range budgeted for this role?" | unresolved |
| DRR3 | Concrete, measurable scope | positive_signal | — | "track on-time delivery and temperature compliance across our refrigerated fleet" | Success is defined by two measurable outcomes | `[grounded]` posting | "What on-time and temperature targets does this team report against?" | noted |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead the CV with the depot-facing on-time dashboard. Proposed line: "Worked in SQL and Power BI daily on the on-time delivery dashboard depot managers used; ran the weekly route-performance review." | Maps to DR2, DR3, DR4, DR5, DR8. Wording traced clause by clause to Femi's intake; "built" is left out because the intake does not say it | `[grounded]` intake | pending your approval |
| A2 | Make no temperature or cold-chain claim unless Femi can add evidence | DR6 is unclear; claiming it would be an unsupported claim | `[grounded]` DR6 row | pending your approval |
| A3 | State Dutch as "conversational, working toward fluency" if asked | Matches the intake's own word | `[grounded]` intake | pending your approval |

## 2. Supply Planner, Kroonhaven Foods (Utrecht)

### Decision snapshot

**Not worth applying to as written. Status: `no_go`.** Three must-haves at the centre of the role (planning years, the 13-week plan and capacity-against-forecast) are absent. Femi has said they have never worked in planning, and no answer on the open items changes that. This is a recommendation; the decision is Femi's.

**Fit ledger.**

- `hard_gate` — unclear: KR1 (On-site in Utrecht)
- `must_have` — absent: KR2 (3+ years of supply or demand planning in FMCG), KR3 (13-week plan balancing production capacity against the forecast) · adjacent: KR4 (run the weekly S&OP meeting), KR7 (fluent Dutch) · unclear: KR5 (advanced Excel), KR6 (SAP IBP or a similar planning system)

KR2 and KR3 are absent: Femi has never worked in planning. KR4 transfers only as a recurring review cadence, not as cross-functional planning. KR7 is conversational, not fluent. KR5 and KR6 are not mentioned in the intake, so they are unknown rather than absent.

**Opportunity ledger.** The ownership of the plan is clear (KRR2). The employer is not established from attributable sources (KRR1, standing).

- **Hard gates:** none failed; unconfirmed: KR1 (On-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** a planning history not in the intake (demand, supply, S&OP or capacity-planning work, even outside food) would move KR2 and KR3 off absent. Without that, the status holds.

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; chilled ready meals | `[grounded]` posting |
| Mandate | Own the 13-week supply plan; balance capacity against the forecast; run the weekly S&OP meeting | `[grounded]` posting |
| Working pattern | On-site in Utrecht | `[grounded]` posting |
| Scope read | A planning-owner role with cross-functional authority | `[inferred]` from the ownership and S&OP language |
| Market calibration | Not established | — |
| Unknowns | Pay; the scope of decision rights in S&OP | — |
| Contradictions | None visible in the posting text | `[grounded]` posting |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| KR1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Femi's location was not given | `[grounded]` posting; constraint not given | Ask (Q1) |
| KR2 | 3+ years of supply or demand planning in FMCG | must_have | absent | medium | capability | Femi has never worked in planning, per intake. Years are a fit call, not a gate | `[grounded]` intake, self-reported | Closure path: a junior or demand-planning role first |
| KR3 | 13-week plan balancing production capacity against forecast | must_have | absent | medium | capability | No planning or capacity work in the intake | `[grounded]` intake silence and self-report | Closure path as KR2 |
| KR4 | Run a weekly S&OP meeting | must_have | adjacent | medium | transferability | Ran the weekly route-performance review. Limit: it reviewed route results and did not balance production or sales | `[grounded]` intake; `[inferred]` that the cadence transfers | Make the bridge and its limit |
| KR5 | Advanced Excel | must_have | unclear | none | discovery | Excel is not mentioned | `[grounded]` intake silence | Ask |
| KR6 | SAP IBP or a similar planning system | must_have | unclear | none | discovery | Not mentioned | `[grounded]` intake silence | Ask |
| KR7 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, not fluent. Limit: not fluent | `[grounded]` intake | Dutch closure path |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| KRR1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | As DRR1: research did not run, so existence is unconfirmed | `[generic]` pattern for companies of this size, not a claim about this one | "Can you point me at this role on your own careers site, and who would I be interviewing with?" | unresolved |
| KRR2 | Clear ownership of the plan | positive_signal | — | "Own the 13-week supply plan" | The planner's decision rights are stated | `[grounded]` posting | "Which planning decisions does this role make alone, and which go through the S&OP meeting?" | noted |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| K-A1 | Do not spend application time on this posting as written | KR2 and KR3 are absent, with no closure before this application cycle | `[grounded]` KR2, KR3 | your call |
| K-A2 | Look instead for demand- or supply-planning analyst roles, where Femi's SQL, Power BI and route-review work is the entry point | Closure path for KR2 and KR3 | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet. Both postings' candidate claims are Femi's own intake, self-reported and not yet probed.

WebSearch was not permitted this session, so the employer and pay checks did not run. The two employers' existence is therefore unestablished (DRR1, KRR1).

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Duinvaart Cold Chain Rotterdam"; "Kroonhaven Foods Utrecht chilled ready meals") were refused by the permission setting; no page was read. Would have moved the existence and liveness of both postings (DRR1, KRR1) |
| 2. Role-family sweep | unavailable | Two searches (operations analyst logistics salary, Rotterdam; supply planner FMCG salary, Utrecht) were refused. Would have set a market calibration and pay band for DRR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Granting WebSearch would run targets 1 and 2. After this turn's refused calls, the L1 budget has one search and two fetches left, so a wider pass needs your go-ahead.
- Pasting the postings' text from each company's own careers page would check existence by reading, and would not be charged to the budget. It would move DRR1 and KRR1.
- A budgeted or expected pay figure would close DRR2 against the band.
- A temperature-monitoring or cold-chain artifact would move DR6 from unclear toward direct.
- Any Excel or planning-system use (SAP IBP or similar) would settle KR5 and KR6.
- Any demand, supply or capacity-planning history would move KR2 and KR3 off absent, and could change the Kroonhaven decision.

If you want, I can write a `tuesday-dossier.md` that keeps this analysis for a later session.

Questions:

1. **Location (DR1, KR1):** Where are you based, and could you commit to three days a week in Rotterdam, or to on-site work in Utrecht?
2. **Temperature (DR6):** Have you ever monitored temperature, cold-chain or other compliance thresholds, or reported against them, even outside food? What did you own, and what happened?
3. **Pay (DRR2):** What is the lowest pay you would accept for a role like this?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.