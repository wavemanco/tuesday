**Short answer:** Duinvaart is worth applying to once you've checked one thing: can you do three office days a week in Rotterdam. Kroonhaven isn't worth applying to as posted, because it asks for three years of FMCG planning and SAP IBP, and you have neither.

I could not run web checks. The search calls were blocked by a permission prompt, so neither employer is verified and no salary benchmarks were pulled. Everything below rests on the two postings and your background as you described it.

## Posting 1: Operations Analyst, Duinvaart Cold Chain (Rotterdam)

**Decision snapshot. Status: `hold_pending_answers`.** Waiting on your answer to the schedule question below.

**Fit ledger.**
- `hard_gate`: unclear: R1 (three office days a week in Rotterdam)
- `must_have`: direct: R2 (2+ years logistics or ops analysis), R3 (SQL), R4 (Power BI or Tableau), R5 (on-time delivery tracking), R7 (weekly dashboards), adjacent: R8 (depot managers and route changes), absent: R6 (temperature compliance)
- `preferred`: adjacent: R9 (Dutch, conversational only)

R6 is the one real gap in the role's core work. R1 is the one question that could close the decision.

- **Hard gates:** none failed; unconfirmed: R1 (three office days a week in Rotterdam); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity:** The scope is clear and the tools are named (RR2 is positive). Salary is withheld (RR3), and it's not yet clear whether the role decides route changes or recommends them to depot managers (RR4). The employer check did not run (RR1).
- **What would change this:** a yes on the schedule moves this to `conditional_go`. If the office days are impossible, it is `no_go` on R1. Conditions for go: the employer's own careers page shows this role, and R6 gets answered in interview.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; refrigerated fleet | `[grounded]` posting |
| Mandate | Track on-time delivery and temperature compliance; weekly Power BI dashboards; route changes with depot managers | `[grounded]` posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Scope read | A standard analyst remit with a field-facing element | `[inferred]` from the listed duties |
| Market calibration | Not run: no salary or role-family search | — |
| Unknowns | Salary; route-change authority; whether temperature data is yours to own | — |
| Contradictions | None visible from the posting alone; careers page not checked | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Three office days a week in Rotterdam | hard_gate | unclear | none | hard_gate | No constraint from you yet, so the gate can't be checked | `[grounded]` posting | Q1 |
| R2 | 2+ years logistics or ops analysis | must_have | direct | medium | none | Four years at a parcel carrier; self-reported, no artifact yet | `[grounded]` your background | none |
| R3 | Strong SQL | must_have | direct | medium | none | Daily use; self-reported | `[grounded]` your background | none |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use | `[grounded]` your background | none |
| R5 | Track on-time delivery | must_have | direct | medium | none | You built the depot managers' on-time dashboard | `[grounded]` your background | none |
| R6 | Track temperature compliance across a refrigerated fleet | must_have | absent | none | discovery | No temperature or cold-chain data in your background; a parcel carrier may have some, but you haven't said | `[grounded]` absence from your background | Q2 |
| R7 | Weekly dashboards in Power BI | must_have | direct | medium | none | Same as R4 and R5 | `[grounded]` your background | none |
| R8 | Work with depot managers on route changes | must_have | adjacent | medium | transferability | You ran the weekly route-performance review. Limit: you haven't said you approved or made route changes | `[inferred]` from the review's scope | Confirm decision rights in interview |
| R9 | Dutch, a plus | preferred | adjacent | medium | transferability | Conversational; limit: not fluent for depot-level work | `[grounded]` your statement | Name the limit honestly |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified (check did not run) | unknown | — | "Duinvaart Cold Chain, Rotterdam" | The check was blocked, so nothing is known about the employer either way | — (no finding about the employer) | Can you point me at this role on your own careers site, and who would I interview with? | unresolved |
| RR2 | Clear scope with named tools and a depot-manager interface | positive_signal | — | "Track on-time delivery… build weekly dashboards in Power BI" | The role has defined outputs | `[grounded]` posting | — | noted |
| RR3 | Salary withheld | unknown | — | (not stated) | Could be below your expectation or simply unpublished | `[inferred]` from the omission | What is the salary band for this role? | unresolved |
| RR4 | Route-change authority unclear | unknown | — | "work with depot managers on route changes" | You may advise rather than decide | `[inferred]` from the wording | Does this role approve route changes, or recommend them to depot managers? | unresolved |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R6, must_have) | discovery | Your background covers on-time tracking, not temperature | This is the one must-have with no evidence | Sensor or excursion reports you read; any cold or temperature-sensitive shipments in your parcel work | A sample report, a dashboard screenshot | `[grounded]` absence; `[generic]` that this is the probe interviewers would likely use |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Surface the on-time delivery dashboard as its own bullet on your CV | Shows the closest match to R5 | `[grounded]` your background | pending your approval |
| A1 | Check the posting on Duinvaart's careers page yourself before applying | The employer check didn't run | — | your action |
| A2 | Prepare an honest answer on temperature: "I haven't owned temperature data; here is the closest thing I have" | Covers R6 without inflating it | `[grounded]` R6 row | pending your approval |

## Posting 2: Supply Planner, Kroonhaven Foods (Utrecht)

**Decision snapshot. Status: `no_go`, as posted.** The reason is capability, not a hard gate. You'd be screened out on the FMCG planning years and the SAP IBP requirement, and there's no realistic path to close either in this posting.

**Fit ledger.**
- `hard_gate`: unclear: R1 (on-site Utrecht)
- `must_have`: absent: R2 (3+ years FMCG planning), R5 (SAP IBP or similar); adjacent: R3 (planning from forecast and capacity), R6 (fluent Dutch); unclear: R4 (advanced Excel)
- `important`: adjacent: R7 (weekly S&OP-type review)

- **Hard gates:** none failed; unconfirmed: R1 (on-site Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity:** Well-defined. The 13-week plan and the S&OP meeting are clear (RR1). Salary is withheld (RR2). The employer check did not run (RR3).
- **What would change this:** Two absent must-haves would have to change. A different target role would be a better fit, such as a junior demand or supply planner role.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; chilled ready meals | `[grounded]` posting |
| Mandate | Own the 13-week supply plan; balance capacity against forecast; run the weekly S&OP meeting | `[grounded]` posting |
| Scope read | A full planning owner, with three years of experience expected | `[inferred]` from the requirement list |
| Market calibration | Not run | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site Utrecht | hard_gate | unclear | none | hard_gate | No constraint from you yet | `[grounded]` posting | Q1 |
| R2 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You've never worked in planning; no credible direct or adjacent evidence | `[grounded]` your statement | Closure path below |
| R3 | Balance production capacity against forecast | must_have | adjacent | low | transferability | Analytical work on delivery and route KPIs; limit: no forecast or capacity work | `[inferred]` from your background | none |
| R4 | Advanced Excel | must_have | unclear | none | discovery | Not stated in your background | `[grounded]` absence | Upgrade menu |
| R5 | SAP IBP or a similar planning system | must_have | absent | none | capability | Not in your background | `[grounded]` absence | Closure path below |
| R6 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational; limit: not fluent | `[grounded]` your statement | Name the limit honestly |
| R7 | Run a weekly S&OP meeting | important | adjacent | medium | transferability | You ran the weekly route-performance review; limit: not cross-functional supply planning | `[inferred]` from the review's scope | none |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Clear scope | positive_signal | — | "Own the 13-week supply plan" | Defined ownership | `[grounded]` posting | — | noted |
| RR2 | Salary withheld | unknown | — | (not stated) | Unknown | `[inferred]` from the omission | What is the salary band? | unresolved |
| RR3 | Employer not verified (check did not run) | unknown | — | "Kroonhaven Foods, Utrecht" | The check was blocked | — | Can you point me at this role on your own careers site? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| C1 | Don't apply as posted | R2 and R5 are absent | `[grounded]` R2, R5 | your decision |
| C2 | If you want planning, target junior demand or supply planner roles, and get a planning course or practice in Excel and IBP-style tools | Closure path for R2 and R5 | `[generic]` typical route into planning roles | pending your approval |

## Evidence status

**Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers pages (Duinvaart, Kroonhaven) | unavailable | Every search was refused, so neither employer is verified (RR1, RR3) |
| 2. Role-family sweep (salary, scope) | unavailable | Would have calibrated the salary band in both postings |
| 3. Hiring manager's public footprint | n/a | No name was given |

Verified: none yet. Your background is self-report at `medium` at most, until you show an artifact.

## Dossier offer

If you want, I can save this as `tuesday-dossier.md` so a prep module can read it later.

## Upgrade menu

- Search permission granted, which would run the employer checks and the salary sweep
- A link to each live posting (on the employer's site) → RR1 and RR3 close or stay open
- A sanitized on-time dashboard screenshot → R5 and R7 move from `medium` to `high`
- Any temperature or cold-chain data you've handled → R6 closes or becomes an honest limit
- Any forecast or capacity work → R3 moves up
- A salary expectation from you → the salary comparison in RR2 and RR3

## Questions

1. **Q1 (R1 for both postings):** Could you work three office days a week in Rotterdam, and on-site full-time in Utrecht? This decides whether the first posting moves to `conditional_go`.
2. **Q2 (G1, R6):** Have you ever read or handled temperature or cold-chain data, such as sensor logs or excursion reports? If so, what did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.