**Decision: don't go ahead, and don't send anything yet.** The role may suit you, but this process asks for money and bank details before any offer exists, so I'd treat it as held until it's verified.

Research tier: L0, no searches. Everything about the company below is unverified.

**Fit (your side):** Strong on the stated requirements. Zendesk at about 60 tickets a day, Excel tracking, and training two starters map directly to the role. Written English and a quiet workspace are presumably fine, but I can't check them from here.

**Pay (hard gate, unknown):** Your €30,000 floor is reachable only at the top of their range. At €26/h you'd need about 22 hours a week every week of the year. At 15 hours you'd need roughly €38/h. "Up to" and "plus commission" mean no guaranteed base is stated. Ask for the base rate, the hours, and whether you'd be employed or self-employed.

**Opportunity risk register:**

1. **High, confirmed, quoted.** "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." Being asked to pay for your own equipment before any written offer is a red flag. Routine payroll details come only after a credible written offer, and this one doesn't have one.
2. **High, confirmed, quoted.** "We are posting you a cheque for €2,850... keep €350... transfer the rest to our equipment partner." You'd be sending real money out of your own account against a cheque that hasn't cleared. Cheques can take days to clear and can still be reversed later, so the money you transfer can be lost while the cheque is still treated as yours.
3. **High, confirmed, quoted.** "Send your IBAN, your PPS number and a clear photo of your passport" before the interview. Don't send these. Your passport and PPS number aren't needed at this stage. Don't paste your IBAN into this chat or anywhere else.
4. **Medium.** The whole process is by Telegram, with no call, video or verifiable company contact. The only contact offered is a Telegram handle and an email on a generic mail domain.
5. **Medium, unverified.** Failed attribution: I haven't confirmed that Velloway Logistics exists as described. This caps any `go` at `conditional_go` until it's checked.

**Gap recovery queue** (what would close each gap):

- Confirm Velloway Logistics from its own website and careers page, found by you, not through the posting or Telegram links.
- Check the company's registration with the business registry for the country the role is based in. The euro and PPS reference suggest Ireland, which is an inference, so verify it.
- Get the base rate, the hours, and the employment type in writing from a contact on the company's own site.

**Application plan (as far as the evidence allows):**

- Don't pay anything, don't deposit any cheque, and don't send bank, PPS or ID details through Telegram.
- If you have already sent anything, call your bank now using the number on your card, not one from these messages.
- Apply, if at all, through a listing you found independently or through the company's own careers page. Reference your Zendesk and training experience directly.

**Evidence status:** Documents and messages you provided only. Posting and chat content are unverified claims.

**Dossier offer:** If you want, I can write a `tuesday-dossier.md` file for this role so you can track the checks above.

**Upgrade menu:**
- Run L1 research (up to 5 searches and 2 page fetches) on the company's website, a role-family pay sweep, and the business registry. This would show whether the employer exists and what this kind of role normally pays.
- A link to a live posting on a site you trust, or the company's careers page, would change the attribution status.
- A written offer from a verified company email domain would be needed before any payroll step.

**Questions:**
1. Have you already sent any money, a photo of your passport, or your PPS or IBAN to this contact?
2. Do you have a link to Velloway's own website or careers page, and if so, what does it say about this role?
3. Would you like me to run the L1 research now?

Reply in any form, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.