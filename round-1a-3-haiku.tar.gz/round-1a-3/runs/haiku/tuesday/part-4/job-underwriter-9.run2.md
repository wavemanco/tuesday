**Yes, that request is routine.** Asking for bank details, a PPS number and a passport scan after a written offer that names the role and pay is standard onboarding. The caution you were taught applies to requests made before any offer, or to requests for payment. This offer came by email from the employer's domain, states the role, salary, reporting line and terms, and followed in-person interviews at their office. **`conditional_go`**: apply and accept only after the checks below.

**What to do:** Look up Marrowgate Housing's website yourself, by typing the address rather than following a link from the email. Confirm the post is listed there and that the people-team email domain matches. Enter your bank, PPS and passport details only in the onboarding portal at the address on their own website, never by email. Keep the original passport for your first day, as they ask. Web search was refused in this session, so I could not confirm the employer or the pay band. I did not retry.

## Decision snapshot

- **Fit ledger.**
  - `hard_gate`: unclear: R9 (hybrid, two days a week in the Limerick office)
  - `must_have`: direct: R1, R3, R4, R5, R6 · unclear: R2 (Irish PAYE, PRSI and USC) · adjacent: R7 (pension changes)
  - `important`: unclear: R8 (answering staff payroll queries)

  R2 — Irish tax steps are not in your background; R7 — a bridge, with its limit named; R9 — no answer yet on office days.
- **Opportunity ledger.** The offer is specific and in writing (PS1). The employer is unchecked (RR1), and the salary is not checked against a band (RR2).
- **Hard gates:** none failed; unconfirmed: R9 (Hybrid, two days a week in the Limerick office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and post are confirmed on its own website before you accept or enter any details (RR1); (2) your PAYE, PRSI and USC depth holds up in interview (R2); (3) pension changes are named as a limit, not claimed (R7).
- **What would change this:** if you cannot attend the Limerick office two days a week, R9 fails and the status becomes `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Housing association in Limerick, 240 staff | `[grounded]` posting; not checked online |
| Mandate | Monthly payroll, starters, leavers, pension changes, payroll-to-ledger reconciliation, staff queries | `[grounded]` posting |
| Scope read | Solo payroll administrator at a larger scale than your 90 staff, reporting to the Finance Manager | `[inferred]` from the posting |
| Pay | €40,000 offered, inside the posted €38k–€42k range | `[grounded]` posting and offer |
| Market calibration | Not run; search refused | `[generic]` none |
| Working pattern | Hybrid, two office days a week | `[grounded]` posting |
| Unknowns | Employer existence, pension scheme, depth of Irish tax knowledge, whether the salary is the budgeted figure | — |
| Contradictions | None between posting and offer | `[grounded]` |

## Evidence map

Your background is self-report, so confidence tops out at `medium` until something is inspected.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff, stated | `[grounded]` your background | none |
| R2 | Working knowledge of Irish PAYE, PRSI, USC | must_have | unclear | low | discovery | Not named in your background; running payroll implies some of it but does not establish it | `[inferred]` from posting against silence | Q2 below |
| R3 | Payroll qualification or working towards | must_have | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your background | none |
| R4 | Strong Excel | must_have | direct | medium | none | Daily pivot tables and XLOOKUP | `[grounded]` your background | none |
| R5 | Monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | Done for three years | `[grounded]` your background | none |
| R6 | Starters and leavers | must_have | direct | medium | none | Part of your three years | `[grounded]` your background | none |
| R7 | Pension changes | must_have | adjacent | low | transferability | You know the payroll inputs these depend on, but you have never processed one; your manager did | `[inferred]` adjacency from your payroll work | Q3 below |
| R8 | Answering staff payroll queries | important | unclear | low | discovery | Your background does not mention queries | `[grounded]` silence in your background | Ask in interview how queries reach payroll |
| R9 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | Your location and office days are not in the material | `[grounded]` posting | Q1 below |

## Gap recovery queue

| # | Gap (req) | Type | What I see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI, USC (R2) | discovery | Not in your background | Specific steps you ran yourself, such as a Revenue return or a USC calculation | `[grounded]` silence |
| G2 | Pension changes (R7) | transferability | Payroll knowledge, no pension processing | Any pension enrolment or opt-out work you touched, or a scheme you have been trained on | `[inferred]` adjacency |
| G3 | Office days (R9) | hard_gate | Not stated | Your answer to Q1 | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and post not checked in this session | unknown | — | "Marrowgate Housing, a housing association in Limerick" | Cannot tell from here whether the post is live on the employer's own site | `[generic]` pattern: check the employer's own site before entering details | Where on your own website is this post listed, and does the onboarding portal sit on that same domain? | unresolved |
| RR2 | Salary not checked against a band | unknown | — | "€40,000 a year" | The figure may sit at, above or below the usual band; no band was searched | `[generic]` none; not searched | Is €40,000 the budgeted salary for this post, and is any pension contribution on top? | unresolved |
| PS1 | Offer is specific and in writing | positive_signal | — | "delighted to offer you the permanent post … at €40,000" | Terms are concrete and reviewable | `[grounded]` offer email | Is the post permanent, and what is the probation period? | noted |

The onboarding request has no register entry, because a written offer naming the role and pay makes it routine.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the employer on its own website, typed in yourself, before replying | RR1 | `[generic]` standard check | your action |
| A2 | Accept in writing once A1 is clear, and ask for the portal address, the pension scheme name and the probation period | R7, RR1, RR2 | `[generic]` | your action |
| A3 | Enter bank, PPS and passport details only in the portal on their own site; never by email; bring the original passport on day one | Routine onboarding | `[generic]` | your action |
| A4 | In interview, describe what you have processed and what you have not, for pensions | R7 | `[grounded]` your background | your action |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it would have moved |
|---|---|---|
| 1. Official site and careers page | unavailable | Whether the employer exists, the post is live, and the email domain matches. Search was refused. |
| 2. Role-family sweep | unavailable | Whether €40,000 sits in the usual band for this role. Search was refused. |
| 3. Hiring manager's public footprint | unavailable | Declan Garvagh's public professional background. Search was refused. |

## Next steps

Want me to save these findings to `tuesday-dossier.md`, so they carry into your next step?

**Upgrade menu**
- Enable web search and I can run the three checks above, covering the employer, the post and the pay band (RR1, RR2).
- Your answer to Q1 settles R9.
- Your answer to Q2 moves R2.
- HR's pension scheme details would narrow R7.

**Questions**
1. (R9) Can you attend the Limerick office two days a week? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. (R2) Which PAYE, PRSI and USC steps have you run yourself, from calculating deductions through to a Revenue return? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. (R7) Have you ever touched pension deductions or enrolments, even just opt-outs or contribution changes? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.