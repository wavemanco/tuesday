**Short answer:** Duinvaart is worth an application, with conditions. Kroonhaven isn't on the evidence you've given me, but one question could change that.

Web search was refused in this session, so neither employer was checked and I have no salary figures. Everything about the companies comes from the posting text alone.

---

## Posting 1: Operations Analyst, Duinvaart Cold Chain (Rotterdam)

### Decision snapshot

**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**
- `hard_gate`: unclear: R1 (three days a week in the Rotterdam office)
- `must_have`: direct: R2 (logistics or operations analysis), R3 (strong SQL), R4 (Power BI) · unclear: R5 (temperature compliance)
- `important`: direct: R6 (on-time delivery dashboards), R7 (depot-manager route work)
- `preferred`: adjacent: R8 (Dutch, conversational)

R5 is the one must-have the background doesn't evidence. R1 can't be settled without your constraints.

**Opportunity ledger.** The posting is specific: it names its metrics, tools and counterparts, and I found no red flags in the text. The employer is not established, because the search that would have checked it was refused. That is an open check, not a finding against the company.

- **Hard gates:** unconfirmed: R1 (three days a week in the Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting appears on Duinvaart's own careers page; (2) three Rotterdam office days a week works for you; (3) you can credibly bridge to temperature compliance (G1).

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; existence not checked | `[grounded]` posting only |
| Mandate | On-time delivery and temperature compliance across a refrigerated fleet; weekly Power BI dashboards; route changes with depot managers | `[grounded]` posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Scope read | A mid-level analyst role with reporting and operational input | `[inferred]` from the listed duties |
| Market calibration | Not run; no salary band | — |
| Unknowns | Whether the role decides route changes or only advises on them; salary; contract type | — |
| Contradictions | None visible in the posting text | `[grounded]` posting |

### Evidence map

Your background is prose, so it is self-report. Confidence tops out at `medium` until something is inspected.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three Rotterdam office days a week | hard_gate | unclear | none | hard_gate | Your constraint is not stated, so the gate is not established | `[grounded]` posting | G2 |
| R2 | 2+ years logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier | `[grounded]` your background | none |
| R3 | Strong SQL | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your background | none |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use, self-reported | `[grounded]` your background | none |
| R5 | Temperature compliance across a refrigerated fleet | must_have | unclear | low | discovery | Nothing in your background covers temperature data | `[grounded]` absence in your background | G1 |
| R6 | Weekly on-time delivery dashboards | important | direct | medium | none | You built the on-time delivery dashboard depot managers use | `[grounded]` your background | none |
| R7 | Working with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review | `[grounded]` your background | none |
| R8 | Dutch, a plus | preferred | adjacent | medium | transferability | Conversational Dutch; not fluent | `[grounded]` your statement | none |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R5, must_have) | discovery | Your background shows on-time work at a parcel carrier, not temperature data | R5 is the one must-have without evidence, and it decides whether this is `go` or `conditional_go` | Any temperature-sensitive shipments, reporting feeds or compliance checks you touched, even as a side project | A dashboard screenshot with client data removed, or a spec for a temperature feed | `[inferred]` that R5 moves the decision; `[grounded]` absence in your background |
| G2 | Office attendance (R1, hard_gate) | hard_gate | Your constraint on Rotterdam attendance is not stated | A gate you can't meet is a `no_go` regardless of fit | — | — | `[grounded]` posting |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Salary and contract type not stated | unknown | — | (none quoted; both absent) | The role may be a standard permanent post, or the employer may simply withhold pay | `[inferred]` from the posting's silence | What is the salary range, and is the contract permanent? | unresolved |
| RR2 | Route decision rights unclear | unknown | — | "work with depot managers on route changes" | You may advise on route changes without approving them | `[inferred]` from the posting's wording | Which route changes does this role approve itself, and which go to depot managers? | unresolved |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead the CV with the on-time delivery dashboard and the route-performance review | Those are your closest matches to the mandate | `[grounded]` your background | pending your approval |
| A2 | Write one honest cold-chain line: "I haven't run temperature-compliance reporting; my closest work is on-time performance for parcel delivery" | It names the limit instead of hiding it | `[grounded]` your background | pending your approval |

### Evidence status

Verified: none yet. Everything above is your self-report.

---

## Posting 2: Supply Planner, Kroonhaven Foods (Utrecht)

### Decision snapshot

**Not worth applying to on this evidence. One question could change that. Status: `hold_pending_answers`.** If the answer to G3 is no, this moves to `no_go`.

**Fit ledger.**
- `hard_gate`: unclear: S7 (on-site in Utrecht)
- `must_have`: absent: S1 (3+ years FMCG planning), S3 (SAP IBP or a similar planning system) · unclear: S2 (advanced Excel) · adjacent: S4 (fluent Dutch; yours is conversational)
- `important`: adjacent: S5 (running a weekly cross-functional review) · absent: S6 (balancing capacity against forecast)

Two must-haves are absent and one is unclear. The 3+ years of planning is the one you've said you don't have.

**Opportunity ledger.** The posting is specific and I found no red flags in its text. The company is not established, for the same reason as before.

- **Hard gates:** unconfirmed: S7 (on-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a yes to G3 showing real forecasting or capacity planning, with a named scope and outcome.

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; existence not checked | `[grounded]` posting only |
| Mandate | Own the 13-week supply plan for a chilled ready-meals range; balance production capacity against forecast; run the weekly S&OP meeting | `[grounded]` posting |
| Working pattern | On-site in Utrecht | `[grounded]` posting |
| Scope read | A planning owner role; it carries the plan and the meeting | `[inferred]` from the listed duties |
| Market calibration | Not run; no salary band | — |
| Unknowns | Salary; whether the role owns the production schedule; contract type | — |
| Contradictions | None visible in the posting text | `[grounded]` posting |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| S1 | 3+ years supply or demand planning in FMCG | must_have | absent | none | transferability | You've never worked in planning. Route-performance and on-time work is the nearest adjacency, and it does not include forecasting or capacity | `[grounded]` your statement | G3 |
| S2 | Advanced Excel | must_have | unclear | low | discovery | Not mentioned in your background | `[grounded]` absence in your background | none |
| S3 | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning system appears in your background | `[grounded]` absence in your background | none |
| S4 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, not fluent | `[grounded]` your statement | none |
| S5 | Weekly cross-functional review | important | adjacent | medium | transferability | You ran the weekly route-performance review | `[grounded]` your background | none |
| S6 | Balancing capacity against forecast | important | absent | none | capability | No capacity or forecast work in your background | `[grounded]` absence in your background | G3 |
| S7 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Your location constraint is not stated | `[grounded]` posting | none |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G3 | Forecasting and capacity planning (S1, S6) | discovery | No forecasting or capacity work appears in your background | This is the decision: any real forecast or capacity work moves the status | Any demand forecast, capacity or staffing plan, or reorder model you built, even informally | A forecast sheet or capacity model with client data removed | `[inferred]` that this moves the decision; `[grounded]` absence in your background |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| SR1 | Planning experience required against none on your side | unknown | — | "3+ years of supply or demand planning in FMCG" | The role may be closed to career changers, or the requirement may be a screening line | `[inferred]` from the requirement's wording | Would you consider a candidate with adjacent planning experience and no FMCG years? | unresolved |

### Application plan

Nothing is proposed until G3 is answered. If the answer is no, the plan is to skip this role.

### Evidence status

Verified: none yet.

---

## Evidence status, both postings

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page (both employers) | unavailable | Four searches were refused. Neither employer's existence or live posting is checked, which is why the employer check above is still open |
| 2. Role-family sweep (salary and scope norms) | unavailable | Refused. No salary band or scope norm is given. Model memory is not a source for market values |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

---

**Dossier offer:** If you want to keep either assessment, I can write it out as a `tuesday-dossier.md` file.

**Upgrade menu:**
- Allow web search, or paste each employer's careers-page link. That checks existence and the live posting, and adds the salary and scope norms that are missing above.
- A dashboard screenshot with client data removed, or a temperature-feed spec, would raise R2, R3, R4 and R6 from `medium` toward `high` and would answer G1.

**Questions:**
- G1 (R5): Did any of your work involve temperature-controlled or regulated shipments or their data (cold chain, food, pharma), even as a side project? Say what it was and what you owned.
- G2 (R1): Is three days a week in the Rotterdam office workable for you?
- G3 (S1, S6): Have you ever built a forecast, a capacity plan or a supply plan, even informally in a spreadsheet? If so, what did it cover, and how did you know it was right?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.