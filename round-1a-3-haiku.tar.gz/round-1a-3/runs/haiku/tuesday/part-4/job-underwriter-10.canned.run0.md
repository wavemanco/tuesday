**Yes, worth taking the call, on conditions. Status: `conditional_go`.** The public pages agree with the posting (RR1, RR2). The WhatsApp message asks only for a call, which is a routine step, so it adds no risk entry.

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Pay €52,000–€60,000 plus 0.5–1% equity)
- `must_have`: direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important`: adjacent: R8 (Run research calls with school owners) · absent: R9 (Working as the only designer)

R7 — checkout is real, end-to-end ownership not yet shown; R9 — never done, and the posting says you'd be the first designer; R2 — no pay floor given, so unchecked.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** The scope is concrete (RR1) and the company's pages agree with the posting (RR2). Open items are the equity terms and the CTO title (RR3), and who holds design decisions when you're the only designer (RR4).
- **Conditions for go:** (1) a pay floor checked against €52,000–€60,000 (R2); (2) on the call, decision rights and design review are answered (RR4, R9); (3) the booking-flow claim stays at checkout unless you can confirm more (R7).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: Kelproster booking software for sea-kayak, surf and sailing schools; six people in Galway; founded 2023 by Ronan Kehoe and Saoirse Doyle; funded by customers | `[grounded]` fernquay.example/about |
| Role | First design hire; hybrid, two days a week in Galway; €52,000–€60,000 plus equity | `[grounded]` posting and careers page |
| Market calibration | Ireland survey, 3–5 years' experience: median €57,000, IQR €51,500–€62,000. The posting's range sits inside it, near the median. Ireland-wide, not Galway-specific | `[generic]` Tillerby 2026 survey (n=520); `[grounded]` posting for the range |
| Unknowns | Equity value and vesting; decision rights; Saoirse Doyle's CTO title (the about page says co-founder; "CTO" appears only in the WhatsApp message) | — |
| Contradictions | None between the posting and the careers page | `[grounded]` careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway last year; intake prose is self-report | `[grounded]` your intake | none |
| R2 | Pay €52,000–€60,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor from you, so nothing to check against | `[grounded]` posting | G3 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at one company; not probed | `[grounded]` your intake | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use; self-report | `[grounded]` your intake | none |
| R5 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers | `[grounded]` your intake | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | Four years in a squad with four engineers | `[grounded]` your intake | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | Checkout redesign is one step of booking; ownership of the rest is not stated | `[inferred]` bridge from checkout work to the posting's scope | G1 |
| R8 | Run research calls with school owners | important | adjacent | medium | transferability | Consumer customer sessions; school owners are a different buyer | `[inferred]` from your research history | none |
| R9 | Working as the only designer ("you would be our first designer") | important | absent | medium | transferability | Never been the only designer; the squad with engineers is the closest match | `[grounded]` your intake; `[inferred]` that the posting makes this a scope signal | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking flow end to end (R7, must_have) | transferability | Checkout redesign confirmed; nothing on search, booking entry or post-booking | The posting's core scope; the checkout claim is the strongest bridge | Any booking-flow work beyond checkout; decisions you made on flow structure | The checkout case study, if you can share it (see E2) | `[grounded]` your intake; `[inferred]` bridge |
| G2 | Only designer (R9, important) | transferability | No design peers so far; squad of engineers | Decision rights and critique may be thin | Solo projects, critique you arranged yourself, decisions you carried alone | Any example of design you shipped without a design review | `[grounded]` your intake; `[generic]` pattern for first design hires |
| G3 | Pay (R2, hard_gate) | hard_gate | Posted range; no floor from you | Only you can say whether the range works | Not applicable | Your own figure | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Concrete scope | positive_signal | — | "own the booking flow end to end"; "run research calls with school owners" | Work is defined, not a vague mandate | `[grounded]` posting | Which booking-flow decisions would be mine to make alone? | noted |
| RR2 | Public pages agree | positive_signal | — | "Six people, based in Galway" (about page) | Company is findable; careers page carries the same role and terms; the co-founder's profile lists five years as product lead at a Galway travel-software company | `[grounded]` about page, careers page, co-founder profile snippet | — | noted |
| RR3 | Equity and CTO title not public | unknown | — | "0.5–1% equity"; "Saoirse, our CTO" | Equity value depends on terms not published; CTO title appears only in the message | `[inferred]` from the posting against no public terms | What vesting, share class and dilution apply to the 0.5–1%? | unresolved |
| RR4 | Decision rights as the only designer | unknown | — | "You would be our first designer"; "most closely with our co-founder" | Design direction may sit with the founders, and you may carry decisions without design review | `[generic]` pattern for first design hires at small companies | Who sets design direction and priorities, and who reviews design decisions? | unresolved |

No request in the material asks you to pay, deposit, or give bank or ID details. The invite and the video-call scheduling are routine.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Describe the checkout work as "Redesigned the checkout flow at a Dublin travel-booking company", not "owned the booking flow end to end", unless you can confirm that | Keeps R7 honest; avoids scope drift | `[grounded]` R7 and your sentence | pending your approval |
| E2 | Before sending the checkout case study again, check your employer allows sharing it | Employment terms often restrict sharing work; I can't see yours | `[generic]` common in employment contracts | your check |
| E3 | Reply to Ronan with your available times for the 45-minute call | The invite came by email; a short reply is the only step | `[grounded]` WhatsApp message | pending your approval |
| E4 | Prep for the call with the mock-interview module, covering R9 and RR4 | Practice questions for the sole-designer question | `[generic]` | your choice |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay Galway booking software sea kayak surf schools" and "Fernquay careers Product Designer Galway"; fetched fernquay.example/about. Entity exists as described (Kelproster; six people; Galway; founded 2023). The careers page lists the same role and terms. Contradictions: none |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland Galway €52,000 €60,000 startup", which returned the Tillerby 2026 Ireland Design Salary Report (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration and R2's band |
| 3. Hiring manager's public footprint | yes | Searched "Fernquay Ronan Kehoe Galway", which returned his LinkedIn snippet (linkedin.example/in/ronan-kehoe). Moved the positioning: a Galway travel-software background. Snippet only; the page was not read in full |

## Upgrade menu

- Dossier offer: I can write this up as a tuesday-dossier.md you can keep and reuse.
- A read of the checkout case study, once E2 is checked → R7 and R3 toward `high`.
- Your pay floor → R2 closes, and the status may move to `go`.
- The equity terms in writing → RR3 closes.
- Answers on design decision rights → R9 and RR4 close.
- A deeper research pass on Fernquay (funding, leadership, past hiring; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

G3 — What pay figure would you not go below, and does the equity change that?

G1 — On the checkout redesign, did you make the decisions yourself, and did your work go past the checkout step?

G2 — How have you handled design work with no other designer around, and how do you feel about being the only one?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.