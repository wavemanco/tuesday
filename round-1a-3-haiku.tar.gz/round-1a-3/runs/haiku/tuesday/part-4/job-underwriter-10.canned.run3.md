**Yes, it's worth applying for, and the company looks real.** Status: `conditional_go`.

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (pay against your floor)
- `must_have`: direct: R3, R4, R7, R8 · adjacent: R5, R6
- `important`: adjacent: R9

R5 is a checkout redesign, not end-to-end ownership of the booking flow. R6 is consumer usability sessions, not research with school owners. R9 is the sole-designer setting you haven't worked in.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (€52,000–€60,000 against your pay floor); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** The company exists on its own site, and its careers page is live and matches the posting. The pay sits inside the Irish market band. The main risk is RR1, the sole-designer scope.
- **Conditions for go:** (1) you can work as the only designer, with no design peers; (2) the pay range clears your floor; (3) the rest of the process runs through the company's own domain.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, sells Kelproster booking software to sea-kayak, surf and sailing schools in Ireland and Scotland | `[grounded]` fernquay.example/about |
| Mandate | First designer: own the booking flow, run school-owner research calls, ship with two engineers | `[grounded]` posting and careers page |
| Scope read | One designer covering research, flow design and shipping is a broad remit for a single hire | `[inferred]` from the posting's scope against team size |
| Market calibration | Irish 2026 survey: product designers with 3–5 years have a median base of €57,000 (interquartile range €51,500–€62,000); the posting's €52,000–€60,000 sits inside that range | `[generic]` Tillerby 2026 Ireland design salary report (n=520); `[grounded]` posting figure |
| Working pattern | Hybrid, two days a week in Galway, plus 0.5–1% equity | `[grounded]` posting |
| Unknowns | Share count and vesting behind the equity; who makes final design calls; whether the "one messy real project" is a screen | — |
| Contradictions | None between the posting and the careers page | `[grounded]` both pages |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Galway | hard_gate | direct | medium | none | You live in Galway; prose self-report, no artifact | `[grounded]` your message | none |
| R2 | Pay €52,000–€60,000 against your floor | hard_gate | unclear | none | hard_gate | Your floor isn't stated, so the gate isn't settled | `[grounded]` posting | Q1 |
| R3 | 3+ years product design | must_have | direct | medium | none | Four years stated, no artifact yet | `[grounded]` your message | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use stated | `[grounded]` your message | none |
| R5 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow; ownership from research through shipping isn't stated. Limit: checkout, not the whole flow | `[inferred]` bridge from your checkout work | Q3; upgrade menu |
| R6 | Run research calls with school owners | must_have | adjacent | medium | transferability | Monthly usability sessions with customers; these were consumers, not B2B operators | `[inferred]` bridge from your sessions | Q3 |
| R7 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions stated | `[grounded]` your message | none |
| R8 | Works directly with engineers | must_have | direct | medium | none | Four-engineer squad stated | `[grounded]` your message | none |
| R9 | Sole or first designer (implied by "our first designer") | important | adjacent | medium | transferability | You've never been the only designer. Squad experience carries over; design peers and sole-owner decisions are the limit | `[inferred]` from the posting's "first designer" | Q2; G1 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Sole designer (R9) | transferability | Four-engineer squad; no design peers stated | The posting makes this the central scope question, and the fit call turns on it | Times you set a design direction without a design peer to check it; critique done with engineers or PMs | A note on how design decisions got made in that squad | `[inferred]` from the posting; `[generic]` that first-designer roles put most risk on one person |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Research, flow design and shipping in one role at a six-person company | risk_signal | medium | "You would be our first designer: own the booking flow end to end, run research calls…" | The role may carry more than one person can sustain, with no design review | `[inferred]` from scope against team size | Who makes the final design calls when design and engineering disagree, and who reviews the work? | unresolved |
| RR2 | Pay stated, inside the market range | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | Pay is transparent and realistic | `[generic]` survey band; `[grounded]` posting | Is €52,000–€60,000 the budgeted range, and where would an offer sit? | noted |
| RR3 | Equity value unclear | unknown | — | "0.5–1% equity" | Percentage without share count or vesting is hard to value | `[inferred]` from the posting's silence on terms | What is the total share count, the vesting schedule, and the strike price? | unresolved |

The WhatsApp message is routine scheduling for a call held elsewhere, so it gets no register entry and no condition.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle your pay floor before the call | R2 is unconfirmed | `[grounded]` R2 | your decision |
| A2 | Walk through the checkout case study, saying which parts you owned | R5 is the probe most likely to come up | `[grounded]` R5 | pending your approval |
| A3 | Describe the checkout work in your own terms ("I redesigned our checkout flow") and don't claim end-to-end ownership or B2B research | Keeps R5 and R6 honest | `[grounded]` your message; reframing audit applied | pending your approval |
| A4 | Answer the sole-designer question directly, with how you'd work without peers | RR1 and R9 | `[inferred]` RR1 | pending your approval |
| A5 | Ask the RR1–RR3 questions on the call | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A6 | Confirm the call invite came from the company's own domain before you join | Routine check, advice only | `[generic]` routine practice | your decision |

If you want a drill on the call itself, mock-interview can run one.

**Evidence status**

Verified: none yet. Your background is self-report until you confirm specifics; the case study the recruiter mentioned hasn't been seen.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay Product Designer Galway careers"; fetched fernquay.example/about and fernquay.example/careers/product-designer. Confirms the company exists as described and the role is live. Standing employer-not-established entry cleared |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland mid senior 2026", which returned the Tillerby 2026 Ireland Design Salary Report (tillerby.example/2026-ireland-design-salary-report). Sets the market calibration in role reality |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned a public LinkedIn profile: co-founder and CEO at Fernquay, previously a product lead at a Galway travel-software company for five years. Professional footprint only |

**Upgrade menu**

- An inspectable checkout case study or a before-and-after of the flow → R3, R5 to `high`.
- Your pay floor → R2 closes; the decision may simplify to `go` or `no_go`.
- A description of your research with any operator or B2B participants → R6 moves from `adjacent` toward `direct`.
- Deeper company diligence on Fernquay (funding, leadership, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

If you'd like this kept as a file you can update as the process moves on, I can write it as `tuesday-dossier.md`.

**Questions**

Q1 (R2): What is the lowest base you'd accept? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q2 (R9): When you worked in the four-engineer squad, who reviewed your design work, and what happened when you disagreed with an engineer about a design?

Q3 (R5, R6): Did the checkout redesign or the usability sessions involve any business customers, such as operators or venue owners, or only consumers?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.