**Yes, worth pursuing, on three conditions. Status: `conditional_go`.** Your core craft matches the posting, and nothing in the posting or the messages asks you to pay, deposit money, or give bank or ID details. I could not check that Fernquay exists from here, so that stays open. The WhatsApp message is a routine way to arrange a call when the invite comes by email. The one check is P2 below.

**Fit ledger**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000 plus 0.5–1% equity)
- `must_have`: direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end) · absent: R8 (Be the first designer)
- `important`: unclear: R9 (Research with school owners)

R7 is adjacent checkout work with its limit named; R8 has no sole-designer evidence and is the main gap; R2 has no pay floor given, so it can't be checked yet.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 plus 0.5–1% equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Opportunity ledger:** the terms are concrete (RR5, positive). Open items are employer verification (RR1), contract basis (RR2), equity terms (RR3) and the first-designer mandate (RR4).
- **What would change this:** (1) Fernquay verified, with the role on its own careers page and the company registered (RR1); (2) your pay floor set against the range, and the contract basis confirmed (R2, RR2); (3) a truthful answer ready on who reviewed your design calls (R8, RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting; not verified externally |
| Mandate | First designer: own the booking flow end to end, run research with school owners, ship with two engineers | `[grounded]` posting |
| Reporting | Works most closely with co-founder Ronan Kehoe; a 45-minute call with Ronan and CTO Saoirse | `[grounded]` message |
| Pay and equity | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Working pattern | Hybrid: two days a week in the Galway office | `[grounded]` posting |
| Scope read | Research, design and delivery in one role, with no design peer | `[inferred]` from the scope list against the stated team |
| Market calibration | Not run: the salary search was refused, so the range has no band to sit against | — |
| Unknowns | Contract type, equity terms, your pay floor, design review support, whether the company is registered and the posting live | — |
| Contradictions | None found between the posting and the message | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two office days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway last year. You haven't said whether you accept the hybrid pattern. | `[grounded]` your background | none |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | No pay floor or equity preference given, so nothing to check the range against. | `[grounded]` posting; no market band | Q1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as product designer at a Dublin travel-booking company. Self-reported, so the band stops at medium. | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily Figma use. No file or portfolio link yet. | `[grounded]` your background | none |
| R5 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers. Limit: usability testing, not discovery calls with business owners (see R9). | `[grounded]` your background | none |
| R6 | Works directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers. | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned a checkout flow, and the co-founder liked that case study. Checkout is one stage of a booking flow, and you worked it inside a squad. | `[grounded]` checkout work; `[inferred]` adjacency | G2 |
| R8 | Be the first designer, with no design peer | must_have | absent | medium | transferability | You have never been the only designer anywhere (your statement). Squad work is adjacent, not sole-designer work. | `[grounded]` your statement; `[inferred]` adjacency | G1 |
| R9 | Research with school owners, business customers | important | unclear | low | discovery | Your research has been with travel customers. Nothing you've said covers business owners who run the product themselves. | `[grounded]` absence; `[inferred]` difference from travel customers | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | First designer, no design peer (R8, must_have) | transferability | Squad work with four engineers; no sole-designer work | The role depends on making design calls alone, the objection most likely to be raised | Design calls you made inside the squad with no design reviewer; a time you pushed back on an engineering trade-off | Checkout case study with review notes or a decision log | `[grounded]` your statement; `[generic]` that first-designer roles often lack design review |
| G2 | End-to-end booking flow (R7, must_have) | transferability | Checkout redesign; no evidence of owning the whole flow | Checkout is one stage; a stronger bridge narrows the limit | Work on search, date selection, confirmation or rebooking | Case study showing the wider flow you touched | `[inferred]` bridge from checkout work |
| G3 | Business-owner research (R9, important) | discovery | Research with travel customers | Research with school owners is a stated responsibility | Interviews or tests with business owners, even in another sector | Notes or a summary of any such work | `[grounded]` absence; `[generic]` that business users differ from consumers in research |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified from here | unknown | — | "We are six people in Galway" | Company existence, stage and posting status are unchecked. The search was refused, so this is not a finding. Thin footprints are common at this size. | `[generic]` pattern for small companies; not a claim about Fernquay | Which company is registered for this role, and where is it listed on your own careers page? | unresolved |
| RR2 | Contract basis unstated | unknown | — | Posting silent on permanent or fixed-term | The role could be fixed-term. | `[inferred]` from posting silence | Is this a permanent contract or fixed-term, and what is the probation period? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | Share class, vesting and total share count are unknown, so the percentage is hard to value. | `[generic]` equity terms usually come with vesting | What share class is the equity, what is the vesting schedule, and how many shares are issued in total? | unresolved |
| RR4 | First-designer mandate with no design peer | risk_signal | medium | "You would be our first designer: own the booking flow end to end…" | Responsibility may be broad, with no one to review design decisions. | `[inferred]` from scope against team size | Who reviews design decisions day to day, and which decisions does this role make alone? | unresolved |
| RR5 | Concrete terms stated | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity. Hybrid: two days a week…" | Stated terms and named interviewers suggest transparency. | `[grounded]` posting | What would the first 90 days look like, and how would you measure success? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the checkout case study, described as squad work, not sole ownership | R7, R8 | `[grounded]` your case study; wording for your approval | pending your approval |
| P2 | Before the call, check that the invite comes from Fernquay's own domain, and find the role on its website | RR1 | `[generic]` routine check; this is advice, not a register entry | advice |
| P3 | On the call, ask about contract basis, equity share class and vesting, and design review support | RR2, RR3, RR4 | `[grounded]` register | pending your approval |
| P4 | Prepare an honest answer on who reviewed your design decisions, and what you did instead | R8 | `[grounded]` your statement | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Fernquay were refused, so the company's existence, stage and posting status are unchecked. Would have moved RR1 and the employer-not-established check. |
| 2. Role-family sweep | unavailable | The salary search was refused, so €52,000–€60,000 is uncalibrated. Would have moved R2 and the market calibration. |
| 3. Hiring manager's public footprint | unavailable | The search for Ronan Kehoe was refused. Would have informed positioning for the call. The CTO was not searched. |

The search tool was not permitted in this session, so I did not retry.

## Upgrade menu

- A check of Fernquay's own careers page and registered company name → RR1 closes or reduces. I can run it myself if search permission is granted.
- Your pay floor and contract preference → R2 and RR2 close, and the status may move to `go`.
- A shareable link to the checkout case study you sent them → R4 and R7 can move up, with a probe expected.
- Notes from any work with business owners → R9 and G3 move.
- Search permission for this session → targets 1–3 run.

I can write this up as a `tuesday-dossier.md` you can keep and add to later.

**Questions**

**G1 (R8)**: When you redesigned the checkout, who reviewed your design decisions before they shipped?

**R2**: What is the lowest salary you would accept for this role?

**G3 (R9)**: Have you designed or researched anything for business owners who run the product themselves, rather than for their customers?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.