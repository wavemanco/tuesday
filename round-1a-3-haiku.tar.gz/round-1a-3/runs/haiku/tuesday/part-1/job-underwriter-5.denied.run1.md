**Yes, worth applying, on conditions. Status: `conditional_go`.** Your core stack matches the posting. The open items are location and pay, ingestion and data-contract experience, and whether the role is live on Pellucid's own careers site.

**Fit ledger.**

- `hard_gate`: unclear: R1 (US-based remote or Denver location), R10 (base pay against your floor)
- `must_have`: direct: R2 (5+ years data engineering), R3 (strong SQL and Python), R4 (dbt and a cloud warehouse), R6 (orchestration with Airflow or similar), R7 (data quality testing)
- `important`: adjacent: R5 (BigQuery warehouse); unclear: R8 (ingestion from our app and CRM), R9 (data contracts our analysts depend on)

R5 — Snowflake dbt work carries over, BigQuery untested (`medium`); R8 and R9 — no ingestion or contract experience stated, one question to ask.

**Opportunity ledger.** Posted pay sits around the market median and its midpoint is above it (RR4). Equity terms are unstated (RR1). The company facts are self-reported and unchecked here (RR2). No hiring manager is named (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (US-based remote or Denver location), R10 (base pay against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this (conditions for go):** (1) R1 and R10 confirmed: you're US-based and $148,000 base clears your floor; (2) RR2 clears: the role appears on pellucidlearning.com's careers page; (3) R8 and R9 answered with real ingestion or contract work, or framed honestly as untested.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches (company facts; the posting) were refused by the session's permission setting, so nothing returned. The posting and about-page text you pasted are in hand, but whether the role is live and the company facts (31 states, 264 staff, Series C) are unchecked. Would have moved the organization row and RR2. |
| 2. Role-family sweep | unavailable | One search (senior data engineer pay, Series B–D) was refused. The market band rests on the Datawright figures you relayed, unchecked. Would have moved the market calibration and RR4. |
| 3. Hiring manager's public footprint | n/a | No name given, so there was no query to form. |

**Verified: none yet.**

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online K-12 tutoring in 31 states; founded 2016; 264 employees; Series C, $52M, Feb 2026 | `[grounded]` your pasted about page, self-reported, unchecked |
| Mandate | Build and run reporting pipelines: app and CRM ingestion, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | Ownership of one domain's reporting pipelines, from ingestion to contracts; no reports stated | `[inferred]` from the listed responsibilities |
| Market calibration | Senior at Series B–D: base median $151,000, IQR $139,000–$163,500; "Senior" typically 5–8 years, which your six years sit in | `[generic]` Datawright 2026 report as you relayed it, unchecked here |
| Unknowns | Equity terms; hiring manager and team; contract basis (full-time not stated); your location | — |
| Contradictions | None between the JD and the about page. BigQuery versus your Snowflake is a fit gap, not a contradiction | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | US-based remote, or Denver office | hard_gate | unclear | none | hard_gate | Your location and work authorization are not stated | `[grounded]` JD | Q1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | Six years stated; self-report, no artifact yet | `[grounded]` your intake | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no artifact yet | `[grounded]` your intake | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project on Snowflake, about 180 models | `[grounded]` your intake | none |
| R5 | BigQuery warehouse (role description) | important | adjacent | medium | transferability | dbt and SQL carry over; BigQuery never used, so its cost, partitioning and permissions are untested | `[inferred]` bridge from your Snowflake work | G2, A2 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow orchestration stated | `[grounded]` your intake | none |
| R7 | Data quality testing | must_have | direct | medium | none | Great Expectations suite set up; ownership after setup not stated | `[grounded]` your intake | none |
| R8 | Ingestion from our app and CRM | important | unclear | none | discovery | Nothing stated | `[grounded]` absence in material | G1, Q3 |
| R9 | Data contracts analysts depend on | important | unclear | none | discovery | Nothing stated | `[grounded]` absence in material | G1, Q3 |
| R10 | Base pay $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your floor not given; the posted base is a stated term | `[grounded]` JD | Q2 |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion and contracts (R8, R9) | discovery | Neither mentioned | Two important rows covering the analyst-facing half of the role | Pipelines from an app database, Salesforce or HubSpot; a schema agreement with analysts | A pipeline repo or a contract doc | `[inferred]` these are where your background is silent |
| G2 | BigQuery (R5) | transferability | Snowflake dbt at about 180 models; no BigQuery | The posting names BigQuery as the warehouse | Any BigQuery use: a sandbox, a migration, a shared project | A short BigQuery project or a cost note | `[grounded]` posting names BigQuery; `[inferred]` the limit |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Equity terms unstated | unknown | — | "plus equity" | Equity may be a large or small part of total pay; no grant size or vesting given | `[generic]` startup equity is usually negotiated | What equity grant does this role carry, and on what vesting schedule? | unresolved |
| RR2 | Company facts unchecked | unknown | — | "Series C ($52M, February 2026)" | Facts come from their own about page. If the role isn't on their careers site, the employer-not-established entry applies and caps the decision at `conditional_go` | `[generic]` self-reported stage and size are unverified until checked | Can you point me to this role on your careers site, and who would I interview with? | unresolved |
| RR3 | No hiring manager named | unknown | — | (none named) | Reporting line and team are unknown, and they shape the scope | `[generic]` role-family pattern | Who is the hiring manager, and which team does this role sit in? | unresolved |
| RR4 | Posted base near market median | positive_signal | — | "$148,000–$166,000" | Midpoint $157,000 is above the $151,000 median; the top of the range is above the IQR top | `[generic]` Datawright band, unchecked; `[grounded]` posted range | Is this band fixed or open to negotiation? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm your location, work authorization and pay floor before investing in the loop | R1, R10 | `[grounded]` gate rows | proposed |
| A2 | Bridge line for BigQuery, for the cover letter or screen: "I built our dbt project on Snowflake, about 180 models, and have not used BigQuery yet." Audit: each clause traces to your sentences | R5 | `[grounded]` your intake | pending your approval |
| A3 | Ask RR1–RR3 at the first screen | Open questions that could move the decision | `[grounded]` register | proposed |

**Dossier offer:** I can write this up as a `tuesday-dossier.md` so the open rows carry into later sessions.

**Upgrade menu**

- Search access granted: targets 1 and 2 run, RR2 closes or escalates, and the pay band gets checked.
- A pipeline repo or schema doc for ingestion and contracts → R8 and R9 move.
- Any BigQuery use at all → R5's limit narrows.
- Your location, work authorization and pay floor → R1 and R10 resolve.
- The hiring manager's name → the scope read and which story to lead with.
- A deeper pass on Pellucid (funding, leadership, reviews; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

- R1: Are you based in the US, and can you work remotely from there?
- R10: Is $148,000 base the lowest you would accept?
- G1: Have you built ingestion from an app database or a CRM, or owned a data contract that analysts relied on?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.