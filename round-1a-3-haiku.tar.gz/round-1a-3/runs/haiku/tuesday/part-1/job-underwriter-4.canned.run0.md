**Yes, go for it, but confirm the location first.** Status: `conditional_go`. The posting contradicts itself on location: the JD says fully remote (UK), and the careers page says Leeds, four days a week. If the Leeds version is the real one, the decision changes.

**Fit ledger.**

- `hard_gate`: unclear: R1 (location: fully remote UK vs Leeds four days a week)
- `must_have`: direct: R2 (4+ years pricing analytics), R3 (SQL and Python), R4 (GLM), R5 (presenting to underwriting or actuarial leads)
- `important`: direct: R6 (price test design and reading); adjacent: R7 (monitoring rating models)
- `preferred`: adjacent: R8 (insurance experience, motor not pet)

R1 is the one row that could flip the decision. The must-haves rest on your own claims, which are `medium` until there's an artifact to inspect. R7 and R8 are adjacent, not direct.

**Opportunity ledger.** The role is well scoped on paper, with the JD naming the outcomes and the work. The location terms conflict (RR1), decision rights over rate changes are unstated (RR2), and the salary is withheld (RR3). The company footprint is thin (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (fully remote UK vs Leeds four days a week); candidate constraints not given. Checks against them are unknown, so I haven't tested R1 against your own location or schedule limits.
- **Severe red flags:** none found.
- **Conditions for go:** (1) written confirmation that the role is fully remote, or that Leeds is workable for you (RR1, R1); (2) the decision-rights answer on rate changes (RR2); (3) the pet-insurance gap is framed as adjacent, never as pet experience.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech; pet-insurance product | `[grounded]` JD and careers page |
| Hiring manager | Odile Varga, Director of Pricing. Previously head of pricing analytics at Calloway Re for six years; spoke in 2025 on monitoring rating models in small books | `[grounded]` public profile, search snippet only |
| Scope | Owns pricing analytics; reports to the Director of Pricing; no team size stated | `[grounded]` JD and careers page |
| Working pattern | Conflict: "Fully remote (UK)" in the JD; "Leeds office four days a week" on the careers page | `[grounded]` both sources |
| Market calibration | Pricewell 2026 pay survey (n=612, UK insurers and insurtechs): median £58,400, interquartile range £52,100–£64,900. Read from the search snippet, not the full page | `[generic]` role-family band |
| Unknowns | Salary; rate-change decision rights; whether the role manages anyone; monitoring scope | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | Fully remote UK | hard_gate | unclear | medium | hard_gate | Your location constraint isn't in the material, so I can't say whether either version works for you | `[grounded]` both sources conflict |
| R2 | 4+ years pricing analytics | must_have | direct | medium | none | Five years, two as senior analyst; your own statement | `[grounded]` CV, unprobed |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use; no artifact yet | `[grounded]` CV, unprobed |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM | `[grounded]` CV, unprobed |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` CV, unprobed |
| R6 | Designing and reading price tests | important | direct | medium | none | 14 tests last year with underwriting | `[grounded]` CV, unprobed |
| R7 | Monitoring rating models | important | adjacent | medium | transferability | You built and maintained a model; the material doesn't say you monitored it in production | `[inferred]` from R4's build-and-maintain claim |
| R8 | Insurance experience (a plus) | preferred | adjacent | medium | transferability | Motor insurance, not pet. Pet pricing has different loss drivers, so the bridge is partial | `[inferred]` motor-to-pet bridge; `[generic]` pet pricing differs |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Useful evidence |
|---|---|---|---|---|---|
| G1 | Monitoring (R7) | transferability | Model building is clear; monitoring isn't | Monitoring is the stated core of the role, and Odile's public talk is on it | Monitoring pack, drift or performance report, or a model review you ran |
| G2 | Pet insurance (R8) | transferability | Motor only | Preferred, so a minor risk | Any pet-adjacent work, such as a pet product review or a vet-cost analysis |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location terms conflict | risk_signal | medium | "Fully remote (UK)" vs "Leeds office four days a week" | Either the careers page is stale, or the hybrid policy differs between sources | `[inferred]` from the two sources | Is this role fully remote, or is it Leeds four days a week? | unresolved |
| RR2 | Rate-change decision rights unstated | unknown | — | "Own pricing analytics" | Recommendations may go to the Director of Pricing, not be decided by the role | `[inferred]` from the JD's verbs | Which rate changes does this role approve, and which does it only recommend? | unresolved |
| RR3 | Salary withheld | unknown | — | Not stated | Pay may sit inside the survey band, or the company may not publish pay | `[inferred]` from the withheld figure, against `[generic]` band | What base salary is budgeted for this role? | unresolved |
| RR4 | Thin public footprint (standing) | risk_signal | low | Careers page only | A small company may simply have little press. One broad search found no other coverage | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to the team's structure and who I'd report to? | reduced |

**Application plan** (proposed; nothing is sent without your approval)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Ask the employer, through contact details from its own site, to confirm the location in writing | RR1, R1 | `[grounded]` RR1 | pending your approval |
| P2 | Lead with GLM, price tests and underwriting presentations. Describe the pet gap as adjacent, not experienced | R4, R6, R5, R8 | `[grounded]` map; reframing audit | pending your approval |
| P3 | Prepare a monitoring example from your model work, if one exists | G1 | `[inferred]` from R7 | pending your approval |

**Evidence status**

Verified: R2, R3, R4, R5, R6 claims from your CV, unprobed (`medium`). Unverified: none beyond that.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance" (no results) and "Brindlemoor careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved the contradictions row and RR1 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary"; returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (snippet only). Moved the market calibration band |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor"; returned "Odile Varga — Director of Pricing, Brindlemoor" (public profile, snippet only). Moved the scope read and the positioning |

**Dossier offer.** I can write this up as a `tuesday-dossier.md`, which you can keep and update once the location is confirmed.

**Upgrade menu**

- Written confirmation of location → R1 and RR1 close, and the status likely becomes `go` or `no_go`.
- A monitoring artifact → R7 moves up from adjacent.
- The budgeted base salary → RR3 closes against the survey band.
- A deeper pass on Brindlemoor (funding, leadership, past hiring; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

R1 — Can you work from Leeds four days a week, and is fully remote a requirement for you? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G1 — Did you monitor the young-driver model after you built it: drift checks, performance reviews, or a recalibration? What did you do, and is there a pack or report from it? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.