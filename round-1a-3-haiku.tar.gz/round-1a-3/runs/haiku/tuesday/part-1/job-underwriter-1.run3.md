**Yes, on the core requirements, as your background reads today. Status: `conditional_go`.** Apply once the posting checks out and location and pay are confirmed against your constraints.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (location and work pattern)
- `must_have`: direct: R2, R3, R4, R5, R7; unclear: R6 (metrics layer definition)
- `important`: adjacent: R8a (product managers); unclear: R8b (clinicians), R9 (mentoring two junior analysts)
- `preferred`: adjacent: R10b (consumer privacy regime work); absent: R10a (HIPAA data)

R6 — ownership of metric definitions not established; R9 — mentoring not stated; R8b — no clinician work stated; R10a — no healthcare data; R8a and R10b — adjacent, with limits named.

- **Hard gates:** none failed; unconfirmed: R1 (location and work pattern); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** Unverified: the employer and posting (RR3), and location and pay, which the posting doesn't state (RR1, RR2). Positive: the scope is concrete (RR4).
- **Conditions for go:** (1) the posting is confirmed on Harborlight's own careers page (RR3); (2) location and pay are checked against your constraints (R1, RR1, RR2); (3) R6 and R9 hold up in the first conversation.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C | `[grounded]` JD |
| Mandate | Own product analytics for the care-navigation app | `[grounded]` JD |
| Scope read | Metrics layer, experimentation, self-serve dashboards, PM and clinician partnership, mentoring two juniors: a full analytics-lead remit | `[inferred]` from the JD's responsibility list |
| Pay | Not stated | — |
| Location and work pattern | Not stated | — |
| Market calibration | Not run; the role-family search was refused (see research line), so no pay band is given | — |
| Unknowns | Location, pay, reporting line, whether an analytics team already exists, data stack beyond Looker, clinician access to data | — |
| Contradictions | None visible from the JD alone; the careers page was not checked | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location and work pattern (candidate constraint not given) | hard_gate | unclear | none | hard_gate | The JD is silent and you haven't stated a constraint | — | Ask the constraints question |
| R2 | 5+ years product analytics | must_have | direct | medium | none | Six years at a consumer-subscription company, stated at intake; no dated CV yet | `[grounded]` intake statement | Check dates against the CV |
| R3 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake is the evidence; "expert" is a level only a probe can show | `[grounded]` intake statement | Use "daily SQL on Snowflake", not "expert" |
| R4 | Experiment design at scale | must_have | direct | medium | none | Designed and ran the program, 30+ tests a year, including the pricing test | `[grounded]` intake statement | Confirm the basis of the 11% figure before citing it |
| R5 | Looker or similar BI | must_have | direct | medium | none | Built the company's Looker instance from scratch; 40+ governed dashboards | `[grounded]` intake statement | A sanitized screenshot would raise this to high |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed dashboards" don't establish that you owned canonical metric definitions | `[inferred]` from the JD's responsibility list | Question Q1 |
| R7 | Written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly metrics memo read by the exec team; monthly presentation to the VP Product | `[grounded]` intake statement | None |
| R8a | Partner with product managers on roadmap decisions | important | adjacent | medium | transferability | Product-leadership presentations and experiments for product teams; no stated roadmap decision that came from your analysis | `[inferred]` from the intake | Get one named example |
| R8b | Partner with clinicians | important | unclear | none | discovery | No clinician-facing work stated | `[grounded]` intake silence | Gap G3 |
| R9 | Mentor two junior analysts | important | unclear | none | discovery | Not stated | `[grounded]` intake silence | Question Q2 |
| R10a | Healthcare data, HIPAA (a plus) | preferred | absent | none | capability | No healthcare data experience | `[grounded]` intake statement | Gap G4 |
| R10b | Privacy-regime work (adjacent to HIPAA's requirements) | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII and the consent-state model; adjacent, not equivalent | `[grounded]` intake statement; `[inferred]` adjacency | Position as privacy adjacency only |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | Governed dashboards are established; metric ownership is not | A must-have row; the answer decides whether it reads `direct` | Canonical retention or activation definitions; a metric-dictionary or semantic-layer project; deciding which definition won a dispute | A metric dictionary, a dbt or Looker model excerpt, a definitions doc | `[grounded]` intake silence |
| G2 | Mentoring (R9, important) | discovery | Not stated | Explicit in the JD | Onboarding or reviewing a junior's analyses; coaching on test design | Onboarding plan, review notes | `[grounded]` intake silence |
| G3 | Clinician partnership (R8b, important) | discovery | No clinician-facing work stated | Explicit in the JD | Work with ops, care teams, or any non-product clinical stakeholder | A stakeholder example | `[grounded]` intake silence |
| G4 | HIPAA and PHI (R10a, preferred) | capability | No healthcare data | Preferred, so a minor risk | Privacy-by-design work; HIPAA training; any PHI-adjacent project | A training certificate, or a scoped project | `[generic]` that healthcare employers weigh this |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location and work pattern not stated | unknown | — | (none in posting) | The role may be on-site or hybrid in a location that doesn't suit you | `[inferred]` from the JD's silence | Is this role remote, hybrid, or on-site, and in which locations? | unresolved |
| RR2 | Pay not stated | unknown | — | (none in posting) | The posting may withhold pay, or the band may sit below your floor | `[inferred]` from the JD's silence | What is the base salary range for this role? | unresolved |
| RR3 | Employer and posting not verified from outside sources | unknown | — | "Senior Product Analyst — Harborlight Health" | The posting may be stale or aggregated, or the employer may be less established than it reads; none of these is established yet | `[generic]` pattern for unverified postings, not a claim about this employer | Can you point me at this role on Harborlight's own careers site, and who would I interview with? | unresolved |
| RR4 | Scope and outcomes are concrete | positive_signal | — | "define and maintain the metrics layer" | Ownership is defined, so success is checkable | `[grounded]` JD | What does success look like at six and twelve months? | noted |
| RR5 | Clinician work may involve regulated data access | risk_signal | low | "partner with ... clinicians" | Access to PHI may be restricted, shaping the analytics work | `[inferred]` from the clinician partnership and the HIPAA mention | What data can analysts access, and how is PHI separated from product analytics? | unresolved |

**Severe red flags:** none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm the posting on Harborlight's careers site before investing in an application | RR3 | `[grounded]` RR3 | pending your approval |
| P2 | Confirm whether the 11% figure is the test's measured effect, with its interval, before using it | R4 | `[grounded]` R4 | pending your approval |
| P3 | Lead with the Looker build and the 30+ test program; say "daily SQL on Snowflake", not "expert SQL" | R3, R4, R5 | `[grounded]` intake; reframing audit | pending your approval |
| P4 | Present the consent-state and GDPR/CCPA work as privacy adjacency to HIPAA, and don't claim HIPAA knowledge | R10a, R10b | `[grounded]` intake; reframing audit | pending your approval |
| P5 | Ask RR1–RR5's verification questions in the first conversation | Register doubles as interview prep | `[grounded]` register | pending your approval |

Every row is a proposal. Nothing goes into a CV or outreach until you approve it.

## Evidence status

Verified: none yet. Everything above is intake prose, which counts as self-report until you answer a specific probe.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused at the tool permission step, so nothing was read. It would have settled whether the employer exists as described and whether the posting is live (RR3) |
| 2. Role-family sweep | unavailable | One search was refused. It would have set the title and pay band (role reality, RR2) |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Dossier offer

I can write this up as `tuesday-dossier.md` whenever you want it kept.

## Upgrade menu

- A sanitized Looker screenshot or a redacted metrics-memo outline → R5 and R7 to `high`
- A sanitized readout of the pricing test (design, sample, the 11% result and its interval) → R4 to `high`, and the probe is ready
- The live posting link or the careers page → RR3 closes; the decision could move to `go`
- The budgeted salary or a published band → RR2 closes
- Permission to re-run web research (up to 5 searches and 2 fetches) → RR3 and RR2 can be checked
- A deeper research pass on Harborlight (funding, leadership, recent news; up to 5 more searches and 2 more fetches): say the word and it runs

## Questions

Q1 (G1, R6): Did you define and maintain canonical metric definitions, such as retention or activation, in the warehouse or in Looker, or did another team own them?

Q2 (G2, R9): Have you managed or mentored junior analysts? How many, for how long, and what did you do with them?

Q3 (R1): What are your location, work-pattern, and pay constraints for this role, and is any of them non-negotiable?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.