**Short answer: not wasted, but a stretch.** Your adjacent work is strong. The posting's must-have for titled PM years is the part you don't meet, and that is the one to address before you apply.

Status: `conditional_go`. Apply once the posting checks out on Quartzline's own careers page. The conditions are below.

**Fit ledger.** Stage assumed: evaluating.

- `must_have` — direct: R3, R4a · adjacent: R1a, R2, R6 · unclear: R4b, R5 · absent: R1b
  - R1a (3+ years of PM work), R2 (shipped API or platform products), R6 (owning the roadmap), R4b (sales stakeholders), R5 (agile delivery), R1b (3+ years with a PM title)
- `important` — direct: R7 · adjacent: R8, R10 · unclear: R9

R3 and R4a are evidence you already hold; R7 needs better wording, not new evidence; R1a, R2, R6, R8 and R10 are adjacent work with the limits named; R1b is the title itself; R4b, R5 and R9 have no evidence either way yet.

**Opportunity ledger.** The posting names its deliverables concretely (RR3, positive). Scope is wide for one PM across two squads (RR2), and adoption metrics are listed without targets (RR1). Employer and posting are unchecked (RR4), and no compensation is in the text you gave me.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on Quartzline's own careers page (RR4); (2) you can state concretely what product decisions you made in the adjacent work (R2, R6, Q-R2); (3) the scope in RR2 turns out to include the decision rights over squad priorities.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B, as you described it | `[grounded]` your JD text; not checked externally |
| Mandate | Own the roadmap for a partner-facing API platform; discovery with integration partners; specs and delivery with two engineering squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| Scope read | One PM role covers discovery, specs, delivery, metrics and launches | `[inferred]` from the listed responsibilities |
| Market calibration | Not established. The role-family search was refused, so there is no compensation band | — |
| Unknowns | Decision rights over squad priorities; success targets for metrics; contract basis; location; reporting line; compensation | — |
| Contradictions | None found within the text you gave. Not checked against the live posting | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years of product management work | must_have | adjacent | medium | transferability | Seven years as implementation lead with requirements ownership and roadmap-input sessions. That is PM-adjacent work, not PM work by title. Limit: no roadmap or squad ownership named | `[grounded]` CV; `[inferred]` adjacency | Q-R2 |
| R1b | 3+ years with a product management title | must_have | absent | medium | transferability | No PM title held. Your intake statement, not yet probed | `[grounded]` your statement | Carry as the named limit |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ REST integrations delivered end to end. The CV describes delivering on the API, not shipping the product | `[grounded]` CV; `[inferred]` adjacency | Q-R2 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI reading. Self-reported, no artifact; expect a probe on schema design | `[grounded]` CV | none |
| R4a | Stakeholder management: engineering and customers | must_have | direct | medium | none | Coordinated engineers, client engineers and PMs on custom builds | `[grounded]` CV | none |
| R4b | Stakeholder management: sales | must_have | unclear | low | discovery | CV silent on sales | `[grounded]` CV silence | Ask in the loop; not asked this turn |
| R5 | Agile delivery | must_have | unclear | low | discovery | CV names no sprints, backlog or cadence | `[grounded]` CV silence | Q-R5 |
| R6 | Owning a partner-facing API platform roadmap | must_have | adjacent | medium | transferability | Quarterly roadmap-input sessions collecting client feedback for product. That is input, not decision rights | `[grounded]` CV; `[inferred]` adjacency | Q-R2 |
| R7 | Discovery with integration partners | important | direct | medium | presentation | Scoping workshops, requirements and integration architecture with clients are discovery work; the CV does not frame them that way | `[grounded]` CV | Edit A2 |
| R8 | Specs and delivery with two engineering squads | important | adjacent | medium | transferability | Requirements documents and coordinated engineers; no squad ownership named | `[grounded]` CV; `[inferred]` adjacency | Carry as a limit |
| R9 | Defining and tracking adoption metrics | important | unclear | low | discovery | No metrics on the CV. A prior-conversation note about a triage tool is an unconfirmed lead, not evidence | `[grounded]` CV silence; memory lead unconfirmed | Q-R9 |
| R10 | Coordinating launches with sales and support | important | adjacent | medium | transferability | Go-live and UAT across 30+ integrations; no sales or support coordination named | `[grounded]` CV; `[inferred]` adjacency | Ask in the loop; not asked this turn |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Titled PM years (R1a, R1b) | transferability | Adjacent years, no PM title | The must-have names the title's years; adjacent work narrows it but does not close it | A platform or integration decision you made and owned, or a feature you scoped with sign-off | Release notes, a prioritization record or roadmap doc you wrote | `[grounded]` CV; `[generic]` that this kind of remit tends to screen for the title |
| G2 | Shipped product and roadmap ownership (R2, R6) | transferability | Integrations delivered; roadmap input collected | The posting asks for ownership, and that is the part with the most distance | A release you scoped and shipped; a call you made against a conflicting client ask | Release note, roadmap record | `[inferred]` from the CV's delivery and input work |
| G3 | Agile delivery (R5) | discovery | No cadence named | A must-have; one answer can settle it | Sprints or Kanban with an engineering squad; owning a backlog or running planning | Sprint board, retro notes | `[grounded]` CV silence |
| G4 | Adoption metrics (R9) | discovery | No metrics on the CV | Important tier; the role owns measurement | Any adoption measure on a feature, integration or internal tool | A dashboard, or an adoption number | `[grounded]` CV silence |
| G5 | Sales stakeholders (R4b) | discovery | None named | Must-have tier; also bears on R10 | Pre-sales scoping with an account executive; a deal scoped on your work | A scoping note | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Adoption metrics named, no targets | unknown | — | "define and track adoption metrics" | Success may be undefined at hire | `[inferred]` from the listed metric against no target | What adoption target will this role be held to in year one, and what is the current baseline? | unresolved |
| RR2 | One PM across two squads, five functions | risk_signal | medium | "own the roadmap … two engineering squads … coordinate launches" | One PM may carry delivery and launch accountability without decision rights over squad priorities | `[inferred]` from the JD's scope against its silence on decision rights; `[generic]` that remits spanning several squads often lack that | Which squad priorities does this role set directly, and which sit with the engineering leads? | unresolved |
| RR3 | Concrete stated deliverables | positive_signal | — | "coordinate launches with sales and support" | The job can be described and tested in interview | `[grounded]` JD | Which launch in the last year moved an adoption number, and which number? | noted |
| RR4 | Employer and live posting unchecked | unknown | — | "B2B logistics-tech, ~150 people, Series B" | Unchecked, not disproved: the company's existence and the posting's currency are unknown from here | `[grounded]` the refused search | Can you point me at this role on Quartzline's own careers site, and who would I interview with? | unresolved |
| RR5 | Compensation not in the text given | unknown | — | (none in the JD text you pasted) | Pay may be withheld, or it may sit in a section that was not pasted | `[grounded]` the text you gave | What is the base salary range for this role? | unresolved |

The standing "employer not established" entry applies only when research runs and fails to attribute the employer. Research was refused here, so RR4 records it as unchecked. If the check runs and fails, the cap is `conditional_go` again, which is already this status.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the posting on Quartzline's own careers page before you invest in the application | Closes RR4 | `[inferred]` from the refused check | proposed |
| A2 | CV bullet, replacing "Ran quarterly roadmap-input sessions collecting client feedback for product": "Ran quarterly roadmap-input sessions, collecting client feedback for product's roadmap; scoped 30+ client REST integrations from workshop to go-live." The clause "30+" stays attached to integrations, and no decision rights are added | Presents R7 and R6 without new claims | `[grounded]` CV | `resume_edits_pending_approval` |
| A3 | Interview framing for R1b: "I haven't held a PM title. My product-facing work has been [the adjacent work, with its limits]." | Says the gap before the interviewer does | `[grounded]` your statement | pending your approval |
| A4 | Don't claim sales, agile or metrics experience until G3–G5 are answered | Truthfulness core | `[grounded]` R4b, R5, R9 | proposed |

## Evidence status

Verified: none yet. Everything above is intake prose, which counts as CV-equivalent until probed.

Unverified lead: a prior-conversation note says you built an internal request-triage tool that support agents adopted. It is unconfirmed, so it is not used as evidence, only as the basis for Q-R9.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both search calls for Quartzline's careers page and the role were refused by permission, and I did not retry them. Would have moved the organization row, the contradictions row and RR4 |
| 2. Role-family sweep | unavailable | Both search calls for the role's scope and pay were refused. Would have set the market calibration line; no band is given |
| 3. Hiring manager's public footprint | n/a | No name given, so there was no query to form |

## Upgrade menu

- A link to the live posting or Quartzline's careers page, plus permission to search → rechecks targets 1 and 2, and closes RR4 and RR5.
- A sanitized integration playbook or requirements document → R2 and R8 move from `medium` toward `high`.
- A base salary range from the posting or the recruiter → closes RR5 and sets the figure against a market band.
- One release or feature you scoped, with any adoption number from it → R2, R6 and R9 move.
- The hiring manager's name → positioning for R1b and which story to lead with.
- Your constraints (pay floor, location, contract type, start date) → the hard-gates line can then run its checks.

If you'd like, I can write this up as `tuesday-dossier.md` so mock-interview can use it later.

**Q-R2 / R6:** Think of one integration capability or API change that got built partly because of input you gathered. Did you decide what went in, or only supply the evidence? What did you decide, and how did you know it worked?

**Q-R9:** A note from a previous conversation says you built an internal request-triage tool that support agents adopted. I haven't verified that. Is it real? If so, what did it do, who used it, and how did you measure adoption?

**Q-R5:** Have you worked inside sprints, or a Kanban board, with engineering squads? Did you own a backlog, or run any of the planning or review meetings?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.