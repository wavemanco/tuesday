**Yes, it's worth applying, on conditions.** Your six years on a dbt, Airflow, Python and SQL stack covers the must-haves. The open items are BigQuery, ingestion and data contracts, and two hard gates I can't check yet.

**Status: `conditional_go`**

**Fit ledger.**

- `hard_gate`: unclear: R9 (Remote (US) or Denver office), R10 (Base salary $148,000–$166,000)
- `must_have`: direct: R1 (5+ years data engineering), R2 (SQL and Python), R3 (dbt and a cloud warehouse), R4 (Airflow or similar), R5 (data quality testing)
- `important`: adjacent: R6 (BigQuery warehouse); unclear: R7 (ingestion from app and CRM), R8 (data contracts with analysts)

R6 — BigQuery is the warehouse the role names, and Snowflake work transfers, but you have not used it. R7 and R8 — the ingestion and contract ownership the role describes is not in your background as written.

**Opportunity ledger.** Posting is mostly sound: the salary is published and sits inside the role-family band (RR3). Open are whether the employer's footprint checks out (RR1, not verified in this pass) and how far the scope runs (RR2).

- **Hard gates:** none failed; unconfirmed: R9 (Remote (US) or Denver office), R10 (Base salary $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) your location and pay floor clear R9 and R10; (2) R7 and R8 are yours in practice, or the role's scope is stated as shared; (3) RR1 verifies: the posting is live and Pellucid is the employer you think it is.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016; 264 staff; Series C, $52M, Feb 2026 | `[grounded]` your paste of the about page; not verified (see RR1) |
| Mandate | Build and run ingestion from app and CRM, a dbt warehouse in BigQuery, and analyst data contracts | `[grounded]` JD |
| Reporting line | No hiring manager named | `[grounded]` posting silence |
| Pay | $148,000–$166,000 base (midpoint $157,000) plus equity | `[grounded]` JD |
| Market band | Senior DE at Series B–D: median $151,000, IQR $139,000–$163,500; "senior" usually 5–8 years | `[generic]` Datawright report you shared |
| Calibration | Posting range sits above the median and inside the IQR. Your 6 years fits the usual seniority band | `[generic]` band, `[grounded]` range |
| Scope read | Looks like the reporting domain end to end; the report's typical is one domain's pipelines with no reports | `[inferred]` from the JD's three deliverables against the report's norm |
| Unknowns | Hiring manager; split of ingestion vs. analyst ownership; whether BigQuery is a must | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | Six years stated; not inspected | `[grounded]` your background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated | `[grounded]` your background | none |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt on Snowflake, about 180 models; Snowflake is cloud | `[grounded]` your background | none |
| R4 | Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration | `[grounded]` your background | none |
| R5 | Data quality testing | must_have | direct | medium | none | You set up a Great Expectations suite | `[grounded]` your background | none |
| R6 | BigQuery warehouse (named in JD description) | important | adjacent | medium | transferability | Same dbt modelling; BigQuery itself unused | `[inferred]` from R3, plus your "never used BigQuery" | Bridge case in gap queue G1 |
| R7 | Ingestion from app and CRM | important | unclear | none | discovery | Background is silent on source ingestion | `[grounded]` absence in your background | Ask (Q3) |
| R8 | Data contracts analysts depend on | important | unclear | none | discovery | Background is silent on contracts | `[grounded]` absence in your background | Ask (Q3) |
| R9 | Location: Remote (US) or Denver | hard_gate | unclear | none | hard_gate | Your location not given | `[grounded]` JD; candidate constraint not stated | Ask (Q1) |
| R10 | Pay: $148k–$166k base | hard_gate | unclear | none | hard_gate | Your floor not given | `[grounded]` JD; candidate constraint not stated | Ask (Q2) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6) | transferability | dbt and SQL on Snowflake; no BigQuery | The JD names it; a bridge narrows the objection | Any BigQuery sandbox, query or dbt run, even personal | A small dbt-on-BigQuery repo or a query log | `[inferred]` bridge from R3; `[generic]` that BigQuery syntax and cost model are the likely objection |

The limit to state: you have not operated BigQuery in production.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer facts not verified in this pass | unknown | — | "Pellucid Learning runs live online tutoring" | The posting and company facts are unchecked; search was refused, so nothing is established either way | `[generic]` pattern for unverified postings, not a claim about this employer | Is this requisition open today, and can you point me to the Series C announcement? | unresolved |
| RR2 | Scope and reporting line unclear | unknown | — | "Build and run the pipelines behind our reporting" | Ownership may be shared across ingestion and contracts, or may fall to one person without reports | `[inferred]` from the JD against the report's norm | Which of ingestion, the warehouse and the contracts would I own, and who would I work with day to day? | unresolved |
| RR3 | Pay range published | positive_signal | — | "$148,000–$166,000 plus equity" | Pay is stated and sits above the band median | `[grounded]` JD; `[generic]` band | What is the bonus or equity structure? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your summary with "dbt and Airflow at 180-model scale on Snowflake" | Makes R3 and R4 visible to a keyword screen | `[grounded]` your background | pending your approval |
| E2 | State BigQuery as "not yet used" rather than omit it | Avoids a claim the interview will probe | `[grounded]` R6 | pending your approval |
| E3 | Ask RR1 and RR2 of the recruiter before spending time on the loop | Confirms the posting and the scope | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused by the host (permission not granted), so the posting's liveness and the company facts stay unverified; this would have moved RR1 |
| 2. Role-family sweep | skipped | The Datawright report you shared fixes the band, IQR and scope norm, so no search was needed |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- Enable web search and I'll run the two refused checks: the live posting and Pellucid's Series C details. That moves RR1.
- Your answers on location and pay floor → R9 and R10 resolve.
- Your ingestion or contract experience, with a named tool → R7 and R8 move off `unclear`.
- A BigQuery query log or small dbt repo → R6 moves toward `direct`.
- The hiring manager's name → RR2's scope read sharpens.

I can write this assessment to a `tuesday-dossier.md` file at the end of this engagement if you want a record of it.

**Questions**

Q1 (R9) — Are you based in the US, and is Remote (US) or the Denver office workable for you?

Q2 (R10) — Is a $148,000–$166,000 base within your floor?

Q3 (R7, R8) — Have you built ingestion from an app or CRM into a warehouse, or defined data contracts with analysts? If so, which tools and what was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.