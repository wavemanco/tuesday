**Decision snapshot**

Yes, apply. You match the five must-have requirements on your intake: R1, R2, R3, R4 and R5 all read `direct`. The gaps are clinicians, healthcare data, mentoring, and ownership of the metrics layer, and none of them is a hard gate. Status: `conditional_go`, because I could not verify that the employer and posting are live.

- **Fit ledger.**
  - `must_have` — direct: R1, R2, R3, R4, R5
  - `important` — direct: R8 · adjacent: R7 (define and maintain the metrics layer) · unclear: R10 (mentor two junior analysts) · absent: R9 (partner with clinicians)
  - `preferred` — adjacent: R6 (healthcare data, HIPAA)

  R3 (`medium`) — 30+ tests a year and the 11% lift are your claims, and the lift's basis (relative or absolute) is unstated. R7 — adjacent to your Looker governance work, with ownership unconfirmed. R9 — no evidence in what you've shared.

- **Opportunity ledger.** Scope is concrete and the outputs are named (RR3, positive). The employer and live posting are unverified (RR1), and no pay is stated (RR2). Clinician expectations are an open question (RR4).
- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting appears on the company's own careers page (RR1); (2) you can say concretely whether you owned metric definitions (G1 → R7); (3) you have an honest answer on clinician work and healthcare data (R9, R6).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C, as stated in the posting | `[grounded]` posting header |
| Scope | Metrics layer, A/B test design and analysis, self-serve Looker dashboards, PM and clinician partnership, mentoring two analysts | `[grounded]` posting |
| Pay | Not stated in the pasted posting | `[grounded]` posting silence |
| Market calibration | Not run. The role-family search was refused, so there is no pay band or scope norm from here. Model memory is not a source for this | — |
| Unknowns | Employer and posting status, pay, clinician expectations, team structure, who owns metric definitions today | — |
| Contradictions | None visible in the pasted material | `[grounded]` posting |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a subscription company, stated in your intake; not yet probed or inspected | `[grounded]` your intake | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake; "expert" is your word, and a query sample would show it | `[grounded]` your intake | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and a pricing test behind an 11% retention lift; the lift's basis is not stated | `[grounded]` your intake | confirm whether 11% is relative or absolute, and the sample and window |
| R4 | Looker or similar BI; self-serve dashboards | must_have | direct | medium | none | Built the company's Looker instance and 40+ governed dashboards; stated, not inspected | `[grounded]` your intake | none |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | Writes the monthly exec metrics memo and presents monthly to the VP Product | `[grounded]` your intake | none |
| R6 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | Consent-state model and GDPR/CCPA consumer PII work carry over. Limit: no clinical data and no HIPAA work | `[inferred]` adjacency from the consent work you described | G2 |
| R7 | Define and maintain the metrics layer | important | adjacent | medium | transferability | Governed Looker dashboards are close. Limit: you have not said you owned metric definitions | `[inferred]` adjacency from the Looker work | G1 |
| R8 | Partner with PMs to turn analysis into roadmap decisions | important | direct | medium | none | Decision influence shown at VP level through the memo and monthly presentation; day-to-day PM partnership not stated | `[grounded]` your intake | none |
| R9 | Partner with clinicians | important | absent | none | discovery | Nothing in your material touches clinicians | `[grounded]` silence in your intake | G2 |
| R10 | Mentor two junior analysts | important | unclear | low | discovery | Not mentioned; may have happened informally | `[grounded]` silence in your intake | G3 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R7) | transferability | Governed dashboards and a monthly memo; no statement of who defined the canonical metrics | Metric definition is the first responsibility listed, and interviewers will probe it | Owning or signing off on definitions such as retention or active subscriber; a metric dictionary; resolving disputes between dashboards | A metric definitions doc, a dashboard governance note | `[inferred]` that definition ownership is the likeliest probe; `[grounded]` intake |
| G2 | Clinicians and healthcare data (R9, R6) | discovery | Consumer PII and consent work only | Clinician partnership is an important responsibility, and this is the biggest difference from your background | Consent or privacy work on sensitive data; any work with care teams or patient-facing product | Nothing required yet | `[generic]` that regulated-domain hiring probes this line; `[grounded]` intake |
| G3 | Mentoring analysts (R10) | discovery | Not mentioned | A stated responsibility with no evidence either way | Onboarding analysts, reviewing their SQL, setting analysis standards | None needed | `[grounded]` silence in intake |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not verified | unknown | — | Posting as pasted: "Harborlight Health" | Web search was refused, so the company and posting status are unconfirmed from here. This is not a finding about the employer | `[grounded]` search refused this session | Can you point me to this role on your own careers page, and who would I interview with? | unresolved |
| RR2 | Pay not stated | unknown | — | No pay in the posting | Pay can't be calibrated from here, so there's no signal either way | `[grounded]` posting silence | What is the base range for this role, and is there bonus or equity? | unresolved |
| RR3 | Scope and outputs named | positive_signal | — | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards" | Scope is concrete and matches your experience | `[inferred]` from the posting's scope language | What does success look like at twelve months for the metrics layer and the experiment program? | noted |
| RR4 | Clinician expectations | risk_signal | low | "partner with PMs and clinicians to turn analysis into roadmap decisions" | Clinician partnership may assume clinical or care-pathway fluency you haven't shown | `[inferred]` from the posting against your intake | How often do clinicians shape roadmap decisions here, and what clinical background do analysts usually bring? | unresolved |

**Application plan** (every row is proposed; nothing is applied)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on the company's careers page before investing in the application | RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead with the Looker build and the 30+ test program. Keep "governed" as your word; don't say you owned the metrics layer unless you did | R4, R3, R7 | `[grounded]` your intake | pending your approval |
| E2 | Describe the consent-state model as consumer PII and consent work, not healthcare data | R6 | `[inferred]` from the consent work | pending your approval |
| W1 | Prepare the 11% story: the design, guardrails, the decision it drove, and whether 11% is relative or absolute | R3 | `[grounded]` your intake | pending your approval |
| P1 | Prepare an honest clinician answer: no clinician work yet; your closest analog is working with non-technical executives | R9 | `[inferred]` from the intake | pending your approval |

**Evidence status**

Verified: none yet. Your stated claims are specific and unprobed, so they sit at `medium`.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search refused by session permissions, so the company and posting are unverified. Would have moved RR1 |
| 2. Role-family sweep | unavailable | Search refused, so no pay band or scope norm from here. Would have moved RR2 and market calibration |
| 3. Hiring manager's public footprint | n/a | No name was given |
| Un-numbered: Series C and news search | unavailable | Refused. A deeper-diligence query outside the L1 targets. Would have moved RR1 |

**Dossier offer:** If you want, I can write a `tuesday-dossier.md` from this analysis so a later session can pick it up without restarting.

**Upgrade menu**
- A query sample or governed-dashboard screenshot → R2 and R4 to `high`.
- The pricing test's readout doc → R3 to `high`, and it settles the 11% basis.
- A metric definitions doc you maintained → R7 moves toward `direct`.
- Permission to retry web search → RR1 and RR2 can close. The L1 checks are three searches and two fetches; the deeper pass is up to five more searches and two more fetches, if you want it.

**Questions**
- G1 — Did you define and maintain the canonical metric definitions for the subscription business, or did you consume them? Who signed off on them?
- G2 — Have you worked with clinical, care-team, or health-related data, even indirectly through the consent work?
- G3 — Have you managed, mentored, or set review standards for analysts, even informally? What did that look like?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.