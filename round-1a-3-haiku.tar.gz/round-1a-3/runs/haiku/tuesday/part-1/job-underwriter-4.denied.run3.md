**Yes, it's worth applying for, on conditions.** On what you've told me, your GLM, price-test and underwriting-presentation work matches the must-haves. Status: `conditional_go`.

**Fit ledger.**

- `hard_gate`: unclear: R1 (fully remote, UK-based)
- `must_have`: direct: R2, R3, R4, R5
- `important`: direct: R6; adjacent: R7 (build and monitor rating models), R9 (pet-insurance product knowledge)
- `preferred`: direct: R8

R4 is the strongest evidence, a GLM you built and maintained; R5 is the underwriting presentation; R9 is motor pricing carrying over, with pet risk not exercised; R1 is not established from your message.

**Opportunity ledger.** The posting defines its remit clearly (RR5), and I found no red flags. It is silent on line management (RR1), pay (RR2) and contract basis (RR3), and the employer is not verified from here (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (fully remote, UK-based); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** (1) R1 confirmed: you're UK-based with the right to work; (2) RR1 answered: if the role carries direct reports, that's a material change, since you haven't managed anyone; (3) R9 framed as a bridge with its limit named, never as pet expertise.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; pet insurance | `[grounded]` your posting text |
| Mandate | Own pricing analytics for the pet product; build and monitor rating models; design and read price tests; recommend to underwriting and product | `[grounded]` posting |
| Scope read | One product's pricing analytics, with recommendations going to two functions | `[inferred]` from the posting's listed outputs |
| Market calibration | Not run; no pay band | — |
| Unknowns | Line management, pay, contract basis, employer and live posting, pet-specific expectations | — |
| Contradictions | None visible in the posting you pasted | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based | hard_gate | unclear | none | hard_gate | Your location and right to work are not stated; UK motor employment is context, not confirmation | `[inferred]` from your UK employer | Q1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years, last 2 senior; stated, no artifact yet | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Used daily; no artifact yet | `[grounded]` your message | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM; motor, not pet | `[grounded]` your message | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your message | none |
| R6 | Design and read price tests | important | direct | medium | none | 14 tests last year with underwriting | `[grounded]` your message | none |
| R7 | Build and monitor rating models | important | adjacent | medium | transferability | "Maintained" implies monitoring; cadence and metrics not described | `[inferred]` from "maintained" | G2 |
| R8 | Insurance experience | preferred | direct | medium | none | UK motor insurer | `[grounded]` your message | none |
| R9 | Pet-insurance product knowledge (inferred from the product named) | important | adjacent | medium | transferability | Motor pricing carries over; pet risk drivers are not exercised | `[grounded]` "never worked on pet"; `[generic]` that pet risk differs from motor | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance knowledge (R9, important) | transferability | Motor pricing and test design on record; no pet work | The likeliest objection; a clear bridge narrows it | Any non-motor pricing review, even as a reviewer; any pet-claims or loss-ratio analysis from a colleague's work | A sanitised pricing review or test readout, or a note on what differs in pet | `[inferred]` bridge from motor work; `[generic]` that pet risk differs |
| G2 | Monitoring of rating models (R7, important) | transferability | "Maintained" the GLM; monitoring not described | Monitoring is named in the posting's first responsibility | Recurring A/E checks, drift or performance reviews, refresh cycles | A monitoring pack or dashboard screenshot, sanitised | `[inferred]` from "maintained" |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Line management not stated | unknown | — | "Senior Pricing Analyst" (title only) | The role may carry direct reports the posting does not mention | `[inferred]` from title against silence | Does this role line-manage anyone, now or within a year? | unresolved |
| RR2 | Pay not in the posting you pasted | unknown | — | No pay line in the posting | Pay may be on the careers page or withheld | `[inferred]` from silence | What is the salary band for this post? | unresolved |
| RR3 | Contract basis not stated | unknown | — | No contract line in the posting | The post may be fixed-term | `[inferred]` from silence | Is this post permanent or fixed-term? | unresolved |
| RR4 | Employer not verified from this conversation | risk_signal | medium | "Brindlemoor (insurtech)" | Research did not run, so the employer and live posting are unchecked; this is not a finding that they are absent | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR5 | Clear remit | positive_signal | — | "Own pricing analytics for our pet-insurance product" | Scope is specific and close to your history | `[grounded]` posting | Which decisions does this role make alone, and which go to underwriting? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with R4 (GLM), R6 (price tests) and R5 (underwriting presentation) | The three strongest direct rows for this role | `[grounded]` evidence map | pending your approval |
| A2 | Bridge line: "I haven't priced a pet book. I built and maintained a GLM for a motor book and ran 14 price tests with underwriting." | Makes the R9 limit explicit. Each clause traces to your sentences | `[grounded]` R4, R6, R9 | pending your approval |
| A3 | Put RR1, RR2 and RR3 to the recruiter before investing in the loop | These are the unknowns that could change the status | `[grounded]` register | pending your approval |
| A4 | Confirm the posting on Brindlemoor's own careers page before application effort | Settles RR4 | `[generic]` pattern for companies of this size | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three searches were refused permission, so the company, the live posting and the contradictions row are unchecked. Would have moved RR4 and role reality |
| 2. Role-family sweep | unavailable | The search was refused. Would have moved the market calibration and the pay band behind RR2 |
| 3. Hiring manager's public footprint | unavailable | The name Odile Varga was given, so a query could be formed, but the search was refused. Would have moved scope read and positioning |

The three searches were sent to targets 1 to 3 and each was refused, so those targets read `unavailable`.

The dossier offer: I can write this up as a `tuesday-dossier.md` you can keep and reuse across other job-search requests.

**Upgrade menu**

- The posting link from Brindlemoor's own careers page → RR4 clears, and the status can move toward `go`.
- Your CV, or a sanitised GLM documentation extract or price-test readout → R4 and R6 move from `medium` toward `high`.
- The pay band from the posting or recruiter → RR2 closes, and it is set against a role-family band.
- Permission for web search → targets 1 to 3 run (up to 5 searches and 2 fetches), covering the employer, the pay band and Odile Varga's public footprint.

Q1 (R1): Are you based in the UK, with the right to work there, and is fully remote working what you're after?

Q2 (R9): Have you priced, reviewed or seen any non-motor book, pet included, even as a reviewer or a colleague's work?

Q3 (RR4): Where did you see the posting: on Brindlemoor's own careers page, or somewhere else?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.