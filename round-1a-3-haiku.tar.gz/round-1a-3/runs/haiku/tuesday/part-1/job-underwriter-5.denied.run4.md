**Yes, it's worth applying, as `conditional_go`.** Your daily stack matches the posting's requirements. The one real gap is BigQuery, which is learnable. Location and your pay floor decide the rest, and I don't have either from you.

**Fit ledger.**
- `hard_gate`: unclear: R1 (remote US or Denver location), R2 (salary range against your floor)
- `must_have`: direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (Airflow or similar orchestration), R7 (data quality testing)
- `important`: adjacent: R8 (BigQuery warehouse); unclear: R9 (ingestion from app and CRM), R10 (data contracts for analysts)

R8 — credible transfer from Snowflake, limit named (`medium`); R9 — nothing in your material yet; R10 — nothing in your material yet.

**Opportunity ledger.** Pay is sound: the posted range sits inside the market band, and its midpoint is above the median (RR5). Unknown: the hiring manager, equity terms, whether the posting is live (RR1–RR4). No red flags in what you shared.

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver location), R2 (salary range against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** conditions for `conditional_go`: (1) the posting is live on Pellucid's careers page (RR1); (2) you can work remote US or from Denver (R1); (3) your base floor is at or below $166,000 (R2). Above that, it's `no_go` on pay.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` your pasted about page |
| Mandate | Ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts analysts depend on | `[grounded]` JD |
| Scope read | One domain (reporting) with pipeline ownership and no direct reports stated, the usual shape for the title | `[generic]` report; `[grounded]` JD |
| Market calibration | Senior Data Engineer, Series B–D: median $151,000, IQR $139,000–$163,500. Posted $148,000–$166,000, midpoint $157,000 | `[generic]` Datawright 2026 report you pasted (n=2,310, US); `[grounded]` posted range |
| Seniority | Report's typical "Senior" is 5–8 years; your 6 years sits inside | `[generic]` report; `[grounded]` your background |
| Unknowns | Hiring manager, equity terms, your location, your pay floor, data-contract ownership | — |
| Contradictions | None in what you pasted (JD and about page agree) | `[grounded]` your material |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote US or Denver office | hard_gate | unclear | none | hard_gate | Your location isn't in the material | `[grounded]` JD | Q1 |
| R2 | Salary against your floor | hard_gate | unclear | none | hard_gate | No floor stated; the band isn't the problem, your floor is | `[grounded]` JD; `[generic]` band | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years, stated; unprobed prose, so expect a probe | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated; no artifact yet | `[grounded]` your background | sanitized SQL sample would raise to high |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt on Snowflake, about 180 models, built by you | `[grounded]` your background | sanitized dbt project would raise to high |
| R6 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow, stated | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, stated | `[grounded]` your background | suite config would raise to high |
| R8 | BigQuery warehouse | important | adjacent | medium | transferability | dbt and SQL carry over; BigQuery's own tooling and cost model are new | `[grounded]` background and JD; `[generic]` dbt runs on both | G1 |
| R9 | Ingestion from app and CRM | important | unclear | none | discovery | Nothing in material | `[grounded]` silence | Q3 |
| R10 | Data contracts for analysts | important | unclear | none | discovery | Quality testing is adjacent, not the same | `[grounded]` silence; `[inferred]` adjacency | RR4 in the loop |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8) | transferability | Snowflake and dbt experience; no BigQuery | The JD names it in the warehouse description | Any dbt model or pipeline on another cloud warehouse; a BigQuery sandbox run | A small dbt project on BigQuery you run | `[inferred]` bridge from your Snowflake work; `[generic]` closure is usually small |
| G2 | Ingestion from app and CRM (R9) | discovery | Nothing in material | A named responsibility | Pipelines from a product database or a CRM into a warehouse | A pipeline diagram or DAG sketch | `[grounded]` silence |
| G3 | Data contracts (R10) | discovery | Nothing in material | Analysts depend on them | Schema agreements, breaking-change handling | A contract doc, sanitized | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Live posting and employer not verified from attributable sources | risk_signal | medium | pellucidlearning.com/careers/senior-data-engineer | The posting may be stale or already filled | `[generic]` pattern for companies of this size, not a claim about this one; my search didn't run | Is this role open on your careers page now, and who is hiring for it? | unresolved |
| RR2 | Hiring manager not named | unknown | — | "Senior Data Engineer — Pellucid Learning" | Not a risk alone; the answer says who reads the application | `[grounded]` posting names none | Who is the hiring manager, and who would this role report into? | unresolved |
| RR3 | Equity offered, terms withheld | unknown | — | "Salary $148,000–$166,000 plus equity" | Total package can't be compared yet | `[grounded]` JD | What equity is offered, and on what vesting schedule? | unresolved |
| RR4 | Data-contract ownership unstated | unknown | — | "the data contracts our analysts depend on" | The role may own contracts end to end, or only build what they run on | `[inferred]` from JD scope against silence on contract authority | Does this role own the data contracts with analysts, and who approves a change? | unresolved |
| RR5 | Base pay at or above market median | positive_signal | — | "$148,000–$166,000" | Pay sits inside the band, midpoint above median | `[grounded]` posted range against `[generic]` report band | Is this range the approved budget for the hire, or open to adjust? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Check the live posting on Pellucid's careers page; note any named hiring manager | RR1, RR2 | `[grounded]` register | proposed |
| P2 | Settle Q1 and Q2 before investing effort | R1, R2 | `[grounded]` gate rows | proposed |
| P3 | Resume: lead with the 180-model dbt project on Snowflake and the Great Expectations suite, in your verbs (built, set up); no BigQuery claim | R5, R7 | `[grounded]` background | pending your approval |
| P4 | Before applying, run a small dbt project on BigQuery yourself; in interviews, call it learning, not experience | R8 | `[generic]` small project as usual closure | proposed; wording pending your approval |
| P5 | Ask RR3 and RR4 verbatim in the loop | Register doubles as prep | `[grounded]` register | proposed |

## Evidence status

Verified: none yet. Your background and constraints are unprobed intake.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One search sent; web search permission was not granted, so nothing returned. It would have checked the posting is live and that the site matches your pasted about page. Feeds RR1 |
| 2. Role-family sweep | skipped | The Datawright 2026 report you pasted fixes the band (median and IQR), so a search would only re-find it |
| 3. Hiring manager's public footprint | n/a | No name given |

If you want this kept, I can write it up as `tuesday-dossier.md` so you can append answers as they arrive.

**Upgrade menu**
- Grant web search, and I'll run the live-posting and employer check (target 1); it can close RR1.
- A sanitized dbt project or its config: R5 to `high`.
- The Great Expectations suite config, sanitized: R7 to `high`.
- A small BigQuery dbt repo you've run: R8's confidence rises; its fit stays `adjacent` until the work exists.
- Your equity terms: RR3 closes.

**Questions**
1. (R1) Are you based in the US, and would remote US work, or would only Denver work?
2. (R2) Is $148,000 at or above your base floor?
3. (G2, R9) Have you built ingestion from a product app or a CRM? What did you own: extraction, schema, scheduling, or alerting?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.