**Yes, apply, but position yourself as a revenue ops lead ready to take on forecasting and billing data, not as someone who already owns them.** Status: `conditional_go`.

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, hybrid two days a week), R2 (salary £61,500–£67,000). Your constraints weren't given, so checks against them are unknown.
- **Fit ledger:**
  - `hard_gate`: unclear: R1, R2
  - `must_have`: direct: R4a, R5, R8, R9 · adjacent: R3, R6 · absent: R4b
  - `important`: unclear: R7 (working with finance on billing or revenue data)
- **Opportunity ledger:** the posting is specific and its pay sits inside the market band (RR4, positive). Its scope overlaps the public title of the hiring manager (RR5), and I couldn't find the role on Quillfield's own careers site (RR1). No severe red flags.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the billing-data gap (R4b) and the forecast gap (R6) hold up in interview; (2) Bristol hybrid and the pay band are within your constraints; (3) the role is confirmed on Quillfield's own site or by the recruiter.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; founded 2018 in Bristol, 96 employees, £11M Series A (April 2025) | `[grounded]` Quillfield About page (search snippet, not fetched) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options | `[grounded]` posting |
| Market calibration | UK revenue operations lead, B2B software: median £64,200, interquartile range £57,800–£70,400 (n=438) | `[generic]` Ledgerline 2026 pay guide (search snippet). The posted band sits around the median; this is a pattern, not Quillfield's offer |
| Unknowns | Who owns the forecast today (RevOps or finance); who owns billing data; whether this is the same role on Quillfield's own careers page | — |
| Contradictions | None between posting and what I found. The careers-page search returned no results | `[grounded]` search |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid two days a week | hard_gate | unclear | medium | hard_gate | Your constraint isn't in the material | `[grounded]` posting; constraint unstated | Confirm you can meet it |
| R2 | Salary £61.5–67k | hard_gate | unclear | medium | hard_gate | Your floor isn't in the material | `[grounded]` posting | Confirm the band works for you |
| R3 | 4+ years RevOps or sales ops at a B2B software company | must_have | adjacent | medium | transferability | Five years in sales ops, two running RevOps, at a B2B payments company. Years meet the bar; "software" is the adjacency. Years are not a gate | `[inferred]` from your intake prose | Name the payments product and its software side |
| R4a | Own the CRM | must_have | direct | high | none | Salesforce admin certified; rebuilt pipeline and renewal dashboards | `[grounded]` certification (inspectable) plus your account | none |
| R4b | Own billing data | must_have | absent | none | transferability | You've never worked on billing data. Payments-side data is the nearest adjacency, but you haven't said it touched billing | `[grounded]` your statement | Question 2 |
| R5 | Pipeline and renewal reporting | must_have | direct | medium | none | Rebuilt both dashboards; no artifact yet | `[grounded]` your account | Attach a sanitized screenshot to raise to high |
| R6 | Owning a revenue forecast with the CFO | must_have | adjacent | medium | transferability | You've never owned the company forecast; finance did it. You run the monthly pipeline review with the sales director, the nearest adjacency | `[grounded]` your statement; `[inferred]` that pipeline review is adjacent | Question 1 |
| R7 | Working with finance on billing or revenue data | important | unclear | low | discovery | Nothing stated about finance collaboration | `[grounded]` silence | Question 2 |
| R8 | SQL and spreadsheet modelling | must_have | direct | medium | presentation | SQL weekly, Excel daily; "modelling" not yet described | `[grounded]` your statement | Name one model you built |
| R9 | HubSpot or Salesforce admin | must_have | direct | high | none | Salesforce admin certified | `[grounded]` certification | none |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6) | transferability | Pipeline review is real; a forecast you owned is not | A must-have. Closing it moves the decision toward `go` | Any revenue projection you built or presented, even team-level | A forecast sheet, or the pipeline review pack (sanitized) | `[inferred]` bridge from the pipeline review; `[generic]` that forecasting is the likeliest objection |
| G2 | Billing data (R4b, R7) | transferability | No billing work stated | The posting names billing data first | Invoicing, settlement or payment-status reports from the payments company | A sanitized report or field list | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Role not found on Quillfield's own careers site | unknown | — | "Revenue Operations Lead — Quillfield" (aggregator) | The posting may be live only on the aggregator, or the careers page may be out of date | `[grounded]` careers search returned nothing | Is this role live on Quillfield's careers page, and who would I interview with? | unresolved |
| RR2 | Forecast ownership split with finance | risk_signal | medium | "run the quarterly revenue forecast with the CFO" | Forecasting may be shared with finance, with RevOps owning the inputs rather than the number | `[inferred]` from "with the CFO" against silence on who owns the final number | Who owns the final forecast number, and what did the last quarter miss by? | unresolved |
| RR3 | Scope spans CRM, billing data, reporting and forecast | risk_signal | low | "own our CRM and billing data … run the quarterly revenue forecast" | The title may bundle a RevOps lead with a finance analyst's remit | `[inferred]` from the four-part scope | Which of these four is the core of the role, and which sits with others? | unresolved |
| RR4 | Pay disclosed and in band | positive_signal | — | "£61,500–£67,000 plus share options" | Pay is transparent and near the median | `[grounded]` posting; `[generic]` band | What's the review cycle for the share options? | noted |
| RR5 | Public title overlaps the role | unknown | — | Recruiter named hiring manager Tamsin Achebe | The hiring manager appears to be Head of Revenue Operations; how this role sits beside that remit is unclear | `[grounded]` search snippet of a public profile (name match only) | How does this role divide the work with the Head of Revenue Operations function? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the CRM, pipeline and renewal dashboards, the Salesforce certification and the monthly pipeline review | Strongest direct evidence (R4a, R5, R9) | `[grounded]` your CV and certification | `resume_edits_pending_approval` |
| P2 | State the forecast and billing gaps yourself, with a concrete plan for the first 90 days. Don't claim forecast or billing ownership | The panel will probe it (G1, G2) | `[generic]` interviews probe the must-have gaps | pending your approval |
| P3 | Ask the recruiter whether the forecast number and billing data sit with RevOps or finance | Closes RR2 and RR3 before you invest | `[grounded]` RR2, RR3 | pending your approval |

## Evidence status

Verified: none yet. Everything above rests on your intake prose, which is medium at most until you confirm it with an artifact.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol" (quillfield.co.uk/about, search snippet only) and "Quillfield careers Revenue Operations Lead" (no results). Confirmed the employer exists; did not confirm the role. Moved RR1 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead B2B software salary UK revenue operations seniority", which returned the Ledgerline 2026 UK Revenue Operations Pay Guide (ledgerline.example, search snippet only). Moved R2 and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned a public profile (linkedin.example/in/tamsin-achebe, search snippet only): Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. This matches the name only. Moved RR5 |

I didn't fetch any of these pages, so the snippets are all I have from them.

Dossier offer: if you want this kept as a file, I can write it up as `tuesday-dossier.md`.

**Upgrade menu:**
- A forecast sheet or pipeline-review pack (sanitized) → R6 and G1 move from adjacent toward direct.
- A sanitized dashboard screenshot → R5 moves to high.
- A sanitized invoicing or settlement report, or the field list → R4b and G2 move.
- Quillfield's careers page link, or the recruiter's answer on the role → RR1 closes.
- Full text of the Ledgerline guide and Quillfield's About page (2 fetches left in L1) → confirms the pay band and company facts.
- Deeper diligence on Quillfield (funding, leadership changes, reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions:**
- G1 (R6): Have you ever built, rebuilt or presented a revenue forecast, even a team-level or pipeline-weighted one that finance then used? What did you own, and how far off was it?
- G2 (R4b, R7): Did any billing, invoicing or settlement data pass through your reports at the payments company? If so, which fields, and who owned their definitions?
- Gates (R1, R2): Are the Bristol hybrid pattern and the £61,500–£67,000 band within your constraints?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.