The tool is loaded. I'll run the L1 targets now: the company's site and careers page, a role-family sweep, and the hiring manager's public footprint.
The careers page snippet says "Leeds office four days a week", which conflicts with the posting's "Fully remote (UK)". That's a location hard gate, so I'll open the page to check.
**Not yet: `hold_pending_answers`.** The work fits you well, but the posting's location term conflicts with the company's own careers page, and that term decides whether this is worth applying to.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

## Decision snapshot

**Status: `hold_pending_answers`.** Your must-haves read as direct. The open question is whether the role is fully remote, as your posting says, or Leeds four days a week, as the careers page says.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Location and office pattern)
- `must_have` — direct: R2, R3, R4, R5
- `important` — direct: R6 · adjacent: R7 (Build and monitor rating models), R8 (Pet-insurance product pricing)
- `preferred` — direct: R9 (Insurance experience)

R7 — you built and maintained the model, but monitoring isn't claimed; R8 — motor pricing carries over, pet doesn't; R1 — the posting and the careers page disagree.

**Opportunity ledger.** The role is live and clearly scoped (RR3), but the location terms conflict (RR1) and no salary is stated (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Location and office pattern); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** RR1 and R1 are the awaited answers. If the employer confirms fully remote and you have no location limit, this moves to `go`, subject to the salary. If the role is Leeds four days a week and you can't do that, it becomes `no_go`, with R1 as the reason.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; the posting's product is pet insurance | `[grounded]` JD; careers page |
| Mandate | Own pricing analytics for the pet product; build and monitor rating models; design and read price tests; recommend to underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing | `[grounded]` careers page |
| Working pattern | Conflict: "Fully remote (UK)" in the posting vs "Leeds office four days a week" on the careers page | `[grounded]` both sources |
| Scope read | A single-product analytics post, not a team-building one | `[inferred]` from the mandate and reporting line |
| Market calibration | Senior pricing analyst, UK insurers and insurtechs: median £58,400, interquartile range £52,100–£64,900 | `[generic]` one survey (Pricewell 2026, n=612); not this employer's offer |
| Unknowns | Salary; remote vs Leeds; whether the role has direct reports; how much monitoring it owns | — |
| Contradictions | Location (above) | `[grounded]` |

The careers page is on the company's own domain and says the role is live and accepting applications, so the employer is established. The general web search turned up little else, which is a thin footprint, not a flag.

## Evidence map

Your background is your own prose, so every claim is `medium` at most: specific and self-reported, with no artifact yet.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location and office pattern | hard_gate | unclear | none | hard_gate | Posting says fully remote; careers page says Leeds four days a week. Your constraint wasn't given, so nothing to grade | `[grounded]` JD; careers page | G1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics at a UK motor insurer, last two senior | `[grounded]` your prose | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Both used daily; no artifact | `[grounded]` your prose | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM for a young-driver motor book; no artifact | `[grounded]` your prose | Sanitized model note (upgrade menu) |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your prose | none |
| R6 | Design and read price tests | important | direct | medium | none | Ran 14 price tests last year with underwriting | `[grounded]` your prose | none |
| R7 | Build and monitor rating models (monitoring part) | important | adjacent | medium | discovery | Built and maintained the model; monitoring isn't claimed. Limit: no monitoring claim until you confirm one | `[inferred]` from R4 | G2 |
| R8 | Pet-insurance product pricing (inferred from "our pet-insurance product") | important | adjacent | medium | transferability | Motor pricing carries over; no pet exposure. Limit named | `[inferred]` from the JD's scope and your motor work | G3 |
| R9 | Insurance experience | preferred | direct | medium | none | Motor insurer, five years | `[grounded]` your prose | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and office pattern (R1, hard_gate) | hard_gate | The posting and the careers page disagree; your own constraint isn't on record | Decides between `go` and `no_go` | Not applicable — this is a term, not experience | The employer's written confirmation of the location term | `[grounded]` the two sources |
| G2 | Monitoring of rating models (R7, important) | discovery | You've maintained a GLM; nothing shows you monitored it in production | The hiring manager has publicly focused on monitoring, so this is the likeliest probe | Actual-vs-expected checks, loss-ratio tracking, drift reviews on a live model | A monitoring pack or a note on a review you ran | `[inferred]` from the posting and the hiring manager's public talk |
| G3 | Pet-insurance pricing (R8, important) | transferability | Motor pricing is your base; no pet work | Likely to be raised, so the limit must be stated | Any benchmark or pilot touching pet or other companion-animal products | A bridge note on what transfers | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location terms conflict | risk_signal | medium | "Fully remote (UK)" vs "Leeds office four days a week" | One of the two sources is out of date, or the role is hybrid with a Leeds office | `[inferred]` from the conflict between the two sources | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Salary not stated | unknown | — | No salary in the JD or the careers page | The budget may sit inside the market band, or the company may simply not publish it | `[generic]` band from one survey; `[grounded]` the posting's silence | What base salary is budgeted for this role? | unresolved |
| RR3 | Scope and reporting line stated | positive_signal | — | "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing" | Scope is concrete; the decision rights are not | `[grounded]` careers page | Which pricing decisions does this role make itself, and which go to the Director? | noted |
| RR4 | Direct reports unknown | unknown | — | "Senior Pricing Analyst" with no reports stated | The role may or may not line-manage; you've never managed anyone | `[inferred]` from the title and reporting line against silence on reports | Does this role have direct reports now or planned within a year? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Put the location question to the employer through its own careers page before applying | RR1, R1 | `[grounded]` RR1 | pending your approval |
| P2 | Lead with the GLM for the young-driver book and the 14 price tests, using "built and maintained" and "ran" | R4, R6 | `[grounded]` your prose | pending your approval |
| P3 | Say motor pricing carries over and pet is new to you; don't imply pet experience | R8 | `[inferred]` from R8 | pending your approval |
| P4 | Read the hiring manager's public talk on monitoring rating models in small books before the interview; claim monitoring only if you've done it | R7, G2 | `[grounded]` talk title from search; `[inferred]` that monitoring is her focus | pending your approval |

Every row is a proposal. Nothing goes out until you approve it.

## Evidence status

Verified: none yet. Every candidate claim here is your own prose, not inspected.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance" (no results) and "Brindlemoor careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved: the role is live; location conflict (RR1); reporting line (RR3) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary GLM pricing", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved: the market band in role reality; RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing insurance", which returned her public profile (linkedin.example/in/odile-varga) and a 2025 forum talk, "Small Books, Loud Errors" (from the search snippet; not fetched). Moved: positioning in P4 |

Deeper research on Brindlemoor is available if you want it (see the upgrade menu).

If you want this kept for later work, I can write it out as `tuesday-dossier.md`.

## Upgrade menu

- The employer's written confirmation of the location term → R1 closes and the status moves to `go` or `no_go`.
- Your answer to the location question → R1's fit becomes `direct` or `hard_gate_fail`.
- A sanitized monitoring pack, such as an actual-vs-expected check or a drift review → R7 from adjacent toward direct.
- A sanitized GLM model note or validation summary → R4 from `medium` to `high`.
- The budgeted salary → RR2 closes, set against the market band.
- A deeper research pass on Brindlemoor (funding, leadership changes, public employee reports; up to 5 more searches and 2 more fetches). It runs only if you say so; this is the one offer.

## Questions

G1 — Could you work from the Leeds office four days a week if the role turns out to be that?

G2 — Have you monitored a rating model in production after it went live (actual-vs-expected checks, loss-ratio tracking, drift reviews), or only maintained it?

Constraints — What's your pay floor, and is there any location or schedule limit I should check against this role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.