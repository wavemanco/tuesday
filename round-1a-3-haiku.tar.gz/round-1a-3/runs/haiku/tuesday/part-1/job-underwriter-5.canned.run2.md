**Yes, it's worth applying, once two checks come back. Status: `conditional_go`.** Your location and your pay floor are the conditions. The BigQuery gap is real but small, and the posting itself looks legitimate.

**Fit ledger**

- `hard_gate`: unclear: R7 (Remote (US) or Denver office), R8 (Pay $148,000–$166,000)
- `must_have`: direct: R1 (5+ years data engineering), R2 (Strong SQL and Python), R3 (dbt and a cloud warehouse), R4 (Airflow or similar), R5 (data quality testing)
- `important`: adjacent: R6 (BigQuery warehouse)

R3 — Snowflake meets the posting's generic "cloud warehouse" wording; R6 (`medium`) — the one real gap, with its transferable part named; R7 and R8 — unknown until you answer.

**Opportunity ledger.** The posting is live and matches the JD you pasted, and it states pay (RR3). Open items are pipeline ownership and team size (RR1), whether BigQuery is actually required (RR2), and company figures that rest on the company's own site (RR4).

- **Hard gates:** none failed; unconfirmed: R7 (Remote (US) or Denver office), R8 (Pay $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can work from the US or Denver (R7); (2) your pay floor sits at or below the posted range (R8); (3) BigQuery is presented as new to you, never as experience (R6).
- **What would change this:** a floor above the range, or a location outside the US, would make this `no_go`.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online K-12 tutoring in 31 states; founded 2016; Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` company About page (its own claim; one search found no independent source) |
| Mandate | Build and run reporting pipelines; a dbt warehouse on BigQuery; data contracts for analysts | `[grounded]` JD |
| Scope read | Domain ownership of pipelines, with no direct reports stated | `[inferred]` from the JD's wording against the typical scope for this title |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, interquartile range $139,000–$163,500; the posted $148,000–$166,000 sits inside that range | `[grounded]` the Datawright pay report you sent; `[generic]` that it is a role-family band, not this employer's offer |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Contradictions | None between the pasted JD and the live posting | `[grounded]` the fetched careers page |
| Unknowns | Team size, hiring manager, equity value, your location and pay floor | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated in your message; not yet inspectable | `[grounded]` your statement | Probe: pipelines owned, team size |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use, as stated | `[grounded]` your statement | none |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | About 180 dbt models on Snowflake; Snowflake is a cloud warehouse | `[grounded]` your statement | Upgrade: sanitized dbt artifact |
| R4 | Airflow or similar | must_have | direct | medium | none | Airflow orchestration, as stated | `[grounded]` your statement | none |
| R5 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite, as stated | `[grounded]` your statement | Upgrade: sanitized test config |
| R6 | BigQuery warehouse (in the role description) | important | adjacent | medium | transferability | Snowflake carries over: dbt, SQL, warehouse design. Limit: you have never used BigQuery | `[inferred]` transfer from your Snowflake work; `[generic]` that tooling and dialect are the main differences | G1 |
| R7 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location wasn't given, so the check can't run | `[grounded]` JD | Q1 |
| R8 | Pay $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your floor wasn't given | `[grounded]` JD | Q2 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery warehouse (R6, important) | transferability | Snowflake work with dbt and SQL; no BigQuery | The posting names BigQuery, so an interviewer may probe it | Any cloud-warehouse migration or cost work; any dbt project on a different warehouse | A short BigQuery sandbox project that loads and models a dataset with dbt | `[inferred]` bridge from your Snowflake work; `[generic]` that BigQuery's own tooling is the usual ramp |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pipeline ownership and team size unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may carry these pipelines with little shared support | `[generic]` pattern for a data team at this stage; not a claim about this team | "How many data engineers and analysts would I work with, and who else owns these pipelines?" | unresolved |
| RR2 | BigQuery named in the mandate, "a cloud warehouse" in the requirements | unknown | — | "a dbt-modelled warehouse in BigQuery" | BigQuery may be a hard expectation, or the requirement may be generic | `[inferred]` from the two JD lines | "Is BigQuery experience required, or would Snowflake experience with a short ramp be acceptable?" | unresolved |
| RR3 | Pay stated and inside the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Transparent pay, roughly at market for the title and stage | `[grounded]` posting and pay report; `[generic]` the band | "Is this range fixed for this level, and how is the equity valued?" | noted |
| RR4 | Company scale and funding rest on its own site | unknown | — | "Series C ($52M, February 2026)" | The figures are the company's own; one search found no independent source | `[grounded]` company About page | "Who led the February 2026 round, and is the headcount still current?" | unresolved |

The standing "employer not established" entry is not triggered: the company's own site confirms the entity and the live posting. Independent corroboration is thin, which is RR4.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm your location and the range with the recruiter before investing in the loop | R7, R8 | `[grounded]` JD | pending your approval |
| A2 | Ask RR1–RR4 in the first recruiter screen | the register doubles as prep | `[grounded]` register | pending your approval |
| E1 | Lead with dbt on Snowflake (about 180 models) and say BigQuery is new to you | R3, R6 | `[grounded]` your statement; no BigQuery claim made | pending your approval |

**Evidence status.** Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning tutoring company Denver", which returned the company's About page. Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer): the posting is live and matches the pasted JD. Moved the contradictions row (none) and the organization row. |
| 2. Role-family sweep | skipped | The Datawright 2026 pay report you sent already fixes the market calibration for this title, seniority and stage. Skipped; it feeds the market calibration line and the RR3 check. |
| 3. Hiring manager's public footprint | n/a | Neither the posting nor your material names one. |

**Dossier offer.** I can write this assessment to a `tuesday-dossier.md` file so you can keep it; say the word.

**Upgrade menu**

- Your location and pay floor → R7 and R8 move from unconfirmed; the status likely becomes `go` or `no_go`.
- A sanitized dbt model doc or data-test config → R3 and R5 move to `high`.
- A BigQuery sandbox project → R6 could move up from `adjacent`.
- The team size and who else owns the pipelines → RR1 closes.
- A deeper pass on Pellucid (independent coverage of the Series C, leadership changes; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

- R7 — Are you based in the US, and could you work from Denver or fully remote?
- R8 — What base pay is your floor for this role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.