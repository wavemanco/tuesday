I'll load the job-search module and the web fetch tool, then read the posting.
**Decision: conditional_go.** Apply, but go in knowing that two of the posting's listed requirements are not in your background, and don't claim them.

**Hard gates:** None fails on what you've given me. Two are unknown: the role is Bristol, hybrid, two office days a week, and the pay is £61,500–£67,000 plus share options [grounded, from the posting]. I don't know your location or pay floor.

**Fit by requirement** (requirements [grounded] from the posting; your evidence as you stated it, not verified):

| Requirement | Fit | Confidence | Basis |
|---|---|---|---|
| 4+ years in RevOps, sales ops or analytics at a B2B software company | Likely meets | medium | 5 years sales ops, 2 running RevOps. The employer is a payments company, not software, which is a minor gap. |
| HubSpot or Salesforce admin | Meets | high | Salesforce admin certified |
| Pipeline and renewal reporting | Strong | high | You rebuilt both dashboards and run the monthly pipeline review |
| Strong SQL and spreadsheet modelling | Likely meets | medium | SQL weekly, Excel daily. Modelling depth isn't described. |
| Owning a forecast | Gap | unproven | You've never owned the company forecast; finance did. The posting makes this central: the role runs the quarterly forecast with the CFO. |
| Working with finance on billing or revenue data | Gap | unproven | You've never worked on billing data, and finance-facing work isn't described. |
| Owning CRM and billing data (scope) | Partial | medium | CRM yes; billing no |

**Why conditional and not go:** Forecasting and billing are written as requirements, and the scope centres on them. **Why not no_go:** The reporting core is what you've built. Your monthly pipeline review may have fed a forecast number finance used. That's worth checking, but I can't count it until you confirm it.

**Application plan:** Lead with the pipeline and renewal dashboards, the Salesforce work and the pipeline review. Don't describe yourself as owning a forecast or having billing experience unless you can point to specifics.

**Opportunity side:** The posting is specific: named scope, stated salary, hybrid terms. It doesn't ask for payment or personal details, and I see no red flag in the text.

**Not checked:** I ran no searches, so I haven't confirmed that Quillfield and this posting exist as described. That's a check for you, not a warning about the posting: look for the same role on Quillfield's own careers page, or confirm the recruiter's email domain matches the company.

**Evidence status:** Research tier: L0, no searches; user links read 1 (the posting).

**Dossier offer:** At the end of this engagement I can write this evidence map to a `tuesday-dossier.md`, so the next step starts from it.

**Upgrade menu:**
- Light research (up to 5 searches and 2 page fetches) would check that the company exists as described, give a market pay band for this seniority, and look at Tamsin Achebe's public professional background.
- A redacted sample of a pipeline or renewal dashboard would raise the pipeline evidence from medium to high, if you're comfortable sharing it.

**Questions** (answer in prose, skip any):
1. **Forecast:** Did your pipeline review feed a number finance used, such as commit or best-case categories or forecast accuracy checks? Even indirect input changes how the gap reads.
2. **Finance and billing:** Have you reconciled CRM bookings against invoices, or worked on renewal billing or revenue recognition, even from the sales side?
3. **Logistics:** Are you based in the UK, and can you do two days a week in Bristol? What's your pay floor against £61,500–£67,000?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.