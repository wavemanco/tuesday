**Yes, probably worth applying, with one gate to confirm first.** Your must-have requirements match your background, the posting is live on the employer's own careers page, and nothing in it conflicts with a constraint you've stated. Two things are still open: whether you meet the US-location requirement, and whether $148,000–$166,000 clears your pay floor. Status: `conditional_go`.

**Fit ledger.**

- `hard_gate`: unclear: R1 (US location for remote or Denver), R10 (pay floor against $148,000–$166,000)
- `must_have`: direct: R2 (5+ years), R3 (SQL and Python), R4 (dbt and a cloud warehouse), R5 (Airflow or similar), R6 (data quality testing)
- `important`: adjacent: R7 (BigQuery warehouse) · unclear: R8 (app and CRM ingestion), R9 (data contracts)

R2–R6 (`medium`) are confirmed in your intake, with no inspectable artifact yet. R7 is the BigQuery gap, which transfers from Snowflake but is untested. R8 and R9 have no evidence either way yet.

**Opportunity ledger.** Sound on the posting's own terms: a concrete scope, a stated salary in the market band, and no red flags. Open: the company footprint is unconfirmed (RR1), and no hiring manager is named (RR2). Salary is in range (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (US location for remote or Denver), R10 (pay floor against $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) R1 confirmed: you're US-based and can work for a US employer; (2) R10 confirmed: the posted range clears your floor; (3) RR1 cleared: the Series C and the company's existence are confirmed through a source other than its own website.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring, 31 states, Denver, 264 employees, Series C ($52M, Feb 2026) | `[grounded]` company page you pasted; not independently confirmed (RR1) |
| Scope | Build and run ingestion (app and CRM), a dbt warehouse on BigQuery, and data contracts for analysts | `[grounded]` posting |
| Scope read | Owning one domain's reporting pipelines, consistent with a senior IC role | `[inferred]` from the posting's scope and its silence on direct reports |
| Seniority | 5–8 years is typical for "Senior" at Series B–D; you have 6 | `[generic]` Datawright 2026 pay report you supplied |
| Pay | Posted $148,000–$166,000 sits from the median ($151,000) up to the upper quartile ($163,500); the midpoint is about $157,000 | `[grounded]` posting; `[generic]` band from the pay report |
| Unknowns | Hiring manager; whether ingestion and contracts are owned or shared; what the pay range depends on | — |
| Contradictions | None: the careers page you pasted matches the JD word for word | `[grounded]` fetched careers page |

The pay report was sent by your recruiter, so its band comes from their source. Its Series B–D cut fits Pellucid's Series C stage.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | US location for remote, or Denver | hard_gate | unclear | none | hard_gate | Your location and authorization weren't given, so the gate isn't settled | `[grounded]` posting; no candidate statement | G1 question |
| R10 | Pay floor against $148k–$166k | hard_gate | unclear | none | hard_gate | No floor given | `[grounded]` posting; `[generic]` band | G2 question |
| R2 | 5+ years data engineering | must_have | direct | medium | none | Six years at a payroll company, stated in intake; no artifact | `[grounded]` your intake | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated in intake | `[grounded]` your intake | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt on Snowflake, about 180 models, stated in intake | `[grounded]` your intake | upgrade menu: dbt artifact |
| R5 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow set up and run, stated in intake | `[grounded]` your intake | none |
| R6 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite, stated in intake | `[grounded]` your intake | none |
| R7 | BigQuery warehouse (named in the responsibilities) | important | adjacent | medium | transferability | dbt and warehouse skills carry over; BigQuery specifics (partitioning, clustering, cost model, dialect) are untested, and you've never used it | `[grounded]` Snowflake work; `[inferred]` transfer | G3 |
| R8 | Ingestion from app and CRM | important | unclear | low | discovery | Not in your intake | `[grounded]` posting; silence in intake | G4 question |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Not in your intake | `[grounded]` posting; silence in intake | G5 question |

Fit and gap are separate calls. R2–R6 are direct, but they stay `medium` until there's something to inspect.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | What would close it | Provenance |
|---|---|---|---|---|---|---|
| G1 | US location and authorization (R1) | hard_gate | Not given | Decides whether the role is open to you at all | A yes or no from you | `[grounded]` posting |
| G2 | Pay floor (R10) | hard_gate | Not given | The range is at market; whether it clears your floor is your call | A yes or no from you | `[generic]` band |
| G3 | BigQuery (R7) | transferability | Snowflake dbt work; no BigQuery | Named in the responsibilities, so likely a probe | Limit: BigQuery-specific cost and partitioning. Strengthener: a small dbt project on a BigQuery sandbox, shown in an interview | `[inferred]` transfer; `[generic]` that a BigQuery probe is likely |
| G4 | App and CRM ingestion (R8) | discovery | No mention in intake | An important responsibility | Any ingestion you've built, with an example | `[grounded]` silence in intake |
| G5 | Data contracts (R9) | discovery | No mention in intake | Analysts depend on these | Any schema, SLA or breaking-change process you've owned | `[grounded]` silence in intake |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer footprint not established independently | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" | The company may be too new or small for much press coverage, the page may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies this size, not a claim about this one | "Can you point me to the Series C announcement, and who would I be interviewing with?" | unresolved |
| RR2 | No hiring manager or team named | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The reporting team may own this, with no clear manager yet | `[inferred]` from the posting's silence | "Who would I work with day to day, and who owns the warehouse and the contracts?" | unresolved |
| RR3 | Salary posted and within band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is stated and consistent with the market band | `[grounded]` posting; `[generic]` band | "How is this range set, and does it move with level?" | noted |

The posting is live on the employer's own careers page, which partly answers RR1. The Series C and the company's size are still only the company's own claims.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the Series C through a funding announcement or the recruiter's email domain | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Decide on your pay floor and location before applying | R1, R10 | `[grounded]` gates | pending your approval |
| A3 | Build a small BigQuery sandbox project (even a dbt demo) before the first interview | R7 | `[inferred]` from G3 | pending your approval |

I haven't proposed any CV wording. We should wait until G1 to G5 are answered, and then I'll draft it through the audit so every line traces to what you've told me.

## Evidence status

Verified: none yet. Your intake is prose, so R2–R6 are medium until something can be inspected.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer): live, text matches the JD. Searched "Pellucid Learning live online tutoring K-12 Denver": no results, so the company footprint stays unconfirmed (RR1) |
| 2. Role-family sweep | skipped | The Datawright 2026 pay report you supplied already gives the band and the seniority norm (inputs fix the output) |
| 3. Hiring manager's public footprint | n/a | No name given, so no query to form |

I haven't run the L2 deep-research targets.

## Dossier offer and upgrade menu

I can write this up as a `tuesday-dossier.md` if you want to keep it.

- Answer to G1 → R1 closes; with G2 also clear, the decision moves to `go`.
- A sanitized dbt project or dbt docs for your Snowflake work → R4 from `medium` to `high`.
- A BigQuery sandbox project or a short writeup → R7's gap narrows.
- The Series C announcement or the recruiter's email domain → RR1 closes.
- Deeper research on Pellucid (funding, leadership, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions:**

G1: Are you based in the US, and can you work for a US employer without sponsorship? This decides the remote and Denver options.

G2: Does $148,000–$166,000 plus equity clear your pay floor?

G4 and G5: Have you built ingestion from an application database or a CRM API, or defined data contracts with the analysts who use the data (schemas, breaking-change rules, SLAs)? Which parts did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.