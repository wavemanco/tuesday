**Yes, apply once the posting checks out: `conditional_go`.** On the analytics core, your background is a direct match on the evidence you've given. The gaps are people-mentoring, clinician work, and health data. Nothing in the posting is a hard gate, and I found no red flags. I could not verify the employer (see the research line below).

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R6 · adjacent: R5 (metrics layer)
- `important`: adjacent: R7a (PM partnership) · absent: R7b (clinician partnership) · unclear: R8 (mentoring)
- `preferred`: adjacent: R9 (healthcare data)

R3 (`medium`): confirmed, but the 11% basis is unstated. R5 is near your dashboard-governance work, not a match to it. R8 is unknown from what you've shared, not a gap you've confirmed.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the role is confirmed on Harborlight's own careers page (RR2); (2) you see the pay range before a full loop (RR1); (3) the 11% lift and "built from scratch" claims hold up under probing (R3, R4).

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Web search was refused in this session, so the employer and posting are unchecked. Would have moved RR2. |
| 2. Role-family sweep | unavailable | Same refusal. Would have set a pay band and scope norm for this title. |
| 3. Hiring manager's public footprint | n/a | No name given. |

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C, care-navigation app | `[grounded]` your posting, unverified |
| Scope | Own metrics layer, A/B tests, self-serve Looker, PM and clinician partnership, mentor two juniors | `[grounded]` posting |
| Pay | Not stated | — |
| Contradictions | None within the posting | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a subscription company; stated, not inspected | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake; "expert" is untested | `[grounded]` | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and a pricing test; the 11% basis is unstated | `[grounded]` | Q2 |
| R4 | Looker or similar BI; self-serve dashboards | must_have | direct | medium | none | Built the instance and 40+ governed dashboards; self-serve use not stated | `[grounded]` | confirm self-serve use |
| R5 | Define and maintain the metrics layer | must_have | adjacent | medium | transferability | Governance work is near this; metric-definition ownership not stated. Limit: no stated sign-off on company definitions | `[inferred]` from the governance work | confirm who owned definitions |
| R6 | Written communication to non-technical stakeholders | must_have | direct | medium | none | Monthly exec metrics memo; monthly VP Product presentation | `[grounded]` | none |
| R7a | Partner with PMs on roadmap decisions | important | adjacent | medium | transferability | Presents monthly to VP Product; no PM roadmap partnership described | `[inferred]` | confirm PM involvement |
| R7b | Partner with clinicians | important | absent | none | discovery | No clinical or care-team work described | `[grounded]` silence | Q3 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Nothing either way in your background | `[grounded]` silence | Q1 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | Consumer PII under GDPR/CCPA and a consent-state model; no PHI or HIPAA controls | `[grounded]` | Q3 |

**Gap recovery queue**

- **G-R8** (mentoring, discovery): what you've done for junior analysts, and whether it was formal.
- **G-R7b / R9** (clinical and regulated data, discovery): whether you've worked with health data or care teams.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay not stated | unknown | — | (none in the posting as pasted) | Pay may sit outside the market band, or the posting may omit it by practice | `[generic]` pattern for postings that withhold pay | What is the base salary range for this role? | unresolved |
| RR2 | Employer and posting unverified | unknown | — | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The posting may not be live on the company's site | `[grounded]` posting text; check refused | Which page on your careers site carries this role, and who would I interview with? | unresolved |
| RR3 | Specific scope and outcomes | positive_signal | — | "define and maintain the metrics layer" | Scope is defined and measurable | `[grounded]` posting | Which clinical teams sign off on metric definitions? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the role on Harborlight's own careers page before investing | RR2 | `[grounded]` | proposed |
| A2 | Prepare the 11% test: metric, basis, window, and your share of the design | R3 | `[grounded]` | proposed |
| A3 | Don't claim health-data experience. Lead with the consent-state model and consumer-PII work, and say "no PHI" if asked | R9 | `[grounded]` your sentences | pending your approval |

**Evidence status.** Verified: none yet. Everything above rests on your word, which caps confidence at `medium`.

Want me to write this up as `tuesday-dossier.md` so it carries into later sessions?

**Upgrade menu**

- Search permission granted: rerun targets 1–2 (up to 5 searches, 2 fetches). This clears RR2 and sets the pay band for RR1.
- The live posting link from Harborlight's careers page: RR2 closes.
- The pay range, if you have it: RR1 closes against the band.
- A sanitized experiment readout or a dashboard screenshot: R3 and R4 move toward `high`.

**Questions**

Q1 (R8): Have you formally or informally developed junior analysts? If so, how many, over what period, and what did you own: reviews, hiring, or their roadmap?

Q2 (R3): For the pricing test behind the 11% lift, is 11% relative or percentage points, what was the measurement window, and which parts of the design did you own versus the team?

Q3 (R7b, R9): Have you worked with health, clinical or other regulated data, or with clinical or care-team stakeholders? If so, what, and what were you accountable for?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.