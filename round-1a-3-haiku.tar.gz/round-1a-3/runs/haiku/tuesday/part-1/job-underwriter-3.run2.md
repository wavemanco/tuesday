**No, not on these terms. Status: `no_go`.** Two hard gates fail on the posting's own stated terms: pay ($70–85k base against your $150k floor) and location (Austin on-site five days a week, "no exceptions", against remote-only). Your paper match is real, but a strong fit can't close a gate, and the posting's terms are what's wrong here, not your fit.

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (base compensation $70–85k), R2 (on-site Austin office 5 days a week)
- `must_have` — direct: R3 (8+ years growth leadership), R4 (paid acquisition), R5 (lifecycle/CRM); unclear: R6 (SEO/content)
- `important` — unclear: R7 (brand, PR, partnerships), R8 (sales ops)

R3–R5 are direct on your stated history, which is `medium` until there's an inspectable artifact. R6–R8 are not in your background at all, so they're open questions, not gaps you've confirmed.

Research didn't run (see the evidence status below), so nothing about Novaline itself is verified.

- **Hard gates:** failed: R1 (base compensation $70–85k), R2 (on-site Austin office 5 days a week); candidate constraints given, so checks ran against them.
- **Severe red flags:** none found. The posting asks you for nothing beyond applying.
- **Opportunity ledger.** Sound on paper, but the terms carry risk: the pay band is far below your floor and the seniority (RR1), an always-on expectation (RR2), seven growth functions under "team of one" (RR3), and success metrics that "will evolve" (RR4). The employer itself is not established (RR5).
- **What would change this:** both gates would have to move: base pay at or above $150k and remote work. The posting says "no exceptions" on location and states the band outright, so the material gives no factual path to either. Unless the employer changes both, don't apply.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting's own claims; not verified |
| Mandate | All revenue growth end to end: paid, SEO/content, lifecycle, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Compensation | $70–85k base plus equity | `[grounded]` posting |
| Market calibration | Not run; the salary search was refused (see research) | — |
| Working pattern | On-site Austin, 5 days a week, "no exceptions"; evenings and weekends expected | `[grounded]` posting |
| Unknowns | Whether SEO, brand, PR and sales ops are owned or shared; who the CEO and board are; what "success" means | — |
| Contradictions | "Team of one" alongside ownership of seven functions | `[inferred]` from the posting's own text (RR3) |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base compensation $70–85k | hard_gate | hard_gate_fail | high | hard_gate | Your $150k floor is your own specific, stated constraint; the posted band sits roughly $65k below it | `[grounded]` posting and your stated floor | none; only the employer changing pay resolves it |
| R2 | On-site Austin 5 days a week, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Your remote-only constraint is your own, stated and specific; the posting rules it out | `[grounded]` posting and your stated constraint | none; only the employer changing terms resolves it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, including Head of Growth at two B2C subscription companies; stated, not yet inspected | `[grounded]` your stated history | none |
| R4 | Paid acquisition ownership | must_have | direct | medium | none | Owned paid at two B2C subscription companies; the $8M→$40M ARR run is the strongest single claim, still stated | `[grounded]` your stated history | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | Owned lifecycle; Braze is named in your toolset | `[grounded]` your stated history | none |
| R6 | SEO/content | must_have | unclear | low | discovery | Nothing in your background covers SEO or content | `[grounded]` absence from your background | Question G1 in the closing block |
| R7 | Brand, PR, partnerships | important | unclear | low | discovery | Nothing in your background covers these | `[grounded]` absence from your background | Question G1 in the closing block |
| R8 | Sales operations | important | unclear | low | discovery | Not in your background; the B2C subscription work may be close but is unconfirmed | `[inferred]` adjacency from B2C subscription work | Question G1 in the closing block |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content, brand, PR, partnerships, sales ops (R6, R7, R8) | discovery | Your background is paid, lifecycle and experimentation; the other functions are unmentioned | They'd all fall to one person, so they matter for the workload picture even though the gates decide the status | Any SEO or content program you owned or directed; PR or partner deals; a sales-ops or CRM-pipeline role | A plan, dashboard, or case study from any of these | `[grounded]` your background's silence; `[inferred]` that they affect workload |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Seniority and scope against pay band (cites R1) | risk_signal | medium | "$70–85k base plus meaningful equity upside" | The band may be low for this scope, though the market sweep couldn't run to confirm | `[generic]` pattern for a title this scope; not a claim about Novaline | What's budgeted for this role, and how is the band set? | unresolved |
| RR2 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | The job may run beyond hours, with no stated limit | `[inferred]` from the posting's wording | How often does the team work evenings and weekends, and what does that look like in practice? | unresolved |
| RR3 | Bundled functions under one person | risk_signal | medium | "team of one to start ... own all revenue growth end to end" | Seven functions may land on one person with no budget or team behind them | `[inferred]` from the posting's scope language against its "team of one" | Which of these functions have budget or headcount committed? | unresolved |
| RR4 | Success metrics undefined | risk_signal | medium | "success metrics will evolve as we learn" | Accountability may come without a stated definition of success | `[inferred]` from the posting's wording | What does success look like at 6 and 12 months? | unresolved |
| RR5 | Employer not established (standing entry) | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on Novaline's own careers page, and who would I be interviewing with? | unresolved |

No register entry is `severity: high`, so there are no severe red flags.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply on these terms | R1 and R2 fail | `[grounded]` the gate rows | pending your approval |
| A2 | If you want to test it: ask the recruiter in writing whether the $150k base and remote work are negotiable | A clear no closes it | `[inferred]` from the gate rows | pending your approval; any message is outward-facing |
| A3 | Confirm Novaline exists on its own careers site before spending any time on it | RR5 is unresolved | `[generic]` standing-entry pattern | pending your approval |

## Evidence status

Verified: R1 and R2 are your own stated constraints, confirmed in this conversation at `high`. R3–R5 are stated history, not yet verified.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin"; the call was refused permission, so the entity's existence stays unconfirmed (RR5) |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary base compensation Series A startup 2026"; refused permission, so the market band in RR1 and role reality is missing |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Both searches were refused permission in this session, not returned empty. If you grant search permission, I can run the two checks.

## Upgrade menu

- A link to the live posting on Novaline's own careers page → RR5 clears or stays open.
- The recruiter's written answer on pay and location → R1, R2 and the decision.
- The company and its funding history (research tier L2 would add up to 5 more searches and 2 more fetches) → RR5 and RR1.
- The hiring manager's name → the public footprint check, the third target.

Would you like a full dossier saved to a file for this posting, to keep with your other applications?

1. Did this posting come from Novaline's own careers page, or from a recruiter or job board? (RR5, the employer check.)
2. Do you want me to retry the two searches, which needs permission in this session? (The company and market checks.)

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.