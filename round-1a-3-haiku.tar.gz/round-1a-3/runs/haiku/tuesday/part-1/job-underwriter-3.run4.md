## Decision snapshot

**No, not worth pursuing on these terms. Status: `no_go`.** R1 and R2, both hard gates, fail against your stated constraints.

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site, Austin, 5 days a week), R2 (Base pay $70–85k)
- `must_have`: direct: R3, R4, R9 · unclear: R5 (SEO/content), R6 (Brand and PR), R7 (Partnerships), R8 (Sales ops)
- `important`: adjacent: R10 (E-commerce enablement, from B2C subscription work) · unclear: R11 (Thrives on ambiguity)

On paper, the growth-leadership and paid/lifecycle rows are strong. The gap is in the channels you haven't mentioned owning, and the gates decide it regardless.

**Opportunity ledger.** RR1 (`severity: high`) and RR2 (`severity: high`) are the same two gates seen from the register. RR3, RR4 and RR5 are `risk_signal` entries (always-on hours, a solo seven-channel scope, no stated success metrics). RR6 is unknown because research did not run. RR7 is a self-reported profitability claim.

- **Hard gates:** failed: R1 (On-site, Austin, 5 days a week), R2 (Base pay $70–85k); candidate constraints given.
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the employer would have to change both terms in writing: base at or above $150k, and a remote arrangement. The posting says "no exceptions" on location, so nothing else in this file reopens it.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting; profitability is self-reported and unverified |
| Mandate | All revenue growth across seven channels: paid, SEO/content, lifecycle, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Reporting | CEO, dotted line to the board | `[grounded]` posting |
| Team | "A team of one to start" | `[grounded]` posting |
| Working pattern | Austin on-site five days a week, "no exceptions"; evenings and weekends "just who we are" | `[grounded]` posting |
| Pay | $70–85k base, plus equity | `[grounded]` posting; equity is not base |
| Market calibration | Not established. The role-family search was refused, so there is no band for this title. Nothing here is drawn from memory | — |
| Unknowns | Success metrics; the budget behind the seven channels; who the customers are | — |
| Contradictions | None found in the text provided. Research could not check the posting against a careers page | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site, Austin, 5 days a week | hard_gate | hard_gate_fail | high | hard_gate | Your constraint is remote-only, not relocating. The posting says "no exceptions." Confidence grades your statement, not the role | `[grounded]` posting; your stated constraint | none |
| R2 | Base pay $70–85k | hard_gate | hard_gate_fail | high | hard_gate | Your floor is $150k base. The top of the range is $65k below it. Equity is not base | `[grounded]` posting; your stated floor | none |
| R3 | Paid acquisition ownership | must_have | direct | medium | none | You say you owned paid. Intake prose, not yet probed | `[grounded]` your message | none |
| R4 | Lifecycle and CRM ownership | must_have | direct | medium | none | You say you owned lifecycle, with Braze named. Not yet probed | `[grounded]` your message | none |
| R5 | SEO and content | must_have | unclear | low | discovery | Not mentioned in your message | `[grounded]` silence | Ask whether you owned it, and with what results |
| R6 | Brand and PR | must_have | unclear | low | discovery | Not mentioned in your message | `[grounded]` silence | Ask whether you owned it, and with what results |
| R7 | Partnerships | must_have | unclear | low | discovery | Not mentioned in your message | `[grounded]` silence | Ask whether you owned it, and with what results |
| R8 | Sales ops | must_have | unclear | low | discovery | Not mentioned. The posting does not say who the customers are | `[grounded]` silence | Ask whether you owned it, and with what results |
| R9 | 8+ years growth leadership (required) | must_have | direct | medium | none | Nine years: growth lead, then Head of Growth. Years are not a gate | `[grounded]` your message | none |
| R10 | E-commerce enablement | important | adjacent | medium | transferability | Your B2C subscription growth is e-commerce-adjacent. Limit: no enablement or merchant-facing work named | `[inferred]` adjacency from your B2C work | Limit stays named wherever this is used |
| R11 | Thrives on ambiguity; metrics evolve | important | unclear | low | discovery | The posting asks for it; your message does not address it | `[grounded]` posting | Ask how you have worked without defined metrics |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | What would close it | Provenance |
|---|---|---|---|---|---|---|
| G1 | SEO and content (R5) | discovery | Not in your message | A must-have, but the gates already decide the outcome | Owned SEO strategy with traffic or revenue results | `[grounded]` silence |
| G2 | Brand and PR (R6) | discovery | Not in your message | Same as G1 | Campaigns or press outcomes you led | `[grounded]` silence |
| G3 | Partnerships (R7) | discovery | Not in your message | Same as G1 | Partner deals you sourced or ran | `[grounded]` silence |
| G4 | Sales ops (R8) | discovery | Not in your message. The sales motion is unstated | Same as G1 | Pipeline or sales-process ownership | `[grounded]` silence |
| G5 | E-commerce enablement (R10) | transferability | B2C subscription work, not enablement | Adjacent; the limit is what the bridge does not cover | Any merchant-facing or e-commerce platform work | `[inferred]` adjacency |
| G6 | Ambiguity and undefined metrics (R11) | discovery | Your message does not address it | Posting states it as a requirement | An example of operating without set targets | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base pay below your floor (see R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | Terms unacceptable to you. Equity does not count toward the base you stated | `[grounded]` posting and your floor | What base is approved for this role, and is it the figure in the posting? | confirmed |
| RR2 | On-site five days, "no exceptions" (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | Conflicts with your remote-only constraint | `[grounded]` posting and your constraint | Is any remote arrangement possible, and is "no exceptions" company policy? | confirmed |
| RR3 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Hours may run beyond the stated schedule as a norm | `[generic]` pattern: postings that call weekend work culture | What does a typical week look like, and how often are evenings and weekends needed? | unresolved |
| RR4 | Head-level scope, team of one | risk_signal | medium | "You will be a team of one to start — we believe in players who don't need a bench." | Seven channels owned solo could outrun the budget and people behind them. The posting states no budget | `[inferred]` from the channel list against the solo start and the silent budget | Which of these channels have budget today, and who would own each at month twelve? | unresolved |
| RR5 | Success metrics undefined | risk_signal | medium | "success metrics will evolve as we learn" | Revenue accountability without stated targets could be judged after the fact | `[generic]` pattern for roles at this stage | What revenue target defines success at six months and at twelve? | unresolved |
| RR6 | Employer and pay band not verified | unknown | — | "profitable since day one" | Existence and the band for this title could not be checked from here | `[generic]`: research refused, so no entity claim is made | Can you point me at this role on Novaline's own careers page? | unresolved |
| RR7 | Profitability claim | positive_signal | — | "profitable since day one" | If true, lowers funding risk. Self-reported and unverified | `[grounded]` posting | Is the business profitable today, and how is growth funded from here? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply to this posting as written | R1 and R2 fail your stated constraints | `[grounded]` R1, R2 | proposed |
| A2 | If you want to keep the door open, ask the employer for written terms on base and location before spending any time | These are the posting's own words, and a written change is the only thing that reopens the decision | `[grounded]` RR1, RR2 | proposed |
| A3 | Check Novaline on its own site before any contact | The company could not be verified from here | `[generic]` standard practice for any unfamiliar employer | proposed |

## Evidence status

Verified: R1 and R2, which are your own stated constraints. Your experience claims (R3, R4, R9) are intake prose and have not been probed, so they are unverified. The fit calls on them still stand.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Novaline's company page and listing were refused for lack of permission. Nothing was retried. Would have checked the entity, its stage, and whether the posting is live (RR6, and the contradictions row) |
| 2. Role-family sweep | unavailable | A search for Head-of-Growth base-pay bands was refused. Would have set the market band that calibrates the $70–85k figure (Market calibration) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- A written change from Novaline to both base pay and location → R1 and R2 are re-evaluated. This is the only route that reopens the decision.
- Novaline's live posting or careers page → RR6 is verified or stays open.
- Permission to run research, for Novaline's company facts and a Head-level base-pay sweep for remote roles → RR6 is checked, and the market band calibrates RR1 with a `[generic]` label.
- Evidence of SEO/content, brand/PR, partnerships or sales-ops work → R5–R8 move from `discovery` toward direct or transferable. This matters only if the gates change.

If you want this kept as a file, I can emit it as `tuesday-dossier.md`.

No questions this turn. Both gates are the posting's own stated terms, so asking more would not change the decision.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.