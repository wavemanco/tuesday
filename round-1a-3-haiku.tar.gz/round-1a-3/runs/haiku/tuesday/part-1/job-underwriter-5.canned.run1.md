**Ines, short answer: probably yes, but two gate checks I can't settle without your location and pay floor could still change that.** Status: `hold_pending_answers`. It moves to `go` if both come back clean.

- **Fit:** R3, R4, R5, R6 and R7 (the five must-haves: 5+ years, SQL and Python, dbt and a cloud warehouse, Airflow, data quality testing) read `direct` on your stated background. The real gap is BigQuery (R8, `adjacent`), which the posting names as the warehouse. Ingestion from the app and CRM (R9) and data contracts (R10) are silent in what you've told me.
- **Opportunity:** the posting is live on the company's own careers page and matches the text you pasted. Pay and scope are stated, and the stated band sits at market. I found no red flags and no requests of you.

- **Hard gates:** none failed (R1 and R2 are `unclear`); unconfirmed: R1 (remote US or Denver office), R2 (salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a no on R1 or R2 makes it `no_go`. A clean answer on both, plus a credible BigQuery bridge, makes it `go`.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online K-12 tutoring in 31 states, Denver, 264 employees, Series C ($52M, Feb 2026) | `[grounded]` its about page; the Series C figure is self-reported only, not independently checked |
| Mandate | Pipelines behind tutoring reporting: app and CRM ingestion, a dbt warehouse on BigQuery, data contracts for analysts | `[grounded]` posting and careers page |
| Scope read | Spans three areas (ingestion, warehouse, contracts), wider than the usual one-domain scope for this title | `[generic]` Datawright scope norm; `[inferred]` from the three named areas |
| Market calibration | Datawright 2026 for Senior DE at Series B–D: median $151,000, IQR $139,000–$163,500. The posting's midpoint ($157,000) sits inside the IQR | `[generic]` the Datawright snippet, which matches the figures you pasted; `[grounded]` the posting's band |
| Unknowns | Hiring manager; whether the BigQuery warehouse is greenfield or inherited; team boundary for CRM ingestion; equity terms | — |
| Contradictions | None between the posting and the careers page | `[grounded]` careers page fetched |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote US or Denver office (location and work authorization) | hard_gate | unclear | none | hard_gate | Your location and authorization weren't given, so the gate is not established | `[grounded]` posting | Q1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor wasn't given | `[grounded]` posting | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; self-reported, not yet probed | `[grounded]` your statement | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both, self-reported | `[grounded]` your statement | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt on Snowflake, about 180 models; Snowflake is a cloud warehouse, so the requirement as worded is met | `[grounded]` your statement | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow in production | `[grounded]` your statement | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up a Great Expectations suite; how much you owned is unstated | `[grounded]` your statement | probe ownership |
| R8 | BigQuery warehouse (named in the role, not the requirements list) | important | adjacent | medium | transferability | dbt and warehouse work carry over; BigQuery itself is unused | `[inferred]` bridge from R5 | G1 |
| R9 | Ingestion from app and CRM | important | unclear | none | discovery | Silent in your background | `[grounded]` absence | G2 |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Silent in your background; Great Expectations is quality testing, not contracts | `[grounded]` absence | G2 |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| G1 | BigQuery (R8) | transferability | dbt on Snowflake, nothing on BigQuery | BigQuery is named as the warehouse, so it's the likeliest interview probe | A dbt project or design doc from any warehouse, to show the transfer | `[inferred]` bridge; `[generic]` BigQuery's cost model and dialect differ from Snowflake's |
| G2 | Ingestion and data contracts (R9, R10) | discovery | Your background doesn't mention them | Two of the five named areas of the role | A pipeline or contract doc showing what you owned | `[grounded]` absence |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay and scope stated | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The stated band is at market for the title | `[grounded]` posting; `[generic]` Datawright band | Is $148k–$166k the approved budget for this hire, and how is equity valued? | noted |
| RR2 | No hiring manager named | unknown | — | (posting names no manager) | Not a risk by itself; a reporting-line question | `[generic]` pattern for postings of this kind | Who would I report to, and who owns this pipeline day to day? | unresolved |
| RR3 | Scope spans three areas | risk_signal | low | "Build and run the pipelines behind our tutoring platform's reporting" | The post may be wider than one domain, or CRM ingestion may sit with another team | `[inferred]` from the posting's three areas against the `[generic]` scope norm | Is CRM ingestion in this role's scope, or with another team? | unresolved |

**Application plan** (proposed; pending your approval)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Answer Q1 and Q2 before applying | They are the two checks that could move this to `no_go` | `[grounded]` R1, R2 | pending your approval |
| P2 | Write a BigQuery bridge that says what carries over and what you haven't used | Turns R8 from a gap into a stated limit | `[inferred]` from R8 | pending your approval |
| P3 | Ask the RR2 and RR3 questions in the first recruiter call | They settle scope and reporting line | `[grounded]` register | pending your approval |

**Evidence status**

Verified: none yet. Everything you've said is self-report, so the R3–R7 claims are medium, not high.

Research tier: L1 — searches 2 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning tutoring company Denver" and fetched pellucidlearning.com/careers/senior-data-engineer (live, accepting applications, text matches the posting you pasted). The search also returned pellucidlearning.com/about. Moved: the entity is attributed to its own domain; the failed-attribution check did not trigger. The Series C figure is self-reported only. |
| 2. Role-family sweep | yes | Searched "Datawright 2026 Data Engineering Pay Report senior data engineer salary", which returned datawright.example/2026-data-engineering-pay-report with a snippet matching your figures. I read the snippet, not the full report. Moved: market calibration (RR1). |
| 3. Hiring manager's public footprint | n/a | No name given, so no query could be formed. |

**Dossier offer:** I can write this analysis to `tuesday-dossier.md` so you can carry it into a later interview-prep session.

**Upgrade menu**
- Your answers on location and pay → R1 and R2 settle, and the status moves to `go` or `no_go`.
- A dbt project, design doc or any other inspectable artifact from your Snowflake work → R3–R7 can rise from `medium` to `high`, and G1 gets stronger.
- A pipeline or contract doc showing ingestion or data contracts → R9 and R10 move.
- A deeper pass on Pellucid (funding, leadership changes, public reviews; up to 5 more searches and 2 more fetches). Say the word and it runs.
- The hiring manager's name → the scope read and the positioning for this reader.

**Questions**

Q1 (R1): Are you authorized to work in the US, and can you work remotely in the US or from the Denver office?

Q2 (R2): Is $148,000–$166,000 plus equity above your floor?

Q3 (G2, R9 and R10): Have you built ingestion from a product app or a CRM, or owned data contracts analysts relied on? Describe what you owned and what happened.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.