**Decision: `conditional_go`.** Worth applying, if the forecast and billing parts of the role are real. Those are the two things the posting leads with that you haven't done, so check them before you invest in the loop.

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, two days a week in the office), R2 (£61,500–£67,000 pay); candidate constraints not given. Checks against your pay floor and office days are unknown until you tell me them.
- **Severe red flags:** none found.
- **Conditions for go:** (1) forecast ownership, RR1, is concrete: the role owns the quarterly forecast number rather than feeding finance's; (2) billing-data access, RR2, is confirmed or you're comfortable learning it; (3) R1 and R2 check out against your constraints.

## Fit ledger (requirements from the posting)

- `hard_gate`: unclear: R1 (Bristol, two days a week in office), R2 (£61,500–£67,000 pay)
- `must_have`: direct: R3a (4+ years in RevOps or sales ops; you have 5 in sales ops), R4 (Salesforce admin), R5a (SQL); adjacent: R3b (B2B *software*; your employer was B2B payments), R6 (forecast ownership; you ran pipeline reviews, never owned the forecast), R7 (finance on billing/revenue data; revenue data yes, billing no); unclear: R5b (spreadsheet modelling; daily Excel use, depth not stated)
- `important`: direct: R8 (pipeline and renewal reporting; you rebuilt both); absent: none

Confidence, all from your background as you've described it: `medium` on R3a, R4, R5a, R8 (self-report; Salesforce certificate would raise R4 to `high`). R6 and R7 are `medium` as adjacency.

Each row's reasoning, gap type and next action are in the list below.

- **R6, forecast (`adjacent`, transferability):** `[grounded]` your monthly pipeline review with the sales director. The limit is that finance owned the company forecast. Strengthener: a pipeline-to-forecast reconciliation you ran, if one exists.
- **R7, billing (`adjacent`, transferability):** `[grounded]` renewal and pipeline work. The limit is no billing data. Ask whether you've reconciled renewals against invoices.
- **R5b, spreadsheet modelling (`unclear`, discovery):** the posting asks for modelling; daily Excel use isn't evidence of it yet.

## Opportunity ledger

- **RR1, forecast authority (`unknown`):** "run the quarterly revenue forecast with the CFO" doesn't say who owns the number. `[inferred]` from the JD's wording. Question: "Who owns the forecast number, and who signs it off?"
- **RR2, billing data (`unknown`):** "own our CRM and billing data" doesn't say what access or ownership of billing data means. Question: "Which system holds billing, and what does owning it involve day to day?"
- **RR3, pay (`positive_signal`):** the £61,500–£67,000 range is stated. `[generic]` against a 2026 UK survey (Ledgerline, n=438; median £64,200, IQR £57,800–£70,400), it sits in the lower-middle of the band. Neither a red flag nor an all-clear.
- **RR4, posting live on the employer's site (`unknown`):** I couldn't confirm it there. Question: "Is this role live on quillfield.co.uk, and who would I interview with?"

Employer existence is attributed: a search returned Quillfield's own about page (Bristol, founded 2018, 96 staff, £11M Series A in April 2025). So the failed-attribution entry doesn't apply.

## Role reality

- `[grounded]` The posting: Revenue Operations Lead, Bristol hybrid, £61,500–£67,000 plus share options; owns CRM and billing data, builds pipeline and renewal reporting, runs the quarterly forecast with the CFO.
- `[grounded]` Quillfield's about page (search snippet, not fetched): invoicing and payments software for UK builders' merchants.
- `[grounded]` The hiring manager's public profile (search snippet): Head of Revenue Operations at Quillfield, previously sales operations at a payments company for four years. Your background is close to theirs, which helps positioning.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask RR1, RR2 and RR4 before the first interview | They decide whether the role is what it says | `[grounded]` register | proposed |
| A2 | Lead with the pipeline and renewal dashboards, and the Salesforce certification | Those rows are strongest | `[grounded]` R4, R8 | proposed |
| A3 | Frame the forecast and billing experience as adjacent, with the limit stated | Overclaiming would fail in the first forecast question | `[grounded]` R6, R7 | proposed |

Nothing here is written as CV language yet. I'll draft wording only when you approve it.

## Evidence status

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved |
|---|---|---|
| 1. Official site and careers page | yes | Search returned Quillfield's about page: company exists as described. Careers page not fetched, so RR4 stays open |
| 2. Role-family sweep | yes | Ledgerline 2026 UK RevOps pay guide, `[generic]` band for RR3 |
| 3. Hiring manager's public footprint | yes | Public profile: current role and career pattern only |

Verified: none yet. Everything above rests on your message and the posting; I haven't checked your certifications or any artifacts.

## Upgrade menu

- A copy of your Salesforce certification → R4 to `high`.
- A forecast or reconciliation you worked on, even partly → R6 to `direct`.
- Any billing or invoice reconciliation → R7 to `direct`.
- Your pay floor and office-day limit → the hard-gate line gets checked.
- A deeper pass on Quillfield (funding rounds, leadership changes, reviews; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

R6: Have you ever worked on a forecast that someone else signed off? What did you own in that process?

R1/R2: What's your pay floor, and can you do two office days a week in Bristol?

R7: Have you ever reconciled renewal or pipeline data against invoices or billing records, even a small sample?

Answer in text, or say skip.

If you want this kept as a document you can add to, I can write it up as `tuesday-dossier.md`.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.