**Yes, apply, but verify the posting first.** On the analytics core you're a strong match. The gaps are healthcare data, clinician partnership, and mentoring. Status: `conditional_go`.

- **Fit ledger.**
  - `must_have`: direct R1, R2, R3, R5, R8; adjacent R7a (partner with PMs); unclear R4 (metrics layer), R7b (clinicians)
  - `important`: direct R6; unclear R9 (mentor two junior analysts)
  - `preferred`: adjacent R10 (healthcare data)

  R7a has a real PM link but no named roadmap decision. R4 rests on dashboards you built, not on confirmed ownership of metric definitions. R7b has no clinician work in your background. R9 isn't stated. R10 has consent work, but no PHI or HIPAA controls.

- **Opportunity ledger.** Sound but under-specified. RR1 is that the employer and posting are unverified, because the search was refused. RR2 is that the scope bundles several roles. RR3 is that PHI handling is unknown. RR4 is a concrete remit, which is a positive.
- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is live on Harborlight's own careers page (RR1; this caps the decision at `conditional_go` until it is); (2) the metrics-layer ownership and the PHI scope hold up in screening (R4, RR2, RR3); (3) pay, location and contract type fit your constraints (not yet given).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD self-description; unverified, search refused |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker, PM and clinician partnership, mentoring two analysts | `[grounded]` JD |
| Scope read | Bundles senior analyst, metrics-owner and people-manager work | `[inferred]` from the JD's list against its silence on team and decision rights |
| Market calibration | Not run: the role-family search was refused, so no pay or scope band | — |
| Unknowns | Pay, location, contract type, team and data-platform ownership, PHI scope | — |
| Contradictions | None visible; the JD is the only source | `[grounded]` |

## Evidence map

Your background is self-report, so it is capped at `medium` on this pass.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years, one consumer-subscription company; stated, not yet inspected | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake; "expert" is your word, not yet shown | `[grounded]` your background | Offer a complex query or analysis to show depth |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year, including the pricing test behind an 11% retention lift; a strong match | `[grounded]` your background | Confirm your role in the pricing test |
| R4 | Define and maintain the metrics layer | must_have | unclear | low | discovery | Built 40+ governed dashboards, but canonical definitions ownership is unconfirmed | `[grounded]` dashboards; ownership unknown | Question G1 |
| R5 | Looker or similar BI | must_have | direct | medium | none | Built the company's Looker instance from scratch | `[grounded]` your background | none |
| R6 | Self-serve dashboards | important | direct | medium | none | Governed dashboards built for others to use | `[grounded]` your background | none |
| R7a | Partner with PMs; turn analysis into roadmap decisions | must_have | adjacent | medium | transferability | Monthly VP Product presentations and the exec memo; no named roadmap decision yet | `[inferred]` from presenting to product leadership | Give one roadmap decision your analysis changed |
| R7b | Partner with clinicians | must_have | unclear | low | discovery | No clinician or domain-expert work in your background | `[grounded]` silence | Question G2 |
| R8 | Written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly metrics memo read by the exec team | `[grounded]` your background | Offer a redacted memo to show |
| R9 | Mentor two junior analysts | important | unclear | low | discovery | Mentoring not mentioned | `[grounded]` silence | Question G2 |
| R10 | Healthcare data (HIPAA), a plus | preferred | adjacent | medium | transferability | Built a GDPR/CCPA consent-state model; no PHI, HIPAA controls, or BAAs | `[inferred]` adjacency from consumer-PII governance | Make the bridge and name its limit |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics-layer ownership (R4, must_have) | discovery | Dashboards built; who set the definitions is not stated | Decides whether R4 moves from `unclear` to `direct` | Writing canonical metric definitions; resolving two teams' conflicting numbers; governing a dashboard set | A metric dictionary, a governance doc, or a dashboard screenshot | `[grounded]` silence on ownership |
| G2 | Clinician partnership and mentoring (R7b, R9) | discovery | Nothing in the background | Two requirements the role names directly | Working with nurses, care teams, or ops; coaching analysts through a first project | A note on one case | `[grounded]` silence |
| G3 | PM roadmap link (R7a, must_have) | transferability | Presenting to VP Product; no decision named | Strengthens the case that analysis changes roadmaps | An analysis that changed a launch, a pricing change, or a cut | One example, with the decision and its outcome | `[inferred]` bridge from the exec-facing work |
| G4 | Healthcare data (R10, preferred) | transferability | Consent and PII governance, consumer scope | The main objection the role will raise | Any work on sensitive data under access controls | A consent-model description, with its limits named | `[inferred]` adjacency; `[generic]` that healthcare interviews probe PHI first |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting unverified | unknown | — | "Harborlight Health … Series C" | The check did not run, so this is unverified, not a finding against the company | `[grounded]` search refused; no finding either way | Can you point me at this role on your own careers page, and who would I be interviewing with? | unresolved |
| RR2 | Scope bundles several roles | risk_signal | medium | "define and maintain the metrics layer … partner with PMs and clinicians … mentor two junior analysts" | The role may combine senior analyst, metrics owner, and people manager without stated team or decision rights | `[inferred]` from the JD's list against its silence on team and data platform | Which of these does this role own alone, and which sit with a data or platform team? | unresolved |
| RR3 | PHI scope unstated | unknown | — | "healthcare data experience (HIPAA) a plus" | The role may touch protected health data under controls you have not worked with | `[inferred]` from the HIPAA line against no stated data-access model | What data does the warehouse hold for this app, is any of it PHI, and who approves access? | unresolved |
| RR4 | Concrete remit | positive_signal | — | "build self-serve dashboards … design and analyze A/B tests" | Deliverables are concrete, so success is measurable | `[grounded]` JD | What would show this role working after six months? | noted |
| RR5 | Pay, location, contract not given | unknown | — | (absent from JD) | Without these, your constraint checks cannot run | `[grounded]` absence from the JD | What are the pay band, location policy, and contract type? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the experimentation program: 30+ tests a year, and the pricing test behind an 11% retention lift, as you stated it | Matches R3, the strongest row | `[grounded]` your background | pending your approval |
| E2 | Describe healthcare as consent and PII governance (the consent-state model), with its limit stated: no PHI or HIPAA work | Matches R10 without borrowing HIPAA experience | `[grounded]` your background | pending your approval |
| A1 | Ask RR1, RR2, and RR3 in the first screen | These decide whether the role is what it claims | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Every claim above is your stated background, not yet confirmed or inspected.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused by permission. Would have checked the company's existence, size, stage, and whether the posting is live; this moves RR1 and the cap on the decision |
| 2. Role-family sweep | unavailable | One search was refused. Would have set the market band for title, scope, and pay; no band is stated here |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- A redacted experiment readout or design doc for the pricing test → R3 to `high`.
- A metric dictionary or dashboard screenshot → R4 and R5 to `high`.
- A redacted monthly memo → R8 to `high`.
- The live posting on Harborlight's careers page → RR1 closes, and the cap lifts.
- Pay band, location, and contract type → RR5 closes, and your constraint checks can run.
- A deeper pass on Harborlight Health (funding, leadership changes, recent news, employee reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

If you want, I can write this into a `tuesday-dossier.md` to carry into later turns.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

1. **G1** — When you built the governed dashboards, did you own the canonical metric definitions, or did you build on definitions someone else set?
2. **G2** — Have you worked with clinicians or other domain experts, or mentored analysts, even informally? Describe one case.
3. **RR5** — What are your non-negotiables: pay floor, location or remote, and contract type?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.