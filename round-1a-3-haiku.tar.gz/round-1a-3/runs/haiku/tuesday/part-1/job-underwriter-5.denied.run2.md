**Yes, apply, as a `conditional_go`.** Your stack is close to a direct match for this posting. The open items are BigQuery, the ingestion and data-contract scope, and whether the employer checks out. I could not check the employer independently: both web searches were refused, so everything about Pellucid below comes from the text you pasted.

**Decision snapshot**

- **Status: `conditional_go`.** Apply once the posting is confirmed live on the company's careers page. Also confirm your location and pay floor, since I have neither.
- **Fit ledger:**
  - `hard_gate`: unclear: R1, R2
  - `must_have`: direct: R3, R4, R5, R6, R7
  - `important`: adjacent: R8 (BigQuery, a transferable bridge with its limit named); unclear: R9, R10 (ingestion and data contracts, which the posting describes and your background does not)
- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Base pay $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Opportunity ledger:** The stated pay sits inside the pay report's range, and the scope is concrete. Open: the employer is not established (RR1), team scope (RR2), equity (RR3), and no hiring manager named (RR4).
- **Conditions for go:** (1) the posting is live on pellucidlearning.com's careers page and Pellucid is as described (RR1); (2) your location and pay floor clear R1 and R2; (3) BigQuery is presented as adjacent with its limit named, never as experience.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 states, founded 2016, Denver, 264 staff, Series C ($52M, Feb 2026) | `[grounded]` your paste of the about page, unverified |
| Scope | Build and run ingestion, a dbt warehouse on BigQuery, and data contracts for reporting | `[grounded]` posting |
| Pay | $148k–$166k base plus equity; midpoint $157k | `[grounded]` posting |
| Market calibration | Senior base median $151k, IQR $139k–$163.5k, with typical scope of one domain's pipelines and no direct reports. The posting sits in the upper half of that IQR, and its scope reads as ordinary for the title | `[generic]` pay report figures you pasted |
| Contradictions | None found in what you pasted | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | No location constraint given | `[grounded]` posting | Q1 below |
| R2 | Base pay $148k–$166k | hard_gate | unclear | none | hard_gate | No pay floor given | `[grounded]` posting | Q1 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years, self-reported and not probed | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | 180 dbt models on Snowflake, stated | `[grounded]` your background | none |
| R6 | Orchestration (Airflow or similar) | must_have | direct | medium | none | Airflow, stated | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite, stated | `[grounded]` your background | none |
| R8 | BigQuery (named in the role description) | important | adjacent | medium | transferability | Snowflake dbt and SQL carry over; the BigQuery cost and partitioning model does not | `[inferred]` from your Snowflake work; never used BigQuery is your statement | G2 |
| R9 | Ingestion from the app and CRM | important | unclear | low | discovery | Not in your background | `[grounded]` background silence | G1 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Not in your background | `[grounded]` background silence | G1 |

**Gap recovery queue**

- **G1 (R9, R10):** discovery. Your background is silent on owning ingestion or a contract. Closes if you have owned either, or if you can name an artifact (a contract doc, an ingestion DAG).
- **G2 (R8):** transferability. The bridge is Snowflake to BigQuery. The limit is that you have not run BigQuery workloads. It strengthens if you have a sandbox project or any GCP work.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "Pellucid Learning runs live online tutoring…" | Research was refused, so Pellucid is neither confirmed nor ruled out. The posting and about page sit on the company's own domain, which is a good sign, but unchecked here | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Scope breadth | unknown | — | "Build and run the pipelines behind our… reporting" | One engineer may own the whole reporting stack, not one domain | `[inferred]` from the breadth of the list against the pay report's domain-ownership norm | Is this one engineer owning the whole reporting stack, or one domain within a team? Who else works on the data platform? | unresolved |
| RR3 | Equity unstated | unknown | — | "plus equity" | Terms may be unusual or undisclosed | `[grounded]` posting silence | What equity is offered, in what form, and on what vesting schedule? | unresolved |
| RR4 | No hiring manager named | unknown | — | (posting silent) | Unknown reporting line | `[grounded]` posting silence | Who is the hiring manager, and who is on the team? | unresolved |
| RR5 | Pay range sits near the median | positive_signal | — | "$148,000–$166,000" | Pay is competitive for the title | `[generic]` IQR, `[grounded]` posting | Is this range set for this level and location? | noted |

No `severity: high` entries, so no severe red flags.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on the careers page and the company's Series C claim before applying | RR1 | `[grounded]` RR1 | pending your check |
| A2 | Lead with the Snowflake dbt, Airflow, and Great Expectations work, stated as what you built | R5–R7 | `[grounded]` your background | pending your approval |
| A3 | Describe BigQuery as adjacent, with the limit named | R8 | `[grounded]` R8 | pending your approval |

**Evidence status**

Verified: none yet. Everything above is from your background as you stated it.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused (WebSearch permission was not granted). Pellucid's existence, the posting's live status, and the Series C claim are unchecked. This is RR1 |
| 2. Role-family sweep | skipped | The pay report's median, IQR and typical scope are pasted in full, so a search could not change the band |
| 3. Hiring manager's public footprint | n/a | No name was given |

**Upgrade menu**

- Web search permission granted → reruns target 1, which settles RR1.
- Your location and pay floor → R1 and R2 close.
- A link to the live posting → RR1 closes faster than a search would.
- The hiring manager's name → RR4 closes, and the application plan can lead with the story that reader needs.
- Work samples such as a dbt project or a Great Expectations suite, sanitized → R5–R7 move to `high`.

If you want, I can write this up as a `tuesday-dossier.md` you can keep and add to as things resolve.

Questions:

- **G3 (R1, R2):** Is a Denver or remote-US role workable for you, and what base pay would you not go below?
- **G1 (R9, R10):** Have you owned ingestion from a product app or CRM, or a data contract that analysts used? What did you own, and what broke?
- **G2 (R8):** Have you touched BigQuery at all, such as a sandbox, a GCP project, or its partitioning and cost model?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.