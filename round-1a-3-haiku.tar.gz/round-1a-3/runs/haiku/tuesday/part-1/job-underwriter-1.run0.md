## Decision snapshot

**Yes, apply, once the posting checks out on Harborlight's own careers site. Status: `conditional_go`.** Your core analytics record matches the JD's must-haves. The gaps are healthcare data, clinician partnership, and mentoring, and none of them is a hard gate.

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: direct: R7a · adjacent: R6 · absent: R7b, R8
- `preferred`: adjacent: R9

R1 (5+ years product analytics), R2 (SQL), R3 (experiment design), R4 (Looker) and R5 (written communication) are direct; each confidence is `medium`, the intake ceiling, because nothing is inspectable yet. R6 (`medium`), the metrics layer, is adjacent: you have governed dashboards, not a metrics layer you owned. R7b (clinicians) and R8 (mentoring) are absent, with no evidence either way yet. R9 (healthcare and HIPAA) is adjacent: consumer PII under GDPR/CCPA and a consent model are real, but there is no PHI or HIPAA work.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Opportunity ledger.** The scope is concrete (RR4 positive). The pasted JD states no pay or location (RR2, RR3), and the employer could not be checked (RR1, standing entry).
- **Severe red flags:** none found.
- **Conditions for go:** (1) the live posting appears on Harborlight's careers site and matches the JD (RR1); (2) the recruiter confirms pay and location (RR2, RR3); (3) you present the healthcare background as adjacent, never as HIPAA experience (R9).
- **What would change this:** a clinician-facing or mentoring gap that turns out to be a real requirement in the interview loop would push R7b or R8 toward a harder call, but would not block applying.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` your JD paste; not checked against any outside source |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker, PM and clinician partnership, mentoring two analysts | `[grounded]` JD |
| Scope read | Senior IC plus mentoring, with a named metrics layer | `[inferred]` from the JD's responsibility list |
| Market calibration | Not run. Both role-family searches were refused, so there is no pay band or scope norm | — |
| Unknowns | Pay, location and work pattern, team structure, whether the metrics layer exists yet, clinician access, hiring manager | — |
| Contradictions | None visible in the pasted JD | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a subscription company, stated, not inspected | `[grounded]` your background | Share a CV line with dates |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake for six years; "expert" is your self-assessment | `[grounded]` your background | None |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and the pricing test behind an 11% retention lift; you ran the program | `[grounded]` your background | Ask for a sanitized test readout to raise to high |
| R4 | Looker or similar BI, self-serve dashboards | must_have | direct | medium | none | Built the instance from scratch with 40+ governed dashboards | `[grounded]` your background | Ask for a dashboard screenshot, redacted |
| R5 | Written communication for non-technical stakeholders | must_have | direct | medium | none | Monthly exec memo and monthly VP Product presentation | `[grounded]` your background | Ask for a redacted memo |
| R6 | Define and maintain the metrics layer | important | adjacent | medium | transferability | Governed dashboards imply metric definitions; no evidence you owned a semantic layer | `[inferred]` from "governed dashboards" | Confirm who defined the metric set |
| R7a | Partner with PMs on roadmap decisions | important | direct | medium | none | Monthly VP Product presentations and the metrics memo | `[grounded]` your background | None |
| R7b | Partner with clinicians | important | absent | none | discovery | Nothing in the background touches clinical teams | `[grounded]` silence | Question G1 |
| R8 | Mentor two junior analysts | important | absent | none | discovery | Not mentioned | `[grounded]` silence | Question G2 |
| R9 | Healthcare data, HIPAA a plus | preferred | adjacent | medium | transferability | Consent-state model and GDPR/CCPA PII work are real; no PHI or HIPAA program. Limit: consumer data is not regulated the same way | `[grounded]` your background; the limit is `[inferred]` | Frame as adjacent only |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | What would close it | Provenance |
|---|---|---|---|---|---|---|
| G1 | Clinician partnership (R7b) | discovery | No clinical collaboration in what you've shared | The JD names clinicians as partners; a gap here shapes the interview | Any work with care, clinical or patient-facing teams | `[grounded]` silence; `[inferred]` that the loop will probe it |
| G2 | Mentoring (R8) | discovery | No mentoring or management mentioned | Two junior analysts is an explicit responsibility | Formal or informal analyst mentoring, with what it looked like | `[grounded]` silence |
| G3 | Metrics layer ownership (R6) | transferability | Governed dashboards, no owned semantic layer | A central responsibility; the bridge is real but limited | Metric definitions you wrote or governed | `[inferred]` bridge from dashboard governance |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "Harborlight Health (digital-health scale-up …)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Web checks were refused, so this run could not attribute the company | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | none in the pasted JD | The posting may withhold pay, or the paste may be an abridged version | `[inferred]` from the paste's silence on pay | What is the base salary range for this role? | unresolved |
| RR3 | Location and work pattern not stated | unknown | — | none in the pasted JD | Remote, hybrid or onsite is unknown | `[inferred]` from the paste's silence | Where is this role based, and what is the in-office expectation? | unresolved |
| RR4 | Concrete scope | positive_signal | — | "Own product analytics for our care-navigation app" | Scope and responsibilities are specific and bounded | `[grounded]` JD | Which metric definitions already exist, and who signs off on them? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Find the live posting on Harborlight's careers page and compare it to the pasted JD | Clears RR1 before effort | `[generic]` standing entry | For you to do |
| P2 | Lead with the experiment program (R3) and Looker build (R4) | Strongest direct evidence | `[grounded]` rows R3, R4 | Pending your approval |
| P3 | Describe the healthcare background as consumer privacy and consent work, adjacent to HIPAA, and never claim HIPAA | Keeps R9 honest | `[grounded]` R9 | Pending your approval |
| P4 | Ask the recruiter RR2 and RR3 verbatim | Pay and location decide whether the role is worth it | `[grounded]` register | For you to do |
| P5 | Before writing anything about mentoring or clinicians, answer G1 and G2 honestly | Avoids overclaiming R7b and R8 | `[grounded]` gap queue | Pending your answer |

Proposed CV line (not finalized): "Owned the company's Looker instance end to end: 40+ governed dashboards." Pending your approval.

## Evidence status

Verified: none yet. Every claim is your own statement in this conversation, not an inspected artifact. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both search calls were refused because web search permission was not granted here. I did not retry. Would have moved RR1 and the live-posting check |
| 2. Role-family sweep | unavailable | Refused in the same way. Would have produced a pay and scope band for the market calibration line and RR2 |
| 3. Hiring manager's public footprint | n/a | No name in the pasted posting, so there was no query to form |

## Upgrade menu

- The full posting link, or the careers-page URL → RR1 closes or does not, and RR2 and RR3 may be answered on the page.
- Permission to run web search → rows 1 and 2 can run; the employer and pay band become checkable.
- A hiring manager's name → the scope read and which story to lead with for that reader.
- A sanitized experiment readout or a redacted memo → R3 and R5 move to `high`.
- Any metrics-layer artifact → R6 moves toward `direct`.

I can write a `tuesday-dossier.md` of this assessment so the open items carry into later runs.

1. G1: Have you worked directly with clinicians, care teams or patient-facing staff? What did that involve?
2. G2: Have you mentored or managed analysts, formally or informally? What did it look like?
3. Do you have the full posting link? If so, paste it and I can check the pasted JD against it.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.