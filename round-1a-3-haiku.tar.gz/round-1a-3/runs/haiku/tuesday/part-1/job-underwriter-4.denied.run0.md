**Status: `conditional_go`.** Yes, it's worth applying to, on the three conditions below. Your must-haves are supported by what you've told me, but the posting doesn't yet show that the employer is real or that remote UK eligibility works for you.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5
- `important` — direct: R6 · adjacent: R9 (Pet-insurance product knowledge) · unclear: R7 (Recommendations for product)
- `preferred` — direct: R8 (Insurance experience)

R2, R3, R4 and R5 are evidenced by your statement, at `medium`, with no artifact yet. R9 is adjacent: motor pricing carries over, but pet is not yet evidenced. R7 is unclear: your underwriting recommendations are evidenced, and product recommendations are not stated. R1 is unclear: your location and right to work are not in the material.

**Opportunity ledger.** The remit is specific and names two stakeholder teams (RR4). Decision rights and pay are not stated (RR1, RR3), and the employer is not established from attributable sources (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this, the conditions for `conditional_go`:** (1) the live role is confirmed on Brindlemoor's own careers site (RR2); (2) you are UK-based with right to work (R1); (3) the role's decision rights are concrete when you ask in interview (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech | `[grounded]` JD header; existence not verified (RR2) |
| Mandate | Own pricing analytics for the pet-insurance product: rating models, price tests, recommendations for underwriting and product | `[grounded]` JD |
| Seniority | "Senior" title; your current level is senior analyst | `[grounded]` JD and intake |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` user-supplied; public footprint not checked |
| Scope read | One product, with rating models and price tests in scope | `[inferred]` from "own" plus a single product line |
| Market calibration | Not calibrated. The role-family search was refused, so no band is offered | — |
| First-year outcomes | None stated | `[grounded]` JD silence |
| Unknowns | Decision rights over rate changes, team or direct reports, pay, contract type, your location eligibility, whether the employer is established | — |
| Contradictions | None visible in the material provided | `[grounded]` JD and intake |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | Your location and right to work are not stated, so the gate is unsettled, not failed | `[grounded]` JD; intake silent | One gate question (closing block) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years of pricing analytics at a UK motor insurer, last two as senior analyst. Self-reported, no artifact | `[grounded]` your intake | Artifact offer (upgrade menu) |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated. No query or script inspected | `[grounded]` your intake | Sample offer (upgrade menu) |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for a young-driver motor book. Motor, not pet | `[grounded]` your intake | Documentation offer (upgrade menu) |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your intake | none |
| R6 | Design and read price tests | important | direct | medium | none | 14 price tests run with underwriting last year. Split between designing and reading not stated | `[grounded]` your intake | Readout offer (upgrade menu) |
| R7 | Recommendations for product (underwriting covered by R5) | important | unclear | low | discovery | Underwriting recommendations are evidenced. Product recommendations are not mentioned | `[grounded]` intake silence on product | Gap G1 |
| R8 | Insurance experience | preferred | direct | medium | none | UK motor insurer, five years | `[grounded]` your intake | none |
| R9 | Pet-insurance product knowledge | important | adjacent | medium | transferability | Motor pricing and GLMs carry over. Pet loss drivers, cover design and vet-cost severity are not exercised in the material. The requirement is inferred from the product name; the JD does not tier it | `[inferred]` from "our pet-insurance product"; `[generic]` that pet pricing has its own drivers | Gap G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Recommendations for product (R7, important) | discovery | Underwriting recommendations are evidenced through the quarterly review. Nothing on product-side recommendations | Moves R7 from unclear; the JD names product as a recipient | A pricing or feature change you proposed to a product team; a readout that changed a product decision | A product brief, or a readout that went to product | `[grounded]` intake silence; `[inferred]` that it moves R7 |
| G2 | Pet-insurance product knowledge (R9, important) | transferability | Motor pricing with GLMs and price tests. No pet exposure | The product is pet, so this is the bridge interviewers will probe | Any non-motor pricing you touched, or GLM work where the drivers differed | A sanitized pricing note or readout from a non-motor line | `[inferred]` bridge from motor work; `[generic]` that pet drivers differ from motor |
| G3 | Fully remote, UK (R1, hard_gate) | hard_gate | Location and right to work not stated | If the gate fails, the status is `no_go`; wording cannot solve it | None; this is a surfacing, not a recall | Your own statement of eligibility | `[grounded]` JD term; intake silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Decision rights and team not stated | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may own analysis without authority over rate changes, or may carry sign-off with no stated team | `[inferred]` from "own" against silence on authority | Which rate changes does this role sign off itself, and which go to committee? Does it have direct reports? | unresolved |
| RR2 | Employer not established | risk_signal | medium | "Brindlemoor (insurtech)" | The employer may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for employers of this size, not a claim about this one; employer search refused | Can you point me at this role on Brindlemoor's own careers site, and who would I be interviewing with? | unresolved |
| RR3 | Pay not stated | unknown | — | (JD gives no pay) | Pay may sit below the senior band, or Brindlemoor may not publish pay. No band available: the role-family search was refused | `[inferred]` from silence on pay | What is the budgeted base salary for this role? | unresolved |
| RR4 | Clear remit and named stakeholders | positive_signal | — | "design and read price tests, and turn the results into recommendations for underwriting and product" | The remit is specific, and both named teams are ones you already work with | `[grounded]` JD | Which underwriting and product leads would this role's recommendations go to? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm the live role on Brindlemoor's own careers site before spending application effort | see RR2 | `[generic]` pattern; `[grounded]` JD | pending your approval |
| P2 | Lead with the motor GLM rating model, the 14 price tests and the quarterly review to the head of underwriting, each as you stated it | see R4, R6, R5 | `[grounded]` your intake | pending your approval |
| P3 | Present pet as a transfer: motor pricing carries over, and you have not priced pet products | see R9, G2 | `[inferred]` from the bridge | pending your approval |
| P4 | Put RR1 and RR3 to the interviewer, word for word | the register doubles as interview prep | `[grounded]` register | pending your approval |
| P5 | Don't describe any people leadership. The JD does not ask for it, and you have not managed anyone | see RR1 | `[grounded]` your intake | pending your approval |

## Evidence status

Verified: none yet. Every candidate claim above is your intake statement, not yet checked against an artifact.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Brindlemoor insurtech pet insurance" was refused, so no result came back. It would have checked that the employer exists and the posting is live (RR2) |
| 2. Role-family sweep | unavailable | The search "senior pricing analyst pet insurance UK salary" was refused. It would have set the pay band (RR3) and the scope norm (RR1) |
| 3. Hiring manager's public footprint | unavailable | The search "Odile Varga Director of Pricing Brindlemoor" was refused. It would have fed the scope read and which story to lead with for this reader |

## Upgrade menu

- A link to the live posting or a careers-page listing → RR2 closes or stays open. A clean read, with the other conditions met, would allow the status to move to `go`.
- The budgeted salary or a pay band → RR3 closes, set against a band.
- The answer on sign-off and team → RR1 closes.
- Sanitized GLM model documentation, or a motor price-test readout (confidential detail can stay at a high level, capped at `medium`) → R4 and R6 toward `high`.
- A sanitized SQL or Python sample → R3 toward `high`.
- A product-facing brief or readout → R7 and G1.
- Search: the three searches were refused in this session. Once search is allowed, the three L1 targets can run. A deeper pass (up to 5 more searches and 2 more fetches) is available on your say-so; I'm offering it once.

I can also write this up as a `tuesday-dossier.md` you can keep and update.

## Questions

R1 — Are you based in the UK, and do you have the right to work there without sponsorship? The role is fully remote (UK), so this decides whether the posting is open to you at all.

G1 — Have you ever put a recommendation to a product team and seen it used? What was it, what did you own, and what happened?

Research — Search was refused in this session. Do you want me to retry the L1 targets once it's allowed, or proceed on what's here?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.