**Yes, it's worth applying to, if two facts you haven't given me hold. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R7
- `important`: adjacent: R8 (BigQuery warehouse); unclear: R9 (ingestion from our app and CRM), R10 (data contracts analysts depend on)

R8 is a credible bridge with its limit named. R9 and R10 are not in your material, so they need your answer, not my guess.

**Opportunity ledger.** RR1 and RR2 read positive: the posting is live and matches the company's own site, and the pay sits inside the market band. RR3 and RR4 are unknowns: equity is unquantified and no hiring manager is named.

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 states, founded 2016, Denver, 264 employees, Series C ($52M, Feb 2026) | `[grounded]` company's own About page; not independently verified |
| Mandate | Ingestion from app and CRM, a dbt warehouse on BigQuery, and data contracts for reporting | `[grounded]` JD |
| Scope read | Ownership of one domain's pipelines; the posting names no direct reports | `[generic]` typical scope per the Datawright report; `[grounded]` the posting's silence on reports |
| Market calibration | Senior DE at Series B–D: base median $151,000, IQR $139,000–$163,500, typically 5–8 years' experience | `[generic]` Datawright 2026, from your recruiter. This is a pattern, not this employer's offer |
| Pay position | Posting midpoint $157,000, above the median and inside the IQR | `[grounded]` posting; `[generic]` band |
| Unknowns | Hiring manager, equity terms, whether your location meets the remote/Denver terms | — |
| Contradictions | None: the careers-page fetch matches your pasted text | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and work eligibility are not in the material | `[grounded]` JD | Q1 below |
| R2 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | No pay floor given | `[grounded]` JD | Q2 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated but not yet probed | `[grounded]` your statement | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated | `[grounded]` your statement | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake, stated | `[grounded]` your statement | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow orchestration, stated | `[grounded]` your statement | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up a Great Expectations suite; probe whether you owned it or used it | `[grounded]` your statement | probe at interview |
| R8 | BigQuery warehouse (named in role description) | important | adjacent | none | transferability | dbt and warehouse work carry over from Snowflake; BigQuery itself has no evidence. Limit: its cost and partitioning model is untested | `[inferred]` transfer from Snowflake work; `[generic]` that BigQuery's cost model matters for this kind of role | Q3 below |
| R9 | Ingestion from our app and CRM | important | unclear | low | discovery | Pipeline work is stated; app or CRM ingestion is not | `[grounded]` absence in your material | ingestion example |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Not in your material | `[grounded]` absence | contracts example |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| G1 | Location and pay (R1, R2) | hard_gate | Neither gate is settled from your material | Either one failing sets `no_go`, so they decide the status | Your answers (no artifact needed) | `[grounded]` posting terms |
| G2 | BigQuery (R8) | transferability | Snowflake and dbt experience, no BigQuery | An interviewer will probe the warehouse by name | Any BigQuery exposure, including a course or side project | `[inferred]` bridge from Snowflake work |
| G3 | CRM ingestion and data contracts (R9, R10) | discovery | Not in your material | Both are named responsibilities | A pipeline or contract example | `[grounded]` absence |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting live and consistent with the company's site | positive_signal | — | "Accepting applications" | Employer and posting are attributed to the company's own site; I found no independent source | `[grounded]` careers-page fetch; one search | Is this role open now, and who is on the hiring team? | noted |
| RR2 | Pay inside market band | positive_signal | — | "$148,000–$166,000" | The band sits in the upper-middle of the Series B–D range | `[grounded]` posting against `[generic]` band | Where in the range is this role set, and how is it benchmarked? | noted |
| RR3 | Equity unquantified | unknown | — | "plus equity" | Equity value could be small or large; the posting gives no grant size | `[inferred]` from the posting's silence | What grant size and vesting schedule apply to this role? | unresolved |
| RR4 | No hiring manager named | unknown | — | (none) | Scope read rests on the JD alone | `[inferred]` from the posting's silence | Who would I report to, and does this role have direct reports? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Apply once R1 and R2 are settled | Both gates are unknown from your side | `[grounded]` G1 | pending your approval |
| A2 | Describe BigQuery as adjacent, with the Snowflake work as the basis, and claim no BigQuery use | Keeps the claim within what you've done | `[inferred]` from R8 | pending your approval |

**Evidence status.** Verified: none yet. Everything above is your intake statement, which is a lead until probed.

Research tier: L1 — searches 1 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning tutoring Denver Series C", which returned the company's About page (matches your paste). Fetched pellucidlearning.com/careers/senior-data-engineer ("Senior Data Engineer — Pellucid Learning careers"): posting live, text matches your paste. Moved RR1 and the contradictions row. The employer is attributed to its own site only |
| 2. Role-family sweep | skipped | Your pasted Datawright report already gives the pay band and scope norm. No search would change them |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

**Upgrade menu**

- Your location and US work eligibility → R1 settles; the status likely becomes `go` or `no_go`.
- Your base-salary floor → R2 settles.
- Any BigQuery exposure, including a course or side project → R8 moves off `adjacent`.
- A CRM ingestion or data-contract example → R9 and R10 leave `unclear`.
- A deeper pass on Pellucid (funding and leadership changes, employee reports, sources beyond its own site; up to 5 more searches and 2 more fetches). Say the word and it runs.
- The hiring manager's name → L1 target 3 can run.

I can write this analysis to a `tuesday-dossier.md` file if you want to keep it.

Q1 (R1): Are you eligible to work in the US, and can you work fully remote or from Denver?
Q2 (R2): What is your base-salary floor?
Q3 (R8): Have you used BigQuery at all, even in a course or side project?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.