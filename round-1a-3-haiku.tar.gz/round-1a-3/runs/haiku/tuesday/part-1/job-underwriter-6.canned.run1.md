**Yes, apply, on two conditions:** `conditional_go`. Your tooling and reporting match the posting closely. The stretch is the forecast and billing data, and both are where the interview will probe.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, hybrid, two days a week in office), R2 (salary £61,500–£67,000)
- `must_have`: direct: R3a (4+ years in revenue or sales operations), R4 (HubSpot or Salesforce administration), R5 (strong SQL); adjacent: R3b (B2B software company), R7 (owning a forecast), R8 (working with finance on billing or revenue data); unclear: R6 (spreadsheet modelling)
- `important`: direct: R9 (CRM data), R10 (pipeline and renewal reporting)

R7 — your monthly pipeline review is a real input to a forecast, but you have never owned one; R8 — renewal data is revenue data, billing data you have not touched; R6 — daily Excel use, not yet shown as modelling; R3b — payments, not software.

**Opportunity ledger.** The posting is specific and the salary is stated, which is unusual. The open questions are who holds forecast authority alongside the CFO (RR1), who the role reports to (RR3), and whether the role is live on Quillfield's own careers page (RR4). Quillfield's public footprint is consistent with the posting.

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, hybrid two days a week), R2 (£61,500–£67,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the forecast scope holds up in interview, meaning you would own the build and the CFO would not (RR1, R7); (2) billing data can be learned on the job, which the interview has to confirm (R8); (3) you confirm the location and pay (R1, R2), since I was not given your constraints.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield, invoicing and payments software for UK builders' merchants; founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` quillfield.co.uk/about (search result) |
| Mandate | Own the CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Pay and pattern | £61,500–£67,000 plus share options; Bristol, hybrid, two office days a week | `[grounded]` posting |
| Market calibration | Ledgerline 2026 UK pay guide (n=438): median £64,200, interquartile range £57,800–£70,400. The posting's range sits inside that band, around the median | `[generic]` role-family sweep, one guide |
| Hiring manager | Tamsin Achebe, listed as Head of Revenue Operations at Quillfield, previously four years in sales operations at a payments company | `[grounded]` search result, profile snippet only |
| Unknowns | Forecast authority versus the CFO; billing data scope; reporting line; whether the role is live on the careers page | — |
| Contradictions | None found between the posting and the about page | `[grounded]` both read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two days in office | hard_gate | unclear | none | hard_gate | Your constraint was not given | `[grounded]` posting | Confirm you can meet it |
| R2 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | Your pay floor was not given; the band sits near market | `[grounded]` posting, `[generic]` band | State your floor |
| R3a | 4+ years in RevOps or sales ops | must_have | direct | medium | none | About 7 years in sales ops and RevOps, self-reported | `[grounded]` your intake | none |
| R3b | At a B2B software company | must_have | adjacent | medium | transferability | Payments, not software; the B2B selling and renewal work carries over | `[inferred]` from your employer type | Make the case with its limit named |
| R4 | HubSpot or Salesforce admin | must_have | direct | medium | none | Salesforce admin certified; certification is an artifact not yet inspected | `[grounded]` your intake | none |
| R5 | Strong SQL | must_have | direct | medium | none | SQL weekly | `[grounded]` your intake | none |
| R6 | Spreadsheet modelling | must_have | unclear | low | discovery | Daily Excel use does not establish modelling | `[inferred]` from your intake | Ask for a model you built |
| R7 | Owning a forecast | must_have | adjacent | medium | transferability | Monthly pipeline review with the sales director feeds the forecast; finance owned it | `[grounded]` your intake | Limit: you never owned one |
| R8 | Finance on billing or revenue data | must_have | adjacent | medium | transferability | Renewal dashboards are revenue data; billing data you have not worked on | `[grounded]` your intake | Limit: no billing data |
| R9 | CRM data ownership | important | direct | medium | none | Salesforce admin and rebuilt dashboards | `[grounded]` your intake | none |
| R10 | Pipeline and renewal reporting | important | direct | medium | none | You rebuilt both | `[grounded]` your intake | none |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R7, must_have) | transferability | Pipeline review and forecast inputs, but no forecast owned | The posting asks you to run the forecast with the CFO | Any forecast component you built, a pipeline-to-forecast handoff, a deal-stage weighting you set | A forecast template, a review deck | `[inferred]` bridge from the pipeline review |
| G2 | Billing data (R8, must_have) | transferability | Revenue and renewal data, not billing | The role owns billing data | Payment or invoice reconciliation at your payments company, any billing exception you resolved | A reconciliation example | `[inferred]` from employer type |
| G3 | Modelling (R6, must_have) | discovery | Daily Excel, modelling not shown | Core to the forecast work | Scenario models, sensitivity tables, a commission or pricing model | A workbook | `[grounded]` gap |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast ownership split with the CFO | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may build the forecast, with the CFO signing it off | `[inferred]` from the posting's wording | Who owns the forecast model, and who signs off the number? | unresolved |
| RR2 | Stated salary and share options | positive_signal | — | "£61,500–£67,000 plus share options" | Pay is set out up front, which suggests the role is budgeted | `[grounded]` posting | What is the budget for this hire? | noted |
| RR3 | Reporting line | unknown | — | Hiring manager's public title is Head of Revenue Operations | The role may report to Tamsin, the hiring manager | `[inferred]` from the public profile | Who does this role report to, and is that the hiring manager? | unresolved |
| RR4 | Role on the employer's own careers page | unknown | — | Posting on Tallyboard | The posting may be live on Quillfield's site, but I have not checked | `[generic]` pattern for job-board listings | Can you point me at the role on Quillfield's careers page? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Describe the pipeline review as an input to the forecast, not as running one. Draft: "Ran the monthly pipeline review with the sales director; forecast was owned by finance." | Stops the drift from "reviewed the pipeline" to "owned the forecast" (reframing audit: verb and kind) | `[grounded]` your intake, `[generic]` the audit | `resume_edits_pending_approval` |
| A1 | Do not claim billing data. Say what you have (renewals, revenue reporting) and what you have not | R8 is adjacent; claiming it is inflation | `[grounded]` R8 | pending your approval |
| A2 | Ask RR1 and RR3 in the first call | They decide whether the forecast gap is a dealbreaker | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Everything in your message is self-report, so it sits at `medium` at most.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers", which returned quillfield.co.uk/about (2018 Bristol founding, 96 employees, Series A). Careers page not fetched, so RR4 stays open. Employer footprint: consistent |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software Bristol", which returned the Ledgerline 2026 UK Revenue Operations Pay Guide. Market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned a profile snippet (Head of Revenue Operations; previously sales operations at a payments company). Snippet only; RR3 and the positioning line |

Upgrade menu:

- Your pay floor and your Bristol and office-day constraints → R1 and R2 close
- A forecast you built, even one part of one → R7 moves from `adjacent` toward `direct`
- A workbook you modelled in → R6 closes
- Confirmation on the careers page → RR4 closes
- A deeper research pass on Quillfield (funding, leadership changes, recent hires; up to 5 more searches and 2 more fetches). Say the word and it runs.

A `tuesday-dossier.md` written from this assessment would carry it into a later interview-prep run, and I can emit one whenever you want it.

Three questions, each tied to a row:

R1 — Is Bristol with two office days a week workable for you, yes or no?

R2 — Is £61,500 at or above your pay floor?

R7 — Have you ever produced any part of a forecast that finance or leadership used? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.