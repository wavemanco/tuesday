**Probably yes on fit, but hold off applying until the location is settled.** Status: `hold_pending_answers`. The posting contradicts itself on location, and location is a hard gate.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK)
- `must_have`: direct: R2, R3, R4, R5, R6, R7
- `important`: adjacent: R9 (Pet-insurance product knowledge); unclear: R10 (Recommendations to product)
- `preferred`: direct: R8 (Insurance experience)

R9 — a transferable case with its limit named; R10 — no evidence yet, one question open.

**Opportunity ledger.** The posting says fully remote (UK), but the careers page says Leeds four days a week (RR1, `severity: high`). Salary is not stated (RR2), and whether the role has direct reports is unknown (RR3). The employer footprint is thin beyond its careers page (RR4). The named hiring manager's public record matches the function (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** RR1 (`severity: high`)
- **What would change this:** the posting confirms fully remote (go, once R1 and RR1 close) or confirms Leeds four days a week (no_go, if that doesn't work for you). The awaited answers are RR1, RR3 and the candidate's own location constraint.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; pet-insurance product | `[grounded]` JD; careers page |
| Scope | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, recommend to underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing | `[grounded]` careers page |
| Working pattern | Conflicted: "Fully remote (UK)" in the JD; "Leeds office four days a week" on the careers page | `[grounded]` both sources |
| Compensation | Not stated in the posting. Survey band: median £58,400, IQR £52,100–£64,900 | `[generic]` Pricewell 2026 survey, snippet only, not fetched |
| Scope read | Senior analyst owning one product's pricing; no people scope stated | `[inferred]` from the JD's scope language |
| Unknowns | Direct reports; salary; remote or Leeds; how mature the pet product is | — |
| Contradictions | Location, as above | `[grounded]` |

**Evidence map.** Candidate claims are your prose background, which caps confidence at `medium` until you have an inspectable artifact.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | The JD says remote; the careers page says Leeds four days a week. Your own constraint isn't given | `[grounded]` JD vs careers page | Q1; RR1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years at a motor insurer, last two senior. Length of experience, not a gate | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM. It is motor, not pet | `[grounded]` your background | Artifact: sanitized model documentation |
| R5 | Design and read price tests | must_have | direct | medium | none | Ran 14 tests with underwriting; whether you designed them isn't stated. Expect a probe | `[grounded]` your background | Q3 |
| R6 | Build and monitor rating models | must_have | direct | medium | none | Maintained the young-driver model, which includes monitoring | `[grounded]` your background | none |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly review to the head of underwriting. No actuarial-lead presentations stated | `[grounded]` your background | none |
| R8 | Insurance experience | preferred | direct | medium | none | Five years in motor insurance | `[grounded]` your background | none |
| R9 | Pet-insurance product knowledge | important | adjacent | medium | transferability | Motor rating and testing carry over. Pet risk drivers, vet-cost inflation and claims patterns are not exercised. Your no-pet-experience statement is confirmed | `[inferred]` from the JD's product line and your statement | G1 |
| R10 | Recommendations to product, not only underwriting | important | unclear | low | discovery | JD asks for product recommendations; your background only shows underwriting | `[grounded]` JD | Q2 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance knowledge (R9, important) | transferability | Motor pricing, GLMs and price tests; no pet book | Likely objection in the first interview; a bridge with its limit stated narrows it | Any work on a non-motor book, e.g., home or travel rating, or claims-cost analysis that touched vet or medical costs | A sanitized analysis note from that work | `[inferred]` bridge from your motor work; `[generic]` that this is the likeliest objection |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location conflict | risk_signal | high | "Fully remote (UK)"; "Leeds office four days a week" | One source is out of date, or the role is hybrid with remote wording | `[inferred]` from the two sources | Is this role fully remote, as the advert says, or Leeds four days a week, as your careers page says? | unresolved |
| RR2 | Salary not stated | unknown | — | (no pay in the posting) | Budget may sit below or around the survey band, or pay is simply not published | `[generic]` survey band; `[inferred]` from the posting's silence | What base salary is budgeted for this post? | unresolved |
| RR3 | Direct reports unknown | unknown | — | "Own pricing analytics" (no people scope stated) | The role may carry no reports, or may carry some you haven't been told about | `[inferred]` from the JD's silence on people scope | Does this role have direct reports, and what does "own" cover in year one? | unresolved |
| RR4 | Employer footprint thin | risk_signal | medium | (the careers page is the only company source found) | The company may be too new or small for a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | How large is the pricing team, and who would I work with day to day? | unresolved |
| RR5 | Named hiring manager's public record matches the function | positive_signal | — | Forum talk "Small Books, Loud Errors" (2025), on monitoring rating models in small books | Her background suggests the role is run by someone who knows model monitoring | `[grounded]` public talk title; prior role from search snippet | What would you want the first quarterly pricing review to show? | noted |

**Application plan** (every row proposed, pending your approval)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter Q1 and RR1 before investing in an application | R1 is unclear | `[grounded]` RR1 | pending your approval |
| A2 | Lead with GLM build and maintenance and the 14 price tests, and name the motor limit | R4, R5, R9 | `[grounded]` your background; `[inferred]` on the framing | pending your approval |
| A3 | Ask the recruiter RR2 and RR3 in the first call | Salary and reports are unknown | `[grounded]` RR2, RR3 | pending your approval |

**Evidence status.** Verified: none yet. Your background is intake prose, so every claim sits at `medium` until something inspectable backs it. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor careers Senior Pricing Analyst" and "Brindlemoor insurtech pet insurance" (no results for the second). Fetched brindlemoor.co.uk/careers/senior-pricing-analyst. Moved RR1 and the live-posting check; no company footprint beyond this page (RR4) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary GLM", which returned the Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey (pricewell.example/2026-uk-pricing-analytics-pay-survey), snippet only, not fetched. Moved the market calibration in role reality (`[generic]`) and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned her public profile (linkedin.example/in/odile-varga) and the 2025 forum talk. Moved RR5 and the positioning in A2 |

Deep research (L2) would add company diligence: funding, leadership churn, and recent news. That is up to 5 more searches and 2 more fetches; say the word and it runs.

If you want, I can also emit `tuesday-dossier.md` for this role, which holds the evidence map and register for later use.

**Upgrade menu**

- A recruiter answer on location → R1 and RR1 close; the decision moves to `go` or `no_go`.
- A budgeted salary → RR2 closes, set against the survey band.
- A direct-reports answer → RR3 closes; decides whether "never managed anyone" becomes a gap in the application.
- A sanitized GLM model document → R4 rises to `high`.
- A pet-adjacent analysis note → R9's bridge narrows, and G1 closes.
- The L2 deep-research pass above.

**Questions**

Q1 (R1): Is Leeds four days a week workable for you, or is fully remote a must?

Q2 (R10): Have you ever made recommendations that went to a product team rather than underwriting? What did you own?

Q3 (R5): For the 14 price tests, did you design them, or run tests someone else designed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.