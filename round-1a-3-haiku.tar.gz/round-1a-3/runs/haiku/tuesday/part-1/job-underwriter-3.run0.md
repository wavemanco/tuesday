**No. Both of your hard constraints fail on the posting's own terms: base pay and location. Status: `no_go`.**

I couldn't run research. The three web searches I tried were refused as not permitted in this session, so I did not check Novaline or the market band, and I did not fill either from memory.

**Fit ledger.**
- `hard_gate`: hard_gate_fail: R1 (base pay $70–85k), R2 (on-site Austin, five days)
- `must_have`: direct: R3 (8+ years growth leadership), R4 (paid acquisition), R5 (lifecycle/CRM), R6 (revenue growth end to end) · unclear: R7 (SEO/content), R8 (thrive on ambiguity)
- `important`: unclear: R9 (brand, PR, partnerships), R10 (sales ops)

R1 and R2 are both hard gates, and both fail on stated terms. R3–R6 are the core of your profile, direct at `medium` and unverified. R7–R10 are not in your profile and are not what decides this.

- **Hard gates:** failed: R1 (base pay against your $150k floor), R2 (on-site Austin against remote-only); met: none. Candidate constraints given, both checked.
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **Opportunity ledger.** Before fit enters, the posting is weak on its own terms: a Head of title requiring 8+ years, owning six functions with a team of one, at $70–85k (`[grounded]` JD). It adds an always-on expectation (RR3), no defined success metrics (RR5), unstated decision rights (RR6), and an employer I could not verify (RR7). Your sense that something is off is picking up that combination (`[inferred]` from RR1–RR7).
- **What would change this:** both gates would have to move. Base would need to reach $150k or more, and remote work from Portland would need to be allowed. The posting says "no exceptions" on Austin, so the second is ruled out as written.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` JD claim, unverified |
| Mandate | All revenue growth across six functions, team of one to start, reports to CEO with a dotted line to the board | `[grounded]` JD |
| Pay | $70–85k base plus equity | `[grounded]` JD |
| Market calibration | Not established. Research was refused, so there is no band to compare against | — |
| Working pattern | On-site Austin five days a week, evenings and weekends "when it matters" | `[grounded]` JD |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay at or above $150k (your floor) | hard_gate | hard_gate_fail | high | hard_gate | Top of posted base is $65k under your floor; equity is not base | `[grounded]` JD; your stated floor | none; surfaced in snapshot |
| R2 | On-site Austin, five days (your remote-only limit) | hard_gate | hard_gate_fail | high | hard_gate | "No exceptions"; you live in Portland and won't relocate | `[grounded]` JD; your stated constraint | none; only employer terms change it, and the posting rules that out |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, growth lead then Head of Growth; your statement, no artifact | `[grounded]` your statement | none |
| R4 | Paid acquisition | must_have | direct | medium | none | Owned paid; no artifact | `[grounded]` your statement | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | Owned lifecycle; Braze named | `[grounded]` your statement | none |
| R6 | Revenue growth end to end | must_have | direct | medium | none | $8M to $40M ARR over three years with a budget you controlled | `[grounded]` your statement | none |
| R7 | SEO/content | must_have | unclear | none | discovery | Absent from your profile; neither shown nor ruled out | `[grounded]` absence | ask only if the decision reopens |
| R8 | Thrives on ambiguity; metrics evolve | must_have | unclear | none | discovery | Not evidenced either way | `[grounded]` absence | ask only if the decision reopens |
| R9 | Brand, PR, partnerships | important | unclear | none | discovery | Absent from your profile | `[grounded]` absence | ask only if the decision reopens |
| R10 | Sales ops | important | unclear | none | discovery | Absent from your profile | `[grounded]` absence | ask only if the decision reopens |

Closing R7–R10 would change your fit reading, not the decision, because R1 and R2 fail on their own.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base below your floor | red_flag | high | "$70–85k base plus meaningful equity upside" | Base sits $65k+ under your $150k floor (R1) | `[grounded]` JD vs your floor | Is $150k base within this role's budget? If not, what is the top of the band? | confirmed |
| RR2 | On-site, no exceptions | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | Excludes remote-only candidates outside Austin (R2) | `[grounded]` JD vs your constraint | Is any part of this role remote, and would "no exceptions" hold for a strong candidate outside Austin? | confirmed |
| RR3 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Hours beyond the posted schedule are expected as routine | `[inferred]` from the posting's wording | What does a typical week look like here, including evenings and weekends? | unresolved |
| RR4 | Six functions, one person, senior title, junior-range pay | risk_signal | medium | "team of one to start"; "8+ years required"; "$70–85k" | Several full roles folded into one title, priced below it | `[generic]` pattern for bundled roles, applied to the posting's own numbers | Which of the six areas does the first hire own, and what budget and team come with it? | unresolved |
| RR5 | Success metrics undefined | risk_signal | medium | "success metrics will evolve as we learn" | Accountability without a stated definition of success | `[inferred]` from the posting | What two or three metrics will this role be judged on in year one, and who sets them? | unresolved |
| RR6 | Decision rights unstated | unknown | — | "Report to the CEO with a dotted line to the board" | Budget and decision rights are not stated | `[inferred]` from the reporting line's silence on authority | Which spend decisions does this role make alone, and what budget is committed? | unresolved |
| RR7 | Employer unverified | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | Company claims are unchecked. Research was refused, so this is unverified, not found missing | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on Novaline's own careers page, and who would I be interviewing with? | unresolved |

**Application plan:** none. Nothing here warrants applying at these terms.

**Evidence status**

Verified: R1 and R2 (your own stated constraints, `high`). Unverified, `medium`: R3–R6 (your experience, no artifacts yet).

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | All three search calls were refused. Would have checked that Novaline exists as described and that the posting is live (RR7) |
| 2. Role-family sweep | unavailable | Same refusal. Would have set the market band for this title and seniority (RR4) |
| 3. Hiring manager's public footprint | n/a | No name was given |

If you want this on file, I can write `tuesday-dossier.md` with this assessment, so it's there if the role comes back with different terms.

**Upgrade menu**
- Search access, if you grant it: confirms whether Novaline exists as described and whether this posting is live on its own careers page (RR7), and sets a real market band for the title (RR4). Neither would change the `no_go`, which rests on the posting's own terms.

No questions: nothing you could answer would change the call.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.