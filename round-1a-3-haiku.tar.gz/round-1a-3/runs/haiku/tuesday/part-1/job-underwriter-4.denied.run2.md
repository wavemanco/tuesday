**Yes on fit. Hold for one answer before you apply.** Every must-have matches your background, but the posting's UK-remote requirement is unsettled, and web checks on Brindlemoor were refused, so the employer is unverified · `hold_pending_answers`

**Fit ledger**

- `hard_gate`: unclear: R1 (Fully remote, UK-based)
- `must_have`: direct: R2 (4+ years pricing or actuarial analytics), R3 (strong SQL and Python), R4 (GLM experience), R5 (presenting to underwriting or actuarial leads)
- `important`: direct: R6 (design and read price tests); adjacent: R7 (pet-insurance product)
- `preferred`: direct: R8 (insurance experience)

R4 — direct on the GLM work, `medium` until probed; R7 — the real gap, motor pricing transfers but pet product knowledge does not; R1 — the one answer that could change the status.

**Opportunity ledger.** The posting is concrete on scope and deliverables (RR5). It is silent on pay, people management and how much of the work is pet-specific (RR1, RR2, RR3). The employer and live posting are unchecked (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK-based); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** If R1 comes back as outside the UK or without right to work, the status becomes `no_go`, since that gate has no path. Go requires three things: R1 confirmed, the live posting found on Brindlemoor's own careers site (RR4), and the pet gap named as a transfer limit rather than claimed (R7).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech, pet-insurance product | `[grounded]` the JD header you pasted |
| Mandate | Own pricing analytics; build and monitor rating models; design and read price tests; turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message |
| Scope read | A senior analytics role owning models, tests and recommendations; no team or direct reports are mentioned | `[inferred]` from the JD's responsibilities |
| Stage | Evaluating (assumed) | — |
| Market calibration | Not established: the role-family search was refused, so there is no pay or scope band | — |
| Unknowns | Pay, people management, pet-specific scope, team size | — |
| Contradictions | None visible in the text you pasted | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based | hard_gate | unclear | none | hard_gate | No location or right-to-work statement from you, so the gate is not established either way | `[grounded]` JD text | Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years pricing analytics at a UK motor insurer, last 2 senior. Stated, not yet probed, so `medium` is the ceiling | `[grounded]` your statement | Expect a probe on dates and scope |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no artifact | `[grounded]` your statement | Probe-ready example |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. The method carries over; the domain does not (see R7) | `[grounded]` your statement | Be ready to explain the model's structure |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review presented to the head of underwriting | `[grounded]` your statement | none |
| R6 | Design and read price tests | important | direct | medium | none | 14 price tests run last year with the underwriting team | `[grounded]` your statement | Have one test's design and read-out ready |
| R7 | Pet-insurance product knowledge | important | adjacent | medium | transferability | No pet work stated. Motor pricing and test design are the bridge; the limit is that no pet data, claims or product decisions were touched. Pet risk drivers differing from motor is a pattern | `[inferred]` from your motor work; `[generic]` on pet risk drivers | G1 |
| R8 | Insurance experience | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your statement | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product knowledge (R7, important) | transferability | Motor pricing, GLM and test work; no pet product or claims work stated | Likely the first objection, since the product is pet-specific | Any non-motor line; a model you rebuilt where the risk drivers were new; any pricing where you were the first to define the risk factors | A short bridge note of what carries over and what doesn't | `[inferred]` bridge from your motor work; `[generic]` that pet risk drivers differ from motor |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Line management may be expected | unknown | — | "Senior Pricing Analyst" (no people duties in the JD) | The role may carry people duties the JD leaves out | `[inferred]` from title against JD silence | Does this role line-manage anyone, now or within the first year? | unresolved |
| RR2 | Pet-specific scope from the start | unknown | — | "our pet-insurance product" | Early work may be on pet data with little motor-style history to lean on | `[inferred]` from the product named against your motor-only history | What pet data and claims history do the rating models use, and which model would I own first? | unresolved |
| RR3 | Pay not stated | unknown | — | No pay in the pasted posting | The band is unknown until the market search runs | `[inferred]` from posting silence | What base salary is budgeted for this role? | unresolved |
| RR4 | Employer and live posting unverified | unknown | — | "Brindlemoor (insurtech)" | Not an L1 failure: the search was refused, so nothing returned either way. Pattern for companies of this size, not a claim about this one, is a thin public footprint | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on Brindlemoor's own careers site, and who would I be interviewing with? | unresolved |
| RR5 | Concrete scope and outcomes | positive_signal | — | "design and read price tests"; "build and monitor rating models" | The deliverables are specific and measurable through the models and tests | `[grounded]` JD responsibilities | Which measures would you use to judge the first six months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Name the pet gap yourself: "I haven't priced pet insurance. The transfer is the GLM and test method; the risk drivers are new to me." | Stating the limit is the strongest position here | `[grounded]` R7; `[generic]` pet risk drivers | pending your approval |
| A2 | Lead with R4 (young-driver GLM) and R5 (quarterly review to head of underwriting) | They match "build and monitor rating models" and "present to underwriting leads" | `[grounded]` your statements | pending your approval |
| A3 | On line management, say you haven't managed people, and give the closest true example you have (you supply it) | RR1 is open | `[grounded]` your statement | pending your approval |
| A4 | Have one price test ready: design, control group, read-out, what changed | R6 stays `medium` until probed; test design is usually probed | `[generic]` interviews probe test design | pending your approval |

## Evidence status

Verified: none yet. Your statements are CV-equivalent until a probe confirms them.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused ("Brindlemoor insurtech pet insurance"; "Brindlemoor careers Senior Pricing Analyst"). Would have checked that the employer exists as described and the posting is live. Moves RR4 and the contradictions row |
| 2. Role-family sweep | unavailable | One search refused ("senior pricing analyst pet insurance UK salary"). Would have set the market calibration and the pay band (RR3) |
| 3. Hiring manager's public footprint | unavailable | One search refused ("Odile Varga Director of Pricing Brindlemoor"). Would have informed positioning for this reader |

## Upgrade menu

- Your location and right to work → R1 closes. A failure here makes it `no_go`.
- The live posting link or Brindlemoor's careers page → RR4 closes.
- Your base-salary floor, if you have one → the checks against your constraints run.
- The budgeted salary → RR3 closes, and the figure is set against the market band.
- One redacted price-test write-up or the GLM model documentation → R4 and R6 move from `medium` toward `high`.
- Any non-motor or pet pricing work, even a side project → R7 moves from transferability.
- Allowing web search → the three checks can run. The L1 budget has 1 search and 2 fetches left.

If you want this kept for the next steps, I can write it to a `tuesday-dossier.md`.

1. **R1:** Are you based in the UK, with the right to work here without sponsorship?
2. **R7:** Have you priced, reviewed or rebuilt any non-motor product, pet included, even as a side project? What did you own?
3. **RR1:** Have you ever set direction for, or reviewed, another analyst's model or test plan, even informally?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.