**Not yet. Hold on one term, the location, which the posting states two different ways. On the substance you look like a strong fit.** Status: `hold_pending_answers`.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Location: fully remote UK, or Leeds four days a week)
- `must_have`: direct: R2 (4+ years pricing analytics), R3 (SQL and Python), R4 (GLM experience), R5 (presenting to underwriting leads)
- `important`: direct: R6 (designing and reading price tests); adjacent: R7 (Pet-insurance product knowledge)
- `preferred`: direct: R8 (Insurance experience)

R2, R3, R4 and R5 are your strongest rows. R7 carries over from motor, but the pet-specific risk is not something you have exercised. R1 is the only open gate, and nothing else in the map can settle it.

**Opportunity ledger.** The role is live and matches its own careers page on title, product and reporting line (RR4, a positive signal). The posting contradicts itself on location (RR1). Pay and line management are not in the material you gave me (RR2, RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Location: fully remote UK, or Leeds four days a week); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** a written answer on which location term is right. If the role is Leeds four days a week and you need remote, R1 becomes a failed gate and this is `no_go`. If it is remote as posted, this moves to `go`, subject to pay and line management.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech, pet-insurance product | `[grounded]` JD and careers page |
| Working pattern | Contradictory: JD says fully remote (UK); careers page says Leeds office four days a week | `[grounded]` both sources |
| Reporting line | Reports to the Director of Pricing | `[grounded]` careers page |
| Scope | Owns pricing analytics for one product: builds and monitors rating models, designs and reads price tests | `[inferred]` from the JD's responsibilities |
| Market calibration | Pricewell 2026 survey: senior pricing analyst, UK insurers and insurtechs, median base £58,400, interquartile range £52,100–£64,900. Read from a search snippet, not the full report. No salary in the material you gave me, so this is what to expect, not this employer's offer | `[generic]` role-family sweep |
| Unknowns | Location term, pay, whether the role line-manages | — |
| Contradictions | Location (above) | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location: fully remote UK (JD) vs Leeds four days a week (careers page) | hard_gate | unclear | none | hard_gate | Sources conflict and no candidate constraint was stated, so nothing settles it | `[grounded]` both sources | Question 1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, last two as senior analyst; self-reported, no artifact yet | `[grounded]` your account | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Used daily; self-reported | `[grounded]` your account | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM. The book is motor, the technique is the same | `[grounded]` your account | none |
| R5 | Experience presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your account | none |
| R6 | Designing and reading price tests | important | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your account | none |
| R7 | Pet-insurance product knowledge (implied by "our pet-insurance product") | important | adjacent | medium | transferability | Motor pricing carries over. Pet risk drivers and claims behaviour are not exercised | `[inferred]` from the JD's product line against your motor work | Question 2 below |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | UK motor insurer, five years | `[grounded]` your account | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance knowledge (R7, important) | transferability | Motor pricing only; no pet work in the material | Interviewers will probe whether motor carries over to pet | Any pet, companion-animal or non-motor pricing or claims work, even a small internal study | A short write-up of an analysis you ran on any non-motor book | `[inferred]` bridge from your motor work; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location term contradicts itself | risk_signal | medium | "Fully remote (UK)" (JD); "Leeds office four days a week" (careers page) | One of the two posted terms is stale or wrong. Medium, not high: the posting itself is live and consistent on everything else | `[inferred]` from the two sources disagreeing | The posting says fully remote and the careers page says Leeds four days a week. Which is the term for this role? | unresolved |
| RR2 | Pay not in the material | unknown | — | (none in the material given) | The band above is what to expect. The salary is unknown until stated | `[generic]` band; `[grounded]` absence | What is the budgeted salary for this post? | unresolved |
| RR3 | Line management not stated | unknown | — | JD silent on managing people | "Senior" could carry people leadership. Your record shows none, so this matters | `[inferred]` from the JD's silence | Does this role line-manage anyone, now or within the first year? | unresolved |
| RR4 | Live posting matches its own site | positive_signal | — | "Accepting applications. Senior Pricing Analyst, Leeds office four days a week." | Employer and posting are established from attributable sources; the standing employer-not-established entry does not fire | `[grounded]` careers page | Who would I be interviewing with, and is the Leeds term the one to plan around? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter which location term is right, and whether a remote arrangement is possible | RR1, R1 | `[grounded]` RR1 | for you to do |
| A2 | Ask for the budgeted salary before investing in the loop | RR2 | `[generic]` band | for you to do |
| P1 | Lead with the GLM build-and-maintain work and the price-test readouts, which map to the rating-model and price-test duties | R4, R6 | `[grounded]` your account | pending your approval |
| P2 | Do not claim any small-book or pet experience to Odile Varga. Her public work covers monitoring rating models in small books, and your work is a large motor book | Positioning for this reader | `[grounded]` her public profile | pending your approval |

**Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance" (no results) and "Brindlemoor careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved: employer verified live; location contradiction (RR1) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst insurance UK salary GLM pricing", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example). Moved: market calibration band, read from the snippet |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned her public profile (linkedin.example/in/odile-varga) and a 2025 conference talk listing. Moved: positioning (P1, P2). Read from snippets only |

Her public profile lists six years as head of pricing analytics at Calloway Re before Brindlemoor. The talk listing is titled "Small Books, Loud Errors", on monitoring rating models in small books. I have not read either in full.

## Evidence status

Verified: none yet. Your claims are self-reported in prose, so they are leads until you point to something inspectable.

**Dossier and upgrade menu**

If you want it, I can write this up as a `tuesday-dossier.md` file.

- A written answer on the location term, which closes R1 and RR1 and decides between `go`, `no_go` and a conditional.
- The budgeted salary, which closes RR2 and sets it against the band.
- Line-management answer, which closes RR3.
- Any pet or non-motor pricing work, or a write-up of one, which moves R7 from `medium` toward `high`.
- Your pay floor and any location or contract constraints, so R1 can be checked against them.
- A deeper research pass (up to 5 more searches and 2 more fetches) on Brindlemoor's funding, leadership and hiring history. Say the word and it runs.

**Questions**

1. Is fully remote a must for you, or could you work from Leeds four days a week? (R1)
2. Have you done any pet or non-motor pricing work, even a small internal study? (R7)
3. What is your pay floor for this role? (RR2)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.