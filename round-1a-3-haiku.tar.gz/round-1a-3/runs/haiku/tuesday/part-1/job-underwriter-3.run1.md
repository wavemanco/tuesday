**No, not as posted: R1 and R2, both hard gates, fail · `no_go`.**

**Fit ledger.**
- `hard_gate`: failed: R1 (on-site in Austin five days a week), R2 (base $70–85k)
- `must_have`: direct: R3 (8+ years growth leadership), R4 (paid acquisition), R5 (lifecycle/CRM) · unclear: R6 (sales ops), R7 (SEO/content), R8 (brand and PR), R9 (partnerships)
- `important`: unclear: R10 (thriving on ambiguity)

Your background covers R3–R5 well. The unclear rows are channels your history doesn't mention, so they're open, not failed. None of this changes the status, because the two gates decide it.

**Opportunity ledger.** The mandate is one person owning seven channels with no team (RR1), no defined success metrics (RR2), and always-on language (RR3). What feels off is real: a Head of Growth title, 8+ years required, and one person's scope, at a base $65k under your floor even at the top of the range. The one positive is the stated profitability (RR4, unverified).

- **Hard gates:** failed: R1 (on-site Austin office five days a week, "no exceptions"), R2 (base $70–85k against your $150k floor)
- **Severe red flags:** none found
- **What would change this:** only the employer changing both terms in writing, on-site and base. Nothing else moves a gate, so I'd not spend effort on a workaround.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting; profitability unverified |
| Mandate | All revenue growth end to end across seven channels | `[grounded]` posting |
| Team | "A team of one to start" | `[grounded]` posting |
| Reporting | CEO, dotted line to the board | `[grounded]` posting |
| Working pattern | On-site Austin, five days a week, no exceptions | `[grounded]` posting |
| Compensation | $70–85k base plus equity; equity terms not stated | `[grounded]` posting |
| Scope read | Seven channels for one person is a broad remit against a team-of-one start | `[inferred]` from the channel count against the team size |
| Market calibration | Not established. The role-family search was refused, so I'm not giving a market figure from memory | — |
| Unknowns | Budget, success metrics, equity terms, whether customers are merchants or consumers (your background is B2C subscription) | — |
| Contradictions | Title and seniority ask for a leader; scope, pay and location describe an individual contributor | `[inferred]` from the posting's own terms |

**Evidence map** (your prose background is self-report, so confidence caps at `medium` until probed)

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site Austin, five days a week | hard_gate | hard_gate_fail | high | hard_gate | Your stated constraint is remote-only, confirmed. The posting rules it out | `[grounded]` posting and your statement | none; only the employer changing terms resolves it |
| R2 | Base at least $150k | hard_gate | hard_gate_fail | high | hard_gate | Your floor is confirmed. The posted range tops out at $85k | `[grounded]` posting and your statement | none; same as R1 |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, Growth Lead then Head of Growth | `[grounded]` your background | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You owned paid | `[grounded]` your background | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You owned lifecycle; Braze | `[grounded]` your background | none |
| R6 | Sales ops | must_have | unclear | low | discovery | Not in your background | `[grounded]` silence | none; would not change status |
| R7 | SEO/content | must_have | unclear | low | discovery | Not in your background | `[grounded]` silence | none; would not change status |
| R8 | Brand and PR | must_have | unclear | low | discovery | Not in your background | `[grounded]` silence | none; would not change status |
| R9 | Partnerships | must_have | unclear | low | discovery | Not in your background | `[grounded]` silence | none; would not change status |
| R10 | Thriving on ambiguity | important | unclear | low | discovery | Not stated in your background | `[grounded]` silence | none; would not change status |

**Gap recovery queue.** R6–R10 are open, not failed. I'm asking nothing about them: the gates already set the status, and these rows would matter only if the gates moved.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | One person owns all revenue channels | risk_signal | medium | "team of one to start" | Accountable for every channel without team or budget | `[inferred]` from the scope language against its silence on budget | What budget and headcount are committed to this role in year one, and which channels does it own outright? | unresolved |
| RR2 | Success metrics undefined | risk_signal | medium | "success metrics will evolve as we learn" | Accountability may be set without a fixed definition of success | `[inferred]` from the posting's own language | What three numbers define success at the six-month review, and who sets them? | unresolved |
| RR3 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Overtime may be routine rather than occasional | `[inferred]` from the posting's language | How often in a typical quarter does the team work evenings or weekends, and is that reflected in the pay? | unresolved |
| RR4 | Profitability and stage | positive_signal | — | "profitable since day one" | Stable funding, if the claim holds | `[grounded]` posting; unverified | What are the most recent revenue and cash-position figures you can share? | noted |
| RR5 | Employer not established | risk_signal | medium | Novaline, Series A, e-commerce enablement | Employer may be too new or small for a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Which page on your own careers site lists this role, and who would I interview with? | unresolved; research refused, so unchecked, not disproven |
| RR6 | Pay may sit below market for this mandate | risk_signal | medium | "$70–85k base" | Base may be low for a Head of Growth with this scope | `[generic]` role-family pattern; no market figure established | What is the basis for the $70–85k range, and what does the equity package look like? | unresolved |

**Application plan.** None. Status is `no_go`, so I'd not apply as posted.

**Evidence status**

Verified: R1 and R2 (your own constraints, stated specifically). R3–R5 are your stated background, not yet probed.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Novaline ("e-commerce enablement startup Series A" and "careers Head of Growth Austin") were refused permission. Would have moved RR5 (employer existence, whether the posting is live). I didn't retry. |
| 2. Role-family sweep | unavailable | One search for Head of Growth base pay was refused permission. Would have moved the market calibration and RR6. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Neither refused search would change the status, because the two gates decide it.

I can write this up as a `tuesday-dossier.md` you can keep.

**Upgrade menu**
- A written change to both the on-site requirement and the base → R1 and R2 re-assessed; the status could move from `no_go` only then.
- Research permission, if you want it (up to 5 searches and 2 fetches on Novaline and on role-family pay) → would verify RR5 and calibrate RR6. Neither changes `no_go`.
- Budget and success metrics in writing → RR1 and RR2 close.

No questions this turn: the decision is already stable.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.