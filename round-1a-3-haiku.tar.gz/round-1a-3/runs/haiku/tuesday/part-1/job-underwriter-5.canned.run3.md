**Worth applying, once you've checked two things about your own situation.** Status: `conditional_go`.

**Fit ledger.**
- `hard_gate`: unclear: R1 (remote-US or Denver location), R2 (pay range)
- `must_have`: direct: R3 (5+ years), R4 (SQL and Python), R5 (dbt and a cloud warehouse), R6 (Airflow orchestration), R7 (data-quality testing)
- `important`: adjacent: R8 (BigQuery); unclear: R9 (app and CRM ingestion, data contracts)

R3, R4, R5, R6, R7: the stack and years you already run daily, self-reported at medium; R8: BigQuery is named in the description and Snowflake carries over, but you haven't used it; R9: ingestion and data contracts aren't on your CV.

**Opportunity ledger.** The posting is sound and checkable: the employer is established on its own domain and the role is live there (RR1, positive), and the posted base sits inside the market band (RR3, positive). Still open: the hiring manager and team are unnamed (RR2), equity is unquantified (RR4), and on-call expectations are unstated (RR5).

- **Hard gates:** none failed (R1 `unclear`, R2 `unclear`); unconfirmed: R1 (remote-US or Denver location), R2 (pay range); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1: you can work from remote-US or Denver; (2) R2: a $148,000 base works for you; (3) R9: you have, or can point to, ingestion or contract work.
- **What would change this:** if either gate fails for you, the status becomes `no_go`, with that gate as the reason, whatever the fit. If R9 comes back empty, the fit is weaker on a central duty.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` about page (search snippet of pellucidlearning.com/about; wording matches your paste) |
| Mandate | Build and run ingestion from the app and CRM, a dbt warehouse on BigQuery, and analyst data contracts | `[grounded]` JD and careers page (fetched, identical) |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | One domain (reporting) from ingestion through analyst contracts; no direct reports stated | `[inferred]` from the posting's scope; `[generic]` that this matches typical senior scope |
| Market calibration | Base median $151,000, IQR $139,000–$163,500 for Senior Data Engineers at Series B–D companies. The posted $148,000–$166,000 sits inside the IQR, midpoint $157,000 | `[generic]` Datawright 2026 report (n=2,310; read from search snippet, not the full report); `[grounded]` posted range. Band is what to expect, never this employer's offer |
| Unknowns | Hiring manager, team size, whether you'd be the only data engineer, on-call, equity value, start date | — |
| Contradictions | None between the JD and the careers page. The requirement says "a cloud warehouse" while the description names BigQuery; read as one requirement | `[inferred]` |

Stage assumed: evaluating.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location isn't in the material, so the gate isn't settled | `[grounded]` JD; no candidate statement | Q1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor isn't in the material | `[grounded]` JD; no candidate statement | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated at intake (self-report, not probed) | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Used daily; self-reported | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake | `[grounded]` your background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, self-reported | `[grounded]` your background | none |
| R7 | Data-quality testing | must_have | direct | medium | none | You set up the Great Expectations suite; extent not yet probed | `[grounded]` your background | none |
| R8 | Dbt-modelled warehouse in BigQuery (description) | important | adjacent | medium | transferability | Snowflake dbt work carries over; BigQuery itself is unused, the limit to name | `[grounded]` your statement; `[generic]` that dbt modelling ports across warehouses | G1 |
| R9 | Ingestion from app and CRM; data contracts analysts depend on | important | unclear | low | discovery | Not in your background; may exist under other work | `[grounded]` absence from your background | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery warehouse (R8, important) | transferability | Snowflake dbt work, nothing on BigQuery | It's named in the description, so it will come up | Snowflake model structure and testing that carried over; any Google Cloud work at all | A small BigQuery project, sandbox build, or course certificate | `[inferred]` bridge from your Snowflake work; `[generic]` that BigQuery specifics are the likeliest probe |
| G2 | Ingestion and data contracts (R9, important) | discovery | Airflow and dbt work, but no app or CRM ingestion or analyst contracts named | Ingestion and contracts are the posting's first two duties | Pipelines pulling app events or CRM records into a warehouse; schema agreements with analysts; breaking-change handling | A pipeline README, a contract doc, or a dashboard analysts used | `[grounded]` absence from background; `[inferred]` that these are central duties |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer established; role live | positive_signal | — | "Accepting applications" | The employer is attributable to its own domain, and the posting is live there | `[grounded]` careers page fetched; `[inferred]` stability from funding and headcount | Is this role open now, and is it the one the team is actively hiring for? | noted |
| RR2 | Hiring manager and team unnamed | unknown | — | Posting names no hiring manager | Team size and whether you'd be the only data engineer are unknown | `[generic]` postings often omit this | Who would I report to, and how many data engineers would I work alongside? | unresolved |
| RR3 | Base pay disclosed, inside market band | positive_signal | — | "Salary $148,000–$166,000" | Midpoint $157,000 sits above the $151,000 median and inside the IQR | `[generic]` band; `[grounded]` posted range | What's the top of the range for someone at my level? | noted |
| RR4 | Equity unquantified | unknown | — | "plus equity" | The equity value could move total pay materially | `[inferred]` from the posting's silence on grant size | What's the equity grant range, and what's the vesting schedule? | unresolved |
| RR5 | On-call and pipeline ownership unstated | unknown | — | "Build and run the pipelines" | "Run" may imply on-call ownership of failing pipelines | `[inferred]` from the word "run" against the silence on on-call | What's the on-call and pipeline-failure expectation for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check your location and pay floor against R1 and R2 before applying | These are the gates that decide go or no-go | `[grounded]` gate rows | for you to decide |
| A2 | Lead the resume with dbt on Snowflake, Airflow, and the Great Expectations suite; name Snowflake as the warehouse. Don't imply BigQuery experience | R5, R6, R7 are direct; R8 is adjacent, and the limit has to stay visible | `[grounded]` rows R5–R8 | pending your approval |
| A3 | Before applying, write down any ingestion or contract work you've done (R9), or decide it's a gap to name | Most likely interview probe | `[grounded]` R9 | for you to decide |
| A4 | Ask about the hiring manager, on-call, and equity at the recruiter screen | RR2, RR4, RR5 | `[grounded]` register | pending your approval |

Every row above is a proposal; nothing goes into a resume or outreach without your approval.

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver" (no results: employer not established from that query). Fetched pellucidlearning.com/careers/senior-data-engineer: live, text identical to your paste. The about page (pellucidlearning.com/about) came up as a snippet in the second search, wording matching your paste; not fetched. Moved: employer check (RR1); no contradictions |
| 2. Role-family sweep | yes | Searched "Senior Data Engineer salary 2026 Series B to D company base pay median", which returned the Datawright 2026 Data Engineering Pay Report (datawright.example/2026-data-engineering-pay-report), read from its snippet only; figures match your recruiter's copy. Moved: market calibration `[generic]` and RR3 |
| 3. Hiring manager's public footprint | n/a | No name given, so there was no query to form. Posting names no hiring manager |

Dossier offer: I can write this analysis to `tuesday-dossier.md` if you want it kept for later.

**Upgrade menu**
- Your location and pay floor → R1 and R2 leave `unclear`; the status likely moves to `go` or `no_go`.
- Your ingestion or contract work (or its absence) → R9 settles.
- A BigQuery project, sandbox build, or course → R8 gets an artifact to point to.
- The equity grant range → RR4 closes.
- The hiring manager's name → a public-footprint pass on that person, and which story to lead with.
- A deeper pass on Pellucid (funding, leadership changes, reviews; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

R1: Where are you based, and can you work from there, or does it have to be Denver?

R2: Is a $148,000 base workable for you, or what's your floor?

R9: Have you built ingestion from an app or CRM, or owned data contracts that analysts relied on? If so, describe one: what you built, and who depended on it.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.