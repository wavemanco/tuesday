**Yes, apply, on three conditions. Status: `conditional_go`.** Your experience maps closely to the must-haves. The open items are one unanswered gate, a pet-insurance gap, and an employer check I could not run.

Web search was refused in this session, so I could not verify that Brindlemoor exists as described, the posting is live, or what the role pays.

**Fit ledger.**

- `hard_gate`: unclear: R1 (fully remote UK role; location and right to work not stated)
- `must_have`: direct: R2 (4+ years pricing or actuarial analytics), R3 (strong SQL and Python), R4 (GLM experience), R5 (designing and reading price tests)
- `important`: direct: R6 (presenting to underwriting or actuarial leads); adjacent: R8 (pet-insurance product knowledge)
- `preferred`: direct: R7 (insurance experience, motor)

R8 — motor pricing carries over; pet claims behaviour is untested. R1 — one answer from you settles it.

**Opportunity ledger.** The posting is specific about scope, outputs and stakeholders (RR4), with no red flags and no requests made of you. Three things are unknown: whether the role has direct reports (RR1), the salary (RR2), and whether the employer and posting are real and live (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (fully remote UK role; location and right to work); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) R1 confirmed; (2) the posting found on Brindlemoor's own careers page (RR3); (3) pet insurance framed as adjacent motor experience, never as pet expertise.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech, pet-insurance product | `[grounded]` your JD text; not checked online |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, recommend to underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | Individual-contributor analyst scope with senior ownership of outputs; direct reports not mentioned | `[inferred]` from "own" against silence on team |
| Market calibration | Not run: search refused, so no pay band | — |
| Unknowns | Direct reports; salary; team size; whether the employer and posting are live | — |
| Contradictions | None visible in the JD text you gave | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote UK role; UK location and right to work | hard_gate | unclear | none | hard_gate | Not in your inputs, so not established | `[grounded]` JD; you gave no constraint | Q1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, two as senior analyst; self-reported, no artifact yet | `[grounded]` your intake | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both | `[grounded]` your intake | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM rating model | `[grounded]` your intake | none |
| R5 | Designing and reading price tests | must_have | direct | medium | none | Ran 14 price tests last year with underwriting | `[grounded]` your intake | none |
| R6 | Presenting to underwriting or actuarial leads | important | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your intake | none |
| R7 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your intake | none |
| R8 | Pet-insurance product knowledge (implied by "our pet-insurance product") | important | adjacent | medium | transferability | Motor pricing carries over; pet claim frequency, vet-cost drivers and breed or age effects are not exercised | `[inferred]` from the product named in the JD against your motor-only history | G1 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance knowledge (R8, important) | transferability | Motor experience only; nothing pet-specific | The most likely interview objection, and the one that would move R8 to direct | Any non-motor pricing, retention or claims-severity work, even a side analysis | A sanitised model note or any non-motor analysis | `[inferred]` bridge from motor work; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team and reporting lines not stated | unknown | — | "Own pricing analytics" | The role may carry ownership without direct reports, or may include them | `[inferred]` from "own" against silence on team | Does this role have direct reports, and who sits on the pricing team? | unresolved |
| RR2 | Salary not stated | unknown | — | Not in the posting text you gave | The salary may be budgeted, or withheld | `[grounded]` posting silence | What is the budgeted base salary for this role? | unresolved |
| RR3 | Employer and posting not verified | unknown | — | "Brindlemoor (insurtech)" | Research was refused, so the employer and posting are unchecked; not a finding that either is fake | `[grounded]` no check ran | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR4 | Scope and outcomes clearly named | positive_signal | — | "build and monitor rating models, design and read price tests" | Defined scope with stakeholders named; success is likely measurable | `[grounded]` JD | What would success look like at six months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with GLM, price tests and underwriting presentations; name the employer as a motor insurer, never "insurance expertise" | Keeps claims to what you have done | `[grounded]` your intake; reframing audit | pending your approval |
| P2 | Find the live posting on Brindlemoor's own careers page before applying | RR3 | `[grounded]` RR3 | pending your approval |
| P3 | Answer R1 and RR2 before investing in an application | Gate and pay are unsettled | `[grounded]` R1, RR2 | pending your approval |

## Evidence status

Verified: none yet. Every row above rests on your intake prose, which is `medium` at most until you answer a probe.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Would check that Brindlemoor exists as described and the posting is live (RR3). Two searches were sent and refused by the permission prompt. |
| 2. Role-family sweep | unavailable | Would set a pay band and scope norm for the title (role reality, RR2). No call was sent once search was refused. |
| 3. Hiring manager's public footprint | unavailable | Would show Odile Varga's public professional background (positioning, P1). A name was given, but no call was sent once search was refused. |

## Upgrade menu

- Brindlemoor's careers-page link or the live posting → RR3 closes; the decision can move to `go` if R1 is also confirmed.
- Your answer on UK location and right to work → R1 closes.
- The budgeted salary, or your pay floor → RR2 closes and sets the figure against the pay band, which needs search.
- Any non-motor analysis or work sample → R8 can move to `direct`.
- If you grant web search, I can run the L1 checks above (five searches, two page fetches).

If you want this kept for later, I can emit it as a `tuesday-dossier.md`; say the word.

Questions:

R1 — Are you based in the UK and able to work here without sponsorship? This only asks whether the gate is met.

RR2 — What is the lowest base salary you would accept for this role?

G1 — Have you priced, reviewed or modelled any non-motor product, such as pet, home or travel, even as a side analysis? If so, what did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.