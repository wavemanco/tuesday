**Yes, go for it, on conditions. Status: `conditional_go`.** Your sales-ops years, Salesforce certification, SQL and pipeline reporting match the posting. Two must-haves you can't yet evidence (R7, forecast ownership, and R8, billing data with finance), and three hard gates the posting sets that nobody has checked against you (R1 to R3).

**Fit ledger.**

- `hard_gate` — unclear: R1 (UK right to work), R2 (Bristol, two office days), R3 (salary £61,500–£67,000)
- `must_have` — direct: R4a (4+ years), R5 (Salesforce admin), R6a (SQL) · adjacent: R4b (B2B software), R7 (owning a forecast) · unclear: R6b (spreadsheet modelling), R8 (billing and revenue data with finance)
- `important` — direct: R9 (pipeline and renewal reporting)

R7 — adjacent, pipeline review is the nearest work and never the forecast itself; R8 — unclear, no billing work stated; R4b — a bridge from payments to software, its limit named; R6b — unclear, Excel is daily but modelling isn't stated.

**Opportunity ledger.** The posting is specific: stated pay, share options, named outcomes. Two entries need checking: RR1 (forecast sign-off and billing scope unstated) and RR2 (the role isn't on Quillfield's own careers site, as far as I could find).

- **Hard gates:** none failed; unconfirmed: R1 (UK work eligibility), R2 (Bristol, two office days), R3 (salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R7 is presented as adjacent, and RR1 is verified in the first conversation; (2) R8 gets an answer before you invest in the loop; (3) R1–R3 are checked; (4) RR2 is confirmed: the role is live.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; Bristol; 96 staff; Series A (£11M) closed April 2025 | `[grounded]` quillfield.co.uk/about |
| Role | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Working pattern | Hybrid, two office days a week, Bristol | `[grounded]` JD |
| Pay | £61,500–£67,000 plus share options | `[grounded]` JD |
| Market calibration | Role-family median £64,200, interquartile £57,800–£70,400 (one published 2026 guide, n=438) | `[generic]` Ledgerline 2026 guide; the posted range sits inside it |
| Hiring manager | Tamsin Achebe: Head of Revenue Operations at Quillfield; previously four years as sales operations manager at Corvane Payments | `[grounded]` public profile snippet (not opened). The reporting line for this role isn't stated |
| Scope read | One post carries CRM, billing data, reporting and a CFO-facing forecast: broad for one title | `[inferred]` from the JD's listed responsibilities |
| Unknowns | Forecast sign-off split with the CFO; reporting line; whether the role is live on the company's site | — |
| Contradictions | None found between the JD and the company's About page | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | UK right to work without sponsorship (your constraint; not stated) | hard_gate | unclear | none | hard_gate | No statement from you yet | `[grounded]` posting silent | Q3 |
| R2 | Bristol, two office days a week | hard_gate | unclear | none | hard_gate | JD states it; your location and tolerance not given | `[grounded]` JD | Q3 |
| R3 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | JD states it; your floor not given | `[grounded]` JD | Q3 |
| R4a | 4+ years in RevOps, sales ops or analytics | must_have | direct | medium | none | Five years in sales ops, last two running UK revenue ops; your statement, no artifact | `[grounded]` your intake | none |
| R4b | At a B2B software company | must_have | adjacent | medium | transferability | Your employer was a B2B payments company; close to invoicing software, not the same | `[inferred]` from the JD's sector term | Name the payments-to-software bridge and its limit |
| R5 | Salesforce or HubSpot administration | must_have | direct | medium | none | Salesforce admin certified; certificate not inspected | `[grounded]` your statement | Attach the certificate to reach high |
| R6a | Strong SQL | must_have | direct | medium | none | SQL weekly, your statement | `[grounded]` your intake | none |
| R6b | Spreadsheet modelling | must_have | unclear | low | discovery | Excel daily is stated; modelling is not | `[grounded]` your intake | Fold into Q1 |
| R7 | Experience owning a forecast | must_have | adjacent | medium | transferability | You've never owned the company forecast; finance did. Monthly pipeline review is the nearest work and feeds a forecast but isn't one | `[grounded]` your statement; `[inferred]` the adjacency | G1, Q1 |
| R8 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | No billing work stated; revenue-facing work at the payments company not described | `[grounded]` your statement | G2, Q2 |
| R9 | Pipeline and renewal reporting | important | direct | medium | none | Rebuilt pipeline and renewal dashboards, your statement | `[grounded]` your intake | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R7, must_have) | transferability | Pipeline review with the sales director; no forecast ownership | The headline responsibility is the forecast; it's an adjacent must-have | A weighted pipeline or commit figure you submitted; a renewal forecast; a number finance rebuilt | A forecast sheet or the pipeline-review pack | `[inferred]` bridge from pipeline review; `[generic]` that forecast ownership is the likeliest objection |
| G2 | Billing and revenue data with finance (R8, must_have) | discovery | No billing work stated | An unclear must-have that could become adjacent | Renewal reconciliation with finance; bookings-to-invoice checks; revenue reporting to finance | A reconciliation note or a finance-facing dashboard | `[grounded]` your intake |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast sign-off and billing scope unstated | risk_signal | medium | "run the quarterly revenue forecast with the CFO" | You may be asked to build and defend the forecast with the CFO holding sign-off, not own the model | `[inferred]` from the JD's scope against its silence on sign-off | Which parts of the quarterly forecast does this role build and sign off, and which does the CFO own? | unresolved |
| RR2 | Role not found on the company's own careers site | risk_signal | low | "Revenue Operations Lead, Quillfield" (Tallyboard listing) | The listing may be stale or aggregated, or the role may sit under another title. A pattern for employers of this kind, not a claim about this one | `[generic]` pattern; `[grounded]` search found no careers listing | Is this role open on Quillfield's own careers site now, and who would I report to? | unresolved |
| RR3 | Pay stated and inside the role-family band | positive_signal | — | "£61,500–£67,000 plus share options" | Pay is stated and sits inside the band | `[grounded]` JD; `[generic]` Ledgerline band | How does the share option scheme vest, and at what value? | noted |

The employer itself is established (fetched About page), so the standing employer-not-established entry does not apply. RR2 concerns the listing only.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter whether the role is live on the company's site, who it reports to, and how the forecast splits with the CFO | RR1, RR2 | `[grounded]` register | pending your approval |
| A2 | Frame the forecast-adjacent story as pipeline review and renewal reporting, not forecast ownership | R7, R4b | `[grounded]` your intake; no ownership claimed | pending your approval |
| A3 | Check the three gates before investing in the loop | R1–R3 | `[grounded]` JD | pending your approval |
| A4 | When an interview is booked, drill the forecast and billing questions with mock-interview | R7, R8 | `[generic]` interview practice | pending your approval |

## Evidence status

Verified: R4a, R5, R6a, R9 claims (your statements, not yet inspected). Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol" and "Quillfield Revenue Operations Lead careers" (no listing found); fetched quillfield.co.uk/about. Moved the organization row and RR2 |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK B2B software £60,000", which returned the Ledgerline 2026 UK Revenue Operations Pay Guide. Moved the market-calibration row and R3's check |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned a public profile snippet (linkedin.example/in/tamsin-achebe). Not opened. Moved the hiring-manager row |

Positioning note: Tamsin's public profile shows the same route you took, sales operations at a payments company and then revenue operations. Mention it only if it comes up naturally; don't build a claim on it.

The dossier offer: I can write this up as a `tuesday-dossier.md` you keep and append to.

## Upgrade menu

- Your CV → confirms R4a, R5, R6a and R9 against the page, and lets me propose CV language (pending your approval).
- The Salesforce certificate → R5 to `high`.
- An answer to G1 → R7 moves toward `direct`, or stays adjacent with its limit.
- An answer to G2 → R8 leaves `unclear`.
- Answers on the three gates → R1–R3 close.
- Deeper research on the company (leadership changes, recent news; up to 5 more searches and 2 more fetches) → say the word and it runs.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

1. **G1 (R7):** Have you ever produced a forecast figure, even a weighted pipeline or commit number that finance rebuilt? What did you own, and what did you hand over? Also, have you done any Excel scenario modelling (R6b)?
2. **G2 (R8):** Did you ever work with finance on revenue, bookings or renewal figures, such as reconciling what sold against what was invoiced? What did you do?
3. **Gates (R1–R3):** Do you have the right to work in the UK without sponsorship, can you do two office days a week in Bristol, and is £61,500 a floor you would accept?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.