**Not a waste of time, but you don't clear the 3-year PM must-have as written. The case rests on adjacent experience. `conditional_go`**

**Fit ledger.**

- `must_have`: direct: R3 (technical fluency with API docs and schemas) · adjacent: R1 (3+ years product management), R2 (shipped API or platform products), R4 (stakeholder management across engineering, sales, customers), R5 (owning the roadmap and writing specs)
- `important`: direct: R6 (discovery with integration partners) · adjacent: R9 (launch coordination) · unclear: R7 (agile delivery), R8 (adoption metrics)

R3 — your strongest match, and it's inspectable. R1 and R5 — the PM-ownership bar, met only by adjacency. R7 and R8 — the CV is silent, so they're open questions.

**Opportunity ledger.** The posting is clear and scoped: a named platform, two squads, and five concrete duties. What's unknown is your decision rights against sales and partners (RR2), and the employer hasn't been verified from here (RR1).

- **Hard gates:** none stated in the posting; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) a concrete example of you shaping or deciding what a product team built, which is G1 (R1, R5); (2) agile delivery shown, which is G2 (R7); (3) the role confirmed on Quartzline's own careers page (RR1).
- **What would change this:** a real PM-ownership example moves R1 and R5 toward `direct` and could move the status to `go`. If the bar is read literally and no such example exists, the status moves to `no_go`, not a hold.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` JD header; not verified, since web search was refused |
| Mandate | Own the partner-facing API platform roadmap, run partner discovery, lead two engineering squads, track adoption, coordinate launches | `[grounded]` JD |
| Scope read | A full PM remit for one platform with two squads: a lead-level scope for the title | `[inferred]` from the five duties against two squads |
| Market calibration | Not run; no search was permitted | — |
| Unknowns | Decision rights against sales and partners; whether a PM or product lead sits above this role; compensation (not stated); location and contract basis | — |
| Contradictions | None visible from the JD alone | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management experience | must_have | adjacent | medium | transferability | No PM title. Integration and requirements work sits upstream of PM; no evidence you owned a roadmap. Years are not a gate, so this is graded on fit | `[grounded]` CV ("never held a PM title") | G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You shipped client integrations of REST APIs, not a platform product you managed | `[grounded]` CV | see G1 |
| R3 | Technical fluency: API docs and schemas | must_have | direct | medium | none | 30+ REST integrations, OpenAPI, Postman, SQL. Self-reported, so `medium` | `[grounded]` CV | none |
| R4 | Stakeholder management: engineering, sales, customers | must_have | adjacent | medium | transferability | Strong on engineering and customers. No sales-side work is stated | `[grounded]` CV | upgrade menu |
| R5 | Own roadmap; write specs; drive delivery with two squads | must_have | adjacent | medium | transferability | You wrote requirements documents and ran roadmap-input sessions. You did not own the roadmap | `[grounded]` CV | G1 |
| R6 | Discovery with integration partners | important | direct | medium | presentation | Scoping workshops and quarterly client-feedback sessions are discovery in substance; the CV frames them as implementation | `[grounded]` CV | E1 |
| R7 | Agile delivery | important | unclear | low | discovery | CV silent on sprints, backlogs, ceremonies | `[grounded]` CV silence | G2 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | CV silent. The triage-tool lead is unconfirmed and cannot count | `[grounded]` CV silence; memory lead not counted | G3 |
| R9 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Go-live and UAT coordination with clients. Sales and support launch work not stated | `[grounded]` CV | upgrade menu |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | PM ownership (R1, R5) | transferability | Requirements and roadmap-input work, with no decision you owned | This is the must-have the case turns on | A prioritization call with engineering; a feature scope you chose; a roadmap input that became a decision | A roadmap, a spec that shipped, a prioritization doc | `[grounded]` CV; `[generic]` that PM-ownership is what this bar usually tests |
| G2 | Agile delivery (R7) | discovery | No mention of sprints or backlogs | An important requirement, cheap to close if real | Planning work with engineering squads; sprint reviews; release cadence | A sprint review, a backlog you ran | `[grounded]` CV silence |
| G3 | Adoption metrics (R8) | discovery | No measured-use evidence on the CV | Metrics are a named duty of the role | Any tool or process whose use you tracked | Usage numbers, a tool's adoption record | `[grounded]` CV silence; memory lead, unconfirmed |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The employer may be too new or small for a footprint, the posting may be stale, or it may not be a live hiring entity. Web search was refused, so this is an unchecked gap, not a finding about Quartzline | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Decision rights unstated | unknown | — | "Own the roadmap for our partner-facing API platform" | The role may own the roadmap without authority over sales or partner commitments | `[inferred]` from the duties against the silence on decision rights | Which roadmap decisions does this role make alone, and which need sales or partner sign-off? | unresolved |
| RR3 | Scope is well defined | positive_signal | — | "two engineering squads" | Concrete scope, named platform, named squads | `[grounded]` JD | Who owns the adoption metrics today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Reword the discovery bullet to read: "Ran scoping workshops and quarterly client-feedback sessions that fed product's roadmap" | Shows R6 as discovery, with no new claim | `[grounded]` CV | resume_edits_pending_approval |
| P1 | Position yourself as the technical customer-facing product person who has run integrations end to end, not as a PM by title | Matches what the CV supports; the 3-year bar is not met on title | `[grounded]` CV; `[generic]` on how recruiters screen for the title | pending your approval |
| P2 | Before applying, ask the recruiter how strictly the 3-year PM requirement is read | Decides whether to apply cold or in a referral | `[generic]` hiring-practice pattern | pending your approval |

Do not claim PM ownership, agile delivery or metrics ownership until you can show them.

## Evidence status

Verified: none yet. Every claim above rests on your CV.

Research tier: L1 — searches 1 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | A search for Quartzline was refused by permission and not retried. Would have settled RR1 and confirmed the posting is live |
| 2. Role-family sweep | unavailable | Would have calibrated scope and any seniority norm for a PM role at this size. Not run |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form |

## Upgrade menu

- A real example of shaping or deciding a product's direction (G1) → R1 and R5 move toward `direct`, and the status could move to `go`.
- The triage tool, if it exists: what it did, who used it, and how you know it was used (G3) → R8 moves off `unclear`, and it may also support R1 and R2.
- Sprint or backlog experience (G2) → R7 moves off `unclear`.
- A sales-facing example, such as a deal you supported or a renewal you saved (R4) → R4 moves toward `direct`.
- The live posting or careers-page link → RR1 closes.
- Permission to run web search → the employer check and the role-family sweep run.
- Your constraints (compensation floor, location, schedule, contract type) → the hard-gate checks run.

Want me to save this as `tuesday-dossier.md` so it carries into later sessions?

1. G1 — Have you ever decided what a product or platform team built next, even partly? Which call was yours, who did you decide with, and what happened after?
2. G3 — A prior conversation noted that you built a request-triage tool that support agents adopted. Is that right? If so, what did it do, who used it, and how did you know it was used? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. G2 — Have you worked in sprints or from a backlog that a team planned against? What was your part in planning, and how often did it run?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.