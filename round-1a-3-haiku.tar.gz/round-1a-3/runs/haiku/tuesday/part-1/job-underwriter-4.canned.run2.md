**Not yet. Worth applying to once the location question is answered. Status: `hold_pending_answers`.**

Your account fits the role's core requirements: GLM, SQL and Python, price tests, and presenting to underwriting are all direct on what you've told me. The hold is about where the job is based. The pet-insurance gap is a bridge, not a blocker.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK)
- `must_have`: direct: R2, R3, R4, R5
- `important`: direct: R6, R7 · adjacent: R8 (pet-insurance product)
- `preferred`: direct: R9 (insurance experience)

R2, R3, R4, R5, R6, R7 and R9 are direct on your account and stay at `medium` until something inspectable exists. R8 is a credible bridge from motor, with its limit named. R1 is the one row where the sources disagree.

**Opportunity ledger.** The posting is live and names its reporting line (RR5), but its location term conflicts with the careers page (RR1). Pay is absent from the excerpt (RR4), and decision rights and line management are unstated (RR2, RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** If the role is Leeds-based and you can't work there four days a week, R1 becomes a failed gate and the status becomes `no_go` unless the employer changes the term. If it's genuinely remote and your constraints clear, this moves toward `go`.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; pet-insurance product | `[grounded]` JD and careers page |
| Remit | Own pricing analytics; build and monitor rating models; design and read price tests | `[grounded]` JD |
| Reporting | Reports to the Director of Pricing | `[grounded]` careers page |
| Working pattern | Contradiction: "fully remote (UK)" in your JD; "Leeds office four days a week" on the careers page | `[grounded]` both sources |
| Market calibration | Senior pricing analyst, UK insurers and insurtechs: median £58,400, IQR £52,100–£64,900 | `[generic]` 2026 pay survey, n=612; not this employer's offer |
| Unknowns | Salary; line management; which rating decisions the role makes itself | — |
| Contradictions | Location (above) | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK | hard_gate | unclear | none | hard_gate | JD says remote; careers page says Leeds four days a week. Your location isn't given | `[grounded]` JD vs careers page | Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years at a UK motor insurer, last two senior. Self-report, not yet inspectable | `[grounded]` your account | None; the CV should show dates |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use; no artifact yet | `[grounded]` your account | Upgrade menu |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM for the young-driver book (motor, not pet) | `[grounded]` your account | Upgrade menu |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your account | None |
| R6 | Design and read price tests | important | direct | medium | none | Ran 14 price tests last year with underwriting | `[grounded]` your account | Upgrade menu |
| R7 | Build and monitor rating models | important | direct | medium | none | Built and maintained the GLM; monitoring not yet described | `[grounded]` your account | Describe the monitoring you did |
| R8 | Pet-insurance product context | important | adjacent | medium | transferability | Motor pricing transfers. Pet-specific drivers are not exercised | `[inferred]` from the JD and your motor work; `[generic]` that pet books have distinct drivers | G1 |
| R9 | Insurance experience | preferred | direct | medium | none | Motor insurer | `[grounded]` your account | None |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance context (R8, important) | transferability | Motor pricing and monitoring; no pet work | The product is pet, so this is the likeliest objection | Monitoring a new or small book; any non-motor pricing; a benchmark or market study touching pet | An anonymised monitoring pack or pricing note | `[inferred]` bridge from motor work; `[generic]` that pet books have distinct drivers |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location conflict | risk_signal | medium | "Fully remote (UK)" vs "Leeds office four days a week" | The pasted JD may be an older version, or the live term changed. The fetch returned a summary, not the full posting | `[inferred]` from the two sources | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Line management unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may or may not line-manage; the posting is silent | `[inferred]` from the posting's silence | Does this role line-manage anyone? | unresolved |
| RR3 | Decision rights unstated | unknown | — | "Own pricing analytics" | The role may recommend rating changes rather than make them | `[inferred]` from the posting's silence | Which rating and pricing decisions does this role make itself? | unresolved |
| RR4 | Salary not in the excerpt | unknown | — | (no salary stated) | The figure may be withheld or simply missing from the excerpt | `[inferred]` from the excerpt, against the `[generic]` band | What base salary is budgeted for this role? | unresolved |
| RR5 | Live posting with a named reporting line | positive_signal | — | "Accepting applications … reports to the Director of Pricing" | The role is live and its reporting line is stated | `[grounded]` careers page | What would the first 90 days on the pet book look like? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the location term before applying | R1, RR1 | `[grounded]` | pending your approval |
| A2 | Ask RR2, RR3 and RR4 at first contact | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A3 | Lead with the GLM you built and maintained and the 14 price tests. Name the motor book as the source. Present pet as the adjacent bridge, not as expertise | Positioning from the map; no new claims | `[grounded]` R3–R6, R8 | pending your approval |
| A4 | Be ready to discuss monitoring rating models. The hiring manager's 2025 forum talk on monitoring rating models in small books is public. Bring only monitoring you have done | Public footprint, from a search snippet I did not read in full | `[grounded]` search result | pending your approval |

**Evidence status**

Verified: none yet. Your account so far is intake prose, which counts as a CV for verification purposes, so every claim is unverified. Unverified leads: none. Rejected inferences: none.

Standing check: the employer is established. The careers page is live and matches the JD apart from location, so the employer-not-established entry does not apply.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance careers Senior Pricing Analyst"; fetched brindlemoor.co.uk/careers/senior-pricing-analyst. Posting is live and reports to the Director of Pricing. It states a Leeds office four days a week, which your JD does not. Moved RR1 and R1 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary GLM pricing"; fetched "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved the `[generic]` market calibration: median £58,400; IQR £52,100–£64,900 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor". The result is a profile page (linkedin.example/in/odile-varga), read from the search snippet only. It lists a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", on monitoring rating models in small books, and six years as head of pricing analytics at Calloway Re. Moved A4 |

**Dossier offer:** I can write this up as a `tuesday-dossier.md` you can keep and reuse.

**Upgrade menu**

- Your pay floor, contract preference and start date → the hard-gate checks run and RR4 is set against your floor.
- A location answer, or the full live posting text → R1 and RR1 close.
- An anonymised monitoring pack or pricing note → R7 to `high`, and R8's bridge narrows.
- An anonymised price-test readout → R6 to `high`.
- An anonymised query or notebook → R3 to `high`.
- A deeper pass on Brindlemoor (funding, leadership, pet-book history; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

1. R1: Where are you based, and can you work from the Leeds office four days a week?
2. Your constraints: what is your base-pay floor, which contract types you'll accept, and your earliest start date? None were given, so the hard-gate checks can't run yet.
3. RR2: Are you open to a role that line-manages analysts? You haven't managed anyone yet, and the posting doesn't say whether this one does.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.