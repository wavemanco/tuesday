**Not a waste, but it's a stretch: you don't meet the 3-year PM bar on paper, so apply as a bridge case with a plan for that screen. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R3 · adjacent: R1 (3+ years PM experience), R2 (shipped API or platform products), R4 (stakeholder management across eng, sales, customers), R10 (own the roadmap)
- `important`: adjacent: R5 (run discovery with integration partners), R6 (write specs and drive delivery), R9 (coordinate launches with sales and support) · unclear: R7 (agile delivery experience), R8 (define and track adoption metrics)

R3 — direct on CV self-report; R1, R2, R4 and R10 — adjacent, each with its limit named in the map; R7 and R8 — unclear, nothing in the CV to read.

**Opportunity ledger.** The scope is concrete: two named engineering squads and a defined set of outputs (RR3). The employer is not established, because research did not run (RR1, a standing entry that caps the decision at `conditional_go`). The salary is not in the posting (RR2), and whether the role decides the roadmap alone is open (RR4).

- **Hard gates:** none stated in the posting; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on Quartzline's own careers page (RR1); (2) you can name one roadmap decision you made, not one you fed (G1, closing question 1); (3) the application leads with integration depth and never claims PM experience.

**Research tier: L1 — searches 3 of 5, fetches 0 of 2.** Three searches were refused because WebSearch permission was not granted, so no search ran. I did not retry them.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both calls refused. Would have checked that Quartzline exists as described and that the posting is live (RR1), and the contradictions row in role reality. |
| 2. Role-family sweep | unavailable | The one call refused. Would have set the market band for title, scope and pay (role reality, RR2). |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` posting header; existence not checked (target 1 unavailable) |
| Mandate | Own the roadmap for the partner-facing API platform; run partner discovery; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches | `[grounded]` posting |
| Scope read | A senior PM remit with two squads and launch coordination, which is ordinary for a Series B platform team | `[inferred]` from the responsibility list |
| Market calibration | Not run. Target 2 was refused. | — |
| Unknowns | Salary; whether the role owns roadmap decisions alone; whether the 3-year bar is screened literally; agile practice | — |
| Contradictions | None found within the posting. Not checked against the company's own careers page. | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years PM experience | must_have | adjacent | medium | transferability | No PM title or PM years. Seven years of implementation and solutions work, plus roadmap-input sessions. Limit: you have not made the call on what gets built. | `[grounded]` CV, self-reported | G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ REST API integrations delivered end to end. That is client-side delivery, not a product you owned. | `[grounded]` CV | G2 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI named. No artifact to inspect, so expect a probe. | `[grounded]` CV, self-reported | none |
| R4 | Stakeholder management across engineering, sales, customers | must_have | adjacent | medium | transferability | Coordinated engineers, client engineers and PMs on custom builds. Sales is not named. | `[grounded]` CV | none |
| R10 | Own the product roadmap | must_have | adjacent | medium | transferability | Quarterly roadmap-input sessions collecting client feedback for product. Limit: input, not decision. | `[grounded]` CV | G1 |
| R5 | Discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and requirements work are discovery-shaped but not framed as product discovery. | `[inferred]` from scoping language | upgrade menu |
| R6 | Write specs, drive delivery with engineering squads | important | adjacent | medium | transferability | Requirements documents and engineer coordination on custom builds. Not squads or a backlog. | `[grounded]` CV | none |
| R7 | Agile delivery experience | important | unclear | low | discovery | The CV is silent on agile practice. | `[grounded]` CV silence | upgrade menu |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | No adoption metric stated. UAT and go-live are named. | `[grounded]` CV silence | G3 |
| R9 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Client go-live and UAT, plus an internal playbook the team uses. Sales and support are not named. | `[grounded]` CV | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Decisions owned (R1, R10) | transferability | Roadmap input is on the CV. No decision you made is. | This is the objection a PM hiring manager will press first. | A feature or priority you decided, even inside a custom build, that the client or product team then acted on | A roadmap doc, a decision log, or a sanitized note | `[grounded]` CV; `[inferred]` that this is the first probe |
| G2 | Shipped product (R2) | discovery | The CV shows integrations, not a product you owned. | The posting asks for shipped platform products. | The internal request-triage tool in the memory note, if it was real (see below) | The tool's spec, a usage count, or a support-team quote | `[grounded]` CV; the triage tool is an unconfirmed `memory_lead` |
| G3 | Adoption metrics (R8) | discovery | No adoption measure is stated. | The posting makes adoption tracking a responsibility. | Go-live timelines, partner API usage, time to first successful call | Any dashboard, report, or figure from an integration | `[grounded]` CV silence |

The queue holds no questions. Each question is asked once in the closing block, tagged to its row.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established (standing entry) | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small for a footprint, the posting may be stale, or it may not be a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on Quartzline's own careers page, and who would I interview with? | unresolved |
| RR2 | Salary not in the posting | unknown | — | (no salary in the posting) | The band may sit below the role-family norm, or the company may not publish pay. | `[inferred]` from the posting's silence | What is the budgeted base range for this role? | unresolved |
| RR3 | Scope and resources stated | positive_signal | — | "write specs and drive delivery with two engineering squads" | Authority and capacity are concrete, which is a good sign. | `[grounded]` posting | Which two squads, and do they report into this role? | noted |
| RR4 | Roadmap authority not stated | unknown | — | "own the roadmap for our partner-facing API platform" | Sales commitments or engineering sign-off may limit what the role decides alone. | `[inferred]` from "coordinate launches with sales" | Which roadmap decisions does this role make alone, and which need sales or engineering sign-off? | unresolved |
| RR5 | Literal screen on PM years | risk_signal | medium | "3+ years product management experience (must-have)" | A recruiter may screen on titled PM years before reading adjacent work. | `[generic]` hiring-screen pattern, not a claim about this employer | Is the 3-year product management requirement a screen, or weighed against adjacent experience? | unresolved |

No entry is `severity: high`.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV summary with integration depth: "Led 30+ client integrations of our REST APIs end to end, from scoping to go-live." Keep the number on integrations. | R2, R1 | `[grounded]` CV | `resume_edits_pending_approval` |
| E2 | Move the roadmap-input bullet up, unchanged: "Ran quarterly roadmap-input sessions collecting client feedback for product." Do not write "shaped the roadmap." | R10 | `[grounded]` CV | `resume_edits_pending_approval` |
| I1 | Interview framing: "I've led 30+ API integrations end to end and collected client feedback on the platform every quarter. I haven't yet made the roadmap call, and that's the step I'm going for." | R1, R10 | `[grounded]` the two CV lines above | pending your approval |
| A1 | Check the posting on Quartzline's own careers page before applying | RR1 | `[generic]` pattern | pending your approval |
| A2 | Ask the recruiter whether the 3-year PM requirement is a literal screen | RR5 | `[generic]` pattern | pending your approval |

Do not claim PM experience, a shipped product, or adoption numbers you cannot name. The audit found no clause in E1 or I1 that goes beyond your own sentences.

## Evidence status

Verified: none yet. Every CV claim is self-reported and not confirmed by you in this conversation.

Unverified leads: the request-triage tool from a prior conversation, which support agents adopted. This is a `memory_lead`, not evidence, and it is the basis for closing question 2 only.

Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2 (targets listed above)

Dossier offer: I can write the assessment to `tuesday-dossier.md` so it carries into interview prep.

## Upgrade menu

- **Posting or careers-page link:** confirms or clears RR1, which lifts the `conditional_go` cap.
- **Permission for WebSearch:** two of the five L1 searches remain; they would set the market band (RR2) and check Quartzline.
- **One roadmap decision you made, with its outcome:** moves R1 and R10 toward `direct` if it holds up.
- **The triage tool, if it was real:** its spec, usage, and what support did with it moves R2 and R8.
- **Any integration metric you tracked:** moves R8 from `unclear`.
- **Agile practice you ran:** moves R7 from `unclear`.

## Questions

1. **G1 (R1, R10):** Have you ever made a product or priority call that a team then built? What was it, who else had a say, and what happened?
2. **G2 (R2):** Did you build an internal request-triage tool that support adopted? What did it do, how did adoption show, and is there a spec or a number?
3. **G3 (R8):** Have you tracked any adoption figure for an integration, such as go-live time, first successful API call, or partner usage? Give the number if you have one.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.