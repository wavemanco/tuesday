**Hold, don't apply yet.** You're not wasting your time, but the one literal bar is unmet and two answers could change the call. R1 (3+ years PM, must-have) is absent from your record, and the posting asks for it directly. · `hold_pending_answers`

**Fit ledger.**

- `must_have`: direct: R5a (engineering and customer stakeholders) · adjacent: R2 (roadmap ownership), R3 (shipped platform products) · unclear: R5b (sales stakeholders), R6 (agile delivery) · absent: R1 (3+ years PM)
- `important`: adjacent: R4 (discovery with integration partners), R8 (launch coordination) · unclear: R7 (adoption metrics)

R2 and R3 are bridges with their limits named. R1 has no titled years to point to. R6 and R7 have no evidence either way yet.

**Opportunity ledger.** The posting is clear on scope and outcomes (RR3, positive). The employer and posting are unverified (RR1, unknown), the salary is missing (RR2, unknown), and the 3+ years must-have may be screened literally (RR4, medium).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** the awaited answers are G1 (did you own prioritization and adoption measurement on the triage tool), G2 (sprint or backlog ownership) and G3 (an API change you drove to release). If G1 and G2 come back confirmed, R2, R6 and R7 likely move up and the status goes to `conditional_go`. If none of them hold, the posting becomes a long shot and I'd move to `no_go` for it, with adjacent product titles as the route.

**Research: the two web searches were refused permission in this session**, so no employer or salary facts were checked. Everything below about the market is `[generic]`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` your brief |
| Mandate | Own the partner-facing API roadmap; discovery with integration partners; specs and delivery with two squads; adoption metrics; launch coordination | `[grounded]` JD |
| Stated outcomes | Adoption metrics are named as a duty; no target figures given | `[grounded]` JD |
| Scope read | A dedicated platform PM over two squads, with no PM above it stated | `[inferred]` from the squad count and the launch duties |
| Market calibration | Titled-years must-haves for platform PM roles are often screened literally before anyone reads the rest | `[generic]` pattern; no band researched |
| Unknowns | Seniority level, salary, contract basis, whether a PM sits above the role | — |
| Contradictions | None visible in the JD | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management | must_have | absent | none | transferability | No PM title or PM-owned work in the CV | `[grounded]` CV | G1 |
| R2 | Owns a roadmap for a partner-facing platform | must_have | adjacent | medium | transferability | You ran quarterly roadmap-input sessions collecting client feedback for product. You did not make the roadmap decisions | `[grounded]` CV; `[inferred]` that input work is the closest analogue | G1 |
| R3 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ REST integrations taken end to end to go-live. These were integrations of a vendor's product, not a product you shipped | `[grounded]` CV | G3 |
| R4 | Discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and requirements documents with clients | `[grounded]` CV | G3 |
| R5a | Stakeholder management: engineering and customers | must_have | direct | medium | none | Coordinated your engineers, client engineers and PMs on custom builds | `[grounded]` CV | none |
| R5b | Stakeholder management: sales | must_have | unclear | low | discovery | The CV is silent on sales | `[grounded]` CV silence | G4 |
| R6 | Agile delivery experience | must_have | unclear | low | discovery | The CV is silent on sprints or agile cadence | `[grounded]` CV silence | G2 |
| R7 | Defines and tracks adoption metrics | important | unclear | low | discovery | SQL is listed. The triage tool is an unconfirmed lead only | `[grounded]` CV; memory lead, not evidence | G1 |
| R8 | Launch coordination with sales and support | important | adjacent | medium | transferability | You owned UAT and go-live for client integrations. No internal sales or support launch is stated | `[grounded]` CV | G4 |

Fit and gap are separate calls. R5a is `direct` but I have not pushed it as a headline, because the rest of the map is where the decision sits.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product ownership and adoption measurement (R1, R2, R7) | transferability | Roadmap input, requirements documents and coordinating PMs are on the CV. No titled years and no stated decision rights. The triage tool is an unconfirmed earlier lead | This is the must-have the decision turns on. A confirmed product decision would narrow it | The triage tool if you owned what it built and how it was measured; any backlog you ordered | A spec, a usage figure, or a screenshot of adoption | `[inferred]` bridge from the input work; `[generic]` that titled years are the usual literal screen |
| G2 | Agile delivery (R6) | discovery | Nothing on sprints, backlogs or a delivery cadence | Must-have with no evidence either way | Any sprint or backlog you ran with a squad | Sprint board, roadmap, or a release plan | `[grounded]` CV silence |
| G3 | Shipped platform product (R3) | transferability | Integrations shipped to go-live, with no API change you drove | An API change you pushed to release would be the strongest bridge | A schema or default changed because of a client failure | A release note or ticket | `[inferred]` from the integration work |
| G4 | Sales launch coordination (R5b, R8) | discovery | Go-live coordination on the CV; nothing with sales | Must-have for R5b; needed for the launch duty | Pricing, packaging or sales enablement for an integration | A sales-facing doc | `[grounded]` CV silence |

The queue holds no questions. The questions are in the closing block, tagged by row.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | unknown | — | "Product Manager, Platform APIs — Quartzline" | The posting may be stale or the company may be too new to have a footprint; I could not check either way | `[generic]` pattern for early-stage companies; no claim about this one | Can you point me to this role on Quartzline's own careers page, and who would I interview with? | unresolved |
| RR2 | Salary not stated | unknown | — | none in the posting | The band is unknown; the posting may withhold it | `[grounded]` posting silence | What is the budgeted band for this role? | unresolved |
| RR3 | Scope and outcomes are explicit | positive_signal | — | "own the roadmap for our partner-facing API platform" | Success can be measured here | `[grounded]` JD | Which adoption metrics are set today, and who owns them? | noted |
| RR4 | Titled-years must-have | risk_signal | medium | "3+ years product management experience (must-have)" | The role may be screened literally on titled years before a human reads adjacent work | `[generic]` pattern for must-have years; not a claim about this employer | Would you consider a candidate whose product-ownership work sits in a solutions or implementation role, and what evidence would you need to see? | unresolved |

**Severe red flags:** none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Answer G1 to G3 in writing before applying | They decide R1, R2, R3 and R6 | `[grounded]` gap queue | pending your answers |
| A2 | Lead the CV with partner discovery work (input sessions, requirements docs, 30+ go-lives), with no titles or "owned the roadmap" wording | R2, R4 | `[grounded]` CV. Reframing audit: no product-ownership claim added | pending your approval |
| A3 | Add the triage tool as a bullet only with an adoption measure you can state | R7 | Only if G1 is confirmed | pending your approval |
| A4 | Also search PM-adjacent titles (technical PM, platform or integrations PM, implementation-to-product moves) | The titled-years screen bites harder on this exact title | `[generic]` pattern, not a claim about Quartzline | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search refused permission this session, so no result. Would have settled RR1 (does Quartzline exist as described, and is the posting live) |
| 2. Role-family sweep | unavailable | Search refused permission this session. Would have set the salary band and the market calibration line |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- A spec, usage figure or screenshot for the triage tool → R1 bridge strengthens, and R7 may move from `unclear`.
- An integration architecture doc or a sanitized version of the playbook → R3 may move to `direct` with an inspectable artifact.
- Permission to retry the two web searches → RR1 and RR2 close or sharpen, and the salary band gets a source.
- Deeper company diligence (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want, I can write this up as `tuesday-dossier.md` so the map, register and questions carry into a later session. Say so and I'll emit it.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

1. **G1 (R1, R2, R7):** Did you decide what the triage tool built and prioritized, and how did you measure whether support agents adopted it? Give figures if you have them.
2. **G2 (R6):** Have you run work in sprints or another agile cadence, with a backlog you ordered? Name the cadence, the team, and who set the order.
3. **G3 (R3):** Did you push a change to an API, a schema or a default through to release because of a client's failed integration? What did you own, and did it ship?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.