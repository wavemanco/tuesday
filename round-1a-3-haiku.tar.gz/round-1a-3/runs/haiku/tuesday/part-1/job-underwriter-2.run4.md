## Decision snapshot

**Not a waste, but a stretch. You have no PM title, and the answer to whether you've owned product decisions decides it. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R3, R4 · adjacent: R1 (3+ years PM experience), R2 (shipped API or platform products) · unclear: R5 (agile delivery)
- `important`: direct: R7 (partner discovery) · adjacent: R6 (own API roadmap), R8 (specs and squad delivery), R10 (launch coordination with sales and support) · unclear: R9 (adoption metrics)

R3 and R4 are direct and medium: your own CV claims, not yet probed. R1 and R2 are the bars your title doesn't meet; the adjacent work is real and its limit is named.

**Opportunity ledger.** The posting is clean and its scope is defined (RR3). Pay, location and contract are unstated (RR2). The employer and the live posting are unverified because web search was refused (RR1).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1: the posting shows on Quartzline's own careers page; (2) R5 and R9 answer concretely in your favor (Q2 and Q3 below); (3) any CV line you write describes your real role as implementation lead who drove product input, not as product management.

## Research

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Every call was refused by the search permission. Would have confirmed the employer and live posting (RR1). |
| 2. Role-family sweep | unavailable | Refused. Would have set the market band for this title and scope (RR2, role reality). |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` JD header |
| Mandate | Own the partner-facing API roadmap; discovery; specs; two engineering squads; adoption metrics; launches | `[grounded]` JD |
| Scope read | Ordinary for a platform PM title with two squads | `[generic]` role-family pattern, not checked |
| Market calibration | Not run: search refused | — |
| Unknowns | Salary, location, contract type, whether the role sets the roadmap alone | — |
| Contradictions | None visible in the material you gave | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management experience | must_have | adjacent | medium | transferability | Seven years of implementation and solutions work, no PM title. Years are product-adjacent, not PM | `[grounded]` CV; `[inferred]` adjacency | Q1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | Led 30+ REST integrations end to end. You shipped client builds, not the platform | `[grounded]` CV; `[inferred]` adjacency | Upgrade menu item 2 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI; self-reported, unprobed | `[grounded]` CV | none |
| R4 | Stakeholder management across engineering, sales, customers | must_have | direct | medium | presentation | Coordinated your engineers, client engineers and PMs; sales not evidenced. The CV calls it coordination, not stakeholder management | `[grounded]` CV | Reframe only with your approval |
| R5 | Agile delivery | must_have | unclear | low | discovery | CV silent on sprints or cadence | `[grounded]` CV silence | Q2 |
| R6 | Own the API roadmap | important | adjacent | medium | transferability | Ran quarterly roadmap-input sessions; did not own the roadmap | `[grounded]` CV; `[inferred]` adjacency | Q1 |
| R7 | Partner discovery | important | direct | medium | presentation | Scoping workshops and requirements work with clients are discovery | `[grounded]` CV; `[inferred]` mapping | none |
| R8 | Write specs and drive delivery with engineering squads | important | adjacent | medium | transferability | Requirements documents and coordination on custom builds; not squad priorities | `[grounded]` CV | Upgrade menu item 1 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | CV silent on metrics. An unconfirmed memory lead exists (see Q3) | `[grounded]` CV silence | Q3 |
| R10 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Go-live and UAT for clients; internal sales and support not evidenced | `[grounded]` CV; `[inferred]` adjacency | Q3 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not verified | unknown | — | Role "Product Manager, Platform APIs — Quartzline" | Not checked. The posting may be stale or aggregated, or the employer may be too new to have a footprint | `[generic]` pattern for companies this size, not a claim about this one | Can you point me to this role on Quartzline's own careers page, and who would I interview with? | unresolved |
| RR2 | Pay, location and contract unstated | unknown | — | No salary or location in the JD | Pay may sit below the market band; the posting may simply not publish it | `[inferred]` from the JD's silence | What is the budgeted base range, and is the role remote, hybrid or on-site? | unresolved |
| RR3 | Scope and metric ownership defined | positive_signal | — | "define and track adoption metrics" | Role has concrete outcomes and owned measures | `[grounded]` JD | Does this role set the roadmap alone, or do product leads sign it off? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the posting on Quartzline's own careers page before you invest effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Seek a referral to a Quartzline employee | Referrals tend to get past literal years filters | `[generic]` hiring pattern | pending your approval |
| A3 | Before you apply, prep the screen with the mock-interview module | It handles the years question | — | pending your approval |

On positioning: any line you use for R1 or R2 must describe what you did, not product ownership. Anything proposed for your CV or outreach is pending your approval.

## Evidence status

Verified: none yet. Every claim above is your CV self-report, not probed. The request-triage tool from prior context is a memory lead, unconfirmed, and it is not evidence.

## Upgrade menu

- A web-search permission lets the two skipped checks run: the posting (RR1) and the market band for this title (RR2).
- The integration playbook you wrote, shared at a high level, is an inspectable artifact. It would raise R8 and R4 toward `high`.
- A roadmap-input summary or launch plan from a client engagement would raise R6 and R10.
- The budgeted salary and location would close RR2.

I can also save this analysis as a `tuesday-dossier.md` file with the full map and register, if you want to keep it.

## Questions

Q1 (R1, R6, R8): Have you ever decided what got built: owned a backlog, prioritized features, or made a roadmap call that engineering shipped? Give one example: what you decided, who agreed, and what shipped.

Q2 (R5): How did you work with engineering day to day (sprints, planning, ticketing), and did you run that cadence or join someone else's?

Q3 (R9, R10): Did you build an internal request-triage tool that support agents adopted? If so, what did you decide to build, who used it, and how did you know it worked?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.