# Job underwriting: Head of Growth at Novaline

**No, not as posted. Both of your hard constraints fail: R1 (base pay) and R2 (location). Status: `no_go`.**

- **Fit ledger.**
  - `hard_gate` — hard_gate_fail: R1 (base pay, $70–85k posted), R2 (on-site Austin five days a week)
  - `must_have` — direct: R3 (8+ years growth leadership), R4 (paid acquisition), R5 (lifecycle/CRM), R6 (budget-controlled revenue growth) · unclear: R7 (SEO/content), R8 (brand and PR), R9 (partnerships and sales ops)
  - `important` — unclear: R10 (running with no bench), R11 (thriving on ambiguity)
  - `preferred` — adjacent: R12 (e-commerce enablement); direct: R13 (SQL, GA4, Braze)

  Your experience clears the must-haves on paper. R1 and R2 are the reason for `no_go`: the posting states both terms as fixed, and neither depends on fit.
- **Opportunity ledger.** RR5 is a severe red flag: "on-site five days a week, no exceptions" conflicts with your remote-only requirement. RR2 is a pay mismatch: $65–80k below your floor, with the market band not checked. RR1, RR3 and RR4 are risk signals: one person carries the full remit, always-on hours are expected, and success metrics are undefined. RR6 is a positive signal: the CEO reporting line with a board dotted line. RR7 is unknown: I could not verify that Novaline or this posting exists as described.
- **Hard gates:** failed: R1 (base pay, $70–85k posted), R2 (on-site Austin five days, no exceptions); unconfirmed: none; met: none.
- **Severe red flags:** RR5 (`severity: high`).
- **What would change this:** the employer would need to offer remote work and a base of $150k or more. That would be a different role, not a negotiation.

Your "something feels off" has a concrete basis. The pay is roughly half your floor, the role is in Austin, and the posting describes always-on work with no defined success criteria.

**Research tier: L1 — searches 2 of 5, fetches 0 of 2.** Both searches were refused by permission, so this assessment rests on the posting and your stated constraints only.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting; profitability is the employer's own claim, unverified |
| Mandate | Own all revenue growth end to end: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Resources | "A team of one to start" | `[grounded]` posting |
| Reporting | CEO, with a dotted line to the board | `[grounded]` posting |
| Working pattern | On-site Austin five days a week, no exceptions; evenings and weekends "when it matters" | `[grounded]` posting |
| Pay | $70–85k base plus equity | `[grounded]` posting |
| Pay against your floor | $65–80k below your $150k minimum | `[grounded]`, arithmetic on the two stated figures |
| Market calibration | Not run; the role-family search was refused. No band is asserted | — |
| Unknowns | Employer existence; posting is live; equity terms; which functions get budget or headcount | — |
| Contradictions | Seven listed functions against one person to start | `[inferred]` from the scope list against "team of one" |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay, $70–85k posted | hard_gate | hard_gate_fail | high | hard_gate | Your stated floor is $150k base, specific and your own; the posting's range sits below it | `[grounded]` posting and your constraint | Surfaced in snapshot; only the employer changing the range resolves it |
| R2 | Remote-only, Portland | hard_gate | hard_gate_fail | high | hard_gate | Your stated requirement is remote-only; the posting says on-site Austin five days, no exceptions | `[grounded]` posting and your constraint | Surfaced in snapshot; only the employer changing terms resolves it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, growth lead then head at two companies; self-reported, not inspected | `[grounded]` your background | none |
| R4 | Paid acquisition | must_have | direct | medium | none | Owned paid, self-reported | `[grounded]` your background | none |
| R5 | Lifecycle and CRM | must_have | direct | medium | none | Owned lifecycle; deep in Braze, self-reported | `[grounded]` your background | none |
| R6 | Revenue growth end to end | must_have | direct | medium | none | $8M to $40M ARR over three years with a budget you controlled, self-reported | `[grounded]` your background | none |
| R7 | SEO and content | must_have | unclear | low | discovery | Not mentioned in your background | `[grounded]` silence | Ask whether you have owned it |
| R8 | Brand and PR | must_have | unclear | low | discovery | Not mentioned in your background | `[grounded]` silence | Ask whether you have owned it |
| R9 | Partnerships and sales ops | must_have | unclear | low | discovery | Not mentioned in your background | `[grounded]` silence | Ask whether you have owned it |
| R10 | Running with no bench | important | unclear | low | discovery | You built and managed teams of 3–7; a solo start is untested | `[grounded]` your background | Ask about solo-operator work |
| R11 | Thriving on ambiguity | important | unclear | low | discovery | No evidence either way | `[grounded]` silence | Ask for a concrete example |
| R12 | E-commerce enablement | preferred | adjacent | medium | transferability | B2C subscription work carries over; the limit is no enablement-software experience | `[inferred]` from your background | Name the limit in any application |
| R13 | SQL, GA4, Braze | preferred | direct | medium | none | Stated, specific, self-reported | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Would close it | Provenance |
|---|---|---|---|---|---|---|
| G1 | SEO, brand, PR, partnerships, sales ops (R7–R9) | discovery | Your background does not mention these | Together they make up most of the mandate | Evidence you have owned any of them | `[grounded]` silence |
| G2 | Solo operation and ambiguity (R10–R11) | discovery | No evidence either way | The posting makes both central | A concrete example of building without a team | `[grounded]` silence |

The queue holds no questions. Neither gap changes the `no_go`, so I am not asking them this turn.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Responsibility without resources | risk_signal | medium | "a team of one to start — we believe in players who don't need a bench" | Accountable for the full remit with no budget or headcount behind it | `[inferred]` from the scope list against the team-of-one line | Which of these functions get budget or headcount in year one? | unresolved |
| RR2 | Pay against seniority and scope | risk_signal | medium | "$70–85k base" | Pay may sit well below market for this scope; market band not checked | `[generic]` pattern for roles of this kind; no market data retrieved | What base range is budgeted for this role? | unresolved |
| RR3 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Work hours are open-ended | `[grounded]` posting wording | How often does "when it matters" happen in a typical quarter? | unresolved |
| RR4 | Success metrics undefined | risk_signal | medium | "success metrics will evolve as we learn" | Accountability without a defined bar | `[grounded]` posting wording | What would you need to see in the first 90 days for this to count as success? | unresolved |
| RR5 | On-site against remote-only | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | Incompatible with your stated remote-only requirement (R2) | `[grounded]` posting and your constraint; see R2 | Is any remote arrangement available, in writing? | confirmed |
| RR6 | CEO reporting line, board dotted line | positive_signal | — | "Report to the CEO with a dotted line to the board" | Clear authority line | `[grounded]` posting | Who sets the budget for this role? | noted |
| RR7 | Employer and posting unverified | unknown | — | "Novaline (e-commerce enablement startup, Series A)" | Research could not confirm the employer or the posting | `[grounded]` research unavailable | Which page on your careers site lists this role, and who would I interview with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Do not apply on the posted terms | R1 and R2 are both stated as fixed | `[grounded]` posting against your constraints | pending your approval |
| P2 | If you want to keep the lead open, check the posting on Novaline's own careers page before any contact | RR7 | `[grounded]` research unavailable | pending your approval |

## Evidence status

Verified: R1 and R2 (your own stated constraints, at high confidence). Everything else is self-reported background: leads, not proof.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search for Novaline was refused by permission. It would have checked that the employer exists and the posting is live (RR7) |
| 2. Role-family sweep | unavailable | Search for Head of Growth pay was refused by permission. It would have set the market band for RR2 and the scope read |
| 3. Hiring manager's public footprint | n/a | No name given, so there was no query to form |

## Upgrade menu

- A link to the live posting or Novaline's careers page → RR7 closes. The decision stays `no_go`.
- A working role-family pay search → sets the market band for RR2. The decision stays `no_go`, because R1 is a gate.
- Evidence of SEO, brand, PR, partnerships or sales-ops work → R7–R9 move off unclear.
- Deeper company diligence (funding, leadership churn, recent news; up to 5 more searches and 2 more fetches) → it would check Novaline's stability, but it cannot clear either gate. Say the word and it runs.

If you want this kept, I can write a `tuesday-dossier.md` for it that a later session can read.

No questions this turn: the decision is already stable, and the open gaps cannot change it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.