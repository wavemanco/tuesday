**Yes, it's worth applying, on conditions: `conditional_go`.** Your must-haves are covered on the evidence you gave. The one real gap is BigQuery, and it is recoverable. Three things need checking before you invest: your location, your pay floor, and whether the posting is live.

**Fit ledger.**

- `hard_gate`: unclear: R1 (remote US or Denver office), R2 (base salary $148,000–$166,000)
- `must_have`: direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R7 (orchestration with Airflow or similar), R8 (data quality testing)
- `important`: adjacent: R6 (BigQuery warehouse); unclear: R9 (ingestion from app and CRM, data contracts)

R6 — a credible bridge from Snowflake, its limit named; R9 — the CV is silent, one question resolves it.

**Opportunity ledger.** The pay sits around the market median (RR3, positive). The posting names no hiring manager and leaves equity unspecified (RR1, RR2). The employer and posting could not be checked, because the search was refused (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver office), R2 (base salary $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) your location fits R1; (2) $148,000 clears your pay floor (R2); (3) the posting is live on Pellucid's own careers page (RR4); (4) the BigQuery gap is framed as adjacent, not as experience (R6).
- **What would change this:** a failed location or pay gate would make it `no_go`. Confirmed BigQuery use would move R6 toward direct.

**Research tier: L1 — searches 2 of 5, fetches 0 of 2**

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states, founded 2016, 264 employees, Series C ($52M, Feb 2026) | `[grounded]` your pasted About page; not checked by search |
| Scope | Pipelines for reporting, ingestion from app and CRM, a BigQuery dbt warehouse, data contracts for analysts | `[grounded]` JD |
| Seniority | Your 6 years sits in the 5–8 years the report gives for "Senior" | `[generic]` Datawright 2026, US, n=2,310, from your recruiter |
| Market calibration | Stated $148k–$166k: the report's median is $151k and its IQR is $139k–$163.5k, so the range sits at median-plus with the top slightly above the IQR. The basis is one supplied survey, not a search | `[generic]` |
| Unknowns | Hiring manager, equity terms, location eligibility, whether the posting is live | — |
| Contradictions | None between the JD and the About page you pasted | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location isn't stated, so the gate is not established | `[grounded]` JD | Q1 |
| R2 | Base $148,000–$166,000 against your floor | hard_gate | unclear | none | hard_gate | Your floor isn't stated; the posted range is the JD's | `[grounded]` JD | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, self-reported; expect a probe | `[grounded]` CV | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported, no artifact | `[grounded]` CV | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project on Snowflake, ~180 models; Snowflake is a cloud warehouse | `[grounded]` CV | none |
| R6 | BigQuery warehouse (named in role) | important | adjacent | medium | transferability | dbt and SQL carry over; no BigQuery use stated. Limit: no BigQuery-specific work claimed | `[inferred]` from R5 | G1, Q3 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow orchestration, self-reported | `[grounded]` CV | none |
| R8 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite | `[grounded]` CV | none |
| R9 | Ingestion from app and CRM; data contracts | important | unclear | low | discovery | The CV names neither sources nor contracts | `[grounded]` CV silence | G2 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6) | transferability | Snowflake dbt work; no BigQuery mentioned | The role names the warehouse; this is the most likely objection | Any BigQuery query, sandbox, migration plan, or cost review | A sanitized model or query | `[inferred]` bridge from R5; `[generic]` that the SQL and dbt skills carry over |
| G2 | Ingestion and data contracts (R9) | discovery | CV silent on sources and contracts | Part of the stated scope, not yet evidenced | Pipelines pulling from product or CRM systems; schema agreements with consumers | A DAG outline or a contract doc | `[grounded]` CV silence |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | No hiring manager named | unknown | — | (posting names none) | Ownership of the team may be unclear | `[inferred]` from the posting's silence | Who would I report to, and how big is the team? | unresolved |
| RR2 | Equity unspecified | unknown | — | "plus equity" | Value may be hard to judge without terms | `[inferred]` from the posting's silence | What is the equity grant size, vesting schedule and valuation basis? | unresolved |
| RR3 | Pay within market band | positive_signal | — | "$148,000–$166,000" | Pay is competitive for this seniority | `[generic]` band from the supplied report | Is this range set for this level, and is it the budgeted figure? | noted |
| RR4 | Employer and posting not verified | unknown | — | the posting's own text | Not checked: search refused, so this is unverified, not a finding | `[generic]` pattern for companies of this size | Is this role open now, and is your careers page the place to apply? | unresolved |
| RR5 | Stated scale and funding | positive_signal | — | "Series C ($52M, February 2026)" | Established and funded, if the About page is accurate | `[grounded]` your pasted About page | How many data roles are open, and how large is the data team? | noted |

**Severe red flags:** none found. Nothing in the posting asks you to pay, deposit, or give bank details.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Apply through the employer's own careers page, after confirming the role is live | RR4 | `[generic]` standard practice | pending your approval |
| A2 | Keep the CV's wording on Snowflake and dbt; do not add BigQuery | R6; no new claims | `[grounded]` CV | pending your approval |
| A3 | In the cover note, say plainly you have not used BigQuery and your warehouse work is on Snowflake | R6 limit | `[grounded]` R6 | pending your approval |

**Evidence status.** Verified: none yet. Everything above rests on your prose background and the posting. Your answers to the questions below would change that.

**Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were sent (the company, and the role). Both were refused by a permission prompt and I did not retry. Would have checked RR4 and whether the employer exists as described |
| 2. Role-family sweep | skipped | The supplied Datawright report already fixes the market calibration for this seniority |
| 3. Hiring manager's public footprint | n/a | No name was given |

**Dossier offer.** If you want, I can write this assessment to a `tuesday-dossier.md` file so later work can reuse it.

**Upgrade menu**

- Permission for the two searches → resolves RR4 and checks the company and posting against the About page you pasted.
- The live posting URL from Pellucid's careers page → RR4 closes.
- Your location and your pay floor → R1 and R2 move to `direct` or `hard_gate_fail`.
- Any BigQuery exposure, however small → R6 moves toward `direct`.
- A sanitized dbt model or query from the Snowflake work → R5 rises from `medium` to `high`.
- The hiring manager's name → positioning for the interview.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

1. **R1:** Are you eligible to work remotely in the US, or could you work from the Denver office?
2. **R2:** Is a base of $148,000 above your floor?
3. **R6:** Have you used BigQuery at all, such as a sandbox, a side project, a migration, or a cost review? If so, what did you own?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.