Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-2-rooms-case-7-canned-426846c7/43a8f8f7-bac8-4d72-82cc-b2e0d00e827a/scratchpad/Saltmarsh_Games_live-operations-producer_interview_pack.md`. I built it on a hiring-manager round, since your note doesn't say who you're meeting. I did no research, so everything about Saltmarsh itself is unverified.

# Live Operations Producer, Saltmarsh Games: Interview Pack for Femi

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be **hiring manager**; not yet confirmed.
**Format:** 60 minutes, Friday. Session mode, one round.
**Research tier:** L0. No search or fetch was run.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **JD** = stated job requirement. **EXP** = a deep-dive on something you did. **CASE** = a live problem from the role. (No VAL or CO questions: no values were provided and research did not run.)
- Guidance is scaffolding, not a script. Say it in your own words.
- Provenance labels: **[grounded]** = traceable to your message or the JD you gave me. **[inferred]** = my derivation. **[generic]** = a pattern, not a fact about you or this employer.

## Fit snapshot

Requirements come from the JD text you supplied. Your evidence is quoted from your message. No CV was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | The material shows one title, on a weekly drop cadence, for two years. Two titles at once is not in it. Words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you have planned for more than one title at a time, say how; if you have not, say so and say how you would split one calendar across two titles. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | This quote already reaches the requirement. Lead with the calendar in its own terms, and expect a probe on what it contained (see C3). |
| F3 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show you coordinating design, art, engineering or community on an update. Answer slot: if you did this on any update, name the teams and the update in your own words; if you did not, say so plainly and say how you would set up the handoffs between those four teams. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you wrote the checklist and QA still uses it. Words: "I wrote the release checklist our QA team still uses." Day-to-day management with QA is not stated, so this row gets no slot. |
| F5 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [grounded] | transferability | Presenting numbers is adjacent to owning a review and its KPIs. Your material does not show you set the KPIs or ran a post-event review. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which KPIs went into that presentation, or ran any review after an event, say what you did; if you did not, say so plainly. |
| F6 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you handled monthly retention numbers and presented them. Words: "I presented the monthly retention numbers to the studio head." No figure was given, so no defend-the-number slot is raised here (see C1). |
| F7 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [grounded] | presentation | The checklist is one written document other people use. Your material shows no other writing. Words: "I wrote the release checklist our QA team still uses." Bring a written sample if you have one (see the upgrade menu). |
| F8 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | low | [grounded] | hard_gate | Your material does not establish this gate. "Associate producer" is not "producing", and a puzzle game is not named as live-service. Surfaced here, not bridged. The closing questions ask about it. |
| F9 | Leading a team. Not in the JD text, which asks you to coordinate. [generic] | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | A stated negative, kept as stated. Words: "I haven't led a team." Then how you would learn to coordinate people without managing them, said as a plan. Never a claim to have led anyone. |
| F10 | Monetisation experience. Not in the JD text. [generic] | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | A stated negative, kept as stated. Words: "I haven't worked on a game with in-app purchases." Then how you would learn a title's monetisation model, said as a plan. The JD does not ask for it, so a probe is possible but not certain. |

**Reading the map.** Your strongest rows are F1 and F2 (the calendar) and F4 (the checklist). The weakest is F5, owning the KPIs, which is the JD's headline ownership line. F8 is a gate the material does not show, and the closing questions ask you about it.

## Prohibited claims

Built locally from the fit snapshot. These are the claims you are likely to reach for under pressure. None will be coached.

| Not coached | Basis | Honest form |
|---|---|---|
| I ran live operations for two titles. | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title for the last two years." Limit, as my observation: your material says one title, not two. |
| I owned the post-event review and the KPIs. | Inflated form of F5 | "I presented the monthly retention numbers to the studio head." Limit, as my observation: your material says you presented the numbers. |
| I managed the release checklist with QA. | Inflated form of F4 | "I wrote the release checklist our QA team still uses." |
| I have led a team. | Stated negative, F9 | "I haven't led a team." |
| I have in-app purchase or monetisation experience. | Stated negative, F10 | "I haven't worked on a game with in-app purchases." |

Not listed, and handled as an answer slot instead: coordinating design, art, engineering and community on an update (F3). Your material is silent on it, so the pack asks you to answer from your own experience.

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A live problem on the calendar: plan two titles, or handle a release that is in trouble | **High.** A hiring manager buys capability and runs a live problem on their own roadmap. The JD is mostly about a calendar and a release process. | Clarify first, then structure, then name the metric you would watch. Say your assumptions out loud. |
| Skeptic | Probes the gaps: one title, not two; presented, not owned; never led a team; no in-app purchases | **High.** The JD's headline asks (own the KPIs, coordinate four teams, two titles) sit where your material is thinnest, and your own message names two of the gaps. | Rehearse the most predictable objection until it is plain. Use only what you have stated. Name the gap yourself, then give a concrete plan. |
| Data-Driven Prober | Asks how the retention number was counted and what it is sensitive to | **Medium.** You presented a retention figure, and the JD asks you to be comfortable with retention metrics. | Know what you can and cannot say about how the figure was counted. Say so plainly when you do not know. |
| Conversational / Rapport | An easy opener, then a casual question on a JD topic | **Medium.** This is usually the first five minutes. Casual questions are still scored. | A 90-second arc. Answer a casual retention question with the same care as a scored one. |
| Pressure | Interrupts, time-boxes, asks "how much of that was actually you?" | **Low to medium.** A 60-minute Head-level round can include one hard challenge. | Pause, restate the question, hold your sentence through two follow-ups, then concede the specific thing you do not know. |

**Weights.** Case / Strategist and Skeptic at 5 questions each. Data-Driven Prober at 4. Conversational and Pressure at 2 each. If Tobias is a peer, the weights change.

## The sixty-minute shape

You asked for this. It is a typical shape for a hiring-manager round, not Saltmarsh's known format, which I could not verify.

| Minutes | Block | Questions |
|---|---|---|
| 0 to 5 | Opener and journey | D1 |
| 5 to 20 | Your record against the JD: calendar, checklist, retention | C1, C3, C4, D2, A4 |
| 20 to 35 | Skeptic: gaps and ownership | A1, A2, A3, A5 |
| 35 to 50 | Live problems on the calendar and releases | B1, B2, B3, B4, B5 |
| 50 to 55 | Pressure, if it comes | E1, E2 |
| 55 to 60 | Your questions | R1 to R5 |

## Question banks

### Bank A: Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I haven't led a team." and "I haven't worked on a game with in-app purchases." | Name the two gaps in your own words, then a plan for each, starting in the first month. Do not add to either sentence. | F9 and F10 are the stated negatives. This is the honest self-assessment the Skeptic scores. |
| A2 | "You'd be coordinating design, art, engineering and community on every update. What have you done like that?" | JD | [grounded] | Answer slot: if you coordinated any of those teams on an update, name the team and the update in your own words. If you did not, say so plainly and describe how you would set up handoffs between the four teams. | F3 is silent in your material, so this is the honest answer. Expect the question. |
| A3 | "You presented the retention numbers. Did you own the KPIs they reported?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | **Highest-ROI prep in this pack.** This is the JD's headline ownership line, pressed against your thinnest evidence. Hold the sentence through two follow-ups: "I presented the monthly retention numbers to the studio head." Do not add to it. Answer slot: if you chose which KPIs went in, or how they were counted, say so; if you did not, say that, and say what you did with the numbers. | F5 is the requirement most likely to be probed. The honest version is rehearsed before the probe arrives. |
| A4 | "What did you run on the calendar, week to week?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-map from the quote: the weekly cadence, the main title, the two years. Answer slot: if any calendar decision was yours to make, say which and why; if the calendar was set by others, say so and describe what you ran. | F2 is a line the JD's calendar requirement reaches. The question asks what it contained, which is where a Skeptic tests it. |
| A5 | "Your retention numbers went to the studio head. How would you know a content drop moved them?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you ever separated one drop's effect from the rest of a month's movement, say how; if you did not, say so and say how you would set up that comparison before the next event. | F6 and F5 both point here. The honest answer is the plan, not a method you did not use. |

### Bank B: Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Plan the next six weeks of live events for two titles. What do you need to know first?" | CASE | [grounded] (JD line: "Plan and run the live-events calendar for two of our mobile titles") | Clarify first: each title's current KPIs, its monetisation model, team capacity, QA windows and community commitments. Then structure: the calendar as the fixed spine, one event per title per window, and freeze dates. Name the retention metric you would watch. Say each assumption out loud. | This is the JD's core task as a live problem. The clarify-first habit is what the Case persona scores. |
| B2 | "You're handed a title you have never played, with an event due in three weeks. How do you start?" | CASE | [generic] | Start with the title's last three events and their results. Then ask what its revenue model is before you plan any offer. Name what you would not change until you have the data. | This is the monetisation gap in live form. It presumes nothing about your past. |
| B3 | "A content drop is two days out and QA has failed a build. Walk me through the call." | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Structure: what the checklist says about a fail, who owns the go or no-go, what slips and what does not, and who you tell. Answer slot: if you have made or shared a go or no-go call, say what you weighed; if the call sat with someone else, say so and say what you would bring to them. | F4 is the checklist, and the JD asks for release management with QA. The slot keeps the decision where your material puts it. |
| B4 | "Design wants an event reward that the community team thinks players will hate. Engineering says it cannot ship in time. How do you decide?" | CASE | [generic] (JD line: "coordinate design, art, engineering and community teams on each update") | Name the four teams' stakes, the player harm, the KPI at risk, and the date. Decide with a stated owner. Write down what was agreed. | The JD's coordination line, as a conflict. It is a pattern for the problem, not a fact about you. |
| B5 | "Your post-event review says an event beat its target but lost players on day seven. What goes in the write-up?" | CASE | [generic] (JD line: "own the post-event review and the KPIs it reports") | Lead with the result that matters. Name the cohort split, the metric you trust least, and what you would test next. State what the review cannot prove. | The post-event review is the JD's ownership line, asked as a judgment rather than a record. |

### Bank C: Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention number was counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you know how it was counted, walk the steps in your own words. If you did not calculate it, say so, say who did, and say what you checked before you presented it. Weakest-assumption move: name the assumption you would defend least, if you know one. If you do not know how it was counted, say that. | F6 is the figure you presented. Every headline number gets a defend-the-number question. |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Name the assumption in your own words, before the interviewer does. If you do not know the assumption, say you do not know. | F6 again. This is the second follow-up a Prober asks, and the honest answer is a named limit. |
| C3 | "You ran a weekly content-drop calendar for two years. What did it contain, and what was left out?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-map from the quote: the weekly cadence, the main title, the two years. Answer slot: say which items you chose and which were set by others, in your own words. | F2 is the calendar line. A Prober asks for the denominator: how many drops, what share of them were yours. |
| C4 | "Who uses your release checklist now, and what would you change in it first?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Say who uses it and what for, in the quote's terms. Answer slot: if QA has asked for changes, name one; if not, say what you would change first and why. | F4 and F7: the checklist is a written artifact still in use. A Prober tests whether it is still yours. |

### Bank D: Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | A 90-second arc: the puzzle studio, the associate producer role, the weekly calendar, the checklist, the retention presentations. End on why live operations at Saltmarsh. | The opener is scored for economy. The arc is the one you will reuse in other answers. |
| D2 | "What are you doing with player-retention metrics these days?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you still work with retention numbers, name what you look at; if not, say so and name the retention source you would look at first in this role. | F6 is the retention requirement. A casual question about a JD topic is still scored. |

### Bank E: Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we pick you over someone who has led a team?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pause. Restate the question. Hold on what your material shows: "I ran the weekly content-drop calendar for our main title for the last two years." After two follow-ups, concede the specific gap: "I haven't led a team," and say how you would learn to coordinate without managing. | F9 is the gap, and the honest answer is the hold-then-concede structure. |
| E2 | "That presentation: how much of the retention result was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Pause. Answer slot: if you did any of the analysis behind the numbers, say which part; if you presented numbers someone else built, say that. Hold the sentence through two follow-ups. Concede the specific thing you did not do. | F5 and F6 again. The answer is the honest one, given under pressure. |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A4, B1, B2, C3 |
| Coordinate design, art, engineering and community teams on each update | A2, B4 |
| Own the post-event review and the KPIs it reports | A3, A5, B5, C1, C2 |
| Manage the release checklist with QA | B3, C4 |
| 3+ years producing live-service games or apps | none in the banks. The gate is a closing question for you to answer. |
| Experience running a content calendar | A4, C3, D1 |
| Comfortable with player-retention metrics | C1, C2, D2, E2 |
| Clear written communication | C4. A written sample would strengthen this (upgrade menu). |

**Highest-ROI prep:** A3. Practise holding "I presented the monthly retention numbers to the studio head", and give the honest answer to "did you own the KPIs?"

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first ninety days look like for whoever takes the calendar across both titles?" | It shows you are planning to own the calendar, not just to join it. |
| R2 | "Which of the two titles is the bigger calendar problem right now, and what is driving it?" | It asks for the real constraint and shows you read the JD as a set of trade-offs. |
| R3 | "How is the post-event review run today: who writes it, and who owns the KPIs it reports?" | It goes straight to the JD's ownership line, and the answer tells you where the role sits. |
| R4 | "How are in-app purchases handled across the two titles, and who makes the monetisation calls on an event?" | It tests whether monetisation is part of this role, which the JD does not say. |
| R5 | "What would you want me to have done by the end of the first month?" | It turns the conversation into a shared plan and gives you a measurable target. |

No reverse question is tied to Tobias's own career path, because there is no profile to read. Reciprocity is not asked, since the assumed relationship is hiring manager, not peer.

## Sources

- **Provided documents:** your message, containing the JD text and your background. No CV was supplied.
- **Searches and fetches:** none. Research tier L0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet. Not included, since no values were provided and no values-style round is detected. |
| 2. Saltmarsh Games interview process, live operations | unavailable | Loop structure and persona weights. Weights here rest on the assumed relationship, not on the loop. |
| 3. Saltmarsh Games strategy and recent news | unavailable | Company knowledge questions and a grounding brief. The banks have none, so company-specific questions are missing. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Reading the interviewer, persona weights, and a reverse question tied to his path. |
| 5. Representative live-operations JD | skipped | The JD you supplied already fixes the fit snapshot. |

## Upgrade menu

- Confirm whether Tobias is your future manager or a peer → persona weights recomputed for the actual relationship
- Allow a research pass on Saltmarsh's values, interview process and recent news → company-specific questions, a values cheat sheet if values are published, and a grounding brief
- Tobias Wrenfield's public profile or talks → a persona reading, and a reverse question tied to his career path
- A CV or written sample → F5, F7 and F9 move from your message quotes to CV quotes, and the written-communication row gets its evidence
- Time you have before Friday → a prioritised prep schedule, tied to question IDs

---

Two quick things before you rehearse:

- Drill: I can play the Skeptic on A3, the highest-ROI question, and give feedback against its guidance.
- Dossier: I can save a `tuesday-dossier.md` recording the gaps this prep exposed, so they carry into later sessions.

Is Tobias your future manager, or a peer on the team? The answer changes the weights.

Does your puzzle title count as live-service in the sense Saltmarsh means it, a game you shipped content to on a recurring schedule? That decides whether your 3-year requirement reads as met.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh_Games_live-operations-producer_interview_pack.md -----
# Live Operations Producer, Saltmarsh Games: Interview Pack for Femi

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be **hiring manager**; not yet confirmed.
**Format:** 60 minutes, Friday. Session mode, one round.
**Research tier:** L0. No search or fetch was run. Everything about Saltmarsh Games itself is unverified and marked as such below.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **JD** = stated job requirement. **EXP** = a deep-dive on something you did. **CASE** = a live problem from the role. **VAL** = values (none detected here). **CO** = company knowledge (none here, since research did not run).
- Guidance is scaffolding, not a script. Say it in your own words.
- Provenance labels: **[grounded]** = traceable to your message or the JD you gave me. **[inferred]** = my derivation. **[generic]** = a pattern, not a fact about you or this employer.

## Fit snapshot

Requirements come from the JD text you supplied. Your evidence is quoted from your message. Nothing here is from a CV.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | The material shows one title, on a weekly drop cadence, for two years. Two titles at once is not in it. Words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you have planned for more than one title at a time, say how; if you have not, say so and say how you would split one calendar across two titles. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | This quote already reaches the requirement. Lead with the calendar in its own terms, and expect a probe on what it contained (see C3). |
| F3 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show you coordinating design, art, engineering or community on an update. Answer slot: if you did this on any update, name the teams and the update in your own words; if you did not, say so plainly and say how you would set up the handoffs between those four teams. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you wrote the checklist and QA still uses it. Words: "I wrote the release checklist our QA team still uses." Day-to-day management with QA is not stated, so this row gets no slot. |
| F5 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [grounded] | transferability | Presenting numbers is adjacent to owning a review and its KPIs. Your material does not show you set the KPIs or ran a post-event review. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which KPIs went into that presentation, or ran any review after an event, say what you did; if you did not, say so plainly. |
| F6 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you handled monthly retention numbers and presented them. Words: "I presented the monthly retention numbers to the studio head." No figure was given, so no defend-the-number slot is raised here (see C1). |
| F7 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [grounded] | presentation | The checklist is one written document other people use. Your material shows no other writing. Words: "I wrote the release checklist our QA team still uses." Bring a written sample if you have one (see the upgrade menu). |
| F8 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | low | [grounded] | hard_gate | Your material does not establish this gate. "Associate producer" is not "producing", and a puzzle game is not named as live-service. Surfaced here, not bridged. The closing questions ask about it. |
| F9 | Leading a team. Not in the JD text, which asks you to coordinate. [generic] | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | This is a stated negative, and the pack keeps it. Words: "I haven't led a team." Then how you would learn to coordinate people without managing them, said as a plan. Never a claim to have led anyone. |
| F10 | Monetisation experience. Not in the JD text. [generic] | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | This is a stated negative, and the pack keeps it. Words: "I haven't worked on a game with in-app purchases." Then how you would learn a title's monetisation model, said as a plan. The JD does not ask for it, so a probe is possible but not certain. |

**Reading the map.** Two rows are your strongest: F1 and F2, the calendar, and F4, the checklist. The weakest is F5, owning the KPIs, which is the JD's headline ownership line. F8 is a gate the material does not show, and the closing questions ask you about it.

## Prohibited claims

Built locally from the fit snapshot. These are the claims you are likely to reach for under pressure. None of them will be coached.

| Not coached | Basis | Honest form |
|---|---|---|
| I ran live operations for two titles. | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title for the last two years." Limit, as my observation: your material says one title, not two. |
| I owned the post-event review and the KPIs. | Inflated form of F5 | "I presented the monthly retention numbers to the studio head." Limit, as my observation: your material says you presented the numbers. |
| I managed the release checklist with QA. | Inflated form of F4 | "I wrote the release checklist our QA team still uses." |
| I have led a team. | Stated negative, F9 | "I haven't led a team." |
| I have in-app purchase or monetisation experience. | Stated negative, F10 | "I haven't worked on a game with in-app purchases." |

Not listed, and handled as an answer slot instead: coordinating design, art, engineering and community on an update (F3). Your material is silent on it, so the pack asks you to answer from your own experience.

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A live problem on the calendar: plan two titles, or handle a release that is in trouble | **High.** A hiring manager buys capability and runs a live problem on their own roadmap. The JD is mostly about a calendar and a release process, so the problems will be of that kind. | Clarify first, then structure, then name the metric you would watch. Say your assumptions out loud. |
| Skeptic | Probes the gaps: one title, not two; presented, not owned; never led a team; no in-app purchases | **High.** The JD's headline asks (own the KPIs, coordinate four teams, two titles) sit where your material is thinnest, and your own message names two of the gaps. | Rehearse the most predictable objection until it is plain. Use only what you have stated. Name the gap yourself, then give a concrete plan. |
| Data-Driven Prober | Asks how the retention number was counted and what it is sensitive to | **Medium.** You presented a retention figure to the studio head, and the JD asks you to be comfortable with retention metrics. | Know what you can and cannot say about how the figure was counted. Say so plainly when you do not know. |
| Conversational / Rapport | An easy opener, then a casual question on a JD topic | **Medium.** This is usually the first five minutes. The casual questions are still scored. | A 90-second arc. Answer a casual retention question with the same care as a scored one. |
| Pressure | Interrupts, time-boxes, asks "how much of that was actually you?" | **Low to medium.** A 60-minute Head-level round can include one hard challenge. | Pause, restate the question, hold your sentence through two follow-ups, then concede the specific thing you do not know. |

**Weights.** Case / Strategist and Skeptic at 5 questions each. Data-Driven Prober at 4. Conversational and Pressure at 2 each. The relationship is assumed, so the weights would change if Tobias is a peer.

## The sixty-minute shape

You asked for this. It is a typical shape for a hiring-manager round, not Saltmarsh's known format, which I could not verify.

| Minutes | Block | Questions |
|---|---|---|
| 0 to 5 | Opener and journey | D1 |
| 5 to 20 | Your record against the JD: calendar, checklist, retention | C1, C3, C4, D2, A4 |
| 20 to 35 | Skeptic: gaps and ownership | A1, A2, A3, A5 |
| 35 to 50 | Live problems on the calendar and releases | B1, B2, B3, B4, B5 |
| 50 to 55 | Pressure, if it comes | E1, E2 |
| 55 to 60 | Your questions | Reverse questions R1 to R5 |

## Question banks

### Bank A: Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I haven't led a team." and "I haven't worked on a game with in-app purchases." | Name the two gaps in your own words, then a plan for each, starting in the first month. Do not add to either sentence. | F9 and F10 are the stated negatives. This is the honest self-assessment the Skeptic scores. |
| A2 | "You'd be coordinating design, art, engineering and community on every update. What have you done like that?" | JD | [grounded] | Answer slot: if you coordinated any of those teams on an update, name the team and the update in your own words. If you did not, say so plainly and describe how you would set up handoffs between the four teams. | F3 is silent in your material, so this is the honest answer. Expect the question. |
| A3 | "You presented the retention numbers. Did you own the KPIs they reported?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | **Highest-ROI prep in this pack.** This is the JD's headline ownership line, pressed against your thinnest evidence. Hold the sentence through two follow-ups: "I presented the monthly retention numbers to the studio head." Do not add to it. Answer slot: if you chose which KPIs went in, or how they were counted, say so; if you did not, say that, and say what you did with the numbers. | F5 is the requirement most likely to be probed. The answer is rehearsed so the honest version is ready before the probe arrives. |
| A4 | "What did you run on the calendar, week to week?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-map from the quote: the weekly cadence, the main title, the two years. Answer slot: if any calendar decision was yours to make, say which and why; if the calendar was set by others, say so and describe what you ran. | F2 is a line the JD's calendar requirement reaches. The question asks what it contained, which is where a Skeptic tests it. |
| A5 | "Your retention numbers went to the studio head. How would you know a content drop moved them?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you ever separated one drop's effect from the rest of a month's movement, say how; if you did not, say so and say how you would set up that comparison before the next event. | F6 and F5 both point here. The honest answer is the plan, not a method you did not use. |

### Bank B: Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Plan the next six weeks of live events for two titles. What do you need to know first?" | CASE | [grounded] (JD line: "Plan and run the live-events calendar for two of our mobile titles") | Clarify first: each title's current KPIs, its monetisation model, team capacity, QA windows and community commitments. Then structure: the calendar as the fixed spine, one event per title per window, and freeze dates. Name the retention metric you would watch. Say each assumption out loud. | This is the JD's core task as a live problem. The clarify-first habit is what the Case persona scores. |
| B2 | "You're handed a title you have never played, with an event due in three weeks. How do you start?" | CASE | [generic] | Start with the title's last three events and their results. Then ask what its revenue model is before you plan any offer. Name what you would not change until you have the data. | This is the monetisation gap in live form. It presumes nothing about your past. |
| B3 | "A content drop is two days out and QA has failed a build. Walk me through the call." | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Structure: what the checklist says about a fail, who owns the go or no-go, what slips and what does not, and who you tell. Answer slot: if you have made or shared a go or no-go call, say what you weighed; if the call sat with someone else, say so and say what you would bring to them. | F4 is the checklist, and the JD asks for release management with QA. The slot keeps the decision where your material puts it. |
| B4 | "Design wants an event reward that the community team thinks players will hate. Engineering says it cannot ship in time. How do you decide?" | CASE | [generic] (JD line: "coordinate design, art, engineering and community teams on each update") | Name the four teams' stakes, the player harm, the KPI at risk, and the date. Decide with a stated owner. Write down what was agreed. | The JD's coordination line, as a conflict. It is a pattern for the problem, not a fact about you. |
| B5 | "Your post-event review says an event beat its target but lost players on day seven. What goes in the write-up?" | CASE | [generic] (JD line: "own the post-event review and the KPIs it reports") | Lead with the result that matters. Name the cohort split, the metric you trust least, and what you would test next. State what the review cannot prove. | The post-event review is the JD's ownership line, asked as a judgment rather than a record. |

### Bank C: Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention number was counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you know how it was counted, walk the steps in your own words. If you did not calculate it, say so, say who did, and say what you checked before you presented it. Weakest-assumption move: name the assumption you would defend least, if you know one. If you do not know how it was counted, say that. | F6 is the figure you presented. Every headline number gets a defend-the-number question. |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Name the assumption in your own words, before the interviewer does. If you do not know the assumption, say you do not know. | F6 again. This is the second follow-up a Prober asks, and the honest answer is a named limit. |
| C3 | "You ran a weekly content-drop calendar for two years. What did it contain, and what was left out?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-map from the quote: the weekly cadence, the main title, the two years. Answer slot: say which items you chose and which were set by others, in your own words. | F2 is the calendar line. A Prober asks for the denominator: how many drops, what share of them were yours. |
| C4 | "Who uses your release checklist now, and what would you change in it first?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Say who uses it and what for, in the quote's terms. Answer slot: if QA has asked for changes, name one; if not, say what you would change first and why. | F4 and F7: the checklist is a written artifact still in use. A Prober tests whether it is still yours. |

### Bank D: Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | A 90-second arc: the puzzle studio, the associate producer role, the weekly calendar, the checklist, the retention presentations. End on why live operations at Saltmarsh. | The opener is scored for economy. The arc is the same one you will use in every other answer. |
| D2 | "What are you doing with player-retention metrics these days?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you still work with retention numbers, name what you look at; if not, say so and name the retention source you would look at first in this role. | F6 is the retention requirement. A casual question about a JD topic is still scored. |

### Bank E: Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we pick you over someone who has led a team?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pause. Restate the question. Hold on what your material shows: "I ran the weekly content-drop calendar for our main title for the last two years." After two follow-ups, concede the specific gap: "I haven't led a team," and say how you would learn to coordinate without managing. | F9 is the gap, and the honest answer is the hold-then-concede structure. |
| E2 | "That presentation: how much of the retention result was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Pause. Answer slot: if you did any of the analysis behind the numbers, say which part; if you presented numbers someone else built, say that. Hold the sentence through two follow-ups. Concede the specific thing you did not do. | F5 and F6 again. The answer is the honest one, given under pressure. |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A4, B1, B2, C3 |
| Coordinate design, art, engineering and community teams on each update | A2, B4 |
| Own the post-event review and the KPIs it reports | A3, A5, B5, C1, C2 |
| Manage the release checklist with QA | B3, C4 |
| 3+ years producing live-service games or apps | none in the banks. The gate is a closing question for you to answer. |
| Experience running a content calendar | A4, C3, D1 |
| Comfortable with player-retention metrics | C1, C2, D2, E2 |
| Clear written communication | C4. A written sample would strengthen this (upgrade menu). |

**Highest-ROI prep:** A3. Practise the hold on "I presented the monthly retention numbers to the studio head", and the honest answer to "did you own the KPIs?"

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first ninety days look like for whoever takes the calendar across both titles?" | It shows you are planning to own the calendar, not just to join it. |
| R2 | "Which of the two titles is the bigger calendar problem right now, and what is driving it?" | It asks for the real constraint and shows you read the JD as a set of trade-offs. |
| R3 | "How is the post-event review run today: who writes it, and who owns the KPIs it reports?" | It goes straight to the JD's ownership line, and the answer tells you where the role sits. |
| R4 | "How are in-app purchases handled across the two titles, and who makes the monetisation calls on an event?" | It tests whether monetisation is part of this role, which the JD does not say. |
| R5 | "What would you want me to have done by the end of the first month?" | It turns the conversation into a shared plan and gives you a measurable target. |

No reverse question is tied to Tobias's own career path, because there is no profile to read. Reciprocity is not asked, since the assumed relationship is hiring manager, not peer.

## Prohibited list

See the prohibited claims table above. It applies to every answer slot and every guidance cell in this pack.

## Sources

- **Provided documents:** your message, containing the JD text and your background. No CV was supplied.
- **Searches and fetches:** none. Research tier L0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, section 10. Not included, since no values were provided and no values-style round is detected. |
| 2. Saltmarsh Games interview process, live operations | unavailable | Loop structure and persona weights. Weights here rest on the assumed relationship, not on the loop. |
| 3. Saltmarsh Games strategy and recent news | unavailable | Company knowledge (CO) questions and a grounding brief. The banks have none, so the company-specific questions are missing. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Reading the interviewer, persona weights, and a reverse question tied to his path. |
| 5. Representative live-operations JD | skipped | The JD you supplied already fixes the fit snapshot. |

## Upgrade menu

- Confirm whether Tobias is your future manager or a peer → persona weights are recomputed for the actual relationship
- Allow a research pass at L1 on Saltmarsh's values, interview process and recent news → company-specific questions, a values cheat sheet if values are published, and a grounding brief
- Tobias Wrenfield's public profile or talks → a persona reading, and a reverse question tied to his career path
- A CV or written sample → F5, F7 and F9 upgrade from your message quotes to CV quotes, and the written-communication row gets its evidence
- Time you have before Friday → a prioritised prep schedule, tied to question IDs
