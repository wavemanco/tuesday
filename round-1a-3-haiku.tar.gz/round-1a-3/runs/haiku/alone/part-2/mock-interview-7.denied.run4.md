Web search was refused in this session, so the research step came back empty. I'll build the pack from your JD and your background, and say plainly where the missing research would have changed it.
Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-2-rooms-case-7-denied-f2b024e3/0b200feb-5a7c-4912-988d-fbbbed2545db/scratchpad/saltmarsh_live-operations-producer_interview_pack.md`. I built it for a hiring-manager-style round, since your note didn't say how Tobias fits in.

Web search was refused in this session, so I had no research on Saltmarsh Games: no values, interview loop, strategy or information on Tobias. The pack makes no claims about the company or him, and it has no values cheat sheet or company-strategy questions. The reverse questions are generic.

What the pack builds on:

- **Your strongest material:** the content-drop calendar, the release checklist QA still uses, and the retention presentation. Each is quoted from your own sentences.
- **Your biggest exposure:** "coordinate design, art, engineering and community teams" and "own the post-event review and the KPIs it reports". Your message doesn't show either, so the pack treats them as the likely probes.
- **The objection to rehearse hardest:** "You've never led a team. How would you get design, art, engineering and community to act on an update when none of them report to you?" Hold to "I haven't led a team," then give a plan. Don't add a team you didn't lead.
- **The in-app purchases gap:** name it plainly and give a ramp plan. It isn't a JD line, but two mobile titles make it likely to come up.

The pack also lists five claims you shouldn't rehearse, because they stretch what you told me: owning the retention KPIs, running live events across two titles, managing release sign-off, leading a team and monetisation experience.

If you grant web search permission, I can run the research again. That would add the company's values, the loop structure, a strategy-based question bank and an interviewer read.

Your prep pack is saved as saltmarsh_live-operations-producer_interview_pack.md. I can also run a live drill on the highest-ROI question (A2, the leadership one). Or I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

Is Tobias your future manager, or someone you'd work alongside? The answer reweights the persona table and the reverse questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Interview prep: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Round type and your relationship to him: not stated, so this pack assumes a hiring-manager-style round (see the persona table). Format: 60 minutes, Friday, read as 27 November 2026.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **JD** = stated job requirement. **EXP** = deep-dive on something you did. **CASE** = live problem, no claim about your past. **CO** = company knowledge (none in this pack, because no company research ran). **VAL** = values (none in this pack, see the note under the persona table).
- Guidance is scaffolding, not a script. Rehearse the shape, then say it in your own words.

## Fit snapshot

Requirements come from the JD you pasted (quoted). Evidence is quoted from your message. Your message is the only source of your background; no CV was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | presentation | "I've spent four years as an associate producer at a puzzle-game studio." Your message gives the years and the studio type. It does not use the words live-service, and the bridge does not add them. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | No gap. Lead with the quote as it stands. Expect a probe on how the calendar was set each week, since it is a one-person claim with no artifact behind it yet. |
| F3 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | "I presented the monthly retention numbers to the studio head." Your message shows presenting the numbers, not defining or owning them. Answer slot: if you chose what the numbers measured or how they were read, say which and how; if you did not, say so plainly and say what you did with them. |
| F4 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | transferability | "I wrote the release checklist our QA team still uses." That is one written artifact still in use. It does not show the wider written work the JD names. Answer slot: if another written piece of yours comes to mind, name it and who read it; if none does, say so plainly. |
| F5 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | "I ran the content-drop calendar for our main title." Your message covers one title. Answer slot: if you ever planned a calendar across more than one title, say how; if you have not, say so plainly. |
| F6 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordination with these teams. The nearest quote, F4, is about QA only. Answer slot: if you got an update through a team other than QA, describe how, in your own words; if there was no such step, say so plainly and describe how the content drops reached players. |
| F7 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [grounded] | discovery | Your material does not show a post-event review. The nearest quote touches KPIs without showing ownership. Answer slot: if you ran a review after an update and chose its KPIs, say which and how; if you did not, say so plainly and say what you did with the numbers you presented. |
| F8 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | transferability | "I wrote the release checklist our QA team still uses." Writing the checklist is not the same as managing release sign-off. Answer slot: if you ran a release sign-off with QA, say how; if you did not, say so plainly. |
| F9 | Leading a team: not in the JD text, raised by you as a gap | "Never led a team" (your message) | none | [grounded] | capability | The absence is yours to state: "I haven't led a team." Then a plan, stated as a plan and never as a past: how you would get the teams in F6 moving without line authority. |
| F10 | Monetisation experience: not in the JD text, raised by you as a gap | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | "I haven't worked on a game with in-app purchases." Then a plan, stated as a plan: what you would read first about the two titles' purchase data. |

**Gate rows:** none. The JD states no legal, credential, location, schedule or pay terms. Experience length ("3+ years") is graded like any other requirement.

**Confidence note:** every quote is a sentence you wrote, but none has an artifact behind it yet. That is why the bands are medium at best. Sharing the release checklist itself, or any retention report you presented, would be the inspectable proof that could raise F3, F4 and F8.

## Prohibited claims

Built locally from the fit snapshot. These are the stretched versions of your sentences, and the stated negatives. The pack will not coach any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the retention KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material shows presenting the numbers, not owning them. |
| Ran live events across two titles | Inflated form of F5 | F5's quote at its own scope. |
| Managed release sign-off with QA | Inflated form of F8 | F8's quote at its own scope. |
| Led a team | Negative you stated, F9 | "I haven't led a team." No answer slot. |
| Worked on a monetised game | Negative you stated, F10 | "I haven't worked on a game with in-app purchases." No answer slot. |

## Persona table

No relationship or round type was given, so these weights are the hiring-manager prior, flattened because no loop source established the loop. The archetype fallback here is "Generic" (flat weights, said plainly). Reweight once you tell me the round.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of F6, F7, F9 and F10: the requirements with no quote behind them | High. The JD asks for coordination and KPI ownership, and your message does not show either. | Rehearse the one most likely objection (A2) until it is plain. Name the gap first, then give a plan. |
| Case / Strategist | Live problems on the release calendar and updates | High. The JD is a planning role, so live problems on the calendar are its likely form. | Clarify, then structure, then metrics, then risks. Think aloud. |
| Data-Driven Prober | Defend-the-number probes on the retention presentation | Medium. The JD names retention metrics and your message names one retention presentation. | Say what you can and cannot say about how the figure was counted. Name the weakest assumption before they do. |
| Pressure / Stress | Time-boxed challenges on leadership and on the retention work | Medium. Likely if the interviewer is testing the gap rather than the content. | Pause, restate, hold a challenged position through two follow-ups, then concede the specific uncertainty. |
| Conversational / Rapport | Friendly opener, "walk me through the journey" | Medium. Casual questions here are still scored. | A 90-second arc built only from your quoted sentences. |
| Peer Evaluator | Seam questions between teams | Low. Your relationship to the interviewer is not known to be peer. | Not weighted; reconsider if the round is with a peer. |

**Values:** no values round is detected. No loop source established one, and the Generic archetype does not assume one. No values cheat sheet is included.

## Question banks

Question types are one token each. Provenance lists every quoted sentence a guidance cell rests on. Where a guidance cell makes no claim about you, it carries its label alone.

### A. Skeptic (weight: high, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which of this role's requirements would you be weakest at on day one?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Name coordination across design, art, engineering and community as the one with no evidence behind it in your material. Give a first-30-days plan, stated as a plan. | Surfaces F6 before they do. The question is open, so it presupposes nothing about you. |
| A2 (highest ROI) | "You've never led a team. How would you get design, art, engineering and community to act on an update when none of them report to you?" | JD | [grounded] "Never led a team" (your message) | Hold: "I haven't led a team." Then the plan: how you would make each team's decision on the update visible and get it on record, and where you would escalate. Hold through two follow-ups by returning to the plan, never by adding a team you did not lead. Answer slot: if you have moved a team's work without leading it, say how; if not, say so plainly and give the plan. | F9 is the objection most likely to come up in some form, and the one the JD presses hardest. Rehearsing the plain acknowledgment and a plan keeps the answer from turning defensive. |
| A3 | "Walk me through how you would run a post-event review, and which numbers you would report." | JD | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Describe your method first. The one related fact is the retention presentation, and you may use it only at its own scope. Answer slot: if you ran a review after an update and chose its KPIs, say which and how; if you did not, say so plainly and give your method. | F7 is a gap the JD names directly. The question asks for a method, which you can give without a past. |
| A4 | "I don't see in-app purchase experience in your background. How would you handle monetisation on these titles?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Hold: "I haven't worked on a game with in-app purchases." Then a ramp plan, stated as a plan: what purchase and pricing data you would read first, and whom you would ask. | F10. The interviewer's premise matches your own negative, so the plain acknowledgment is safe. |
| A5 | "Why this role, and why now?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message) | Name what the next role should give you that your current one does not, in your own words. Do not claim a reason you have not stated. | Motivation probe on a move from puzzle games to mobile live-ops. The quote is the only fact the answer rests on. |

### B. Data-Driven Prober (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "How was that retention figure counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Answer slot: say how it was counted if you know. If you do not, say so plainly, and say which part you presented and which part you did not produce. Do not reconstruct a method you cannot repeat. | F3, defend-the-number. A method you cannot repeat under a second question is worse than none. |
| B2 | "Which assumption behind your retention numbers would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Name the weakest assumption you know of before they do. If you do not know the assumptions, say that. | Metric question. The weakest-assumption move turns a gotcha into a credibility point. |
| B3 | "Did your content calendar move any KPI? How would you know?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Say what you can show and what you cannot. If you cannot attribute a change to the calendar, say so. | F2. The question leaves room for "no", so the honest answer is available. |

### C. Case / Strategist (weight: medium, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A retention dip shows up in week three of an update. What do you check first?" | CASE | [generic] | Clarify: which title, which cohort, what changed in week three. Then segmentation, metrics, and the risks of the two obvious fixes. Think aloud. | Live problem from the role. It presupposes nothing about you. |
| C2 | "A release slips two days before a live event. What do you do?" | CASE | [generic] | Clarify what the release checklist gates and who signs it off. Decide ship or slip against the event's stakes. Name QA and the teams you would talk to. | Live problem built from F8's checklist. The question presupposes nothing about your past. |
| C3 | "Design wants a bigger event and engineering says the build cannot carry it. How do you decide?" | CASE | [generic] | Clarify the constraint, then the cost of each option, then who decides. State the decision rule you would use before you hear their answers. | Live coordination problem from F6. A structured answer with no claim about past events. |
| C4 | "Walk me through how you would plan the live-events calendar for two mobile titles in your first quarter." | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD); "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Give the plan first. Then an answer slot: say what carries over from the one title you ran, and what you would learn first about the second. If you have planned across more than one title, say how; if not, say so plainly. | F5. The question is a plan, so the honest answer is a plan. |

### D. Pressure / Stress (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has led a team?" | JD | [grounded] "Never led a team" (your message); "Wrote the release checklist our QA team still uses." (your message) | Pause. Restate the question. Hold: "I haven't led a team." Then the one quoted contribution: the release checklist your QA team still uses. Answer slot: if you have coordinated work without leading it, name it; if not, say so plainly. Concede the specific gap, not the whole case. | F9 under time pressure. The hold is the plain acknowledgment, not a larger claim. |
| D2 | "That retention presentation: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Hold: "I presented them to the studio head." Concede specifically what you cannot claim: who defined them, how they were counted, if you do not know. Do not fold on the presentation itself. | F3. Hold-then-concede: the presentation is quoted, the rest is not. |
| D3 | "Who signed off on releases where your checklist was used?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Say who you know signed off, and who you did not work with. If the sign-off was not yours, say so plainly. | F8. Asks for the decision chain, which your quote does not show. |

### E. Conversational / Rapport (weight: low, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message); "I ran the weekly content-drop calendar for our main title for the last two years." (your message); "Wrote the release checklist our QA team still uses." (your message) | A 90-second arc made only of those three quoted sentences, in order. | Opener that is scored as well as friendly. Your arc should carry the quotes and nothing added. |
| E2 | "What mobile game have you been playing lately, and what did its updates get right?" | JD | [generic] | Have a real answer. If you play little mobile, say so and name the nearest thing you do play. Do not invent a game you have not played. | Casual-register question on a JD topic. Treat it as scored. |
| E3 | "What would you want to understand first about one of our titles?" | CASE | [generic] | Name one specific question you would bring to the first week, stated as a question you would ask, not as something you already know. | Rapport question that tests whether you have thought about the job. |

**Requirement coverage:**

| JD requirement | Covered by | Note |
|---|---|---|
| 3+ years producing live-service games or apps | E1 | The years are one quoted line, so no separate question. |
| experience running a content calendar | B3, C4 | |
| comfortable with player-retention metrics | B1, B2, A3 | |
| clear written communication | none, and why | No question. F4 carries it. Expect it in the interview; the upgrade menu says what would help. |
| coordinate design, art, engineering and community teams | A1, A2, C3 | |
| own the post-event review and the KPIs it reports | A3 | |
| manage the release checklist with QA | C2, D3 | |
| Plan and run the live-events calendar for two titles | C4 | |

**Session total:** 18 questions, against a target of 18 to 26. Persona depth follows weight.

**CO coverage:** none. No company strategy research ran, so no company-specific CO question is included.

## Reverse questions

Role-generic, because no interviewer profile exists. Each has why it lands.

1. "What does a good post-event review look like here, and who writes the first draft?" Why it lands: shows you think about the review you would own (F7).
2. "Are the two titles' calendars planned together or separately today?" Why it lands: finds the real seam in the role (F5, F6).
3. "Which team is usually the bottleneck on an update, and what has been done about it?" Why it lands: shows you are planning for the friction, not the brochure.
4. "How is retention defined for each title, and who agrees on that definition?" Why it lands: connects to the KPI ownership in the JD (F3, F7).
5. "Does the release checklist act as a gate or as a guide?" Why it lands: asks about the checklist you wrote and its real authority (F8).
6. "What would success look like at the end of the first ninety days?" Why it lands: a standard question done well, and it tells you what they will measure you on.

## Sources

**Provided documents:** the JD (in your message) and your background (in your message). No CV, no dossier, no links.

**Searches and fetches, all in this session:**

- Query: "Saltmarsh Games values". Result: refused (web search permission was not granted).
- Query: "Saltmarsh Games interview process Live Operations Producer". Result: refused.
- Query: "Saltmarsh Games mobile studio strategy news". Result: refused.
- Query: "Tobias Wrenfield Saltmarsh Games Head of Live Operations". Result: refused.

Those four calls were the whole L1 search budget I attempted. No fetches were sent.

**Research tier: L1, searches 4 of 6 (all refused), fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Would have produced a values cheat sheet. Refused, so there is none, and no values round is detected in any case. |
| 2. Saltmarsh Games interview process | unavailable | Would have named the loop. Refused, so the persona weights are the flat Generic fallback. |
| 3. Saltmarsh Games strategy / recent news | unavailable | Would have fed CO questions. Refused, so no CO questions. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Would have produced an interviewer read and tailored reverse questions. Refused, so the reverse questions are role-generic. |
| 5. Representative JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions. |

**Company note.** I could not verify anything about Saltmarsh Games: no values, no loop, no strategy, no news. The pack makes no claim about the company.

## Upgrade menu

- Web search permission granted → the four refused searches run, and a values cheat sheet, the loop structure, a strategy-grounded CO bank and an interviewer read can be added.
- Round type and your relationship to Tobias → reweights the persona table and the reverse questions.
- The recruiter's note on the round format, or the invite → if it names the rounds, the loop is established and the persona weights rest on it.
- A CV or the release checklist itself → an inspectable artifact that could raise F4 and F8 from medium to high, and the retention work from low to medium where it is shown.
- A deeper research pass, if you want it: up to 6 more searches and 2 more fetches, several more minutes. Offered once.
