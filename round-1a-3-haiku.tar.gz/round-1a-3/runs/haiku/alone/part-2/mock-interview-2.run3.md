Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-2-rooms-case-2-denied-6ba26ccc/da83a299-b249-4269-ba6f-cd79327b1948/scratchpad/atlas-freight_operations-manager_interview_pack.md. I built it for a hiring-manager round, since your note didn't say who you're meeting. I couldn't research Atlas Freight because web search wasn't permitted in this session, so the pack says nothing about their values, interview process or strategy.

Say the word and I'll play the Skeptic on B1, the question the pack names as the highest-ROI prep. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting, and what kind of round is it: hiring manager, peer, skip-level, or recruiter screen? If the recruiter sent guidance on focus areas or a deliverable, paste it in.
2. The JD asks for 5+ years of operations leadership. Your background shows seven years in operations and a current role over three supervisors. How many years have you had people responsibility, and since when?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Atlas Freight: Operations Manager interview prep

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer:** not known
**Round:** not stated. Built on a hiring-manager prior, which is an assumption and not a fact about this loop.
**Company research:** none. Web search was not permitted in this session, so nothing here about Atlas Freight's values, interview process or strategy. See Sources.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and answer in your own experience.

An **answer slot** is an instruction for the interview. It gives two honest branches: answer from what you did, or say plainly that the practice was not yours or did not happen. Neither branch is a wrong answer.

Type key:

- **VAL**: behavioural and values alignment. None in this pack; no values-style round was detected.
- **EXP**: experience deep-dive. Whether your CV claims survive scrutiny.
- **JD**: role and job-description driven. What the listed job asks.
- **CO**: company and strategy knowledge. None; no company research ran.
- **CASE**: hypothetical or live problem.

Sections left out, each on its stated condition: prep triage (prep time not stated), values cheat sheet (no values-style round detected), reading the interviewer (no interviewer named), graded deliverables (none declared), grounding brief (no research ran), delivery coaching (no assessment provided).

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (the JD) | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material shows a shift role over three supervisors and no multi-site role. The bridge stays at that scope: "currently a senior shift manager over 3 supervisors." Answer slot: if your responsibility has ever reached beyond one site, say where and what was yours; if it has not, say so, and say how you would cover four. |
| F2 | "lead a team of 12 supervisors" (the JD) | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Three supervisors is the adjacent scope, not the requirement. Bridge at its own span only. Answer slot: if you have ever been responsible for more people through supervisors, say how many and over what period; if not, say so, and say how you would organise a team of that size. |
| F3 | "drive on-time performance and cost-per-shipment down" (the JD) | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material moved an accuracy measure, not on-time performance or cost per shipment. Bridge: "cut mis-pick rate 40% by redesigning the pick path." Answer slot: if the pick change touched on-time or cost, say what you saw and how you know; if it did not, say which measure you would link a change like it to first. |
| F4 | "build reporting in Excel/Power BI" (the JD) | "solid Excel" — your message | medium | [grounded] | discovery | Your material gives Excel skill and does not show a report you built. Answer slot: if you have built reports people relied on, say what they were for and how you checked them; if you have not, say so, and say how you would check a report before anyone relied on it. |
| F5 | "Excel/Power BI" (the JD, Power BI part) | "never used Power BI" — your message | none | [grounded] | capability | Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. No claim of Power BI work. |
| F6 | "5+ years operations leadership required" (the JD) | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [grounded] | hard_gate | Your material does not establish five years of operations leadership. It shows seven years in warehouse and distribution ops and a current role over three supervisors, but not how long you have led people. Not bridged. The question in this message asks for it. |
| F7 | "Lean/Six Sigma a plus" (the JD) | "green belt certified" — your message | high | [grounded] | none | The quote reaches the Six Sigma part in role terms. Your material does not name Lean. Words: "green belt certified." If asked, say which programme it was and whether it covered Lean. |

## The prohibited list

Claims this pack will not coach, because the material does not carry them. Each is built from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran daily terminal operations across four sites | Inflated form of F1 | The quote "currently a senior shift manager over 3 supervisors," at its own scope. The material shows no multi-site role. |
| Led a team of twelve supervisors | Inflated form of F2 | The same quote, at its own span. |
| Moved on-time performance or cost per shipment | Inflated form of F3 | "cut mis-pick rate 40% by redesigning the pick path," at its own scope. |
| Built Excel or Power BI reporting that leadership used | Inflated form of F4 | "solid Excel," with the F4 answer slot. |
| Five years of operations leadership | Gate the material does not show | The gate question in this message. No figure is offered. |
| Any Power BI experience | Negative you stated (F5) | "I haven't used Power BI." |

## Persona table

Weights start from the hiring-manager prior: Case and Skeptic dominate. The Prober is raised to 4 because the CV carries two headline claims with no counting detail. Depth follows weight.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Case / Strategist | Live problems on the four-site network | High. The JD reads as an operating scorecard, so judgement on it is what gets bought. | Clarify the metric, split by site and shift, one hypothesis per site | 5 (A1–A5) |
| Skeptic | Quiet probes on 12 supervisors, four sites, Power BI | High. The thin spots are the JD's headline asks, so this persona is likeliest to find them. | Hold on quoted work, concede plainly, bridge with a plan | 4 (B1–B4) |
| Data-Driven Prober | How the 40% was counted; what the peak plan delivered | Medium. The CV's one headline figure is the magnet. | Defend-the-number slots; name the weakest assumption | 4 (C1–C4) |
| Pressure / Stress | "Why you over someone who has run several sites?" | Medium. Depends on the round. | Hold, then concede | 3 (D1–D3) |
| Conversational / Rapport | The biography opener | Medium to high. Almost every round opens this way. | 90-second arc in the order of your quoted sentences | 2 (E1–E2) |
| Values / Behavioural | Not weighted | Low. No values round detected. | Section dropped | 0 |
| Peer Evaluator | Not weighted | Low under the hiring-manager prior. Raise it if the round is with a peer. | Reciprocity framing | 0 |

## Question banks

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your four sites' on-time performance has slipped for three weeks. Where do you start?" | CASE | [generic] | Clarify what counts as on time and over what window. Split the miss by site, shift, lane and day before forming a view. Check whether it is one site or all four, and whether volume changed. State one hypothesis per site and the single check that would confirm or kill it. Speakable in 90 to 120 seconds. Makes no claim about your past. | The JD's on-time line made live. The four sites come from the JD's own wording. |
| A2 | "Cost per shipment is rising across the network. Diagnose it, and tell me what you would measure first." | CASE | [generic] | Define cost per shipment first: what is in the numerator and the denominator. Break the rise into labour, overtime, volume mix and idle time. Ask whether the rise is in rate or in mix. Name the first data pull. | The JD's cost line made live. No claim about your past. |
| A3 | "Your first 90 days: one site is missing on time, and its supervisors have had no regular performance review. What is your plan?" | CASE | [generic] | Thirty, sixty, ninety structure. Listen and get the data in the first two weeks. Fix the review cadence before adding metrics. Pick one site-level target. Name who you would ask first. | Tests the scale and leadership lines as a decision, not as a record. |
| A4 | "You would be leading twelve supervisors across four sites. What would your first management cadence look like?" | JD | [generic] | Name the cadence: site huddle, weekly supervisor review, monthly network review. Say what each level measures and what you would check first at each site. Make no claim about how you have run a span of that size. | The JD's leadership line as a design problem. The span is the interviewer's, not yours. |
| A5 | "Build the weekly report the four site leads will read. What is on the first page?" | JD | [grounded] "build reporting in Excel/Power BI" (the JD); "solid Excel" — your message; "never used Power BI" — your message | Start with the decision, not the data: the few numbers that drive the job. Name Excel as the tool for a first version, since you have it. For Power BI, use the plain acknowledgment: "I haven't used Power BI." Then how you would get there, as a plan. | The reporting line of the JD. The tool answer is where the stated gap meets the scored requirement. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You are a senior shift manager over three supervisors. This role leads twelve across four sites and asks for five years of operations leadership. Why should we believe you can do it?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" — your message; "cut mis-pick rate 40% by redesigning the pick path" — your message; "ran the site's peak-season surge plan two years running" — your message; "lead a team of 12 supervisors" and "5+ years operations leadership required" (the JD) | **Highest-ROI prep.** This is the objection the material predicts most strongly, and it will come in some form. Hold: say what you run, in your words, and what you did with it: the pick path result and the surge plan. Concede plainly and specifically that the scope is larger than your current role. Then move to the plan, not the past. Answer slot: if your leadership has reached beyond the shift, say how many people and over what period, in your own words; if not, say so plainly. Hold through two follow-ups by returning to the work you did. Concede the scale, never the quality of the work. | The question's premise is the JD's scale and your quoted scope, both quoted. The concession is the honest branch, not a confession. |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never used Power BI" — your message; "build reporting in Excel/Power BI" (the JD) | Name Power BI first, plainly: "I haven't used Power BI." Then your ramp plan. Give one clean answer unless asked for a second. | The Skeptic's stem, asked directly. The stated gap is said first. |
| B3 | "Your material shows Excel. The JD asks for Power BI as well. How would you build the reporting here?" | JD | [grounded] "solid Excel" — your message; "never used Power BI" — your message | Lead with what you can build now, in Excel, and what you would deliver first. Then "I haven't used Power BI," followed by how and by when you would learn it. Answer slot: if you have built reports used by others, say what they were for; if not, say so. | The reporting line is a second live probe of F4 and F5. |
| B4 | "Your headline result is a mis-pick rate. What does that have to do with cost per shipment?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message; "drive on-time performance and cost-per-shipment down" (the JD) | Say what the 40% measured: mis-pick rate, and nothing more. Answer slot: if you tracked any cost or on-time effect of the pick change, say what and how you know; if you did not, say so and say what you would link it to first. Do not assert a cost saving the material does not show. | The Skeptic's gap question on F3. The honest branch keeps the cost claim out. |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 40% was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Defend-the-number: the baseline period, what counted as a mis-pick, and the sample. Name the assumption you would defend least, before they do. Answer slot: if you know how it was counted, state the baseline period and what counted; if you do not, say plainly that you do not know, and name the check you would run. Do not supply a baseline. | The CV's headline figure is where probers go first. An explanation you cannot repeat under a second question is worse than none. |
| C2 | "Which part of the 40% was yours, and what else changed in that period?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Attribution in your own words. Answer slot: if you designed or led the redesign, say what your part was; if it was a team's or the site's change, say whose it was and what your part in it was. | The quoted sentence does not say who did the redesigning. The answer should. |
| C3 | "The peak-season surge plan ran two years running. What did it deliver, and how did you measure that?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" — your message | Name what you ran, in its own words, then the measure. Answer slot: if you measured an outcome, say what and how; if you ran it without measuring, say so and say what you would measure. Never describe a result the material does not show. | A second headline in the CV with no number attached. A prober finds it fast. |
| C4 | "When have you built or checked a report that other people relied on?" | EXP | [grounded] "solid Excel" — your message; "build reporting in Excel/Power BI" (the JD) | An open prompt. Pick an instance only if you have one: what it calculated and how you checked it. Answer slot: if you have none, say so plainly, then describe how you would check a report before people relied on it. | The reporting requirement, asked as a question about your history. Your material shows Excel and no report. |

### D. Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run several sites?" | JD | [grounded] "7 years in warehouse and distribution ops" — your message; "green belt certified" — your message | Hold: say what you bring that is specific, in your own words. Concede the scope gap in one plain sentence, and do not argue down the other candidate. Then the one specific thing you have done. Hold for two follow-ups; concede the scale, never a claim you can back. Speakable in 60 seconds. | Time-boxed and comparative. It tests composure more than content. |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Hold, then concede. Hold: your part in the redesign, in your own words. Concede: where the change was shared, say so specifically. Answer slot: if the redesign was yours to lead, say what you led; if it was not, say whose it was and what you did. Do not fold the whole result to restore harmony. | The pressure framing of C2. The held position is one the quote carries. |
| D3 | "Seven years in ops, and three people report to you. Isn't this a step too far?" | JD | [grounded] "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | Hold: it is a step up in scope. Say what the step requires and what you would do first. Concede plainly the areas where your scope has been narrower. Do not claim readiness the material does not show. | Tests whether the scope jump is faced directly. |

### E. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | JD | [grounded] "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message; "cut mis-pick rate 40% by redesigning the pick path" — your message; "green belt certified" — your message | A 90-second arc in the order of your quoted sentences: where you started, what you run now, the pick path result, the green belt. Do not add a stage the quotes do not carry. | The biography opener is scored. Covers the Lean/Six Sigma plus, asked casually. |
| E2 | "What are you actually playing with in Power BI these days?" | JD | [grounded] "never used Power BI" — your message | Say it plainly: "I haven't used Power BI." Then one line on how you are going to learn it, as a plan. | A casual question about a scored tool. Treat it as scored. |

**Requirement coverage**

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A1, A3, B1 |
| Drive on-time performance down | A1, B4 |
| Drive cost-per-shipment down | A2, B4 |
| Lead a team of 12 supervisors | A4, B1, D3 |
| Build reporting in Excel/Power BI | A5, B2, B3, C4, E2 |
| 5+ years operations leadership | B1, D1; the gate question in this message |
| Lean/Six Sigma a plus | E1 covers the green belt. Lean: none, and why: a plus, and your material does not name Lean. |

## Reverse questions

No interviewer is known, so none is tied to an interviewer's path. Not a peer round, so no reciprocity question.

1. "What does on-time performance look like at the end of year one, and how is it measured?" Why it lands: shows you are thinking in the scorecard they use.
2. "How different are the four sites today, and which one worries you most?" Why it lands: shows site-level thinking, and invites the diagnosis you rehearsed in A1.
3. "Which reports does leadership read each week, and what decision does each one drive?" Why it lands: puts the reporting conversation on decisions, without claiming a tool skill.
4. "How many of the twelve supervisors are new in role, and what support do they have now?" Why it lands: shows you want to know how the span is actually run.
5. "Where is Lean or Six Sigma used here, if it is?" Why it lands: shows interest in the plus, and tells you whether it matters in this job.
6. "What did the last person in this role find hardest?" Why it lands: a candid answer tells you what they are likely to test.

## Sources

- **Provided documents:** the job description text and the candidate background, both in the message.
- **Search attempted:** "Atlas Freight regional logistics operations". Refused: web search permission was not granted in this session. No result came back. No other search or fetch was sent.
- **Research tier:** L1. Searches: 0 of 6 returned results (1 refused). Fetches: 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet. Would also have settled whether a values-style round exists. |
| 2. Atlas Freight interview process, operations | unavailable | Loop structure and persona weights. Weights here rest on the hiring-manager prior instead. |
| 3. Atlas Freight strategy or recent news | unavailable | Company and strategy questions. None were written, so no CO bank exists. |
| 4. Interviewer name and Atlas Freight | n/a | No name was given, so there was no query to form. |
| 5. Representative operations manager JD | skipped | The JD was supplied, which fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The round type and who you are meeting → persona weights and reverse questions for that person (question 1 in the message)
- The recruiter's prep email → coverage of any focus areas or deliverable they named
- Web search permission, or Atlas Freight's public values and careers pages pasted in → a values section, a process-grounded loop, and company and strategy questions
- Which programme your green belt was in, and whether it covered Lean → F7 becomes grounded on Lean, and E1 covers it directly
- How many years you have had people responsibility → F6 becomes a grounded row, and B1's answer slot is filled in your words
- A tuesday-dossier.md from an evidence review of your material → an evidence-graded fit snapshot and a list of claims the pack should not coach
