Web search was refused by the permission step, so I can't research Larkfield's values, interview structure or strategy. I'll build the pack from your message alone and say so in the file.
Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-2-rooms-case-6-denied-4aa170f2/86dea2b4-3cbd-40b8-9cf7-473ea03aa9a3/scratchpad/larkfield_engineering-manager_interview_pack.md. It covers all three rounds from a shared fit snapshot, with a question bank, persona weights and reverse questions for each round.

Web search was refused by the permission step, so the pack has nothing on Larkfield's values, interview structure or strategy. Those parts are labelled generic, and the values cheat sheet is left out. If you allow search, I can rerun those checks.

Say the word and I'll play the Skeptic on H5, the managing-managers objection the pack names as your highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Two things would sharpen the pack:
1. Does the role carry a location, in-office or right-to-work condition you'd have to meet? Your message doesn't say, and the answer decides whether the snapshot's gate row gets a real finding.
2. Can you paste the full job description? Right now the requirements are your summary of the role, so the quotes are your words, not the employer's.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems

**Candidate:** Yusuf. **Company:** Larkfield Systems (industrial IoT, ~600 people). **Role:** Engineering Manager, leading two device-management squads.
**Rounds:** Tuesday, 45 min, hiring manager (Director of Engineering). Thursday, 60 min panel (two staff engineers, one product manager). Following Monday, 30 min, VP Engineering ("values and leadership philosophy").
**Built on:** your message only. No job description text was supplied, so the requirements are your summary of the role. Web research was refused by the host, so nothing here about Larkfield's values, interview structure or strategy is established. Those parts are generic and labelled as such.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioural and values; **EXP** your own record, tested for attribution; **JD** the role's stated requirements; **CO** company and strategy knowledge; **CASE** a live problem from the role.
- Guidance is scaffolding for a spoken answer, not a script. Each cell is written to be said aloud in about 90 seconds.
- Every claim about your past rests on a sentence you wrote, quoted in the Provenance cell. If a cell has no quote, the cell is an answer slot: you supply the true answer, including "that wasn't mine" or "I haven't done that."

## The fit snapshot

Shared across all three rounds. Each evidence cell holds your own words and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role summary, your message) | "9 years engineering, 3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows one team of six, not two squads. Bridge: "For three years I was team lead of six." Answer slot on the two squads: if you have led more than one group at a time, say how; if you have not, say so and say how you would divide your time across two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" (role summary, hiring part) | "I run our hiring loop for backend roles" and "about 40 interviews last year" (your message) | medium | [grounded] | presentation | Hiring reaches this requirement in other terms. Bridge reworded only from those two quotes: "I run our hiring loop for backend roles, about 40 interviews last year." Say the scope out loud: backend roles. Answer slot: whether you set the loop's criteria or inherited them. Say which. |
| F3 | "own delivery, hiring and growth for 11 engineers" (role summary, growth part) | none given | none | [grounded] | discovery | Your material is silent on growing engineers. Answer slot: say what you have done to develop engineers, in your own words. If nothing you did was aimed at growth, say so and say what you would do first. |
| F4 | "own delivery, hiring and growth for 11 engineers" (role summary, delivery part) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | presentation | Delivery reaches here in other terms: a quarter pushed through under roadmap pressure. Keep "my team's" for the 60% and "I pushed" for the quarter. Limit, as this pack's own observation: the material gives the figure and the push, not how the figure was measured. |
| F5 | "partner with hardware and product on roadmap" (role summary, your message) | "I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | Holding a roadmap against pressure is adjacent to partnering with hardware and product, and does not reach it directly. Bridge: "I pushed a reliability quarter through against roadmap pressure." Answer slot: how you would work with hardware and product on a roadmap you have not yet seen, said as a plan. |
| F6 | "partner with hardware and product on roadmap" (role summary, your message) | "I've never owned a hardware-adjacent roadmap" (your message) | none | [grounded] | capability | A stated absence, which wording cannot close. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F7 | Managing managers (your stated focus; not in the role text you pasted) | "I've never managed managers" (your message) | none | [grounded] | capability | A stated absence. Words: "I've never managed managers." Then the quote at its own scope: "For three years I was team lead of six." The plan for a lead layer is said as a plan. Whether the squads have leads is unknown; see upgrade menu. |
| F8 | Location, in-office days or right to work (not in your material) | none given | none | [generic] | hard_gate | Your material does not establish this. Surfaced, not bridged. The one question asked on it is whether the gate is met. |
| F9 | "Build device-management services" (role summary, domain) | "currently at a payments company" (your message) | low | [inferred] | discovery | Your material shows payments work and does not show whether it reaches device or industrial work. Derivation: the payments quote, with the device gap inferred from it. Answer slot: if you have built anything touching devices, sensors or industrial systems, say what it was. If not, say so and say what you would learn first. |

## Prohibited claims

Built locally from the snapshot. Each entry names its basis and its honest form. No question, answer slot, or guidance cell below asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| "Led two squads" | Inflated form of F1 (one team of six is quoted) | "For three years I was team lead of six." Pack observation: your material shows one team. |
| "Owned a hardware-adjacent roadmap" or "partnered on a hardware roadmap" as past | Sourced negative, F6 | "I've never owned a hardware-adjacent roadmap." No slot on past ownership. |
| "Managed managers" | Sourced negative, F7 | "I've never managed managers." |
| "Built the hiring function" or "ran hiring for the org" | Inflated form of F2 (backend roles, one loop) | "I run our hiring loop for backend roles, about 40 interviews last year." |
| "The 60% was your result alone" | Inflated form of F4 ("my team's") | "My team's on-call burden dropped 60%," and "I pushed" applies to the quarter only. |

Not listed, and not coached: how the 60% was measured, its baseline and its time window. Your material says none of these, so they are answer slots (H6, P4), not claims.

## Sources

**Provided:** your message only: the role summary, your background, and the recruiter's phrase "values and leadership philosophy".

**Research tier:** L1. Searches 0 of 6 completed (3 sent, all refused by the host's permission step; not retried). Fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Would have moved the values cheat sheet. No published values are in hand, so that section is omitted. Query refused: "Larkfield Systems values" |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Would have confirmed the loop. The rounds below come from your message, which establishes them, so no archetype fallback is needed. Query refused: "Larkfield Systems interview process engineering manager" |
| 3. Larkfield Systems strategy, industrial IoT device management | unavailable | Would have moved the CO bank and the CASE questions from generic to grounded. Query refused: "Larkfield Systems strategy industrial IoT device management" |
| 4. Interviewer name and company | n/a | No interviewer names were given, so no query could be formed. The interviewer read is absent. |
| 5. Representative engineering manager JD | unavailable | Would have grounded the requirements. You supplied a role summary, so the snapshot uses that. No search was sent for this target; the host's search was not granted. |

Loop structure: three rounds, each with a named format and interviewer type, from your message. Persona weights follow those rounds.

## Round 1: Hiring manager (Director of Engineering), Tuesday, 45 min

**Persona weights.** The relationship prior for a hiring manager is Case/Strategist plus Skeptic. The CV carries two claims a Director can test, so the Prober weight rises to match. No interviewer profile exists, so no adjustment from one.

| Persona | Weight | How it shows up | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | 3 | Live problems from the role, scored on structure | Director is buying capability for two squads | Clarify, then objective, then approach, then metrics |
| Skeptic | 2 | "Which part would you be weakest at?" and the managing-managers objection | F6 and F7 are the material's largest gaps | Concede the exact gap in your own words, then the plan |
| Data-Driven Prober | 3 | Attribution and method questions on the 60% and the hiring loop | F4 and F2 are the two claims the Director can test | Say what you can and cannot say; name your weakest assumption first |

**Question bank.**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "If you were in this role, how would you plan your first ninety days across two squads, and what would you need to know first?" | CASE | [generic] | Clarify first: each squad's current roadmap, which device-management services carry the most operational risk, and who leads each squad. Then state the objective, the three things you would check in week one, and the order you would do them in. Give a plan, not a past. | Case/Strategist, top weight. Scores structure at the role's altitude. Makes no claim about your past. F1 sets the scale. |
| H2 | "A device fleet stops reporting for one customer. Walk me through how you would diagnose it." | CASE | [generic] | Clarify scope first: one customer or fleet-wide, and whether the firmware or the service changed recently. Then hypotheses in order, the data you would check first, and who you would call on the hardware side. Name one assumption you would test first. | Domain case for device-management services (F9). Generic because it is a pattern for the problem, not a fact about Larkfield. |
| H3 | "Hardware and product both want a commitment next quarter that your squads cannot fully staff. What do you do?" | JD | [grounded] "partner with hardware and product on roadmap" (your message) | Structure it: what the commitment is, what saying no costs the other team, and what you would offer in return. Name the trade-off you would refuse. The guidance makes no claim about your past. | Tests the partnership requirement directly. The Director's role is to settle exactly this kind of conflict. |
| H4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap" (your message) | Give the honest answer first: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, as a plan. Do not add a second weakness to look balanced. | F6 is the largest JD gap the material names. The Skeptic objection arrives in this form. |
| H5 | "I don't see managing managers in your background. How would you handle the leads of two squads?" | JD | [grounded] "I've never managed managers" (your message); "3 as a team lead of 6" (your message) | **Highest-ROI prep in this pack.** Concede first: "I haven't managed managers." Then "For three years I was team lead of six." Then the plan for a lead layer you would set up in the first month, said as a plan. Hold through two follow-ups by returning to the team of six and the plan, never by claiming you managed managers. If pressed on the exact point, concede it: "I'd expect to learn that fastest. I'd want to know what good looks like from me." Limit: no lead-of-leads experience is in your material, and none is coached. | Deepest rehearsal: F7 is the stated negative the objection targets. Expect three levels of follow-up. The Skeptic stem is sourced to your own words. |
| H6 | "Walk me through how the 60% on-call drop was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Defend the number. Say what you can say and what you cannot. Name the assumption you would defend least before the Director does. Answer slot: if you counted it yourself, say how, in your own words. If you did not count it, say so plainly and say who did. Do not supply a baseline, a time window or a method. | Prober, weight 3: headline numbers get tested first. F4 is its evidence. |
| H7 | "Which part of that quarter was yours to set, and which was set for you?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Premised on your quote: you pushed it. Say what you decided and what the team decided, each in your own words. If the scope was set for you, say so and say what you did push. Do not claim the team's result as yours alone. | Attribution probe. The prohibited entry "the 60% was your result alone" is what this question catches. |
| H8 | "Walk me through how you run the hiring loop for backend roles." | EXP | [grounded] "I run our hiring loop for backend roles" (your message); "about 40 interviews last year" (your message) | Describe the loop as it runs, in your own words. Answer slot: whether you set its criteria or inherited them. If you inherited them, say so and say what you changed, if anything. | F2. Hiring is the clearest evidence for the 11-engineer requirement, so it gets probed. |

**Reverse questions.**

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What would make the hardware-facing part of this role a success in six months?" | Turns F6 into a shared definition of done, and shows you are thinking at the Director's altitude. |
| R2 | "Is there a lead layer under the two squads, or do the squads' engineers report straight to the manager?" | Tells you whether managing managers is in scope before the round ends. It is the question F7 turns on. |

## Round 2: Panel (two staff engineers, one product manager), Thursday, 60 min

**Persona weights.** Per member, from the panel rule: each staff engineer blends Peer Evaluator and Data-Driven Prober; the product manager is Case/Strategist. You have not been given the names, so the assignment is by role.

| Persona | Weight | How it shows up | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Peer Evaluator | 3 | Seam questions between teams, credit, disagreement | Staff engineers price what a new manager adds to their own work | Propose seam principles, not a seam you have not seen; reciprocity framing |
| Data-Driven Prober | 2 | The 60% figure, asked again by the other staff engineer | Panel members who read the CV test it separately | Same answer as H6, consistent word for word |
| Case/Strategist | 2 | Roadmap trade-offs from the product manager | The PM is the roadmap partner the role names | Clarify, then one trade-off per case |

**Question bank.**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our teams sit side by side. Where is the seam between yours and ours, and what happens when we disagree?" | JD | [generic] | Propose seam principles: who decides the interface, how a disagreement escalates, and how you would know the arrangement is working. Do not pretend to know their seam. Say what you bring to their team, not only what you need. | Peer Evaluator. Stem from the persona. Makes no claim about your past. |
| P2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name the people who did the work. Say "we" for the context and "I" for what you did. If you use the on-call quarter, separate your push from your team's work. | Peer Evaluator, credit probe. No claim about your past beyond the quote carried in F4. |
| P3 | "A staff engineer thinks your squads' device API contract is wrong and has a design doc. How do you decide?" | CASE | [generic] | Clarify what the doc claims, which consumers depend on the contract, and what a reversal would cost. Decide with a named owner and a date, and say when you would overrule and when you would defer. | Peer Evaluator with technical judgement. Structure, not a past. |
| P4 | "Which assumption behind that on-call number would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Name the weakest assumption yourself, first. Answer slot: if you know how the figure was counted, say how in your own words. If you do not, say so. Do not invent a baseline. | Prober. The panel sharpens the same figure H6 tests, so the answers must match. |
| P5 | "How did you decide which reliability work went into that quarter?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Premised on a decision having been made. Answer slot: if you chose the scope, say how. If it was set for you, say so and say what you did push. | Premised question. "Which work" presupposes a choice, so the second branch must allow the scope was set for you. |
| P6 | "The hardware team wants a firmware update before a customer deadline. Product wants the dashboard first. Walk me through your call." | CASE | [generic] | Clarify the cost of missing the deadline and the firmware risk. Name the decision owner. Offer a trade to each team and say which trade you would refuse. | Case/Strategist. The roadmap-partnership requirement, as a live problem. No claim about your past. |
| P7 | "What is one roadmap trade-off you would refuse to make, and why?" | JD | [generic] | Name one trade you would hold, what it costs, and what you would give instead. Answer slot: if you have refused one before, say so in your own words. If you have not, give the one you would refuse and why. | Product manager's partnership test. The second branch allows that no refusal has happened. |

**Reverse questions.**

| # | Question to ask | Why it lands |
|---|---|---|
| R3 | To the staff engineers: "What could a new engineering manager do in their first month that would genuinely help your team?" | Reciprocity question for a peer panel. It turns the round into a working conversation. |
| R4 | To the product manager: "Which roadmap call did engineering push back on last quarter, and how did it end?" | Shows you want the partnership norms, and tests how roadmap pressure is handled in practice. |

## Round 3: VP Engineering, Monday, 30 min (values and leadership philosophy)

**Persona weights.** The recruiter's phrase names a values-style round, so Values/Behavioural carries the most weight. The VP round is the one place a skip-level's strategy and composure questions also land, so Case and Pressure follow.

| Persona | Weight | How it shows up | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Values/Behavioural | 4 | Scenario questions asking for a story | The recruiter named the round as values and leadership philosophy | STAR shape; "we" for context, "I" for contribution; say when a story is not there |
| Case/Strategist | 1 | "What does the next twelve months look like?" | Skip-level altitude test | Clarify what done means, then sequence |
| Pressure | 1 | "Make the case that this was the wrong call" | Composure under an opposing senior view | Hold for two follow-ups, then concede one specific cost |

**Published values.** None are in hand, so the values cheat sheet is omitted. The VAL questions below are selection scaffolds built on the recruiter's phrase.

**Question bank.**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Pick a time you told someone senior something they did not want to hear. It needs a named stake, the moment you said it, and what happened after. If none comes to mind, say so plainly, then give the nearest thing: the reliability quarter, if it holds a moment you said no to someone senior. If it does not, say that. | Values stem from the persona. The quarter is the only sentence in your material with a stake, so it is the nearest thing, not a proven fit. |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time a customer's need changed what you were measured on. If none comes, say so, then give the nearest thing in your own words. Do not stretch the on-call quarter into a customer story: your material names no customer. | Values persona. Your material has no customer sentence, so the guidance says so rather than supplying one. |
| V3 | "What is your leadership philosophy in one sentence, and where has it cost you something?" | VAL | [grounded] "values and leadership philosophy" (recruiter's words) | Give one sentence, then one story from your own record that tests it. Answer slot: if the story is the team of six or the on-call quarter, say what you did and what it cost, in your own words. If none of your experience cost you anything, say so. | The recruiter named the theme. The sentence is yours; the story is a selection from what is in your material. |
| V4 | "How do you grow an engineer you do not think is ready yet?" | VAL | [grounded] "values and leadership philosophy" (recruiter's words) | Pick an engineer you developed, or a time you held one back. If neither is in your material, say so, then say what you would do in the first month. | Covers the growth requirement (F3). The guidance says what to do if no story exists, and does not supply one. |
| V5 | "Two squads, eleven engineers, and a hardware team that sets its own dates. What does the next twelve months look like for you?" | CASE | [generic] | Clarify what done means at Larkfield. Then a sequence: stabilise delivery, then build the roadmap partnership, then grow the engineers. Name the first thing you would stop doing. | Skip-level altitude test. Generic, because no strategy research ran. |
| V6 | "Someone senior thinks the reliability quarter was the wrong call. Make your case in sixty seconds." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Hold the position through two follow-ups. Lead with the 60% only as a figure you can count. Name one specific cost of the quarter. Do not claim the outcome as yours alone. | Pressure test on your strongest story. The concession has to be specific, or it reads as a fold. |

**Reverse questions.**

| # | Question to ask | Why it lands |
|---|---|---|
| R5 | "What did the last leader in this role do that you would want the next one to keep?" | Shows values in practice rather than the culture slide. |
| R6 | "When a device-management reliability fix and a feature compete for the same squad, how does Larkfield decide?" | A philosophy question with a concrete trade-off. It links to V6 and tests whether the values are lived. |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Lead two squads building device-management services | H1, H2, H5, V5 (F1) |
| Own delivery | H6, H7, P4, P5 (F4, F5) |
| Hiring for 11 engineers | H8 (F2) |
| Growth for 11 engineers | V4 (F3, answer slot) |
| Partner with hardware and product on roadmap | H3, H4, P6, P7 (F5, F6) |
| Managing managers (your stated focus) | H5, R2 (F7) |
| Device-management services (domain) | H2 (F9) |
| Location, in-office days, right to work | none, and why: your material does not establish it, so it is not a question this pack can answer for you (F8) |

## Upgrade menu

- The full job description text → the requirements quote the posting's own words instead of your summary, and F1 to F7 can be checked against it.
- Permission for web search, and I will rerun the three company targets → the values page would let the VP round carry a values cheat sheet, the interview page would confirm the three rounds, and the strategy search would turn the CASE questions from generic to grounded.
- The interviewers' names (Director, two staff engineers, product manager, VP) → reverse questions tailored to each person, and persona weights read from their public background.
- One email to the recruiter → whether the squads have leads (F7), whether the panel is in person, and whether any round includes a presentation or take-home, which would add a graded-deliverable section.
- Your answer on location and in-office days → closes the gate row F8.
- A `tuesday-dossier.md`, if you have one → verifies F1 to F7 against its own evidence and replaces the inferred bridges.
