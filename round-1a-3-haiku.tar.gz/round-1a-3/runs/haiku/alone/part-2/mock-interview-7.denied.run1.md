Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-2-rooms-case-7-denied-75844e8b/13fc5602-2b75-4472-8337-91d4a222b7cb/scratchpad/Saltmarsh_Games_Live_Operations_Producer_interview_pack.md, and I've attached it. I built it for a hiring-manager round, since your note didn't say who you're meeting.

Web search was refused (the permission wasn't granted), so the pack has no Saltmarsh values, no interview-loop structure, no strategy, and nothing on Tobias Wrenfield's public work. Where those would matter, the pack labels the content generic or leaves it out.

The biggest gap is one title with weekly content drops versus a live-events calendar across two titles. B1 is the question to rehearse most. I'd expect it to come up in some form.

Say the word and I'll play the Skeptic on B1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Friday a hiring-manager interview, or a panel or peer round with other people in the room? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh_Games_Live_Operations_Producer_interview_pack.md -----
# Interview prep: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship not confirmed; this pack assumes a hiring-manager round.
**Format:** 60 minutes, Friday. Round format not confirmed.
**Changelog:** none. First pack.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **JD** role requirement. **EXP** what you actually did. **CASE** live problem. **CO** company knowledge (none in this pack; no research ran). **VAL** behavioural or values.
- Guidance is scaffolding, not a script. Each answer should take 90 to 120 seconds spoken aloud.
- An **answer slot** is an instruction for the interview. It gives you two honest branches. Rehearse both, and use whichever is true.
- **Highest-ROI prep: B1.** The gap between one title's weekly content drops and a live-events calendar across two titles is the objection this interview is most likely to raise.

## Fit snapshot

**Gates:** none in the JD text. It states no location, work-authorisation or credential term. "3+ years" is a length requirement, so it is graded on fit, not treated as a gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | discovery | The years are not the question. Your material does not show whether that title was live-service. Answer slot: if it ran as a live service, say what made it so, in your own words. If you would not call it that, say what the content drops were. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement directly. Lead with the calendar in your own terms: the weekly content drop, the main title, two years. Expect a probe on scope (F3). |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Content drops on one title are adjacent to a live-events calendar across two. The bridge stays at the quote's scope: one title, weekly content drops. Answer slot: if you ran or planned events beyond content drops, or on a second title, say which. If not, say so and say how you would extend a calendar to two titles. |
| F4 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | Your sentence reaches the requirement in other terms: you presented the numbers. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: which measure you chose or acted on, if any. If you presented figures someone else defined, say so. |
| F5 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | The checklist touches cross-team work with QA only. It does not show coordination with design, art, engineering or community. Answer slot: name one update you coordinated across any of those teams and what each team did. If none, say so and say how you would set it up. |
| F6 | "own the post-event review and the KPIs it reports" (JD) | none given | none | [grounded] | discovery | Your material is silent on post-event reviews. Answer slot: describe the last post-event review you ran or fed into, and the KPIs it reported. If you did not own one, say so. |
| F7 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote reaches the requirement directly. Bridge: "I wrote the release checklist our QA team still uses." |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | presentation | A checklist that a team uses day to day is written work. Bridge uses the quote as written, with no added detail. |
| F9 | Monetised mobile games (not in the JD text; you raised it) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | A stated absence, so the words come from you. Words: "I have never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. |

**Confidence** grades your evidence. **Provenance** grades what this pack wrote. Gap rows state absences; they never claim capability.

## Persona table

Relationship prior for a hiring-manager round: Case/Strategist and Skeptic dominate. The JD is a list of things to plan and run, and two of its lines are gaps in your material. Round type is unconfirmed, so weights are a prior, not a finding.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Case / Strategist | Live problems on the calendar, the retention drop, the release sequence | High. The JD is mostly plan-and-run language. | Clarify, then sequence, then state the first decision. | 5 (A1 to A5) |
| Skeptic | The one-title scope, the live-service question, the IAP gap | High. F3 and F9 are the largest gaps in the snapshot. | Hold at your quotes' scope, concede specifically, plan for the gap. | 4 (B1 to B4) |
| Data-Driven Prober | How the retention figure was counted, how a result is attributed | Medium. Retention metrics are a JD requirement and you presented them, not defined them. | Say what you know and what you do not. | 3 (C1 to C3) |
| Pressure / Stress | A sixty-second challenge on the IAP gap, attribution challenges | Medium. The IAP gap is the sharpest line available to a challenge. | Pause, restate, hold two follow-ups, then concede specifically. | 2 (D1 and D2) |
| Conversational / Rapport | An open "walk me through" and a casual question about games you play | Medium. Common openers in this kind of round. | Use a prepared 90-second arc from your four sentences. | 2 (E1 and E2) |
| Values / Behavioural | Stories about unpopular truths and player experience | Low. No values page was retrieved, so no values-style round is detected. | Selection scaffolds with an honest branch. | 2 (F1 and F2) |

Total: 18 questions. Peer personas are not weighted because the round is not confirmed as peer.

## Question banks

**Provenance** lists every sentence a guidance cell rests on, quoted exactly as it appears in the fit snapshot or the message. A row with no candidate claim carries only its label.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You take over two mobile titles and their live-events calendar. What do you need to know in your first two weeks, and in what order?" | CASE | [generic] | Clarify first: which two titles, the current event cadence, what the team reports on, and who signs off a release. Then the objective, then the first decisions you would make. Say the order aloud before proposing anything. No claim about your past. | Hiring-manager case on the JD's opening line. CASE because the answer is reasoning. [generic] because it is a pattern for the problem, not a fact about this studio. |
| A2 | "A retention figure on one of your titles falls about 15 percent in the week after an event. Walk me through how you would diagnose it." | CASE | [generic] | Name the cohort definition before the number: which users, which week, and what else changed in the same window. Then check instrumentation, event overlap, and segments such as new and returning players. Name the assumption you would test first. | The JD asks for comfort with retention metrics. The probe is about method, so the guidance makes no claim about your history. |
| A3 | "Walk me through how you would coordinate design, art, engineering and community on one update, from brief to live." | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD, your message) | Give it as a sequence: the brief, one owner per team, the dependency that usually slips, the community message, the go or no-go. Describe how you would run it, not a past update. | The JD sentence raises it. F5 is where your own history is thin, so show method and say where your history stops. |
| A4 | "Walk me through the release checklist you would run with QA for a live event." | JD | [grounded] "manage the release checklist with QA" (JD, your message); "Wrote the release checklist our QA team still uses." (your message) | Name the checklist's stages in order, the sign-off each needs, and what triggers a hold. Then say how QA's role changes between a content drop and a live event. Draw on your own checklist only at its scope: you wrote it, and QA uses it. | The JD sentence raises the question. The quote lets you draw on your real work and nothing wider. |
| A5 | "Which three KPIs would you report after each live event, and which would you trust least?" | CASE | [generic] | Pick KPIs by the decision each one informs: retention, engagement, and one spend or revenue measure. Name the one you trust least and why, before anyone asks. | The JD's "own the post-event review and the KPIs it reports" raises it. Generic. No past claim. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role plans live events across two titles. What in your background shows you can do that?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD, your message); "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Hold at the quote's scope: one title, weekly content drops, two years. Say it in those words, then say which part of live events you have run, if any. Answer slot: if you ran or planned events beyond the content drops, or on a second title, say which and what you decided. If you did not, say so plainly and say how you would extend a calendar to two titles. Hold through two follow-ups by returning to the calendar you ran. | The highest-ROI rehearsal. F3 is the largest transferability gap, and the JD sentence raises the premise. The second branch lets "no" be the honest answer. |
| B2 | "Four years at a puzzle-game studio: was the title live-service, and how do you know?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Your strongest evidence is the weekly content drop, which you can name. If you can call the title live-service in a sense you would defend, say why in your own words. If not, say what the content drops were, and do not claim more. | F1. The years are not in question, the live-service part is. The premise is limited to the quoted studio and calendar, and the second branch allows "no". |
| B3 | "You presented retention numbers each month. Which of them did you choose, define or act on yourself?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Answer slot: if you chose or defined a retention measure, or acted on one, say which and how, in your own words. If you presented figures someone else defined, say so plainly and say what you did with them. Do not claim the figures moved. | The JD's "comfortable with player-retention metrics" raises it. F4's bridge is the only thing your material says about it. |
| B4 | "You have never worked on a game with in-app purchases. How would you come up to speed on monetised live events in your first quarter?" | EXP | [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment first: "I have never worked on a game with in-app purchases." Then the plan, as a plan: what you would read, whom you would ask, and which data you would look at first. Do not claim knowledge of in-app purchase mechanics. | F9 is a stated absence, so the words come from you. The question's premise is your own stated negative. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Answer slot: if you know how the figure was counted, such as the cohort, the window and the definition, say it. If you do not, say plainly that you did not own the counting and who did. If you know one assumption behind it that you would defend least, name it. | F4. No figure appears in the quote, so the honest branch is "I do not know how it was counted". The JD raises the question. |
| C2 | "How would you tell whether a content drop moved retention, rather than something else that happened that week?" | EXP | [generic] | Name the comparison first: a holdout, a matched cohort, or a before-and-after with a control. Say what would make you distrust the result. Do not describe a comparison you ran. | A method question on attribution. No claim about your history, so the label is generic. |
| C3 | "What does your release checklist check, and what would you change after a bad release?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Answer slot: name the checks in your own words and the one stage you would add. If you cannot recall the checklist's contents in detail, say so and say how you would check it. After a bad release, say what you would change. | F7. The checklist is real and in use. Its contents are not in the material, so the second branch allows "I cannot recall them". |

### D. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why hire someone who has never worked on in-app purchases over someone who has?" | JD | [grounded] "never worked on a game with in-app purchases" (your message); "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Pause and restate the question in your own words. Hold the position: what you bring is the calendar and the checklist you ran, and what you lack is monetised events. Concede that specifically. Hold through two follow-ups before conceding anything more. | Pressure is scored on composure. The hold rests only on what your quotes carry. |
| D2 | "You presented retention numbers. How much of what happened to them was actually yours?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Hold on what you did: presenting is yours. The movement is not yours unless you can show it. Say that in one sentence, then stop. If pushed twice, concede the limit: you cannot say what caused the numbers to move. | Attribution pressure. The quote caps the hold at presenting. Nothing in the material says what drove the numbers. |

### E. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey. How did you get from a puzzle studio to here?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); "I ran the weekly content-drop calendar for our main title for the last two years." (your message); "Wrote the release checklist our QA team still uses." (your message); "Presented the monthly retention numbers to the studio head." (your message) | A 90-second arc in this order: the four years, the content-drop calendar, the checklist, the retention presentation. Stop at the quote's edge. Close with what you want next, in one sentence. | Casual openers are still scored. The arc uses only your four sentences. |
| E2 | "What are you playing right now, and what would you change in it?" | JD | [generic] | Name a live game you actually play and one live-ops decision in it you would have made differently, with the reason. Do not claim expertise in a genre you have not worked in. | Casual probe of the JD's live-service requirement. Generic, because it is taste, not history. |

### F. Values / Behavioural (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Selection scaffold: pick a time you told leadership something they did not want to hear, with a named stake, a moment you did not soften it, and a working relationship afterwards. If none comes to mind, say so plainly, then give the nearest thing your material carries: the retention presentation and what you said in it. Do not supply how the room reacted if you do not know. | A persona stem. No published values were retrieved, so this is a generic values probe at low weight. |
| F2 | "When did you put a player's experience ahead of an internal metric?" | VAL | [generic] | Same scaffold: a specific decision, the metric you gave up, what the player got. If you do not have one, say so, then say how you would decide it. | A persona stem. No company values were retrieved, so there is no published value to map. |

**Requirement coverage**

| JD requirement | Covered by |
|---|---|
| 3+ years producing live-service games or apps | B2, E1 |
| experience running a content calendar | A1, E1 |
| comfortable with player-retention metrics | A2, B3, C1 |
| Plan and run the live-events calendar for two of our mobile titles | A1, B1 |
| coordinate design, art, engineering and community teams on each update | A3 |
| own the post-event review and the KPIs it reports | A5, C1 |
| manage the release checklist with QA | A4, C3 |
| clear written communication | none, and why: no written task is declared, so no question tests it. The checklist quote in the fit snapshot covers it on paper. |

## Reverse questions

Every question has a reason it lands. No interviewer profile was available, so none is tied to their path. Reciprocity does not apply, because the round is not confirmed as peer.

1. "Which two titles would this role cover first, and what does each one's calendar look like today?" Why it lands: shows you are reading the JD as a plan, not a list.
2. "Where does the post-event review sit between live ops and the title teams?" Why it lands: tests the "own the post-event review" line, which your material does not cover.
3. "How does QA sign-off work on a live event right now, and where does it slow the calendar?" Why it lands: connects to the release checklist with QA.
4. "What does the first ninety days look like for someone taking over the live-events calendar?" Why it lands: shows planning, not just interest.
5. "Which KPI does the team trust least when it reports an event, and why?" Why it lands: signals metric rigour, which the Prober bank rewards.
6. "How is monetised content currently planned alongside the content drops?" Why it lands: raises the in-app purchase gap as a question about the team, not a confession.

## Prohibited claims

Not coached in any cell of this pack. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two mobile titles | Inflated form of "I ran the weekly content-drop calendar for our main title for the last two years." | The quote at its own scope. Limit, as this pack's observation: your material says one title and weekly content drops, not live events on two. |
| Owned the KPIs and the post-event review | Inflated form of "Presented the monthly retention numbers to the studio head." | The quote at its own scope: you presented the numbers. Limit, as this pack's observation: your material shows presenting, not owning the reporting. |
| Coordinated design, art, engineering and community on each update | Inflated form of "Wrote the release checklist our QA team still uses." | The quote at its own scope: you wrote a checklist QA uses. |
| Produced live-service games | Inflated form of "4 years as an associate producer at a puzzle-game studio." | The quote at its own scope. Limit, as this pack's observation: the material does not say the title was live-service. |
| Has led a team | Your stated negative: "Never led a team" | "I have never led a team." Plain acknowledgment, with no slot. |
| Has worked on in-app purchase games | Your stated negative: "never worked on a game with in-app purchases" | "I have never worked on a game with in-app purchases." Followed by the plan in B4. |

## Sources

**Provided documents:** the JD text and your background notes, both in your message. No CV file, no dossier, no working-style assessment.

**Research tier:** L1, searches 4 of 6, fetches 0 of 2. Every search was refused because the search permission was not granted. No results came back, so no research claim is in this pack.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Would have moved the values cheat sheet. Not built, because no values-style round is detected without it. |
| 2. Saltmarsh Games interview process, live operations producer | unavailable | Would have moved the loop structure and the persona weights. Weights here are a hiring-manager prior. |
| 3. Saltmarsh Games strategy and recent news | unavailable | Would have moved the CO questions. None are written; the CASE questions are generic. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Would have moved the interviewer read and a reverse question tied to their path. Both absent. |
| 5. Representative JD for this title | skipped | The JD in your message fixes the fit snapshot and the JD-tagged questions. |

Searches sent, all refused:
- "Saltmarsh Games values": refused
- "Saltmarsh Games interview process live operations producer": refused
- "Saltmarsh Games mobile games strategy news": refused
- "Tobias Wrenfield Saltmarsh Games": refused

## Upgrade menu

- Web search permission, or the Saltmarsh values page pasted → values cheat sheet and grounded CO and CASE questions. Until then, the CASE questions are generic.
- The round format from the recruiter, in one email → confirms the persona weights and whether the round is a panel or one-to-one.
- Tobias Wrenfield's public profile or a bio, pasted → an interviewer read and a reverse question tied to their career path.
- The name of the live title your content drops ran on, and what a drop contained → makes F1, B2 and E1 more specific, in your own words.
- The release checklist's section headings → rehearsal on C3 in specifics.
- Hours you have before Friday → a prioritised prep schedule. Without it, the full pack stands.
- A tuesday-dossier.md → verified evidence in place of the inferred rows, F5 and F8.
