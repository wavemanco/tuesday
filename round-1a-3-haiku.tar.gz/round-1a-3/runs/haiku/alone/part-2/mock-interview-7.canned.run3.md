Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-2-rooms-case-7-canned-6b53a14a/00191c2e-40ba-4676-90d0-762cc256b8a1/scratchpad/saltmarsh_games_live_operations_producer_interview_pack.md`. It is built from your JD and background only, with no company research yet, so the company-specific parts are thin and the case questions are generic.

# Live Operations Producer, Saltmarsh Games: interview prep pack

Candidate: Femi (they/them). Interviewer: Tobias Wrenfield, Head of Live Operations. Format: 60 minutes, Friday. Relationship and round type not yet confirmed; the persona weights assume a hiring-manager round.

## How to use

Personas describe how a question arrives. Types describe what is being scored:

- **VAL**: behavioral and values alignment
- **EXP**: your own experience, tested for attribution
- **JD**: the job's stated responsibilities and qualifications
- **CO**: company and strategy knowledge
- **CASE**: a live problem from the role

This is scaffolding, not a script. Say it in your own words.

Not included, and why: prep triage (prep time not stated), graded deliverables (none declared), grounding brief (no research), reading the interviewer (only a title is known), values cheat sheet (no published values in hand), delivery coaching (no assessment provided).

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title, your main title. Two titles are not shown, so do not stretch the claim. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you ever planned across more than one title, say how; if not, say so plainly, then describe how you would split one calendar across two titles. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | low | [inferred] | discovery | Your material does not show coordinating these teams on a drop. That is silence, not a gap you stated. Answer slot: name the teams you coordinated with on a drop and what each had to deliver; if one was not involved, say so plainly. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Adjacent: it shows presenting KPIs, not owning a post-event review. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you ran a review after a live update, say what it covered; if not, say so and say how you would run one. |
| F4 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | Reaches the requirement in other terms. Bridge reworded from that quote only: "I presented the monthly retention numbers to the studio head." The probe on counting is in bank C. |
| F5 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | Already says what the JD asks. Say it as it stands. Expect a probe on how the calendar was kept. |
| F6 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | Bridge reworded from that quote only: "I wrote the release checklist our QA team still uses." Answer slot: if you ran each release against the checklist, say so; if you only wrote it, say that. |
| F7 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | Shows written work others use, not that the writing is clear. Answer slot: name a document of yours that others acted on and what it was for; if none comes to mind, say so and say what you would show them. |
| F8 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message); "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | low | [inferred] | discovery | Your material does not say the main title ran live updates for the whole period. Answer slot: say which years it ran with ongoing updates and what you were on it for; if that falls short of three years, say so plainly. |

Two gaps you named are not in the JD: leading a team, and in-app purchases. They appear in the prohibited list and the banks, because interviewers ask about them anyway.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the calendar across two titles | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title for the last two years." Limit, in the pack's analysis: your material names one title. |
| Owned the post-event review and its KPIs | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." Limit, in the pack's analysis: your material shows presenting, not owning a review. |
| Defined the retention metrics | Inflated form of F4 | The same quote. Limit, in the pack's analysis: presenting the numbers, not defining them. |
| Ran every release against the checklist | Inflated form of F6 | "Wrote the release checklist our QA team still uses." Limit, in the pack's analysis: writing it, not running each release. |
| Led a team | Your own negative: "Never led a team" | Plain acknowledgment: "I haven't led a team." |
| Worked on a game with in-app purchases | Your own negative: "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Skeptic | Quiet probes on the scope gaps: two titles, four teams, live-service years, leadership | High. Hiring-manager prior; six fit rows (F1, F2, F3, F6, F7, F8) carry answer slots | Rehearse A2 until it is plain; name the scope you ran before anyone probes it | 5 |
| Case / Strategist | A live problem on a calendar, a post-event review or a release sequence | High. Hiring-manager prior; the JD names the calendar and the review | Clarify before structuring; state the objective first | 4 |
| Data-Driven Prober | Asks how the retention numbers were counted | Medium-high. The JD names retention metrics and KPIs; your CV line is a presented figure | Say what you know about the counting; say plainly what you do not | 3 |
| Pressure | Time-boxed challenge on leadership or in-app purchases | Medium. The two sourced negatives are what it would press on | Hold through two follow-ups, then concede the exact gap | 2 |
| Peer Evaluator | Seam questions from design, art and engineering | Medium. Only if the hour includes peers; the JD's coordination line suggests it may | Propose seam principles; reciprocity framing | 2 |
| Conversational | A warm opener, and a casual question about what you are playing | High as an opener. Casual questions are still scored | A 90-second arc; no improvised history | 2 |

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you ran the weekly content-drop calendar for your main title." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Tell the calendar in your own words: the weekly cadence, the two years, the part you set. Answer slot: which parts were yours to set and which were set by others; say it plainly. | F5 is the strongest fit row and the likeliest opener for a probe. EXP tests what was yours. |
| A2 | "The role plans the live-events calendar for two titles. What have you planned across more than one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | **Highest-ROI rehearsal in this pack.** Answer from the one title first. Answer slot: if you ever planned across more than one, say how; if not, say so plainly, then describe how you would split one calendar across two. Hold through two follow-ups by returning to the title you ran. | F1 is where the JD's scope presses hardest. Rehearsing the honest second branch matters most. |
| A3 | "When an update needs design, art, engineering and community at once, how do you keep it on track?" | JD | [inferred] | Describe the mechanism you would use: one schedule, a named owner per team, a go or no-go checkpoint. Answer slot: if you did this on a drop, say which teams and what each had to deliver; if one was not involved, say so. | Raised by the JD's coordination line. Asks for a method, so no claim about your past beyond the slot. |
| A4 | "Which of your four years at the puzzle-game studio had the main title running with ongoing updates?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" and "I ran the weekly content-drop calendar for our main title for the last two years." | Say which years had ongoing updates and which you were on the main title for. Answer slot: if the title ran with updates for the full period, say so; if only part, say which part and what you did in the rest. If it falls short of three years of live-service, say so plainly. | F8. The honest answer carries the weight here, because the 3+ years requirement is measured against it. |
| A5 | "This role coordinates four teams. Where have you had to get people to commit to a date you did not control?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | If asked about leadership: "I haven't led a team." Then the nearest real example in your own words. Answer slot: if no such time comes to mind, say so plainly, then describe how you would secure commitments across four teams. | The leadership gap comes up through the coordination requirement. Answer it directly, then give what your material carries. |

### B. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Retention is down this month. Plan the next six weeks of content for one title. What do you need to know first?" | CASE | [generic] | Clarify first: size and timing of the drop, where it sits in the player funnel, what is scheduled, team capacity, QA's sign-off window. Then objective, segmentation, options, risks, metrics. 90 to 120 seconds. | R1 and R7 in a live problem. No claim about the studio or your history. |
| B2 | "A live event lands under its participation plan. Walk me through the post-event review you would run." | CASE | [generic] | Restate the planned figure and its assumption first. Split the result by segment and by the event's stages; decide what changes in the next calendar; say what you would report and to whom. | The post-event review the JD asks you to own. A case, not a claim about your history. |
| B3 | "How would you sequence next quarter's updates around the release checklist with QA?" | JD | [inferred] | Name the constraints: release windows, QA's capacity, the checklist as a gate. Propose a sequencing rule; say what you would need from QA. | Raised by the JD's release checklist line. No claim about your past. |
| B4 | "A bug is hitting a live event's reward flow. Who decides whether to pull the event, and on what evidence?" | CASE | [generic] | Name the owners: engineering for the fix, QA for sign-off, the producer for the call, community for messaging. Set criteria: scale of impact, and whether the change can be reversed. | Cross-functional judgment the coordination line implies. Generic on purpose. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Defend-the-number move: say what you know about the counting, in your own words. Name the assumption behind the figure you would defend least, if you know one, before they do. Answer slot: if you built or checked the counting, say which step; if you only presented the figures, say so, and who counted them if you know. | F4 and F3. The pack supplies no method, baseline or definition. |
| C2 | "Tell me about a time a KPI you reported was challenged. What did you do?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Open prompt. If a challenge came to your numbers, tell it: you presented, the figures were questioned, what you did. Answer slot: if none came, say so plainly and name the nearest question you handled about the numbers. | The KPI requirement is in the JD. Beats beyond the quote are a slot, not a story. |
| C3 | "Has the release checklist ever stopped a release? If so, what changed afterwards?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Open prompt. Answer slot: if it stopped a release, say what it caught and what changed; if not, say so and describe how you would use it as a gate. | F6. A plain yes or no is an honest branch the question allows. |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You have never worked on a game with in-app purchases. What would you need to learn first?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "I ran the weekly content-drop calendar for our main title for the last two years." | Hold: "I haven't worked on a game with in-app purchases." Then the calendar you ran, as what you can speak to. Concede exactly what you have not seen: how purchase events change a calendar. Say how you would learn it. | The sourced negative is the one that will be pressed. Hold, then concede the exact gap; do not fold on the calendar. |
| D2 | "You have never led a team. Why take on a role that coordinates four of them?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Sixty seconds. "I haven't led a team." Hold the coordination you did: "Wrote the release checklist our QA team still uses." Concede what you expect to learn about the people side. Hold through two follow-ups. | Pressure on the leadership gap. The hold is only what your quotes carry. |

### E. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Design and art share every update with you. Where would you draw the line between your call and theirs?" | JD | [inferred] | Propose a principle: the producer owns dates and scope, the leads own craft, disagreements settle within a set time-box, then escalate. A principle, not a history. | The seam the coordination line creates. No claim about your past. |
| E2 | "What would engineering need from you to plan around two titles, and what would you give back?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Reciprocity framing: what you bring to their planning. Answer slot: if your calendar gave engineering a fixed schedule to plan against, say how; if not, say so and say what you would give them. | Engineering is named in the JD. Peers score partnership, not your needs. |

### G. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the last few years." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." | A 90-second arc in this order: the four years, the two years on the weekly calendar, then the retention presentation. Stop there. Add nothing you have not said. | Scored casually. The arc is built only from your own sentences. |
| G2 | "What are you playing at the moment, and what would you change about how it runs live?" | JD | [generic] | Name a game you actually play, if any, and one live change you would make, with its reason. If you play none that is live, say so and name the nearest one you have studied. | Casual, but touches the retention requirement. A view, not a fact about you. |

## Coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A2, B1, F1 |
| Coordinate design, art, engineering and community teams on each update | A3, A5, E1, E2 |
| Own the post-event review and the KPIs it reports | B2, C2 |
| Manage the release checklist with QA | B3, C3, B4 |
| 3+ years producing live-service games or apps | A4 |
| Experience running a content calendar | A1 |
| Comfortable with player-retention metrics | C1 |
| Clear written communication | none, and why: the round as described has no written exercise; B1 scores how you structure a problem out loud |

## Reverse questions

Your interviewer profile is only a title, so none of these is tied to Tobias's own career path. That is in the upgrade menu.

1. "How does a content drop get decided today between live operations and the title's design lead? Who has the final say on scope?" Why it lands: it shows you already think about the producer's seam.
2. "What did the last post-event review change in the following calendar?" Why it lands: it names the review loop the role owns and asks what it has done.
3. "Which KPI does the team treat as the health check for each title, and how is it counted?" Why it lands: it tests your retention vocabulary against his definitions.
4. "What would the first ninety days need to look like for this role to count as a success?" Why it lands: it sets KPI ownership as the measure.
5. "Where does QA's sign-off sit in the release checklist today, and where has it caused friction?" Why it lands: it shows you know the checklist is a gate, not a formality.

## Run order for the hour (added at your request)

A sketch assuming one hiring-manager session. Tobias's actual agenda is unknown.

| Minutes | Segment | Questions |
|---|---|---|
| 0 to 5 | Opener | G1 |
| 5 to 20 | Your calendar and the two-title scope | A1, A2, A4 |
| 20 to 35 | Case work | B1, B2 |
| 35 to 45 | Coordination and leadership | A3, A5, E1 |
| 45 to 52 | Metrics and the checklist | C1, C2, C3 |
| 52 to 58 | Your reverse questions | the five above |
| 58 to 60 | Close | none |

## Sources

- Provided documents: your job description and your background message. Nothing else was supplied.
- Research tier: L0. No searches or fetches ran; research depth has not been agreed.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet. Research not yet consented. |
| 2. Saltmarsh interview process, role family | unavailable | Loop structure and persona weights. Research not yet consented. |
| 3. Saltmarsh strategy and recent news | unavailable | Company and strategy bank (CO). Research not yet consented. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Reading the interviewer; a tailored reverse question. Research not yet consented. |
| 5. Representative JD for the title | skipped | Your supplied JD fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Your answer to the research question → Saltmarsh's published values (values cheat sheet), its interview process (loop structure and persona weights), its current strategy (a company bank), and Tobias's public talks and career (a reading of him and a tailored reverse question)
- The round type and Tobias's relationship to you → persona weights recomputed; Skeptic and Case banks retuned to the round
- The title's calendar, the release checklist, or a retention export you can share → F1, F5 and F6 move from medium toward high, with the artifact named
- Whether the puzzle title ran ongoing updates across your four years → F8 moves from low, and A4 gets a grounded answer
- How many days you have before Friday → a prioritized prep triage section

---

I can play a live drill: the Skeptic on A2, the two-title question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your hiring manager, a peer, or a skip-level, and is Friday the only session or one of several?
Shall I run research at the default depth on Saltmarsh's values, interview process and current strategy, plus Tobias's public talks and career?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_games_live_operations_producer_interview_pack.md -----
# Live Operations Producer, Saltmarsh Games: interview prep pack

Candidate: Femi (they/them). Interviewer: Tobias Wrenfield, Head of Live Operations. Format: 60 minutes, Friday. Relationship and round type not yet confirmed; the persona weights below assume a hiring-manager round.

## How to use

Personas describe how a question arrives. Types describe what is being scored:

- **VAL**: behavioral and values alignment
- **EXP**: your own experience, tested for attribution
- **JD**: the job's stated responsibilities and qualifications
- **CO**: company and strategy knowledge
- **CASE**: a live problem from the role

This is scaffolding, not a script. Say it in your own words.

Built from your job description and your background only. No company research has run yet, so company-specific content is absent and the case questions are generic (`[generic]`).

Sections not included, and why: prep triage (prep time not stated), graded deliverables (none declared), grounding brief (no research), reading the interviewer (only a title is known), values cheat sheet (no published values in hand), delivery coaching (no assessment provided).

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title, your main title, on a weekly content-drop calendar. Two titles are not shown, so do not stretch the claim. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you ever planned across more than one title, say how; if you did not, say so plainly, then describe how you would split one calendar across two titles. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | low | [inferred] | discovery | Your material does not show coordinating these teams on a drop. That is silence, not a gap you stated. Answer slot: name the teams you coordinated with on a drop and what each had to deliver; if one was not involved, say so plainly. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | The quote is adjacent: it shows presenting KPIs, not owning a post-event review. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you ran a review after a live update, say what it covered and what it reported; if you did not, say so and say how you would run one. |
| F4 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Bridge reworded from that quote only: "I presented the monthly retention numbers to the studio head." The probe on how the figures were counted is in bank C. |
| F5 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote already says what the JD asks. Say it as it stands. Expect a probe on how the calendar was kept, since no artifact has been inspected. |
| F6 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Bridge reworded from that quote only: "I wrote the release checklist our QA team still uses." Answer slot: if you ran each release against the checklist, say so; if you only wrote it, say that. |
| F7 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | The quote shows written work that others use, not that the writing is clear. Answer slot: name a document of yours that others acted on and what it was for; if none comes to mind, say so and say what you would show them. |
| F8 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message); "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | low | [inferred] | discovery | Four years at a puzzle-game studio, and two years of content drops. Your material does not say the main title ran live updates for the whole period. Answer slot: say which years the main title ran with ongoing updates and what you were on it for; if that falls short of three years, say so plainly. |

Two gaps you named are not in the JD: leading a team, and in-app purchases. They appear in the prohibited list and in the banks, because interviewers ask about them anyway.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the calendar across two titles | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title for the last two years." The limit, in the pack's own analysis: your material names one title. |
| Owned the post-event review and its KPIs | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." The limit, in the pack's analysis: your material shows presenting, not owning a review. |
| Defined the retention metrics | Inflated form of F4 | The same quote. The limit, in the pack's analysis: your material shows presenting the numbers, not defining them. |
| Ran every release against the checklist | Inflated form of F6 | "Wrote the release checklist our QA team still uses." The limit, in the pack's analysis: your material shows writing it, not running each release. |
| Led a team | Your own negative: "Never led a team" | Plain acknowledgment: "I haven't led a team." |
| Worked on monetized games, or in-app purchases | Your own negative: "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Skeptic | Quiet probes on the scope gaps: two titles, four teams, years of live-service, leadership | High. Hiring-manager prior, and six fit rows (F1, F2, F3, F6, F7, F8) carry answer slots | Rehearse A2 until it is plain; name the scope you ran before anyone probes it | 5 |
| Case / Strategist | A live problem on a calendar, a post-event review or a release sequence | High. Hiring-manager prior; the JD names the calendar and the review | Clarify before structuring; state the objective first | 4 |
| Data-Driven Prober | Asks how the retention numbers were counted | Medium-high. The JD names retention metrics and KPIs, and your CV line is a presented figure | Say what you know about the counting; say plainly what you do not | 3 |
| Pressure | Time-boxed challenge on not leading a team, or on in-app purchases | Medium. The two sourced negatives are what it would press on | Hold the position through two follow-ups, then concede the exact gap | 2 |
| Peer Evaluator | Seam questions from design, art and engineering | Medium. Only if the hour includes peers; the JD's coordination line suggests it may | Propose seam principles; reciprocity framing | 2 |
| Conversational | A warm opener, and a casual question about what you are playing | High as an opener. Casual questions are still scored | A 90-second arc; no improvised history | 2 |

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you ran the weekly content-drop calendar for your main title." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Tell the calendar in your own words: the weekly cadence, the two years, and the part you set. Answer slot: which parts of the calendar were yours to set and which were set by others; say it plainly. | F5 is the strongest fit row and the likeliest opener for a probe. EXP tests what was actually yours. |
| A2 | "The role plans the live-events calendar for two titles. What have you planned across more than one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | The highest-ROI rehearsal in this pack. Answer from the one title first, in your words. Answer slot: if you ever planned across more than one title, say how; if you did not, say so plainly, then describe how you would split one calendar across two titles. Hold through two follow-ups by returning to the title you ran. | F1 is where the JD's scope presses hardest, so expect this in some form. Rehearsing the honest second branch matters more than rehearsing a first. |
| A3 | "When an update needs design, art, engineering and community at once, how do you keep it on track?" | JD | [inferred] | Describe the mechanism you would use: one schedule, a named owner for each team, a go or no-go checkpoint. Answer slot: if you did this on a drop, say which teams and what each had to deliver; if one was not involved, say so plainly. | Raised by the JD's coordination line. The question asks for a method, so the guidance makes no claim about your past beyond the slot. |
| A4 | "Which of your four years at the puzzle-game studio had the main title running with ongoing updates?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" and "I ran the weekly content-drop calendar for our main title for the last two years." | Say which years had ongoing updates and which of them you were on the main title for. Answer slot: if the title ran with updates for the full period, say so; if only part, say which part and what you did in the rest. If the live-service years fall short of three, say so plainly. | F8. The honest answer is the one that carries the most weight here, because the 3+ years requirement is measured against it. |
| A5 | "This role coordinates four teams. Where have you had to get people to commit to a date you did not control?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment if asked about leadership: "I haven't led a team." Then an open answer: a time you got others to commit, in your own words. Answer slot: if no such time comes to mind, say so plainly, then describe how you would secure commitments across four teams. | The leadership gap will come up through the coordination requirement. Answering it directly, with the acknowledgment and then the nearest thing your material carries, scores better than avoiding it. |

### B. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Retention is down this month. Plan the next six weeks of content for one title. What do you need to know first?" | CASE | [generic] | Clarify first: the size and timing of the drop, where it sits in the player funnel, what is already scheduled, team capacity and QA's sign-off window. Then objective, segmentation, options, risks and metrics. Speakable in 90 to 120 seconds. | R1 and R7 in a live problem. `[generic]`: no claim about the studio or your history. |
| B2 | "A live event lands under its participation plan. Walk me through the post-event review you would run." | CASE | [generic] | Restate the planned figure and the assumption behind it first. Then split the result by segment and by the event's stages, decide what changes in the next calendar, and say what you would report and to whom. | R3 is the post-event review the JD asks you to own. The question is a case, not a claim about your history. |
| B3 | "How would you sequence next quarter's updates around the release checklist with QA?" | JD | [inferred] | Name the constraints: release windows, QA's capacity, the checklist as a gate. Propose a sequencing rule and say what you would need from QA. | Raised by the JD's release checklist line. The guidance makes no claim about your past. |
| B4 | "A bug is hitting a live event's reward flow. Who decides whether to pull the event, and on what evidence?" | CASE | [generic] | Name the owners: engineering for the fix, QA for sign-off, the producer for the call, community for messaging. Set criteria: scale of the impact and whether the change can be reversed. | Cross-functional judgment, which the coordination line implies. Generic on purpose. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | The defend-the-number move: say what you know about how the figures were counted, in your own words. Name the assumption behind the figure you would defend least, if you know one, before they do. Answer slot: if you built or checked the counting, say which step; if you only presented the figures, say so and say who counted them, if you know. | F4 and F3. Figures raise this slot; the pack does not supply a method, baseline or definition. |
| C2 | "Tell me about a time a KPI you reported was challenged. What did you do?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Open prompt. If a challenge came to your retention numbers, tell it: you presented, the figures were questioned, and what you did. Answer slot: if no challenge came, say so plainly and name the nearest question you handled about the numbers. | The KPI requirement is in the JD. The beats beyond the quote are a slot, not a story. |
| C3 | "Has the release checklist ever stopped a release? If so, what changed afterwards?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Open prompt. Answer slot: if it stopped a release, say what it caught and what changed; if it has not, say so plainly and describe how you would use it as a gate. | F6. A yes or no here is the honest branch the question allows. |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You have never worked on a game with in-app purchases. What would you need to learn first?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "I ran the weekly content-drop calendar for our main title for the last two years." | Hold: plain acknowledgment, "I haven't worked on a game with in-app purchases." Then hold the calendar you ran as the thing you can speak to. Concede exactly what you have not seen: how purchase events change the calendar. Name how you would learn it. | The sourced negative is the one the interviewer will press. Hold, then concede the exact gap, and do not fold on the calendar. |
| D2 | "You have never led a team. Why take on a role that coordinates four of them?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Sixty seconds, time-boxed. Plain acknowledgment: "I haven't led a team." Hold the coordination you did: "Wrote the release checklist our QA team still uses." Concede what you expect to learn about the people side. Hold through two follow-ups. | Pressure on the leadership gap. The hold is only what your quotes carry. |

### E. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Design and art share every update with you. Where would you draw the line between your call and theirs?" | JD | [inferred] | Propose a principle: the producer owns dates and scope, the leads own their craft, disagreements settle within a set time-box, then escalate. A principle, not a history. | The seam the JD's coordination line creates. The guidance makes no claim about your past. |
| E2 | "What would engineering need from you to plan around two titles, and what would you give back?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Reciprocity framing: what you bring to their planning. Answer slot: if your calendar gave engineering a fixed schedule to plan against, say how; if it did not, say so and say what you would give them. | Engineering is named in the JD. Peer questions are scored on partnership, not on what you need. |

### G. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the last few years." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." | A 90-second arc in this order: four years as an associate producer at a puzzle-game studio, two years on the weekly calendar, then the retention presentation. Stop there. Add nothing you have not said here. | The opener is scored casually. The arc is built only from your own sentences. |
| G2 | "What are you playing at the moment, and what would you change about how it runs live?" | JD | [generic] | Name a game you actually play, if any, and one live change you would make, with its reason. If you play none that is live, say so and name the nearest one you have studied. | Casual, but it touches the retention requirement. `[generic]`: it asks for a view, not a fact about you. |

## Coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A2, B1, F1 |
| Coordinate design, art, engineering and community teams on each update | A3, A5, E1, E2 |
| Own the post-event review and the KPIs it reports | B2, C2 |
| Manage the release checklist with QA | B3, C3, B4 |
| 3+ years producing live-service games or apps | A4 |
| Experience running a content calendar | A1 |
| Comfortable with player-retention metrics | C1 |
| Clear written communication | none, and why: the round as you have described it has no written exercise. B1 scores how you structure a problem out loud. |

## Reverse questions

Your interviewer profile is only a title, so none of these is tied to Tobias's own career path. That is in the upgrade menu.

1. "How does a content drop get decided today between live operations and the title's design lead? Who has the final say on scope?" Why it lands: it shows you already think about the producer's seam.
2. "What did the last post-event review change in the following calendar?" Why it lands: it names the review loop the role owns, and asks what it has actually done.
3. "Which KPI does the team treat as the health check for each title, and how is it counted?" Why it lands: it tests your retention vocabulary against his definitions.
4. "What would the first ninety days need to look like for this role to count as a success?" Why it lands: it sets the KPI ownership as the measure.
5. "Where does QA's sign-off sit in the release checklist today, and where has it caused friction?" Why it lands: it shows you know the checklist is a gate, not a formality.

## Run order for the hour (added at your request)

This is a sketch of the order, assuming one hiring-manager session. Tobias's actual agenda is unknown.

| Minutes | Segment | Questions |
|---|---|---|
| 0 to 5 | Opener | G1 |
| 5 to 20 | Your calendar and the two-title scope | A1, A2, A4 |
| 20 to 35 | Case work | B1, B2 |
| 35 to 45 | Coordination and leadership | A3, A5, E1 |
| 45 to 52 | Metrics and the checklist | C1, C2, C3 |
| 52 to 58 | Your reverse questions | the five above |
| 58 to 60 | Close | none |

## Sources

- Provided documents: your job description, and your background message. No other documents were supplied.
- Research tier: L0. No searches or fetches ran; research depth has not been agreed yet.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet (section 10). Research not yet consented. |
| 2. Saltmarsh interview process, role family | unavailable | Loop structure and persona weights. Research not yet consented. |
| 3. Saltmarsh strategy and recent news | unavailable | Company and strategy bank (CO). Research not yet consented. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Reading the interviewer, and a tailored reverse question. Research not yet consented. |
| 5. Representative JD for the title | skipped | Your supplied job description fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Your answer to the research question → Saltmarsh's published values (a values cheat sheet), its interview process (loop structure and persona weights), its current strategy (a company bank), and Tobias's public talks and career (a reading of him and a tailored reverse question)
- The round type and Tobias's relationship to you → persona weights recomputed, and the Skeptic and Case banks retuned to the round
- The title's calendar, the release checklist, or a retention export you can share → F1, F5 and F6 move from medium toward high, with the artifact named
- Whether the puzzle title ran ongoing updates across your four years → F8 moves from low, and A4 gets a grounded answer
- How many days you have before Friday → a prioritized prep triage section
