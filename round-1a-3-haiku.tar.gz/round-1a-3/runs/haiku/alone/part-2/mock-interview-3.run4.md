I'll read the reference files the skill requires before building anything, starting with the output template, rubric, personas, and research checklist.
The skill's research tier is L1 by default, and the JD, CV and round details are all missing. I'll load the search tool and run the L1 targets on Stripe's values and interview process.
The search permission was denied, so no research ran. I'll build the pack from what you've given me, with the gaps marked, and save it to the scratchpad.
Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-2-rooms-case-3-denied-f0343196/862d463e-8e2d-48fd-975a-29c535663add/scratchpad/stripe_product_operations_manager_interview_pack.md`. I built it without a job description or CV, so every requirement is generic and the answers are scaffolds until you add your own material. I also couldn't research Stripe's values or interview process, because search permission was denied. The pack has no values cheat sheet, and I haven't used anything from memory in its place.

Say the word and I'll play the Skeptic on B1, the question the pack names as your highest-value prep, since it's the one most likely to come up in some form.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

Two questions would reshape the pack. Who are you meeting, and is the final a single conversation or several sessions? And if you paste the job description and a short summary of your past work, I can replace the generic rows with ones built on your own sentences.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product_operations_manager_interview_pack.md -----
# Interview pack: Stripe, Product Operations Manager, final round

Session mode, one conversation. Relationship to the interviewer is unknown, so persona weights are flat and that weakens the pack. No JD and no CV were provided, so every requirement is `[generic]` and every evidence cell reads `none given`.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioral/values, **EXP** your past work, **JD** the role's stated duties, **CO** company knowledge, **CASE** live problem.
- Guidance is scaffolding, not a script. Speak it in your own words. Each guidance cell runs about 90 to 120 seconds spoken.

## Prep triage

Prep time was not stated, so no schedule is given. Do these three things, in order:

1. Write one 90-second answer to the "walk me through your career" question (E1), using only sentences you can stand behind.
2. Rehearse the Skeptic question B1 until the honest branch comes out plainly.
3. Rehearse the CASE question A1 out loud, with the clarifying questions first.

Everything else is insurance.

## Fit snapshot (worksheet variant)

No background was supplied, so every row below is a worksheet row. Requirements are role-family prose with no source, so each row is `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Designing and running operating processes across teams (role family, generic) | none given | none | [generic] | discovery | Answer slot: name one process you designed or ran, in your own words. If none, say so plainly and say how you would start. |
| F2 | Turning operating data into decisions: metrics, dashboards, reviews (role family, generic) | none given | none | [generic] | discovery | Answer slot: name one metric you used to judge a change and how it was counted. If none, say so plainly and say what you would measure first. |
| F3 | Coordinating launches and rollouts with product, engineering and go-to-market (role family, generic) | none given | none | [generic] | discovery | Answer slot: name one cross-team launch or rollout and your part in it. If none, say so plainly and describe how you would run one. |
| F4 | Influencing stakeholders who do not report to you (role family, generic) | none given | none | [generic] | discovery | Answer slot: name one time you got a decision through without authority over the people involved. If none, say so and describe your approach. |

Gate rows: none known. The JD would show whether any requirement is a gate.

## Prohibited claims

Nothing is listed yet. The list is built from quoted sentences you give, and none have been given. Until you give them, the pack claims no experience for you at all. Do not claim a process, metric or launch in an interview unless you can name the real one.

## Persona table

Relationship is unknown, so weights are flat and the rounds below are a blend. Final rounds often combine several sessions, but the schedule is unknown. Loop structure is not established, so no archetype is assumed.

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live ops problem: a launch slipping, a process breaking at scale | High, flat weight | Clarify, then objective, then segments, then approach, then metrics, then risks. Think aloud. |
| Skeptic | "Where is the operations experience?" and "why this role, why now?" | High, flat weight | Rehearse the thinnest-evidence question until plain. Give a ramp plan. |
| Data-Driven Prober | "How was that metric counted?" | Medium | Name the metric, the counting method and the assumption you would defend least. Say plainly what you do not know. |
| Pressure | Time-boxed challenge to a claim | Medium | Pause, restate, hold through two follow-ups, then concede specifically. |
| Conversational | Casual opener that is still scored | Medium | Have a 90-second arc ready. |
| Values / Behavioral | Stakeholder-conflict story | Low. A values round is not established, so it is not assumed. | Use a story only if you can name one. Otherwise say so. |

## Question banks

### Bank A: Case / Strategist (top weight, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch you are running slips two weeks, and two teams blame each other. What do you do first?" | CASE | [generic] | Clarify what slipped, for whom, and by what date. Name the owner of each dependency. Get the facts before the decision. Then the decision, then the message to each team. | Generic live problem from the role family; no past claim is made. |
| A2 | "A process that works for ten teams is breaking at forty. How would you diagnose it?" | CASE | [generic] | Break the process into steps. Find where volume or handoffs multiply. Pick one fix to test first and name how you would know it worked. | Scales the Case persona to the role; no past claim. |
| A3 | "What would you want to know in your first 30 days before proposing any process change?" | JD | [generic] | List three questions, most-important first. Say how you would get each answer. | Tests whether you change process only after understanding it. |
| A4 | "A cross-functional team asks you to take on a recurring report that nobody owns. Walk me through your decision." | CASE | [generic] | Decide whether it is an operations job. Name what you would stop doing to make room. Name who signs off. | Tests judgment about scope; no past claim. |
| A5 | "How would you decide which internal process to standardize first?" | CASE | [generic] | Score candidates by pain, reach and cost of change. Pick one and state the trade-off. | Tests prioritization with a stated method. |

### Bank B: Skeptic (high weight, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What is your experience with product operations, and where is it thinnest?" | JD | [generic] | Name the closest work you did, in your own words. If none fits, say so plainly, then say how you would learn it. Answer slot: if the closest work included a process you designed, name it; if not, say so. | Probes the largest likely gap. Answer slot because no sentence of yours exists yet. |
| B2 | "Which part of this role would be weakest for you on day one?" | JD | [generic] | Name one part honestly. Give a concrete ramp plan. Do not bluff. | Calibrated candor is what the Skeptic scores. |
| B3 | "Why this role, and why now?" | VAL | [generic] | Answer in your own words. Do not add motives you have not stated. | Motivation consistency; the most common final-round probe. |
| B4 | "Tell me about a time a process you proposed did not stick." | EXP | [generic] | Open prompt: choose a real instance. Describe what you did and why it failed. If you have no such time, say so plainly, then describe how you would handle it. | Tests honesty about failure. |

### Bank C: Data-Driven Prober (medium weight, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a metric you used to judge whether an operational change worked. How was it counted?" | EXP | [generic] | Open prompt. Pick one real metric and say how it was counted. Answer slot: if you did not track one, say so and describe what you would track. | Prober checks counting method and attribution. |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name the weakest assumption in your own words. If you cannot name one, say so. | The weakest-assumption move converts a gotcha into a credibility gain. |
| C3 | "How do you know an operating review is producing decisions rather than updates?" | JD | [generic] | Name the signal: a decision recorded, an owner assigned, a follow-up date. | Tests how you measure a forum. |

### Bank D: Pressure (medium weight, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run this function for years?" | JD | [generic] | Pause. Restate the question. Answer from what you can truthfully claim. Hold the position through two follow-ups, then concede specifically. | Tests composure under a challenge to your candidacy. |
| D2 | "That result. How much of it was actually you?" | EXP | [generic] | Name your part and the team's part, in your own words. Do not claim more than you did. | Honesty under probing; applies to any result you bring. |

### Bank E: Conversational (medium weight, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through your career in two minutes." | EXP | [generic] | Prepare a 90-second arc from your own sentences. Keep to facts you can name. | The most common opener; sets the tone. |
| E2 | "What have you been reading about operations lately?" | CO | [generic] | Name one thing you read and what you took from it. | Scored casually; signals interest. |

### Bank F: Values / Behavioral (low weight, 1 question)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you had to deliver an unpopular decision to a senior stakeholder." | VAL | [generic] | Open prompt. Pick a real instance and describe what you said and what happened. If none comes to mind, say so plainly, then describe how you would handle it. | Included because final rounds often hold one; not confirmed for Stripe. |

Coverage: no JD was supplied, so the requirement-coverage line is not built. It can be built once a JD is provided.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would make this role clearly successful at six months?" | Shows you plan for outcomes, not tasks. |
| R2 | "Which operating process here is under the most strain right now?" | Shows you want the real problems. |
| R3 | "How is operations' work measured here, and who reads those measures?" | Shows you care how success is judged. |
| R4 | "What does this final round assess that the earlier rounds did not?" | Shows you want to prepare for the right thing. |
| R5 | "What would a strong first 90 days look like?" | Gives you a concrete plan to repeat back. |

## Sources

- Provided documents: none. No JD, CV or recruiter guidance was supplied.
- Searches sent: "Stripe company values principles" and "Stripe interview process product operations manager final round". Both were refused because search permission was not granted. No results returned.

Research tier: L1, targeted; no search returned results

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Values cheat sheet, section 10. Would have named the published values. Refused. |
| 2. `Stripe interview process product operations manager` | unavailable | Loop structure and persona weights. Would have named the rounds. Refused. |
| 3. `Stripe strategy` / recent news | unavailable | Company-knowledge bank (CO). Not sent: no search permission. |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given. |
| 5. representative `Product Operations Manager` JD | unavailable | Would have grounded the fit snapshot and JD questions as `[inferred]`. Not sent: no search permission. |

## Upgrade menu

- The round type and who you are meeting → reweights the persona table and the reverse questions
- Your job description, pasted → turns the `[generic]` requirements into `[grounded]` rows and builds the requirement-coverage line
- Your CV or a short list of your past work → fills the evidence cells, lets the prohibited list take real entries, and turns the answer slots into story maps
- Search permission for the company's values and interview process → adds the values cheat sheet and the loop structure
- The interviewer's name → a tailored reverse question and persona weights from their public footprint
