Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-2-rooms-case-8-canned-6664b74a/632436f2-5275-4b62-bdcf-8414760ef59c/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md`, and I've attached it. I built it as a three-round loop, with one mini-pack per round, since you gave the round types. Nothing was searched; I worked only from the values, the strategy summary and the recruiter's process you pasted.

The three things to take from it:

- **Biggest gap:** you've never worked in a contact centre and never presented above regional level. Both are JD requirements, so expect them in round 2. B8 is the one to rehearse hardest: hold on your complaints log and spreadsheet, then concede both gaps specifically, with a plan rather than a claimed past.
- **Values:** the material supports Own the Fix and Neighbours, Not Numbers the least. Those answers are scaffolds, with an honest "no such time" branch.
- **Escalation case:** the pack includes a three-run, 20-minute practice plan. The case itself is a generic pattern, since the panel's actual case isn't known.

Two cautions. The strategy figures come from your summary, not the brief, so check them before quoting. And the file marks the "Premise" and "Answer slot" items; where the material is silent, the pack says so rather than filling in an answer for you.

Would you like a live drill? I can play the Skeptic on B8, the question the pack names as highest-ROI prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead prep pack

Three rounds on 29 November 2026. Built 20 November 2026. First version.

- **Round 1:** recruiter, 30 minutes.
- **Round 2:** Head of Member Services, 45 minutes, mostly behavioural. This is your future manager; not yet named.
- **Round 3:** panel of two branch managers, 60 minutes, with a 20-minute complaint-escalation case. The recruiter says the panel also scores the four values. Names not yet assigned.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores:

- **VAL**: behavioural and values alignment. Whether past behaviour shows Ashgrove's published values.
- **EXP**: experience deep-dive. Whether your claims survive scrutiny, and what you actually did.
- **JD**: role requirement. Can you do the listed job, gaps included.
- **CO**: company and strategy knowledge.
- **CASE**: a live problem, reasoned aloud.

Guidance is scaffolding, not a script. Say it in your own words. An **answer slot** is an instruction for the interview: it asks for no reply here, and where the honest answer is "no", that answer is allowed.

## Fit snapshot

Every evidence cell holds your own words, quoted. The only source about your background is your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Your words already reach it: "For six years I've worked in retail banking, the last three as a branch supervisor." Expect a probe on the three supervisor years. |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material shows formal complaints. It does not show they were regulated. Answer slot: if the log followed a complaint rule or deadline, name it and say what it required, in your own words; if not, say so plainly and say how the log was run. |
| F3 | "own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Adjacent work: one branch's log, not the process end to end across branches. Bridge: "At my branch I handled the formal complaints log." Limit stated: one branch. Answer slot: if you had any part of the process beyond the log, say which, in your own words; if not, say what the log covered. |
| F4 | "the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A negative you stated, so it can be said: "I have never worked in a contact centre." Then how you would learn its complaint path, said as a plan, never as a past. |
| F5a | "report monthly on complaint volumes" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | Bridge only the quote: "I built the monthly complaints spreadsheet our regional manager uses." |
| F5b | "resolution times" — JD | none given | none | [grounded] | discovery | Your material does not show whether resolution times were reported. Answer slot: if the spreadsheet showed how long complaints took to close, say how it was measured; if it did not, say so, then say what you would measure first. |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Adjacent: you trained tellers, not supervisors. Bridge: "I trained new tellers on our escalation script." Limit stated: tellers. Answer slot: if you coached any supervisor or team lead on escalations, say what you did; if not, say so. |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Answer slot: if you worked with anyone on a digital or self-service journey, say what it was and your part; if not, say so, and say how you would bring the digital team in. |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A negative you stated: "I've never presented to anyone above regional level." Then how you would prepare, as a plan. |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | Bridge only the quote. Limit stated: your sentence says spreadsheet, and does not name Excel. Answer slot: which Excel features you used, if any, in your own words. |

Gate check: none of the JD requirements is a term or credential gate, so no row is `hard_gate`. The four-year bar is experience, graded on fit.

## Grounding brief

From the July 2026 strategy brief, as summarised in your message. I have not seen the brief itself. Check the figures against it before you quote them.

| Item | What it says | Use in the rounds |
|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | B7 (digital question). Expect it from the Head of Member Services. |
| Branch network | "consolidate eight branches into five hubs over 2027" | A5 (location) and RR-1. Your work may move with the hubs, so ask about it rather than assume. |
| Lending | "launch a small-business lending product in Q1 2027" | Know it exists. It is not in the JD, so do not present it as your area. |
| Competition | "the main competitive pressure is app-only banks" | Use it when asked why members might leave, or what the digital shift is for. |

## Round 1: recruiter screen (30 min)

**Persona weights:** Conversational 4 (A1 to A6), Skeptic light 2 (A7, A8). The recruiter's round is priored to logistics and motivation. The four logistics questions (A3 to A6) are mandatory coverage for a screen, so they sit in the Conversational count without shrinking it. Risk: treating this round as unscored.

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your career so far, in about 90 seconds." | EXP, JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc with the three quotes as its beats, in that order: the years and the supervisor role, then the complaints log, then the spreadsheet. Stop there. The rest is the interviewer's question. | F1, F3 and F5a are the arc. The recruiter's opener is scored, not casual. |
| A2 | "What does complaints work look like day to day in a branch?" | JD, EXP | [grounded] "I handled the branch's formal complaints log" | Describe the log as you ran it. Answer slot for F2: if complaint rules or deadlines governed it, name them and what they required, in your words; if not, say so. | F2 is the regulated-complaints requirement, and this is where it is first probed. |
| A3 | "What salary are you looking for?" | JD | [generic] | Logistics slot. Give your own figure, or ask for the role's band first. Do not estimate, and do not give a range you have not decided. | Pay is a recruiter-screen logistics question. Nothing in your material states a figure. |
| A4 | "When could you start, and what notice do you owe?" | JD | [generic] | Logistics slot. Give your actual notice period in your own words. If you do not know the start date yet, say when you could start. | Notice is a recruiter-screen logistics question. Nothing in your material states it. |
| A5 | "Where would you need to be based?" | JD | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief, as summarised) | Logistics slot. Say where you could work, in your own words. If the hub plan affects you, say so. | The hub plan is the reason location may come up now. |
| A6 | "Why are you leaving your current role?" | EXP | [generic] | Logistics slot. Give your own reason in your own words. Keep it to the reason, not a complaint about the employer. | The reason for leaving is a recruiter-screen logistics question. No reason is in your material. |

### Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A7 | "Why Ashgrove, and why now?" | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter." | Give one reason in your own words that connects to the member-owned model or to a member-facing part of your work. If no such reason is true, say the reason you are applying in plain terms. | Motivation consistency is a light-skeptic check. The recruiter will test whether the answer matches the rest of your CV. |
| A8 | "You haven't worked in a contact centre. Does that matter for this role?" | JD | [grounded] "Never worked in a contact centre" | Say it plainly: "I have never worked in a contact centre." Then give a plan, not a past: how you would learn the contact centre's complaint path in your first month. | The JD names the contact centre (F4). A recruiter who has read the JD will ask. |

### Reverse questions, round 1

- **"What does a strong first six months in this role look like?"** Why it lands: it turns the screen toward outcomes, and tells the recruiter you read the role as a mandate.
- **"Which parts of the complaints process does this role own, and which stay with the branches or the contact centre?"** Why it lands: it tests the JD's "end to end" line directly, and gives you the seam before round 3.
- **"How do you measure a good outcome for complaints work here?"** Why it lands: it shows you already think in volumes and resolution times, which the JD asks for.
- **"Who would I be working with most closely in the first month?"** Why it lands: it names the people you will need, and signals you are planning the job.
- **"What happens after this conversation, and when?"** Why it lands: it sets the timing for the next round and shows you are organised.

## Round 2: Head of Member Services (45 min, mostly behavioural)

**Persona weights:** Values/Behavioral 4 (B1 to B4), Skeptic 4 (B5 to B8). The recruiter calls this round mostly behavioural, so values stories come first. The manager is buying de-risking, so the gap questions carry equal weight. Hiring-manager priors would normally add Case; this round is weighted against it. Pressure is not weighted; B8 borrows its hold-then-concede structure because the objection is pressure-shaped.

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you decided something from the member's side when the rule pointed the other way." | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter."; "I handled the branch's formal complaints log" | Selection scaffold: pick a time a rule and a member pulled apart and you chose the member's side. Name the stake, what you decided, and what changed for the member. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the complaints log you handled, and what you decided inside it. | Values round, scored. Your material shows no decision of this kind, so the guidance gives you a scaffold, not a story. |
| B2 | "Tell me about a time you found a problem and stayed with it until it was fixed." | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved."; "I handled the branch's formal complaints log" | Selection scaffold for Own the Fix. If the fix did not hold, or the complaint closed on the first answer, say so. A stated limit scores better than a tidy ending you cannot repeat. | The panel scores Own the Fix. "Handled" is not "solved", so do not turn one into the other. |
| B3 | "When have you had to explain something to a member, or a teller, more than once?" | VAL | [grounded] "trained new tellers on our escalation script" | If you changed how the script was taught so a teller could act on it first time, say what changed, in your own words. If you taught it as written, say that, and say what you would change now. | Plain Words, scored. The only quote is about training, so the story is yours to build from that and no further. |
| B4 | "Tell me about a time a number and the people it counted pointed in different directions." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold for Neighbours, Not Numbers. If no such case comes to mind, say so. Then say how you would keep a branch's own customers in view when reporting by numbers. | The spreadsheet is a numbers tool, so Neighbours, Not Numbers is the value your material is weakest on. Say that honestly. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B5 | "This role owns complaints across the contact centre. You haven't worked in one. What would you do in your first month there?" | JD | [grounded] "Never worked in a contact centre" | Say it: "I have never worked in a contact centre." Then a plan: who you would sit with, what you would check first, how you would learn the centre's complaint path. Plan only. | F4 is a capability gap you stated. Plan-not-past is the honest form. |
| B6 | "Walk the executive team through a complaints trend." | JD | [grounded] "I've never presented to anyone above regional level" | Say it: "I've never presented to anyone above regional level." Then a plan: how you would prepare, what you would show first, and who would check it before the meeting. | F8, a capability gap you stated. The question is premised on a presentation you have not given. The plan says that without claiming one. |
| B7 | "The strategy moves 40% of member service to digital by 2028. What have you done that touched a self-service journey?" | CO, JD | [grounded] "move 40% of member service to digital channels by 2028"; answer slot from F7 | Answer slot: if you worked with anyone on a digital or self-service journey, say what it was and your part, in your own words. If you did not, say so, and say how you would bring the digital team in. | F7 is discovery, not a gap you stated, so the answer must come from your experience. The 40% figure is Ashgrove's, from the brief. |
| B8 | "Why should we hire you for a role that needs a contact-centre background and presenting to executives, when you have neither?" | JD | [grounded] "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses"; "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Hold: "I handled the branch's formal complaints log, and I built the monthly complaints spreadsheet our regional manager uses. That is the work I can point to." Follow-up 1: say the same in new words, back to the log. Follow-up 2: concede specifically: "I have never worked in a contact centre, and I have never presented above regional level. Here is how I would close each in the first ninety days." Never fold on the log. | **Highest-ROI prep in this pack.** It is the objection this JD most predicts (F4, F8, and the F3 gap). It gets two follow-ups of rehearsal and exact concession wording. The hold rests only on quotes you wrote. |

### Reverse questions, round 2

- **"How will the hub consolidation change the complaints process?"** Why it lands: it shows you read the brief, and asks for their plan rather than yours.
- **"What would you want the move to digital to do to complaint volumes and resolution times?"** Why it lands: it links F5 and F7 to the manager's own target, and invites a judgement you can then build on.
- **"What does the escalation path look like from a branch today?"** Why it lands: it signals you are ready to coach branch supervisors (JD, F6), and asks where the current gap sits.
- **"What would success look like in this role at six months, and at a year?"** Why it lands: it sets a bar you can be held to, which is what a manager wants to hear.
- **"What would you want a new Member Experience Lead to stop doing in the first quarter?"** Why it lands: it surfaces the manager's real pain points, and shows you are thinking about the job rather than the title.

## Round 3: panel of two branch managers (60 min, with a 20-minute escalation case)

**Persona weights:** Case/Strategist 2 (C1, C2), Data-Driven Prober 2 (C3, C4), Peer Evaluator 2 (C5, C6), Values/Behavioral 2 (C7, C8). The 20-minute case is the largest single block, and the panel scores values, so the case and the values questions carry weight. The panel is a blend of its members' relationships, so the peer and prober questions match what branch managers check. Your depth in the case is in the practice plan below.

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member has escalated a complaint to the branch and wants a decision by the end of the day. Talk us through the first 20 minutes." | CASE | [generic] | Structure: clarify (what the complaint is, what the deadline is, what the member needs, whether anyone is at risk). Then objective (close it fairly, avoid a repeat escalation). Then segmentation (one member, or a pattern across branches?). Then approach (who decides, what the member is told, what the supervisor does). Then metrics (time to close, repeat escalations). Then risks (regulatory timing, precedent). Say your assumptions aloud. | The live problem is a pattern for the role, not a fact about this panel, so the guidance makes no claim about your past. |
| C2 | "A branch supervisor is sending you every escalation. What do you do?" | CASE, JD | [grounded] "I trained new tellers on our escalation script" | Clarify which escalations, and what decision the supervisor is allowed to make. Coach the decision, not the outcome. Say what you would measure to see whether it changed. Bridge, if asked about experience: "I trained new tellers on our escalation script." | Coaching branch supervisors is a JD requirement (F6). The quote is the only experience you can speak to, and it is about tellers. |

**Practice plan for the 20-minute case (C1):**

1. Run C1 three times aloud, with a timer set to 20 minutes.
2. Run 1: minutes 0 to 3, clarify with three written questions. Minutes 3 to 8, objective and segmentation. Minutes 8 to 16, approach with one named owner and one named risk. Minutes 16 to 20, metrics and what you would check next.
3. Run 2: have C2's objection ready, and let the panel interrupt you once.
4. Run 3: give your answer in 90 seconds, then go deeper only when asked.
5. Do not prepare one "right answer". The panel scores structure and reasoning.

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C3 | "Walk me through how the numbers in your monthly complaints spreadsheet were counted." | EXP, JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: say how the figures were counted, if you know. Name what they are sensitive to, and the assumption you would defend least, before they ask. Say which part was yours. If you do not know how a figure was counted, say so plainly. Excel: say which features you used, if any. | This is the defend-the-number question for your reporting. It also covers the Excel requirement (F9). |
| C4 | "Did your monthly complaints reporting show how long complaints took to close? If so, how?" | JD, EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: if it showed resolution times, say what it measured and how. If it did not, say so plainly, then say what you would measure first. Never describe a measure you did not track. | F5b is discovery: the JD asks for resolution times, and your material does not show them. |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C5 | "The branches and the contact centre see the same members. Where does the seam sit, and who owns a complaint that crosses it?" | JD, VAL | [generic] | Name seam principles rather than pretending to know this seam: one owner per complaint, one record, and the branch sees the outcome. Bridge, if asked about your part: "I handled the branch's formal complaints log." | The JD asks for end-to-end ownership across branches and the contact centre (F3). The principles are a pattern, so they stay `[generic]`. |
| C6 | "A branch manager thinks a complaint should close, and you think it should stay open. What do you do?" | VAL | [generic] | Selection scaffold: pick a time you disagreed with an equal and say what happened. If none comes to mind, say so plainly, then say how you would settle it: the record, the member's outcome, and whose call it is. Frame what you bring to their team, not only what you need from it. | Peer partnership. Your material shows no disagreement, so the scaffold ends in the honest branch. |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C7 | "When did you put a customer ahead of a number?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | If you have held back a figure, or raised a case the number did not show, say it. If not, say so, then give the nearest truthful version: what you would do if the monthly figure looked fine and a branch's customers did not. | Neighbours, Not Numbers, scored by the panel. The spreadsheet is your only numbers evidence, so do not invent an override. |
| C8 | "Tell me about a time you told someone senior something they did not want to hear." | VAL | [generic] | Selection scaffold: pick a time, name the stake, what you said, and what happened. If the nearest time was with your regional manager, say that. If you have had no such time, say so plainly. | Own the Fix and candour. Your material shows no such moment, so the honest branch is the answer, and it is a valid one. |

### Reverse questions, round 3

- **"How do you hand a complaint between a branch and the contact centre today?"** Why it lands: it asks for the seam as it is now, and lets you respond to the actual process rather than a model.
- **"What would a new person do in their first month that would genuinely help your branch?"** Why it lands: it is the reciprocity question. It turns the panel from examiners into potential colleagues, and it is the question peers weigh most.
- **"Which part of the escalation process gets the most complaints from members?"** Why it lands: it shows you know where escalations come from, and gives you the case's real context.
- **"From where you sit, how do you judge whether a complaint was resolved?"** Why it lands: it tests the resolution-time question (C4) from the branch side, which is where the panel works.
- **"What would you want the Member Experience Lead to stop doing?"** Why it lands: it surfaces the panel's real friction points, and lets you show you intend to fix rather than add.

## Values cheat sheet

Round 3 is the values round, so this table lives here. Each row maps a published value to the fit-snapshot row whose quote is nearest. Where no quote carries a story, the row gives a selection scaffold and its honest branch.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | No quoted sentence carries a decision from the member's side. Nearest: F3, "I handled the branch's formal complaints log." Scaffold in B1 and C7; honest branch: say so, then the nearest thing. |
| Plain Words | If a member needs it explained twice, the wording was wrong. | F6, "trained new tellers on our escalation script," carries training, not plain wording. Scaffold in B3; honest branch: say whether you changed the wording. |
| Neighbours, Not Numbers | Every branch is part of its town. | F5a, "I built the monthly complaints spreadsheet our regional manager uses," carries a numbers tool and no town. Scaffold in B4 and C7; honest branch: say how you would keep the town in view. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | F3, "I handled the branch's formal complaints log," carries handling, not solving. Scaffold in B2; honest branch: if the fix did not hold, say so. |

## Prohibited claims

Claims this pack will not coach. Each has its basis, and the honest form is what you can say.

| Not coached | Basis | Honest form |
|---|---|---|
| "Owned the member complaints process end to end across branches" | Inflated form of F3. Your sentence covers one branch's log. | "I handled the branch's formal complaints log." Limit, in the pack's own analysis: your material shows one branch. |
| "Wrote the escalation script" | Inflated form of F6. Your sentence says "our escalation script." | "trained new tellers on our escalation script" |
| "Coached branch supervisors on escalations" | Inflated form of F6. Your sentence says tellers. | "I trained new tellers on our escalation script." |
| "Handled regulated complaints to the regulator's standard" | Inflated form of F2. Your sentence says formal, not regulated. | "I handled the branch's formal complaints log." Limit: the material does not show regulation. |
| "Branch manager" as your title | Inflated form of F1. Your sentence says branch supervisor. | "a branch supervisor" |
| "Reported monthly complaints to senior leaders" | Inflated form of F5a. Your sentence says your regional manager uses the spreadsheet. | "I built the monthly complaints spreadsheet our regional manager uses." |
| "Worked in a contact centre" | Negative you stated (F4). | "I have never worked in a contact centre." |
| "Presented to anyone above regional level" | Negative you stated (F8). | "I've never presented to anyone above regional level." |

## Sources

Provided documents:

- The job description, as you pasted it.
- Your background, from your message.
- Ashgrove's values, as you copied them from ashgrovecu.org/about/values on 20 November 2026. I have not re-checked them against the live page.
- The recruiter's email on the rounds, the panel, and the scored values round.
- The July 2026 strategy brief, as you summarised it. I have not seen the brief itself.

Searches and fetches: none sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text fixes the values cheat sheet and the B1 to B4 and C7 to C8 values rows. |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email fixes three rounds, their lengths and their relationships, so it fixes the loop structure and persona weights. |
| 3. Ashgrove strategy and recent news | skipped | The strategy summary in your message fixes the grounding brief and the CO question, B7. |
| 4. Interviewer names | n/a | No names given. The interviewer read and per-person reverse questions are absent; the upgrade menu says what names would unlock. |
| 5. Representative Member Experience Lead JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- **Prep hours before 29 November** → a prioritised triage of the three rounds, with the questions ranked by what each round scores.
- **The interviewers' names** (Head of Member Services, and the two branch managers, once assigned) → per-person persona weights from their public professional footprint, and one tailored reverse question each.
- **The strategy brief, pasted in full** → the figures in the grounding brief and B7 move from your summary to checked text.
- **The recruiter's words on the case, if they will share the theme** → C1 and C2 can rest on the panel's own words, quoted, instead of `[generic]`.
- **Your answers to the discovery slots, in your own words** (F2, F5b, F7, F9, C3, C4) → each of those rows becomes a quoted answer you can rehearse. Tell me what happened and I will quote it into the fit snapshot.
- **Your own notice period, pay expectation, location and reason for leaving** → A3 to A6 move from logistics slots to your quoted answers. These are only yours to give, so I will not supply them.
- **A tuesday-dossier.md from an earlier session** → its verified evidence and prohibited claims would bind every cell in this pack, and its underwriter-graded confidence bands would replace the ones above.
