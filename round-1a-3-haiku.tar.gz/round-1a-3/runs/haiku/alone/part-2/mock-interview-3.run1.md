I'll read the reference files the skill points to before building anything.
The output template and question rubric were truncated in that read. I'll pull the skeleton and the question-writing rules directly.
The skill's spec is clear now. Next I'll run the L1 research it calls for: Stripe's published values, its interview loop, and recent Product Operations context.
The search tool was refused by permission, so no research ran. I won't retry it. Next I'll read the research checklist to account for the targets correctly.
Research didn't run, so the pack has to rest on labelled generic content. Before writing I still need the persona definitions and the rest of the output template (banks, prohibited list, sources).
I have what I need. No research ran, no JD or CV was supplied, and the round format is unknown, so I'll build the pack on generic, labelled content and save it to the scratchpad.
Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-2-rooms-case-3-denied-fdf82f7e/ff3f3705-29bc-4283-9c6e-a0a03ba0e7a2/scratchpad/stripe_product-operations-manager_interview_pack.md. I built it for a final round with no job description, CV or interviewer, and web search was refused, so nothing about Stripe is verified. Every question is labelled `[generic]`, and the persona weights are flat.

# Stripe: Product Operations Manager, final round. Interview prep pack

**Company:** Stripe · **Role:** Product Operations Manager · **Round:** final; format, length and interviewer not given · **Interviewer:** not given

## How to use this pack

- **Personas** describe how a question is asked (register, pressure). **Types** describe what is being scored.
- Type key: **VAL** behavioural and values; **EXP** experience deep-dive; **JD** role-driven; **CO** company knowledge; **CASE** live problem.
- Guidance is scaffolding, not a script. Aim for 90 to 120 seconds, in your own words.

## Fit snapshot (worksheet variant)

No CV and no JD were supplied, so there are no quoted sentences and no quoted requirements. Each row is a role-family requirement written as plain prose and labelled `[generic]`. Evidence is `none given` throughout.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | Runs cross-functional operating processes for a product organisation (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like a process you ran across several teams, with the parts you decided named. Selection: pick one such process; if any of its steps were yours to design, say which and why; if none were, say so plainly and describe how you ran it. |
| R2 | Defines and tracks the metrics a product leadership team decides on (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like a metric you chose, the decision it fed, and how you checked it. Selection: pick one metric you used; say what it informed and what it was sensitive to. If you did not choose the metric, say so. |
| R3 | Coordinates launches across product, engineering, go-to-market and support (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like a launch you coordinated, with who was involved and what you owned. Selection: pick one launch; say what you coordinated and what others owned. |
| R4 | Makes prioritisation and governance work when teams disagree (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like a disagreement you helped resolve, with the decision rule used. Selection: pick one; say how the call was made and who made it. |
| R5 | Works with senior leaders on decisions they lack time for (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like a decision you brought to a senior leader, with the options you gave them. Selection: pick one; say what you put in front of them and what they decided. |
| G1 | Right to work in the role's location (gate; role-family pattern) | none given | none | [generic] | hard_gate | Your material does not establish this. The one question this pack asks is whether you meet it. |
| G2 | Office-days or schedule pattern (gate; role-family pattern) | none given | none | [generic] | hard_gate | Your material does not establish this. The one question this pack asks is whether you can meet it. |

Gap-type routing: R1 to R5 are `discovery`, because the material is silent and you have stated no absence. G1 and G2 are `hard_gate`, because the material does not show them met.

## Persona table

Relationship and round format are unknown, so weights are flat. That makes this pack noticeably weaker than one built on a known interviewer; the upgrade menu says what would fix it.

| Persona | Weight | Why this weight | How it shows up | Counter-strategy |
|---|---|---|---|---|
| A. Skeptic | 4 | Final rounds commonly include the interviewer who probes fit gaps (a pattern, `[generic]`) | Quiet, persistent probing of ownership and motivation | Rehearse the highest-ROI objection until it is plain; say what you did, and concede a specific limit |
| B. Case / Strategist | 4 | Ops roles are scored on live problems (role-family pattern, `[generic]`) | A process or launch problem to diagnose or design, out loud | Clarify, structure, then answer; name the trade-off you would not standardise |
| C. Values / Behavioural | 4 | No loop source documents the loop. The fallback archetype is structured large-company, whose loop usually has a values-style round | Scenario probes asking for specific past decisions | Pick a specific decision and say what it showed; say so plainly when no example fits |
| D. Data-Driven Prober | 3 | Ops roles are measured on metrics, so a number invites a probe | Asks how a number was counted and for its assumptions | Name the weakest assumption before they do; say when you did not count it yourself |
| E. Pressure | 3 | Composure is scored in finals (pattern) | Interrupts, time-boxes, questions motive | Pause, restate, hold a position through two follow-ups, then concede only the real limit |
| F. Conversational | 2 | Casual openers are still scored | "Walk me through your journey" | A pre-scripted 90-second arc, with every step true |
| G. Peer Evaluator | 2 | Peer register applies only if the interviewer is a peer, which is unknown | Seam questions, credit-sharing | Propose seam principles; name who carried the work |

**Loop, stated plainly:** no loop source establishes this loop. The pack uses the structured large-company fallback, under which a values-style round is assumed likely somewhere in the loop. That is a pattern, not a documented Stripe process.

## Question banks

Each question is `[generic]`, and no answer rests on a sentence from you, so every story is a selection scaffold that ends in an honest branch. Depth follows persona weight. Total: 22 questions.

### A. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Why product operations, and why this role now?" | EXP | [generic] | Name the operational problem that drew you in, from work you have actually done. If the move came from a specific frustration, say which; if not, say what draws you and why. Keep it to 90 seconds. | Motivation consistency is what the Skeptic scores in a final. No sentence from you yet, so this is a selection, not a story. |
| A2 | "What part of a process you ran did you actually set, and what was set for you?" | EXP | [generic] | Pick one process you ran end to end. Say which parts you designed or decided, and which you inherited or executed. Answer slot: if you set none of it, say so plainly and describe how you ran it. Hold through two follow-ups by returning to the parts you did decide; concede a specific limit rather than folding on those. | **Highest-ROI prep in this pack.** Attribution is the most predictable objection for ops roles, because the job is making other people's decisions run. This is a pattern, `[generic]`, not a claim about Stripe. It will come in some form, so it gets the deepest rehearsal. |
| A3 | "Where would you be weakest on day one?" | JD | [generic] | Name one honest gap, not a generic one, and say how you would close it in the first 30 days. Do not claim fluency you have not shown. | The Skeptic checks self-assessment; the answer is a plan, not a past. |
| A4 | "How would you know, six months in, that you were failing in this role?" | JD | [generic] | Name one metric you would watch and the failure signal behind it. Then name the assumption behind that metric you would defend least, before they ask. | Tests whether you can judge your own work, which the Skeptic weighs heavily. |

### B. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A launch goes live and support tickets triple in a week. Walk me through what you do." | CASE | [generic] | Clarify first: what changed, when, for whom. Segment the tickets (new or existing users, region, cause). Decide what to tell the waiting stakeholder now, and name the risk of each option. Think aloud. | Live diagnosis of a cross-functional launch, the core of ops work. Scored on structure, not on a single right answer. |
| B2 | "Each product team runs its own launch checklist. Design the process that replaces them." | CASE | [generic] | Clarify goals, the number of teams, and the tension between speed and control. Propose the smallest shared standard, with an owner. Say what you would leave to the teams. | Tests process design at organisation altitude. The answer is judged on what you would not standardise. |
| B3 | "Which three metrics would you put in front of product leadership to show the product org is healthy, and why those?" | JD | [generic] | Tie each metric to a decision it informs. Say what each is sensitive to. Name one you would drop. | Metric choice is a common requirement for this role family; the guidance supplies method, not figures. |
| B4 | "Where is the biggest operational risk in a fast-growing product organisation, and what would you do first?" | CO | [generic] | Name one risk, the early signal that shows it, and a first action you could take within a month. Keep it general; make no claim about this company. | CO without research. It stays generic, and the pack does not claim knowledge of Stripe's current priorities. |

### C. Values / Behavioural (weight 4)

No published values are in hand, so no value is mapped to a story. These are behavioural probes under the fallback.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you pushed back on a decision that would hurt users or customers." | VAL | [generic] | Pick a time the user stake was real and you raised it with a decision-maker. Say what you said, what happened, and where it did not land. Selection: if no such time comes to mind, say so plainly, then give the nearest thing you did. | Scores a specific decision, not a slogan. |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Choose a time the truth landed, or give the outcome honestly if it did not. Say "we" for context and "I" for what you did. | A story where the hard truth actually landed scores better than one that stops short. |
| C3 | "Tell me about a process you changed where people resisted it. How did you get it adopted?" | VAL | [generic] | Pick a change that met real resistance. Say who resisted and why, what you did, and whether it held. Selection: if you changed nothing against resistance, say so and describe the nearest change you made. | Tests influence without authority, a common ops probe. |
| C4 | "When did you move fast without full information? What did you do?" | VAL | [generic] | Pick a decision made on partial data. Say what you knew, what you did not, and what you would check now. Selection: if none comes to mind, say so and give the nearest one. | Judgement under uncertainty. The honest answer names the gap in the data. |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a number from your last role. How was it counted?" | EXP | [generic] | Give one number you can defend. Say how it was counted, what it is sensitive to, and the assumption you would defend least. Answer slot: if you did not count it yourself, say so and say what you did do. | Defend-the-number slot. No figure from you yet, so none is supplied. |
| D2 | "How do you decide whether a process change worked?" | JD | [generic] | Name the before-and-after measure, the comparison group or baseline you would use, and what you would do if the result was ambiguous. | Tests measurement judgement for a role that runs change. |
| D3 | "Tell me about a metric you owned that moved the wrong way. What did you do?" | EXP | [generic] | Pick one. Say what moved, why you think it moved, what you tried, and what you would now check first. Selection: if no metric you owned moved the wrong way, say so and describe the nearest one. | Probers test honesty about failure; a story with no failure in it invites a follow-up. |

### E. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has done this job here?" | EXP | [generic] | Pause. Name the one thing you would bring that an internal alternative would not, and what you would need to learn. Hold it through one follow-up; concede the specific limit, not the whole case. | Tests composure. Hold-then-concede: do not fold on the core claim. |
| E2 | "That result you're proudest of: how much of it was actually you?" | EXP | [generic] | Name your part in your own words, and name what others did. Answer slot: if your part was small, say so; do not claim the team's work as yours. | Attribution under pressure. Concede what was shared; hold your actual part. |
| E3 | "You have 45 seconds. Give me your strongest example." | EXP | [generic] | Lead with the decision you made, then the outcome, then what you would change. Stop at 45 seconds. | A time-boxed answer. Tests whether you lead with the decision. |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey to here." | EXP | [generic] | A pre-scripted 90-second arc: role, what you did, what drew you to ops. Each step is a true move you have made; no story you did not live. | Casual openers are still scored. Pre-scripting prevents a rambling answer. |
| F2 | "What area of product operations are you most keen to build in the next year?" | JD | [generic] | Name one area and why, in terms of a problem you have seen. Do not answer with a list. | Casual register, scored for interest and judgement. |

### G. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our product and go-to-market teams disagree about launch timing. Where's the seam between us, and what happens when we disagree?" | CASE | [generic] | Propose a principle for the seam (who decides which trade-off) rather than pretending to know their teams. Say what you would bring to their side. | Peer seam probe, with reciprocity framing. |
| G2 | "How do you handle credit when an ops process spans teams?" | VAL | [generic] | Name the people whose work carried the process and what you did. Do not claim their work. | Credit-sharing probe; the answer is attribution again, in a peer register. |

### Role-family requirement coverage (no JD supplied)

| Requirement | Covered by |
|---|---|
| R1 cross-functional processes | A2, B2, D3 |
| R2 metrics for leadership | B3, D1, D2 |
| R3 launch coordination | B1, B2, G1 |
| R4 prioritisation and governance | C3, G1, G2 |
| R5 senior decisions | A1, C1, E1, E2 |
| G1 right to work; G2 office pattern | none in the banks, and why: a gate is asked as a closing question, not rehearsed |

## Reverse questions

Each has a one-line "why it lands." No interviewer profile exists, so these are role-generic. A career-path question and a peer reciprocity question are not included, because neither the interviewer's path nor their peer status is known.

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "What would a strong first six months in this role look like, and how would the team know it was working?" | Asks what success means, which shows you think in outcomes. |
| RQ2 | "When product and go-to-market priorities conflict, where does the decision get made?" | Surfaces decision rights, which is the thing ops exists to make work. |
| RQ3 | "What operational problem does the product org most want solved this year?" | Lets you answer with the problem they name, not the one you assumed. |
| RQ4 | "Is this role embedded in one team, or central across several?" | Sets the scope, which changes how you would answer the ops questions. |
| RQ5 | "What separates people who do well here from those who struggle in the first year?" | Asks for the working reality, and signals you want it. |
| RQ6 | "What is the first decision you would want this role to take off your leaders' plate?" | Tests scope and shows you think about leverage. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any Stripe-specific fact: its values by name, its strategy, its recent moves | Not in hand. Research was refused and nothing was pasted | Use only what the interviewer says, or what you have read yourself and can cite |
| Owning a process, metric or launch you have not stated | No sentence from you exists yet, so there is no wording to stretch. Any such claim would be invented | Not coached. Answer slots only. This list is rebuilt when your CV is in |

No inflated-form entry is listed yet, because there is no candidate sentence to stretch. It is rebuilt from your own sentences when your CV is in.

## Sources

**Provided documents:** your message only (Stripe; Product Operations Manager; final round). No job description, CV, dossier or interviewer name was supplied.

**Searches sent (all refused by permission; none returned a result):**
1. `Stripe company values principles careers "users first" "move with urgency"`: refused. This query included phrasing from memory; nothing in the pack relies on it.
2. `Stripe Product Operations Manager interview process final round`: refused.
3. `Stripe Product Operations role responsibilities job description`: refused.

**Fetches sent:** none.

**Research tier:** L1, searches 3 of 6, fetches 0 of 2. All three searches were refused.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Values cheat sheet (section 10 dropped), and the value-mapped VAL questions. Those are absent |
| 2. `{company} interview process {role family}` | unavailable | Loop structure. The pack uses the structured large-company fallback, not a documented loop, and persona weights are flat |
| 3. `{company} strategy` / recent news | unavailable | CO bank. B4 stays generic, and no grounding brief was built. No call was sent because search was refused |
| 4. `{interviewer name} {company}` | n/a | No interviewer name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `{role title}` JD | unavailable | JD-tagged questions and the fit snapshot rows. These are role-family patterns, not a representative posting |

## Upgrade menu

- **Job description, pasted** → rows R1 to R5 become quoted `[grounded]` requirements, and the JD-tagged questions get a raising source
- **CV, or a summary of your last two roles** → evidence cells fill with your own sentences; the open prompts become story maps, and the Skeptic objection gets its real shape
- **Round relationship and format** → persona weights are reweighted; if the final is several sessions, a per-session mini-pack
- **Interviewer's name** → the interviewer read, persona weights from their public footprint, and a reverse question tied to their path
- **Stripe's values page, pasted** → the values cheat sheet, and the C bank's questions gain mapped stories
- **Permission to use web search** → research tiers become runnable; targets 1 to 3 turn `yes`
- **Deep research (L2), offered once:** up to 6 more searches and 2 more fetches, several minutes. It would need search permission to run
- **Recruiter's email on focus areas or any pre-declared deliverable** → a build section for it
- **`tuesday-dossier.md`:** would add verified evidence and a prohibited-claims list from a prior review

---

I can also run a drill: I'd play the Skeptic on A2, the question this pack names as highest-ROI prep. I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Three things would reshape the pack:

1. Who are you meeting, and is the final one conversation or several back-to-back sessions?
2. Could you paste the job description and a summary or CV of your background? Or say "proceed without" and I'll keep the pack as it is.
3. Do you have the right to work where this role is based, and can you meet its office-days pattern?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe: Product Operations Manager, final round. Interview prep pack

**Company:** Stripe · **Role:** Product Operations Manager · **Round:** final; format, length and interviewer not given · **Interviewer:** not given

**Built on:** the company and role you gave, and nothing else. No job description, CV, interviewer name or round format was supplied, and web search was refused, so no fact about Stripe is verified here. Every question is `[generic]`, and persona weights are flat.

## How to use this pack

- **Personas** describe how a question is asked (register, pressure). **Types** describe what is being scored.
- Type key: **VAL** behavioural and values; **EXP** experience deep-dive; **JD** role-driven; **CO** company knowledge; **CASE** live problem.
- Guidance is scaffolding, not a script. Aim for 90 to 120 seconds, in your own words.

## Fit snapshot (worksheet variant)

No CV and no JD were supplied, so there are no quoted sentences and no quoted requirements. Each row is a role-family requirement written as plain prose and labelled `[generic]`. Evidence is `none given` throughout.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | Runs cross-functional operating processes for a product organisation (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like a process you ran across several teams, with the parts you decided named. Selection: pick one such process; if any of its steps were yours to design, say which and why; if none were, say so plainly and describe how you ran it. |
| R2 | Defines and tracks the metrics a product leadership team decides on (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like a metric you chose, the decision it fed, and how you checked it. Selection: pick one metric you used; say what it informed and what it was sensitive to. If you did not choose the metric, say so. |
| R3 | Coordinates launches across product, engineering, go-to-market and support (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like a launch you coordinated, with who was involved and what you owned. Selection: pick one launch; say what you coordinated and what others owned. |
| R4 | Makes prioritisation and governance work when teams disagree (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like a disagreement you helped resolve, with the decision rule used. Selection: pick one; say how the call was made and who made it. |
| R5 | Works with senior leaders on decisions they lack time for (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like a decision you brought to a senior leader, with the options you gave them. Selection: pick one; say what you put in front of them and what they decided. |
| G1 | Right to work in the role's location (gate; role-family pattern) | none given | none | [generic] | hard_gate | Your material does not establish this. The one question this pack asks is whether you meet it. |
| G2 | Office-days or schedule pattern (gate; role-family pattern) | none given | none | [generic] | hard_gate | Your material does not establish this. The one question this pack asks is whether you can meet it. |

Gap-type routing: R1 to R5 are `discovery`, because the material is silent and the candidate has stated no absence. G1 and G2 are `hard_gate`, because the material does not show them met.

## Persona table

Relationship and round format are unknown, so weights are flat. That makes this pack noticeably weaker than one built on a known interviewer; the upgrade menu says what would fix it.

| Persona | Weight | Why this weight | How it shows up | Counter-strategy |
|---|---|---|---|---|
| A. Skeptic | 4 | Final rounds commonly include the interviewer who probes fit gaps (a pattern, `[generic]`) | Quiet, persistent probing of ownership and motivation | Rehearse the highest-ROI objection until it is plain; say what you did, and concede a specific limit |
| B. Case / Strategist | 4 | Ops roles are scored on live problems (role-family pattern, `[generic]`) | A process or launch problem to diagnose or design, out loud | Clarify, structure, then answer; name the trade-off you would not standardise |
| C. Values / Behavioural | 4 | No loop source documents the loop. The fallback archetype is structured large-company, whose loop usually has a values-style round | Scenario probes asking for specific past decisions | Pick a specific decision and say what it showed; say so plainly when no example fits |
| D. Data-Driven Prober | 3 | Ops roles are measured on metrics, so a number invites a probe | Asks how a number was counted and for its assumptions | Name the weakest assumption before they do; say when you did not count it yourself |
| E. Pressure | 3 | Composure is scored in finals (pattern) | Interrupts, time-boxes, questions motive | Pause, restate, hold a position through two follow-ups, then concede only the real limit |
| F. Conversational | 2 | Casual openers are still scored | "Walk me through your journey" | A pre-scripted 90-second arc, with every step true |
| G. Peer Evaluator | 2 | Peer register applies only if the interviewer is a peer, which is unknown | Seam questions, credit-sharing | Propose seam principles; name who carried the work |

**Loop, stated plainly:** no loop source establishes this loop. The pack uses the structured large-company fallback, under which a values-style round is assumed likely somewhere in the loop. That is a pattern, not a documented Stripe process.

## Question banks

Each question is `[generic]`, and no answer rests on a sentence from you, so every story is a selection scaffold that ends in an honest branch. Depth follows persona weight. Totals: 22 questions.

### A. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Why product operations, and why this role now?" | EXP | [generic] | Name the operational problem that drew you in, from work you have actually done. If the move came from a specific frustration, say which; if not, say what draws you and why. Keep it to 90 seconds. | Motivation consistency is what the Skeptic scores in a final. No sentence from you yet, so this is a selection, not a story. |
| A2 | "What part of a process you ran did you actually set, and what was set for you?" | EXP | [generic] | Pick one process you ran end to end. Say which parts you designed or decided, and which you inherited or executed. Answer slot: if you set none of it, say so plainly and describe how you ran it. Hold through two follow-ups by returning to the parts you did decide; concede a specific limit rather than folding on those. | **Highest-ROI prep in this pack.** Attribution is the most predictable objection for ops roles, because the job is making other people's decisions run. This is a pattern, `[generic]`, not a claim about Stripe. It will come in some form, so it gets the deepest rehearsal. |
| A3 | "Where would you be weakest on day one?" | JD | [generic] | Name one honest gap, not a generic one, and say how you would close it in the first 30 days. Do not claim fluency you have not shown. | The Skeptic checks self-assessment; the answer is a plan, not a past. |
| A4 | "How would you know, six months in, that you were failing in this role?" | JD | [generic] | Name one metric you would watch and the failure signal behind it. Then name the assumption behind that metric you would defend least, before they ask. | Tests whether you can judge your own work, which the Skeptic weighs heavily. |

### B. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A launch goes live and support tickets triple in a week. Walk me through what you do." | CASE | [generic] | Clarify first: what changed, when, for whom. Segment the tickets (new or existing users, region, cause). Decide what to tell the waiting stakeholder now, and name the risk of each option. Think aloud. | Live diagnosis of a cross-functional launch, the core of ops work. Scored on structure, not on a single right answer. |
| B2 | "Each product team runs its own launch checklist. Design the process that replaces them." | CASE | [generic] | Clarify goals, the number of teams, and the tension between speed and control. Propose the smallest shared standard, with an owner. Say what you would leave to the teams. | Tests process design at organisation altitude. The answer is judged on what you would not standardise. |
| B3 | "Which three metrics would you put in front of product leadership to show the product org is healthy, and why those?" | JD | [generic] | Tie each metric to a decision it informs. Say what each is sensitive to. Name one you would drop. | Metric choice is a common requirement for this role family; the guidance supplies method, not figures. |
| B4 | "Where is the biggest operational risk in a fast-growing product organisation, and what would you do first?" | CO | [generic] | Name one risk, the early signal that shows it, and a first action you could take within a month. Keep it general; make no claim about this company. | CO without research. It stays generic, and the pack does not claim knowledge of Stripe's current priorities. |

### C. Values / Behavioural (weight 4)

No published values are in hand, so no value is mapped to a story. These are behavioural probes under the fallback.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you pushed back on a decision that would hurt users or customers." | VAL | [generic] | Pick a time the user stake was real and you raised it with a decision-maker. Say what you said, what happened, and where it did not land. Selection: if no such time comes to mind, say so plainly, then give the nearest thing you did. | Scores a specific decision, not a slogan. |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Choose a time the truth landed, or give the outcome honestly if it did not. Say "we" for context and "I" for what you did. | A story where the hard truth actually landed scores better than one that stops short. |
| C3 | "Tell me about a process you changed where people resisted it. How did you get it adopted?" | VAL | [generic] | Pick a change that met real resistance. Say who resisted and why, what you did, and whether it held. Selection: if you changed nothing against resistance, say so and describe the nearest change you made. | Tests influence without authority, a common ops probe. |
| C4 | "When did you move fast without full information? What did you do?" | VAL | [generic] | Pick a decision made on partial data. Say what you knew, what you did not, and what you would check now. Selection: if none comes to mind, say so and give the nearest one. | Judgement under uncertainty. The honest answer names the gap in the data. |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a number from your last role. How was it counted?" | EXP | [generic] | Give one number you can defend. Say how it was counted, what it is sensitive to, and the assumption you would defend least. Answer slot: if you did not count it yourself, say so and say what you did do. | Defend-the-number slot. No figure from you yet, so none is supplied. |
| D2 | "How do you decide whether a process change worked?" | JD | [generic] | Name the before-and-after measure, the comparison group or baseline you would use, and what you would do if the result was ambiguous. | Tests measurement judgement for a role that runs change. |
| D3 | "Tell me about a metric you owned that moved the wrong way. What did you do?" | EXP | [generic] | Pick one. Say what moved, why you think it moved, what you tried, and what you would now check first. Selection: if no metric you owned moved the wrong way, say so and describe the nearest one. | Probers test honesty about failure; a story with no failure in it invites a follow-up. |

### E. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has done this job here?" | EXP | [generic] | Pause. Name the one thing you would bring that an internal alternative would not, and what you would need to learn. Hold it through one follow-up; concede the specific limit, not the whole case. | Tests composure. Hold-then-concede: do not fold on the core claim. |
| E2 | "That result you're proudest of: how much of it was actually you?" | EXP | [generic] | Name your part in your own words, and name what others did. Answer slot: if your part was small, say so; do not claim the team's work as yours. | Attribution under pressure. Concede what was shared; hold your actual part. |
| E3 | "You have 45 seconds. Give me your strongest example." | EXP | [generic] | Lead with the decision you made, then the outcome, then what you would change. Stop at 45 seconds. | A time-boxed answer. Tests whether you lead with the decision. |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey to here." | EXP | [generic] | A pre-scripted 90-second arc: role, what you did, what drew you to ops. Each step is a true move you have made; no story you did not live. | Casual openers are still scored. Pre-scripting prevents a rambling answer. |
| F2 | "What area of product operations are you most keen to build in the next year?" | JD | [generic] | Name one area and why, in terms of a problem you have seen. Do not answer with a list. | Casual register, scored for interest and judgement. |

### G. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our product and go-to-market teams disagree about launch timing. Where's the seam between us, and what happens when we disagree?" | CASE | [generic] | Propose a principle for the seam (who decides which trade-off) rather than pretending to know their teams. Say what you would bring to their side. | Peer seam probe, with reciprocity framing. |
| G2 | "How do you handle credit when an ops process spans teams?" | VAL | [generic] | Name the people whose work carried the process and what you did. Do not claim their work. | Credit-sharing probe; the answer is attribution again, in a peer register. |

### Role-family requirement coverage (no JD supplied)

| Requirement | Covered by |
|---|---|
| R1 cross-functional processes | A2, B2, D3 |
| R2 metrics for leadership | B3, D1, D2 |
| R3 launch coordination | B1, B2, G1 |
| R4 prioritisation and governance | C3, G1, G2 |
| R5 senior decisions | A1, C1, E1, E2 |
| G1 right to work; G2 office pattern | none in the banks, and why: a gate is asked as a closing question, not rehearsed |

## Reverse questions

Each has a one-line "why it lands." No interviewer profile exists, so these are role-generic. A career-path question and a peer reciprocity question are not included, because neither the interviewer's path nor their peer status is known.

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "What would a strong first six months in this role look like, and how would the team know it was working?" | Asks what success means, which shows you think in outcomes. |
| RQ2 | "When product and go-to-market priorities conflict, where does the decision get made?" | Surfaces decision rights, which is the thing ops exists to make work. |
| RQ3 | "What operational problem does the product org most want solved this year?" | Lets you answer with the problem they name, not the one you assumed. |
| RQ4 | "Is this role embedded in one team, or central across several?" | Sets the scope, which changes how you would answer the ops questions. |
| RQ5 | "What separates people who do well here from those who struggle in the first year?" | Asks for the working reality, and signals you want it. |
| RQ6 | "What is the first decision you would want this role to take off your leaders' plate?" | Tests scope and shows you think about leverage. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any Stripe-specific fact: its values by name, its strategy, its recent moves | Not in hand. Research was refused and nothing was pasted | Use only what the interviewer says, or what you have read yourself and can cite |
| Owning a process, metric or launch you have not stated | No sentence from you exists yet, so there is no wording to stretch. Any such claim would be invented | Not coached. Answer slots only. This list is rebuilt when your CV is in |

No inflated-form entry is listed yet, because there is no candidate sentence to stretch. It is rebuilt from your own sentences when your CV is in.

## Sources

**Provided documents:** your message only (Stripe; Product Operations Manager; final round). No job description, CV, dossier or interviewer name was supplied.

**Searches sent (all refused by permission; none returned a result):**
1. `Stripe company values principles careers "users first" "move with urgency"`: refused. This query included phrasing from memory; nothing in the pack relies on it.
2. `Stripe Product Operations Manager interview process final round`: refused.
3. `Stripe Product Operations role responsibilities job description`: refused.

**Fetches sent:** none.

**Research tier:** L1, searches 3 of 6, fetches 0 of 2. All three searches were refused.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Values cheat sheet (section 10 dropped), and the value-mapped VAL questions. Those are absent |
| 2. `{company} interview process {role family}` | unavailable | Loop structure. The pack uses the structured large-company fallback, not a documented loop, and persona weights are flat |
| 3. `{company} strategy` / recent news | unavailable | CO bank. B4 stays generic, and no grounding brief was built. No call was sent because search was refused |
| 4. `{interviewer name} {company}` | n/a | No interviewer name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `{role title}` JD | unavailable | JD-tagged questions and the fit snapshot rows. These are role-family patterns, not a representative posting |

## Upgrade menu

- **Job description, pasted** → rows R1 to R5 become quoted `[grounded]` requirements, and the JD-tagged questions get a raising source
- **CV, or a summary of your last two roles** → evidence cells fill with your own sentences; the open prompts become story maps, and the Skeptic objection gets its real shape
- **Round relationship and format** → persona weights are reweighted; if the final is several sessions, a per-session mini-pack
- **Interviewer's name** → the interviewer read, persona weights from their public footprint, and a reverse question tied to their path
- **Stripe's values page, pasted** → the values cheat sheet, and the C bank's questions gain mapped stories
- **Permission to use web search** → research tiers become runnable; targets 1 to 3 turn `yes`
- **Deep research (L2), offered once:** up to 6 more searches and 2 more fetches, several minutes. It would need search permission to run
- **Recruiter's email on focus areas or any pre-declared deliverable** → a build section for it
- **`tuesday-dossier.md`:** would add verified evidence and a prohibited-claims list from a prior review
