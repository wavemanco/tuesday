Your Ashgrove pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-2-rooms-case-8-denied-a6fc69a6/f4537633-61be-4fc9-a88d-bdf6dc071310/scratchpad/ashgrove_member-experience-lead_interview_pack.md`.

I built it in loop mode, one mini-pack per round, on a shared fit snapshot. I ran no web searches: your JD, background, values copy, the strategy brief and the recruiter's email already cover what a search would check.

The pack puts most of your prep time on three gaps: the contact centre, presenting above regional level, and regulated complaints. The highest-ROI rehearsal is 2.5, the "you've never worked in a contact centre" objection in Round 2. It is the one most likely to come up in some form, and your own sentences give you a plain, honest answer to it.

Say the word and I'll play the Round 2 skeptic on 2.5.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the role based at one site, or does it run across branches and the future hubs with regular travel? The answer settles the location gate in the fit snapshot and question 1.5.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead, interview pack

Candidate: Dara · Loop mode: three rounds on 29 November 2026 · Pack built 20 November 2026

Round 1 is the recruiter (30 min). Round 2 is the Head of Member Services, your future manager (45 min, mostly behavioural). Round 3 is a panel of two branch managers (60 min, scored against the four values, with a 20-minute complaint-escalation case). Round 2's and Round 3's interviewers are not named yet, so the interviewer read is absent.

## How to use + type key

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **VAL**: values alignment, tested by past behaviour. **EXP**: deep-dive on what you actually did. **JD**: stated responsibilities and requirements, gaps included. **CO**: company and strategy knowledge. **CASE**: a live problem from the role.
- Question IDs are round.number (1.1, 2.5, 3.10), so the drill can point at one.
- Guidance is scaffolding, not a script. Each cell is speakable in 90 to 120 seconds.
- **Answer slots** are instructions for the interview. They are not questions to me, and each has an honest branch: "if it was not yours, say so plainly." Use that branch whenever it is true.
- Provenance leads with one label, then your own sentences the guidance rests on.

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's log, not an end-to-end process across branches and a contact centre. Bridge: "I handled the branch's formal complaints log." Answer slot: if you set any step between a complaint arriving and its close, say which and how you decided; if none of that was yours to set, say so and describe how the log was handled. |
| F2 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap. Bridge: "Six years in retail banking, the last three as a branch supervisor." Expect a check on dates; it is a self-reported CV line. |
| F3 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | transferability | Derived from the JD's word "regulated" and the nearest quote. Your material says formal complaints, not regulated ones, so do not stretch the bridge. Answer slot: if the log ran to a time limit or an outside review, name it and what you did when one ran late; if it did not, say so and say what you would learn first. |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms: a spreadsheet, not necessarily Excel. Bridge: "I built the monthly complaints spreadsheet our regional manager uses." Name the tool yourself, in your own words; the material does not say which one it was. |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | Derived: the spreadsheet touches monthly reporting, but your material does not show whether it counted volumes or resolution times. Answer slot: say what it counted; if it did not track resolution times, say so and say what you would add first. |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Tellers, not supervisors. Bridge: "I trained new tellers on our escalation script." Answer slot: if you coached anyone on escalations, name them and what changed; if not, say so and say how you would first check the escalation trigger is clear. |
| F7 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | You stated the absence, so the words are yours. Plain acknowledgment: "I've never presented to anyone above regional level." Then a plan, said as a plan and never as a past. |
| F8 | "Own the member complaints process end to end across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | You stated the absence. Plain acknowledgment: "I've never worked in a contact centre." Then the nearest thing your material carries, as adjacent work: the branch complaints log. Then a plan for learning the contact-centre side. Never claim contact-centre complaint work. |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Silence is not an absence. Answer slot: if you have worked with a digital or self-service channel, say what it was and your part in it; if not, say so and say what you would first want to learn about how members use it. |
| F10 | "across branches and the contact centre" — JD (the role's location and travel are not stated) | none given | none | [grounded] | hard_gate | Your material does not establish where the role sits or how much travel it needs. The strategy brief's move from eight branches to five hubs makes this a live question. Surfaced, not bridged. The one question in the message asks about it. |

Read: your material supports the six years, the branch complaints work, and the tellers' escalation training. The three places the three rounds will press are the contact centre (F8), presenting above regional level (F7), and regulated complaints (F3). Those are where the prep time should go.

## Prohibited claims (built locally; they bind every cell below)

| Not coached | Basis | Honest form |
|---|---|---|
| Ran complaints end to end across a contact centre | Inflated form of F1 and F8 | "I handled the branch's formal complaints log." Your material says the branch log; it says nothing about a contact centre. |
| Presented to senior leaders, or confident doing so | Stated negative, F7 | "I've never presented to anyone above regional level." No slot. |
| Handled regulated complaints | Inflated form of F3 | "I handled the branch's formal complaints log." The regulatory side is an answer slot, not a claim. |
| Designed or owned the monthly reporting of volumes and resolution times | Inflated form of F4 and F5 | "I built the monthly complaints spreadsheet our regional manager uses." Your material does not say what it counted. |
| Coached branch supervisors on escalations | Inflated form of F6 | "I trained new tellers on our escalation script." |

## Grounding brief: Ashgrove's current strategy

Source: the 2026 strategy brief Ashgrove published in July 2026, which the recruiter sent. It is about four months old, so check for newer news before the rounds.

| Term | Brief's words | What it means for complaints |
|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | More complaints will start in the app. Self-service journeys become complaint routes. |
| Hub consolidation | "consolidate eight branches into five hubs over 2027" | Branch-level complaint ownership and the "every branch is part of its town" value are under strain during 2027. |
| Small-business lending | "launch a small-business lending product in Q1 2027" | A new product line brings a new set of complaint types. |
| Competitive pressure | "the main competitive pressure is app-only banks" | Members who compare you with an app will judge a slow complaint harshly. |

No stale framings were found in what you pasted.

## Round 1: Recruiter screen (30 minutes)

**Persona weights.** Conversational 5: recruiter screens are friendly, but the logistics and the motivation check are scored. Skeptic 3: "why leave" and the contact-centre gap are the two places a recruiter will test the fit.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | An open career question, then the logistics asked in a chatty register | High. Recruiter screens open this way, and the logistics are scored. | A 90-second arc (1.1). Treat each logistics question as scored. Give your own answers and nothing more. |
| Skeptic (light) | Why are you leaving, and what is the contact-centre match | Medium. The contact-centre gap is on the JD, and the recruiter will have read it. | Plain acknowledgment, then the nearest adjacent work, then a plan (1.7). |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1.1 | "Talk me through your career so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log" | Give a 90-second arc in this order: six years in retail banking, the last three as a branch supervisor, then the complaints log. Say the log in your own words and stop there. | F2 and F1 are the arc's two facts. A casual question is still scored, and this is the answer you will give most often. |
| 1.2 | "Why Ashgrove, and why this role?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief) | Give your own reason in your own words. Answer slot: if the digital shift is part of your reason, say which part of the complaints work it touches and what you would want to learn about it first. | The recruiter has read the brief. The quote is Ashgrove's fact, not a claim about you. |
| 1.3 | "What are your salary expectations?" | JD | [generic] | Logistics slot: decide before the call whether you will name your own figure or ask for the band first. Either is a fair answer. Do not improvise a range. | Pay is a logistics question. No figure was given, so the pack gives none. |
| 1.4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words. | Logistics. The only safe answer is your own. |
| 1.5 | "Where would you need to be based, and how much travel would you expect?" | JD | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief) | Logistics slot: state your own location and travel answer once. | F10 is the gate: the material does not say where the role sits. The hub plan is why it matters. |
| 1.6 | "Why are you looking to leave your current role?" | EXP | [generic] | Reason slot: give your actual reason, short and forward-looking. Do not criticise your current employer. | Motivation-consistency check. No reason was supplied, so the pack supplies none. |
| 1.7 | "Our contact centre is part of this role. What's your experience there?" | JD | [grounded] "Never worked in a contact centre" — your message | Plain acknowledgment: "I've never worked in a contact centre." Then: "The nearest thing I have is the branch's formal complaints log, which is adjacent, not the same." Then one line on how you would learn the contact-centre side. | F8 is a stated absence, so the words are yours. This is the light version of the Round 2 objection at 2.5. |
| 1.8 | "What do you know about Ashgrove as a member-owned credit union?" | VAL | [grounded] "Neighbours, Not Numbers — every branch is part of its town." (values page copy, 20 November 2026) | Say what you read on the values page, in your own words. Pick one of the four values and say what it means for member complaints. | The recruiter checks that you have read the values before Round 3, where they are scored. |

**Round 1 reverse questions**
- "What does the first 90 days look like, given the 2027 hub moves?" Why it lands: it shows you read the brief and are thinking about timing.
- "Who will I be working with most often in the first month?" Why it lands: it shows you are planning, not just applying.
- "How does the team measure a good complaint outcome?" Why it lands: it leads straight into resolution times, a JD requirement.

## Round 2: Head of Member Services, your manager (45 minutes)

**Persona weights.** Values/Behavioral 4: the recruiter says this round is mostly behavioural. Prober 2: the log and the reporting need defending. Skeptic 2: the contact centre and presenting. Case 2: the digital shift and coaching supervisors.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | STAR-shaped questions on Members First, Own the Fix, Plain Words and Neighbours | High. The recruiter calls the round behavioural, and your manager will test the values before the panel does. | Pick a real situation, say "I" for what you did, and say honestly when no example fits. |
| Data-Driven Prober | "What did the log count? What did the report show?" | Medium-high. Your CV line about the spreadsheet is the probe target. | Say what it counted and what it did not. Do not add a figure. |
| Skeptic | "You've never worked in a contact centre. You've never presented above regional level." | High. These are the two stated absences the role depends on. | Plain acknowledgment, then the nearest adjacent work, then a plan. Hold, then concede one specific thing. |
| Case / Strategist | A live problem on the digital shift and on coaching a supervisor | Medium. The recruiter's email calls the round behavioural, so cases will be short. | Clarify first, then structure, then one metric. |

**Highest-ROI prep in this pack: 2.5.** It is the objection this loop will most likely raise in some form, because your two stated absences, the contact centre and presenting above regional level, are exactly what the role depends on. A rehearsed plain answer changes that interview.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2.1 | "Tell me about a time you decided something from the member's side of the counter when the process pointed the other way." | VAL | [grounded] "I handled the branch's formal complaints log" (nearest only) | Selection scaffold: pick a time a member's outcome changed your call. It needs a named situation, what you chose, and what happened to the member. If none comes to mind, say so plainly, then give the nearest thing your material carries: the complaints log. | Members First has no quote in your material, so it gets a scaffold and its honest branch, not an invented story. |
| 2.2 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Story map from the log: you handled it, and the beats are the ones that sentence states. Answer slot: if you followed one complaint from first contact to a closed outcome, name it and the last step you took. If the log stopped short of closing it, say so and say what you did with it. | Own the Fix. "Handled" is in your sentence, "closed" is not, so closure is the slot. |
| 2.3 | "Tell me about a time you had to explain something to someone twice." | VAL | [grounded] "trained new tellers on our escalation script" | Story map: the training. Beats: you taught the escalation script to new tellers. Answer slot: if a teller needed a second explanation, say what you changed in the words you used. If none, say so, then how you would check a member has understood. | Plain Words. The training is the nearest teaching moment; the explained-twice story is the slot. |
| 2.4 | "Walk me through the complaints log you handled: what got logged, and which rules or time limits, if any, governed a complaint after it was logged." | EXP | [grounded] "I handled the branch's formal complaints log" | Walk the log from logging to close, in your own words. Answer slot: the JD asks for regulated complaints, and your material does not show what governed the log. If a time limit or review step applied, name it and what you did when one ran late. If none applied, say so plainly and describe how you tracked the age of a complaint. | This is where F3 is most likely to be probed. The second branch allows that no rules governed the log. |
| 2.5 | "The role owns complaints across branches and the contact centre. You've never worked in a contact centre. What would you do in your first 90 days?" | JD | [grounded] "Never worked in a contact centre" — your message | Plain acknowledgment: "I've never worked in a contact centre." Then the nearest adjacent work: "I handled the branch's formal complaints log," said as adjacent. Then a plan, not a past: in the first weeks, listen in on contact-centre calls, shadow the complaints queue, and map how a complaint moves from the contact centre to a branch. Hold through two follow-ups. Concede one specific gap: say what you do not yet know about how contact-centre complaints are logged. | F8 and F1. The interviewer's most predictable objection, and the candidate's own stated absence supplies the plain words. Never claim contact-centre complaint work. |
| 2.6 | "You've never presented to anyone above regional level. How would you present complaint trends to a leadership team?" | JD | [grounded] "I've never presented to anyone above regional level" — your message | Plain acknowledgment: "I've never presented to anyone above regional level." Then the plan, as a plan: prepare one page, dry-run it with your regional manager, and take feedback before the first leadership slot. | F7 is a stated absence. Never describe a past presentation to a senior audience. |
| 2.7 | "What would you put in a monthly report on complaint volumes and resolution times?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Describe what the spreadsheet counts, in your own words. Answer slot: if it counted volumes or resolution times, say which and how you counted them; if it did not track resolution times, say so, and say what you would add first. Then say what a head of service needs to see on one page. | F5 is discovery: your material does not show what the spreadsheet counts. Do not invent a figure or a method. |
| 2.8 | "Ashgrove is consolidating eight branches into five hubs in 2027. How do you keep 'every branch is part of its town' when a branch closes?" | VAL | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief, sent by the recruiter); "Neighbours, Not Numbers — every branch is part of its town." (values page) | No claim about your past. The approach is generic: what happens to open complaints and records on the day; how members hear about it, in plain words; what you would track so a closing branch's complaints are not lost in the totals. | Neighbours is the value most at risk in a consolidation, and the panel will know the brief. The premise is the brief's, sent by the recruiter, not something you did. |
| 2.9 | "Digital channels are meant to take 40% of member service by 2028. What happens to complaints when a member moves to the app?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief) | Structure: which complaint types move with the member; how a complaint raised in the app reaches a person; what happens to members who cannot or will not use the app; the metric that shows it is working, such as resolution time by channel. Name one thing you would ask the digital team. No claim about digital work. | JD requirement on digital journeys, which is discovery (F9). The structure is generic; the target is from the brief. |
| 2.10 | "A branch supervisor is slow to escalate complaints. How do you coach them?" | CASE | [grounded] "coach branch supervisors on escalations" (JD); "trained new tellers on our escalation script" — your message | Structure: find out why (training, workload, an unclear trigger); agree the escalation trigger together; work one live case side by side; set a dated follow-up. Answer slot: if you have coached a supervisor or anyone else on escalations, name the case and what changed; if not, say so. | F6 transferability. The tellers' training is the nearest quote; supervisor coaching is the slot. |

**Round 2 reverse questions**
- "How is complaint volume and resolution time reported today, and who reads it?" Why it lands: it shows you read the JD's reporting line and want to know the current baseline.
- "When you think about the first branch consolidation, what do you want the complaints team to have done by then?" Why it lands: it shows you have thought about Neighbours in a live change, not on a poster.
- "What would make you say, a year from now, that this was the right hire?" Why it lands: it turns the close into a planning conversation.

## Round 3: Branch-manager panel (60 minutes, values-scored, with a 20-minute case)

The recruiter's email says the panel scores against the four values. **Persona weights.** Values/Behavioral 4: each value is scored. Case 3: the 20-minute escalation case. Peer Evaluator 2: the branch managers are the people this role serves, and they will judge the seam. Pressure 1: a sixty-second challenge.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One scored question per value | Very high. The recruiter says this round scores the values. | Map each value to a story, or to the honest branch. |
| Case / Strategist | The 20-minute escalation case, with a hold-then-concede follow-up | High. The recruiter specifies it. | Clarify, own the file, talk to the member, find the cause, fix it or date a plan. |
| Peer Evaluator | Where is the seam between branches and the contact centre? | Medium. Branch managers sit beside the team. | Principles for the seam, not a claimed one. Reciprocity: what you bring their branches. |
| Pressure | A sixty-second challenge on the contact centre | Medium. A panel often closes with one. | Pause, restate, plain acknowledgment, hold through two follow-ups. |

**Values cheat sheet (shared with this round, which the recruiter names as the values round)**

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | No sentence in your material carries a story for this. Selection scaffold and honest branch: see 3.1. |
| Plain Words | If a member needs it explained twice, the writing was wrong. | Row F6, "trained new tellers on our escalation script": the teaching is the story. The explained-twice moment is the slot, see 3.2. |
| Neighbours, Not Numbers | Every branch is part of its town. | Row F4, "I built the monthly complaints spreadsheet our regional manager uses", is the number side. No sentence carries the town side. Scaffold and honest branch: see 3.3. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | Row F1, "I handled the branch's formal complaints log": handled, but closure is not stated. Answer slot: see 3.4. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3.1 | "Tell me about a time you decided something from the member's side that the process didn't support." | VAL | [grounded] "I handled the branch's formal complaints log" (nearest only) | Selection scaffold: pick a case where the member's outcome and the process pulled apart. Name the member's situation, your decision, and what the process said. If none comes to mind, say so plainly, then give the nearest thing your material carries: the complaints log. | Members First. Honest branch is the answer when no such case exists. |
| 3.2 | "Tell me about a time you had to explain something to someone a second time, and what changed." | VAL | [grounded] "trained new tellers on our escalation script" | Story map: the script training. Beats: you taught the script to new tellers. Answer slot: if a teller needed a second explanation, say what you changed in the words you used. If none, say so, then one thing you would do differently. | Plain Words. Plain acknowledgment is the fallback, not an invented moment. |
| 3.3 | "Tell me about a time a number pointed one way and a branch's people pointed another." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold: pick a time a figure hid something a branch knew. If the spreadsheet ever showed a branch problem the numbers missed, name it. If not, say so plainly and say how you would check the numbers against a branch. | Neighbours, Not Numbers. The spreadsheet is the only nearby quote, so the answer is the honest branch. |
| 3.4 | "Tell me about a problem you found that wasn't yours to fix, and what you did until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Answer slot: name a problem you found, what you did, and whether you stayed with it until it was solved. If you did not, say so, and say what you would do differently. | Own the Fix. The log is the nearest quote; closure is not in it. |
| 3.5 | "A member has complained three times about the same fee. The branch says it's resolved; the member says it isn't, and now they have asked for you. Walk us through the next 20 minutes." | CASE | [generic] | Structure for the 20 minutes: clarify what was resolved, what the member received, and which records exist. Name yourself as the holder of the file. Speak to the member in plain words: what you know, what you will check, and when they will hear. Check the time limits and whether an outside route applies. Find the cause: the fee's wording, the branch's process, or the system. Fix it, or set a dated plan. Tell the branch manager, and coach the supervisor on the escalation. | A live problem. It asks about no past of yours, so the guidance makes no claim. Each step maps to a value: ownership, plain words, members first, and the branch. |
| 3.6 | "The branch manager says the fault is the member's and wants the file closed. What do you say?" | CASE | [generic] | Hold the member's side: ask what would show the member is wrong, check it, and close the file only on that evidence. Concede what you do not know. Do not close it to restore harmony. Say how you would tell the member. | Pressure inside the case: hold, then concede. No claim about your past. |
| 3.7 | "Twenty complaints about the same fee come in this week from one branch. What do you report, and to whom?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Structure: count and categorise, check for one root cause, report to the head of service and the branch with a date for the fix. Answer slot: if the spreadsheet already counts by branch and category, say so and how; if not, say what you would add. | F5 is discovery. The spreadsheet is the nearest tool, and what it counts is the slot. |
| 3.8 | "Our branch managers sit beside your team. Where's the seam, and what happens when you disagree about a complaint?" | VAL | [grounded] "coach branch supervisors on escalations" (JD) | Principles for the seam, not a claimed one: agree who owns a complaint at the handover from branch to contact centre, and say so in writing. Answer slot: if you have disagreed with a peer about a complaint, say what happened and how you settled it. If not, say how you would settle one. | Peer Evaluator: turf and disagreement. Branch managers are the people the role serves. |
| 3.9 | "What would you need from us in your first month?" | JD | [generic] | Reciprocity: say what you would bring their branches, such as an early read of complaint types by branch, and what you would ask them for in return. Keep to concrete asks. | Peer Evaluator's test: does the hire reduce their load or add to it? |
| 3.10 | "Sixty seconds: why should we trust someone with no contact-centre experience to run complaints across it?" | JD | [grounded] "Never worked in a contact centre" — your message | Pause, then restate the question. Plain acknowledgment: "I've never worked in a contact centre." Then the adjacent work, the branch complaints log, and one plan. Hold the point through two follow-ups. Concede one specific thing; do not fold on your handling record. | The sixty-second version of 2.5. The same plain words, delivered under time pressure. |

**Round 3 reverse questions**
- "When a complaint moves from a branch to the contact centre today, who holds it?" Why it lands: it names the seam the role exists to close.
- "What do branch managers most want from the complaints team that they are not getting now?" Why it lands: it asks the peer what the hire would give them.

**Other reverse question, for any round**
- "How will complaints from the small-business lending product, launching in Q1 2027, be routed?" Why it lands: it shows you read the brief past the digital and hub items.

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | 1.1 (F2, no gap) |
| Own the complaints process end to end across branches and the contact centre | 2.4, 2.5, 3.10 |
| Report monthly on complaint volumes and resolution times | 2.7, 3.7 |
| Coach branch supervisors on escalations | 2.10, 3.8 |
| Work with digital teams on self-service journeys | 2.9 |
| Experience handling regulated complaints | 2.4 |
| Confident presenting to senior leaders | 2.6 |
| Comfortable with Excel reporting | 2.7 (F4) |
| Location and travel (the gate, not in the JD's text) | 1.5 (F10) |

## Sources

**Provided documents**
- JD text, in your message.
- Your background, in your message.
- Ashgrove values page copy, dated 20 November 2026, which you copied from ashgrovecu.org/about/values.
- The recruiter's email on the process: three rounds on 29 November; the Round 3 panel is the values round.
- The 2026 strategy brief, published July 2026, which the recruiter sent.

**Research tier: L1, searches 0 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values page copy in hand fixes the four value names and definitions: the values cheat sheet and 1.8. |
| 2. Interview process | skipped | The recruiter's email establishes the loop: three sessions, and who runs each. This fixes the loop-mode structure and round weights. |
| 3. Strategy / recent news | skipped | The July 2026 brief in hand fixes the current priorities: the grounding brief, 1.2, 1.5, 2.8, 2.9. |
| 4. Interviewer name | n/a | No names given: the Head of Member Services and the Round 3 branch managers are unnamed. |
| 5. Representative JD | skipped | The JD is supplied, so it fixes the fit snapshot. |

No search or fetch was sent, and none failed. The strategy brief and the values copy are not fetched from Ashgrove's own site in this run; they are the copies you and the recruiter supplied.

## Upgrade menu

- The answer to the location question → settles gate row F10 and turns 1.5 from a slot into a grounded answer.
- Names of the Head of Member Services and the two branch managers → an interviewer read, persona weights per interviewer, and reverse questions tied to their public career paths.
- The regulator and complaint time limits that apply to Ashgrove → the escalation case's clock (3.5) and 2.4 become grounded in named rules, not generic.
- What your monthly spreadsheet counts (its column headings) → F5 becomes grounded, and 2.7 and 3.7 get a real answer instead of a slot.
- The tool you built the spreadsheet in, and what you built into it → F4's presentation bridge becomes a specific, checkable claim.
- Any digital or self-service work you have done → F9 becomes a grounded row, and 2.9 gets a story.
- A deeper research pass (up to 6 searches and 2 fetches, several minutes) on Ashgrove's recent leadership and reorganisation → the recent-org-context row, and sharper reverse questions. Offered once; say if you want it.
- The recruiter's prep note, if one exists → coverage of anything they say the panel will focus on.
