Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-2-rooms-case-4-denied-b87e18ef/2f2c97ca-c5ab-494a-9a6e-69ceb3dca575/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md`. It's built for the Thursday hiring-manager round from your dossier. The interviewer isn't named, so the persona weights use the usual hiring-manager pattern.

Two things to check before Thursday:

- **The dossier is about three months old** (dated 2026-08-14). Confirm the role and the squad-authority situation are still as it describes.
- **Your dossier doesn't evidence "shipped API or platform products" (R2, a must-have).** The pack treats it as an open question, not a gap you've already named. Be ready to answer it honestly, whichever way it goes: question A5 covers it.

The pack's highest-ROI rehearsal is A1, the "why hire you into a PM role" objection. It's a three-beat answer: acknowledge the gap, state the adjacent work at its own scope, then give a ramp plan.

Research didn't run. Both searches were refused because search permission wasn't granted in this session, so the values and strategy sections are absent and the question bank is built from your dossier and the posting alone.

Offers, none pushed:
- I can run a live drill on A1, with the interviewer pressing back on the objection and feedback against that question's guidance.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry forward.
- If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep: Product Manager, Platform APIs at Quartzline

Round: 45-minute conversation with the hiring manager, Thursday 2026-11-26. Interviewer: not named. First version, so no changelog. The dossier is dated 2026-08-14, about three months before this pack, so check the role's status before relying on it.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored.

- **JD**: can you do a requirement the posting lists, including its gaps.
- **EXP**: what you actually did, in your own words.
- **CASE**: a live problem from this role, reasoned aloud.
- **CO**: company strategy. Not covered here, because research did not run.
- **VAL**: published values. Not covered here, because no values were detected.

Guidance is scaffolding, not a script. Say it in your own words. Where a cell marks an answer slot, the interviewer's probe is what you answer, and either honest branch is a complete answer.

## Fit snapshot

Requirements come from the dossier's role profile (`dossier R1` to `R5`). Evidence is quoted from the dossier's verified evidence (`dossier V1` to `V3`). Confidence and gap type follow the dossier where it has them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | low | [grounded] | transferability | Adjacent work, not PM experience, and the limit comes first. Plain acknowledgment, sourced to the dossier's prohibited_claims: "I haven't held a product manager title." Then the adjacent work, at its own scope, quoted in the evidence column. Never call the integration or roadmap-input work PM experience. |
| F2 | "Shipped API or platform products" (dossier R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | none | [inferred] | discovery | Your material touches this requirement without showing whether it reaches it. Answer slot: if you shipped an API or platform product, say what shipped and what your part was, in your own words; if none did, say so plainly and stay with the integrations you led. The dossier does not list R2 as a weak area, so the underwriter may not have checked it. Treat it as open. |
| F3 | "Technical fluency: API docs, schemas" (dossier R3, important) | "Wrote the internal integration playbook her team uses" — dossier V2 | low | [inferred] | discovery | The playbook is the nearest evidence, but the material does not show whether it covered API docs or schemas. Answer slot: if you wrote or reviewed API docs or schemas in the playbook or in an integration, say what and your part; if not, say so plainly and name the doc or schema you would read first. |
| F4 | "Stakeholder management across engineering, sales, customers" (dossier R4, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [grounded] | presentation | Reword only the quote. Scoping, requirements, UAT and go-live are client-facing phases, and the material does not name engineering or sales. Do not add groups or practices. |
| F5 | "Agile delivery experience" (dossier R5, preferred) | none given | low | [grounded] | discovery | The dossier records this as a clarify area: the evidence may exist and was not established. Answer slot: if you worked in sprints or a delivery cadence, say what it was and your part; if you did not, say so plainly, and say what you would want to confirm about how this team defines agile delivery. |
| F6 | "Owning a roadmap and prioritization authority" (dossier R1 sub-claim, acknowledge_gap) | none given | none | [grounded] | capability | The dossier records this gap, so the words are a plain acknowledgment, not a bridge: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Source: dossier prohibited_claims, named by field. Then a ramp plan, in plan language only. No answer slot here. |

What the table does not settle: the dossier lists no hard gates, so none appear here. Decision authority against the two squad leads is unresolved (see the reverse questions).

## Persona table

The hiring-manager prior is Case/Strategist plus Skeptic. No interviewer profile was supplied, so no weights were adjusted.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Presses the PM-title gap and the roadmap claim, the "why you, not a PM with three years" objection | High. A hiring manager is buying derisked capability, and the dossier names this objection as the likeliest one | Rehearse the objection until it is plain. Acknowledge first, then the adjacent work at its own scope, then the plan |
| Case/Strategist | Live problems on the partner roadmap and squad sequencing | High. The JD makes the role two squads plus partners, so expect a live problem | Clarify, then objective, then who decides, then metrics, then risks. Name the decision boundary before proposing anything |
| Data-Driven Prober | Asks how "30+" was counted and what adoption looks like | Medium. The 30+ figure and the medium-confidence roadmap-input line invite a count probe | Know how the figure was counted, or say you do not. Name the assumption you would defend least |
| Pressure | Time-boxed, challenges how much of the work was yours | Medium. The objection is hard to answer briefly, so expect a time limit | Pause. Restate. Hold through two follow-ups. Concede the uncertain part without folding the core claim |
| Conversational | Opens with "walk me through the journey" and a casual JD topic | Low to medium. Common opener, and casual questions are still scored | Keep a 90-second arc ready. Treat casual questions on the JD's topics as scored |

## Question banks

Eighteen questions: Skeptic 5 (top weight), Case/Strategist 4, Prober 3, Pressure 3, Conversational 3.

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Having held a product manager title or role"; "Having owned a product roadmap" (dossier prohibited_claims); "Owning a roadmap and prioritization authority" (dossier acknowledge_gap); "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3) | The highest-ROI prep in this pack. Three beats, under 120 seconds. (1) Plain acknowledgment: "I haven't held a product manager title, and I haven't owned a product roadmap." (2) Adjacent work at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs, scoping through go-live," and "Ran quarterly roadmap-input sessions feeding client evidence to product." Stop there. The limit is the scope. (3) Ramp plan, in plan language: the first decisions you would take to the squad leads, and what you would check in the first month. Hold through two follow-ups by returning to beats 2 and 3. Concede plainly: if pressed on "you would be the one deciding," say you have not made that call and would want to confirm the decision boundary before taking it on. | The underwriter named this objection, so it is used as written. Every negative in it has a source (prohibited_claims and acknowledge_gap, named by field). It targets F1 and F6. It is the deepest rehearsal because it will be asked in some form. |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Owning a roadmap and prioritization authority" (dossier acknowledge_gap); "Having set prioritization for an engineering squad" (dossier prohibited_claims) | Name the roadmap and prioritization gap first, plainly: "I haven't set prioritization for an engineering squad." Then the ramp plan. Do not list other gaps you cannot back up. | Scores whether you can name your own gap without bluffing. Maps to F6, and to the requirement R1 sub-claim. |
| A3 | "I don't see agile product delivery in your background — how would you handle it in this role?" | JD | [grounded] "Agile delivery experience" (dossier R5, clarify area) | Clarify strategy. Answer slot: if you worked in sprints or a delivery cadence, say what it was and your part; if you did not, say so plainly, and say what you would want to confirm about how this team defines agile delivery. | F5 is low confidence and a clarify area, so the question is about how you define the term, not a claim that you did it. |
| A4 | "Why move from integration work into product management, and why now?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3) | Start from the one sentence you have: the roadmap-input sessions were where client evidence reached product. Answer slot: say what drew you to the product side, in your own words. If those sessions are the closest you came, say so. | The motivation is not in your material, so the guidance does not supply one. The sessions are the only bridge the material carries, and it is stated at its own scope. |
| A5 | "Tell me about an API or platform product you have shipped. If none comes to mind, say so." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Open prompt: choose an instance. If you shipped one, say what shipped and your part, in your own words. If none did, say so plainly, then give the nearest thing your material carries: the integrations you led, at their scope. | R2 is must-have and has no quote that reaches it (F2). The honest branch is part of the answer. |

### Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch the first 90 days: what do you need to know before you propose any change to the partner roadmap?" | CASE | [generic] | Clarify, then objective, then who decides, then partner segments, then metrics, then risks. Ask first which decisions belong to the squad leads. Do not claim a decision you have not made. | A live problem from the role. The question needs no claim about your past, so the guidance makes none. |
| C2 | "Partners say the API docs are unclear and integrations stall. Diagnose it." | CASE | [generic] | Clarify which partners and which stage of integration. Then name the signals you would check, starting with where integrations stop. Do not assert a specific failure point. | Covers R3 (API docs and schemas) through a live problem, because F3 is discovery and the diagnosis should not rest on a claim about past docs work. |
| C3 | "Adoption fell 20% last quarter. Where do you start?" | CASE | [generic] | Hypothetical figure, so no claim about your past. Clarify the metric and how it was counted, then segment (new versus existing partners), then check whether the drop is in signups or in live use. Say what you would need from the squad leads. | Tests the metrics and adoption work in the JD. The figure is a hypothetical, labeled as one. |
| C4 | "Two engineering squads disagree on sequencing for a partner feature. What do you do?" | CASE | [generic] | Clarify what the disagreement turns on and who has the call. Propose a decision path that does not require authority you do not have: put the trade-off in front of the decision owner, with the partner evidence attached. Say plainly that you have not set priorities for a squad. | Covers R4 (stakeholder management) and the squad-authority risk. The answer shows judgment without claiming authority. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through how you ran the roadmap-input sessions. How did you count the client evidence?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3) | Lead with the limit, because V3 is medium confidence: "the sessions are confirmed, but the proof of what they changed is limited, and I expect you to ask about it." Then describe the sessions in the dossier's words. Answer slot: if you counted or scored the evidence, say how; if you did not, say it was a qualitative input and say what you would count next time. | Medium confidence means a probe is likely, and the limit is best volunteered before it is extracted. The premise "how did you count" presupposes a counting method that is not in the quote, so it is a slot. |
| P2 | "Your '30+' — how was that counted, and which of those integrations were yours from scoping to go-live?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Defend-the-number: say how the 30+ was counted, in your own words. Name the assumption behind the count you would defend least. Say which phases you did and which, if any, were shared. Hold the figure at its quoted scope. | The highest-scrutiny figure in the material. The answer is a precise attribution, not an explanation of the count. |
| P3 | "How would you measure partner API adoption, and what did you measure after go-live?" | JD | [inferred] "How adoption is measured today" (dossier unknowns, derived) | Answer slot: if you measured anything after go-live, say what and how; if you did not, say so plainly and say what you would measure first. Do not describe a measure you did not track. | Covers the adoption-metrics responsibility. The dossier says the baseline is not stated, so the slot allows that you measured nothing. |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Sixty seconds: why you over a PM with three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1); "I haven't held a product manager title" (dossier prohibited_claims) | Pause, then restate the question in your own words. Give the acknowledgment and the adjacent work in 60 seconds. Hold through two follow-ups by returning to the same two facts. Concede the uncertain part specifically, for example "the PM side is the part I have not done." | Pressure tests composure. The position you hold must be one your quotes carry. |
| S2 | "That integration number — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Name your phases in your own words, from the quoted list. Where a phase was shared, say so before they ask. Hold the core claim, which is that you led them, and concede any phase that was not yours. | Attribution under time pressure. The rehearsal is precise honesty about your share. |
| S3 | "Two squad leads hold delivery decisions. When a squad lead disagrees with your call, what do you do?" | JD | [grounded] "Write specs and drive delivery with two engineering squads" (dossier role_profile responsibilities); "Decision authority versus the two squad leads" (dossier unknowns, quoted as a plain unknown) | Hold: put the decision question to the decision owner, with the evidence attached. Concede: say you would want the decision boundary confirmed before you take a call against a squad lead. | The unknown is not yet resolved, so the honest answer names the boundary as open. |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So — walk me through the journey." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1); "Wrote the internal integration playbook her team uses" (dossier V2); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3) | A 90-second arc in this order: the integrations, the playbook, the roadmap-input sessions. Then one sentence that names the PM gap. End there. | Casual openers are scored. The arc puts the limit in the last sentence, so it is not a surprise. |
| R2 | "What do you read about API product management?" | JD | [generic] | Answer slot: name any source you read, or say you have not followed the field. Do not name reading you did not do. | Tests interest in the JD's domain. No claim about your past is needed. |
| R3 | "Anything you'd want to ask me?" | CO | [generic] | Do not give a generic answer. Use the reverse questions below, starting with the two the dossier named. | Rapport interviewers weight this slot heavily. |

Requirement coverage:

| Requirement | Questions |
|---|---|
| R1, 3+ years PM experience | A1, A2, A4, S1 |
| R2, shipped API or platform products | A5 (F2 is discovery) |
| R3, API docs and schemas | C2, P1 (F3 is discovery) |
| R4, stakeholder management | C4, S3 |
| R5, agile delivery | A3 |
| Roadmap and prioritization authority (R1 sub-claim) | A1, A2, S3 |
| Adoption metrics (responsibility) | P3 |

## Reverse questions

1. "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" — Why it lands: the squad-authority question is unresolved, and you need the answer before you accept. Asking it reads as diligence. (From the dossier's questions for employer.)
2. "How is partner API adoption measured today, and what is the current baseline?" — Why it lands: the dossier found no baseline. The answer tells you whether the adoption responsibility is a measured job or a new one. (From the dossier's questions for employer.)
3. "What would make you say the hire was a success at six months?" — Why it lands: it sets the bar in the hiring manager's words, and their answer shows how they weigh the gap. [generic]
4. "Which of the two squads is closest to partner delivery right now?" — Why it lands: it shows where the partner work sits and who carries it. [generic]
5. "What is the biggest partner-facing risk the roadmap carries right now?" — Why it lands: it turns the conversation to the work and tests whether the role has a known problem. [generic]

## Prohibited claims

Each entry has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "Having held a product manager title or role" | Sourced: dossier prohibited_claims | The plain acknowledgment "I haven't held a product manager title." Then V1 and V3 at their own scope |
| "Having owned a product roadmap" | Sourced: dossier prohibited_claims and acknowledge_gap | The plain acknowledgment. Then a ramp plan in plan language, never the past tense |
| "Having set prioritization for an engineering squad" | Sourced: dossier prohibited_claims | The plain acknowledgment. Then the decision boundary, stated as open |
| "Drove the roadmap" (from "Ran quarterly roadmap-input sessions feeding client evidence to product") | Inflated form of V3, built here | V3 at its own scope. The material says the sessions fed client evidence to product. It does not say what product did with it |
| "Owned partner API delivery across both squads" (from "Led 30+ end-to-end client integrations") | Inflated form of V1, built here | V1 at its own scope. The material says you led integrations, not squads |
| "Shipped the vendor's API" (from "Led 30+ end-to-end client integrations") | Inflated form of V1, built here | V1 only. Shipping a product is an answer slot (F2), never a claim |

## Sources

Provided documents:

- `tuesday-dossier.md`, dated 2026-08-14. Consumed: `handoff_to_mock_interview` (verified evidence, weak areas and their strategies, the objection, risks and employer questions, prohibited claims), `role_profile` (requirements R1 to R5, responsibilities, unknowns), and the decision context (conditional_go, the bridge positioning, and the squad-authority condition). The dossier carries no hard gates and no severe red flags.
- Verified evidence cited as V1, V2 and V3 in the pack.

Research:

- Query "Quartzline company values interview process product manager platform APIs" (standard): refused. Permission to use WebSearch was not granted in this session.
- Query "Quartzline partner API platform" (standard): refused. Same cause.
- No fetches were attempted.

Research tier: L1 — searches 0 of 6 returned results (2 refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Would have decided whether the values cheat sheet applies. Every call was refused, so no values were established |
| 2. `Quartzline interview process product manager` | unavailable | Would have set the loop structure and the persona weights. Weights here rest on the hiring-manager prior |
| 3. `Quartzline strategy` / recent news | unavailable | The search was refused. The dossier and the posting do not carry current strategy, so no CO questions were written |
| 4. `{interviewer name} Quartzline` | n/a | No interviewer name was given, so there was no query to form. The upgrade menu says what a name would unlock |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role profile fixes the requirements, so the JD tier is met |

## Upgrade menu

- The interviewer's name → a reverse question tied to their own path, and persona weights read from their public footprint
- Quartzline's published values page, pasted here → a values cheat sheet mapping each value to a story
- Search permission granted for this session → the values, interview-process and strategy research the pack could not run (targets 1 to 3 above)
- A current status check on the role, since the dossier is about three months old → confirms or updates F1 to F6 and reverse questions 1 and 2
- Whether you have shipped an API or platform product, stated in your own words → F2 becomes a grounded row and A5 gets a quoted answer
- Deep research (L2), offered once: four further targets, up to 6 more searches and 2 more fetches. It needs search permission, and it takes longer than this run
