This matches the mock-interview skill, which covers hiring-manager rounds and panels, so I'll load it and build the prep pack from there.
I have what I need from the spec. Research hasn't run, so I'll build the pack on your message alone and offer research as a question. Saving the pack file first.
The file I just wrote still carries the closing offers, questions and watch-out, which belong in the message, not the saved file. Removing them from the file.
Your prep pack for all three rounds is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-2-rooms-case-6-denied-8bde6c54/9737f5e5-ee5e-4e5c-af9c-1333ec915aa8/scratchpad/larkfield_engineering-manager_interview_pack.md`. I built it as one loop: a shared fit snapshot, then a mini-pack per round. It uses your message only, since no research has run yet.

# Larkfield Systems — Engineering Manager — three-round prep pack (loop mode)

**Rounds:** Tuesday, Director of Engineering, hiring manager, 45 min · Thursday, panel of two staff engineers and a product manager, 60 min · following Monday, VP Engineering, "values and leadership philosophy", 30 min.
**Built on:** your message only. No research has run. Interviewer names are not given, so personas are weighted by round type.
**Not included, and why:** prep triage (no prep time given); interviewer read (no names); values cheat sheet (no published values in hand); graded deliverables (none declared); grounding brief (no research).

## How to use

Personas are how each question arrives. Types are what is scored: **JD** role requirement, **EXP** your experience and its attribution, **CASE** live problem, **VAL** values and leadership, **CO** company knowledge (none here, since no research ran).
Guidance is scaffolding, not a script. Say the quoted sentences in your own words. Where a row says "answer slot", the honest answer is either branch, and "I don't know" or "that wasn't mine" are both valid.

## Fit snapshot (shared across rounds)

Requirements are quoted from your message; there is no posting text yet.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role summary, your message) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows one team of six. It does not show two squads. Keep the scope: "3 as a team lead of 6." Answer slot: the two-squad scope makes a probe on how you would run it likely. If you have run more than one group, say which and how, in your own words; if not, say so and say how you would split the two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" (role summary, your message), hiring part | "I run our hiring loop for backend roles" and "about 40 interviews last year" (your message) | medium | [grounded] | presentation | Your sentences already reach hiring. Say them in those terms, and keep the scope to backend roles. Do not widen it to the whole engineering org. |
| F3 | "own delivery, hiring and growth for 11 engineers" (role summary, your message), growth part | none given | none | [grounded] | discovery | Your material does not show growth work for engineers. Answer slot: if you have grown someone's scope or role, say who and what changed, in your own words; if you have not, say so and say how you would start with eleven people. |
| F4 | "own delivery" (role summary, your message) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | This is delivery against roadmap pressure on one team's reliability work, not ownership of a delivery function. Keep "after" as your word; do not turn it into "because". |
| F5 | "partner with hardware and product on roadmap" (role summary, your message), product part | "pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | Roadmap pressure is in your material. Partnering with product on the roadmap is not shown. Answer slot: if you shaped roadmap decisions with product, say which and how; if not, say so and say how you would partner. |
| F6 | "partner with hardware and product on roadmap" (role summary, your message), hardware part | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn hardware constraints, as a plan and never as a past. |
| F7 | Your own named gap: "managing managers" (your message) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | Words: "I've never managed managers." Then how you would learn it, as a plan. Not in the role summary; it is your gap, and it will likely come up at Director level. |

Requirement coverage: "Lead two squads" → A3, B7, C5 · "own delivery" → A8, B2, C4, C6 · "hiring" → A9, B6 · "growth" → A7 · "partner with hardware" → A1, A2, A6, C7 · "partner with product on roadmap" → B4, B5, B8, C4 · "managing managers" (your gap, not in the role text) → A2, A3 · values and leadership philosophy (VP round) → C1–C4.

## Prohibited claims

Built locally from the fit snapshot. No dossier is present.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've managed managers" | Negative you stated (F7) | Plain acknowledgment: "I've never managed managers." No slot. |
| "I've owned a hardware roadmap" | Negative you stated (F6) | Plain acknowledgment: "I've never owned a hardware-adjacent roadmap." No slot. |
| "I led two squads" or "I run engineering for eleven" | Inflated form of F1 | "3 as a team lead of 6." Limit, in the pack's analysis: your material shows one team of six, not two squads. |
| "I cut on-call burden by 60%" as the sole cause | Inflated form of F4 | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Limit: the sentence says "after", not "because of". |
| "I run hiring across the engineering org" | Inflated form of F2 | "I run our hiring loop for backend roles." |

## Persona weights by round

Weights are relationship priors, with reasoning shown. There are no interviewer signals, since there are no names.

| Round | Persona | Weight | Why |
|---|---|---|---|
| A · Director (hiring manager) | Skeptic | top, 4 | Hiring-manager prior: they are derisking the two named gaps (F6, F7) and the scale step (F1). |
| A · Director | Case/Strategist | mid, 3 | Hiring-manager prior: live problems on the actual roadmap. |
| A · Director | Data-Driven Prober | low, 2 | Your on-call and hiring lines invite attribution probes. |
| B · Panel, staff engineers | Peer Evaluator | top, 3 | Peer prior: seams and disagreement with equals. |
| B · Panel, staff engineers | Data-Driven Prober | mid, 2 | Staff engineers read the 60% and the 40 interviews closely. |
| B · Panel, PM | Values/Behavioral | mid, 2 | Cross-functional prior: a scored conversation from outside the function. |
| B · Panel, PM | Case/Strategist | low, 1 | One technical case, from the second staff engineer. |
| C · VP Engineering | Values/Behavioral | top, 4 | Recruiter named the round "values and leadership philosophy". |
| C · VP | Pressure | mid, 2 | Executive prior: composure on your strongest number. |
| C · VP | Case/Strategist | low, 1 | Altitude check, with no research to draw strategy from. |

Total: 24 questions across three rounds, within the 18–26 range.

---

## Round A — Director of Engineering, Tuesday, 45 min

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap." (your message) | Name the hardware-adjacent roadmap in those words. Then say how you would learn it in the first 90 days, as a plan. Do not describe a past. | F6 is the largest stated gap, and this stem asks for it directly. |
| A2 | **Highest-ROI prep.** "You haven't owned a hardware-adjacent roadmap. How would you partner with hardware on ours?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message); [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Acknowledge the gap in your words: "I've never owned a hardware-adjacent roadmap." Then the one roadmap-adjacent thing your material carries: "pushed a reliability quarter through against roadmap pressure." Answer slot: if you have worked alongside hardware or firmware teams on a decision, say which and what you decided; if not, say so and say how you would set up that partnership. Hold through two follow-ups by returning to the sentence. Concede specifically: you do not yet know the hardware constraints. | The role says "partner with hardware," and your material says you have not owned a hardware-adjacent roadmap. Expect this in some form. The question presupposes nothing about a partnership, so the slot's second branch is always open. |
| A3 | "You've led a team of six. Two squads and eleven people is a different job. What changes first?" | JD | [grounded] "3 as a team lead of 6" (your message); [grounded] "Lead two squads building device-management services" (role summary, your message) | Start from the scope: "3 as a team lead of 6." Name the one thing about the step up you would act on first. Answer slot: if you have run more than one group, say which and how; if not, say so and say how you would split the two squads. Do not claim you already manage at this scale. | F1 is transferability, so a scale probe is likely. The premise is the role's two squads, which comes from the role summary. |
| A4 | "Why leave a payments company now, for this role?" | EXP | [generic] persona stem, "why leave, why here, why now" | Your material gives no stated reason to leave. If no reason comes to mind, say so plainly, then give the nearest thing your material carries: the reliability quarter, in its own words. Give the reason in your own words. Do not borrow the company's pitch. | The Skeptic scores motivation consistency. Your material has no reason on record, so the honest form is the slot. |
| A5 | "A device fleet's alert volume doubled a week after a firmware rollout. Walk me through your first week." | CASE | [generic] | Clarify first: which devices, what changed, who owns the rollout. Then objective, segmentation, approach, metrics, risks, in that order, thinking aloud. If you draw on your own on-call work, use only: "pushed a reliability quarter through against roadmap pressure." | A live problem in device-management services. It makes no claim about your past. |
| A6 | "Hardware and product both want the next quarter's capacity. How do you decide?" | CASE | [generic] "partner with hardware and product on roadmap" (role summary, your message) | Clarify who owns the decision. Name the tradeoff. Propose a decision rule you would defend, and say what you would need from each partner. Do not claim you have made this call before. | Tests the partnership requirement the role states. F6 means you should not reach for a past. |
| A7 | "How would you grow a senior engineer who wants more scope than you can give them?" | JD | [generic] "own delivery, hiring and growth for 11 engineers" (role summary, your message) | Scaffold: say what you would ask them, what scope you would test, and how you would know it worked. Answer slot: if you have grown someone's scope, say who and what changed, in your words; if you have not, say so. | F3 is a discovery gap: your material shows no growth work. The slot asks only what you have done. |
| A8 | "Walk me through how the 60% on-call drop was counted. Which part would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Defend the number: name the counting method if you know it. If you do not, "I don't know how it was counted" is an honest branch. Name the weakest assumption before they do. Keep "after" as your word. Answer slot: which part was yours. Pushing the quarter through is the sentence's action; what caused the drop is what it does not say. | The headline figure on your record gets the defend-the-number slot. Probers find causal leaps first. |
| A9 | "Of about 40 interviews last year, what did you decide, and what did the team decide?" | EXP | [grounded] "I run our hiring loop for backend roles" (your message); [grounded] "about 40 interviews last year" (your message) | Answer in your own sentences: you run the loop for backend roles. Say which decisions were yours and which were shared. If you do not have offer or hire counts, say so. Do not invent an outcome. | F2 is presentation: the attribution is the question. The stem asks for the split, not for a named practice. |

**Reverse questions, Round A**

- "What would the first two quarters need to look like for you to say this hire worked?" *Why it lands:* it asks for the success measure and turns their derisking into a shared target.
- "Where does the hardware roadmap stand today, and which decisions are still open?" *Why it lands:* it shows you are thinking about the roadmap you would own, and it asks for facts without claiming anything.
- "What has to change in how the two squads run over the next year for it to go well?" *Why it lands:* it keeps the conversation on the job. No profile exists, so no question here ties to their own career path.

---

## Round B — Panel: two staff engineers and a product manager, Thursday, 60 min

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where's the seam between your squads and the staff engineers' work, and what happens when you disagree?" | JD | [generic] persona stem | Propose seam principles rather than a map you do not know: agree which decisions are theirs and which are yours, then test it. Answer slot: if you have disagreed with a senior engineer, say what it was and how it resolved, in your words; if not, say so and say how you would resolve it. | Peer scoring is seam-splitting. No sentence of yours touches seams, so the slot is the honest form. |
| B2 | "Which assumption behind the 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Same answer as A8, so the panel hears the same thing as Round A. Name the weakest assumption in your words. If you do not know how it was counted, say so. | The panel will compare notes on F4, so consistency across rounds is itself scored. |
| B3 | "A senior engineer wants to rewrite a service you've just stabilised. What's your first move?" | JD | [generic] | Ask what the rewrite fixes, what the stabilised service costs to keep, and what evidence would change your mind. Hold your position if the evidence supports it; concede specifically if the rewrite is the right call. Do not claim a past instance. | Tests peer disagreement style. It is a generic pattern, so it claims nothing about you. |
| B4 | "Tell me about a time you pushed back on roadmap pressure." | VAL | open prompt, theme from "partner with hardware and product on roadmap" (role summary, your message); [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Nearest story: the reliability quarter, in its own words: the pressure, the push, the drop. The sentence does not name who applied the pressure, so say who was asking. Answer slot: if the pushback was from product or someone else, say so and what you did; if the quarter was not pushback at all, say so and give the nearest thing your material carries. | The PM's native question. The honest branch covers material that does not carry it. |
| B5 | "What would you need from this role to make roadmap decisions faster?" | JD | [grounded] "partner with hardware and product on roadmap" (role summary, your message) | Reciprocity: say what you bring to the product team, not only what you need from it. Propose one principle for how roadmap calls get made. Do not pretend to know their process. | Peer reciprocity is what this panel weighs. |
| B6 | "Of the 40 interviews, how many led to offers?" | EXP | [grounded] "about 40 interviews last year" (your message) | Use only the figure you gave. If you know offer counts, give them. If not, say "I don't have that number." Do not estimate. | F2: the prober asks for the denominator. A count you did not give is not supplied. |
| B7 | "How would you set on-call targets for two squads of device-management services?" | CASE | [generic] "device-management services" (role summary, your message) | Clarify what the pager covers. Propose one measure. Name two risks: gaming the metric, and hidden toil. If you mention your 60%, keep its scope: "after I pushed a reliability quarter through." | The one technical case in the panel, grounded only in the role's scope. |
| B8 | "Describe a roadmap call you had to make without the data you wanted." | VAL | open prompt, theme from "partner with hardware and product on roadmap" (role summary, your message) | Scaffold: name the decision, what you did not have, what you did with it, and what you would check. If you have no such call, say so, and give the nearest thing your material carries: the reliability quarter, at its scope only. | Roadmap partnership is the role's requirement and the PM's native territory. |

**Reverse questions, Round B**

- "Where do the staff engineers and product most often disagree, and how does that get settled?" *Why it lands:* it shows you want to understand the seams, and it lets you hear how decisions get made.
- "What would a new engineering manager do in their first month that would genuinely help your team?" *Why it lands:* peer reciprocity. It asks what you can give before asking what you need.
- "What is one thing you would want the new lead to protect that people outside the team do not see?" *Why it lands:* it invites their judgment about what matters. No profile exists, so the question is role-generic.

---

## Round C — VP Engineering, following Monday, 30 min

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | open prompt, theme from the recruiter's "values and leadership philosophy"; [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Nearest story: the reliability quarter, at its scope. Say who you took the case to, in your words; the sentence does not name the audience. Answer slot: if the truth did reach leadership, say what it was and what it cost; if the quarter was not an unpopular truth to leadership, say so and give the nearest thing your material carries. | The standard values stem. The slot allows that the story does not exist. |
| C2 | "What's your leadership philosophy, in a minute?" | VAL | [generic] recruiter's "values and leadership philosophy"; [grounded] "I run our hiring loop for backend roles" (your message); [grounded] "3 as a team lead of 6" (your message); [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | A 90-second arc built only from your sentences. Name the one belief you act on, then point at one thing you did. Do not invent a philosophy you do not hold. | The recruiter named this round. The arc uses only sentences you actually said. |
| C3 | "When did you put a customer ahead of an internal metric?" | VAL | open prompt, theme from persona stem; [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Your material has no customer in it. The quarter is about your team's on-call burden. If no customer-first time comes to mind, say so plainly, then give the nearest thing: the quarter, at its scope. Do not turn "my team's on-call burden" into a customer. | A common values theme that your material does not carry, so the honest form is the slot. |
| C4 | "How do you decide what gets cut when reliability and roadmap pull apart?" | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Name what you weighed, in your words. If the decision was not yours, say whose it was. Hold the choice you made. Concede what you would weigh differently next time. | Values probe on the one decision your material records. |
| C5 | "Sixty seconds: why you over someone who has already run two squads?" | JD | [generic] persona stem; [grounded] "Lead two squads building device-management services" (role summary, your message) | Hold with your scope: "3 as a team lead of 6." Then name what you bring in its place, each in its own words: the hiring loop and the reliability quarter. Hold through two follow-ups. Concede specifically: "I haven't run two squads. Here is how I would learn it." | The composure test for this round. The hold is only the scope and the parts you can name. |
| C6 | "That 60%. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Hold, then concede. Hold: the quarter was yours to push, in your words. Concede the part you cannot establish: the drop followed the quarter, and you cannot say how much of it the quarter alone caused. Do not fold on "pushed through," and do not claim the whole drop. | The most likely composure test on your strongest number. The limit is named before it is asked for. |
| C7 | "Where would a device-management roadmap go wrong in the next two years?" | CASE | [generic] "partner with hardware and product on roadmap" (role summary, your message) | Structure: what you would want to know first, and what the roadmap is for and who sets it. State a hypothesis, then name two risks you would watch. Do not claim company strategy, since no research has run. | An altitude check. The pack says what it does not know instead of guessing at strategy. |

**Reverse questions, Round C**

- "Which of your values do people most often misread, and what does it look like when it is done well?" *Why it lands:* it asks for the operational meaning behind the values without claiming any.
- "What does this leadership team mean by a strong engineering manager, and where do managers here most often fall short?" *Why it lands:* it asks for the bar, which shows you are asking about the job's standard.
- "How do you want an engineering manager to disagree with you, and in which forum?" *Why it lands:* it tests the leadership philosophy in the open, and a clear answer tells you how decisions are made.

---

## Sources

- **Provided documents:** your message (the role summary, your background, the three rounds, your gap list).
- **Research tier: L0.** No searches or fetches ran. The pack rests on your message only.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield values | unavailable | Values cheat sheet, which would apply to Round C. Research was not run; consent is asked in the message. |
| 2. Larkfield interview process | unavailable | Loop structure; would confirm the round weights. |
| 3. Larkfield strategy and recent news | unavailable | Would give the altitude check in C7 a real company strategy to draw on. |
| 4. Interviewer names | n/a | No names given, so there is no query to form. |
| 5. Representative role JD | skipped | Your role summary fixes the requirements in the fit snapshot. |

## Upgrade menu

- **Full posting text** → the F-rows quote the posting instead of your summary, any gate terms it states (location, work authorization, pay) become gate rows, and A3, A6 and B5 get exact wording.
- **Interviewer names** (Director, each staff engineer, the PM, the VP) → persona weights from their public footprint, and one reverse question per interviewer tied to their career path.
- **Research at L1** (up to 6 searches, 2 page fetches) → Larkfield's published values and a values cheat sheet for Round C, the interview process to confirm the round weights, and a strategy question for C7.
- **Recruiter's prep email** → any pre-declared deliverable (a POV, a take-home) gets its own build section, and each round's focus areas get named.
- **Prep time before Tuesday** → a prioritised schedule keyed to A2, B2 and C6.
- **`tuesday-dossier.md`**, if you have one → verified claims in place of the local prohibited list, and objections ranked by evidence.

---

Two offers, neither pushed:
- Say the word and I'll play the Skeptic on A2, the hardware-roadmap question the pack names as the highest-ROI prep.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.

If you want the pack as a Word document, say so and I'll convert it.

Two questions:
1. Do you have the full posting text? If you paste it, the fit snapshot quotes it rather than your summary. If not, I'll keep the pack as built.
2. Shall I run public research on Larkfield (values, interview process, recent news), up to 6 searches and 2 page fetches? If not, the pack stays as built.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering-manager_interview_pack.md -----
# Larkfield Systems — Engineering Manager — three-round prep pack (loop mode)

**Rounds:** Tuesday, Director of Engineering, hiring manager, 45 min · Thursday, panel of two staff engineers and a product manager, 60 min · following Monday, VP Engineering, "values and leadership philosophy", 30 min.
**Built on:** your message only. No research has run. Interviewer names are not given, so personas are weighted by round type.
**Not included, and why:** prep triage (no prep time given); interviewer read (no names); values cheat sheet (no published values in hand); graded deliverables (none declared); grounding brief (no research).

## How to use

Personas are how each question arrives. Types are what is scored: **JD** role requirement, **EXP** your experience and its attribution, **CASE** live problem, **VAL** values and leadership, **CO** company knowledge (none here, since no research ran).
Guidance is scaffolding, not a script. Say the quoted sentences in your own words. Where a row says "answer slot", the honest answer is either branch, and "I don't know" or "that wasn't mine" are both valid.

## Fit snapshot (shared across rounds)

Requirements are quoted from your message; there is no posting text yet.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role summary, your message) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows one team of six. It does not show two squads. Keep the scope: "3 as a team lead of 6." Answer slot: the two-squad scope makes a probe on how you would run it likely. If you have run more than one group, say which and how, in your own words; if not, say so and say how you would split the two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" (role summary, your message), hiring part | "I run our hiring loop for backend roles" and "about 40 interviews last year" (your message) | medium | [grounded] | presentation | Your sentences already reach hiring. Say them in those terms, and keep the scope to backend roles. Do not widen it to the whole engineering org. |
| F3 | "own delivery, hiring and growth for 11 engineers" (role summary, your message), growth part | none given | none | [grounded] | discovery | Your material does not show growth work for engineers. Answer slot: if you have grown someone's scope or role, say who and what changed, in your own words; if you have not, say so and say how you would start with eleven people. |
| F4 | "own delivery" (role summary, your message) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | This is delivery against roadmap pressure on one team's reliability work, not ownership of a delivery function. Keep "after" as your word; do not turn it into "because". |
| F5 | "partner with hardware and product on roadmap" (role summary, your message), product part | "pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | Roadmap pressure is in your material. Partnering with product on the roadmap is not shown. Answer slot: if you shaped roadmap decisions with product, say which and how; if not, say so and say how you would partner. |
| F6 | "partner with hardware and product on roadmap" (role summary, your message), hardware part | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn hardware constraints, as a plan and never as a past. |
| F7 | Your own named gap: "managing managers" (your message) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | Words: "I've never managed managers." Then how you would learn it, as a plan. Not in the role summary; it is your gap, and it will likely come up at Director level. |

Requirement coverage: "Lead two squads" → A3, B7, C5 · "own delivery" → A8, B2, C4, C6 · "hiring" → A9, B6 · "growth" → A7 · "partner with hardware" → A1, A2, A6, C7 · "partner with product on roadmap" → B4, B5, B8, C4 · "managing managers" (your gap, not in the role text) → A2, A3 · values and leadership philosophy (VP round) → C1–C4.

## Prohibited claims

Built locally from the fit snapshot. No dossier is present.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've managed managers" | Negative you stated (F7) | Plain acknowledgment: "I've never managed managers." No slot. |
| "I've owned a hardware roadmap" | Negative you stated (F6) | Plain acknowledgment: "I've never owned a hardware-adjacent roadmap." No slot. |
| "I led two squads" or "I run engineering for eleven" | Inflated form of F1 | "3 as a team lead of 6." Limit, in the pack's analysis: your material shows one team of six, not two squads. |
| "I cut on-call burden by 60%" as the sole cause | Inflated form of F4 | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Limit: the sentence says "after", not "because of". |
| "I run hiring across the engineering org" | Inflated form of F2 | "I run our hiring loop for backend roles." |

## Persona weights by round

Weights are relationship priors (`personas.md`), with reasoning shown. There are no interviewer signals, since there are no names.

| Round | Persona | Weight | Why |
|---|---|---|---|
| A · Director (hiring manager) | Skeptic | top, 4 | Hiring-manager prior: they are derisking the two named gaps (F6, F7) and the scale step (F1). |
| A · Director | Case/Strategist | mid, 3 | Hiring-manager prior: live problems on the actual roadmap. |
| A · Director | Data-Driven Prober | low, 2 | Your on-call and hiring lines invite attribution probes. |
| B · Panel, staff engineers | Peer Evaluator | top, 3 | Peer prior: seams and disagreement with equals. |
| B · Panel, staff engineers | Data-Driven Prober | mid, 2 | Staff engineers read the 60% and the 40 interviews closely. |
| B · Panel, PM | Values/Behavioral | mid, 2 | Cross-functional prior: a scored conversation from outside the function. |
| B · Panel, PM | Case/Strategist | low, 1 | One technical case, from the second staff engineer. |
| C · VP Engineering | Values/Behavioral | top, 4 | Recruiter named the round "values and leadership philosophy". |
| C · VP | Pressure | mid, 2 | Executive prior: composure on your strongest number. |
| C · VP | Case/Strategist | low, 1 | Altitude check, with no research to draw strategy from. |

Total: 24 questions across three rounds, within the 18–26 range.

---

## Round A — Director of Engineering, Tuesday, 45 min

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap." (your message) | Name the hardware-adjacent roadmap in those words. Then say how you would learn it in the first 90 days, as a plan. Do not describe a past. | F6 is the largest stated gap, and this stem asks for it directly. |
| A2 | **Highest-ROI prep.** "You haven't owned a hardware-adjacent roadmap. How would you partner with hardware on ours?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message); [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Acknowledge the gap in your words: "I've never owned a hardware-adjacent roadmap." Then the one roadmap-adjacent thing your material carries: "pushed a reliability quarter through against roadmap pressure." Answer slot: if you have worked alongside hardware or firmware teams on a decision, say which and what you decided; if not, say so and say how you would set up that partnership. Hold through two follow-ups by returning to the sentence. Concede specifically: you do not yet know the hardware constraints. | The role says "partner with hardware," and your material says you have not owned a hardware-adjacent roadmap. Expect this in some form. The question presupposes nothing about a partnership, so the slot's second branch is always open. |
| A3 | "You've led a team of six. Two squads and eleven people is a different job. What changes first?" | JD | [grounded] "3 as a team lead of 6" (your message); [grounded] "Lead two squads building device-management services" (role summary, your message) | Start from the scope: "3 as a team lead of 6." Name the one thing about the step up you would act on first. Answer slot: if you have run more than one group, say which and how; if not, say so and say how you would split the two squads. Do not claim you already manage at this scale. | F1 is transferability, so a scale probe is likely. The premise is the role's two squads, which comes from the role summary. |
| A4 | "Why leave a payments company now, for this role?" | EXP | [generic] persona stem, "why leave, why here, why now" | Your material gives no stated reason to leave. If no reason comes to mind, say so plainly, then give the nearest thing your material carries: the reliability quarter, in its own words. Give the reason in your own words. Do not borrow the company's pitch. | The Skeptic scores motivation consistency. Your material has no reason on record, so the honest form is the slot. |
| A5 | "A device fleet's alert volume doubled a week after a firmware rollout. Walk me through your first week." | CASE | [generic] | Clarify first: which devices, what changed, who owns the rollout. Then objective, segmentation, approach, metrics, risks, in that order, thinking aloud. If you draw on your own on-call work, use only: "pushed a reliability quarter through against roadmap pressure." | A live problem in device-management services. It makes no claim about your past. |
| A6 | "Hardware and product both want the next quarter's capacity. How do you decide?" | CASE | [generic] "partner with hardware and product on roadmap" (role summary, your message) | Clarify who owns the decision. Name the tradeoff. Propose a decision rule you would defend, and say what you would need from each partner. Do not claim you have made this call before. | Tests the partnership requirement the role states. F6 means you should not reach for a past. |
| A7 | "How would you grow a senior engineer who wants more scope than you can give them?" | JD | [generic] "own delivery, hiring and growth for 11 engineers" (role summary, your message) | Scaffold: say what you would ask them, what scope you would test, and how you would know it worked. Answer slot: if you have grown someone's scope, say who and what changed, in your words; if you have not, say so. | F3 is a discovery gap: your material shows no growth work. The slot asks only what you have done. |
| A8 | "Walk me through how the 60% on-call drop was counted. Which part would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Defend the number: name the counting method if you know it. If you do not, "I don't know how it was counted" is an honest branch. Name the weakest assumption before they do. Keep "after" as your word. Answer slot: which part was yours. Pushing the quarter through is the sentence's action; what caused the drop is what it does not say. | The headline figure on your record gets the defend-the-number slot. Probers find causal leaps first. |
| A9 | "Of about 40 interviews last year, what did you decide, and what did the team decide?" | EXP | [grounded] "I run our hiring loop for backend roles" (your message); [grounded] "about 40 interviews last year" (your message) | Answer in your own sentences: you run the loop for backend roles. Say which decisions were yours and which were shared. If you do not have offer or hire counts, say so. Do not invent an outcome. | F2 is presentation: the attribution is the question. The stem asks for the split, not for a named practice. |

**Reverse questions, Round A**

- "What would the first two quarters need to look like for you to say this hire worked?" *Why it lands:* it asks for the success measure and turns their derisking into a shared target.
- "Where does the hardware roadmap stand today, and which decisions are still open?" *Why it lands:* it shows you are thinking about the roadmap you would own, and it asks for facts without claiming anything.
- "What has to change in how the two squads run over the next year for it to go well?" *Why it lands:* it keeps the conversation on the job. No profile exists, so no question here ties to their own career path.

---

## Round B — Panel: two staff engineers and a product manager, Thursday, 60 min

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where's the seam between your squads and the staff engineers' work, and what happens when you disagree?" | JD | [generic] persona stem | Propose seam principles rather than a map you do not know: agree which decisions are theirs and which are yours, then test it. Answer slot: if you have disagreed with a senior engineer, say what it was and how it resolved, in your words; if not, say so and say how you would resolve it. | Peer scoring is seam-splitting. No sentence of yours touches seams, so the slot is the honest form. |
| B2 | "Which assumption behind the 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Same answer as A8, so the panel hears the same thing as Round A. Name the weakest assumption in your words. If you do not know how it was counted, say so. | The panel will compare notes on F4, so consistency across rounds is itself scored. |
| B3 | "A senior engineer wants to rewrite a service you've just stabilised. What's your first move?" | JD | [generic] | Ask what the rewrite fixes, what the stabilised service costs to keep, and what evidence would change your mind. Hold your position if the evidence supports it; concede specifically if the rewrite is the right call. Do not claim a past instance. | Tests peer disagreement style. It is a generic pattern, so it claims nothing about you. |
| B4 | "Tell me about a time you pushed back on roadmap pressure." | VAL | open prompt, theme from "partner with hardware and product on roadmap" (role summary, your message); [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Nearest story: the reliability quarter, in its own words: the pressure, the push, the drop. The sentence does not name who applied the pressure, so say who was asking. Answer slot: if the pushback was from product or someone else, say so and what you did; if the quarter was not pushback at all, say so and give the nearest thing your material carries. | The PM's native question. The honest branch covers material that does not carry it. |
| B5 | "What would you need from this role to make roadmap decisions faster?" | JD | [grounded] "partner with hardware and product on roadmap" (role summary, your message) | Reciprocity: say what you bring to the product team, not only what you need from it. Propose one principle for how roadmap calls get made. Do not pretend to know their process. | Peer reciprocity is what this panel weighs. |
| B6 | "Of the 40 interviews, how many led to offers?" | EXP | [grounded] "about 40 interviews last year" (your message) | Use only the figure you gave. If you know offer counts, give them. If not, say "I don't have that number." Do not estimate. | F2: the prober asks for the denominator. A count you did not give is not supplied. |
| B7 | "How would you set on-call targets for two squads of device-management services?" | CASE | [generic] "device-management services" (role summary, your message) | Clarify what the pager covers. Propose one measure. Name two risks: gaming the metric, and hidden toil. If you mention your 60%, keep its scope: "after I pushed a reliability quarter through." | The one technical case in the panel, grounded only in the role's scope. |
| B8 | "Describe a roadmap call you had to make without the data you wanted." | VAL | open prompt, theme from "partner with hardware and product on roadmap" (role summary, your message) | Scaffold: name the decision, what you did not have, what you did with it, and what you would check. If you have no such call, say so, and give the nearest thing your material carries: the reliability quarter, at its scope only. | Roadmap partnership is the role's requirement and the PM's native territory. |

**Reverse questions, Round B**

- "Where do the staff engineers and product most often disagree, and how does that get settled?" *Why it lands:* it shows you want to understand the seams, and it lets you hear how decisions get made.
- "What would a new engineering manager do in their first month that would genuinely help your team?" *Why it lands:* peer reciprocity. It asks what you can give before asking what you need.
- "What is one thing you would want the new lead to protect that people outside the team do not see?" *Why it lands:* it invites their judgment about what matters. No profile exists, so the question is role-generic.

---

## Round C — VP Engineering, following Monday, 30 min

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | open prompt, theme from the recruiter's "values and leadership philosophy"; [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Nearest story: the reliability quarter, at its scope. Say who you took the case to, in your words; the sentence does not name the audience. Answer slot: if the truth did reach leadership, say what it was and what it cost; if the quarter was not an unpopular truth to leadership, say so and give the nearest thing your material carries. | The standard values stem. The slot allows that the story does not exist. |
| C2 | "What's your leadership philosophy, in a minute?" | VAL | [generic] recruiter's "values and leadership philosophy"; [grounded] "I run our hiring loop for backend roles" (your message); [grounded] "3 as a team lead of 6" (your message); [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | A 90-second arc built only from your sentences. Name the one belief you act on, then point at one thing you did. Do not invent a philosophy you do not hold. | The recruiter named this round. The arc uses only sentences you actually said. |
| C3 | "When did you put a customer ahead of an internal metric?" | VAL | open prompt, theme from persona stem; [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Your material has no customer in it. The quarter is about your team's on-call burden. If no customer-first time comes to mind, say so plainly, then give the nearest thing: the quarter, at its scope. Do not turn "my team's on-call burden" into a customer. | A common values theme that your material does not carry, so the honest form is the slot. |
| C4 | "How do you decide what gets cut when reliability and roadmap pull apart?" | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Name what you weighed, in your words. If the decision was not yours, say whose it was. Hold the choice you made. Concede what you would weigh differently next time. | Values probe on the one decision your material records. |
| C5 | "Sixty seconds: why you over someone who has already run two squads?" | JD | [generic] persona stem; [grounded] "Lead two squads building device-management services" (role summary, your message) | Hold with your scope: "3 as a team lead of 6." Then name what you bring in its place, each in its own words: the hiring loop and the reliability quarter. Hold through two follow-ups. Concede specifically: "I haven't run two squads. Here is how I would learn it." | The composure test for this round. The hold is only the scope and the parts you can name. |
| C6 | "That 60%. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Hold, then concede. Hold: the quarter was yours to push, in your words. Concede the part you cannot establish: the drop followed the quarter, and you cannot say how much of it the quarter alone caused. Do not fold on "pushed through," and do not claim the whole drop. | The most likely composure test on your strongest number. The limit is named before it is asked for. |
| C7 | "Where would a device-management roadmap go wrong in the next two years?" | CASE | [generic] "partner with hardware and product on roadmap" (role summary, your message) | Structure: what you would want to know first, and what the roadmap is for and who sets it. State a hypothesis, then name two risks you would watch. Do not claim company strategy, since no research has run. | An altitude check. The pack says what it does not know instead of guessing at strategy. |

**Reverse questions, Round C**

- "Which of your values do people most often misread, and what does it look like when it is done well?" *Why it lands:* it asks for the operational meaning behind the values without claiming any.
- "What does this leadership team mean by a strong engineering manager, and where do managers here most often fall short?" *Why it lands:* it asks for the bar, which shows you are asking about the job's standard.
- "How do you want an engineering manager to disagree with you, and in which forum?" *Why it lands:* it tests the leadership philosophy in the open, and a clear answer tells you how decisions are made.

---

## Sources

- **Provided documents:** your message (the role summary, your background, the three rounds, your gap list).
- **Research tier: L0.** No searches or fetches ran. The pack rests on your message only.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield values | unavailable | Values cheat sheet, which would apply to Round C. Research was not run; consent is asked in the message. |
| 2. Larkfield interview process | unavailable | Loop structure; would confirm the round weights. |
| 3. Larkfield strategy and recent news | unavailable | Would give the altitude check in C7 a real company strategy to draw on. |
| 4. Interviewer names | n/a | No names given, so there is no query to form. |
| 5. Representative role JD | skipped | Your role summary fixes the requirements in the fit snapshot. |

## Upgrade menu

- **Full posting text** → the F-rows quote the posting instead of your summary, any gate terms it states (location, work authorization, pay) become gate rows, and A3, A6 and B5 get exact wording.
- **Interviewer names** (Director, each staff engineer, the PM, the VP) → persona weights from their public footprint, and one reverse question per interviewer tied to their career path.
- **Research at L1** (up to 6 searches, 2 page fetches) → Larkfield's published values and a values cheat sheet for Round C, the interview process to confirm the round weights, and a strategy question for C7.
- **Recruiter's prep email** → any pre-declared deliverable (a POV, a take-home) gets its own build section, and each round's focus areas get named.
- **Prep time before Tuesday** → a prioritised schedule keyed to A2, B2 and C6.
- **`tuesday-dossier.md`**, if you have one → verified claims in place of the local prohibited list, and objections ranked by evidence.

