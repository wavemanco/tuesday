Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-2-rooms-case-1-denied-8495c0d3/6f8fc05f-0b4f-4a9a-abd9-83f4c4b153a0/scratchpad/northwind_senior-gtm-strategy-lead-emerging-products_interview_pack.md. I built it for a peer round, since you said Dan is a peer. It runs at L0: your JD highlights, your notes on Priya, Dan's profile and your research note. I didn't run any searches.

The pack has 21 questions across seven personas, weighted to Data-Driven Prober (5) and Peer Evaluator (4). Three things to know first:

- **C1 is the highest-ROI prep.** Dan's likely objection is that nine years in consumer tech doesn't show business selling. Your notes show nothing about selling to business customers or about quota work, so that's where the pack is thinnest.
- **A1 is the next one to rehearse.** The $400M figure is credited to Priya, which is attribution, not a solo result. Expect a probe on how it was counted.
- **Several answers are slots, not scripts.** Where your notes don't cover something, the pack gives her an honest branch ("that wasn't mine" or "I don't know") instead of a story.

Say the word and I'll play the Skeptic on C1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full JD text? The pack currently rests on six highlight lines, and the full text would sharpen the requirement rows. If you can't, I'll proceed as it stands.

Did the recruiter flag focus areas, a pre-declared deliverable or a process detail for this round?

Has Priya ever set or defended a quota, territory or partner-program target, even informally? If she hasn't, her own confirmation changes the sales-motion row from a gap the material shows to one she states herself.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Northwind Data: Senior GTM Strategy Lead, Emerging Products. Interview pack for Priya

**Round:** single 60-minute conversation with Dan Kovac, Director of Sales Strategy. Dan is a **peer**: both would report to the same VP.
**Research tier:** L0, provided documents only (JD highlights, the coach's notes on Priya, Dan's profile, the coach's research note). No searches were run. Section 14 has the accounting.
**Changelog:** first version.

---

## 1. How to use, and the type key

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **VAL** behavioral / values alignment. **EXP** work-experience deep-dive. **JD** role-driven, tied to a JD line. **CO** company and strategy knowledge. **CASE** live problem, no claim about the past.
- **Provenance** labels: `[grounded]` traces to what you gave me or the research note. `[inferred]` is a derivation, named. `[generic]` is a pattern with no claim about Priya or Northwind.
- **Answer slots** are instructions for the answer in the room. They are not sentences to memorize, and they have an honest branch for "that was not mine" or "I don't know."
- **Guidance is scaffolding, not a script.** Rehearse it in Priya's own words.

---

## 2. Fit snapshot

Requirements are quoted from the JD highlights. Evidence is quoted from the coach's notes on Priya. Nothing in the evidence column is paraphrased.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | medium | [grounded] | transferability | Your material shows product strategy and ops at a consumer-tech company, not go-to-market strategy for a product line. In your words: "9 at a large consumer-tech company in product strategy & ops." Answer slot: if you set any go-to-market decision for a product, say which and how you decided. If none was yours, say so and stay with the strategy and ops work. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | medium | [grounded] | transferability | Revenue modeling is adjacent to whitespace across the lifecycle. Nothing in the material shows a lifecycle view. Answer slot: if the model showed where value was unclaimed, say where and how you saw it. If it did not, say what it did show and what you would map first. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (the coach's notes) | low | [inferred] | discovery | A skill is named and no analysis is shown, so this is a lead, not a claim. Answer slot: if you ran an analysis yourself, name the question and the result you acted on. If not, say so and say what you would query first. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | medium | [grounded] | transferability | Partner-level economics is adjacent to partner-motion design. The material shows a model used in negotiations, not a partner program. In your words: "built a partner-level revenue model used in carrier negotiations." Answer slot: if you shaped how partners were paid or enabled, say which decision was yours. If not, say the model is what you built and that you did not design a partner motion. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (the coach's notes) | medium | [grounded] | presentation | Your material reaches this in other terms: cross-org consensus on a target. The bridge rewords only that quote: "I set annual volume targets with cross-org consensus." It adds no method. If the room asks how consensus was reached, that is an answer slot: say it in your own words. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (the coach's notes) | medium | [grounded] | transferability | Daily use is adjacent to AI product experience. It does not reach building or evaluating AI. In your words: "I use AI tools daily." Answer slot: if you have built or evaluated anything AI-based, name it. If not, name what you use and what you would test first for Compass. |
| F7 | No JD line. CV headline metric. | "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | medium | [grounded] | discovery | This is the most-probed claim in the pack. "Credited" is attribution, and the material does not show the method or the share. Defend-the-number slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. In your words: "proposed a store-surface change credited with a ~$400M ARR uplift." |
| F8 | Sales motion, land/adopt/expand/renew. Role-family pattern, not a quoted JD line. | "No classic sales-ops or quota-setting experience" (the coach's notes) | none | [grounded] | discovery | The notes show no sales-ops or quota work. That absence is the pack's observation about the material, not a line for Priya to say. Answer slot: if you set or shaped any target that carried a sales outcome, say what and how. If not, say so plainly. This is the most likely objection; see C1. |

**Gate check.** No requirement here is a gate. A gate is a term such as authorization, licence, location, schedule, pay, travel or a credential. "Partner-motion design experience required" is experience, so it is graded on fit and gap type. The one gate question (Step 1 item d) therefore has no row to ask about.

**Confidence and provenance are separate axes.** F3 is low because the skill is only named. F8 is confidence none because the notes show no sales-ops or quota work. Neither band is set by how strong the JD line sounds.

---

## 3. Grounding brief (from the coach's research note)

| Topic | What the note says | Used in |
|---|---|---|
| Enterprise expansion | Stated priority | D3, R5 |
| AI copilot launch ("Compass") | Stated priority | B3, D1, R4 |
| Reaching profitability | Stated priority | D2 |
| Bundling by a much larger platform vendor | Main competitive threat | D1, R3 |

The brief comes from the coach's note and was not verified by search in this run. The vocabulary "land/adopt/expand/renew" comes from the JD highlights. Refresh it with a search if you want a more current strategy read.

---

## 4. Reading the interviewer

**Career pattern (from Dan's profile):** a pricing and monetization spine, with one early-stage-startup chapter. The self-description is "relentlessly data-driven." This is the public footprint you gave me; nothing else was checked.

**Practical implications**

1. **Expect denominators.** The Data-Driven Prober's weight goes up. Every figure Priya gives will be taken back to its assumptions.
2. **Case questions tilt toward pricing, packaging and unit economics.** That is Dan's native ground, so D1 and D2 are weighted to it.
3. **The startup chapter means builder stories land.** Expect a "what did you do with no team and no budget" probe, and rehearse one honest answer to it.
4. **Mirror opportunity, a shared domain and not a shared identity.** Priya's "built a partner-level revenue model used in carrier negotiations" sits in monetization, which is Dan's territory. A reverse question about pricing ties there (R1). No shared career jump is known, so none is claimed. Shared identity is not a strategy and is not coached.

---

## 5. Persona weights

Starting point: a **peer** round gives Peer Evaluator and Data-Driven Prober as the dominant pair. Adjustments follow from Dan's profile and from the fit snapshot.

| Persona | Weight (depth) | Reasoning | How it shows up | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | 5 | Peer prior, plus "relentlessly data-driven" raises it. The CV headline is a $400M attribution | Denominators, assumptions, "walk me through how it was counted" | Name the weakest assumption first; say plainly what is not known |
| Peer Evaluator | 4 | Peer prior. Both report to the same VP, so the seam and the split matter | Seam questions, credit, "what would you need from me" | Reciprocity first; propose seam principles rather than claiming the seam |
| Skeptic | 3 | The fit snapshot's thinnest area is sales motion (F8) and business selling (F1). That is where a skeptic will press | "Nine years at a consumer-tech company, what did you sell?" | Rehearse C1 until it is plain and not defensive |
| Case / Strategist | 3 | Dan's pricing spine tilts cases to pricing and unit economics. Compass and bundling are live | Sized problems, pricing for Compass, a unit-economics diagnosis | Clarify, then structure, then state a hypothesis early |
| Pressure / Stress | 2 | Low: no stress-round signal in the material, but a 60-minute peer round can still test composure | "Sixty seconds," "how much of that was you" | Hold through two follow-ups; concede one specific point |
| Conversational / Rapport | 2 | Low: an opener is still scored | "Walk me through the journey," "what are you playing with in AI" | A 90-second arc; treat casual AI questions as scored |
| Values / Behavioral | 2 | Low: no values round is detected. Cross-functional influence is a JD line, so it is still touched | Cross-org story prompts | Story map from quoted sentences; selection scaffolds where none exists |

Depth totals 21 questions, inside the 18–26 range. The top persona gets 5, the mid-weight ones 3, and the low-weight ones 2.

---

## 6. Question banks

Type tags are on each row. Provenance lists every quoted sentence the guidance rests on.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Defend the number in order: the method in your own words, then what it is sensitive to, then which part was yours. Answer slot: if you can say how it was counted, say how. If you do not know, say so plainly and say what you would check. Do not reconstruct a method you cannot repeat. | F7 is the headline metric and the first thing a prober tests. "Credited" is attribution, so the probe is about the share, not whether the uplift exists. |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Name the weakest assumption before Dan does, in your own words. Answer slot: if you know the assumptions, name the one you would defend least. If you cannot name any, say that plainly rather than inventing one. | The weakest-assumption move on F7. Naming it first turns a gotcha into a credibility gain. |
| A3 | "Your partner-level revenue model. What were its inputs, and which one would you change first?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | Say what the model was for and the inputs you can name. Answer slot: if you can name the inputs, pick the weakest and say what you would change. If you cannot list them, say so. Do not list inputs you do not have. | F4 and F2: the model is the strongest partner-economics evidence, so it draws the deepest scrutiny. Its premise is a model, and its use in negotiations, both quoted. |
| A4 | "Tell me about an analysis you ran yourself in SQL or Tableau. What question did it answer, and what did you do with the result?" | JD, EXP | [inferred] "skilled in SQL/Tableau" (the coach's notes) | The skill is a lead, not a story. Answer slot: if you ran one yourself, name the question, the data and the result you acted on. If the work was shared, or you only used a dashboard, say so. If you have not run one, say that and say how you would start with this company's data. | F3 is low confidence, so the guidance cannot assert an analysis. The open prompt takes its theme from the JD line, and the answer slot allows the honest branch. |
| A5 | "Your ~$400M figure is an attribution. What would have to be true for it to be half as large?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Hold the figure as stated, then name what would shrink it: the share of the outcome credited to the change, and whatever else moved in the same window. Answer slot: name a sensitivity you know of. If you have not checked, say so. Do not give a new number. | A sensitivity probe on the same figure. The quote carries the figure's scope, so the guidance adds no figure. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where would you draw the seam between your new-product GTM work and sales strategy, and what happens when we disagree?" | VAL, JD | [generic] persona stem; no claim about Priya | Reciprocity first: say what you bring to Dan's team. Then propose seam principles, such as who owns price, who owns the target, and who decides when two plans collide, rather than claiming to know the seam. For disagreement: pick a time you disagreed with a peer team over a number. If none comes to mind, say so, then say how you would handle it. | The Peer Evaluator's core probe. F5 is the influence line, and no quoted disagreement story exists, so the scaffold ends in its honest branch. |
| B2 | "When a launch spans product, pricing and sales, how do you handle credit?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Credit-sharing: name who else shaped the change and what you did, in your own words. Answer slot: if the change was shared, name the others and your part. If you proposed it and little more, say that. Do not present the $400M as yours alone. | The credit probe fits a peer seat. The quote says "credited," so the answer keeps that scope. |
| B3 | "Compass is an AI copilot launch. Which parts should go through partners and which direct, and how would you split that with my team?" | JD, CO | [grounded] "AI copilot launch ('Compass')" and "partner-motion design experience required" (the coach's research note; JD highlights) | Reason from principles: which buyer needs the direct relationship, and which partner already owns distribution. Say the principle, not a past partner program. Answer slot: if you have designed a partner motion, name one decision you made. If not, say what you would test first. | This is the partner-motion gap (F4) meeting a live CO question. The answer runs on principles and marks the experience slot honestly. |
| B4 | "We both report to the same VP. How would you divide new-product GTM with me?" | JD | [grounded] "both reporting to the same VP" (the coach's notes) | Propose a split by principle: what you would own, what you would share, and how you would settle a conflict. State one split and one decision rule. Claim no history. | Peer reciprocity, and a JD line on owning GTM for two new product lines. The answer proposes a split and does not assert that the ownership already exists. |

### C. Skeptic (weight 3). C1 is the highest-ROI prep in the pack.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've spent nine years at a consumer-tech company. What have you done that involved selling to business customers?" | JD, EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" and "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | Hold: name the business counterparts you do have, in your own words, and your part in each. Carrier negotiations are the nearest business counterparty in the material, and the material does not say what role Priya played in them. Answer slot: if you worked directly with a business customer or partner, say who and what you did. If the carrier work was the only one, say what your part was. Concede: if you have carried a quota or sales target, say what it was; if you have not, say so plainly, in your own words. Hold through two follow-ups on the model, and concede the selling point once, specifically. | This is the highest-ROI prep. The objection aims at the thinnest area in the fit snapshot (F1, F8). The premise is "nine years" and "consumer-tech," both quoted. |
| C2 | "Tell me about the most sales-like target you have set, and who was accountable for hitting it." | JD, EXP | [grounded] "set annual volume targets with cross-org consensus" (the coach's notes) | Start from the quote: you set annual volume targets with cross-org consensus. Answer slot: say who was accountable for hitting it, and whether the target carried a sales outcome. If it was a volume plan rather than a sales quota, say that plainly. Do not call it a quota. | The theme comes from the JD's land/adopt/expand/renew motion. Quota-setting is absent from the material, so the guidance does not name it. |
| C3 | "How would you test a whitespace claim across land, adopt, expand and renew before a team commits to it?" | CASE, JD | [generic] pattern; no claim about Priya | Structure it: define whitespace per stage, name the data that would show it, pick a cheap test, and state the kill criterion. Make no claim about past analysis. If you cite SQL or Tableau, name what you would query first. | A live problem from the JD's whitespace line. It tests whether the analysis method in F3 is real, without asking for a past the material does not show. |

### D. Case / Strategist (weight 3). Tilted to pricing, per Dan's profile.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Compass is an AI copilot, and a much larger platform vendor can bundle something similar. How would you price it?" | CASE, CO | [grounded] "AI copilot launch ('Compass')" and "bundling by a much larger platform vendor" (the coach's research note) | Clarify first: who buys it, whether it is sold separately, and what a bundle would anchor on. Then objective, segmentation, pricing approach (value, usage or bundle), metrics and risks. Say the bundle risk aloud and state one hypothesis early. Speakable in 90 seconds. | Dan's pricing spine makes this the native case. The threat comes from the research note, so it is a fair premise. |
| D2 | "Profitability is a priority. Which of the two new product lines would you put on a unit-economics diagnosis first, and what would you measure?" | CASE, CO | [grounded] "reaching profitability" (the coach's research note) | Clarify the two lines and their current economics before choosing. Name the metric, such as payback, margin by segment or cost to serve, and the assumption behind it. The metric list is [generic]. | A case built on a stated priority. Dan's spine tilts it toward unit economics. |
| D3 | "Enterprise expansion is a priority. Sketch the whitespace across land, adopt, expand and renew for one of the new product lines. What do you need to know first?" | CASE, JD | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights) and "enterprise expansion" (the coach's research note) | Clarify first: which product line, what the customer base looks like, and what counts as adoption. Then segment by stage, and say what the first data pull would be. Name no market figure. | Covers the JD's whitespace line in the company's stated priority. The clarify-first move is the scored behavior. |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has sold B2B for ten years?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | Pause and restate the question. Then anchor in what you stated: the partner-level model and the carrier negotiations, quoted. Hold through two follow-ups. Concede the specific gap in one sentence, in your own words, and say how you would close it. | The sixty-second challenge is the Pressure persona's signature. The hold is only what the quote supports, so the guidance claims no sales experience. |
| E2 | "That result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Hold: you proposed the change, which the quote says. Concede attribution: name the share, not the whole. Do not fold on the proposing claim. | Hold-then-concede on F7, the claim most likely to be pushed. |

### F. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | A 90-second arc: consulting, then product strategy and ops, then the partner-level model, then why this role. Use only those beats, and add no new claims. | The opener is scored for economy. The arc follows the quote's own sequence. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (the coach's notes) | Name the tools you use daily and what for. Answer slot: if you have built or tested anything AI-based, name it and what you did. If not, say what you use and what you would want to learn for Compass. | AI is a JD plus, asked casually. F6 is medium confidence, and it covers use, not building. |

### G. Values / Behavioral (weight 2). No values round is detected, so no cheat sheet is built.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you got people across orgs to agree on a number. What happened?" | VAL, JD | [grounded] "set annual volume targets with cross-org consensus" (the coach's notes) | Story map from the quote: you set annual volume targets, and the consensus was cross-org. Beats: the number, the orgs, and how agreement was reached, in your own words. Answer slot: whether the consensus held, and what you would change. If you did not see it through, say so. | Cross-functional influence is a JD line (F5). VAL because a behavioral story is what a peer will ask for. |
| G2 | "When did a customer outcome beat an internal metric for you?" | VAL | [generic] persona stem; no claim about Priya | Selection scaffold: pick a time a customer result changed a plan an internal number had set. If none comes to mind, say so, then give the nearest thing your material carries and what you would do. Do not invent the ending. | None of Priya's quoted sentences carries this story, so the scaffold ends in its honest branch. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | B4, D3 |
| identify whitespace across land/adopt/expand/renew | D3, C3, C2 |
| run independent analysis in SQL and Tableau | A4 |
| partner-motion design experience required | B3, A3, C1 |
| strong cross-functional influence | B1, B2, G1 |
| AI experience a plus | F2, D1 |
| Headline metric (CV, not a JD line) | A1, A2, A5, E2 |
| Sales motion and quota (role-family pattern, not quoted) | C2, C1 |

---

## 7. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came up through pricing and monetization, with a stint at an early-stage startup. Which of that carries most into emerging products?" | Ties to Dan's own path, which turns the profile into a peer conversation. It also shows you researched Dan, not just the company. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Peer reciprocity. Peers weight this question heavily. |
| R3 | "How is the team thinking about defending against bundling by the larger platform vendor: on price, on integration, or on the data layer?" | Uses the threat from the research note and asks for the strategy, not a pitch. |
| R4 | "Compass is the AI copilot launch. Where does it sit in the sequence against enterprise expansion?" | Tests the stated priorities and shows which one the launch competes with. |
| R5 | "Which of the two new product lines is furthest from its first enterprise customer, and what would you need from me to move it?" | The most concrete peer-collaboration ask. It gives Dan a chance to name a seam. |

---

## 8. Prohibited claims

Not coached in any cell of this pack. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "Owned GTM strategy for product lines" | Inflated form of F1. The JD says "own GTM strategy," and the quote says "product strategy & ops." | The F1 quote at its own scope. The limit is the pack's observation: the material shows product strategy and ops, not GTM. The slot stays inside that. |
| "Set sales quotas" or "ran sales-ops" | Inflated form of F5 and F8 ("set annual volume targets"). | G1 and C2 at the quote's scope. The limit is the pack's observation, and the pack does not give a first-person negative. |
| "Designed partner motions" | Inflated form of F4. The quote is a model, not a motion. | The F4 quote. B3's slot. |
| "Ran independent SQL and Tableau analysis" | Inflated form of F3 ("skilled in"). | A4's slot only. |
| "Drove the $400M ARR" | Inflated form of F7 ("credited with"). | A1, A5 and E2 at the quote's scope. |
| "I have never sold to a business customer" or "I have never set a quota" | A negative the candidate has not stated. The coach's note says only "No classic sales-ops or quota-setting experience." | No first-person negative in any cell. C1 and C2 carry the slots. The upgrade menu asks for Priya's own confirmation. |

---

## 9. Prep scope

Prep time was not stated, so no triage schedule is given. The full bank is the set to rehearse. The top two, in order, are **C1** (the business-selling objection) and **A1** (the $400M attribution).

---

## 10. Sources

**Provided documents, all used:**
- The coach's notes on Priya: the quoted sentences in F1 to F8 and in the banks.
- The JD highlights: six lines, quoted in the requirement column.
- Dan's profile, as given: career spine, self-description, one startup chapter.
- The coach's research note: three stated priorities and the main competitive threat.

**Searches and fetches:** none run this turn.

**Not built, and why:** prep triage (no prep time), values cheat sheet (no values round detected), graded deliverables (none declared), delivery coaching (no working-style assessment).

**Research tier: L0, provided documents only.** Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Values cheat sheet. Not built, since no values round is detected. A values page would sharpen G2. |
| 2. Northwind interview process, GTM strategy role family | unavailable | Loop structure. The persona weights assume the single peer round as stated. |
| 3. Northwind strategy and recent news | skipped | The research note already supplies the three priorities and the threat. A search would refresh recent moves only. |
| 4. Dan Kovac and Northwind | unavailable | Interviewer public footprint. The read uses only the profile given. |
| 5. Representative Senior GTM Strategy Lead JD | skipped | The JD highlights fix the fit snapshot and the JD-tagged questions. |

---

## 11. Upgrade menu

- **Full JD text** → the six JD-highlight rows become full-text quotes, and any requirements the highlights left out get questions.
- **Priya's CV** → inspectable artifacts: an analysis she owns in SQL or Tableau (F3 moves toward medium), the attribution sheet behind the $400M (F7 becomes inspectable), and the partner model itself (F4).
- **Priya's own words on any quota, sales or partner-program work** → F8 becomes a stated absence (capability, with a plain acknowledgment), and C1 and C2 get a stated branch.
- **Recruiter's note on focus areas, deliverables or process** → coverage weights, and a build section for any pre-declared deliverable.
- **Research at L1** (up to 6 searches and 2 fetches: Northwind values, recent strategy, Dan's public footprint) → a values cheat sheet if a values round is confirmed, a fresher grounding brief, and interviewer-specific reverse questions.
- **Research at L2** (deep research, offered once: a further 6 searches and 2 fetches on loop reports and Dan's talks or writing) → a sharper case bank and loop-aware persona weights. Say which tier you want.
- **A tuesday-dossier.md** → would replace the locally built prohibited list with a verified one and grade each row against its evidence.
