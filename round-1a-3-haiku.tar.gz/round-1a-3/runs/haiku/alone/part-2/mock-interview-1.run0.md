The search tool was refused permission, so the pack runs without live research. I'll write it up from your inputs and record the refused calls in Sources.
Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-2-rooms-case-1-denied-aa8984ee/ae079ecf-7665-43de-94e0-2417d6befbe4/scratchpad/northwind_senior-gtm-strategy-lead_interview_pack.md`. It's built on your JD highlights, your summary of Priya, and your research note. Live search was refused in this session, so company values, the interview process, Compass and Dan's public footprint are not researched. The file ends at the upgrade menu.

# Northwind Data: Senior GTM Strategy Lead, Emerging Products. Mock-interview pack for Priya

**Round:** single 60-minute conversation. **Interviewer:** Dan Kovac, Director of Sales Strategy. **Relationship:** peer, same VP.

## How to use + type key

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **VAL**: behavioral / values alignment. **EXP**: work-experience deep-dive. **JD**: role and requirement fit. **CO**: company and strategy knowledge. **CASE**: live problem.
- Guidance is scaffolding, not a script. Rehearse what you actually did, in your own words.
- Every candidate fact below is quoted from your summary, not from Priya's own sentences. Priya should restate each in her own words so the pack can re-quote them.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | The material says a revenue model, not a GTM strategy: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if she set any go-to-market decision for a product line, say which and how she decided; if none was hers, say so and stay with the model. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | none given | none | [grounded] | discovery | Nothing in the material shows this. Answer slot: if she has found an unserved segment or motion before, name it and how she found it; if not, say so and describe how she would look for whitespace first. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (coach's notes) | low | [inferred] | presentation | "I'm skilled in SQL and Tableau." A self-description with no artifact, so expect a request for one. Answer slot: name one analysis she ran herself, the question, the data and the output; if she has not run one end to end, say which part she did. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | Adjacent, not the same work: "I built a partner-level revenue model used in carrier negotiations." Limit: nothing shows partner terms, incentives or a motion designed and run. Answer slot: if she set partner terms or program rules, say which; if not, say what she would do first. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (coach's notes) | medium | [grounded] | presentation | "I set annual volume targets with cross-org consensus." The consensus is the outcome; the steps are not in the material, so do not add them. |
| F6 | "AI experience a plus" (JD highlights; a plus, not a requirement) | "uses AI tools daily" (coach's notes) | low | [inferred] | transferability | "I use AI tools daily." Use is not building; nothing shows AI products or model work. |
| F7 | Sales-side motion: quota-setting and sales-ops (role-family, not a JD line) | "No classic sales-ops or quota-setting experience" (coach's notes) | none | [grounded] | discovery | This is your note, not Priya's words, so it cannot become a first-person negative. Priya should state in her own words what she has and has not done here. |
| F8 | Headline revenue figure (not a JD line) | "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | medium | [grounded] | none | "I proposed a store-surface change; it was credited with a ~$400M ARR uplift." No inspected count is behind the figure, so expect a probe. Verify it before the interview. |
| F9 | Career arc (not a JD line) | "2 years strategy consulting at a top firm" and "9 at a large consumer-tech company in product strategy & ops" (coach's notes) | medium | [grounded] | none | "Two years in strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops." |

Flags: "carrier negotiations" may be confidential, so check what can be said before naming any carrier or deal. The ~$400M figure needs a source Priya can point to.

## Grounding brief

From your research note only; not verified; no search ran.

- Stated priorities: "enterprise expansion", an AI copilot launch ("Compass"), and reaching profitability.
- Main competitive threat: "bundling by a much larger platform vendor."
- Current segmentation, headline numbers and recent moves are not in the material. Check anything Priya says about them against current sources.

## Reading the interviewer

Public footprint was not researched. This is from your summary only.

- **Career pattern:** pricing and monetization, with one early-stage startup chapter.
- **Self-described style:** "relentlessly data-driven."
- **Implications:**
  1. Expect every number to be taken apart: how it was counted, its assumptions, what part was hers.
  2. Revenue-model and pricing vocabulary will land. The partner-level revenue model is the closest common ground (F1).
  3. Expect "how fast does big-company work move?" given the startup chapter. *(Hypothesis from career pattern.)*
- **Mirror opportunity:** revenue modeling and monetization (F1). No shared career jump is offered, since Priya has no startup chapter in the material.

## Persona table

Peer priors (Peer Evaluator plus Data-Driven Prober) are adjusted up for the Prober by the data-driven self-description, and the pricing spine tilts case questions toward pricing and unit economics.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Follows every number two levels deep | Top weight: data-driven peer, and a $400M headline (F8) | Say how the figure was counted, name the weakest assumption, say plainly what you don't know |
| Peer Evaluator | Seams between teams, credit, disagreement | High: peer on the same VP; the influence requirement | Reciprocity; seam principles, not claimed seams |
| Case / Strategist | Live GTM and whitespace problems | Medium: GTM role with land/adopt/expand/renew, tilted to pricing | Clarify, structure, metrics |
| Skeptic | Probes partner-motion and quota gaps | Medium: partner-motion is required and no quote reaches it (F4, F7) | Rehearse the top objection; hold, then concede exactly |
| Pressure / Stress | Interrupts, time-boxes | Low-medium: a challenged headline figure invites pressure | Pause, restate, hold through two follow-ups |
| Conversational / Rapport | Casual openers that are still scored | Low-medium: AI is a plus asked casually | Pre-script a 90-second arc |
| Values / Behavioral | Cross-functional influence stories | Low: no values round detected; the influence requirement keeps it in | STAR-shaped; "we" for context, "I" for contribution |

## Question banks

Weights: Prober 5, Peer 4, Case 3, Skeptic 3, Pressure 2, Conversational 2, Values 2. Total 21.

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that $400M was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say the figure as credited, then the change she proposed. The count: who did it, the window, the control. Answer slot: if she knows the method, say so; if not, say that plainly and name who would know. | F8 is the headline; the likeliest probe is the counting method. |
| A2 | "Which assumption behind that uplift would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Name the assumption she would defend least, before he does. Answer slot: if she can name one, say it; if not, say she has not tested it and what she would test first. | The weakest-assumption move turns a gotcha into a credibility point. |
| A3 | "Walk me through an analysis you ran yourself in SQL or Tableau, end to end." | JD | [grounded] "skilled in SQL/Tableau" | Answer slot: name one analysis she ran herself: question, data, output, what changed. If she has not run one end to end, say which part she did. | The JD asks for independent analysis (F3); an artifact is what he will want. |
| A4 | "What did the partner-level revenue model assume about partner behavior?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Name the main assumption if she can. Answer slot: if she set the assumptions, say which; if others did, say so. | F1 and F4 share this quote; its assumptions are not in the material. |
| A5 | "How did you set the annual volume targets, and what were they measured against?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Beats: the targets, the consensus across orgs. Answer slot: which numbers were hers and which were agreed; if the targets came from above, say so. | Prober follow-up on F5. |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam with sales, and what happens when we disagree?" | VAL | [grounded] "set annual volume targets with cross-org consensus" | Name seam principles, not claimed seams. Answer slot: if she has disagreed with a peer org, say how it resolved; if not, give the principle she would apply. | Influence is a stated requirement (F5). |
| B2 | "What would you need from my team to make a partner motion work?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Reciprocity: what the model gives his team, then what she would need. Claim no partner motion she has not designed. | F4's gap, asked from a peer seat. |
| B3 | "How do you handle credit when work spans teams?" | VAL | [grounded] "credited with a ~$400M ARR uplift"; [grounded] "set annual volume targets with cross-org consensus" | Say how credit was handled. Answer slot: if credit was contested, say how; if not, say so. | Peer credit probe on F8 and F5. |
| B4 | "How would you split whitespace work with my pricing team?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Frame the model as monetization input to his pricing work. Answer slot: if pricing and her work overlapped, say how. | The revenue model is the shared ground (F1). |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two new product lines launch next year. What do you need to know before you set the GTM?" | CASE | [generic] | Clarify the objective, then segment, approach, metrics. Land, adopt, expand, renew give the spine. | The JD's ownership requirement as a live problem. |
| C2 | "Enterprise expansion is a stated priority. Where would you look for whitespace across land, adopt, expand and renew?" | CO | [grounded] "enterprise expansion" (your research note) | Diagnose before prescribing: which motion leaks, and where the data would show it. | The whitespace requirement (F2) on the company's priority. Generic, since no search ran. |
| C3 | "A much larger platform vendor bundles a competing product. How do you protect the emerging lines?" | CO | [grounded] "bundling by a much larger platform vendor" (your research note) | Separate bundled from differentiated. Test which customers the bundle reaches first. Name what a partner motion does against bundling, as an approach, not a result. | The stated main threat. Generic, since no search ran. |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Partner-motion design is required here. Where has your work designed one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | **Hold:** state the model at its scope once. **Second follow-up, "who designed the terms?":** answer slot, if she set any partner terms, say which and how she decided; if not, say so. **Third, "could you design one?":** concede the gap in her own words, then name the first 90 days. Never describe a motion she did not design. | **Highest-ROI prep.** The JD requires partner-motion design and no quote reaches it. |
| D2 | "Quota-setting isn't something I see in your background. How would you approach it?" | JD | [grounded] "set annual volume targets with cross-org consensus" | The closest sentence is the volume-target one. Do not claim quota-setting. Answer slot: if targets she set became quotas or compensation, say so; if not, say how she would learn the link. | F7: a gap your note records, which Priya must confirm in her own words. |
| D3 | "Why this, and why now?" | VAL | [generic] | Give your own reason in one sentence, then one concrete reason about this role. No claim about the company's plans. | Motivation consistency is the skeptic's standard probe. |

### E. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run a sales org?" | JD | [grounded] "set annual volume targets with cross-org consensus" | **Hold:** her strongest sentence is the consensus-based target-setting. **Concede** the gap in her own words, then name the first 90 days. | F7 under time pressure; hold-then-concede. |
| E2 | "That $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | **Hold** at the sentence's scope: she proposed the change, and the figure was credited to it. **Concede** uncertainty about her share. Answer slot: if she can say what share was hers, say it; if not, say the attribution was not hers to settle. | F8 challenged. |

### F. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | VAL | [grounded] "2 years strategy consulting at a top firm"; [grounded] "9 at a large consumer-tech company in product strategy & ops" | Pre-scripted 90-second arc: consulting, product strategy and ops, the revenue model and targets. Beats are only those sentences. | F9. Casual openers are still scored. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Name one task she uses AI tools for. Answer slot: if she has built anything with models, say what; if not, say use only. | The AI plus, asked casually (F6). |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "set annual volume targets with cross-org consensus" | Selection scaffold: pick a time she disagreed with leadership and the relationship held. If none comes to mind, say so, then give the nearest thing her material carries: the consensus-based target-setting. | Influence (F5). No values round detected. |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer outcome beat an internal number. If there is none, say so plainly. | No quote carries a customer story. |

## Requirement coverage

| JD requirement (JD highlights) | Questions |
|---|---|
| Own GTM strategy for two new product lines | C1, A4 |
| Identify whitespace across land/adopt/expand/renew | C2, D2 |
| Run independent analysis in SQL and Tableau | A3 |
| Partner-motion design experience required | D1, B2 |
| Strong cross-functional influence | B1, B3, G1, A5 |
| AI experience a plus | F2 |
| Research note: enterprise expansion | C2 |
| Research note: Compass AI copilot | none, and why: no sourced Compass facts exist in this run |
| Research note: reaching profitability | none, and why: no sourced profitability facts exist in this run |
| Research note: bundling threat | C3 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the GTM for a product line | Inflated form of F1 | "built a partner-level revenue model used in carrier negotiations." The limit is the pack's observation: a model, not a GTM. |
| Designed or ran a partner motion | Inflated form of F4 | The model at its own scope. |
| Drove the $400M | Inflated form of F8 | "proposed a store-surface change credited with a ~$400M ARR uplift." "Credited" is attribution, not ownership. |
| Set quotas or compensation targets | Inflated form of F5 | "set annual volume targets with cross-org consensus." |
| Led carrier negotiations | Inflated form of F1 | The model was used in negotiations; her role in them is not in the material. |
| Built AI products | Inflated form of F6 | "uses AI tools daily." |

## Target accounting

Research tier: L1 — searches 4 of 6, fetches 0 of 2; user links read 0. All four searches were refused, so none returned a result.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data company values | unavailable | Values cheat sheet. Not built; no values-style round was detected in any case. |
| 2. Northwind Data interview process, sales strategy | unavailable | Loop structure; persona weights follow the stated round. |
| 3. Northwind Data strategy / recent news (Compass) | unavailable | Grounding brief; the C2 and C3 framing rests on your note. |
| 4. Dan Kovac, Northwind | unavailable | Interviewer read: public footprint. The read here is from your summary only. |
| 5. Representative JD | skipped | Your JD highlights fix the fit snapshot. |

## Sources

- Provided: your message (JD highlights, Priya's background summary, the research note, the interviewer summary).
- Searches sent, all refused: "Northwind Data company values"; "Northwind Data interview process sales strategy"; "Northwind Data Compass AI copilot launch"; "Dan Kovac Director of Sales Strategy Northwind".
- No dossier was present.

## Upgrade menu

- Priya's CV, or her own restatement of each fit-snapshot sentence → rows F1 to F9 move from your notes to her record.
- Full JD text → requirement quotes become the posting's own lines.
- The source for the ~$400M figure → A1, A2 and E2 can state the count and her share precisely.
- Interviewer's public footprint (talks, writing, profile) → an evidence-based interviewer read and a tailored reverse question.
- Live search permission → targets 1 to 4 run, and C2, C3 and the grounding brief get current facts.
- Deep research (L2) → strategy brief, interviewer talks, loop reports: up to 6 more searches and 2 fetches, if you want it.

Reverse questions (not yet in the file; include these in your prep):
- "What did your early-stage chapter teach you about pricing that the larger-company version hasn't?" *Why it lands:* ties to his own path and turns the interview toward a peer conversation.
- "What could a new person do in their first month that would genuinely help your team?" *Why it lands:* the peer reciprocity question.
- "How is Compass being measured against the profitability target?" *Why it lands:* shows you read the stated priorities.
- "When partner terms are set, who owns the trade-off between volume and price?" *Why it lands:* probes the seam on the partner motion.
- "What does a good 90 days look like for the emerging lines?" *Why it lands:* grounds the role in its first milestones.

Two offers, neither pushed:
- Want a live drill? I can play the Skeptic on D1, the highest-ROI prep, with follow-ups that react to what Priya says.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead_interview_pack.md -----
# Northwind Data: Senior GTM Strategy Lead, Emerging Products. Mock-interview pack for Priya

**Round:** single 60-minute conversation. **Interviewer:** Dan Kovac, Director of Sales Strategy. **Relationship:** peer, same VP.
**Built on:** your JD highlights, your summary of Priya's background, your research note. No CV, full JD or interviewer footprint was supplied, and live search was refused in this session (see Sources).

## How to use + type key

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **VAL**: behavioral / values alignment. **EXP**: work-experience deep-dive. **JD**: role and requirement fit. **CO**: company and strategy knowledge. **CASE**: live problem.
- Guidance is scaffolding, not a script. Rehearse what you actually did, in your own words.
- Every candidate fact below is a sentence from your summary, quoted exactly. These are your summaries, not Priya's own sentences. Before rehearsing, Priya should restate each in her own words and send them back; the pack re-quotes those.

## Fit snapshot

Requirements are your JD highlights, quoted as you wrote them. Evidence is quoted from your summary of Priya (source: coach's notes).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights, your message) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | The material says a revenue model, not a GTM strategy, and the bridge stays at that scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if she set any go-to-market decision for a product line, say which and how she decided; if none was hers, say so and stay with the model. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights, your message) | none given | none | [grounded] | discovery | Nothing in the material shows this. Answer slot: if she has found an unserved segment or motion in a past role, name it and how she found it, in her own words; if not, say so and describe how she would look for whitespace first. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights, your message) | "skilled in SQL/Tableau" (coach's notes) | low | [inferred] | presentation | The quote reaches the requirement in other terms: "I'm skilled in SQL and Tableau." It is a self-description with no artifact behind it, so expect a request for one. Answer slot: name one analysis she ran herself, the question, the data and the output; if she has not run one end to end, say which part she did. |
| F4 | "partner-motion design experience required" (JD highlights, your message) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | Adjacent to partner design, not the same work: "I built a partner-level revenue model used in carrier negotiations." Limit: nothing in the material shows partner terms, incentives or a motion designed and run. Answer slot: if she set partner terms, incentives or program rules, say which and how she decided; if not, say so and describe what she would do first. |
| F5 | "strong cross-functional influence" (JD highlights, your message) | "set annual volume targets with cross-org consensus" (coach's notes) | medium | [grounded] | presentation | The quote reaches influence in other terms: "I set annual volume targets with cross-org consensus." The consensus is the outcome; the steps that produced it are not in the material, so do not add them. |
| F6 | "AI experience a plus" (JD highlights, your message; a plus, not a requirement) | "uses AI tools daily" (coach's notes) | low | [inferred] | transferability | Use is not building: "I use AI tools daily." Limit: nothing in the material shows AI products or model work. |
| F7 | Sales-side motion: quota-setting and sales-ops work (role-family, not a JD line) | "No classic sales-ops or quota-setting experience" (coach's notes) | none | [grounded] | discovery | This is your note, not Priya's words, so it cannot be turned into a first-person negative. Answer slot: Priya should state in her own words what she has and has not done here; the pack will then re-quote it. |
| F8 | Headline revenue figure (not a JD line; a figure on her background) | "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | medium | [grounded] | none | No gap in the quote, but the figure has no inspected count behind it, so expect a probe. Verify the number against the source before the interview. Bridge: "I proposed a store-surface change; it was credited with a ~$400M ARR uplift." |
| F9 | Career arc (not a JD line; a background fact) | "2 years strategy consulting at a top firm" and "9 at a large consumer-tech company in product strategy & ops" (coach's notes) | medium | [grounded] | none | No gap. Bridge: "Two years in strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops." |

Flags: "carrier negotiations" may be confidential; check what can be said before naming any carrier or deal. "~$400M" needs a source Priya can point to.

## Grounding brief

From your research note only. Not verified, and no search ran.

- Stated priorities: "enterprise expansion", an AI copilot launch ("Compass"), and reaching profitability. [grounded]
- Main competitive threat: "bundling by a much larger platform vendor." [grounded]
- Current segmentation language, headline numbers and recent moves are not in the material. Anything Priya says about them should be checked against current sources before the interview. [generic]

## Reading the interviewer

Public footprint was not researched. What follows is from your summary alone.

- **Career pattern:** pricing and monetization, with one early-stage startup chapter. [grounded, your summary]
- **Self-described style:** "relentlessly data-driven." [grounded, your summary]
- **Implications:**
  1. Expect every number to be taken apart: how it was counted, the assumptions behind it, what part was hers.
  2. Revenue-model and pricing vocabulary will land. The partner-level revenue model is the closest common ground (F1).
  3. Expect "how fast does big-company work move?" to come up, given the startup chapter. [inferred from career pattern]
- **Mirror opportunity:** shared domain of revenue modeling and monetization (F1). No shared career jump is offered: Priya has no startup chapter in the material.

## Persona table

Peer relationship priors (Peer Evaluator plus Data-Driven Prober) are adjusted by the self-described data-driven style, which raises the Prober, and by the pricing spine, which tilts case questions toward pricing and unit economics.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Follows every number two levels deep | Top weight: peer with data-driven self-description, and a $400M headline (F8) | Say how the figure was counted, name the weakest assumption, say plainly what you don't know |
| Peer Evaluator | Seams between teams, credit, disagreement | High: peer on the same VP, and the role's cross-functional influence requirement | Reciprocity: what you bring to his team; seam principles, not claimed seams |
| Case / Strategist | Live GTM and whitespace problems | Medium: a GTM role with land/adopt/expand/renew, tilted to pricing | Clarify, then structure, then metrics; say the framework before using it |
| Skeptic | Probes the partner-motion and quota gaps | Medium: partner-motion is required and no quote reaches it (F4, F7) | Rehearse the highest-ROI objection until it is plain; hold, then concede exactly |
| Pressure / Stress | Interrupts, time-boxes | Low-medium: a peer round, but a challenged headline figure invites pressure | Pause, restate, hold through two follow-ups before conceding |
| Conversational / Rapport | Casual openers that are still scored | Low-medium: a peer opener, and AI is a plus asked casually | Pre-script a 90-second arc; treat casual AI questions as scored |
| Values / Behavioral | Cross-functional influence stories | Low: no values-style round was detected; the influence requirement keeps it in | STAR-shaped; "we" for context, "I" for contribution |

## Question banks

Weights: Prober 5, Peer Evaluator 4, Case 3, Skeptic 3, Pressure 2, Conversational 2, Values 2. Total 21.

Quotes in the Provenance column are Priya's sentences from the fit snapshot, verbatim.

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that $400M was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say the figure as credited, then the change she proposed. The count: who did it, the window, the control. Answer slot: if she knows how it was counted, say so; if not, say that plainly and name who would know. | F8 is the headline figure, and the likeliest probe is the counting method. |
| A2 | "Which assumption behind that uplift would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Name the assumption she would defend least, before he does. Answer slot: if she can name one, say it in her words; if not, say she has not tested it and what she would test first. | The weakest-assumption move converts a gotcha into a credibility point. F8 is the only quote. |
| A3 | "Walk me through an analysis you ran yourself in SQL or Tableau, end to end." | JD | [grounded] "skilled in SQL/Tableau" | Answer slot: name one analysis she ran herself: the question, the data, the output, and what changed. If she has not run one end to end, say which part she did and what she would do. | The JD asks for independent analysis (F3). "Skilled" is self-description, so an artifact is what he will want. |
| A4 | "What did the partner-level revenue model assume about partner behavior?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Name the main assumption if she can. Answer slot: if she set the model's assumptions, say which; if others set them, say so. | F1 and F4 share this quote, and the model's assumptions are not in the material. |
| A5 | "How did you set the annual volume targets, and what were they measured against?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Beats: the targets, the consensus across orgs. Answer slot: which numbers were hers to set and which were agreed; if the targets came from above, say so. | Prober follow-up on F5. Consensus is the outcome; the process is an answer slot. |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam with sales, and what happens when we disagree?" | VAL | [grounded] "set annual volume targets with cross-org consensus" | Name seam principles, not claimed seams. Disagreement story only if she has one; answer slot: if she has disagreed with a peer org, say how it resolved; if not, give the principle she would apply. | Cross-functional influence is a stated JD requirement (F5); this is a collegial probe. |
| B2 | "What would you need from my team to make a partner motion work?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Reciprocity: what the model gives his team, then what she would need. Do not claim a partner motion she has not designed. | F4's gap, asked from a peer seat. |
| B3 | "How do you handle credit when work spans teams?" | VAL | [grounded] "credited with a ~$400M ARR uplift"; [grounded] "set annual volume targets with cross-org consensus" | Say how the credit was handled, in the company's terms. Answer slot: if credit was contested, say how; if not, say so. | Peer credit probe on F8 and F5. |
| B4 | "How would you split whitespace work with my pricing team?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Frame the model as monetization input to his pricing work. Answer slot: if pricing and her work overlapped, say how. | Dan's pricing spine makes the revenue model the shared ground (F1). |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two new product lines launch next year. What do you need to know before you set the GTM?" | CASE | [generic] | Clarify the objective, then segment, then approach, then metrics. Land, adopt, expand, renew give the spine. | The JD's own ownership requirement, asked as a live problem. The question presupposes nothing about Priya. |
| C2 | "Enterprise expansion is a stated priority. Where would you look for whitespace across land, adopt, expand and renew?" | CO | [grounded] "enterprise expansion" (your research note) | Diagnose before prescribing: which motion is leaking, and where the data would show it. | The whitespace requirement (F2) on the company's priority. Generic, because no search ran. |
| C3 | "A much larger platform vendor bundles a competing product. How do you protect the emerging lines?" | CO | [grounded] "bundling by a much larger platform vendor" (your research note) | Separate bundled from differentiated. Test which customers the bundle reaches first. Name what a partner motion does against bundling, as an approach, not a result. | The stated main threat. Generic, because no search ran. |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Partner-motion design is required here. Where has your work designed one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold: state the model at its scope, once: "I built a partner-level revenue model used in carrier negotiations." Second follow-up, "who designed the terms?": answer slot, if she set any partner terms, say which and how she decided; if not, say so. Third, "would you be able to design one?": concede the gap in her own words, then name the first 90 days. Never describe a motion she did not design. | **The highest-ROI prep.** The JD requires partner-motion design and no quote reaches it, so this will come in some form. |
| D2 | "Quota-setting isn't something I see in your background. How would you approach it?" | JD | [grounded] "set annual volume targets with cross-org consensus" | The closest sentence is the volume-target one. Do not claim quota-setting. Answer slot: if targets she set became quotas or compensation, say so; if not, say so and say how she would learn the link. | F7: a sales-side gap your note records, which Priya must confirm in her own words. |
| D3 | "Why this, and why now?" | VAL | [generic] | Give your own reason in one sentence, then one concrete reason about this role. No claim about the company's plans. | Motivation consistency is the skeptic's standard probe. |

### E. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run a sales org?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Hold: her strongest sentence is the consensus-based target-setting. Concede the gap in her own words, then name what she would do in the first 90 days. | F7 under time pressure. Hold-then-concede. |
| E2 | "That $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold at the scope of the sentence: she proposed the change, and the figure was credited to it. Concede uncertainty about her share specifically: answer slot, if she can say what share was hers, say it; if not, say the attribution was not hers to settle. | F8 challenged. Holding the sentence's own scope is the honest hold. |

### F. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | VAL | [grounded] "2 years strategy consulting at a top firm"; [grounded] "9 at a large consumer-tech company in product strategy & ops" | Pre-scripted 90-second arc: consulting, then product strategy and ops, then the revenue model and targets. Beats are only those sentences. | F9. Casual openers are still scored. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Name one task she uses AI tools for. Answer slot: if she has built anything with models, say what; if not, say use only. | The JD's AI plus, asked casually (F6). |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "set annual volume targets with cross-org consensus" | Selection scaffold: pick a time she disagreed with leadership and the relationship held. If none comes to mind, say so, then give the nearest thing her material carries: the consensus-based target-setting. | Influence stories (F5). No values round is detected, so this is a persona stem. |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer outcome beat an internal number. If there is none, say so plainly. | Generic: no quote carries a customer story. |

## Requirement coverage

| JD requirement (JD highlights) | Questions |
|---|---|
| Own GTM strategy for two new product lines | C1, A4 |
| Identify whitespace across land/adopt/expand/renew | C2, D2 |
| Run independent analysis in SQL and Tableau | A3 |
| Partner-motion design experience required | D1, B2 |
| Strong cross-functional influence | B1, B3, G1, A5 |
| AI experience a plus | F2 |
| Research note: enterprise expansion | C2 |
| Research note: Compass AI copilot | none, and why: no sourced Compass facts exist in this run; see upgrade menu |
| Research note: reaching profitability | none, and why: no sourced profitability facts exist in this run |
| Research note: bundling threat | C3 |

## Prohibited claims

Built locally from the fit snapshot. Nothing in the banks, reverse questions or drill feedback may assert these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the GTM for a product line | Inflated form of F1 | "built a partner-level revenue model used in carrier negotiations." The limit is the pack's observation: the material says a model, not a GTM. |
| Designed or ran a partner motion | Inflated form of F4 | The model at its own scope. The gap is the pack's observation, not a first-person negative. |
| Drove the $400M | Inflated form of F8 | "proposed a store-surface change credited with a ~$400M ARR uplift." "Credited" is attribution, not ownership. |
| Set quotas or compensation targets | Inflated form of F5 | "set annual volume targets with cross-org consensus." |
| Led carrier negotiations | Inflated form of F1 | The model was used in negotiations. Her role in the negotiations is not in the material. |
| Built AI products | Inflated form of F6 | "uses AI tools daily." |

## Target accounting

Research tier: L1 — searches 4 of 6, fetches 0 of 2; user links read 0. All four searches were refused, so no result was returned.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data company values | unavailable | Values cheat sheet: not built. The values-style round was not detected, so the cheat sheet is dropped in any case. |
| 2. Northwind Data interview process, sales strategy | unavailable | Loop structure. Persona weights follow the stated round. |
| 3. Northwind Data strategy / recent news (Compass) | unavailable | Grounding brief current status, and the C2 and C3 company-specific framing, which rests on your note. |
| 4. Dan Kovac, Northwind | unavailable | Interviewer read: public footprint. The read here is from your summary only. |
| 5. Representative JD | skipped | The JD highlights you supplied fix the fit snapshot. |

## Sources

- Provided: your message (JD highlights, Priya's background summary, the research note, the interviewer summary).
- Searches sent, all refused (permission not granted):
  - "Northwind Data company values": refused
  - "Northwind Data interview process sales strategy": refused
  - "Northwind Data Compass AI copilot launch": refused
  - "Dan Kovac Director of Sales Strategy Northwind": refused
- No dossier was present.

## Upgrade menu

- Priya's CV, or her own restatement of each sentence in the fit snapshot → quotes become her words, and rows F1 to F9 move from coach's notes to grounded in her record.
- Full JD text → requirement quotes become the posting's own lines; any missing requirement gets a question.
- The source for the ~$400M figure → A1, A2 and E2 can state the count and her share precisely.
- Interviewer's public footprint (talks, writing, profile) → an interviewer read from evidence, and a tailored reverse question.
- Live search permission → targets 1 to 4 run and the grounding brief and C2 and C3 get current facts.
- Deep research (L2) → strategy brief, interviewer talks, loop reports: up to 6 further searches and 2 fetches, if you want it run.
- Recruiter guidance on the loop's format → confirms session persona weights.

