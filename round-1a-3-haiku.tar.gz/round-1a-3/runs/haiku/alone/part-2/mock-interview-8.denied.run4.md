Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-2-rooms-case-8-denied-bfa7b2b1/66275331-3f8e-473c-9e8f-42cc18751171/scratchpad/ashgrove_member_experience_lead_interview_pack.md and sent to you as a file. It covers 18 questions across the three rounds, a fit map against the JD, the values cheat sheet, the 20-minute case structure, the strategy questions, and six reverse questions. I ran no web searches, because the JD, values, recruiter email, strategy summary and your background already cover what a search would check. The interviewer names aren't known, so the personas are set by round.

The highest-return prep is B2. Your complaints work is one branch's log, and the JD asks for end-to-end ownership across branches and the contact centre. Expect that objection in the 45-minute round and again on the panel.

Say the word and I'll play the Skeptic on B2.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member_experience_lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview pack

**Role:** Member Experience Lead, Ashgrove Credit Union (member-owned, about 900 staff)
**Interviewers:** recruiter (name not given); Head of Member Services, your future manager (name not given); panel of two branch managers (names not given)
**Dates:** 29 November 2026. Round 1, 30 min with the recruiter. Round 2, 45 min with the Head of Member Services, mostly behavioural. Round 3, 60 min with a panel of two branch managers, including a 20-minute complaint-escalation case; the panel scores the four values.

## 1. How to use this pack

Personas describe how a question arrives. Types describe what is being scored:

- **VAL**: values and behaviour, scored against the published values
- **EXP**: your own experience, checked for what you actually did
- **JD**: a requirement from the job description
- **CO**: company and strategy knowledge
- **CASE**: a live problem from the role

Words in quotation marks are yours, from your message or from the documents you gave me. "Answer slot" lines are instructions for the interview: answer whichever branch is true for you. This guidance is scaffolding, not a script.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Your material describes one branch's formal complaints log, not the process across branches and the contact centre. Say it at that scope: "I handled the branch's formal complaints log." Answer slot: if any step beyond that log was yours to set, say which and how you decided; if none was, say so and say how you would learn the rest. |
| F2 | "report monthly on complaint volumes" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Your sentence already reaches monthly complaints reporting. Say it in its own words: "I built the monthly complaints spreadsheet our regional manager uses." Add no count, measure or audience beyond it. |
| F3 | "and resolution times" (JD) | none given | none | [grounded] | discovery | Your material does not show whether resolution times were in the spreadsheet. Answer slot: if they were, say how they were measured, in your own words; if they were not, say so, and say what you would add first. |
| F4 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message); "6 years in retail banking, the last 3 as a branch supervisor" (your message) | low | [grounded] | transferability | Your sentence is about training tellers, not coaching supervisors. Say it at that scope: "trained new tellers on our escalation script." Answer slot: if you coached anyone above teller level on an escalation, say who and what you did; if you did not, say so and say how you would coach a supervisor on one. |
| F5 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material does not show any digital-journey work. Answer slot: if you have shaped or tested a self-service journey, say what it was and what you saw; if you have not, say so and say how you would find where complaints start in digital channels. |
| F6 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | high | [grounded] | none | The quote reaches the requirement in role-relevant terms. Say it: "6 years in retail banking, the last 3 as a branch supervisor." |
| F7 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | presentation | Your sentence reaches complaints work in other terms: formal complaints. Say it as written. Do not describe a regulator's rules as something you applied unless you did. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | You stated this absence, so the words can be yours: "I haven't presented above regional level." Then how you would build the skill, said as a plan, never as a past. |
| F9 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Your sentence says spreadsheet, not Excel. Describe the spreadsheet's job and no more. Answer slot if asked about tools: name what you used, in your own words. |
| F10 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | You stated this absence, so the words can be yours: "I haven't worked in a contact centre." Then how you would learn its work, said as a plan. |

Pack observation (analysis, not words for you): your material shows one branch's complaints work, a monthly spreadsheet, teller training, and no contact-centre, digital or senior-presenting work. Those are the places an interviewer will press.

## 3. Prohibited claims

These claims are not coached anywhere in this pack, because your material does not carry them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F1 | F1's sentence at its own scope. The limit is the pack's observation: your material says one branch's log. |
| Coached branch supervisors on escalations | Inflated form of F4 | "trained new tellers on our escalation script." Coaching a supervisor is an answer slot only. |
| Reported resolution times monthly | Inflated form of F2 and F3 | F2's sentence, and F3's answer slot on whether resolution times were in it. |
| Has presented to senior leaders | Negative you stated, F8 | "I haven't presented above regional level." No slot. |
| Has worked in a contact centre | Negative you stated, F10 | "I haven't worked in a contact centre." No slot. |

## 4. Persona weights

| Persona | Round | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Values / Behavioral | Head of Member Services; panel | High | The recruiter says the Head of Member Services round is mostly behavioural and the panel scores the four values | Map a story to each value where your words carry one; say the honest branch where they do not |
| Skeptic | Recruiter (light); Head of Member Services | High | F1, F8 and F10 are visible in your background, and the JD asks for the first two | Plain acknowledgment, then the sentence at its own scope; hold it through two follow-ups |
| Case / Strategist | Panel | High | The 20-minute case is a live escalation problem | Clarify first, then structure, then challenge one premise |
| Pressure | Panel | Medium | "I handled the branch's log" invites "how much of that was you" | Hold the sentence, then concede exactly what you cannot count |
| Conversational | Recruiter | Medium | Opening arc and logistics questions | A 90-second arc, using only your own sentences |
| Data-Driven Prober | Panel (branch managers) | Medium | The monthly spreadsheet invites questions about what it counts | Say what it counts; say plainly what you do not know |

Depth: Values and Case get the most questions in the panel and Values leads the Head of Member Services round. The recruiter screen is light on depth but carries four logistics rows, which the process requires.

## 5. Question banks

### Recruiter screen (30 min): A1 to A5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc with the three beats in the order your sentences give them: the years and the supervisor role, the complaints log and teller training, the monthly spreadsheet. Stop there. Add no outcomes, numbers or dates you have not given. | Tests the opening arc and whether your summary matches your CV (F1, F2, F6). It is a stem for an open prompt, so it presupposes nothing you did not say. |
| A2 | "You've never worked in a contact centre. Why should we consider you for this role?" | EXP | [grounded] "Never worked in a contact centre" | Acknowledge it first: "I haven't worked in a contact centre." Then go to the one thing your material carries: "I handled the branch's formal complaints log." Do not claim contact-centre process knowledge. | The Skeptic's opener on the biggest scope gap (F10). The premise is your own stated negative, so the plain acknowledgment is allowed. |
| A3 | "Why are you leaving your current role?" | EXP | [grounded] none given | A logistics slot: give your own reason, in your own words. Your material gives none, so do not borrow one. | Recruiter screens check motivation and logistics; this is the reason-for-leaving row. |
| A4 | "What are your pay expectations, what is your notice period, and where can you work?" | JD | [grounded] none given | Three logistics slots. Pay: give your own figure, or ask for the band first. Notice: give the notice period you actually owe. Location: give the place and pattern you can work. Supply no figure you have not decided on. | Knockout checks. The only safe answers are your own, so each slot is an instruction, not a number. |
| A5 | "Why this credit union, rather than a bank?" | VAL | [grounded] "member-owned, about 900 staff" (recruiter's words) | Selection scaffold: pick one reason from the posting's own words or the published values, and say what you know about Ashgrove. If your honest reason is only the role, say so plainly and give that. | A motivation question for a member-owned employer. No claim about your past is made. |

### Head of Member Services (45 min): B1 to B5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you coached someone on an escalation." | VAL | [grounded] "trained new tellers on our escalation script" | The nearest thing your material carries is training tellers on the escalation script. Tell that in the beats the sentence states: who you trained, the script, the escalation it covers. Answer slot: if you coached anyone above teller level on an escalation, tell that one, with who, what you said and what happened, in your own words. If not, say so plainly and tell the training. | JD requirement "coach branch supervisors on escalations" (F4). Open prompt; its theme comes from the JD line. |
| B2 | "Your complaints work was one branch's log. This role runs the process across branches and the contact centre. What would you do differently?" | JD | [grounded] "I handled the branch's formal complaints log"; JD: "Own the member complaints process end to end across branches and the contact centre" | **Highest-ROI prep in this pack.** Open with the sentence at its scope: "I handled the branch's formal complaints log." Hold it through two follow-ups by returning to that sentence, not adding to it. Concede specifically, in this form: "What I can't yet show is the process across more than one site; here is how I would learn it." Answer slot: if any step past the log was yours to set, say which and how you decided; if none was, say so and say how you would learn the rest. | The most likely objection to you, since it is the JD's first line set against your one branch (F1, F10). Deepest rehearsal: rehearse three levels of follow-up, with the concession wording above. |
| B3 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [generic] | Selection scaffold: pick a problem you found yourself and were still responsible for at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the formal complaints log, said at its own scope. | Values round, Own the Fix. No quoted sentence carries a story, so the guidance is a scaffold ending in the honest branch. |
| B4 | "Walk me through what your monthly complaints spreadsheet counts." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what it counts, in your own words. If resolution times are in it, say how they were measured and which part of that you would defend least. If they are not, say so. | The JD asks for monthly volume and resolution-time reporting (F2, F3, F9). Defend-the-number applies only to figures you give, so the guidance names none. |
| B5 | "This role presents to senior leaders. Have you presented above regional level?" | JD | [grounded] "I've never presented to anyone above regional level" | Acknowledge it: "I haven't presented above regional level." Then say how you would build the skill, as a plan: what you would do first, and how you would test it. Never describe a presentation as past experience. | The JD requirement you have stated as a gap (F8). It is asked directly, so the plain acknowledgment is the right move. |

### Panel (60 min, including the 20-minute case): C1 to C8

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a decision you made from the member's side of the counter, when the process said otherwise." | VAL | [generic] | Selection scaffold: pick a case where you chose the member's side against the process, and say what you did to get the process to catch up. If none comes to mind, say so, then give the nearest thing your material carries, the complaints log at its own scope. | Members First. No quote carries a story, so the honest branch is written in. |
| C2 | "When did a member need something explained to them twice? What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" | The nearest sentence is the escalation-script training. Scaffold: a moment a member had to hear something twice, and what changed in how it was explained. If you changed nothing, say so and say how you would check whether a member understood. | Plain Words. The question is open, so the guidance takes its theme from the published value. |
| C3 | "We are consolidating eight branches into five hubs over 2027. How do you keep each town in view when the plan counts sites?" | VAL | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief you supplied) | Scaffold: name what you would keep visible for each town, such as the complaints a branch's members raise locally, and how you would measure it. If you have been through a branch change, say how. If not, say so. | Neighbours, Not Numbers, asked against the strategy. Your material has no branch change, so the slot stays open. |
| C4 | "You handled the branch's formal complaints log. Which of those cases did you personally take to a close?" | EXP | [grounded] "I handled the branch's formal complaints log" | Pressure. Hold the sentence through two follow-ups: "I handled the log." Concede exactly what you cannot count, in plain words. Answer slot: if you can name cases you closed, name them; if you cannot count them, say that plainly and keep the log as the held claim. | Pressure and Skeptic meet at F1. Hold-then-concede: the held claim is your own sentence, and the concession is the one you can actually make. |
| C5 | "A member's complaint has been escalated twice. The branch says the contact centre owns the reply, and the final-response date is close. Walk us through the next 48 hours." | CASE | [generic]; JD: "coach branch supervisors on escalations" | 20-minute structure, spoken briefly: (1) clarify the final-response date, the channel, who holds the file, and any regulator clock; (2) objective: a fair final answer by the date, with one named owner; (3) segment: branch-led or contact-centre-led, first escalation or repeat; (4) approach: name the owner, coach the supervisor on the decision in plain words, check the outcome against the script; (5) metrics: days to final response, repeat escalations, whether the member understood; (6) risks: a missed date, a decision that contradicts policy, cost to the member. Challenge one premise of your own. | The panel's case. It is a hypothetical, so it presupposes nothing about your past. It covers the JD's end-to-end ownership and escalation coaching. |
| C6 | "We plan to move 40% of member service to digital channels by 2028. Which complaints would move with that, and how would you find out?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief you supplied); JD: "work with digital teams on self-service journeys" | Thesis: complaints follow the channel, so track them by channel before the switch. Answer slot: if you have shaped a digital journey, say which and what you saw; if you have not, say so and describe how you would find where complaints start. | The strategy's main number, tested against the JD's digital line (F5). The slot prevents a claim you cannot back. |
| C7 | "A small-business lending product launches in Q1 2027. What complaint risks would you plan for before it opens?" | CO | [grounded] "launch a small-business lending product in Q1 2027" (strategy brief you supplied) | Name the risks you would map before launch: where a business member's complaint would route, what decisions a complaint could turn on, and how you would report the new product separately. Generic, with no claim about experience in lending. | A strategy question the panel can ask of any candidate. It tests altitude; your material gives no SME lending work to draw on. |
| C8 | "App-only banks are our main competitive pressure. How does complaint handling keep a member who is about to leave?" | CO | [grounded] "the main competitive pressure is app-only banks" (strategy brief you supplied) | Thesis: a fast, owned fix at the point of complaint is the retention point. Concede that a member's choice to leave is theirs, and that the fix needs to be right first. | Strategy altitude, asked as a retention question. It draws on the values rather than on any claim about your past. |

## 6. Requirement coverage

| JD requirement | Covered by | Notes |
|---|---|---|
| Own the complaints process end to end across branches and the contact centre | B2, C4, C5 | F1 and F10 |
| Report monthly on complaint volumes | B4 | F2 |
| Report monthly on resolution times | B4 | F3, an answer slot |
| Coach branch supervisors on escalations | B1, C5 | F4 |
| Work with digital teams on self-service journeys | C6 | F5, an answer slot |
| 4+ years in financial-services customer operations | A1 | F6, met |
| Experience handling regulated complaints | B2, C4 | F7 |
| Confident presenting to senior leaders | B5 | F8, a stated gap |
| Comfortable with Excel reporting | B4 | F9 |

## 7. Values cheat sheet

The panel scores these four. Each row gives the working meaning, then the story your material gives you, or a scaffold where none exists.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No row carries a story. Scaffold: C1's decision from the member's side. If none comes to mind, say so, then give the complaints log at its own scope (F1). |
| Plain Words | If a member needs it explained twice, the writing was wrong | F4 gives the nearest sentence: "trained new tellers on our escalation script." Scaffold: C2's moment of explaining twice, and what changed. |
| Neighbours, Not Numbers | Every branch is part of its town | No row carries it. Scaffold: C3's view of the town through a hub change. If you have been through a branch change, say how; if not, say so. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1 is the nearest. Handling a log is not the same as holding a fix to its end. Scaffold: B3's problem you found and kept until solved; if none, say so and give the log at its scope. |

## 8. Grounding brief

From the strategy summary you gave me. I did not read the full brief, so check the numbers against it before the interview.

- **Digital shift:** 40% of member service to digital channels by 2028.
- **Branch footprint:** eight branches consolidated into five hubs over 2027.
- **New product:** a small-business lending product launches in Q1 2027.
- **Competitive frame:** app-only banks are the main pressure.
- Vocabulary to use: member service, digital channels, hubs, branches, towns. Your values use the word "members" throughout, so match it.

## 9. Reverse questions

| Question | Why it lands |
|---|---|
| "Who owns a complaint once it moves from a branch to the contact centre today?" | It tests how the end-to-end ownership in the JD works in practice, which is the gap you most need to understand. |
| "What would the monthly complaints report need to show for the Head of Member Services to act on it?" | It treats reporting as a decision tool, which matches the JD's reporting line. |
| "Which branches move first in the five-hub plan, and where does complaints handling sit in that move?" | It shows you read the strategy and ties the consolidation to the complaints work. |
| "How is the 40% digital target measured for member service, and who is accountable for complaints inside it?" | It connects the target to complaint ownership, and makes the interviewer say who owns the number. |
| "What would you want the first 90 days to deliver, and where should I not spend time?" | It is the manager-facing question, and it invites a plain answer about priorities. |
| "What do branch supervisors most often get wrong on an escalation?" | Panel question. It goes straight at the coaching half of the role and gives you a real answer to work from. |

## 10. Sources

**Provided documents:**
- The job description, as pasted in your message
- The values, copied from ashgrovecu.org/about/values on 20 November 2026. I have not checked the live page, so confirm the wording against it.
- The recruiter's email: three rounds on 29 November, with the round formats
- The 2026 strategy brief, as you summarised it. I have not read the full brief.
- Your background, from your message

**Searches and fetches:** none sent. The provided documents already settle every target below.

**Research tier:** L1, with searches 0 of 6 and fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text fixes the values cheat sheet (section 7) |
| 2. Ashgrove interview process, Member Experience Lead | skipped | The recruiter's email fixes the three rounds and their formats |
| 3. Ashgrove strategy / recent news | skipped | The strategy summary you supplied gives the current priorities; the full brief is not read (see section 8) |
| 4. Interviewer name and Ashgrove | n/a | No interviewer names were given, so there was no query to form |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 11. Upgrade menu

- **Your CV** → lets the pack quote more than four of your sentences, and checks F1 to F9 against the document itself
- **Names of the Head of Member Services and the two branch managers** → persona weights from their public footprint, and reverse questions tailored to their careers
- **The full text of the values page and the strategy brief** → checks the pasted wording and adds the detail section 8 lacks
- **The recruiter's note on the case format** → coverage of what the panel scores in the 20-minute case
- **Deep research (L2)** → strategy brief, interviewer talks and recent organisation news, at most 6 further searches and 2 further fetches, adding a few minutes of research time; offered once, run only if you ask
- **`tuesday-dossier.md`** → verified evidence and prohibited claims carried into this pack
