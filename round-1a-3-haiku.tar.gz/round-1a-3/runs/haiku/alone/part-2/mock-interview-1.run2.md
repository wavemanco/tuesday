Priya's pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-2-rooms-case-1-denied-241deff2/c444dca8-2fc2-49cf-95ea-2f6da9ee0078/scratchpad/Northwind-Data_senior-gtm-strategy-lead_interview_pack.md`. It has 19 questions across six personas, each tagged by type, with answer guidance, rationale, and a fit snapshot quoting only what you gave me.

Three things shaped it:

- **No web research ran.** All three searches were refused for lack of permission, so the pack runs on your JD highlights, your research note (undated, so confirm it's current before using it in the room), and my notes on Priya and Dan. The file has the full target accounting. If you grant search permission, I can rerun the values, loop and Dan-footprint checks.
- **Highest-ROI prep is Dan's home ground: target-setting across land, adopt, expand and renew.** Priya has no quota-setting or sales-ops experience, and the pack gives her an honest branch there rather than a story.
- **Priya's material is thin where the JD is heavy.** Partner-motion design and SQL/Tableau analysis are adjacent or self-rated only, and the pack flags them as such. Her "no quota-setting" negative comes from your notes, so she should state it herself before it's coached as an acknowledgment.

Two questions that would sharpen it:

1. Do you have the full JD text? The pack can see only the six highlights, so any other requirement (level, location, travel, work authorization) is invisible.
2. Can you paste Priya's CV, or her own sentences about the ~$400M figure and the partner model? Right now the quotes are from your notes, and her own words would make them hers.

I can also run a drill with Dan's persona on question B1 (the $400M counting question) or D1 (target-setting), and save a `tuesday-dossier.md` recording the gaps this prep exposed for later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind-Data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy. Peer, same VP. Single 60-minute conversation.
**Candidate:** Priya (she/her).
**Built on:** your JD highlights, the coach's notes on Priya's background, your research note. No CV text, no full JD text, and no web research (all three searches were refused; see Sources).

---

## 1. How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Guidance is scaffolding for a spoken answer, not a script. Rehearse the beats in your own words.
- Anything in an *answer slot* is an instruction for the interview. Where your own experience doesn't fill it, use the honest branch.
- **Type key:** JD = role requirement. EXP = work-experience deep-dive. CO = company and strategy. CASE = live problem. VAL = values (none in this pack: no values-style round was detected).
- **Dropped sections:** prep triage (no prep time given), values cheat sheet (no values round), graded deliverables (none declared), delivery coaching (no assessment).

## 2. Prep priorities

Ranked by how much a session can move. Everything not listed is insurance.

1. **D1 — the highest-ROI objection.** Target-setting across land, adopt, expand and renew, which is Dan's home ground. Rehearse until the honest answer is boring.
2. **B1 and B2 — the $400M figure.** Know exactly what you can and cannot say about how it was counted.
3. **B4 — one analysis you ran yourself in SQL and Tableau.** If you don't have one, the answer is still a clear one.
4. **A3 — partner-motion design.** A JD requirement your material only reaches adjacently.

Everything else is insurance.

## 3. Fit snapshot

The evidence column quotes only your inputs. Source names: "the coach's notes" (Priya's background as given in the request), "your message" (JD highlights and research note).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Your material says she proposed a store-surface change. It does not say she owned a go-to-market strategy. Words: "I proposed a store-surface change, and it is credited with a ~$400M ARR uplift." Answer slot: if any go-to-market decision for a product was hers to make, name it and how she decided; if none was, say so plainly and stay with the store-surface change. |
| F2 | "run independent analysis in SQL and Tableau" — your message | "skilled in SQL/Tableau" — the coach's notes | low | [inferred] (derived: the requirement's wording against a skill-level sentence) | none | The wording reaches the requirement, but it is a self-rating with no artifact behind it. Coach it as a note, not as a demonstrated analysis. Answer slot: an analysis she ran herself, from question to recommendation, is the proof. If she can show one, say what it answered. |
| F3 | "identify whitespace across land/adopt/expand/renew" — your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | low | [inferred] (derived: partner economics against whitespace across four motions) | transferability | Adjacent at best. The sentence does not reach whitespace across the four motions. Words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if that model pointed to where to act next, say what it pointed to and what she did; if it did not, say so and say how she would find whitespace across the four motions. |
| F4 | "partner-motion design experience required" — your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Adjacent. A partner-level model is partner economics, not partner-motion design. Stay at the quote's scope. Answer slot: if she designed any part of a partner motion (terms, tiers, incentives, enablement), name it and her decision; if she did not, say so plainly and describe what the model gave the carrier negotiation. |
| F5 | "strong cross-functional influence" — your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Words: "I set annual volume targets with cross-org consensus." No practice added. |
| F6 | "AI experience a plus" — your message | "uses AI tools daily" — the coach's notes | low | [inferred] (derived: usage against a plus-level requirement) | none | Usage, not building. Words: "I use AI tools daily." Do not elevate this to building AI features. |
| F7 | Sales-strategy and target-setting work for a sales organization — [generic] (role-family pattern, not in the supplied JD highlights) | "No classic sales-ops or quota-setting experience." — the coach's notes (a negative reported by the coach, not yet stated by Priya) | none | [grounded] | capability | A gap the candidate has not yet stated herself. Words are held until Priya gives this negative in her own words. Then: "I haven't set quotas or run sales operations." After that, how she would learn it, said as a plan, never as a past. |

**Gates:** none in the material. Work authorization, location and travel terms are not in the highlights (see upgrade menu).

## 4. Prohibited claims

Not coached in any cell of this pack. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned go-to-market for a product line | Inflated form of F1 | F1's quote at its own scope. Pack's observation, not words for her: the material says the store-surface change, not go-to-market ownership. |
| Set quotas or sales targets for a sales organization | Inflated form of F5 and F7: "set annual volume targets" widened to quota-setting for a sales team | F5's quote at its own scope. Pack's observation: the material says volume targets with cross-org consensus. |
| Drove or delivered the ~$400M | Inflated form of F1: "credited with" widened to causal ownership | "credited with a ~$400M ARR uplift" at its own scope. |
| Ran SQL and Tableau analysis end to end for the business | Inflated form of F2: a self-rating widened to a demonstrated analysis | F2's quote at its own scope. |
| Designed partner programs or partner motions | Inflated form of F4: a partner-level model widened to partner-program design | F4's quote at its own scope. |
| "I haven't set quotas or run sales operations" | Sourced entry, pending confirmation: the coach's negative, not Priya's words | No first-person acknowledgment is coached until she states it herself. Until then, the cell is an answer slot. |

## 5. Interviewer read

Source: the coach's notes only. Public-footprint research was refused, so nothing here is checked against Dan's published work.

- **Career pattern:** pricing and monetization as the spine, plus one early-stage startup chapter.
- **Self-described style:** "relentlessly data-driven."

**Practical implications:**

1. Every number will be taken back to its assumptions. That is why the Prober bank is the largest.
2. Case questions will lean toward pricing, packaging and unit economics. Bring a packaging frame to H2.
3. Expect questions about big-company pace, and about how much of a result was built by hand. Tell a builder story only if your material holds one; the notes do not.
4. The register is peer, so expect seam and credit probes (A1, A2).

**Mirror opportunities:** none. The notes show no shared professional path and no shared background. Don't build rapport on either.

## 6. Grounding brief

From your research note. **Undated.** Confirm it is current before quoting it in the room.

- **Stated priorities:** "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability."
- **Main competitive threat:** "bundling by a much larger platform vendor."
- **Vocabulary from the JD:** "land/adopt/expand/renew."

Use this to sound current. Do not coach Priya to correct the interviewer on anything.

## 7. Persona weights

Relationship priors for a peer round set the starting weights: Peer Evaluator and Data-Driven Prober dominate. The interviewer signals then tilt them. No values round is detected, so no values bank.

| Persona | Questions | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | 5 (top) | Assumption and denominator probes on the $400M, the partner model and the SQL claim | Top weight. The self-described "relentlessly data-driven" line plus the analytics-heavy reading of the JD ("run independent analysis") both point here | Know what you can and cannot say about each number; name the weakest assumption before they do |
| Peer Evaluator | 4 (top) | Seam, decision rights, credit | Peer round, same VP, and the JD asks for cross-functional influence | Reciprocity: what you bring to their team. Propose seam principles, not a claimed seam |
| Skeptic | 3 | The target-setting gap (D1) and motivation (D3) | Your highest-ROI objection sits here, where the material is thinnest | Rehearse D1 until the honest branch is boring. Calibrated candor over bluffing |
| Case / Strategist | 3 | Copilot sizing, bundling response, adoption-to-renewal diagnosis | The research note gives live priorities; the pricing spine tilts toward packaging | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| Pressure | 2 | Defending the $400M and a 60-second case for the role | Lower weight in a peer round, but a peer can push hard on one headline figure | Hold through two follow-ups; concede the specific uncertainty, not the core claim |
| Conversational | 2 | Biography and AI usage asked casually | Casual openers are still scored | A 90-second arc; treat the AI question as scored |

Total: 19 questions, inside the 18–26 range.

## 8. Question banks

### Prober (top weight, 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Say what the figure is and what it is credited to, in your own words. Answer slot, four parts: how it was counted; what it is sensitive to; the assumption you would defend least; which part was yours. If you do not know how it was counted, say so plainly. That is an honest answer. | F1 is the headline metric and the prober's first target. Defend-the-number slot. |
| B2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Name the weakest assumption before they do, in your own words. Answer slot: if you know one, name it and what it would do to the figure. If you do not know the assumptions behind the number, say so. Do not invent one to sound rigorous. | Converts a gotcha into a credibility gain. Same figure, second level of probing. |
| B3 | "Your partner-level model: what were its main inputs, and what did carrier negotiations do with its output?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" — the coach's notes | Describe the model and how it was used, in the sentence's own terms. Answer slot: name the inputs you can and say which were yours. If you cannot reconstruct them, say so. | F4 is the partner requirement. A partner-economics probe is likely, and the honest answer is available. |
| B4 | "Tell me about an analysis you ran end to end in SQL and Tableau: the question, the data, what changed." | EXP | [grounded] "skilled in SQL/Tableau" — the coach's notes; the JD requirement "run independent analysis in SQL and Tableau" — your message | Selection scaffold: pick one analysis you ran yourself, from question to recommendation. If none comes to mind, say so plainly, then say what you have done with SQL and Tableau and how you would show it. | F2 is low-confidence. The prober will push it, and a self-rating must not turn into a story. |
| B5 | "You set annual volume targets with cross-org consensus. How did you know the number was right when you set it?" | EXP | [grounded] "set annual volume targets with cross-org consensus" — the coach's notes | Answer slot: if the target came from a model you built, say which model and what it did. If the consensus set it, say so, and say what was yours. | F5 is the cross-functional evidence. The prober tests the basis of the number. |

### Peer Evaluator (top weight, 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam between your work and sales strategy, and what happens when we disagree?" | JD | [grounded] "strong cross-functional influence" — your message | Propose seam principles (who decides what, by question) rather than pretending to know the seam. Answer slot: if you have disagreed with a peer on a number or a call, say what you argued, what they argued and how it resolved. If you have no such case on record, say so and describe how you would handle one. | The collegial version of the influence requirement. F5 is the evidence it draws on. |
| A2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "set annual volume targets with cross-org consensus" — the coach's notes | Lead with what the consensus parties agreed and what was yours within it. Answer slot: which part of the targets was your decision and which was the group's. Credit the group in the same breath as your own part. | The peer's credit probe. F5 is the sentence it rests on. |
| A3 | "Which partner motions would you design first for the two new lines, and who would you need to agree?" | JD | [grounded] "partner-motion design experience required" — your message | Answer from the role, not from a claimed history. Answer slot: if you designed any part of a partner motion, name the part and your decision. If you did not, say so plainly, then give your first two motions and who you would involve. | The JD's partner requirement is hard, so it needs a JD-tagged question. F4 is adjacent, so the honest answer carries the limit. |
| A4 | "You'd be building go-to-market for two new lines beside my pricing-side work. Which calls would be yours, and which mine?" | JD | [grounded] "own GTM strategy for two new product lines" — your message | Propose decision rights by question: which price, which motion, which target. Do not assert the pricing team's current structure, which the notes do not describe. | Dan's pricing background makes this the most likely peer probe. The JD line raises it. |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How would you set targets across land, adopt, expand and renew?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" — your message | Highest-ROI prep in this pack. Answer slot: if you have set targets for any of those motions, say which and how. If you have not, say so plainly, then say how you would start: which motion first, what data, and which target you would test. Hold through two follow-ups by returning to the method. Concede the gap in one sentence. Do not claim a history of quota-setting. | F7 is the weakest point and the likeliest objection. The question is aimed where the material is thinnest, so it gets the deepest rehearsal, with the exact concession wording and no added affirmative content. |
| D2 | "Which part of this JD would you be weakest at on day one?" | CO | [generic] | Name the weakest part plainly, then give the ramp: what you would do in the first two weeks. Answer slot: the target-setting work (F7) if you have not done it. Use your own words for the gap. | A standard skeptic probe. Its honest answer is the same as D1's, so rehearse them together. |
| D3 | "Why leave a consumer-tech product org for B2B data infrastructure, and why now?" | CO | [generic] | Answer slot: give your own reason in your own words. The material you gave me does not include one. Do not borrow the company's stated priorities as your motivation unless that is your real reason. | Motivation-consistency probe. The skeptic will test a reason that sounds rehearsed. |

### Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Northwind's priorities are enterprise expansion, an AI copilot launch and reaching profitability. How would you size the whitespace for the copilot across land, adopt, expand and renew?" | CASE | [grounded] "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" — your message (research note, undated) | Clarify the objective first, then segment, approach, metrics and risks. Think aloud. Make no claim about your past. | A live problem from the stated priorities. Confirm the priorities are current first. |
| H2 | "A much larger platform vendor bundles a similar capability into its suite at no added price. How do you respond?" | CASE | [grounded] "bundling by a much larger platform vendor" — your message (research note, undated) | Frame it as a pricing and packaging decision: options such as differentiating, unbundling, or pricing the gap. Challenge one premise respectfully. Make no claim about your past. | Dan's native language is pricing and packaging, so tilt toward it. |
| H3 | "An account adopted one product line and stalled before renewal. Diagnose it." | CASE | [grounded] "identify whitespace across land/adopt/expand/renew" — your message | Walk the funnel stage by stage. Name the data you would pull for each stage. Make no claim about your past. | Adoption-to-renewal diagnosis, drawn from the JD's motion list. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Hold: "I proposed the change, and the uplift is credited to it." Hold through two follow-ups. Concede the specific uncertainty: "I can't separate the change's share from the rest without knowing how it was counted, and that is the part I would check." Do not fold on "proposed." | The pressure version of B1. A held position must be one the quote carries. |
| C2 | "Sixty seconds: why you for this role, when the JD asks for things you haven't shown yet?" | JD | [grounded] "own GTM strategy for two new product lines" — your message | Sixty seconds: lead with what the quotes carry (F1, F5), name the gap plainly, then commit to one ramp step. Answer slot: if part of the role is new to you, name that part and what you would do first. | Time-boxed. The gap is stated by the JD, not invented by the pack. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | A 90-second arc in those beats: two years of strategy consulting, then nine years in consumer-tech product strategy and operations. Answer slot: one sentence on why this role, in your own words. | Casual register, still scored. The arc is the rehearsed answer. |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "AI experience a plus" — your message; "uses AI tools daily" — the coach's notes | Name the tools and what you use them for, in your own words. Answer slot: name one task where you used them and what changed. If none comes to mind, say so. | F6 is a plus-level requirement asked casually. Keep it at usage. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | A4, C2 |
| identify whitespace across land/adopt/expand/renew | D1, H1, H3 |
| run independent analysis in SQL and Tableau | B4 |
| partner-motion design experience required | A3, B3 |
| strong cross-functional influence | A1, A2 |
| AI experience a plus | E2 |

Every requirement has at least one JD-tagged question or a stated reason. The target-setting gap in F7 is not a JD line, so it is covered by D1, D2 and D3.

## 9. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your career has run through pricing and monetization. Which part of that carried over best into sales strategy, and which part didn't?" | Ties to Dan's own path. Turns an interview into a peer conversation and shows you read their background. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer. Weighted heavily as a preparation signal. |
| R3 | "Which of the two new product lines do you think is most exposed to the bundling threat?" | Uses the research note and invites Dan's view on strategy. |
| R4 | "Where does the sales-strategy team's analysis stop and the emerging-products team's start?" | Seam question. Lets you hear the boundary in their own words. |
| R5 | "How will the copilot's launch be judged in its first two quarters?" | Ties to a stated priority and surfaces the success measure. |

## 10. Sources

**Provided documents:** your JD highlights; your research note (strategy priorities and bundling threat, undated); the coach's notes on Priya's background and on Dan's profile.

**Searches and fetches:**

| Query | Result |
|---|---|
| "Northwind Data company values operating principles" | refused (search permission not granted) |
| "Northwind Data Compass AI copilot launch" | refused (search permission not granted) |
| "Dan Kovac Director of Sales Strategy Northwind Data" | refused (search permission not granted) |

No fetches were sent.

**Research tier:** L1 attempted. Searches 0 of 6 returned results; 3 were sent and all were refused. Fetches 0 of 2.

**Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Values section, which is dropped because no values round was detected. The search was refused. |
| 2. Northwind Data interview process, senior GTM | unavailable | Loop structure. No call was sent; the permission refusal on targets 1 and 3 was not retried. The loop here rests on your stated single 60-minute conversation. |
| 3. Northwind Data strategy and recent news | unavailable | Current priorities check on the research note. The search was refused; the note is used as given and undated. |
| 4. Dan Kovac, Northwind Data | unavailable | Public-footprint persona weights, talks and reverse questions. The search was refused. |
| 5. Representative senior GTM JD | skipped | Your JD highlights fix the fit snapshot. |

## 11. Upgrade menu

- **Full JD text** → any requirement not in the highlights becomes visible (level, location, travel, work authorization). Right now, the pack can see only the six highlights.
- **Priya's own CV, or her own sentences about the $400M and the partner model** → the coach's-notes quotes become her words. Rows F1 to F6 upgrade from coach's notes to her material, and B1 and B2 get more exact.
- **Priya's own statement of the sales-ops and quota gap** → F7 becomes coachable, and D1's concession gets its exact wording.
- **Search permission** → targets 1 to 4 rerun. Values and interview-process checks confirm this loop, and Dan's public talks and posts would sharpen the persona weights and reverse questions.
- **Posting terms for work authorization, location and travel** → gate rows (none exist yet) and the logistics answers they need.
- **Recruiter email on focus areas or any pre-read** → confirms that no graded deliverable sits in this round.
- **Deeper research, once:** a strategy brief, Dan's talks and writing, and recent org context. Up to 6 more searches and 2 more fetches, several minutes. Needs search permission.
