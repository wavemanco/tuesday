# Prep pack: Senior Partnerships Manager, Kelverton Rail, second round

**Interviewers:** Deepa (VP Partnerships, your future manager); Ross (Commercial Director)
**Format:** 60 minutes. First 15 minutes, a short spoken POV with no slides. Remaining 45 minutes, Q&A, with Ross pressing on commercials.
**Built on:** your message, and the recruiter's email as you quoted it. No job description was supplied, and no company research ran (see Sources), so requirements below come from the recruiter's words.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Type | Meaning |
|---|---|
| VAL | Behavioral and values alignment |
| EXP | Deep-dive on your own experience |
| JD | Stated role requirement |
| CO | Company and strategy knowledge |
| CASE | Live problem |

The guidance is scaffolding, not a script. Rehearse the structure and the honest branch, then say it in your own words.

## Prep triage (4 hours)

1. **75 min: the POV (section 5).** Pick one thesis, write its concession, and write the operator-benefit close. Say it aloud three times, timed at 15 minutes. Start with thesis T1 unless it does not fit how you think.
2. **60 min: Skeptic bank B1 to B4.** Rehearse the plain acknowledgments aloud until they are flat and unhedged. B1 is the highest-ROI item in this pack.
3. **60 min: Commercial bank C1, C2, D1 and D2.** Write the "how was the £4M counted" answer in your own words, or write the honest "I don't know how it was counted" branch.
4. **45 min: reverse questions and the fact sheet.** Put your own quoted sentences from section 3 on one page, and read it aloud.

Everything else is insurance.

## Fit snapshot

Requirements come from the recruiter's email, since no JD was supplied. Every evidence cell holds only sentences you wrote, quoted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" (recruiter email) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Your material shows partner-channel growth at a payments company, not operator partnerships. Say so yourself: "The channel I grew was payments ISVs, not operators." Do not stretch the channel result across to operators. |
| F2 | "land on what it means for the operators themselves" (recruiter email) | "bus and light rail network planning, so I know the operator world from the other side" (your message) | medium | [grounded] | presentation | Your quote already reaches the requirement in other terms: planning work for bus and light rail networks is the operator's own problem. Lead with it in your words. Add no operator practice you did not do. |
| F3 | "Ross will push on commercials" (recruiter email) | "Never carried a direct quota, only influenced revenue" (your message) | medium | [grounded] | capability | You stated the absence. Words: "I've never carried a direct quota. What I have carried is influenced revenue, roughly £4M." Then how you would take commercial ownership, said as a plan, never as a past. |
| F4 | sell into train operating companies (role-family requirement, not quoted, [generic]) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | You stated it. Words: "I haven't sold into rail." Then how you would learn operator buying, said as a plan. No slot. |

Rules these rows follow: the gap type follows the evidence cell, not my sense of the row. Confidence grades your evidence, and medium is the band for user-confirmed claims with no inspectable artifact. Provenance grades what this pack wrote, and every bridge stays inside the quote's own scope.

## Prohibited claims

Built locally from the fit snapshot. None of the guidance below asserts these.

| Not coached | Basis | Honest form |
|---|---|---|
| "I grew the channel to 40 partners on my own" | Inflated form of F1: "took it from 6 partners to 40" does not say who did it | Your quote at its own scope. The limit is my observation: your material does not say how much of the growth was yours. Slot in C2 stays inside it. |
| "£4M in sourced revenue" | Inflated form of "roughly £4M of influenced revenue" | Keep "influenced". The limit is my observation: your material says influenced, not sourced. |
| "I've sold into rail" or "I know rail buyers" | Negative you stated, F4 | Plain acknowledgment: "I haven't sold into rail." |
| "I carried a quota" or "I owned revenue targets" | Negative you stated, F3 | Plain acknowledgment: "I've never carried a direct quota." |
| "I know operators from their side of the table" | Inflated form of F2: "I know the operator world from the other side" is your phrase about planning work | Your quote at its own scope: planning work for operators, not operator-side buying. |

## Persona weights

No interviewer profile was researched, so weights follow round-type priors. The panel rule blends the top two personas for each member.

| Interviewer | Dominant personas | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Deepa (future manager) | Case/Strategist (top), Skeptic | Live problems on operator partnerships; direct questions on the rail gap | High. A hiring manager is buying capability and derisking the gaps F3 and F4 expose | Clarify, then structure; the plain acknowledgment, then a plan |
| Ross (commercials) | Pressure (top), Data-Driven Prober | Time-boxed challenges on the £4M figure and the quota gap; "how much of that was you" | High. Your recruiter wrote that Ross will push on commercials, and F1 and F3 are where a commercial probe lands | Hold through two follow-ups, concede specifically, never fold on the core claim |

Depth follows weight: Deepa's bank and Ross's pressure bank get the most questions.

## Coverage

Requirement-coverage line against the recruiter's three stated requirements. No JD was supplied, so this is not a full JD check.

| Requirement | Covered by |
|---|---|
| POV on operator partnerships over 18 months | Section 5; A3 |
| What it means for operators | A3; section 5 close |
| Commercials | C1 to C5; D1 to D4 |
| Rail selling (role-family, [generic]) | B1; B2; C5 |

## Question banks

### Deepa: Case/Strategist and Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two operators want different things from the same scheduling platform. Who do you prioritise, and why?" | CASE | [generic] | Clarify first: which operators, what each wants, what it costs them to be wrong. Then structure: a segment choice with a stated reason, and one risk named. Make no claim about your past. | A live problem from the role, not a fact about you. |
| A2 | "Which operator segment would you start with?" | CASE | [generic] | Name the segment and the one assumption it rests on. If you cannot test that assumption in the first month, say how you would. | Tests structure, not a right answer. |
| A3 | "What does a partnership with an operator actually give the operator?" | CO | [grounded] "land on what it means for the operators themselves" (recruiter email) | Start from the operator's own measure, such as the planning outcome it cares about. Then name one thing the operator would have to give up. Use the quote in the recruiter's words. | Your POV's close depends on this, so rehearse it until it is one sentence. |
| A4 | "What did you do to take the channel from 6 partners to 40?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | Tell the beats the quote states, in your own words: six partners at the start, forty at the end, the influenced revenue figure. Answer slot: if you set specific steps in that growth, name them and how you decided. If the programme was set by others, or the steps were not yours, say so plainly and describe your part. | The channel is your best evidence for the partnerships requirement, and the first probe will ask which parts were yours. |
| A5 | "How would you know, within a quarter, that an operator partnership is working?" | CASE | [generic] | Name two leading signals and one lagging signal. Say which one you would distrust first. | Tests whether you can measure the operator side, not just the channel. |

### Deepa: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail. Why would an operator trust a partnerships lead who hasn't?" | JD | [grounded] "Never sold into rail specifically" (your message); [grounded] "bus and light rail network planning, so I know the operator world from the other side" (your message) | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't sold into rail." Then the bridge, in your quote's scope: the planning work on the operator's side of the table. Hold through two follow-ups by returning to what you did in planning, not by adding to it. Concede specifically if pressed: you do not yet know how operators buy scheduling software. | F4 is the gap. A plain, unhedged acknowledgment defuses the probe before it is asked as a trap. |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Name the direct quota plainly: "I've never carried a direct quota." Then a 90-day plan: what you would learn first, from whom, and how you would know it was working. Plan language, never past tense. | F3 is the gap most likely to be named by Deepa. |
| B3 | "Why leave a payments company, where the channel is working, for rail?" | EXP | [grounded] "last 4 at a payments company running the ISV channel" (your message) | Answer slot: give your own reason for leaving, in your own words. If you have not settled the reason, say so and say what you are still deciding. Do not borrow a reason from the job spec. | The motivation probe is the one a future manager always asks. |
| B4 | "Your revenue figure is influenced, not sourced. What number would you hold a rail operator to?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Answer slot: say which number you would hold the operator to, and why. If you know how influence was attributed in your figure, say how; if you do not, say so. Keep "influenced" in the sentence. | Links the figure to the new job without stretching it, and forces the honest attribution answer. |

### Ross: Pressure and Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why should we trust a partnerships head with no quota to own a commercial plan?" | JD | [grounded] "Never carried a direct quota, only influenced revenue" (your message) | Hold: the number you carry is influenced revenue, roughly £4M across a channel that grew from 6 partners to 40. Hold it through two follow-ups. Concede specifically on the quota: you have not carried one, and say what you would need to see to be sure you could. | Ross's pressure lands on F3. The hold must be one your quotes carry, nothing bigger. |
| C2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | Answer slot: say which part was yours, in your own words. If the share cannot be separated from the team's or the partners', say so plainly. | Most likely pressure question on F1, and the honest answer is the attribution. |
| C3 | "Operators run on thin margins and penalty clauses. Where's the money in a partnership with one?" | CO | [generic] | Name the operator's economics in general terms, then the number you would put first, and what you do not know yet. No claim about your past. | Tests whether you can think at the operator's altitude. |
| C4 | "Forty-five seconds: what would you do in your first 90 days that a quota-carrier would not?" | JD | [generic] | Give one answer with a reason. Do not claim a past result as proof. | A time-boxed pressure probe. |
| C5 | "You've told us you haven't sold into rail. Name one deal you would lose first." | CASE | [grounded] "Never sold into rail specifically" (your message) | Plain acknowledgment: "I haven't sold into rail." Then name the likeliest loss and why. Do not invent a deal or a past loss. | Pressure on F4, answered with the acknowledgment rather than defended. |

### Ross: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how that £4M was counted." | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Answer slot: if you know the counting method, say it in your own words. If you do not know how it was counted, say that plainly. Name the weakest assumption you know of before Ross does. | Defend-the-number slot on F1. An explanation you cannot repeat under a second question is worse than none. |
| D2 | "Which assumption behind that £4M would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Answer slot: name the assumption only if you know it. If you do not, say so, and say what you would check first. | The weakest-assumption move, in the honest form. |
| D3 | "How would you model revenue from an operator partnership on a multi-year contract?" | CO | [generic] | Name the drivers and the one you would test first. Say which assumptions you would not yet trust. No claim about your past. | Tests commercial thinking without asking for a figure. |
| D4 | "Your channel went from 6 partners to 40. How did those 40 come to be partners?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Answer slot: describe how the partners came on, in your own words. If the recruiting was not yours, say who did it and what you did. | Probes the same growth as A4 from the attribution side. |

## POV build (section 5)

Recruiter-declared deliverable: a short spoken POV on operator partnerships over 18 months, landing on what it means for operators. No slides.

Grounded fact to build on: F2, quoted: "bus and light rail network planning, so I know the operator world from the other side" (your message).

Theses, each with a concession:

- **T1. Plan partnerships around the operator's timetable-change cycle, not the sales cycle.** Concession: operators may not share the planning data this needs, and that would slow the work.
- **T2. Tie operator partnerships to a planning outcome the operator measures, not licence volume.** Concession: outcome measures need operator agreement and add commercial complexity.
- **T3. Scale the operator channel slowly, with fewer operators in deeper partnership.** Concession: this gives up pipeline speed, and I cannot yet show it is the right trade.

Differentiation: the consensus answer is "more partners, deeper integrations, co-selling". Bring it as one item to show you know it, then depart from it with a reason. The anti-pick: do not chase partner count with operators who will not share planning data. Say that out loud.

Close: state the operator benefit in the operator's own measure, in one sentence.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a successful first six months look like, in operator terms rather than revenue terms?" | Shows you are thinking about what the operator gets. Gives Deepa room to describe her own bar. |
| R2 | "Where has the operator partnership model been tested, and where did it break?" | Invites candour about the team's own history. Useful to hear before you commit to a view. |
| R3 | "How does the commercial plan get set, and where do partnerships sit in that process?" | Lets Ross say how decisions are made. Relevant to the commercial pressure. |
| R4 | "What would you need to see from me in the first month to know I'd been the right hire?" | A direct question about the bar, which helps you prepare for the next round. |
| R5 | "When operators push back on a scheduling change, what usually causes it?" | A real operator-side question. It shows you know the operator's problem is the thing that matters. |
| R6 | "What have you learned from the rail partnerships you have run so far?" | Asks Deepa about her own experience. No interviewer profile exists, so this is role-generic. |

## Sources

- Provided: your message; the recruiter's email, as you quoted it. The market report is referenced but not in this environment.
- Research tier: L1 — searches 0 of 6 run (3 refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton values | unavailable | Values cheat sheet, section 10, is absent. Query "Kelverton Rail values" refused. |
| 2. Kelverton interview process, Senior Partnerships | unavailable | Loop structure; no call sent, search permission declined. Would have shaped persona weights beyond the round-type priors. |
| 3. Kelverton strategy and recent news | unavailable | Grounding brief and CO questions; query "Kelverton Rail strategy partnerships news" refused. The CO questions here are generic as a result. |
| 4. Deepa / Ross + Kelverton | unavailable | Interviewer read and tailored reverse questions. Names are first names with title and company, so a query exists; it was refused. |
| 5. Representative Senior Partnerships Manager JD | unavailable | JD-tagged questions and requirement coverage; no call sent, search permission declined. |

Refused calls, listed in full: "Kelverton Rail values"; "Kelverton Rail scheduling software train operating companies"; "Kelverton Rail strategy partnerships news".

## Upgrade menu (closing)

- The recruiter's JD, or your summary of the internal market report → sections 5 and 6 and the commercial bank can differentiate from it.
- Deepa's and Ross's public professional profiles → interviewer read and persona weights.
- Search permission granted → rows 1 to 5 above can run at the next session.
