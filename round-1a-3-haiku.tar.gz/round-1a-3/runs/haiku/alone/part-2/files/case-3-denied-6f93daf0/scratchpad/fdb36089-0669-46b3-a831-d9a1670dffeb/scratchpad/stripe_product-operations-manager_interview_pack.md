# Stripe: Product Operations Manager, final round prep pack

**Built on:** the company and role you gave me. No job description, CV, round details, interviewer name or prep time was shared, and web search was refused for this session, so nothing below is sourced from Stripe itself. Anything about the candidate's past is a question for the interview, not a claim in this pack.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what it is scoring.
- Type key: **VAL** behavioral/values, **EXP** past-work deep-dive, **JD** role/requirement, **CO** company knowledge, **CASE** live problem.
- Guidance is scaffolding, not a script. Rehearse out loud, in your own words, and stop when you hit an answer slot you cannot fill truthfully.

## Fit snapshot

No job description or CV was supplied, so the requirements below are **role-family requirements** typical of product operations roles. They are not quotes from Stripe's posting, and every evidence cell is `none given`. Each bridge is a selection scaffold ending in an honest branch.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Process design and ownership of operating processes (role family) | none given | none | [generic] | discovery | Pick a process you designed or materially changed. Say what it replaced, who it touched and how you knew it worked. If you have not owned one, say so plainly, then describe how you would map the current process before changing it. |
| F2 | Metrics and reporting that leaders act on (role family) | none given | none | [generic] | discovery | Pick a number you reported and used to decide something. Say how it was counted and which assumption you would defend least. If you have not reported one, say what you would track first and why. |
| F3 | Launch and cross-team coordination (role family) | none given | none | [generic] | discovery | Pick a launch or cross-team effort you coordinated. Say which teams were involved, where it slipped and what you changed. If you have not coordinated one, say so plainly, then name the first thing you would do to learn the teams' dependencies. |
| F4 | Prioritization and influence without direct authority (role family) | none given | none | [generic] | discovery | Pick a decision you influenced without owning the team that made it. Say what evidence you used and how the disagreement resolved. If none comes to mind, say so plainly, then describe how you would decide who has the call. |
| F5 | Clear written and spoken communication to senior leaders (role family) | none given | none | [generic] | discovery | Pick a status update or recommendation that went to a senior audience. Say what you led with and what you cut. If you have not written for that audience, say so plainly, then describe how you would structure a first update. |

**Gate rows:** none. Without a job description the pack cannot tell which requirements are hard gates (work authorization, location, days on site). Send the posting and this section updates.

## Prohibited list

No candidate-specific claims are listed, because no quoted sentences from the candidate exist yet to stretch. The same limits apply to every answer in this pack:

- **Do not invent figures, team sizes, dates or outcomes from your past.** If an answer needs a number you do not have, say so, or say what you would measure.
- **Do not claim to have done a practice you have not done.** "I would" is an honest answer. "I did" needs your own experience behind it.

## Persona weights

No round type, interviewer or loop structure was given, so these weights are flat across the relationship priors. This is the weakest version of the pack, and recalibrating it is the first thing to fix.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (4 questions) | Live problems on process, launches and adoption | High. Product ops is judged on how you diagnose operating problems, and this is the most common format for that | Clarify, then structure, then choose one fix and one measure |
| Skeptic (3) | Probes the gap between your experience and the role | High. The likeliest objection is that the experience has not been tested at this scale or in this domain | Rehearse the single most likely objection until it is plain; name one real weakness and a ramp plan |
| Data-Driven Prober (3) | Asks how a number was counted and what it is sensitive to | Medium. Depends on whether the role owns metrics; the JD would settle it | Name the weakest assumption before it is asked |
| Pressure (3) | Interrupts, time-boxes, questions motive | Medium. Common in final rounds with senior leaders | Pause, restate the question, hold a position through two follow-ups |
| Peer Evaluator (3) | Seams with adjacent teams, disagreement, credit | Medium. Likely if the final includes a cross-functional partner | Propose principles for the seam; describe how you would decide disagreements |
| Values/Behavioral (2) | STAR-style stories | Low. No values round was detected, and Stripe's published values were not checked, so the pack does not assume one | Keep stories specific; say so when the material has none |
| Conversational (2) | Friendly openers that are still scored | Low to medium. Often the first two minutes of any round | Pre-script a 90-second arc; treat casual questions about the role as scored |

## Question banks

Every question carries `[generic]` provenance because no candidate sentences exist yet. Where guidance is a story map, the story is missing, so the guidance is a scaffold with an honest branch.

### A. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch checklist step was missed twice this quarter. Walk me through how you'd find out why and what you'd change." | CASE | [generic] | Clarify what the step is, who owns it and how often it fails. Map the process as it runs, not as documented. Look for ownership gaps. Pick one fix and one measure. | Tests the core diagnostic of process ownership (F1). CASE because it is a live problem with no past claim. |
| A2 | "Adoption of an internal tool is low across three teams. What do you do in the first two weeks?" | CASE | [generic] | Clarify what "low" means and which teams. Talk to users before proposing anything. Separate reach from usefulness. | Tests launch and coordination judgment (F3). Generic problem, so no claim about the candidate's past. |
| A3 | "What would you want to understand about how a company like this sets priorities across product, engineering and go-to-market?" | CO | [generic] | Name one specific question about process, not strategy, since no research ran. Say where you would look for the answer. | Tests homework depth at the process level. CO is tagged, but the pack has no company strategy to ground it, so the answer stays generic. |
| A4 | "Two teams disagree on a launch date and both say they're right. You don't own either team. What do you do?" | JD | [generic] | Find out what each team is optimizing for. Name who has the decision and on what evidence. Propose a decision date and the owner. | Tests influence without authority (F4) and the cross-team coordination the role presumes (F3). |

### B. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **Highest-ROI prep in this pack.** Pause, then name one area honestly. Describe how you would close the gap in the first 30 days: talk to the teams the process serves, read the existing docs, sit in the reviews. Hold a specific ramp plan rather than claiming speed. Follow-ups will ask for specifics, so name the one skill you would need first. Answer slot: if you have run a process like this before, name it and where you were weakest. If you have not, say so plainly and name the one skill you would need first. | This stem is the most likely objection because no background was given to check against. Rehearsing an honest weakness with a ramp plan converts the Skeptic's gotcha into a credibility point. |
| B2 | "Why this role, and why now?" | CO, EXP | [generic] | Two sentences on the work you want, tied to a concrete thing you would do. One thing you want to learn from the company. Answer slot: if you have wanted this kind of role for a reason from your own experience, name it. If not, say what drew you to it. | Motivation consistency is scored in every round. Without research, the company-specific part stays generic. |
| B3 | "What's the strongest reason a hiring manager should not pick you over someone with direct product ops experience?" | JD | [generic] | Concede the real advantage the other candidate has. Then give the one thing you would bring. Hold the second half through a follow-up; do not fold on it. | Tests honest self-assessment and the hold-then-concede structure. |
| B4 | "Tell me about a process you ran that did not work." | EXP | [generic] | Open prompt: choose a real instance. Say what you expected, what happened and what you changed. If none comes to mind, say so plainly, then describe the nearest one you have. | Probes whether the candidate can name a failure without spin. The story is the candidate's to choose. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which number would you put on a dashboard for a launch you ran, and how would you know it was counted correctly?" | EXP | [generic] | Name the metric type first, then how it is counted and what it is sensitive to. Answer slot: if you have a figure from past work, give it and how it was counted, in your own words. If you do not, say what you would track first and why. | Tests the metric judgment in F2. |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name the weakest assumption before it is asked. If you have no figure, say which assumption you would check first. | Converts a gotcha into a credibility gain. Follows C1. |
| C3 | "How would you know a process change worked, six weeks after it shipped?" | JD | [generic] | Name the outcome you expected and a leading indicator you would watch. Say what would make you roll it back. | Tests measurement of process change (F1, F2). |
| C4 | "Show me how you'd tell an accurate dashboard from a misleading one." | CASE | [generic] | Walk through one check you would run: definitions, denominators, the period. Name one way a clean-looking chart can mislead. | Tests metric literacy as a live problem. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause. Restate the question in one line. Give one specific reason tied to the job. Hold it through one follow-up before conceding anything. | Tests composure under a time box and a clear answer to a fair question. |
| D2 | "That result, how much of it was actually you?" | EXP | [generic] | Name your part in your own words, then what others did. Answer slot: if you have a result you are proud of, name your part. If the result was mostly others', say so plainly. | Tests attribution honesty under pressure. Hold the part that was yours; concede the part that was not. |
| D3 | "You have sixty seconds. What would you cut from your last project plan first?" | EXP | [generic] | Open prompt: choose a real plan. Name the one item you would cut and why, and what you would protect. | Tests prioritization under time pressure. |

### E. Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam, not a map you do not have. Describe how you would decide a disagreement: who decides, on what evidence, and how the losing side is told. | Tests partnership fit and disagreement style. Reciprocity: say what you would bring to the peer's team. |
| E2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Name what you did and what others did, in your own words. Name a habit you would keep. Answer slot: if you have a case where credit was shared, describe it honestly. If not, say how you would handle it. | Tests credit sharing and turf awareness. |
| E3 | "What would you need from my team to make this role work?" | JD | [generic] | Name two concrete needs, such as data access or decision rights. Do not name a need you cannot justify. | Tests whether the candidate sees dependencies. Peer-style reciprocity. |

### F. Values/Behavioral (weight 2)

No published values were checked, so these use the persona's stems as the theme. Treat them as generic until Stripe's own values are verified.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Open prompt: choose a real instance. Say what the truth was, who needed to hear it and how it landed. Use "we" for context and "I" for your contribution. If none comes to mind, say so plainly, then describe the nearest one. | Tests candor under scrutiny. Theme from the persona stem, not a company value. |
| F2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Open prompt. Name the metric you gave up, the customer effect and the outcome. If none comes to mind, say so plainly. | Tests customer judgment. Theme from the persona stem. |

### G. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | Pre-script a 90-second arc: the work you have done, the part that is most like this role, and why this role now. Build it from your CV. No story is supplied here. | Casual openers are scored. The arc has to be yours, and it cannot be drafted without your background. |
| G2 | "What are you actually playing with in product ops these days?" | JD | [generic] | Name one tool or practice you have used. Answer slot: if you have used one, name it and what it did. If not, name one you are learning and how. | Treat casual questions about the role's tools as scored. |

## Requirement coverage

| Role-family requirement | Question IDs |
|---|---|
| F1 Process design and ownership | A1, A4 |
| F2 Metrics and reporting | C1, C2, C4 |
| F3 Launch and cross-team coordination | A2, E1, E3 |
| F4 Prioritization and influence | A4, E2 |
| F5 Senior communication | D1, D2, D3, F1 |

These requirements are role-family prose, not a posting. The map will change when the JD arrives.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first 90 days look like for someone in this role?" | It shows you are planning the work, not the title. |
| R2 | "Which current process is the team least happy with, and what has already been tried?" | It surfaces real pain and gives you a ramp to plan. |
| R3 | "When product, engineering and finance disagree, who decides, and how is that decided?" | It tests decision rights, which decide whether the role can work. |
| R4 | "How are success measures for this role set, and who reviews them?" | It tests whether the role owns its metrics. |
| R5 | "What would make you say in six months that this hire was a clear success?" | It closes on criteria rather than adjectives. |
| R6 (if the interviewer is a peer) | "What could a new person do in their first month that would genuinely help your team?" | It converts the interview into a peer conversation. |

No interviewer profile was supplied, so no reverse question ties to the interviewer's own path.

## Sources

- **Provided documents:** your note only (company, role, final round).
- **Research tier:** L0. The web search tool was refused permission, so no search or fetch ran.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet dropped. The search "Stripe company values principles" was refused. Stripe's own values are not established here. |
| 2. Stripe interview process, product operations | unavailable | Loop structure unknown, so persona weights stay flat. The search "Stripe interview process product operations manager final round" was refused. |
| 3. Stripe strategy and recent news | unavailable | CO questions stay generic. The search "Stripe strategy recent news 2026" was refused. |
| 4. Interviewer name and Stripe | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative product operations JD | unavailable | Requirements are role-family prose, not quoted. No search was sent for it, since the search tool was refused. |

## Upgrade menu

- **Job description text** → the five role-family rows become quoted `[grounded]` rows, the coverage map becomes exact, and any gate rows appear.
- **CV or a few bullets on your background** → the evidence cells fill with your own sentences, the scaffolds become story maps, and B1 gets the objection your background actually raises.
- **Round type and who you are meeting** (hiring manager, peer, panel, cross-functional partner; one session or several) → the persona weights and reverse questions get reweighted from flat.
- **Any focus areas or take-home from the recruiter** → a graded-deliverable section.
- **Interviewer's name** → a tailored reverse question and persona weights from their public footprint. Needs research permission.
- **Research permission** → Stripe's values, interview process and strategy, which would add a values cheat sheet, loop structure and a grounding brief.
- **Prep time available** → a prioritized triage schedule.
- **A `tuesday-dossier.md`, if you have one** → verified evidence and prohibited claims from a prior review, which would sharpen the pack.
