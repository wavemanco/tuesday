# Interview pack: Senior Partnerships Manager, Kelverton Rail

Second round, Tuesday. Panel: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes: a 15-minute spoken POV with no slides, then Q&A where Ross presses on commercials.

Built on: your message and the recruiter's words as you quoted them. No JD text, no market report text, no research run. Pack depth is therefore thinner than a JD-backed pack; the upgrade menu says what closes that.

## 1. How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored: JD, EXP, CO, CASE, VAL.
- Guidance is scaffolding, not a script. Say it in your own words.

## 2. Prep triage (about 4 hours)

1. **The POV (D1):** build it, then speak it aloud twice, timed to 15 minutes. About 90 minutes.
2. **Ross's commercial bank (C1 to C5):** drill C3 and C2 until the weakest-assumption move comes without notes. About 75 minutes.
3. **Plain acknowledgments (B1, C2):** say "I haven't sold into rail" and "I haven't carried a direct quota" aloud until they are flat, not apologetic. About 20 minutes.
4. **Reverse questions:** pick three from section 8. About 15 minutes.

Everything else is insurance.

## 3. Fit snapshot

Requirement sources: the recruiter's own words, quoted from your message, marked [grounded]. Role-family requirements with no source are [generic].

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Please land on what it means for the operators themselves." (recruiter, your message) | "so I know the operator world from the other side" (your message) | medium | [grounded] | transferability | Your material puts you on the operator side of bus and light rail network planning. It does not show you inside a rail operator's commercial decisions. Words: "I know the operator world from the other side." Answer slot: if you have been in an operator's commercial or procurement conversation, say what it was in your own words; if not, say so plainly and say how you would learn it. |
| F2 | "Ross will push on commercials." (recruiter, your message) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Your figures are partner count and influenced revenue in payments, not rail operator revenue. Words: "I took it from 6 partners to 40." Keep "influenced" in any sentence about the £4M. Answer slot: how influence was counted and which part was yours, in your own words. |
| F3 | Owning a direct revenue target (role-family, [generic]) | "never carried a direct quota, only influenced revenue" (your message) | none | [grounded] | capability | You stated the absence. Words: "I haven't carried a direct quota." Then how you would build a forecast, as a plan and never as a past. |
| F4 | Rail or transport buyer sales experience (role-family, [generic]) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | You stated the absence. Words: "I haven't sold into rail." Then how you would learn the buyer, as a plan. |
| F5 | Operator contracting and pricing (role-family, [generic]) | none given | none | [generic] | discovery | Your material does not show operator contract or pricing work. Answer slot: if you have priced or negotiated with a buyer whose budget was set elsewhere, say how; if not, say so and say how you would test it. |

Reading the gap types: F1 and F2 are adjacent work that does not reach rail commercials. F3 and F4 are absences you stated, so they get plain acknowledgments, not bridges. F5 is silence, so it gets an answer slot.

## 4. Prohibited claims

Coached nowhere in this pack, including in drills.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've sold into rail" or "I know how rail buyers decide" | Negative you stated (F4) | "I haven't sold into rail." |
| "I carried a quota" or "I hit a target" | Negative you stated (F3) | "I haven't carried a direct quota." |
| "I generated £4M" or "I drove £4M of revenue" | Inflated form of F2 | "roughly £4M of influenced revenue," at its own scope. The limit is this pack's observation: your material says influenced, not closed. |
| "I know how operators buy" | Inflated form of F1 | "I know the operator world from the other side," at network-planning scope |

## 5. Interviewer read

Dropped: no public profile was supplied for Deepa or Ross. The only interviewer signal is the recruiter's line "Ross will push on commercials." It is used as the raising source for Ross's bank.

## 6. Persona table

| Interviewer | Persona | Weight | Why | Counter-strategy |
|---|---|---|---|---|
| Deepa | Case/Strategist | High, 3 questions | A hiring manager buys capability and tests the 18-month plan on her own roadmap | Clarify, then objective, segmentation, approach, metrics |
| Deepa | Skeptic | Mid, 2 questions | She owns the hire's gaps (F3, F4, F5) | Plain acknowledgment, then a concrete ramp plan |
| Ross | Pressure | High, 3 questions | A commercial director tests composure under a commercial challenge | Pause, restate, hold through two follow-ups, concede specifically |
| Ross | Data-Driven Prober | Mid, 2 questions | His commercials turn your £4M into a question about assumptions | Name the weakest assumption before he does |
| Both | Conversational | Low, 1 question | The opener is still scored | A 90-second arc from your own sentences |

Total: 11 questions. Below the usual 18 because no JD was supplied. The upgrade menu says what closes the gap.

## 7. Question banks

Provenance is the first thing you check. A guidance cell may say only what its quoted sentence says.

### Deepa, Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Where would you start with our operator partnerships in the first 90 days?" | CASE | [generic] | Clarify first: which operators matter most, what they are measured on, what the current partnerships deliver. Then objective, segmentation, approach, metrics. Name one premise you would test. Makes no claim about your past. | The hiring manager's standard live problem. No past claim. |
| A2 | "Which two operators would you call in your first week, and what would you ask them?" | CASE | [generic] | Name criteria for choosing them before naming them. Your questions should be about the operator's year, not your product. | Tests the operator-first thesis from D1 in a live setting. |
| A3 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" (your message); "so I know the operator world from the other side" (your message) | A 90-second arc: partnerships, then the payments ISV channel with its scale at the stated figures, then transport consulting on the operator side. Ends on why operators and rail now. Use only these sentences. | The opener is scored. Every claim in the arc is one of your own sentences. |
| A4 | "What would you need to believe about an operator's year for this plan to work?" | CO | [generic] | Name two beliefs and how you would test each. Do not claim operator data you do not have. | Probes whether the POV rests on assumptions the candidate can name. |

### Deepa, Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail. What would you be weakest at on day one?" | EXP | [grounded] "Never sold into rail specifically" (your message) | **Highest-ROI prep.** Plain acknowledgment: "I haven't sold into rail." Then F1's sentence at its own scope: "I know the operator world from the other side." Then a plan, not a past: the two or three buyers you would learn from first and what you would ask them. Answer slot: if you have sold to a transport buyer, say how in your own words; if not, say so plainly. Hold through two follow-ups by returning to the acknowledgment and the plan. | This is the most predictable objection. Rehearse it until it is boring. |
| B2 | "Which part of the POV would you not stake your name on yet?" | JD | [generic] | Name the one assumption you have not tested. Say what evidence would change your mind. Do not promise a result. | A self-assessment probe. Honest limits score well here. |
| B3 | "What would make you say no to an operator partnership?" | CASE | [generic] | Name the criteria, with at least one commercial gate, such as no free pilot work without a sponsor and a budget owner. | Tests whether the candidate can decline, which a partnerships role has to do. |

### Ross, Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why would an operator pay for this when they already run their own planning?" | CO | [generic] | Hold the position: name what an unplanned change costs the operator, in terms they would recognise. Do not add a figure. Concede specifically what you cannot yet show. | Pressure stem with no past claim. |
| C2 | "You've never carried a quota. Why should I trust your forecast for an operator pipeline?" | JD | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Plain acknowledgment: "I haven't carried a direct quota." Then the forecast as a plan: stages, what you would measure, what you would report. Hold through two follow-ups; concede uncertainty on the first forecast, not on the method. | The premise is your own stated negative. The hold is a plan, not a record. |
| C4 | "What does a rail operator's commercial model look like: who pays, on what terms, and what does the operator get?" | CO | [generic] | Say how you would test it: who signs, which budget, which contract cycle. F5 applies: say you have not priced operator contracts, and how you would learn. Answer slot. | Live commercial probe. The gap is F5, so the answer is a method, not a claim. |
| C5 | "A TOC says the budget is locked until the next contract cycle. What do you do?" | CASE | [generic] | Structure it: timing, what you can do before the budget opens (scope, sponsor, a pilot with a gate), and what you would not do (free work without a budget owner). | The recruiter named commercials. This scenario is the role's own. |

### Ross, Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C3 | "How was the £4M counted, and which assumption would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Name the figure in your own words. Weakest-assumption move: name the assumption behind it before he does. Answer slot: if you know how influence was counted, say how and what the number is sensitive to; if you do not, say so and say what you would check. Say which part was yours. | The defend-the-number slot. The pack supplies no counting method. An honest "I don't know how it was counted" is a valid branch. |
| C6 | "Where is the operator partnership plan most likely to be wrong?" | CO | [generic] | Name one risk and what would show it early. Do not pick a risk that is safe to name. | A prober's favourite. Shows judgment, not defence. |

Count: 11 questions. Coverage gap: with no JD, no JD-tagged question maps to a stated requirement. The upgrade menu fixes that.

## 8. Reverse questions

Each one has a reason it lands. There is no interviewer profile, so these are role-generic.

| # | Ask | To | Why it lands |
|---|---|---|---|
| R1 | "What has the operator partnership work delivered so far, and where has it stalled?" | Deepa | Shows you want the honest picture before you pitch. |
| R2 | "What would success look like at six months, on the commercial side specifically?" | Ross | Gives Ross a chance to state his bar, which you can then meet or push back on. |
| R3 | "How do operators usually decide to buy from a supplier like us, and who signs off?" | Ross | Tests your model of the buying process against his. |
| R4 | "Where do you think the operator plan is most likely to be wrong?" | Ross | Invites him to name the risk he already sees. |
| R5 | "What have people who held this role found hardest?" | Deepa | Points to the real difficulty and signals you plan to work with it. |

## 9. Graded deliverable: the 15-minute POV (D1)

Grounded facts: F1 and F2 above. Speak the POV, do not read it. Choose two of the three theses below and build around them.

- **T1, operators buy outcomes they are measured on, not licences.** Start from what the operator is measured on, then partner around that. **Mandatory concession:** operator budgets follow their contracts with government, so a correct pitch can still wait a cycle.
- **T2, the partner model is the lever.** Reach operators through the suppliers and integrators around them, not only by direct selling. Your evidence is the sentence "running the ISV channel," at its own scope. **Mandatory concession:** a payments channel model may not transfer to a small set of rail buyers with long relationships. Say so before someone else does.
- **T3, anti-pick: fewer partners, not more.** The consensus answer is to add partners. Say which partner you would drop first and why. **Mandatory concession:** pruning costs a near-term number, and you should name that cost.

**Differentiation:** the consensus answer is to grow partner count and sell reliability. Your departure is to start from what operators are measured on, and to say which partner you would drop. The market report would sharpen this, but its text was not supplied, so this differentiation is generic until it is.

**Close (what it means for operators):** one sentence in your own words, of the form "For an operator, this means ___." Do not pre-write a number for the blank.

## 10. Coverage line

| Stated item | Covered by |
|---|---|
| Operators' interests (recruiter) | A1, A2, C5, R4 |
| Commercials (recruiter, Ross) | C1 to C5, R2, R3 |
| Partnerships scale (your background) | A3, C3 |
| Direct revenue ownership (role-family) | C2, B1 |
| Rail buyer experience (role-family) | B1, C4 |
| JD requirements | None, and why: no JD text was supplied |

## 11. Sources

- Provided: your message, including the recruiter's lines you quoted and your background.
- Market report: described, not supplied. Not used.
- Research tier: L0. No searches, no fetches.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Values cheat sheet. Not triggered: no values round was detected. |
| 2. Kelverton Rail interview process | unavailable | Loop structure and persona weights. The panel is already known from your email. |
| 3. Kelverton Rail strategy and recent news | unavailable | CO bank, and the differentiation in section 9. The market report would move this more. |
| 4. Deepa or Ross public footprint | unavailable | Interviewer read and tailored reverse questions. Names were given, so this target was not n/a. |
| 5. Representative Senior Partnerships Manager JD | unavailable | JD-tagged questions and [inferred] requirement rows. |

## 12. Upgrade menu

- JD text → the five requirement rows move from [generic] to [grounded], and about six JD-tagged questions get added.
- Market report key lines → the differentiation in section 9 stops being generic and can be checked against the consensus answer.
- Deepa's and Ross's public profiles → persona weights from their career pattern, and a tailored reverse question for each.
- Research run at L1 → current strategy and recent news for the CO bank, and the values cheat sheet if values come up.
- Your CV as a document → exact quotes replace your message as the evidence, and F1 and F2 get sharper bridges.
