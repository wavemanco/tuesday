# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be **hiring manager**; your note did not say, and the persona weights below follow from that assumption.
**Round:** one 60-minute session, format not confirmed.
**Built from:** the job description you pasted and your background note. No CV, no dossier, and no web research (see Sources).

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: VAL (values), EXP (your experience), JD (the listed role), CO (company knowledge), CASE (live problem).
- Guidance is scaffolding for a spoken answer, not a script. Rehearse the beats, not the sentences.
- Answer slots (instructions, not questions) say what to do when the material does not show something. Answer from your own experience, or say plainly it was not yours.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title's weekly content-drop calendar, over two years. Say it at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD asks for two titles at once, so expect a probe on it. If any of the second title's work was yours, say which and how; if none was, say so and say how you would learn that title's calendar. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your message says nothing about coordinating these teams, so the pack cannot show it. Answer slot: if you coordinated any of these teams on a drop, name them and the step you took; if you did not, say so, and say how you would set that coordination up. |
| F3 | "Own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [grounded] | discovery | Presenting figures touches the KPIs but does not show a post-event review or ownership of the KPIs. Answer slot: if you ran a post-event review, say what it covered and what it reported; if you only presented figures someone else produced, say so. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | transferability | Your material says you wrote the checklist and that QA still uses it. The JD asks you to manage it with QA. Say it at its own scope: "I wrote the release checklist our QA team still uses." Answer slot: if you ran a release with QA against that checklist, say how; if not, say so. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message); "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | presentation | Four years, with a weekly content-drop calendar. Your material does not say the puzzle game was live-service, though weekly drops suggest it. Say the two sentences as they stand. Do not add a claim about the game's model. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | Your quote reaches the requirement in its own terms. This is your strongest match. Limit: one title. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the metric but shows presenting, not analysis. Say only: "I presented the monthly retention numbers to the studio head." The how-counted probe is in bank C. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [grounded] | presentation | One written artifact, used by another team. Say it as written. Do not claim other writing you have not described. |
| F9 | Not in the JD: experience with in-app purchases (your message) | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan, never as a past. |
| F10 | Not in the JD: leading people (your message) | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't led a team." Then how you would work across teams without line authority, said as a plan. Do not describe a past you did not have. |
| F11 | Not in the JD: mobile live-ops tooling | none given | none | [grounded] | discovery | Your message names no tooling. Answer slot: if you used a live-ops tool or dashboard on your title, name it and what you used it for; if you did not, say so. |

Confidence grades your evidence. Provenance grades what this pack wrote. "Not in the JD" rows come from your own gap list, not from the posting.

## Prohibited claims

Built locally from the snapshot. Each entry is a stretched form of a sentence you did say, or a negative you stated. No guidance below asserts any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events for two titles | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title for the last two years." Your material says one title. |
| Owned the KPIs the team reports | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." Presenting is not owning. |
| Managed the release process with QA | Inflated form of F4 | "I wrote the release checklist our QA team still uses." |
| Led a team, or managed people | Negative you stated (F10) | "I haven't led a team." |
| Shipped or worked on a title with in-app purchases | Negative you stated (F9) | "I haven't worked on a game with in-app purchases." |

## Persona table

Starting weights are the hiring-manager prior: they are buying capability and checking the gaps. Interviewer signals are absent, because the interviewer read needs public information that this run could not fetch. Values-style round: not detected, since no loop source was read.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the two-title gap, the leadership gap and the IAP gap | High. The hiring-manager prior plus three gaps you named yourself | Rehearse the one-title objection until it is plain. Hold to what you ran; concede specifically |
| Case / Strategist | Live problems on a live-ops calendar, a release clash, a retention drop | High. The hiring-manager prior, and the JD describes planning work | Clarify, then objective, approach, metrics, risks. Say your assumptions aloud |
| Data-Driven Prober | Asks how the retention figure was counted and what it is sensitive to | Medium. Retention is a stated requirement and your one metric line is on it | Say what you can and cannot say about how the figure was counted. Name the weakest assumption before they do |
| Pressure / Stress | Time-boxed challenges to your fit and your leadership gap | Medium. Your gaps are the likeliest targets | Pause, restate, hold a position through two follow-ups, then concede the specific limit |
| Conversational / Rapport | Opens with your journey; casual questions about live games | Low to medium. Often the first five minutes | Use a 90-second arc. Treat casual questions as scored |
| Values / Behavioral | One open behavioral prompt, if the round has one | Low. No values-style round is detected, so the bank holds two generic items | STAR-shaped stories from your own material; say where you have none |
| Peer Evaluator | Seam questions with adjacent teams | Not weighted. Only a peer or panel round would raise it | Left out of the bank. The upgrade menu asks whether a panel is planned |

## Question banks

Ordered by weight: Skeptic (4), Case (4), Prober (3), Pressure (3), Conversational (2), Values (2). Eighteen questions in total.

### A. Skeptic (weight 4)

**A1 is the highest-ROI prep in this pack.** The role runs two titles at once, and your material shows one. That objection is almost certain to come up in some form. Rehearse A1 until a non-defensive answer comes easily.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role runs live events for two titles at once. You've run a calendar for one. What would you do to cover the second?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say the one-title record at its scope, in those words. Hold through two follow-ups by returning to that record. Answer slot: if any of the second title's calendar was yours, say which and how; if none was, say so plainly and set out your plan to learn that title's cadence, its players and its team. The honest branch is a limit, not a confession | F1 is the requirement with the widest gap, and the premise here is the JD's own "two of our mobile titles" plus your quote. A JD line raises it, so the question is lawful |
| A2 | "Walk me through how the weekly content-drop calendar ran." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on the calendar: one title, weekly, two years. Describe what you did in your own words. Answer slot: the JD says "plan and run", so a probe on who set the drop schedule is likely. If you set it, say how you decided; if someone else set it, say so and what you did | F6 is your strongest match and this question tests it. EXP because it asks what you actually did |
| A3 | "On each update, who did you coordinate, and how?" | JD | [generic] | Name the teams you worked with on a drop, and the step you took to align them. Answer slot: if your work ran through one team, or none, say so plainly. Do not name teams you did not coordinate | F2 is a discovery gap. The JD's "coordinate design, art, engineering and community teams" raises the question, so it is asked; the guidance claims nothing about your past |
| A4 | "What's different about planning for a title with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Name two or three things you would check first (the monetization model, how an event moves spending, how you would read revenue against retention). Then say: "I haven't worked on a game with in-app purchases." Give the plan you would use to learn it | F9 is a stated gap. The plain acknowledgment is your own words; the guidance does not imply IAP work |

### B. Case / Strategist (weight 4)

Generic live problems. No claim about your past is made or implied.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Retention on one of your titles has slipped for four weeks. Plan the next six weeks of events." | CASE | [generic] | Clarify first: which segment, what the drop looks like, what has already shipped. Then objective, approach (events versus fixes), metrics, risks. Name one assumption aloud | Core live-ops problem for the role's calendar work |
| B2 | "Two titles each have a drop in the same week, and QA says one build is not ready. What do you do?" | CASE | [generic] | Clarify what the release checklist gates and who can move a date. Lay out the trade-off for each title. Name who decides and who you inform | Tests the JD's release-checklist and cross-team lines together |
| B3 | "A community post-mortem says players found an event confusing. How would you structure the review?" | JD | [generic] | Question, then evidence (what data, what sample, what counts as confusion), then owners and actions. Say what you would not conclude from one thread | Tests the post-event review the JD asks you to own. Not your past |
| B4 | "Retention went up after the drop, but spend went down. Which number do you trust, and why?" | CASE | [generic] | State the weakest assumption in the comparison (the window, the cohort, the seasonality) before they do. Say what you would check first | A metric question that scores the reasoning, not a number |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Where did the monthly retention numbers you presented come from?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you calculated any of them, say how and from what. If you only presented figures someone else produced, say so, and say what you would check before trusting them | F7 is a presentation gap and the number is the probe's target. The question is premised on your quote only |
| C2 | "Which assumption behind that retention figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Name the assumption in your own words before they do. If you cannot name one, say that plainly. Do not invent a method to fill the gap | Defend-the-number slot on a figure you gave. Converts a gotcha into a credibility point |
| C3 | "How would you measure whether a post-event review worked?" | JD | [generic] | Name two measures, a baseline, a time window, and how you would separate an event effect from seasonality | F3's gap. A method question, scored on reasoning. Nothing about your past is claimed |

### D. Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why hire someone with one title's calendar for two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the position that the calendar work is relevant, in your quote's words. Concede the specific limit: "I haven't run two titles." Hold through two follow-ups; do not fold on the relevance | The sharpest version of A1. Pressure scores whether you hold and concede specifically |
| D2 | "How much of the checklist QA uses was actually yours?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: you wrote it. Concede: QA runs it, and you say what part you did. Answer slot: if you ran release cycles with QA, say how; if not, say so | F4's bridge under probe. Tests attribution, not the artifact |
| D3 | "You're a producer, not a leader. Why should I trust you to coordinate four teams?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Hold the difference between coordinating and line-managing. Concede: "I haven't led a team." Describe how you have worked across teams without line authority, only where your material shows it. Otherwise give the plan | F10 is a stated gap. The concession is your own words |

### E. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through how you got into live ops." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | 90-second arc: four years as an associate producer, the weekly content-drop calendar, the checklist, the monthly retention numbers. Each beat is a sentence you already said. End on the calendar | Opener scored for economy and fit. Every beat is one of your own sentences, so nothing is added |
| E2 | "What live game are you playing right now, and what would you change about how it runs its events?" | JD | [generic] | Name a game you know. Give one specific change and why. Do not name Saltmarsh's titles. The research that would let you do that did not run | Casual questions about the role's work are scored. A specific opinion beats a general one |

### F. Values / Behavioral (weight 2)

No values-style round detected, and no published values were available. These two are generic.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time you disagreed with a deadline or a decision. It needs a named stake, a moment you did not fold, and an intact working relationship after. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Persona stem from the values-behavioral pattern. No claim about your past is made |
| F2 | "How do you give feedback to a designer whose drop went badly?" | VAL | [generic] | Name the specific thing, the evidence, and what you asked them to change. Say what you would do if they disagreed. Use a real example only if you have one | Tests the coordination requirement in a conversational form |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A1, A2, B1, D1 |
| Coordinate design, art, engineering and community teams | A3, B2, F2 |
| Own the post-event review and the KPIs | B3, B4, C1, C3 |
| Manage the release checklist with QA | B2, D2 |
| 3+ years producing live-service games or apps | E1, D1 |
| Experience running a content calendar | A2, E1 |
| Comfortable with player-retention metrics | B4, C1, C2 |
| Clear written communication | none, and why: no question here tests written work, and the interview is mostly spoken. The upgrade menu asks for a writing sample you can discuss |

Not in the JD, but in your gap list: in-app purchases (A4, D3 via F10 context), leading people (D3, F1), two titles at once (A1, B2), mobile live-ops tooling (F11 has no question; it is an answer slot only).

## Reverse questions

Each one is a question for Tobias. No interviewer profile exists, so none is tied to his career path.

1. "What does a strong first ninety days look like for whoever takes this role?" Why it lands: it shows you are planning, and it gives you his priorities.
2. "How is the calendar split between the two titles right now, and what is the tightest constraint on each?" Why it lands: it engages the two-title problem directly.
3. "How are post-event reviews run today, and who owns the KPIs they report?" Why it lands: it checks the ownership line in the JD, which is where F3 is weakest.
4. "On a title day, how does the release checklist work with QA, and who signs off?" Why it lands: it shows you know the checklist is a shared process.
5. "Where do you expect this role to need the most support from the teams it coordinates?" Why it lands: it turns the coordination requirement into a conversation about where help is needed.
6. "What part of the job do you expect a new person to find hardest in the first six months?" Why it lands: it is honest, and his answer tells you what he is worried about.

## Sources

**Provided documents:** the job description, as pasted; your background note, as stated in your message. No CV was provided. No dossier was used.

**Searches and fetches:** this session refused web search permission on every call, so nothing about Saltmarsh Games or Tobias Wrenfield is established from the web. Every call below counted against the budget, refused calls included.

- "Saltmarsh Games values": refused
- "Saltmarsh Games interview process Live Operations Producer": refused
- "Saltmarsh Games mobile games news": refused
- "Tobias Wrenfield Saltmarsh Games": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet absent. Its call was refused |
| 2. Saltmarsh Games interview process | unavailable | Loop structure unknown. Persona weights rest on the hiring-manager prior, not on a documented loop. Call refused |
| 3. Saltmarsh Games strategy / news | unavailable | Company & strategy (CO) bank absent. Call refused |
| 4. Tobias Wrenfield Saltmarsh Games | unavailable | Interviewer read and tailored reverse questions absent. Call refused |
| 5. Representative JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

**Checks for you to run before Friday** (this pack did not search them):
- Saltmarsh's careers page and any published values or principles
- The store listings and patch notes for its two mobile titles, to see how often they run events and whether they are monetized
- Tobias's public profile, talks or posts, to see what he has written about live ops
- Interview-process reports for the company (treat them as leads, not facts)
- Any Saltmarsh news from the last six months

## Upgrade menu

- Your CV → the fit snapshot quotes your CV instead of your message, and a CV line can raise F2 and F3 from discovery.
- The recruiter's note on the round format and who you are meeting → persona weights and whether a panel changes the bank.
- Tobias's public profile or talks → the interviewer read and reverse questions written for his path. Needs web search permission, then a re-run.
- Saltmarsh's values page → the values cheat sheet and a VAL bank tied to published values.
- A writing sample you can discuss → covers the written-communication requirement.
- Any post-event review you ran, or KPI you owned, described in your own words → would upgrade F3 and the matching bank questions. Only if it happened.
- A deeper research pass, once web search is allowed: a strategy brief, interviewer talks, and recent org changes at Saltmarsh. Up to six more searches and two more fetches, several minutes.
