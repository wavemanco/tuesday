# Larkfield Systems — Engineering Manager: interview prep pack (three rounds)

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, ~600 people)
**Rounds:** (1) Tuesday — 45 min, Director of Engineering (hiring manager). (2) Thursday — 60 min panel, two staff engineers and a product manager. (3) Monday — 30 min, VP Engineering, "values and leadership philosophy."
**Interviewer names:** not given. Persona weights use round-type priors only.
**Changelog:** first version (loop mode).

## How to use + type key

Personas are how a question is asked. Types are what it scores. Guidance is scaffolding, not a script.

- **VAL**: behavioural and values alignment
- **EXP**: deep-dive into your own work
- **JD**: the role's stated responsibilities, including its gaps
- **CO**: company and strategy knowledge
- **CASE**: a live problem

Company research did not run: the web search was refused in this session. The pack has no company values, loop detail or strategy from outside sources. The loop comes from your message and the recruiter's words. CO questions are `[generic]`.

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description you sent | "9 years engineering, 3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your message gives a team of six, not two squads. Bridge: "For three years I've led a team of six." Answer slot: if you have split a group or run more than one team, say how, in your own words; if not, say so and say how you would divide two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" — role description you sent | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap on hiring, but a line with nothing inspected behind it, so expect a probe on the 40. Lead with the loop in your own terms: you run the backend hiring loop. |
| F3 | "own delivery, hiring and growth for 11 engineers" — role description you sent | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Your message shows reliability work under roadmap pressure, not ownership of delivery plans. Bridge: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you set the delivery plan or milestones, say which; if not, say so. |
| F4 | "growth" for 11 engineers — role description you sent | none given | none given | [grounded] | discovery | Your material does not show how you have grown engineers. Answer slot: say what you did to develop people, with examples in your own words; if you have not done it, say so and say how you would start. |
| F5 | "partner with hardware and product on roadmap" — role description you sent | "never owned a hardware-adjacent roadmap" — your message | high | [grounded] | capability | A gap you stated. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, as a plan, never as a past. |
| F6 | Managing managers (not in the role text; your own gap) — [generic] | "I've never managed managers" — your message | high | [grounded] | capability | A gap you stated. Words: "I haven't managed managers." Then how you would coach a manager, as a plan. |
| F7 | Location and on-site time (gate) — role description you sent | none given | none given | [grounded] | hard_gate | Your material does not establish where the role sits or how much on-site time it needs. Surfaced, not bridged. One question asks it. |

## Prohibited claims

These are not coached anywhere in the pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Sourced negative: "I've never managed managers" — your message | "I haven't managed managers." Plain acknowledgment, no slot. |
| Owned a hardware-adjacent roadmap | Sourced negative: "never owned a hardware-adjacent roadmap" — your message | "I haven't owned a hardware-adjacent roadmap." Plain acknowledgment, no slot. |
| Led eleven engineers across two squads | Inflated form of F1: "a team lead of 6" | "A team of six." The pack's observation: your material shows a team of six and no two-squad or eleven-person scope. |
| Designed the reliability quarter, or measured the 60% | Inflated form of F3: "I pushed a reliability quarter through" | Quote at its own scope: you pushed it through. The pack's observation: the material does not show designing it or how the 60% was measured. |
| Ran hiring for the company | Inflated form of F2: "I run our hiring loop for backend roles" | "Backend roles, about 40 interviews last year." |

## Persona weights by round

Round 1 (Director, hiring manager): relationship prior is Case/Strategist and Skeptic. No interviewer signals exist, so the weights stay at the prior. The Skeptic is weighted up because F5 and F6 are the headline gaps.

Round 2 (panel): the rule is to blend the top two personas of each member's relationship. Staff engineers: Prober and Pressure. Product manager: Peer Evaluator and Case. Member names are not known, so personas cannot be assigned per member.

Round 3 (VP Engineering): the recruiter's words "values and leadership philosophy" name a values-style round, so Values/Behavioural is guaranteed. The skip-level prior adds Case (strategy-heavy) and Pressure. No values page was fetched, so the values cheat sheet is dropped.

| Round | Persona | Weight | How it shows up | Counter-strategy |
|---|---|---|---|---|
| 1 | Case/Strategist | heaviest | live problems on the two-squad roadmap | clarify, then structure, then name a plan |
| 1 | Skeptic | high | F5 and F6 probed directly | plain acknowledgment, then the plan |
| 1 | Pressure | low | time-boxed challenge on managers | hold through two follow-ups, then concede precisely |
| 1 | Conversational | low | the opener, "walk me through the journey" | 90-second arc from quoted sentences |
| 2 | Data-Driven Prober | heaviest | the 60% and the 40 interviews, to the denominator | name the weakest assumption before they do |
| 2 | Peer Evaluator | high | seam between squads and product | propose seam principles, not a map you do not have |
| 2 | Pressure | medium | the fleet cannot deliver the roadmap | hold a position you can carry, concede specifics |
| 2 | Case | low | backlog prioritisation with hardware blocking | structure, name the trade-off |
| 3 | Values/Behavioural | heaviest | "values and leadership philosophy" | selection scaffold; honest branch where no story |
| 3 | Case/Strategist (strategy-heavy) | medium | first moves for two squads | structure, name what you would not do |
| 3 | Pressure | medium | reliability versus roadmap, from the top | hold the criteria, concede uncertainty |
| 3 | Skeptic | low | managing managers | plain acknowledgment, then the plan |

## Question banks

### Round 1: Tuesday, Director of Engineering (hiring manager), 45 min

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6"; "I run our hiring loop for backend roles — about 40 interviews last year." | 90-second arc: nine years of engineering, three leading a team of six, then the backend hiring loop, each beat the quoted sentence states. Answer slot: why this role and why now, in your own words; no quoted sentence gives your reasons. | F1 and F2 carry the arc. Motivation is not in any quote, so it is a slot. |
| A2 | "Sixty seconds: how would you approach your first ninety days running two squads on device-management services?" | CASE | [grounded] "Lead two squads building device-management services" — role description you sent | Clarify, then objective, then approach, then risks. Ask first: what each squad owns, what is in flight, which hardware dependencies exist. Give a plan, not a past. | Case persona. This is the role's first live problem; F1 is the scope it tests. |
| A3 | "You've never owned a hardware-adjacent roadmap. On day one, where are you weakest?" | JD | [grounded] "never owned a hardware-adjacent roadmap" — your message | Say: "I haven't owned a hardware-adjacent roadmap." Then how you would close it, as a plan: whom you would learn from and what you would ask hardware first. Hold through two follow-ups by returning to the plan. **Highest-ROI prep in this pack:** F5 is the gap this round will test, and a plain, non-defensive answer changes the round. | Skeptic, deepest rehearsal. The hardware roadmap is the role's headline gap. |
| A4 | "Eleven engineers across two squads — you've led six. What's the difference?" | JD | [grounded] "3 as a team lead of 6" — your message | "I've led a team of six for three years." Then scaling. Answer slot: if you have split a group or run more than one team, say how, in your own words; if not, say so and say how you would divide two squads. | F1: the stated scope is six, not eleven across two squads. |
| A5 | "Your squads and hardware disagree on a device-release date. How do you decide?" | CASE | [grounded] "partner with hardware and product on roadmap" — role description you sent | Clarify the decision and who owns it. Name the trade-off, the evidence you would want, and what you would escalate. | Case persona. Cross-functional partnership is the scored content. |
| A6 | "Sixty seconds: why you over someone who has managed managers?" | JD | [grounded] "I've never managed managers" — your message | Pause, then restate the question. Hold the position you can carry: three years leading a team of six, and the reliability record. Say it once. Then concede precisely: "I haven't managed managers." Hold through two follow-ups; never fold on the team-lead claim. | Pressure. The hold rests on F1 and F3 at their own scope only. |
| A7 | "Walk me through how the on-call number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | State the 60%, the quarter and the pressure in your words. Weakest-assumption move: name the assumption behind the 60% you would defend least, before they do. Answer slot: if you measured it, say what and how; if you did not, say so plainly. | Defend-the-number slot. F3 is your strongest credential, and the probe is on the counting. |
| A8 | "What would you do about hiring and growth for eleven engineers?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." — your message | Hiring, from the quote: "I run the backend hiring loop; about 40 interviews last year." Growth: answer slot. Say how you have grown engineers, with examples from your material; if you have not, say so and say how you would start. | F2 covers hiring. Growth is `discovery` (F4), so it stays a slot. |

### Round 2: Thursday, panel of two staff engineers and a product manager, 60 min

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What was that 60% measured against?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Answer slot: if you know the denominator, pages, incidents or engineers, say it and where it came from; if not, say so plainly. Weakest-assumption move, as in A7. | Prober. The denominator is where a headline number breaks. |
| B2 | "Which part of that reliability quarter did you set, and which part came from elsewhere?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" — your message | Answer slot: say what you decided and how. If the quarter's scope came from elsewhere, say so and describe what you did push through. Never describe a design you did not make. | Prober. F3: the quote says pushed through, not designed. |
| B3 | "The device fleet can't do what the roadmap promises. You're the manager. What do you say?" | CASE | [generic] | Structure: the evidence you need from hardware, what you would commit to and what you would not, how you would tell product. Hold: no date without evidence. Concede what you do not know about the fleet. | Pressure with case content. No claim about your past. |
| B4 | "Where's the seam between your squads and product, and what happens when we disagree?" | JD | [grounded] "partner with hardware and product on roadmap" — role description you sent | Reciprocity framing: what you bring to the product team, not only what you need. Propose seam principles rather than pretending to know the seam. | Peer Evaluator. The collegial version of A5. |
| B5 | "How have you handled roadmap pressure from product?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" — your message | Story map: the reliability quarter, against roadmap pressure, using the beats the sentence states. Answer slot: what you traded and who agreed; if no trade was made, say so and describe the decision you did make. | Peer Evaluator. Reuses F3 at its own scope. |
| B6 | "Device onboarding is backlogged, and hardware blocks half of it. How would you prioritise?" | CASE | [grounded] "partner with hardware and product on roadmap" — role description you sent | Clarify, objective, segment blocked from unblocked, approach, metrics, risks. | Case persona from the product manager. |
| B7 | "What signal did you track across the 40 interviews, and how did you calibrate panels?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." — your message | Answer slot: say which signal you tracked, if you tracked one; if not, say so. | Prober on the hiring claim. F2 is medium-confidence and has nothing inspected behind it. |
| B8 | "Tell us about the last time you disagreed with product." | JD | [grounded] "partner with hardware and product on roadmap" — role description you sent (raising source only; no claim about you) | Open prompt. Selection scaffold: pick a disagreement with a named stake and a decision you can describe. If none comes to mind, say so, then give the nearest one your material carries — the reliability quarter, in its own words. | Peer Evaluator. The theme comes from the role text. |

### Round 3: Monday, VP Engineering, 30 min, "values and leadership philosophy"

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" — your message (nearest story only) | Selection scaffold: pick a time you held a position under pressure from someone senior, with a named stake. Story map from the quote: the quarter and the pressure. Answer slot: the moment you did not fold and whether the relationship held; if you cannot say, say so. If no such time comes to mind, say so plainly, then give the nearest one. | Open prompt. The theme comes from the recruiter's "values and leadership philosophy." |
| C2 | "What's your leadership philosophy, in a paragraph?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6" — your message | Answer slot: your philosophy, in your own words. Your material gives the years and the team size, not a philosophy. Do not borrow a generic one. | Open prompt. Theme from the recruiter's phrase. |
| C3 | "Two squads, eleven engineers, a device platform. What are your first three moves, and what would you not do?" | CASE | [generic] | Clarify first, then three moves, then one thing you would not do and why. | VP case. CO is generic: no strategy research ran. |
| C4 | "You've never managed managers. A manager reporting to you is struggling. What do you do?" | JD | [grounded] "I've never managed managers" — your message | Plain acknowledgment: "I haven't managed managers." Then the plan: what you would coach first and what you would escalate, as a plan. | Skeptic. F6 gap. |
| C5 | "If I force a choice from the top, reliability or the roadmap commitment: which wins?" | CASE | [grounded] "I pushed a reliability quarter through against roadmap pressure" — your message | Hold the position you can carry: name the criteria — stake, evidence, reversibility. Hold through two follow-ups. Concede uncertainty specifically. Never fold to restore harmony. | Pressure. The hold rests only on the quote's scope. |
| C6 | "What's a hire you got wrong, and what did you change?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." — your message | Answer slot: if a hire went wrong, name what you changed in the loop; if none did, say so. | Values by behaviour, on hiring. No quote shows a wrong hire. |
| C7 | "How do you know your team is growing?" | VAL | [grounded] "own delivery, hiring and growth for 11 engineers" — role description you sent (raising source only) | Answer slot: how you have grown people, in your own words; if you have not, say so and say how you would measure growth. | F4 is `discovery`. Growth is in the role text, not in your message. |
| C8 | "A squad lead says your decision was wrong. What happens next?" | VAL | [generic] | Structure: listen, check the facts, decide, record. Say what you would reverse and what you would not. | Values-style, generic. Tests judgement under challenge. |

Requirement-coverage line:

- Lead two squads: A2, A4, C3
- Device-management services: A2
- Own delivery: A7, B1, B2, C5
- Hiring: A8, B7, C6
- Growth for 11 engineers: A8, C7 (F4 is `discovery`)
- Partner with hardware: A2, A5, B3, B6
- Partner with product on roadmap: A5, B4, B5, B8
- Managing managers (your gap, not in the role text): A6, C4

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would the first ninety days look like for someone new to hardware-adjacent roadmaps?" | Turns A3 into a planning conversation and shows you scope before you answer. |
| R2 | "How are the two squads' backlogs split today, and where does hardware sit in them?" | Asks for the facts behind A2 and A5. |
| R3 | "What could a new manager do in the first month that would genuinely help your teams?" | Reciprocity for the panel. The product manager and staff engineers are peers. |
| R4 | "Where are device-management decisions made between firmware, cloud and product?" | The seam question B4 needs. |
| R5 | "How does this organisation judge whether a reliability quarter was worth it?" | Connects to F3 without claiming how the 60% was counted. |
| R6 | "What would you be disappointed to see missed in the first year?" | Asks for their leadership philosophy in their own terms. |

No interviewer profile exists, so no reverse question is tailored to an interviewer's own path.

## Sources

Provided documents:

- Your message: the role description and your background.

Research. Search queries sent: 3. All were refused, because search permission was not granted in this session.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Values cheat sheet, which is dropped (no published values in hand). Query refused. |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Loop structure. The loop is set by your message and the recruiter's words, so no archetype fallback was needed. Query refused. |
| 3. `Larkfield Systems strategy news industrial IoT device management` | unavailable | CO questions would have been sourced. They are `[generic]` instead. Query refused. |
| 4. Interviewer name and Larkfield | n/a | No interviewer name was given. |
| 5. Representative engineering manager JD | unavailable | No search was sent, because search could not run. Would have sourced role-family requirements. |

## Upgrade menu

- The posting or role text in full → F1–F5 become `[grounded]` requirement lines, and the `[generic]` rows A2, B3, C3 and C8 take sourced requirements.
- The Director's name → round 1 persona weights and a reverse question tied to their career path.
- The two staff engineers' and the product manager's names → per-member persona assignment for round 2.
- The VP's name → round 3 persona weights and a tailored reverse question.
- The recruiter's note on any declared take-home or presentation → graded-deliverable sections.
- A pasted Larkfield values page → the values cheat sheet for round 3, and VAL questions can name the values.
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a company strategy brief for CO questions, and loop reports for this role family. Want it?
- Your on-site and location answer → F7 is settled either way.
