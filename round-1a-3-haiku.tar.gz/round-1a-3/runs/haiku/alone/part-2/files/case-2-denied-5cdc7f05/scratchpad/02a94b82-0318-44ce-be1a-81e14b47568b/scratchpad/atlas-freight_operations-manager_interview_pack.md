# Interview prep pack: Operations Manager, Atlas Freight

Round: assumed hiring-manager round (your note didn't say who you're meeting). Interviewer: not known. Research tier: L0 (your documents only; see Sources).

## How to use this pack

- **Personas** describe how a question arrives (friendly, skeptical, numbers-first, under pressure). **Types** describe what is being scored.
- Type key: **JD** = stated responsibility or qualification; **EXP** = a claim on your CV or message, probed for what you actually did; **CASE** = a live problem from the role; **VAL** = behavioural, scored on past decisions; **CO** = company knowledge (not covered here, because no company research ran).
- Guidance is scaffolding, not a script. Say it in your own words.
- Each guidance cell is built from your own sentences, quoted in the Provenance column. Where a sentence doesn't carry an answer, the cell gives an **answer slot**: an instruction to answer from your experience, or to say plainly that the practice wasn't yours.

## Fit snapshot

Your sentences are quoted verbatim. "your message" means the background you typed for this prep; "JD" means the requirement text you pasted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" (your message); "ran the site's peak-season surge plan two years running" (your message) | low | [grounded] | discovery | Your material says "the site's", singular, and does not say how many sites you have run. Answer slot: if you have been accountable for daily operations at more than one site, say which and how; if you have run one, say so and describe what you carried day to day. |
| F2 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows leadership of three supervisors, not twelve. Words: "I'm currently a senior shift manager over three supervisors." The scope gap is the pack's observation, not something to argue away. Answer slot: if you have led more than three supervisors at once, say how many and in what role; if you haven't, say so and describe how you would structure a layer of twelve. |
| F3 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | low | [grounded] | transferability | Seven years is operations time; the material does not show how many of those years involved leading people. Answer slot: if you can give the years you have led people, give the number in your own words; if you can't separate them, say so and name the roles you held and when. |
| F4 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows accuracy, not on-time performance or cost per shipment. Words: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you have tracked on-time performance or cost per shipment, say which and how it was counted; if you haven't, say so and say what you would measure first. |
| F5 | "build reporting in Excel/Power BI" (JD), Excel part | "solid Excel" (your message) | low | [grounded] | discovery | Your sentence rates your Excel skill; it does not show a report built. Words: "I'm solid in Excel." Answer slot: if you have built a report or tracker in Excel, say what it tracked and who read it; if you haven't, say so. |
| F6 | "build reporting in Excel/Power BI" (JD), Power BI part | "never used Power BI" (your message) | none | [grounded] | capability | You stated the absence, so the words are yours: "I haven't used Power BI." Then how you would learn it, as a plan, never as a past. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The credential reaches the requirement directly. Words: "I'm Green Belt certified." It is a claim on paper, not yet shown; bring the certificate. |

**Gate check.** The JD you pasted names no location, schedule or travel term, so no gate row is written. If the full posting names one, send it and the snapshot is rebuilt.

**Requirement coverage**

| JD requirement | Question IDs | Note |
|---|---|---|
| Own daily terminal operations across 4 sites | A3, B1, D3 | |
| Drive on-time performance and cost-per-shipment down | B1, B2, C2 | |
| Lead a team of 12 supervisors | A1, D2 | |
| Build reporting in Excel/Power BI | B4, C3, E2 | |
| 5+ years operations leadership required | A2 | |
| Lean/Six Sigma a plus | none, and why | Stated credential in F7; no question needed to surface it. A4 carries it in your own words. |

## Prohibited list

Claims this pack will not coach, each with its basis and honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operations across four sites | Inflated form of F1 | "the site's" peak-season plan, at its own scope. The pack's observation: your material does not show more than one site. |
| Led twelve supervisors | Inflated form of F2 | "a senior shift manager over 3 supervisors" |
| Drove on-time performance or cost per shipment down | Inflated form of F4 | "cut mis-pick rate 40% by redesigning the pick path" |
| Five years of operations leadership | Inflated form of F3 | seven years in operations; the leadership years are an answer slot |
| Any Power BI experience or dashboards | Negative you stated, F6 | "I haven't used Power BI." No slot. |

## Persona weights

No interviewer profile and no round type were given, so weights use the hiring-manager prior, with the JD's scope and metrics as the signal.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the scope gap (3 supervisors vs 12, one site vs four) | High (4 questions). Hiring managers buy capability and derisk gaps; F2 and F1 are the most visible gaps. | Rehearse the single most predictable objection until it is plain. Bridge only from what you stated, and say the limit yourself. |
| Case / Strategist | Live ops problems: on-time performance across four sites, cost per shipment, peak planning | High (4 questions). The JD is an operations scoring sheet, so expect live problems. | Clarify, segment, name hypotheses, then metrics. Name your weakest assumption. |
| Data-Driven Prober | Asks how the 40% was counted, and what Excel reporting exists | Medium (3). The 40% and the reporting line are the numbers they'll test. | Know what you can say about how each figure was counted, and say plainly when you don't know. |
| Pressure / Stress | Time-boxed challenges on leadership scope and attribution | Medium (3). Senior ops roles test composure under challenge. | Pause, restate, hold a position through two follow-ups, concede only what you cannot separate. |
| Conversational | Casual openers, a "walk me through" and a Power BI aside | Low (2). Casual questions are still scored. | Keep a 90-second arc ready. Give the Power BI answer in one plain sentence. |
| Values / Behavioural | Unpopular news, customer vs internal metric | Low (2). No published values were checked, so these are generic behavioural stems. | Choose a real decision, with a stake and an outcome. If none, say so and use the nearest thing you did. |
| Peer | Seam questions between teams, credit sharing | Low (2). Weight rises if the interviewer is a peer ops manager. | Propose seam principles rather than pretending to know their site. |

## Question banks

Question IDs are letter-by-persona. Provenance is the first column of guidance, so you can see what each answer rests on.

### A. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're a senior shift manager over three supervisors, and this role leads twelve. What makes you ready for that step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message); JD "lead a team of 12 supervisors" | **Highest-ROI prep in this pack.** Start with the number you have, in your words: "I'm currently a senior shift manager over three supervisors." Then the scope change: how you would structure a layer of twelve, what you would delegate, how you would check in. Answer slot: if you have led more than three supervisors at once, say how many and in what role; if you haven't, say so and go to the structure. Hold the structure through two follow-ups. Do not claim experience at twelve. | F2 is the largest visible gap against a headline requirement, so this is the objection most likely to come up in some form. |
| A2 | "The role asks for five-plus years of operations leadership. How many of your years have been leadership, not just operations?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message) | Give the operations figure first, in those words: seven years in warehouse and distribution ops. Then the leadership figure, in your own words. Answer slot: if you can separate the two, give the number; if you cannot, say so, and name the roles you held and when. | F3 is transferability: the years are real, but the leadership span is unshown. The question scores the requirement as written. |
| A3 | "Four sites, daily terminal operations. What would be the hardest part of that for you on day one, and why?" | JD | [grounded] JD "Own daily terminal operations across 4 sites" | Answer with the mechanism, not a claim: how you would learn each site's daily rhythm in the first month, what you would standardise, what you would leave to site leads. Answer slot: if you have run daily operations across more than one site, say which and how; if you have run one, say so and answer with the plan. Hold the plan, not a claim to a network you haven't run. | F1 is discovery: the evidence may exist, and the material does not show it. The question is open, so it chooses no past event. |
| A4 | "Sixty seconds: why you rather than an internal candidate?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message); "ran the site's peak-season surge plan two years running" (your message); "green belt certified" (your message) | Three parts. What you have run, in the sentences you gave. What that does for this role. The gap you would close first, which is scope: name it yourself in the first thirty seconds. Hold the scope you have run, and don't stretch it. | The Skeptic's central stem. F2 and F1 are where the answer has to be honest. |

### B. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance is slipping across the four sites. Walk me through how you would diagnose it in the first two weeks." | CASE, JD | [generic] pattern for an ops role; JD "drive on-time performance and cost-per-shipment down" | Clarify first: what counts as on time, which sites, which shifts, what the cut-off is. Then segment: by site, shift, lane, carrier and time window. Name two hypotheses and the data you would check first. Ask for the one thing that would rule out the most. Speakable in about 90 seconds. | The role's core metric as a live problem. No claim about your past, so the guidance makes none. |
| B2 | "Cost per shipment is rising while volume is flat. What do you look at first?" | CASE, JD | [generic] pattern for an ops role; JD "cost-per-shipment down" | Decompose cost per shipment: labour hours per unit, overtime and temp share, rework, handling time, and fuel or linehaul if in scope. Say what you would check before changing anything. Name the weakest assumption in your own decomposition. | JD cost requirement, scored as structure. Your cost experience is not in the material, so the guidance claims none. |
| B3 | "Walk me through how you would plan a peak season across four sites, using the surge plan you ran." | CASE, JD | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Use what you ran, in your words: what the plan covered and the two seasons. Then extend it to the scope in the question: how you would sequence the sites, where you would share labour, what would trigger a change mid-peak. Answer slot: if any part of the plan was set by someone else, or you had no say in the plan, say which part was yours; if you had no say at all, say so plainly and describe what you ran. | The peak plan is your strongest operational proof, and this question tests whether it scales. |
| B4 | "Which three numbers would you put on a daily terminal dashboard, and what decision does each drive?" | JD | [grounded] "solid Excel" (your message); "cut mis-pick rate 40% by redesigning the pick path" (your message); JD "build reporting in Excel/Power BI" | Pick three. Use the mis-pick measure you have measured yourself as one. For each, say the decision it drives. Build it first in Excel. Name Power BI as the next step you plan to take, not one you have taken. | Covers the reporting requirement without claiming Power BI, which you stated you have not used (F6). |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Say the baseline period, the measure and who counted it, in your own words. Say which step of the pick path was yours to redesign and which were set elsewhere. Answer slot: if you know how the figure was counted, say it; if you don't, say so: "I don't know how the baseline was normalised" is an honest answer. | F4 is a headline figure, and the figure is the magnet for probes. Defend-the-number slots apply. |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name the one assumption you'd defend least, in one sentence, before they press. Answer slot: if you can't name one, say so. Don't build a model for why the number moved. | A stock Prober stem applied to the same figure. |
| C3 | "Tell me about a report or tracker you've built in Excel. What did it track, and who used it?" | JD | [grounded] "solid Excel" (your message); JD "build reporting in Excel/Power BI" | Open prompt. If you've built one, name what it tracked and who read it, in your words. If you haven't, say so: "solid Excel" is what you wrote, and the honest answer is the tracker you would build first. | F5 is discovery: the question asks whether a report exists, which the material does not show. |

### D. Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 40% mis-pick reduction. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Pause, then restate the question. Answer with what you did, in the sentence you gave, then what others did. Hold the part you can stand behind. Concede specifically what you cannot separate: the team's part, a volume change, anything you can't attribute. Hold through two follow-ups, then concede only what you can't separate. | Attribution under pressure. The hold is the sentence you wrote, and the concession is specific. |
| D2 | "Three supervisors isn't twelve. Why isn't this a step you haven't earned yet?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message); JD "lead a team of 12 supervisors" | Hold, don't fold: name the scope change directly. Then the structure you would use for twelve. Concede specifically on the scope you haven't run, and don't concede the work you did. | A pressure version of A1 with a harder framing. |
| D3 | "What makes you credible across four sites?" | JD | [grounded] JD "Own daily terminal operations across 4 sites" | Answer with the plan rather than a claim: how you would spend the first month, what you would standardise, what you would leave to site leads. Answer slot: if you have run operations across more than one site, say which and how; if you haven't, say so and say how you would close that. | Same gap as A3 under time pressure. The honest answer is the plan. |

### E. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through how you got here." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | A 90-second arc: seven years in warehouse and distribution ops; the mis-pick redesign; the peak plan two years running; senior shift manager over three supervisors; why this role's scope is the next step. Keep to what you have done. | Casual, but scored. A rehearsed arc prevents a rambling answer. |
| E2 | "Any Power BI yet, or is it on your list?" | JD | [grounded] "never used Power BI" (your message) | Answer in one plain sentence: "I haven't used Power BI." Then the plan: what you would learn first, and how you would use Excel until then. Make no claim to dashboards. | A plain acknowledgment with a source: your own sentence. |

### V. Values / Behavioural (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you had to tell site leaders something they didn't want to hear." | VAL | [generic] open prompt from the persona stem; "cut mis-pick rate 40% by redesigning the pick path" (your message) | Selection scaffold: pick a time you raised an unwelcome operational fact with a senior person. It needs a named stake, a moment you didn't soften it, and a working relationship at the end. If none comes to mind, say so plainly, then give the nearest thing your material carries, the pick-path change, and what you did with the result. | No published values were checked, so this is the generic behavioural stem. |
| V2 | "When have you put a customer's delivery ahead of an internal site metric?" | VAL | [generic] open prompt from the persona stem; "ran the site's peak-season surge plan two years running" (your message) | Selection scaffold: pick a time a customer-facing outcome conflicted with a site target. Say what you chose and what it cost, if anything. If none comes to mind, say so, then give the nearest thing: the peak-season plan, and the trade-offs you made in it. | Behavioural stem; the peak plan is the closest sentence you gave. |

### P. Peer (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our teams sit side by side at the terminal. Where's the seam, and what happens when we disagree?" | JD | [generic] peer collaboration stem | Propose seam principles, not facts about their site: who owns handoffs, who decides cut-off changes, how disagreements escalate. Don't claim to know their seam. Answer slot: if you have disagreed with a peer team on a handoff, say how you resolved it, in your own words; if you haven't, say so and say how you would start. | Peer stem. The answer shows how you'd work beside an ops peer. |
| P2 | "How do you handle credit when work spans two teams?" | VAL | [generic] peer collaboration stem; "ran the site's peak-season surge plan two years running" (your message) | State the principle first. Then one example you can give in your own words. Answer slot: if you have a specific example of shared credit, say whose work and whose credit; if not, say so and give your principle. | Peer stem, tested against the peak plan as the nearest example. |

## Reverse questions

Each one is for you to ask the interviewer. There is no interviewer profile, so these are role-generic.

1. "What would success look like at 90 days, across the four sites?" Why it lands: it signals you are thinking about terminal-wide scope, not one site.
2. "How are on-time performance and cost per shipment doing today across the sites, and which is furthest from target?" Why it lands: it shows you read the JD's two metrics as a pair.
3. "What reporting exists today, and how much of it is manual?" Why it lands: the JD asks you to build reporting, and this question surfaces the starting point.
4. "How is the supervisor layer set up now, and is anyone on it ready to step up?" Why it lands: leadership scope is your largest gap, and this asks about the team you would inherit.
5. "What has made this role hardest for the people who've held it?" Why it lands: it names the hard part and invites candour, without asking for anything personal.
6. "How far ahead is peak planning locked across the sites?" Why it lands: you have run a peak plan two years running, so the question is one only you would ask.

## Sources

- Provided documents: your message, containing the JD text you pasted and your background summary. No CV was provided.
- Searches and fetches: none. This pack was built at research tier L0, because the research question has not been answered yet.

Research tier: L0 (no searches, no fetches)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. company values | unavailable | Values cheat sheet would have been built from published values. Not run pending your answer on research depth. |
| 2. interview process, operations role family | unavailable | Loop structure, and persona weights following named rounds. Not run pending your answer. |
| 3. company strategy / recent news | unavailable | Company and strategy questions (CO type). Not run pending your answer. |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form. The interviewer read is absent. |
| 5. representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Sections not included, and why: prep triage (no prep time given); graded deliverables (none declared); grounding brief (research not run); reading the interviewer (no interviewer information); values cheat sheet (no values-style round detected); delivery coaching (no working-style assessment given).

## Upgrade menu

- Your CV → quotes from your résumé for F1 to F4 and F7, so the claims are checked against a document, not only your message.
- Green Belt certificate → F7 confidence rises from medium to high, and the certificate can be shown in the interview.
- How the 40% was counted (baseline period, measure, who counted it) → C1 and C2 can be answered from your own record, not from the slot.
- Whether you have ever tracked on-time performance or cost per shipment → F4, B2 and A4 become grounded in your own words.
- The full posting → lets the gate check run on location and schedule, and may add requirements.
- The interviewer's name → a tailored reverse question, and persona weights from their public background (needs research tier L1 or above).
- A `tuesday-dossier.md` → would record the gaps this prep exposed, so later sessions start from them.
