# Interview prep: Member Experience Lead, Ashgrove Credit Union

**For:** Dara · **Company:** Ashgrove Credit Union (member-owned, about 900 staff) · **Dates:** three rounds on 29 November 2026 (note: that date is a Sunday; confirm it with the recruiter)
**Interviewers:** recruiter (round 1); Head of Member Services, your future manager (round 2); a panel of two branch managers (round 3). Names not yet given.
**Format:** loop mode. One shared fit snapshot and sources block, then one mini-pack per round.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: rehearse the structure, and say only what you did, in your own words.

| Type | Meaning |
|---|---|
| VAL | Behavioural / values: does past behaviour show a published value |
| EXP | Experience deep-dive: does what you said about your past hold up under questions |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Live problem from the role, worked out aloud |

Answer slots are instructions for the interview. They are not questions to me, and each one has an honest branch you can use when the material does not carry the answer.

## Fit snapshot (shared across rounds)

Requirements are the JD's own words. Evidence is quoted from your message or the recruiter's email, and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | Your material says you handled the branch's log. It does not say you owned the process end to end. Words: "I handled the branch's formal complaints log." Answer slot: if you took a complaint from first contact to closure yourself, say which steps; if the log was your part and others owned the rest, say so. |
| F2 | "…and the contact centre" (JD) | "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | You stated this absence. Words: "I haven't worked in a contact centre." Then how you would learn the contact-centre side, as a plan, never as a past. |
| F3 | "Report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | The quote already reaches monthly reporting in other words. Words: "I built the monthly complaints spreadsheet our regional manager uses." Your material does not show resolution times. |
| F4 | "Coach branch supervisors on escalations" (JD) | "6 years in retail banking, the last 3 as branch supervisor." and "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | Training tellers on a script is adjacent to coaching supervisors, not the same work. Words: "I trained new tellers on our escalation script." Answer slot: if you coached a supervisor on when to escalate, say how; if you trained on the script only, say so. |
| F5 | "Work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material does not show digital-team work. Answer slot: if you worked with anyone on a channel or app change, say what; if not, say so and say how you would start with the digital team. |
| F6 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as branch supervisor." (your message) | medium | [grounded] | none | The years are covered. Branch work is customer-facing; the JD's "customer operations" is wider, so say what you did at the counter and in the back office, in your own words. |
| F7 | "Experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log." (your message) | medium | [grounded] | presentation | The quote reaches it in other terms. Your material does not name the regulator's rules or timescales you worked to. Bridge: "I handled the branch's formal complaints log." |
| F8 | "Confident presenting to senior leaders" (JD) | "I built the monthly complaints spreadsheet our regional manager uses; I've never presented to anyone above regional level." (your message) | low | [grounded] | capability | You stated the absence. Words: "I haven't presented to anyone above regional level." Then how you would prepare for a senior audience, as a plan. |
| F9 | "Comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | none | The quote reaches the requirement. Excel is not named in your material. Bring a sanitised copy of the spreadsheet (no member data) if you can. |

No JD requirement is a gate in the sense of a licence, credential or legal term, so no row is `hard_gate`.

## Prohibited claims

These are not coached anywhere in this pack, in any cell, slot or drill.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | "I handled the branch's formal complaints log." The pack's observation: your material says the log, not the process. |
| Coached branch supervisors on escalations | Inflated form of F4 | "I trained new tellers on our escalation script." |
| Wrote the escalation script | Inflated form of "our escalation script" | "I trained new tellers on our escalation script." Your material does not say who wrote it. |
| Built resolution-time reporting | Inflated form of F3 | "I built the monthly complaints spreadsheet our regional manager uses." Resolution times are not in your material. |
| Worked in a contact centre | Negative you stated (F2) | "I haven't worked in a contact centre." |
| Presented to senior leaders | Negative you stated (F8) | "I haven't presented to anyone above regional level." |

Digital-team work is not on this list. Your material is silent on it, so it is an answer slot (F5), not a claim.

## Grounding brief: the strategy and the process

Source: the July 2026 brief, as you summarised it in your message. I have not read the brief itself. Check the wording against the document before you use it.

| Brief line (quoted from your message) | What it means for the role | Provenance |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | The self-service journeys in the JD are a core part of the plan. | [grounded] |
| "consolidate eight branches into five hubs over 2027" | Complaint handling for branches that move into hubs is a live question. | [grounded] |
| "launch a small-business lending product in Q1 2027" | A new product will likely bring new complaint types. This is an inference, not something the brief says. | [inferred] the derivation: a new lending product usually creates new complaint categories |
| "the main competitive pressure is app-only banks" | Members compare Ashgrove's app with app-only banks. | [grounded] |

Use Ashgrove's own words: member service, member-owned, self-service, hubs.

Process flags from the recruiter's email and the brief:

| Flag | What the source says | Provenance |
|---|---|---|
| 29 November 2026 is a Sunday | "Three rounds on 29 November" | [grounded] for the date; the weekday is a calendar fact you can check. Confirm the date and times with the recruiter. |
| Round 3 packs values scoring into the same 60 minutes as the case | "60 minutes with a panel … including a 20-minute case" and "The panel is also the values round" | [grounded] |
| The panel are branch managers, and the plan consolidates branches | "consolidate eight branches into five hubs over 2027" | [inferred] the consolidation may touch the panel's own branches; the brief does not say which |
| The 40% digital target and "Neighbours, Not Numbers" pull against each other | "move 40% of member service to digital channels by 2028" and "Neighbours, Not Numbers — every branch is part of its town" | [inferred] expect a question on this tension in round 3 |

## Sources

- **Provided documents:** the JD text in your message; the recruiter's email (round structure, times, panel composition); your background sentences in your message; the values copied from ashgrovecu.org/about/values on 20 November 2026 and pasted; the July 2026 strategy brief as summarised in your message.
- **Searches and fetches:** none sent.
- **Dossier:** none present.

**Research tier:** L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values you pasted fix the values section and the cheat sheet. |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email fixes the three rounds, their lengths and the panel. |
| 3. Ashgrove strategy / recent news | skipped | The pasted July 2026 brief summary supplies current priorities. A sweep for news since July would be the L2 upgrade. |
| 4. Interviewer name + Ashgrove | n/a | No names given, so there was no query to form. The interviewer read is absent. |
| 5. Representative JD for the title | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own the complaints process end to end across branches and the contact centre | B4, C4, D2, H1 |
| Report monthly on complaint volumes and resolution times | E1, E2 (resolution times are an answer slot; they are not in your material) |
| Coach branch supervisors on escalations | C3, D2 |
| Work with digital teams on self-service journeys | B5, D3 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | C4, D2 |
| Confident presenting to senior leaders | G1 |
| Comfortable with Excel reporting | A6, E1, E2 |

Values coverage: Plain Words (C1, C7), Members First (C2, C8), Neighbours, Not Numbers (C6), Own the Fix (C5, C9).

---

## Round 1: Recruiter screen (30 minutes)

**Persona weights.** Relationship prior: conversational, with a light skeptic. Six questions are on the conversational side, because four of them are logistics knockouts that the coverage rule requires. Three are skeptic questions. Persona-table reasoning: the recruiter's screen is where pay, notice, location and the reason for leaving get checked, and the rest of the personas are rehearsed in rounds 2 and 3.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Walk through your journey; a casual question on Excel; the logistics knockouts | High. Recruiter screens are friendly and scored. | Rehearse a 90-second arc. Treat casual JD questions as scored. |
| Skeptic (light) | Why now; what is missing | Medium. The two stated absences (F2, F8) will show in a screen. | Plain acknowledgment, then a ramp plan. |

**Bank: Conversational (A) and Skeptic (B)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your journey so far, in about two minutes." | JD | [grounded] "6 years in retail banking, the last 3 as branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A ninety-second arc: the six years, the last three as a branch supervisor, the complaints log you handled, the tellers you trained on the escalation script, then why this role. Nothing in the arc goes beyond those sentences. | The opener. F6 is covered in one breath, and the arc's middle is the quoted sentence. |
| A2 | "What are your pay expectations for this role?" | JD | [generic] | Logistics slot: give your own figure in your own words, or ask for the role's band before you answer. Do not give a range, a floor or a history unless you choose to. | A knockout question. No pay figure is in your material, so none is supplied here. |
| A3 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period in your own words. | A knockout question. Your notice period is yours to give. |
| A4 | "Where would you be based, and how often can you come into an office?" | JD | [generic] | Logistics slot: name the locations and the office days you can commit to, in your own words. If the office pattern is unclear, ask for it before you answer. | Location matters more than usual given the 2027 hub plan: the sites this role covers may change. |
| A5 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot (reason for leaving): give your reason at its real scope, in your own words, without criticism of your employer. | Your material gives no reason, so none is supplied. |
| A6 | "What are you doing in Excel these days?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Name the spreadsheet you built and what it does each month, in those words. Answer slot: if you used formulas, pivots or macros, name which; if you did not, say so and say what you used. | Excel is a JD requirement asked as small talk, so it is scored. F9 is the row. |
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say it plainly: "I haven't worked in a contact centre." Then what you would do in the first month to learn it. A plan, not a past. | The skeptic's stem. F2 and F8 are the stated absences, and the first sentence is the acknowledgment you gave. |
| B2 | "I don't see contact-centre experience in your background. How would you handle that in this role?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Acknowledge the absence in your words, then a ramp plan: who you would ask first, what you would need to see, and how you would report progress. | The premise is a negative you stated, so the question may presuppose it. |
| B3 | "Why this role, and why now, after three years as a branch supervisor?" | EXP | [grounded] "6 years in retail banking, the last 3 as branch supervisor." | Say what the role adds that the supervisor job does not: work across branches and the contact centre, the monthly reporting, the coaching. Do not criticise your current employer. | Motivation consistency is a skeptic's probe. The three years are the base you state, and the rest is the role's scope, not a claim about you. |

**Reverse questions (round 1)**

1. "What happens after the three rounds on 29 November: who decides, and when do you expect to tell candidates?" Why it lands: it gets you a decision date and shows you plan around the timeline.
2. "How is the monthly complaints report used now, and who reads it?" Why it lands: it shows you have thought about the reporting part of the JD.
3. "Is the 2027 hub plan part of what this role is hired to deliver?" Why it lands: it ties the role to the published strategy and tests how big the scope is.
4. "Are all three rounds scored against the same sheet?" Why it lands: it checks whether the values round is scored like the others.
5. "What would make the first three months in this role clearly a good start?" Why it lands: a rapport question. The recruiter tells you what matters.

---

## Round 2: Head of Member Services, your future manager (45 minutes, mostly behavioural)

**Persona weights.** The recruiter's email says mostly behavioural, so values/behavioural leads. The manager is the person who would coach you on escalations, so the skeptic questions stay. The case, prober and pressure personas are touched once each, because the round is not a case round.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / behavioural | Stories against the four values; escalation judgement | High. The round is "mostly behavioural". | Pick a real story or say plainly there is none. |
| Skeptic | Contact centre; digital; why move from a branch | High for the contact centre (F2). The manager will test whether the gap is honest. | Acknowledge the gap, then a ramp plan. |
| Case / strategist | The 2027 hub move, once | Medium. The manager owns the roadmap. | Clarify, then structure. |
| Data-driven prober | The spreadsheet's counting, once | Medium. The manager reads the monthly report. | Name the assumption you would defend least. |
| Pressure | Presenting to senior leaders, once | Medium. F8 is the stated absence. | Hold on what the quote carries, then concede. |

**Bank: Values / behavioural (C), Skeptic (B), Case (D), Prober (E), Pressure (G)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time a member didn't understand a decision the first time you explained it. What did you change?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open prompt, so pick a real instance. If none comes to mind, say so, then give the nearest thing your material carries: training new tellers on the escalation script, and what you changed in how you taught it. Plain Words is the value; the quote carries the training, not a member's second explanation. | "If a member needs it explained twice, we wrote it wrong" is the published value. The honest branch is the answer. |
| C2 | "Tell me about a time you put a member's outcome ahead of a target or a process." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open prompt. Pick a complaint where the process and the member's case pulled apart; say what you chose and why. If none comes to mind, say so, then walk through how you handled a complaint from the log. | Members First. Your material carries the log, not a member decision, so the scaffold is the honest form. |
| C3 | "How do you coach a branch supervisor on when to escalate a complaint?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Answer slot: if you coached a supervisor or a teller on when to escalate, not only on the script, say how you did it. If you trained on the script alone, say so, then say how you would coach a supervisor on judgement calls. | The coaching requirement (F4). The second branch allows the practice never existed. |
| C4 | "Walk me through one complaint on the branch's formal log: how it got there, what you did, and how it ended." | JD | [grounded] "I handled the branch's formal complaints log." | Walk through the entry, your steps, and the ending, in your own words. Answer slot: if you handed any part to someone else, say who and where it stopped. If the log was your only step, say so plainly. | The end-to-end requirement (F1). The question names only the log, which is the sentence you gave. |
| C5 | "Tell me about a time you kept hold of a problem until it was solved, even after it moved to someone else." | VAL | [grounded] "I handled the branch's formal complaints log." | Open prompt. Pick a complaint you stayed with until it closed. If none comes to mind, say so, then say how you would keep hold of a case that moves between a branch and the contact centre. | Own the Fix. The log is the nearest thing the material carries. |
| B4 | "This role covers the contact centre as well as branches. What would you need to learn about the contact centre before you could own its complaints?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Acknowledge plainly: "I haven't worked in a contact centre." Then what you would learn, from whom, and in what order: the handling steps, the systems, the people. A plan, not a past. | The highest-ROI prep in this pack. It is the objection the manager is most likely to raise, and C4 is the answer that carries the evidence. |
| B5 | "Our self-service journeys are worked on with digital teams. What's your experience there?" | JD | [grounded] JD: "work with digital teams on self-service journeys" | Answer slot: if you have worked with a digital team on a channel or app change, say what you did. If you have not, say so, then say how you would start with the digital team. | F5. Your material is silent on digital work, so the honest answer is either branch. |
| B6 | "You've been a branch supervisor for three years. Why would you move to a role that reports on and coaches other people's complaints?" | EXP | [grounded] "6 years in retail banking, the last 3 as branch supervisor." | Say what you would carry over from supervising, and what you would learn from reporting and coaching across branches. Keep it to the role, not to a grievance. | A skeptic's motivation probe. It rests only on the years you stated. |
| D1 | "Our plan moves some branches into hubs during 2027. If a branch's open complaints had to move to a hub, what would you check first?" | CASE | [grounded] the July 2026 brief summary: "consolidate eight branches into five hubs over 2027" | Structure it aloud: how many open cases and how old they are; which have deadlines; who owns each; what the member is told about the move. Ninety seconds. Nothing in it is a claim about your past. | The strategy-grounded CASE question. The brief is a provided document, not a raising source, so the question is worded as a hypothetical. |
| E1 | "Walk me through the monthly complaints spreadsheet. What does it count, and what does it leave out?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what it counts, in your own words, from the build you described. Name the assumption you would defend least. Answer slot: resolution time is not in your material; if the spreadsheet recorded when complaints closed, say what counted as closed; if it did not, say so. | F3's gap is resolution time. The question is premised on the quoted spreadsheet. |
| G1 | "Sixty seconds: why would I trust you to present complaints to our senior leaders, when you've never presented to anyone above regional level?" | JD | [grounded] "I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Hold: pause, restate the question, then hold on what you did: the spreadsheet your regional manager uses. Concede plainly: "I haven't presented to anyone above regional level." Then your plan for preparing a senior audience. Through two follow-ups, return to the spreadsheet; concede the senior presenting, never the monthly numbers. | Pressure. F8 is the stated absence. The hold is the spreadsheet, which is the only presenting-adjacent thing you stated. |

**Reverse questions (round 2)**

1. "How do you see complaint handling changing as branches move into hubs in 2027?" Why it lands: it ties the role to the published plan and shows you read the strategy against the job.
2. "What does a good escalation look like to you, from a supervisor's first call?" Why it lands: it opens the coaching conversation with the person who would be your manager.
3. "Where do branch and contact-centre teams most often disagree about who owns a complaint?" Why it lands: it names the seam the role sits on, and asks the manager to describe it.
4. "What would you need to see in the first 90 days to think the role is working?" Why it lands: it asks the manager to define success, which is the question a manager is most likely to answer well.
5. "Which part of the complaints process worries you most right now?" Why it lands: it invites the manager's real concern, and you can then answer it.

---

## Round 3: Panel of two branch managers (60 minutes, including a 20-minute case; values scored)

**Persona weights.** The recruiter's email says the panel scores the four values and runs a case. Panel relationship prior: blend peer and values/behavioural, with a case. The panel members are not named, so personas are blended rather than assigned. The case is one scenario with one follow-up, so the case persona carries two questions.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / behavioural | Four scored values questions | High. The recruiter says the panel scores all four. | One story per value, or the honest "none" with a scaffold. |
| Peer evaluator | Seams between branches and the contact centre; credit; what the panel would need from you | High. Branch managers are the role's peers across branches. | Seam principles, not a made-up map; reciprocity. |
| Case / strategist | The 20-minute complaint escalation and its follow-up | High. The case is in the brief. | Clarify, then structure, then the member. |
| Data-driven prober | The spreadsheet, once | Medium. Branch managers read the numbers their branches appear in. | Name the assumption you would defend least. |
| Skeptic | Contact centre, once | Medium. | Acknowledge, then the first-month plan. |
| Pressure | Your log, once | Medium. | Hold, then concede. |
| Conversational | Covered in round 1 (A1) | Low here. | Reuse the round 1 arc. |

**Bank: Case (D), Values (C), Peer (H), Prober (E), Skeptic (B), Pressure (G)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D2 | "A member says a branch promised them a fee refund and it never arrived. Their third contact ended with 'someone will ring you'. They now say they'll take it to the ombudsman. The branch supervisor says the refund was never approved. You have twenty minutes: what do you do in the next 48 hours, and what do you change afterwards?" | CASE | [generic] | Opening ninety seconds: (1) clarify what was promised, by whom, and what is recorded. (2) Decide whether it is a formal complaint under your definition, and check the regulator's and ombudsman's timescales rather than rely on memory. (3) Give it one owner, end to end. (4) Reply to the member in plain words: one clear answer, what happens next, and by when. (5) Speak to the supervisor before deciding; decide on the policy and the promise, and coach on the decision, not the blame. (6) Fix the cause, and count it in the monthly numbers. | The complaint escalation the panel will run. No claim about your past: the structure is generic, and the candidate's experience appears only as the quoted log. |
| D3 | "Now the member raised it through the app, and the form has no field for the branch. What changes?" | CASE | [generic] | Name the owner for the digital request. Say what you would ask the digital team first: the form's fields, where a request lands, and what the member sees. Do not promise a fix date. | The self-service push (40% by 2028) is the digital seam in the case. |
| C6 | "Our branches each sit in their own town. If a branch were folded into a hub, how would you keep its members from being treated as a number?" | VAL | [grounded] "Neighbours, Not Numbers — every branch is part of its town." | Name the principle first: decide with the town in view. Then a story only if you have one: pick a decision that kept a local member's case local. If none, say so, then say how you would test a hub move against the town. | Neighbours, Not Numbers. The hypothetical asks about no past. Your branches' fate is not known to you, so do not assume it. |
| C7 | "A member's complaint letter is full of our internal jargon. How would you rewrite the reply?" | VAL | [grounded] "Plain Words — if a member needs it explained twice, we wrote it wrong." | Rewrite from the member's question: one sentence per decision, no internal codes, and a reader test with a colleague who does not know the process. No claim about your past. | Plain Words, as a hypothetical so that it asks nothing of your history. |
| C8 | "A process says no. The member has a strong case, and your branch manager wants the process followed. What do you do?" | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter." | Decide from the member's side: check which rule actually says no; take the member's facts to your manager; record your reasons; own the answer you give. No claim about a past decision. | Members First, tested as a live dilemma. |
| C9 | "When a complaint is passed between a branch and the contact centre, who should hold it? What do you do when nobody does?" | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved." | Name one owner, a date, and a check at closure. If the handover fails, go to the owner on both sides. No claim about your past. | Own the Fix, as a seam question. |
| E2 | "Which number in the monthly spreadsheet would you defend least, and why?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Name the number, and the assumption behind it, in your own words. If you did not define how a figure was counted, say so. Answer slot: if the spreadsheet tracked closure times, say how it counted a closed complaint; if it did not, say so. | Branch managers will read the numbers their branches appear in. F3 and F9 are the rows. |
| H1 | "Where's the seam between a branch and the contact centre for a complaint, and what happens when the two disagree?" | JD | [grounded] JD: "across branches and the contact centre" | Propose seam principles: who owns the member's answer, who holds the record, when a branch can overrule the contact centre. Do not pretend to a map you have not seen. If you have a disagreement story, use it; if not, say so and give the principle. | The peer's seam question. F2 caps what you can claim about the contact-centre side. |
| H2 | "When a branch fix needs the contact centre to act, how do you handle the credit?" | EXP | [generic] | Name the member's outcome as the shared result. Say who did what, in your own words. Do not claim the contact centre's work. | Peer probe on credit. No claim about your past. |
| H3 | "What would you need from a branch manager to make a complaint move on the day it's raised?" | JD | [grounded] JD: "Own the member complaints process end to end across branches and the contact centre" | Name two or three things you would ask for, such as the case file and a named contact, and say what you would offer in return. | A peer reciprocity question: what you bring to the panel's teams, not only what you need. |
| B7 | "What complaints problem would you expect to find in your first month, and what would you do about it?" | JD | [generic] | Name the problem class you expect: handover gaps, or open cases older than the team's own target. Say what you would check first and who you would tell. Do not claim you have seen it. | Skeptic, for the contact-centre gap. It asks about the future, so it presupposes nothing about your past. |
| G2 | "The complaints on the log you handled: which decisions were yours, and which were someone else's?" | EXP | [grounded] "I handled the branch's formal complaints log." | Hold through two follow-ups by returning to the log and the steps you took. Answer slot: if decisions were yours, say which; if none were, say so plainly and describe how the log worked. Concede where others decided. | Pressure. The question presupposes decisions that your quote does not state, so the second branch must be honest. |

**Reverse questions (round 3)**

1. "What could a new person do in their first month that would genuinely help your branches?" Why it lands: peer reciprocity. It shows you think about what you bring to the panel's teams.
2. "When a complaint moves from a branch into the contact centre, where does it usually stall?" Why it lands: it names a real seam and invites the panel's experience.
3. "What does 'own the fix' look like on your branch floor today?" Why it lands: it uses the value's own words and asks the panel to describe their practice.
4. "With the hub plan coming in 2027, what would you want the complaints process to protect first?" Why it lands: it asks a branch manager's view on the plan. Ask it lightly: the panel may be affected, so let them choose how much to say.
5. "How do you want the monthly complaints numbers to look to branch managers?" Why it lands: it shows you will report for them, not just about them.

### Values / principles cheat sheet

The recruiter's email says the panel scores against the four values. These are the values as published, paraphrased, and the story each one has in your material.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No row carries a member decision. Scaffold: pick a case where the member's side and the process pulled apart, say what you chose, and why. If none comes to mind, say so, then walk through how you handled a complaint from the log (F1: "I handled the branch's formal complaints log"). |
| Plain Words | If a member needs it explained twice, the wording was wrong | No row carries a member's second explanation. Scaffold: pick a member who needed something twice, and what you changed in your words. If none comes to mind, say so, then give the nearest thing your material carries: training new tellers on the escalation script (F4). |
| Neighbours, Not Numbers | Every branch is part of its town | No row carries a town or a local story. Scaffold: pick a decision that kept a local member's case local. If none comes to mind, say so, then say how you would test a hub move against the town. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1 carries handling the log, not solving a problem. Scaffold: pick a complaint you stayed with until it closed. If the log was your only step, say so, then say how you would keep hold of a case that moves between branch and contact centre. |

---

## Upgrade menu

- Prep hours before 29 November → a prioritised schedule for the three rounds (the prep-triage section is held until then)
- Names of the Head of Member Services and the two branch managers → personas assigned per person, an interviewer read, and reverse questions tied to their own paths
- Confirmation of the 29 November date and the times, since that date is a Sunday → nothing else in the pack changes
- Whether the 20-minute case comes with any material in advance → the case guidance can use it
- One complaint you took from first contact to closure, in your own words → F1 becomes a story-mapped row, the Own the Fix cell becomes a story, and C5 and C9 get a real answer
- Whether you have worked on any channel or app change with a digital team → F5's answer slot becomes a story
- The regulator or ombudsman timescales your branch worked to, in your own words → F7 gets its specifics and D2's clock check is grounded
- A sanitised copy of the monthly spreadsheet, with no member data → F9 is inspectable; the Excel answers in A6 and E2 can point to it
- Latest Ashgrove news since July 2026 (deep research, L2: up to 6 more searches and 2 more fetches; it takes a few minutes and is offered once) → the grounding brief and the case's strategy hooks are refreshed
- A `tuesday-dossier.md` file → verified evidence and the rows where the pack's gaps are confirmed
