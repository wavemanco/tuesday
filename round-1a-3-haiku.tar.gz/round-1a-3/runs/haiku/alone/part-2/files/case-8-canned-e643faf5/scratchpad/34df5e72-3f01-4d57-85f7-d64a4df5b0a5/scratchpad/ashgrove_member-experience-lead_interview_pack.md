# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Prepared for Dara. Three rounds on 29 November 2026, run as a loop: one shared fit snapshot and source block, then a mini-pack per round. Interviewer names are not assigned yet, so there is no interviewer read, and the personas rest on round type and the recruiter's process email.

## 2. How to use this pack

Personas describe how a question arrives. Types describe what it scores. Each question carries one type tag:

- **VAL**: values and behaviour, measured against Ashgrove's four published values.
- **EXP**: your own experience, where precise attribution is what gets tested.
- **JD**: the listed job, including its gaps.
- **CO**: company and strategy knowledge.
- **CASE**: a live problem from the role, scored on structure.

Guidance is scaffolding, not a script. An answer slot is an instruction for the interview: answer in your own words, and where your material does not carry the answer, say so plainly. Nothing here gives you a past you did not describe to me.

## 4. Fit snapshot (shared across all rounds)

Requirements are quoted from the JD you pasted. Evidence is quoted from what you wrote to me. Confidence grades your evidence; provenance grades what this pack wrote about it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap in the years. Say them in your words: six years in retail banking, the last three as a branch supervisor. |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | presentation | Your material says formal complaints log. Keep those words. It does not say the log was kept to a named regulatory standard, so do not add one. |
| F3 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | Your material says spreadsheet, not Excel. Say spreadsheet, and say Excel only if you used Excel. |
| F4 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | A monthly spreadsheet is shown, but not which measures it held. Answer slot: if it counted volumes or resolution times, say how each was counted; if it counted something else, say what, and stay with that. |
| F5 | "Own the member complaints process end to end across branches and the contact centre" — JD (branch scope) | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material shows one branch's log. Say one branch's log. Do not claim the end-to-end ownership the JD describes. |
| F6 | "across branches and the contact centre" — JD (contact-centre scope) | "Never worked in a contact centre" — your message | none | [grounded] | capability | Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan, never as a past. |
| F7 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "6 years in retail banking, the last 3 as a branch supervisor" — your message | low | [inferred] | transferability | Training tellers on an escalation script is adjacent to coaching supervisors, which your material does not show. Bridge: "I trained new tellers on our escalation script." Do not extend it to supervisors. |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Answer slot: if you worked with anyone on digital or self-service channels, say who and what that involved; if you did not, say so and say how you would start. |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | Words: "I haven't presented to anyone above regional level." Then your plan for building that skill, said as a plan, never as a past. |

**Gates.** The JD names no term that is a gate (no location, licence or credential). Section 9 asks the one question about location, because the hub changes may make it one.

**Worksheet note.** Your material gives no figure for anything you did, so no defend-the-number question applies. Every quote above is one of your own sentences.

## 6. Grounding brief (company)

Source: your summary of Ashgrove's July 2026 strategy brief. I have not read the brief itself. Check these figures against it before you quote them.

- Digital: move 40% of member service to digital channels by 2028.
- Network: consolidate eight branches into five hubs over 2027.
- Products: launch a small-business lending product in Q1 2027.
- Competition: the main pressure is app-only banks.

Vocabulary to use: "member service", "digital channels", "hubs". Do not add figures you have not seen in the brief.

**Tensions to hold, all three derived from the material above:**

- **Branches versus towns.** The values page says "every branch is part of its town"; the brief consolidates eight branches into five hubs. [inferred] Expect questions about how a complaint from a town keeps a local owner when its branch closes. Do not guess how the branch managers on the panel see the change.
- **Volumes across channels.** The JD asks for monthly volumes and resolution times, and the brief moves 40% of member service to digital. [inferred] Counts will shift by channel, so the monthly report must hold across them.
- **New product, new complaints.** A small-business lending product from Q1 2027 may bring complaints this team has not handled. [inferred]

## 8. Persona table (by round)

**Round 1: recruiter screen, 30 minutes.** Prior: conversational, with a light skeptic. Weights: conversational 3 questions, light skeptic 2, logistics 4 (the recruiter's knockout checks, which the recruiter screen runs in a friendly register).

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Open background question, motivation, logistics asked casually | High. A recruiter screen is a conversational register, and the logistics are scored in it | Pre-scripted 90-second background arc; have the four logistics facts ready |
| Light skeptic | Contact-centre gap and the Excel line, asked plainly | Medium. The recruiter screens for knockouts, and two of your gaps are on the JD's face | Say the negative once, plainly, then the plan |

**Round 2: Head of Member Services, 45 minutes, mostly behavioural.** Prior: a hiring manager is usually case and skeptic. Your recruiter's "mostly behavioural" moves values to the top. Weights: values/behavioural 5 questions, skeptic 3, prober 1, case 1.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/behavioural | "Tell me about a time…" scenarios on the four values | High. Stated by your recruiter as the round's focus | Selection scaffolds, honest branches, STAR shape |
| Skeptic | The contact-centre gap, presenting above regional level, the single-branch log | High. A manager is buying capability and derisking gaps: the highest-ROI area | Hold, then concede specifically; plan, not past |
| Prober | How the spreadsheet counted volumes and times | Medium. The JD names the reporting line | Name the weakest assumption before asked |
| Case | A branch moving into a hub | Low to medium. Mostly behavioural, so one scenario at most | Clarify, then structure |

**Round 3: panel of two branch managers, 60 minutes, including a 20-minute case, values scored.** Prior: values/behavioural plus conversational for a values round, blended with the panel's case role. Weights: values/behavioural 3, case 2 (the 20-minute escalation case, C4, is the centrepiece), pressure 2, peer evaluator 1, prober 1.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/behavioural | Scored against the four values | Certain. The recruiter states the panel scores against them | One honest story per value, or the honest branch |
| Case/strategist | The escalation case, then a structured walk | High. The case is 20 of the 60 minutes | Clarify first, then structure, then "I would", never "I did" |
| Pressure | Challenges the handoff view; the supervisor-coaching gap | Medium. Branch managers may test a supervisor applying for a lead role | Hold a position through two follow-ups |
| Peer evaluator | Seam questions between branches and the contact centre | Medium. The panel runs branches, the seam is theirs too | Propose seam principles, not a map |
| Prober | Monthly reporting across channels | Low to medium | Name the weakest assumption in the count |

## 9. Question banks

**Requirement coverage.** Every JD requirement maps to at least one question below, except where noted.

| JD requirement | Question IDs | Note |
|---|---|---|
| 4+ years in financial-services customer operations | A1 | |
| Experience handling regulated complaints | B10 | |
| Confident presenting to senior leaders | B4 | |
| Comfortable with Excel reporting | A8 | |
| Own complaints end to end across branches and the contact centre | B3, C5 | |
| Report monthly on volumes and resolution times | B5, C6 | |
| Coach branch supervisors on escalations | C9 | |
| Work with digital teams on self-service journeys | C6 | Partly: C6 covers channels and reporting, not self-service design. No question on that exists in this pack |

### Round 1: recruiter screen (A-bank)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc in your own words, in this order: the years and your last role; the complaints log; the escalation training; the monthly spreadsheet. Stop at what the quotes say. | F1, F2, F3 and F7 are the spine of your background. Conversational, so it is scored casually. |
| A2 | "What draws you to this role?" | JD | [generic] | Name the motivation in your own words: what in the JD you want to do. If the honest reason is that you want to move beyond the branch floor, say that. No quote in your material states a motivation, so this is an answer slot. | Motivation is screened in the friendly register; there is no fact to draw on, so the answer must be yours. |
| A3 | "What are you looking for in pay?" | JD | [generic] | Give your own figure, or ask what the band for the role is before you answer. Do not give a figure you have not chosen. | Pay is a logistics slot. Your material states no figure, so none is supplied. |
| A4 | "What's your notice period?" | JD | [generic] | Give your actual notice period in your own words. Have the fact ready before the call. | Notice is a logistics slot. Your material states none. |
| A5 | "Are you able to work in the location this role is based in?" | JD | [generic] | Give your constraint: which location, and which working pattern you can meet. | Location is a logistics slot, and the hub changes make it real. Your material states none. |
| A6 | "Why are you thinking of leaving your current role?" | EXP | [generic] | Give your true reason, short, and about what you want next. Your material states none, so the answer is yours to give. | Reason for leaving is a logistics slot. Recruiters ask it early, so have it ready. |
| A7 | "This role runs complaints across branches and the contact centre. You have never worked in a contact centre. How do you respond?" | JD | [grounded] "Never worked in a contact centre" | Say it plainly: "I haven't worked in a contact centre." Then the plan, as a plan: what you would learn first and from whom. Do not describe contact-centre work you have not done. | F6 is the first gap a recruiter will see. The negative has your source, so the question may state it. |
| A8 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what you built and used, in your word, spreadsheet. Name Excel only if you used it. | F3. The JD says Excel; your material says spreadsheet. The gap is the word, not the skill. |

### Round 2: Head of Member Services (B-bank)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you had to tell someone senior something they did not want to hear." | VAL | [generic]; nearest thing: "I handled the branch's formal complaints log" | Open prompt, selection scaffold: choose a time with a named stake, a point where you did not soften the message, and an outcome you can state. If none comes to mind, say so plainly, then give the nearest thing your material carries: the log you kept. | Values/behavioural, and a manager's standard behavioural probe. Your material holds no such story, so the honest branch is the one you will use. |
| B2 | "Tell me about a complaint that took several handoffs to close." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt: if a complaint from the log stayed open across handoffs, pick it, and say who held it, when you kept hold, and how it closed. If none stayed open, say so, and say how the log handled open cases, if it did. | Own the Fix. Scored on who held the problem, not on the drama. |
| B3 | "You have never worked in a contact centre, and this role owns complaints across one. Why should we believe you can run it?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | **Highest-ROI prep in this pack.** Hold: "I haven't worked in a contact centre." Then what carries over, at its own scope: the complaints log you handled at one branch. Concede specifically: how a contact centre takes and passes on complaints is what you would have to learn, and name the first thing. Hold through two follow-ups by returning to the log; concede on the second. Never claim the end-to-end ownership. | F5 and F6 together. This is the most predictable objection to you, and it is aimed where your material is thinnest. Deepest rehearsal, with the concession named before it is asked for. |
| B4 | "The role presents monthly to senior leaders. You've never presented above regional level. How would you prepare?" | JD | [grounded] "I've never presented to anyone above regional level" | Say: "I haven't presented to anyone above regional level." Then your plan: what you would rehearse, with whom, and how you would get feedback before the first session. A plan, never a past. | F9. The JD raises the senior presenting, and the negative is yours. |
| B5 | "The role reports monthly on volumes and resolution times. What did your spreadsheet report, and how was each figure counted?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what it counted, in your words. If it counted resolution time, say when the clock started and stopped. If it did not, say what it counted instead and how you would add the measure. Name the weakest assumption you know in the count before they ask. | F4. The JD's reporting line makes this probe likely. Your answer is the only thing that can settle the count. |
| B6 | "A branch in a town that is moving into a hub is one of your biggest sources of complaints. What do you do before the decision is made?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the strategy brief) | Structure it: clarify what the complaints are, how many, which members, and what the hub changes for them; set the objective as keeping each complaint owned locally while the network moves; say what you would check first; name the metrics, by channel; name the risks. Speak in "I would". | Strategy-grounded CASE. You have no experience of this, so the guidance makes no claim about it. |
| B7 | "You handled one branch's log. Why should we trust that at a 900-staff organisation?" | JD | [grounded] "I handled the branch's formal complaints log"; "6 years in retail banking, the last 3 as a branch supervisor" | Hold: say the scope of what you did in the quote's words. Concede what is untested at 900 staff. Do not add scale to the log. | F5. Hold, then concede. The position you hold is the one your material carries, no more. |
| B8 | "Tell me about a time you treated a member's problem as part of their town, not as a count." | VAL | [generic] | Open prompt, selection scaffold: pick a case where a local detail changed what you did. If the honest answer is that your work has leaned towards counts, say that, and say what you would change. Do not invent a local story. | Neighbours, Not Numbers. Your material shows counts (F3), so the honest branch is the likely one. |
| B9 | "When did you decide something from the member's side of the counter when the process did not require it?" | VAL | [generic]; nearest thing: "trained new tellers on our escalation script" | Open prompt: pick one decision and name who was affected. If the process required the same thing, say so. If you have none, say so, and give the nearest: the escalation training. | Members First. Scored on the decision, not on the sentiment. |
| B10 | "The role handles regulated complaints. Which rules did the formal log have to follow, and how did you check that it did?" | JD | [grounded] "I handled the branch's formal complaints log" | Answer slot: if you worked to named rules, name them and how you checked; if the log was not kept to named rules, or applying them was not yours, say so and say what the log recorded. Do not name a rule you did not work to. | F2. The JD's regulated line makes this probe likely, and it is the place a gap is most often inflated. |

### Round 3: panel of two branch managers (C-bank)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell us about a time you kept hold of a problem until it was solved." | VAL | [generic]; nearest thing: "I handled the branch's formal complaints log" | Open prompt, selection scaffold: a named problem, the moment you could have handed it on, and the end state. If none, say so, then give the nearest: the log you kept. | Own the Fix. Scored by the panel against the value. |
| C2 | "Tell us about a time you put a member ahead of an internal measure." | VAL | [generic] | Open prompt: pick one where the measure and the member pulled apart; say what you chose and what it cost the measure. If none, say so and say what you would check first. | Members First. The panel scores this value directly. |
| C3 | "One of the branches in your area is moving into a hub in 2027. What does its town lose, and what happens to its complaints in the meantime?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the strategy brief) | Name who in the town the change reaches. Say what happens to complaints in flight: who owns them, and how the member knows. Speak in "I would". | Neighbours, Not Numbers against the brief. The panel may run branches in this network. |
| C4 | Case: a member's fee complaint, sent between branch and contact centre, now threatened outside the credit union. | CASE | [generic] | See the 20-minute walkthrough below. | The JD's end-to-end line, scored by the panel on structure and on the values. |
| C5 | "Your branch and the contact centre disagree on who owns a complaint at handover. You have 60 seconds. Who owns it?" | JD | [generic] | Hold a position: name one owner and the principle behind it. Hold through two follow-ups. Concede what you do not know about each side's systems. | The seam question. Pressure on a position, not on a fact. |
| C6 | "If digital becomes 40% of member service by 2028, how do you keep monthly volumes and resolution times comparable across channels?" | JD | [inferred] derived from the strategy summary's 40% target and the JD's monthly report line | Name the assumption you would defend least: that each channel counts a complaint the same way. Say what you would check first. Speak in "I would". | Partly covers the digital requirement. Derived, so labelled inferred. |
| C7 | "Where's the seam between a branch and the contact centre, and what happens when we disagree?" | JD | [generic] | Propose a principle for the seam, not a map: one handover rule, and how you would test it with both sides. Do not claim to know the seam. | Peer evaluator. The panel are colleagues in the same network. |
| C8 | "Explain to a member, in one minute, why their complaint was not upheld." | VAL | [generic] | Say the decision, the reason and the next step, in that order, with no word you would have to define. If you have not written such a letter, say what you would check first. | Plain Words. Scored on the member's understanding. |
| C9 | "The role coaches branch supervisors on escalations. You have been a branch supervisor. What would you change in how escalations are coached?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "trained new tellers on our escalation script" | Answer slot: if you coached other staff on escalations, say how. If you coached tellers only, say that, and say what you would add for supervisors. Do not claim coaching of supervisors. | F7. Pressure from a panel of branch managers, who run the supervisors. |

#### 20-minute case walkthrough (C4)

This is a practice scenario, generic to any credit union. The panel's version may differ. Use "I would", never "I did".

**Scenario.** A member's fee complaint began at a branch. The branch says the fee was correct. The contact centre says the branch never sent the paperwork. The member has called twice and now says they will take it outside the credit union.

| Minutes | Step | What to say |
|---|---|---|
| 0 to 3 | Clarify | Ask: the deadline, and which rules apply if this is a regulated complaint; the member's situation and any vulnerability; what evidence exists; who holds the case now. Do not assume the deadline. |
| 3 to 6 | Objective | Resolve the member's complaint correctly and inside the deadline, and close the handoff gap so the next complaint does not bounce the same way. |
| 6 to 10 | Today's actions | Name one owner, which is the Own the Fix value. Get the paperwork from the branch and the call record from the contact centre. Tell the member in plain words what happens next and when. Stop the second loop by making one person their contact. |
| 10 to 14 | Root cause and measure | Missing paperwork is one explanation, not the whole story; test it first. Measure repeat contacts, time to first update, and how many complaints cross the branch and contact-centre boundary. |
| 14 to 17 | Rule | A one-page handoff rule with an owner, tested with the people on both sides. |
| 17 to 20 | Risks and the question | The regulatory clock, the member's outcome, and the branch's view. Close with a question to the panel: where do handoffs fail today? |

**What the panel is scoring.** Structure before answer: clarify first. Challenge one premise respectfully, here the paperwork explanation. Values in play: Own the Fix (the owner), Members First (the member's outcome), Plain Words (the update), Neighbours, Not Numbers (the branch's view of its town).

## 10. Values / principles cheat sheet

**Condition met.** The panel "scores against the four values", per your recruiter's email, which is a loop source. So a values-style round is detected, and it is the panel round.

**Honest note.** Your material carries no finished story for any of the four values. The rows below give selection scaffolds with the honest branch. Build two stories before 29 November in your own words, and send them to me. I will quote them into the fit snapshot.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence carries a story. Scaffold: pick one decision where the member's side changed the outcome. If none, say so and give C2's honest branch. |
| Plain Words | If a member needs it explained twice, it was written wrong | No story. F7's "trained new tellers on our escalation script" carries training, not a rewrite. Scaffold: pick a time you changed how something was explained because the person did not follow it. If none, say so, and give the training quote. |
| Neighbours, Not Numbers | Every branch is part of its town | No story. F3 shows counts, which this value asks you to balance. Scaffold: pick a time a local detail changed a decision. If none, say so. |
| Own the Fix | Whoever finds the problem keeps hold of it until solved | No story. F5 shows a log, not an ending. Scaffold: pick one complaint kept open until solved. If you have none, say so and give the log quote. |

## 11. Reverse questions

Each has a "why it lands". No interviewer profile exists, so none is tied to a career path yet.

**Round 1 (recruiter)**

- "Who reads the monthly complaints report, and what do they decide from it?" Why it lands: it shows you think about what the report is for, which the JD is built on.
- "What does the next step look like after the third round?" Why it lands: it signals that you plan around the process, and it closes the call on a practical note.

**Round 2 (Head of Member Services)**

- "What is the first complaints problem you would want fixed by month six?" Why it lands: it asks your manager what they actually care about, in outcome terms.
- "How will complaints raised through digital channels reach the same log and owner as branch complaints?" Why it lands: it ties to the 40% digital target and tests the seam.
- "What did the last complaints report get wrong, or leave out?" Why it lands: it invites honest feedback on the reporting the job depends on.

**Round 3 (panel)**

- "As branches move into hubs during 2027, what happens to complaints still open at a branch when it closes?" Why it lands: it shows you read the brief and care about the member's side of the change.
- "Where do complaints from your branch get stuck today?" Why it lands: it opens the seam conversation the panel can answer from their own experience.
- Reciprocity (peer): "What could a new person do in their first month that would genuinely help your branch?" Why it lands: it turns the panel from judges into colleagues, which is what the peer-evaluator persona is scoring.

## 13. Prohibited claims

Built locally from the fit snapshot. Each entry names its basis and its honest form. None of these may be coached, even in an answer slot.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F5. The JD widens your sentence about one branch's log | Your sentence at its own scope: "I handled the branch's formal complaints log." The limit is this pack's observation: your material shows one branch. |
| Worked in a contact centre | Negative you stated (F6) | "I haven't worked in a contact centre." |
| Presented to senior leaders | Negative you stated (F9) | "I haven't presented to anyone above regional level." |
| Met regulatory deadlines, or kept the log to a named standard | Inflated form of F2 | "I handled the branch's formal complaints log," at its own scope. |
| Measured resolution times in the spreadsheet | Inflated form of F4 | Your spreadsheet, and what it measured, in your words. This pack does not know which measures it held. |
| Coached branch supervisors on escalations | Inflated form of F7 | "I trained new tellers on our escalation script." |

Digital and self-service (F8) is silence, not a listed claim. It gets an answer slot, not a prohibition.

## 14. Sources

**Provided documents.** The JD you pasted. Ashgrove's values, copied this morning (20 November 2026) and pasted. Your recruiter's process email, as you summarised it. Ashgrove's July 2026 strategy brief, as your summary. I have not read the brief itself. Your background, from your message.

**Searches and fetches sent.** None.

**Research tier: L0, no searches; user links read 0.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet (section 10) and the value names used throughout. The values you pasted this morning fix the names and definitions. |
| 2. Ashgrove interview process, member services | skipped | Round structure and persona weights. The recruiter's email establishes three rounds, with a session and a runner for each. |
| 3. Ashgrove strategy / recent news | skipped | Grounding brief (section 6) and the CO question C3. Your summary of the brief fixes the current priorities. It is not checked against the brief itself. |
| 4. Interviewer name and Ashgrove | n/a | No interviewer names were given, so there was no query to form. The interviewer read is omitted. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## 15. Upgrade menu

- Interviewer names for the three rounds → an interviewer read, persona weights per interviewer, and reverse questions tied to their career paths.
- The 20-minute case brief, if the recruiter has one → turns C4 from a generic case into the actual scenario, with the same walkthrough.
- The strategy brief itself → checks the four figures in section 6, and lets the grounding brief quote the document.
- What your monthly spreadsheet counted, in your words → upgrades F4, B5 and C6 from discovery to presentation or none, and gives their answer slots real beats.
- Any concrete figure from that spreadsheet, such as a volume or a time → raises the defend-the-number questions on B5 and C6.
- Two sentences in your own words about a complaint you kept open until it closed, and a time you held a view with someone senior → turns the values scaffolds into mapped stories where those sentences carry one.
- A tuesday-dossier.md from an earlier engagement → would add verified evidence and prohibited claims.
- Deep research, consent-gated: up to 6 more searches and 2 more fetches, several more minutes → interviewer public footprint, role-family loop reports, and recent organisation context. Offered once.
