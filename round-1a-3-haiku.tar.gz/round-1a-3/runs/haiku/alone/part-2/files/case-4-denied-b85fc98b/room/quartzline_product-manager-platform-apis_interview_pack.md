# Prep pack: Product Manager, Platform APIs at Quartzline

**Round:** 45-minute conversation with the hiring manager, Thursday 26 November 2026. Interviewer not named.
**Built on:** your underwriting dossier (`tuesday-dossier.md`, decision conditional_go, generated 2026-08-14). That is 14 weeks before today, 2026-11-20. Check the posting against the dossier before Thursday. If the requirements have changed, the fit snapshot changes with them.
**Research:** none completed. All three company searches were refused, so values, loop structure and strategy are not established here, and the parts that depend on them are labeled generic.

## 1. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what it scores.
- **Type key:** VAL behavioral and values; EXP your experience, probed; JD the listed job, gaps included; CO company knowledge; CASE a live problem.
- Guidance is scaffolding, not a script. Say it in your own words, and say only what your quoted sentences carry.
- Answer slots are instructions for the interview, not questions to answer here. Either honest branch is a valid answer.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence 1) | high | [grounded] | transferability | Your verified work is integration leadership, which is adjacent to product management. Say it at its own scope: you led 30+ end-to-end client integrations of the vendor's REST APIs. Name the limit: "I haven't held a product manager title." Do not count the integrations as years of PM work. |
| F2 | "Shipped API or platform products" (dossier role_profile R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence 1) | high | [grounded] | transferability | The quote is integration work on the vendor's APIs, not a product you shipped. Keep the bridge at the integrations. Your material does not show a shipped product. |
| F3 | "Technical fluency: API docs, schemas" (dossier role_profile R3) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence 1); "Wrote the internal integration playbook her team uses" (dossier verified_candidate_evidence 2) | high | [grounded] | transferability | REST API integration and architecture reach technical fluency in part. Say what you did with the APIs and the playbook you wrote. The material does not show API reference docs or schemas you wrote, so do not describe them. |
| F4 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence 1); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified_candidate_evidence 3) | medium | [grounded] | discovery | Customers and product appear in your quotes. Engineering and sales do not. Caveat: the roadmap-input line is confirmed with limited inspectable proof, so expect a probe. Answer slot: if you worked with engineering or sales on a client integration, say which and what you did, in your own words. If you did not, say so plainly and stay with the customer and product work. |
| F5 | "Agile delivery experience" (dossier role_profile R5, preferred) | none given | low | [grounded] | discovery | No verified entry speaks to agile delivery. Answer slot: if you ran planning or delivery cadence with engineers on any integration, name it and your part in it, in your own words. If you did not work that way, say so plainly, and say what you would want to confirm about how this team defines agile. |
| F6 | "Owning a roadmap and prioritization authority" (dossier uncertain_or_weak_areas, R1 sub-claim, allowed strategy acknowledge_gap) | none given | none | [grounded] | capability | Stated negative from the dossier's acknowledge_gap area. Words: "I haven't owned a product roadmap." Then say how you would learn it, as a plan and never as a past. |

The dossier file has no `evidence_map`, so the R2 to R4 grades above are this pack's derivation from the dossier's verified quotes. They are labeled as such.

## 3. Prohibited claims

Each entry has its basis and its honest form. No guidance cell, slot, reverse question or drill may assert, soften or imply any entry in the left column.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | dossier prohibited_claims | "I haven't held a product manager title." Plain acknowledgment from prohibited_claims. No slot. |
| Having owned a product roadmap | dossier prohibited_claims; uncertain_or_weak_areas (acknowledge_gap) | "I haven't owned a product roadmap." Plain acknowledgment from the named fields. No slot. |
| Having set prioritization for an engineering squad | dossier prohibited_claims | "I haven't set prioritization for an engineering squad." Plain acknowledgment from prohibited_claims. No slot. |
| Shaped or owned the product roadmap through the roadmap-input sessions | Inflated form of "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified_candidate_evidence 3) | The quote at its own scope: the sessions fed client evidence to product. The limit is the pack's own observation: your material says evidence went to product, not decisions. No slot names a decision. |
| Three years of product management | Inflated form of F1 | The quote at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." |
| Having shipped an API product | Inflated form of F2 | The integration quote at its own scope. |
| Having written API reference docs or schemas | Inflated form of F3 | "Wrote the internal integration playbook her team uses," at its own scope. |

## 4. Persona table

Weights start from the hiring-manager prior (Case/Strategist and Skeptic). There is no interviewer profile and no loop source, so no interviewer signal and no loop adjustment applies. Within those pairs the weights are flat. This is a pattern for hiring-manager rounds, not a claim about Quartzline's process.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Skeptic | Presses the PM-title gap and the roadmap gap | Highest. The prior puts it top, and the dossier names the PM-title objection as the likely first move. | Rehearse the limit until it is plain. Hold the bridge through two follow-ups. | A1 to A5 (5) |
| Case/Strategist | Live roadmap and squad problems | High. The prior puts it top with Skeptic. | Clarify, then structure, then name metrics. | B1 to B4 (4) |
| Data-Driven Prober | Counts the 30+ integrations and the sessions | Medium. The 30+ figure is the likeliest magnet for a probe. | Defend the number in your own words. | C1 to C3 (3) |
| Pressure | Time-boxed challenge on the PM-title gap | Medium. A 45-minute conversation can time-box, and the objection is where pressure lands. | Pause, restate, hold two follow-ups, then concede specifically. | D1 to D3 (3) |
| Conversational | Opening arc and the closing "anything for me?" slot | Medium. Conversations open unstructured, and casual questions are scored. | A 90-second arc, and reverse questions prepared in advance. | E1 to E3 (3) |
| Values/Behavioral | none | Not detected. No loop source established a loop, and the generic archetype reads no values round. The values section is omitted. | none | 0 |
| Peer Evaluator | none | Not plausible for a hiring manager. | none | 0 |

## 5. Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Having held a product manager title or role"; "Having owned a product roadmap" (dossier prohibited_claims); "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence 1); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified_candidate_evidence 3) | Highest-ROI rehearsal. Hold the bridge: "Here's what I did: I led 30+ end-to-end client integrations of the vendor's REST APIs, and I ran quarterly roadmap-input sessions feeding client evidence to product." Concede the limit plainly: "I haven't held a product manager title, and I haven't owned a product roadmap." Then one sentence on your plan for the first 90 days, stated as a plan. Hold through two follow-ups by returning to the integrations. Concede the limit once, specifically. Never add a PM year. | The dossier named this objection in likely_interviewer_objections, so it is the underwriter's rather than an inference. F1 and F6 are the rows it presses. The negatives in the question are sourced from prohibited_claims. |
| A2 | "How would you decide what the platform roadmap prioritises in your first quarter?" | CASE | [generic] | Clarify the goal first: who the partners are and what the squads can deliver. Name the inputs you would gather, and what you would need to confirm about who decides which calls. Say it as a plan. It makes no claim about your past. | Scores how you would decide, not what you decided. It asks about no past, so it presupposes nothing about you. Covers the roadmap part of F6. |
| A3 | "What does agile delivery look like for you with two engineering squads?" | JD | [grounded] "Agile delivery experience" (dossier role_profile R5) | Clarify, then the slot. Answer slot: if you ran planning or delivery cadence with engineers on any integration, name it and your part in it, in your own words. If you did not work that way, say so plainly and say what you would want to confirm about how this team defines agile. Nothing about your past goes in unless it is quoted or sits in the slot. | F5, a discovery gap. The dossier's allowed strategy for this area is clarify. |
| A4 | "How much of the 30+ integrations was actually you, and how much was the team?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence 1) | Name the integrations you led end to end, in those words, and what the team did on them. Answer slot: if you did a part of an integration yourself, say which part and how you decided it. If a part was the team's, say so plainly. Hold through two follow-ups by returning to the quote's own scope: "led end-to-end" is the claim. | An attribution probe on your strongest figure. F1 and F3 both draw on it. |
| A5 | "Tell me about a time you had to manage a stakeholder who disagreed with a client-facing decision." | JD | [grounded] "Stakeholder management across engineering, sales, customers" (dossier role_profile R4); "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence 1) | Story map: pick a client integration where a stakeholder disagreed, and tell it through the stages in your quote. Answer slot: if the disagreement involved engineering or sales, say which and what you did. If it involved only the client, say so and stay there. | An open prompt on R4. F4 is a discovery gap, so the probe will want engineering or sales. The slot keeps the answer inside your quotes. |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch how you would approach the partner API roadmap in your first 90 days. What do you need to know first?" | CASE | [generic] | Clarify, then objective, partners and their adoption, squad capacity, metrics, risks. Think aloud. Name the first question you would ask about who decides which calls. Claim nothing about your past. | A live problem from the role's roadmap responsibility. It asks no past and presupposes nothing about you. |
| B2 | "Partner adoption of the API dropped 20% last quarter. Diagnose it." | CASE | [generic] | Clarify what counts as adoption and its denominator before you guess. Then segments (which partners, which endpoints), approach, metrics, risks. Say plainly that you would need a baseline first. | Covers the adoption-metrics risk the dossier names. Asking for the baseline first is the move the reverse question also tests. |
| B3 | "Two squads disagree on a partner-API change, and the partner wants it this quarter. What do you do?" | CASE | [generic] | Clarify who holds the call and what each squad has committed. Say what you would need to decide it and whom you would take it to. Do not claim the call as yours. | Tests the squad-authority unknown live. The guidance keeps to the prohibited list. |
| B4 | "What would make you say no to a partner's feature request?" | JD | [generic] | Name the criterion you would apply: the other partners, squad capacity, the adoption evidence. Give one case you would refuse, and why, as a principle. | Tests prioritization judgment without claiming a past decision. |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ integrations were counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence 1) | Defend the number. Say how the count was made, in your own words. Name the assumption you would defend least before they do. Say which of the 30+ were yours. Answer slot: if you did not count them yourself, say so plainly. | Every headline figure gets a defend-the-number question. The pack supplies no counting method, because an explanation you cannot repeat under a second question is worse than none. |
| C2 | "Which number would you use to say partner adoption is working, and what would it count?" | JD | [generic] | Name one metric, its denominator, and the assumption you would defend least. Say you would confirm the baseline before you commit to a target. | A metric question on the role's adoption responsibility. It makes no claim about your past. |
| C3 | "How many quarterly roadmap-input sessions did you run, and who attended?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified_candidate_evidence 3) | Give the count and the attendees in your own words. If you do not know one of them, say so. Describe what the sessions fed as evidence, not what product decided. Do not describe a decision the sessions produced unless you can name it. | F4's medium-confidence line. Expect a probe on whether anything came of it, so volunteer the limit first. |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a PM with three years of the job?" | JD | [grounded] "3+ years product management experience" (dossier role_profile R1); "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence 1) | Pause. Restate the question in your own words. Give the adjacent evidence at its own scope, then name the limit. Hold through two follow-ups. Concede specifically: "I haven't held a product manager title." | F1's transferability gap under time pressure. Hold then concede on the limit. Never fold on the integrations. |
| D2 | "That 30+ — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence 1) | Hold then concede. The claim is "led end to end," so say which parts you led. Concede specifically what the team did. Do not fold on "led" to restore harmony. | Attribution pressure on F1 and F3. The held position is the quote's own word. |
| D3 | "You have no roadmap authority. Why would squad leads listen to you?" | JD | [grounded] "Having owned a product roadmap"; "Having set prioritization for an engineering squad" (dossier prohibited_claims); "I haven't owned a product roadmap" (dossier uncertain_or_weak_areas, acknowledge_gap) | Concede the two plain acknowledgments: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then describe how you would work with the squad leads, as a plan. Hold the plan. Do not add a past decision. | F6 and the squad-authority risk. The concession is the sourced acknowledgment, held firmly. |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence 1); "Wrote the internal integration playbook her team uses" (dossier verified_candidate_evidence 2); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified_candidate_evidence 3) | A 90-second arc in your own words: the integrations, the playbook, the sessions. When they ask about the PM title, name the limit in one sentence. Do not tell the arc as a product-management story. | An open register, and still scored. The arc uses only your verified sentences. |
| E2 | "What are you playing with in REST API docs these days?" | JD | [grounded] "Technical fluency: API docs, schemas" (dossier role_profile R3); "Wrote the internal integration playbook her team uses" (dossier verified_candidate_evidence 2) | Describe the playbook and the REST integration work in those words. Do not describe API reference docs or schemas unless you wrote them. If you did not, say so and name the nearest thing you did. | A casual register on the R3 requirement, still scored. F3. |
| E3 | "Tell me about an API or platform you helped ship." | JD | [grounded] "Shipped API or platform products" (dossier role_profile R2); "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence 1) | Open prompt on R2. Choose the client integration you can tell end to end, from scoping to go-live. Answer slot: if none of your integrations was a product you shipped, say so plainly and describe the nearest one. | F2's transferability gap. The slot keeps you inside what the quote carries. |

## 6. Requirement coverage

| Requirement | Questions | Notes |
|---|---|---|
| R1 3+ years product management experience | A1, D1 | F1 |
| R1 sub-claim: owning a roadmap and prioritization authority | A1, A2, D3 | F6 |
| R2 Shipped API or platform products | E3 | F2 |
| R3 Technical fluency: API docs, schemas | E2 | F3 |
| R4 Stakeholder management across engineering, sales, customers | A5 | F4 |
| R5 Agile delivery experience | A3 | F5 |
| Headline figure: 30+ integrations | A4, C1 | Defend-the-number |
| Headline figure: quarterly sessions | C3 | Defend-the-number |
| CO company knowledge | none, and why: the strategy search was refused, so no current-strategy question can be grounded. Bank B covers the live problems in generic form. | — |
| VAL values | none, and why: no values-style round was detected, and the values search was refused. | — |

## 7. Reverse questions

| # | Question | Why it lands | Source |
|---|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Asks the squad-authority unknown directly. The answer shows whether your F6 gap is the job's gap or a mismatch. | dossier questions_for_employer |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | Goes to the adoption-metrics risk. The dossier notes that no baseline is stated. | dossier questions_for_employer |
| 3 | "What would a new PM need to know in the first month to help the two squads?" | Turns the conversation toward a plan you can pursue, and shows you are thinking about the squads. | [generic] |
| 4 | "What would a successful first six months look like for this role?" | Tests the bar your bridge has to clear, in their words. | [generic] |
| 5 | "What has made this role hard to fill?" | Shows you the risks you would walk into, and whether they match the dossier's risks. | [generic] |

No interviewer profile exists, so no reverse question ties to the interviewer's path.

## 8. Sources

- **Provided documents:** your message, including the dossier pasted in conversation (`tuesday-dossier.md`, dossier_version 1.1, generated 2026-08-14, role Product Manager, Platform APIs, stage interviewing, decision conditional_go).
- **Dossier consumed.** Sections supplied: `role_profile` (requirement text as the supplied JD's lines; responsibilities and unknowns as the underwriter's analysis), `handoff_to_mock_interview` (all entries), and `decision` (context only). Not present in the file: `evidence_map`, `evidence_state`, `risk_register`, `candidate_constraints`, `gap_queue` and `application_plan`.
- **Dossier age.** Generated 14 weeks before today. Re-check the posting before Thursday.
- **Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read: none.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Values section. One search sent: "Quartzline values," refused (search permission not granted in this session). No values-style round is detected, so the section is omitted either way. |
| 2. Quartzline interview process product manager platform APIs | unavailable | Loop structure and persona weights. One search sent, refused. Weights stay on the hiring-manager prior with the generic archetype. |
| 3. Quartzline strategy recent news | unavailable | The CO bank. One search sent, refused. CO questions are generic; no current-strategy question is grounded. |
| 4. Interviewer name and company | n/a | No interviewer name was given, so there was no query to form. The interviewer read is absent. |
| 5. Representative JD | skipped | The dossier's role_profile fixes the requirements and the JD-tagged questions. |

Refused calls, listed in full: "Quartzline values" (refused); "Quartzline interview process product manager platform APIs" (refused); "Quartzline strategy recent news" (refused). No retries were sent.

## 9. Upgrade menu

- **Current posting** → re-checks R1 to R5 and the fit snapshot against what the role now asks, since the dossier is 14 weeks old.
- **Search permission for this session** (or the recruiter's email on the round format) → the values section, loop structure, and CO questions grounded in current strategy.
- **Interviewer's name** → an interviewer read, persona weights from their public footprint, and a tailored reverse question.
- **Deeper research, L2** (offered once): up to 6 more searches and 2 more fetches, several more minutes. Want it?
- **The source behind "30+"** (a list or record of the integrations) → A4 and C1 can be answered with a named record instead of a count you must defend from memory.
- **Your CV** → the quotes in F1 to F4 move from the dossier to your own words. The guidance does not change.
