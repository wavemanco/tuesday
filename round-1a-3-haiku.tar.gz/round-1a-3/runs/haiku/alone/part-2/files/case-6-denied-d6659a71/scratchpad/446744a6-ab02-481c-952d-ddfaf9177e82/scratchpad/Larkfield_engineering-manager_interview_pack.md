# Larkfield Systems: Engineering Manager, three-round prep pack (loop mode)

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, ~600 people)
**Candidate:** Yusuf
**Rounds:** (1) hiring manager, Director of Engineering, 45 min; (2) panel, two staff engineers and a product manager, 60 min; (3) VP Engineering, 30 min, described by the recruiter as "values and leadership philosophy"
**Research tier:** L1, not achieved. Both searches were refused (see Sources). This pack rests on your material and the role description you gave.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored.

- **VAL**: behavioural / values alignment
- **EXP**: deep-dive on your own experience
- **JD**: the role's stated responsibilities
- **CO**: company and strategy knowledge (not covered; no research ran)
- **CASE**: live problem from the role

Guidance is scaffolding, not a script. Every claim about your past is one of your own quoted sentences, a plain acknowledgment of a gap you stated, or an answer slot. Where a question asks what you did, answer from what you actually did.

## Cross-round plan (about two weeks)

Your three rounds share one story set. Build the material once and rehearse it in three shapes.

1. **Days 1–3: the three gaps you named.** Say the plain acknowledgments aloud: "I haven't managed managers." "I haven't owned a hardware-adjacent roadmap." Then give each a 90-day learning plan, said as a plan, never as a past. Banks A2, B6, C6, C7.
2. **Days 4–6: the reliability quarter, one story, five probes.** Write its arc in at most your own quoted scope: the reliability quarter, the roadmap pressure, the 60% drop. Prepare the defend-the-number answer for the 60%: how it was counted, the weakest assumption, which part was yours. Banks A4, A5, B1, B2, C4.
3. **Days 7–9: the hiring loop and the team of six.** Prepare what you decided in the backend loop, and what you decided as a team lead of six. Banks A6, A7, B5, C8.
4. **Days 10–11: the hardware ramp plan.** One page: what you would learn first about hardware-adjacent roadmaps, and who you would ask. Banks A3, A8, B3, B4.
5. **Days 12–13: drill.** Run the Skeptic on A2, the Pressure persona on C3 and C4, and the panel's product question on B4.
6. **Day 14, before round 3:** ask the recruiter for Larkfield's published values (see the upgrade menu). Then write the values mapping for round 3.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says a team lead of six, not two squads. Words: "I've been a team lead of 6 for 3 years." Answer slot: if you led work across more than one team, say which and what you decided; if not, say so and stay with the team of six. |
| F2 | "own delivery, hiring and growth for 11 engineers" — your message | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | transferability | Your material says the hiring loop for backend roles, not hiring across eleven engineers. Words: "I run the hiring loop for backend roles; last year that was about 40 interviews." Answer slot: if you set the bar or made hire decisions in those loops, say which; if not, say so. |
| F3 | "own delivery, hiring and growth for 11 engineers" — your message | none given | none | [grounded] | discovery | Your material does not show developing engineers. Answer slot: name one engineer you developed and what changed, in your own words; if none comes to mind, say so and say how you would start. |
| F4 | "partner with hardware and product on roadmap" — your message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | You stated the absence. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F5 | "Lead two squads building device-management services" — your message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | You stated the absence. Words: "I haven't managed managers." Then how you would learn it, said as a plan. |
| F6 | "partner with hardware and product on roadmap" — your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | presentation | The quote already reaches roadmap trade-offs under product pressure. Words, rewording only: "I pushed a reliability quarter through against roadmap pressure, and on-call burden dropped 60%." The 60% is a figure you gave, so it raises the defend-the-number slots in bank A (A4) and bank B (B2). |

**The gap map in one line:** two stated absences (manager-of-managers, hardware-adjacent roadmap) are capability gaps. Team scope (team of six, not two squads or eleven engineers) and org-scale hiring are transferability gaps. Developing people is a discovery gap, since your material is silent on it.

## Prohibited claims

Built locally, since no dossier is present. Each claim lists its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've managed managers" | Negative you stated (F5) | "I haven't managed managers." Plain acknowledgment, no slot |
| "I've owned a hardware-adjacent roadmap" | Negative you stated (F4) | "I haven't owned a hardware-adjacent roadmap." Plain acknowledgment, no slot |
| "I led delivery for eleven engineers" or "I managed two squads" | Inflated form of F1 and F2 | F1's quote at its own scope: "3 as a team lead of 6." The limit is this pack's observation: your material shows a team of six. |
| "I designed the hiring loop" or "I set the bar for the org" | Inflated form of F2 | F2's quote at its own scope. A slot asks only which decisions you made in the loop you run |
| "The 60% drop was my work" or "I drove the reliability work across the org" | Inflated form of F6 | F6's quote at its own scope. A slot asks which part of the reliability quarter was yours to decide |

## Interviewer read

Dropped. No interviewer profile was given. Persona weights come from round-type priors and the loop itself.

## Persona weights by round

| Round | Dominant personas | Reasoning | Counter-strategy |
|---|---|---|---|
| 1. Hiring manager (45 min) | Case/Strategist (top) and Skeptic (top) | A hiring manager buys capability and de-risks gaps; expect live problems on the actual roadmap | Clarify before structuring. Rehearse the two stated gaps until they are plain. |
| 2. Panel (60 min) | Peer Evaluator (staff engineers and PM) and Data-Driven Prober (staff engineers) | Peers price what the hire costs their work. Staff engineers probe the numbers. The PM tests the roadmap seam. | Propose seam principles, not facts. Name the weakest assumption behind the 60% before they do. |
| 3. VP Engineering (30 min) | Values/Behavioral (top) and Pressure (top) | The recruiter's own words, "values and leadership philosophy", detect a values round. A VP tests composure and altitude. | Map each story to a value only where your quote carries it. Hold-then-concede on the core claim. |

Weights are shown so you can recalibrate. If you know the interviewers' backgrounds, send them and I'll reweight.

## Round 1: hiring manager (Director of Engineering, 45 min)

Depth: Case and Skeptic at 4 questions each in this bank's weighting; EXP at 3.

**Highest-ROI prep:** A2. The Skeptic's objection, "you've never managed managers", is the single most predictable question for you in this loop. Rehearse it until the plain acknowledgment and the 90-day plan come out without hedging.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two squads, and one is slipping on a hardware dependency. What do you do first?" | CASE | [generic] | Clarify: what is slipping, what the dependency is, who owns it. Then structure: the squad's next delivery, the hardware team's constraint, what you tell product. Think aloud. The question needs no claim about your past, so give none. | A live problem from the role's hardware-and-roadmap line. [generic] because it is a pattern, not a fact about Larkfield. |
| A2 | "You've never managed managers. What would make you fail in this role?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Plain acknowledgment: "I haven't managed managers." Then the honest risk and a 90-day plan: what you would learn first, from whom, and how you would check it. Hold through two follow-ups by returning to the plan. | F5 is the stated gap this question is aimed at. The question's premise is your own sentence, so it is a fair open prompt. |
| A3 | "Which part of this role would you be weakest at on day one?" | Skeptic stem | [grounded] "I've never owned a hardware-adjacent roadmap." | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then a plan for learning it: which hardware constraints you would ask about first and who would teach you. Do not claim adjacent hardware work. | F4's stated gap, rehearsed so the honest answer is ready. |
| A4 | "Walk me through how the 60% on-call reduction was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Defend-the-number, in your words: the baseline period, the incidents or pages counted, the time window, what changed in the team around it. Answer slot: name the assumption you would defend least. If you did not track how it was counted, say that plainly. | F6's figure. A figure you gave raises these slots; the pack supplies no method, baseline or attribution model. |
| A5 | "Walk me through the reliability quarter you pushed through against roadmap pressure." | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Story map from the quoted sentence: the quarter, the roadmap pressure, and that you pushed it through. Answer slot: if someone objected or something was traded away, say what and how you handled it; if nothing was traded away, say so, and stay with the quarter. | F6's story. The sentence carries the quarter and the pressure, nothing about who objected. |
| A6 | "Walk me through the hiring loop you run for backend roles." | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say what you run and the scale: backend roles, about 40 interviews last year. Answer slot: if you set the rubric, the bar or the hire decision, say which and how; if you ran the process without setting those, say so. | F2. The JD's hiring requirement is covered at the scope the quote carries. |
| A7 | "How have you developed the engineers on your team?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Honest branch: name one engineer you developed and what changed, in your words. Answer slot: if you cannot name one, say so and describe how you would start with eleven engineers. | F3. Silence in the material is discovery, so the answer must come from you. |
| A8 | "The device fleet's firmware rollout fails on a small share of devices. What is your first hour?" | CASE | [generic] | Clarify scope and blast radius, stop the rollout, get the failure data, check the hardware team's view, then decide who tells product and when. Think aloud. | A live problem in the role's hardware domain. Generic, so no claim about your history. |

**Reverse questions, Round 1.** Interviewer profile missing, so these are role-generic.

1. "What does success look like for the two squads at six months?" Why it lands: it shows what the Director will score you against.
2. "Where has the hardware dependency hurt delivery most in the last two quarters?" Why it lands: it shows you already know where the roadmap risk sits.
3. "What would you want the new engineering manager to change in the first 90 days?" Why it lands: it turns the stated gap into a shared plan.
4. "How is the 11-person team split between the two squads, and where is the hiring plan?" Why it lands: it tests whether the scope you are being offered is as described.
5. "What would you need to see in the first month to feel this hire was right?" Why it lands: it asks for the scorecard in the Director's words.
6. "How do you balance roadmap work and reliability work right now?" Why it lands: it connects to your reliability quarter without claiming it.

## Round 2: panel (two staff engineers and a product manager, 60 min)

Depth: Peer Evaluator at 4 questions, Prober at 3, Skeptic at 2.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where is the seam between your squads and the hardware teams, and what happens when you disagree with product?" | JD | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Propose seam principles, not facts about Larkfield's seams: who decides what, how disagreements get escalated. Then use the reliability quarter as the one disagreement you can speak to, at its quoted scope. | Peer stem from the Peer Evaluator. The disagreement is the one your quote carries. |
| B2 | "Which assumption behind the 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60%" | Weakest-assumption move, in your words, before they ask. Answer slot: if you did not track how it was counted, say that plainly and name what you would check first. | Defend-the-number slot from F6's figure, asked by a Prober. |
| B3 | "How would you know a device-management service is reliable enough to ship to a fleet you cannot easily patch?" | CASE | [generic] | Clarify the failure modes, the rollout gates and the rollback path. Say which assumptions need the hardware team's input. Make no claim about IoT fleet experience. | A staff engineer's technical probe. Generic because it is a pattern. |
| B4 | "How would you split roadmap capacity between reliability and features?" | JD | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Hold your position through two follow-ups: reliability work earns time when the on-call cost is measured. Concede specifically where the trade-off is uncertain. Do not claim a split you have run. | The PM's roadmap probe, premised on your quoted sentence. |
| B5 | "Walk me through the bar you hold for a senior backend engineer." | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Answer slot: if you set the bar, describe it and where it came from. If the bar was set by others and you applied it, say so plainly. | A staff probe on F2. The answer only says what you decided. |
| B6 | "Hardware isn't your background. Why should the hardware team trust your roadmap calls?" | Skeptic stem | [grounded] "I've never owned a hardware-adjacent roadmap." | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then how you would earn trust: ask the hardware team what they need to see, and show the first two decisions you would take to them. | F4's stated gap, pressed by the PM. |
| B7 | "Walk me through your path to here." | Conversational | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Pre-scripted 90-second arc from the quoted sentence: nine years of engineering, three as team lead of six, now at a payments company. Say what you did in those roles in your own words. Do not add scope. | Open prompt, story-mapped from E1. Casual openers are scored. |
| B8 | "A firmware rollout fails on a small share of devices. What is your first hour?" | CASE | [generic] | Clarify blast radius, stop the rollout, pull failure data, consult the hardware team, then decide who tells product. Think aloud. | A staff engineer's live problem. Generic. |

**Reverse questions, Round 2.** Interviewer profile missing, so these are role-generic. The panel includes peers, so one question is a reciprocity question.

1. "What could a new engineering manager do in their first month that would genuinely help your team?" Why it lands: this is the peer reciprocity question. It shows you are thinking about what you bring.
2. "Where do the squads' services meet the firmware, and who owns that boundary?" Why it lands: it tests the seam question from the other side.
3. "What is the most common disagreement between engineering and product on device roadmaps?" Why it lands: it names the PM's real tension.
4. "What does a good design review look like here?" Why it lands: it tells you how staff engineers judge a proposal.
5. "What do you wish the last engineering manager had done differently?" Why it lands: it surfaces the team's real need, asked as a peer.

## Round 3: VP Engineering (30 min, "values and leadership philosophy")

Depth: Values/Behavioral at 4 questions, Pressure at 3, Skeptic at 1.

**Values section.** Section 10 (the values cheat sheet) is omitted. A values round is detected from the recruiter's own words, but Larkfield's published values are not in hand, because the search was refused. The questions below take their theme from the recruiter's words. Where none of your quotes carries a story, each has a selection scaffold ending in an honest branch.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Story map from the quoted sentence: the quarter, the pressure, that you pushed it through. Answer slot: if the truth you delivered was a different one, pick it and describe the moment in your own words. If no such moment comes to mind, say so plainly, then give the reliability quarter at the scope your quote carries. | Open prompt. The theme comes from the recruiter's "leadership", and the story comes from your quote. |
| C2 | "What is your leadership philosophy in one minute?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Pre-scripted arc from the quoted sentence: how you came to lead, what you have led, and what you have learned. Keep to the team of six. Do not preview scope you have not led. | Open prompt. The recruiter named this round as leadership philosophy. |
| C3 | "Why would I trust a team lead of six to run two squads and eleven engineers?" | Pressure | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Hold through two follow-ups on the core claim: what carries over from six to eleven, and what you would do first to test that. Concede specifically where it does not carry over. Do not claim scope you have not run. | Pressure stem on the scope gap in F1. |
| C4 | "That reliability result: how much of it was actually you?" | Pressure | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold your part and name the rest honestly: the team's work, the on-call rota, the roadmap owner's decision. Answer slot: say which part was yours to decide and which was not. | Pressure stem on F6. The honest branch is the one the pack wants. |
| C5 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer's need changed a delivery decision, and name the metric you let go. If no such time comes to mind, say so plainly, then give the nearest decision your material carries, or how you would handle it. | Stem from the Values persona. No quote carries it, so the scaffold ends in its honest branch. |
| C6 | "What would you need to learn before you owned hardware-adjacent roadmap decisions?" | Skeptic | [grounded] "I've never owned a hardware-adjacent roadmap." | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then a learning plan, said as a plan. | F4's stated gap, asked at the VP's altitude. |
| C7 | "How would you develop managers if you have never managed managers?" | VAL | [grounded] "I've never managed managers" | Plain acknowledgment: "I haven't managed managers." Then the plan: which managers you would learn from, and what you would watch for. | F5's stated gap, pressed at the VP's altitude. |
| C8 | "Describe a time you turned down a strong candidate, or hired one you later regretted." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Selection scaffold from the quoted sentence: pick one hire decision you made in the loop. Say what you decided and what happened after. Answer slot: if you have no regret, say so. If you have no decision you were accountable for, say so. | Open prompt. The hiring loop is the story source; the outcome is yours to name. |

**Reverse questions, Round 3.** Profile missing, so role-generic.

1. "What does leadership here expect a team lead to change first when they move up a level?" Why it lands: it names the transition you are being asked to make.
2. "Give me one example of a decision that showed the company's values in practice." Why it lands: it asks for proof, not slogans.
3. "How do you want managers to handle a disagreement with product?" Why it lands: it tests the leadership philosophy against the hardest seam.
4. "What leadership mistake do you see new managers make here most often?" Why it lands: it shows you learn from the company's own pattern.
5. "How does the company support managers who are managing managers for the first time?" Why it lands: it is the stated gap, asked as a question about support.

## Sources

**Provided documents:** your message (the role description, your background and your three round descriptions). No CV, no JD text, no dossier, no pasted values page, no strategy brief, no interviewer profile.

**Searches and fetches:**

- `Larkfield Systems values`: refused. Permission to use WebSearch was not granted in this session.
- `Larkfield Systems interview process engineering manager`: refused. Same cause.
- No fetches were attempted.

**Research tier:** L1. Searches 0 of 6 (2 refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have fixed the values cheat sheet (section 10), which is omitted. Round 3 values questions use the recruiter's words instead. |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have confirmed the loop. The loop here rests on your own description of the three rounds, which establishes it. |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have moved the CO bank. No CO questions were written. |
| 4. Interviewer name + company | n/a | No names were given, so there was no query to form. |
| 5. Representative JD for the title | unavailable | No JD text was supplied, so the fit snapshot's requirements come from your role description. A representative JD would have made requirements [inferred]. |

**Loop established by:** your message, which names three rounds with their length, interviewer type and purpose. Persona weights follow those rounds.

**Recruiter wording:** "values and leadership philosophy" (the recruiter's words, as you reported them). This detects the values-style round.

## Upgrade menu

- **The full JD text** → the six `[grounded]` requirement rows (F1 to F6) become quoted from the posting, and the JD-tagged questions get their own quotes. If the JD names requirements I haven't covered, I'll add rows for them.
- **The recruiter's focus areas for the panel and the VP round** → shapes the panel and VP banks around what they will score.
- **Any pre-declared deliverable (take-home, presentation, POV)** → adds a build section per deliverable. None is in the material now.
- **Interviewer names (Director, staff engineers, PM, VP)** → persona weights read from public footprint, and path-tied reverse questions. The Director's path is the one that matters most for round 1.
- **Larkfield's published values page** → the values cheat sheet (section 10) becomes possible. It maps each value to your quoted stories. Ask the recruiter for it; a search will also work if permission is granted.
- **Working search (L1, then L2 if you want it)** → the company's values, loop, and current strategy. L2 would add a strategy brief for the CO bank, and up to 6 more searches and 2 more fetches, several more minutes.
- **`tuesday-dossier.md`** → if one is produced, the underwriter's evidence map would replace the local prohibited list and sharpen the grading.
