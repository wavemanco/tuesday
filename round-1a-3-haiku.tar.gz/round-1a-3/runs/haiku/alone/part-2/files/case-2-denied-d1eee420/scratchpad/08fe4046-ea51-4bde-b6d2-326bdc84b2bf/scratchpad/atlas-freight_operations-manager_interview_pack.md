# Operations Manager, Atlas Freight: interview prep pack

Session mode. Round: unknown, built on a hiring-manager prior because your note didn't say who you're meeting. Research did not run (search permission was refused), so nothing here about Atlas Freight comes from outside your message.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioral/values · **EXP** your own work, probed · **JD** the listed job · **CO** company knowledge · **CASE** a live problem.
- Guidance is scaffolding, not a script. Say it in your own words. Anything in quotation marks is your own sentence.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows warehouse and shift work, not four sites. Answer slot: if you have been accountable for daily operations at more than one site, say where and how; if not, say so, and say how you would apply the shift-level control you have run to four sites. |
| F2 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows three supervisors. Answer slot: if you have led more supervisors or managers than these three, say how many and where; if not, say so, and describe how you would structure twelve. |
| F3 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material says mis-pick rate, not on-time performance or cost per shipment. Answer slot: if you tracked on-time or cost per shipment in any role, say which and what moved; if you did not, say so and stay with the 40%. |
| F4 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | medium | [grounded] | presentation | Your material says "solid Excel", and stops there. The Excel half of the requirement is reached in other terms; the words stay with the quote. |
| F5 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | high | [grounded] | capability | A gap you stated, so the words are yours: "I haven't used Power BI." Then how you would learn it, said as a plan, never as a past. |
| F6 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | low | [inferred] | discovery | Total operations years are shown; leadership years are not. Not a gate (length of experience), so it is graded like any other row. Answer slot: the date your first people-leadership role began, in your own words; if it is under five years, say so plainly. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | No gap. A certificate you can show is inspectable, not yet inspected. Expect a probe on what it was applied to: see E2. |

Confidence grades your evidence; Provenance grades this pack's statement. The pack observes that your material does not show leadership years (F6) and does not show four-site work (F1); those observations are analysis, not words for you.

## Prohibited claims

Built locally from the fit snapshot. These wordings are not coached, and no answer slot, hold or rationale asserts them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned daily operations across four sites | Inflated form of F1 | F1's quote at its own scope: the material shows warehouse and shift work. |
| Led twelve supervisors | Inflated form of F2 | "over 3 supervisors" |
| Owned on-time performance and cost per shipment | Inflated form of F3 | The 40% mis-pick reduction, at its own scope. |
| Built Power BI reports, or any Power BI experience | Stated negative, F5 | "I haven't used Power BI." No slot. |
| Designed the peak-season surge plan | Inflated form of "ran the site's peak-season surge plan two years running" | "ran", at its own scope. |

Five years of leadership is not listed: the material is silent on it, so it is an answer slot (A2), not a prohibited claim.

## How to use the rest of this pack

Confidence and gap type are in the fit snapshot; each question row carries its own quotes in Provenance. Answer slots are instructions for the interview, not questions to me.

## Persona table

Relationship unknown, so the weights are the hiring-manager prior: they are buying capability and checking gaps, and they will test the JD line by line. Weights move if you tell me the relationship.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the gaps: scope, tenure, Power BI | High. Your three gaps (scope, leadership years, Power BI) are the ones a hiring manager checks first. 5 questions. | Know the scope and tenure facts cold; say the Power BI sentence plainly, then the plan. |
| Case / Strategist | Live problems from this job: four sites, on-time, cost per shipment, reporting | High. The JD is a set of operating problems, and this persona scores structure. 5 questions. | Clarify before structuring; state the first metric you would pull; name one risk. |
| Data-Driven Prober | Asks how your 40% and your Excel work were counted | Medium. Your one hard number invites it. 4 questions. | Say what you know about how it was counted, and say plainly what you do not. |
| Pressure / Stress | Time-boxed challenge to your fit | Lower. Standard for senior roles but not signalled. 2 questions. | Hold the position through two follow-ups, then concede the specific gap. |
| Conversational / Rapport | Friendly opener, JD plus-skill asked casually | Lower, but scored. 2 questions. | A 90-second arc; treat the casual question as scored. |

## Question banks

Coverage line first: every JD requirement, and the question IDs that cover it.

| Requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A4, D3 |
| Drive on-time performance and cost per shipment down | C4, D1, D2 |
| Lead a team of 12 supervisors | A1, B1 |
| Build reporting in Excel/Power BI | C3, D5, A3 |
| 5+ years operations leadership | A2 |
| Lean/Six Sigma a plus | E2 |

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You lead three supervisors today. This role leads twelve across four sites. What's the difference, and how would you close it?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | **Highest-ROI prep in this pack.** Answer slot: if you have led more supervisors or managers than three, say how many and where; if not, say so plainly and describe how you would build a twelve-supervisor structure from the three you lead. Hold through two follow-ups by returning to the three you lead, and concede the scope gap by name. | F2 is the largest scope gap, and the question presupposes only what your quote says. |
| A2 | "The role requires five-plus years of operations leadership. When did your first people-leadership role start?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Answer slot: give the date your first people-leadership role began, in your own words. If it is under five years, say so plainly, then point to the shift and surge work your material does show. | F6: total years are yours, leadership years are not in the material. The question asks for a date, not a claim. |
| A3 | "You haven't used Power BI. What's your plan for the reporting side?" | JD | [grounded] "never used Power BI" (your message); JD "build reporting in Excel/Power BI" | Plain acknowledgment: "I haven't used Power BI." Then the plan: start with the Excel reporting you already do, name how you would learn Power BI, and say a timeline only if it is yours. Never describe Power BI work as done. | F5, a stated gap: the words are yours and the rest is a plan. |
| A4 | "This role owns daily terminal operations across four sites. Which sites or terminals have you run yourself, and how?" | JD | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Answer slot: name the site and the period you ran it, in your own words. If you ran more than one site, say which and how; if not, say so and describe how you would run four. | F1: the question asks which sites, which the quote does not answer. Stay inside the one site you ran. |
| A5 | "What draws you to this operations manager role over your current senior shift role?" | [generic] | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Give your own reason, in your own words, from what the role adds: scope, sites, reporting. Do not describe the company, which the pack has not researched. | A motivation probe every hiring manager runs; it asks for your reason, not a claim about them. |

### B. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: why should we hire you over someone who already runs four sites?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message); [grounded] "ran the site's peak-season surge plan two years running" (your message) | Hold-then-concede: anchor in the 40% and the two peak seasons, then concede the four-site gap in one sentence. Do not fold on the strength of the results. | Pressure test of fit; the position held is only what your quotes carry. |
| B2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Say what you did, the redesign of the pick path, in your own words. Answer slot: if others made part of the change, name which parts, and which were yours. | Attribution probe; the question is premised on your sentence, and the answer is yours to give. |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Defend-the-number: answer slot. If you know the baseline period, the count method and which part was yours, say them in your own words. If you do not know how it was counted, say so plainly. The pack supplies no baseline or method. | F3: the number is yours, and an explanation you cannot repeat under a second question is worse than none. |
| C2 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Weakest-assumption move: name the assumption in your own words before they do. If none comes to mind, say so. | Standard prober follow-up on a headline figure. |
| C3 | "What have you used Excel for in operations reporting?" | JD | [grounded] "solid Excel" (your message); JD "build reporting in Excel/Power BI" | Name the reports you produced, in your own words. Keep "solid" as your word; do not upgrade it. Answer slot: if a report was used by others, name it and who used it; if not, say what you did with Excel. | F4: the Excel half of the requirement, at the scope your quote gives. |
| C4 | "You ran the surge plan two years running. What did the numbers look like, and how were they counted?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Answer slot: if you have figures for the surge plan, give them and the count method in your own words. If you do not, say so, and name what you tracked. | The question asks for figures your material does not give; the answer is yours. |

### D. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Terminal A's on-time performance dropped eight points last month. Walk me through your first 48 hours." | CASE | [generic] | Clarify first: what counts as on time, which lanes and shifts. Then state the objective, segment by shift and dock, name the first metric you would pull, one approach, one risk. Do not claim a past case. | A live problem from the JD's on-time line; asks about no past. |
| D2 | "Cost per shipment is up across all four sites. Where do you start?" | CASE | [generic] | Clarify the cost basis and period; split cost per shipment into labour, handling and transport; pick the largest driver to test first. Name the risk of cutting cost at the expense of on-time performance. | Tests the JD's cost-per-shipment line as a live problem. |
| D3 | "Four sites run different volumes and shift patterns. How would you set one daily operating rhythm across them?" | JD | JD "Own daily terminal operations across 4 sites" | Structure: one daily review, one set of metrics, site-level exceptions. Say what you would standardise and what you would leave to each site. | The JD's four-site line as a design problem; no claim about your past. |
| D4 | "Volume runs 25% above normal for six weeks. What goes in place in week one?" | CASE | [generic] | Structure: staffing, the surge plan's trigger, the daily exception list, and what you would stop doing to make room. Say what you would check first. | A live surge problem; you may draw on your own surge work only in your own words (see E1). |
| D5 | "What would you put on a weekly terminal dashboard, and how would you build it before Power BI?" | JD | JD "build reporting in Excel/Power BI"; [grounded] "never used Power BI" (your message) | Name the metrics you would track (on-time, cost per shipment, mis-pick rate) and start in Excel. Power BI as a plan, not a past. | Covers the reporting requirement honestly: the Excel route is the one your material supports. |

### E. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); [grounded] "currently a senior shift manager over 3 supervisors" (your message); [grounded] "green belt certified" (your message) | A 90-second arc in your own words: years, current role, the pick-path result, the surge plan, the Green Belt. Add nothing. | Opening arc; the casual register is still scored. |
| E2 | "What's your Six Sigma work been like?" | EXP | [grounded] "green belt certified" (your message) | Answer slot: if you used the Green Belt method on the pick-path work, say so; if not, say so, and name what you would apply it to. | F7: a plus, asked casually; the answer is what you actually applied. |

## Reverse questions

Six, each with why it lands. No interviewer profile exists, so none is tied to a career path.

1. "What does the first ninety days look like for someone taking over daily operations across the four sites?" Why it lands: shows you are planning for the scope, not only the title.
2. "Which of the four sites is furthest from its on-time target right now, and what is driving it?" Why it lands: shows you think in site-level numbers.
3. "How is reporting built today, and who owns it?" Why it lands: your Power BI gap is the honest opening to discuss the reporting setup.
4. "How are the twelve supervisors spread across the sites?" Why it lands: tests the scope and shows you asked before assuming.
5. "What separates the people who succeed in this role from the ones who struggle in the first six months?" Why it lands: asks for their criteria, which you can then meet in your own words.
6. "How has the peak-season plan been run, and who owns it now?" Why it lands: links your surge experience to their real practice.

## Sources

Provided documents: the job description and background in your message.

Searches and fetches sent: none returned results. Two searches were sent and refused by the host, because search permission was not granted in this session:

- "Atlas Freight regional logistics company values": refused.
- "Atlas Freight operations manager interview process terminal": refused.

I could not confirm Atlas Freight publicly from this session. Nothing about the company's values, process or strategy is in this pack.

Research tier: L0, since search was refused.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet, and VAL questions, not included. |
| 2. Atlas Freight interview process | unavailable | Loop structure and persona weights, which stay at the hiring-manager prior. |
| 3. Atlas Freight strategy / recent news | unavailable | CO questions and a grounding brief, not included. |
| 4. Interviewer name | n/a | No name given. |
| 5. Representative JD | skipped | Your JD fixes the fit snapshot. |

## Upgrade menu

- The round type and who you meet (manager, peer, skip-level) → reweights every bank; the current weights are a hiring-manager prior.
- Working search permission → Atlas Freight's values, interview loop and strategy, which add a values cheat sheet and company-specific questions.
- The interviewer's name → a tailored reverse question and persona weights read from their public footprint.
- Your first people-leadership start date → upgrades the answer in A2 from a slot to a stated fact.
- How the 40% was counted (baseline period, count method) → upgrades C1 and F3 from answer slots to quotes you can defend.
- Your Green Belt certificate → makes F7 inspectable; the upgrade is the artifact itself, not more words.
- `tuesday-dossier.md` from job-underwriter → would add evidence-verified confidence bands and a prohibited-claims list built from a checked record, not from this pack's own reading.
