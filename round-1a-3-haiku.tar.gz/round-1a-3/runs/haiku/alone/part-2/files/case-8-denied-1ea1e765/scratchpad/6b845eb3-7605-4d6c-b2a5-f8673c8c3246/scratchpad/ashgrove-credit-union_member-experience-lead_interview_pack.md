# Ashgrove Credit Union: Member Experience Lead interview pack

- **Role:** Member Experience Lead, Ashgrove Credit Union (member-owned, about 900 staff)
- **Round 1:** recruiter, 30 minutes
- **Round 2:** Head of Member Services (your prospective manager), 45 minutes, mostly behavioural
- **Round 3:** panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case; scored against the four values
- **Interviewer names:** not given
- **Built:** 20 November 2026, for 29 November 2026

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. The guidance is scaffolding, not a script: say it in your own words.

Every sentence the pack says about your past is one of your own sentences, quoted in the tables. Where your material does not show something, the guidance is a question you answer truthfully, not a line to say.

Type key:

- **VAL:** values. Does past behaviour show a published value?
- **EXP:** your experience. Does what you did survive questions?
- **JD:** the job's stated responsibilities and requirements, including gaps.
- **CO:** company and strategy. Do you think at their altitude?
- **CASE:** a live problem from the role.

"Your message" below means the background you gave in this conversation. No CV was supplied.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as branch supervisor." (your message) | medium | [grounded] | none | No gap as worded. Say the quote as it stands. Your material says retail banking and a supervisor role. It does not say "customer operations", so do not stretch the term. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | Adjacent work. Say it at its own scope: "I handled the branch's formal complaints log." Answer slot: the JD raises regulated complaints. If you were responsible for a deadline or reporting rule, say which and how, in your own words. If you were not, say so plainly. |
| F3 | "confident presenting to senior leaders" (JD) | "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't presented to anyone above regional level." Then how you would learn it, said as a plan, never as a past. |
| F4 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | A gap you stated, for the contact-centre part. Words: "I haven't worked in a contact centre." Then a plan, not a past. |
| F5 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | Adjacent work at one branch's scope. Say: "I handled the branch's formal complaints log." Answer slot: if you handled complaints across more than one branch, say which. If it was one branch's log, say so and stay with it. |
| F6 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | low | [inferred] | discovery | Monthly reporting is shown. Volumes and resolution times are not. Answer slot: if the spreadsheet counted volumes or resolution times, say what and how. If it did not, say so and say what you would count first. |
| F7 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | Your quote already reaches reporting, in the word "spreadsheet". Say it: "I built the monthly complaints spreadsheet our regional manager uses." Name the tool you built it in. |
| F8 | "coach branch supervisors on escalations" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." and "6 years in retail banking, the last 3 as branch supervisor." (your message) | low | [inferred] | transferability | Training tellers on the script is adjacent to coaching supervisors. Say it at its scope: "I trained new tellers on our escalation script." Answer slot: if you coached a supervisor or a peer on an escalation, say how. If not, say so and say how you would start. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | No sentence in your material speaks to this. Answer slot: if you worked with a digital team on a member-facing journey, name it and your part. If not, say so plainly and say how you would start. |

No row is a gate. None of the JD's requirements is a term or credential bar in the material. "4+ years" is a length of experience, graded as fit.

## Prohibited claims

These claims are not coached anywhere in this pack. Each row shows its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F5. Your sentence covers one branch's log. | "I handled the branch's formal complaints log." Limit, as the pack's observation: your material says one branch's log, not the process across branches. The F5 slot stays inside the log. |
| Built reporting that senior leaders use | Inflated form of your spreadsheet sentence | "I built the monthly complaints spreadsheet our regional manager uses." Limit, as the pack's observation: the regional manager is the one named as using it. |
| Tracked complaint volumes and resolution times | Inflated form of your spreadsheet sentence. The JD names these; your sentence does not. | Your spreadsheet sentence at its own scope. The F6 slot asks what it counted. |
| Coached branch supervisors on escalations | Inflated form of "trained new tellers" | "I trained new tellers on our escalation script." The F8 slot asks about coaching supervisors. |
| Presented to senior leaders | A negative you stated | Plain acknowledgment: "I haven't presented to anyone above regional level." No slot. |
| Worked in a contact centre | A negative you stated | Plain acknowledgment: "I haven't worked in a contact centre." No slot. |

## Grounding brief

The brief itself was not pasted. These points come from your summary of the July 2026 strategy brief, and the brief's figures should be said as the brief gives them. Do not present its dates as settled. The brief is four months old.

- Digital: move 40% of member service to digital channels by 2028.
- Network: consolidate eight branches into five hubs over 2027.
- Lending: launch a small-business lending product in Q1 2027.
- Competition: the main pressure is app-only banks.

## Persona weights by round

Weights come from the recruiter's round descriptions and the relationship priors. The interviewer names are unknown, so there is no interviewer read.

| Persona | How it shows up | Likelihood by round, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Open biography, casual "what's your view" | Round 1 high: a recruiter screen is friendly and scored. Rounds 2 and 3 low. | A pre-scripted 90-second arc (A1). Treat every casual question as scored. |
| Skeptic | Your two stated gaps, and the "why leave, why here" check | Round 1 light. Round 2 high: a manager's prior, plus two gaps you stated. Round 3 low. | Rehearse B2 until the plain acknowledgment is easy to say, then the plan. |
| Values / Behavioral | Scenarios mapped to the four values | Round 2 medium: the recruiter says it is "mostly behavioural". Round 3 top: the panel scores against the values. | STAR, with "we" for context and "I" for what you did. A scaffold with its honest branch where no story exists. |
| Case / Strategist | Live problems from the role | Round 2 medium: one live problem. Round 3 medium-high: a 20-minute case. | Clarify, then structure, then act (C5 and its case prep). |
| Peer Evaluator | Seams between branches and the contact centre | Round 3 medium: the panel members' branches are the ones this role serves, so their probes come as seams. | Propose principles for the seam (C6). Do not pretend to know theirs. |
| Data-Driven Prober | Your spreadsheet and any figure you give | Round 2 low. Round 3 low-medium: the spreadsheet is your only reporting evidence. | Name what the spreadsheet counted, and what it did not (B8, C8). |
| Pressure / Stress | Time-boxed case and follow-ups | Round 3 low-medium: the case is time-boxed. | Hold through two follow-ups, then concede what you cannot back (C8). |

## Round 1: recruiter, 30 minutes

Persona weights: Conversational top, light Skeptic, plus logistics slots.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as branch supervisor." [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A 90-second arc: six years in retail banking, the last three as a branch supervisor. Then the two things you did with complaints, in your own words. Stop there and let the recruiter pull the thread. | Opening arc in a friendly register, still scored. Sets up F1, F2 and F8. |
| A2 | "Where do you think complaints go as member service moves online?" | CO | [grounded] the brief's "move 40% of member service to digital channels by 2028", from your summary | No sentence of yours carries a view. Say what you think, in plain words. If you have no view yet, say so and name what you would want to learn first. | The digital target is the strategy term the role depends on. This tests altitude. No claim about you, so no slot. |
| A3 | "Why are you leaving your current role?" | EXP | [generic] | Logistics slot: give the reason you actually have, in one or two sentences. | Knockout and motivation check. Your material gives no reason, so the slot is yours to fill. |
| A4 | "What notice would you need to give?" | JD | [generic] | Logistics slot: give your actual notice period. | Logistics row. No figure is in your material. |
| A5 | "What are your pay expectations?" | JD | [generic] | Logistics slot: give your own number, or ask for the band first. | Logistics row. No figure is in your material. |
| A6 | "Where would you be based, and how often could you travel between sites?" | JD | [generic] | Logistics slot: give the places and days you can work. | Logistics row for the role's location terms. |
| A7 | "Why this role, and why here?" | CO | [grounded] "the 2026 strategy brief Ashgrove published in July 2026, which the recruiter sent me" | Pick one thing from the brief that bears on your work, and say why in your words. Do not claim knowledge beyond what you read. | The "why here" check, answered from the brief you read. |
| A8 | "Which part of our July plan stood out to you?" | CO | [grounded] the same brief sentence | Name one item from the brief (digital, the hubs, the lending launch, or app-only competition), and what it means for complaints. Plain words. | Vocabulary check: using the brief's own items accurately is the signal. |

Reverse questions, round 1:

- **RQ-A1:** "Which parts of the three rounds are scored, and who scores each?" Why it lands: you want to know how the values are weighed before 29 November.
- **RQ-A2:** "What does the team around this role look like?" Why it lands: you are asking about colleagues, not only the job.

## Round 2: Head of Member Services, 45 minutes

Persona weights: Skeptic top, Values / Behavioral next (the recruiter says mostly behavioural), then Case and Prober lower.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Name the two gaps in your words: "I haven't worked in a contact centre," and "I haven't presented to anyone above regional level." Then what you would do first, as a plan. Do not add a past. | The Skeptic's opener. F3 and F4 are the two absences you stated. |
| B2 | "I don't see contact-centre or senior-presentation work in your background. How would you handle that in this role?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | **Highest-ROI prep in this pack.** The two gaps you stated are the most likely objection, so rehearse this one hardest. Say both acknowledgments plainly, then your plan: how you would learn the contact-centre side and prepare the first senior presentation. Hold that through one follow-up. If pressed again, concede the uncertainty about how long it would take, rather than claim a skill. | Its premise uses your stated negatives, so it is lawful. The deepest rehearsal in the pack. |
| B3 | "Walk me through how you kept the branch's formal complaints log." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story map on F2: the log, its formal entries, and how you handled them, in your words. Answer slot: the JD raises regulated complaints, so expect a probe on the rules the log had to meet. If you were responsible for a deadline or reporting rule, say which and how. If you were not, say so plainly. | F2 is the nearest evidence for regulated complaints. It is adjacent, not the same, so the honest branch is ready. |
| B4 | "Tell me about a complaint that came back to you after it was closed." | EXP | [grounded] "I handled the branch's formal complaints log" | Open prompt on the JD's escalation line. Pick one case that came back, and say what came back and what you did, in your words. If none came back to you, say so plainly and give the nearest case from the log. | The JD asks you to coach on escalations. F8 is thin, so you need one worked escalation. |
| B5 | "Tell me about a time a member needed something explained to them twice. What did you change?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Plain Words: "if a member needs it explained twice, we wrote it wrong." Pick a moment you changed wording, a script or a letter. If you did not change it, say so plainly, and say what you would test first. | Selection scaffold with its honest branch. Nothing in your material shows the value. |
| B6 | "Tell me about a complaint you had to pass to someone else. How did you keep hold of it?" | VAL | [grounded] "I handled the branch's formal complaints log" | Own the Fix: "whoever finds the problem keeps hold of it until it is solved." Pick one case you handed on, and say how you kept track of it. If none comes to mind, say so and give the nearest case. | Own the Fix, asked about a hand-off. Does not assume you finished anything. |
| B7 | "How would you tell complaints were getting worse before the monthly report showed it?" | CASE | [generic] | Structure: what you would watch each week (for example, cases open past their target date, and cases that come back after closure). Name the assumption behind each measure you would pick. Then say who you would tell first. | A live problem from the monthly-reporting requirement. Generic: a pattern, not a fact about Ashgrove. |
| B8 | "What did the monthly spreadsheet report?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Name the columns and the purpose in your words. If it counted volumes or resolution times, say how you counted them. If not, say so plainly and say what you would add first. | Tests whether the Excel and monthly-reporting requirements are yours. No figure was given, so no defend-the-number slot. |
| B9 | "What would you do first to work with digital teams on a self-service journey?" | JD | [grounded] the JD line "work with digital teams on self-service journeys." No candidate sentence carries this. | Name a first step: find where members get stuck online, using complaints as evidence. If you have worked with a digital team, name it and your part. If not, say so. | The one JD requirement with no sentence in your material. F9 is discovery, so the honest form is a plan. |

Reverse questions, round 2:

- **RQ-B1:** "What do branch supervisors find hardest about escalations right now?" Why it lands: you hear the coaching problem in her words, and that is the job's first problem.
- **RQ-B2:** "What would make the first 90 days a clear success from your side?" Why it lands: you get a measure to plan against, and it shows you think in outcomes.

## Round 3: panel of two branch managers, 60 minutes

Persona weights: Values / Behavioral top (the panel scores the four values), Case and Peer next, Pressure in the time-boxed case.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided a complaint from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Members First, Always: "we decide from the member's side of the counter." Pick one complaint where the member's side settled the decision. If none comes to mind, say so plainly, then give the nearest case in the log and what you chose for the member. | Values round, first question. The panel scores the value, not your confidence. |
| C2 | "Tell me about a time a local detail changed how a branch handled its work." | VAL | [grounded] "6 years in retail banking, the last 3 as branch supervisor." | Neighbours, Not Numbers: "every branch is part of its town." Pick one time a branch's own place mattered. If none does, say so, then give the nearest: the three years as branch supervisor, and what you noticed from that seat. | Selection scaffold with its honest branch. |
| C3 | "Tell me about a time wording you used with members did not land. What happened?" | VAL | [grounded] "trained new tellers on our escalation script" | Plain Words: "if a member needs it explained twice, we wrote it wrong." Pick one occasion. If there was none, say so, then say how you would check a letter or script for that failure. | Open prompt. Its premise is the value's own line, not an event you have. |
| C4 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Own the Fix. Pick one complaint you stayed with to the end. If you did not see one through, say so and give the nearest. Do not add an ending you did not see. | Own the Fix, asked by the panel. |
| C5 | **Case, 20 minutes:** the complaint escalation (see case prep below). | CASE | [generic] | Follow the case prep below. | The round's case. Generic: a hypothetical, not an Ashgrove file. |
| C6 | "Where is the seam between the contact centre and the branches on a complaint, and what happens when we disagree?" | JD | [grounded] the JD line "Own the member complaints process end to end across branches and the contact centre." and "Never worked in a contact centre, and I've never presented to anyone above regional level." | Peer Evaluator. Propose principles for the seam: one owner per complaint, one case record, one timeline. Then "I haven't worked in a contact centre," and how you would learn their side first. On disagreement, one time you held a view with a peer, if you have one. If not, say how you would settle it. | The seam question is the panel's version of the contact-centre gap. |
| C7 | "What would the monthly complaints report you'd own contain, and who would it go to?" | JD | [grounded] the JD line "report monthly on complaint volumes and resolution times" and "I built the monthly complaints spreadsheet our regional manager uses." | Name the two measures the JD names, volumes and resolution times, and who reads the report. Answer slot: if your spreadsheet counted either, say what and how. If not, say so and say what you would count first. | Covers the monthly-reporting requirement. The spreadsheet is the nearest evidence, not the same thing. |
| C8 | "That spreadsheet: how much of its reporting was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Hold, then concede. "I built it. My regional manager uses it." Say which design decisions were yours, if any. Hold through two follow-ups by returning to what you built. Concede what you cannot say about the figures it produced. | The attribution probe, aimed at the Excel requirement. Do not add credit you were not given. |
| C9 | "How would you present a quarter's complaint trends to senior leaders?" | JD | [grounded] "I haven't presented to anyone above regional level." from your message | Plain acknowledgment first: "I haven't presented to anyone above regional level." Then a plan: one page, the few numbers that matter, and the decision you need from them. | The presentation requirement. The acknowledgment has its source. |

Reverse questions, round 3:

- **RQ-C1:** "When a complaint crosses from a branch into the contact centre, where does it usually get stuck?" Why it lands: you ask about the seam in their words rather than assume it.
- **RQ-C2 (reciprocity, peer):** "What could a new person do in their first month that would genuinely help your branches?" Why it lands: it shows you are thinking about what you bring, not only what you need.

## Case prep: the 20-minute complaint escalation (C5)

**The scenario (hypothetical, not an Ashgrove case):** A member has complained three times about a fee charged twice. The branch says it was refunded. The contact centre still has the case open. The member has now written to the branch manager. You have 20 minutes to talk it through.

**Structure, in the order to say it aloud:**

1. **Clarify first.** What counts as resolved? Who owns the case now? Is any regulatory timeframe running? Ask. Do not assume.
2. **Objective.** The member gets one answer from one named owner, and the case stops moving between desks.
3. **First 24 hours.** Check the branch file against the contact-centre record. Name one owner. Send a written reply in plain words.
4. **The member.** Say what happened, what has been done, what happens next, and by when. No internal codes.
5. **The supervisor.** Coach the branch supervisor on this case, using the file. This is not a blame conversation.
6. **Root cause and fix.** Why did the refund not close the case on the other side? Propose the fix, and who signs it off.
7. **Measure.** What goes into the monthly report, so the pattern can be seen again.
8. **Risks.** What you would not do. For example, promise a refund outcome you cannot confirm.

**Honest branch:** If you have handled a similar case, say which, in your own words, and which part was yours. If you have not, say so, and show the structure. Rehearse the structure, not an outcome.

**Practice:** Say it aloud at 20 minutes, with one interruption at minute 8 ("What if the member won't accept the refund?"). Hold the structure, then concede what you cannot know from the scenario.

## Values cheat sheet

The four values are the ones pasted from ashgrovecu.org/about/values on 20 November 2026. None of your sentences carries a story for any value, so each row is a selection scaffold with its honest branch.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | Scaffold: C1. Nearest sentence: "I handled the branch's formal complaints log and trained new tellers on our escalation script." If no story comes, say so. |
| Plain Words | If a member needs it explained twice, the wording was wrong. | Scaffold: C3 and B5. Nearest sentence: "trained new tellers on our escalation script." |
| Neighbours, Not Numbers | Every branch is part of its town. | Scaffold: C2. Nearest sentence: "6 years in retail banking, the last 3 as branch supervisor." |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | Scaffold: C4 and B6. Nearest sentence: "I handled the branch's formal complaints log." |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | A1, B3 |
| experience handling regulated complaints | B3, C5 |
| confident presenting to senior leaders | B1, B2, C9 |
| comfortable with Excel reporting | B8, C8 |
| Own the member complaints process end to end across branches and the contact centre | B2, C5, C6 |
| report monthly on complaint volumes and resolution times | B7, C7 |
| coach branch supervisors on escalations | B4, C5 |
| work with digital teams on self-service journeys | A2, B9 |

## Prohibited list in use

Every guidance cell above has been checked against the prohibited list. No cell asserts, softens or implies a listed claim.

## Sources

- **Provided documents:** the recruiter's email (three rounds on 29 November, their formats, and the values scoring); the JD text as pasted; Ashgrove's four values as pasted from ashgrovecu.org/about/values; your summary of the July 2026 strategy brief; your background.
- **Research tier:** L1. Searches 0 of 6, fetches 0 of 2. Every target was fixed by an input, so no search was sent. You asked that nothing about Ashgrove beyond what was given be invented.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet: the four values are pasted in hand |
| 2. Ashgrove interview process, Member Experience | skipped | Loop structure: the recruiter's email names the rounds |
| 3. Ashgrove strategy and recent news | skipped | Grounding brief: your summary of the July brief supplies current priorities |
| 4. Interviewer name and Ashgrove | n/a | No names given for the Head of Member Services or the panel |
| 5. Representative Member Experience Lead JD | skipped | The JD you pasted fixes the fit snapshot |

## Upgrade menu

- **Your CV:** the quotes in the fit snapshot come from your message. A CV gives inspectable proof, which can raise F1, F2 and F7 from medium.
- **The July brief, pasted:** the grounding brief quotes the document's own wording instead of your summary.
- **Focus areas the recruiter names for each round:** confirms or reweights each round's persona weights.
- **Names of the Head of Member Services and the two branch managers:** an interviewer read, a tailored reverse question for each, and persona weights from their public footprint.
- **Hours you have before 29 November:** a prioritized prep schedule, with a triage section.
- **Deep research (L2), offered once:** at most six further searches and two further fetches, on recent Ashgrove news and public loop reports for complaints roles. It takes time.
- **A tuesday-dossier.md:** would hold verified evidence and the objections the fit snapshot found, so B2 is drawn from it rather than inferred.
