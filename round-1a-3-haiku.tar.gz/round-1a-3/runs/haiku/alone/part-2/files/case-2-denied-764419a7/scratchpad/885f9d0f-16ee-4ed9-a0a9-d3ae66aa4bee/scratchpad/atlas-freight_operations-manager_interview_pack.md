# Operations Manager, Atlas Freight: interview prep pack

Round type, interviewer and recruiter guidance: not given. Built as a generic full-loop pack with flat-ish persona weights. Research: web search was refused permission, so nothing about Atlas Freight itself is in this pack.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **JD** = stated job requirement · **EXP** = your past work, tested for attribution · **CASE** = live problem · **VAL** = behavioural or values · **CO** = company knowledge (none in this pack; research did not run).
- Guidance is scaffolding, not a script. Say it in your own words.
- Answer slots (in the guidance) are instructions for the interview. They are not questions for this chat.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "senior shift manager over 3 supervisors" — your message; "7 years in warehouse and distribution ops" — your message | medium | [grounded] | transferability | Your material shows one shift and three supervisors, not four sites. Words: "I've been senior shift manager over 3 supervisors." Answer slot: the four-site scope makes a probe likely. If you have run operations across more than one site, say which and how; if you have run one, say so plainly and describe how you would organise four. |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material shows an accuracy result at the pick and a peak-season plan. It does not show on-time performance or cost per shipment moving. Words: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you have moved on-time or cost per shipment, say which measure and by how much; if not, say so plainly and say which measure you would watch first. |
| F3 | "drive on-time performance and cost-per-shipment down" — JD | none given | none | [grounded] | discovery | Nothing in your material touches cost per shipment. Answer slot: if you tracked or influenced cost per shipment, say what was counted and what part was yours; if not, say so plainly and say what you would measure first. |
| F4 | "lead a team of 12 supervisors" — JD | "senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material shows three supervisors, not twelve. Words: "I've been senior shift manager over 3 supervisors." Answer slot: if you have led a larger group, say how many and how you ran it; if not, say so and describe how you would scale from three to twelve. |
| F5 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "senior shift manager over 3 supervisors" — your message | low | [grounded] | discovery | Your material gives seven years of operations work. It does not show how many of those years were leadership. Answer slot: say how many years you have led people, in your own words. If that is fewer than five, say the number plainly and say what the seven years covered. |
| F6 | "build reporting in Excel" — JD | "solid Excel" — your message | medium | [grounded] | presentation | Your sentence reaches the Excel half of the requirement. Words: "I'm solid in Excel." Your material does not show reporting you have built. Do not claim it. |
| F7 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap you stated. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. |
| F8 | "Lean/Six Sigma a plus" — JD | "Green Belt certified" — your message | medium | [grounded] | none | Covers the requirement. Confidence is medium because the certificate has not been inspected. Have it to hand if asked. |

What the gap types mean here: **transferability** = adjacent work that does not reach the requirement; **discovery** = the material is silent; **capability** = you said you lack it; **presentation** = your sentence reaches the requirement in other terms; **none** = covered.

Requirement coverage: "Own daily terminal operations across 4 sites" → F1, A2, A5 · "drive on-time performance and cost-per-shipment down" → F2, F3, A3, A4, B2, C2, C3 · "lead a team of 12 supervisors" → F4, A1, B1 · "build reporting in Excel/Power BI" → F6, F7, D2, A5, F2 · "5+ years operations leadership required" → F5, A1, E1 · "Lean/Six Sigma a plus" → F8, C4.

## Prohibited claims

Not to be said in the interview. Each has a basis and an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran terminal operations across 4 sites | Inflated form of F1 | F1's quote at its own scope: "senior shift manager over 3 supervisors." The material shows one shift and three supervisors (pack observation, not words for you). |
| Led 12 supervisors | Inflated form of F4 | "senior shift manager over 3 supervisors" |
| Drove on-time performance and cost-per-shipment down | Inflated form of F2 | "cut mis-pick rate 40% by redesigning the pick path." The material shows accuracy at the pick, not on-time or cost (pack observation). |
| Five years of operations leadership | Inflated form of F5 | "7 years in warehouse and distribution ops." The material does not show leadership years (pack observation). |
| Power BI experience, or built Power BI reporting | Negative you stated, F7 | "I haven't used Power BI." |

## Persona table

No interviewer, round or relationship is known, so these are generic weights. Each persona gets at least one question.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: scale, four sites, Power BI, cost per shipment | Highest. The JD asks for three things you have not shown (12 supervisors, 5+ leadership years, four sites), and the gaps are the likeliest probes. | Rehearse A1 until it is plain. Name the gap before it is named for you. |
| Data-Driven Prober | Asks how your 40% was counted, and for baselines | High. The 40% is a headline figure. | Name the weakest assumption before it is asked for. |
| Case / Strategist | Live problem on four sites' on-time performance | Medium. Ops manager loops often include one. | Clarify before structuring. |
| Pressure | Time-boxed challenge on your fit | Medium. Holds your position for two follow-ups, then concedes specifically. | Hold, then concede the exact gap. |
| Values / Behavioural | Stories about delivering bad news or putting service ahead of targets | Low. No values round is known. | Selection scaffold; say plainly where your material is silent. |
| Conversational | Journey question, Power BI in passing | Medium. Casual questions are scored too. | 90-second arc in your own words. |

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What's the largest team you've led directly?" | JD | [grounded] "senior shift manager over 3 supervisors" — your message | **Highest-ROI prep.** Answer with the number first: "I've been senior shift manager over 3 supervisors." Answer slot: if you have led a larger group, say how many and how you ran it; if not, say so plainly and say how you would lead 12 supervisors. Hold through two follow-ups by returning to three, then concede specifically on scale. | F4 is the largest gap, and the JD names twelve. Deepest rehearsal because it is most likely to be asked in some form. |
| A2 | "This role runs daily terminal operations across four sites. What's your experience running more than one site?" | JD | [grounded] "senior shift manager over 3 supervisors" — your message; "7 years in warehouse and distribution ops" — your message | Describe your shift and your seven years of operations work in those words. Answer slot: if you have run operations across more than one site, say which and how; if you ran one site, say so plainly and describe how you would organise four. | F1. The question presupposes a multi-site practice, so its second branch allows that none existed. |
| A3 | "Your numbers show accuracy at the pick. This role is on-time and cost per shipment. Why should I believe you move those?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Name the 40% as your mis-pick result and say what it did and did not touch. Answer slot: if you have moved on-time or cost per shipment, say which measure and what changed; if not, say so plainly and say what you would measure first. Do not present the mis-pick result as an on-time result. | F2. The mis-pick result is real; the bridge is the risk. |
| A4 | "Cost per shipment is what this job is judged on. Have you owned that number?" | JD | [grounded] "drive on-time performance and cost-per-shipment down" — JD | Answer slot: if you tracked or influenced cost per shipment, say what was counted and what part was yours; if not, say so plainly and say what you would measure first. | F3. The material is silent; the answer must be yours. |
| A5 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never used Power BI" — your message | Name Power BI plainly, then one more gap from the JD (multi-site or cost per shipment), then the ramp plan. Calibrated candour over bluffing. | Skeptic stem. F7 and F1 are the likely answers. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: why should we hire someone who has managed three supervisors over someone who has run four sites?" | JD | [grounded] "senior shift manager over 3 supervisors" — your message; "cut mis-pick rate 40% by redesigning the pick path" — your message | Pause and restate. Say what your three supervisors and the pick-path redesign show, in your own words. Hold through two follow-ups. Concede specifically: "I haven't run four sites; here is how I'd learn them first." That is a plan, not a past. | F1 and F4. Hold-then-concede. |
| B2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Answer slot: if you led the redesign, say so; if others did part of it, say which part was yours. Do not add a team or a result you did not give. | F2. The attribution probe. |

### Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Answer slot: say how it was counted, what it was measured against, the assumption you would defend least, and which part was yours. Name the weakest assumption before they do. If you do not know how it was counted, say so. | Defend-the-number slot. Figures raise these four slots, and only these. |
| C2 | "What was the mis-pick rate before and after, and over what period?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Give the figures only if you have them. If you do not, say you would check your records rather than estimate. | Defend-the-number. Baseline is not given in your material. |
| C3 | "What did on-time look like through the peak season you ran?" | JD | [grounded] "ran the site's peak-season surge plan two years running" — your message | Answer slot: if you tracked on-time through peak, say what you measured; if you did not, say so plainly. | F2. Raising source is the JD's on-time line. |
| C4 | "Where has your Green Belt shown up in your day-to-day work?" | JD | [grounded] "Green Belt certified" — your message | Answer slot: if it has shown up in a project, say which; if the certificate is the extent of it, say so plainly. | F8. |

### Case (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A terminal's on-time performance drops for three weeks while cost per shipment rises. Where do you start?" | CASE | [generic] | Clarify: how on-time is measured, what changed in those three weeks. Objective. Segment by site, shift and lane. Approach. Metrics. Risks. Think aloud. | Role-family problem; no claim about your past. |
| D2 | "Four sites need one weekly report. What's your first version, and which tool?" | CASE | [grounded] "solid Excel" — your message; "never used Power BI" — your message | Start in Excel from what you know. Say you have not used Power BI, and that your plan is to learn it. | F6 and F7. |
| D3 | "What would you need to know in your first 30 days before changing anything?" | CASE | [generic] | Name the data you would ask for first, the people, and the one decision you would not make until you had seen it. | Generic live problem. |

### Values (weight 2, generic fallback)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you had to tell a senior manager a number they did not want to hear." | VAL | [grounded] "senior shift manager over 3 supervisors" — your message | Selection scaffold: pick a time you gave bad news to someone senior, with a named stake, what you said and what happened. If no such time comes to mind, say so plainly, then give how you would handle it. | Open prompt. No values round is known. |
| E2 | "When did you put a team's service ahead of a target?" | VAL | [generic] | Same scaffold. If you have no clear instance, say so and describe how you would weigh it. | Open prompt; the answer is yours to choose. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey from the warehouse floor to shift manager." | JD | [grounded] "7 years in warehouse and distribution ops" — your message; "senior shift manager over 3 supervisors" — your message | A 90-second arc, one beat per sentence above. Do not add a role. | Casual opener, scored. |
| F2 | "How comfortable are you with dashboarding tools beyond Excel?" | JD | [grounded] "never used Power BI" — your message | Say: "I haven't used Power BI," then how you would learn it. | F7. |

## Reverse questions

1. "What does success look like in the first 90 days, in on-time and cost-per-shipment terms?" *Why it lands:* shows you are thinking about the measures the job is judged on.
2. "How is the four-site scope split across managers? Do supervisors report by site?" *Why it lands:* tests how the role is structured, and where the gap sits.
3. "What reporting does the team use today, and where would Power BI fit?" *Why it lands:* tells you how big the tool gap is.
4. "How many of the twelve supervisors are new in post?" *Why it lands:* shows you know the team is a live question.
5. "What is the biggest on-time problem across the four sites right now?" *Why it lands:* shows you are working on operations, not on your CV.

## Sources

- **Provided:** the JD text (your message), your background (your message).
- **Searches attempted (L1, all refused):** "Atlas Freight values regional logistics" — refused; "Atlas Freight interview process operations manager" — refused; "Atlas Freight strategy news 2026" — refused. No page fetches were sent.
- **Research tier:** L1 requested, L0 effective. No search returned a result, so no fact about Atlas Freight is in this pack.

Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Values cheat sheet not built. Would have sourced the value names. |
| 2. `Atlas Freight interview process operations manager` | unavailable | Loop structure unknown; persona weights are generic. |
| 3. `Atlas Freight strategy` / recent news | unavailable | No CO bank. |
| 4. `{interviewer name} Atlas Freight` | n/a | No interviewer name given. |
| 5. representative JD | skipped | Your JD fixes the fit snapshot. |

## Upgrade menu

- Interviewer's name → persona weights and a tailored reverse question.
- Round type and recruiter's note → weights and any pre-declared exercise.
- Atlas's published values or careers page, pasted → values cheat sheet and loop source.
- Permission to use web search → targets 1 to 3 rerun.
- The 40% baseline and period; any on-time or cost-per-shipment figures → C1 and C2 get grounded figures; A3 and A4 get a measure to name.
- Your Green Belt certificate, to hand → F8 confidence stays medium until inspected.
- A sample Excel report you built → F6 becomes a grounded artifact.
