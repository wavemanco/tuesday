# Northwind Data: Senior GTM Strategy Lead, Emerging Products

**Interviewer:** Dan Kovac, Director of Sales Strategy. Peer, same VP.
**Format:** single 60-minute conversation.
**Candidate:** Priya.
**Built on:** the JD highlights, your candidate notes, and your research note. Web search was refused in this session, so nothing here is from the web.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Every line that says what Priya did rests on a sentence quoted from her material. Where the material is silent, the cell is an answer slot: an instruction to answer in her own words, with both honest branches.

Type key (one token per question):

| Type | Meaning |
|---|---|
| VAL | Behavioral: whether past behavior shows the working principle the question names |
| EXP | Experience deep-dive: whether her claims survive scrutiny and what she did herself |
| JD | Role requirement: can she do the listed job, gaps included |
| CO | Company and strategy: whether she thinks at Northwind's altitude |
| CASE | Live problem from the role, delivered now, with no claim about her past |

Dual-tagged questions take the primary type; the rationale names the second.

## Fit snapshot

Requirements are quoted from the JD highlights in your note. Evidence is quoted from your candidate notes ("the coach's notes") and your research note where marked.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights, your note) | "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes); "9 years product strategy & ops at a large consumer-tech company" (the coach's notes) | medium | [grounded] | transferability | Your material shows product strategy and ops, and one proposed change. It does not show go-to-market ownership for a product line. Say the work at its own scope: "I proposed a store-surface change." Answer slot: if you made any go-to-market decision for a product, say which and how you decided; if none, say so and say what you would own first. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights, your note) | "partner-level revenue model used in carrier negotiations" (the coach's notes) | medium | [grounded] | transferability | The model is revenue-level work used in carrier negotiations. Your material does not show a land, adopt, expand or renew stage. Say it as the quote states it: a partner-level revenue model, used in carrier negotiations. Answer slot: if you have worked any of the four stages, name it and what you did there; if none, say so and say how you would find whitespace across them. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights, your note) | "skilled in SQL/Tableau" (the coach's notes) | low | [inferred] | presentation | The quote reaches the tools, not the independence. For the tools, say "skilled in SQL and Tableau", and no more. Answer slot: if you have run an analysis yourself, say what you asked and what it changed; if none, say so and say how you would start. |
| F4 | "partner-motion design experience required" (JD highlights, your note) | "partner-level revenue model used in carrier negotiations" (the coach's notes) | medium | [grounded] | transferability | The carrier work is partner-level economics, not partner motion design. Say the quote's own words, and stop there. Answer slot: if you designed any way of enabling or co-selling with partners, say which and how you decided; if none, say so and describe how you would design one. |
| F5 | "strong cross-functional influence" (JD highlights, your note) | "set annual volume targets with cross-org consensus" (the coach's notes) | medium | [grounded] | presentation | The quote reaches influence in other terms: consensus across orgs. Reword only: "I set annual volume targets with consensus across orgs." Answer slot: how the consensus was reached, in your own words, if you were the one who reached it. |
| F6 | "AI experience a plus" (JD highlights, your note) | "uses AI tools daily" (the coach's notes) | low | [inferred] | transferability | Daily use is adjacent to AI experience, and the quote stops there. Say it as the quote states it: "I use AI tools daily." Your material does not show AI product work, so do not stretch the row. Answer slot: if an AI tool changed a decision you made, say which; if none did, say so. |
| F7 | Not a JD line. A probe this pack expects, from the sales-strategy context of the role: sales-ops or quota-setting | "No classic sales-ops or quota-setting experience." (the coach's notes) | none | [grounded] | discovery | The coach's notes state the absence, but the words for Priya are hers to give, so the pack does not supply them. Answer slot: if you have set or been held to a quota or a sales-ops target, say which and how; if not, say so plainly and say what you would learn first to test a whitespace call. |

Gap-type routing: no JD requirement is a gate, because the highlights name none. Gate terms (location, travel, pay, work authorization) are not visible until full JD text arrives; see the upgrade menu.

## Prohibited claims

The pack will not coach these. Each entry names its basis; each honest form is the quote at its own scope, with the limit stated as the pack's observation in analysis, not as a first-person negative. All of these are inflated forms built from your sentences.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned go-to-market for a product line | Inflated form of F1: "proposed" stretched to "owned" | F1's quote at its own scope. Your material shows a proposal, not go-to-market ownership |
| Set quotas, or ran sales ops | Inflated form of F5 and F7: "set annual volume targets" stretched to quotas and a sales-ops function | F5's quote, with no quota or sales-ops words |
| Designed a partner motion | Inflated form of F4: a partner-level revenue model stretched to a motion | F4's quote at its own scope |
| Ran independent analyses in SQL and Tableau at scale | Inflated form of F3: "skilled" stretched to independent work at volume | F3's quote, the skill word only |
| Built or led AI work | Inflated form of F6: daily use stretched to building | F6's quote at its own scope |
| The ~$400M was hers | Inflated form of F1: "credited with" stretched to sole credit | F1's quote with "credited with" kept as written; the attribution answer slot in A2 and E1 |

## Interviewer read

Source: the description you gave of Dan's career. This is not a public-footprint read; search was refused.

- **Career pattern:** pricing and monetization, plus one early-stage startup chapter. Expect the pricing vocabulary to be their native language: "revenue model" and "volume target" will land as shared terms.
- **Self-described style:** "relentlessly data-driven." Every figure will be probed to its denominator and assumptions (A1, A2, E1). Have the weakest assumption ready before it is asked.
- **Case tilt:** price, packaging and unit economics go first in any structure (C1).
- **Startup chapter:** builder stories land with someone who has run a small team. Expect scrappiness probes. Priya's material holds no such story, so the pack offers none.
- **Mirror opportunities:** the shared language above. No shared professional jump is offered: the public path that would establish one was not checked.

## Persona table

Relationship prior for a peer round: Peer Evaluator plus Data-Driven Prober (`personas.md`). No loop source established this company's loop, so the weights below rest on the fallback archetype and say so. The Generic archetype gives flat weights; the peer tilt is the interviewer-signal adjustment, not a documented process.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Data-Driven Prober | Denominators, assumptions, counting method | High. Peer prior, plus a "relentlessly data-driven" self-description; top weight, 5 questions | Name the weakest assumption before they do; say plainly when you do not know how a figure was counted | A |
| Peer Evaluator | Seams with pricing, disagreement with equals, credit, what the hire adds to their load | High. Peer prior; 4 questions | Reciprocity framing; propose seam principles, not a claimed seam; one disagreement story | B |
| Case / Strategist | Live diagnosis and approach; pricing and unit economics | Medium-high. Pricing career spine tilts case work toward pricing; 3 questions | Clarify, then structure with price and packaging early; challenge one premise | C |
| Skeptic | The JD gaps: lifecycle stages, quota work, partner motion | Medium-high. Biggest gaps sit in the JD's own lines; 3 questions, with D1 the top-ROI item | Hold the quoted position, concede the rest plainly, then give a test method | D |
| Pressure / Stress | Time-boxed challenges to the $400M figure and to the sales background | Low-medium. Nothing in the profile suggests a pressure style; 2 questions | Pause, restate, hold through two follow-ups, then concede the attribution | E |
| Conversational / Rapport | Casual opener, casual AI question | Low-medium. Peers open casually and still score; 2 questions | Pre-scripted 90-second arc; treat the casual AI question as scored | F |
| Values / Behavioral | Candor with numbers; customer over metric | Low. No values-style round was detected; 2 questions, generic | Selection scaffolds with honest branches | G |

Total: 21 questions, inside the 18 to 26 range.

## Grounding brief

Source: your research note only. Freshness is not checked, because search was refused.

| Item | Source |
|---|---|
| Stated priorities: enterprise expansion; an AI copilot launch ("Compass"); reaching profitability | Your research note |
| Main competitive threat: bundling by a much larger platform vendor | Your research note |
| Stale framings in provided documents: none identified | Not checked |

## Question banks

### A. Data-Driven Prober (top weight, 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Give the figure at the scope the quote states: the change you proposed, and the uplift it is credited with. Say what you know about how it was counted, in your own words. Answer slot: name the assumption behind it that you would defend least, and what it is sensitive to, if you know them; if you do not know how it was counted, say so plainly and say what you would check first. Do not name a method. | F1 is the headline metric and the likeliest place a prober starts. EXP because it tests attribution and counting. |
| A2 | "What did you decide yourself in that uplift, and what did others decide?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Use the quote's verb: you proposed the change. Say who else decided what. Answer slot: if you decided more than the proposal, say which and how; if you decided only the proposal, say so and stop there. Hold the proposal through the second follow-up; do not extend it. | The defend-the-number slot for which part was theirs. The question allows that the proposal was the whole of her part. |
| A3 | "The role covers whitespace across land, adopt, expand and renew. Where would you look first?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights, your note) | Speak as a method, not a past: the data you would pull by stage, the segment cut, and the number you would distrust first. Make no claim about having done this. Speakable in 90 seconds. | The raising source is the JD highlight; no quote carries a lifecycle stage, so the guidance names no past. JD because it scores the whitespace requirement; the denominator probe is the Prober's. |
| A4 | "Tell me about an analysis you have done in SQL or Tableau, from question to answer." | JD | [grounded] "skilled in SQL/Tableau" (the coach's notes) | Open prompt: choose one analysis. If you ran it yourself, give the question, the data, what you did with it, and what changed. Answer slot: if you have not run an analysis yourself, say so and describe how you would start on one here. | The theme comes from the JD's independent-analysis line. "Skilled" is the only quote, so the analysis itself is the slot. |
| A5 | "Has an AI tool changed a decision you made? If so, which?" | EXP | [grounded] "uses AI tools daily" (the coach's notes) | Say what you use the tools for, at the quote's scope. Answer slot: if one changed a decision you made, say which decision and how; if none did, say so plainly. Do not describe AI work the quote does not state. | F6 is a plus-requirement; a prober tests whether daily use changed anything. The question allows that none did. |

### B. Peer Evaluator (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where does your revenue-model work meet the pricing calls on my side, and what happens when we disagree about a number?" | VAL | [grounded] "set annual volume targets with cross-org consensus" (the coach's notes) | Story-mapped on F5: the targets were set with cross-org consensus, which the quote states. Answer slot: if a number you set was disputed, say what the dispute was and how it closed, in your own words; if none was, say so and describe how you handle a disagreement about a number. | Peer seam probe. VAL because it scores disagreement style with equals; the seam is the peer's concern. Dual-tag: EXP for the revenue-model claim. |
| B2 | "Partner-motion design is a requirement here. How would you approach it for a data product that sits next to a platform partner?" | JD | [grounded] "partner-level revenue model used in carrier negotiations" (the coach's notes) | Speak as an approach: partner economics first, using the quote's own words at its scope; then who the partner is and what they gain; then the parts of a motion. Answer slot: if you have designed any partner motion, say which and how you decided; if none, say so and describe your approach as a plan. | The required line with the thinnest quote. "Platform partner" comes from the bundling threat in your research note. |
| B3 | "How do you handle credit when a result spans two teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Say who else touched the result, at the quote's scope. Answer slot: which credit you claimed, and which you gave away; if none of it was a credit question, say so. | Peer stem on credit. The quote is the only one that carries a credited result. |
| B4 | "Our teams sit side by side. What would you need from me in the first 90 days?" | JD | [grounded] "partner-level revenue model used in carrier negotiations" and "set annual volume targets with cross-org consensus" (the coach's notes) | Reciprocity: ask for specifics, then say what you bring to the pricing side from the two quotes, at their scope. Make no claim beyond them. | Peer reciprocity and the cross-functional influence requirement. The question asks what Dan needs, not what Priya did. |

### C. Case / Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Suppose expansion has slowed on one of the two new product lines. How do you diagnose it?" | CASE | [generic] | Clarify first: which line, which stage, what slowed (volume, price, conversion), and what changed. Then structure: a stage-by-stage cut; price and packaging as candidate causes, tested through unit economics per seat or per volume; the one test that separates them; and the risk. Think aloud and name one premise to challenge. Makes no claim about her past. | A live problem from the JD's expand line. With a pricing-career interviewer, price and packaging come early in the structure. |
| C2 | "Compass is launching as an AI copilot. What would you sell first, and what would you not bundle yet?" | CO | [grounded] "AI copilot launch ('Compass')" (your research note) | Use the research note's priority, with no added detail about Compass. Say what you would sell first and the one assumption behind it. Name one thing you would not bundle yet, and why. | The company's stated priority, from your note. CO tests altitude. |
| C3 | "Our main threat is a much larger platform vendor bundling. How would you respond for a new product line?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your research note) | Pick one response: price, differentiate, or stay out of bundles. Name what you would not do; the consensus answer is to bundle back, so say why you would not, if that is your view. Name the buyer assumption behind the choice. | The competitive frame from your note. The peer will test whether the answer is the consensus one. |

### D. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Have you been accountable for a sales number? If not, what would you use to test a whitespace call?" | JD | [grounded] "set annual volume targets with cross-org consensus" (the coach's notes) | **Highest-ROI prep.** Hold the quote's words: you set annual volume targets with cross-org consensus. Do not describe a quota, a bookings target or a sales-ops process the quote does not state. Hold through two follow-ups by returning to the targets and what they were tested against. Concede plainly, when the second follow-up presses: quota mechanics and sales-ops process are not in your material. Answer slot: if you were accountable for a sales target, say which and how it was tested; if not, say so, then describe how you would test a whitespace call. | This is where F7 (no sales-ops or quota work) and F2 (no lifecycle stage) meet in one probe. The "no" branch is valid, so the answer does not depend on a claim. Deepest rehearsal: hold, then concede the quota part, then pivot to a test method. |
| D2 | "Which of the two product lines' go-to-market would you be weakest at on day one?" | JD | [grounded] "own GTM strategy for two new product lines" (JD highlights, your note) | Concede the gap the quote leaves: product strategy and ops, and one proposed change, not go-to-market ownership. Then name the first thing you would do in the first 30 days for each line. Do not argue the gap away. | Dan's stem on the headline requirement F1 cannot reach. Rehearsed so the concession is calm. |
| D3 | "Partner-motion design is required. What is the closest thing in your material to it?" | JD | [grounded] "partner-level revenue model used in carrier negotiations" (the coach's notes) | Give the quote at its scope and stop. Say it is economics used in negotiations, not a motion, and concede that motion design is not shown. Answer slot: if you have designed any partner-facing way of working, say which; if not, say so. | The honest answer is the quote, honestly limited. Its premise is the JD line, not a past claim. |

### E. Pressure / Stress (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That ~$400M figure: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Pause, then restate: the change you proposed, and the uplift it is credited with. Hold the proposal through two follow-ups. Concede what you cannot claim: "credited with" is not a share. Answer slot: if you know what share is attributable to your work, give it in your own words; if you do not, say so. | A sharper form of A2 under time pressure. Hold-then-concede, not a fold. |
| E2 | "Sixty seconds: why you over someone who has run a sales motion?" | JD | [grounded] "9 years product strategy & ops at a large consumer-tech company" (the coach's notes) | Sixty seconds. Lead with the product strategy and ops years in the quote's words, then the one thing you bring that a sales operator would not. Concede the motion part early, inside the first ten seconds, so the rest lands. Do not claim motion experience you do not have. | A time-boxed challenge on the F7 gap. Conceding early is the structure. |

### F. Conversational / Rapport (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" and "9 years product strategy & ops at a large consumer-tech company" (the coach's notes) | A pre-scripted 90-second arc from those two quotes, in that order, at their own scope, then a bridge to this role through the revenue model and the cross-org targets (F2, F5). Make no claim beyond the quotes. | A casual opener is still scored; a rambling arc is the cost. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (the coach's notes) | Name the tools in one breath, and one use, at the quote's scope. Answer slot: if one use changed a decision, say which; if none did, say so. Do not turn a daily habit into a build. | The AI plus-requirement, asked casually. The casual register is still scored. |

### G. Values / Behavioral (2, generic)

No published values were checked, and no values-style round was detected, so these are patterns, not Northwind principles.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you reported a number that disappointed someone." | VAL | [generic] | Selection scaffold: pick a time you reported a figure someone did not want, with a named stake, a moment you held the figure, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. | A candor-with-numbers probe. No sentence in her material carries such a story, so this is a scaffold. |
| G2 | "When did a customer's need change a metric you were watching?" | VAL | [generic] | Selection scaffold: pick a time a customer or user need moved a number you tracked, and say what you did with the number. If none comes to mind, say so plainly and give the nearest thing with a customer in it, or how you would handle one. | A customer-over-metric stem. Her material holds no such sentence. |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | D2, C2 |
| identify whitespace across land/adopt/expand/renew | A3, C1, D1 |
| run independent analysis in SQL and Tableau | A4 |
| partner-motion design experience required | B2, D3 |
| strong cross-functional influence | B1, B4 |
| AI experience a plus | A5, F2 |
| Sales-ops and quota-setting (not a JD line; your candidate notes) | D1, E2 |

Every requirement has at least one question.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which pricing decision on your side would you most want modeled before it shipped?" | Ties to Dan's pricing and monetization career. It invites a peer conversation rather than a pitch. |
| RQ2 | "What could someone do in their first month that would genuinely help your team?" | Reciprocity. It asks what the peer needs, which peers weight heavily. |
| RQ3 | "How will Compass change how your team and mine decide what to bundle or price first?" | Shows you read the priority, and names the seam between the two teams. |
| RQ4 | "When bundling comes up with the larger platform vendor, what does the team know now that it would like to know sooner?" | Tests the threat with someone who sees the data. The answer shows where the hire's work would sit. |
| RQ5 | "Where does the land-to-expand handoff break most often today?" | Whitespace in practice. The answer tells you what the role's first quarter would look like. |
| RQ6 | "What from your early startup chapter about pricing still applies at this scale?" | Ties to the one startup chapter in Dan's career. Asks about their path, not the company's. |

## Sources

Provided documents: the JD highlights in your message, your candidate notes (the coach's notes), and your research note. No JD text, recruiter email or interviewer profile was supplied.

Searches sent, all refused by the host (permission not granted):

- "Northwind Data" Compass AI copilot launch: refused
- "Northwind Data" enterprise expansion profitability data infrastructure: refused
- "Northwind Data" interview process sales strategy: refused

Research tier: L1, searches 3 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | No call sent; search refused by the host. Would have moved the values cheat sheet, which this peer round does not trigger |
| 2. Northwind Data interview process, sales strategy | unavailable | Searched: refused. Would have moved the loop structure and persona weights; the weights here rest on the archetype |
| 3. Northwind Data strategy and recent news | unavailable | Searched: refused. Would have checked the research note's priorities and threat; they are used as given and unchecked |
| 4. Dan Kovac, Northwind Data | unavailable | No call sent; search refused. Would have moved the interviewer read, persona weights and reverse questions |
| 5. Representative JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web search permission → re-runs the three refused checks: verifies Compass and the priorities, checks the loop, and checks the bundling threat. Upgrades C2, C3, the grounding brief and the persona weights.
- Dan's public footprint, if search is allowed → talks, posts and career path. Upgrades the interviewer read, the persona weights, and RQ1 and RQ6.
- Full JD text → turns the requirement quotes into the posting's own words and surfaces any gate terms (location, travel, pay, work authorization), each of which would get its own row.
- Your recruiter's prep email → confirms the round's format and any deliverable it names. A named deliverable adds a build section.
- A deeper research pass (offered once): up to 6 more searches and 2 more fetches, several minutes. Needs search permission.
- An inspectable artifact behind the ~$400M figure, such as the analysis itself → moves F1 from medium toward high, and lets A1 and E1 cite it.
- Your own answers to the answer slots (A1, A2, B2, D1, E1), given outside a drill → each becomes a quoted fact in the fit snapshot, and the rows that draw on it regenerate.
- Prep time before the round → a prioritized triage section, sized to your time.
