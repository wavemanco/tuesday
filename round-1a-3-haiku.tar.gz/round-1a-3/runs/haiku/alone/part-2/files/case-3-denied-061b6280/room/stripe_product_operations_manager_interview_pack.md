# Stripe: Product Operations Manager, final round. Session prep pack

Built on the company and role you gave, with no JD, no CV and no round details yet. Persona weights are flat because the round and the interviewer are unknown. Web research was refused in this session, so nothing below about Stripe's values, process or strategy is established. Those sections are absent, not guessed.

## How to use this pack

- **Personas** describe how a question is asked (the register and the pressure). **Types** describe what is being scored.
- Type key: **JD** = role requirement, can you do the listed job. **EXP** = your past work, what you actually did. **CASE** = a live problem from the role, scored on structure. **CO** = company knowledge (not included, since research did not run). **VAL** = values (not included, since no published values are in hand).
- Guidance is scaffolding, not a script. Answers are yours. Where a guidance cell says "answer slot", it means the honest answer depends on your own experience, which this pack has not seen.

## Fit snapshot (worksheet variant)

No CV, JD or quoted sentence has been supplied, so every evidence cell reads `none given`. Requirements are role-family patterns, unquoted, labelled `[generic]`. Every row is therefore `discovery`: the evidence may exist and the pack cannot show it. Share your CV or a few sentences about your work and these rows will be rebuilt on your own words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Designing and running an operating process, such as intake, cadence or review. Role family | none given | none | [generic] | discovery | Strong evidence looks like one process you designed or ran from start to finish, with what it replaced and who used it. Selection scaffold: pick one such process and say what you decided and why. If you have none, say so plainly, then say how you would design one in the first month. |
| F2 | Metrics and operating reviews that drive decisions. Role family | none given | none | [generic] | discovery | Strong evidence looks like a number you tracked that changed a decision, and what you did when it moved. Selection scaffold: pick a metric you reviewed regularly; say what decision it fed. If none, say so plainly, then say which metric you would set up first and why. |
| F3 | Influence across product, engineering and go-to-market without direct authority. Role family | none given | none | [generic] | discovery | Strong evidence looks like a decision you moved through people who did not report to you. Selection scaffold: pick one such decision and say what you did, what they did, and where it stalled. If none, say so plainly, then say how you would build alignment in the first quarter. |
| F4 | Coordinating launches and rollouts across teams. Role family | none given | none | [generic] | discovery | Strong evidence looks like one launch or rollout you coordinated, with its dates, its risks and what slipped. Selection scaffold: pick one; say what you owned and what you did not. If none, say so plainly, then describe how you would run the first one. |
| F5 | Automating or tooling operational work. Role family | none given | none | [generic] | discovery | Strong evidence looks like a workflow you moved out of manual steps, and what it saved. Selection scaffold: pick one; say what the tool was and what you built or only configured. If none, say so plainly, then name the first manual step you would automate and why. |

## Prohibited list

Nothing can be listed yet. No candidate sentence has been supplied, so no stretched form of your past exists to guard against.

| Not coached | Basis | Honest form |
|---|---|---|
| Any account of your past work, including owning a process, a metric or a result | No quoted sentence exists yet, so the pack writes no past claim | None. Every past-facing cell in this pack is an answer slot. Share your CV or sentences and this list is rebuilt |

## Persona table

Weights are flat (3 questions each) because the relationship and the loop are unknown. The archetype fallback is `Generic` in the research checklist, which the pack says plainly: these weights rest on a pattern, not on Stripe's documented process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A live operations problem from the role | Medium. A final round for this role often includes one; flat weight since the loop is unknown | Clarify before structuring; say what you would measure first |
| Data-Driven Prober | Asks how a number was counted | Medium. Any metric you name will be tested | Define the event and the denominator; name the assumption you would defend least |
| Pressure / Stress | Challenges fit, interrupts | Medium. A final round is often where fit is tested hard | Pause; hold a position through two follow-ups; concede a specific uncertainty, not the core claim |
| Skeptic | Motivation, gaps, "why now" | Medium-high. Motivation is the question a final round most reliably presses | Give a motivation built from your own reasons; name a real gap and how you would close it |
| Peer Evaluator | Seams with adjacent teams | Medium. Often part of a final round for this kind of role | Name the seam as a principle, not a claim to know their work; bring what you add |
| Conversational / Rapport | Open, chatty openers | Medium. Casual questions are still scored | Have a 90-second arc ready; treat casual questions on the role's topics as scored |

## Question banks

Provenance comes before the guidance. Every past-facing question here is an open prompt or a premised question with no premise, so each guidance cell carries `[generic]` and rests on no claim about you.

### A. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Launches on this team keep slipping past their review dates. How would you find out why, and what would you change first?" | CASE | [generic] | Clarify what slipping means: which launches, against which date, measured how. Then segment the causes (intake, dependencies, review gates, scope change). Pick one to test first and name the metric that would show it working. State one assumption you are making. | A live version of the role's core work. [generic] because it is a pattern, not a fact about this company |
| A2 | "You join and find no shared view of what the product organisation is working on. What do you build in your first month?" | CASE | [generic] | Ask who will use the view and what decision it supports. Start with a light source of truth before any tool. Name one recurring artifact or meeting, and how you would know people used it. | Tests scoping and altitude, not tooling |
| A3 | "Leadership wants one number that shows whether the process is working. What do you pick, and why?" | CASE | [generic] | Name the decision the number drives before naming the metric. Pick one leading and one lagging measure. Name the counter-metric that stops the number being gamed. Say what it misses. | Altitude with metrics; sets up B1 and B2 |

### B. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Pick a number you would track for this work. Walk me through how you would count it." | JD | [generic] | Define the event precisely, then the denominator, then the data source. Name the one assumption you would defend least, before the interviewer does. | Probers test the definition before the value. Pairs with A3 |
| B2 | "A process metric improved twenty percent last quarter. How do you know the process caused it?" | CASE | [generic] | Name the confounders first: volume, staffing, a change in definition. Say the check you would run. Say what you would conclude if the check fails. | Tests attribution under a clean-sounding result |
| B3 | "Tell me about a process you measured. What did you count, and what would you not trust about it?" | EXP | [generic] | Open prompt. Selection scaffold: pick a time you measured a process. Say what was counted, the weakest assumption, and which decisions were yours. If no such time comes to mind, say so plainly, then give the nearest thing your experience carries, or how you would set it up. | EXP because it tests what was actually yours. Your answer rests on your own experience, which this pack has not seen |

### C. Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why should we hire you over someone who has done this exact job?" | JD | [generic] | Answer with the specific problems you have solved that map to this role, in your own words. If there is a real gap, name it and what you would do first. Hold the position through two follow-ups. Concede one specific uncertainty if pressed, never the core claim. | Tests composure and fit under time pressure |
| C2 | "This role has a lot of coordination and little authority. Why would people listen to you?" | JD | [generic] | Name the mechanisms you would rely on: shared data, clear decisions, escalation rules. Concede that influence without authority is slower. Hold the point you actually believe about how it works. | Probes the "influence without authority" requirement under pressure |
| C3 | "What would you need in place from day one to be effective here, and what would you do without it?" | JD | [generic] | Name two or three specific needs. For each, say what you would do if it were not there. Do not argue with the premise; describe what you would do. | Tests realism without inventing facts about the role's resourcing |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Why product operations, and why this company?" | JD | [generic] | Highest-ROI prep in this pack. Build the motivation from your own reasons and the work you have done that pulled you toward it. Add one specific reason about this company only if you have verified it from its own site. Do not borrow facts about Stripe that you have not checked. The motivation must hold across the whole interview. | The Skeptic presses motivation consistency. A generic enthusiasm answer is the most likely failure, and this question will be asked in some form |
| D2 | "What part of this role would you be weakest at on day one?" | JD | [generic] | Name one real area. Say how you would learn it in the first thirty days and who you would ask. Calibrated candour beats bluffing. | Tests honest self-assessment |
| D3 | "Operations work is often invisible. What have you done that someone would only notice if it stopped?" | EXP | [generic] | Open prompt. Selection scaffold: pick one process you kept running. Say what it prevented. If you have not run one, say so plainly, then give the nearest thing your experience carries. | Tests whether invisible work is yours to describe |

### E. Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our product teams own their roadmaps. Where is the line between your work and theirs, and what happens when you disagree?" | JD | [generic] | Seam principle: you own the operating system, they own the priorities. Disagreement goes to a named decision-maker with data. Describe your principle; use a real example only if you have one. | Partnership fit. Tests seam awareness without claiming to know their work |
| E2 | "How do you handle credit when a process change works and several teams did the work?" | EXP | [generic] | Open prompt. Selection scaffold: pick a time a change worked with several teams. Name your specific contribution and credit the others by name. If no such time comes to mind, say so plainly, then describe how you would handle it. | Credit-sharing is a peer probe. Answer rests on your own experience |
| E3 | "What would you need from our team to be effective in your first quarter?" | JD | [generic] | Name two or three specific needs, such as access, a decision-maker, or data. Then say what you would bring back. | Reciprocity: what you add to their team, not only what you need |

### F. Conversational / Rapport (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey to here." | EXP | [generic] | Build a 90-second arc: the through-line, two turns that mattered, and why this role now. Fill it from your own material; this pack has none yet. | Casual openers are scored on economy and clarity |
| F2 | "What is the most interesting operations problem you have been thinking about lately?" | JD | [generic] | Pick a real one. Explain the cause and what you tried. Keep it under two minutes. | Treats a casual question on the role's topic as scored |
| F3 | "What tools are you using for this kind of work these days?" | JD | [generic] | Name only tools you have used and what you used them for. Do not claim tools you have only read about. | Tool claims are the easiest to probe |

## Requirement coverage

No JD was supplied, so this maps the role-family requirements, all `[generic]`, to question IDs.

| Requirement | Covered by |
|---|---|
| Designing and running an operating process | A1, A2, F1 |
| Metrics and operating reviews | A3, B1, B2 |
| Measurement and attribution | B2, B3 |
| Influence without authority | C2, E1, F3 |
| Fit and motivation | C1, D1 |
| Honest self-assessment and learning | D2, C3 |
| Ownership of invisible work | D3 |
| Cross-functional partnership | E2, E3 |
| Launch and rollout coordination | A1 |
| Tooling and automation | F3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first six months look like in this role?" | Gets the success criteria from the people who will score you, and shows you plan to be measured |
| R2 | "Which process does this team most want fixed right now?" | Surfaces the current pain and shows you think in operations |
| R3 | "When product and engineering priorities conflict, how does this role get involved?" | Tests the seam directly, peer to peer |
| R4 | "Which decisions does this role make alone, and which need sign-off?" | Maps the authority before you commit to anything |
| R5 | "How will success in this role be reviewed, and by whom?" | Signals outcome thinking and gives you the real evaluation path |

## Sources

Provided documents: the company name, the role title and your message. No JD, CV or pasted material.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Refused. Would have moved the values cheat sheet (section 10). Section absent, since no values are in hand |
| 2. Stripe interview process, product operations | unavailable | Refused. Would have set the loop structure and persona weights. Weights stay flat |
| 3. Stripe strategy and recent news | unavailable | Refused. Would have fed CO questions. None were written, so the pack has no company-strategy questions |
| 4. Interviewer name and Stripe | n/a | No interviewer name was given, so no query could be formed. Interviewer read absent |
| 5. Representative product operations manager JD | unavailable | No search sent; no JD was supplied and the budget was spent on targets 1 to 3. Would have grounded the fit rows as `[inferred]` |

Queries sent, each refused:
- "Stripe values operating principles official", domain filter stripe.com. Refused.
- "Stripe interview process product operations manager final round". Refused.
- "Stripe strategy recent news 2026". Refused.

## Upgrade menu

- The round and the person you are meeting → persona weights, the reverse-question set and the interviewer read
- Your JD text → the fit rows become `[grounded]`, the coverage table is rebuilt against its own requirements, and JD questions are tailored
- Your CV, or a few sentences about your past work → the evidence cells, story maps for B3, D3 and E2, and the prohibited list
- Permission for web searches → the values cheat sheet, the interview-process check and current strategy for CO questions
- The recruiter's prep email → any pre-declared deliverable and the process details
- A deeper research pass (up to six more searches and two more fetches, several minutes) → the company strategy brief and role-family loop reports
