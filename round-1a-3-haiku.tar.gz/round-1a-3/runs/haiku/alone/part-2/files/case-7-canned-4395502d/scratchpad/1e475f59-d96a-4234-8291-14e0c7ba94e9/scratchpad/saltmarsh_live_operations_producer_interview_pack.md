# Interview prep: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship: hiring manager, assumed from the company's Outage Hour format (to confirm).
**Round:** 60-minute Outage Hour (live-incident tabletop, then a values conversation), per saltmarshgames.com/careers/interviewing.
**Candidate:** Femi (they/them).
**Changes in this version:** first version.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (your past work), JD (role requirement), CO (company strategy), CASE (live problem).
- Guidance is scaffolding, not a script. Rehearse out loud, in your own words.
- Quoted sentences are yours, from your message. Quote only what you can stand behind.

## Research tier

Research tier: L1, 4 searches of 6 and 2 fetches of 2. Sources are in section 9.

## 1. Prep triage (about 60 minutes of prep)

1. **B2** (highest-ROI prep): the "two titles, never led a team" objection. Rehearse until the hold and concession are routine.
2. **A1** and **A2**: the outage tabletop. Practise the first ten minutes out loud.
3. **C1** to **C3**: the three published values, each with a story or an honest "I don't have one."
4. **Reverse questions** (section 11): pick two and say them aloud.
5. Everything else is insurance.

## 2. Fit snapshot

Requirements come from the JD you supplied (quoted), and the JD's gaps are scored against your quoted sentences only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | presentation | Your material gives four years at a puzzle-game studio. It does not say the game was live-service, so say that yourself if asked: "I was an associate producer for four years at a puzzle-game studio." |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | high | [grounded] | none | No gap. Lead with the calendar in your own words. |
| F3 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | Your material says you presented the numbers, not that you owned the metric definitions. Say presented; do not say owned. |
| F4 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | transferability | The checklist is written work that others still use. It is not a communication sample on its own. Lead with the checklist's use, not an adjective. |
| F5 | "Plan and run the live-events calendar for two mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material is one title and content drops, not two titles and live events. Say the one-title scope, then how you would extend it. |
| F6 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | low | [grounded] | discovery | Your material does not show cross-team coordination on each update. Answer slot in B2. |
| F7 | "own the post-event review and the KPIs it reports" (JD) | none given | low | [grounded] | discovery | Your material does not show a post-event review. Answer slot in A2 and B2. |
| F8 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | You wrote it and QA still uses it. Say that. Do not say you managed the QA process unless you did. |
| F9 | Not in the JD: team leadership | "Never led a team" (your message) | none | [grounded] | capability | The JD does not ask for people management. The Skeptic may still raise it through "coordinate". Plain acknowledgment: "I haven't led a team." See B2. |
| F10 | Not in the JD: in-app purchase experience | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | The JD does not name monetisation, but the Outage Hour's live-event scenario may raise it. Plain acknowledgment: "I've never worked on a game with in-app purchases." See B1. |

Seven rules are behind this table. The gap type follows your quote, not my sense of the row.

**Observation:** your material does not show post-event reviews, cross-team coordination, or KPI ownership. The pack will not supply them.

## 3. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the live-events calendar for two titles | Inflated form of F5 | "I ran the weekly content-drop calendar for our main title." The material says one title, not two. |
| Owned the KPIs | Inflated form of F3 | "Presented the monthly retention numbers to the studio head." |
| Led a team, or managed people | Negative you stated (F9) | "I haven't led a team." No slot. |
| Worked on in-app purchase games | Negative you stated (F10) | "I've never worked on a game with in-app purchases." No slot. |

## 4. Interviewer read

- **Public footprint:** a GDC 2026 talk, "Patch Notes Are a Promise", by Tobias Wrenfield, Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio. Source: search snippet only; I did not open the talk page.
- **Practical implications:** the talk's thesis is that a live team is judged by how often its patch notes describe what actually shipped. Expect questions on what shipped versus what was promised. The shared thread with your release checklist (F8) is real: both are about the gap between plan and shipped work.
- **Shared professional path:** Tobias came from QA, and your checklist is QA-facing. This is a legitimate mirror. Do not overstate it.

## 5. Persona weights

| Persona | Weight | Reasoning |
|---|---|---|
| Case / Strategist | 4 | The Outage Hour is a live-incident tabletop. Expect CASE questions on a simulated outage during a live event. |
| Skeptic | 3 | Hiring managers buy capability and derisk gaps. F5, F6, F9, F10 are the gaps. |
| Values / Behavioral | 3 | The Outage Hour's second half is a values conversation against three published values. |
| Pressure | 2 | Time-boxed challenge on F5 and F9 is plausible from a hiring manager. |
| Conversational | 1 | Opening biography and "walk me through" are scored even when casual. |

## 6. Question banks

### Case / Strategist (CASE)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We're mid-event and a simulated outage hits. Walk me through your first ten minutes." | CASE | [generic] | Clarify: which players, which platform, how many, what changed. Then decide who is pulled in: engineering on call, community for player messaging. Then set a comms cadence and choose between a fix and a rollback. Speak it in about 90 seconds. | The Outage Hour's tabletop, per the careers page. Generic process: this makes no claim about your past. |
| A2 | "Retention dropped eight percent in the week after an event. Diagnose it." | CASE | [generic] | Name the first cut you would check: by platform, by cohort, by event exposure. State the weakest assumption in the metric before the interviewer does. Say what you would tell the community while you investigate. | Retention is in the JD. The metric is a generic example, not a fact about your past. |
| A3 | "Plan the next two events across two titles. What do you need to know first?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Clarify: release windows, QA capacity, which titles share engineering, what counts as an event. Then sketch a calendar. Use your one-title calendar as the only experience you cite. | The JD raises two titles. The quote is the only past work you cite. |

### Skeptic (JD, EXP)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked on a game with in-app purchases. How would you plan an update when monetisation is involved?" | JD | [grounded] "I've never worked on a game with in-app purchases." (your message) | Plain acknowledgment first: "I haven't worked on a game with in-app purchases." Then answer slot: if you have made a decision that touched monetisation, say which and how you decided, in your own words. If not, say so plainly, and describe how you would learn it: pricing and offer cadence first, then talking to the monetisation team. | F10 is a stated gap, and the Outage Hour may raise it through a live event. |
| B2 | "Your background is a puzzle studio and you've never led a team. What makes you ready to coordinate design, art, engineering and community on each update?" | JD, EXP | [grounded] "Never led a team" (your message). [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message). | **Highest-ROI prep.** Hold: "I ran the weekly content-drop calendar for our main title for the last two years." Hold through two follow-ups by returning to the calendar. Concede: "I haven't led a team." Then answer slot: if you coordinated any of those four teams, name which and how; if none, say so plainly, and describe how you would set up the update's cross-team plan. | F9 and F6 together: the most likely objection. "Coordinate" is the JD's word, not "lead". Do not claim the four-team coordination. |
| B3 | "Sixty seconds: why should we take a one-title producer over someone who has run two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Pressure version of B2. Hold the one-title record and say it is the scope you have. Concede: "Two titles is more than I've run." Do not add scope. | F5 is the gap a Pressure interviewer tests first. |

### Values / Behavioral (VAL)

Saltmarsh's three published values are: **Players Before Plans**, **Ship the Patch Not the Promise**, and **Leave the Build Greener**. Source: saltmarshgames.com/values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Open prompt. Map: the weekly drop is the calendar. If a drop had to move for players, say so and what you did. If none comes to mind, say so plainly, then give the nearest thing: how the weekly drop was scheduled. | Players Before Plans, a published value. The calendar is the only sentence you have to hold. |
| C2 | "When have you announced something before it was ready? What happened?" | VAL | [generic] | Open prompt. Selection scaffold: pick a time a date went out before the content was done, and what you did next. If none comes to mind, say so plainly, then say how you would avoid it. | Ship the Patch Not the Promise, a published value. No quoted sentence carries a story. |
| C3 | "Tell me about something you left better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Map to the checklist. Say what it changed and who uses it. If you do not know what changed, say that. Do not add a metric. | Leave the Build Greener, a published value. The checklist is the sentence you have. |

### Conversational (EXP)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through your background." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" and "I ran the weekly content-drop calendar for our main title for the last two years" and "Presented the monthly retention numbers to the studio head" and "Wrote the release checklist our QA team still uses" (your message) | A 90-second arc: studio and role, calendar, retention presentation, checklist. Use only these four sentences. | Opening question. Rapport interviewers score casual answers too. |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 3+ years producing live-service games or apps | F1 (fit snapshot); D1 |
| Experience running a content calendar | A3, C1, D1 |
| Comfortable with player-retention metrics | A2 |
| Clear written communication | C3 (the checklist) |
| Plan and run the live-events calendar for two titles | A3, B3 |
| Coordinate design, art, engineering and community teams | B2 |
| Own the post-event review and the KPIs it reports | A2, B2 (answer slot, F7) |
| Manage the release checklist with QA | C3 |

## 7. Values cheat sheet

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | C1: selection scaffold with honest branch, anchored in "I ran the weekly content-drop calendar for our main title for the last two years" (F2) |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | C2: selection scaffold; no quoted sentence carries a story |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | C3: anchored in "Wrote the release checklist our QA team still uses" (F8) |

## 8. Company strategy (grounding)

- **Project Larkspur (September 2026):** Tidepool Tactics and Lantern Row move to a season-pass model with one shared events calendar from February 2027. Per-title event teams are retired in favour of a single live-ops group.
- **Why it matters for you:** the JD says "two of our mobile titles", and Larkspur is a one-calendar, one-group model. Expect the Outage Hour to test whether you can work across both titles.
- **Source:** search snippet only (saltmarshgames.com/news/project-larkspur). I did not open the page. Check it before you rely on the titles or dates.

## 9. Sources

- Provided: JD, candidate background, and the role and interviewer you named.
- Search: "Saltmarsh Games values". Returned saltmarshgames.com/values.
- Fetch: saltmarshgames.com/values. Values names and definitions came from this page.
- Search: "Saltmarsh Games interview process Live Operations Producer". Returned saltmarshgames.com/careers/interviewing.
- Fetch: saltmarshgames.com/careers/interviewing. Loop structure: recruiter call, then the Outage Hour.
- Search: "Saltmarsh Games strategy live operations 2026". Returned the Project Larkspur announcement (snippet only).
- Search: "Tobias Wrenfield Saltmarsh Games Head of Live Operations". Returned a GDC 2026 talk listing (snippet only).

### Target accounting

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. saltmarsh values | yes | Values cheat sheet (section 7) and C1 to C3 |
| 2. interview process | yes | Loop structure: Outage Hour, which sets persona weights |
| 3. strategy / recent news | yes | Project Larkspur, section 8 and A3 |
| 4. interviewer name | yes | Interviewer read, section 4 |
| 5. representative JD | skipped | The JD you supplied fixes the fit snapshot |

## 10. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| E1 | "With Larkspur moving both titles to one calendar from February, how will the Outage Hour's live events be split between titles?" | Shows you read the September announcement. Turns a worry into a planning conversation. |
| E2 | "What did the last post-event review change in the calendar?" | Tests the JD's post-event review requirement and gives you a live answer on how they learn. |
| E3 | "Which part of the release checklist would you want the QA team to change first?" | Opens the checklist work (F8) as a shared problem with Tobias, who came from QA. |
| E4 | "What does a good first 90 days look like on the live events calendar?" | Standard, but it signals you are planning for the job, not interviewing for it. |
| E5 | "When the calendar and the players disagree, which way has it gone for you recently?" | Ties to Players Before Plans and gives Tobias a values answer to react to. |
| E6 | "Your GDC talk argues that patch notes are a promise. What is the one note you would most like to see rewritten?" | Ties to Tobias's own published talk. Use only if you have read the talk; the snippet is all I have. |

## 11. Upgrade menu

- A recruiter email confirming the round format and whether a presentation or take-home is due → the pack adds a graded-deliverable section. Saltmarsh's careers page says there is no take-home.
- Your account of any cross-team coordination or post-event review → F6 and F7 become grounded, and B2's answer slot gets its material.
- The Larkspur page and the GDC talk, opened in full → section 8 and E6 move from snippet to verified.
- Whether Tobias is the hiring manager for this role → section 5 and the Outage Hour assumption are confirmed.
