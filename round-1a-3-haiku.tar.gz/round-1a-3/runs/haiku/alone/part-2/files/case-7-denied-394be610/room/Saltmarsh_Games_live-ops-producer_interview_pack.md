# Live Operations Producer, Saltmarsh Games: interview pack

- **Role:** Live Operations Producer
- **Company:** Saltmarsh Games (mobile, about 350 people)
- **Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager; not yet confirmed.
- **Format:** 60 minutes. Whether it is one conversation or a panel is not yet confirmed.
- **Research:** the host refused every web search, so no company values, loop structure, strategy or interviewer footprint is in this pack. Those sections are absent or generic, and the upgrade menu says what they would add.
- **Version:** first version.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioural / values | Whether past behaviour shows a published value. No values were retrieved, so no VAL questions are in this pack. |
| EXP | Experience deep-dive | Whether your stated experience survives scrutiny, and what you actually did |
| JD | Role / JD-driven | Whether you can do the listed job, including its gaps |
| CO | Company knowledge | Not in this pack: research did not run |
| CASE | Live problem | Structure and reasoning on a problem from the role |

Guidance is scaffolding, not a script. Say things in your own words. Where a cell quotes a sentence from you, that sentence is the most you can claim.

## Fit snapshot

Requirements come from the JD you supplied, quoted exactly. Evidence is quoted exactly from your message, which is the only source of your background. Confidence is medium throughout because nothing has been inspected. Two gap rows (G1 and G2) are marked as role-family expectations rather than JD lines.

Observations, in the pack's own analysis:
- Your material says one "main title" and a "weekly content-drop calendar". It does not say the title was mobile.
- No row is a gate. The JD's years line is not a legal or credential bar, and the material states no term the role sets.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one main title and a weekly content-drop calendar, not two titles or live events. Keep the words at that scope: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the two-title line makes a probe on how you would split one calendar across two likely. If you planned across more than one title, say how, in your own words; if you did not, say so and say how you would plan two. |
| R2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [grounded] | discovery | The material shows a checklist QA uses. It does not show coordinating design, art, engineering or community on an update. Answer slot: if you coordinated any of those teams on an update, say which and what you did; if none, say so and describe how you would coordinate them. |
| R3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Presenting monthly numbers is adjacent reporting. It does not show owning a post-event review, and the reporting was monthly, not per event. Keep the words at scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you owned a post-event review, say which parts; if you presented numbers without owning the review, say so plainly. |
| R4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Words: "I wrote the release checklist our QA team still uses." A checklist is an inspectable artifact, so sharing it (with confidential content removed) would raise confidence to high. |
| R5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | presentation | The quote gives the years and the studio type. It does not say the work was live-service, though R6 is the nearest live-service fact. Words: "I was an associate producer at a puzzle-game studio for four years." Nothing is added to the years. |
| R6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Words: "For two years I ran the weekly content-drop calendar for our main title." Expect a probe on cadence and scale. |
| R7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: it shows you reported retention. Words: "I presented the monthly retention numbers to the studio head." No figure is in your material, and the pack supplies none. Any figure you give will be probed. |
| R8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote shows written work another team uses. It does not show the quality of your writing. Words: "I wrote the release checklist our QA team still uses." Upgrade: a redacted writing sample would show it directly. |
| G1 | [generic] team leadership. The JD says coordinate, not lead, but a Skeptic will probe it. | "Never led a team" (your message) | medium | [grounded] | capability | Your stated absence. Plain acknowledgment: "I've never led a team." Then how you would handle leading or coordinating teams, said as a plan and never as a past. Nothing is added to make the gap smaller. |
| G2 | [generic] monetised live operations, in-app purchases. Not a JD line, but a likely probe on a mobile title. | "never worked on a game with in-app purchases" (your message) | medium | [grounded] | capability | Your stated absence. Plain acknowledgment: "I've never worked on a game with in-app purchases." Then what you would learn first, as a plan. |

## Persona weights

Relationship priors for a hiring manager set the starting weights, since the relationship is assumed. Your answer to the question at the end of this message would reweight them. The loop is not established by any source, so no loop-based adjustment applies, and the archetype fallback is not used for a values round: no values-style round is detected.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Skeptic | Probes the two stated gaps and the JD's coordination and review lines | High. Hiring managers buy capability and derisk gaps; G1 and G2 are visible in your material. | Rehearse the gap acknowledgments until they are plain. Bridge only from quoted evidence. Give a plan, not a past. | 5 |
| Case / Strategist | Live calendar and diagnosis problems from the role | High. Hiring managers test structure on their own roadmap. | Clarify first. Structure before answering. Say your assumptions. | 4 |
| Data-Driven Prober | Defend-the-number on the retention presentation and the calendar | Medium to high. The retention line is the one place your material carries a metric. | Say how a figure was counted only if you know. If you do not, say so. Name the weakest assumption. | 4 |
| Pressure | Holds on your "never led a team" and on the calendar's attribution | Low. Included at a low weight for composure. | Pause, restate, hold through two follow-ups, then concede specifically. | 2 |
| Conversational | Casual opener, a casual question on mobile games | Low to medium. Casual questions are scored. | A 90-second arc from your quoted sentences only. Answer casual topics truthfully. | 3 |

Total: 18 questions. Values/Behavioural bank: none, because no values-style round is detected.

## Question banks

**Highest-ROI prep: A2.** The most predictable objection to you is that the role coordinates four teams and you have never led one. It will come in some form. Rehearse the plain acknowledgment and the plan until they are boring. A3 is the close second, on in-app purchases.

### Persona A: Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team" (your message); [grounded] "never worked on a game with in-app purchases" (your message) | Open prompt. Name the two gaps you have already stated, in your own words: "I've never led a team." and "I've never worked on a game with in-app purchases." Then give the first things you would do about them, as a plan. | The most likely opening of a Skeptic round. Both gaps are your own negatives, so both can be said plainly. G1 and G2 are the evidence. |
| A2 | "The JD says you'd coordinate design, art, engineering and community on each update. I don't see team leadership in your background. How would you do that without managing them?" | JD | [grounded] "Never led a team" (your message); [grounded] "Wrote the release checklist our QA team still uses." (your message) | Plain acknowledgment: "I've never led a team." Then answer as a plan: how you would get each team's input before an update is locked, and who decides when they disagree. The nearest fact is the checklist, at its own scope: "I wrote the release checklist our QA team still uses." Do not describe coordinating any team you did not coordinate. | The JD's coordination line is the raising source; the premise is your own negative. The material shows no coordination, so the answer is a plan. |
| A3 | "If the titles earned through in-app purchases, what would you need to learn first?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I've never worked on a game with in-app purchases." Then what you would learn first, as a plan. Do not claim you have learned it. | The conditional "if" keeps the question from presupposing that the role's titles earn through purchases, which the JD does not say. G2 is the evidence. |
| A4 | "Presenting numbers to a studio head is different from owning a review. Which did you do?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Answer slot: if you ran a post-event review and owned what it concluded, say which parts, in your own words. If you presented the numbers and did not own a review, say so plainly, then say what you would own. Hold through two follow-ups by returning to what you presented. | The JD's "own the post-event review and the KPIs it reports" is the raising source. R3 is the evidence. The honest branch covers "I did not own one". |
| A5 | "Did anyone else shape the release checklist?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Answer slot: if others shaped it, name who and what they changed. If it was yours alone, say so. Then say what QA uses it for, in your own words. | Tests attribution on the one artifact the material has. R4 is the evidence. |

### Persona B: Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two titles, one live-events calendar. Sketch the next quarter. What do you need to know first?" | CASE | [generic] | Clarify first: which titles, what the current calendar already commits, what the events are for, and who signs off on dates. Then objective, the players the events target, approach, metrics and risks. Name one premise you would challenge. Make no claim about your history. | A live problem from the JD's calendar line. CASE because it scores structure on a problem from the role. |
| B2 | "Retention dropped after the last update. Diagnose it." | CASE | [generic] | Clarify: which cohort, which dates, what else changed that week. Separate the update from seasonality, and from any change in how retention is counted. Name the metric you would check first. | A pattern for the JD's retention line. No claim about you. |
| B3 | "Two days before a live event, QA says the build isn't ready. What do you do?" | CASE | [generic] | Structure it: what the blocker is, what it puts at risk, who makes the go or no-go call, and what you would record. Make no claim about your past. | The JD's "manage the release checklist with QA" is the raising source. CASE because it is a live decision. |
| B4 | "Which parts of the post-event review would you own, and which would you hand off?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Answer slot: if you have owned a post-event review, name the parts you owned, in your own words. If you have not, say so, then say which parts you would own and why. | The JD's exact line is the raising source. The honest branch covers "not owned". |

### Persona C: Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Defend-the-number slot. Your material has no figure and no method. If you know how the numbers were counted, say it in your own words. If you do not, say so plainly. | A presented figure raises the defend-the-number slots. R7 is the evidence. The answer must come from what you remember, not from a method this pack supplies. |
| C2 | "Which assumption behind those retention numbers would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Weakest-assumption move: name the assumption before they do, in your own words. If you do not know one, say that instead. | The second defend-the-number level. Same evidence as C1. |
| C3 | "What did you decide about the weekly content-drop calendar, and what did other people decide?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Answer slot: describe the decisions that were yours and the ones that were not, in your own words. If any were yours to set, say which and how you decided. If they were set elsewhere, say so. | The quote says "ran", not "decided". The question asks for attribution so the answer does not drift past the quote. |
| C4 | "For a mobile title you're new to, which KPI would you look at first, and why?" | JD | [generic] | Name one KPI, what it tells you, and what you would need to rule out before trusting it. Do not name a title you have played or a number from one. | Tests the JD's KPI line. Makes no claim about you. |

### Persona D: Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire a producer who has never led a team?" | JD | [grounded] "Never led a team" (your message) | Pause. Restate it: why you would coordinate without having led. Hold: "I ran the weekly content-drop calendar for our main title for the last two years." and "I wrote the release checklist our QA team still uses." Hold through two follow-ups. Concede specifically: "I haven't led a team, and the coordination part is where I'd need to prove it." | Hold-then-concede. The position held is one your quotes carry. The concession names the gap and does not rescue it. G1 is the evidence. |
| D2 | "How much of the weekly content-drop calendar was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Hold: you ran it for two years. Concede what was shared: name the other people and what they did, specifically. Do not claim decisions that C3 did not establish. | A pressure form of attribution. The hold rests on the quote; the concession is specific, not a blanket "a lot of people helped". |

### Persona E: Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | A 90-second arc using only these sentences: four years as an associate producer at a puzzle-game studio; the weekly calendar for two years; the release checklist; the retention presentation. Close with what you want next, in your own words. | Casual questions are scored. The arc rests only on R5 and R6. |
| E2 | "What are you playing on mobile these days?" | JD | [generic] | Name a game you have actually played, and one thing about its live updates you would keep. If you have not played one recently, say so and name the nearest one you know. | A casual question on a JD-adjacent topic, scored. Makes no claim about you beyond the instruction to answer truthfully. |
| E3 | "What was the hardest week on that content calendar?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Open prompt. Choose one hard week you can describe, and name its beats in your own words. If no week stands out, say so and give the nearest thing the calendar involved. | An open prompt on the quoted calendar. The honest branch is built in. R6 is the evidence. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | B1, C4 |
| Coordinate design, art, engineering and community teams on each update | A2, D1 |
| Own the post-event review and the KPIs it reports | A4, B4, C4 |
| Manage the release checklist with QA | A5, B3 |
| 3+ years producing live-service games or apps | E1 (arc only) |
| Experience running a content calendar | C3, E3 |
| Comfortable with player-retention metrics | B2, C1, C2 |
| Clear written communication | None, and why: no question tests written work directly. A5 touches the checklist only. Upgrade menu: a writing sample. |

## Reverse questions

1. "What would the first update you'd want me to plan look like, and which title would it be for?" Why it lands: shows you are thinking about their calendar, not a generic one.
2. "How is the post-event review run today, and who owns the KPI definitions?" Why it lands: tests whether the KPIs are the role's to own, which is the JD's line.
3. "When design, art, engineering and community disagree on an update's scope, who makes the call?" Why it lands: asks the coordination question the Skeptic will test, from their side.
4. "What has happened when a build missed a release date, and what changed afterwards?" Why it lands: shows you take the QA line seriously.
5. "How much of the monetisation decisions does this role inform, and which sit with others?" Why it lands: puts the in-app purchase gap as a question about their structure, not as an apology.

## Prohibited claims

Built locally from the fit snapshot. Each entry names its basis and its honest form. No answer slot, hold, bridge or rationale in this pack asserts any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led or managed a team | Stated negative: "Never led a team" | Plain acknowledgment: "I've never led a team." No slot about past leadership. |
| Has worked on a game with in-app purchases | Stated negative: "never worked on a game with in-app purchases" | Plain acknowledgment: "I've never worked on a game with in-app purchases." No slot about past monetisation. |
| Owned the post-event review or its KPIs | Inflated form of R3: "Presented the monthly retention numbers to the studio head." | R3's quote at its own scope. The limit is the pack's observation: the material says presenting numbers, not owning a review. A4 covers it. |
| Ran live events across two titles | Inflated form of R1: "I ran the weekly content-drop calendar for our main title for the last two years." | R1's quote at its own scope. The material says one main title and a weekly content-drop calendar. |
| Drove or improved retention | Inflated form of R7 | The quote says you presented the numbers. It says nothing about movement, so no slot on it. |
| Live-service mobile experience | Inflated form of R5: "4 years as an associate producer at a puzzle-game studio." | R5's quote at its own scope. The material says a puzzle-game studio and does not say live-service or mobile. |

## Sources

- **Provided documents:** the job description and your background, as written in your message.
- **Searches attempted (all refused by the host, none returned results):**
  - "Saltmarsh Games mobile studio"
  - "Tobias Wrenfield Head of Live Operations Saltmarsh Games"
  - "Saltmarsh Games values careers live operations producer"

**Research tier: L1, searches 0 of 6 returned results (3 refused), fetches 0 of 2.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet absent. Nothing from model memory was used. |
| 2. Saltmarsh Games interview process | unavailable | Loop structure unknown. Persona weights rest on hiring-manager priors, not on this company's process. |
| 3. Saltmarsh Games strategy / recent news | unavailable | CO questions absent. The CASE questions are generic. |
| 4. Tobias Wrenfield Saltmarsh Games | unavailable | No interviewer read. Reverse questions are role-generic. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot. |

## Upgrade menu

- Whether Tobias is your future manager, and whether the 60 minutes is one conversation or a panel → persona weights, and whether the reverse questions are reweighted.
- Any exercise or presentation Saltmarsh has announced → a graded build section for it.
- The company values page, pasted → a values cheat sheet, and VAL questions.
- The company's careers page or interview guide, pasted → the loop structure, in place of the archetype prior.
- Tobias's public profile or talks, pasted → an interviewer read and a reverse question tied to his path.
- A recent Saltmarsh strategy note, pasted → CO questions in place of generic CASE questions.
- The release checklist, with confidential content removed → R4 and R8 move to high confidence.
- The retention figures you presented, and how you remember them being counted, in your own words → C1 and C2 get a stated figure to defend.
- A redacted writing sample → R8 and the written-communication requirement get a row of their own.
- A tuesday-dossier.md, if you have one → evidence-derived objections in place of the inferred ones here.
