# Larkfield Systems, Engineering Manager: prep for three rounds

Role: Engineering Manager, Larkfield Systems (industrial IoT, about 600 people). Rounds in order: Tuesday, 45 min with the hiring manager (a Director of Engineering); the Thursday after, 60 min panel with two staff engineers and a product manager; the following Monday, 30 min with the VP Engineering. Interviewer names: not given. Loop mode: your message names each round and who runs it, so the loop is set by your words.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script.

- **VAL**: behavioral and values alignment
- **EXP**: your own experience, checked for attribution
- **JD**: the role's stated requirements
- **CO**: company and strategy knowledge
- **CASE**: a live problem from the role

An answer slot is an instruction for the interview. It is not a question to me, and you do not answer it here.

## Prep triage: sequencing across the rounds

Prep hours were not given, so this is ordered by round, not timed.

1. **Now to Tuesday.** Say A1, A4 and A8 aloud until they sound plain. They are the three the Director is most likely to press. Build each answer only from the quoted sentences in its Provenance cell.
2. **Tuesday to Thursday.** Write down from memory which question landed hardest on Tuesday. Keep every figure and every sentence the same in the panel. Rehearse B1, B2, B5 and B8 aloud.
3. **Thursday to Monday.** Draft your leadership philosophy in five sentences, each tied to one of C1, C3 or C9's quotes. Rehearse C8 and C9 aloud, because they are the pressure questions at VP altitude.
4. **Throughout.** Carry the one plain acknowledgment that matters most into every round: "I've never owned a hardware-adjacent roadmap." Say it once, then give the plan for how you would learn it.

Everything else is insurance.

## The fit snapshot (shared across all three rounds)

Requirements are quoted from your role text. Evidence is quoted from your message. Nothing else is evidence.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (your message) | "9 years engineering, 3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows one team of six for three years, and the bridge keeps that scope: "3 as a team lead of 6." Two squads is a step the material does not show. Answer slot: if you have coordinated work across two groups, say what you did and how it went, in your own words; if you have not, say so and describe how you would split the work across two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" (your message) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | The quote is reliability work, not delivery across squads, so the bridge stays with it: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you ran delivery planning for a group of engineers, say how; if the reliability quarter was the closest you came, say so and say what it did and did not cover. |
| F3 | "own delivery, hiring and growth for 11 engineers" (your message) | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | presentation | The quote already reaches hiring, in backend terms. The bridge rewords only that quote and adds no practice: "For backend roles, I run the hiring loop — about 40 interviews last year." The count is a figure, so expect a probe on it (A10). |
| F4 | "own delivery, hiring and growth for 11 engineers" (your message) | none given | none | [grounded] | discovery | Your material does not show how you have grown engineers, and the pack does not supply it. Answer slot: if someone you managed moved to a bigger role and you helped, say what you did, in your own words; if no one did, say so and say how you would start. |
| F5 | "partner with hardware and product on roadmap" (your message) | "I pushed a reliability quarter through against roadmap pressure" (your message) | low | [inferred] | transferability | Your material shows you held a reliability quarter against roadmap pressure. It does not show a roadmap you partnered on with product. The bridge is this pack's reading of F2's quote, so it is a lead, not a claim. Answer slot: if you agreed the roadmap with product, say how; if the roadmap was set without you, say so. |
| F6 | "partner with hardware and product on roadmap" (your message) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Never a claim to hardware roadmap work. |
| F7 | Not in your role text. Managing managers, from your own gap note. (your message) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | Words: "I haven't managed managers." Then what you would do to learn it, as a plan. |

No gate row exists. Your role text states no location, travel or work-authorization term, so the material is silent on them and nothing is surfaced as a gate.

What the material shows: your strongest evidence is one measured reliability result and one hiring loop count. Growth and hardware have no evidence in it.

## Prohibited claims

These claims are not coached in any answer, hold, bridge or reverse question. Each carries its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Inflated form of F1 and of F7's gap | "3 as a team lead of 6" at its own scope. Plain acknowledgment from F7: "I haven't managed managers." |
| Owned a hardware-adjacent roadmap | Negative you stated, F6 | Plain acknowledgment from F6: "I've never owned a hardware-adjacent roadmap." No slot. |
| Set the roadmap, or owned delivery across two squads | Inflated form of F2 and F5 | The reliability quarter quote at its own scope. The limit is this pack's observation: your material says you pushed the quarter through, not that you set the roadmap. |
| Cut on-call burden by 60% | Inflated form of the on-call quote, where "after" is temporal, not causal | "burden dropped 60% after I pushed a reliability quarter through." The figure at its scope. |
| Ran hiring for the whole organization | Inflated form of F3 | "I run our hiring loop for backend roles." |

## Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| Lead two squads building device-management services | A2, A5, B8, B9, C6, C7 |
| Own delivery | A8, A9, B5, B6, C9 |
| Own hiring | A7, A10, B7 |
| Own growth for 11 engineers | A7 only. No question asks growth alone, because your material has no growth evidence for one to draw on. |
| Partner with hardware and product on roadmap | A4, A6, A12, B8, C3, C6 |

## Round 1: hiring manager, Director of Engineering (Tuesday, 45 min)

Persona weights, with the reasoning shown. Relationship priors for a hiring manager are Case/Strategist and Skeptic. No interviewer profile exists, so the weights stay at the priors.

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Skeptic (4) | Quiet cross-examination of your gaps; "why you" | High. A hiring manager is buying capability and checking the two gaps your message names. | Rehearse A1 until it is plain. Hold the position through two follow-ups, then concede the exact gap. Never bluff hardware. |
| Case/Strategist (3) | Live problems on device-management and hardware dates | High. Hiring managers test on their actual roadmap. | Clarify before structuring. State the trade-off. Name what you would ask hardware first. |
| Data-Driven Prober (3) | Counting the 60% and the 40 interviews | Medium. These are the only figures the pack has, and a Director reads the CV. | Say what you know about each count. Name the weakest assumption before it is asked. |
| Conversational (2) | The opening arc and a casual hardware question | Medium. The opener is scored, and the casual hardware question is a scored gap. | A 90-second arc from quotes. Treat A12 as scored. |

**A1 is the highest-ROI prep in this pack.** The objection is that you have never managed managers and never owned a hardware-adjacent roadmap, and it will come up in some form. Rehearse it until a non-defensive answer is ready.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Why should this Director bet on someone who has never managed managers and never owned a hardware-adjacent roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "9 years engineering, 3 as a team lead of 6" | Hold on what you did: "3 as a team lead of 6." Concede the exact gaps in your own words: "I haven't managed managers" and "I've never owned a hardware-adjacent roadmap." Then say how you would close each one, as a plan. Hold through two follow-ups by returning to the quote. Answer slot: if a scoped step toward either gap exists in your past, say it at its own scope; if none, say so. | This is the objection the Skeptic is built to press. F1, F6 and F7 are its evidence. The concession is named before it is asked for. |
| A2 | "Which of the three requirements would you be weakest at on day one?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" | Name the requirement you are least ready for, in the quote's terms: one team of six, so the two-squad scope is the step. Answer slot: if you have coordinated work across two groups, say what you did; if not, say so and give your first move. | F1 is the scope gap. Answering with a plan beats a bluff. |
| A3 | "Sixty seconds: why should we choose you over a candidate who has managed managers?" | JD | [grounded] "I've never managed managers" | Keep it to 60 seconds: the one experience you have that the role needs, then the gap in one sentence, then the plan. Do not argue the comparison. | The Skeptic's stress version of A1. The concession is the same sentence as in A1. |
| A4 | "Where in the two-squad scope would you rely most on people who know the hardware better than you?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap." | Name the hardware decisions you would hand to hardware leads and the ones you would not. Say you have never owned a hardware-adjacent roadmap, and say how you would learn the dependencies first. | F6 is the stated absence. Naming delegation is a plan, not a past. |
| A5 | "Two squads, a device-management release and a hardware revision that slips six weeks. What do you do in the first week?" | CASE | [generic] | Clarify what is fixed and what is not. Name who you would talk to first (hardware, product, the squads). Set the trade-off out loud. State what you would decide by the end of week one. | A live problem from the role. It asks about no past, so it claims nothing about you. |
| A6 | "Hardware wants to slip, and product wants the date held. Walk me through how you would decide the order." | CASE | [grounded] "partner with hardware and product on roadmap" | Frame the decision by what each side loses. Say what you would need to know from hardware before you decide. Name who decides if you cannot agree. | The raising source is the role text, so the question is fair to ask. The guidance makes no claim about your past. |
| A7 | "How would you run hiring and growth for 11 engineers over the next two quarters?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Start from the loop you run today, for backend roles, and say what would change for the new roles. Then say how you would develop people, as a plan. Answer slot: growth has no quoted evidence (F4); if you have grown anyone, say how; if not, say so and say how you would begin. | Covers hiring (F3) and, in the slot, growth (F4). A plan rests on the quote, not on invented growth. |
| A8 | "Walk me through how the 60% on-call figure was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say the figure in your own words. If you know how it was counted, say so. If you do not, say that plainly. Name the assumption you would defend least. Say which part was yours: you pushed the quarter through. Do not explain a method you cannot repeat under a second question. | Your headline figure. A Prober tests the count and the assumption behind it. The method is not in the quote, so the guidance supplies none. |
| A9 | "Which part of that drop was yours to change, and which was the team's?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Separate what you did from what the team did, in the quote's terms: you pushed it through. Do not claim the whole drop. If the team did the work, say so. | Attribution is what a Prober checks. The quote's "after" is temporal, so do not turn it into cause. |
| A10 | "About 40 interviews last year: what did that number leave out?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say what the count covers and what it does not: interviews, not hires, and backend roles only. Name the figure you would defend least. | A figure raises the defend-the-number slots, and this one is in the loop you run. |
| A11 | "Walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc: nine years in engineering, three of them as a lead of six, now at a payments company. Tell it in your own words. | Speakable opener. The Conversational persona scores it as a real answer. |
| A12 | "What would you need to learn first about the hardware side?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap." | Name the two or three things you would learn first about the hardware side, as a plan. Say you have never owned a hardware-adjacent roadmap. | A casual question about a scored gap. The plain acknowledgment is the only claim. |

**Reverse questions, Director of Engineering.** No interviewer profile exists, so no question ties to their own career path.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would the first ninety days need to show for the two squads, and what would you rather I not spend time on?" | Shows you plan around their priority, and the second half signals judgment. |
| R2 | "Which of the two squads' device-management services carries the most open risk going into the next two quarters?" | Shows you have read the scope and want the real risk, not the summary. |
| R3 | "How much of the roadmap is set by hardware dates, and who holds those dates?" | Puts the hardware dependency on the table before they raise it. |
| R4 | "What did the last engineering manager in this role do well, and what did they wish they had done earlier?" | Invites candour about the role, and signals you want to learn from it. |
| R5 | "If you were hiring for this role, which gap in my background would worry you most?" | Asks for the objection early, so you can rehearse the answer before Thursday. |

## Round 2: panel, two staff engineers and a product manager (Thursday, 60 min)

Persona weights, with the reasoning shown. The relationship prior for a panel is to blend the top two personas of each member. Your message gives no names, so the assignment is by role: staff engineers get Peer Evaluator and Data-Driven Prober; the product manager gets Case/Strategist and Conversational.

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (4) | The seam between your squads and their architecture work; disagreement; credit | High. The staff engineers are your peers, and they are pricing what you add to their work. | Propose seam principles rather than pretend to know the seam. Show spine and tact in a disagreement story. Offer reciprocity. |
| Data-Driven Prober (3) | Your 60% figure, the reliability quarter, the backend loop | Medium to high. Staff engineers test technical claims and their assumptions. | Name the weakest assumption first. Say what you do not know. |
| Case/Strategist (2) | The product manager's roadmap conflict with hardware | Medium. The product manager partners with you on roadmap, so the hardware change is the test. | Clarify, then structure. Say what you would need from hardware before you decide. |
| Conversational (2) | The opener, and payments-to-IoT transfer | Low to medium. Casual questions are scored. | A short, specific answer. Stay with what carries over and what does not. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where is the seam between your squads and the staff engineers' architecture work, and what happens when you disagree?" | JD | [generic] | Propose seam principles: who owns the interface, who decides on a disagreement, how it is escalated. Do not claim to know their architecture. | Peer pricing of what you add to their work. The seam is not in your material, so the guidance does not describe it. |
| B2 | "When an engineer on your squad and a staff engineer's design disagree, who decides, and how?" | JD | [generic] | State the decision rule before the disagreement: who decides, what evidence counts, and how the result is written down. | A disagreement with equals. The rule is a pattern, not a claim about you. |
| B3 | "How do you handle credit when a squad's work spans another team?" | EXP | [generic] | Pick a time you shared credit across teams, if one comes to mind. If none does, say so plainly, then state the rule you would apply. | A selection scaffold with its honest branch. No claim about your past is made. |
| B4 | "Where did you disagree with a peer engineering leader, and how did it end?" | EXP | [generic] | Pick a disagreement with a peer engineering leader, with a stake and a resolution. If none comes to mind, say so plainly, then say how you would handle one. | The Peer persona's disagreement probe. The honest branch is named. |
| B5 | "Which assumption behind the 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Name the assumption in your own words before they do. The figure is the quote's, so do not restate its method. | A defend-the-number question. The weakest-assumption move converts a gotcha into credibility. |
| B6 | "What did the reliability quarter push back on, and who decided that?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Name what was pushed back, in your words. Say who decided it. If you decided, say so; if someone else did, say whose call it was. | The quote states the roadmap pressure, and nothing more. |
| B7 | "Your loop is for backend roles. What would change for engineers who work close to devices?" | JD | [grounded] "Lead two squads building device-management services" and "I run our hiring loop for backend roles — about 40 interviews last year." | Say what you would keep from the backend loop and what you would test differently for device-adjacent roles. Frame it as a plan. | Hiring for the squads' domain. The device-adjacent part is a plan, not a past. |
| B8 | "Product wants a feature that needs a hardware change nobody has scoped. Run that conversation with me." | CASE | [grounded] "partner with hardware and product on roadmap" and "I've never owned a hardware-adjacent roadmap." | Structure the conversation: what is scoped, what is not, what you would ask hardware, what product must decide. If asked whether you have owned a hardware roadmap, say "I've never owned a hardware-adjacent roadmap," and give the plan. | The partnering requirement, rehearsed with the honest acknowledgment in the same answer. |
| B9 | "Which three roadmap decisions would you take to product in your first month?" | JD | [grounded] "Lead two squads building device-management services" | Name three decisions as a plan. Make no claim about past roadmap work. | A forward plan from the role's own words. |
| B10 | "What is the thing about payments engineering you would carry into an IoT setting, and what would you leave behind?" | EXP | [grounded] "currently at a payments company" | Name one thing that carries over and one that does not, in plain terms. Do not claim device work. | The transferability limit, stated as the honest scope of your current work. |
| B11 | "What is the part of this job you are most looking forward to?" | JD | [grounded] "Lead two squads building device-management services" | Twenty seconds on the part of the role you want most, in its own words. Do not claim anything about your past. | A casual question with a scored answer. |

**Reverse questions, the panel.** The staff engineers and the product manager each get one question. The first is reciprocity, because they are peers.

| # | Question | Why it lands |
|---|---|---|
| P1 | "What could a new engineering manager do in the first month that would genuinely help your team?" | The peer reciprocity question. It turns the panel into a working conversation. |
| P2 | "Where does the device-management architecture carry its biggest unresolved trade-off?" | Shows you read the system's risk, and invites them to name it. |
| P3 | "When hardware and product disagree on order, how does the roadmap get decided today?" | Puts the roadmap decision on the table, the place your gap sits. |
| P4 | "What does a good design review look like here, and what makes one go badly?" | Shows you care about how decisions get made, not only what gets decided. |
| P5 | "What is the one thing about this team that a new manager should know before the first sprint?" | Asks for the thing they would not put on a slide. |

## Round 3: VP Engineering, values and leadership philosophy (following Monday, 30 min)

Your message says the recruiter described this round as "values and leadership philosophy." That names a values round, so it is detected as one. No Larkfield values page was fetched (see Sources), so there is no values cheat sheet. The VAL questions below carry mapped stories where one of your quoted sentences carries one, and a selection scaffold with its honest branch where none does.

Persona weights, with the reasoning shown. The relationship prior for a values round is Values/Behavioral with Conversational. The VP is at a skip-level altitude, so Pressure and Case/Strategist are added.

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (4) | Scenario probes on leadership and truth-telling | High. The recruiter's own words name this round. | Selection scaffolds with honest branches. "I" for your contribution, "we" for the context. |
| Case/Strategist (3) | Altitude questions on strategy and the plan for two quarters | Medium. Skip-level, and no company strategy was researched, so these are generic. | Think aloud. Say what you would need to know before you decide. |
| Pressure (2) | "Why should I trust your leadership at this altitude?" | High to medium. Never managing managers is the first thing a VP at this level asks. | Hold for two follow-ups. Concede the specific gap. |
| Conversational (2) | The opener, and what you enjoy about leading people | Low to medium. The opener is scored casually. | A specific 90-second arc from quotes. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Story-mapped on the quote: the reliability quarter, the roadmap pressure, and you pushing it through. Answer slot: if the pressure came from leadership, say what you said to them and how it landed; if it came from elsewhere, say so and tell the nearest version. | F2 is the only story your material carries for this. The truth-to-leadership part is an answer slot, not a claim. |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] and the quote "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Pick a time with a named stake, a moment you did not fold, and an intact relationship at the end. If none comes to mind, say so plainly, then give the nearest thing your material carries: the reliability quarter, which was about team health rather than a customer. Do not call it a customer story. | No quote carries a customer story, so this is a selection scaffold. The nearest thing is named as such. |
| C3 | "How did you decide when reliability work beats the roadmap?" | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Say the rule you used in that quarter, in your own words. If you had no rule, say so, and do not generalise beyond the quarter. | An open leadership-philosophy question tied to the one story you have. It asks for your rule, not a claim. |
| C4 | "What is a leadership belief you have changed your mind on?" | VAL | [generic] | Pick one belief with a before and an after you can name. If none comes to mind, say so plainly, then name the nearest belief you have held and tested. | A selection scaffold. No quote carries it, so no story is supplied. |
| C5 | "Where do you think device management goes in the next two years, and what does that mean for how you would organise two squads?" | CO | [generic] | Think aloud from the role's own words, not from any company strategy. Say what you would need to know about the company's direction before you commit to a structure. | No strategy was researched, so this is generic. Say so if asked. |
| C6 | "Two squads, one hardware dependency, and a leadership team that wants both faster and safer. How do you set the next two quarters?" | CASE | [generic] | Clarify what is fixed. Name the trade-off between speed and safety. Set the plan in stages, with the hardware dependency first. | A live problem from the role. No claim about your past. |
| C7 | "What would you need from me and the Director to succeed in six months?" | JD | [grounded] "Lead two squads building device-management services" | Name two or three things you would need from the VP and the Director, in terms of decisions and access. Make no claim about past support. | A reciprocity question. It shows you plan for the role's scope. |
| C8 | "You have led six people for three years and never managed managers. Why should I trust your leadership philosophy at this altitude?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6" and "I've never managed managers and never owned a hardware-adjacent roadmap." | Hold on the quote: three years leading six. Concede the gap in your own words: "I haven't managed managers." Then give the plan to learn it. Hold through two follow-ups. Do not fold on the three years. | The pressure question at VP altitude. The concession is named before it is asked for. |
| C9 | "That 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold on "I pushed it through," which is what the sentence carries. Concede the team's share honestly. Do not claim the whole drop. | A pressure question about attribution. The honest answer is the quote, plus the concession. |
| C10 | "So what made you move from building things to leading people?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6" | Open prompt. Pick the moment you took on leading six, if one comes to mind; if none does, say so plainly, then give the nearest thing: three years as a team lead of six. | A casual opener, scored. The quote holds the only story. |
| C11 | "What did you enjoy most about leading six people?" | EXP | [grounded] "3 as a team lead of 6" | Answer in your own words. If the honest answer is not enjoyment, say what it was. | A conversational question the VP may still score. The quote holds the only fact. |

**Reverse questions, VP Engineering.** No interviewer profile exists, so none ties to their path.

| # | Question | Why it lands |
|---|---|---|
| V1 | "How does Larkfield tell a strong engineering manager from a good one at this level?" | Shows you want the bar in their terms. |
| V2 | "When leadership and the roadmap pull against reliability, what has the VP usually done?" | Asks for their judgment on the exact tension in your one story. |
| V3 | "What principle would you want the new manager to hold that is not written on the values page?" | Signals you know a values page is not the whole answer. |
| V4 | "Which of the company's stated principles has been hardest to live up to?" | Invites candour, and tells you what they will test. |
| V5 | "What would make you say in six months that this hire was a mistake?" | Asks for the bar directly, and gives them room to be specific. |

## Target accounting

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The values cheat sheet, section 10. The VP round is values-style by your recruiter's words, so the cheat sheet would have mapped Larkfield's published values. It was not built because no values page is in hand. |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Loop structure. Your message already names the three rounds and who runs each, so the loop is set by your words, not by this target. |
| 3. `Larkfield Systems industrial IoT strategy news` | unavailable | The CO question C5 and the Case/Strategist weights in round 3. C5 is generic as a result. |
| 4. `{interviewer name} {company}` | n/a | No interviewer name was given, so there was no query to form. The interviewer read is absent. |
| 5. representative `{role title}` JD | skipped | Your role text fixes the requirement rows and the JD-tagged questions. |

## Sources

- **Provided documents:** your message. It gives the role text, the three rounds and who runs each, your background, and the recruiter's wording "values and leadership philosophy."
- **Searches sent, all refused, so none returned a result:** `Larkfield Systems values`; `Larkfield Systems interview process engineering manager`; `Larkfield Systems industrial IoT strategy news`.
- **Fetches sent:** none.
- **Pack basis:** the pack runs on your material alone. Nothing about Larkfield's values, loop or strategy is established beyond what your message says.

## Upgrade menu

- Larkfield's published values page, pasted, or the recruiter's email naming them → the values cheat sheet for the VP round, and C1 to C4 gain mapped stories wherever your quoted sentences carry one.
- The recruiter's note on any take-home, presentation or panel format → a graded-deliverable section if one is named.
- The full job description text → the requirement rows quote the posting itself, and any requirement your summary dropped is added.
- The interviewer names (Director, the two staff engineers and the product manager, the VP) → an interviewer read, persona weights per member, and a reverse question tied to each person's path.
- An inspectable artifact: the source data behind the 60% figure, or the plan for the reliability quarter → the 60% and 40-interview rows move from medium toward high, and the artifact is the proof a Prober will ask for.
- Permission to run web search → the three refused targets (values, loop, strategy) run at the next pass.
- A tuesday-dossier.md, if you have one → its verified evidence and prohibited claims would bind these rows in place of the local list.
