# Kelverton Rail: Senior Partnerships Manager, second-round panel

Panel, Tuesday 24 November 2026, 60 minutes. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: a short spoken point of view on operator partnerships over the next 18 months, no slides, landing on what it means for the operators. Remaining time: Q&A, with Ross pushing on commercials.

Built on your message and the recruiter's email as you quoted it. I have not seen the internal market report, and no web research ran (see Sources).

## 2. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** values/behaviour · **EXP** your past work, tested · **JD** the role's requirements · **CO** company and strategy knowledge · **CASE** a live problem.
- Guidance is scaffolding, not a script. Say it in your own words, and only what you did.
- **Answer slot** (rows marked "Answer slot"): the question may ask about something your material does not show. Answer from your own experience, or say plainly that it was not yours. Both are valid answers.

## 3. Prep triage (about 4 hours)

1. **About 75 min: the POV.** Build the three theses in section 5 and the close. Time yourself out loud to 15 minutes. Do it twice.
2. **About 60 min: Ross.** Rehearse C1, C2 and D1 until the hold-then-concede order is automatic. Ross is the harder interview.
3. **About 45 min: Deepa.** Rehearse A1, A2 and B1.
4. **About 30 min: reverse questions.** Choose five from section 11 and make them sound like your own.
5. **About 30 min: the market report.** Check each thesis's concession against the report. Note where the report contradicts a thesis and change the thesis, not the report.
6. **About 30 min: full run.** Open with the POV, then take Q&A with a timer running.

Everything else is insurance.

## 4. Fit snapshot

Each evidence cell quotes your words exactly, or is `none given`. The requirement column quotes the recruiter's email, or is marked `[generic]` where no source exists. No job description was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter email) | "Never sold into rail specifically" (your message); "I know the operator world from the other side" (your message) | low | [grounded] | capability | You stated the absence, so the plain form is: "I haven't sold into rail specifically." Then your own scope: "I know the operator world from the other side." Do not describe rail buyers, rail deals or operator relationships you did not have. |
| F2 | "Ross will push on commercials." (recruiter email) | "never carried a direct quota, only influenced revenue" (your message); "roughly £4M of influenced revenue" (your message) | medium | [grounded] | capability | You stated the absence, so the plain form is: "I haven't carried a direct quota. My number was influenced revenue, roughly £4M." Influenced and booked revenue are different, and Ross will test that. Do not call the £4M yours. |
| F3 | `[generic]` role-family: build and scale a partner channel | "took it from 6 partners to 40" (your message); "Last 4 years at a payments company running the ISV channel" (your message) | medium | [grounded] | transferability | At its own scope: "I ran the ISV channel at a payments company, and took it from 6 partners to 40." Answer slot: which parts of that build would carry to train operators, and which would not? Say it from what you know, not from what the operators might want. |
| F4 | "Please land on what it means for the operators themselves." (recruiter email) | `none given` | none | [grounded] | discovery | Answer slot: if you can name a planning decision an operator made in your consulting work, say what it depended on. If you cannot, say you are building the operator view from the market report and your transport background. |

Gap types, one line each: F1 and F2 are stated absences, so their words are the plain acknowledgment only. F3 is adjacent work at its own scope. F4 is an answer slot.

## 5. Graded deliverable: the 15-minute point of view

Declared by the recruiter: "present a short POV on where you'd take our operator partnerships over the next 18 months". The grounded facts you build on: F1 ("I know the operator world from the other side") and F3 ("took it from 6 partners to 40").

**Three theses, each with a concession:**

- **T1. Organise operator partnerships around an outcome the operator already measures**, such as timetable change delivery or planning turnaround, rather than around the number of partners. *Concession:* this only works if operators' contracts reward those outcomes. I have not checked that. The market report may already show which metrics operators track, so check it before you say this.
- **T2. Use partners already inside operator planning workflows**, such as consultancies and integrators, as the main route, with direct sales as the second route. *Concession:* this gives up margin and control. *Anti-pick:* do not say "grow the channel to N partners". That is the consensus answer. Your 6-to-40 story maps onto it, so say that it is not enough for operators, and why.
- **T3. Prove value to the operator's own planners in a short pilot** with agreed operator metrics, before anyone is asked to commit to a contract. *Concession:* the pilot costs Kelverton time and margin, and Ross will press on that. Have a number ready for it, or say you do not have one yet.

**The close (what it means for the operators):** the operator gets fewer timetable changes that fail, and clearer accountability when one does. *[generic]*: this is a hypothesis about operators, not a fact from the report. Check it against the report before you say it.

## 7. Reading the interviewer

Public footprint was not checked (research refused), so this section uses the role titles only.

- **Deepa (VP Partnerships):** your future manager. Expect her to test the POV against her roadmap and your gap in rail.
- **Ross (Commercial Director):** the commercial pressure. Expect him to test the £4M and the quota.
- Neither name's public record has been checked. If you want that, see the upgrade menu.

## 8. Persona table

Panel: blend the top two personas for each member.

| Interviewer | Persona | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Deepa | Case/Strategist | high | A hiring-manager prior: she is buying capability and will test a live plan on her own roadmap | Clarify, then structure, then answer. Use the POV's theses as the plan. |
| Deepa | Skeptic | medium | The rail gap (F1) is the obvious place for a derisking question | Rehearse B1 until it is plain. Say the stated absence, then your own scope. |
| Ross | Pressure / Stress | high | "Ross will push on commercials" is the recruiter's own warning | Pause, restate the question, hold a position through two follow-ups, then concede only what is real. |
| Ross | Data-Driven Prober | high | A commercial director will test how a number was counted | Name the weakest assumption before he does. Say plainly when you do not know how a figure was counted. |

## 9. Question banks

Ordered by weight. Provenance first: each bank row lists the candidate sentences its guidance rests on, quoted exactly as in section 4.

### Deepa (Case/Strategist, then Skeptic)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What is the one operator outcome you would put ahead of any revenue number?" | CASE | [generic] | Structure it: clarify the outcome, then the operator's view of it, then the approach, then the metric, then the risk. This question makes no claim about your past, so the guidance makes none. | The POV's first thesis (T1) answers this directly. CASE because it is a live problem. |
| A2 | "How would you know in month six that a new operator partnership is working for the operator?" | CASE | [generic] | Give the operator's test first, then how you would measure it. Name one thing you would not yet know. | Tests whether the POV has a measure behind it. [generic] because it is a pattern for the problem, not a fact about this employer. |
| B1 | "Which part of this would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" (your message); [grounded] "I know the operator world from the other side" (your message) | Say it plainly: "I haven't sold into rail specifically." Then your scope: "I know the operator world from the other side." Then a 90-day plan to learn how rail buyers decide, in future tense. | F1. The likeliest Skeptic probe, and the one to rehearse until it is boring. |

### Ross (Pressure/Stress, then Data-Driven Prober)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why should we believe a partnerships person can carry a commercial number?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" (your message); [grounded] "roughly £4M of influenced revenue" (your message) | Hold: "I haven't carried a direct quota. My number was influenced revenue, roughly £4M." Return to that number through two follow-ups. Concede only what is real: influenced revenue is not booked revenue, and your attribution would need proving. | F2. Pressure answer: hold, then concede the real limit. |
| C2 | "That number: how much of it was actually yours?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Say what you did, in your own words. Answer slot: which decisions were yours, and which were shared with the payments company's sales team? If you do not know the split, say so. | F2 and F3. The honest branch is a limit, not a confession. |
| D1 | "How was that influenced revenue counted, and what share would you defend?" | EXP | [grounded] "took it from 6 partners to 40" (your message); [grounded] "roughly £4M of influenced revenue" (your message) | Prober answer: name the attribution rule you know, and the weakest assumption in it. If you do not know how it was counted, say that plainly, then name the assumption you would test first. | F2. The Prober's question on the same number C1 and C2 hold. |

## 11. Reverse questions

Each one has a "why it lands". None asks the interviewer to check anything about the invitation, if there were one.

1. **To Deepa:** "What would you want the first operator partnership I run to have proven within six months?" *Why it lands:* it turns F1 into a shared plan, and tells you what she is scoring.
2. **To Deepa:** "Where does a partnerships hire most often get it wrong in the first quarter here?" *Why it lands:* shows you are planning for the job, not interviewing for it.
3. **To Ross:** "How is partner-sourced revenue credited today, between partners and Kelverton's own sales team?" *Why it lands:* it tests F2 directly and shows you know the attribution question is real.
4. **To Ross:** "What is the one commercial question you want answered by month six?" *Why it lands:* it gives you Ross's measure, and it is the question his pressure is for.
5. **To either:** "Which operators do you most want to deepen partnerships with, and what do they already buy from you?" *Why it lands:* it shows you have thought about the POV's operator focus, without claiming a fact you do not have.

## 13. Prohibited claims

Built from the fit snapshot. None of the following is coached, and no guidance cell may assert it, soften it or imply it.

| Not coached | Basis | Honest form |
|---|---|---|
| Sold into rail or to train operators | F1 stated absence | "I haven't sold into rail specifically." |
| Carried a direct quota or a booked revenue number | F2 stated absence | "I haven't carried a direct quota. My number was influenced revenue." |
| Owned the £4M | "influenced" in your own words | "roughly £4M of influenced revenue", at its own scope |
| Worked with operators as clients in consulting | Not in your material | "I know the operator world from the other side." |
| Knowledge of Kelverton's products, or of what the market report says | Not in your material; I have not seen the report | Say what you have read, and nothing more. |

## 14. Sources

- **Provided, used:** your message (background, the panel, and the POV brief). The recruiter's email, as you quoted it in your message.
- **Provided, not seen:** the internal market report. You have read it; I have not. The theses in section 5 need checking against it.
- **Research:** three standard searches were attempted (Kelverton Rail scheduling software; Kelverton Rail company values; Great British Railways and TOC reform). All were refused by the host, and none returned results. No fetch was attempted.

**Research tier:** L1 requested by default; 0 of 6 searches ran (3 refused), 0 of 2 fetches. Effectively L0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton values | unavailable | Would have moved section 10 (values cheat sheet). Refused. |
| 2. Kelverton interview process | unavailable | Would have moved loop structure and persona weights. Not searched. |
| 3. Kelverton strategy / recent news | unavailable | Would have moved the operator-context half of the POV. Refused. |
| 4. Deepa and Ross, public footprint | unavailable | Would have moved the interviewer read (section 7) and the reverse questions. Not searched. |
| 5. Representative JD for the role | unavailable | Would have moved the JD rows of the fit snapshot. Not searched. |

## 15. Upgrade menu

- **The job description** → F1 to F4 gain a requirement source, and the JD-tagged questions become grounded rather than inferred.
- **The market report, or the sections you think matter** → the three theses get checked against it, and the concessions get firmer.
- **Public footprint on Deepa and Ross** (their names and any public profile you are happy to share) → persona weights and a tailored reverse question.
- **Permission to run web research** → the values, the process and the recent-news targets in section 14 become runnable.
- **`tuesday-dossier.md`** → if you carry it into later sessions, the gaps this prep exposed travel with it.
