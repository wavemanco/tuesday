# Live Operations Producer, Saltmarsh Games: interview prep for Femi

- **Company and role:** Saltmarsh Games (mobile, about 350 people), Live Operations Producer
- **Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship: hiring manager. The careers page says the Outage Hour is run "with the hiring manager", and I have assumed that is him. Confirm this (upgrade menu).
- **Round:** one 60-minute Outage Hour: a live-incident tabletop on a simulated outage during a live event, then a values conversation (careers page)
- **Version:** first version

## How to use

Personas describe how a question arrives. Types describe what is being scored: **VAL** values, **EXP** your experience, **JD** the listed job, **CO** company knowledge, **CASE** a live problem. Guidance is scaffolding, not a script. Answer slots are instructions for the interview: answer from your own experience in your own words, and either honest branch is a good answer.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "Ran the weekly content-drop calendar for the main title for the last two years" (your message) | medium | [grounded] | transferability | Your material describes a content-drop calendar for one title, not a live-events calendar across two. Say: for two years I ran the weekly content-drop calendar for the main title. Answer slot: the JD asks about two titles at once. If you have ever planned two titles' dates together, say how. If not, say so and say how you would sequence two. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordinating those four teams. Answer slot: if you coordinated any of design, art, engineering or community on a content update, say which and how. If none, say so and describe how you would run one update across all four. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | KPI reporting is adjacent. Your material shows no post-event review. Say: I presented the monthly retention numbers to the studio head. Answer slot: if you have reviewed what an event or drop achieved, say what you reviewed. If not, say so and say what you would review first. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | This reaches the requirement in role terms. Lead with the quote's own words: you wrote it, and QA still uses it. "Wrote" does not say you ran each release through it, so do not promote the verb. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Years match. Your material does not say whether that title was live-service. Say: for four years I was an associate producer at a puzzle-game studio. Answer slot: if the title kept running after launch, say how, in your own words. If it did not, say so. This is a length-of-experience line, so it is not a gate. |
| F6 | "experience running a content calendar" (JD) | "Ran the weekly content-drop calendar for the main title for the last two years" (your message) | medium | [grounded] | none | This reaches the requirement directly. Keep the limit visible: one title, two years. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: presenting is not owning. Reword only: I presented the monthly retention numbers to the studio head. Add no method and no figure. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | discovery | The checklist is written and used, but the material does not show clarity. Say: the checklist is a written document others use, and that is the example I can point to. Answer slot: if you have a writing sample you can name, say what it is. |

Notes on the snapshot:

- The JD names no location, schedule, pay or credential term, so there is no gate row.
- Two gaps you raised are not JD lines and so have no row: "Never led a team" and "Never worked on a game with in-app purchases." The Skeptic bank rehearses both.
- Live-incident experience is not in your material. The Outage Hour is built around one, so the CASE bank covers it without claiming any.

## Prohibited claims

Each entry names its basis. The honest form is the quoted sentence at its own scope.

| Not coached | Basis | Honest form |
|---|---|---|
| Owns the live-events calendar for two titles | Inflated form of F1 | "Ran the weekly content-drop calendar for the main title for the last two years." The limit is the pack's observation: your material says one title's content-drop calendar, not a two-title live-events calendar. |
| Owns the post-event review and its KPIs | Inflated form of F3 | "Presented the monthly retention numbers to the studio head." |
| Manages QA release sign-off | Inflated form of F4 | "Wrote the release checklist our QA team still uses." |
| Owns retention metrics | Inflated form of F7 | "Presented the monthly retention numbers to the studio head." |
| Live-service producer | Inflated form of F5 | "4 years as an associate producer at a puzzle-game studio." The material does not show that title was live-service. |
| Has led a team | Negative you stated | Plain acknowledgment: "I haven't led a team." No slot. |
| Has worked on a game with in-app purchases | Negative you stated | Plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot. |

## Reading the interviewer

- **Career pattern (public footprint):** previously a QA lead at a console studio, now Head of Live Operations at Saltmarsh (GDC 2026 talk listing, search snippet).
- **Self-described argument:** the talk "Patch Notes Are a Promise" argues that a live team is judged by how often its patch notes describe what actually shipped.
- **Implications:**
  1. The release checklist is a QA-facing artifact in his own territory. Lead with it, in the quote's terms.
  2. Truthful release communication is his stated test. Attribution precision scores with him.
  3. Do not claim a player-facing decision you cannot show. He will ask what shipped.
- **Mirror opportunity:** no shared career jump. The shared object is the QA-facing checklist, which is a professional overlap, not a similar path.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The Outage Hour tabletop: a live incident during a live event, scored on structure | Top weight, 4. The loop source names the tabletop as half of the hour, and the JD's live-events role makes it the likeliest format. | Clarify, then objective, then owners and comms, then the decision. Think aloud. Name one premise you challenge. |
| Values / Behavioral | The values conversation, against the three published values | Equal top weight, 4. The loop source names it, and it is the other half of the hour. | One story per value where a quoted sentence carries one. Where none does, a selection scaffold ending in its honest branch. |
| Skeptic | Probes the leadership gap and the in-app-purchase gap, and whether coordination without authority is real | 3. The hiring manager is buying derisking, and your two stated gaps are the obvious probes. | Rehearse the objection until it is plain. Bridge only from quotes. Say the limit plainly rather than bluff. |
| Data-Driven Prober | Asks how the retention figure was counted and what you calculated versus received | 3. You presented numbers, and a prober checks attribution. | Say which numbers you calculated and which you received. Name the weakest assumption you know. |
| Pressure | Time-boxed challenge on your senior-leadership or live-service claims | 2. A panel of one with a fixed clock; pressure is less likely than the tabletop. | Hold the position through two follow-ups. Concede the specific limit, never the core claim. |

## Question banks

### Persona A: Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event on one of the two titles is failing, and a patch is ready. Walk me through the first thirty minutes." | CASE | [generic] | Clarify what is failing and for how many players. Name the decision (patch, hold, roll back), its owners, and what you tell players and the community team. Keep it to a structure and a decision. | The loop source names a live-incident tabletop, and the JD's live-events role makes this the central format. No claim about your past. |
| A2 | "Retention drops sharply in week two of an event. What do you check before you say why?" | CASE | [generic] | Check the definition first: which cohort, which date range, whether the drop is real or a counting change. Name the assumption you would test first. | Metric-first diagnosis is what the tabletop scores. The JD's retention requirement (F7) gives the frame. |
| A3 | "How would you plan one calendar across two titles that share a team?" | JD | [grounded] "Ran the weekly content-drop calendar for the main title for the last two years" (your message); [grounded] Project Larkspur (Saltmarsh news, search snippet): the company is moving two titles to one shared events calendar from February 2027 | Separate what stays per-title from what merges. Name the constraint you would hold fixed. Say what you would need to know first. Your own answer rests only on F1: you ran one title's calendar, and any two-title plan is a plan, not a record. | Raised by the JD's two-title line and the announced Larkspur calendar (F1 for your side). Asks for a plan, so it presupposes no past two-title work. |
| A4 | "A patch you shipped breaks a feature during a live event. What do you say to players, and in what order?" | CASE | [generic] | Order: stop the bleeding, tell players what is known and not known, commit to a next update time you can keep. Name who signs the message. Make no claim about a past incident. | Live-incident handling is not in your material. Covering it as a plan avoids inventing an incident. |

### Persona B: Values / Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "Ran the weekly content-drop calendar for the main title for the last two years" (your message) | Selection scaffold: pick a time when what players needed cut against a dated plan, and say what you did. If none comes to mind, say so plainly, then give the nearest thing your material carries: the content-drop calendar you ran, and how you would handle the same conflict now. | Maps to "Players Before Plans". The quote carries the calendar but not a player-over-plan decision, so the story is a scaffold, not a mapped story. |
| B2 | "Tell me about a time you had to tell people something about a release that turned out differently." | VAL | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Selection scaffold: pick a release where what was announced and what shipped diverged. If none, say so, then the checklist: what it checks before anything is announced. Do not claim the checklist caught a specific failure unless you can say so. | Maps to "Ship the Patch Not the Promise". The checklist is the nearest artifact. |
| B3 | "What have you left better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Beats the quote carries: you wrote the checklist, and QA still uses it. Answer slot: if you revised it after a release went wrong, say what changed. If it was not revised, say so. | Maps to "Leave the Build Greener". Durable use is the only evidence you have for it. |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Selection scaffold: if the monthly numbers showed something the studio head did not want, say what they showed and what you said. If not, say so plainly and describe the nearest case. Hold the factual content; concede only what you cannot show. | Persona stem for the values round. The quote supports presenting numbers, not an unwelcome result, so the story is a scaffold. |

### Persona C: Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never led a team. How would you coordinate design, art, engineering and community on one update, when none of them report to you?" | JD | [grounded] "Never led a team" (your message) | **The deepest rehearsal in this pack.** Say the plain acknowledgment: "I haven't led a team." Then describe the coordination you would run: one owner per update, a shared checklist, decision rights agreed before the work starts. Hold the position that leading and coordinating differ, through two follow-ups. Concede the specific limit: you have not run four disciplines through a shared update. Answer slot: if you have coordinated any of the four on an update, say how. | The most likely objection to you: it targets the JD's coordination line (F2), where your material is silent, and the gap you named yourself. Highest-ROI prep. |
| C2 | "You've run one title's calendar. How would you run two?" | JD | [grounded] "Ran the weekly content-drop calendar for the main title for the last two years" (your message) | Say what you ran: the weekly content-drop calendar for one title, for two years. Then how you would sequence two calendars. Answer slot: if you have ever planned two titles' dates together, say how. If not, say so. | The premise is your own sentence. The probe is F1's transferability gap. |
| C3 | "I don't see in-app purchases in your background. How would you handle them in this role?" | JD | [grounded] "Never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then what you would ask first: which offers the monetisation side owns, and what the retention plan must not break. Make no claim about past monetisation work. | A probe on your own stated gap. The acknowledgment needs no further source. |
| C4 | "Design and engineering disagree on an update's date, and it's your call. What do you do?" | CASE | [generic] | Clarify what each side is protecting: player impact, scope, risk. Name the decision rule and who makes the call. Say what you would write down afterward. | The JD's coordination line, as a live decision. No claim about your past. |

### Persona D: Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You presented monthly retention numbers to the studio head. Which of those did you calculate, and which did you receive?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Say which numbers you calculated and which came from elsewhere, in your own words. If you calculated none, say so: I presented them. | F7 is a presentation gap. A prober checks attribution first. |
| D2 | "If someone challenged that monthly figure, which part of its definition would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Name the weakest assumption you know, in your own words. Answer slot: if you did not define the figure, say so, and name what you would check first. | Weakest-assumption move. No figure was given, so the slot is open. |
| D3 | "The role owns the post-event review and its KPIs. What have you reviewed, and what did it change?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Answer slot: if you have reviewed what an event or drop achieved, say what you reviewed and what changed. If you have never run a post-event review, say so plainly, and describe the KPIs you would review first. | The JD's post-event line (F3). The premise, that you have run reviews, is not in your material, so the second branch is part of the answer. |
| D4 | "How would you separate retention moved by a content drop from retention moved by season timing?" | CASE | [generic] | Name the comparison you would use: a holdout, or matched prior periods. Say what each would miss. | A metric-design probe. No claim about your past. |

### Persona E: Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run a live-service title?" | JD | [grounded] "Ran the weekly content-drop calendar for the main title for the last two years" (your message); [grounded] "Wrote the release checklist our QA team still uses" (your message) | Hold: you ran a content calendar for two years, and you wrote a checklist still in use. Concede the specific limit: "I haven't worked on a live-service title with purchases, and your material does not show the puzzle title was live-service." Do not concede the calendar or the checklist. | The JD's 3+ years live-service line. The concession is the honest limit, and the hold is the quotes. |
| E2 | "That checklist: how much of its current form is actually yours?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Hold the fact you wrote it. Concede what you cannot show: QA maintains it, and you cannot say how much of its current form is yours. | Pressure on F4. The second follow-up is where a stretched claim breaks. |

## Coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A1, A3, C2 |
| Coordinate design, art, engineering and community teams on each update | C1, C4, A1 |
| Own the post-event review and the KPIs it reports | D3, D1 |
| Manage the release checklist with QA | B2, E2 |
| 3+ years producing live-service games or apps | E1 |
| Experience running a content calendar | B1, B3 |
| Comfortable with player-retention metrics | A2, D2, D4 |
| Clear written communication | none, and why: no question covers it. A writing sample would add one (upgrade menu). |

## Values cheat sheet

Values round detected: the careers page names a values conversation in the Outage Hour.

| Value (official name) | Working meaning (paraphrase) | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | F1 quote: "Ran the weekly content-drop calendar for the main title for the last two years." No player-over-plan decision in your material. Selection scaffold: B1. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | F4 quote: "Wrote the release checklist our QA team still uses." The checklist's role in what gets announced is not in your material. Selection scaffold: B2. |
| Leave the Build Greener | Every release leaves the codebase and checklist better than it found them. | F4 quote, the durable-use beat only. Revision after failures is not in your material. Selection scaffold: B3. |

## Reverse questions

1. "Under Project Larkspur, how do the two titles' calendars stay distinct in the first season?" Why it lands: you read the announcement, and you ask about the thing he is building.
2. "The Outage Hour is a tabletop on a live event. Which incident has the team learned most from this year?" Why it lands: it asks about his team's own practice, not a generic one.
3. "Your talk argues patch notes are a promise. Where do they most often drift from what shipped?" Why it lands: it engages his public argument. Name the talk you are referring to.
4. "You went from QA lead to Head of Live Operations. What did you carry across?" Why it lands: it ties to his own path. It is a question about him, not a claim.
5. "Where does the release checklist sit under the single live-ops group?" Why it lands: it names the artifact you wrote and asks who will own it next.
6. "What would success look like for this hire at six months, and how would you measure it?" Why it lands: it asks for the scoring he is using.

## Sources

Provided documents: your message (background, JD). No link was given.

Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet: three values by name, from the fetched values page |
| 2. Saltmarsh Games interview process, live operations producer | yes | Loop structure: recruiter call, then one 60-minute Outage Hour with the hiring manager; values-style round detected. Fetched careers page |
| 3. Saltmarsh Games strategy / recent news | yes | Project Larkspur (September 2026): two titles on one shared events calendar from February 2027, per-title event teams retired. Read from the search snippet; the article was not fetched |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Public footprint: GDC 2026 talk and prior QA-lead role, from the search snippet |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Queries and results:

- "Saltmarsh Games values": saltmarshgames.com/values (fetched)
- "Saltmarsh Games interview process live operations producer": saltmarshgames.com/careers/interviewing (fetched)
- "Saltmarsh Games strategy news mobile games": saltmarshgames.com/news/project-larkspur (snippet only)
- "Tobias Wrenfield Saltmarsh Games": talks.gdconf.example/2026/patch-notes-are-a-promise (snippet only)

## Upgrade menu

- Your own sentence about a post-event review, or a KPI you reported and what it changed → upgrades F3 and D3 from answer slots to stated beats
- A sentence on whether the puzzle title was live-service → upgrades F5 and E1
- A writing sample you can name → upgrades F8 from discovery to medium confidence
- The Larkspur article, read in full → confirms A3 and reverse question 1, which currently rest on the search snippet
- Whether Tobias is the hiring manager for this role, and whether the Outage Hour is the whole interview → confirms the persona weights in this pack
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) would add his talks and writing, the strategy brief, role-family loop reports and recent org changes → sharper reverse questions and CO questions
- A `tuesday-dossier.md` from job-underwriter would add verified evidence and a map of which of your claims survive scrutiny → firmer grades on F1 to F8
