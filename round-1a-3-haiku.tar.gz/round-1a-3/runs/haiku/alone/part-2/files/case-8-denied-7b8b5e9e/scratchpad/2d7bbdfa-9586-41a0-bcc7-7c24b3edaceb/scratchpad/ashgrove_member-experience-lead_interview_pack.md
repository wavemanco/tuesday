# Ashgrove Credit Union: Member Experience Lead, interview pack

**Role:** Member Experience Lead. **Company:** Ashgrove Credit Union (member-owned, about 900 staff).
**Rounds:** 29 November 2026. (1) Recruiter, 30 min. (2) Head of Member Services, 45 min, mostly behavioural. (3) Panel of two branch managers, 60 min, including a 20-minute complaint-escalation case; the panel scores against the four values.
**Interviewers:** the Head of Member Services is your manager. The two branch managers are not named yet, so there is no interviewer read.

## 2. How to use, and the type key

Personas describe how a question arrives. Types describe what is being scored.

- **VAL:** values fit, tested through your past behaviour.
- **EXP:** what you actually did, and how far your material carries it.
- **JD:** the listed requirements of this job.
- **CO:** company and strategy knowledge.
- **CASE:** a live problem from the role.

The guidance is scaffolding, not a script. Speak each answer in 90 to 120 seconds, in your own words. An **answer slot** asks you to answer from your own experience, and if a thing was not yours, to say so plainly.

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | No gap. Say the years and the role in those words. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | presentation | "I handled the branch's formal complaints log." Your material says "formal", not which rules applied. That is for B8, not for this bridge. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Adjacent work: one branch's complaints. "For my branch, I handled the formal complaints log." Your material does not show end-to-end ownership. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | The quote reaches monthly complaints reporting in other terms. Volumes and resolution times are not named, so say only what the sheet holds. Answer slot: see B3. |
| F5 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Adjacent work: training tellers, not coaching supervisors. "I trained new tellers on our escalation script." |
| F6 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent on digital or self-service work. Answer slot: see B6. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | "I haven't presented to anyone above regional level." Plan how you would learn it, as a plan, never as a past. |
| F8 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | Your material says spreadsheet, not Excel, and names no functions or tools. Say only what you built. |
| F9 | "across branches and the contact centre" (JD) | "Never worked in a contact centre." (your message) | none | [grounded] | capability | "I haven't worked in a contact centre." Plan the learning, as a plan. |

**Gap type routing:** F1 has evidence that reaches its requirement, so it is `none`. F2, F4 and F8 have quotes that reach their requirements in other terms, so they are `presentation`. F3 and F5 have adjacent work that does not reach the requirement, so they are `transferability`. F6 is silent, so it is `discovery`. F7 and F9 are absences you stated, so they are `capability`.

**Limit, as the pack's own observation:** your material shows one branch's complaints work, a spreadsheet, training of tellers, and no contact centre, no supervisor coaching, no digital work and no presenting above regional level.

## 6. Grounding brief (from the strategy brief you pasted, July 2026)

- **Current priorities:** move 40% of member service to digital channels by 2028. Consolidate eight branches into five hubs over 2027. Launch a small-business lending product in Q1 2027.
- **Competitive pressure:** app-only banks.
- **Vocabulary to use:** "member service", "digital channels", "hubs", "self-service journeys", "the member's side of the counter".
- **Stale-framing check:** the brief is dated July 2026 and the values were copied on 20 November 2026. Use them as current. Do not correct the interviewers on them.

## 8. Persona table

| Round | Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| 1 Recruiter | Conversational / rapport | Warm opener, then logistics checks | High. Recruiter-screen prior. Pay, notice, location and reason for leaving are scored, in a friendly register | Pre-script a two-minute background. Give each logistics answer in your own words |
| 1 Recruiter | Skeptic (light) | "You've never worked in a contact centre" | Medium. The JD names the contact centre and your material shows none | Plain acknowledgment, then the bridge |
| 2 Head of Member Services | Skeptic | "Your case, given the scope?" | High. The hiring manager buys capability and checks gaps. The recruiter says mostly behavioural | Rehearse B1 until it is plain |
| 2 Head of Member Services | Case / strategist | The digital-shift question | High. The strategy is in the brief the recruiter sent | Clarify, then structure. Answer from principles, not experience |
| 2 Head of Member Services | Data-driven prober | "How was that spreadsheet counted?" | Medium. The spreadsheet is your one reporting quote | Say what you know and what you don't. Name the assumption you would defend least, only if you know it |
| 3 Panel | Values / behavioural | Values-scored stories | Highest. The panel scores against all four values | Story or honest branch for each value (section 10) |
| 3 Panel | Case | The 20-minute escalation | Highest. Stated in the recruiter's email | Clarify, then the member's outcome, then decisions |
| 3 Panel | Pressure, with a peer seam | "One branch's log, why should we trust you with the network?" | Medium. Two branch managers may test scope, and may be your future peers | Hold the position through two follow-ups, then concede only the scope |

Weighting: relationship priors set the start. The round and the loop were stated by the recruiter, so no adjustment comes from interviewer profiles.

## 9. Question banks

### Round 1: Recruiter screen (weights: conversational 4, light skeptic 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background in about two minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message); "I handled the branch's formal complaints log" (your message) | The beats the quotes state: six years in retail banking, the last three as a branch supervisor, and the branch's formal complaints log. Stop there. Tell it in your own words. | Opener. Built entirely from F1 and F2. |
| A2 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period in your own words. Don't round it. | Recruiter logistics check. Makes no claim about your past. |
| A3 | "Where would you need to be based for this role?" | JD | [grounded] "eight branches into five hubs over 2027" (strategy brief from the recruiter) | Logistics slot: give your own answer. If you don't know whether the base is a branch, a hub or the contact centre, say so and ask where it is. | The brief makes a hub base plausible. The JD does not state a location. |
| A4 | "What's your reason for looking to move?" | EXP | [generic] | Answer slot: give the true reason in your own words, not the most flattering one. | Reason for leaving is a scored logistics item. |
| A5 | "What are your pay expectations?" | JD | [generic] | Logistics slot: give your own figure, or ask for the band first. Do not give a figure you have not chosen. | Pay is a logistics item. The material holds no figure. |
| A6 | "You've never worked in a contact centre. What's your case for this role?" | JD | [grounded] "Never worked in a contact centre." (your message) | Plain acknowledgment: "I haven't worked in a contact centre." Then the bridge: "For my branch, I handled the formal complaints log, and I trained new tellers on our escalation script." Stop there. | F9's stated absence. Answer it early and it sets up B1. |

### Round 2: Head of Member Services (weights: skeptic 4, case 2, prober 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This job owns complaints across branches and the contact centre. Your material shows one branch and no contact centre. Why should I hire you for it?" | JD | [grounded] "I handled the branch's formal complaints log" (your message); "Never worked in a contact centre." (your message) | The hold: "For my branch, I handled the formal complaints log." The concession, plainly: "I haven't worked in a contact centre." Then what you would do in the first month, as a plan. Hold through two follow-ups by returning to the log and the escalation script. Concede the scope, never widen it. | **Highest-ROI prep.** F3 and F9 are where the JD's scope is widest and your material is narrowest. This objection is near-certain in some form. |
| B2 | "The bank plans to move 40% of member service to digital channels by 2028. Which complaints should never move to self-service, and why?" | CO / CASE | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief from the recruiter) | Structure: which complaints carry regulatory or vulnerability stakes; which a member can finish alone; what a digital route must hand to a person; how you would measure whether the shift hurt resolution. Speak in principles. Claim no digital experience. | The brief sets the frame. Nothing in your material supports digital experience, so the answer is reasoning. |
| B3 | "Walk me through how you built the monthly complaints spreadsheet. What did it count, and how?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Answer slot: say what it counted and how it counted, in your own words. If it held volumes but not resolution times, say so. If you don't know how a figure was counted, say so. Name the assumption you would defend least, if you know one. Invent no figure. | F4 and F8 depend on it. Prober questions test what was yours. |
| B4 | "Coaching branch supervisors on escalations is part of this role. Have you done that?" | JD | [grounded] "trained new tellers on our escalation script" (your message) | Answer slot: if you coached supervisors, say how, in your own words. If you trained tellers and not supervisors, say that, then how you would start with supervisors. | F5 is an adjacent quote. The question presumes supervisor coaching. The second branch allows that it never happened. |
| B5 | "Tell me about a time you presented a recommendation to senior leaders." | JD | [grounded] "I've never presented to anyone above regional level." (your message) | Open prompt, honest branch: "I haven't presented to anyone above regional level." Then the nearest thing your material holds: the spreadsheet your regional manager uses, and how it was used, if you know. Describe no presentation. | F7's stated absence. The JD raises senior presenting. |
| B6 | "Digital teams are building self-service journeys for complaints. What would you bring to that work?" | JD | [generic] | Answer slot: if you have worked on a self-service journey, say what your part was. If not, say so, then what you would ask the digital team first: where members drop out, and where a complaint gets stuck. | F6 is silent. The honest form is the plan. |
| B7 | "What would you report every month on complaint volumes and resolution times, and why those measures?" | CASE | [generic] | Structure: volumes by branch and channel; time to resolve; repeat complaints; share past any regulatory deadline that applies; one member-side measure. Say what you would measure first and what you cannot yet measure. | The JD's reporting requirement. A plan, not a past. |
| B8 | "Which rules and timescales governed the formal complaints log you kept?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Answer slot: name the rules and timescales, in your own words, if you knew them and worked to them. If the log had no set timescales you worked to, say so, and say what you did track. | Regulated complaints is a JD requirement. "Formal" does not show which rules applied. |

### Round 3: Panel (weights: values 3, case 2, pressure 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided something from the member's side of the counter, when the rule pointed the other way." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Open prompt, honest branch: pick a complaint where the member's view changed what you did. Say what you did, and what you did not decide. If none comes to mind, say so plainly, then give the nearest one from the log. Use "I" for what you did. | Members First. Your material shows the log, not a named decision. |
| C2 | "Tell me about a time you had to explain something to a member, and then had to explain it again." | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Open prompt, honest branch: a time you explained the escalation script so that a teller could act first time. If you have no such time, say so. Don't say a member needed a second explanation unless it happened. | Plain Words. The value's test is a second explanation, which your material doesn't show. |
| C3 | "What would you do for a town that loses its branch in a hub move?" | VAL | [grounded] "eight branches into five hubs over 2027" (strategy brief from the recruiter) | Answer from principles, not experience: which members travel, which need a counter, and how complaints will reach you from that town. Make no claim about closures you have worked on. | Neighbours, Not Numbers meets the brief's consolidation. Your material holds no closure. |
| C4 | "Tell me about a problem you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Scaffold: pick a complaint you took from first contact to closure, and say what you did at each step. If the log shows you passed the file on, say so. | Own the Fix. A passed-on file is not a failure to admit. |
| C5 | "A member has complained three times about a fee. The branch resolved it twice, and the member says they will go to the external complaints body. You are the complaints lead. Walk us through what you do." | CASE | [generic] | Structure: clarify what each resolution said and what the member was told; check which rules and timescales apply; decide who holds the fix and say so; write the reply in plain words; brief the supervisor; record the pattern. Start from the member's side. Name no deadline you do not know. | The panel's 20-minute case. A live problem from the role, and it makes no claim about your past. |
| C6 | "You've run one branch's log. Why would two branch managers trust you with the rules for the whole network?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | The hold: the log is yours, and you know how the escalation worked. The concession: name which network rules you have not yet run, then what you would do to learn them. Hold through two follow-ups. Concede only the scope. | Pressure, with a peer seam. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | F1; A1 |
| Experience handling regulated complaints | B8; F2 |
| Own the complaints process end to end across branches and the contact centre | B1; C5; F3, F9 |
| Report monthly on complaint volumes and resolution times | B3; B7; F4 |
| Coach branch supervisors on escalations | B4; F5 |
| Work with digital teams on self-service journeys | B2; B6; F6 |
| Confident presenting to senior leaders | B5; F7 |
| Comfortable with Excel reporting | B3, covered as the spreadsheet; F8. Excel itself is not named in any question |

## 10. Values cheat sheet

Values round detected: the panel scores against the four published values.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F2's "I handled the branch's formal complaints log". Pick a log entry where the member's view changed the outcome. If none, say so. Scaffold, honest branch: C1 |
| Plain Words | If a member needs it explained twice, the wording was wrong | F5's "trained new tellers on our escalation script". Pick a time you explained the script so a teller could act first time. If none, say so. C2 |
| Neighbours, Not Numbers | Every branch is part of its town | No row carries a story. Scaffold: pick a time you weighed a branch's role in its town. If none, say so, since your material holds no closure. C3 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F2's "I handled the branch's formal complaints log". Pick a complaint you held to closure. If you passed the file on, say so. C4 |

## 11. Reverse questions

Interviewer profiles are not yet known, so these are role-generic. Each has a "why it lands."

1. "How is the 40% digital target measured for complaints, and who owns that number?" Why it lands: it links to the brief and asks who is accountable for it.
2. "Which of the eight branches move into hubs first, and what changes for complaints raised there?" Why it lands: it shows you read the hub plan and think about members.
3. "What does the first 90 days look like, and who should I meet early in the contact centre?" Why it lands: it asks for a plan, and it doesn't claim experience.
4. "Who receives the monthly complaints report today, and what do they do with it?" Why it lands: it tests whether the reporting drives decisions.
5. "Which complaints are decided at branch level, and which go to the contact centre?" Why it lands: it names the split this job has to hold together.
6. For the panel, reciprocity: "What could someone in this role do in their first month that would genuinely help your branch?" Why it lands: the branch managers may be your future peers, and this asks what you bring, not only what you need.

## 13. Prohibited claims

Built locally from the fit snapshot. Each entry gives its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F3 and F9 | "For my branch, I handled the formal complaints log." Limit, as the pack's own observation: your material shows one branch and no contact centre |
| Advanced Excel, or built automated reporting | Inflated form of F8 | "I built the monthly complaints spreadsheet our regional manager uses." |
| Coached branch supervisors | Inflated form of F5 | "I trained new tellers on our escalation script." |
| Ran a regulated complaints process to the regulator's timescales | Inflated form of F2 | "I handled the branch's formal complaints log." B8 asks which rules applied, and stays inside that quote |
| Reported resolution times to the regional manager every month | Inflated form of F4 | "I built the monthly complaints spreadsheet our regional manager uses." B3 asks what it counted |
| Presented to senior leaders | Stated negative, F7 | "I haven't presented to anyone above regional level." Plain acknowledgment, no slot |
| Worked in a contact centre | Stated negative, F9 | "I haven't worked in a contact centre." Plain acknowledgment, no slot |

## 14. Sources

**Provided documents:**
- Job description (your message).
- Company values, copied 20 November 2026 from ashgrovecu.org/about/values (your message).
- Recruiter's email on the loop: three rounds, 29 November, with the escalation case and the values scoring.
- The 2026 strategy brief, July 2026 (sent by the recruiter, pasted by you).
- Your background (your message).

No dossier was present.

**Research tier:** L1. Searches 0 of 6. Fetches 0 of 2. Every default target was already fixed by a document you supplied, so no call was needed.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values fix the four principles. Section 10 |
| 2. Ashgrove interview process | skipped | The recruiter's email fixes the rounds and the 20-minute case. Section 8 and the round banks |
| 3. Ashgrove strategy / recent news | skipped | The July 2026 brief fixes the current priorities. Section 6 and B2, C3. A news sweep would add recent moves; L2, offered in the upgrade menu |
| 4. Interviewer name + Ashgrove | n/a | No names were given, so there was no query to form |
| 5. Representative JD for this title | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 15. Upgrade menu

- **The complaints framework (regulator, jurisdiction, response timescales) →** B8 and C5 get specific guidance in place of the generic structure. Your answer to B8 can then be quoted.
- **The role's base and hours (branch, hub or contact centre; fixed or flexible) →** A3 becomes a grounded answer, not a logistics slot.
- **The interviewers' names →** persona weights from their public footprint, and a reverse question tied to their career path.
- **Deep research (L2) →** recent Ashgrove news and the strategy's latest framing, to refresh section 6 and B2.
- **Column names from the complaints spreadsheet (no figures) →** B3's answer slot can quote what the sheet held, and F4 and F8 get a sharper bridge.
- **A `tuesday-dossier.md` from an earlier session →** verified evidence and the strongest objection to rehearse, which would sharpen B1 and the prohibited list.

**Drill offer:** I can play the Head of Member Services on B1, the highest-ROI question, and give feedback against its guidance cell. Say the word.
**Dossier offer:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
**Word offer:** I can convert this pack to a Word document once you've finished iterating.
