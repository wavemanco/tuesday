# Ashgrove Credit Union: Member Experience Lead interview pack

Three rounds on 29 November 2026. Round 1: recruiter, 30 min. Round 2: Head of Member Services (your future manager), 45 min, mostly behavioural. Round 3: panel of two branch managers, 60 min, including a 20-minute complaint-escalation case, scored against the four values. Interviewer names for rounds 2 and 3 are not yet assigned.

First version, so no changelog. Built on the material you gave: your background, the JD requirements and responsibilities, the four values copied on 20 November 2026, and the July 2026 strategy brief as you summarised it.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and stop where your own material stops.

Type key:
- **VAL**: behavioural, testing a published value through a past instance
- **EXP**: your own experience, checked for attribution
- **JD**: a requirement or responsibility in the job description
- **CO**: company and strategy knowledge
- **CASE**: a live problem from the role, asked without reference to your past

## Sources and research tier

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The four values you pasted, copied 20 November 2026, fix the values sheet. The page you named was not fetched. |
| 2. Interview process | skipped | The recruiter's email fixes the three rounds, their lengths and their content, so the loop structure is in hand. |
| 3. Strategy and recent news | skipped | The July 2026 brief, as you summarised it, fixes the priorities and figures. A search would only check it against Ashgrove's published copy. |
| 4. Interviewer name and company | n/a | No names were given for rounds 2 or 3, so there was no query to form. |
| 5. Representative JD | skipped | The requirements you pasted fix the fit snapshot. |

Provided documents: your message, which holds your background, the JD requirements and responsibilities, the values text, the strategy summary and the recruiter's process summary. User links read: 0.

Searches: none sent. Every quote below is from your message, so the pack needs no outside source.

## Fit snapshot

Requirements are quoted from the JD you pasted. Your evidence is quoted from your message. Nothing is added to either.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | presentation | Your material gives six years in retail banking, the last three as a branch supervisor. Say those years plainly. The phrase "customer operations" is the JD's, so do not adopt it as a label for your own role. Limit: self-reported, so expect a check on dates. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | presentation | Say it at its own scope: for the branch's formal complaints log, you handled it. Your material does not show the regulated element, such as an external deadline or referral. Answer slot: if the log carried a regulatory timescale or an external referral, say which and what you did with it; if it did not, say so plainly. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | The adjacent work is one branch's log. It does not reach "end to end", and it does not reach across branches. Say the log at that scope and no wider. Answer slot: if you took a complaint from first contact to closure, say which steps were yours; if the log covered only part of that process, say which part. |
| F4 | "Own the member complaints process end to end across branches and the contact centre" (JD), contact-centre part | "Never worked in a contact centre" (your message) | none | [grounded] | capability | The words are yours: "I've never worked in a contact centre." Then how you would learn it, as a plan and never as a past. |
| F5 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Say it as built: "I built the monthly complaints spreadsheet our regional manager uses." Your material does not say what it counted. Answer slot: if it counted volumes, resolution times, or both, say which and how you counted them; if it counted neither, say so plainly and say what you would add first. |
| F6 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Say "spreadsheet", because that is your word. Your material does not name Excel. Answer slot: if it was Excel, say so; if it was another tool, name it. |
| F7 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Training tellers is adjacent to coaching supervisors, and does not reach it. Say the training at its own scope. Answer slot: as a branch supervisor, if you coached anyone through an escalation, say whom and what you did; if you did not, say so plainly and say how you would start. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: if you worked with anyone on a digital or self-service journey, say what it was and your part in it; if you did not, say so plainly and say how you would learn the journey. |

No gate rows: the JD you pasted states no licence, location, schedule or credential term.

Your material also states two negatives, and the pack treats them as given: "Never worked in a contact centre" (F4) and "I've never presented to anyone above regional level" (used in B8 and B5).

## Prohibited claims

These are not coached in any answer, hold or reverse question. Each entry has its basis and the honest form that replaces it.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across the contact centre | Inflated form of F3, and F4 says otherwise | "I handled the branch's formal complaints log." Plain acknowledgment: "I've never worked in a contact centre." |
| Coached branch supervisors on escalations | Inflated form of F7 | "I trained new tellers on our escalation script." |
| Presented complaints reporting to senior leaders | Inflated form of F5, plus a stated negative | "I built the monthly complaints spreadsheet our regional manager uses." Plain acknowledgment: "I've never presented to anyone above regional level." |
| Built Excel reports | Inflated form of F6 | "I built the monthly complaints spreadsheet." |
| Brought resolution times down, or any resolution-time figure | Inflated form of F5; no figure is in your material | "I built the monthly complaints spreadsheet our regional manager uses." Your material gives no resolution figure. |

## Persona weights and loop structure

Three rounds are scheduled, so this is a loop: one shared fit snapshot and prohibited list, then a mini-pack per round with its own weights.

| Round | Relationship | Personas and weights | Reasoning |
|---|---|---|---|
| 1. Recruiter, 30 min | Recruiter screen | Conversational 2 (A1, A2); light Skeptic 1 (A6); logistics slots 3 (A3, A4, A5) | The recruiter row's prior. The recruiter's own email names the logistics the screen covers. |
| 2. Head of Member Services, 45 min | Manager, mostly behavioural | Values/Behavioral 3 (B1, B2, B3); Skeptic 3 (B5, B6, B8); JD and strategy 2 (B4, B7) | The recruiter calls it mostly behavioural and names this person as your manager. Skeptic weight comes from F4 and F7. |
| 3. Panel of two branch managers, 60 min | Panel, scored on values | Values/Behavioral 3 (C1, C2, C3); Case 2 (C4, C5); Pressure 1 (C6); Peer Evaluator 1 (C7) | A panel blends its members' personas. The 20-minute case is the Case weight; the values score is the Values weight. |

Depth: round 2's top persona gets the most questions, and the deepest rehearsal goes to B6, below.

## Highest-ROI prep

**B6 is the highest-ROI prep in this pack.** The contact-centre gap (F4) and the presenting gap (B8) will be asked about in some form in every round, and C6 is the panel version of the same objection. Hold the branch-level handling you did (F2), concede the contact-centre gap in these words — "I've never worked in a contact centre, and that's the part I'd need to learn first" — and let a second follow-up test the hold.

## Round 1: recruiter (A bank)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Ninety seconds, in this order: the six years, the last three as a supervisor; the complaints log; the teller training on the script; the spreadsheet. Use your own words and stop where the quotes stop. Do not add a title or a team size. | A conversational opener that the recruiter scores for economy. These four sentences are the arc every later round tests. |
| A2 | "What's drawing you to Ashgrove?" | CO | [grounded] the brief, as you summarised it: "move 40% of member service to digital channels by 2028"; "consolidate eight branches into five hubs over 2027" | Name one line from the brief and what it means for member service, in your words. Answer slot: say what in the role itself pulls you; the brief is public and you may refer to a line you have read. | Motivation has to be specific, and the brief is the one published source you have. The pack does not supply your reasons. |
| A3 | "What are your salary expectations?" | JD | [generic] | Logistics slot. Choose one: give your own figure, in your own words, or ask what the band is first. Your material gives no figure, so do not give one you have not chosen. | Pay is a logistics question. Its only safe answer is your own. |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period. | A knockout check in a friendly register, and still scored. |
| A5 | "The branches are moving to five hubs. Where could you work from?" | JD | [grounded] the brief, as you summarised it: "consolidate eight branches into five hubs over 2027" | Logistics slot: say the places you can work and the travel you can do, in your own words. The hub plan is the reason the question is likely now. | Location is a logistics slot, and the brief raises it. |
| A6 | "Why are you looking to move on from your current role?" | EXP | [generic] | Answer slot: give your own reason in one or two sentences. Your material does not state one, so the answer is yours to supply. | A reason for leaving is a logistics slot in the recruiter's register. |

## Round 2: Head of Member Services (B bank)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a formal complaint you saw through to the end." | VAL / EXP | [grounded] "I handled the branch's formal complaints log" | Pick one complaint from the log that you followed from logging to closure. Beats: what it was, what you did at each step, what came back. Selection scaffold: if none stands out, say so plainly, then give the nearest one. Do not add a resolution you did not see. | An open prompt on the JD's end-to-end responsibility. F2 is the only quote the story can rest on, so the rest must come from your own memory of the case. |
| B2 | "Tell me about a time you coached someone through an escalation." | VAL | [grounded] "trained new tellers on our escalation script" | Map: the training on the escalation script. Answer slot: if you coached a supervisor or a teller through a live escalation, say what you said and what changed; if the training is the nearest thing, say it was tellers and a script, and what you taught them. | The JD's coaching line raises this. F7 is the nearest sentence, so the honest answer is the training at its own scope. |
| B3 | "Tell me about a time you had to explain a decision a member did not like." | VAL | [generic] | Selection scaffold: pick a moment you explained a decision that went against a member. It needs what you said and what the member did next. If no such moment comes to mind, say so plainly and give the nearest. Keep the explanation in plain words: a member should not need it twice. | Plain Words and Members First are scored here. The question asks you to choose an instance, so the guidance supplies none. |
| B4 | "Walk me through the monthly complaints spreadsheet you built, and what it counts." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Describe what you built and who uses it, in your words. Answer slot: if it counted volumes, resolution times, or both, say which and how you counted them; if it counted neither, say so plainly and say what you would add first. If the tool was Excel, say so; if not, name it. | The JD's reporting line and its Excel requirement both point here (F5, F6). Do not name a tool or a figure you did not state. |
| B5 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Say plainly that you have not worked in a contact centre and have not presented above regional level. Then how you would learn each one, as a plan. Do not bluff. | A Skeptic question scored on candour. F4 gives the words, and they are the only honest answer. |
| B6 | "You haven't run a contact centre. Why would this go any differently from your branch?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre" | **Highest-ROI rehearsal.** Hold-then-concede. Hold: what carries over is the complaints handling you did at branch level. Hold through two follow-ups, and return to the log each time. Concede specifically: "I've never worked in a contact centre, and that's the part I'd need to learn first." Do not fold on the handling, and do not claim contact-centre work. | The pressure version of B5. The position held is the one the log sentence carries, and the concession is the one your own sentence supports. |
| B7 | "The plan moves 40% of member service to digital channels by 2028. What's your part in that?" | CO | [grounded] the brief, as you summarised it: "move 40% of member service to digital channels by 2028" | Answer slot: if you worked on a digital or self-service journey, say what it was and your part in it. If you did not, say so plainly, then describe how you would work with digital teams: start from where complaints show a journey breaks. | The brief raises it. F8 has no quote, so the slot is the honest form. |
| B8 | "You'd present monthly figures to senior leaders. What have you presented, and to whom?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I've never presented to anyone above regional level." Then how you would prepare for a senior audience, as a plan. | A stated requirement with a stated negative. The words are yours, and the plan is the only thing to add. |

## Round 3: panel of two branch managers (C bank)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you did right by a member when the rules pointed the other way." | VAL | [generic] | Selection scaffold: pick a moment when a member's interest and a rule pulled apart. Say what you did and what the rule said. If none comes to mind, say so plainly and give the nearest. | Members First. An open prompt whose theme comes from the value; the pack supplies no past. |
| C2 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Map: the log you handled. Answer slot: if you kept one complaint open until it was solved, say what held it open and what closed it; if no complaint on the log was carried that far, say so and give the nearest. | Own the Fix. F2 is the only ownership sentence, so the closure must be your own. |
| C3 | "How do you make sure a branch's decision still makes sense to the people in its town?" | VAL | [generic] | Selection scaffold: pick a decision that changed how a branch dealt with its own local members. If none, say so, and say what you would check first. | Neighbours, Not Numbers. A value-linked prompt with no past supplied. |
| C4 | CASE, twenty minutes: "A member writes that their claim has been rejected three times, and their branch cannot say why. Walk us through your first week." | CASE | [generic] | Clarify: what the rejection rests on, which branch, how many members. Objective: the member's answer, and the complaint closed. Segmentation: by branch, cause, and age of complaint. Approach: one owner, a written explanation in plain words, and the branch supervisor coached on the escalation. Metrics: volume and resolution time, the two the JD names. Risks: the branch decision being wrong, and the member being told twice. Think aloud, and name one assumption. | Scored on structure over the right answer. Built from three JD lines: end-to-end ownership, supervisor coaching, and monthly volumes and resolution times. |
| C5 | Follow-up to C4: "Two supervisors disagree on the fix to the script. Which do you back, and what do you do with the other?" | JD | [generic] | Decide and say why. Then the supervisor you did not back: how you would coach them. Name the evidence you would want first. | The case's second beat, testing coaching of supervisors. |
| C6 | "Sixty seconds: why should we hire someone who has never worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Pressure. Hold: what you bring is the complaints handling at branch level, from the log you handled. Hold through two follow-ups, then concede the real gap: contact-centre work is new to you. Give your learning plan as a plan. | The panel version of B6. Premised on your own sentence, not on any other candidate. |
| C7 | "Where does a branch's responsibility for a complaint stop and the contact centre's start?" | JD | [grounded] the JD line you pasted: "Own the member complaints process end to end across branches and the contact centre" | Peer seam. Propose principles, not a map you have not seen: one owner per complaint, one log, and the handoff written down. Answer slot: if you have seen such a handoff, describe it; if not, say so plainly and propose the principle. | A Peer Evaluator probe on the seam the JD names. |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| 4+ years in financial-services customer operations | A1, B5 |
| Experience handling regulated complaints | B1, B6 |
| Confident presenting to senior leaders | B8, C6 |
| Comfortable with Excel reporting | A1, B4 |
| Own the complaints process end to end across branches and the contact centre | B1, B6, C4, C7 |
| Report monthly on volumes and resolution times | B4, C4 |
| Coach branch supervisors on escalations | B2, C4, C5 |
| Work with digital teams on self-service journeys | B7, C7 |

## Values cheat sheet (round 3, and values scoring in round 2)

Values are copied from your message (ashgrovecu.org/about/values, 20 November 2026). Your material does not carry a story for any of the four values, so each row gives a selection scaffold and its honest branch.

| Value | Working meaning | Mapped story | Where asked |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | None carries it. Selection scaffold: pick a decision you made at the counter that a member would have seen differently. If none comes to mind, say so plainly, then give the nearest. | C1, B3 |
| Plain Words | If a member needs it explained twice, it was written wrong. | None carries the story. The nearest sentence is "trained new tellers on our escalation script". Selection scaffold: if you explained the script so tellers could use it, say how; if the training was the script as written, say that. | B3, B2 |
| Neighbours, Not Numbers | Every branch is part of its town. | None carries it. Selection scaffold: pick a decision that changed how a branch dealt with its own local members. If none, say so. | C3 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | "I handled the branch's formal complaints log" is the nearest ownership sentence. The closure is not in your material. Selection scaffold: pick a complaint you kept open until it was solved. If none was carried that far, say so and give the nearest. | C2, B1 |

## Grounding brief

From the July 2026 strategy brief, as you summarised it in your message. This is the vocabulary, not a claim you should repeat as fact about Ashgrove's internal plans. Check the wording against Ashgrove's published copy before the interview, since this pack did not verify it.

- **Member service moves to digital channels**: 40% by 2028. Use "digital channels" and "member service", the brief's words.
- **Branch consolidation**: eight branches into five hubs over 2027. Use "hubs".
- **Small-business lending**: launch in Q1 2027. You do not need to speak to it, but a line from the brief shows you read it.
- **Competitive pressure**: from app-only banks. Say what the complaints process looks like for a member who uses only an app, if asked, as a question you would want answered.

If asked about the branch changes, say what you know from the brief and what you would want to learn. Do not describe the hubs' future from memory.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "As the eight branches move into five hubs, how will complaints be handled across them?" | It shows you read the brief and treat complaints as the continuity thread through the change. |
| R2 | "What would a good first ninety days look like in this role?" | It asks the manager a scoped question and lets you hear what success means to the person who would judge it. |
| R3 | "How are branch supervisors supported on escalations today?" | It names the coaching line in the JD and asks what exists before you assume any of it. |
| R4 | "Where are the digital teams on self-service journeys, and how would complaints feed into that work?" | It tests the JD's digital line and shows you see complaints as input to the journeys, not an afterthought. |
| R5 | "Which measures does the monthly report go to senior leaders with, and what does the resolution-time picture look like now?" | It ties to the monthly reporting line and shows you want the existing numbers, not a fresh start. |
| R6 | "What would you need from a Member Experience Lead in the first month that would genuinely help your branches?" | A reciprocity question for the branch managers on the panel. It converts an interview into a peer conversation. |

## Upgrade menu

- Interviewer names for rounds 2 and 3 → persona weights read from their public footprint, and a tailored reverse question for each.
- The JD as posted, in full → the requirement quotes become exact text, and the requirement coverage table covers every line.
- Your CV → the four evidence quotes become checkable, with a named document to show for each.
- The recruiter's note on the 30-minute round → confirms whether pay, notice and location are asked there.
- Deep research (L2), if you want it: up to six more searches and two page fetches, on Ashgrove's published strategy brief, the interviewers' public footprint once named, and recent news. Say yes and it runs.
- A tuesday-dossier.md → verified evidence, prohibited claims, and the objections to rehearse most. Without one, the highest-ROI objection is inferred from your material, not evidence-derived.
