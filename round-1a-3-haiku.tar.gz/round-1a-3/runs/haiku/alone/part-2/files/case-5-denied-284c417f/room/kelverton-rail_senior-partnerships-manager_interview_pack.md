# Prep pack: Senior Partnerships Manager, Kelverton Rail, second-round panel

**Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes: a 15-minute spoken point of view (no slides), then about 45 minutes of Q&A with Ross pushing on commercials.
**Built on:** your background message and the recruiter's email. No job description, no CV, no research run, and I have not seen the internal market report. Everything below rests on those.

---

## 1. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **Type key:** **VAL** behavioural/values. **EXP** your own experience, tested for attribution. **JD** the role's stated requirements. **CO** company and strategy knowledge. **CASE** a live problem.
- The guidance is scaffolding, not a script. Say it in your own words. Each guidance cell is written to be speakable in 90 to 120 seconds.
- An **answer slot** is an instruction for the interview, not a question for me. It tells you what to say when the interviewer goes there, and it has an honest branch for when the practice was not yours.

---

## 2. Prep triage (about 4 hours)

1. **75 min: the POV.** Write theses T1 and T3 (section 5) as spoken paragraphs, each with its concession. Close on one operator-visible outcome. Say it aloud twice, timed to 12 minutes.
2. **45 min: D1, the objection this pack ranks highest.** Rehearse it three times aloud, holding through two follow-ups each time, and conceding exactly what section 9 says you concede.
3. **40 min: A1 to A3, the £4M.** Write down, in your own words, how the figure was tracked. Then say whether you can defend it, and where you would check it. Do not reconstruct a method you cannot recall.
4. **25 min: C1, the first-90-days problem.** Say the framework out loud: clarify, objective, segment, approach, metrics, risks.
5. **15 min: the openers.** Time E1 to 90 seconds. Pick three reverse questions from section 10.

Everything else is insurance.

---

## 3. Fit snapshot

Requirements come from the recruiter's email, quoted. The job description is missing, so no requirement below is JD-sourced. The evidence column holds only your own sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | "where you'd take our operator partnerships over the next 18 months" (recruiter email) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Your material says partner growth in a payments ISV channel, not operator partnerships. Keep the words at that scope: "I took the channel from six partners to forty." Answer slot: if the operator model differs from the ISV model, say which part carries over and which does not, in your own words. |
| R2 | "what it means for the operators themselves" (recruiter email) | "bus and light rail network planning, so I know the operator world from the other side" (your message) | medium | [grounded] | presentation | The quote reaches operators, but from the planning side and for bus and light rail, not train operators' commercial side. Reword only that quote: "I've seen the operator side from network planning, on bus and light rail." Add no practice. |
| R3 | "Ross will push on commercials" (recruiter email) | "never carried a direct quota, only influenced revenue" (your message) | low | [grounded] | capability | You stated the absence. Words: "I've never carried a direct quota, only influenced revenue." Then what you would do to learn the commercial model, said as a plan and never as a past. |
| R4 | Experience selling into rail operators (generic: role family, no JD line yet) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | You stated the absence. Words: "I haven't sold into rail." Then how you would learn it, as a plan. Never a claim to rail sales. |

**Gate status:** none of these rows is decided as a gate. Whether R4 is a must-have depends on the posting. Question Q1 asks.

---

## 4. Prohibited claims

Claims this pack will not coach, each with its basis. Nothing in any guidance cell asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've sold into rail" or "I know the rail sales cycle" | Inflated form of R2 and R4 | The planning-side quote at its own scope, plus "I haven't sold into rail." Your material shows planning on bus and light rail. It does not show rail sales. |
| "I built the ISV channel strategy" | Inflated form of "running the ISV channel" | "I ran the ISV channel." The material shows you ran it, not that you designed its strategy. If asked, the slot is which parts you designed. |
| "I generated £4M" | Inflated form of "influenced revenue" | "roughly £4M of influenced revenue." The material says influenced, not sourced or closed. |
| "I owned a quota" or "I hit target" | Negative you stated (R3) | "I've never carried a direct quota, only influenced revenue." No further claim about targets. |

---

## 5. Graded deliverable: the 15-minute point of view

**Declared by the recruiter:** "First 15 minutes we'd like you to present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves."

**Facts to build on** (from section 3):
- R1: "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message)
- R2: "bus and light rail network planning, so I know the operator world from the other side" (your message)

**Consensus answer and differentiation.** I have not seen the internal market report, so I cannot say what the consensus answer is. The rule is to differentiate from it, never to recite it. Paste its main claims (Q3) and I will mark which thesis departs from it and why. Until then, treat T1 and T3 as the candidates for departure.

**Theses.** Pick two. Each one carries its concession.

- **T1 (operators' change cycle): partnerships should be organised around the operator's timetable-change and disruption-recovery work, not around the partner's sales cycle.**
  Argument: operators experience scheduling software through change events, so a partner that is tied to those events is worth more to them than a partner tied to a deal.
  Concession (say it): "I've seen the change cycle from the planning side, on bus and light rail. I haven't seen a train operator's franchise commercial process, so I'd test this with operators before I'd commit to it."

- **T2 (reach through the operators' own delivery teams): partners extend reach by working inside operators' delivery teams, not only by reselling.**
  Argument: the ISV channel was resale-led. Rail operators may buy direct, so the partner's value is in delivery, not in the sale.
  Concession (say it): "The ISV model I ran was resale-led. I haven't run a partner model where the operator buys direct, so that part is a hypothesis."

- **T3 (anti-pick): don't set a partner-count target in the first 18 months. Set a target on operator outcomes instead.**
  Argument: a count of partners is easy to report and says nothing about what the operator gets. The partner count you grew from six to forty is evidence that you can build a count. It is not evidence about operator outcomes.
  Concession (say it): "A count is easier to report, and Ross may want one. I'd keep one as a leading indicator, not as the target."

**Requested close, land on what it means for the operators.** Finish on one outcome the operator would notice, described as the operator would feel it. Do not add a figure you cannot defend. If you name a number, it must be one you can say how you would measure.

---

## 6. Persona table

| Persona | Who it fits on the panel | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | Ross | Asks how the £4M was counted, and which of the 40 partners were yours. | High. He is the commercial voice, your CV leads with a headline figure, and the recruiter said he will push on commercials. | Know what you can say about the figure's counting. Say plainly when you do not know. Name the weakest assumption before he does. |
| Pressure / Stress | Ross | Interrupts, time-boxes, presses on "how much was actually you". | Medium to high. Commercial directors often test composure on numbers. | Pause, restate, hold the position through two follow-ups, then concede the specific uncertainty. |
| Case / Strategist | Deepa | Gives a live problem from the operator side and watches how you structure it. | High. A future manager buying capability for her roadmap, and the POV is a strategy test. | Clarify first. Say the framework aloud before using it. |
| Skeptic | Deepa | Presses on the rail and quota gaps, and asks why you, why now. | High. The stated gaps are the first thing a manager must de-risk. | Rehearse the single most predictable objection until it is plain. Concede calibrated limits. Do not bluff rail sales. |
| Conversational / Rapport | Either | Opens with "walk us through your journey" and treats it as unscored. | Low weight, since it is an opener. Still scored. | A 90-second arc, prepared in advance. |

**Panel weighting:** blend the top two personas of each member. Ross: Prober, then Pressure. Deepa: Case, then Skeptic. The Conversational persona sits at the opener only. No interviewer profile was supplied, so there is no interviewer read and no adjustment from public signals.

---

## 7. Question banks

Depth follows weight: the top persona gets 5 questions, mid-weight 3 to 4, low-weight 2. The banks total 18.

### Bank A: Ross, Data-Driven Prober (5 questions, highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the £4M was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | Say the figure in those words. Answer slot: if you can say how it was counted, say how, in your own words. If you cannot reconstruct the method, say that plainly, then say where the figure would be checked. Never supply a counting method you do not recall. | R1 is the headline figure. It is the first thing a prober tests, and the question presumes only the figure you gave. |
| A2 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Name, in your own words, the assumption you are least sure of before he finds it. Answer slot: if you do not know which assumption is weakest, say the figure's attribution is the part you would least defend, and say why. | The weakest-assumption move turns a gotcha into a credibility point. The pack does not supply the assumption, because no quote does. |
| A3 | "Of the partners you grew, which did you sign yourself?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Use the quote's own scope: you took the base from six to forty. Answer slot: if some partners came through others, say which, and what part you played in each. If you signed none of them personally, say so. | Ross separates the candidate's share from the team's. "Took it" is the sentence's scope, so the answer does not stretch it. |
| A4 | "What's the revenue case for an operator partnership, and how would you count the partner's share?" | JD | [generic] | Structure it aloud: who pays, what the operator buys, how the partner's contribution is attributed. Use no figures. Name what you would test first. | Ross pushes on commercials. The question asks about the model, not your past, so the guidance makes no claim about it. |
| A5 | "What would you need to see in the first quarter to know operator partnerships are working?" | JD | [generic] | Name leading indicators and lagging ones, and say which you would not report alone. Do not supply pipeline numbers. | The role's first-quarter test. A plan, not a past. |

### Bank B: Ross, Pressure (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: why should a commercial director put you on a number you've never carried?" | JD | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Pause. Restate: "You're asking whether I can own a number I haven't carried." Then the quote as stated, and the partner growth in R1. Hold through two follow-ups. Concede specifically: "I'd expect a ramp period on a direct number, and I'd want it stated up front." | R3 is the stated gap, and Ross will go straight at it. Hold the position the quote carries, and concede only what you can name. |
| B2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | Hold: the partner growth was yours to drive, and the revenue was influenced, not booked. Concede shared credit explicitly. Answer slot: if other people closed deals or ran parts of it, say who, in your own words. | Pressure on attribution. The hold is only the quote's own scope. |
| B3 | "Operators run on fixed budgets and long contracts. Why would a payments partner playbook work?" | CO | [generic] "running the ISV channel" (your message) | Hold: the playbook will not transfer whole. Name the one part you think carries over: partner recruitment and enablement, from "running the ISV channel". Concede the part you do not know. | A challenge built from the market's general shape. The guidance does not assert operator facts, only what you ran. |

### Bank C: Deepa, Case / Strategist (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "An operator's timetable change is delaying partner integrations. How would you approach the first 90 days?" | CASE | [generic] | Clarify first: which operator, which change, what the delay costs them. Objective. Segment the partners. Approach. Metrics that would tell you it is working. Risks. Say the framework aloud. | A live problem from the operator side. It asks about no past, so it claims nothing about you. |
| C2 | "How would you explain to an operator's head of planning what the partnership does for them?" | CO | [grounded] "bus and light rail network planning, so I know the operator world from the other side" (your message) | Start from the planner's problem, not your partner count. Use the planning-side view the quote carries, at its scope. Answer slot: if you have tested any version of this with an operator, say what they said. If not, say so. | R2 is the bridge into the operator side. Lead with the operator's problem, which is the close the recruiter asked for. |
| C3 | "What would an operator notice in the first month that they would not notice from a partner?" | CASE | [generic] | Name one operator-visible result, and say how you would check it was real. Do not promise a result. | The recruiter's close, "what it means for the operators themselves", in a live form. |
| C4 | "What would you stop doing in operator partnerships?" | CO | [generic] | This is the anti-pick, T3. Name one thing you would stop, and say why. | The consensus answer is to do more. Saying no is the judgement test. |

### Bank D: Deepa, Skeptic (4 questions; highest-ROI objection)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've never sold into rail and never carried a quota. Why would I hire you to own operator partnerships?" | JD | [grounded] "Never sold into rail specifically" (your message); "never carried a direct quota, only influenced revenue" (your message); "bus and light rail network planning, so I know the operator world from the other side" (your message) | **The highest-ROI rehearsal in this pack.** Beat 1: the stated facts at their scope. "I haven't sold into rail, and I've never carried a direct quota, only influenced revenue." Beat 2: the planning side, at its scope. Beat 3: the ramp, as a plan. "In the first 90 days I'd…" Concede: "You're right that the sales motion is the gap. I'd want to be measured on operator outcomes first." Hold through two follow-ups by returning to beat 1. Answer slot: if you have had any operator-facing conversation, say which, in your own words. If not, say so. | This objection will come in some form. It is aimed at R3 and R4, where the material is thinnest, so the pack is most tempted to thicken it. It does not. |
| D2 | "Which part of the operator job would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" (your message) | Name the gap as you stated it. Then the ramp: how you would close it. Do not name a strength that the material does not show. | Skeptics test whether the candidate knows their own limit. |
| D3 | "You ran a payments ISV channel. Operators buy differently. What transfers?" | EXP | [grounded] "running the ISV channel" (your message) | Two beats from what you ran: partner recruitment and enablement. Concede the operator's buying process as the unknown. Answer slot: if any part of the ISV model changed for operators, say which. | Tests whether the payments experience is a lesson or a template. |
| D4 | "Why this, and why now? You're leaving a payments company." | EXP | [generic] | The material does not state your reasons for leaving. Answer slot: give your own reasons in your own words. Ground the "why this" in the operator-side view from R2 only if it is true for you. Do not invent a motive. | Motivation consistency. The guidance supplies no reason. |

### Bank E: Openers (2 questions, low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through your journey." | JD | [grounded] "last 4 at a payments company running the ISV channel" (your message) | A 90-second arc in this order: transport planning, then the payments ISV channel, then why operators. Keep each step to what the sentence says. | Unscored in tone, scored in content. A pre-scripted arc stops you freezing. |
| E2 | "What have you been reading about the operator world lately?" | CO | [generic] | Name a source you have actually read. Answer slot: if you have not read anything recent on the operator side, say so and say what you would read first. | Tests curiosity without asking you to recite. |

**Requirement coverage**

| Requirement | Covered by | Note |
|---|---|---|
| R1: operator partnerships over 18 months | C1, C2, C3, A4, section 5 | Covered. |
| R2: what it means for the operators themselves | C2, C3, E1, section 5 close | Covered. |
| R3: commercials | A1 to A5, B1, B2, B3 | Covered. |
| R4: rail operator sales | D1, D2, D3 | Covered. The thinnest area, so the most rehearsal sits here. |

---

## 8. Reverse questions

Each one has a reason it lands. No interviewer profile was supplied, so none is tied to their own path yet.

1. **To Ross:** "When a partner's influenced revenue is counted, how do you split credit with the operator?" *Why it lands:* it asks him how he thinks about attribution, which is the question he will be testing you on.
2. **To Deepa:** "What would make the first six months a success in your eyes?" *Why it lands:* it turns the interview toward her priorities and gives you the criteria she will judge you against.
3. **To Deepa:** "Which operator relationship would you want the new person to inherit first?" *Why it lands:* it tests where the real work is, and shows you are thinking about the operators, not only the job title.
4. **To Ross:** "Where do partnerships and the commercial team disagree most about operator deals?" *Why it lands:* it names the friction he will recognise, and shows you expect it.
5. **To either:** "Which operator would be the first test of this strategy, and why that one?" *Why it lands:* a concrete question about the first real case is one they can answer in the room.

---

## 9. Concessions to rehearse

- **On rail:** "I haven't sold into rail." Then the plan, not a claim.
- **On the quota:** "I've never carried a direct quota, only influenced revenue." Then "I'd want a ramp, stated up front."
- **On the £4M:** shared credit is the default concession. If you cannot recall the counting method, say so, and say where it would be checked.
- **On the strategy:** T1 and T2 each concede their unknown. T3 concedes that a count is easier to report.

---

## 10. Sources

- **Provided documents:** the recruiter's email (quoted in sections 3, 5 and 6); your background message (quoted throughout).
- **Not seen:** the internal market report, mentioned in the recruiter's email. Its content is not in this pack.
- **Research tier:** L0. No searches and no fetches were run, because consent had not been given.

**Target accounting**

Research tier: L0 — searches 0 of 0, fetches 0 of 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Would have fed a values cheat sheet, though no values-style round was detected, so it would not appear in this pack anyway. |
| 2. `Kelverton Rail interview process` | unavailable | Would have fixed loop structure and persona weights beyond the panel shape given. |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Would have grounded the CO questions in current strategy. Those questions are generic here. |
| 4. `Deepa VP Partnerships Kelverton Rail` | unavailable | Would have produced an interviewer read and tied one reverse question to her path. |
| 5. Representative `Senior Partnerships Manager` JD | unavailable | Would have turned R1 to R4 into `[inferred]` requirements, with a source. |

---

## 11. Upgrade menu

- **The job description, or your note on whether rail operator experience is a must-have** → R4 gets its requirement text, and the gate status is decided.
- **The market report's main claims, pasted** → section 5 marks which thesis departs from the consensus answer, and why. T3 becomes grounded instead of generic.
- **Light research (6 searches, 2 page reads) on values, interview process and recent strategy** → the CO questions in banks B3, C2 and E2 get current strategy, and the target accounting moves from unavailable.
- **Public profiles or talks for Deepa and Ross** → an interviewer read, persona weights per member, and a reverse question tied to their path.
- **Your CV** → R1 to R3 gain sentences you actually wrote, and the story maps in the banks can carry beats.
- **Your own notes on how the £4M was tracked** → A1 and A2 turn from answer slots into story maps. Use only what you can repeat under a second question.
