# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager; not yet confirmed.
**Format:** one 60-minute session, Friday.
**Research:** none ran. Web search was refused in this session, so nothing about Saltmarsh's values, interview loop, strategy or Tobias's public background is in this pack. See Sources.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. The guidance is scaffolding, not a script: say it in your own words.

Type key:

- **EXP**: work-experience deep-dive. Tests whether what you did is yours to claim.
- **JD**: the job's own requirements, including the gaps.
- **CASE**: a live problem from the role, scored on structure and reasoning.
- **VAL**: values alignment. Not used: no company values are in hand.
- **CO**: company and strategy knowledge. Not used: no research ran.

Labels: **[grounded]** traces to your message or the JD you pasted. **[generic]** is a role-family pattern with no claim about you or Saltmarsh. There are no **[inferred]** rows.

An **answer slot** is an instruction for the interview: it says what to answer when the question arrives. It asks nothing of you here.

## Fit snapshot

Requirements are the JD's own words. Evidence is your sentences, quoted exactly.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one main title and content drops, not two titles and live events, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you planned or ran anything beyond the main title, or ran live events as well as content drops, say which and how, in your own words. If you did not, say so plainly and stay with the main title. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordinating design, art, engineering or community on an update. Answer slot: if any update you worked on needed those teams to move together, say how you got them moving, in your own words. If none did, say so and describe how you would run one. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the numbers. It does not show a post-event review. Answer slot: if you ran a review after a drop or an event, say what it looked at, in your own words. If you did not, say so. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap in the quote, which already reaches the requirement. The limit is that it says you wrote the checklist, not that you ran the release process. Expect a probe on "manage." |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | transferability | The years meet the 3+ bar. Your material does not say the work was live-service, and the words stay there: "4 years as an associate producer at a puzzle-game studio." Answer slot: describe the title's live cadence in your own words. If you would not call it live-service, say so and say what you would call it. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. The quote reaches the requirement directly. Its scope is one main title. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms, so use it as written: "Presented the monthly retention numbers to the studio head." It does not show how the numbers were built. Answer slot: name the figure you know best and what you would check first in a figure you did not build, in your own words. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The quote is written work that a team uses. Say it as written: "I wrote the release checklist our QA team still uses." It is one artifact, and it is not a writing sample. |
| O1 | Not in the JD: people leadership. Your own gap, from your message. | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap you stated, so the words are yours to give back: "I haven't led a team." Then a plan, never a past: how you would coordinate four teams without managing them. |
| O2 | Not in the JD: in-app purchases. Your own gap, from your message. | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap you stated: "I haven't worked on a game with in-app purchases." Then a plan for learning it, never a claim of experience. |

Notes on the table:

- R5 (F5) is a length-of-experience requirement. It is not a gate, so it is graded on fit like the others.
- O1 and O2 are not JD requirements. They are the gaps you named, and interviewers often probe the same ground.
- Four years at a puzzle-game studio meets the "3+ years" line on time. Whether it meets "live-service" is open, and your material does not settle it.

## Prohibited claims

Built locally from the fit snapshot. These are claims to avoid, and no answer, hold or bridge in this pack asserts them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the live-events calendar for two titles | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title for the last two years." The limit, as this pack's observation: your material shows one main title and content drops, not two titles and live events. A1's slot stays inside the main title. |
| Managed the release checklist with QA | Inflated form of F4 | "Wrote the release checklist our QA team still uses." The limit, as this pack's observation: your material says you wrote it, not that you managed the release process. |
| Owned the post-event review and the KPIs it reports | Inflated form of F3 | "Presented the monthly retention numbers to the studio head." The limit, as this pack's observation: your material shows presenting the numbers. B4's slot asks only what you looked at. |
| Live-service experience at the puzzle studio | Inflated form of F5 | "4 years as an associate producer at a puzzle-game studio." The limit, as this pack's observation: your material does not say the title was live-service. |
| Leading a team | Negative you stated, O1 | "I haven't led a team." No slot. |
| Working on a game with in-app purchases | Negative you stated, O2 | "I haven't worked on a game with in-app purchases." No slot. |

## Persona weights

**Relationship prior:** hiring manager. The hiring-manager row of the persona model weights Case and Skeptic highest, because the hiring manager is buying capability and checking the gaps.

**Interviewer signals:** none. There is no public footprint on Tobias in this session, so the interviewer read is absent.

**Loop:** no loop source establishes the process, and no values round is detected. The weights rest on the generic archetype, not on Saltmarsh's documented process.

**Weights:** A Skeptic 5. B Case 4. C Prober 3. D Pressure 2. E Conversational 2. Peer evaluator low, because Tobias is assumed to be your manager. If that is wrong, the weights change; see the message that presents this pack.

| Persona | How it shows up here | Likelihood and why | Counter-strategy |
|---|---|---|---|
| A. Skeptic (5) | "You've run one title, and this role runs two. What makes you think you can?" | High. The JD's two titles and live events sit against your one main title, and the quotes make the gap visible to any reader of your CV. | Rehearse A1 until it is plain. Use the quote at its scope, concede the gap in one sentence, and give a concrete plan for the second title. |
| B. Case / Strategist (4) | A live problem on a title's retention or a cross-team update. | High. A hiring manager asks for live problems, and the JD names a live calendar and cross-team updates. | Clarify before you structure. Say the framework aloud once, then use it. |
| C. Data-Driven Prober (3) | "Which of those retention numbers would you defend least?" | Medium. The retention line is on your CV, and probers go to the numbers. | Name the weakest assumption before they do. Say plainly where you do not know how a figure was counted. |
| D. Pressure (2) | "Sixty seconds: why you over someone with both?" | Medium. Your two named gaps make a pressure question natural, and the question is about your motive. | Hold the calendar and the checklist for two follow-ups, then concede the gaps in plain words. |
| E. Conversational (2) | "So, walk me through the journey." | Medium. A 60-minute session opens casually, and casual questions on JD items are scored. | Use a 90-second arc built only from your own sentences. |
| Values / Behavioral | not weighted | No values round is detected: no loop source, and no values in hand. | None |
| Peer evaluator | not weighted | Assumed not a peer. | None |

## Question banks

Question types: EXP, JD, CASE. Each row's provenance quotes every sentence its guidance rests on.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've run the content calendar for your studio's main title. This role runs live events on two titles. What in your background shows you can run two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | **Highest-ROI prep in this pack.** The honest line is the quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." Say what the calendar involved, in your own words, and what from it would transfer to a second title and what would not. Answer slot: if you planned or ran anything beyond the main title, or ran live events, say which and how. If you did not, say so plainly, stay with the main title, and give your plan for the second title. Hold through two follow-ups by returning to the main title. Concede plainly that you have not yet run two titles. | F1 is the calendar line and the likeliest target of this probe. The premise is the JD's own line and the quote's own scope. Tagged JD because it scores a stated requirement. |
| A2 | "You've never led a team. This role coordinates design, art, engineering and community on every update. How would you get those four teams to ship an update together?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." — your message | Plain acknowledgment: "I haven't led a team." Keep it to one sentence and do not argue it away. Then the coordination answer, which the material does not show. Answer slot: if any update you worked on needed those teams to move together, say how you got them moving, in your own words. If none did, say so and give your plan for running one. A plan is a plan, not a past. | O1 is the stated negative this question presupposes. The JD's coordination line is the raising source. F2 carries no quote, so the coordination answer is a slot. |
| A3 | "You've never worked on a game with in-app purchases. What do you understand about how purchases change a live calendar, and how would you learn the rest?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." — your message | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then say what you understand now, in your own words, and attribute no purchase work to yourself. The learning plan is a plan. | O2 is the stated negative this question presupposes. In-app purchases are not in the JD, so this is a probe, and the answer should describe what you know now, not what you have done. |
| A4 | "Your background is a puzzle studio. Why would that experience carry over to live operations on two mobile titles?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." — your message | Start from the sentence: four years, associate producer, puzzle-game studio. Then name what carries over, using the calendar and the checklist, each in its own words. Answer slot: describe the title's live cadence, and if you would not call it live-service, say so and say what you would call it. Do not claim the studio's monetisation or event work as yours beyond what you can describe. | F5 is the years-and-sector line. The live-service part is the gap, so the answer must not supply it. |
| A5 | "Why are you looking to move on from a studio you've spent four years at?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." — your message | Give your own reason, in your own words. Your material does not state one, so this pack supplies none. Keep the answer about what you want to do next. | The motivation probe of the Skeptic persona. The question's premise is the four years at the studio, which the quote carries. |

### B. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A live event for one of the two titles missed its retention target in its first week. Walk me through your first hour on it." | CASE | [generic] | Clarify the target and what counts as a miss. Segment the drop by new and returning players, by event and by cohort. Check the release state against the checklist. Decide what goes into the post-event review. Speak it in about two minutes. | A live problem on the JD's review and retention lines. The pattern is generic and makes no claim about Saltmarsh. |
| B2 | "Design wants to ship a new event on a date that art has said they cannot meet. What do you do?" | CASE | [generic] | Clarify what each team needs, and separate the scope from the date. Decide who decides, and what QA needs in writing. Say what you would put on record. | F2 has no quote, so this is where the coordination answer is practised without a claim about your past. |
| B3 | "Plan the next eight weeks of content for a title whose retention has fallen for two months." | CASE | [generic] | Ask what the target is and what the cause hypotheses are. List what you would change, in what order, and what you would leave alone. Name the one metric you would watch weekly. | The calendar requirement, tested as a live plan. F1 is the calendar you ran, but this problem is generic. |
| B4 | "How would you run the post-event review for an event that shipped on time and underperformed?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Say what you would look at first, what you would compare it against, who you would bring in, and what you would write down. Answer slot: the JD asks you to own the review and its KPIs, and your material shows presenting monthly retention numbers. If you ran a review after a drop or an event, say what it looked at. If you did not, say so and describe how you would run one. | F3 is the nearest evidence. The method in the guidance is generic, and the quote is the only thing said about your past. |
| B5 | "Pick a live event from any game you know. What would you measure in its post-event review?" | CASE | [generic] | Name the decision the review is for. Give three measures, then the one you would distrust most. Describe an event you can speak about as a player or an observer, and do not claim you worked on it. | The review and KPI requirement, asked as a case. The example is any game, so the answer is not about your past. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which of the retention numbers you presented to the studio head would you defend least, and why?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Name, in your own words, the assumption behind the figure you would defend least, before the interviewer does. Your material does not show how any figure was built, so this pack supplies no method, baseline or cohort. If you do not know how a figure was counted, say so. Answer slot: name the figure you know best and say which part of it was yours to set. If none of it was yours, say so. | F7 is the retention line. The weakest-assumption move is the one the pack can teach without naming an assumption. |
| C2 | "What does the release checklist cover, and how does your QA team use it?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." — your message | Open with the sentence as written: you wrote it, and QA still uses it. Then describe what it covers, in the order QA works through it. Answer slot: if the checklist was agreed with QA or changed by QA, say that in your own words. If you wrote it alone, say so. | F4 is the evidence for the release requirement, and "manage" is the word a prober will test here. |
| C3 | "How many updates did that content calendar cover in a year?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | If you have the number, give it, and say whether it counted drops or events. If you do not have it, say so, and say how you would count it. Do not estimate a figure aloud as if it were fact. | F6 is the calendar. The count is the prober's denominator, and the answer must be your own number or none. |
| C4 | "What is the difference between a content drop and a live event, from where you have sat?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Give the difference in cadence, scope, what the team coordinates and what gets measured. Then say which of these you have run, in your own words. Answer slot: if you ran or planned a live event, say which and what you did. If you ran only content drops, say so and say what you would do differently for a live event. | F1's gap is the word "live events." The question tests whether the two are being treated as the same thing. |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire someone with no team leadership and no in-app purchase work over someone who has both?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." — your message; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message; [grounded] "Wrote the release checklist our QA team still uses." — your message | Pause, then restate the question in one line. Hold: the case you can make is the calendar and the checklist, which you ran and wrote, in their own words. Concede specifically: "I haven't led a team, and I haven't worked on in-app purchases." Hold through two follow-ups. Never fold on the case you can back. | O1 and O2 are the gaps the question presses on. F6 and F4 are the claims you can hold. |
| D2 | "That calendar. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Separate what you set from what was set for you. Answer slot: if the schedule or priorities were set by others, say so. If you decided parts of it, say which and how. Do not add to the calendar in the answer. | F1 is the attribution probe on the calendar line. Holding the line honestly is the skill. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." — your message; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message; [grounded] "Wrote the release checklist our QA team still uses." — your message; [grounded] "Presented the monthly retention numbers to the studio head." — your message | Run the 90-second arc in this order: the four years, the calendar, the checklist, the retention reporting. Then say why you are here. Use only those four beats. | F5, F1, F4 and F7, in order. Every beat is a sentence you said. |
| E2 | "What live-service games are you playing these days, and what do their events do?" | JD | [generic] | Name two games you actually play. Describe one event in your own words and say what you think it was for. Do not claim you worked on either game. | A casual probe of the JD's live-service requirement. It asks about the market, not about you. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A1, C4 |
| Coordinate design, art, engineering and community teams on each update | A2, B2 |
| Own the post-event review and the KPIs it reports | B4, B5, C1 |
| Manage the release checklist with QA | C2 |
| 3+ years producing live-service games or apps | A4, E2 |
| Experience running a content calendar | C3, E1 |
| Comfortable with player-retention metrics | B1, C1 |
| Clear written communication | none, and why: no question tests written work, and the pack has no writing exercise. The checklist and the retention reporting are the only written evidence. Reverse question 4 asks whether a written exercise exists. |

Coverage note: there are 18 questions. There are no VAL or CO questions, because no values or research were available.

## Reverse questions

Each one has a reason for asking it. None is tied to Tobias's career path, because there is no public profile.

1. "What would a new producer own in the first 90 days that the current calendar does not already cover?" **Why it lands:** it shows you are planning for the role's real scope, not the one you have done.
2. "Are the two titles planned on one shared calendar, or on two?" **Why it lands:** it tests the scope objection in A1, and the answer tells you how to frame the second title.
3. "How does the post-event review get done today, and who owns the KPIs it reports?" **Why it lands:** it asks about the JD's ownership line directly, and it shows you read that line closely.
4. "Is there a written exercise or deliverable in the process, and what is it judged on?" **Why it lands:** the JD asks for clear written communication, and no question in this pack tests it. Asking tells you whether there is a test.
5. "How does monetisation shape the live calendar for these two titles?" **Why it lands:** it asks about the in-app purchase gap as a question about the role, not a claim that you know it.
6. "What would a strong first quarter in this role look like to you?" **Why it lands:** it gives you the bar in the hiring manager's own words, and it is the question most likely to shape how you close.

## Sources

**Provided documents:** your message, which holds the JD text, your background, and the gaps you named. No CV file was supplied.

**Searches and fetches sent:**

- "Saltmarsh Games mobile studio values culture": refused. Web search permission was not granted in this session.
- "Tobias Wrenfield Head of Live Operations Saltmarsh Games": refused, for the same reason.
- No fetch was sent.

**Research tier:** L1 requested; searches 0 of 6 returned results, fetches 0 of 2. Both searches were refused.

**Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, which is dropped. Its query was refused. |
| 2. Saltmarsh Games interview process, live operations producer | unavailable | Loop structure. Search was refused, so no loop source exists and the generic archetype is used with flat weights. |
| 3. Saltmarsh strategy and recent news | unavailable | CO questions, which are absent. No strategy brief was pasted. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Interviewer read and an interviewer-tied reverse question. Its query was refused. |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Web search permission, or a pasted Saltmarsh values page, interview guide or strategy note → the values cheat sheet, the loop structure and CO questions grounded in current strategy.
- Tobias's public profile, or a link to it you can paste → the interviewer read, persona weights tuned to his background, and a reverse question tied to his path.
- The release checklist itself, a redacted content calendar, or the retention slide you presented → an inspectable artifact for F4, F1 and F7, which raises their confidence from medium.
- A writing sample, such as a review or a spec you wrote → an artifact for F8, the only row with no direct evidence of written communication.
- Any take-home or presentation the recruiter has announced → a build section for the deliverable.
- Your prep time before Friday → a prioritised triage, with the few items that matter first.
- A `tuesday-dossier.md`, if one exists → verified evidence and absolute prohibited claims that would replace the locally built list.
