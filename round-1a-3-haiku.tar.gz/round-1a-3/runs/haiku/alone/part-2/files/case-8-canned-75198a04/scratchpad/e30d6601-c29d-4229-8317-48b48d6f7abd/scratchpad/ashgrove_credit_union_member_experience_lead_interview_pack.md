# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**For:** Dara
**Interviews:** 29 November 2026, three rounds (recruiter, 30 min; Head of Member Services, 45 min, your future manager; panel of two branch managers, 60 min, including a 20-minute complaint-escalation case, scored against the four values)
**Built on:** the JD, the recruiter's email, the values copied 20 November 2026, the strategy summary you pasted, and your background as you described it.
**Assumption:** no interviewer names yet, so persona weights follow the round types.

## 1. How to use + type key

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and stop where your material stops.

- **VAL**: behaviour that shows a published value
- **EXP**: what you actually did in your past work
- **JD**: can you do what the job lists, including its gaps
- **CO**: company and strategy knowledge
- **CASE**: a live problem from the role

## 2. Fit snapshot

Quotes are your own words, from the message you sent me. "Your message" marks everything from your background.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | presentation | Say it in those terms: six years in retail banking, three as a branch supervisor. The material shows branch work. Do not stretch it into "customer operations" at scale. |
| F2 | "Own the member complaints process end to end across branches" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | "I handled the branch's formal complaints log." That is one branch's log. Answer slot: if you set any handling steps, say which and how you decided. If the branch set them, say so. |
| F3 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | low | [inferred] | transferability | Your log is "formal", but the material does not say which rules governed it. Answer slot: if a regulator's or ombudsman's complaint rules applied, name them and how you applied them. If the log ran on internal policy only, say so. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: how resolution times were counted, if they were counted at all. Do not supply a method. |
| F5 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | low | [inferred] | transferability | "I trained new tellers on our escalation script." That is tellers, not supervisors. Answer slot: any time you coached a colleague on a hard escalation, in your own words. If you did not, say so. |
| F6 | "work with digital teams on self-service journeys" (JD) | none given | none | — | discovery | Answer slot: if you have worked with a digital team on a journey, say what you did. If not, say so and say how you would start. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | "I haven't presented above regional level." Then how you would prepare: a plan, never a past. |
| F8 | "Comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | transferability | Your material says "spreadsheet", not Excel. Answer slot: name the Excel work you did, in your own words. If you used it only to build the monthly report, say so. |
| F9 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | "I've never worked in a contact centre." Then how you would learn the contact-centre side quickly, as a plan. |

**Gate check:** no requirement here is treated as a gate. If the JD lists a licence, a right-to-work condition or similar, tell me and I'll re-run the snapshot.

## 3. Prohibited claims

These are claims the pack will not coach. Every guidance cell is written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F2 | The branch log, at its own scope. The pack's observation: your material says the branch's log, not an end-to-end process. |
| Handled regulated complaints | Inflated form of F3 | The branch log, at its own scope. The pack's observation: your material does not say the log was regulated. |
| Coached branch supervisors on escalations | Inflated form of F5 | "I trained new tellers on our escalation script." |
| Has contact-centre experience | Stated negative, F9 | "I've never worked in a contact centre." No slot. |
| Has presented to senior leaders | Stated negative, F7 | "I haven't presented above regional level." No slot. |

## 4. Values / principles cheat sheet

The panel scores against these. Your material carries a story for none of them, so each row gives a selection scaffold and its honest branch.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F2 is the nearest thing. Scaffold: pick a time a member's situation changed what you decided, even when it cost the branch something. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. |
| Plain Words | If a member needs it explained twice, the writing was wrong | F5 is the nearest thing. Scaffold: did you ever change how the script was worded so tellers could follow it? If yes, say what changed. If not, say so and say what you would change. |
| Neighbours, Not Numbers | Every branch is part of its town | No row carries it. Scaffold: pick a time a branch's standing in its town shaped how you handled something. If none comes to mind, say so plainly, then give how you would weigh a town's view against a number. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F4 is the nearest thing. Scaffold: pick a complaint you followed past its first answer. If you did not, say so, then say what the spreadsheet showed you and what you did with it. |

## 5. Grounding brief (from the strategy summary you pasted)

These are the summary's own words. They are not checked against the published brief.

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- Main competitive pressure: app-only banks.

Use these terms in answers. Do not quote figures you have not checked against the brief itself.

## 6. Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational (recruiter) | Warm, logistics-first, motivation checks | High: a recruiter screen leans this way | Keep answers short, have the logistics ready, and tie your motivation to the role's real job |
| Skeptic (light, recruiter; full, Head of Member Services) | "Where is your experience thin?" | High: the gaps in F7, F9 and F2 are the ones an interviewer will test first | Concede the gap in one sentence, then return to what you did |
| Case / Strategist (Head of Member Services) | Live problems on the brief's changes | High: the hub and digital changes are the live work | Structure first: what changes, who is affected, what you'd check |
| Peer Evaluator (panel) | "What would you do on my team?" | Medium-high: branch managers price what a hire costs them | Ask what the branches need, then show one concrete thing you'd take on |
| Data-Driven Prober (panel and Head of Member Services) | "How was that counted?" | High: F4 and F8 invite it | Name the counting method you used, or say you do not know it |
| Pressure (rare, but possible from the Head of Member Services) | Interrupts, time-boxes | Low-medium | Hold your position through two follow-ups, then concede precisely |

## 7. Question banks

### Recruiter screen (30 min): Conversational, light Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | What are your pay expectations for this role? | JD | [generic] | Logistics slot. Give your own figure, or ask what the band is first. Do not give a figure you have not chosen. | Recruiter-screen logistics. Pay is a logistics topic, so no reply here adds content. |
| A2 | What notice do you need to give where you are now? | JD | [generic] | Logistics slot. Give your actual notice period, in your own words. | Recruiter-screen logistics. |
| A3 | Where are you based, and what travel can you do? | JD | [generic] | Logistics slot. Say where you are and what travel you can do, in your own words. | Recruiter-screen logistics. |
| A4 | Why are you looking to move on from your current role? | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Give your own reason, in your own words. The material gives no reason, so the slot is yours to fill. Do not invent one. | Logistics and motivation. The reason is for you to set. |
| A5 | Tell me about your current role and what you're proud of. | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I built the monthly complaints spreadsheet our regional manager uses" | Walk the spreadsheet: what it contains, who uses it, in those terms. Add no figures. | F1 and F4 are your strongest material for a conversational opener. |
| A6 | Where would you say your experience is thinnest for this role? | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Say the contact-centre gap and the senior-presenting gap in plain words, then say how you would close each. | The most likely light-skeptic question. F9 and F7 are the honest answers. |

### Head of Member Services (45 min): Case / Strategist, Skeptic, Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | You've never worked in a contact centre, and this role owns the complaints process across one. Why should I believe you can run it? | JD | [grounded] "Never worked in a contact centre" | **Highest-ROI prep in this pack.** Hold, then concede: "I've never worked in a contact centre." Then return to your branch log, the one thing you can describe in detail. Answer slot: what you would learn first, said as a plan, never a past. Hold through two follow-ups by returning to the log. Do not claim cross-channel work. | F9. This is the objection most likely to be raised in some form, and the honest answer is also the strongest one. |
| B2 | Your complaints work was one branch's log. The role runs end to end across branches. What's different? | JD | [grounded] "I handled the branch's formal complaints log" | Say what the log covered and what it did not. Answer slot: if you set any handling steps, say which and how you decided. If the branch set them, say so and stay with the log. | F2. The end-to-end wording is the inflated form, which is listed in section 3. |
| B3 | Which complaint rules governed your log, and who checked it? | EXP | [grounded] "I handled the branch's formal complaints log" | Answer slot: if a regulator's or ombudsman's rules applied, name them and how you applied them. If the log ran on internal policy, say so. If someone else checked it, say who. | F3. Regulated complaints is a stated requirement. The log's rules are unknown to the material. |
| B4 | The brief has eight branches becoming five hubs in 2027. Walk me through what happens to complaints from a branch that closes. | CASE, CO | [generic]; raising source: the strategy summary, "consolidate eight branches into five hubs over 2027" | Structure it: open cases and who owns them, how members are told, what happens to the record, and how you would check that complaints did not slip. Presupposes nothing about your past. | Current strategy is the differentiator. Figures are the summary's; verify them first. |
| B5 | The brief moves 40% of member service to digital by 2028. What does that change for the complaints you'd own? | CASE, CO | [generic]; raising source: JD, "work with digital teams on self-service journeys" | Structure it: what a digital complaint looks like, where it can go wrong, and who owns the handover. Answer slot: if you have worked with a digital team on a journey, say what you did. If not, say so. | F6. The gap is discovery, so the honest answer is the plan. |
| B6 | You've never presented above regional level. How would you present monthly complaint numbers to the executive? | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented above regional level." Then one page: what you'd put on it, in terms of what the monthly report already shows. Add no figures. | F7. A plan, never a past. |
| B7 | A branch supervisor has been handed an escalation she is worried about. What do you do? | JD | [generic]; raising source: JD, "coach branch supervisors on escalations" | Structure it: what you'd ask her first, what the escalation's stake is for the member, and how you'd coach her to decide without you. Presupposes nothing about your past. | F5. Coaching supervisors is a stated requirement with no quote behind it. |

### Panel (60 min): Peer Evaluator, Data-Driven Prober, values scoring

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | Tell me about a time you decided something from the member's side of the counter, even though it cost the branch something. | VAL | [generic] | Selection scaffold: pick a time a member's situation changed what you decided. If no such time comes to mind, say so plainly, then give the nearest thing your material carries (F2), or how you would handle it. | Members First. No quote carries the story. |
| C2 | Tell me about a time you had to explain something to a colleague or a member, and it hadn't landed. | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F5: the script and the tellers. Answer slot: did you change the wording so the script was plainer? If yes, say what changed. If not, say so and say what you would change. | Plain Words. The training is the only story the material carries. |
| C3 | The brief turns eight branches into five hubs. How would you keep a town's complaints from being handled as numbers? | VAL, CO | [generic]; raising source: the published value, "every branch is part of its town" | Selection scaffold: name what a member in a town loses when a branch closes, and what you would do about it. Then your honest branch if no time comes to mind. | Neighbours, Not Numbers. Ties the value to the live strategy. |
| C4 | Tell me about a complaint you followed past its first answer. | VAL | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" | Scaffold: say what the spreadsheet was for, in your words. If it showed open items you followed up, say so. If it did not, say so and say what you did instead. | Own the Fix. The spreadsheet is the only nearby sentence. |
| C5 | Walk me through the spreadsheet. What's in it, and how is a resolution time counted? | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Defend-the-number answer slot: if you counted resolution times, say how. If the figure came from a system, say so. If you do not know how it was counted, say so. Name the assumption you would defend least, in your words. | F4. Figure-level questions are where probers press. |
| C6 | Show me how you'd build a monthly volume and resolution-time report in Excel. | CASE, JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Describe the report's layout first. Answer slot: name the Excel features you have used, in your own words. If you used it only for the monthly report, say so. | F8. The material says spreadsheet, not Excel. |

### Escalation case (20 min, within the panel round)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | Practice case: a member's charge complaint was closed by a branch as "explained". They have since rung the contact centre twice; the second call went to a supervisor with no record of the first. They say they will take it further. What do you do in the next 20 minutes? | CASE, VAL | [generic] | Walkthrough, 20 minutes. **0–3 min, clarify:** what is open, what the member was told, and the deadline (check Ashgrove's policy and the rules that apply). **3–8 min, one owner:** name who holds the case and who can see the one record. **8–13 min, decide:** what the member needs now, who can decide, and what is out of scope. **13–17 min, communicate:** a short message in plain words: what happens next, and by when. **17–20 min, prevent:** what goes to the branch, the contact centre and the digital team, and what you would check in the monthly report. Answer slot: if you have handled a case like this, say how, in your words. If you have not, say so and walk the steps. | Covers the panel's case and the values in one answer: Own the Fix, Plain Words, Members First. The deadline is a fact to verify, not one to assume. |

## 8. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | (Head of Member Services) What would you want fixed in the first 90 days? | Signals you want ownership, not a holding pattern. |
| R2 | (Head of Member Services) How are complaint volumes and resolution times reported today, and who reads them? | Shows you have looked at the reporting part of the role. |
| R3 | (Head of Member Services) As branches move into hubs, how should complaints from a closing branch be handled? | Shows you have read the brief and care about the towns. |
| R4 | (Head of Member Services) How far has the digital team got with self-service journeys for complaints? | Shows you have read the JD's digital line and want to know where things stand. |
| R5 (reciprocity, panel) | (Panel) What could a new person do in their first month that would genuinely help your branches? | Turns the panel into a working conversation, the peer signal they weight. |
| R6 (panel) | (Panel) When a complaint escalates from a branch, what usually makes it stall? | Shows you want the real problem, not the policy answer. |

## 9. Requirement coverage

| JD requirement | Questions |
|---|---|
| 4+ years in financial-services customer operations | A5, F1 |
| Own the complaints process end to end across branches and the contact centre | B1, B2, F2, F9 |
| Experience handling regulated complaints | B3, D1 (F3) |
| Report monthly on complaint volumes and resolution times | C5, B6, F4 |
| Coach branch supervisors on escalations | B7, C2 (F5) |
| Work with digital teams on self-service journeys | B5 (F6) |
| Confident presenting to senior leaders | B6 (F7) |
| Comfortable with Excel reporting | C6, F8 |

## 10. Sources

**Provided documents:** the JD (your message); the recruiter's email (your message); the values, copied 20 November 2026 (your message); the strategy summary (your message, a summary rather than the brief itself); your background (your message).

**Research tier: L0.** I ran no searches and fetched nothing. Each research target's output was already fixed by the pasted inputs, so the accounting below says so.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | skipped | Pasted values fix section 4 |
| 2. Interview process | skipped | The recruiter's email fixes the three rounds and their content |
| 3. Strategy / recent news | skipped | The pasted summary fixes section 5 and the CO questions |
| 4. Interviewer name and footprint | n/a | No names given |
| 5. Representative JD | skipped | Your JD fixes the fit snapshot |

**Verify before you rely on these:**
- The strategy figures (40%, eight to five, Q1 2027, app-only pressure). I have only your summary.
- The values wording on the site, against the copy you made.
- The complaint deadlines and which regulator or ombudsman scheme applies. This depends on the jurisdiction and Ashgrove's own policy.
- That "formal complaints" in your log were regulated. The material does not say.
- Whether the spreadsheet tracks resolution times, and how.
- The format of the 20-minute case: whether you will see it in advance, and how it is scored.

## 11. Upgrade menu

- The Head of Member Services' name and public footprint → a tailored reverse question and persona weights based on their path.
- The strategy brief itself → checks sections 5 and B4, B5 and C3 against the source.
- The 20-minute case's format → D1 tuned to what the panel will score.
- Which rules governed your complaints log → F3, B3 and D1 become grounded.
- How resolution times were counted, if they were → F4 and C5 become grounded.
- Any Excel work you have done → F8 and C6 become grounded.
- Any digital-team work → F6 and B5 become grounded.
- Any coaching of colleagues on escalations → F5 and B7 become grounded.
- Prep time available → a prioritised schedule.
- A `tuesday-dossier.md` from a job-underwriter run → would carry verified evidence and an objection ranking forward between sessions.
