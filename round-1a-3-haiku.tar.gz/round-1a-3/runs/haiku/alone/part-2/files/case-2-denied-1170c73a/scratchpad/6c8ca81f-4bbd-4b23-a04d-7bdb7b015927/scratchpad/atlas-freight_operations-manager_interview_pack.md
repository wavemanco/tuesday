# Interview prep pack: Operations Manager, Atlas Freight

Role: Operations Manager. Company: Atlas Freight (regional logistics, 800 employees, per your JD). Interviewer: not named. Round: assumed hiring-manager round, since your note did not say who you are meeting.

## How to use

- **Personas** are how a question is asked. **Types** are what it scores.
- Type key: **JD** = the role's stated responsibilities and qualifications. **EXP** = whether your past work holds up under scrutiny. **CASE** = a live problem from the role, reasoned aloud. **VAL** = values fit (none detected here). **CO** = company strategy knowledge (none built, because research did not run; see Sources).
- Guidance is scaffolding, not a script. Say things in your own words. Speakable in 90 to 120 seconds.
- Answer slots are instructions for the interview. They are not questions to answer here.

## Fit snapshot

Requirements are the JD's own words. Evidence is your own sentences, verbatim, with the source named. Source for every row is the JD you supplied and your message, since no CV was given.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "currently a senior shift manager over 3 supervisors" (your message); "7 years in warehouse and distribution ops" (your message) | medium | [grounded] | transferability | Your material shows a shift role over 3 supervisors. It does not show four sites or a terminal. Words for you: "I'm a senior shift manager over 3 supervisors." Answer slot: if you have run any routine across more than one site, say which and what your part was; if not, say so, and say how you would set the daily rhythm for the first site. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your result is pick accuracy, not on-time performance or cost per shipment. Say the result as it is and let the interviewer make the link. Answer slot: if you tracked on-time or cost for that change, say what moved; if you did not, say so plainly. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows 3 supervisors, not 12. Words for you: "I manage 3 supervisors." The scale gap is the thing to name first, before anyone else does. |
| F4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | low | [grounded] | discovery | Your material shows 7 years in operations, and does not show how long you have led people. This is a length-of-experience requirement, not a gate. Answer slot: state when you first held a leadership role, from your own records. |
| F5 | "build reporting in Excel/Power BI" (JD), Excel part | "solid Excel" (your message) | low | [grounded] | discovery | Your material says you are strong in Excel, not what you built in it. Answer slot: name one report you built or changed, what it fed, and who used it. If none, say so and say what you would build first. |
| F6 | "build reporting in Excel/Power BI" (JD), Power BI part | "never used Power BI" (your message) | none | [grounded] | capability | You stated the absence. Words for you: "I haven't used Power BI." Then how you would close it, said as a plan and never as a past: for example, a first dashboard on a metric the team already agrees matters. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. Words for you: "I'm Green Belt certified." No certificate has been inspected, so expect a question on which project it covered. Answer slot: if you applied the Green Belt method to the pick path, name the steps you took; if not, say so. |

Gap types follow the routing rule in the reference: F1, F2 and F3 are adjacent work that does not reach the requirement. F4 and F5 are evidence that may exist and is not shown. F6 is a negative you stated. F7 is reached by a quote.

No row is a gate. The JD has no location, travel, schedule or credential requirement beyond the Lean/Six Sigma plus, so no gate question is needed.

## Prohibited claims

Things this pack will not coach you to say, and why. Each one is a stretched version of something you actually wrote, or a negative you already stated.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operations across four sites | Inflated form of "the site's" in your message (F1) | Your quote at its own scope: "currently a senior shift manager over 3 supervisors." Your material says one site's shifts, not four. |
| Leads 12 supervisors | Inflated form of "over 3 supervisors" (F3) | "I manage 3 supervisors." |
| Has Power BI experience, or built Power BI dashboards | Negative you stated (F6) | "I haven't used Power BI." Plain acknowledgment, no slot. |
| Built the reporting for a site | Inflated form of "solid Excel" (F5) | "solid Excel." Any report you built goes in the answer slot, in your own words. |
| Set the Lean method for the pick-path redesign | Practice your message does not state (F7 and F2) | "cut mis-pick rate 40% by redesigning the pick path." Whether a Lean method was used is an answer slot, not a claim. |
| Cut cost per shipment, or improved on-time performance | Widening of the mis-pick result (F2) | "cut mis-pick rate 40% by redesigning the pick path," at its own scope. |

Pack observation, not words for you: your material does not show multi-site work, a team of 12, Power BI, or on-time or cost results. Those are gaps, and the honest answer to each is in the fit snapshot.

## Persona table

| Persona | How it shows up in this loop | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the scale gap (3 to 12, one site to four) and the tool gap (Power BI). | Weight 5. Hiring-manager prior, and the JD names requirements your message does not cover. Highest weight because the gaps are the largest risk. | Rehearse A2 until it is boring. Name the gap first, then the step you would take. |
| Case / Strategist | Live problems on sites, on-time performance and cost. | Weight 4. Hiring-manager prior, and the JD's outcome metrics are the natural case material. | Clarify before structuring. Name the denominator. Say the approach aloud. |
| Data-Driven Prober | Asks how the 40% was counted and what it is sensitive to. | Weight 3. Your one headline figure is the prober's natural target. | Say what you can and cannot say about the count. Name the weakest assumption before they do. |
| Pressure / Stress | Time-boxed challenge to your leadership claim and to the mis-pick result. | Weight 3. Kept mid-weight because round type is unknown. | Pause, restate, hold through two follow-ups, then concede what is not yours. |
| Peer Evaluator | Seam questions about planning and disagreement with equals. | Weight 2. Touched, not weighted, because the round is probably not a peer round. | Propose seam principles. Do not invent a story. |
| Conversational / Rapport | Opening "walk me through" and a casual tool question. | Weight 2. Common opener, and the JD's Power BI line may be asked casually. | Pre-script a 90-second arc. Treat casual questions as scored. |

## Question banks

Ordered by weight. Provenance carries the sentences each guidance cell rests on. Answer slots are instructions for the interview.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message); "never used Power BI" (your message) | Name the two gaps the material shows, in your own order: scale (3 supervisors and one site, against 12 and four) and reporting tools (Power BI). For each, one step you would take in the first month. About 60 seconds. | F1, F3 and F6 are the rows this draws on. Naming the gap first is the non-defensive move. |
| A2 | "You lead three supervisors today. This role leads twelve across four sites. What's the step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | **Highest-ROI prep in this pack.** This is the most predictable objection. Hold: "I manage 3 supervisors." Concede the gap plainly, then: answer slot, if you have led more people or more than one site's shifts, say how many and what part you led; if not, say so, and describe the first month you would spend learning the 12. Hold through two follow-ups by returning to what you lead today. Never fold to "I can handle 12." | F3 and F1. The deepest rehearsal goes here because the objection is aimed at the thinnest part of your material. The premise is the JD's line, and your own quote is the only fact you hold. |
| A3 | "How would you run daily terminal operations across four sites?" | JD | [grounded] "Own daily terminal operations across 4 sites" (JD) | Speak to the principle: one daily rhythm across sites, one set of measures, and who owns each. Answer slot: if you have run any cross-site routine, say which and your part in it; if not, say so and say what you would do in the first 30 days. | F1. The JD raises multi-site operations, so the probe is fair. Guidance is a plan, not a past claim. |
| A4 | "How long have you been in a leadership role?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Give the start date of your first leadership role, from your own records, and say how you counted it. No figure is supplied here. If you are not sure, say how you would count it. | F4. The 5+ years requirement is length of experience, not a gate, so it is answered with your own dates. |
| A5 | "The posting asks for Excel and Power BI reporting. Which have you built, and for whom?" | JD | [grounded] "solid Excel, never used Power BI" (your message) | Power BI: "I haven't used Power BI," then how you would learn it, as a plan. Excel: answer slot, name one report you built or changed, what it fed, and who used it. If none, say so. | F5 and F6. The question is an open prompt, so it allows the honest no. |

### B. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "One site is behind on on-time performance this month. Where do you start?" | CASE | [generic] | Clarify first: what counts as late, which shifts, which lanes, what changed. Then split the lateness by site, shift and lane before choosing a lever. Think aloud. Challenge one premise respectfully. | A live problem from the JD's on-time line. No claim about your past. |
| B2 | "The posting puts on-time and cost-per-shipment first. Which would you move first at a site behind on both?" | JD | [generic] | Name the measure you would trust first, and why. Then the lever you would test first, and what would make you stop. | The JD's outcome metrics, asked as a choice. No claim about your past. |
| B3 | "Volume is up 20 percent on last year, and two supervisors are out for the peak week. What do you do?" | CASE | [generic] | Clarify what the 20 percent is measured against. Cover the two gaps first, then decide on staffing, overtime and the order of work. Say what you would not do. | A live problem from the role's peak-season and team scope. No claim about your past. |
| B4 | "What would the first three reports you'd build for a site leader contain?" | JD | [generic] | Name three reports. For each, the metric, the decision it drives, and the tool you would build it in. Be honest that you would start in Excel. | The JD's reporting line. Speaks to the design of a report, not to a report you built. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40 percent mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Say what you can and cannot say about the count. Answer slot: if the baseline came from a count, say which count and which period; if no baseline was recorded, say so plainly. Then say which part was yours. | F2. Defend-the-number: the figure is yours and will be probed. Guidance supplies no method. |
| C2 | "Which assumption behind that 40 percent would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name, in your own words, the assumption you would defend least. If you do not know one, say that you do not know how it was counted. Do not offer a sizing method or a baseline you did not state. | F2. The weakest-assumption move, rehearsed so the honest answer is ready. |
| C3 | "The posting puts on-time and cost-per-shipment first. Did your pick-path work touch either?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold to what you measured: mis-pick accuracy. Answer slot: if you tracked on-time or cost for that change, say what moved; if you did not, say so plainly. Do not extend the 40 percent to cost. | F2. The honest bridge is a limit, not a stretch. |

### D. Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run four sites?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message); "ran the site's peak-season surge plan two years running" (your message) | Pause, then restate the question. Name what you bring that is specific: the pick-path result and the peak plan you ran two years running. Concede the scale gap before they press it. Hold through two follow-ups. | F1 and F2. Hold-then-concede: never claim four-site experience to win the exchange. |
| D2 | "That mis-pick result. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold the claim at its scope: you redesigned the pick path, and the rate fell. Answer slot: if others did the floor work, say who and what you did; if the redesign was yours, say so. Concede what you cannot attribute exactly. | F2. The attribution probe, rehearsed as candor. |
| D3 | "Why should twelve supervisors trust a manager whose team is three?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Hold: the three you lead is the evidence you have. Concede that twelve is untested. Name the step you would take to earn their trust, as a plan. Do not describe a trust you have not been shown. | F3. Pressure on the scale gap, held without defensiveness. |

### E. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our planning team and yours sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles: who owns the schedule, who owns the forecast, and who decides when they conflict. Answer slot: if you have disagreed with a peer team and resolved it, say how; if not, say so. | A seam probe. Principles, not a story you do not have. |
| E2 | "What would you need from me in your first month?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Ask for something concrete: the forecast, a seat in the planning meeting, the site data. Offer what you bring their team, and only what you have shown: the pick-path method you used. | Reciprocity, anchored in your one quoted result. |

### F. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message); "ran the site's peak-season surge plan two years running" (your message) | A 90-second arc: where you started, the pick-path result, the peak plan, and where you are now. Hold to these facts. Add no role, no title and no site. | Common opener. Scored casually. |
| F2 | "What's your reporting setup today?" | JD | [grounded] "solid Excel, never used Power BI" (your message) | Say what you use: Excel. Then, plainly, that you have not used Power BI. Answer slot: name the reports you produce today, if any, and who reads them. | F5 and F6. Asked casually, the Power BI question is still scored. |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own daily terminal operations across 4 sites | A3, A2, D1 |
| Drive on-time performance and cost-per-shipment down | B1, B2, C3 |
| Lead a team of 12 supervisors | A2, D3, F1 |
| Build reporting in Excel/Power BI | A5, B4, F2 |
| 5+ years operations leadership required | A4 |
| Lean/Six Sigma a plus | none, and why: "green belt certified" already reaches it (F7). The project question sits in the upgrade menu, not in the bank. |

Totals: 19 questions across six personas.

## Reverse questions

Each one has a reason it lands. No profile exists for the interviewer, so these are role-generic.

1. "What does success look like at six months, across the four sites?" Why it lands: shows you think in outcomes, not tasks.
2. "Which site is furthest from its on-time target, and what is driving it?" Why it lands: shows you will start on the metric the JD names first.
3. "How are the twelve supervisors split across sites today, and where is the span of control stretched?" Why it lands: tests the scale gap directly, in their terms.
4. "What reporting do the sites use now, and what do leaders wish they could see?" Why it lands: surfaces the Excel and Power BI picture from their side.
5. "What is the team's biggest constraint going into the next peak season?" Why it lands: ties to the peak-plan work in your message.
6. "How will the cost-per-shipment target be measured, and who owns the baseline?" Why it lands: asks the question a prober would ask, as a planning question.

## Sources

Provided documents: the JD and your background message. No CV, no interviewer profile, no recruiter guidance, no company document.

Research tier: L1 — searches 3 of 6 (all refused, nothing returned), fetches 0 of 2 (none attempted). Web search was not permitted in this session, so the company values, interview process and strategy targets are unavailable. Nothing about Atlas Freight beyond the JD is in this pack.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Values cheat sheet. Query "Atlas Freight values" was refused. |
| 2. `Atlas Freight interview process operations manager` | unavailable | Loop structure and persona weights. Query was refused. Weights above use the hiring-manager prior, with no loop source. |
| 3. `Atlas Freight regional logistics strategy news` | unavailable | CO bank and grounding brief. Query was refused. CO questions were not built. |
| 4. `{interviewer name} Atlas Freight` | n/a | No interviewer name was given, so there was no query to form. |
| 5. representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

No values-style round is detected. No loop source establishes the loop, and the fallback archetype reads `no` for a values round, so no values cheat sheet is built.

## Upgrade menu

- Who you are meeting, and whether they are your future manager, a peer or a skip-level → reweights every persona bank and tailors the reverse questions. Asked in the message that presents this pack.
- Your first leadership start date → F4's answer slot becomes a number you state.
- Green Belt certificate and the project it covered → F7 moves from medium to high, and the project question gets an answer.
- Interviewer's name → an interviewer read, persona weights from their public footprint, and a tailored reverse question. Web search would be needed, and it is not permitted in this session.
- The Atlas Freight values page, pasted → the values cheat sheet and the VAL questions. Pasting it is enough; search is not needed.
- A recruiter email on the focus areas and process → loop structure, and any pre-declared deliverable.
- Power BI or any reporting you have built in Excel → F5 and F6 move from discovery and capability to a named, grounded answer.
