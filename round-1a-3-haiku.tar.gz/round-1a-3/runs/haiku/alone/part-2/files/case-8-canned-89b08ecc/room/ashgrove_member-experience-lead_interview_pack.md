# Ashgrove Credit Union: Member Experience Lead interview pack

**For:** Dara. **Built:** 20 November 2026. **Interviews:** 29 November 2026.

- **Round 1, recruiter:** 30 minutes.
- **Round 2, Head of Member Services (your future manager):** 45 minutes, mostly behavioural. Name not yet known.
- **Round 3, panel of two branch managers:** 60 minutes, including a 20-minute complaint-escalation case. The panel also scores the values round against the four values. Names not yet known.

## How to use this pack

- **Personas** are how a question arrives. **Types** are what is being scored.
- **Type key:** VAL = behavioural and values. EXP = your own work experience. JD = the listed job. CO = company and strategy. CASE = a live problem with no past in it.
- **Guidance is scaffolding, not a script.** Say it in your own words, and only what you actually did.
- **Provenance labels:** `[grounded]` traces to something you or the recruiter wrote. `[inferred]` is this pack's derivation. `[generic]` is a pattern for the role, not a fact about you or Ashgrove.
- **Answer slots** are instructions for the interview. They are not questions to answer here.

## 1. Fit snapshot

Requirements are the JD's own words. Evidence is your own sentences, quoted exactly. Where the material is silent, the pack says so and does not fill the gap.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material shows one branch's log. The end-to-end process across branches and a contact centre is not shown. Say the log at its own scope: "I handled the branch's formal complaints log." Answer slot: if you set any stage of how that log ran, say which and how you decided, in your own words. If no stage was yours to set, say so and stay with the log. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | low | [inferred] | discovery | Your material does not say whether the formal log was regulated. This is the pack's inference that "formal" may or may not mean regulated. It is not a claim you have made. Answer slot: if the formal complaints carried deadlines or a referral route you had to follow, say which and how you worked to them. If they did not, say what made a complaint formal in your branch. |
| F3 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message); "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | transferability | Say it at its own scope: "I trained new tellers on our escalation script." Those were tellers, and your material does not show coaching a supervisor. Answer slot: if you coached a supervisor on an escalation, say what the case was and what you changed. If you did not, say so and say how you trained the tellers. |
| F4 | "report monthly on complaint volumes" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote already reaches the requirement in role terms. Say it as written: "I built the monthly complaints spreadsheet our regional manager uses." It does not show what the spreadsheet counted. F5 and E1 cover that. |
| F5 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] | discovery | Your material does not show whether the report includes resolution times. Answer slot: if the spreadsheet recorded how long complaints took to resolve, say what it measured and how you counted it. If it did not, say so and say what you would add. |
| F6 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | none | The quote reaches the requirement. No gap. Do not bring member data to show the spreadsheet. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Your words: "I've never presented to anyone above regional level." Answer slot: say how you would learn to present to senior leaders, as a plan. Never describe it as something you have done. |
| F8 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. Say it as written. The years are a length requirement, not a gate. |
| F9 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Your words: "I've never worked in a contact centre." Answer slot: say how you would learn how a contact centre runs, as a plan. |
| F10 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent on digital work. Answer slot: if you have worked on a self-service journey or alongside a digital team, say what it was and what part was yours. If you have not, say so and say how you would start. |

**Gap types in one line each.** F1, F3 and F4 are transferable or presentation gaps: real work, short of the JD's scope. F2, F5 and F10 are discovery gaps: your material does not show them either way. F7 and F9 are capability gaps: you have stated the absence yourself, so the pack gives your words back and asks only for a plan.

## 2. Prohibited claims

These claims are not coached anywhere in this pack. Each has a basis and an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F1 | "I handled the branch's formal complaints log." The pack's observation: your material shows one branch's log, not the end-to-end process. |
| Has contact-centre experience | Negative you stated, F9 | "I've never worked in a contact centre." |
| Presented to senior leaders | Negative you stated, F7 | "I've never presented to anyone above regional level." |
| Has handled regulated complaints | Inflated form of F2 | The formal log, at its own scope. Your material does not show whether it was regulated. |
| Coached branch supervisors on escalations | Inflated form of F3 | "I trained new tellers on our escalation script." |
| Tracks resolution times in the monthly report | Inflated form of F5 | The spreadsheet quote at its own scope. Resolution times are an answer slot only. |

## 3. Grounding brief

From your summary of the July 2026 strategy brief, not from the document itself. Check the exact wording before you quote it in the interview.

| Topic | Current statement (your message) | Shapes which questions |
|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | D1, A3 |
| Branch network | "consolidate eight branches into five hubs over 2027" | D2, A3 |
| Small business | "launch a small-business lending product in Q1 2027" | Reverse question 4 |
| Competition | "the main competitive pressure is app-only banks" | Reverse question 3 |

No stale framings were flagged in what you sent.

## 4. Persona weights

Interviewer names are not known, so there is no interviewer read. Weights come from the relationship priors, shown with their reasoning.

| Persona | How it shows up in this loop | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Round 1, the recruiter's screen. Logistics questions in a friendly register. | Top weight in round 1. A recruiter screen is the friendly round, but its logistics are scored. | Pre-scripted 90-second arc. Treat logistics as scored. Give your own answers. |
| Skeptic | Round 2, the Head of Member Services. Probes the contact-centre and presenting gaps. | Top weight in round 2. A manager's round is about derisking gaps, and F7 and F9 are the two largest. | Rehearse B1 until it is plain. Hold, then concede one specific thing. |
| Values / behavioural | Round 2 for behavioural stories. Round 3 for the four values, scored by the panel. | Mid weight in round 2, top weight in round 3. The recruiter wrote that the panel "is also the values round". | One story per value, or a selection scaffold with its honest branch. |
| Case / strategist | Round 2 for two strategy questions. Round 3 for the 20-minute escalation case. | Mid weight. The strategy questions come from the brief. The escalation case is in the panel's round. | Clarify, structure, then answer. Name the weakest assumption you hold. |
| Data-driven prober | Round 3. Branch managers will read the complaints report. | Mid weight in round 3 only. The panel is branch managers, not analysts, so probes stay light. | Defend only what you built. Say "I don't know" when that is true. |
| Pressure | Not weighted. No signal in the loop. | Low. The hold-then-concede in B1 covers it. | None needed separately. |
| Peer | Not weighted. No peer in the loop. | Low. | None needed. |

Depth follows weight. Round 1 has five questions, round 2 has nine, and round 3 has six.

## 5. Question banks

Questions are grouped by persona, and the round is shown in each heading.

### A. Conversational: Round 1, recruiter screen

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What's your notice period, and when could you start?" | JD | [grounded] "Three rounds on 29 November: 30 minutes with me" (recruiter's email) | Logistics slot. Give your actual notice period, in your own words. Your material gives no figure, so none is suggested. | Notice is a knockout check. The slot is the candidate's own answer. |
| A2 | "What salary range are you targeting?" | JD | [grounded] "Three rounds on 29 November: 30 minutes with me" (recruiter's email) | Logistics slot. Give your own number, or ask first what the band for this role is. Do not offer a figure you have not decided on. | Pay is a logistics slot. No pay figure appears in your material, so none appears here. |
| A3 | "Eight branches are moving into five hubs during 2027. Where can you work from?" | JD | [grounded] "consolidate eight branches into five hubs over 2027" (your message) | Logistics slot. State your location constraint once, in your own words. If you have none, say so. | Location is a logistics slot. The hub plan is the recruiter's own brief. |
| A4 | "Why are you looking to leave your current role?" | EXP | [generic] | Reason-for-leaving slot. Give the reason in your own words. Keep it about the work you want, not the branch or its people. Your material gives no reason, so none is suggested. | Reason for leaving is a logistics slot. The question names no occasion and presupposes nothing about your past. |
| A5 | "Walk me through your background in two minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc, in this order: the six years and the three as supervisor, then the formal complaints log, then the spreadsheet. Use the words above. Do not add contact-centre or senior-presenting experience. Name those gaps when B1 and B3 come up. | Open prompt. Every beat is a quoted sentence, so the interviewer hears only what you did. F8, F1 and F4 carry it. |

### B. Skeptic: Round 2, Head of Member Services

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked in a contact centre. What makes you confident you can own the complaints process across one?" | JD | [grounded] "Never worked in a contact centre" (your message) | **Highest-ROI prep in this pack.** Hold, then concede. Hold: the process you have run is a branch's, and say what you ran. Concede in one specific sentence: "I haven't worked in a contact centre, and I'd need to learn how one runs before I changed anything." Then say how you would learn it, as a plan. On the second follow-up, return to the branch log, not to a claim about the contact centre. | The largest gap against the JD's "across branches and the contact centre" (F9). A manager will press it. The premise is your own stated negative. |
| B2 | "Tell me about a formal complaint you handled. What made it formal, and what happened?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Open prompt. Story-map from the log: the formal complaints, and what you did with one. Answer slot: if the formal complaints carried deadlines you had to meet, say which and how you worked to them. If they did not, say so and describe how formal complaints were tracked. | The JD raises regulated complaints. F2 is low confidence, so the question asks rather than asserts that the log was regulated. |
| B3 | "You'd be presenting monthly to senior leaders. How would you prepare for that?" | JD | [grounded] "I've never presented to anyone above regional level" (your message); "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Say plainly that you have not presented above regional level. Then say how you would prepare: start from the report you already build, and have someone senior test one page before the room sees it. Answer slot: say how you would learn to present to senior leaders, as a plan. Never describe a senior presentation as past. | F7 is a capability gap. The guidance gives your own words back and asks for a plan, which is the form the gap allows. |
| B4 | "Why should I trust you to coach supervisors on escalations when your training experience was with tellers?" | JD | [grounded] "trained new tellers on our escalation script" (your message) | Hold, then concede the scope. Hold: the escalation script is what you taught, and a supervisor's job is the decision that follows it. Concede the scope in one sentence. Answer slot: if you coached a supervisor on an escalation, say which case. If you have not, say so. Second follow-up: say how you would check a new supervisor's escalation decisions. | F3 is a transferability gap. The challenge names only what you stated. |

### C. Values and behavioural: Round 2 (C1, C2) and Round 3 (C3 to C6)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a complaint that ran long. What did you do?" | VAL | [grounded] "Own the member complaints process end to end across branches and the contact centre" (JD) | Open prompt, with its theme from the JD line. Selection criteria: pick a complaint you kept hold of past its first handler, with a stake, what you did next, and how it ended. If none comes to mind, say so plainly, then give the nearest thing your material carries: the formal log you kept. | None of your quoted sentences carries a long-running complaint, so this is a selection scaffold with its honest branch. |
| C2 | "Tell me about a time you had to tell a supervisor their escalation decision was wrong." | JD | [grounded] "coach branch supervisors on escalations" (JD) | Open prompt. Selection criteria: pick a time you challenged a decision, with what you said, what they did, and the result. If none comes to mind, say so, then give the nearest thing your material carries: the escalation script you taught tellers, and say its scope. | Supervisor coaching is the JD's line. No quoted sentence carries a challenge to a supervisor, so the guidance is a scaffold. |
| C3 | "Tell me about a time you put a member's side ahead of the rule." | VAL | [grounded] "Members First, Always: we decide from the member's side of the counter" (values page); "I handled the branch's formal complaints log" (your message) | Selection criteria: pick a decision that went against procedure or the easy answer for a member. It needs what the member asked for, what you decided and why, and the result. If none comes to mind, say so. Then give the nearest thing your material carries: the formal log, and say what you decided from the member's side in it. If no such decision is in that log, say so. | Members First is scored in the panel's values round. No quoted sentence carries a member-side decision, so this is a selection scaffold. |
| C4 | "How do you write a complaint response a member can act on the first time?" | VAL | [grounded] "if a member needs it explained twice, we wrote it wrong" (values page); "trained new tellers on our escalation script" (your message) | Selection criteria: if you wrote or changed a letter, script or template so members understood it, say what changed and how you knew. If you did not, say so, then give the nearest thing: the escalation script you trained tellers on, and what the script was for. | Plain Words is scored by the panel. Your nearest sentence is about training, not about member wording, so the guidance does not stretch it. |
| C5 | "Tell me about a time something about a branch's local area changed how you handled a complaint." | VAL | [grounded] "Neighbours, Not Numbers: every branch is part of its town" (values page) | Selection criteria: pick a case where something local changed the decision. If none comes to mind, say so plainly, and say how you would learn what a town expects from its branch. | None of your quoted sentences speaks to a branch's place in its town, so the honest branch is the answer. |
| C6 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "Own the Fix: whoever finds the problem keeps hold of it until it is solved" (values page); "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Answer slot: if the spreadsheet showed a pattern you then followed through on, say what it was, who you took it to, and when it closed. If it did not, say so, then give the nearest thing: the log you kept, and how you knew a case was still open. | The spreadsheet is the nearest sentence, but the material does not show follow-through, so the guidance asks rather than assumes it. |

### D. Case and strategist: Round 2 (D1, D2) and Round 3 (D3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "We want to move 40% of member service to digital channels by 2028. What would you do first for complaints?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your message); "work with digital teams on self-service journeys" (JD) | Clarify first: which complaints arrive through which channel today, and how you would count them. Structure: segment by channel, then ask what drives complaints in a digital journey, then what a self-service journey has to do so a member does not need to complain. Name the assumption you would test first. Answer slot: if you have worked on a self-service journey, say what it was and your part. If you have not, say so and say how you would start with the digital team. | The strategy figure is the recruiter's own. The self-service line is the JD's, which raises it. |
| D2 | "Eight branches become five hubs in 2027. What happens to the complaints open in the branches that close?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" (your message); "I handled the branch's formal complaints log" (your message) | Clarify: which complaints are open, who holds each one, and what the member was last told. Structure: keep each open case with a named owner through the move, then decide how members in closing branches reach the complaints process. Name the risk you would check first. Your branch's log is the nearest experience, so say that scope. Answer slot: if you have managed a branch change, say what. If not, say so and describe how you would check open cases before the move. | A live problem from the strategy brief. It asks nothing about your past except through the answer slot. |
| D3 | "A member has complained three times about the same fee, and each branch gave a different answer. The case is now with the contact centre, and the branch manager wants it closed today. What do you do?" | CASE | [generic] | The 20-minute case. Spend three minutes on structure, then answer. (1) Clarify what the member was told, what they asked for, and whether it is a formal complaint with a clock. (2) Keep one named owner. Do not close it by handing it on. (3) Decide the fix from the member's side. (4) If the fix sits outside the branch, escalate with a named person and a date. (5) Coach the supervisor on the decision, not only the result. (6) Record what you decided and why. Expect the branch manager to push for a close. Hold the member-side fix until you have checked the facts, then say what you would tell them. | The recruiter's "20-minute case on a complaint escalation" and the JD's coaching line. The case is hypothetical, so it presupposes nothing about you. |

### E. Data-driven prober: Round 3, panel

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "What did your monthly complaints spreadsheet count, and how did you count it?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Defend the count in your own words, and name only what you built. Name the assumption behind the count you would defend least, if you know one. If you do not know how a count was done in the regional template, say so. Answer slot: if you built a column or a count, say which and why. If the regional manager set it, say that. | The spreadsheet is the one number-bearing artefact in your material. F4 covers it. |
| E2 | "If the regional manager asked for resolution times next month, what would have to change in that spreadsheet?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Answer slot: say whether the spreadsheet holds dates for when a complaint opened and closed. If it does, say how you would work out the time. If it does not, say what you would add first and who would check it. | F5 is a discovery gap. The guidance asks, and does not assume resolution times exist. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the member complaints process end to end | B2, C1, D2 |
| across branches and the contact centre | B1, D2 |
| report monthly on complaint volumes | A5, E1 |
| resolution times | E2 |
| coach branch supervisors on escalations | B4, C2, D3 |
| work with digital teams on self-service journeys | D1 |
| 4+ years in financial-services customer operations | A5 |
| experience handling regulated complaints | B2 |
| confident presenting to senior leaders | B3 |
| comfortable with Excel reporting | E1, E2 |

**Highest-ROI prep:** B1. This is the objection the pack expects you to meet in some form, so rehearse the hold-then-concede until it sounds like you.

## 6. Values cheat sheet

Included because the recruiter wrote that the panel "is also the values round". Values are paraphrased; the official names are used.

| Value | Working meaning | Mapped story | Question |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | No story is carried by your quoted sentences. Selection scaffold, honest branch: say so if none comes to mind, then give the formal log at its own scope. | C3 |
| Plain Words | If a member needs it explained twice, the writing was wrong. | No story is carried by your quoted sentences. Selection scaffold, honest branch: say what you changed if you changed any wording, or say you did not. | C4 |
| Neighbours, Not Numbers | Every branch is part of its town. | No story is carried by your quoted sentences. Selection scaffold, honest branch: say how you would learn what a town expects from its branch. | C5 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | Your sentence "I built the monthly complaints spreadsheet our regional manager uses" is the nearest, but it does not show follow-through. Answer slot, honest branch: say whether a pattern you found was followed to a close. | C6 |

## 7. Reverse questions

Each one is for the end of the interview. Ask two or three, not all six.

| Question | Why it lands |
|---|---|
| "What would make the first six months a success for complaint resolution times?" | Shows you are thinking in the report's own metrics, which the JD names. |
| "When the eight branches become five hubs, who owns the open complaints during the move?" | Ties the hub plan to the Own the Fix value and shows you have read the brief. |
| "Where do self-service complaints get logged today, and who owns the handoff to a branch?" | Shows you know the digital shift is a complaints question too. |
| "How will the small-business lending launch be built into the complaints process before Q1 2027?" | Shows you have read the brief's product timeline and are planning ahead of it. |
| "What does 'own the fix' look like when a fix needs the digital team or IT?" | Tests the value against a real seam. Shows you take it seriously. |
| "How do the branch managers on the panel use the monthly complaints report today?" | Links the reporting to the people who will judge it, and gives you a read on their expectations. |

## 8. Prohibited claims: where they bind

Every answer, bridge, hold, rationale and reverse question is checked against section 2. Nothing in this pack says you have contact-centre experience, have presented to senior leaders, have handled regulated complaints, or have coached supervisors. Those claims were built locally, from your own sentences.

## 9. Sources

- **Provided documents:** the JD text, the recruiter's email, the Ashgrove values as you copied them on 20 November 2026, your summary of the July 2026 strategy brief, and your background, all from your message.
- **Research:** none run.
- **Research tier:** L1, searches 0 of 6, fetches 0 of 2. The default tier was not used because every research target below is fixed by your inputs.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Section 6. The values you copied fix it, so no search was needed. |
| 2. Ashgrove interview process, customer operations | skipped | Loop structure and persona weights. The recruiter's email fixes both. |
| 3. Ashgrove strategy and recent news | skipped | Section 3 and the strategy questions. Your summary of the brief fixes them. Recent news would add to the grounding brief. |
| 4. Interviewer name and Ashgrove | n/a | No interviewer names were given, so there was no query to form. The interviewer read is absent. |
| 5. Representative customer-operations JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions. |

## 10. Upgrade menu

- **Round 2 and round 3 interviewer names** → an interviewer read, a tailored reverse question, and persona weights for each panel member, from their public footprint.
- **The strategy brief itself, not your summary** → exact quotes from the document in D1 and D2, and checked wording in section 3.
- **Whether the complaints spreadsheet holds resolution dates or times** → F5 and E2 move from discovery to grounded, and their answer slots are replaced by your own account.
- **Any stage of the complaint process you set yourself** → F1 and B2 get a stronger, sourced answer.
- **Any work with a digital team on a self-service journey** → F10 and D1 get a sourced answer.
- **The recruiter's note on any deliverable or focus area** → coverage of anything they have asked you to prepare. None is declared so far.
- **Deep research (L2):** interviewer footprints, recent Ashgrove news and round-level reports. This is up to six more searches and two more fetches. Say yes to run it.
- **tuesday-dossier.md** → records the verified evidence and the gaps this prep found, so the next pack starts from them.
