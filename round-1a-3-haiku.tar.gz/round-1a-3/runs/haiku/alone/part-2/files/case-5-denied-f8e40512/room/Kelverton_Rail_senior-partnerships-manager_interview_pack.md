# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, panel, 60 minutes (15-minute spoken POV, then Q&A)
**Interviewers:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director)
**Relationship read:** hiring-manager round with an executive on the panel
**Research tier:** L1, but every search was refused. Nothing about the company, the interviewers or the industry has been checked. The pack uses your message, the recruiter's brief as you quoted it, and nothing else.
**Not yet received:** the job description, and the internal market report. Both would change this pack (see the upgrade menu).

---

## How to use this pack and the type key

Personas describe how a question arrives. Types describe what it scores.

| Tag | Name | What it scores |
|---|---|---|
| **CASE** | Live problem | Structure and reasoning on a problem from the role, delivered live |
| **JD** | Role requirement | Can you do the job the brief describes, gaps included |
| **EXP** | Experience deep-dive | Whether your stated record survives scrutiny, and what was actually yours |
| **VAL** | Behavioural | Past behaviour, mapped to a value or principle (none published that I could check) |
| **CO** | Company and strategy | Homework depth on the company's position (not checkable here) |

Guidance is scaffolding, not a script. Each answer should take 90 to 120 seconds spoken.

---

## Prep triage: 4 hours

Done in this order:

1. **75 min: build the POV.** Choose one thesis from Section 5, write the 15-minute version with the operator close, and say it aloud twice against a timer. Covers A1 to A5 and E1.
2. **60 min: commercial pushback.** Write your own answers to the £4M questions (C1, C2, D1, D2), using only what you counted and what you did not. Answer slots need your real answers, not mine.
3. **45 min: the predictable objection.** Rehearse B2, then B1 and B4, with someone who will push two follow-ups on each.
4. **30 min: reverse questions.** Pick three of the five and write one line on why you would ask each.
5. **30 min: full run.** The POV on a timer, then twenty minutes of Q&A with someone playing Ross.

Everything else is insurance.

---

## Fit snapshot

The requirements here come from the recruiter's brief, quoted as you gave it to me. There is no job description yet, so no row quotes one.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" (recruiter's email, as you quoted it) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Your material shows partner growth in a payments channel, not with operators. Say the channel in your own terms: "Last 4 years at a payments company running the ISV channel." Then say what carries over and what does not. Answer slot: if any partner mechanism carries over, name it and how you would test it; if none does, say so. |
| F2 | "land on what it means for the operators themselves" (recruiter's email, as you quoted it) | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" (your message) | medium | [grounded] | transferability | Adjacent work: planning for bus and light rail, from the consulting side. Your material does not show a train operating company seat. Keep the sentence at its own scope. Answer slot: name one operator decision you saw from the planning side and what you saw; if you did not see one, say so and say how you would learn it. |
| F3 | Selling into rail, for a company that "sells scheduling software to train operating companies" (your message) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | You stated this gap. Words: "I've never sold into rail specifically." Then how you would learn it, as a plan, never as a past. |
| F4 | Owning a commercial number for operator partnerships (role-family pattern, not quoted from any source) [generic] | "never carried a direct quota, only influenced revenue" (your message) | none | [grounded] | capability | You stated this gap. Words: "I've never carried a direct quota." The number you did carry is the influenced one, stated at that scope: "roughly £4M of influenced revenue." |
| F5 | "Ross will push on commercials." (recruiter's email, as you quoted it) | "roughly £4M of influenced revenue" (your message) | medium | [grounded] | discovery | Your material does not show how the figure was counted or which part was yours. Answer slot: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, in your own words. If you cannot say, say so. |
| F6 | Office, location or travel terms for this role (not in the recruiter's note as you quoted it) | none given | none | [grounded] | hard_gate | Your material does not establish this. No words are given for it here. The question that settles it is among the closing questions. |

**Gap types, in plain terms.** F1 and F2 are adjacent work, so the bridge says what the work was. F3 and F4 are gaps you stated, so the words come from your own negatives. F5 is a figure the material does not explain. F6 is a gate the material is silent on.

---

## Prohibited claims

These are the claims this pack will not coach. Each one comes with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Sold into rail | Negative you stated: "Never sold into rail specifically" | "I've never sold into rail specifically." No slot asserts rail experience. |
| Carried a quota | Negative you stated: "never carried a direct quota" | "I've never carried a direct quota." |
| Owned £4M of revenue | Inflated form of "roughly £4M of influenced revenue" | The quote at its own scope. The limit is the pack's own observation: your material says influenced, not owned. C1, C2, D1 and D2 stay inside "influenced." |
| Worked with train operating companies | Inflated form of "bus and light rail network planning" | The quote at its own scope. Your material shows bus and light rail planning work, not train operating company work. |
| Scheduling-software or timetabling-tool experience | Inflated form: no tool is named in your material | The quote at its own scope. B4 asks; nothing is claimed. |
| Knows how operators buy | Inflated form of "so I know the operator world from the other side" | The sentence as you wrote it. A3 and B3 ask what you saw. No further first-person claim. |

---

## Graded deliverable: the 15-minute POV

The recruiter asked for a short spoken POV, with no slides, on where you would take operator partnerships over 18 months, landing on what it means for the operators. It is graded, so it gets a build.

**Facts to build on**
- F1: "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message)
- F2: "so I know the operator world from the other side" (your message)

**Three theses. Each carries its own concession. Pick one.**

- **T1. Operators buy predictability in their planning cycle, so the partnership should start there.** Labelled [generic]: a pattern for planning-heavy operators, to be checked against the market report. Concession: "I've never sold into rail specifically, so the first thing I would test is whether this framing holds with two operators before I build anything on it." Ties to F2.
- **T2. Partner leverage: operators are reached through the people already inside their planning work.** Grounded in F1: the partner count rose from 6 to 40. Concession: "The partner model I ran was in payments. Whether integrators or consultancies reach operators, and whether they want to, is something I do not know yet." Ties to F1.
- **T3. Tie part of partner economics to operator outcomes.** Labelled [inferred]: a design direction, not a track record. Concession: "I have not designed or priced an outcome-based model. The risk is that it moves risk onto Kelverton, and I would want Ross's view before I committed to it." Ties to F4 and F5.

**Differentiation against the consensus.** The market report is the shared source, and any prepared candidate has read it. Bring one point it makes, to show you have it, then one thesis that departs from it, with reasons. I cannot see the report, so I cannot name its shortlist. Answer slot: name one operator segment, partner type or deal shape you would deprioritise, and say what you would tell that operator. If you have no such view yet, say you would test it first.

**The close: what it means for the operators themselves.** Name one operator decision that gets easier, who makes it, and the measure you would watch. Frame any operator benefit as a hypothesis you would test. Do not state an operator outcome you have not seen. Answer slot: if you have tracked a measure in any operator-facing setting, name it; if not, say you would define one in the first ninety days.

**Timing (15 minutes):** about 1 minute to open with your thesis, 9 minutes on the thesis and the differentiation, 2 minutes on the commercial case, 2 minutes on the operator close.

---

## Persona table

Weights come from the relationship (a hiring manager plus an executive). No interviewer profile was available, so there is no career-pattern adjustment.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (weight 5) | Live problems on the POV brief: "what do you need to know first?" | High. Deepa is the hiring manager, and the brief is itself a live problem. | Clarify, then structure aloud. Name one hypothesis and the evidence that would change it. |
| Skeptic (weight 4) | "Why should we trust you with rail?" "Why should we hire someone who has never carried a quota?" | High. The stated negatives (F3, F4) are exactly what a hiring manager probes. | Say the negative plainly, then bridge only with what you stated. Hold through two follow-ups. |
| Pressure / Stress (weight 4) | Ross on the £4M: "how do we know it was yours?" | High for Ross. The recruiter wrote that he would push on commercials. | Pause, restate the figure as you stated it, separate influenced from owned, then concede only what you do not know. |
| Data-Driven Prober (weight 3) | "Walk me through how that was counted." | Medium. The £4M is the one number on your record. | Name the assumption you would defend least before they do. |
| Conversational (weight 2) | An opener, "walk us through the journey." | Low to medium. Casual openers are still scored. | A 90-second arc built from your own sentences. |
| Values / Behavioural (weight 2) | A scenario about an unpopular truth | Low. No values round was signalled, and I could not check published values. | Selection scaffold with the honest branch. |
| Peer Evaluator (weight 2) | A seam with sales or product | Low to medium. Deepa is your manager, but Ross's commercial team sits beside partnerships. | Principles for the seam, not claims about it. |

---

## Question banks

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Before you write a plan for operator partnerships, what do you need to know?" | CASE | [grounded] "present a short POV on where you'd take our operator partnerships over the next 18 months" (recruiter's email) | Clarify first: which operators, what a partnership means for them (product, channel or service), and what the 18-month outcome is. Say the structure in one sentence: clarify, objective, segments, approach, metrics, risks. Speakable in 90 seconds. | The panel's own brief. CASE, because the scoring is structure. |
| A2 | "Which operators would you start with, and what would make you wrong about that choice?" | CASE | [grounded] "present a short POV on where you'd take our operator partnerships over the next 18 months" (recruiter's email) | Pick a segmentation criterion you can name, state it as a hypothesis, then name the evidence that would change your mind. Any operator you name is your hypothesis, not a fact. | The POV needs operator-specific content, and naming the disconfirming evidence is what Case scores. |
| A3 | "What does your plan mean for the operators themselves?" | JD, CASE delivery | [grounded] "land on what it means for the operators themselves" (recruiter's email) | Close on one operator decision that gets easier, who makes it, and the measure you would watch. Answer slot: if you have tracked a measure in an operator-facing setting, name it; if not, say you would define one in the first ninety days. | The recruiter's explicit close, so it is scored. |
| A4 | "Which of your theses would you drop first if the evidence went against it?" | CASE | [generic] | Name the thesis, the evidence that would kill it, and what you would do instead. | Rehearses the concession from the POV build. |
| A5 | "What would your plan tell us to stop doing?" | CASE | [generic] | Name one thing to deprioritise and the reason. If you have no such view yet, say you would test it first. Do not invent a no. | The anti-pick. Case scoring rewards a stated trade-off. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail. What makes you the person who should start?" | JD | [grounded] "Never sold into rail specifically" (your message) | Acknowledge first: "I've never sold into rail specifically." Then give the nearest things your material carries, quoted: "Last 4 years at a payments company running the ISV channel" and "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." Say which part of the planning work you would expect to carry over and which you would need to learn, in your own words. Answer slot: name the first operator-facing step you would take, as a plan. Hold through two follow-ups by returning to the channel and the planning work, not to a rail sale. | Born from F3. Pairs with B2 as the second-most likely objection. |
| B2 | "You've never carried a direct quota, only influenced revenue. Why would we hire you to own operator revenue?" | JD | [grounded] "never carried a direct quota, only influenced revenue" (your message); [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | **The highest-return rehearsal in this pack.** Acknowledge: "I've never carried a direct quota." Hold the position: "What I can show is partner growth from 6 to 40 and roughly £4M of influenced revenue." Hold through two follow-ups. Concede specifically: "I haven't owned a number the way a quota holder does, so I'd want the quota and the partner split agreed in the first month." Answer slot: if a target was ever set for the channel, say what it was and who set it; if none was, say so plainly. | Born from F4 and F1 together, and the objection most likely to come in some form. Deepest rehearsal, because the hold has to stay inside "influenced." |
| B3 | "Where would your payments channel playbook fail with operators?" | JD | [grounded] "Last 4 years at a payments company running the ISV channel" (your message) | Name one thing that would not transfer and why, from how the channel actually ran. Answer slot: if you can name what an operator buyer would need that the payments partners did not, say it; if you have no view, say you would test the playbook with two operators first. | Probes the transferability in F1 honestly. |
| B4 | "Did your planning work ever touch how a scheduling tool was bought?" | JD | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" (your message) | Answer in your own words, yes or no. If you saw tools chosen or replaced, say which and what you saw. If not, say so, then say what the planning work does give you for this role. | Tests the consultant-versus-buyer relationship in F2. |

### C. Pressure / Stress (weight 4, Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: how do we know the £4M was yours?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | Pause. Restate the figure as you stated it: "roughly £4M of influenced revenue." Say which part was yours, in your words, using the sentence's own verb: "took it from 6 partners to 40." Hold that it is influenced, not owned. Answer slot: how the figure was counted, in your words; if you cannot say, say so. | The commercial probe on the one number you have. |
| C2 | "How much of that £4M would have happened without you?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Hold-then-concede. The honest answer may be that you do not know. Name the assumption you would defend least: how influence was attributed. Answer slot: if influence was tested, say how; if not, say you do not know and what you would measure next. | Weakest-assumption move on the figure. |
| C3 | "Give me the number you'd commit to in year one, and how you'd know it's on track." | CO | [grounded] "Ross will push on commercials." (recruiter's email); the three inputs named in the guidance are [generic] | Do not give a number you cannot back. Name the three inputs you would need before committing to one: operator count, deal size and sales-cycle length. Then say you would commit to a range you would test. | Commercial pushback with no quota behind it. The honest answer is what you would need to know. |
| C4 | "Would you trade near-term revenue for better operator outcomes? Pick one." | CO | [generic] | Refuse the false binary briefly. Name the condition under which you would take the trade, then hold it through the second follow-up. | A dilemma test on the outcome-based thesis (T3). |

### D. Data-Driven Prober (weight 3, Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how that £4M was counted." | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Answer slot: if you know the method, describe it in your own words; if you do not, say so plainly. Do not reconstruct a method after the fact. | Defend-the-number slot. |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Name the weakest assumption before they do, in your words. Answer slot: if you can name one, name it; if the attribution was not yours to set, say so. | Weakest-assumption move. |
| D3 | "Six to forty partners. How many of those forty actually drove the revenue?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | Answer slot: if you can split the partners, give the split as you know it. If you did not track it, say that the revenue was influenced across the base and that you did not split it. | Distribution probe on the partner count. |

### E. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through the journey." | EXP | [grounded] "9 years in partnerships."; "Last 4 years at a payments company running the ISV channel."; "took it from 6 partners to 40, roughly £4M of influenced revenue."; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | A 90-second arc in four beats, each a clause from your sentences: nine years in partnerships, the last four at the payments company running the ISV channel, the move from 6 partners to 40, and before that five years in transport consulting. Finish on why this seat, in your own words. | Casual, but scored. Your sentences already give you the arc. |
| E2 | "Anything in our market report you'd push back on?" | CO | [grounded] "the market report their strategy team circulated internally last quarter" (your message) | Name one point you would push back on and why, in your own words. I cannot see the report, so I cannot supply the point. Answer slot: if you have one, say it; if not, name the point you would test first. | Differentiation from the shared source. |

### F. Values / Behavioural (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] open prompt; theme from the persona stem | Selection scaffold: pick a time you told senior people something they did not want to hear. It needs a named stake, the moment you did not fold, and a relationship that was intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it. Your material does not show one. | No values round was signalled, so this is coverage at low weight. |
| F2 | "When did you put a partner's interest ahead of an internal target?" | VAL | [generic] open prompt; theme from the persona stem | Same selection scaffold and honest branch as F1. | Partnerships-specific, at low weight. |

### G. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our sales and product teams sit next to partnerships. Where's the seam, and what happens when you disagree?" | JD | [generic] | Propose principles, not facts: who owns which partner decision, and how a disagreement gets settled in writing. Answer slot: if you have resolved a real disagreement across a seam, say how; if not, give the principle you would use. | Ross's commercial team is adjacent to partnerships. |
| G2 | "How do you handle credit when a partner deal spans two teams?" | JD | [generic] | Say the rule you would set up front. Answer slot: if you have a real case, say what you did; if not, give the rule. | Partnership fit, as a peer would probe it. |

---

## Requirement coverage

| Requirement, from the recruiter's brief | Covered by |
|---|---|
| POV on operator partnerships over 18 months (F1) | A1, A2, A4, A5 and the POV build |
| Land on what it means for the operators (F2) | A3, E1 and the POV close |
| Ross will push on commercials (F5) | C1, C2, C3, C4, D1, D2, D3, B2 |
| Stated negatives: rail and quota (F3, F4) | B1, B2, B4 |
| Gate: office, location or travel (F6) | none, and why: your material does not establish it, and the question that settles it is among the closing questions |
| The £4M figure, defend-the-number | C1, C2, D1, D2 |
| The "6 to 40" partner count | D3 |

---

## Reverse questions

Each one has a reason it lands.

1. **"What would a strong first 90 days look like in this seat?"** Why it lands: it shows you will judge the role by what Deepa will judge you on.
2. **"How will partnerships be measured: influenced revenue, sourced revenue, or a mix?"** Why it lands: Ross will push on commercials, so you learn the measure before the probe, and you show you know the difference.
3. **"Which operator relationship today is the one you'd most want to see repeated?"** Why it lands: it asks for the best evidence of the partner base and what the company values in it.
4. **"Where has an operator said no to partnering so far, and why?"** Why it lands: it finds the real objection and signals that you plan for it.
5. **"What does Ross need from partnerships that sales can't provide?"** Why it lands: it treats the seam as a question and shows you think about the commercial load he carries.

No interviewer profile was available, so none of these is tied to a career path. The upgrade menu says what would add that.

---

## Sources

- **Provided:** your message, which includes the recruiter's email as you quoted it and your background.
- **Referenced, not received:** the internal market report. This pack has not read it.
- **Searches sent (4), all refused:**
  - "Kelverton Rail" (refused)
  - "Kelverton Rail values strategy train operators scheduling software" (refused)
  - "Kelverton Rail Deepa VP Partnerships Ross Commercial Director" (refused)
  - "Great British Railways train operating companies 2026 timetable planning digital tools operators" (refused)
- **Fetches:** none sent.

**Research tier: L1, searches 4 of 6 (all refused), fetches 0 of 2, user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Would have set the values cheat sheet. That section is dropped here, since no values round was signalled. |
| 2. Interview process, role family | unavailable | Would have set the loop structure. Persona weights therefore follow the relationship, not a documented loop. |
| 3. Strategy and recent news | unavailable | Would have grounded the POV's current facts and the company vocabulary. The POV's industry framing is [generic] until checked. |
| 4. Interviewer public footprint (Deepa, Ross) | unavailable | Would have produced the interviewer read and a path-tied reverse question. Both are dropped. |
| 5. Representative job description | unavailable | Would have filled the requirement rows and the JD-tagged questions. The rows here use the recruiter's brief instead. |

---

## Upgrade menu

- **Job description text** → the requirement rows quote the JD instead of the brief, so F1, F2 and F5 gain requirement sources. The location and travel gate in F6 gets settled, and the JD-tagged questions (A3, B1, B3, B4, G1, G2) become grounded in the posting.
- **Three main points from the market report** → Section 5's differentiation step gets a real consensus answer to depart from, A4, A5 and E2 become grounded in the report, and T1 to T3 can be checked against it.
- **Search permission for this session** → research at L1 for targets 1 to 5, which would check the POV's current facts and the company vocabulary.
- **Full names for Deepa and Ross, with search permission** → an interviewer read, one reverse question tied to their path, and persona weights per panel member.
- **Deep research (L2), offered once and only after search is permitted** → up to 6 more searches and 2 more fetches, for the strategy brief and interview-loop reports.
- **Interview schedule, if the POV is one of several sessions** → per-session mini-packs.
