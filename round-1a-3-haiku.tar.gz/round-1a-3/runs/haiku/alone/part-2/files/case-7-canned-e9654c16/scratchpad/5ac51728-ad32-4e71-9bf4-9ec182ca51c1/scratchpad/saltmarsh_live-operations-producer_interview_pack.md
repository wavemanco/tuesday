# Interview pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations (relationship assumed to be hiring manager; see the upgrade menu)
Round: one 60-minute session, the "Outage Hour" (per the company's careers page): a live-incident tabletop on a simulated outage during a live event, then a values conversation.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** = behavioural / values alignment. **EXP** = work-experience deep-dive. **JD** = role / JD-driven. **CO** = company and strategy knowledge. **CASE** = live problem.
- Guidance is scaffolding, not a script. Rehearse the structure and the honest branches, and say everything in your own words.

## Fit snapshot

Requirements come from the JD you supplied, or from the company's careers page where marked. Evidence is quoted from your own message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material says one title's weekly content drops, not two titles' live events. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD asks about two titles and live events. If you planned events for a second title, say which; if not, say so and say how you would plan two titles on one calendar. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | discovery | The checklist touches cross-team work but does not show coordinating design, art, engineering or community on an update. Answer slot: if you coordinated any of those teams on a drop, name the team and what you did; if none, say so and describe how you would run that coordination. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Your material says you presented retention numbers. It does not show owning a post-event review or the KPIs one reports. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you ran a post-event review or set what it reported, say which; if not, say so and say what you would put in one. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you wrote the checklist, the JD says manage it. Bridge rewords only the quote: "I wrote the release checklist our QA team still uses." Do not say you managed the checklist. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | presentation | The years match. Whether a puzzle title counts as live-service is a judgement the interviewer will make. Bridge: state the years and describe the weekly content drops in your own words; do not assert the category yourself. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | The quote already reaches the requirement. Caveat: limited inspectable proof, so expect a probe on what the calendar contained. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you presented retention, which is not the same as defining or analysing it. Bridge rewords only the quote. The question of how the figure was counted is answered in D1. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | The quote reaches the requirement: a written artifact other teams use. Caveat: the checklist itself is the inspectable proof. A redacted sample would raise the band (see the upgrade menu). |
| F9 | "a live-incident tabletop on a simulated outage during a live event" (careers page) | none given | none | [grounded] | discovery | Your material does not show incident or outage handling. Answer slot in A4. |
| F10 | no people management (your message) | "Never led a team" (your message) | high | [grounded] | capability | Stated absence. Words: "I haven't led a team." Then coordination as a plan, never as a past. |
| F11 | in-app purchases (your message) | "Never worked on a game with in-app purchases" (your message) | high | [grounded] | capability | Stated absence. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, as a plan. |

Routing note: F9 is discovery because your material is silent on it, not because you said you lack it. F10 and F11 are capability because you stated the absence.

## Prohibited claims

Each entry names its basis. Do not say any of these, in any answer.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed the release checklist with QA | Inflated form of F4 | "I wrote the release checklist our QA team still uses." |
| Owned the live-events calendar for two titles | Inflated form of F1 | "For two years I ran the weekly content-drop calendar for our main title." |
| Led post-event reviews and the KPIs they report | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." |
| Coordinated four teams on each update | Inflated form of F2 | Stay with the checklist, and describe coordination as a plan. |
| Led a team | Negative you stated, F10 | "I haven't led a team." |
| Worked on monetisation or in-app purchases | Negative you stated, F11 | "I haven't worked on a game with in-app purchases." |

Not listed, and therefore answer slots rather than prohibitions: incident or outage experience (silent in your material, F9), and any claim that your title is live-service (a judgement for the interviewer, F5).

Prohibited-list note: the material says the round and the checklist, not the pipeline of events and the teams around them. That limit is this pack's observation, not words for you to say.

## Reading the interviewer

Public footprint only. From one search result, not a fetched page: a GDC 2026 talk, "Patch Notes Are a Promise", by Tobias Wrenfield, Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio. Its argument, as the snippet gives it: a live team is judged by how often its patch notes describe what actually shipped. The talk link returned a reserved example domain. Verify the talk before you refer to it in the room; until then, treat it as unconfirmed.

Practical implications:
1. Expect probes on the checklist and on what the release actually did. The QA background means the checklist will be read closely.
2. Saltmarsh's value "Ship the Patch Not the Promise" matches the talk's argument. Use it as the frame for B2.
3. Shared territory: QA. Your sentence "Wrote the release checklist our QA team still uses" sits beside the talk's QA background. This is a shared domain, not a shared career jump, so do not present it as one.
4. Tobias's talk puts patch-note accuracy at the centre. A reverse question on it is the strongest interviewer-specific question in the pack.

## Persona table

Weights start from the relationship prior for a hiring manager (Case/Strategist plus Skeptic). The careers page sets the loop to one session with the hiring manager, which is an established loop, so no archetype fallback applies. The weights are reasoned from that, not from Tobias's personal style.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The Outage Hour tabletop | High. The careers page names the live-incident tabletop as the opening of the session. | Clarify, then objective, approach, metrics and risks, spoken aloud. |
| Values/Behavioural | The values conversation | High. The careers page names it as the second half, and the company publishes three values. | Map each value to one honest story or a clear selection scaffold. |
| Skeptic | Probes on the three gaps: leading, in-app purchases, two titles | High. F1, F10 and F11 are the gaps most likely to be raised. | Rehearse the single most predictable objection until it is boring. Use bridges and plain acknowledgments. |
| Data-Driven Prober | "How was that counted?" on retention | Medium. You presented retention numbers, which invites a question on the count. | Say what you know and where your knowledge stops. Name the weakest assumption first. |
| Pressure | "How much of that was actually you?" | Low to medium. Not evidenced by any source; folded into D3. | Hold the position through two follow-ups. Concede specifically. |
| Conversational | Opener and "what are you playing" | Medium. Casual questions are still scored. | Use the 90-second arc, using only your own sentences. |

Weights for depth: Case 5 questions, Values 4, Skeptic 4, Prober 2, Pressure 1 (inside D), Conversational 2.

## Question banks

### Bank A: Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Ten minutes into a live event, a reward is granting twice to some players. Walk me through your first ten minutes." | CASE | [generic] | Clarify: who is affected, what players see, what undoing the grant costs. Then objective, two or three options (pause the grant, hotfix, communicate), who you bring in (engineering on the fix, QA on verification, community on the message), what you tell players and when. Name the risk of each option aloud. 90 to 120 seconds. | The careers page's live-incident tabletop, as a generic instance. No claim about your past. |
| A2 | "Tidepool Tactics and Lantern Row move to one shared events calendar from February 2027. What changes in how you would plan a month of events?" | CO | [grounded] "Project Larkspur moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027" (company news, search snippet, not fetched); "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Name the one-title calendar you ran. Say what carries over: a fixed weekly cadence, a single owner of dates. Say what you would need to learn first: how the season-pass cadence interacts with events. Answer slot: if you have ever aligned two calendars, say how; if not, say so and say what you would map first. | Larkspur is the most recent company move the research found. It changes the scope of the role. F1 is the only calendar evidence. |
| A3 | "Design says the update cannot go live today, and the event starts in six hours. What do you do?" | CASE | [generic] | Structure: each team's stake; what can ship without the update; who decides; what you tell players; what you write down. No claim about your past. | The JD's coordination line (F2), as a live decision. |
| A4 | "Tell me about a time something went wrong during a live event." | JD | [grounded] "a live-incident tabletop on a simulated outage during a live event" (careers page); "Wrote the release checklist our QA team still uses" (your message) | Open prompt, a selection scaffold: pick an incident or near-miss you were involved in, say what you did and what you did not do. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "Wrote the release checklist our QA team still uses," and say how you would run the tabletop. | F9 is silent in your material. The honest branch is the point. |
| A5 | "Write the patch note for a fix that shipped to half the players. What does it say?" | CASE | [generic] | Say what shipped and to whom, then what did not, then what players should do. Keep it short and factual. Do not promise the rest. | JD's "clear written communication", and the talk's theme; the only question that tests writing. |

### Bank B: Values / Behavioural (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. Which one won?" | VAL | [grounded] "Players Before Plans: when the calendar and the players disagree, the players win" (values page); "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Pick a case where a dated drop met a player problem: a bug, a pacing complaint, a rollback. Say the date, what players reported, and which one moved. If none comes to mind, say so plainly, then give the nearest thing your material carries: "I ran the weekly content-drop calendar for our main title for the last two years." | No sentence of yours carries a story about players winning over a date; the slot's second branch is the honest one. |
| B2 | "Tell me about a time you shipped less than you had promised. How did you say so?" | VAL | [grounded] "Ship the Patch Not the Promise: we announce what is built, not what is hoped" (values page); "Wrote the release checklist our QA team still uses" (your message) | Selection scaffold: pick a time an announcement outran the build, or a feature was cut before a date. Say what you announced and what shipped. If none comes to mind, say so plainly, then give the nearest thing your material carries: "Wrote the release checklist our QA team still uses." | The value matches the talk's argument. No story of yours carries it. |
| B3 | "Your release checklist: what did it leave better than you found it?" | VAL | [grounded] "Leave the Build Greener: every release leaves the codebase and the checklist better than it found them" (values page); "Wrote the release checklist our QA team still uses" (your message) | Say what the checklist changed about releases, in your own words, and that your message says QA still uses it. Answer slot: if you changed a release step or caught a problem with the checklist, say which; if you cannot name a change, say so plainly and say what you would check first. | The question names the checklist you wrote; the second branch allows that nothing changed. |
| B4 | "Tell me about a time you brought leadership news they did not want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Only if a retention figure you presented was unwelcome: say the figure as you presented it and what you recommended. If none landed badly, say so plainly, then give the nearest thing your material carries: "Presented the monthly retention numbers to the studio head." | Stem from the values persona; the presentation is the nearest sentence. |

### Bank C: Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have not led a team. How would you coordinate four teams on each update without managing any of them?" | JD | [grounded] "Never led a team" (your message) | Plain acknowledgment: "I haven't led a team." Then describe the coordination in your material (the checklist, with QA), and a plan: what you would put in writing for each team and who decides when two teams disagree. The plan is a plan, not a past. | F10 and F2. The acknowledgment has its source; the plan carries no claim about past coordination. |
| C2 | "Have you worked on a game with in-app purchases? What would change in your event planning if one of ours did?" | JD | [grounded] "Never worked on a game with in-app purchases" (your message); [generic] the conditional about planning | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then say what you would want to learn first, and from whom: the team that owns purchases. Do not claim monetisation knowledge. | F11, the capability gap. The learning plan is the honest answer. |
| C3 | "Two titles on one calendar, and you have run one. Why would that work for us?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message); "plan and run the live-events calendar for two of our mobile titles" (JD) | Hold the one-title record: "For two years I ran the weekly content-drop calendar for our main title." Say what carries over (cadence, dependencies) and what you would check first on the second title. Answer slot: if you ever planned across two titles, say which; if not, say so. Hold through two follow-ups. Concede what is untested. | F1. The highest-ROI rehearsal in this pack: it is the most likely objection, and the honest answer is a limit. |
| C4 | "Puzzle games aren't live-service. Why would that count for us?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Describe the weekly content drops: what shipped each week, in your words. Leave the category to the interviewer. Do not argue the label. If pressed, concede that puzzle is a different genre and say what transfers. | F5. A held position you can back, not a defence of the label. |

### Bank D: Data-Driven Prober and Pressure (weight 2 + 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How do you define player retention for a live title?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Give a definition you would defend, then your weakest assumption before it is asked. Answer slot: if you built or checked the count behind the monthly numbers you presented, say how; if not, say so, and say what you would confirm first. No figure from your material is available to defend, so this is a slot, not a number. | F7. The probe on how a figure was counted usually follows a presentation. |
| D2 | "Which post-event review have you owned, and what KPIs did it report?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD); "Presented the monthly retention numbers to the studio head" (your message) | Say that you presented the monthly numbers. If you ran any post-event review, say which and what it reported. If none, say so, and describe what you would put in one. | F3. This requirement has no sentence of yours behind it. |
| D3 | "That retention slide. How much of that number was actually you?" | Pressure | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Hold the position you can defend: what you presented, and who produced the figure only if you know. Hold through two follow-ups. Concede specifically where you do not know. | Pressure stem. Hold-then-concede. |

### Bank E: Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); "I ran the weekly content-drop calendar for our main title for the last two years" (your message); "Wrote the release checklist our QA team still uses" (your message); "Presented the monthly retention numbers to the studio head" (your message) | A 90-second arc in your own words, using only these four sentences, closing on why this role. | Opener, scored as communication and as the content-calendar requirement. |
| E2 | "What are you playing at the moment?" | CO | [generic] | Name a game you actually played, and what you noticed about its events or updates. If you do not play mobile games now, say so. | Rapport question with a live JD topic. Do not invent. |

Coverage of JD requirements:
- Plan and run the live-events calendar for two titles: A2, C3
- Coordinate design, art, engineering and community teams: A3, C1
- Own the post-event review and KPIs: D2, D1
- Manage the release checklist with QA: B3, A4
- 3+ years live-service: C4
- Experience running a content calendar: E1
- Player-retention metrics: D1, D3
- Clear written communication: A5
- Careers-page items: Outage Hour, A1 and A4; values, B1 to B3.

## Values / principles cheat sheet

| Value (official name) | Working meaning | Your story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | B1. No sentence of yours carries a story of this. Selection scaffold, honest branch, nearest sentence: "I ran the weekly content-drop calendar for our main title for the last two years." |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | B2. No sentence of yours carries this. Scaffold, honest branch, nearest sentence: "Wrote the release checklist our QA team still uses." |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | B3. Your sentence: "Wrote the release checklist our QA team still uses." Answer slot: name a change, or say you cannot yet. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Project Larkspur puts both titles on one events calendar from February 2027. What does the single live-ops group own that the per-title teams did not?" | Shows you read the news, and the answer tells you the role's real scope. |
| R2 | "Your GDC talk argues a live team is judged by how often its patch notes describe what shipped. What do you measure to know that?" | Ties the question to Tobias's own path. Ask only after the talk is verified. |
| R3 | "What does the post-event review look like today, and who writes it?" | The role owns it. The answer shows whether it exists and how far it is run. |
| R4 | "Which decisions does this role make alone, and which need sign-off from design or QA?" | Maps the coordination requirement against real authority. |
| R5 | "Where do you expect the hardest coordination problem to be across the four teams?" | Shows you think at the level of the team, not only the calendar. |
| R6 | "What would make the first six months clearly successful?" | A standard question that tests altitude. |

## Interview run-of-show (60 minutes, suggested)

The careers page gives the order (tabletop, then values) but not the split. These times are a suggestion from this pack, not from the company.

- 0 to 5 minutes: opener (E1, E2).
- 5 to 35 minutes: Outage Hour tabletop (A1, A3, A5, and A4 if the talk goes that way).
- 35 to 55 minutes: values conversation (B1 to B4, C1 and C3 if they come up).
- 55 to 60 minutes: your reverse questions (R1 to R3 first).

## Prohibited claims check

No answer in this pack asserts any entry in the prohibited-claims table.

## Sources

Provided documents: the JD and your background message.

Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. saltmarsh games values | yes | Values cheat sheet, B1 to B3 and the value names. Fetched the official page. |
| 2. saltmarsh games interview process, role family | yes | Loop structure: one 60-minute Outage Hour with the hiring manager. Fetched the careers page. |
| 3. saltmarsh games strategy or recent news | yes | A2 and R1. Search snippet only; the Larkspur page was not fetched. |
| 4. Tobias Wrenfield with Saltmarsh | yes | Reading the interviewer, R2, the patch-note frame in B2. One search result; the talk page was not fetched, and its domain is a reserved example domain, so unverified. |
| 5. representative JD | skipped | The JD you supplied fixes the fit snapshot and JD-tagged questions. |

Queries sent, and what came back:
- "Saltmarsh Games values" returned saltmarshgames.com/values.
- "Saltmarsh Games interview process live operations producer" returned saltmarshgames.com/careers/interviewing.
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations" returned talks.gdconf.example/2026/patch-notes-are-a-promise.
- "Saltmarsh Games strategy recent news" returned saltmarshgames.com/news/project-larkspur.
- Fetches: saltmarshgames.com/values (values returned); saltmarshgames.com/careers/interviewing (loop returned).

## Upgrade menu

- Confirmation that Tobias is your hiring manager, and whether anyone else joins → reweights the personas and changes the reverse questions.
- The talk's actual page, opened and checked → R2 and the interviewer read move from unconfirmed to grounded.
- A redacted sample of the release checklist, if your former studio's terms allow it → F4 and F8 move from medium to high, and B3 gets a concrete artifact. Check your former studio's confidentiality terms before you share anything.
- Your notes on the retention figures you presented → D1 and D3 get defend-the-number slots, and the figures are yours to explain.
- A deeper research pass, if you want it: up to 6 more searches and 2 more fetches, several minutes → the strategy brief on Larkspur, Tobias's other writing, and recent leadership changes.
- The recruiter's prep email → confirms the tabletop and values split, and any scoring criteria.
