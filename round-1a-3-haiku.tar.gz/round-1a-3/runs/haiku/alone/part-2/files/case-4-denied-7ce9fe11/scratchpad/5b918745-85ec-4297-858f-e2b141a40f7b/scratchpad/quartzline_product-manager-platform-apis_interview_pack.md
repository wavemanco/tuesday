# Interview pack: Product Manager, Platform APIs at Quartzline

**Round:** 45-minute conversation with the hiring manager (Thursday).
**Built from:** the underwriting dossier (`tuesday-dossier.md`, generated 2026-08-14, stage: interviewing). The dossier is about 14 weeks old as of 2026-11-20. Before Thursday, confirm the posting and the two-squad setup still match.
**Interviewer:** not named. The interviewer read and the tailored reverse questions are absent.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: **JD** (the listed job), **EXP** (what you actually did), **CASE** (a live problem), **CO** (company knowledge), **VAL** (values).
- Guidance is scaffolding for a spoken answer, not a script. Rehearse it aloud, in your own words.
- Your own sentences appear in the Provenance column. Where guidance says what you did, it rests on those quotes, and nothing else.

## Persona weights

| Persona | Weight | How it shows up here | Why | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Highest, 5 questions | The missing PM title and roadmap, and why you should be hired into the role anyway | A hiring manager is buying capability and derisking the gaps the dossier names | Rehearse the named objection until it is plain. Bridge only from the quotes. Concede the gaps directly |
| Case / Strategist | 4 questions | Live problems on the partner platform: adoption, squad disagreement, partner discovery, the first 90 days | Hiring-manager prior: expect live problems on the actual roadmap | Clarify, then structure, then metrics. Name the decision rights you do not yet know |
| Data-Driven Prober | 4 questions | The 30+ integrations figure, the playbook, the roadmap-input outcomes, API docs and schemas | The dossier flags the roadmap-input line as medium confidence, so expect a probe | Say how the number was counted, which part was yours, and what you cannot say |
| Pressure | 3 questions | "Why you, in sixty seconds" and "how much of that was actually you" | Testing composure under a challenged position | Hold the bridge through two follow-ups. Concede the specific gap, never the core claim |
| Conversational | 2 questions | The "walk me through" opener and the API-tools question | Casual openers are still scored | Pre-script a 90-second arc from quotes only |

**The loop is not documented.** No loop source established the rounds, so these weights rest on the hiring-manager prior, not on this company's process. The values-style round is therefore not detected, and no values section is included.

## Fit snapshot

Requirement text is quoted from the dossier's `role_profile`, which stands in for the JD. The verified evidence is quoted from `handoff_to_mock_interview.verified_candidate_evidence`. The dossier carries no `evidence_map`, so the grades below use the dossier's confidence and gap-type fields. Gap types follow the routing rule in the template, and the pack has graded R2 as `transferability` on its own reading. The underwriter did not flag R2 as a weak area.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile, R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence[0]); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified_candidate_evidence[2]) | low | [grounded] | transferability | The material shows client integration work and roadmap inputs. It does not show product management. Say the limit first: "I haven't held a product manager title." Then the adjacent work at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Never describe the integrations as PM experience |
| F2 | "Owning a roadmap and prioritization authority" (dossier uncertain_or_weak_areas, R1 sub-claim) | none given | none | [grounded] | capability | The dossier records this absence (acknowledge_gap). Plain words: "I haven't owned a product roadmap." Then a ramp plan, said as a plan and never as a past. No bridge |
| F3 | "Shipped API or platform products" (dossier role_profile, R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence[0]) | high | [grounded] | transferability | The material shows integrating a vendor's API with clients. It does not show shipping an API product. Say the scope of the integrations, and do not describe them as a product you shipped |
| F4 | "Technical fluency: API docs, schemas" (dossier role_profile, R3, important) | "Wrote the internal integration playbook her team uses" (dossier verified_candidate_evidence[1]) | high | [grounded] | discovery | The playbook does not show whether it covers API docs or schemas. Answer slot: if you wrote or reviewed API docs or schemas, say which, in your own words. If you did not, say so and say how you would close that gap |
| F5 | "Stakeholder management across engineering, sales, customers" (dossier role_profile, R4, important) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified_candidate_evidence[2]) | medium | [grounded] | presentation | This is the medium-confidence entry, so the caveat stays visible: limited inspectable proof, and expect a probe. Volunteer the limit before it is extracted. Reword the quote only. Do not add engineering or sales to it |
| F6 | "Agile delivery experience" (dossier role_profile, R5, preferred) | none given | low | [grounded] | discovery | Clarify rather than bridge. Answer slot: if you ran delivery on a sprint cadence, name the team and what you ran. If you did not work that way, say so plainly |

**Gate rows:** none. The dossier's `hard_gates` is empty.

## Prohibited claims

Built from the dossier's `prohibited_claims` and `acknowledge_gap` areas, plus inflated forms of the verified quotes. Nothing on this list may be asserted, softened or implied in any cell below.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | dossier prohibited_claims | Plain words: "I haven't held a product manager title." Then the adjacent quotes at their own scope |
| Having owned a product roadmap | dossier prohibited_claims and acknowledge_gap | Plain words: "I haven't owned a product roadmap." Then a ramp plan |
| Having set prioritization for an engineering squad | dossier prohibited_claims | Plain words: "I haven't set prioritization for an engineering squad." No slot |
| Shipped an API product | Inflated form of F3 | The integration quote at its own scope. Its limit is this pack's observation: the material shows integrations, not a shipped product |
| Owned the integration roadmap | Inflated form of F1 | "Led 30+ end-to-end client integrations." The roadmap is not in the material |

## Question banks

### Skeptic (weight: highest, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; negatives sourced to prohibited_claims: "Having held a product manager title or role", "Having owned a product roadmap" | **The highest-ROI prep in this pack.** The underwriter named this objection, so rehearse it deepest. Open with the limit in your own words: "I haven't held a product manager title or owned a roadmap." Then the bridge at its own scope: "I led 30+ end-to-end client integrations, from scoping through go-live, and I wrote the playbook my team uses." Then the ramp plan, as a plan: "In the first months I would learn how the two squads set priority before proposing any change." Hold through two follow-ups by returning to the integrations. On the second follow-up, concede the specific gap: you have not set a roadmap. Never claim you did the PM job | Named by the underwriter as the likely objection. The question is asked as the underwriter wrote it because both negatives have a source in prohibited_claims. Scores R1 (F1, F2) |
| S2 | "The JD asks for three years of product management. Where does your experience sit against that?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product"; negative sourced to prohibited_claims: "Having held a product manager title or role" | Name the requirement's own words as the probe. Then the quote, at its scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Say the limit: that is input to product, not the product role. Do not extend the sessions into prioritization | F1 is the evidence that reaches the requirement, and only at adjacent scope. Scores R1 |
| S3 | "Describe how you have run delivery on an agile cadence inside a product org." | JD | [grounded] JD line "Agile delivery experience" (dossier role_profile, R5). The question presupposes a product org that the quotes do not state | Clarify strategy. Answer slot: if you ran delivery on a sprint cadence, name the team and what you ran. If you did not work that way, say so plainly, then say what you would want to confirm about how this org defines agile delivery | F6 is discovery, not capability, so the guidance asks rather than claims. Scores R5 |
| S4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] plain words sourced to prohibited_claims: "Having owned a product roadmap" | Answer honestly and specifically: roadmap ownership and prioritization authority (F2). Then the ramp plan, as a plan. Do not list areas you have not been asked about | Persona stem. Gives the candidate an honest, prepared answer to the gap the underwriter named |
| S5 | "Tell me about a time a client's need and an internal plan pulled in different directions." | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (F5). The theme is the JD's "Stakeholder management across engineering, sales, customers" | Story map from the quote's beats only: the sessions, the client evidence, the product. Selection scaffold: pick a time a client need and a product plan diverged. If none comes to mind, say so plainly, then give the nearest thing the sessions carry. Volunteer the medium-confidence limit before the probe: the evidence is inspectable only in part | F5 is medium-confidence, so the caveat is coached into the answer. Scores R4 |

### Case / Strategist (weight: 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Partner API adoption has flattened since launch. What do you need to know first?" | CASE | [grounded] JD responsibility "Define and track adoption metrics" (dossier role_profile) | Clarify before structuring: what counts as adopted, from which partners, measured how. Then segment partners by integration stage, check the baseline, and form two hypotheses. Say which data you would ask for first. No claim about your past | The dossier names the adoption baseline as unknown. This is a live problem from the role, so it is scored as a case |
| C2 | "Two squad leads disagree on a partner-facing deprecation. How do you decide?" | CASE | [grounded] JD responsibility "Write specs and drive delivery with two engineering squads" (dossier role_profile); negative sourced to prohibited_claims: "Having set prioritization for an engineering squad" | Clarify decision rights first: who owns the call under this role's remit. Name the partner input you would gather. Propose a decision path, and say what you would escalate. Plain words for the negative: "I haven't set prioritization for an engineering squad." Do not claim the decision was yours | Decision authority versus the squad leads is the dossier's named unknown. The guidance asks rather than asserts |
| C3 | "Walk me through the first partner discovery session you would run." | CASE | [grounded] JD responsibility "Run discovery with integration partners" (dossier role_profile). Answer slot anchor: "Ran quarterly roadmap-input sessions feeding client evidence to product" | Structure: the goal, the partner segment, the questions about their integration pain, and what you will not promise yet. If the roadmap-input sessions are the nearest thing you have, say how they differed. If they did not differ, say so | Partner discovery is a named responsibility. The guidance draws on the sessions only as an answer slot |
| C4 | "Sketch your first 90 days owning the roadmap for the partner-facing API platform." | CASE | [grounded] JD responsibility "Own the roadmap for the partner-facing API platform" (dossier role_profile); negative sourced to prohibited_claims: "Having owned a product roadmap" | Structure: listen first, map the partners, establish the adoption baseline, pick one decision to make with evidence. Say plainly that roadmap ownership is new to you. Do not describe a roadmap you have owned | The case is the role's own. The negative keeps the answer honest |

### Data-Driven Prober (weight: 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you counted the 30+ integrations." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what counted as one integration, in your own words. Then the assumption you would defend least. Answer slot: if any of the 30+ were not yours to lead, say which. If you do not know how the count was kept, say so | The figure is the dossier's headline claim. The defend-the-number slot asks for the count and the attribution, not a method the pack supplies |
| D2 | "Which part of the playbook would you show us, and how do you know your team uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Name the part you would show. For "how do you know", answer from your own experience: what you saw or were told. If you cannot point to evidence of use, say so | The playbook is inspectable. The prober asks for the proof of use, which the dossier does not give |
| D3 | "The roadmap-input sessions: what did product change because of them?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Answer slot: if product changed something, name it and say how much of it came from your evidence. If product changed nothing, say so plainly. Volunteer the medium-confidence limit first: limited inspectable proof | F5 is medium-confidence, so this probe is expected. The guidance does not supply the outcome |
| D4 | "Which API docs or schemas have you written or reviewed yourself?" | JD | [grounded] JD line "Technical fluency: API docs, schemas" (dossier role_profile, R3) | Answer slot: name the docs or schemas you wrote or reviewed, in your own words. If you have not written or reviewed any, say so, then say how you would learn them | F4 is discovery. The guidance asks, and does not claim the playbook covered schemas |

### Pressure (weight: 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why should we hire you into this role?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; negative sourced to prohibited_claims: "Having held a product manager title or role" | Hold, then concede. Lead with the closest quote. Hold that position through two follow-ups. Concede specifically when pressed: "I have not held a PM title or owned a roadmap." Do not fold on the integration work | A pressure stem. The hold rests on the quote, and the concession names the gap the underwriter found |
| P2 | "That 30+ figure: how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" | Defend-the-number slot: say how the count was kept, which part you led, and the assumption you would defend least. If any were supported rather than led, say so. Hold the number; do not round it up | Premised on the quote's own scope and attribution: "led", not "delivered" |
| P3 | "You wrote the playbook. Did anyone outside your team ever use it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Answer slot: if it stayed inside your team, say so. If it reached others, name who, and how you know. Do not extend the playbook's reach beyond what you can say | Pressure on the quote's scope. The honest answer may be a limit |

### Conversational (weight: 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc from these three quotes only, in order: the integrations, the playbook, the roadmap inputs. Then stop and let the interviewer lead. Name the PM gap in one sentence at the end, so it is not extracted later | Casual openers are scored. The arc gives the three verified claims in their own words |
| A2 | "What are you playing with in API tooling these days?" | JD | [grounded] JD line "Technical fluency: API docs, schemas" (dossier role_profile, R3) | Answer slot: name a tool you have used on the integration work, in your own words. If your work has been mostly on the client side, say so and name what you did use | Persona stem on the JD's plus-skill. The honest answer is a tool you have actually used |

## Coverage: requirement to question

| Requirement | Questions |
|---|---|
| R1 "3+ years product management experience" | S1, S2, P1, A1 |
| R1 sub-claim "Owning a roadmap and prioritization authority" | S1, S4, C2, C4 |
| R2 "Shipped API or platform products" | S1, D1, P2 |
| R3 "Technical fluency: API docs, schemas" | D4, A2 |
| R4 "Stakeholder management across engineering, sales, customers" | S5, D3, C2 |
| R5 "Agile delivery experience" | S3 |
| Responsibility "Define and track adoption metrics" | C1 |
| Responsibility "Run discovery with integration partners" | C3 |
| Responsibility "Own the roadmap for the partner-facing API platform" | C4 |

**CO questions: none.** Company research was refused in this run, so no strategy-grounded question was written. CO and CASE questions here are generic patterns, labeled `[grounded]` only where they come from the role's own responsibilities.

## Reverse questions

Seeded from the dossier's `questions_for_employer` and `opportunity_risks_to_validate`. The interviewer has no profile, so none ties to their path, and no reciprocity question is needed for a hiring-manager round.

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The JD asserts decision authority, and no evidence in the pack shows it. The answer decides whether the bridge is credible for this role |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | The JD names adoption metrics as a responsibility, and no baseline is stated. The answer sets your first 90 days |
| RQ3 | "What does agile delivery look like across the two squads today?" | R5 is preferred and unverified. The answer tells you whether this is a ramp or a mismatch |
| RQ4 | "What would make you say this hire worked, one year in?" | Asks for the success measure directly. Shows you plan around outcomes, not the title |
| RQ5 | "Which partner integration is causing the most trouble right now?" | Shows you want the live problem, and it surfaces where the role's first work sits |

## Target accounting in Sources

**Provided documents:** `tuesday-dossier.md` (dossier version 1.1, generated 2026-08-14). Consumed sections: `role_profile` (requirements, responsibilities, unknowns), `handoff_to_mock_interview` (verified evidence, weak areas, likely objection, risks, employer questions, prohibited claims), `decision` (context only). Not present: `evidence_map`, `risk_register`, `evidence_state`, so the grades above are this pack's routing on the dossier's fields. No links were read.

**Research tier:** L1 — searches 3 of 6, fetches 0 of 2. All three searches were refused by the permission setting in this session.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline company values` | unavailable | Refused (query: "Quartzline company values"). Would have moved the values section, which is absent because no values-style round is detected |
| 2. `Quartzline interview process product manager platform APIs` | unavailable | Refused (query: "Quartzline interview process product manager platform APIs"). Would have established the loop, so the persona weights would rest on the documented process rather than the hiring-manager prior |
| 3. `Quartzline strategy recent news` | unavailable | Refused (query: "Quartzline strategy recent news"). Would have moved the CO bank, which is absent here |
| 4. `{interviewer name} Quartzline` | n/a | No name given |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` fixes the requirements and responsibilities |

## Upgrade menu

- **Full JD text** → the requirement rows become quoted JD lines rather than the dossier's restated lines, and C1 to C4 can cite the posting's own wording.
- **Interviewer's name** → an interviewer read, persona weights from their public footprint, and a reverse question tied to their own path.
- **Company values page, pasted** → a values section and VAL questions, which are absent now.
- **Strategy brief or recent-news paste** → CO questions grounded in current priorities. Without it, the CO bank stays generic.
- **Round format from the recruiter** (case, presentation, or part of a loop) → confirms the persona weights and says whether the 45 minutes includes a live case.
- **Raw CV** → the bridges can quote more than the three verified entries. Only the dossier's confirmed claims are used now.
- **Deeper research, once** (L2): up to 6 more searches and 2 more fetches, several minutes. It will meet the same permission setting unless you grant it.
- **Fresh dossier with `evidence_map`** → the row grades come from the underwriter's map, not this pack's routing.
- **Loop schedule** → if Thursday is one of several rounds, send the schedule, and the pack becomes per-round mini-packs.
