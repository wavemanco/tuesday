Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-2-rooms-case-1-denied-830c19fe/c7de1f1a-ffb4-46c7-8185-5531e1ea31f4/scratchpad/northwind_senior-gtm-strategy-lead_interview_pack.md. It has 20 questions across six personas, weighted for a peer round with Dan (Prober top, then Peer Evaluator and Case, Skeptic, Pressure and Conversational lower). It holds the fit snapshot, a prohibited-claims list, the question banks with rationale, reverse questions, and sources.

Two things shape it. Web search was refused by the host, so Northwind's values, loop and strategy are not verified; the pack uses your research note as provided. And the highest-return prep is D1: "You haven't set quotas or run sales operations." Priya's notes state that absence, so the honest answer is the plain acknowledgment followed by what she did set, plus a concrete learning plan. Rehearse the hold-then-concede on that one first.

I'm taking the straightforward reading of your notes as the basis: the $400M figure and the carrier model are the headline claims Dan will test, so A1, A2 and E2 cover them, and they are the same figure asked two ways.

Drill: I can play Dan on D1 or A1 and give feedback against that question's guidance. Dossier: I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. A Word version of the pack is also available if you want one.

1. Can you paste the full JD text? The JD highlights are my summary, so the requirements are unquoted until I have the posting's wording.
2. Does the posting set any hard terms, such as location, office days, travel or work authorization? If so, they become gate rows in the fit snapshot.
3. Can you allow web search? Then I can run the three refused research targets: Northwind's values, interview process and current strategy.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

Candidate: Priya. Interviewer: Dan Kovac, Director of Sales Strategy. Relationship: peer (you both report to the same VP). Format: one 60-minute conversation.

Built on: your notes as provided; JD highlights as a summary (not the posting's text); your research note on Northwind's priorities and competitive threat; your summary of Dan's profile. Web search was refused by the host, so no outside sources were used.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values | Past behavior against published values. None detected for this loop, so no VAL questions. |
| EXP | Experience deep-dive | Whether your claims survive scrutiny and what you actually did |
| JD | Role / JD-driven | Stated requirements, including the gaps |
| CO | Company and strategy | Northwind's current priorities and competitive frame |
| CASE | Live problem | Structure and reasoning on a problem from the role |

## Fit snapshot

Requirements are JD highlights you summarised, so they are plain prose, not quotes. Your evidence is quoted verbatim from your notes. Source for every evidence quote: the coach's notes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Own GTM strategy for two new product lines (JD highlights) | "built a partner-level revenue model used in carrier negotiations" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Your notes show a revenue model and a proposal, not a go-to-market plan you owned for a product line. Words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you set the go-to-market plan for a product, say which decisions were yours; if not, say the nearest thing you did, at its own scope. |
| F2 | Whitespace across land, adopt, expand and renew (JD highlights) | none given | none | [grounded] | discovery | Your notes say nothing about these lifecycle stages. Answer slot: if you have worked on any stage, say which and what it decided; if none, say so and walk through how you would find the whitespace (see C4). |
| F3 | Independent analysis in SQL and Tableau (JD highlights) | "skilled in SQL/Tableau" — the coach's notes | low | [grounded] | discovery | Your notes say skilled, not what you analysed alone. Answer slot: name one analysis you ran yourself and what it decided; if you have none, say so and say what you would run first. |
| F4 | Partner-motion design, required (JD highlights) | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The model reaches partner economics, not partner programmes you designed. Words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you have designed partner terms, incentives or a programme, say which; if not, say so and say how the model would inform partner design. |
| F5 | Cross-functional influence (JD highlights) | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap. Expect a probe on who disagreed and how it resolved. |
| F6 | AI experience, a plus (JD highlights) | "uses AI tools daily" — the coach's notes | low | [grounded] | presentation | Daily use is what your notes show. Words: "I use AI tools daily." Do not present use as building. Answer slot: name one decision an AI tool changed, and how you checked it. |
| F7 | Enterprise expansion, a stated Northwind priority (your research note) | none given | none | [grounded] | discovery | Your notes say nothing about enterprise buyers. Answer slot: if you have sold to or planned for enterprise buyers, say what; if your work was consumer-facing, say so and describe how you would learn enterprise buying. |
| F8 | Sales operations and quota setting (flagged by you; not in the JD highlights) | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan, never as a past. |

Gate rows: none supplied. If the posting sets location, office days, travel or work-authorization terms, they become hard-gate rows (question 2 below).

Confidence grades your evidence. Provenance grades what this pack wrote. On F8 the Provenance is [grounded] because the gap is one you stated.

## Prohibited claims

Built locally from the fit snapshot. These are wordings the pack will not coach, because they stretch what your notes say.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the go-to-market for a product line | Inflated form of F1 | The revenue model and the proposal, at their own scope. The material says a model and a proposal, not a go-to-market plan. |
| Drove the ~$400M ARR uplift | Inflated form of the credited proposal in F1 | "proposed a store-surface change credited with a ~$400M ARR uplift": you proposed it; the credit is what it is credited with. |
| Designed partner programmes or incentives | Inflated form of F4 | The partner-level revenue model, at its own scope. |
| Ran independent SQL or Tableau analysis that changed a decision | Inflated form of F3 | "skilled in SQL/Tableau", with the example coming from you. |
| Set quotas or ran sales operations | Negative you stated, F8 | "I don't have classic sales-ops or quota-setting experience." No slot. |

## Reading the interviewer

Public footprint only, as you summarised it. Dan self-describes as "relentlessly data-driven". His career spine is pricing and monetization, with one early-stage startup chapter.

Practical implications:
- Expect every number on your CV to be probed to its assumptions. Prepare the weakest assumption for each figure.
- Pricing, packaging and unit economics are his native language. Case answers should use that vocabulary.
- You have no startup chapter, so there is no shared career jump to offer. Do not reach for one.
- Shared professional domain: monetization. Your carrier revenue model sits in that space. It is a fair point of contact; it is not a shared jump.

## Persona table

Relationship prior for a peer round is Peer Evaluator plus Data-Driven Prober. Your summary of Dan's profile raises the Prober. Your flagged gaps raise the Skeptic.

| Persona | How it shows up | Likelihood and reasoning | Weight | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | Line-by-line probes of figures and assumptions | High. Peer prior, plus his self-description | Top: 5 questions (A1 to A5) | Name the weakest assumption first. Say plainly where you do not know how a figure was counted. |
| Peer Evaluator | Seam probes, disagreement, credit | High. Peer prior: he is pricing what you cost and add to his work | 4 (B1 to B4) | Propose seam principles, not claims to know the seam. Credit by role. |
| Case / Strategist | Live GTM and pricing problems | Medium-high. The two new lines and the Compass launch are live problems; his pricing background tilts cases toward pricing | 4 (C1 to C4) | Clarify, then objective, segmentation, approach, metrics, risks. Use pricing vocabulary. |
| Skeptic | Gap probes: quota setting, enterprise, motivation | High for the quota and enterprise gaps. These are the gaps the material shows | 3 (D1 to D3) | Plain acknowledgment, then the nearest real thing at its own scope, then a concrete learning plan. D1 gets the deepest rehearsal regardless of weight. |
| Pressure | Time-boxed challenges to the $400M claim and to your motives | Low-medium. A peer round rarely presses hard, but one challenge on the $400M is likely | 2 (E1 to E2) | Pause, restate, hold through two follow-ups, then concede specifically. |
| Conversational | Casual openers that are still scored | Low-medium. Openers are where the journey and the SQL question come in | 2 (F1 to F2) | Prepare a 90-second arc. Treat casual questions on SQL and Tableau as scored. |

Total: 20 questions, inside the 18 to 26 range.

## Question banks

### Data-Driven Prober (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Say what you proposed, in those words. Name the weakest assumption behind the figure before he does. Answer slot: if you know how it was counted, say how, in your own words. If there was no such step, or you were not the one who counted it, say so plainly and stay with what you can stand behind. | The headline metric in your notes. Defend-the-number slot: method, sensitivity, weakest assumption, what was yours. Prober's top probe. |
| A2 | "Of that uplift, what was yours and what was credited to you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | The sentence holds three things: you proposed the change, the change is credited with the uplift, and credit is a judgment others made. Answer slot: if you were involved after the proposal, say which decisions were yours; if not, stop at the proposal. | Tests attribution directly. The question's premise is the figure you quoted. |
| A3 | "Which assumption in the carrier revenue model would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" — the coach's notes | Name one assumption in your own words, before he asks for it. Your notes give none, so this is yours to name. Answer slot: if you cannot name one, say you would check the inputs before defending the output. | The only quantitative artifact in your notes. The weakest-assumption move is what converts a gotcha into a credibility gain. |
| A4 | "Which analysis have you run yourself in SQL and Tableau, end to end, and what did it decide?" | JD | [grounded] "skilled in SQL/Tableau" — the coach's notes | Name one analysis, the question it answered and the decision it moved, in your own words. Answer slot: if you have one, walk it end to end. If you have not run one yourself, say so and say what you would run first. | JD requirement F3, whose evidence is the thinnest in the pack. Likely probe. |
| A5 | "How do you use AI tools in analysis, and how do you check what they give you?" | JD | [grounded] "uses AI tools daily" — the coach's notes | Name two tasks you use them for and how you check the output. Describe nothing you have built. Answer slot: if you have checked an AI-assisted result against a source, say how; if not, say so. | AI is a JD plus (F6). Scored even though casual in tone. |

### Peer Evaluator (weight: 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where is the seam between your team and mine, and what happens when we disagree about a number?" | JD | [generic] open prompt on a peer-seam theme from the persona stems | Propose one seam principle, such as who owns the number and who owns the decision. Do not claim to know his seam. For disagreement, use a time you disagreed with equals, if one comes to mind. If none does, say so plainly and point to B3. | Peer evaluators split seams and test disagreement. No notes-based claim is made, so no quote is needed. |
| B2 | "How would you design the partner motion for the two new lines: who gets which economics, and what do partners do that direct sales does not?" | JD | [grounded] partner-motion design, required (JD highlights you summarised); [grounded] "built a partner-level revenue model used in carrier negotiations" — the coach's notes | Start from the economics, not from programme names. Say what the carrier model put on the partner's side of the table, in your words. Answer slot: if you have designed partner terms, incentives or a programme, say which; if not, say so and say how the revenue model would inform the design. | F4, the required partner-motion requirement. The question presupposes nothing about your past. |
| B3 | "Tell me about a time you got several orgs to agree on one target." | JD | [grounded] "set annual volume targets with cross-org consensus" — the coach's notes | Story map from the sentence: the annual volume targets, reached by cross-org consensus. Beats: whose agreement you needed, where they disagreed, what the final target was. Answer slot: if you did this, say how consensus was reached. If nobody disagreed, say so and do not invent a disagreement. | F5's evidence, and the cross-functional requirement. Turns the peer's collegial probe into your evidence. |
| B4 | "Who would say the partner model was theirs, not yours?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" — the coach's notes | Credit people by role for what they used or shaped. Say "used in carrier negotiations", not "won the negotiations". Answer slot: if you built it with others, say who did what; if it was yours alone, say so. | Credit-sharing is a standard peer probe. The sentence says used, so the guidance says used. |

### Case / Strategist (weight: 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is an AI copilot launch. How would you go to market for it: pricing, packaging, and who buys first?" | CASE, JD | [grounded] "AI copilot launch ('Compass')" and "enterprise expansion" — your research note | Clarify the target (attach, new logos, retention). State the objective, segment the enterprise base, set out the approach with its packaging tiers and unit economics, then name the metric and the risk. Present everything as a plan, not as a past. | Compass is a stated priority. Also covers the JD's go-to-market requirement, F1. Pricing lens matches Dan's career. |
| C2 | "A much larger platform vendor bundles a comparable feature into its suite at no extra cost. What do you do in the next 90 days?" | CO, CASE | [grounded] main competitive threat is bundling by a much larger platform vendor — your research note | Separate where bundling bites: new logos or renewals. Then options: price, partner, or differentiate on the enterprise data layer. Name the one metric you would watch first and its weakest assumption. | The competitive threat from your research note. Bundling is a pricing problem as much as a product one. |
| C3 | "Northwind must reach profitability while two new lines launch. Where would you hold spend first, and what would you measure?" | CO | [grounded] reaching profitability is a stated priority — your research note; [grounded] "built a partner-level revenue model used in carrier negotiations" — the coach's notes | Name the trade-off between launch spend and the profitability goal. Describe the revenue-model approach as a tool you would apply, not a result you have. | Profitability is a stated priority, and the trade-off is what a peer tests. |
| C4 | "How would you find the whitespace across land, adopt, expand and renew for a new data product?" | CASE, JD | [grounded] whitespace across land, adopt, expand and renew — JD highlights you summarised | Segment by lifecycle stage, then by account type. State the SQL pull you would run to size each stage and name one assumption. Answer slot: if you have worked on any stage, say which; if not, say so and walk the method. | F2 is a discovery gap. Without this question the requirement goes uncovered. |

### Skeptic (weight: 3; D1 carries the deepest rehearsal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't set quotas or run sales operations. Why should we trust a sales-strategy call from you?" | JD | [grounded] "No classic sales-ops or quota-setting experience" — the coach's notes; [grounded] "set annual volume targets with cross-org consensus" — the coach's notes | Plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." Then the nearest real thing at its own scope: the annual volume targets, reached by cross-org consensus. Say the difference between a volume target and a quota. Hold through two follow-ups by returning to what you set and what you did not. Concede specifically: name how you would learn quota design, and from whom. Never claim quota work. | Highest-ROI prep in this pack. The only absence in your notes that sits squarely on the JD's sales-strategy scope, and it will be asked in some form. The hold-then-concede structure is what carries the answer. |
| D2 | "Your background is a large consumer-tech company. Enterprise data-infrastructure buyers behave differently. What is your enterprise evidence?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | Answer slot: if you have worked with enterprise buyers, say what, in your own words. If your work was consumer-facing, say so and describe how you would learn enterprise buying, through which accounts or data. | F7 is a discovery gap. The question names your consumer-tech background, which the notes do carry. |
| D3 | "Why leave a large consumer-tech company now?" | EXP | [generic] motivation prompt; no claim about your past | Give your reason in your own words. Your notes give none, so this slot is yours. Do not frame it as a comment on your employer. | A Skeptic's why-now probe. Motivation consistency matters more in a peer round than a reason to leave. |

### Pressure (weight: 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why this over staying in product strategy?" | JD | [generic] motivation prompt | Pause, restate the question, then answer with the content of the role, not your fatigue. Hold the position you give in your own words through two follow-ups. Do not add a motive you have not given. | Time-boxed motivation probe. The hold is the point, not the content. |
| E2 | "That $400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Hold: you proposed it, and the figure is credited to the proposal. Two follow-ups before any concession. Concede specifically where the credit exceeds your part. Never fold on "I proposed it." | The most likely single challenge to the headline claim. Pressure scoring is whether you hold and concede precisely. |

### Conversational (weight: 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" and "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | A 90-second arc in the order of those two sentences, then a bridge to this role. Use your own words for everything in between. | Casual opener. Scored for communication economy, so keep it to the two sentences and the bridge. |
| F2 | "What are you actually playing with in SQL and Tableau these days?" | JD | [grounded] "skilled in SQL/Tableau" — the coach's notes | Name what you use and one thing you have built, in your words. Answer slot: if no build comes to mind, say so. | A casual question on a JD requirement (F3). Treat as scored. |

## Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| GTM strategy for two new product lines | C1, F1 | Fit row F1 |
| Whitespace across land, adopt, expand and renew | C4 | F2 |
| Independent analysis in SQL and Tableau | A4, F2 | F3 |
| Partner-motion design | B2 | F4 |
| Cross-functional influence | B3, B1 | F5 |
| AI experience, a plus | A5 | F6 |
| Enterprise expansion (your research note) | D2, C1 | F7 |
| Sales operations and quota setting (your flagged gap) | D1 | F8 |
| Values-style round | none, and why: none detected for this loop | VAL not used |

Headline metrics: the ~$400M figure is covered by A1, A2 and E2. The carrier revenue model is covered by A3, B2 and B4.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How did the pricing and monetization work shape how you read sales strategy?" | Ties to Dan's own path. Converts the interview into a peer conversation about how he thinks. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity. Shows you are thinking about what you add to his team. Required for a peer round. |
| R3 | "Where does emerging products hand off to sales strategy today, and where does it stall?" | Shows you have thought about the seam he will test in B1. |
| R4 | "How will the two new lines be measured against the profitability goal?" | Uses your research note's priority. Gets a decision-level answer. |
| R5 | "Which of enterprise expansion, Compass and profitability is the hardest trade-off right now?" | Shows you have read the priorities closely and invites a candid answer. |
| R6 | "How is the team thinking about a bundled competitor: pricing, partners or product?" | Uses the competitive threat from your research note. The question asks about the team; it asserts nothing about Northwind. |

## Prep order

Time available was not given, so no schedule is set. The highest-return rehearsal is D1, then A1 and E2 together, since they are the same figure asked two ways.

## Sources

Provided documents: your notes (Priya's background), your JD highlights, your research note (Northwind priorities and the bundling threat), and your summary of Dan's profile.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Refused by the host. Would have settled whether a values-style round exists, and the values cheat sheet. |
| 2. Northwind interview process | unavailable | Refused by the host. Would have named the loop and set persona weights from its rounds; weights here are from the peer prior and your summary. |
| 3. Northwind strategy and recent news | unavailable | Refused by the host. Would have dated the research note's priorities and added recent moves. CO questions rest on your note as provided, unverified for freshness. |
| 4. Dan Kovac and Northwind | unavailable | Refused by the host. Would have added his public talks and writing. The interviewer read rests on your summary. |
| 5. Representative JD for the title | skipped | JD highlights you supplied fix the fit snapshot. Full text would upgrade the rows (see upgrade menu). |

Queries sent, all refused: "Northwind Data values operating principles"; "Northwind Data interview process go-to-market strategy"; "Northwind Data Compass AI copilot enterprise expansion profitability". Each returned no results because the permission was not granted.

## Upgrade menu

- Full JD text → the JD-highlight requirements become quoted rows, and the requirement-coverage table gets exact wording
- Hard terms from the posting (location, office days, travel, work authorization) → hard-gate rows in the fit snapshot
- Web search permission → the three refused research targets run, dating the strategy note, checking the loop and the values page
- Your own answers to the answer slots (for example, how the $400M was counted, or any enterprise work) → new quoted material, which upgrades F2, F3, F7 and A1 to A2
- Confirmation in your own words that the sales-ops and quota gap is as stated → confirms F8 as a plain acknowledgment
- A `tuesday-dossier.md` in context → its verified evidence and prohibited claims would replace the local prohibited list
