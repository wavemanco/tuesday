Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-2-rooms-case-3-denied-af8d39aa/e39148bc-130a-41b7-a84b-ed8679638cbf/scratchpad/stripe_product-operations-manager_interview_pack.md. I built it for a final round with a hiring-manager-style interviewer, since you didn't say who you're meeting. I also had no job description, no CV, and no web research. The web search permission was refused, so I didn't retry, and the company values and interview process are unverified. The fit snapshot is a worksheet, and the questions are generic and labeled that way.

The pack has 13 questions across Case, Skeptic, Prober, Pressure and Values. Start with B1, "Which part of this role would you be weakest at on day one?" It's the most predictable objection for an unknown fit, so it's the highest-value thing to rehearse.

Say the word and I'll play the Skeptic on B1 as a live drill. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Two things would make this much sharper:

1. Who are you meeting, and is it a hiring manager, a peer, a skip-level or a panel? Did the recruiter share focus areas or a take-home? The answer reweights every bank.
2. Could you paste the job description and your CV? If you'd rather not, say "proceed without" and I'll work from the role family alone.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe: Product Operations Manager, final-round prep pack

**Role:** Product Operations Manager
**Company:** Stripe
**Interviewer:** not named. Round type not stated.
**Built as:** a final round with a hiring-manager-style interviewer, because the round is unknown. Flat persona weights are used where the loop is unknown.
**Changelog:** first version. No job description, CV or web research, so the fit snapshot is a worksheet and every guidance cell is `[generic]`.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values | Whether past behavior shows a published value |
| EXP | Work-experience deep-dive | Whether what you did survives scrutiny |
| JD | Role-driven | Whether you can do the listed job, including its gaps |
| CO | Company and strategy | Whether you think at the company's altitude |
| CASE | Live problem | Structure and reasoning on a problem from the role |

Guidance is scaffolding, not a script. Rehearse the shape, then say it in your own words.

## Fit snapshot

No CV, no job description, and nothing about your past in this conversation. The requirements below are role-family prose, not quotes, so they are `[generic]`. Every evidence cell reads `none given`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run cross-team operating processes such as planning, reviews and launches (role family) | none given | none | [generic] | discovery | Your material does not show this yet. Answer slot: name the largest process you ran end to end; if you did not own one, say so, then describe the nearest process you did run |
| F2 | Build metrics and dashboards that surface bottlenecks (role family) | none given | none | [generic] | discovery | Your material does not show this yet. Answer slot: name one metric you tracked and what it was for; if you tracked none, say so, then say what you would measure first |
| F3 | Work with product, engineering and finance leads on prioritisation (role family) | none given | none | [generic] | discovery | Your material does not show this yet. Answer slot: name a prioritisation disagreement you were part of and how it was settled; if you were not part of one, say so |
| F4 | Influence senior stakeholders without direct authority (role family) | none given | none | [generic] | discovery | Your material does not show this yet. Answer slot: name one senior stakeholder you moved, and what moved them; if none, say so and describe how you would approach one |

## Prohibited claims

Built locally. No sentence about your past has been quoted yet, so no inflated form exists yet. The list is kept so the banks are written against it from the start.

| Not coached | Basis | Honest form |
|---|---|---|
| Any past ownership, metric or outcome | No candidate sentence quoted yet; a claim now would be invented | Coached only after you give your own words, quoted and kept at their scope |
| Stripe-specific products, figures or leaders | Not researched; model memory is not a source | Say what you know from public material you have read yourself, and name what you have not read |
| Payments or fintech experience | Not stated | Answer only from what you have actually done |

## Persona weights

Relationship and round are unknown, so there is no interviewer read and no loop source. The generic archetype is used and said plainly: flat weights, tilted to a hiring-manager prior because a final round usually involves the hiring manager.

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problem from the team's operating work | High | Clarify, then objective, approach, metrics, risks |
| Skeptic | Why you, and what is weakest on day one | High | Rehearse the predictable objection until it is plain; no bluffing |
| Data-Driven Prober | How a number was counted | Medium | Name the weakest assumption; say when you do not know |
| Pressure / Stress | Time-boxed challenge | Medium | Pause, restate, hold through two follow-ups, then concede specifically |
| Values / Behavioral | Scenario probes | Low to medium: no values page read and no loop source, so no values round is detected | STAR shape, "I" for your contribution |

Depth: Case 4, Skeptic 3, Prober 2, Pressure 2, Values 2 questions. The bank is thinner than a full pack because the inputs are missing.

## Question banks

**Highest-ROI prep:** B1. The Skeptic's day-one question is the most predictable objection to any candidate with an unknown fit, and it will be asked in some form.

### A. Case / Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch you are responsible for is two weeks late and nobody agrees why. How would you diagnose it?" | CASE | [generic] | Clarify what late means and against which plan. Separate scope, dependency and decision delays. Name the first two data pulls. Propose one decision that unblocks the team | Live problem typical of operations roles; tests structure, not past experience |
| A2 | "Sketch how you would set up a planning cadence for forty people across five product areas. What do you need to know first?" | CASE | [generic] | Clarify team shape, current tooling and decision rights. State the objective, then the cadence layers, the metrics and the risks. Keep it to 90 to 120 seconds | Tests clarify-before-structure; covers F1 |
| A3 | "A metric your team owns dropped 20 percent last month. Walk me through it." | CASE | [generic] | Clarify the definition and whether the drop is real. Segment it. Check instrumentation before the business. Rank hypotheses and say what you would rule out first | Strategist probe; covers F2 |
| A4 | "What company-level problem do you think this team is solving right now, and how would you know if you were wrong?" | CO | [generic] | Say what you know from public material you have read yourself, and name what you have not read. Do not assert current priorities | CO bank without research, so generic and labeled as such |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one specific area honestly. Say what you would do in the first 30 days to close it. Answer slot: if you have run that area before, say where; if you have not, say so plainly | Highest-ROI prep: the predictable objection for an unknown fit, and the answer is tested by follow-ups |
| B2 | "Why operations, and why Stripe, now?" | JD | [generic] | Give your motivation in your own words. Anchor it in one thing you have read or used. Keep it under 60 seconds | Motivation-consistency probe |
| B3 | "This role sits between product and finance. Which side do you usually get wrong?" | JD | [generic] | Name one side honestly, with an example only if you have one. Answer slot: if you have no example, say you would check with each side first | Skeptic probe on fit; covers F3 |

### C. Pressure / Stress (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why should we hire you over someone who has run this kind of work at larger scale?" | JD | [generic] | Pause and restate the question. Answer with the one thing you can show. Hold through two follow-ups. Concede a specific limit rather than folding. Answer slot: if you have run at scale, say so; if not, say so and name the strength you bring | Pressure stem; hold-then-concede structure; covers F4 |
| C2 | "That process you described: how much of it was actually you?" | EXP | [generic] | Answer slot: if the process was yours, name the part; if you led one piece, say which; if you contributed without owning it, say so. Never claim ownership your own words did not give | Attribution probe; tests honesty under pressure; covers F1 |

### D. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you would count the number you would put on this role's dashboard." | JD | [generic] | Describe the definition, the denominator, and the assumption you would defend least. Say you would validate it before relying on it | Prober stem; covers F2 |
| D2 | "Which assumption behind your favourite metric would you defend least?" | EXP | [generic] | Name a metric, its weakest assumption, and how it was counted. Answer slot: if you tracked a metric, name it and how it was counted; if you tracked none, say so | Prober stem; a figure you give raises this slot and no other |

### E. Values / Behavioral (weight: low to medium)

Labeled `[generic]` because no values page was read and no loop source establishes a values round.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to a leader." | VAL | [generic] | Selection scaffold: pick a time it cost you something, a moment you did not fold, and a relationship that stayed intact afterwards. If none comes to mind, say so plainly, then give the nearest thing you have | Open prompt; theme from a persona stem; covers F4 |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Same scaffold: pick an instance, state what you chose and why. If none comes to mind, say so plainly and give the nearest thing you have | Open prompt; the customer-first theme is a stem, not a published value |

## Requirement coverage

No job description was supplied, so coverage maps the role-family requirements in the fit snapshot.

- F1 → A1, A2, C2
- F2 → A3, D1, D2
- F3 → A2, B3
- F4 → C1, E1, E2

## Reverse questions

No interviewer profile, so none is tied to a career path. No peer reciprocity question applies.

1. "What does success look like for this role at six months, and who would tell you first if it were not happening?" Why it lands: it turns the Skeptic's question into a shared test of success.
2. "Which operating problem is costing the team the most time right now?" Why it lands: it shows you think at the team's altitude.
3. "When product, finance and operations disagree on priorities, how does the decision get made?" Why it lands: it tests the seam you would work across.
4. "What did the last person in this role spend most of their time on that they wish they had not?" Why it lands: it signals that you expect the job to be messy.
5. "Which decision in the first 90 days would most shape whether this hire works?" Why it lands: it turns the conversation to your plan.
6. "How does this round weigh against the rest of the loop?" Why it lands: it shows you know the final is one part of a larger process.

## Sources

- **Provided documents:** your message only. It gives the company, the role and a final round. No job description, no CV, no interviewer name.
- **Searches sent (all refused):** "Stripe company values principles official" (stripe.com only), "Stripe interview process Product Operations Manager final round", and "Stripe strategy news 2026". Each was refused because permission to use web search has not been granted in this session. I did not retry.

**Research tier:** L1, searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Refused. No values cheat sheet; no published values are named in the pack |
| 2. Stripe interview process | unavailable | Refused. No loop source, so persona weights are flat and the archetype fallback is stated |
| 3. Stripe strategy / recent news | unavailable | Refused. The CO questions are generic and labeled |
| 4. Interviewer name and Stripe | n/a | No name was given, so no query could be formed |
| 5. Representative Product Operations Manager JD | unavailable | No search sent. Would have supplied quoted requirement wording for the fit snapshot |

## Upgrade menu

- A job description, pasted → the four `[generic]` rows become quoted requirements, and the role-family questions become source-tied.
- Your CV, or your background in your own words → the fit snapshot's evidence cells fill, and the answer slots become story-mapped answers.
- The round type and who you are meeting (hiring manager, peer, skip-level or panel) → persona weights and reverse questions are retuned to that person.
- The recruiter's prep email → focus areas, and any take-home or presentation, get their own build sections.
- Approval of web search → values, loop and strategy research at the default tier, up to 6 searches and 2 fetches. This adds a values cheat sheet and current-strategy CO questions.
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes. It adds a strategy brief and loop reports.
