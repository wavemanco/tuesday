Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/haiku/alone/part-2/rooms/case-4-denied-49f73589/Quartzline_product-manager-platform-apis_interview_pack.md`. I built it for the hiring-manager round you described, using your dossier as the evidence base.

**Before Thursday:** the dossier is dated 14 August, about 14 weeks old. Re-check the posting against the requirement lines and confirm the role is still open and the squad split hasn't changed. Web search was refused in this session, so the pack has no current Quartzline values, interview-process or strategy research. Those gaps are on the upgrade menu.

**What to rehearse most:** the objection the underwriter named, "why hire you into a PM role when you've never held the title or owned a roadmap?" (question A1). Open at scope: you led 30+ end-to-end client integrations from scoping to go-live. Then state the limit plainly, without claiming more. If pressed, hold the trade-off, then concede that you'd be slower to own roadmap decisions at first and would want that ramp planned.

**Lines the pack will not coach:** the dossier's prohibited claims are absolute. You haven't held a PM title or role, owned a roadmap, or set prioritization for an engineering squad. The pack gives you the plain acknowledgment for each, and no answer slot touches them.

**Two places to be ready:**
- **Squad authority (B3, reverse question 1):** don't claim decision rights over either squad. Propose a split and confirm it with the squad leads.
- **Roadmap-input sessions (D2):** they're medium confidence and will probably be probed. Name their limit yourself: the sessions and the evidence they passed to product.

**Reverse questions:** five, all tied to the dossier's open risks. The top ones ask about the squad split and the current adoption baseline.

**Choices I made:**
- Your dossier's pronoun isn't one I should carry over, so I avoided it in the pack.
- I didn't ask any clarifying questions, since the dossier and your message covered the round type, the JD and the evidence.
- I graded R2 to R4 myself, since the dossier pasted here doesn't include its evidence map. Those rows are marked `[inferred]`.

Watch-out: Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Role:** Product Manager, Platform APIs · **Company:** Quartzline · **Round:** 45-minute conversation with the hiring manager, Thursday · **Interviewer:** not named

**Check before Thursday:** the underwriting dossier is dated 14 August 2026, about 14 weeks old. Re-read the posting against the requirement lines below, and confirm the role is still open and the squad split is unchanged. Any change there moves the fit snapshot.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Types used here:

- **JD**: can you do the listed job, gaps included
- **EXP**: do your claims survive scrutiny, and what did you actually do
- **CASE**: structure and reasoning on a live problem from the role

VAL and CO are not used: no values-style round is described, and no company research ran this session. Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

Requirement text is quoted from the dossier's `role_profile`, which stands in for the posting. Evidence is quoted from the dossier's `verified_candidate_evidence`, with the confidence note moved to the Confidence column. Grades for R1, R5 and the roadmap row come from the dossier. Grades for R2 to R4 are this pack's own, so they are marked `[inferred]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence) | low | [inferred] | transferability | Your material shows integration leadership, not product management, so the bridge stops at the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping to go-live." The limit is this pack's observation: the material does not show a PM title or the PM job. The words for it are the plain acknowledgment in the prohibited list, not a bridge. |
| F2 | "own the roadmap for the partner-facing API platform" (dossier role_profile R1 sub-claim) | none given | none | [grounded] | capability | The dossier's `acknowledge_gap` area records the absence, so the words come from it: "I haven't owned a product roadmap." Then a ramp plan, stated as a plan and never as a past. No slot here. |
| F3 | "Shipped API or platform products" (dossier role_profile R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence) | low | [inferred] | transferability | The quote reaches integrations of a product, not a product you shipped. Say the quote at its own scope and stop there. Answer slot: if you shipped anything yourself, name it and your part; if the integrations were of a product someone else shipped, say so. |
| F4 | "Technical fluency: API docs, schemas" (dossier role_profile R3) | "Wrote the internal integration playbook" (dossier verified_candidate_evidence) | low | [inferred] | discovery | The playbook is shown; what it covered is not. Answer slot: if the playbook covered endpoint docs or schemas, say what it covered; if it did not, say so and say how you would learn them. |
| F5 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified_candidate_evidence, medium) | high | [inferred] | presentation | The quotes reach customers and product in their own terms, and architecture and UAT touch engineering. Sales is not in the material. Reword only the quotes: "I ran quarterly sessions that fed client evidence to product." The roadmap-input sessions are medium confidence and expect a probe. Name the limit yourself: the sessions and what they passed on. |
| F6 | "Agile delivery experience" (dossier role_profile R5) | none given | low | [inferred] | discovery | No verified entry speaks to agile delivery, so nothing is quoted. Clarify slot, the dossier's form: "Here's how I'd define agile delivery, and what I'd want to confirm about how this team runs it." If you have worked in a sprint cadence, say where; if not, say so. |

## Prohibited claims

Each entry has a basis and an honest form. Entries 1 to 3 come from the dossier and bind every cell below. Entries 4 to 6 are this pack's own, built from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | dossier `prohibited_claims` | "I haven't held a product manager title or role." Plus F1's quote at its own scope. |
| Having owned a product roadmap | dossier `prohibited_claims` and the `acknowledge_gap` area (R1 sub-claim) | "I haven't owned a product roadmap." Then a ramp plan. |
| Having set prioritization for an engineering squad | dossier `prohibited_claims` | "I haven't set prioritization for an engineering squad." No slot names this claim. |
| Owned the integration playbook | Inflated form of "Wrote the internal integration playbook" | The quote at its own scope. Your material says you wrote it, not that you owned how it is kept or adopted. |
| Decided the architecture for each client integration | Inflated form of "architecture" in the F1 quote | The F1 quote at its own scope. Slots in A2 and E4 ask about calls made, never architecture. |
| Turned client input into product priorities | Inflated form of "feeding client evidence to product" | The F5 quote at its own scope. D2 asks what changed, and its second branch allows that no change can be named. |

## Persona weights

Relationship prior: hiring manager, which the prior weights toward Case/Strategist and Skeptic. The dossier's named objection and its three weak areas push Skeptic to the top. The adoption-metrics responsibility and the medium-confidence roadmap-input evidence push Prober up. No interviewer profile exists, so no interviewer-signal adjustment applies.

| Persona | How it shows up | Likelihood and reasoning | Weight | Counter-strategy |
|---|---|---|---|---|
| Skeptic | "Why hire you into this rather than a PM with the job?" and the gap probes | Highest. The dossier names this objection, and a hiring manager is buying capability and reducing gap risk | 5 | Rehearse the objection until it is plain. Bridge at scope, then concede the limit |
| Case/Strategist | Live problems on partner adoption and squad alignment | High. The responsibilities are discovery, roadmap and adoption metrics, which lend themselves to live problems | 4 | Clarify, then structure, then name metrics and their weakest assumption |
| Data-Driven Prober | Counting the 30+, the roadmap-input sessions and the adoption baseline | Medium. The Q1 figure and the Q3 evidence will be probed | 3 | Know how each figure was counted, and say plainly when you do not know |
| Pressure | Interruptions on the roadmap and the 30+ figure | Medium. Pressure tests composure on the one gap that matters | 3 | Hold through two follow-ups, then concede the specific uncertainty |
| Conversational | "Walk me through the journey" and a casual question on API docs | Lower, but casual questions are scored | 2 | A 90-second arc, with the gap named in one sentence |
| Peer Evaluator | Where the seam sits between two squads and what happens when you disagree | Lower. The role sits between two squad leads, so a peer's view is plausible | 2 | Propose seam principles, not claims about past seams |

## Question banks

Questions are scored by type. Guidance cells cite the quotes they rest on, so every claim about your past is one you can check.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence). The two negatives are sourced to dossier prohibited_claims and the acknowledge_gap roadmap area. | **Highest-ROI prep in this pack.** The underwriter named this objection, so rehearse it most. Open at scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping to go-live." Then the limit: "I haven't held a product manager title or owned a roadmap, and I won't present the integration work as either." Then what you bring, and what you'd need to learn: roadmap ownership. Follow-up one ("but why us?"): return to the integration work, described in its own terms. Follow-up two ("a PM with three years will be faster"): hold the trade-off, then concede the specific point, that you would be slower to own roadmap decisions at the start and would want that ramp planned. Do not add a PM story to close the gap. | F1 is the evidence for the PM requirement and the likeliest place to be pressed. JD because it scores the stated requirement. The question carries two negatives, and both have a source. |
| A2 | "Which of your decisions on the integrations do you point to as yours, and which were set by the client or someone else?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on F1: the integrations, from scoping to go-live. Answer slot: if you made any of the calls on an integration, say which and how you decided; if the client or the team made them, say so plainly and describe what you did within them. | F1 is the evidence and this is the probe it invites. The slot asks about calls, which the material does not claim you made. |
| A3 | "Name a platform or API product you shipped end to end." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: if you shipped a product yourself, name it and your part in your own words. If your work was integrations of a product someone else shipped, say so, and describe the integrations at their own scope. | F3 is the requirement this question scores, and the honest answer may be the second branch. |
| A4 | "How would you build and defend a roadmap for partner APIs in your first 90 days, without having owned one?" | JD | [grounded] dossier acknowledge_gap, the R1 roadmap sub-claim, named by field: "I haven't owned a product roadmap." | Plain acknowledgment, then a plan: the inputs you would gather first, such as partner interviews, adoption data, and the squad leads' view of priorities. No slot and no bridge on this area. | F2 is a capability gap the dossier records. The answer is an acknowledgment and a ramp, never a claim of past ownership. |
| A5 | "How do you run agile delivery with two engineering squads?" | JD | [generic] | Clarify slot, the dossier's form: "Here's how I'd define agile delivery, and what I'd want to confirm about how this team runs it." If you have worked in a sprint cadence, say where; if not, say so. | F6 is a discovery gap: no verified entry speaks to it, so the answer is a clarification, not a bridge. |

### B. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Thirty integrations. How much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause, then restate the question. Hold: "I led the end-to-end work on 30+ integrations, from scoping to go-live." Follow-up two: "I can't split every call on each one from memory, and I'd rather say so than guess." Concede the specific uncertainty: which calls on each integration were yours. Do not claim more than the quote holds. Answer the figure's weakest assumption in your own words, which is how the count was kept. If you do not know, say so. | F1's figure is the one the pressure will land on. Hold-then-concede keeps the position the quote carries and admits the unknown. |
| B2 | "Adoption is flat. Do you wait for the squad leads' view, or do you move first?" | JD | [generic] | Hold the position: the adoption baseline comes first, and you would ask for it before committing to a view. Follow-up one: say what you would ask the squad leads. Follow-up two: concede that you would move only after the baseline is agreed, even if that costs time. Do not claim you have set a baseline before. | No quote is needed: this is a plan position, not a past claim. Adoption metrics are a responsibility in the role, and the baseline is an open risk in the dossier. |
| B3 | "Who decides on this roadmap, you or the squad leads?" | JD | [generic] | Answer as a proposal: the split should be agreed with the squad leads in the first weeks, and you would propose one and confirm it with them. Do not claim authority over either squad. | The squad-authority split is the dossier's largest open risk, and this is where it is pressed. |

### C. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Partner adoption of our API is stalling. Where do you start?" | CASE | [generic] | Clarify first: which partners, which integration type, and what stalled. Then the objective, a segmentation, an approach, the metrics, and the risks. Think aloud, and challenge one premise respectfully. | A live problem from the role's adoption responsibility. It asks about no past, so the guidance makes no claim. |
| C2 | "Sketch how you would define and track adoption for a partner API product." | CASE | [generic] | Define the adoption event first, then the metric you would defend, then its weakest assumption, named before the interviewer names it. | The JD's "define and track adoption metrics" is the raising source, and the weakest-assumption move is the scored bar for a metric answer. |
| C3 | "Two squads want to ship in the same quarter and their roadmaps conflict. What do you do?" | CASE | [generic] | Clarify who holds the decision, then the trade-off and the options, then how you would take it to the squad leads. Do not claim you have decided between squads before. | Covers the "write specs and drive delivery with two engineering squads" responsibility and F5's engineering stakeholder. |
| C4 | "How would you run discovery with integration partners?" | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what you would ask a partner first, and where the scoping work on client integrations gives you a starting list. Answer in your own words. | The "run discovery with integration partners" responsibility is the raising source. The guidance draws on the scoping in F1, and nothing beyond it. |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you counted the 30-plus integrations." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: say how the count was kept, in your own words. If you cannot reconstruct how it was counted, say so. Name the assumption behind the figure you would defend least. | F1's figure, which the defend-the-number rule requires. Say the figure only as it was counted. |
| D2 | "What changed in product because of the roadmap-input sessions?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Answer slot: say what the sessions were and what evidence went to product. If you can name a change in product, say what it was and what part was yours. If you cannot name one, say so. Say the medium-confidence limit yourself: the sessions, and the evidence they passed on. | F5's medium-confidence evidence is the likeliest probe. The question presupposes a change the quote does not carry, so the second branch must allow there was none to name. |
| D3 | "What is the current adoption baseline, and how is it counted today?" | JD | [generic] | Answer slot: if you know the baseline, say how it is counted. If you do not know it, say so, and say what you would ask first. | Adoption metrics are a responsibility in the role, and the dossier records no baseline. This is a question the candidate can ask in return, so it is also reverse question R2. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in three beats, one per quote: the integrations, the playbook, the roadmap-input sessions. Close with what you want next, and name the PM gap in one sentence rather than at length. | Casual openers are scored. The arc uses only the three quotes, and no more. |
| E2 | "What are you actually working with in API docs and schemas these days?" | JD | [grounded] "Wrote the internal integration playbook" | Answer slot: say what you have worked with in docs or schemas. If the playbook covered them, say how. If it did not, say so, and say what you would learn first. | F4 is the requirement this question scores, and R3 has its own JD question here. |

### F. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-1 | "Our two squads sit side by side — where's the seam, and what happens when we disagree?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Propose seam principles, not claims about past seams. Answer slot: if you have disagreed with an engineering lead about an integration, say what happened and how it ended. If you have not, give the principle you would use. | F5's engineering stakeholder work is the raising source. R4 is covered by this question and C3. |
| F-2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: say which part of the 30+ was yours to lead, and whose the rest was, in your own words. Use "we" for the team's work and "I" for what you led. | The 30+ is the one shared-work claim in the material, so credit is where a peer will test it. |

## Requirement coverage

| Requirement | Questions covering it |
|---|---|
| R1: 3+ years product management experience (must) | A1 (JD), A2, A4 |
| R2: Shipped API or platform products (must) | A3 (JD), A1 |
| R3: Technical fluency, API docs and schemas (important) | E2 (JD), F4 |
| R4: Stakeholder management across engineering, sales, customers (important) | F-1 (JD), C3, D2 |
| R5: Agile delivery experience (preferred) | A5 (JD) |
| Roadmap ownership (R1 sub-claim) | A4, B3 |
| Discovery with integration partners | C4 |
| Adoption metrics | C2, D3, B2 |
| Squad delivery and specs | C3 |

## Reverse questions

Use these at the end. The hiring manager's own career path is not known, so none is tied to it.

1. **"Which roadmap decisions does this PM make alone, and which belong to the squad leads?"** Why it lands: the squad split is the largest open risk in the dossier. Asking it reads as diligence, and you need the answer before accepting.
2. **"How is partner API adoption measured today, and what is the current baseline?"** Why it lands: the dossier records no baseline, and the adoption responsibility is unmeasured on paper. The question shows you read the job, not only the title.
3. **"What would make this role's first 90 days a success, in terms the squad leads would agree with?"** Why it lands: it tests the ramp expectation that the roadmap gap depends on. It also gives you the hiring manager's own view of the ramp.
4. **"How do the two squads plan their work today — sprint cadence, and who sets the order?"** Why it lands: it tests the agile gap (R5) and whether delivery sits inside the product org or beside it. It answers something you need before accepting.
5. **"What did the last person in this role spend most of their time on that they would have changed?"** Why it lands: it gets past the job description to the real week, and shows you are thinking about the job rather than the title.

## Sources

- **Provided documents:** the underwriting dossier `tuesday-dossier.md` (version 1.1, generated 2026-08-14). Consumed. It supplied:
  - `handoff_to_mock_interview`: verified evidence, weak-area strategies, the named objection, risks and employer questions, and `prohibited_claims`
  - `role_profile`: requirement text, which satisfies the JD tier
  - `verified_candidate_evidence`: which satisfies the CV tier
  - `decision`: context only (conditional_go)
  - `evidence_state` and `risk_register`: absent from the dossier

  The dossier's `evidence_map` was not in the pasted text, so R2 to R4 are graded by this pack and marked `[inferred]`.
- **Searches sent:**
  - "Quartzline API platform product manager": refused

Research tier: L1, searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | No call succeeded (search refused). Would have moved the values cheat sheet, which is dropped here since no values-style round is named |
| 2. Quartzline interview process, role family | unavailable | Search refused. Would have moved loop structure. Persona weights follow the relationship prior and the dossier instead |
| 3. Quartzline strategy and recent news | unavailable | Search refused. Would have moved the grounding brief and any CO questions. The pack has none, since the dossier carries no current strategy |
| 4. Interviewer name and company | n/a | No name given, so there was no query to form |
| 5. Representative JD | skipped | The dossier's `role_profile` fixes the fit snapshot and the JD questions |

## Upgrade menu

- The interviewer's name → a tailored reverse question, and persona weights read from their public footprint
- Web search permission → the three refused targets above: current values, the interview process and current strategy. That adds CO questions and a grounding brief
- The posting, if it has changed since August → the requirement quotes in the fit snapshot update
- How many hours you have before Thursday → a prioritized prep triage with question IDs
- Your raw CV → any further sentences that can ground F3 and F4 beyond the three quotes
- A deep research pass (L2) → strategy brief, interviewer talks, and role-family loop reports. Offered once; it runs at most 6 further searches and 2 further fetches, and takes several minutes
