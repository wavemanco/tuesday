I'll load the mock-interview skill to build this prep pack from your dossier.
The skill's rules are loaded. The dossier covers the role and evidence, but nothing yet tells me about Quartzline's current strategy, which the competency questions depend on. I'll load the search tool and run a small L1 check.
Both searches were refused (permission not granted), so I'll build the pack from your dossier and record the refusals in the Sources section. Writing the pack file now.
Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-2-rooms-case-4-denied-4d15a852/a3717254-5941-4d29-9357-18dffdf76a14/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md`. I built it for the hiring-manager round, using your dossier as the source for the role and your evidence.

The main thing to rehearse is A1, the objection your dossier named: "You've never held the PM title or owned a roadmap — why should we hire you into one?" The answer concedes the premise in one sentence, bridges with the integration work at its own scope, states the limit before you're asked, and gives a ramp plan framed as a plan rather than a past. The pack also covers the Skeptic, Case, Prober, Pressure and Conversational personas, and includes six reverse questions. Two of those come straight from your dossier: who decides roadmap calls versus the squad leads, and the current adoption baseline.

Things to know before Thursday:

- **Research didn't run.** Both web searches were refused because search permission wasn't granted. The pack has no Quartzline strategy or values content, so the strategy-grounded questions are missing. If you grant search and I rerun it, that content can be added.
- **The dossier is about three months old** (generated 14 August). If the posting has changed, a refreshed dossier would update the rows it feeds.
- **Some answers are slots, not scripts.** Where your material doesn't show something (for example, sales or engineering work, or whether you can point to a roadmap item the input sessions changed), the pack gives you the honest branch rather than a made-up example.

If you'd like, I can play the Skeptic on A1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry forward, and convert the pack to Word if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** 45-minute conversation with the hiring manager (single session).
**Built from:** your underwriting dossier (`tuesday-dossier.md`, generated 2026-08-14, decision `conditional_go`). Live research did not run (see Sources).

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **Type key:** **JD** = the role's stated responsibilities and requirements. **EXP** = what you actually did, checked closely. **CASE** = a live problem from the role, scored on structure. (VAL and CO are not used: no values-style round was detected, and no current strategy was retrieved.)
- Guidance is scaffolding, not a script. Practise saying it in your own words, then check every sentence against what you actually did.

## Fit snapshot

Requirements come from the dossier's `role_profile`, which satisfies the JD input. Evidence is quoted from the dossier's `handoff_to_mock_interview.verified_candidate_evidence` and `uncertain_or_weak_areas`. No gate is listed in the dossier, so no `hard_gate` row appears.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence; "Wrote the internal integration playbook her team uses" — dossier verified evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence | low | [inferred] | transferability | Adjacent work only. The integrations, the playbook and the input sessions are real, but none is a PM title or PM years. Say the integration work in its own terms, then name the limit yourself: this is adjacent to product management, not PM experience. |
| F2 | "Owning a roadmap and prioritization authority" (dossier weak area, R1 sub-claim) | none given. Dossier prohibited_claims and acknowledge_gap areas apply | none | [grounded] | capability | Stated absence, recorded in the dossier. Plain acknowledgment: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Then a ramp plan, said as a plan and never as a past. |
| F3 | "Shipped API or platform products" (dossier role_profile R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence | high | [inferred] | transferability | The quote reaches the APIs, through client integrations. It does not show a product shipped. Say the integrations as they are; the limit is the pack's observation, not something to add. |
| F4 | "Technical fluency: API docs, schemas" (dossier role_profile R3, important) | "Wrote the internal integration playbook her team uses" — dossier verified evidence | high | [grounded] | presentation | Your material already reaches documentation. Say it in the quote's terms: "You wrote the internal integration playbook your team uses." Add no detail to it. |
| F5 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence | medium | [grounded] | transferability | Your material reaches customers and product. It does not show engineering or sales. Answer slot: if you worked with engineering or sales on an integration, say which and how, in your own words; if you did not, say so and stay with customers and product. |
| F6 | "Agile delivery experience" (dossier role_profile R5, preferred) | none given | low | [grounded] | discovery | Evidence may exist and the material does not show it. Answer slot: if you ran a delivery process with a team, say which team and your part; if you have not worked inside an agile product org, say so plainly and say what you would learn first. |

**Why these gap types:** F2 is `capability` because the dossier records the absence. F1 and F5 are `transferability` because adjacent evidence exists but does not reach the requirement. F4 is `presentation` because the quote already reaches the requirement in other terms. F6 is `discovery` because nothing is established either way.

## Prohibited claims

Each entry has its basis and its honest form. None of these may be asserted, softened or implied in any answer.

| Not coached | Basis | Honest form |
|---|---|---|
| Held a product manager title or role | Dossier prohibited_claims and acknowledge_gap | Plain acknowledgment: "I haven't held a product manager title or role." No answer slot. |
| Owned a product roadmap | Dossier prohibited_claims and acknowledge_gap | Plain acknowledgment: "I haven't owned a product roadmap." No answer slot. |
| Set prioritization for an engineering squad | Dossier prohibited_claims | Plain acknowledgment: "I haven't set prioritization for an engineering squad." No answer slot. |
| Decided what went on the roadmap | Inflated form of "Ran quarterly roadmap-input sessions feeding client evidence to product" | That quote at its own scope. The limit is the pack's observation: your material says you ran the input sessions, not that you decided the roadmap. |
| Owned the integration or API roadmap | Inflated form of the integrations quote | That quote at its own scope. Its limit is the same: integrations led, not roadmap owned. |
| Shipped API or platform products | Inflated form of the integrations quote (F3) | The integrations quote at its own scope. The limit is the pack's observation, as in F3. |

## Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| **Skeptic** | Presses the gap: "why you, not a PM with the years." | **Top weight, 5 questions.** Hiring managers buy capability and derisk gaps. The dossier names the objection, and F2 is the one record of a stated absence. | Rehearse the single objection until it is plain. Concede the premise in one sentence, bridge only with quoted evidence, name the limit, give a ramp plan. |
| **Case / Strategist** | Live problems from the role: partner adoption, decisions between squads, cadence. | **4 questions.** Hiring managers test judgment on their actual roadmap. The JD names these responsibilities, so the questions can come straight from them. | Clarify, then structure, then decide. Ask for the metric definition and the decision owner first. Make no past claim. |
| **Data-Driven Prober** | Asks how the 30+ figure was counted and what the playbook actually contains. | **3 questions.** The only figure in your material is the integration count, so the prober will go there. | Say how you counted, name the assumption you would defend least, and say which parts were yours. |
| **Pressure** | Interrupts and challenges the premise: "integrations aren't a roadmap." | **3 questions.** Lower than the Skeptic, but the objection invites pressure. Hold once, then concede specifically. | Pause, restate, hold the bridge through two follow-ups, concede exactly where the material is thin. |
| **Conversational** | A casual opener and a casual question about partner work. | **3 questions.** Friendly openers are still scored. | A 90-second arc with the limit stated in one line before you are asked. |

Total: 18 questions, weighted 5 / 4 / 3 / 3 / 3.

## Question banks

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "I haven't held a product manager title or role, and I haven't owned a product roadmap." (dossier acknowledge_gap and prohibited_claims); "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified evidence); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified evidence) | **The highest-ROI rehearsal in this pack.** The underwriter named this objection from evidence you confirmed. (1) Concede the premise in one sentence: "I haven't held the PM title or owned a roadmap." (2) Bridge with the integrations quote, at its own scope. (3) Name the limit before you are asked: integration leadership is not roadmap ownership. (4) Give a ramp plan as a plan: what you would do in the first months to earn prioritization calls. Hold through two follow-ups by returning to the integrations and the input sessions. Do not add roadmap authority. Concede specifically: a PM with three years of roadmap work has prioritization judgment you have not yet shown. Answer slot (input sessions): if any roadmap decision was yours, say which; if none was, say so plainly and say what the sessions gave product. | F1 and F2 are the objection's source. The dossier wrote this exact question, and its negatives are sourced to the acknowledge_gap and prohibited_claims fields, so it is asked as written. |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I haven't owned a product roadmap." (dossier acknowledge_gap); "Own the roadmap for the partner-facing API platform" (JD, dossier role_profile) | Name roadmap ownership first, in A1's words. Then name prioritization across two squads. Then the ramp plan. Do not present the integrations as roadmap experience. | F2 is the weakest area; the JD line makes the probe likely. |
| A3 | "Which roadmap decisions would you make alone, and which would you bring to the squad leads?" | JD | [generic] a pattern for product roles, which usually split decisions by scope; no claim about you | Answer prospectively. Name the decisions you would own, such as partner-facing scope and what to decline, and those you would bring to the squad leads, such as engineering sequencing. Present this as a plan, not a memory. Then ask what the current split is. | The dossier lists decision authority as unevidenced. This question lets you show judgment without claiming a past. |
| A4 | "Have you ever set prioritization for an engineering squad?" | JD | [grounded] "I haven't set prioritization for an engineering squad." (dossier prohibited_claims) | Say the plain acknowledgment in one line. Then the nearest thing your material carries: "Ran quarterly roadmap-input sessions feeding client evidence to product." Do not stretch the input sessions into setting priorities. Hold once, then concede. | F2 and the prohibited list both apply. |
| A5 | "The JD asks for discovery with integration partners. What have you done closest to that?" | JD | [grounded] "Run discovery with integration partners" (JD, dossier role_profile); "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified evidence) | Answer with the scoping and requirements from the integrations, at client scope. Name the limit: client scoping is not discovery on a platform roadmap. Answer slot: if you ran discovery with partners beyond scoping, say how, in your own words; if you did not, say so plainly. | F1 and F3. This is a transferability case, so the limit comes with it. |

### B. Case / Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner says adoption of the new endpoint is flat after launch. What do you check first?" | CASE | [generic] a live problem from the role; no claim about you | Clarify first: what adoption means for this endpoint, and whether a baseline exists. Then segment partners by integration stage. Then test whether blockers are docs, schemas or auth. Say what you would ask before you propose a fix. | The dossier lists adoption measurement as unknown. This question makes you reason about it without inventing a baseline. |
| B2 | "Two squads disagree on a deprecation timeline for an API version. How do you run that decision?" | CASE | [grounded] "Write specs and drive delivery with two engineering squads" (JD, dossier role_profile) | Clarify who owns the call and which partners depend on the old version. Then the options: keep, sunset with partner notice, or stage it. Name the decision owner you would propose and how you would take it to the squad leads. No past claim. | The squad-authority question, asked as a live problem. |
| B3 | "Partners keep asking for a feature we haven't prioritized. Walk me through how you'd decide." | CASE | [grounded] "Run discovery with integration partners" (JD, dossier role_profile) | Structure: what the requests have in common, whether they reflect a shared workflow, the cost against likely adoption, and what you tell partners who wait. Keep it spoken and short. | JD discovery responsibility, as a decision problem. |
| B4 | "How would you run delivery with two squads on different cadences?" | JD | [generic] a pattern for two-squad delivery; no claim about you | Clarify what the hiring manager means by agile here: sprints, quarterly plans or both. Answer slot (R5): if you ran a delivery process with a team, say which and your part; if you have not worked inside an agile product org, say so plainly and say what you would learn first. | F6 is `discovery` with `clarify`. The slot names the requirement's own wording. |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How many of the 30+ integrations did you lead end to end, and how did you count them?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified evidence) | Defend the number. Say how you counted, in your own words. Name the assumption behind the count that you would defend least. Say which parts of the end-to-end list were yours. If you did not keep a count, say so. | F3 is the only figure in your material. The prober will test it, so the count and its assumption must be yours to state. |
| C2 | "Walk me through the integration playbook: what's in it, and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" (dossier verified evidence) | Describe only what you can speak to from the playbook. Say who uses it in the quote's words. Answer slot: if any part was written by someone else, say which. Add no features or sections you cannot name. | F4. The playbook is the inspectable artifact that backs this claim. |
| C3 | "What happened to the evidence you fed into those input sessions?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified evidence) | Medium confidence: volunteer the limit before a prober finds it. Say what the sessions fed to product, in those words. Answer slot: if you can point to a roadmap item that changed, say which and how the evidence got there; if you cannot, say so plainly and stay with what the sessions gave product. | F5. The dossier flags this claim as thin, so expect a probe. |

### D. Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That's a lot of integrations, but integrations aren't a roadmap. How much of that was actually you?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified evidence); "Wrote the internal integration playbook her team uses" (dossier verified evidence) | Pause, then restate the question. Answer by listing the integrations you led and which of the listed stages you did yourself, at the quote's scope. Hold through two follow-ups by returning to that list. Concede: roadmap ownership is not in what you have shown. | F1 and F3. Pressure rehearses holding the position without folding, and also conceding without becoming defensive. |
| D2 | "A partner has told us your integration playbook is out of date. What do you do?" | CASE | [grounded] "Wrote the internal integration playbook her team uses" (dossier verified evidence) | A hypothetical, so it asks about no past. Clarify which parts are out of date and who maintains the playbook. Then the fix path: update, re-date, or hand off. No answer slot here. | F4. It tests how you handle criticism of your own artifact. |
| D3 | "Hold on — you're saying you haven't owned a roadmap. What makes you think you can prioritize?" | JD | [grounded] "I haven't owned a product roadmap." (dossier acknowledge_gap and prohibited_claims) | Hold once: restate the scope as prioritization of integration work, with the input sessions as the nearest thing. Concede specifically: prioritization judgment at roadmap level is unproven, and it is what you would build first. | F2. A held position must be one the material carries. Here it is the integrations, not roadmap authority. |

### E. Conversational (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified evidence); "Wrote the internal integration playbook her team uses" (dossier verified evidence); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified evidence) | A 90-second arc: the integrations (in the quote's order), the playbook, the input sessions. State the limit in one line before you are asked: this is integration leadership, not roadmap ownership. Then why this role. | The opener is scored. The limit comes first, so it is not extracted later. |
| E2 | "What's the most interesting problem you've hit on a platform API?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified evidence) | Open prompt: pick one integration from that list and say what was hard, in your own words. If no single problem comes to mind, say so and give the nearest one. | F3. "Shipped API or platform products" is the requirement, so this tests the API side without claiming a product. |
| E3 | "Our partners can be vocal. How do you handle one who wants everything?" | JD | [grounded] "Run discovery with integration partners" (JD, dossier role_profile) | Open prompt: pick a partner who pushed back on scope. Map the scoping and requirements beats from the integrations quote onto it. If none comes to mind, say so and give the nearest. | F5 and the partner-discovery responsibility. |

### Requirement coverage

| Requirement or responsibility | Covered by |
|---|---|
| R1: 3+ years product management experience | A1, A2, D3 |
| Roadmap ownership (R1 sub-claim) | A1, A2, A3, A4, D3 |
| R2: Shipped API or platform products | C1, E2 |
| R3: Technical fluency, API docs, schemas | C2, D2 |
| R4: Stakeholder management, engineering / sales / customers | B2 (engineering), E1 (customers); sales: none, and why: no sentence in your material reaches sales |
| R5: Agile delivery experience | B4 |
| Run discovery with integration partners | A5, B3, E3 |
| Define and track adoption metrics | B1 |
| Decision authority vs. squad leads (dossier unknown) | A3, B2 |
| Named objection (dossier likely_interviewer_objections) | A1 |

## Reverse questions

Ask these of the hiring manager. Each has a "why it lands."

1. **"Which roadmap decisions does this PM make alone, and which belong to the squad leads?"** [grounded] Dossier `questions_for_employer`. *Why it lands:* it resolves the decision-authority unknown, which is the thing you most need answered before accepting.
2. **"How is partner API adoption measured today, and what is the current baseline?"** [grounded] Dossier `questions_for_employer`. *Why it lands:* the JD makes adoption a responsibility but states no baseline. Asking shows you noticed and tests whether one exists.
3. **"How does discovery with integration partners get scheduled and owned right now?"** [grounded] JD line "Run discovery with integration partners" (dossier role_profile). *Why it lands:* it checks whether partner discovery is a process or an improvised task, which decides how much of your scoping experience carries over.
4. **"What would you need to see from someone in this role by the end of the first quarter?"** [generic] A standard hiring-manager question. *Why it lands:* it turns the objection into a shared definition of success.
5. **"Where is the seam between the two squads hardest to keep aligned right now?"** [generic] A standard question about team structure. *Why it lands:* it shows you are thinking about the work, not only the job title, and surfaces the decision-authority risk in the interviewer's own words.
6. **"What did the last person in this role get right, and what would you have them do differently?"** [generic] A standard question about the role's history. *Why it lands:* it gives you the hiring manager's real priorities and a signal of what they are willing to change.

## Sources

- **Provided documents:** `tuesday-dossier.md` (job-underwriter, dossier_version 1.1, generated 2026-08-14). Sections consumed: `role_profile` (requirements and unknowns), and `handoff_to_mock_interview` (verified evidence, weak areas, likely objection, risks, employer questions, prohibited claims). **The dossier is about three months old:** if the posting or the role has changed since August, the rows it feeds may need refreshing.
- **Round type:** from your message (45-minute hiring-manager conversation).

**Research tier: L1 — searches 2 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Refused: search permission was not granted. Would have moved the values section, which was dropped because no values-style round was detected. |
| 2. `Quartzline interview process` (product role family) | unavailable | Not sent: search permission was refused. Would have moved the loop structure, meaning whether more rounds follow this one. Persona weights here assume a single session. |
| 3. `Quartzline strategy` / recent news | unavailable | Refused (query: `Quartzline platform APIs partner integrations`). Would have moved the CO bank: no strategy-grounded question was written. |
| 4. `{interviewer name} Quartzline` | n/a | No interviewer name was given, so there was no query to form. The interviewer read is absent. |
| 5. representative JD for the title | skipped | The dossier's `role_profile` fixes the requirements, so no representative JD was needed. |

## Upgrade menu

- **Search permission, or pasted pages** (Quartzline's values page, or a current strategy or partner announcement) → a values section if the round turns out to be values-style, and a strategy-grounded CASE question.
- **Interviewer's name** → persona weights and a reverse question tied to their own career path.
- **Inspectable proof for the input sessions** (notes from one session, or a roadmap document you fed) → moves F5 and C3 from medium toward high confidence, and gives C3 a named artifact.
- **A sales-facing example** → covers the sales part of R4, which currently has no question.
- **Refreshed dossier** (if the posting changed since August) → updates every row the dossier feeds.
- **Deep research (L2)**, offered once: four further targets (strategy brief, interviewer talks and writing, role-family loop reports, recent organisation context), at most 6 further searches and 2 further fetches. Same permission needed.
