Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-5-rooms-case-9-canned-722e4363/5d86a35e-3962-4b6a-b54e-f98010dce4b2/scratchpad/Halvering_fourth_grade_teacher_interview_pack.md`. I built it from your invite and resume with no job posting, so the requirements come from the invite alone.

**What the pack says:**
- **Your license is your strongest point.** Your resume shows the Illinois PEL with the elementary endorsement active through June 30, 2029, which meets the invite's requirement. Check the status on the ISBE license lookup before Thursday.
- **Your biggest gap is fourth grade.** Expect a probe on it, so rehearse this one most. Say "I haven't taught fourth grade," then give a concrete plan for your first month, not a claim about past experience.
- **Team lead is the second gap.** Say "I've never been a team lead," then describe the 2024 curriculum move at its own scope. Be ready to say which decisions were yours.
- **Your reading club and weekly family email** map to the district's published beliefs, "Every Child a Reader" and "Families Are Partners." The third belief, "Teach for Tomorrow, Not for the Test," has no story in your material, so the pack gives you a selection prompt and a fallback answer.
- **The pack includes two banks of questions.** The principal bank is weighted toward skeptical questions. The peer bank covers how you measure results and how you'd work with the team.
- **Reverse questions** are included, with one tied to how the district carries a third-grade reading plan into fourth grade.

**What I did not do:** I didn't research the principal, Dolores Vantongeren, so the pack has no profile-based tailoring. I also didn't search the interview format. Send her public profile or the full job posting if you have them, and I can update the pack.

**Your Social Security number:** I didn't use it or repeat it anywhere, and a school district doesn't need it before an offer. Don't send it by email or share it in the interview.

**Next steps:**
- Would you like me to play the skeptical principal on question A1? It's the most likely probe.
- I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
- If you want the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth_grade_teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Orrinsford Community School District** · Panel: Principal Dolores Vantongeren + two fourth-grade team members · 45 minutes · Thursday

**Built on:** your invite, your resume, and your message. No job posting was supplied, so requirements come from the invite only.

## 1. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: JD (role requirements), EXP (your past work), VAL (district values), CASE (a live problem), CO (knowledge of the district).
- Guidance is scaffolding, not a script. Aim for 90–120 seconds per answer.
- **Answer slots** are instructions for the interview. Answer them from your own experience, in your own words. If the practice was not yours, say so plainly.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | Gate shown met by your CV. Confirm the status on the ISBE license lookup before Thursday; that check is yours. |
| F2 | Fourth-grade teaching experience (role title, invite) | "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | medium | [grounded] | capability | Words: "I haven't taught fourth grade." Then the adjacent work at its own scope: "Six years teaching third grade." Answer slot: how you would learn the fourth-grade content in your first term. Describe a plan, never a past. |
| F3 | Working on a grade-level team (invite: "two members of our fourth-grade team") [generic] | "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've never been a team lead" (your message) | medium | [generic] | capability | Words: "I've never been a team lead." Then the 2024 move at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: which decisions in that move were yours, and which were made by others. |
| F4 | Families as partners (district beliefs, fetched) [grounded] | "I write a weekly email to families" (your CV) | medium | [grounded] | presentation | The weekly email is a real channel but not a conversation with each family. Reword only the quote: "I write a weekly email to families." Answer slot: any other family contact you have had, and how often. |
| F5 | Reading instruction (district belief "Every Child a Reader") [grounded] | "I've run the after-school reading club for the last two years" (your CV) | medium | [grounded] | none | This reaches the belief in role-relevant terms. Answer slot for any outcome: say what you saw, and say so if you did not track it. |

**Gap types:** `capability` means you stated the absence. `transferability` means adjacent work that does not reach the requirement. `presentation` means a quote that reaches it in other terms. `none` means no gap.

## 3. Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Fourth-grade experience | Inflated form of F2 (third grade stretched to cover fourth) | "I haven't taught fourth grade." Plus "Six years teaching third grade" at its own scope. |
| Team lead experience | Inflated form of F3 (a curriculum move stretched to "I led the team") | "I've never been a team lead." Plus the 2024 move at its own scope. |
| Reading-club results or test gains | No quote gives any result; supplying one would be invention | Answer slot only: what you saw, or that you did not track it. |

## 4. Persona weights

| Interviewer | Relationship prior | Likely personas | Weight and reasoning |
|---|---|---|---|
| Principal Dolores Vantongeren | Hiring manager | Skeptic (4), Case/Strategist (2) | They are buying capability and checking the gaps in F2 and F3. Expect live problems from fourth grade. |
| Fourth-grade team member 1 | Peer | Data-Driven Prober (2), Peer Evaluator (2) | Peers price what you add to their work. Probes will be collegial. |
| Fourth-grade team member 2 | Peer | Peer Evaluator (2), Conversational (1) | Same; expect questions about seams between classrooms. |

*Interviewer names beyond the principal were not supplied. The principal's public profile was not researched; see the upgrade menu.*

## 5. Values cheat sheet (published beliefs, fetched from the district's "Mission and Beliefs" page)

| Belief (official name) | Working meaning | Your mapped story |
|---|---|---|
| Every Child a Reader | No student leaves third grade without a reading plan. | "I've run the after-school reading club for the last two years." Answer slot: what you did in the club and what you saw. |
| Families Are Partners | Each teacher speaks with every family each term. | "I write a weekly email to families." Answer slot: any direct contact beyond the email. |
| Teach for Tomorrow, Not for the Test | Assessments inform teaching and never replace it. | None of your quotes carries this. Selection scaffold: pick a time an assessment changed what you taught next. If none comes to mind, say so plainly, then describe how you would use one. |

## 6. Question banks

### Principal bank (Skeptic and Case; 6 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. What would you do in your first month?" | JD | [grounded] "I've never taught fourth grade" (your message) | **Highest-ROI prep.** Plain acknowledgment: "I haven't taught fourth grade." Then a plan, not a past: how you would learn the content, and whom you would ask. Answer slot: name the resources you would use, in your own words. Hold through two follow-ups by returning to the plan. | F2 is the biggest gap and the most likely probe. |
| A2 | "Six years in third grade: what carries over to fourth, and what doesn't?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | State the six years and what third grade gave you, in your words. Name one thing you would have to learn. | F2's adjacent work, at its own scope. |
| A3 | "A student who finished third grade reading below level arrives in your class. What do you do in the first two weeks?" | CASE | [generic] | Structure: assess first, then group, then contact the family, then check progress. The question needs no claim about your past. | A live problem from the role; generic because it is a pattern, not a fact about this school. |
| A4 | "You led the 2024 curriculum move. Which decisions were yours?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Story-mapped from the quote: the move, the grade level, 2024. Answer slot: which decisions were yours and which were not. If you did not make the choice, say so. Hold through two follow-ups by returning to what you led. | F3's bridge. Your own decisions are the likely probe. |
| A5 | "How do you work with colleagues when a grade-level decision is not yours to make?" | JD | [grounded] "I've never been a team lead" (your message) | Plain acknowledgment: "I've never been a team lead." Then describe a time you worked within a team decision, if you have one. If not, describe how you would contribute to one. | F3's gap, asked as a working-relationship question. |
| A6 | "Families are partners here. How do you keep families informed?" | VAL | [grounded] "I write a weekly email to families" (your CV) | Say what the weekly email carries, in your words. Answer slot: any direct contact beyond the email, and how often. | F4's presentation gap, against the district's belief. |

### Peer bank (Data-Driven Prober and Peer Evaluator; 6 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about the reading club and how you judged whether it was working." | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Describe the club as you ran it. Answer slot: if you measured anything, say what; if you did not, say so plainly. Never name a result you did not record. | A peer will ask how you know. The honest answer is the rehearsal. |
| B2 | "Walk me through how the move to the new reading curriculum happened." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Beats from the quote: the move, the grade level, 2024. Answer slot: which part you decided and which was decided for you. Weakest-assumption move: name the assumption behind the choice you would defend least. | F3, a peer probe into process. |
| B3 | "Where is the seam between your classroom and ours? What would you need from us?" | JD | [generic] | Propose principles for handling the seam, such as shared pacing and shared assessments. Do not claim seams you have already managed. | Peer Evaluator probe. Generic because no quote covers it. |
| B4 | "Our team uses assessments to plan. How do you use them?" | VAL | [generic] | Answer slot: name an assessment you have used and what you changed because of it. If none changed your teaching, say so plainly. | Values cheat sheet, third belief. |
| B5 | "What goes into your weekly family email?" | EXP | [grounded] "I write a weekly email to families" (your CV) | Say what the email carries, in your words. Answer slot: whether any reply or meeting followed from it. | F4's gap, asked for the detail. |
| B6 | "Two classes on our team pace reading differently. How would you handle that?" | CASE | [generic] | Structure: find out why, agree on one shared measure, and raise it with the team before changing anything. | A peer collaboration case. |

## 7. Requirement coverage

| Requirement | Questions |
|---|---|
| Illinois PEL with elementary endorsement (F1) | None, and why: met on your CV. |
| Fourth-grade teaching (F2) | A1, A2, A3 |
| Grade-level team work (F3) | A4, A5, B2, B6 |
| Families as partners (F4) | A6, B5 |
| Every Child a Reader (F5) | B1, A3 |
| Teach for Tomorrow, Not for the Test | B4 |

## 8. Reverse questions

1. **"What does the fourth-grade team already do well that a new teacher should keep?"** Why it lands: it shows you are planning to join the team, not replace it.
2. **"How does the district carry a third-grade reading plan into fourth grade?"** Why it lands: it ties to the district's own belief that no student leaves third grade without a reading plan, and to your six years in third grade.
3. **"How does the school reach families beyond the weekly email, such as conferences or term check-ins?"** Why it lands: it ties to "Families Are Partners."
4. **"What would a strong first term look like for this role?"** Why it lands: it asks for the expectations in concrete terms.
5. **"What could a new person do in their first month that would genuinely help your team?"** Why it lands: reciprocity framing for the peers on the panel.

## 9. Research and sources

- **Provided:** your invite, your resume, your message.
- **Searches:** 2 of 6 used. "Halvering Elementary School Orrinsford Community School District" returned no results. "Orrinsford Community School District values mission" returned the district's "Mission and Beliefs" page.
- **Fetches:** 1 of 2 used: the "Mission and Beliefs" page.
- **Research tier:** L1, with the principal's profile not searched because no search was run for her name.

| Target | Status | What it moved |
|---|---|---|
| 1. District values | yes | Values cheat sheet (section 5) |
| 2. Interview process | unavailable | Loop structure is taken from your invite: a 45-minute panel. Not searched. |
| 3. Strategy / recent news | skipped | Not needed for a classroom role; the strategy brief would not change the banks. |
| 4. Principal's name and profile | unavailable | Not searched. Would tune the principal's persona weights and add reverse questions tied to her path. |
| 5. Representative fourth-grade JD | skipped | Your invite and resume fix the requirements. |

## 10. Upgrade menu

- **The full job posting** → turns the `[generic]` rows into `[grounded]` rows and sharpens the coverage table.
- **Principal Dolores Vantongeren's public profile**, if you can share it → tailored persona weights and a reverse question tied to her career path.
- **The two team members' names** → per-member personas.
- **Any agenda or pre-declared task from HR** (a lesson demonstration, a written response) → a build section for it.
- **Your answers to the answer slots** → regenerated rows that quote your own words instead of leaving slots open.
- **Deep research** (L2): the district's recent news and the panel's public footprint.
