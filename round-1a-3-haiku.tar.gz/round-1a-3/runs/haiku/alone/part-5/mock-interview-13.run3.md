Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-5-rooms-case-13-denied-6f2328c5/77d4b9d3-fdba-496c-bed0-46fe75d39266/scratchpad/quillmoor_operations-coordinator_interview_pack.md`. It has the full fit snapshot, prohibited claims, reverse questions and requirement coverage. Here are the parts you'll use on the call.

**Your answers, in your own words**

- **Salary (R2):** "I'm hoping for £42,000." Don't add a range, a justification, or say you'd take less. If they ask about the band, ask them to share it first.
- **Notice period (R3):** Your material doesn't include it, so give your actual figure. I haven't supplied one.
- **Hybrid (R4):** "Two days at Avonmouth is fine." Three days is your ceiling.
- **Reason for leaving (R5):** "Our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Keep it about the move, then say what you want next.
- **Pay history (R6):** If asked what you earn now, say "I'd rather talk about the band for this role." No figure.

**The gaps they may probe**

- **SAP (S1), your biggest gap:** "I haven't used SAP. We run our own in-house stock system." Then say how you'd learn it, as a plan, not as experience.
- **Production and QA (S2):** You have delivery scheduling, not production planning or QA. If you've worked with planning or QA on anything, say who and what. If not, say so and say how you'd get up to speed.
- **The "about a third" figure (S3):** This is the one most likely to be pushed. Be ready to explain how the discrepancies were counted and what the starting point was. If you don't know, say "I'd need to check how it was counted." Say what you did, and who else was involved.
- **Dispatch reporting (S4):** You have no stated experience of weekly on-time dispatch reports. Say whether you produced any reports, and if not, what you'd track first.
- **Excel (S5):** Name the features you actually used in the stock-count spreadsheet.

**Questions to ask Hannah:** what a typical week looks like across planning, the warehouse and QA; which two days are the Avonmouth days; whether the stock system is moving to SAP; how on-time dispatch is measured; and the next steps and timing.

**Notes on the pack**

- I didn't run any web research. The advert and Hannah's message are the only sources, so the company section is limited to the advert.
- It has 13 questions, below the usual 18–26, because this is a 30-minute recruiter screen. Most of the gap questions don't need more.
- I left out the interviewer, values and delivery sections, because there's no interviewer profile, no stated values round, and no assessment.
- Hannah's message and your background contain no fees, bank details or document requests, so I didn't flag the invite.

**Upgrade menu:** your notice period in your words (fills R3). The figures behind "about a third" (turns S3 into a story). Any planning, warehouse or QA contact from your past (turns S2 into a grounded answer). The full posting, if it's longer than the advert. A search pass on Quillmoor and its Avonmouth site, which would give R8 more than the advert.

Would you like me to run a live drill? I'd play Hannah and take you through the SAP question (S1). I can also save a `tuesday-dossier.md` recording these gaps for later sessions. And if you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Quillmoor Diagnostics: Operations Coordinator, recruiter screen

Recruiter: Hannah Lowther (Talent Partner). Thursday 2pm, 30-minute phone call; they will ring the mobile number on the application.

## How to use

Personas describe how a question arrives. Types describe what is being scored:

- **VAL**: values alignment
- **EXP**: work-experience deep-dive
- **JD**: role and job-description fit
- **CO**: company knowledge
- **CASE**: live problem

Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | high | [grounded] | none | Met, and it is your own sentence. Say it as written. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [inferred] | transferability | Delivery scheduling is related, not the same. Your material shows no planning or QA work. Answer slot: if any of your scheduling involved planning or QA, say who and what you agreed; if none did, say so and say how you would get up to speed on production sequencing. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message) | high | [grounded] | none | Your sentence covers chasing. Say it as written. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | medium | [grounded] | none | Your sentence covers the rebuild. The result is in F4's figure, which the pack does not restate. |
| F5 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | medium | [grounded] | transferability | The spreadsheet is evidence of spreadsheet work, not a stated level of Excel. Answer slot: name the features you used (formulas, lookups, pivots, or basic sheets, whichever is true). |
| F6 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material is silent on reporting. Answer slot: if you produced any regular report, say what it measured; if not, say so and say what you would track first. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system" (your message) | high | [grounded] | capability | A gap you stated. Words: "I haven't used SAP. We run our own in-house stock system." Then how you would learn it, as a plan and never as a past. |
| F8 | "Two days a week at our Avonmouth site" (advert) | "two days at Avonmouth is fine" and "I wouldn't want more than three" (your message) | high | [grounded] | none | Your own words. |
| F9 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Your own figure. |
| F10 | Notice period (recruiter's agenda) | none given | none | [grounded] | discovery | Not in your material. Logistics slot, see R3. |
| F11 | Reason for leaving (recruiter's agenda) | "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | high | [grounded] | none | Your own words. |

## Prohibited claims

Built locally from the fit snapshot. These are the claims you might reach for under pressure, and the pack will not coach them.

- **Any SAP or ERP experience.** Basis: F7, "Never used SAP". Honest form: "I haven't used SAP; we ran our own in-house stock system."
- **Production planning or QA experience.** Basis: F2, delivery scheduling only. Honest form: the answer slot in S2.
- **Running on-time dispatch reporting.** Basis: F6, none given. Honest form: the answer slot in S4.
- **Any baseline or counting method for the "about a third" figure.** Basis: your figure is "about a third over a year", with no method stated. Honest form: "I'd need to check how it was counted."
- **Sole credit for the stock-count result.** Basis: "I rebuilt" is your word; the pack does not say who else was involved. Honest form: say what you did and who else was involved.
- **A notice period, pay history or range beyond the figure you gave.** Basis: F9 and F10. The pack does not name a range, floor or counter-offer.
- **Excel expertise beyond what you have stated.** Basis: F5. Honest form: name the features you actually used.

## Question banks

Requirement coverage: each JD requirement maps to the question IDs below.

| Requirement | Covered by |
|---|---|
| 2+ years in ops or logistics coordination | R1 |
| Coordinate production schedules across planning, warehouse and QA | S2 |
| Track supplier deliveries, chase late orders | R7 |
| Keep stock records accurate | S3 |
| Weekly on-time dispatch report | S4 |
| Confident with Excel | S5 |
| ERP (SAP or similar) a plus | S1 |
| Salary band | R2 |
| Hybrid, two days at Avonmouth | R4 |

**Persona weights:** Recruiter (weight 5, the screen's own voice). Skeptic (weight 2, a recruiter probing fit before passing you on). Reason: this is a 30-minute recruiter screen with a set agenda, so most questions are logistics and fit screening, and the gaps are probed only lightly.

### Recruiter (weight 5)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Tell me about your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots" | Open with the 4 years and the three depots, then the chasing. About 60 seconds. | The opener every screen starts with. Your own sentences carry it. |
| R2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot. Say the figure in your own words. If asked about the band, you can ask them to share the band first. Do not add a range, justify the figure or say you would take less. | Pay is on the recruiter's agenda. The figure is yours and raises nothing else. |
| R3 | "What is your notice period?" | JD | none given | Logistics slot. Give your actual notice period. Your material does not state it, so the pack supplies no figure. | Notice is on the agenda. Only your own number answers it. |
| R4 | "How would the hybrid pattern work for you?" | JD | [grounded] "two days at Avonmouth is fine"; "I wouldn't want more than three" | Say two days at Avonmouth works, and three is your ceiling. Do not describe your commute. | Your stated limit, in your words. |
| R5 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say the Bristol office closes next year and the only offer is relocating to Reading. Keep it about the move, not about your employer. Then say what you want next, in your own words. | A plain, positive reason. The pack does not add criticism. |
| R6 | "What are you earning now?" | JD | none given | A line to decline or redirect, with no figure: "I'd rather talk about the band for this role." | Pay history is a common pre-offer question. The line prepares a redirect; it gives no figure. |
| R7 | "What does your current role involve day to day?" | JD | [grounded] "chase suppliers when orders slip" | Say you schedule deliveries for three depots and chase suppliers when orders slip. Stop there. | Tracks the JD's supplier and late-order requirement. |
| R8 | "What do you know about Quillmoor?" | CO | [grounded] advert: "diagnostic-test manufacturer, about 400 staff" | Say what the advert says: a diagnostic-test manufacturer, about 400 staff, with a hybrid role at Avonmouth. Stop there; the pack adds nothing. | No research was run, so the answer uses only the advert. |

### Skeptic (weight 2)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "The role asks for SAP or a similar ERP. What's your experience?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Words: "I haven't used SAP. We run our own in-house stock system." Then the plan: how you would learn it, as a plan. Concession: name the gap before it is asked for. Highest-ROI prep: this gap is the one most likely to be probed. | Your largest stated gap. Rehearse saying it plainly, then the plan. |
| S2 | "You schedule deliveries. Have you coordinated production schedules with planning, the warehouse or QA?" | JD | [inferred] from "I schedule deliveries for our three depots" | Answer slot: if any of your scheduling involved planning or QA, say who and what you agreed. If none did, say so and say how you would get up to speed on production sequencing. | The JD's first requirement has no quote behind it. |
| S3 | "Discrepancies fell by about a third. How did you count that?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet; discrepancies fell by about a third over a year" | Defend-the-number slot. Answer slot: say how the count was made, what the baseline was, and what the figure is sensitive to. If you do not know, say so: "I'd need to check how it was counted." Say what you did, and who else was involved. | The headline metric. The pack supplies no method or baseline. |
| S4 | "Have you produced a weekly report on on-time dispatch?" | JD | none given | Answer slot: if you produced regular reports, say what they measured. If not, say so and say what you would track first. | The JD's reporting requirement has no quote behind it. |
| S5 | "How confident are you with Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Answer slot: name the features you used (formulas, lookups, pivots, or basic sheets, whichever is true). | The JD asks for Excel confidence. Your evidence is the rebuild, and that is what you can speak to. |

## Reverse questions

Each one has a "why it lands". Ask the ones that fit the call; the rest are back-up.

1. "What does a typical week look like across planning, the warehouse and QA?" Why it lands: shows you understand the cross-functional job, and tells you which gap matters most.
2. "Which two days are the Avonmouth days, and does the team set them?" Why it lands: checks your three-day ceiling is workable.
3. "Is the stock system moving to SAP, and if so, when?" Why it lands: tells you whether the SAP gap matters in this role.
4. "How is on-time dispatch measured and reported today?" Why it lands: reveals the reporting expectation.
5. "What are the next steps, and when would the team interview happen?" Why it lands: gets the timescale you need.

## Sources

- Provided documents: Hannah Lowther's LinkedIn message (the call details and agenda); the advert; your background message.
- Research tier: **L0**. No searches or fetches were run. The advert and the recruiter's message are the only sources. Company facts come from the advert alone.

## Upgrade menu

- Your notice period, in your words → R3 gets a ready answer, and F10 is no longer a gap.
- The figures behind "about a third" (how it was counted, the baseline) → S3 becomes a story, not a slot.
- Any planning, warehouse or QA contact in your past → S2 becomes a grounded answer.
- The full posting, if it runs longer than the advert → more requirements graded.
- One search pass on Quillmoor and its Avonmouth site (research tier L1) → R8 gets more than the advert.
