**Before anything else: this invite has the classic signs of a job scam.** It says:

- "transfer the €95 equipment registration fee to our supplier's account"
- "reply with a photo of your passport and your bank details before the interview"
- "Successful candidates receive a cheque for €1,850 to buy a laptop and desk from our approved vendor: you deposit the cheque and send the balance on to the vendor."

Don't pay the fee, send your passport or bank details, or deposit any cheque. A cheque that clears before it's found fake can leave you owing the bank the money you sent on. Check the company yourself: look up Brennock Facilities Ltd on the CRO register (cro.ie) and find a phone number from that register or its official website, not from this email. Then ask the office manager to confirm the interview through that number. A job-underwriter check, if you can get one, can review the posting too.

## Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Basis:** the ad summary you gave me, your background, and the invite. I haven't researched the company, so I have no values or strategy for it. The pack uses only your material and generic admin-interview practice, and I've labelled what is generic.

### Fit snapshot

| JD requirement | Your evidence (quoted) | Gap type | Confidence | Gap-and-bridge language |
|---|---|---|---|---|
| Manage calendars | "I ran the appointment book for four physios" | None stated | High | "I kept four people's schedules from clashing every week." |
| Book travel | Nothing in your material | No evidence | Low | "I haven't booked travel for a team, but I've managed tight, changing schedules and I'd learn the booking tools quickly." |
| Word documents | "good with Word" | None stated | Medium | Give one specific example of a document you produced. |
| Excel | "okay with Excel" | Partial | Low | "I'm comfortable with the basics. I'd want to build up my formulas and pivot tables." |
| Supplier invoices | "chased unpaid invoices" | Partial | Medium | "I followed up unpaid invoices. I haven't processed supplier invoices end to end, but I know how payments and follow-ups work." |

### Prohibited claims

These are claims I won't coach you to make, because your material doesn't support them:

- Any experience booking travel
- Processing supplier invoices end to end, such as entering, matching or approving them
- Advanced Excel (pivot tables, lookups, macros) unless you've used them

### Question bank

**Behavioural (likely opener)**

- *"Tell me about your experience managing schedules."*
  - **Guidance:** Describe the appointment book for four physios: how you handled clashes, cancellations and last-minute changes. Give one concrete example with a result.
  - **Provenance:** Your CV: "I ran the appointment book for four physios"

**Skeptic (where the gaps show)**

- *"You haven't booked travel before. What would you do the first time?"*
  - **Guidance:** Be direct: "I haven't done it for a team. Here's how I'd approach it: confirm the traveller's requirements, check the policy, book, and send the itinerary." Don't claim experience you don't have.
  - **Provenance:** Gap in the fit snapshot. No CV sentence supports travel.

- *"Have you processed supplier invoices?"*
  - **Guidance:** Separate what you did from what the role needs. "I chased unpaid invoices, so I know how to follow up on payments. I haven't processed invoices through a system end to end, but I'm comfortable learning it."
  - **Provenance:** Your CV: "chased unpaid invoices"

**Pressure ("how much was you?")**

- *"You ran the appointment book. Did you set the system up, or did you use what was there?"*
  - **Guidance:** Name exactly what you did: how you used the existing system, what you changed in practice, and what you didn't own. Shrinking an inflated claim is better than defending it.
  - **Provenance:** Your CV: "I ran the appointment book for four physios"

### Reverse questions

1. *"What does a normal week look like for this role?"* Why it lands: it shows you're thinking about the work, not just the offer.
2. *"Which systems do you use for calendars, travel and invoices?"* Why it lands: it tells you whether the role fits your Excel and booking gaps.
3. *"What are the next steps after this call?"* Why it lands: a real process will have clear next steps, and this question tests that without accusing anyone.

### Delivery notes

No working-style assessment was provided, so there's no delivery coaching section. Keep answers under two minutes, and have one example ready for each requirement above.

### Upgrade menu

- **Full job description:** lets me match the requirements exactly rather than working from your summary.
- **Company research:** would give me values and current context for Brennock. Only do this once the company checks out.
- **Recruiter or office-manager focus areas:** would tell me what the 30-minute call will test.

**Drill offer:** I can play the office manager and run any of these questions with follow-ups, then give feedback.

**Dossier offer:** I can save a `tuesday-dossier.md` from this pack if you want it to carry forward.

**Questions:**

1. Can you paste the full job description?
2. Did the office manager or the invite name any topics for the call?
3. How confident are you with Excel formulas, lookups and pivot tables?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.