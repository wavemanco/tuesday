Before the prep, one thing in the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." before your slot is confirmed, to "please also reply with a photo of your passport and your bank details before the interview", and to "you deposit the cheque and send the balance on to the vendor" for a €1,850 cheque. Requests like these, a fee or equipment payment, a cheque to deposit, and passport and bank details before any offer, are a known scam pattern, and this job invite is very likely a scam. Hold all of them. Don't pay, deposit a cheque, or send documents or bank details until you have checked the invite with the company through contact details you find yourself, on its own website or careers page, not through the email, address or number in the invite. You can also ask job-underwriter to check the invite as a separate request; I haven't run that here. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-5-rooms-case-12-denied-6d18272a/03a42f53-2485-41bc-9729-0d22bc5ca18a/scratchpad/Brennock-Facilities_remote-administrative-assistant_interview_pack.md. I built it for a 30-minute screen with an office manager, with no research run.

# Brennock Facilities Ltd: Remote Administrative Assistant, interview prep pack

Candidate: Aoife. Round: 30-minute video call. Interviewer: office manager (name not given).

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is scored: EXP (what you actually did), JD (the ad's requirements), CASE (a live problem). There are no VAL or CO questions, because no values or company research was run.
- Guidance is scaffolding, not a script. Rehearse out loud, in your own words. Where a cell says "answer slot", your real answer goes there.
- Nothing here claims more than your own message says. Where your material is silent, the pack says so.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you summarised it | "I ran the appointment book for four physios" — your message | medium | [grounded] | transferability | Your material says an appointment book for four physios. That is close to calendar work, but it does not show calendars for anyone else. Keep it at that scope. Answer slot: if you set rules for who could book when, or resolved a clash, say how, in your own words; if the book was simply a shared diary, say so plainly. |
| F2 | "booking travel" — the ad, as you summarised it | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you booked travel for anyone, say what and how; if you have not, say so plainly and say how you would learn the booking tool. |
| F3 | "preparing documents in Word" — the ad, as you summarised it | "I'm good with Word" — your message | medium | [grounded] | none | "I'm good with Word" reaches the requirement in role terms, but it is a self-rating with nothing shown behind it. Lead with the sentence as you wrote it; expect a request for an example. |
| F4 | "preparing documents in Excel" — the ad, as you summarised it | "okay with Excel" — your message | low | [grounded] | discovery | "Okay with Excel" touches the requirement without showing what you have done in Excel. Answer slot: name the Excel tasks you have done, in your own words; if they went no further than basic entry and sums, say so plainly. |
| F5 | "processing supplier invoices" — the ad, as you summarised it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Chasing unpaid invoices is adjacent to processing supplier invoices. It does not show whose invoices they were, or whether you entered, matched or approved any. Keep it at that scope. Answer slot: if you entered, matched or approved supplier invoices for payment, say how; if you only chased payment, say so. |
| F6 | "Remote Administrative Assistant" — the invite's job title | none given | none | [grounded] | discovery | Your material does not show remote working. Answer slot: if you have worked remotely or with people out of sight, say how; if not, say so and give the set-up you would use for shared calendars, files and a daily check-in, as a plan. |

The material says nothing about licences, certificates or checks. The ad, as you summarised it, names none, so no gate row applies.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed executive calendars | Inflated form of F1: your sentence says an appointment book for four physios | "I ran the appointment book for four physios." Your material says the book, not executive calendars. |
| Processed supplier invoices | Inflated form of F5: your sentence says chasing unpaid invoices | "I chased unpaid invoices." Your material says chasing, not processing. |
| Advanced or expert Excel | Inflated form of F4: your sentence says "okay" | "Okay with Excel." |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (weight 5) | Asks where your experience falls short of the ad | Highest. A short screen for a remote admin role, where two of four tasks have thin or no evidence | Know the gaps and state them plainly; rehearse A1 until it is boring |
| Case (weight 4) | Practical problems: a clash, a duplicate invoice, a deadline | High. An office manager tests day-to-day judgement | Clarify first, then order the steps |
| Data-Driven Prober (weight 4) | Asks how you did the things you claim | High for Excel and invoices, where your claims are thinnest | Say what you did and what you did not |
| Conversational (weight 3) | Opens with your background, asks what you look forward to | Medium. A 30-minute call often starts informally, and the answers are still scored | Have a 90-second arc ready |
| Pressure (weight 2) | Time-boxed challenge to your fit | Low to medium. Only if the interviewer tests composure | Hold the position, then concede the real limit |

Weights total 18 questions. Reasoning: a hiring-manager relationship starts from case plus skeptic; an admin role run by an office manager tilts case toward calendars and invoices; 30 minutes limits the depth of prober and pressure rounds. Every persona still gets at least two questions.

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your background is a receptionist's appointment book. Which of this ad's four tasks have you actually done?" | JD | [grounded] "I ran the appointment book for four physios" — your message; "chased unpaid invoices" — your message | The highest-ROI rehearsal in this pack. Take the tasks in the order the ad gives them, each with what your sentences say: the appointment book at its own scope for calendars; "chased unpaid invoices" at its own scope for invoices; your Word and Excel words as you wrote them. Booking travel is an answer slot: if you booked travel for anyone, say what and how; if you have not, say so plainly and say how you would learn the booking tool. Hold through two follow-ups by returning to the quotes. | F1, F2 and F5 are the thinnest rows, and this objection arrives in some form. JD because it scores the ad's own list. |
| A2 | "I don't see much Excel depth in what you've told me. How would you handle a spreadsheet you have never built?" | JD | [grounded] "okay with Excel" — your message | Say "okay with Excel" as you wrote it. Answer slot: name the Excel tasks you have done, in your own words; if they went no further than basic entry and sums, say so plainly. Then give your plan for a new spreadsheet, as a plan and never as a past. | F4 is discovery; the probe comes from the ad's Excel line. |
| A3 | "Why are you leaving a clinic front desk for an admin role?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" — your message | Answer slot: give your own reason for the move, in your own words, and state the two years as a fact. | Motivation is the skeptic's standard question. Your material gives no reason, so none is supplied. |
| A4 | "This is a remote role. How do you keep working with people you can't see?" | JD | [grounded] "Remote Administrative Assistant" — the invite | Answer slot: if you have worked remotely or with people out of sight, say how; if not, say so and give the set-up you would use for shared calendars, files and a daily check-in, as a plan. | F6 is discovery; remote working is in the job title, not in your material. |
| A5 | "Processing supplier invoices is a different job from chasing unpaid ones. What's the difference, to you?" | JD | [grounded] "chased unpaid invoices" — your message | Say "I chased unpaid invoices" at its own scope. Answer slot: if you entered, matched or approved supplier invoices for payment, say how; if you only chased payment, say so and say what you would learn. | F5 is transferability: chasing is adjacent to processing, not the same work. |

### B. Case (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two colleagues both need the meeting room at 2pm on Thursday, and one has a flight landing at 3pm. What do you do?" | CASE | [generic] | Clarify which booking is fixed (the flight). Ask whether the other can move. Check the room system, confirm with both in writing, and tell the one who gives way why. | Calendar management is the ad's first task. A live problem, so no claim about your past. |
| B2 | "A supplier invoice arrives twice, with two amounts. What happens before anything is paid?" | CASE | [generic] | Stop the payment. Check both against the order or the original. Ask the supplier. Log both. Pay only once it matches. | Invoice processing is the ad's fourth task. A live problem, not a record. |
| B3 | "The board pack is due at 5pm in Word and Excel, and two other deadlines land the same day. How do you order the day?" | CASE | [generic] | List the three, check which are fixed, do the figures before the layout, and tell the owner of any late item early. | Tests ordering under the ad's Word and Excel work. No claim about your past. |
| B4 | "A traveller's itinerary is sent, then the fare rules say the change costs more. What do you do?" | CASE | [generic] | Check the fare rules and the traveller's options. Get approval for the extra cost. Rebook, then confirm in writing. | Booking travel (F2) answered by method, with no past claim. |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You ran the appointment book for four physios. Which part was yours to decide, and which did the clinic set?" | EXP | [grounded] "I ran the appointment book for four physios" — your message | Say the four physios and what you ran, in your words, at the sentence's scope. Answer slot: name one rule you set for the book and one the clinic set; if all of it was set by the clinic, say so. Weakest-assumption move: name the assumption behind the book being accurate that you would defend least. | F1 is the calendar evidence. "Four" is the only figure you gave, so it draws the defend-the-number slots. |
| C2 | "When invoices were unpaid, how did you decide what to chase first?" | EXP | [grounded] "chased unpaid invoices" — your message | Answer slot: if you had an order (by age, amount or client), say which and why; if you chased them as they came, say so. | F5. The question presumes a method your sentence does not carry, so the second branch must allow that there was none. |
| C3 | "Show me the most complex spreadsheet you've built. What does it do?" | EXP | [grounded] "okay with Excel" — your message | Answer slot: if you have built one beyond simple entry, describe the most complex in your own words; if not, say so plainly. | F4 is discovery, and "okay" will be probed. The question presumes a spreadsheet, so the honest branch is written in. |
| C4 | "Tell me about the last document you prepared in Word that someone relied on." | JD | [grounded] "I'm good with Word" — your message | Open prompt: choose a document, name who relied on it and what for, in your own words. If none comes to mind, say so plainly, then describe the nearest Word work you did. | F3. "Good with Word" is a self-rating, and the probe asks for an instance. The theme comes from the ad's "preparing documents in Word". |

### D. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios"; "chased unpaid invoices" — your message | A 90-second arc in this order: the clinic, the book, the invoices, then Word and Excel as you rated them. End on why this kind of role, as an answer slot in your own words. | Rapport openers are scored. The arc uses only your own sentences. |
| D2 | "What's the part of this job you're most looking forward to?" | JD | [generic] | Pick one of the ad's four tasks, say why in your own words, and keep it to one answer. No claim about your past. | A casual question about the ad's tasks is still scored. |
| D3 | "Anything else you'd like me to know before we finish?" | EXP | [grounded] "I ran the appointment book for four physios" — your message | One sentence that returns to your strongest quote, not a new claim. Do not re-argue the gaps. | The close is scored. Add nothing the quotes do not carry. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone with office experience?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" — your message | Hold the position: your two years and the book you ran. Through two follow-ups, return to those quotes. Concede precisely: name the part of the role where you would need the most time, in your own words. | The thinnest comparison under time pressure. Hold, then concede. |
| E2 | "That appointment book: how much of it was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" — your message | Answer slot: name the part you ran and the part the physios or the clinic set. Hold the core ("I ran it") without inflating it. | Attribution pressure on F1. |

### Requirement coverage

| Ad requirement | Questions |
|---|---|
| managing calendars | A1, B1, C1, D1 |
| booking travel | A1, B4 |
| preparing documents in Word and Excel | A2, B3, C3, C4 |
| processing supplier invoices | A1, A5, B2, C2 |
| remote working (from the job title) | A4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Is the 30-minute call the only stage, or is there a further step after it?" | Shows you are planning the process, and tells you how much to prepare. |
| 2 | "What does a normal week look like for whoever holds this role?" | Tests how the four tasks weigh in practice. |
| 3 | "Which of the four tasks takes most of the time day to day?" | Lets you put your strongest answers there. |
| 4 | "Which booking and calendar tools does the team use?" | Shows you can learn them, and sets up A1. |
| 5 | "How are supplier invoices checked before anything is paid?" | Separates entering, checking and approving, which matters for A5. |

## Sources

- **Provided documents:** your message (your background, and the ad as you summarised it).
- **Searches:** none. **Fetches:** none.

**Research tier:** L0. Searches 0 of 0, fetches 0 of 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Brennock Facilities values | unavailable | Values cheat sheet. Research consent gave way to the upgrade menu (Step 1), so no values were checked. |
| 2. Brennock interview process | unavailable | Loop structure. The 30-minute call comes from your message, not from research. |
| 3. Brennock strategy / recent news | unavailable | Company-knowledge (CO) questions. None are in this pack. |
| 4. Interviewer name | n/a | No name was given, so there was no query to form. |
| 5. Representative administrative-assistant JD | skipped | The ad, as you summarised it, fixes the requirements in the fit snapshot. |

## Upgrade menu

- The full ad text → each requirement becomes a verbatim quote, not your summary
- Your CV → more of your own sentences to quote, and fewer answer slots
- Research consent (L1) → company values and a representative admin-assistant JD, labelled `[inferred]`. It cannot confirm the invite.
- The name of any later interviewer, or a later round → persona weights for that round
- `tuesday-dossier.md` → verified evidence and prohibited claims carried in from an earlier session

I can also play the Skeptic on A1, the question the pack names as the highest-ROI prep. Say the word and I'll run it. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is the office manager the person you'd report to, or a screener for a later round? That reweights the personas.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock-Facilities_remote-administrative-assistant_interview_pack.md -----
# Brennock Facilities Ltd: Remote Administrative Assistant, interview prep pack

Candidate: Aoife. Round: 30-minute video call. Interviewer: office manager (name not given).

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is scored: EXP (what you actually did), JD (the ad's requirements), CASE (a live problem). No VAL or CO questions: no values or company research was run.
- Guidance is scaffolding, not a script. Rehearse out loud, in your own words. Where a cell says "answer slot", your real answer goes there.
- Nothing here claims more than your own message says. Where your material is silent, the pack says so.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you summarised it | "I ran the appointment book for four physios" — your message | medium | [grounded] | transferability | Your material says an appointment book for four physios. That is close to calendar work, but it does not show calendars for anyone else. Keep it at that scope. Answer slot: if you set rules for who could book when, or resolved a clash, say how, in your own words; if the book was simply a shared diary, say so plainly. |
| F2 | "booking travel" — the ad, as you summarised it | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you booked travel for anyone, say what and how; if you have not, say so plainly and say how you would learn the booking tool. |
| F3 | "preparing documents in Word" — the ad, as you summarised it | "I'm good with Word" — your message | medium | [grounded] | none | "I'm good with Word" reaches the requirement in role terms, but it is a self-rating with nothing shown behind it. Lead with the sentence as you wrote it; expect a request for an example. |
| F4 | "preparing documents in Excel" — the ad, as you summarised it | "okay with Excel" — your message | low | [grounded] | discovery | "Okay with Excel" touches the requirement without showing what you have done in Excel. Answer slot: name the Excel tasks you have done, in your own words; if they went no further than basic entry and sums, say so plainly. |
| F5 | "processing supplier invoices" — the ad, as you summarised it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Chasing unpaid invoices is adjacent to processing supplier invoices. It does not show whose invoices they were, or whether you entered, matched or approved any. Keep it at that scope. Answer slot: if you entered, matched or approved supplier invoices for payment, say how; if you only chased payment, say so. |
| F6 | "Remote Administrative Assistant" — the invite's job title | none given | none | [grounded] | discovery | Your material does not show remote working. Answer slot: if you have worked remotely or with people out of sight, say how; if not, say so and give the set-up you would use for shared calendars, files and a daily check-in, as a plan. |

The material says nothing about licences, certificates or checks. The ad, as you summarised it, names none, so no gate row applies.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed executive calendars | Inflated form of F1: your sentence says an appointment book for four physios | "I ran the appointment book for four physios." Your material says the book, not executive calendars. |
| Processed supplier invoices | Inflated form of F5: your sentence says chasing unpaid invoices | "I chased unpaid invoices." Your material says chasing, not processing. |
| Advanced or expert Excel | Inflated form of F4: your sentence says "okay" | "Okay with Excel." |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (weight 5) | Asks where your experience falls short of the ad | Highest. A short screen for a remote admin role, where two of four tasks have thin or no evidence | Know the gaps and state them plainly; rehearse A1 until it is boring |
| Case (weight 4) | Practical problems: a clash, a duplicate invoice, a deadline | High. An office manager tests day-to-day judgement | Clarify first, then order the steps |
| Data-Driven Prober (weight 4) | Asks how you did the things you claim | High for Excel and invoices, where your claims are thinnest | Say what you did and what you did not |
| Conversational (weight 3) | Opens with your background, asks what you look forward to | Medium. A 30-minute call often starts informally, and the answers are still scored | Have a 90-second arc ready |
| Pressure (weight 2) | Time-boxed challenge to your fit | Low to medium. Only if the interviewer tests composure | Hold the position, then concede the real limit |

Weights total 18 questions. Reasoning: a hiring-manager relationship starts from case plus skeptic; an admin role run by an office manager tilts case toward calendars and invoices; 30 minutes limits the depth of prober and pressure rounds. Every persona still gets at least two questions.

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your background is a receptionist's appointment book. Which of this ad's four tasks have you actually done?" | JD | [grounded] "I ran the appointment book for four physios" — your message; "chased unpaid invoices" — your message | The highest-ROI rehearsal in this pack. Take the tasks in the order the ad gives them, each with what your sentences say: the appointment book at its own scope for calendars; "chased unpaid invoices" at its own scope for invoices; your Word and Excel words as you wrote them. Booking travel is an answer slot: if you booked travel for anyone, say what and how; if you have not, say so plainly and say how you would learn the booking tool. Hold through two follow-ups by returning to the quotes. | F1, F2 and F5 are the thinnest rows, and this objection arrives in some form. JD because it scores the ad's own list. |
| A2 | "I don't see much Excel depth in what you've told me. How would you handle a spreadsheet you have never built?" | JD | [grounded] "okay with Excel" — your message | Say "okay with Excel" as you wrote it. Answer slot: name the Excel tasks you have done, in your own words; if they went no further than basic entry and sums, say so plainly. Then give your plan for a new spreadsheet, as a plan and never as a past. | F4 is discovery; the probe comes from the ad's Excel line. |
| A3 | "Why are you leaving a clinic front desk for an admin role?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" — your message | Answer slot: give your own reason for the move, in your own words, and state the two years as a fact. | Motivation is the skeptic's standard question. Your material gives no reason, so none is supplied. |
| A4 | "This is a remote role. How do you keep working with people you can't see?" | JD | [grounded] "Remote Administrative Assistant" — the invite | Answer slot: if you have worked remotely or with people out of sight, say how; if not, say so and give the set-up you would use for shared calendars, files and a daily check-in, as a plan. | F6 is discovery; remote working is in the job title, not in your material. |
| A5 | "Processing supplier invoices is a different job from chasing unpaid ones. What's the difference, to you?" | JD | [grounded] "chased unpaid invoices" — your message | Say "I chased unpaid invoices" at its own scope. Answer slot: if you entered, matched or approved supplier invoices for payment, say how; if you only chased payment, say so and say what you would learn. | F5 is transferability: chasing is adjacent to processing, not the same work. |

### B. Case (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two colleagues both need the meeting room at 2pm on Thursday, and one has a flight landing at 3pm. What do you do?" | CASE | [generic] | Clarify which booking is fixed (the flight). Ask whether the other can move. Check the room system, confirm with both in writing, and tell the one who gives way why. | Calendar management is the ad's first task. A live problem, so no claim about your past. |
| B2 | "A supplier invoice arrives twice, with two amounts. What happens before anything is paid?" | CASE | [generic] | Stop the payment. Check both against the order or the original. Ask the supplier. Log both. Pay only once it matches. | Invoice processing is the ad's fourth task. A live problem, not a record. |
| B3 | "The board pack is due at 5pm in Word and Excel, and two other deadlines land the same day. How do you order the day?" | CASE | [generic] | List the three, check which are fixed, do the figures before the layout, and tell the owner of any late item early. | Tests ordering under the ad's Word and Excel work. No claim about your past. |
| B4 | "A traveller's itinerary is sent, then the fare rules say the change costs more. What do you do?" | CASE | [generic] | Check the fare rules and the traveller's options. Get approval for the extra cost. Rebook, then confirm in writing. | Booking travel (F2) answered by method, with no past claim. |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You ran the appointment book for four physios. Which part was yours to decide, and which did the clinic set?" | EXP | [grounded] "I ran the appointment book for four physios" — your message | Say the four physios and what you ran, in your words, at the sentence's scope. Answer slot: name one rule you set for the book and one the clinic set; if all of it was set by the clinic, say so. Weakest-assumption move: name the assumption behind the book being accurate that you would defend least. | F1 is the calendar evidence. "Four" is the only figure you gave, so it draws the defend-the-number slots. |
| C2 | "When invoices were unpaid, how did you decide what to chase first?" | EXP | [grounded] "chased unpaid invoices" — your message | Answer slot: if you had an order (by age, amount or client), say which and why; if you chased them as they came, say so. | F5. The question presumes a method your sentence does not carry, so the second branch must allow that there was none. |
| C3 | "Show me the most complex spreadsheet you've built. What does it do?" | EXP | [grounded] "okay with Excel" — your message | Answer slot: if you have built one beyond simple entry, describe the most complex in your own words; if not, say so plainly. | F4 is discovery, and "okay" will be probed. The question presumes a spreadsheet, so the honest branch is written in. |
| C4 | "Tell me about the last document you prepared in Word that someone relied on." | JD | [grounded] "I'm good with Word" — your message | Open prompt: choose a document, name who relied on it and what for, in your own words. If none comes to mind, say so plainly, then describe the nearest Word work you did. | F3. "Good with Word" is a self-rating, and the probe asks for an instance. The theme comes from the ad's "preparing documents in Word". |

### D. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios"; "chased unpaid invoices" — your message | A 90-second arc in this order: the clinic, the book, the invoices, then Word and Excel as you rated them. End on why this kind of role, as an answer slot in your own words. | Rapport openers are scored. The arc uses only your own sentences. |
| D2 | "What's the part of this job you're most looking forward to?" | JD | [generic] | Pick one of the ad's four tasks, say why in your own words, and keep it to one answer. No claim about your past. | A casual question about the ad's tasks is still scored. |
| D3 | "Anything else you'd like me to know before we finish?" | EXP | [grounded] "I ran the appointment book for four physios" — your message | One sentence that returns to your strongest quote, not a new claim. Do not re-argue the gaps. | The close is scored. Add nothing the quotes do not carry. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone with office experience?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" — your message | Hold the position: your two years and the book you ran. Through two follow-ups, return to those quotes. Concede precisely: name the part of the role where you would need the most time, in your own words. | The thinnest comparison under time pressure. Hold, then concede. |
| E2 | "That appointment book: how much of it was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" — your message | Answer slot: name the part you ran and the part the physios or the clinic set. Hold the core ("I ran it") without inflating it. | Attribution pressure on F1. |

### Requirement coverage

| Ad requirement | Questions |
|---|---|
| managing calendars | A1, B1, C1, D1 |
| booking travel | A1, B4 |
| preparing documents in Word and Excel | A2, B3, C3, C4 |
| processing supplier invoices | A1, A5, B2, C2 |
| remote working (from the job title) | A4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Is the 30-minute call the only stage, or is there a further step after it?" | Shows you are planning the process, and tells you how much to prepare. |
| 2 | "What does a normal week look like for whoever holds this role?" | Tests how the four tasks weigh in practice. |
| 3 | "Which of the four tasks takes most of the time day to day?" | Lets you put your strongest answers there. |
| 4 | "Which booking and calendar tools does the team use?" | Shows you can learn them, and sets up A1. |
| 5 | "How are supplier invoices checked before anything is paid?" | Separates entering, checking and approving, which matters for A5. |

## Sources

- **Provided documents:** your message (your background, and the ad as you summarised it).
- **Searches:** none. **Fetches:** none.

**Research tier:** L0. Searches 0 of 0, fetches 0 of 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Brennock Facilities values | unavailable | Values cheat sheet. Research consent gave way to the upgrade menu (Step 1), so no values were checked. |
| 2. Brennock interview process | unavailable | Loop structure. The 30-minute call comes from your message, not from research. |
| 3. Brennock strategy / recent news | unavailable | Company-knowledge (CO) questions. None are in this pack. |
| 4. Interviewer name | n/a | No name was given, so there was no query to form. |
| 5. Representative administrative-assistant JD | skipped | The ad, as you summarised it, fixes the requirements in the fit snapshot. |

## Upgrade menu

- The full ad text → each requirement becomes a verbatim quote, not your summary
- Your CV → more of your own sentences to quote, and fewer answer slots
- Research consent (L1) → company values and a representative admin-assistant JD, labelled `[inferred]`. It cannot confirm the invite.
- The name of any later interviewer, or a later round → persona weights for that round
- `tuesday-dossier.md` → verified evidence and prohibited claims carried in from an earlier session
