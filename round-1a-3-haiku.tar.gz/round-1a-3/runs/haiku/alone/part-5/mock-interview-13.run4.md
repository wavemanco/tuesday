I saved the full pack to `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-5-rooms-case-13-denied-86e85f1c/9ac261a9-01de-44e9-b3d8-4c518bf58799/scratchpad/quillmoor-recruiter-screen-pack.md`. The main points are below. I used only your advert and your notes, with no web research.

**The invite:** It reads as an ordinary recruiter contact. It asks for no payment, bank details or ID before an offer.

## Fit snapshot

| Requirement | Your evidence | Gap |
|---|---|---|
| 2+ years in logistics coordination | "4 years as a logistics coordinator at a building-supplies wholesaler." | None |
| Track supplier deliveries, chase late orders | "I schedule deliveries for our three depots and chase suppliers when orders slip." | None |
| Keep stock records accurate | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | None |
| Confident with Excel | Not in your material | Answer slot |
| Weekly on-time dispatch report | Not in your material | Answer slot |
| Production scheduling across planning, warehouse and QA | Scheduling across three depots only | Gap |
| SAP or similar ERP (a plus) | "Never used SAP — we run our own in-house stock system." | Gap |

## Prohibited claims

- No SAP or ERP experience.
- No production planning, manufacturing or QA experience.
- Don't say you ran the whole stock system.
- Don't claim the discrepancy drop was yours alone.
- Don't quote a market rate for the salary.

## Questions and suggested answers

**Salary: "What are you looking for?"**
Say "I'm looking for around £42,000" once. If she asks for the range, ask to see it first. The advert's £38k–£44k puts £42k in the upper half.

**Salary: "What's your current salary?"** (may come up)
Answer slot. Give the real figure, or say you'd rather discuss the target. Don't round up.

**Notice period**
Answer slot. Give the exact contractual notice and earliest start date.

**Hybrid: "How would that work for you?"**
"Two days at Avonmouth works for me. I wouldn't want more than three." Then ask whether the two days are fixed or flexible.

**Hybrid: "Would two days be difficult?"** (may come up)
Answer slot. Give your real commute time; don't guess it.

**Move reason: "What's prompting the move?"**
"The Bristol office is closing next year. The only offer is to move to Reading, and I want to stay in Bristol." Keep it short and don't criticise the company.

**Move reason: "Would you consider Reading?"** (likely)
"No, I'm looking to stay in Bristol." Then stop.

**SAP gap: "How would you handle an ERP system here?"** (likely)
"I haven't used SAP. I've worked in our in-house stock system and rebuilt our stock-count spreadsheet, so I know how stock records get kept accurate." Don't say you'd pick it up quickly unless you can point to evidence.

**Production gap: "How much production-side work have you done?"** (likely)
"My scheduling has been across three depots, not a production line. I haven't worked with QA."

**Dispatch reporting** (likely)
Answer slot. Say whether you've produced any regular delivery or on-time reports.

## Reverse questions

- **What does success look like in the first 90 days?** Shows you're thinking about the job, not just the pay.
- **Is the Avonmouth pattern fixed, or can the two days vary?** Tests the hybrid terms directly.
- **Which ERP system does the team use day to day?** Her answer shows how much the SAP gap matters.
- **What are the next steps after this call?** Sets up the process and timing.

## Upgrade menu

- **Notice period and current salary:** would turn two answer slots into worked answers.
- **Excel and dispatch-reporting details:** would fill the two unknown rows in the fit snapshot.
- **Recruiter focus areas:** one message to Hannah asking what she'll cover would let the pack match her agenda.
- **Company research:** Quillmoor's recent news and values would give you a line for the team-and-next-steps part. I can run this if you want it.
- **Dossier:** a `tuesday-dossier.md` from job-underwriter would replace my inferred prohibited list with evidence-graded claims.

**Drill:** I can play Hannah and run the salary and notice questions with follow-ups, then give feedback.
**Dossier:** I can write a `tuesday-dossier.md` from this pack if you want one.

**Question:** What's your notice period, and is it contractual? She will ask this on the call, and the answer decides your earliest start date.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-recruiter-screen-pack.md -----
# Recruiter screen prep: Operations Coordinator, Quillmoor Diagnostics

**Round:** 30-minute phone screen, Thursday 26 Nov 2026, 2pm, with Hannah Lowther (Talent Partner). She calls the mobile number on the application.
**Research tier:** L0, provided documents only (the advert and your message). No web search was run.
**Assumptions:** Notice period, current salary and the Avonmouth day pattern are not in the material. Answers for them are slots for you to fill.

## Fit snapshot

| Requirement (advert) | Your evidence (quoted) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| 2+ years in operations or logistics coordination | "4 years as a logistics coordinator at a building-supplies wholesaler." | High | None | Meets it directly. |
| Coordinate delivery and supply timing | "I schedule deliveries for our three depots and chase suppliers when orders slip." | High | None | Covers the supplier-chasing and scheduling parts of the role. |
| Track supplier deliveries and chase late orders | "I schedule deliveries for our three depots and chase suppliers when orders slip." | High | None | Direct match. |
| Keep stock records accurate | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | High | None | Direct match; say what you did and what changed. |
| Confident with Excel | Not stated in your material. | Unknown | Answer slot | Answer slot: say which Excel skills you use day to day. |
| Weekly report on on-time dispatch | Not stated in your material. | Unknown | Answer slot | Answer slot: do you already report on delivery or dispatch performance? |
| Production scheduling across planning, warehouse and QA | Scheduling is across three delivery depots. No manufacturing or QA work is stated. | Medium | Gap | "I've coordinated schedules across three depots, not a production line. I haven't worked with QA release." |
| ERP experience (SAP or similar) — a plus | "Never used SAP — we run our own in-house stock system." | High | Gap (stated) | "I haven't used SAP. I've worked in our in-house stock system, and I rebuilt the stock-count spreadsheet." |

**Gap type key:** *None* means the evidence matches. *Gap* means the material does not show it. *Answer slot* means you need to supply the fact.

## Prohibited claims

Not to be said or implied in any answer:

1. Any SAP or ERP experience. Basis: "Never used SAP."
2. Production planning, manufacturing or QA experience. Basis: the material shows depot delivery scheduling only.
3. That you ran the whole stock system. Basis: "we run our own in-house stock system", with no ownership stated.
4. That the discrepancy drop was yours alone. Basis: "I rebuilt our stock-count spreadsheet" describes your part, not the team's results.
5. Any market-rate figure for the salary. No research was run, so no market data is cited.

## Interviewer read

Not available. No profile for Hannah Lowther was provided, and the recruiter role means she will mainly screen for logistics, pay and fit.

## Persona weights

| Persona | Weight | Reason |
|---|---|---|
| Recruiter (commercial screen) | High | Salary, notice, hybrid and motive are her stated agenda. |
| Logistics screener | Medium | Her questions on the advert's duties will test what your evidence shows. |
| Team-fit / motive | Low | She said she will cover the team and next steps later. |

## Question banks

### Salary

**Q1. What salary are you looking for?**
- **Type:** Commercial.
- **Provenance:** Your stated target, "I'm hoping for £42,000."
- **Guidance:** Give the number plainly: "I'm looking for around £42,000." Say it once. If she asks for the range, say you would like to see the range first. The advert's range is £38,000–£44,000, so £42,000 sits in the upper half.
- **Rationale:** Commercial question with a clear target. The advert gives the range, so stating a figure inside it is defensible.

**Q2. What is your current salary?** *(may come up)*
- **Type:** Commercial.
- **Provenance:** Answer slot. Your current salary is not in the material.
- **Guidance:** Answer slot: give your actual current figure, or say you would rather discuss the target. Do not round it up.

### Notice period

**Q3. What is your notice period?**
- **Type:** Commercial.
- **Provenance:** Answer slot. Not in the material.
- **Guidance:** Answer slot: state the exact contractual notice and any earliest start date. Use the true figure.
- **Rationale:** She listed this as a topic. The start date depends on it, so you should know it before the call.

### Hybrid

**Q4. How would the hybrid pattern work for you?**
- **Type:** Logistics / fit.
- **Provenance:** "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three."
- **Guidance:** "Two days at Avonmouth works for me. I wouldn't want more than three." Then ask whether the two days are fixed or flexible.
- **Rationale:** She named hybrid as a topic. Your stated limit is the honest answer.

**Q5. Is there any reason two days would be difficult?** *(may come up)*
- **Type:** Logistics / fit.
- **Provenance:** Answer slot. Commute time is not in the material.
- **Guidance:** Answer slot: give your real commute to Avonmouth. Do not claim a time you have not checked.

### Move reason

**Q6. What is prompting your move?**
- **Type:** Motive.
- **Provenance:** "Our Bristol office is closing next year, and the only offer is relocating to Reading, which I don't want."
- **Guidance:** Say it briefly: "The Bristol office is closing next year. The only offer is to move to Reading, and I want to stay in Bristol." Do not criticise the company.
- **Rationale:** This is a true reason that needs no embellishment. Keeping it short avoids sounding like a complaint.

**Q7. Would you consider relocating to Reading?** *(likely follow-up)*
- **Type:** Motive.
- **Provenance:** Your stated preference, "which I don't want."
- **Guidance:** "No, I'm looking to stay in Bristol." Stop there.

### Experience and gaps

**Q8. You haven't used SAP. How would you handle an ERP system here?** *(likely)*
- **Type:** Gap.
- **Provenance:** "Never used SAP — we run our own in-house stock system."
- **Guidance:** "I haven't used SAP. I've worked in our in-house stock system and rebuilt our stock-count spreadsheet, so I know how stock records get kept accurate." Do not claim you would learn it quickly unless you can point to evidence.
- **Rationale:** The gap is stated, so acknowledging it plainly is more credible than deflecting.

**Q9. How much of the production side have you worked on?** *(likely)*
- **Type:** Gap.
- **Provenance:** "I schedule deliveries for our three depots and chase suppliers when orders slip."
- **Guidance:** "My scheduling has been across three depots, not a production line. I haven't worked with QA." Stop there.

**Q10. Have you reported on dispatch performance?** *(likely)*
- **Type:** Experience.
- **Provenance:** Answer slot. Not in the material.
- **Guidance:** Answer slot: say whether you have produced any regular delivery or on-time reports, and how often.

## Reverse questions

| Question | Why it lands |
|---|---|
| What does success look like in the first 90 days? | Shows you are thinking about the role, not just the pay. |
| Is the Avonmouth pattern fixed, or can the two days vary? | Tests the hybrid terms directly. |
| Which ERP system does the team use day to day? | Her answer will show how far the SAP gap matters. |
| What are the next steps after this call? | Sets up the process and timing. |

## Delivery coaching

Not included: no working-style assessment was provided.

## Invite check

The invite reads as an ordinary recruiter contact. It asks for no payment, bank details or ID before an offer, and it schedules by chat, which is normal.

## Upgrade menu

- **Notice period and current salary:** would turn Q2 and Q3 into worked answers instead of slots.
- **Excel and dispatch-reporting details:** would fill the two unknown rows in the fit snapshot.
- **Recruiter focus areas:** a single question to Hannah on what she will cover would let the pack match her agenda. Usually one message.
- **Research tier L1:** Quillmoor's recent news and values, which would add a company line for the team-and-next-steps part of the call. Offered, not run.
- **Dossier:** `tuesday-dossier.md` from job-underwriter would replace the inferred prohibited list with evidence-graded claims.
