Before the prep, one thing in the invite. It says the process is "carried out entirely on Telegram" and that "your offer and onboarding will be completed in this chat as well." A hiring process run wholly by chat is a known scam pattern, and a chat alone doesn't show who you're dealing with. Hold anything that involves money, documents or bank details until you've checked the role with Lumenvale through contact details from its own website or careers page, not through this chat. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-5-rooms-case-10-denied-f9d5ecdd/7fdf02d2-cd7c-4432-a660-837796e9b6ed/scratchpad/lumenvale_customer-support-specialist_interview_pack.md, and I've attached it here. I built it for a team-lead round on the four requirements you summarised from the ad. It has 17 questions across five personas, with the highest-priority rehearsal on S2: "Our queue runs on Zendesk, and you use Freshdesk. Why should I believe you'll pick it up quickly?"

Say the word and I'll play the Skeptic on S2 so you can drill it.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is this text chat the only stage, or does a call or video step follow?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale_customer-support-specialist_interview_pack.md -----
# Lumenvale Software: Customer Support Specialist interview pack

**Role:** Customer Support Specialist, remote, Lumenvale Software (applied via careers page)
**Interviewer:** support team lead (no name given). Round: text chat on Telegram.
**Relationship:** team lead, so the hiring-manager prior applies.
**Research tier:** L0, provided documents only. Built on your message, your summary of the ad's requirements, and your background.

## How to use this pack

Personas are how a question is asked. Types are what it scores.

| Type | Meaning |
|---|---|
| EXP | Your experience, tested for attribution |
| JD | A requirement from the ad |
| CASE | A live problem from the role, with no claim about your past |

The guidance is scaffolding, not a script. This interview is a chat, so answers are read rather than heard: write in short paragraphs, and expect follow-ups in the same thread.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your summary of the ad) | "3 years as customer service advisor at an energy supplier, answering around 60 calls and emails a day" (your message) | medium | [grounded] | none | No gap, but a CV-level claim with nothing inspected behind it, so expect a probe on the 60. Say it in those words: three years as a customer service advisor at an energy supplier. |
| F2 | "experience with Zendesk or a similar ticketing tool" (your summary of the ad) | "I use Freshdesk every day" (your message) | medium | [grounded] | presentation | Freshdesk is the similar tool, and your quote reaches the requirement in other terms. Say: I use Freshdesk every day. Do not say you have used Zendesk, because your material does not show it. |
| F3 | "clear written communication" (your summary of the ad) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Emails show volume, not what was written in them. Answer slot: if you can describe a written reply you sent and what it resolved, say so in your own words; if you cannot point to one, say so and describe how you check your own writing before sending. |
| F4 | "confidence handling escalations" (your summary of the ad) | "trained four new starters on our refunds process last year" (your message) | low | [inferred] | discovery | Training others on a refunds process is not handling escalations. Answer slot: if you have handled an escalation, say what it was and what you did, in your own words; if you have not, say so plainly, then give the nearest thing you do carry: the refunds process you trained four starters on, and how you would decide when a refund goes up a level. |

## Prohibited claims

Built locally from the fit snapshot. Nothing in this pack asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Used Zendesk | Inflated form of F2 | "I use Freshdesk every day." Your material shows Freshdesk, not Zendesk. |
| Handled escalations | Inflated form of F4 | The refunds-training quote at its own scope; F4's slot is the only route to escalations. |
| Led the refunds process | Inflated form of "trained four new starters on our refunds process last year" | "I trained four new starters on our refunds process last year." Your material says you trained others; it does not say you owned the process. |
| Strong written communication as a proven skill | Inflated form of F3 | Not coached as a claim. The emails figure stays at its own scope. |
| Software-company experience | A negative you stated: "I've never worked for a software company." | Plain acknowledgment: "I've never worked for a software company." |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Presses the two requirements with no quote behind them (escalations, Zendesk) and the software-company line | High. The team lead is the hiring manager, and the hiring-manager prior is Case plus Skeptic. | Rehearse S2 until it is plain. Hold, then concede. |
| Case / Strategist | Live ticket problems from the queue | High, for the same prior. | Clarify, then answer, then escalate. |
| Data-Driven Prober | Asks how the 60 a day was counted | Medium. A headline CV figure always gets a defend-the-number slot. | Name the assumption you are least sure of, or say you do not know how it was counted. |
| Conversational / Rapport | Opens with "walk me through", and casual questions about the tool | Medium. Chat openers are common, and casual questions are still scored. | A 90-second arc, in the order of your own sentences. |
| Pressure / Stress | Challenges the writing and the figure | Low to medium. A chat limits stress probes, but a team lead may test composure. | Hold the position, then concede the specific part. |

Weights: Skeptic 5, Case 4, Prober 3, Conversational 3, Pressure 2. Depth follows weight.

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You've never worked for a software company. Why would our queue be any different?" | JD | [grounded] "I've never worked for a software company." (your message) | Open with the plain acknowledgment: "I haven't worked for a software company." Then carry over only what you did: "I've spent three years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day." Do not argue the difference. | You volunteered the negative, so a team lead hiring into a software company will test it first. F1 is the evidence. |
| S2 | "Our queue runs on Zendesk, and you use Freshdesk. Why should I believe you'll pick it up quickly?" | JD | [grounded] "I use Freshdesk every day" (your message); [grounded] "experience with Zendesk or a similar ticketing tool" (your summary of the ad) | Highest-ROI rehearsal in this pack. Hold: "I use Freshdesk every day." Answer slot: say what you would do first with Zendesk's views and macros, and if you have used Zendesk, say when, in your own words; if you have not, say so plainly. Concession: "I haven't used Zendesk. I'd expect to need time on its views and macros, and I would ask the team for them early." Hold through two follow-ups by returning to the Freshdesk line. | F2 is the requirement with the gap, and the Skeptic's likeliest target. Deepest rehearsal, because this is the objection most likely to be asked in some form. |
| S3 | "The ad asks for confidence handling escalations. Show me where that is in your background." | JD | [grounded] "trained four new starters on our refunds process last year" (your message); [grounded] "confidence handling escalations" (your summary of the ad) | Answer slot (F4): if you have handled an escalation, say what it was and what you did, in your own words. If you have not, say so plainly, then give the refunds process you trained four starters on, and say how you would decide when a refund goes up a level. Do not name an escalation you cannot describe. | F4 is discovery, so the honest answer has to be ready before the probe. |
| S4 | "Walk me through what your three years as a customer service advisor covered." | JD, EXP | [grounded] "3 years as customer service advisor at an energy supplier, answering around 60 calls and emails a day" (your message) | Name the job in your own words, starting from the quote. Then describe what the role covered, stopping at what you did yourself. Do not extend the list. | Checks the "2+ years in customer support" requirement against what the role actually was. F1 is the evidence. |
| S5 | "Why leave energy for a software company?" | JD | [grounded] "3 years as customer service advisor at an energy supplier" (your message) | Answer slot: give your own reason in your own words. If you do not have one yet, say so, and describe what you are looking for in this role from the ad. No reason is supplied here. | Motivation probe. The material holds no reason for leaving, so the pack gives none. |

### Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A customer writes that the refund they were promised has not arrived. It's their third message. What do you send?" | CASE | [generic] | Check the ticket history first. Say what you can confirm, give a time you will come back by, and say what you will do rather than what you cannot. Write it as the reply, under 120 words. Promise no refund amount or date you cannot verify. | A live problem from the role. Written, because the interview is. It makes no claim about your past. |
| C2 | "A ticket is stuck between you and billing, and the customer has waited a week. How do you escalate it?" | JD | [grounded] "confidence handling escalations" (your summary of the ad) | Clarify what the customer needs and what billing needs. Write the escalation note so billing does not come back with questions. Tell the customer who owns it now and when they will hear. Give the steps, not a past case. | The ad raised escalations. This tests the method, not a past event. |
| C3 | "Your queue has 40 open tickets and everything is marked urgent. What do you do first?" | CASE | [generic] | Sort by what breaks for the customer, not by the label. Name the two or three you would take first and say why. Say what you would tell your team lead. | Prioritising under load, from the role. No claim about your past. |
| C4 | "A customer writes in with no detail at all. What is the first thing you ask?" | CASE | [generic] | Ask for the one thing that lets you act: the account or order, what they expected, and what happened instead. Keep it to one message. | Clarifying before answering, which is what this interviewer scores. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "You handled around 60 calls and emails a day. What was in that count?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Answer slot: if you know how the figure was counted, say how, in your own words. Name the assumption behind it you would defend least, before they do. If you do not know how it was counted, say so plainly. | F1 is a headline figure, so it gets a defend-the-number slot. The pack supplies no counting method. |
| P2 | "Of those 60 a day, which part was yours, and which was the team's?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Say what you answered yourself, and say plainly where the team shared the work. Do not claim the whole figure. If you cannot separate the two, say so. | Attribution. It keeps the figure at the scope of your own sentence. |
| P3 | "You trained four new starters on the refunds process. How did you know they had understood it?" | EXP | [grounded] "trained four new starters on our refunds process last year" (your message) | Answer slot: if you checked their understanding in a way you can describe, say how, in your own words. If you did not check, say so, and say how you would check next time. Do not report how they did unless you know. | The question presupposes a check, and the second branch allows that none happened. |

### Conversational / Rapport (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "So, walk me through your journey to support." | EXP | [grounded] "3 years as customer service advisor at an energy supplier, answering around 60 calls and emails a day" (your message); [grounded] "I use Freshdesk every day" (your message); [grounded] "I trained four new starters on our refunds process last year" (your message) | A 90-second arc in this order: the energy supplier and the three years, the calls and emails, the Freshdesk daily use, the refunds training. Use only those sentences. | Casual register, still scored on F1, F2 and F4. |
| V2 | "What do you actually do in Freshdesk day to day?" | JD | [grounded] "I use Freshdesk every day" (your message) | Describe what you use it for, in your own words. Do not list features you have not used. If you are unsure what a feature is called, say so. | Feeds S2. The casual wording still counts toward the tool requirement. |
| V3 | "Any questions for us?" | Conversational | None. This is the reverse-question slot. | Ask one of the questions in section 11. Do not answer "no". | Rapport interviewers weight this slot heavily. |

### Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| PR1 | "A text chat tells me little about how you write under pressure. Convince me." | JD | [grounded] "clear written communication" (your summary of the ad) | Pause, then answer in short plain paragraphs. Hold: the job is written, so a reply is better evidence than an argument. Concede the specific part: "I can't show you how I'd write on a bad day from one chat." Then offer a written reply to a sample ticket, as C1 is written. | Pressure on the writing requirement, which the chat format makes the whole interview. |
| PR2 | "That 60 a day sounds high. How much of it was really you?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Hold: the calls and emails were ones you answered. Concede what is specific: you cannot split the number exactly from memory. Then the P2 answer. | Hold-then-concede on a headline figure. |

### Coverage

| Requirement | Covered by |
|---|---|
| 2+ years in customer support | S4 (JD), F1 |
| Zendesk or a similar ticketing tool | S2 (JD), V2 (JD) |
| Clear written communication | PR1 (JD), C1 (written reply) |
| Confidence handling escalations | S3 (JD), C2 (JD) |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Is this text chat the only stage, or does a call or video step follow?" | Tells you whether to prepare for a live conversation too. |
| R2 | "Which ticketing views and macros does the team use most day to day?" | The answer shows how far the Freshdesk-to-Zendesk gap reaches. |
| R3 | "How are escalations routed, and who owns a ticket once it has been escalated?" | Asks about the requirement with the least evidence, from the owner's side. |
| R4 | "What does a typical day's ticket volume look like, and through which channels?" | Lets you compare it with your own figure. |
| R5 | "What would a strong first month look like for someone in this role?" | Gives the team lead a chance to say what they need, which you can answer in the chat. |

## Sources

- **Provided documents:** your Telegram message (the invite, pasted in full), your summary of the ad's requirements, and your background.
- **Searches and fetches sent:** none. This run is L0.

**Research tier: L0, no searches or fetches**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale values | unavailable | Values cheat sheet (section 10). Not run at L0, so it is absent. |
| 2. Lumenvale interview process, customer support | unavailable | Would show whether a call or video stage follows the chat (see R1). |
| 3. Lumenvale strategy / recent news | unavailable | Would set current company language for the banks. |
| 4. Interviewer name | n/a | The invite names a support team lead and no person. |
| 5. Representative JD | skipped | The requirements you summarised fix the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The full ad text → the four requirements become `[grounded]` in the ad's own wording, and any requirement my summary dropped gets a row.
- A reply you have written to a customer, or an escalation you handled → F3 and F4 become quoted evidence, and their answer slots can be replaced with your own sentences.
- Any Zendesk exposure, however small → F2 gets its own quote, and S2 loses its slot.
- Research at L1 → the values cheat sheet and the process structure come from the company's own pages.
- tuesday-dossier.md → verified evidence and a sharper objection list for later sessions.
