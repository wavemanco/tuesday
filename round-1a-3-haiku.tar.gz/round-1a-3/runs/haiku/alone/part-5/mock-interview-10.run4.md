Before the prep, one thing about the invite. It says "Our hiring process is fully remote and is carried out entirely on Telegram", that your interview "will be a text chat here with our support team lead", and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known warning sign, and a chat alone doesn't show who you're dealing with. Until you've checked it, don't send documents, bank details, ID, or any money through this chat, and hold off replying with a time. To check, use the contact details on Lumenvale's own website or careers page, where you applied, not anything in the chat. If you want the invite weighed more carefully, job-underwriter can check it as a separate request. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-5-rooms-case-10-denied-1c7663d5/9fc37a1a-ffd4-4c56-a58e-a08edf6b7ab1/scratchpad/lumenvale_customer_support_specialist_interview_pack.md`. I built it from your message alone, with no research run, and assumed the support team lead is interviewing you in a hiring-manager-style round, since your note didn't say.

The pack's highest-ROI prep is B2, the escalation question. Say the word and I'll play the skeptic on it.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the support team lead your future manager or a peer? And is this chat the only stage before an offer, or is there a call or work sample after it?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale_customer_support_specialist_interview_pack.md -----
# Interview pack: Customer Support Specialist (remote), Lumenvale Software

Interviewer: the support team lead (name not given). Recruiter contact: Marcus Hale, talent team.
Round: a text chat on Telegram with the support team lead. Round type and the team lead's role in the decision are assumed, not confirmed (see upgrade menu).
Built on: your message only. No research was run.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what it scores:
  - **EXP**: work-experience deep-dive. Tests whether what you did holds up under questions.
  - **JD**: the listed job. Tests whether you can do what the ad lists, gaps included.
  - **CASE**: a live problem. Tests structure and reasoning as you write them.
- The guidance is scaffolding, not a script. Say things in your own words.
- Answer slots ask for your real experience. If the true answer is "I haven't done that", say so plainly. That is a complete answer.

## Fit snapshot

Requirements are your summary of the ad (your message), not the posted text. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your message) | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" (your message) | medium | [grounded] | presentation | Your material says customer service advisor, not customer support. Say the title you held, in your words: "For three years I was a customer service advisor at an energy supplier." |
| F2 | "experience with Zendesk or a similar ticketing tool" (your message) | "I use Freshdesk every day" (your message) | medium | [grounded] | presentation | Freshdesk is a ticketing tool of the kind the ad names. Answer slot: if you have used Zendesk, say when and how much. If you have not, say so and name what carries over from Freshdesk. |
| F3 | "clear written communication" (your message) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Volume is not quality. Answer slot: if any of your written replies were checked, praised or complained about, say which and how. If none were, say so and offer to show a sample in the chat. |
| F4 | "confidence handling escalations" (your message) | "I trained four new starters on our refunds process last year" (your message) | low | [inferred] | discovery | Refund training is not escalation handling. Answer slot: if you handled escalations, describe one in your own words. If you did not, say so and say how you would take one. |
| F5 | Software-product support work (generic; a likely probe, not in your summary of the ad) | "I've never worked for a software company" (your message) | none | [grounded] | capability | Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan, never as a past. |

## Prohibited claims

Not coached in this pack. Each entry says why.

| Not coached | Basis | Honest form |
|---|---|---|
| Handled escalations | Inflated form of F4 | F4's answer slot only. Say what you did handle. |
| Owned the refunds process | Inflated form of F4's quote | "I trained four new starters on our refunds process last year." |
| Resolved 60 tickets a day | Inflated form of F1 | "around 60 calls and emails a day," and only as a count you can explain. |
| Used Zendesk | Not in your material | F2's answer slot. |
| Experience in software support | Negative you stated, F5 | "I haven't worked for a software company." Then the plan. |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Prober (team lead who reads the CV closely) | Pushes on the figures and the tools | High. Your background is a CV line and a number, so the number gets checked. Weight 4 | Defend the number: say what it counts and what you can't say |
| Skeptic (checks the ad line by line) | Asks for the escalation and the Zendesk experience directly | High. Those are the two lines your material does not reach. Weight 3 | Hold, then concede: return to what you did; name the gap plainly |
| Process (checks logistics and written work) | Gives a written task, asks how you'd handle a message | Likely, because the round is a chat. Weight 2 | Plain answers, with structure shown in the text |

## Question banks

### A. Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through a typical day with around 60 calls and emails." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Use the quote's words: three years, calls and emails, around 60 a day. Answer slot: which were calls and which emails, and how many you finished yourself. If you don't know the split, say so. | F1 is the evidence for the support requirement. EXP because it tests what was yours. |
| A2 | "Of those 60, how many were escalations, and how did you decide to escalate?" | EXP | [grounded] "answering around 60 calls and emails a day" | The 60 is the only figure in your material. Answer slot: if you can say how it was counted, say so. If you can't, "I don't know how it was counted" is an honest answer. Do not invent an escalation count. | F3 and F4 both press here. This is a defend-the-number question. |
| A3 | "What did you do in Freshdesk every day?" | EXP | [grounded] "I use Freshdesk every day" | Name the Freshdesk tasks you actually did, in your own words. Answer slot: if you used it but did not set it up or manage it, say so. | F2 is the bridge to the tool requirement. Only your tasks count. |
| A4 | "You trained four new starters. What did you teach them, and how did you check it stuck?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Beats: four starters, the refunds process, last year. Answer slot: what you covered, and how you checked it. If you did not check, say so. | F4's nearest evidence. Tests whether the training was yours to design. |

### B. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "We run Zendesk. Have you used it?" | JD | [grounded] "experience with Zendesk or a similar ticketing tool"; [grounded] "I use Freshdesk every day" | Answer slot: if you have used Zendesk, say when and how much. If not, say so plainly, then name Freshdesk as your daily tool and what carries over. Hold a follow-up by returning to Freshdesk. | F2. The ad names Zendesk, and your material shows Freshdesk. |
| B2 | "Tell me about an escalation you handled from start to finish. What did you decide?" | JD | [grounded] "confidence handling escalations" | **Highest-ROI prep in this pack.** The escalation line is where your material is thinnest, so this is the most likely objection. Answer slot: describe one escalation you did handle, in your own words. If your refund decisions went to someone else, say who and where your part stopped. If you have not handled escalations, say so plainly and describe how you would take one. Hold through two follow-ups by returning to the one you did. Never add to it. | F4. Deepest rehearsal, because the requirement is the one the material does not reach. |
| B3 | "Here's an angry customer whose refund was refused. Write your reply here in the chat." | CASE | [generic] | Structure: acknowledge, state the decision, give the reason, give the next step, say what you will do. Write it as you would send it. No claim about your past. | Tests "clear written communication" live, which F3 cannot show. |
| B4 | "Where's the line for a refund you would decline?" | CASE | [grounded] "I trained four new starters on our refunds process last year" | Answer slot: name the rule as you taught it. If the rule was your company's, say so. | Uses your one refunds quote without claiming ownership of the policy. |

### C. Process (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "We're a software company. How would you learn our product in your first month?" | JD | [grounded] "I've never worked for a software company" | Plain acknowledgment: "I haven't worked for a software company." Then the plan: how you would learn the product. Present it as a plan, not a past. | F5. The gap is stated by you, so it is said plainly. |
| C2 | "A customer's question isn't covered by any macro or policy. What do you do?" | CASE | [generic] | Structure: what you check first, who you ask, what you tell the customer in the meantime, what you record. No claim about your past. | Live problem from the escalation requirement. |

**Requirement coverage**

| Requirement (from your summary) | Covered by |
|---|---|
| 2+ years in customer support | A1, F1 |
| Zendesk or a similar ticketing tool | B1, A3, F2 |
| Clear written communication | B3, F3 |
| Confidence handling escalations | B2, A2, C2, F4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Is this chat the only stage before an offer, or is there a call or a work sample after it?" | Tells you how many stages to prepare for. |
| R2 | "What does a typical first month look like for someone starting on the team?" | Shows you what onboarding covers and what C1 should answer. |
| R3 | "Which ticketing tool does the team use, and how are escalations routed between tiers?" | Lets you map B1 and B2 to the team's own setup. |
| R4 | "How does the team measure reply quality?" | Prepares you for F3. |
| R5 | "What's the hardest kind of ticket the team handles?" | Lets you ask about escalations without claiming experience with them. |

## Sources

- Provided documents: your message (the invite, your summary of the job ad, your background).
- No search or fetch was run.

**Research tier: L0** (no search or fetch run)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale values` | unavailable | Values cheat sheet, not included. Would have moved it if a values round were detected |
| 2. `Lumenvale interview process customer support` | unavailable | Loop structure and persona weights. Would have shown whether the chat is the only stage |
| 3. `Lumenvale strategy` / recent news | unavailable | Grounding brief and any CO questions. Would have moved them |
| 4. `{interviewer name} Lumenvale` | n/a | No team-lead name given, so no query could be formed |
| 5. representative `Customer Support Specialist` JD | unavailable | Your summary fixes the fit snapshot, but not the full posted requirements |

## Upgrade menu

- The full posted job ad → the fit snapshot quotes the posting rather than your summary, and the coverage table checks every listed requirement.
- Whether the team lead is your future manager or a peer, and whether the chat is the only stage → reweights the persona table and the reverse questions.
- The team lead's name → a tailored reverse question, and persona weights from any public footprint.
- Research at L1 (up to 6 searches, 2 page fetches) → company values, the team's support tooling and recent Lumenvale news, with a CO question.
- `tuesday-dossier.md` → carries the gaps this prep exposed into later sessions.
