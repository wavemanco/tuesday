# Interview prep: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: office manager (name not given). Relationship not yet confirmed, so the weights assume a hiring-manager-style round. Format: 30-minute video call.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Types used here: **JD** (the listed duties), **EXP** (what you actually did), **CASE** (a live problem). The guidance is scaffolding, not a script. Say it in your own words. Where a line says "answer slot", answer the branch that is true for you.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you summarised it | "ran the appointment book for four physios" — your message | medium | [grounded] | transferability | Your material says an appointment book for four physios. Keep it in those words: "I ran the appointment book for four physios." Answer slot: if you ever moved or resolved clashes across several people's diaries, say how you did it; if you did not, say so and stay with the book. |
| F2 | "booking travel" — the ad, as you summarised it | none given | none | [grounded] | discovery | Answer slot: if you have booked travel for anyone, say what and for whom; if you have not, say so plainly and say how you would learn the company's booking tools. |
| F3 | "preparing documents in Word and Excel" — the ad, as you summarised it | "good with Word" — your message | low | [inferred] | discovery | Your words are a self-rating with no document behind them, so the pack will not turn them into a track record. Answer slot: when have you used Word to prepare something someone relied on? If you have not, say so. |
| F4 | "preparing documents in Word and Excel" — the ad, as you summarised it | "okay with Excel" — your message | low | [inferred] | discovery | Your words are "okay with Excel", and they stay that. Answer slot: if you used Excel for a tracker, a list or a schedule, name it and what it did; if you have not used it for anything, say you are okay with it and say what you would learn first. |
| F5 | "processing supplier invoices" — the ad, as you summarised it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices. It does not say whether you ever checked, entered or paid bills from suppliers, and the bridge must not assume it. Answer slot: if you ever checked, entered or paid supplier invoices, say what that involved; if you did not, say so and say what chasing involved. |
| F6 | "Remote Administrative Assistant" — the invite | none given | none | [grounded] | hard_gate | Your material does not establish that you can work remotely from where you live, on the role's hours. The pack gives no words for this: it is a term, and the message asks about it. |

Only the candidate's own words appear in quotation marks in the evidence column. The duties are quoted from your summary of the ad.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (weight 5) | Probes the gaps: "I don't see" calendars, travel or invoices; "why this move" | Top weight. A hiring-manager round is the prior, and F1, F2 and F5 are the gaps the ad's duties expose. | Rehearse A2 until it is dull. Say the bridge you can stand behind, and no further. |
| Data-Driven Prober (weight 4) | Asks how the book was kept, what counted as overdue, what the spreadsheet did | F3 and F4 are thin, and invoice and spreadsheet claims are where a probe starts. | Name the tools you used and which functions you know. Say plainly what you do not know. |
| Case/Strategist (weight 3) | Live office problems: a room clash, a mismatched invoice, a cancelled flight | The ad lists four duties, and each has a live-problem version. | Clarify first, then order the steps, and say who you would check with. |
| Conversational (weight 3) | "Walk me through your background"; "what are you looking forward to" | Video calls open casually, and casual questions are still scored. | A 90-second background arc built from your own sentences. |
| Pressure (weight 3) | "Why you over someone with direct admin experience?" | Short calls are often time-boxed, and your Excel will be pressed. | Hold the position you can state, then concede exactly what you lack. |

The Skeptic leads because the ad's four duties map onto the gap rows F1 to F5.

## Question banks

Ordered by weight. Each row's guidance rests on the sentence in its own Provenance cell.

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Why are you moving from a physiotherapy clinic into an administrative role?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Give the reason in one sentence, in your own words, then name what you want from an admin role. Answer slot: your material does not give a reason for the move; if the reason is the work itself, say so, and if it is something else, say that plainly. | Motivation is the Skeptic's first test. It draws on your background, not on a gap row. |
| A2 | "I don't see calendar management in your background. How would you handle it on day one?" | JD | [grounded] "ran the appointment book for four physios" | The highest-ROI prep in this pack. The hold is only the quote: "I ran the appointment book for four physios." Say how the book worked and where it stopped. Answer slot: if you moved or resolved clashes across several people's diaries, say how, in your own words; if you did not, say so plainly and say how you would learn the calendar tools this role uses. Hold through two follow-ups by returning to the book, never by adding to it. | F1 is the likeliest probe and the row most tempted to be thickened. The stem is the Skeptic's "I don't see X" form. |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "okay with Excel" | Name Excel as the part you would want to be sharper in, if that is true for you, and say what you would do in the first two weeks. | F4 is the spreadsheet gap, and the question asks for honesty about it. |
| A4 | "Have you booked travel for anyone? What did it involve?" | JD | [grounded] | Answer slot: if you have booked travel for anyone, say what and for whom; if you have not, say so plainly and say how you would learn the booking tools. | F2 has no quote, so the guidance makes no claim about you. The rationale is the ad's travel duty. |
| A5 | "What did chasing unpaid invoices involve?" | EXP | [grounded] "chased unpaid invoices" | Say what you did: who you contacted, what you asked for, and what happened. Answer slot: if you ever checked, entered or paid supplier invoices, say what that involved; if you did not, say so plainly and stay with chasing. | F5 is the gap between the duty and your sentence. The question tests whether you keep the two apart. |

### Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you kept the appointment book for four physios." | EXP | [grounded] "ran the appointment book for four physios" | Name what the book had to keep track of, in your own words, then how clashes were handled. Answer slot: if you had a rule for clashes between diaries, say it; if the system or someone else handled them, say so. | F1 is the row this probes. The question is premised on your own quote, not on a method. |
| D2 | "What did chasing unpaid invoices involve? How did you know which were overdue?" | EXP | [grounded] "chased unpaid invoices" | Say what you tracked and how, in your own words. Answer slot: if you kept a list of overdue invoices, say how it was kept; if someone else kept the ledger, or no list existed, say so and say what your part was. | The Prober asks how a thing was tracked. F5 is thin on exactly that. |
| D3 | "Show me how you would set up a tracker of supplier invoices in Excel. Which functions would you use?" | CASE | [grounded] "okay with Excel" | Say which columns you would use, then the functions you know and the ones you would look up. Do not name a function you cannot explain. | Tests Excel at the level your quote claims. F4 is the row this probes. |
| D4 | "When have you used Word to prepare something someone relied on?" | EXP | [grounded] "good with Word" | Name the document, who used it and what for, if one exists. Answer slot: if you have none, say so plainly, and say what you have written in Word, if anything. | An open prompt: you choose the instance. F3 is the row this probes. |

### Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two directors have meetings at 10am and both want the same room. The office manager asks you to fix it. What do you do?" | CASE | [generic] | Clarify which meeting can move and who decides. Then propose two options, confirm with both, and write the change down. Speak it in under two minutes. | A live calendar problem from the ad's calendar duty. [generic], because it is a pattern for the problem, not a fact about your past. |
| B2 | "A supplier invoice does not match its purchase order. How do you handle it?" | CASE | [generic] | Stop before paying. Check the purchase order and the delivery record, ask the supplier for what is missing, and log what you found. Do not promise to pay it. | A live version of the ad's supplier-invoice duty. [generic]. |
| B3 | "A traveller's flight is cancelled the night before a client visit. What do you do?" | CASE | [generic] | Find out what the traveller needs first, check rebooking options by cost and time, confirm with the traveller, then book and tell the office manager what you did. | A live version of the ad's travel duty. [generic]. |

### Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your background." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | A 90-second arc from those words, in order: the clinic and the two years, the appointment book for four physios, the unpaid invoices, and what you want next. Add nothing to any of them. | The opener is scored, not casual. The arc is built from your sentence only. |
| C2 | "What part of the admin side are you most looking forward to?" | EXP | [generic] | Say one part, honestly, and tie it to something you have actually done. Do not pick Excel because it sounds right. | Rapport question with a motivation check. [generic]. |
| C3 | "Why do you want to work remotely?" | JD | [generic] | Give the reason in your own words. Do not describe a home set-up you have not described to them. | The remote setup is the open gate in F6, so the answer must not assume it. [generic]. |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone with direct admin experience?" | JD | [grounded] "ran the appointment book for four physios"; "chased unpaid invoices" | Hold the position you can state: name the two things you bring from your own words, the appointment book for four physios and the unpaid invoices. Hold through two follow-ups. Then concede plainly where the other candidate is stronger, and say what you would do to close it. | A stress stem. The held position is one your quotes carry, and the concession is the part the Pressure interviewer scores. |
| E2 | "Chasing invoices for two years sounds like a job you wanted to leave. Why would we trust you with the detail?" | EXP | [grounded] "chased unpaid invoices" | Hold on the fact, not on the motive: describe what the chasing involved. Concede any part of the detail work you have not done. Do not argue about why you left. | The probe questions motive, which the answer cannot settle. Hold, then concede exactly. |
| E3 | "You have called yourself okay with Excel. Why should I trust a spreadsheet from you?" | JD | [grounded] "okay with Excel" | Hold the word you used. Do not inflate it. Say how you check your own work and when you would ask for help. Concede exactly where a spreadsheet would need more than that. | The Pressure interviewer tests the weakest quote. Hold only what the quote carries. |

### Requirement coverage

| Requirement (ad) | Covered by |
|---|---|
| Managing calendars | A2, B1, D1 |
| Booking travel | A4, B3 |
| Preparing documents in Word and Excel | A3, D3, D4, E3 |
| Processing supplier invoices | A5, B2, D2, E2 |
| Working remotely (a gate) | none, and why: it is a term, not an interview question. It is surfaced in F6 and asked in the message. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week look like for this role, and which tasks take most of the time?" | It shows you are planning the job, not only the offer. |
| R2 | "Is this 30-minute call the only stage before a decision, or is there another step?" | It tells you how much to prepare and whether a follow-up test is likely. |
| R3 | "Which calendar, travel and invoice tools does the team use?" | Those are what you would need to learn first, and you can prepare the ones you already know. |
| R4 | "What would a strong first month look like for whoever takes this role?" | It gets the office manager describing success, which is what you will be measured on. |
| R5 | "How does the team keep in touch when someone works remotely?" | It opens the remote question without asking you to claim a set-up you have not described. |

## Prohibited claims

What this pack will not coach, built from the fit snapshot. Each entry states its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars for a team | Inflated form of F1 | F1's quote at its own scope: "ran the appointment book for four physios". The limit is the pack's observation: your material says one book, not several people's calendars. A2's answer slot stays inside the book. |
| Processed supplier invoices | Inflated form of F5 | "chased unpaid invoices", at its own scope. The pack's observation: your material does not say which side of the ledger those invoices were on. |
| Prepared documents for others in Word and Excel | Inflated form of F3 and F4 | "good with Word" and "okay with Excel", with no claim to documents prepared for anyone. |

## Sources

- Provided documents: your message, which holds the summary of the ad, the invite text as pasted, and your background.
- Dossier: none consumed.
- Searches and fetches: none were sent for this pack.

Research tier: L0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Brennock Facilities Ltd values | unavailable | No search ran for this pack. A values section would apply only if a values-style round were detected, and the ad does not show one. |
| 2. Brennock interview process, admin role | unavailable | No search ran. Would confirm whether the 30-minute call is the only stage; R2 asks it instead. |
| 3. Brennock strategy / recent news | unavailable | No search ran. Would matter only if the role needed company-level questions, which the ad does not show. |
| 4. Interviewer name with Brennock | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative admin-assistant JD | unavailable | No search ran. Would move the duties from your summary to the ad's own words (see the upgrade menu). |

## Upgrade menu

- The full ad text → the requirement quotes in F1 to F5 move from your summary to the ad's own words, and the coverage table is checked against every line of it.
- Whether the office manager is your manager or a screener → reweights the personas, and the Skeptic and Prober banks are retuned.
- A research pass on Brennock's own careers page and interview process → the loop structure, company-specific reverse questions and cited sources.
- One named Word document or Excel file you have made → F3 or F4 moves from low confidence toward medium, with the file as the proof.
- A tuesday-dossier.md → carries the verified evidence and the gap notes into later sessions, and tightens the answer slots.
