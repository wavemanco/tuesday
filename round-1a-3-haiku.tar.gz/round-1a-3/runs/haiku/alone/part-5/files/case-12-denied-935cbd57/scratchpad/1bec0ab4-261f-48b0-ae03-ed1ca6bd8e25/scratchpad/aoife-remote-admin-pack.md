# Interview prep pack: Remote Administrative Assistant (Aoife)

**Built on:** your background as you described it, the duties from the advert (calendars, travel, Word/Excel documents, supplier invoices), and a 30-minute video call with the office manager. No full job description, round details beyond that, or company research was provided, so the question banks are generic to the role and labelled as such.

## 1. Fit snapshot

| Requirement (advert) | Your evidence (quoted from you) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| Managing calendars | "I ran the appointment book for four physios" | Medium | Partial match | "I kept four people's diaries in step every week, so I'm used to clashes and last-minute changes." |
| Booking travel | Not in your material | Low | Not shown | "I haven't booked travel for a team, but I've handled bookings with suppliers and rearranged them when plans changed." (only if true) |
| Word documents | "I'm good with Word" | High | Direct match | "Word is my strongest tool; I'm comfortable producing and formatting documents." |
| Excel | "okay with Excel" | Medium | Partial match | "I'm comfortable with the basics and I'd tell you where I'm still learning." |
| Supplier invoices | "chased unpaid invoices" | Medium | Partial match | "I chased unpaid invoices, so I know how to follow up on payments. I'd need a quick walkthrough of your processing system." |

**Prohibited claims (built locally):** do not claim advanced Excel, travel-booking experience, or invoice entry or posting in an accounting system unless that is true. Keep Excel at "okay" and say what you would need to learn.

## 2. Persona weights

- **Office manager (primary):** practical and process-focused. Expect questions on how you organise your day, handle conflicting requests, and work without someone next to you.
- **Remote-work screen (secondary):** how you manage a remote role: communication, availability, tools.

## 3. Question banks

### Bank A: Role-fit and experience (behavioural)

**A1. Tell me about your role at the physiotherapy clinic.**
- *Type:* Background.
- *Guidance:* Lead with the appointment book for four physios, then the invoice follow-up. Keep it under 90 seconds.
- *Provenance:* Candidate-sourced. "I ran the appointment book for four physios" and "chased unpaid invoices."

**A2. Give an example of when two people wanted the same slot.**
- *Type:* Behavioural (calendar management).
- *Guidance:* Describe the situation, what you checked (priority, urgency), who you told, and the result. Use a real example only.
- *Provenance:* Story-selection scaffold. Pick a real clash from the appointment book.

**A3. How would you manage a calendar for someone who travels a lot?**
- *Type:* Situational.
- *Guidance:* Describe your process: confirm the schedule in advance, block travel time, check time zones, send a daily summary. Be clear this is your approach, not past experience, unless it is.
- *Provenance:* Generic. No candidate sentence supports this; it is a selection scaffold.

**A4. Have you booked travel before?**
- *Type:* Skeptic / gap probe.
- *Guidance:* Answer honestly. If you have not, say so and describe the nearest real experience (booking supplier appointments, rearranging bookings). Then say how you would learn the booking tool quickly.
- *Provenance:* Answer slot. The material does not show travel booking.

### Bank B: Technical tasks (Word, Excel, invoices)

**B1. How comfortable are you with Excel? What would you use it for?**
- *Type:* Skeptic.
- *Guidance:* Say "okay" honestly, then name the tasks you can do (sorting, simple totals, basic formulas if true). Name one thing you would need to learn. Do not claim more.
- *Provenance:* Candidate-sourced: "okay with Excel."

**B2. Walk me through how you would prepare a document in Word for a client.**
- *Type:* Practical.
- *Guidance:* Describe your steps: template or previous version, structure with headings, consistent formatting, proofreading, file naming, and checking before sending.
- *Provenance:* Candidate-sourced: "good with Word." Process details are generic unless you have a real example.

**B3. How would you process a supplier invoice you received?**
- *Type:* Practical.
- *Guidance:* Describe the general steps: check the invoice against the order or the agreed price, confirm the goods or services were received, log it, send it for approval, and track payment. Be clear if you have only done part of this, like chasing unpaid invoices.
- *Provenance:* Candidate-sourced: "chased unpaid invoices." Process steps are generic.

**B4. An invoice doesn't match the purchase order. What do you do?**
- *Type:* Situational.
- *Guidance:* Hold the invoice, check the difference, contact the supplier and the requester, record the outcome. Do not approve or pay it until it is resolved.
- *Provenance:* Generic.

### Bank C: Remote working

**C1. How do you stay organised and reachable when you work remotely?**
- *Type:* Situational.
- *Guidance:* Name the tools you have used, your check-in routine, and how you flag urgent items. Use only tools you have used.
- *Provenance:* Generic unless you name real tools.

**C2. What would you do if you had two urgent requests from different people at the same time?**
- *Type:* Situational.
- *Guidance:* Ask which is more urgent and who decides, tell both people about the conflict, and agree a deadline. Escalate to the office manager if it cannot be settled.
- *Provenance:* Generic.

## 4. Reverse questions (ask the interviewer)

- "What does a typical week look like for the person in this role?" *Why it lands:* shows you think about the job in practice.
- "Which of the tasks in the advert takes the most time right now?" *Why it lands:* shows priorities and gives you the real workload.
- "What tools do you use for calendars, travel and invoices?" *Why it lands:* lets you say what you already know and what you would need to learn.
- "How do you usually onboard someone into this role?" *Why it lands:* shows you plan to learn quickly.

## 5. Preparation checklist

1. Re-read the advert and write one real example for each duty.
2. Practise A2 and B3 out loud. Keep answers under two minutes.
3. Test your video call setup: camera, mic, lighting, quiet room, a clean background.
4. Prepare two or three real examples: a calendar clash, a chased invoice, a Word document you produced.
5. Prepare your answers on Excel: what you can do now and what you would learn.

## 6. Upgrade menu

- **Full job description:** would replace the generic duties with the real requirements and tighten the banks.
- **Round details:** whether the call is screening or a full interview, and the topics the office manager will cover.
- **Excel examples:** any spreadsheet tasks you have done, which would move B1 from "okay" to a specific example.
- **Company research:** the company's published values and recent news, to build a values cheat sheet.
