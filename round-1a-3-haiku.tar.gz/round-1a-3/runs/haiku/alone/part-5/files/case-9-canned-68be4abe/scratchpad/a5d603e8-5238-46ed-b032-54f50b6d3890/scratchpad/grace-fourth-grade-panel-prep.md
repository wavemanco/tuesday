# Interview prep: Fourth Grade Teacher, Halvering Elementary (Orrinsford CSD)

Format: 45-minute panel on Thursday. Principal Dolores Vantongeren plus two fourth-grade team members.
Built from: your résumé summary and the invite. No job description or research was used (see the upgrade menu).

## 1. Fit snapshot

| Requirement (from invite) | Your evidence (quoted) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| Valid Illinois Professional Educator License with elementary endorsement | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | High | None | Meets the stated requirement. Say it plainly. |
| Elementary classroom teaching | "Six years teaching third grade at a public elementary school in Joliet." | High | None | Six years of elementary classroom teaching. |
| Fourth-grade content | "I've never taught fourth grade" | High | Experience gap (grade level) | "I haven't taught fourth grade yet. My six years in third grade built the skills that carry into it: [your reading-instruction experience]." |
| Team leadership | "I've never been a team lead." | High | Experience gap (role) | "I haven't held the title of team lead. What I have done is [the curriculum transition you led], which involved colleagues on my grade level." |
| Reading curriculum / instruction (inferred from the role; no JD supplied) | "I led our grade level's move to a new reading curriculum in 2024" | High | None | Lead with this. It is your strongest match. |
| Family communication (inferred) | "I write a weekly email to families." | High | None | Concrete habit you can describe. |
| Extra-curricular reading support (inferred) | "I've run the after-school reading club for the last two years." | High | None | Ongoing commitment, two years running. |

Prohibited claims (do not coach these in any answer):
- Any fourth-grade teaching experience, including substitute or co-teaching, unless you actually have it.
- Any team-lead title or formal leadership role.
- Reading score gains or other outcomes. Your material gives none. Add them only if you have data and can cite it.
- Any claim that you led the curriculum decision for the whole school. Your material says you led your grade level's move.

## 2. Panel read

Three people, three likely angles:
- **Principal:** school-wide fit, leadership potential, how you handle change. Likely to probe the team-lead gap.
- **Fourth-grade team member (1):** day-to-day collaboration and grade-level planning. Likely to probe fourth-grade content.
- **Fourth-grade team member (2):** classroom practice and student needs. Likely to ask about specific routines and assessments.

Weights (relationship priors, since no profiles were supplied): principal 40%, team members 60% combined.

## 3. Question bank

Question types: **Behavioral**, **Situational**, **Skeptic** (probes a gap), **Technical** (grade-level content and practice).

### Principal

**Q1. Tell us about a time you led a change that affected your colleagues.** (Behavioral)
- Provenance: Your sentence "I led our grade level's move to a new reading curriculum in 2024" is the base.
- Guidance: Describe the situation, the colleagues involved, what you did, and what happened. Keep your role exact: you led the move for your grade level. Name one thing you would do differently.

**Q2. You haven't been a team lead. Why should we consider you for a role on a grade-level team?** (Skeptic)
- Provenance: "I've never been a team lead."
- Guidance: Acknowledge the gap in one sentence. Then bridge with the 2024 curriculum move and the reading club. Close by naming what you want to learn from the fourth-grade team. Do not claim leadership you have not held.

### Fourth-grade team members

**Q3. What do you know about fourth-grade reading expectations, and how would you adapt your third-grade approach?** (Technical)
- Provenance: "Six years teaching third grade" and "I've never taught fourth grade."
- Guidance: Name two or three specific third-grade practices you would carry forward. Say what you would need to learn about the fourth-grade standards and where you would look for them. Do not imply familiarity with the school's fourth-grade materials that you do not have.

**Q4. How do you communicate with families, and how would you keep the fourth-grade team informed?** (Behavioral)
- Provenance: "I write a weekly email to families."
- Guidance: Describe the email's structure and one example of a useful message. Offer to share updates with the team in the same rhythm.

**Q5. Tell us about a time you worked through a disagreement with a colleague about instruction.** (Situational)
- Provenance: none in your material. This is an answer slot: pick a real example if you have one. If you do not, say so and describe how you would approach it.
- Guidance: Use a real example. Describe what you heard from the other person, what you changed or held to, and the result.

## 4. Gap-and-bridge answers you can rehearse

- **Fourth-grade gap:** "I haven't taught fourth grade. I have taught six years of third grade, so I know what students bring into the year, and I want to learn the fourth-grade sequence from your team."
- **Team-lead gap:** "I haven't been a team lead. The closest I have come is leading our grade level's reading curriculum move in 2024, and I'd like to build more of that kind of work."

## 5. Reverse questions (ask 2 or 3)

- "What does a typical week of planning look like for the fourth-grade team?" (Shows you are thinking about daily work.)
- "What would you hope the new fourth-grade teacher has accomplished by the end of the first semester?" (Shows you care about outcomes.)
- "How does the team currently use reading data to plan instruction?" (Links back to your reading background.)

## 6. Logistics checklist

- Confirm the exact time, room or video link, and who to contact if the link fails.
- Bring printed copies of your PEL verification if the panel asks. Do not bring your SSN or any other identifying number to the interview.
- Prepare a one-minute opening that covers the PEL, six years of third grade, the 2024 curriculum move, and the reading club.

## 7. Upgrade menu

- **Job description:** would let the questions track the posting's exact wording.
- **Focus areas or pre-declared tasks from HR:** would tell you whether the panel will ask for a lesson demo or planning sample.
- **Research on the school or district:** would add values and recent strategy. Not run yet, so none is included here.
- **Panel member names and public background:** would let the reverse questions be personal to each interviewer.
