# Interview prep pack: Remote Administrative Assistant

**Company:** Brennock Facilities Ltd (as named in the invite; not verified)
**Interviewer:** office manager (name not given)
**Format:** 30-minute video call
**Built from:** your message only. Research tier L0: no searches or page fetches were run, so there is no company values, strategy or vocabulary section.

## How to use

Personas describe how a question is asked. Types describe what is being scored:

- **VAL**: behavioural / values alignment
- **EXP**: work-experience deep-dive
- **JD**: role and job-description driven
- **CO**: company and strategy knowledge
- **CASE**: hypothetical or live problem

The guidance is scaffolding, not a script. Say only what you did.

## Prep triage

Time available wasn't stated, so this is a default order:

1. Rehearse **B1** and **A1** out loud. These are the two you are most likely to be asked to expand on.
2. Rehearse the honest answer slots **A2** and **C2**. These are the gaps the interviewer is most likely to probe.
3. Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (your message) | "ran the appointment book for four physios" (your message) | medium | [grounded] | transferability | Your material shows a shared appointment book for four clinicians, not executive diaries. Say that scope plainly: "I ran the appointment book for four physios." Answer slot: name one scheduling clash you resolved and how. |
| F2 | "booking travel" (your message) | none given | none | [grounded] | discovery | Nothing in your material shows travel booking. Answer slot: say whether you have booked travel for yourself or anyone else. If not, say so and describe how you would learn the supplier portal. |
| F3 | "preparing documents in Word" (your message) | "good with Word" (your message) | medium | [grounded] | presentation | Your quote reaches Word document work in your own terms. Say it as you said it: "I'm good with Word." Name one document you have formatted or produced. |
| F4 | "preparing documents in ... Excel" (your message) | "okay with Excel" (your message) | low | [grounded] | discovery | "Okay" is your own self-rating and shows no task. Answer slot: name the most complex thing you have done in Excel, or say you are comfortable with basics and would ask for help with the rest. |
| F5 | "processing supplier invoices" (your message) | "chased unpaid invoices" (your message) | low | [grounded] | transferability | Chasing unpaid invoices is the collections side of the same ledger. It does not show processing supplier invoices. Say what you did: "I chased unpaid invoices." Answer slot: say whether you have ever recorded or matched a supplier invoice. |

## Prohibited claims

These are claims a candidate reaches for under pressure that your material does not support. This pack will not coach them.

- **Managing executive or multi-person calendars, or booking travel for others.** Basis: F1, F2. Honest form: "I ran an appointment book for four clinicians. I haven't booked travel, and here is how I would learn it."
- **Processing supplier invoices or running accounts payable.** Basis: F5. Honest form: "I chased unpaid invoices, which is the other side of the ledger. I haven't processed supplier invoices, but I would check the record-keeping first."
- **Advanced Excel.** Basis: F4 (your own words: "okay with Excel"). Honest form: "I'm comfortable with basics, and I would tell you where I'd need help."

## Question banks

Persona weights, from the relationship and round type you gave: **Skeptic** (primary, because your evidence has gaps the interviewer can see on the CV), **Conversational / Rapport** (a 30-minute first call), **Case / Strategist** (a small admin scenario).

### Skeptic

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | EXP, JD | "Tell me about the appointment book. How much of that was actually you?" | [grounded]: "ran the appointment book for four physios" (your message) | Describe what you did with the book: the rules you applied, how you handled clashes, which parts were decided by you and which were not. Stay at the scope of the four physios. | This is the most likely probe and your strongest transferable evidence. The skill here is shrinking the claim to what you did, not defending a bigger one. |
| A2 | JD | "You haven't booked travel before. How would you handle it?" | [generic] (answer slot, no quote) | If you have booked anything for yourself or others, say what. If not, say so, then describe your first three steps: the supplier portal, the approval, the confirmation. | This is the discovery gap in F2. A plain, honest answer beats a bluff. |
| A3 | JD | "Your experience is on the chasing side of invoices. Have you processed supplier invoices?" | [grounded]: "chased unpaid invoices" (your message) | Say what you did: chased unpaid invoices. Then say whether you have recorded or matched supplier invoices. If not, say so and say what you would check first. | Transferability gap in F5. The interviewer will likely test whether you can tell the two sides apart. |

### Conversational / Rapport

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| B1 | EXP | "So, walk me through your background." | [grounded]: "two years as a receptionist at a physiotherapy clinic" (your message) | A 90-second arc: the role, the four physios, the appointment book, the invoice chasing, and why you want this kind of role now. | Openers are scored, even when casual. |
| B2 | JD | "What would you enjoy most about this kind of work?" | [generic] (answer slot) | One sentence in your own reason. Pick something the job actually contains: calendars, documents, or the sense of running an office. | Shows whether you read the ad. |

### Case / Strategist

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | CASE, JD | "A manager asks you to book a trip into a full diary, by end of day. Walk me through your first three steps." | [generic] (scenario, no quote) | Clarify dates, budget and approval first. Check the diary for clashes. Book, confirm, and record it where the manager can see it. | Scores structure and clarifying questions more than the right answer. |
| C2 | JD | "How comfortable are you building a spreadsheet from scratch, for example a supplier invoice log?" | [grounded]: "okay with Excel" (your message) | Say what you can do now, and name what you would need to look up. Do not describe the spreadsheet as advanced. | Excel gap in F4, asked as a live task. |
| C3 | JD | "Show me how you would format a three-page document for a client." | [grounded]: "good with Word" (your message) | Walk through the steps you would take in Word: styles, headings, the contents page. Name one document you have produced. | Tests the presentation claim in F3 against a concrete task. |

## Reverse questions

Each one is a question for the interviewer. None asks them to check the invite.

1. **"What does a typical week look like for whoever holds this role?"** Why it lands: it shows you are planning for the workload.
2. **"Which of the four areas, calendars, travel, documents or invoices, takes the most time?"** Why it lands: it shows you are thinking about priorities.
3. **"What systems do you use for the diary and for invoices?"** Why it lands: it shows you would check the tools before you start.
4. **"How is the role supported in the first month?"** Why it lands: it shows you expect to learn on the job and want to plan for it.
5. **"What would a good first six months look like?"** Why it lands: it gives you a clear picture of the target.

## Upgrade menu

- **The full ad text** → the requirements in the fit snapshot become quoted rather than paraphrased, and the gap rows get sharper.
- **Anything from the company's own website** → a short company vocabulary section, so you sound current.
- **The interviewer's name and role** (only once the company is confirmed through contact details you find yourself) → a tailored reverse question and adjusted persona weights.
- **Any process details from the employer** (length, format, what happens next) → the interview structure in the pack gets firmer.
