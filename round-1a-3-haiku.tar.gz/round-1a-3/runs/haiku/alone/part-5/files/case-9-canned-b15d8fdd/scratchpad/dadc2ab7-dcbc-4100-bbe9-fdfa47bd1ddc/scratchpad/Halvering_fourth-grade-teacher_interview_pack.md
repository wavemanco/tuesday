# Interview prep: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. 45-minute panel interview on a Thursday, with Principal Dolores Vantongeren and two fourth-grade team members (names not given).

**Date:** the invite says "Thursday" without a date. Today is Friday 20 November 2026, so the next Thursday is 26 November, which is Thanksgiving. Confirm the date with HR.

**Research tier:** L0. No searches or page fetches were run for this pack. It is built from your invite and your résumé only.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored:

- **VAL**: behavioral and values alignment
- **EXP**: deep-dive on your work experience
- **JD**: the role's stated requirements
- **CO**: company and strategy knowledge
- **CASE**: a live problem

Guidance is scaffolding, not a script. An answer slot is an instruction for the interview with two honest branches: say what you did, or say plainly that it was not yours or did not happen.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | Met on the page. State the license and its date as your CV does. |
| F2 | "Fourth Grade Teacher" (invite, position title) | "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your CV) | medium | [grounded] | transferability | Your material shows six years of third grade, and it says you have not taught fourth. Bridge from the quote's own scope: "For six years I taught third grade." Answer slot: if any of your work touched fourth-grade content or planning, say which; if none did, say so plainly and say how you would learn the year. |
| F3 | Leads a grade-level team (generic, role-family) | "I've never been a team lead." (your CV) | none | [grounded] | capability | The stated negative is yours: "I haven't been a team lead." Then the plan, said as a plan and never as a past: how you would learn the team's planning and what you would ask them first. |
| F4 | Leads curriculum change and reading instruction (generic, role-family) | "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've run the after-school reading club for the last two years" (your CV) | medium | [grounded] | presentation | Reword only the quotes: "In 2024 I led our grade level's move to a new reading curriculum. For the last two years I've run the after-school reading club." Add no practice, figure or event. |
| F5 | Communicates with families (generic, role-family) | "I write a weekly email to families." (your CV) | medium | [grounded] | none | The quote reaches the requirement. Say it in those words. Expect a probe on whether it works (D3). |
| F6 | Uses student data to plan instruction (generic, role-family) | none given | none | [generic] | discovery | Your material does not show it. Answer slot: if you tracked anything in the reading club or the 2024 move, name it and what it counted; if you did not, say so and say what you would track first. |

Reading the snapshot: Confidence grades your evidence. Provenance grades what this pack wrote. Gap type says how the gap is handled. Rows F2 and F6 are the places the panel is most likely to press.

## Prohibited claims

Each entry names its basis, and each has an honest form. The pack will not coach any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Fourth-grade teaching experience | Inflated form of F2. Your CV says third grade. | "For six years I taught third grade." The limit is the pack's own observation: your material shows third grade only. |
| Team lead, or leading the grade-level team | Inflated form of F3 and F4. You stated the negative yourself. | F4's quote at its own scope, plus the plain acknowledgment "I haven't been a team lead." |
| Running the school's reading program | Inflated form of "I've run the after-school reading club" (F4). | The club, for two years, in those words. |

## Persona table

The panel blends two relationship priors. The principal carries the hiring-manager prior (Skeptic and Case/Strategist). The two team members carry the peer prior (Peer Evaluator and Data-Driven Prober). Pressure is not weighted, since nothing signals a stress interview; the Skeptic bank's follow-ups cover it. The weights are shown so you can recalibrate if you know something the pack does not.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (principal) | Probes the fourth-grade gap and the team-lead gap | 5 questions. The two stated gaps (F2, F3) are where this panel will look first. | Rehearse the single most likely objection until it is calm. Bridge only from quoted evidence; state the limit plainly. |
| Peer Evaluator (team) | Seams with their team, shared planning, disagreement | 4 questions. Team members weigh what a new colleague costs their work. | Reciprocity: say what you bring, then what you need. Describe disagreement with spine and tact. |
| Case/Strategist (principal) | Live reading and first-term problems | 4 questions. The principal is buying judgment for the fourth-grade year. | Clarify, then structure. Think aloud. Name a risk. |
| Data-Driven Prober (team) | Asks how you know reading is improving | 3 questions. Team members check claims against their own data habits. | Say what you measured and how. Say plainly when you did not measure. Never offer a figure you cannot repeat. |
| Conversational / Rapport | Opening "walk me through" | 2 questions. Casual openers are still scored. | Keep a 90-second arc built from quotes only. |

## Question banks

Provenance comes before the guidance. Each row carries every quote its guidance rests on.

### A. Skeptic (weight 5, principal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. Why should we hire you to teach it?" | JD | [grounded] "I've never taught fourth grade" (your CV); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Answer in one sentence first: the six years, in your words. Then the nearest grade-level change you carried: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if any of your work touched fourth-grade content or planning, name it; if none did, say so plainly, then say how you would learn the fourth-grade year in your first term. Hold the third-grade quote through two follow-ups instead of arguing the premise. | **Highest-ROI prep in this pack.** F2 is the gap no quote reaches, and the principal is likely to open here. A calm, specific answer changes the interview. Type JD because it scores the title's requirement. |
| A2 | "Third grade and fourth grade are different jobs. What difference are you underestimating?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Hold, then concede: name one real difference you expect, in your own words, and what you would do about it. Do not claim you already know the fourth-grade year, and do not say the difference does not matter. | A follow-up to A1 from the same chair. It tests whether you fold or overclaim under pressure. |
| A3 | "I don't see leading a team in your background. How would you handle that here?" | JD | [grounded] "I've never been a team lead." (your CV); "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Plain acknowledgment: "I haven't been a team lead." Then the nearest thing you have, at its own scope: you led that change for your grade level. Then a plan, not a past: how you would learn the team's planning, and what you would ask them first. | F3 is a gap you stated. The acknowledgment is your own words; the plan is a plan. Do not describe a team-lead role. |
| A4 | "Your team disagrees with a reading decision you have been asked to carry out. What do you do?" | CASE | [generic] | Structure it: what you would ask first, who makes the call and where you fit, how you carry the decision out in the meantime, and what you would bring back later with evidence. | A live problem from the team setting. It presupposes nothing about you, so the guidance makes no claim about your past. |

### B. Peer Evaluator (weight 4, team members)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our team plans units together. Where would you fit in, and what would you need from us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Say what you did at the scope the sentence gives: you led the grade level's move to a new reading curriculum. Then ask what the team's units and assessments are, and what they would want you to bring. | The team's planning practice is the interviewer's own words, so the question may presuppose it. The bridge rests on the quote alone. |
| B2 | "How do you keep families in the loop during a unit?" | JD | [grounded] "I write a weekly email to families." (your CV) | Describe the weekly email in your own words: what it covers and how it goes out. Answer slot: if you know how families respond to it, name that; if you do not track it, say so plainly and say what you would check first. | F5. Family communication is a common grade-team requirement. The answer stays on what you do, not on what it achieves. |
| B3 | "Tell me about a time you disagreed with a colleague about how to teach something." | JD | [generic] | Open prompt. Selection scaffold: pick a time a colleague saw a teaching approach differently from you; say what you proposed, what they proposed, what each of you did, and how it ended. If no such time comes to mind, say so plainly, then describe how you would raise a disagreement with a grade-level colleague. | An open prompt on the peer seam. It supplies no event, so the guidance claims nothing about your past. |
| B4 | "The 2024 reading move: whose idea was it, and what was yours?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Attribute at the sentence's scope: say what you led. Answer slot: if someone else chose the curriculum, name who, and say what you did with it; if the decision was not yours, say so and stay with what you led. | Credit-sharing probe. "Led the move" is not "chose the curriculum", and the answer must match the sentence. |

### C. Case/Strategist (weight 4, principal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A fourth grader is reading well below level in October. Walk me through what you would do." | CASE | [generic] | Clarify first: what the reading data shows, what has already been tried, and what the family knows. Then structure: confirm the level of need, targeted small-group work, progress checks on a set schedule, family contact, and a specialist referral if it stalls. Name one risk. | A live problem from the role. Clarifying before structuring is the scored move. No claim about your past. |
| C2 | "Your first sixty days with the team: what do you do before you change anything?" | CASE | [generic] | Listen and learn first: the scope and sequence, the assessments, the team's routines. Then propose one change, small and tested. Say what you would not change yet. | The first-term question at the principal level. Generic. |
| C3 | "Our fourth-grade reading scores dipped this year. What would you check first?" | CASE | [generic] | Clarify: which measure, which students, and what changed. Then structure: a data check, whether the curriculum is being taught as designed, instruction time, and grouping. Name what you would need from the team. | A diagnostic case. The premise is the interviewer's own, and the guidance presupposes nothing about you. |
| C4 | "What would you change about how a new reading curriculum rolls out, based on your 2024 move?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Answer slot: if there is something you would change from that move, say what and why; if you would change nothing, say what you would keep and why. | Tests whether you reflect on the 2024 move rather than repeat it. The answer has to come from your experience, not a lesson drawn for the interview. |

### D. Data-Driven Prober (weight 3, team members)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How would you know a student's reading is improving?" | JD | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Answer slot: name what you measured in the reading club and how it showed progress. If you did not measure progress there, say so plainly, then name the first measure you would use and why. | The prober's opener on reading data. F6 is the gap here; the honest branch covers it without claiming a measure. |
| D2 | "Tell me how you ran the reading club: how students were chosen, and how you knew it was working." | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Describe how the club ran, in your words. Answer slot: if you measured whether it worked, name the measure and what it counted; if you did not, say so plainly and say what you would measure next. Do not offer a figure you cannot repeat. | A denominator probe. The club is the only program on your CV, so expect it. |
| D3 | "How do you know families read your weekly email?" | JD | [grounded] "I write a weekly email to families." (your CV) | Answer slot: name any sign that families read it, such as replies or questions; if you have none, say so and say what you would try. | A prober's follow-up on F5. "I don't know" is an honest answer, and it is one the panel can use. |

### E. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey to fourth grade." | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | A 90-second arc: where you started, the third-grade years, the 2024 move, the reading club, the family email. Answer slot: why fourth grade, in your own words; your material gives no reason for it. | The casual opener is still scored. The arc is built from quotes only, and the reason for fourth grade is yours to supply. |
| E2 | "What's the best part of teaching for you right now?" | JD | [generic] | Name one specific moment from your own experience, in one or two sentences. Answer slot: if no moment comes to mind, say so, and name what you would most like to do with a fourth-grade class. | A rapport opener. Generic; the answer is yours. |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Illinois PEL with elementary endorsement (invite) | None, and why: F1 shows it met. The panel's check on it is a status check, not a rehearsal. |
| Fourth-grade teaching (position title) | A1, A2, C1, C2 |
| Team membership and planning | B1, B3, B4 |
| Team lead (generic) | A3 |
| Reading instruction and curriculum (generic) | C3, C4, D1, D2 |
| Family communication (generic) | B2, D3 |
| Data-based instruction (generic) | D1, D2 (F6 is the gap) |

## Reverse questions

1. "How does the fourth-grade team plan together week to week?" Why it lands: shows you are planning for their actual routine.
2. "Which reading materials does the fourth-grade team use now, and how were they chosen?" Why it lands: connects to your 2024 curriculum move.
3. "What does a new fourth-grade teacher most need to learn in the first month that isn't written down?" Why it lands: signals you expect to learn, and gets you the unwritten part.
4. "When a student falls behind, who on the team gets involved first?" Why it lands: ties to C1 and shows you think about process.
5. "What does the team need from a new colleague that it doesn't have yet?" Why it lands: a reciprocity question for the peer members. It turns the conversation toward what they need.
6. "What would make you say in a year that this hire worked out?" Why it lands: tells you the principal's real success measure.

## Sources

- Provided documents: your invite (quoted above) and your résumé as you pasted it.
- Searches and fetches: none run.

Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Halvering Elementary values | unavailable | Research was not run for this pack. Would have given a values cheat sheet. |
| 2. Orrinsford district interview process | unavailable | Would have set the round structure and the persona weights. |
| 3. District strategy and recent news | unavailable | Would have supplied CO questions. |
| 4. Principal Dolores Vantongeren, public footprint | unavailable | Would have tuned the Skeptic bank and added a tailored reverse question. |
| 5. Representative Fourth Grade Teacher JD | unavailable | Would have supplied requirement lines marked [inferred]. |

## Upgrade menu

- The job posting or full JD → the invite's requirements become a full list, and the coverage table is checked against it
- The panelists' names → persona weights per panelist, and a tailored reverse question for the principal
- The recruiter's note on focus areas or a graded task → the banks reweight, and any deliverable gets its own build section
- Research at L1 (school values, district strategy, a representative JD) → a values cheat sheet, current CO questions, and `[inferred]` requirements replaced by sourced ones
- Your answers to the answer slots (A1, A3, D1, D2, E1) → those answers become quoted material, and the rows that draw on them are rebuilt
- A tuesday-dossier.md from job-underwriter → verified evidence and a checked objection list in place of the worksheet's inferred rows
