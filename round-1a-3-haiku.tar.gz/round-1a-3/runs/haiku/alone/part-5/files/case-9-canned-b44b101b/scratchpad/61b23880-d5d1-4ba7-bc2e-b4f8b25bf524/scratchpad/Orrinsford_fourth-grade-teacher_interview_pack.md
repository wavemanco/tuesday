# Interview pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Panel interview, 45 minutes, Thursday. Panel: Principal Dolores Vantongeren and two fourth-grade team members (names not yet known).

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: JD (the stated requirement), EXP (your past work), VAL (the district's published beliefs), CASE (a live problem), CO (company knowledge).
- Guidance is scaffolding for a spoken answer, not a script. Rehearse what you actually did, in your own words.
- Where a guidance cell says "answer slot," it is an instruction for the interview: answer the branch that is true for you.

## Requirements and sources

The invite sets one requirement: "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." No job description was supplied, so the other requirements below come from the district's published beliefs (fetched) and from your own statement of your gaps. Rows drawn from either are labeled `[generic]` where they are role-family patterns.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | Met on your CV. The endorsement covers grades 1–6, which includes fourth grade. Have your license details ready to confirm, since the invite makes it a requirement. |
| F2 | fourth-grade classroom teaching (role-family, the posting's grade level) | "I've never taught fourth grade" (your CV) | none | [generic] | capability | Stated absence, so the words are yours: "I haven't taught fourth grade." Adjacent work, at its own scope: "Six years teaching third grade at a public elementary school in Joliet." Then a plan for the first month, said as a plan and never as a past. |
| F3 | leading a grade-level team (role-family, the panel's structure) | "I've never been a team lead" (your CV) | none | [generic] | capability | Stated absence: "I haven't been a team lead." Adjacent work, at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Do not describe that move as team leadership. |
| F4 | "Every Child a Reader: no student leaves third grade without a reading plan." (district's published beliefs, fetched) | "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years" (your CV) | medium | [grounded] | presentation | Your material already reaches this belief in other terms. Reword only that quote: "I led the move to a new reading curriculum, and for two years I've run the after-school reading club." Add no outcome, figure or student story. |
| F5 | "Families Are Partners: each teacher speaks with every family each term." (district's published beliefs, fetched) | "I write a weekly email to families." (your CV) | low | [inferred] | transferability | The email is written contact at its own scope. It does not show conversations with every family. Say what the email is: "I write a weekly email to families." Answer slot: if families reply, or you talk with them directly, say how, in your own words. |
| F6 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." (district's published beliefs, fetched) | none given | none | [grounded] | discovery | Your material does not show how assessments informed your teaching. Answer slot: if an assessment changed what you taught, say which and how; if none did, say so plainly and say how you would use one. |

Two observations from this snapshot, as the pack's own analysis:
- Your material says "the grade level's move," not the district's adoption, and it says "run the reading club," not any outcome. The pack does not add either.
- F2 and F3 are stated absences. You can say them plainly; the rest of your answer rests on the adjacent work at its own scope.

## Prohibited claims

Not coached in any answer, slot, or drill feedback in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Sourced negative, F2 | "I haven't taught fourth grade." |
| Has led a team | Sourced negative, F3 | "I haven't been a team lead." |
| Led the district's reading curriculum adoption | Inflated form of F4 | "I led our grade level's move to a new reading curriculum in 2024." |
| Speaks with every family each term | Inflated form of F5 | "I write a weekly email to families." |

## Reading the interviewer

Public footprint only. Principal Dolores Vantongeren has been principal of Halvering Elementary School since 2022, after nine years as a reading specialist. Her 2025 forum talk, "Small Groups, Big Readers," covered weekly reading conferences in grades 3 to 5.

- Practical implication: she is a reading person. Expect reading probes, and let F4 carry them.
- Shared jump: none offered. Your path has no reading-specialist-to-principal move for her to mirror.
- Mirror opportunity: her phrase "weekly reading conferences" is hers. Use it only if your own material says it. It does not.
- The two team members' public footprints were not researched. Their personas below are the peer priors.

## Persona table

Panel weighting: the principal carries the Case/Strategist and Skeptic personas; each team member carries Peer Evaluator and Data-Driven Prober. Weights are relationship priors for a panel, adjusted by the principal's published reading focus.

| Persona | Who | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Principal | Quiet probing of the fourth-grade and team-lead gaps | High (5 questions): the invite's requirement is met, so the open risk is fit to fourth grade and leadership | Rehearse the single most predictable objection until it is plain; the plain acknowledgment, then a plan |
| Case/Strategist | Principal | A live problem from fourth-grade reading | Medium (1 question): a principal hiring for a grade she does not teach directly still tests judgment | Clarify, then structure, then answer |
| Values/Behavioral | Principal, panel | Probes on the district's three published beliefs | High (3 questions): the beliefs are published and the panel is teaching staff and principal | Map a story to a belief only where your quote carries one; otherwise the selection scaffold |
| Peer Evaluator | Team members | Seam questions: what you would need from them, how you handle disagreement | High (3 questions): two peers will weigh what you add to their team | Reciprocity framing, and propose principles rather than pretending to know their seam |
| Data-Driven Prober | Team members | Asks how your reading work was counted | Medium (2 questions): the reading club and the curriculum move carry no figures in your material | Say what you measured, or say plainly you did not |
| Pressure | Panel | Interruptions, time-boxed answers | Low (0 separate questions): the Skeptic and Peer questions already test composure; hold through two follow-ups | Pause, restate, hold a position through two follow-ups |

## Question banks

### Skeptic (principal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. What would you do in your first month?" | JD | [grounded] "I haven't taught fourth grade." | Say the plan, not a past: how you would learn the fourth-grade scope and sequence, and what you would ask the team before changing anything. Keep it a plan. | F2 is the requirement this question probes; the answer is a plan, so it claims nothing. |
| A2 | "Why should we hire someone with no fourth-grade experience and no team lead role?" | JD | [grounded] "I haven't taught fourth grade." "I haven't been a team lead." | **Highest-ROI rehearsal in this pack.** "I haven't taught fourth grade, and I haven't been a team lead." Then your adjacent work at its own scope: "Six years teaching third grade at a public elementary school in Joliet," and "I led our grade level's move to a new reading curriculum in 2024." Hold through two follow-ups by returning to those sentences. Concede specifically if pressed: name what you would need to learn first. | F2 and F3 are the gaps the panel will press. The concession is the honest answer; a rehearsed hold is worth more than a stretched one. |
| A3 | "What changed for students when your grade level moved to the new reading curriculum?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if you saw an outcome, say what and how you know; if you did not measure one, say so plainly and say what you would look at first. | F4 is the strongest bridge, and the question presumes an outcome your material does not state. |
| A4 | "Sixty seconds: why this district?" | CO | [grounded] "Every Child a Reader: no student leaves third grade without a reading plan." | Pick the one published belief that matches your work and say it in your own words. Your motivation is yours; nothing here supplies it. | The district's own belief is the raising source; it gives you the one anchor to answer from. |

### Values/Behavioral (principal and panel)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time a student's reading did not move. What did you do?" | VAL | [grounded] "I've run the after-school reading club for the last two years." | Open prompt. If a student in the club stalled, tell that one, in your own words, with what you tried. If none comes to mind, say so plainly, then describe how you would handle a stalled reader. | Maps to "Every Child a Reader"; the club is the nearest sentence you have. |
| V2 | "How do you keep families informed about what their child is learning?" | VAL | [grounded] "I write a weekly email to families." | Describe the weekly email: what it covers and how you write it. Answer slot: if families reply or you speak with them, say how. | Maps to "Families Are Partners." Your quote is the email; the answer does not stretch it. |
| V3 | "How do assessments change what you teach next week?" | VAL | [generic] | Answer slot: if an assessment changed a lesson, say which and how; if none did, say so plainly and say how you would use one. | Maps to "Teach for Tomorrow, Not for the Test"; your material does not show an assessment, so this is a selection scaffold. |

### Peer Evaluator (team members)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our team has taught fourth grade together for years. How would you fit in?" | JD | [grounded] "I haven't taught fourth grade." | Say what you would need from them first, then what you bring from third grade. Propose principles for working together rather than claiming to know their seam. | The seam question; F2 is the gap and the reciprocity is the answer. |
| P2 | "What would you need from us in your first term?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Name what you would ask for: planning time, the scope, the team's reading routine. Each is a request, not a claim about your past. | Peer reciprocity: what you need and what you bring to their team. |
| P3 | "Tell us about a time you disagreed with a colleague about how to teach reading." | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Open prompt. If the curriculum move involved a disagreement, tell it in your own words. If none did, say so plainly and describe how you would handle one. | Peer disagreement style is what this persona scores. |

### Data-Driven Prober (team members)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How did you measure the reading club's effect?" | EXP | [grounded] "I've run the after-school reading club for the last two years." | Answer slot: if you measured anything, say what and how; if you did not, say so and name what you would track. | The question presumes a measure your material does not state. |
| D2 | "Which students did the curriculum move help, and how do you know?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: say which students you watched and what you saw, in your own words; if you did not track it, say so. | Same presumption as A3, asked from the peer side. |

### Case

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A fourth grader reads at a second-grade level in week three. What do you do?" | CASE | [generic] | Clarify first: what the assessments show, what the student has been taught, what the family knows. Then structure a plan, with the team in it. | A live problem from the grade; it presumes nothing about your past. |

Coverage: JD requirement (the PEL) is met on your CV and is not a question. Fourth-grade experience (F2) is covered by A1, A2, P1. Team lead (F3) by A2, P3. Every Child a Reader (F4) by A4, V1, A3. Families Are Partners (F5) by V2. Teach for Tomorrow (F6) by V3. Thirteen questions in total; a 45-minute panel cannot rehearse many more, so this pack is deliberately shorter than a typical session pack.

## Values / principles cheat sheet

The district publishes three beliefs (fetched from its mission page).

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Every Child a Reader | No student leaves third grade without a reading plan. | F4: "I've run the after-school reading club for the last two years." |
| Families Are Partners | Each teacher speaks with every family each term. | F5: "I write a weekly email to families." Answer slot for direct contact. |
| Teach for Tomorrow, Not for the Test | Assessments inform teaching and never replace it. | F6 has no quote. Selection scaffold: pick a time an assessment changed what you taught; if none did, say so and say how you would use one. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Could you say more about how weekly reading conferences work in grades 3 to 5?" | Ties to her 2025 talk and her reading specialist path; it shows you read her work. |
| R2 | "What does a strong first term look like for a new fourth-grade teacher here?" | Shows you are planning for the role, and gives the panel a chance to name what they need. |
| R3 | "What could a new team member do in the first month that would genuinely help your team?" | Reciprocity for the team members; it turns the seam question into a shared one. |
| R4 | "How does the team check whether a reading plan is working before the term ends?" | Connects to the district belief and to the assessment question; a practical question about process. |
| R5 | "Which part of the fourth-grade year would you most want the new teacher to lead in year one?" | Asks about the role's real demands without claiming you have led them. |

## Sources

- Provided documents: the invite and your resume and message.
- Research tier: L1, searches 3 of 6, fetches 1 of 2.
- Fetched: the district's mission and beliefs page (fetched, one page).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford Community School District values | yes | Values cheat sheet and F4–F6: the three published beliefs, fetched and quoted. Query: "Orrinsford Community School District values mission". One URL returned, read. |
| 2. Interview process for this role family | skipped | The invite fixes the loop: one 45-minute panel with the principal and two team members. Persona weights follow that panel. |
| 3. District strategy and recent news | unavailable | Would have moved the CO bank. Not searched within the L1 budget. The upgrade menu offers it. |
| 4. Interviewer name (Principal Dolores Vantongeren) | yes | Reading the interviewer section. Query: "Dolores Vantongeren principal Illinois". One profile returned, the 2025 talk and principal since 2022. |
| 5. Representative JD for this title | unavailable | Would have fixed requirements beyond the PEL. Not searched within the L1 budget. The upgrade menu offers it. |

Unnumbered:
- Query "Halvering Elementary School Orrinsford": no results. A school check outside the declared targets; it moved nothing.

## Upgrade menu

- The job description text → the requirements beyond the PEL become `[grounded]`, and F2 and F3 are checked against the posting's own words.
- The two team members' names → per-member persona weights, and a note on their public footprint.
- Any task HR set for the 45 minutes (a demonstration lesson or a writing sample) → a graded-deliverable section for it.
- Any figures from the reading club or the curriculum move, if you tracked them → D1, D2 and A3 move from answer slots to defend-the-number questions.
- A representative JD search for the title → covers the rest of the requirement list.
- The district's current news and strategy → a learn-the-vocabulary section for recent moves.
- `tuesday-dossier.md` → one line on what it would add: a record of this prep's gaps, carried into later sessions.
