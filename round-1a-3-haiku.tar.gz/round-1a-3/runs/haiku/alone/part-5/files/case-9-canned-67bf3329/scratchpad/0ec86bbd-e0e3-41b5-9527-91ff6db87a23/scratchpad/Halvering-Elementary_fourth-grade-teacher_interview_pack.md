# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Orrinsford Community School District.** 45-minute panel, Thursday: Principal Dolores Vantongeren plus two fourth-grade team members (names not given). Built from your invite and CV, with no job description and no web research.

Relationship priors: the principal reads as a hiring manager (evaluator of your practice); the two team members read as peers (your future colleagues).

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say nothing you did not do.

- **JD**: the invite's requirements or the role itself
- **EXP**: what you actually did, and how you can show it
- **VAL**: not used here (no published values)
- **CO**: not used here (no research run)
- **CASE**: a live problem from the job, with no claim about your past

## Fit snapshot

Requirements are quoted from your invite; quotes from your CV and message are verbatim.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | Met on your CV. Your words: "active through June 30, 2029." Bring the license document. |
| F2 | "Fourth Grade Teacher position" (invite) | "Six years teaching third grade at a public elementary school in Joliet" (your CV) | medium | [grounded] | transferability | Your quote carries third grade, not fourth. Words: "Six years teaching third grade at a public elementary school in Joliet." Answer slot: the position raises a probe on what carries over. If you can name something from third grade you expect to carry into fourth, say what, in your own words; if you cannot, say so and say how you would learn the fourth-grade standards. |
| F3 | "two members of our fourth-grade team" (invite) | "I've never taught fourth grade" (your CV) | none | [grounded] | capability | A gap you stated, so the words are yours: "I haven't taught fourth grade." Then how you would learn it, said as a plan, never as a past. |
| F4 | Work with a grade-level team on a shared change ([generic], role family) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [generic] | presentation | Your words: "I led our grade level's move to a new reading curriculum in 2024." Add no detail the CV does not carry. |
| F5 | Communicate with families ([generic], role family) | "I write a weekly email to families" (your CV) | medium | [generic] | presentation | Your words: "I write a weekly email to families." Describe it as you do it. |
| F6 | Support student reading ([generic], role family) | "I've run the after-school reading club for the last two years" (your CV) | medium | [generic] | presentation | Your words: "I've run the after-school reading club for the last two years." Nothing about results is in the material. |

Your CV does not show that you have been a team lead. You said so directly: "I've never been a team lead." That is handled in the prohibited list and A4, not as a requirement row, because the invite does not ask for it.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any fourth-grade teaching experience | Sourced: your stated negative (F3) | "I haven't taught fourth grade." Plain acknowledgment; no slot. |
| Having been a team lead | Sourced: your stated negative ("I've never been a team lead") | "I haven't been a team lead." Plain acknowledgment; no slot. |
| Choosing the reading curriculum | Inflated form of F4 | F4's quote at its own scope. Your material says you led the move, not that you selected the curriculum. A3's slot asks how the choice was made, if it was yours. |
| Building or designing the reading club | Inflated form of F6 | F6's quote at its own scope: you run the club. |

## Persona table

| Persona | Who | Weight | How it shows up | Why | Counter-strategy |
|---|---|---|---|---|---|
| Skeptic | Principal | top, 5 questions | "You have never taught fourth grade." | The invite names the fourth-grade position; F2 and F3 are the visible gap. | Hold the third-grade years, acknowledge the gap plainly, then a plan, not a past. |
| Peer Evaluator | Two fourth-grade members | top, 5 questions | Seams, collaboration, credit, disagreement | They are the people you would work beside. | Name what you bring, not what you need; propose principles, not claims. |
| Data-Driven Prober | Fourth-grade members | mid, 3 questions | "What did you count?" | The reading club and the 2024 curriculum move are claims a prober tests. | Say what was counted; say plainly when it was not. |
| Case/Strategist | Principal | mid, 3 questions | A live classroom problem | The principal evaluates practice. | Clarify, then structure, then name risks. |
| Conversational | Either | low, 2 questions | Friendly opener: "walk me through" | Panels often open this way; casual questions are still scored. | A 90-second arc from your own sentences. |
| Pressure | Either | covered by A1's follow-ups | Time-boxed challenge | A 45-minute panel can time-box answers. | Pause, restate, hold through two follow-ups, then concede the gap specifically. |

Persona weights are priors from the relationship, not measured. Nothing about either interviewer's background is in the material.

## Question banks

### Skeptic (principal)

Highest-ROI prep in this pack: A1. The invite points at fourth grade, so expect this question in some form.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never taught fourth grade. Why should we hire you for this position?" | JD | [grounded] "I've never taught fourth grade" (your CV); [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Say the plain part first: "I haven't taught fourth grade." Then your years, in those words: "Six years teaching third grade at a public elementary school in Joliet." Answer slot: name one thing from those years you expect to carry into fourth grade, in your own words. If you cannot name one, say so and say how you would learn the fourth-grade standards. Hold through two follow-ups by returning to the third-grade years, never by adding fourth-grade experience. If pressed a third time, concede the gap in those words. | F3 is the gap the invite points at. The question presupposes only your own negative, so it is premised on F3's quote and adds no experience. JD because it scores the title requirement. |
| A2 | "What would you need to learn first to teach fourth grade well?" | JD | [generic] | Name what you would need, such as standards, materials and the team's routines, and how you would find out. Present it as a plan. Do not describe anything you have done. | Second follow-up to A1, rehearsed separately so the plan sounds like a plan. [generic] because the topic is the role's. |
| A3 | "Tell me about the reading curriculum change you led. What was your part?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Story-map on F4: the move, 2024, and what you led, in those terms. Answer slot: if you chose the curriculum, say how you chose it. If the district or a committee chose it, say so and describe what you did as the one leading the move. | F4 is your strongest evidence for leadership of a shared change and the likeliest place to be probed. EXP because it asks what was yours. |
| A4 | "You've never been a team lead. How would you lead a grade-level change here?" | JD | [grounded] "I've never been a team lead" (your CV); [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Plain acknowledgment first: "I haven't been a team lead." Then the move, in your own words. Then a plan: how you would learn the team's priorities before proposing a change. | The team-lead gap is one you stated. The plan shows judgment without claiming a title. JD because the panel is a team. |
| A5 | "Six years in Joliet, and now this position. Why this school, and why now?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Give your actual reason in your own words. Your material gives none, so this pack does not supply one. Answer slot: name what about this school or position draws you, if you can say so truthfully. If your reason is about leaving, not the school, say that plainly. | "Why now" is a standard motivation probe. The quoted years carry the only fact the question presupposes. |

### Peer Evaluator (fourth-grade team members)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What would you bring to a team that has been teaching fourth grade together?" | JD | [grounded] "two members of our fourth-grade team" (invite); [grounded] "I've run the after-school reading club for the last two years" (your CV) | Name what you bring in your own words, quoting only what your CV carries: the reading club, for two years. Do not claim fourth-grade experience. Answer slot: if you have worked on a shared plan with colleagues, say which. If not, say so and say how you would join their routines. | Reciprocity framing: what your work adds to their team. The reading club is the one concrete thing your CV carries here. |
| B2 | "Tell me about a time you disagreed with a colleague about how to teach something." | EXP | [generic] (persona stem: disagreement with equals) | Selection scaffold: pick a time you disagreed with a colleague over a teaching decision, with a named disagreement, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the 2024 curriculum move, or how you would handle it. | An open prompt, so it supplies no event. Peer Evaluator probes disagreement style. |
| B3 | "When work spans your grade level, how do you handle credit?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Say what the group did and what you did, as separate things. Use "led" only for what that sentence says. Answer slot: if credit came up on the curriculum move, say who did which part. If no one tracked it, say that. | Credit-sharing is a standard peer probe; F4 is the example it would test. |
| B4 | "How do you keep families informed about what is happening in class?" | JD | [grounded] "I write a weekly email to families" (your CV) | Describe what the weekly email carries and how you decide what goes in, using those words. Answer slot: if something changed and families needed telling, say how you handled it. If the email has not carried a change, say so. | F5 is your evidence. The team will care how families hear about shared decisions. |
| B5 | "Where do you expect the hardest part of teaching fourth grade to be?" | JD | [grounded] "two members of our fourth-grade team" (invite) | Name what you would expect, in plan form, and what you would want their view on. Make no claim about your fourth-grade experience. | A seam question from peers. Answered as curiosity, not a test. |

### Data-Driven Prober (fourth-grade team members)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What, if anything, do you track for the reading club?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Answer slot: if you tracked anything, say what was counted and what it was sensitive to. If you did not, say so plainly and say what you would measure first. Do not name a result you did not record. | Probers ask for the denominator. Your material gives the club's length, not any count. The question presupposes nothing. |
| C2 | "What did you measure before and after the reading curriculum change?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Answer slot: if you measured something before and after, say what, how it was counted, and which assumption behind it you would defend least, in your own words. If you did not measure it, say so, and say what you would measure first. Never name a result. | Tests the one headline claim, the 2024 move, for evidence. The second branch allows there was no measurement. |
| C3 | "Which assumption behind your reading-club work would you defend least?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | If you have an assumption in mind, name it in your own words. If you have not considered it, say so. Make no claim about any result. | Prober move: name the weakest assumption before they do. "I have not thought about it" is an honest branch. |

### Case/Strategist (principal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A fourth grader reads two years below grade level by October. What would you do in the first two weeks?" | CASE | [generic] | Structure: what you check first (what the student can already do, and assessment data), how you adjust instruction, how you involve the family, and what you record. Make no claim about your past. | A live problem from the role. CASE asks about no past. |
| D2 | "A parent emails that the reading change is moving too fast. What do you write back?" | CASE | [generic] | Structure: acknowledge, check the facts, offer a specific next step, and name who else needs to know. Do not describe a past parent email. | A live problem from family communication. |
| D3 | "What would be your first move in your first month with a new fourth-grade team?" | CASE | [grounded] "two members of our fourth-grade team" (invite) | Name one or two specific steps, in plan form. Make no claim about past moves. | A live problem set in the team the invite describes. |

### Conversational (either interviewer)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through how you got from third grade in Joliet to this interview." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | A 90-second arc: where you taught, what you led, what you ran, and why you are here, using only sentences from your CV. Do not add an event. | The casual register is still scored. The quoted years anchor the arc. |
| E2 | "What do you enjoy most about running the reading club?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Name one part in your own words. Do not invent a result or a number. | Scored for interest and communication economy, not for facts. |

## Requirement coverage

| Requirement | Source | Questions |
|---|---|---|
| Valid Illinois PEL with elementary endorsement | invite | None needed: your CV shows it met (F1). Bring the document. |
| Fourth Grade Teacher position | invite | A1, A2, D3 |
| Panel of two fourth-grade team members | invite | B1, B5, D3 |
| Work with a grade-level team on a shared change | [generic] | A3, A4, B3, C2 |
| Communicate with families | [generic] | B4, D2 |
| Support student reading | [generic] | C1, C3, D1, E2 |

## Reverse questions

Each is for the end of the panel, when they ask whether you have questions.

1. **"What does a strong first semester look like for this position?"** Why it lands: shows you are planning to deliver, not just to be hired.
2. **"What reading materials and assessments does the fourth-grade team use now?"** Why it lands: shows you are preparing for the curriculum, and gets you concrete information.
3. **"How does the grade-level team plan together: weekly, or by unit?"** Why it lands: tests fit with the team's working rhythm, which is the thing the panel can tell you.
4. **"What would a new person on this team do in their first month that would genuinely help you?"** Why it lands: a reciprocity question to peers; it turns the panel into a conversation between colleagues.
5. **"What has the principal asked the fourth-grade team to focus on this year?"** Why it lands: connects you to the school's own priorities, asked of the person who sets them.
6. **"What are the next steps and timeline after this panel?"** Why it lands: shows you are organized, and gets the process information you will need.

## Sources

- Provided: the invite and the CV block, as quoted in your message.
- Research tier: L0 — no search or fetch was run. Research was offered, not consented to, in this turn.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford Community School District values | unavailable | Values cheat sheet, section 10: not built |
| 2. Orrinsford interview process, fourth-grade teaching | unavailable | Loop structure and persona weights: priors used instead |
| 3. Orrinsford strategy / recent news | unavailable | Company-strategy questions: none included |
| 4. Dolores Vantongeren, Orrinsford | unavailable | Interviewer read and a tailored reverse question: absent |
| 5. Representative fourth-grade teacher JD | unavailable | Would turn F1 to F6 into grounded rows and fill the requirement coverage |

## Upgrade menu

- The full job posting or the district's description of the position → converts [generic] rows to [grounded] and gives the coverage table its real requirements
- Permission to run research at L1 (up to 6 searches and 2 page fetches) → the district's public values, the interview process, and a representative JD for fourth-grade teaching
- Dolores Vantongeren's public professional profile, if you want it checked → an interviewer read and a tailored reverse question
- HR's notes on focus areas, or any demonstration or written task → coverage of any deliverable they declare
- How much prep time you have before Thursday → a prioritized prep schedule
- A `tuesday-dossier.md` file, if you have one → would add verified evidence and the objections to rehearse
