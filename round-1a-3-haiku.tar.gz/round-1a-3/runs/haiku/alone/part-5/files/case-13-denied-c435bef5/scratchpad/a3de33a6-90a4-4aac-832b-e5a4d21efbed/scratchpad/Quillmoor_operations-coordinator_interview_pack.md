# Recruiter screen prep: Operations Coordinator, Quillmoor Diagnostics

- **Role:** Operations Coordinator (hybrid, two days a week at Avonmouth, Bristol)
- **Company:** Quillmoor Diagnostics (diagnostic-test manufacturer, about 400 staff)
- **Interviewer:** Hannah Lowther, Talent Partner (recruiter)
- **Round:** 30-minute phone screen, Thursday 2pm. Hannah will call the mobile number on your application.
- **Built from:** the recruiter's LinkedIn message, the advert text, and your message.

## How to use this pack

- **Personas** describe how a question arrives: Conversational, Skeptic, Data-Driven Prober, Pressure.
- **Types** describe what is being scored: JD (the listed job and its terms), EXP (what you actually did).
- Guidance is scaffolding, not a script. Quoted sentences are your own words. Say them as written.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | high | [grounded] | none | No gap. Say the years and the job title as written. |
| F2 | "coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material shows deliveries across three depots. It does not show production schedules, and it says nothing about planning or QA. The bridge stays at the scope of that quote. Answer slot: if you coordinated a schedule that depended on production, planning or quality timing, say who and how, in your own words; if you did not, say so plainly and say how you would learn the production side. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message) | high | [grounded] | none | No gap on chasing. Tracking is not in the quote: if asked how you tracked deliveries, say how, in your own words. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet" and "discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | The quote reaches the requirement. The figure is about a third and it raises the defend-the-number questions (C1). |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show dispatch reporting. Answer slot: if you reported how often orders or deliveries went out on time, say what you reported and how often; if you did not, say so plainly. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | A spreadsheet rebuild shows Excel use, not the level the advert asks for. The bridge stops there. Answer slot: say what you built, in your own words, and how you would rate your own Excel. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP" and "we run our own in-house stock system" (your message) | none | [grounded] | capability | Your words: "I haven't used SAP." Then what you do run: "we run our own in-house stock system." How you would learn SAP is a plan, not a past. |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | No gap. Say it as written. |

Salary and reason for leaving are not fit rows. They are the call's logistics, covered in A3 and A6.

## Prohibited claims

Not coached in any cell of this pack. Each entry gives its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules | Inflated form of F2 | "I schedule deliveries for our three depots." The pack's own observation: your material shows deliveries, not production scheduling. |
| Advanced Excel | Inflated form of F6 | The spreadsheet rebuild, at its own scope. No level is stated. |
| Reported on-time dispatch | Inflated form of F5 | Nothing given. F5's answer slot only. |
| Has ERP or SAP experience | Negative you stated, F7 | "I haven't used SAP." No slot. |
| Cut discrepancies by a third | Inflated form of F4 | "discrepancies fell by about a third over a year." Whether that was your doing is yours to say. |

## Persona table

Relationship prior for a recruiter screen: Conversational plus light Skeptic. The call is mostly logistics, so the four logistics rows (A3 to A6) sit in the Conversational bank as the recruiter's agenda, not as a persona weight.

| Persona | Weight | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Conversational / rapport | 4 | An opener, then pay, notice, hybrid and reason for leaving asked casually | Certain: these are the call's named agenda | Say your figures and reasons as written, and keep each answer short |
| Skeptic | 3 | Probes on production scheduling, dispatch reporting and ERP | High: the advert lists these and your material is silent or thin on them | Rehearse the production-scheduling gap (B1) until the answer is plain |
| Data-Driven Prober | 2 | One figure, the discrepancy fall, and Excel | Medium: the figure is a magnet for a follow-up | Name how the figure was counted, or say you do not know |
| Pressure | 1 | "Why us over someone who's used SAP?" | Low to medium: a recruiter screen rarely presses hard | Hold what you stated, concede the ERP gap by name, and stop |

## Question banks

Question types: JD, EXP. No CASE or VAL questions fit a recruiter screen; none are included.

### Conversational and logistics (weight 4, plus the recruiter's agenda)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip." | About 90 seconds in three beats: four years as a logistics coordinator at a building-supplies wholesaler; you schedule deliveries for three depots; you chase suppliers when orders slip. Say each beat in your own words and add nothing. | The likeliest opener. F1 and F3 are the whole story the material tells. |
| A2 | "How do you handle an order that's running late?" | JD | [grounded] "chase suppliers when orders slip" | You chase the supplier when an order slips, in those words. Answer slot: if you tracked deliveries in a particular way, name the method you actually used. | Covers the advert's "track supplier deliveries and chase late orders" (F3). |
| A3 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." | Say "I'm hoping for £42,000." Stop there. If you would rather hear the range first, you can ask what the advertised band is for the role; the advert says £38,000–£44,000. | Pay is a logistics slot. Your figure needs no defence and raises no further question. |
| A4 | "What's your notice period?" | JD | [grounded] the recruiter's own message names notice period. Your material does not state one. | Instruction: give your actual notice period, in your own words. The pack holds no figure for it. | A logistics slot the recruiter named. Only you can fill it. |
| A5 | "How do you feel about the hybrid pattern, two days a week at Avonmouth?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Say it as written. If asked about the commute, your own words were: "I live in north Bristol, so two days at Avonmouth is fine." Add no commute detail. | Hybrid is one of the recruiter's named topics (F8). |
| A6 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say it in those words: the office closes next year, the only offer is relocating to Reading, and you don't want that. Add no second reason; the pack holds none. | The reason for leaving is a logistics slot, answered with the fact you stated and nothing more. |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background is scheduling deliveries across three depots. This role coordinates production schedules between planning, the warehouse and QA. How does the first carry over to the second?" | JD | [grounded] "I schedule deliveries for our three depots"; the advert's "coordinate production schedules between planning, the warehouse and QA" | Start from your quote: you schedule deliveries for three depots. Answer slot: if you coordinated a schedule that depended on production, planning or quality timing, say who and how, in your own words; if you did not, say so plainly, and say how you would learn the production side. Hold through two follow-ups by returning to the deliveries quote. | **Highest-ROI prep in this pack.** It is the role's core and the largest gap (F2). The objection will come in some form. |
| B2 | "The role reports weekly on on-time dispatch. Have you reported on that?" | JD | [grounded] the advert's "report weekly on on-time dispatch" | Answer slot: if you reported how often orders or deliveries went out on time, say what you reported and how often; if you did not, say so plainly. | F5 has no evidence in your material, and the advert names the task. |
| B3 | "The role lists SAP or similar as a plus. What's your ERP experience?" | JD | [grounded] "Never used SAP"; "we run our own in-house stock system." | Say "I haven't used SAP." Then say "we run our own in-house stock system." Then how you would learn SAP, as a plan. | F7 is a gap you stated. The plain acknowledgment needs no slot. |

### Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "discrepancies fell by about a third over a year"; "I rebuilt our stock-count spreadsheet" | Answer slot: say how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, all in your own words. If you cannot say how it was counted, say that plainly. | The one headline figure. F4 is where a prober goes first. |
| C2 | "What did you build in the spreadsheet, and how confident are you with Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet"; the advert's "confident with Excel" | Say what you rebuilt, in your own words. Answer slot: name the Excel features you used and rate your own confidence honestly. | The advert asks for Excel confidence. F6 is low, so the rating is yours to give. |

### Pressure (weight 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Why should we look at you over someone who's used SAP?" | JD | [grounded] "Never used SAP"; "I schedule deliveries for our three depots"; the advert's "ERP experience (SAP or similar) a plus" | Hold: restate the question, then answer with what you stated, deliveries for three depots and the stock-count rebuild. Concede the ERP gap by name: "I haven't used SAP." Hold through two follow-ups; do not fold the rest of the answer to restore harmony. | Pressure tests composure. The ERP point is the one place to concede, and only that point. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who would I work with day to day across planning, the warehouse and QA?" | Shows you have read the scope and want the real seams, not the summary. |
| R2 | "What does the weekly on-time dispatch report look like now, and who reads it?" | Tests the reporting expectation the advert names. |
| R3 | "Is the team's stock system SAP, and what training is there for someone coming from an in-house system?" | Shows you have thought about the ERP gap before the interviewer raises it. |
| R4 | "Which two days would be the Avonmouth days, and how is that set?" | Shows you have thought about the hybrid pattern without adding a commute story. |
| R5 | "What happens after this call, and roughly when?" | Keeps the process moving and gives you a date to plan around. |

## Requirement coverage

| Requirement (advert) | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1 |
| Coordinate production schedules between planning, the warehouse and QA | B1 |
| Track supplier deliveries and chase late orders | A2 |
| Keep stock records accurate | C1 |
| Report weekly on on-time dispatch | B2 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B3, D1 |
| Hybrid, two days a week at Avonmouth | A5 |
| Salary band £38,000–£44,000 | A3 |

Pack length is shorter than the usual session norm of 18 to 26 questions. That is deliberate: a 30-minute logistics call has about 12 questions' worth of time, and every bank above maps to a requirement or to the recruiter's named topics.

## Sources

- **Provided documents:** the recruiter's LinkedIn message, the advert text, and your message.
- **Research tier:** L0. No searches or fetches were sent for this pack.
- **Target accounting:**

| Target | Status | What it would have moved |
|---|---|---|
| 1. Quillmoor values | unavailable | Nothing in this call: the values section is off, since this is not a values-style round. |
| 2. Quillmoor interview process | unavailable | Round structure. A recruiter screen is a single call, so little would change. |
| 3. Quillmoor strategy / recent news | unavailable | A short "why here" grounding brief. The recruiter may lead there under "team and next steps". |
| 4. Hannah Lowther public footprint | unavailable | A recruiter read. Low value for a logistics call. |
| 5. Representative Operations Coordinator JD | skipped | The advert you supplied already fixes the fit snapshot. |

## Upgrade menu

- **Your notice period** → A4 gets your own figure in place of the instruction, so the call's first logistics answer is rehearsed as stated.
- **Quillmoor's public profile and recent news (L1 research)** → a short "why here" brief, for the "team and next steps" part of the call.
- **The recruiter's prep email, if one arrives** → confirms whether any extra stage or deliverable applies.
- **`tuesday-dossier.md`** → would carry the gaps this prep exposed into later sessions. Optional.
