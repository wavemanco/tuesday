Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-5-rooms-case-13-denied-dc8bc481/0883a20c-d9b3-435d-a6c7-0b5084e636cb/scratchpad/quillmoor_operations-coordinator_interview_pack.md`. It's built only from the advert, Hannah's message and your notes. I didn't run any research.

The pack covers the four things Hannah said she'll ask about (pay, notice, hybrid, reason for leaving), each with your own words quoted back to you. Its main points:

- **Pay:** say "I'm hoping for £42,000" once, then stop. Your figure sits inside the advert's £38,000–£44,000 band.
- **Notice period:** your material has no figure, so this is an answer slot. Give your actual notice period.
- **Hybrid:** your own sentence covers it: two days at Avonmouth is fine, but not more than three.
- **Reason for leaving:** say it as you wrote it. It's a fact about the office closing, so it needs no framing.
- **Highest-priority prep (SAP):** hold with "I haven't used SAP," then say how you'd learn it, as a plan. Don't describe an ERP you haven't used.
- **Gaps the advert asks for that your notes don't show:** production scheduling across planning, the warehouse and QA; weekly on-time dispatch reporting; and naming the Excel tools you used. Each has an answer slot. Say which applies, in your own words, and say so plainly if none does.
- **Stock figure:** "discrepancies fell by about a third" will likely draw a question on how it was counted. Be ready to say what was counted and which part was yours.

The pack also has five reverse questions for Hannah, a list of what's still missing, and a note that a prep schedule would help if you tell me how much time you have before Thursday.

Would you like me to play Hannah for a practice run on the pay and notice questions? Or should I save a `tuesday-dossier.md` recording the gaps this prep exposed, so they carry into later rounds? I can also convert the pack to a Word document if you'd like one.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Quillmoor Diagnostics: Operations Coordinator, recruiter screen

**Call:** Thursday 2pm, 30 minutes by phone, with Hannah Lowther (Talent Partner). They will ring the mobile number on your application.
**Built on:** the advert, Hannah's LinkedIn message and your notes. No research was run, so the questions come from the advert and the agenda Hannah set out.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: JD (the advert's requirements), EXP (what you actually did), CASE (a live problem).
- Guidance is scaffolding, not a script. Say things in your own words, and stop when the point is made.
- Quoted sentences come from your message, the advert or Hannah's message. Nothing here is a fact about your past that you have not already told me.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | high | [grounded] | none | No gap. Say the years and the job title as you gave them. |
| F2 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | medium | [grounded] | presentation | Your sentence already covers supplier chasing and delivery scheduling. Keep the bridge in those words. Do not describe a tracking system you did not mention. |
| F3 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | none | No gap, but the one figure is a probe target (see B2). |
| F4 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | Your material does not name the tool. Answer slot: name the tools you used and what you built in them. If you are unsure of your level, say so. |
| F5 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | none | [grounded] | capability | Your words: "I haven't used SAP." Then how you would learn it, said as a plan and never as a past. |
| F6 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | low | [inferred] | transferability | Delivery scheduling across three depots is adjacent to production scheduling across three teams. Your material does not show production scheduling or working with QA. Answer slot (B3). |
| F7 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show any dispatch reporting. Answer slot (B4). |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol." (advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | Met on your stated terms. |
| F9 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000." (your message) | high | [grounded] | none | Your figure sits inside the advert's band. |

**Rules the table follows:** no paraphrase in the evidence column; each gap row's words come from what you stated, or are an answer slot.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP or another ERP | Negative you stated (F5) | "I haven't used SAP." |
| Has coordinated production schedules | Wider form of F2 and F6: your sentence says delivery scheduling for three depots | "I schedule deliveries for our three depots." Limit, in analysis: your material shows delivery scheduling, not production scheduling. |
| Is an Excel expert | Wider form of F4: your sentence names a spreadsheet, not a tool or a level | "I rebuilt our stock-count spreadsheet." The tool and level are yours to state. |

## Persona table

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Recruiter screen (Hannah) | Logistics questions on pay, notice, hybrid and reason for leaving, then a skim of the role | High: Hannah listed these four topics themselves | Say each answer once, in your own words, and stop. Do not fill silence. |
| Skeptic (later hiring-manager round) | Probes the one gap in the fit snapshot and the one figure | Moderate: this is not yet scheduled, so the weighting is a prior | Rehearse B1 and B2 until the hold is calm. |

## Question banks

### Recruiter bank (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Say your figure once, in your own words: "I'm hoping for £42,000." Then stop and let them respond. If asked for your current pay, you can decline, or ask to see the role's band first. The pack gives no other figure. | Hannah named pay first. Your figure sits inside the advert's band (F9). |
| A2 | "What's your notice period?" | JD | [grounded] Hannah's message: "your notice period" | Answer slot: give your actual notice period in your own words. The pack has no figure for it. | Hannah named it. Your material gives no figure, so the slot is yours to fill. |
| A3 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Say it as you wrote it, quoted whole. Do not add a commute method or a reason you did not give. | Hybrid is in the advert (F8). Hannah named it. |
| A4 | "What's prompting a move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say it as you wrote it, quoted whole. It is a factual reason, so it needs no framing. Do not add other reasons. | Hannah named it. Your reason is a fact about the office, not a judgment about the job. |

### Skeptic bank (weight: moderate, later round)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never used SAP. How would you get up to speed?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | **Highest-ROI prep in this pack.** Hold: "I haven't used SAP." Then say how you would learn it, as a plan. Do not describe an ERP you have not used. If pressed a second time, return to the in-house system you actually ran. | F5 is the requirement you cannot bridge. It will come up in some form, and a plain answer is better than a stretched one. |
| B2 | "Discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: say in your own words how discrepancies were counted, what the figure is sensitive to, the assumption you would defend least, and which part was yours. If you cannot say how it was counted, say so. | The one figure you gave. A figure invites a probe on how it was counted. |
| B3 | "Have you coordinated production schedules between planning, the warehouse and QA?" | JD | [grounded] "I schedule deliveries for our three depots" | Answer slot: if you coordinated any schedule across teams, say which, in your words. If you did not, say so plainly, and say what your delivery scheduling covered. | F6 is adjacent, not a match. The advert names this first. |
| B4 | "Have you produced weekly on-time dispatch reporting?" | JD | [grounded] advert: "report weekly on on-time dispatch" | Answer slot: if you produced any dispatch reporting, describe it in your own words. If you did not, say so, and say what you would measure first. | F7 has no quote in your material. |
| B5 | "How confident are you with Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Answer slot: name the tools you used and what you built in them. Give your own level. Do not claim features you did not use. | F4 is discovery: the material does not name the tool. |

**Requirement coverage**

| Requirement | Covered by | Note |
|---|---|---|
| 2+ years in operations or logistics coordination | F1, A1 | Covered |
| Track supplier deliveries and chase late orders | F2, B3 | Covered |
| Keep stock records accurate | F3, B2 | Covered |
| Confident with Excel | F4, B5 | Covered |
| ERP experience (SAP or similar) a plus | F5, B1 | Covered |
| Coordinate production schedules (planning, warehouse, QA) | F6, B3 | Covered |
| Report weekly on on-time dispatch | F7, B4 | Covered |
| Hybrid, two days a week at Avonmouth | F8, A3 | Covered |
| Pay band £38,000–£44,000 | F9, A1 | Covered |

## Reverse questions

Hannah will describe the team and next steps, so these are for after that.

1. **"What would a new person do in their first month that would help the team most?"** Why it lands: shows you are already thinking about the job.
2. **"How is on-time dispatch measured today, and who gets the weekly report?"** Why it lands: asks about the reporting duty without assuming you already know it.
3. **"Which systems do planning, the warehouse and QA use to share schedules?"** Why it lands: tests how much ERP work the job involves, from their side.
4. **"What happens after this call, and roughly when?"** Why it lands: Hannah will describe next steps, so this confirms the timing.
5. **"How is the two-day Avonmouth pattern set: by team, or by role?"** Why it lands: clarifies the hybrid terms before you rely on them.

## Sources

- Provided: the advert; Hannah Lowther's LinkedIn message; your message.
- Research tier: L0. No searches or fetches were run.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Quillmoor values | skipped | A values cheat sheet. No values-style round was detected, so the section is dropped. |
| 2. Quillmoor interview process | skipped | Loop weighting. Hannah has set out the call's agenda, which fixes the questions. |
| 3. Quillmoor strategy / recent news | skipped | Company-level questions. The call is about the role and logistics, so these are not needed. |
| 4. Hannah Lowther, public profile | skipped | Tone for one reverse question. Their agenda already sets the questions. |
| 5. Representative Operations Coordinator JD | skipped | Nothing: the advert is supplied and fixes the fit snapshot. |

## Upgrade menu

- A notice period figure in your own words → fills A2's slot.
- Hannah's public LinkedIn profile → a read of their career path and a more specific reverse question.
- Quillmoor's values page → a values cheat sheet, if the call turns to values.
- Hannah's prep email, if they send one → covers any task they set in advance.
- Prep time before Thursday → a prioritised schedule for the call.
- A tuesday-dossier.md → would carry your verified evidence and the gaps this prep exposed into later rounds.
