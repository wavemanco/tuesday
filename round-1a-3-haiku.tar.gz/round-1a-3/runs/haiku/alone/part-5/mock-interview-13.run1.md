Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-5-rooms-case-13-denied-90c8de57/1a15fc64-baf6-4c34-a865-c71a8d4110fa/scratchpad/Quillmoor_Operations_Coordinator_interview_pack.md`.

The three things to get right on Thursday:

- **The biggest gap is production scheduling.** The advert asks you to coordinate production schedules across planning, the warehouse and QA. Your material shows delivery scheduling across three depots. Don't stretch the first into the second. Be ready to say plainly where your experience stops.
- **Salary, hybrid and reason for leaving are scored.** Say them in the pack's words. "I'm hoping for £42,000" sits inside the advert's £38,000–£44,000 range. "Two days at Avonmouth is fine, but I wouldn't want more than three" is your stated limit. The closure and Reading offer are facts you stated.
- **SAP is a plus, not a requirement.** Say "I haven't used SAP. We ran our own in-house stock system," then how you'd learn it.

I did no web research on Quillmoor. The pack uses only your message and the advert. Your notice period is an open item, and the pack has an answer slot for it.

I can also draft a Word version of the pack, run a drill on any question, or save a `tuesday-dossier.md` recording the gaps this prep exposed.

Is your notice period in weeks, and is there a start-date constraint?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quillmoor_Operations_Coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** Recruiter screen, 30 minutes by phone, Thursday 2pm
**Interviewer:** Hannah Lowther, Talent Partner
**Candidate:** Sam
**Research tier:** L0 (provided documents only; no web searches or page fetches were run)

---

## 1. How to use this pack and the type key

Personas describe **how a question is asked**. Types describe **what it is scoring**. Each question carries a type tag so you can see coverage at a glance.

| Tag | Meaning |
|---|---|
| **VAL** | Values alignment: past behaviour that shows a published value |
| **EXP** | Experience deep-dive: whether your CV claims hold up and what you actually did |
| **JD** | Role fit: can you do the listed job, including its gaps |
| **CO** | Company and strategy knowledge |
| **CASE** | Live, hypothetical problem |

The guidance is scaffolding, not a script. Use your own words. Only rehearse what you actually did.

**Important for a recruiter screen:** it is scored, even though it feels like admin. Pay, notice, hybrid working, and reason for leaving are logistics checks, and the answers must match what you say later. Treat each one as scored.

---

## 2. Fit snapshot

Requirements are quoted from the advert. Evidence is quoted from your message, verbatim.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | No gap. Expect a probe on what the four years covered, so keep the scope exact. |
| F2 | "coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material shows delivery scheduling across three depots, not production scheduling across planning, warehouse and QA. Words: "I schedule deliveries for our three depots." Answer slot: if any of your scheduling touched production planning or QA, say what and how. If none did, say so and say how you would get up to speed on production planning. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message) | medium | [grounded] | none | No gap. Words: "I chase suppliers when orders slip." |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. The figure is a probe target because the counting method is not in the material. Answer slot: how discrepancies were counted and over what base. If you did not track the method, say so. |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | The material is silent. Answer slot: did you report on delivery timing on a regular basis? If yes, what and to whom. If no, say so and say what you would report first. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | A spreadsheet is not the same as Excel. Answer slot: which tools you used for the stock-count work and what they did. If you used Excel, say so in those terms. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system" (your message) | none | [grounded] | capability | This is a stated absence. Words: "I haven't used SAP. We ran our own in-house stock system." Then how you would learn it, said as a plan and never as a past. This is a plus, not a requirement, so it is lower stakes. |
| F8 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Your figure sits inside the advert's range. |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | medium | [grounded] | none | The location term is met on your own statement. Your stated limit is three days. |
| F10 | Notice period (not in advert; Hannah will ask) | none given | none | [generic] | discovery | Your notice period is not in the material. Answer slot: state it in weeks, with any start-date constraint. |

Confidence grades your evidence. Provenance grades this pack's statement about it. Gap type is a separate call.

---

## 3. Prohibited claims

These claims are not coached, and no guidance in this pack asserts, softens or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules across planning, warehouse and QA | Inflated form of F2 | "I schedule deliveries for our three depots." The limit is the material: it shows deliveries, not production. |
| Reported weekly on-time dispatch | Not in the material (F5) | Answer slot only. |
| Advanced or confident Excel skills | Not in the material (F6) | Name the tools you used and what they did. |
| Any ERP or SAP experience | Stated negative (F7) | "I haven't used SAP." |
| A stated or measured method behind the one-third figure | Not in the material (F4) | Answer slot only. Say how it was counted, or that it was not tracked. |
| A pay floor, or flexibility on pay | Not stated | Answer slot only. Decide your own position before the call. |

---

## 4. Persona weights

Relationship: recruiter screen. Relationship prior: Conversational dominant, light Skeptic (`personas.md`).

Interviewer signals: none. There is no public footprint or profile for Hannah in the material, so no interviewer read is included.

Loop: unknown. Hannah has said the call covers salary, notice, hybrid working, reason for moving, then the team and next steps. Stated topics are the logistics slots.

| Persona | Weight | Questions | Why |
|---|---|---|---|
| Conversational | Top: 5 questions | C1–C5 | Logistics checks run in a friendly register, and the risk is treating the call as unscored. |
| Skeptic | Light: 4 questions | S1–S4 | Knockout and fit checks against the advert, in a short, direct register. |

---

## 5. Question banks

### Conversational (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me a bit about your background and what you're doing now." | EXP | [grounded] "4 years as logistics coordinator at a building-supplies wholesaler" (your message) | Lead with the role and the depots, in your words: "I schedule deliveries for our three depots and chase suppliers when orders slip." Keep it to about a minute. The stock-count work can come up later. | Opening question. F1 and F3 carry the claims, so nothing beyond them is needed. |
| C2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" (your message) | "I'm hoping for £42,000." Then stop. Do not add a justification you did not make. Answer slot: if she asks whether you are flexible or have a floor, decide your position before the call and say it in your own words. | Pay is a logistics check. F8 places the figure inside the advert range. |
| C3 | "What's your notice period?" | JD | [generic] | Answer slot: state your notice period in weeks, plus any start-date constraint. No wording is supplied because the material does not state it. | Logistics check. F10 is the open item. |
| C4 | "The role is two days a week at Avonmouth. How does that work for you?" | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | "Two days at Avonmouth is fine, and I wouldn't want more than three." Then stop. Check your commute from north Bristol to Avonmouth before the call; the material does not state it. | F9 is met on your own statement. |
| C5 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | "Our Bristol office is closing next year, and the only offer is relocating to Reading, which I don't want." State it plainly and do not criticise the employer. Answer slot: what you want the next role to give you, in your own words. | The closure is a fact you stated. The forward-looking part is yours to supply. |

### Skeptic (light weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "The role coordinates production schedules across planning, the warehouse and QA. Have you done that?" | JD | [grounded] "I schedule deliveries for our three depots" (your message) | Highest-ROI prep in this pack. Hold: "I schedule deliveries for our three depots." Answer slot: if any of your scheduling touched production planning or QA, say what and how. If none did, say so plainly and say how you would get up to speed. Hold through a follow-up by returning to deliveries, not by adding to them. | F2 is the largest gap against the core of the role. |
| S2 | "The role reports weekly on on-time dispatch. Have you done that?" | JD | [grounded] "report weekly on on-time dispatch" (advert) | Answer slot: if you reported on delivery timing regularly, say what and to whom. If not, say so and say what you would report first. | F5 is a discovery gap: the material is silent. |
| S3 | "How did the discrepancies fall by a third? How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." Answer slot: how discrepancies were counted and over what base, in your own words. If you did not track the method, say so. Never offer a larger figure. | F4 is medium confidence and probes are likely. |
| S4 | "Do you have SAP experience?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" (your message) | "I haven't used SAP. We ran our own in-house stock system." Then how you would learn it, as a plan. | F7 is a stated absence, and SAP is a plus. |

Excel (F6) is not a separate question in this pack. If it comes up, use the answer slot in F6.

---

## 6. Reverse questions for Hannah

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would the first three months look like for this role?" | Shows you are thinking about the work, not only the pay. |
| R2 | "Where do late orders usually get stuck between planning, the warehouse and QA?" | Connects to the advert's line about chasing late orders and invites her to describe the real problem. |
| R3 | "Which stock system does the Avonmouth site use day to day, and how much SAP work would the coordinator do?" | Checks the SAP question directly, in a way that gives you her answer without a test. |
| R4 | "Which two days would the team expect in the office?" | Confirms the hybrid pattern you stated. |
| R5 | "What does the next step look like, and roughly when?" | Covers next steps, which she said she would describe after the team. |

---

## 7. Sources

| Target | Tier | Status |
|---|---|---|
| Provided documents: the advert and your message | L0 | Used |
| Quillmoor public site and values | L1 | Not run (L0 only) |
| Interviewer public footprint | L1 | Not run; no name-based profile was requested |

---

## Upgrade menu

- Your notice period → fills the answer slot in C3 and the start-date line
- Quillmoor's published values (L1 research, public site) → a values cheat sheet, plus a company-strategy question
- Your method for the one-third figure → upgrades the S3 answer from a slot to a worked answer
- Any ERP-type system beyond the in-house stock system → upgrades the F7 bridge
- Hannah's public profile → a tailored reverse question and persona weights
- A `tuesday-dossier.md` would record the gaps this prep exposed and carry them forward, with the prohibited claims it holds
