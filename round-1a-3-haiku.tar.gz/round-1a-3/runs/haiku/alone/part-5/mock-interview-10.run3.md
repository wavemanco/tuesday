This invite has some red flags, so I'll load the interview-prep skill, which includes guidance on suspicious invitations.
The skill's rules come first. This invite has a warning sign: the whole hiring process runs in chat, with the offer and onboarding there too. So the message must open with a warning. I'll read the reference files the skill requires before drafting.
Before the prep, one thing in the invite. It says "Our hiring process is fully remote and is carried out entirely on Telegram", and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly through chat is a known scam pattern, and a chat alone does not show who you are dealing with. Until you know who sent it, don't send money, documents or bank details here. To check, use contact details from Lumenvale's own website or careers page, not anything in this chat, and you could also ask job-underwriter to check the invite as a separate request. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-5-rooms-case-10-denied-199c1c04/ac23acc2-917d-4c64-b089-2b3ea94c41c0/scratchpad/lumenvale_customer-support-specialist_interview_pack.md`. It's built for a team-lead chat, with a skeptic-heavy persona weighting, since your CV is energy support and this is a software team. The highest-ROI prep is A1, "You haven't worked for a software company. What makes you right for a support team at one?"

Say the word and I'll play the Skeptic on A1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Is the support team lead likely to be your manager, and does the chat include a timed or written exercise?
2. Could you paste the full text of the job ad? The requirement quotes would then come from the ad itself rather than your summary.
3. Does the ad state anything beyond the four requirements you listed, such as location, working hours or right-to-work terms?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

- **Role:** Customer Support Specialist (remote)
- **Company:** Lumenvale Software
- **Interviewer:** support team lead (name not given)
- **Round:** text chat with the support team lead, as the invite describes it

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** values, **EXP** your experience, **JD** the job's stated requirements, **CO** company knowledge, **CASE** a live problem.
- Guidance is scaffolding, not a script. Say it in your own words, and only what you actually did.

## Fit snapshot

Requirements are quoted from your message, where you summarised the ad. Your evidence is quoted from the same message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your message) | "3 years as a customer service advisor at an energy supplier" (your message) | high | [grounded] | none | "I have 3 years as a customer service advisor at an energy supplier." The role is energy, not software, so expect the probe in A1. |
| F2 | "Zendesk or a similar ticketing tool" (your message) | "I use Freshdesk every day" (your message) | high | [grounded] | presentation | "I use Freshdesk every day." Freshdesk is a ticketing tool, but Zendesk is not in your material. Answer slot in A4. |
| F3 | "clear written communication" (your message) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | transferability | "I answer around 60 calls and emails a day." Volume is adjacent to clarity, not proof of it. Answer slot: if any of those replies were checked or praised for clarity, say which; if not, say so and show a sample reply in the chat. |
| F4 | "confidence handling escalations" (your message) | none given | none | [grounded] | discovery | Your material does not show escalation handling. Answer slot: if you have handled an escalation, say what it was, who you passed it to and what happened; if you have not, say so plainly and say how you would approach one. |

The requirement "2+ years in customer support" is met on duration. The rest of the snapshot is what the pack has to work with: F2 is a presentation match, and F4 is a gap the material is silent on.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I have used Zendesk" | Inflated form of F2. Your quote names Freshdesk; the ad names Zendesk. | "I use Freshdesk every day." Zendesk is the answer slot in A4. |
| "I have run the refunds process" | Inflated form of your training sentence, which says you trained four starters on it. | "I trained four new starters on our refunds process last year." |
| "I have worked in software support" | Sourced entry: your own negative. | "I've never worked for a software company." A plain acknowledgment; no slot is needed. |

Escalation experience is not on this list. Your material is silent on it, so it is an answer slot (A2), not a claim the pack must refuse.

## Persona table

| Persona | How it shows up | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Probes the software gap and the escalations requirement; "why should we trust you" | 5 (top) | A team-lead interview is hiring-manager-shaped, and your CV has a visible gap (software, Zendesk). | Rehearse A1 until it is plain. Hold the transfer point; concede the product learning curve. |
| Case / Strategist | Live support cases: a double charge, a bug affecting a group, a contradicted answer | 3 | The ad is about live handling, and the chat format suits case questions. | Clarify first, then triage, then say what you check before you promise anything. |
| Pressure | "Sixty seconds" stems; "how much of that was you" | 3 | Time-boxed challenges are common with team leads filling a hire, and they test composure in writing too. | Pause, restate, hold through two follow-ups, then concede specifically. |
| Conversational | Casual opener and "what do you actually use" | 2 | Chat interviews open informally; casual questions are still scored. | A 90-second arc from quoted sentences only. |
| Prober | Asks how the 60 a day was counted | 2 | Your one headline figure is a magnet for a defend-the-number probe. | Say the figure, the method if you have one, and the assumption you would defend least. |
| Peer | none | 0 | The interviewer is a team lead, not a peer. | none |

Values / Behavioral is not a separate persona here: no company values are in hand, so the values sheet is dropped. Behavioral-style open prompts sit inside the Skeptic bank (A2).

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't worked for a software company. What makes you right for a support team at one?" | JD | [grounded] "I've never worked for a software company" (your message); [grounded] "3 years as a customer service advisor at an energy supplier" (your message) | Start with the sentence as you said it: "I've never worked for a software company." Then name the part of your support work that carries over, in your own words. Say what you'd need to learn about the product, as a plan. Hold the transfer point through two follow-ups; concede the product learning curve specifically. Answer slot: if you have supported users of any software or online service, say how; if not, say so plainly. | This is the highest-ROI prep in the pack. It is the most predictable objection for a team-lead interviewer, because your CV is energy and this is a software team. F1 is the evidence for the experience requirement; the software negative is yours to state. |
| A2 | "Tell me about a time you had to escalate a customer issue. What did you do?" | JD | [grounded] "confidence handling escalations" (your message); [grounded] "I trained four new starters on our refunds process last year" (your message) | Open prompt. Pick a case where the issue was beyond what you could settle at your level: what you checked, who you passed it to, and how the customer was kept informed. If no escalation comes to mind, say so plainly, then give the nearest thing your material carries, the refunds process you trained four starters on, or how you would handle one now. | F4 is the gap the material is silent on. The question is the ad's own line, asked as an open prompt so you choose the instance. |
| A3 | "Show me you can write clearly. Reply to a customer whose refund is three days late." | CASE | [generic] | Three beats: a one-line acknowledgment, what you have checked, and what happens next with a date. Keep it short enough to read in a chat window. Makes no claim about your past. | This tests clear written communication live, in the same channel the interview uses. It is generic because it is a pattern for the problem, and F3 is the thin evidence behind the requirement. |
| A4 | "Have you used Zendesk, or a tool like it other than Freshdesk?" | JD | [grounded] "I use Freshdesk every day" (your message) | Answer slot: if you have used Zendesk, say where and how; if not, say so plainly, then name what you use daily (Freshdesk) and how you pick up a new tool. Do not describe Zendesk features you have not used. | The ad names Zendesk; F2 covers Freshdesk only. The question asks about the ad's own tool and presumes nothing about your history. |
| A5 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" (your message) | Name the one part your material shows least of, in plain words. Then say how you would ramp up in the first weeks, as a plan. Do not widen it beyond that one part. | An honest self-assessment question. The software negative is your own sentence, so you can state it plainly. |

### B. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer says they were charged twice. What is your first reply, and what do you check before you promise a refund?" | CASE | [grounded] "I trained four new starters on our refunds process last year" (your message) | Clarify first: which account, which charge, what the record shows. Then say what you would check before any promise. Name the refunds steps you taught only if they are the ones you would use here; if this case differs, say how. | A refund case is likely given the ad's support role and your refund training. The question presumes no event; the training sentence is the only past claim in the guidance. |
| B2 | "A bug is breaking the same feature for a whole group of customers, and tickets are piling up. What do you do in the first hour?" | CASE | [generic] | Separate triage from the fix. Confirm the scope, tell customers what you know, and route the issue with a clear summary. Say what you would need from the engineering team and when you would update customers. Makes no claim about any bug you have handled. | Tests triage and escalation judgement from the ad's escalations line, asked as a live problem, so it presumes no past. |
| B3 | "Write the escalation you would send to the product team about that bug." | JD | [generic] | Structure: what happens, who is affected, how often, what you have tried, and what you need from them. Keep it factual and free of blame. Answer slot: if you have written an escalation before, describe the one you would point to; if not, say how you would write one. | Tests writing and escalation together, in the chat format. The slot asks only for a method if you have no example. |
| B4 | "A customer says another agent told them something different. How do you handle it?" | CASE | [generic] | Acknowledge, check what was said and recorded, do not blame the other agent, give the correct position, and say how you will confirm it. Makes no claim about a case you have handled. | A live problem on consistency and written clarity, asked without presuming any past event. |

### C. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why should we hire you over someone with Zendesk and software support experience?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); [grounded] "answering around 60 calls and emails a day" (your message) | Pause, then restate the question. Hold: the support work you did is real and is the same kind of work, three years and around 60 contacts a day. Hold through two follow-ups. Concede what the other candidate may bring, the tool and product knowledge. Do not claim to be better. | The question compares you with a rival's background, which is a pressure move. The hold rests on what you did; concede the gap, do not invent a strength. |
| C2 | "That 60 a day: how much of it was actually you, and how much was passed on?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Hold: say what "answering" covered, in your own words. If some contacts were shared or passed on, concede that and say how. Answer slot: if you handled some and passed others on, say which and why. Do not add resolution rates or times you have not stated. | Premised on your own sentence, with "answering" kept at its scope. The second follow-up is where a hold breaks if the answer claims more than you did. |
| C3 | "Sixty seconds: why this role, when your background is energy?" | EXP | [grounded] "I've never worked for a software company" (your message); [grounded] "I trained four new starters on our refunds process last year" (your message) | Hold on your reason for the move, in your own words. The material does not state a reason, so the pack does not supply one. If the training bears on the move, say how. Do not claim software experience. | Motivation consistency under time pressure. The reason for the move is not in your material, so the guidance leaves it to you. |

### D. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey from energy to here." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); [grounded] "I use Freshdesk every day" (your message) | A 90-second arc: the 3 years, the tool you use daily, the refunds training, and the step you are taking now. Give your own reason for the move in your own words. Add no milestone you have not stated. | Casual openers are still scored, and this is likely the chat's first question. The arc uses only the quoted sentences and your own reason. |
| D2 | "What are you actually using in Freshdesk these days?" | JD | [grounded] "I use Freshdesk every day" (your message) | Answer slot: name the parts of Freshdesk you use, in your own words, and leave out any you have not used. If you are unsure of a feature's name, say so. | The register is casual, but the question scores the ad's ticketing requirement. Name only what you actually use. |
| D3 | "What do you enjoy most about support work?" | JD | [generic] | Give one or two honest sentences about one part of the work you have actually done and enjoyed. Avoid a generic answer. | A rapport question that also reveals motivation. The guidance makes no claim about your past. |

### E. Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through how that 60 a day was counted." | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Defend the number: say "around 60," then how you know it (your own estimate, a system count, or a rough check). Name the assumption you would defend least. Say which part was yours. If you did not count it, say so. | Your one headline figure draws this probe. The guidance asks for your method, not one supplied for you. |
| E2 | "What did the refunds training cover?" | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Open with the training's scope in your own words. Keep to what you taught. If the content was set by someone else, say so. | A probe on a training claim. The guidance does not supply what the training covered. |
| E3 | "How would you measure whether a support reply was good?" | JD | [generic] | Give one measure and its weakest assumption, for example whether the customer contacts again. Say how you would check it. Make no claim about what you have measured. | Tests the analytic habit this persona scores. The ad names no metrics, so the question is generic and the guidance makes no claim about your past. |

### Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| 2+ years in customer support | A1, C1, D1 | |
| Zendesk or a similar ticketing tool | A4, D2 | |
| Clear written communication | A3, B3, B4 | |
| Confidence handling escalations | A2, B2, B3, A5 | |

## Reverse questions

1. **"What does a normal shift look like, in contacts across chat, email and phone?"** Why it lands: it shows you are thinking about volume, which matches your 60-a-day background.
2. **"When an issue is escalated, who owns it after it leaves support?"** Why it lands: it tests the escalations requirement from the other side.
3. **"Which tools does the team use day to day, and how much of the work sits in each?"** Why it lands: it tells you whether Zendesk or a similar tool is the whole job, before you answer on Freshdesk.
4. **"What does the first month look like for someone new on the team?"** Why it lands: it shows you are planning for ramp-up, which the ad's requirements imply.
5. **"Is there a live call or video stage after this chat, or is the process all written?"** Why it lands: you need the process for prep, and it asks about the process only.
6. **"What did the last person in this role find hardest?"** Why it lands: it lets you name the hard parts and shows you have thought about them.

## Sources

- **Provided:** your message, which contains the ad as you summarised it, your background, and the invite text.
- **Research tier: L0.** No searches or fetches were run for this pack. The company values, interview loop and current strategy are therefore not in it.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | Values sheet dropped. Not run in this turn. |
| 2. Lumenvale interview process, customer support | unavailable | Loop structure. Persona weights are round-type priors. Not run in this turn. |
| 3. Lumenvale strategy / recent news | unavailable | Current framing for CO questions; none written. Not run in this turn. |
| 4. Interviewer name + company | n/a | No name was given, so there was no query to form. |
| 5. Representative Customer Support Specialist JD | skipped | The ad as summarised in your message already fixes the fit snapshot. |

## Upgrade menu

- The full ad text → the four requirement rows quote the ad itself rather than your summary, and their `[grounded]` labels get stronger.
- Company research at the default depth (values, interview process, strategy) → a values sheet, a CO question, and persona weights matched to the real process. Say yes and I will run it.
- The support team lead's name → a tailored reverse question and interviewer-specific weights, drawn only from a public professional profile.
- The round's format (length of the chat, any written exercise) → weights for A3 and B3, and timing advice.
- `tuesday-dossier.md`, if you have one → verified evidence and a sharper objection in place of the inferred ones.
