I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

The invite asks you to "please transfer the €95 equipment registration fee to our supplier's account" before your slot is confirmed, to "reply with a photo of your passport and your bank details before the interview", and to deposit a cheque and "send the balance on to the vendor". Requests like these, a fee before an interview, passport and bank details before any offer, and a cheque you deposit and then pay back, are very likely a scam pattern. Hold all three: don't pay, don't send documents or bank details, and don't deposit any cheque until the company has been checked. Check it through a phone number or website you find yourself, not the details in the email. If you want the invite checked for you, job-underwriter can do that as a separate request.

Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a3-runs-haiku-alone-part-5-rooms-case-12-denied-278cd646/86bf2ec2-7305-430c-8c7b-8bf5b013c520/scratchpad/Brennock_remote-admin-assistant_interview_pack.md`. The contents are below. The prep is useful for any real interview for this role, including one you find elsewhere.

# Interview prep pack: Remote Administrative Assistant

**Company:** Brennock Facilities Ltd (as named in the invite; not verified)
**Interviewer:** office manager (name not given)
**Format:** 30-minute video call
**Built from:** your message only. No searches or page fetches were run, so there is no company values, strategy or vocabulary section.

## How to use

Personas describe how a question is asked. Types describe what is being scored: **VAL** (behavioural/values), **EXP** (work-experience deep-dive), **JD** (role-driven), **CO** (company knowledge), **CASE** (live problem). The guidance is scaffolding, not a script. Say only what you did.

## Prep triage

1. Rehearse **B1** and **A1** out loud. These are the two you're most likely to be asked to expand on.
2. Rehearse the honest answer slots **A2** and **C2**, the gaps the interviewer is most likely to probe.
3. Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (your message) | "ran the appointment book for four physios" (your message) | medium | [grounded] | transferability | Your material shows a shared appointment book for four clinicians, not executive diaries. Say that scope plainly. Answer slot: name one scheduling clash you resolved and how. |
| F2 | "booking travel" (your message) | none given | none | [grounded] | discovery | Nothing in your material shows travel booking. Answer slot: say whether you've booked travel for yourself or anyone else. If not, say so and describe how you'd learn the supplier portal. |
| F3 | "preparing documents in Word" (your message) | "good with Word" (your message) | medium | [grounded] | presentation | Your quote reaches Word document work in your own terms. Name one document you've formatted or produced. |
| F4 | "preparing documents in ... Excel" (your message) | "okay with Excel" (your message) | low | [grounded] | discovery | "Okay" is a self-rating and shows no task. Answer slot: name the most complex thing you've done in Excel, or say you're comfortable with basics and would ask for help with the rest. |
| F5 | "processing supplier invoices" (your message) | "chased unpaid invoices" (your message) | low | [grounded] | transferability | Chasing unpaid invoices is the collections side of the same ledger. It doesn't show processing supplier invoices. Answer slot: have you ever recorded or matched a supplier invoice? |

## Prohibited claims

- **Managing executive calendars, or booking travel for others.** Basis: F1, F2. Honest form: "I ran an appointment book for four clinicians. I haven't booked travel, and here's how I'd learn it."
- **Processing supplier invoices or running accounts payable.** Basis: F5. Honest form: "I chased unpaid invoices, which is the other side of the ledger. I haven't processed supplier invoices, but I'd check the record-keeping first."
- **Advanced Excel.** Basis: F4, your own words "okay with Excel". Honest form: "I'm comfortable with basics, and I'd tell you where I'd need help."

## Question banks

Persona weights, from the round type you gave: **Skeptic** (primary, because the CV gaps are visible), **Conversational / Rapport** (a 30-minute first call), **Case / Strategist** (a small admin scenario).

**Skeptic**

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | EXP, JD | "Tell me about the appointment book. How much of that was actually you?" | [grounded]: "ran the appointment book for four physios" (your message) | Describe what you did with the book: the rules you applied, how you handled clashes, what you decided and what you didn't. Stay at the scope of four physios. | The most likely probe, and your strongest transferable evidence. The task is shrinking the claim to what you did. |
| A2 | JD | "You haven't booked travel before. How would you handle it?" | [generic] (answer slot) | If you've booked anything, say what. If not, say so, then give your first three steps: the supplier portal, the approval, the confirmation. | The discovery gap in F2. An honest plan beats a bluff. |
| A3 | JD | "Your experience is on the chasing side of invoices. Have you processed supplier invoices?" | [grounded]: "chased unpaid invoices" (your message) | Say what you did: chased unpaid invoices. Then say whether you've recorded or matched supplier invoices. If not, say what you'd check first. | The transferability gap in F5. Expect them to test whether you can tell the two sides apart. |

**Conversational / Rapport**

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| B1 | EXP | "So, walk me through your background." | [grounded]: "two years as a receptionist at a physiotherapy clinic" (your message) | A 90-second arc: the role, the four physios, the appointment book, the invoice chasing, and why this kind of role now. | Openers are scored, even when casual. |
| B2 | JD | "What would you enjoy most about this kind of work?" | [generic] (answer slot) | One sentence in your own reason, picking something the job actually contains: calendars, documents, running an office. | Shows whether you read the ad. |

**Case / Strategist**

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | CASE, JD | "A manager asks you to book a trip into a full diary, by end of day. Walk me through your first three steps." | [generic] (scenario) | Clarify dates, budget and approval first. Check the diary for clashes. Book, confirm, and record it where the manager can see it. | Scores structure and clarifying questions more than the answer. |
| C2 | JD | "How comfortable are you building a spreadsheet from scratch, for example a supplier invoice log?" | [grounded]: "okay with Excel" (your message) | Say what you can do now and name what you'd look up. Don't call the spreadsheet advanced. | The Excel gap in F4, asked as a live task. |
| C3 | JD | "Show me how you'd format a three-page document for a client." | [grounded]: "good with Word" (your message) | Walk through the Word steps: styles, headings, contents page. Name one document you've produced. | Tests the F3 claim against a concrete task. |

## Reverse questions

1. **"What does a typical week look like for whoever holds this role?"** Why it lands: it shows you're planning for the workload.
2. **"Which of the four areas, calendars, travel, documents or invoices, takes the most time?"** Why it lands: it shows you're thinking about priorities.
3. **"What systems do you use for the diary and for invoices?"** Why it lands: it shows you'd check the tools before starting.
4. **"How is the role supported in the first month?"** Why it lands: it shows you expect to learn on the job and want a plan for it.
5. **"What would a good first six months look like?"** Why it lands: it gives you a clear target.

## Upgrade menu

- **The full ad text** → the requirements become quoted rather than paraphrased, and the gap rows sharpen.
- **Anything from the company's own website** → a short vocabulary section, so you sound current.
- **The interviewer's name and role**, once the company is confirmed through contact details you find → a tailored reverse question and adjusted persona weights.
- **Process details from the employer** (length, format, next steps) → a firmer interview structure.

---

If you'd like a live rehearsal, I can play the Skeptic on A1 and give feedback against its guidance. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. Say the word and I'll also convert the pack to Word.

Can you paste the full text of the ad? Quoted requirements would replace my paraphrases in the fit snapshot, and it would make the gap rows more exact.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock_remote-admin-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant

**Company:** Brennock Facilities Ltd (as named in the invite; not verified)
**Interviewer:** office manager (name not given)
**Format:** 30-minute video call
**Built from:** your message only. Research tier L0: no searches or page fetches were run, so there is no company values, strategy or vocabulary section.

## How to use

Personas describe how a question is asked. Types describe what is being scored:

- **VAL**: behavioural / values alignment
- **EXP**: work-experience deep-dive
- **JD**: role and job-description driven
- **CO**: company and strategy knowledge
- **CASE**: hypothetical or live problem

The guidance is scaffolding, not a script. Say only what you did.

## Prep triage

Time available wasn't stated, so this is a default order:

1. Rehearse **B1** and **A1** out loud. These are the two you are most likely to be asked to expand on.
2. Rehearse the honest answer slots **A2** and **C2**. These are the gaps the interviewer is most likely to probe.
3. Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (your message) | "ran the appointment book for four physios" (your message) | medium | [grounded] | transferability | Your material shows a shared appointment book for four clinicians, not executive diaries. Say that scope plainly: "I ran the appointment book for four physios." Answer slot: name one scheduling clash you resolved and how. |
| F2 | "booking travel" (your message) | none given | none | [grounded] | discovery | Nothing in your material shows travel booking. Answer slot: say whether you have booked travel for yourself or anyone else. If not, say so and describe how you would learn the supplier portal. |
| F3 | "preparing documents in Word" (your message) | "good with Word" (your message) | medium | [grounded] | presentation | Your quote reaches Word document work in your own terms. Say it as you said it: "I'm good with Word." Name one document you have formatted or produced. |
| F4 | "preparing documents in ... Excel" (your message) | "okay with Excel" (your message) | low | [grounded] | discovery | "Okay" is your own self-rating and shows no task. Answer slot: name the most complex thing you have done in Excel, or say you are comfortable with basics and would ask for help with the rest. |
| F5 | "processing supplier invoices" (your message) | "chased unpaid invoices" (your message) | low | [grounded] | transferability | Chasing unpaid invoices is the collections side of the same ledger. It does not show processing supplier invoices. Say what you did: "I chased unpaid invoices." Answer slot: say whether you have ever recorded or matched a supplier invoice. |

## Prohibited claims

These are claims a candidate reaches for under pressure that your material does not support. This pack will not coach them.

- **Managing executive or multi-person calendars, or booking travel for others.** Basis: F1, F2. Honest form: "I ran an appointment book for four clinicians. I haven't booked travel, and here is how I would learn it."
- **Processing supplier invoices or running accounts payable.** Basis: F5. Honest form: "I chased unpaid invoices, which is the other side of the ledger. I haven't processed supplier invoices, but I would check the record-keeping first."
- **Advanced Excel.** Basis: F4 (your own words: "okay with Excel"). Honest form: "I'm comfortable with basics, and I would tell you where I'd need help."

## Question banks

Persona weights, from the relationship and round type you gave: **Skeptic** (primary, because your evidence has gaps the interviewer can see on the CV), **Conversational / Rapport** (a 30-minute first call), **Case / Strategist** (a small admin scenario).

### Skeptic

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | EXP, JD | "Tell me about the appointment book. How much of that was actually you?" | [grounded]: "ran the appointment book for four physios" (your message) | Describe what you did with the book: the rules you applied, how you handled clashes, which parts were decided by you and which were not. Stay at the scope of the four physios. | This is the most likely probe and your strongest transferable evidence. The skill here is shrinking the claim to what you did, not defending a bigger one. |
| A2 | JD | "You haven't booked travel before. How would you handle it?" | [generic] (answer slot, no quote) | If you have booked anything for yourself or others, say what. If not, say so, then describe your first three steps: the supplier portal, the approval, the confirmation. | This is the discovery gap in F2. A plain, honest answer beats a bluff. |
| A3 | JD | "Your experience is on the chasing side of invoices. Have you processed supplier invoices?" | [grounded]: "chased unpaid invoices" (your message) | Say what you did: chased unpaid invoices. Then say whether you have recorded or matched supplier invoices. If not, say so and say what you would check first. | Transferability gap in F5. The interviewer will likely test whether you can tell the two sides apart. |

### Conversational / Rapport

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| B1 | EXP | "So, walk me through your background." | [grounded]: "two years as a receptionist at a physiotherapy clinic" (your message) | A 90-second arc: the role, the four physios, the appointment book, the invoice chasing, and why you want this kind of role now. | Openers are scored, even when casual. |
| B2 | JD | "What would you enjoy most about this kind of work?" | [generic] (answer slot) | One sentence in your own reason. Pick something the job actually contains: calendars, documents, or the sense of running an office. | Shows whether you read the ad. |

### Case / Strategist

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | CASE, JD | "A manager asks you to book a trip into a full diary, by end of day. Walk me through your first three steps." | [generic] (scenario, no quote) | Clarify dates, budget and approval first. Check the diary for clashes. Book, confirm, and record it where the manager can see it. | Scores structure and clarifying questions more than the right answer. |
| C2 | JD | "How comfortable are you building a spreadsheet from scratch, for example a supplier invoice log?" | [grounded]: "okay with Excel" (your message) | Say what you can do now, and name what you would need to look up. Do not describe the spreadsheet as advanced. | Excel gap in F4, asked as a live task. |
| C3 | JD | "Show me how you would format a three-page document for a client." | [grounded]: "good with Word" (your message) | Walk through the steps you would take in Word: styles, headings, the contents page. Name one document you have produced. | Tests the presentation claim in F3 against a concrete task. |

## Reverse questions

Each one is a question for the interviewer. None asks them to check the invite.

1. **"What does a typical week look like for whoever holds this role?"** Why it lands: it shows you are planning for the workload.
2. **"Which of the four areas, calendars, travel, documents or invoices, takes the most time?"** Why it lands: it shows you are thinking about priorities.
3. **"What systems do you use for the diary and for invoices?"** Why it lands: it shows you would check the tools before you start.
4. **"How is the role supported in the first month?"** Why it lands: it shows you expect to learn on the job and want to plan for it.
5. **"What would a good first six months look like?"** Why it lands: it gives you a clear picture of the target.

## Upgrade menu

- **The full ad text** → the requirements in the fit snapshot become quoted rather than paraphrased, and the gap rows get sharper.
- **Anything from the company's own website** → a short company vocabulary section, so you sound current.
- **The interviewer's name and role** (only once the company is confirmed through contact details you find yourself) → a tailored reverse question and adjusted persona weights.
- **Any process details from the employer** (length, format, what happens next) → the interview structure in the pack gets firmer.
