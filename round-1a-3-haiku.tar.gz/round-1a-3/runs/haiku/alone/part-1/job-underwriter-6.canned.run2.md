**Worth applying to, on conditions. Status: `conditional_go`.** You have a strong case for most of this role: CRM ownership, pipeline and renewal reporting, Salesforce, and SQL. The two places it asks for more than you have are owning the forecast and working on billing data, and whether those are real parts of the job decides whether it's worth your application time.

**Fit ledger.**

- `hard_gate`: unclear: R7 (Bristol, two office days a week)
- `must_have`: direct: R1, R2, R3, R6 · adjacent: R4 (owning a forecast)
- `important`: unclear: R5 (working with finance on billing or revenue data)

R4 — a real gap with a credible bridge through your monthly pipeline review; R5 (`low`) — unknown until we know what billing work you did at the payments company.

**Opportunity ledger.** Sound on what's stated: a Series A-funded company (RR5) with concrete scope. Open questions are how much of the forecast and billing data this role owns (RR1, RR2), whether the posting is live on the company's own site (RR3), and whether the salary band fits (RR4).

- **Hard gates:** none failed; unconfirmed: R7 (Bristol, two office days a week); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) RR1: the forecast is shared with finance, with your pipeline input as your part of it; (2) RR2: you'd have billing-data access and a working partnership with finance; (3) R7 and RR4: Bristol two days a week works and the £61,500–£67,000 band clears your floor; (4) RR3: the role appears on Quillfield's own careers page.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; Bristol; 96 staff; Series A (£11M) closed April 2025 | `[grounded]` quillfield.co.uk/about |
| Mandate | Owns CRM and billing data; builds pipeline and renewal reporting that sales and finance use; runs the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Hybrid, Bristol, two office days a week; salary £61,500–£67,000 plus share options | `[grounded]` posting |
| Scope read | One role spanning CRM, billing data, pipeline, renewals and the forecast is wide. Expect the forecast and billing parts to be shared with finance | `[inferred]` from the posting's list against its single-role framing |
| Market calibration | Not run this pass, so the salary is uncalibrated | — |
| Unknowns | Whether the role prepares the forecast or owns the number; billing-data access; Tamsin Achebe's background; the share package's value | — |
| Contradictions | None found between posting and company about page. The careers page at quillfield.co.uk/careers returned no page, so the posting isn't confirmed there | `[grounded]` search and fetch |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years in RevOps, sales ops or analytics at a B2B software company | must_have | direct | high | none | Five years in sales ops, the last two running UK revenue ops. The company is B2B payments rather than software, which is close and worth saying plainly on the CV | `[grounded]` your background | none |
| R2 | HubSpot or Salesforce administration | must_have | direct | high | none | Salesforce admin certified | `[grounded]` your background | none |
| R3 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly and Excel daily are confirmed. "Modelling" isn't evidenced yet beyond daily use | `[grounded]` your background | a workbook sample, if you have one |
| R4 | Experience owning a forecast | must_have | adjacent | medium | capability | You run the monthly pipeline review with the sales director, and pipeline is a forecast input. You have never owned the company forecast; finance did | `[inferred]` adjacency from the pipeline review | see G1 |
| R5 | Working with finance on billing or revenue data | important | unclear | low | discovery | No billing work. Unknown whether you reconciled bookings or revenue with finance | `[grounded]` absence from your background | question below |
| R6 | Owning CRM data; building pipeline and renewal reporting | must_have | direct | high | none | You rebuilt the pipeline and renewal dashboards | `[grounded]` your background | none |
| R7 | Hybrid, Bristol, two office days a week | hard_gate | unclear | none | hard_gate | Your location and willingness to commute aren't given | `[grounded]` posting | question below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R4, must_have) | capability | Pipeline review; no forecast ownership | The forecast is named in the role's summary, so it's the first thing an interviewer will probe | Preparing forecast inputs, stage weighting, any forecast-vs-actual check | A pipeline-to-forecast note or workbook | `[inferred]` bridge from the pipeline review; `[generic]` that this is the likely objection |
| G2 | Billing and finance data (R5, important) | discovery | No billing work on record | Owning billing data is in the role's first sentence | Bookings or revenue reconciliation with finance, even informal | A short description of any finance touchpoint | `[grounded]` absence from background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast authority unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may prepare the forecast while the CFO owns the number | `[inferred]` from the posting's wording | Which parts of the quarterly forecast does this role own, and which stay with the CFO? | unresolved |
| RR2 | Billing data ownership unclear | unknown | — | "own our CRM and billing data" | Billing data definitions may sit with finance, with this role depending on them | `[inferred]` from the posting's wording | Who owns billing data definitions, and who signs off on revenue numbers? | unresolved |
| RR3 | Posting not confirmed on the company's site | risk_signal | low | Posting on Tallyboard Jobs; careers page returned no page | The posting may be stale, aggregated, or not current | `[generic]` pattern for job-board listings | Is this role live on your careers site, and who would I interview with? | unresolved |
| RR4 | Salary band uncalibrated | unknown | — | "£61,500–£67,000 plus share options" | The band may sit low for a role spanning forecast and billing | `[generic]`: market sweep not run | How was this band set against the role's scope, and what are the share options worth? | unresolved |
| RR5 | Company is funded and growing | positive_signal | — | "Series A (£11M) closed in April 2025" | Funding supports the hiring and the new function | `[grounded]` company about page | What does the revenue-team hiring plan look like over the next year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead the CV with the renewal and pipeline dashboards and the Salesforce certification | Matches R1, R2, R6 | `[grounded]` your background | pending your approval |
| A2 | Describe forecast experience as what it is: pipeline-review input. Don't list "forecasting" as a skill | Keeps R4 honest; an interviewer will test it | `[grounded]` R4 | pending your approval |
| A3 | Put RR1 and RR2 to the hiring manager in the first conversation, verbatim | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A4 | Confirm the role on Quillfield's own site, or through the recruiter, before investing in an application | Closes RR3 | `[grounded]` RR3 | pending your approval |

## Evidence status

Stated by you, not yet documented: R1, R2, R3, R6. No documents were provided. Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol" (quillfield.co.uk/about: Bristol, 96 staff, Series A closed April 2025) and "Quillfield Revenue Operations Lead careers" (no results). Fetched quillfield.co.uk/careers (no page). Moved: employer established; posting not confirmed on the company's site (RR3) |
| 2. Role-family sweep | skipped | Not run this pass. The salary band stays uncalibrated (RR4) |
| 3. Hiring manager's public footprint | skipped | Name given (Tamsin Achebe), not searched this pass. The upgrade menu names what it would add |

The dossier can be written up as `tuesday-dossier.md` for your interview prep, if you want it.

## Upgrade menu

- A role-family sweep for remit and salary at this seniority (up to 5 searches and 2 fetches; say the word and it runs) → calibrates RR4 and the scope read.
- Tamsin Achebe's public professional profile → the scope read, and which story to lead with for her.
- A forecast-input artifact (a pipeline-to-forecast note or workbook) → R4 moves toward `direct`.
- Any billing or finance-reconciliation example → R5 moves off `unclear`.
- The careers-page listing or the recruiter's email domain → RR3 closes.

**Questions:**

- **R4:** Have you ever prepared inputs to a revenue forecast, such as stage weighting or a forecast-vs-actual check, even if finance owned the final number?
- **R5:** Did you work with finance on bookings, invoicing or revenue reconciliation at the payments company, even informally?
- **R7:** Can you do Bristol two days a week, and is £61,500–£67,000 plus shares near your floor?

Answer any, all, or skip; I'll update the verdict from what you give.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.