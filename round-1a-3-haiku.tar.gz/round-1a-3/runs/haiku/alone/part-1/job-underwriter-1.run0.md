**Yes, apply, on conditions: `conditional_go`.** You fit the core of this role. The gaps are healthcare data (HIPAA), clinician work, and mentoring. I could not check the employer from here, because the web searches were refused.

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5, R8
- `important`: direct: R6a · unclear: R6b (clinician partnership), R7 (mentoring two junior analysts)
- `preferred`: adjacent: R9 (healthcare data experience, HIPAA)

R3 — the pricing test and 11% lift need a probe on what you owned. R6b — no clinician work described. R7 — no mentoring described. R9 — consent-state work is consumer-privacy (GDPR/CCPA), not HIPAA.

**Opportunity ledger.** Scope is defined and measurable (RR4). The employer is unverified from here (RR1), pay is not in the posting as given (RR2), and whether the warehouse holds protected health data is unknown (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify on Harborlight's own careers site (RR1); (2) the pay range works for you (RR2); (3) R6b and R7 hold up in interviews.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD as provided; not verified from here |
| Mandate | Own product analytics for a care-navigation app: metrics layer, A/B tests, Looker self-serve, PM and clinician partnership, mentoring two analysts | `[grounded]` JD |
| Scope read | Broad but coherent for a senior analytics owner | `[inferred]` from the JD's listed responsibilities |
| Market calibration | Not run. The salary search was refused, so there is no band and no number | — |
| Unknowns | Pay; whether the warehouse holds PHI; decision rights on tests; clinician involvement | — |
| Contradictions | None found within the JD as provided | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a ~2M-subscriber company, self-reported; no artifact yet | `[grounded]` intake | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake; level is self-described | `[grounded]` intake | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year plus the pricing test behind an 11% retention lift. Expect a probe on your role versus the team's and on how the lift was measured | `[grounded]` intake | ask for a sanitized test writeup (see upgrade menu) |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the company's Looker instance; 40+ governed dashboards | `[grounded]` intake | none |
| R5 | Define and maintain the metrics layer | must_have | direct | medium | presentation | Governed dashboards and the metrics memo are the evidence; the CV never says you owned metric definitions | `[grounded]` intake; `[inferred]` that governed dashboards imply metric definitions | E1 |
| R6a | Partner with PMs on roadmap decisions | important | direct | medium | none | Presents monthly to the VP Product | `[grounded]` intake | none |
| R6b | Partner with clinicians on analysis | important | unclear | low | discovery | No clinician work described | `[grounded]` intake silence | G1 |
| R7 | Mentor two junior analysts | important | unclear | low | discovery | No mentoring described | `[grounded]` intake silence | G2 |
| R8 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | Writes the monthly exec metrics memo | `[grounded]` intake | none; a sample memo would raise it |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | Consumer PII under GDPR/CCPA and a consent-state model. Limit: no healthcare data, no HIPAA | `[grounded]` intake; `[inferred]` adjacency | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Clinician partnership (R6b) | discovery | Nothing on working with clinicians or care teams | The JD names clinicians as partners; this is a visible gap | Defining a metric with an ops or care team; a launch decision shaped by a non-PM stakeholder | A short analysis brief or a stakeholder readout | `[grounded]` intake silence |
| G2 | Mentoring analysts (R7) | discovery | Nothing on mentoring or managing analysts | The JD asks for mentoring two juniors | Onboarding or reviewing analysts' SQL; owning a team's review process | Team or onboarding plan, if any | `[grounded]` intake silence |
| G3 | Regulated health data (R9) | transferability | Consumer privacy work, no health data | Preferred, but the JD asks for it by name | Any work under a contract or rule beyond GDPR/CCPA, including vendor or partner work on clinical data | A data-access policy or consent model doc | `[grounded]` intake; `[generic]` that health-data roles probe this line |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | Not checked: the search was refused, so nothing confirmed or contradicted the employer. The posting could be stale, the company could be too new to have a footprint, or the posting could be aggregated | `[generic]` pattern for companies of this size, not a claim about this one | Where is this role on your own careers site, and who would I interview with? | unresolved |
| RR2 | Pay not in the posting as provided | unknown | — | (no pay line in the JD text) | The range may be published elsewhere, or withheld | `[inferred]` from the JD text as provided | What is the base range for this role? | unresolved |
| RR3 | Data scope unknown | unknown | — | "care-navigation app" | The warehouse may hold protected health information, which changes access and consent work | `[inferred]` from product category against the JD's silence on data | Does the analytics warehouse hold protected health information, and who approves access? | unresolved |
| RR4 | Scope and ownership stated | positive_signal | — | "Own product analytics… define and maintain the metrics layer" | The role is defined and measurable | `[grounded]` JD | Which roadmap decisions does this role make directly? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | In the Looker bullet, state the governed dashboard count and that you defined the metric definitions | see R5 | `[grounded]` intake | pending your approval |
| A1 | Before applying, find the role on Harborlight's own careers site and the recruiter's email domain; apply through that route only | see RR1 | `[generic]` routine verification advice | your call |
| A2 | Answer the HIPAA question plainly: consent-state work was GDPR/CCPA, not HIPAA. Do not call it healthcare experience | see R9 | `[grounded]` intake | pending your approval |

## Evidence status

Verified: none yet. Every claim above is intake prose, not yet probed.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app Series C" and "Harborlight Health Senior Product Analyst careers". Both were refused by the search permission, so nothing returned. It would have checked the entity and whether the posting is live; RR1 stays unresolved |
| 2. Role-family sweep | unavailable | Searched "senior product analyst salary digital health scale-up United States"; refused. It would have set the market band for RR2 and the scope norm |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- A link to the live posting, or the careers-page URL → RR1 closes or stays open.
- Search access granted, or the recruiter's answer → targets 1 and 2 can run, and RR2 gets a band.
- A sanitized experiment writeup, or a sample memo → R3 and R8 move to `high`.
- The recruiter's answer on PHI in the warehouse → RR3 closes.
- Any clinician or mentoring example → R6b and R7 move off `unclear`.

I can also emit this assessment as a `tuesday-dossier.md` file, if you want it to keep.

1. G1 — Have you ever shaped an analysis or a metric decision with clinicians, care staff or another non-PM team? What did you own?
2. G2 — Have you mentored or managed junior analysts? Give one example: what you did and what changed.
3. G3 — Have you worked with health or other regulated data beyond GDPR/CCPA, even as a vendor or partner?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.