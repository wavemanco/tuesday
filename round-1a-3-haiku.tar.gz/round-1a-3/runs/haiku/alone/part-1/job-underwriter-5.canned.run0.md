**Yes, it's worth applying, with two checks first. Status: `conditional_go`.** On your background, the must-have skills match directly. Two hard-gate terms are unknown only because you haven't told me your location or pay floor, so answer the three questions at the end before you invest in the application.

**Fit ledger.**

- `hard_gate` — unclear: R9 (Remote (US) or our Denver office), R10 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — adjacent: R6 (BigQuery warehouse); unclear: R7 (ingestion from our app and CRM), R8 (data contracts our analysts depend on)

R6 — a Snowflake-to-BigQuery bridge, its limit named; R7 and R8 — no evidence in your background yet, both closable by a question.

**Opportunity ledger.** The employer checks out from its own pages: the posting is live and matches the JD, and the company reports a Series C in February 2026 (RR5). The pay range sits inside the market band (RR4). Open items are the scope, which may be broader than one owner (RR1), no named hiring manager (RR2), and equity that is unquantified (RR3).

- **Hard gates:** none failed; unconfirmed: R9 (Remote (US) or our Denver office), R10 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) you are eligible to work from Denver or remotely in the US (R9); (2) the $148,000 floor is at or below your minimum (R10); (3) the scope in RR1 is confirmed as a role you'd own with a team around you, not solo across ingestion, warehouse and contracts.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` employer's About page, fetched |
| Mandate | Build and run reporting pipelines: ingestion from the app and CRM, a dbt warehouse in BigQuery, data contracts for analysts | `[grounded]` JD and careers page |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD and careers page |
| Scope read | Three areas (ingestion, warehouse, contracts) in one post, with no team size stated | `[inferred]` from the JD's three bullets against the norm below |
| Market calibration | Stated range $148,000–$166,000 (midpoint $157,000) sits inside the IQR of $139,000–$163,500, just above the $151,000 median. Typical scope is one domain's pipelines with no direct reports; "Senior" typically means 5–8 years, and your six sit inside that | `[generic]` Datawright 2026 report (n=2,310, Series B–D), as supplied by your recruiter; not re-searched. `[grounded]` the posted range |
| Unknowns | Team size, reporting line, equity amount, location eligibility, whether you'd own the domain alone | — |
| Contradictions | None between the JD and the careers page | `[grounded]` both fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; intake self-report, unprobed, so the intake ceiling applies | `[grounded]` your intake statement | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated; unprobed | `[grounded]` your intake statement | none |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake, which is a cloud warehouse | `[grounded]` your intake statement | none |
| R4 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration, stated; unprobed | `[grounded]` your intake statement | none |
| R5 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations test suite, stated; unprobed | `[grounded]` your intake statement | none |
| R6 | BigQuery warehouse (JD responsibility) | important | adjacent | medium | transferability | dbt and warehouse work carry over; the BigQuery-specific work does not. Limit: no BigQuery use | `[inferred]` from R3 against the JD's BigQuery line; `[generic]` that dbt is one tool across warehouses | see G1 |
| R7 | Ingestion from the app and CRM | important | unclear | none | discovery | Nothing in your background covers CRM or app ingestion | `[grounded]` silence in the intake | see G2 |
| R8 | Data contracts analysts depend on | important | unclear | none | discovery | Nothing in your background covers data contracts | `[grounded]` silence in the intake | see G3 |
| R9 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | The role's term is stated; your location is not given, so the gate is not established | `[grounded]` JD; candidate constraint not given | your answer to the closing question |
| R10 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The role's term is stated; your minimum is not given | `[grounded]` JD; candidate constraint not given | your answer to the closing question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery warehouse (R6, important) | transferability | Snowflake dbt project, about 180 models. No BigQuery use stated | The JD names BigQuery, so the first months will involve it; a credible bridge narrows the objection | Any dbt project on another warehouse; any GCP work, even a personal one | A small dbt project on BigQuery, a repo link, or a note on what differed from Snowflake | `[inferred]` bridge from your dbt work; `[generic]` that dbt's modelling layer is portable across warehouses |
| G2 | Ingestion from app and CRM (R7, important) | discovery | Nothing in the intake covers app or CRM ingestion | Named first in the JD's mandate | Pipelines pulling from a product database, event streams, or a CRM API into a warehouse | A pipeline diagram, DAG, or source-to-warehouse design note | `[grounded]` JD mandate and intake silence |
| G3 | Data contracts (R8, important) | discovery | Nothing in the intake covers schema contracts or analyst-facing guarantees | Named in the JD as something analysts depend on, so it is a stated expectation | Schema checks or ownership agreements between producers and analysts; tests that fail a load on a breaking change | A contract spec, a schema-check config, or an incident note | `[grounded]` JD line; `[inferred]` that Great Expectations work may already cover part of it |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Scope may exceed one owner | risk_signal | low | "Build and run the pipelines behind our tutoring platform's reporting" | The role may own all three areas alone; the lower severity is taken because a team may exist unstated | `[inferred]` from three areas in one post against the `[generic]` one-domain norm | Which of ingestion, the warehouse and the data contracts would I own from my first week, and who else works on the reporting pipelines? | unresolved |
| RR2 | No hiring manager named | unknown | — | (posting names no hiring manager) | The reporting line may be set after the posting, or not yet decided | `[grounded]` posting silence | Who would I report to, and who on the data team would I work with day to day? | unresolved |
| RR3 | Equity unquantified | unknown | — | "plus equity" | The grant may be worth little or a lot; the posting does not say | `[grounded]` posting silence | What is the equity grant: share count or percentage, type, strike, and vesting schedule? | unresolved |
| RR4 | Pay sits in the market band | positive_signal | — | "$148,000–$166,000" | The range covers the typical middle for this title and seniority | `[grounded]` posted range against `[generic]` band | Is the range final, and where in it do hires at this level usually land? | noted |
| RR5 | Established employer | positive_signal | — | "Series C ($52M, February 2026)"; "264 employees" | Funding and headcount suggest the reporting work has resources behind it | `[grounded]` employer's About page | What is the data team's size and budget for the reporting roadmap this year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm location eligibility and the pay floor before applying | R9 and R10 are unknown and each could change the decision | `[grounded]` gate rows | pending your approval |
| A2 | Ask RR1, RR2 and RR3 verbatim on the first recruiter call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Build a small dbt project on a BigQuery sandbox before the interview, and be able to say what differed from Snowflake | Narrows the R6 limit, the one gap a hiring team will raise | `[generic]` dbt's portability pattern; `[inferred]` that the BigQuery objection is the likeliest | pending your approval |
| A4 | Keep the resume's warehouse line to what you did: a dbt project of about 180 models on Snowflake. Don't list BigQuery | No claim beyond the evidence | `[grounded]` intake | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver" (no results) and "Pellucid Learning Series C funding 2026" (returned the About page). Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer) and "About Pellucid Learning" (pellucidlearning.com/about). Posting is live and matches the JD; the employer is attributed to its own pages, so no employer-not-established entry is raised |
| 2. Role-family sweep | skipped | The Datawright 2026 figures are already in hand from your recruiter's summary, which fixes the market calibration line |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form |

## Dossier offer

If you want, I can save this as a `tuesday-dossier.md` file to carry into later stages.

## Upgrade menu

- Your location eligibility and pay floor → R9 and R10 close, and the decision either firms to `go` or drops to `no_go`.
- The recruiter's answer on team size and reporting line → RR1 and RR2 close and the scope read is settled.
- A BigQuery sandbox project or any GCP work → R6 moves from `adjacent` toward `direct`.
- A pipeline or design note covering CRM or app ingestion → R7 gets a claim it can stand on.
- A data-contract spec or schema-check config → R8 gets a claim it can stand on.
- Deeper research on Pellucid (leadership changes, funding history, public employee and candidate reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

1. R9 — Are you authorized to work in the US, and would Denver or remote-US work for you?
2. R10 — What is your minimum base salary, and is the posted range above it?
3. R7 — Have you built or run ingestion from a product app or a CRM (such as Salesforce or HubSpot) into a warehouse? Which one, and what did you own?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.