**Decision: no_go on the posting as written.** Two hard gates fail on its own stated terms, and no framing in the posting or in your CV changes that. Your fit for the day-to-day work is strong, so the opportunity is what's failing.

## Decision snapshot

- **Fit ledger (can you do this role?):** Strong on paid, lifecycle, experimentation, SQL/GA4/Braze, and years of experience. Not evidenced on SEO/content, brand, PR, partnerships, or sales ops. Fit is stated, not verified.
- **Opportunity ledger (is this role what it claims to be, and acceptable to you?):** Multiple risk signals, no red flags in the text itself. Novaline could not be verified (see Evidence status).
- **Hard gates:** **2 failed.** Compensation: posting says $70–85k base, your floor is $150k. Location: posting says on-site in Austin 5 days a week, "no exceptions," and you are remote-only in Portland. Both are stated terms, [grounded] in the JD.
- **Research tier:** L1 — searches 3 of 5, fetches 0 of 2. All three searches were refused by a permission prompt.

## Role reality

- **Title and scope [grounded]:** Head of Growth, owning all revenue growth end to end: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops. Team of one to start.
- **Reporting [grounded]:** CEO, dotted line to the board.
- **Stated company facts [grounded, unverified]:** e-commerce enablement, Series A, profitable since day one.
- **Stated requirements [grounded]:** 8+ years of growth leadership. Must thrive on ambiguity; success metrics "will evolve."
- **Hours [grounded]:** Evenings and weekends "when it matters," described as "just who we are."
- **Compensation [grounded]:** $70–85k base plus unspecified "meaningful equity."
- **Market calibration:** Not established. The role-family sweep did not run, so I have no sourced market band for this title, scope, or seniority. I did not substitute memory for it.
- **Unknowns:** Equity size, the real success metrics, whether a team gets added, and what "profitable" is based on.
- **Contradictions:** Scope of one person covering about seven functions against a "team of one" start.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | Paid acquisition | must-have | meets | medium | — | CV: owned paid at two B2C subscription companies, budget controlled |
| 2 | Lifecycle/CRM | must-have | meets | medium | — | CV: owned lifecycle; deep in Braze |
| 3 | Experimentation | must-have | meets | medium | — | CV: owned experimentation |
| 4 | Analytics (SQL, GA4) | must-have | meets | medium | — | CV: deep in SQL and GA4 |
| 5 | 8+ years growth leadership | must-have | meets | medium | — | CV: 9 years, growth lead then Head of Growth |
| 6 | Revenue scaling | preferred | partial | medium | transferability | CV: $8M to $40M ARR over three years |
| 7 | Team-of-one start | implied | partial | low | transferability | CV: built and managed teams of 3–7, not solo starts |
| 8 | SEO/content | must-have | unknown | — | discovery | Not on CV |
| 9 | Brand | must-have | unknown | — | discovery | Not on CV |
| 10 | PR | must-have | unknown | — | discovery | Not on CV |
| 11 | Partnerships | must-have | unknown | — | discovery | Not on CV |
| 12 | Sales ops | must-have | partial | low | capability | SQL depth only; no sales-ops work on CV |
| 13 | **Compensation floor $150k** | hard gate | **fails** | — | hard-gate | Posting $70–85k base |
| 14 | **Remote-only** | hard gate | **fails** | — | hard-gate | Posting: on-site Austin 5 days, "no exceptions" |

Confidence is "medium" for CV claims because they are stated and specific but unverified. Nothing here is "high" until you have evidence to show.

## Opportunity risk register

| Class | Signal | Severity | Basis |
|---|---|---|---|
| Risk signal | Responsibility without resources: "team of one," "don't need a bench" | high | [grounded] JD text |
| Risk signal | Bundled specializations: seven functions under one title | high | [grounded] JD text |
| Risk signal | Undefined success criteria: "metrics will evolve" | medium | [grounded] JD text |
| Risk signal | Normalized overwork: evenings and weekends "just who we are" | medium | [grounded] JD text |
| Risk signal | Pay well below the stated seniority and scope | high | [grounded] posting figure against your floor; no market comparison yet |
| Risk signal | Equity described only as "meaningful," unspecified | medium | [grounded] JD text |
| Unknown | Novaline's existence and funding as described | — | Not verified (see Evidence status) |
| Positive signal | Stated reporting to CEO with board visibility | low | [grounded] JD text |
| Positive signal (if verified) | Profitable since day one | low | [grounded] JD text, unverified |

**Standing entry, failed attribution:** Novaline could not be confirmed as the entity described. Possible reasons, none ranked as likely: too new or small, a stale posting, or not a live hiring employer. This caps any `go` at `conditional_go` until verified.

## Application plan

Not recommended under these terms. The location and pay gates cannot be resolved by a better CV or a cover letter, and the posting rules out exceptions. No resume edits or outreach are proposed, so none are pending approval.

If you ever revisit it, the only route is a written change to both the pay and location terms. That is worth checking only if a recruiter offers it in writing.

## Evidence status

- **Company site and careers page (L1 target 1):** unavailable. Web search permission was denied, so the company could not be checked.
- **Role-family sweep (L1 target 2):** unavailable. Same cause, so no market band.
- **Hiring manager footprint (L1 target 3):** n/a. No name was given.
- **L2 targets 4 and 5:** not run. Not offered again until search is available.

## Dossier offer

If you want, I can write this assessment to `tuesday-dossier.md` so it can carry into later analysis.

## Upgrade menu

- **Granting web search permission** would let me verify Novaline's existence, funding, and posting, and run a sourced market band for this title and pay.
- **The live posting link or the recruiter's email domain** would help verify the company's existence without searching.
- **Any SEO, PR, partnerships, or sales-ops work outside your CV** would move rows 8–12 from unknown to evidenced.
- **Your stated equity expectations** would let me assess the "meaningful equity" line.

## Questions

1. Did a recruiter send this, and if so, do you have the live posting link or the company's careers page?
2. Have you done any SEO, PR, partnerships, or sales-ops work, even informally, that isn't on your CV?
3. Should I retry research once search permission is granted in your settings?

Answer any, skip any; silence counts as skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.