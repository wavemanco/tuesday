## Decision snapshot

**Yes on the analytics core, not yet on the healthcare and people-side edges. Status: `conditional_go`.** Apply, once the three conditions below check out.

**Fit ledger.**

- `must_have`: `direct`: R1, R2, R3, R4, R6a · `adjacent`: R5 (define and maintain the metrics layer) · `unclear`: R6b (partner with clinicians)
- `important`: `direct`: R7 · `unclear`: R8 (mentor two junior analysts)
- `preferred`: `adjacent`: R9 (healthcare data experience, HIPAA)

R1–R4 (`medium`) are specific claims you made, not yet backed by an artifact. R5 is governed dashboards, not stated ownership of metric definitions. R6b and R8 have no evidence on the record yet.

**Opportunity ledger.** The role is concrete: named deliverables and two junior analysts to mentor (RR3). Three things are open: whether any data in the warehouse is protected health information (RR1), pay and location (RR2), and whether the posting is live on the company's own site (RR4). Nothing here is a red flag.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) RR4: the posting is live on Harborlight's careers page, and the hiring team confirms it. (2) Gate check: location, work authorization, pay and schedule terms are ones you can meet. Neither the JD nor your message states them, so nothing here has been checked against them. (3) RR1: the HIPAA scope is confirmed, and you frame the health-data work as adjacency, not experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health: digital-health scale-up, ~400 people, Series C, care-navigation app | `[grounded]` your JD and message; not checked here (see Evidence status) |
| Mandate | Own product analytics: metrics layer, A/B test design and analysis, self-serve Looker dashboards, PM and clinician partnership, mentoring two junior analysts | `[grounded]` JD |
| Scope read | Owns a full analytics function for one product, plus two direct reports; a normal senior scope for this title | `[inferred]` from the listed deliverables against the team size stated |
| Market calibration | Unavailable: the role-family sweep did not run | — |
| Unknowns | Pay, work location, reporting line, what data sits in the warehouse, whether the metrics layer exists yet | — |
| Contradictions | None found within the material you gave | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a consumer-subscription company. Length of experience is not a gate; it's read on the work. Your own account, not yet inspected | `[grounded]` your account | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake is specific. "Expert" is self-judged; no query inspected | `[grounded]` your account | Work sample: redacted query (upgrade menu) |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and the pricing test are specific. The 11% lift's basis (relative or percentage points) is not stated, so it carries that caveat wherever used | `[grounded]` your account | Confirm the basis of the 11% before it appears in writing |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | Built the instance from scratch; 40+ governed dashboards. Specific, self-reported | `[grounded]` your account | none |
| R5 | Define and maintain the metrics layer | must_have | adjacent | medium | discovery | Governed dashboards and the metrics memo show metric governance. Nothing says you defined or owned canonical metric definitions. Limit: definition ownership not established | `[inferred]` adjacency from governed dashboards; `[generic]` that metrics layers are usually owned as a shared dictionary | G1 |
| R6a | Partner with PMs and leadership on roadmap decisions | must_have | direct | medium | none | Monthly readout to VP Product; exec metrics memo | `[grounded]` your account | none |
| R6b | Partner with clinicians on roadmap decisions | must_have | unclear | none | discovery | No clinician or care-team work stated | `[grounded]` silence in your account | G2 |
| R7 | Strong written communication with non-technical stakeholders | important | direct | medium | none | Monthly exec metrics memo is the evidence | `[grounded]` your account | none |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | No mentoring stated | `[grounded]` silence in your account | G3 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | Consumer PII under GDPR/CCPA and a consent-state model in the warehouse. Limit: no health data, no HIPAA controls, no protected health information handling stated | `[inferred]` adjacency; `[generic]` that HIPAA is a separate regime from consumer privacy | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R5, must_have) | discovery | Governed dashboards and a monthly memo; no statement of who defined the metrics | First item in the JD's list; a must-have row sitting at adjacent | Metric dictionary, KPI definitions, a metric review or sign-off process, the glossary behind the exec memo | A redacted metric definition or glossary you wrote or maintained | `[inferred]` that this row decides the interview; `[grounded]` the adjacency |
| G2 | Clinician partnership (R6b, must_have) | discovery | Nothing on the record | Must-have; the care-navigation context makes it probable | Work with care-team staff, nurse or coordinator users, a clinical advisory group, even non-analytics input | A brief or decision record from such a project | `[grounded]` silence; `[generic]` that clinical partnership is a common ask in care products |
| G3 | Mentoring (R8, important) | discovery | Nothing on the record | Two named reports, so the role needs it in practice | Onboarding or reviewing analysts, teaching SQL or experiment design, team leadership | Onboarding plan or a review example | `[grounded]` silence |
| G4 | Health data (R9, preferred) | transferability | Consumer privacy and consent work; no health data | Adjacent, not health experience; the limit must be stated | Consent-state design, data minimisation, data-access controls, data-processing agreements | A redacted data-handling plan or consent-model summary | `[inferred]` bridge from consumer consent work; `[generic]` that HIPAA imposes obligations consumer privacy does not |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | HIPAA scope unstated | unknown | — | "healthcare data experience (HIPAA) a plus" | The warehouse may hold protected health information, so the role may carry HIPAA obligations beyond consumer privacy | `[inferred]` from a care-navigation product against the HIPAA reference | What data does the analytics warehouse hold, is any of it protected health information, and who owns the HIPAA controls on it? | unresolved |
| RR2 | Pay and location absent | unknown | — | No pay or location in the posting as provided | Pay may be set after screening, or the posting may be incomplete | `[generic]` pattern for postings that withhold pay | What is the base salary range, and what is the work location or remote policy? | unresolved |
| RR3 | Concrete scope with a named team | positive_signal | — | "mentor two junior analysts"; "define and maintain the metrics layer" | Scope is defined and a team exists to lead | `[grounded]` the posting's deliverables | Who are the two analysts, and what are their current projects? | noted |
| RR4 | Employer and posting unchecked | unknown | — | The company description and role as provided | The company's size, stage and this posting's live status have not been verified from here; the checks did not run | `[inferred]` from the failed search calls | Is this posting live on your careers page, and who is the hiring manager? | unresolved |

The standing "employer not established" entry is not triggered: that rule needs research that ran and failed to attribute the employer. Here the checks did not run.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV's Looker line with "built the company's Looker instance from scratch; 40+ governed dashboards" | presentation gap on R4 | `[grounded]` your account | resume_edits_pending_approval |
| E2 | Add: "Built the consent-state model for the warehouse; handled GDPR/CCPA consumer PII." Every clause is from your message | R9 | `[grounded]` your account | resume_edits_pending_approval |
| P1 | Lead with the exec metrics memo and the monthly VP Product readout as proof of the PM partnership | R6a, R7 | `[grounded]` your account | pending your approval |
| P2 | Describe healthcare as adjacency: "consumer privacy and consent work; I haven't worked with health data." Don't say you handled PHI or HIPAA controls | R9 limit; keeps clear of the logical-form drift the reframing audit flags | `[inferred]` | pending your approval |
| A1 | Check the posting on Harborlight's own careers page, and get pay and location, before investing in the loop | RR2, RR4 | `[grounded]` RR2, RR4 | pending your approval |
| A2 | Ask the RR1 question in the first interview | HIPAA scope decides how far R9 matters | `[grounded]` register | pending your approval |

Nothing in this plan has been finalized. Edits and phrasing change only on your approval.

## Evidence status

Verified: none yet. Your account is specific but not yet confirmed or inspected.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three searches for the company and its posting were refused by the host's permission setting, so nothing was returned. Would have moved the role-reality organization row, RR4, and the standing employer-established check |
| 2. Role-family sweep | unavailable | The same refusal stopped the salary and scope search. Would have set the market calibration line and any mismatch check on pay |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Search permission was refused, not failed. Granting it would let the first two targets run.

## Upgrade menu

- A redacted query or dashboard screenshot from your Looker work → R2 and R4 to `high`
- A one-page redacted readout of the pricing test, with the basis of the 11% → R3 to `high`, and the lift's basis settled
- A metric dictionary or glossary you owned → R5 to `direct`
- An example of onboarding or reviewing an analyst → R8 moves from `unclear`
- Any project with clinicians or care-team staff, even non-analytics input → R6b moves from `unclear`
- Any work under data-processing terms or with health data → R9 moves from `adjacent`
- The live posting link and the hiring manager's name → RR4 closes
- Pay and location → RR2 closes
- Granting search permission → the employer check and salary sweep run (L1: 3 searches, 2 fetches)

Your dossier can be saved as `tuesday-dossier.md` with the map, the register and the evidence status if you want it as a file, which is one sentence and no pressure.

## Questions

G3 — Have you led or mentored junior analysts? How many, what did you do, and what changed for them?

G2 — Have you worked directly with clinicians or care-team staff? What was the question, and what did you own?

Gate check — Are there location, work-authorization, pay or schedule terms you would not trade? If so, which ones?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.