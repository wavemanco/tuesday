**Decision: conditional go.** You're not wasting your time, but the must-have "3+ years of product management" is a real gap, and the application only works if you can show you owned product decisions, not just fed them.

**Research tier: L0, no searches.** I haven't verified that Quartzline exists as described or that the posting is live. Everything about the company is from your paste.

## Fit by requirement

Fit is my reading of the resume against each requirement. Nothing here is a score.

| Requirement (JD) | Fit | Confidence | Evidence and gap |
|---|---|---|---|
| 3+ years PM (must-have) | Partial | Medium | No PM title. Seven years of adjacent work: roadmap-input sessions, requirements documents, scoping. Transferable, not the same thing. [grounded] JD; [inferred] the match |
| Shipped API or platform products | Partial | Medium | Deep work with a REST API from the integrator side (30+ go-lives). No evidence you owned a product release or its roadmap. |
| Technical fluency (API docs, schemas) | Strong | High (CV-only) | Postman, SQL, OpenAPI, integration architecture. Easy to verify in a conversation. |
| Stakeholder management (eng, sales, customers) | Strong | High (CV-only) | Coordinated your engineers, client engineers and PMs; implementation lead role. |
| Discovery with integration partners | Strong | Medium | Scoping workshops and quarterly client-feedback sessions are discovery in substance. |
| Write specs, drive delivery with eng squads | Partial | Medium | Requirements documents and custom-build coordination. No squad-level delivery ownership shown. |
| Own a roadmap | Gap | — | Your CV shows you *feeding* the roadmap, not deciding it. This is the central question. |
| Define and track adoption metrics | Gap | — | No metrics on the CV. Ask whether you measured integration time-to-live, adoption, or support volume. |
| Launch coordination with sales and support | Strong | Medium | Go-live, UAT, and the integration playbook the whole team uses. |
| Agile delivery | Unknown | — | Not claimed on the CV. May be a presentation gap if you worked in sprints. |

## Hard gates

None stated in the JD. Your non-negotiables (pay, location, authorization, schedule) weren't in what you gave me, so those checks are unknown until you share them.

## Opportunity (judged apart from your fit)

- The JD is specific: clear scope, named teams, and concrete outcomes. No red flags in the text.
- Unverified: company stage, size and whether the posting is live. Treat these as unconfirmed until checked against the careers page.
- Compensation isn't stated. [generic] Roles like this usually carry a band, so ask the recruiter for it early.

## Application plan

1. **Lead with the evidence that's closest to ownership.** Frame yourself as a product-minded owner of integration outcomes, not as a PM by title. Don't claim PM experience you don't have.
2. **Prepare one roadmap decision story.** Pick a case where you pushed for or against a feature based on client feedback, and state the trade-off and the result. This is what closes the "own a roadmap" gap.
3. **Prepare one metric story.** Even a rough one (time-to-go-live, number of integrations, support tickets avoided) answers the adoption-metrics gap.
4. **Address agile directly** if you have worked in sprints. Name the ceremonies and your role in them.
5. **Apply anyway, and check the posting first** on Quartzline's own careers page, not only through the link you received.

Reframing note: "product-adjacent" and "product-minded" are accurate. "Product manager" is not, so don't use it on your CV or in conversation.

## Evidence status

| Target | Status | Reason |
|---|---|---|
| Company site and careers page | skipped | No research consent given |
| Role-family pay and scope | skipped | No research consent given |
| Hiring manager's public footprint | n/a | No name given |

Research tier: L0 — no searches

## Gap recovery queue

- **G1 (roadmap ownership):** no evidence you decided priorities. Closes with one decision story.
- **G2 (metrics):** no adoption or outcome numbers. Closes with one measured result.
- **G3 (agile):** not claimed. Closes with a yes/no and a sentence on your role.
- **G4 (triage tool):** unconfirmed memory from an earlier conversation. Not evidence until you confirm it.

## Risk register

- Must-have PM experience is not met on title. Mitigation: the framing above and the roadmap story. Expect the recruiter to screen on this first.
- Employer unverified. Until checked, this caps the decision at conditional.

## Upgrade menu

- **Roadmap or launch document you wrote or contributed to:** verifies G1 and the spec-writing row.
- **Any usage or adoption figures:** closes G2 and the metrics row.
- **Research at L1 (up to 5 searches and 2 page fetches):** verifies Quartzline exists, that the posting is live, and the pay band.
- **Your non-negotiables:** lets the hard-gate check run.

Want a full dossier of this assessment saved for later use? It's one step, and no pressure.

## Questions

Answer any of these in prose; "skip" is a valid answer.

1. **(G1)** Tell me about one product or integration decision you influenced where you chose one path over another. What was the trade-off and what happened?
2. **(G2)** Do you have any numbers from past integrations, such as time to go-live, adoption, or support volume?
3. **(G4)** Did you build the internal request-triage tool from our earlier conversation? If so, how many support agents used it, and how do you know?