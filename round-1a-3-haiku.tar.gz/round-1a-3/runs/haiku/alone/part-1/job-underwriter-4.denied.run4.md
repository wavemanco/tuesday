**Yes, apply, on conditions. Status: `conditional_go`.** Against the JD's must-haves you match directly on everything except the product half of one requirement. The posting is concrete on scope, but it leaves pay, line management and pet-specific expectations open. I could not check that Brindlemoor exists or that this post is live, because web search was refused in this session.

**Fit ledger.**

- `hard_gate` — unclear: R1 (fully remote, UK-based)
- `must_have` — direct: R2, R3, R4, R5, R6, R7, R8; unclear: R9 (product recommendations)
- `important` — adjacent: R10 (pet-insurance product knowledge)
- `preferred` — direct: R11 (insurance experience)

R10 — pet-insurance knowledge, the largest gap; R9 — the product half has no evidence yet; R1 — yours to confirm.

**Opportunity ledger.** The scope and deliverables are concrete (RR5). Pay (RR3), line management (RR2) and expected pet-specific knowledge (RR1) are open. The employer is not established (RR4), but that reflects the refused search, not anything found about the firm.

- **Hard gates:** none failed; unconfirmed: R1 (fully remote, UK-based); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and this live posting are confirmed on its own careers site (RR4); (2) you confirm your UK base and right to work (R1); (3) the pet gap is presented as an adjacent bridge with its limit stated, never as pet experience (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; pet-insurance product | `[grounded]` your brief of the JD |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD as you gave it |
| Reporting line | Hiring manager is Odile Varga, Director of Pricing | `[grounded]` your brief |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | A senior individual-contributor analyst post under a Director, with a defined set of deliverables | `[inferred]` from title, deliverables and reporting line |
| Market calibration | Not established. The pay band needed a role-family search, which was refused | `[generic]` no band available |
| Unknowns | Pay; line management; pet-specific expectations; split of product versus underwriting work; team size | — |
| Contradictions | None visible in the JD text you gave | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based (right to work) | hard_gate | unclear | low | hard_gate | Nothing you gave me states your base or eligibility. Your UK motor background suggests it, but that is not confirmation | `[inferred]` from UK employment history | You confirm base and right to work |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics at a UK motor insurer, two as senior analyst; clears the floor | `[grounded]` your statement | Artifact would raise to high |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both, as you describe it | `[grounded]` your statement | A sanitized query or script would raise to high |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for a young-driver book | `[grounded]` your statement | Sanitized model documentation would raise to high |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your statement | None needed |
| R6 | Build and monitor rating models | must_have | direct | medium | none | Built and maintained one; monitoring is implied by the maintenance | `[grounded]` your statement | None needed |
| R7 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with underwriting | `[grounded]` your statement | A sanitized test design and readout would raise to high |
| R8 | Turn results into recommendations for underwriting | must_have | direct | medium | none | Recommendations to underwriting are part of the quarterly review | `[inferred]` from the review and tests | None needed |
| R9 | Turn results into recommendations for product | must_have | unclear | low | discovery | Nothing you gave me shows product-side recommendations | `[inferred]` absence in what you gave me | See G2 |
| R10 | Pet-insurance product knowledge (JD's product focus, not a stated requirement) | important | adjacent | medium | transferability | Motor rating, GLM and price-test work carry over. No pet-specific drivers, claims or policy structure are evidenced | `[inferred]` transfer from motor work | See G1 |
| R11 | Insurance experience | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your statement | None needed |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance knowledge (R10, important) | transferability | Motor rating, GLM and test skills transfer. No pet-specific drivers, claims or product structure in what you gave me | It is the product the job is for. The transfer case answers the obvious objection, but only if its limit is stated | Any pet-insurance data, pricing or product conversation; side work on pet or vet-cost data; claims-frequency or severity work outside motor | A sanitized note on how you would approach pet-specific drivers; a short pricing write-up | `[inferred]` transfer from motor work; `[generic]` that pet books differ from motor in driver structure |
| G2 | Product recommendations (R9, must_have) | discovery | Your results reach underwriting. Nothing shows product using them | Half of a must-have is unevidenced | A price-test result product adopted; a repricing or cover proposal informed by your analysis | A product memo or test readout addressed to product | `[grounded]` JD; `[inferred]` that the product half is unevidenced |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Expected pet-specific knowledge not stated | unknown | — | "our pet-insurance product" | The role may expect pet-specific loss drivers from day one, which would deepen G1 | `[inferred]` from product focus against no stated pet requirement | What pet-insurance knowledge do you expect a new hire to bring, and what does the first six months look like? | unresolved |
| RR2 | Line management not stated | unknown | — | "Own pricing analytics" | "Senior" ownership may include managing analysts. You have not managed anyone, so this could become a gap | `[inferred]` from the scope against silence on reports | Does this role line-manage anyone, and who does it report to? | unresolved |
| RR3 | Pay not stated | unknown | — | (no pay term in the JD text you gave) | Pay may sit outside the expected band, or may be left off the post | `[inferred]` from the absence against the band you would expect | What is the budgeted base salary for this role? | unresolved |
| RR4 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | Not checked in this run: search was refused. This is a gap in checking, not a finding about the firm. Possible reasons, none ranked: too new or small for a footprint, a stale posting, or no live hiring | `[generic]` pattern for companies of this size; not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR5 | Concrete deliverables and outcomes | positive_signal | — | "build and monitor rating models; design and read price tests" | Scope is defined and measurable, so the role is legible | `[grounded]` JD | Which of these deliverables are already in place, and which are new? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the posting on Brindlemoor's own careers page and find the hiring contact there, before writing anything | Clears RR4, which caps the decision | `[generic]` pattern | proposed |
| A2 | Confirm your UK base and right to work yourself | R1 is a hard gate | `[grounded]` JD | proposed |
| A3 | Lead with this, verbatim, once you approve it: "I own the GLM rating model for a five-year motor book, run price tests with underwriting, and present quarterly to the head of underwriting" | Matches R2, R4, R5, R7 without claiming pet experience | `[grounded]` your statements | pending your approval |
| A4 | Frame pet as a bridge: name what carries over and what does not, and say you are learning the rest | Matches R10 honestly | `[inferred]` G1 | proposed |
| A5 | Put RR1 to RR3 to the employer in the first interview | They shape the role and the pay | `[grounded]` register | proposed |

## Evidence status

Verified: none yet. Every claim above is yours and unsupported by an artifact.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search refused by the host. Would have checked the firm exists as described and that this posting is live (RR4) |
| 2. Role-family sweep | unavailable | Search refused. Would have set a pay band for this title and seniority in UK insurance (market calibration) |
| 3. Hiring manager's public footprint | unavailable | Search refused. A name was given, so the query could be formed; would have shown public background for positioning |

## Upgrade menu

- A sanitized GLM documentation or validation summary → R4 to high.
- A sanitized price-test design and readout → R7 to high.
- An example recommendation that product acted on → R9 moves from unclear.
- Any pet-insurance exposure, even a dataset, a pricing paper or a product conversation → R10 moves toward direct.
- Your UK base and right-to-work confirmation → R1 to direct.
- Web search access: if you grant it, the three L1 targets can run (up to 5 searches and 2 fetches) to check the firm, its live posting, a pay band and Odile Varga's public footprint.

I can also emit a `tuesday-dossier.md` with this assessment, so the verification questions carry into interview prep.

Three questions. Each answer moves a row above.

G1 — Have you worked with any pet-insurance data, pricing, claims or product, even on a side project or in a past role? If not, which pet-specific drivers could you already talk about with confidence?

G2 — Have you ever had a price-test or model result change a product decision, not just an underwriting one? Who acted on it, and what happened?

RR2 — Have you ever line-managed or formally mentored analysts, even informally? Would you be comfortable taking that on in this role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.