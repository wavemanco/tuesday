**Decision snapshot: `conditional_go`.** Worth applying. Your core stack matches the posting closely, and the one hard-looking gap (BigQuery) is not a stated requirement.

**Fit ledger** (per requirement, from the posting [grounded]; your evidence is your CV as you described it [grounded in your statement, unverified])

| Priority | Fit | Requirement |
|---|---|---|
| Must-have | meets | 5+ years data engineering (6 years) |
| Must-have | meets | Strong SQL and Python (daily use) |
| Must-have | meets | dbt and a cloud warehouse (dbt on Snowflake, ~180 models) |
| Must-have | meets | Orchestration with Airflow (set up and run) |
| Must-have | meets | Data quality testing (set up Great Expectations suite) |
| Preferred | partial | BigQuery, named in the responsibilities. Transferable from Snowflake, not experienced |
| Implied | unknown | Ingestion from the app and CRM, named in the responsibilities |
| Implied | unknown | Data contracts with analysts, named in the responsibilities |

**Hard gates:** none failed. Your location is unknown against "remote (US) or Denver", so that gate is unchecked until you confirm it.

**Role reality**
- Scope: owning pipelines for a reporting domain, no direct reports. This matches the typical "Senior" scope in the pay report [generic].
- Pay: the posted $148k–$166k has a midpoint of $157k, above the $151k market median and inside the $139k–$163.5k interquartile range [generic]. Equity is unquantified, so it's unknown.
- No hiring manager is named.
- Sector: school-funded K-12 tutoring can be sensitive to district budgets [generic]. I haven't checked this company's exposure.

**Opportunity risk register**
- *Failed attribution (standing entry), severity medium:* the company's own site and careers page both say what the JD says, and the posting is live. My searches found no independent coverage of Pellucid's funding or size, so the Series C and headcount are self-reported. This caps the decision at `conditional_go`. To resolve it: the recruiter's email domain, or a named hiring manager you can look up.
- *Unnamed hiring manager, severity low.*
- *Equity unquantified, severity low.*

**Application plan (proposed, not yet written; nothing goes out without your approval)**
- Lead with the 180-model dbt project, the Airflow orchestration and the Great Expectations suite. These are direct matches.
- Frame BigQuery as a transfer, not a claim: "Ran dbt at 180-model scale on Snowflake; new to BigQuery." Don't write it as experience you have.
- If you have ingestion or contract work, that's the section to fill before applying.

**Evidence status**

Research tier: L1 — searches 2 of 5, fetches 2 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company's official site and careers page | yes | Queries: "Pellucid Learning live online tutoring K-12 Denver", "Pellucid Learning Series C funding 2026". Pages: careers/senior-data-engineer, about. Both match the provided text. No third-party confirmation found. |
| 2 | Role-family sweep | skipped | Pay report supplied; I didn't run a separate sweep. |
| 3 | Hiring manager footprint | n/a | No name given. |

**Questions** (3 max)
1. Have you built ingestion from a product app database or a CRM (Salesforce, HubSpot or similar) into a warehouse? Which tools? This closes the ingestion gap.
2. Have you defined or enforced data contracts between producers and analysts, for example schema checks in CI or ownership agreements? This closes the contracts gap.
3. Are you based in the US, and would Denver or remote work for you? This closes the location gate.

Reply with answers, "skip" for any you want to leave blank, or "L2" if you want deeper research.

**Dossier offer:** I can write a `tuesday-dossier.md` file with this assessment for later use, if you want one.

**Upgrade menu:**
- Answers to questions 1 and 2 would move the two unknown rows to evidence-backed fit.
- The recruiter's email domain would resolve the failed-attribution entry.
- L2 (up to 5 more searches and 2 more fetches) would check funding history, leadership churn, public candidate reports and recent news for this company. Run it only if you say so.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.