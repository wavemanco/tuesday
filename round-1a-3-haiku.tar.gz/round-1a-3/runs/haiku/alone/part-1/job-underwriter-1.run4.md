## Decision: conditional go. Apply, but verify the posting first.

Your fit is strongest on the analytics core the JD leads with: experiments, Looker, SQL, and executive communication. The gaps are domain (healthcare, clinical partners) and people-management evidence, which the JD asks for but your background doesn't yet show. The posting also isn't verified yet, because I haven't checked the company or the role.

**Hard gates:** None stated in the JD. Your non-negotiables (location, pay floor, work authorization) aren't in the material, so they're unchecked. The question below covers them.

### Fit ledger

| Priority | Fit | Requirements |
|---|---|---|
| Must | Met | 5+ years product analytics; experiment design at scale; Looker/BI; written communication to non-technical stakeholders |
| Must | Likely met | Expert SQL (daily Snowflake use; "expert" is not yet shown); PM partnership and roadmap influence |
| Must | Partial | Metrics layer ownership; self-serve dashboards (built, but adoption not stated) |
| Must | Unknown | Mentoring two junior analysts; partnering with clinicians |
| Plus | Gap | HIPAA / healthcare data |

### Role reality

- **Title and scope** `[grounded]`: Senior Product Analyst owning analytics for a care-navigation app, including the metrics layer, A/B testing, self-serve Looker, and mentoring two analysts.
- **Organization** `[grounded]`: Digital-health scale-up, about 400 people, Series C, as the JD describes it. Not verified.
- **Market calibration:** Not run. Research is off in this pass (see below).
- **Compensation:** Not stated. The posting withholds it, which is worth asking about.

### Evidence map

| # | Priority | Fit | Confidence | Gap | Requirement | Evidence |
|---|---|---|---|---|---|---|
| 1 | Must | Met | High | None | 5+ yrs product analytics | 6 years at a meal-kit subscription company `[grounded]`, CV |
| 2 | Must | Likely met | Medium | None | Expert SQL | Daily SQL on Snowflake `[grounded]`, CV. No work sample yet |
| 3 | Must | Met | High | None | Experiment design at scale | Ran the program: 30+ A/B tests a year, including a pricing test with an 11% retention lift `[grounded]`, CV |
| 4 | Must | Met | High | None | Looker / BI | Built the instance from scratch, 40+ governed dashboards `[grounded]`, CV |
| 5 | Must | Partial | Medium | Discovery | Metrics layer definition and maintenance | Owned the monthly metrics memo, which implies metric ownership. Not stated that you defined the metrics |
| 6 | Must | Partial | Medium | Discovery | Self-serve dashboards | Governed dashboards built. Stakeholder self-serve usage not stated |
| 7 | Must | Met | Medium | None | Partner with PMs; turn analysis into roadmap decisions | Presents monthly to VP Product `[grounded]`, CV |
| 8 | Must | Met | High | None | Written communication to non-technical stakeholders | Writes the monthly exec memo `[grounded]`, CV |
| 9 | Must | Unknown | Low | Transferability | Partner with clinicians | No clinical or care stakeholder work in the material |
| 10 | Must | Unknown | Low | Discovery | Mentor two junior analysts | Not mentioned |
| 11 | Plus | Gap | — | Transferability | HIPAA / healthcare data | GDPR/CCPA PII handling and a consent-state model are transferable. No HIPAA experience |
| 12 | Implied | Gap | Low | Capability | Care-navigation product domain | No health product experience |

Row 3 needs one check before you lean on it: confirm the 11% was the primary metric and held statistical significance. Interviewers will ask.

### Opportunity ledger

- **Positive signals:** The JD is specific about the work and the metrics stack, which reads as a real analytics function. It asks for no payment, deposits, or bank details.
- **Unverified:** Company stage, size, and whether the posting is live. I haven't checked. This is not a failed check, just an open one.
- **Unknown:** Pay, location, and schedule.

### Application plan

- **Lead with:** the experimentation program and the pricing test. That is your strongest and most transferable evidence.
- **Translate subscription terms to care-engagement terms:** retention and activation map to patient engagement. Keep the mapping explicit so it doesn't read as healthcare experience you don't have.
- **On HIPAA, say the true thing:** you built consent-state and PII handling under GDPR/CCPA, and you have not worked under HIPAA. Proposed wording, pending your approval before it goes anywhere.
- **Mentoring:** if you have any mentoring history, it belongs near the top. If you don't, don't claim it.

### Evidence status

Research tier: L0 — no searches

| Target | Status | Reason |
|---|---|---|
| 1. Harborlight official site and careers page | skipped | Research not consented; L0 pass |
| 2. Role-family sweep (title, scope, pay) | skipped | Research not consented; L0 pass |
| 3. Hiring manager public footprint | n/a | No hiring manager named |

Everything above rests on your CV text and the JD you pasted. Nothing was checked outside them.

---

I can save this assessment as `tuesday-dossier.md` so you can pick it up later.

**Upgrade menu** (what each input unlocks):
- **Posting link or the company's careers page:** Verifies the role is live and consistent with the JD. Clears the unverified company status.
- **Anonymized Looker dashboard screenshot or one experiment write-up:** Raises rows 2, 3, and 6 from medium/high to firm evidence.
- **Research at L1** (up to 5 searches and 2 page fetches): Checks the company and posting, and gives a market pay band for this seniority.
- **Research at L2, offered once** (up to 5 more searches and 2 more fetches): Covers funding, leadership churn, and recent news. Optional.

**Questions** (answer in prose, or say skip on any):
1. Have you mentored or managed junior analysts, formally or informally? (row 10)
2. Did you define the metrics themselves, or consume definitions others set? (row 5)
3. What are your non-negotiables on location, pay floor, and work authorization? These are the hard gates I can't check yet.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.