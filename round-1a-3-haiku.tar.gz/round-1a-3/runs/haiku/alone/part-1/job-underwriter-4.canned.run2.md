**Yes, apply, as a `conditional_go`.** Your core requirements match closely. The open questions are the pet-insurance domain, whether this role sets rates or recommends them, and two things the posting doesn't state: pay and whether the role manages people.

**Fit ledger.**

- `hard_gate` — unclear: R9 (Fully remote, UK; your location and right to work aren't stated)
- `must_have` — direct: R1, R2, R3, R4, R5a, R6 · unclear: R5b
- `important` — adjacent: R8 (pet-insurance product)
- `preferred` — direct: R7 (insurance experience)

R8 is the main gap: your motor method transfers, but pet-specific rating factors and claims behaviour are not in your history.

**Opportunity ledger.** Responsibilities and requirements are clearly stated, and the hiring manager is named (RR6, `positive_signal`). Three things are unknown: decision rights over rates (RR1), management scope (RR2) and pay (RR3). I found no red flags, and no severe ones (`severity: high`) in the register.

- **Hard gates:** none failed; unconfirmed: R9 (Fully remote, UK — location and right to work not stated)
- **Severe red flags:** none found
- **Conditions for go:** (1) RR1 decision rights are concrete and consistent across interviewers; (2) R9 is confirmed on your side; (3) pet is framed as a transfer of method, never as experience you have, with a ramp plan for R8.
- **What would change this:** a posting that doesn't appear on Brindlemoor's own careers page would move this to `hold_pending_answers` until it verifies (RR5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` JD |
| Scope read | Core pricing-analytics scope for the title; no management or sign-off authority stated | `[inferred]` from the JD's verbs against its silence on sign-off and reports |
| Market calibration | Not run. Pay band and seniority norms are unchecked at this tier | — |
| Unknowns | Decision rights over rates; direct reports; base salary; maturity of the pet product and its data | — |
| Contradictions | None found in the text provided | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | high | none | Five years, two as senior analyst, at a UK motor insurer | `[grounded]` your statement | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no artifact seen yet | `[grounded]` self-report | sanitized query or notebook raises to high |
| R3 | GLM experience; build and monitor rating models | must_have | direct | high | none | Built and maintained the young-driver GLM. Motor, not pet | `[grounded]` self-report with stated ownership | sanitized model summary |
| R4 | Design and read price tests | must_have | direct | medium | none | 14 tests last year with underwriting; outcomes not described | `[grounded]` self-report | one test readout raises to high |
| R5a | Recommendations for underwriting | must_have | direct | high | none | Quarterly review to the head of underwriting | `[grounded]` self-report | none |
| R5b | Recommendations for product | must_have | unclear | none | discovery | No product-side recommendations in your history | `[grounded]` absence in your account | see G1 |
| R6 | Presenting to underwriting or actuarial leads | must_have | direct | high | none | Presents the quarterly pricing review | `[grounded]` self-report | none |
| R7 | Insurance experience | preferred | direct | high | none | Five years at a UK motor insurer | `[grounded]` self-report | none |
| R8 | Pet-insurance product (implied by "our pet-insurance product") | important | adjacent | low | transferability | Motor pricing method carries over. Not exercised: pet rating factors (breed, age, condition-level claims), vet-cost inflation, lifetime versus annual cover | `[inferred]` from your background; `[generic]` for the pet factors | see G1 |
| R9 | Fully remote, UK (hard gate) | hard_gate | unclear | none | hard_gate | Your location and right to work are not in the material | `[grounded]` absent from your input | question Q1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product and product recommendations (R8, R5b) | transferability | Motor pricing and underwriting work. No pet or product-side recommendation work stated | Two of the JD's responsibilities sit here. A clear bridge narrows the most likely objection | Any non-motor pricing, even partial; a product-change recommendation you made to underwriting; a pricing review for a new cover or a new segment | A sanitized pricing note or review slide | `[inferred]` bridge from your motor work; `[generic]` that pet factors are the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Decision rights over rates not stated | unknown | — | "Own pricing analytics… turn the results into recommendations" | The role may recommend while underwriting or product sets and signs off rates | `[inferred]` from the verbs "own" and "recommendations" against the silence on sign-off | Does this role set rates, or recommend them? Who signs off, and what did the underwriting team own in your last price tests? | unresolved |
| RR2 | Management scope not stated | unknown | — | "Senior Pricing Analyst" | The role may have reports in year one, and you haven't managed anyone | `[inferred]` from the title against the JD's silence on reports | Does this role line-manage anyone now or in the first year? | unresolved |
| RR3 | Base salary not stated | unknown | — | (no salary in the JD) | The pay may sit below what a senior pricing role earns in the UK | `[inferred]` from the posting's silence; band not checked at this tier | What base salary is budgeted for this role? | unresolved |
| RR4 | Maturity of the pet product | unknown | — | "our pet-insurance product" | The product may be new, with thin rating history, which would change what the role can do in year one | `[inferred]` from the product being named without any data description | How much rating and claims history does the pet product have today, and what data does the role work from? | unresolved |
| RR5 | Posting and employer not verified | unknown | — | "Brindlemoor (insurtech)" | No attribution check has run at this tier | `[generic]` | Can you point me at the live posting on Brindlemoor's own careers page? | unresolved |
| RR6 | Clear responsibilities, requirements, named manager | positive_signal | — | "Fully remote (UK)"; named hiring manager | The role's scope is defined and its owner is identified | `[grounded]` JD | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with five years of UK motor pricing, GLM ownership, 14 price tests, and the quarterly review to underwriting leads | R1, R3, R4, R6 are your strongest direct rows | `[grounded]` evidence map | pending your approval |
| A2 | Describe pet as a transfer of method: "I'd apply a motor-tested pricing method to a new line," never as pet experience | R8 is adjacent; overclaiming it would fail at the first pet question | `[inferred]` from R8 | pending your approval |
| A3 | Prepare one sanitized GLM summary and one price-test readout, with no confidential data | Raises R2, R3 and R4 to high | `[grounded]` evidence map | pending your approval |
| A4 | Ask RR1 to RR4 verbatim in the first interview | The register doubles as interview preparation | `[grounded]` register | proposed |
| A5 | Check the posting on Brindlemoor's own careers page before investing effort | RR5 | `[generic]` | proposed |

## Evidence status

Verified: none yet. Every claim above is your own statement in this conversation; no CV, artifact or source has been checked. Rejected inferences: none.

Research tier: L0 — no searches; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | skipped | Would confirm Brindlemoor exists and the posting is live (RR5). Offered in the upgrade menu |
| 2. Role-family sweep | skipped | Would calibrate pay and seniority for RR3 and the market line in role reality. Offered in the upgrade menu |
| 3. Hiring manager's public footprint | skipped | Would inform positioning for Odile Varga. Offered in the upgrade menu |

## Upgrade menu

- A sanitized GLM summary, price-test readout, or SQL/Python sample → R2, R3, R4 move toward `high`.
- An answer on the pet product's history and data (RR4) → R8 and G1 narrow, and the transfer framing can be sharpened.
- Research at L1 (up to 5 searches and 2 fetches): confirms Brindlemoor and the live posting, and gives a pay band for RR3. Say the word and it runs.
- Odile Varga's public professional footprint → positioning for the first conversation. Needs L1 target 3.
- Your right to work and location → R9 closes.

I can also write this assessment to `tuesday-dossier.md` for later interview prep, if you want it.

Q1 (R9): Are you based in the UK with the right to work here, and is a fully remote UK role what you're after?
Q2 (RR5): Can you point me at the live posting on Brindlemoor's own careers page, or tell me where you saw it?
Q3 (R8): Have you done any pet, home or other non-motor pricing, even partly? If not, what's the closest thing you've priced?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.