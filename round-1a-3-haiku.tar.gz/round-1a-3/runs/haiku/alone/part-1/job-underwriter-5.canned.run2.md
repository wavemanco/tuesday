**Yes, worth applying, on conditions. Status: `conditional_go`.** The role matches your background. The open question is whether the employer is real: I could not find Pellucid Learning or this posting online, so verify that before you put in application effort.

**Fit ledger.**

- `hard_gate` — unclear: R1 (remote US or Denver location), R2 (salary range $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (BigQuery warehouse); unclear: R9 (app and CRM ingestion), R10 (data contracts)

R8 is transferable from your Snowflake work, with BigQuery itself untested; R9 and R10 have no evidence either way, so they need questions.

**Opportunity ledger.** The stated pay and the scope read as normal for this title, which is positive (RR2, RR3), but the employer is not established from attributable sources (RR1, unresolved), and the hiring manager, equity value and reporting line are unstated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver location), R2 (salary range $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 clears: the posting is confirmed on the company's own careers site and the employer is real; (2) R1 confirmed: you are based where the role can be done; (3) R2 confirmed: $148,000 meets your floor.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online K-12 tutoring, Denver, 264 employees, Series C ($52M, Feb 2026) | `[grounded]` pasted About page; not confirmed online (RR1) |
| Mandate | Build and run ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and analyst data contracts | `[grounded]` JD |
| First-year outcomes | Not stated | — |
| Scope read | Pipeline ownership for one domain is the usual shape for this title | `[generic]` Datawright 2026 pay report, as sent by your recruiter |
| Market calibration | Median base $151,000; IQR $139,000–$163,500. The stated range sits around the median, with its top end above the upper quartile | `[generic]` Datawright report, Series B–D, n=2,310; `[grounded]` JD for the range |
| Unknowns | Team size, reporting line, hiring manager, equity value, whether dbt and Airflow are current, contract type | — |
| Contradictions | None between the JD and the About page | `[grounded]` both pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver location | hard_gate | unclear | medium | hard_gate | Your location is not in the material, so the gate is not settled | `[grounded]` JD; location not given | Question in closing block |
| R2 | Salary $148,000–$166,000 | hard_gate | unclear | medium | hard_gate | Your floor is not in the material | `[grounded]` JD; floor not given | Question in closing block |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a payroll company, stated not inspected | `[grounded]` your intake statement | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated, no artifact | `[grounded]` your intake statement | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake, stated | `[grounded]` your intake statement | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used in production, stated | `[grounded]` your intake statement | none |
| R7 | Data quality testing | must_have | direct | medium | none | Great Expectations suite set up, stated | `[grounded]` your intake statement | none |
| R8 | Pipelines in BigQuery (JD responsibility) | important | adjacent | medium | transferability | dbt and warehouse work carry over; BigQuery itself is not exercised. Limit: no BigQuery work; the dialect and operating model are unfamiliar | `[grounded]` your statement; `[generic]` that BigQuery's operating model differs from Snowflake's | G1 |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | Not mentioned in your background | `[grounded]` JD; silence in your background | G2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Closest evidence is the test suite, but contracts with analysts are not described | `[inferred]` from the test-suite work | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8) | transferability | Snowflake and dbt experience; no BigQuery | Named in the JD; the limit is what interviewers will probe | Any BigQuery use: a migration, a side project, a course, a query cost review | A small BigQuery project or a repo | `[grounded]` JD; `[generic]` that interviewers probe warehouse-specific gaps |
| G2 | App and CRM ingestion (R9) | discovery | Not in your background | Core to the role's first months | Source connectors, CDC, API pulls from a CRM | A pipeline diagram or a repo | `[grounded]` JD |
| G3 | Data contracts (R10) | discovery | Test suite only | Analysts depend on the contracts, so this is the scope to confirm | Schema agreements, SLAs, breaking-change processes with consumers | A contract doc or an analyst-facing spec | `[inferred]` from the Great Expectations work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states." | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Stated pay sits near the role-family median | positive_signal | — | "$148,000–$166,000" | The range is in line with market for this title and stage | `[generic]` Datawright band; `[grounded]` JD | Is the range the approved budget for this hire? | noted |
| RR3 | Scope matches a senior pipeline owner | positive_signal | — | "Build and run the pipelines behind our tutoring platform's reporting" | The post is a clear single-domain owner role | `[generic]` typical scope; `[grounded]` JD | Who will I be working with, and what does the team look like? | noted |
| RR4 | Hiring manager, equity value and reporting line unstated | unknown | — | "plus equity" | Equity could be material or nominal; the reporting line sets how much scope is yours | `[inferred]` from the posting's silence | What is the equity grant, and who would I report to? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the posting on the company's own careers site, not via the recruiter's link | see RR1 | `[grounded]` RR1 | proposed |
| A2 | Ask your recruiter for the company's domain and the hiring manager's name | see RR1, RR4 | `[grounded]` RR1, RR4 | proposed |
| A3 | Build or refresh a small BigQuery example before any interview | see G1 | `[grounded]` G1 | proposed |
| A4 | Ask the RR1 and RR4 questions verbatim in the first conversation | the register doubles as prep | `[grounded]` register | proposed |

## Evidence status

Verified: none yet. Your intake claims (R3–R8) are self-report; they become verified when you confirm them in writing.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver" and "\"Pellucid Learning\" Senior Data Engineer"; both returned no results. Employer not established from attributable sources — RR1 |
| 2. Role-family sweep | skipped | The Datawright report your recruiter sent fixes the band, so the calibration in role reality rests on it |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- The live posting link or the company's own careers page → RR1 clears or stays open.
- The recruiter's email domain → checks the employer against its own site.
- A deeper company pass (L2: up to 5 more searches and 2 more fetches, on funding, leadership and past postings) → RR1 and RR4. I can run it if you want; say the word.
- The hiring manager's name → the scope read in role reality.
- A BigQuery artifact → R8 moves from adjacent to a verified bridge.
- Your location and pay floor → R1 and R2 close.

I can also write this assessment to a `tuesday-dossier.md` file for later use.

G1 — Have you used BigQuery in any form (a project, a migration, a course)? If so, what did you own?
R1 — Are you based in the US, and can you work remotely from there or from Denver?
R2 — What is your base-salary floor, and does $148,000 meet it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.