**Worth applying, on conditions. Status: `conditional_go`.** The fit is strong on everything the JD lists. The one open question is the work location, because the JD and the company's careers page disagree.

**Fit ledger.**

- `hard_gate`: unclear: R9 (location: "fully remote (UK)" in the JD, "Leeds office four days a week" on the careers page)
- `must_have`: direct: R1, R2, R3, R4, R5, R6
- `important`: adjacent: R8 (pet-insurance product)
- `preferred`: direct: R7 (insurance experience)

**Opportunity ledger.** Clearly scoped, with a stated reporting line (RR5). Unknowns are decision rights (RR3), salary (RR4), the new pet-insurance domain (RR2), and how much independent footprint the company has (RR6). The location conflict is a risk signal (RR1). No red flags found.

- **Hard gates:** none failed; unconfirmed: R9 (location, per the conflict above); your constraints were not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working location is confirmed in writing; (2) it is clear which rate decisions this role makes itself; (3) your pitch stays accurate to motor, with no pet-insurance claims.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD; careers page |
| Mandate | Own pricing analytics for the pet-insurance product; build and monitor rating models; design and read price tests; recommend to underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing | `[grounded]` careers page |
| Working pattern | **Conflict.** JD: fully remote (UK). Careers page: Leeds office four days a week | `[grounded]` both sources |
| Hiring manager | Odile Varga, Director of Pricing; previously head of pricing analytics at Calloway Re; spoke in 2025 on monitoring rating models in small books | `[grounded]` public profile snippet, title and talk only |
| Scope read | A normally scoped senior post: one product, one reporting line, clearly defined outputs | `[inferred]` from the JD's listed responsibilities |
| Market calibration | Senior pricing analysts at UK insurers and insurtechs: median base £58,400, IQR £52,100 to £64,900 | `[generic]` Pricewell 2026 pay survey (n=612) |
| Stated pay | Not in the JD text or the careers page | `[grounded]` posting silent |
| Unknowns | Decision rights on rate changes; budgeted salary; whether the role has direct reports (not stated, not required); pet claims and vet-data history | — |
| Contradictions | Working location (above) | `[grounded]` |
| Company footprint | Only the company's own careers page came up. Stage, size and funding are not established by this research | `[grounded]` search results |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pricing or actuarial analytics, 4+ years | must_have | direct | medium | none | Five years in UK motor pricing analytics, the last two senior | `[grounded]` your CV | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Used daily, as you describe it | `[grounded]` your CV | upgrade: a sanitized query would raise to high |
| R3 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book | `[grounded]` your CV | CV bullet E1 |
| R4 | Designing and reading price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your CV | none |
| R5 | Building and monitoring rating models | must_have | direct | medium | none | Maintaining the model implies monitoring; the monitoring routine is not described | `[inferred]` from "maintained" | upgrade: describe the monitoring routine |
| R6 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Present the quarterly pricing review to the head of underwriting | `[grounded]` your CV | none |
| R7 | Insurance experience | preferred | direct | medium | none | UK motor insurer | `[grounded]` your CV | none |
| R8 | Pet-insurance product knowledge | important | adjacent | low | transferability | Motor pricing uses the same GLM and test methods. Pet claims, vet-cost and claim-frequency patterns are not in your background | `[inferred]` | see G1 |
| R9 | Working location: fully remote UK (JD) vs Leeds four days a week (careers page) | hard_gate | unclear | low | hard_gate | The two sources conflict, and your location constraint was not given | `[grounded]` both sources | question Q1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance knowledge (R8, important) | transferability | Motor pricing experience; nothing on pet products | The product is pet-only, so the learning curve on claims and vet costs is real | Any pricing work on a low-frequency or high-severity line; any claims-frequency or cost analysis | A sanitized analysis or model note from that work | `[inferred]` bridge from the motor GLM work; `[generic]` that the domain curve is the likeliest objection |
| G2 | Working location (R9, hard_gate) | hard_gate | The sources disagree | Four days a week in Leeds would rule out a fully remote working pattern | None; this is a term to confirm, not a skill to show | A written statement of the working pattern from the recruiter | `[grounded]` both sources |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working location conflicts across sources | risk_signal | medium | "Fully remote (UK)" vs "Leeds office four days a week" | The JD may be out of date, or the careers page may be; the working pattern is not settled | `[grounded]` both sources | Is the role fully remote, or Leeds four days a week? | unresolved |
| RR2 | Pet-insurance domain is new | unknown | — | "our pet-insurance product" | Pet pricing has its own claims and cost dynamics, so the first months may carry a steep learning curve | `[inferred]` | What pet data and claims history will the role work with at the start? | unresolved |
| RR3 | Decision rights not stated | unknown | — | "turn the results into recommendations for underwriting and product" | Recommendations may be advisory, with sign-off sitting with underwriting or product leadership | `[inferred]` from the word "recommendations" | Which rate changes does this role approve, and which go to underwriting or product? | unresolved |
| RR4 | Salary not stated | unknown | — | (none in the posting text read) | The budget is unknown; the band is in role reality | `[grounded]` posting silent; `[generic]` band | What is the budgeted salary for this post? | unresolved |
| RR5 | Clear reporting line and responsibilities | positive_signal | — | "reports to the Director of Pricing" | Scope and accountability are defined, and the hiring manager is a pricing lead | `[grounded]` careers page | — | noted |
| RR6 | Thin public footprint for the company | unknown | — | (search returned only the careers page) | Stage, size and funding are unverified; this is a research gap, not evidence of a problem | `[grounded]` search results | What is the company's stage, size and funding? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Keep the CV bullet as the GLM work actually was: "Built and maintained the GLM rating model for a young-driver motor book" | Accurate and specific; avoids pet claims | `[grounded]` your CV | pending your approval |
| P1 | Lead any cover note with the GLM, price-test and underwriting-presentation record, and name the motor insurer explicitly | This is the strongest match; calling it pet expertise would be false | `[inferred]` positioning from R3, R4, R6, R8 | pending your approval |
| P2 | If you mention the hiring manager's talk, keep it to a shared interest in monitoring rating models, without claiming you know its content | The talk's title is the only thing known about it | `[grounded]` search snippet | pending your approval |
| A1 | Ask the recruiter for the working pattern in writing before the loop | Closes R9 and RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask whether the role has direct reports | Not in the JD, so it is not assumed | `[grounded]` JD silence | pending your approval |

## Evidence status

Verified: none yet. Every claim above rests on your statement of your CV, and no artifacts have been shared.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor careers Senior Pricing Analyst" and "Brindlemoor insurtech pet insurance" (the latter returned nothing); fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Role reality: the working-pattern contradiction; RR1, RR6 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary GLM pricing", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Market calibration `[generic]`; RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned a public profile (linkedin.example/in/odile-varga). Role reality's hiring-manager row; positioning P2 |

## Upgrade menu

- A written statement of the working location from the recruiter → R9 and RR1 close; the decision moves to `go` or `no_go`.
- A sanitized query, or a description of the GLM monitoring routine → R2 and R5 rise to high.
- Any pet, vet or claims-frequency work, even a small piece → R8 moves up from low.
- The budgeted salary → RR4 closes, set against the £52k to £65k band.
- A deeper company pass (funding, leadership changes, news; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want this kept for later, I can write it up as a `tuesday-dossier.md` file that you can update as answers come in.

**Questions**

1. **[R9]** Is this role fully remote from the UK, or Leeds four days a week? If it is Leeds, does that work for you?
2. **[RR3]** Does this role approve rate changes itself, or only recommend them to underwriting and product?
3. **[RR4]** Do you know the budgeted salary, or should we ask the recruiter for it before you apply?

Answer any, all, or say "skip" for any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.