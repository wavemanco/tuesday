## Decision snapshot

**Yes, worth applying, on conditions. Status: `conditional_go`.** Your stack matches five of the six listed requirements. The open questions are the two hard gates I could not check (your pay floor and location) and three responsibilities the posting names but your background doesn't yet show.

**Fit ledger.**

- `hard_gate`: unclear: R10 (Remote (US) or Denver office), R11 (Salary $148,000–$166,000)
- `must_have`: direct: R1, R2, R3, R4, R5, R6
- `important`: adjacent: R7 (dbt-modelled warehouse in BigQuery); unclear: R8 (ingestion from our app and CRM), R9 (data contracts analysts depend on)

R7, a credible bridge with its limit named (no BigQuery use). R8 and R9, unclear, with nothing in your material either way yet.

**Opportunity ledger.** No red flags in the material, and it asks nothing of you (no payment, deposit or bank details). Positive signals are the concrete scope (RR2) and an in-band posted range (RR3). Unknowns are the team and hiring manager (RR1), equity terms (RR4), and the employer itself, which I could not check (RR5).

- **Hard gates:** none failed; unconfirmed: R10 (Remote (US) or Denver office), R11 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) your pay floor and location clear R10 and R11. If your floor is above $166,000 or the role can't be done from where you live, this becomes `no_go`. (2) R8 and R9 show up in your past work, or you are comfortable learning them. (3) BigQuery is framed as adjacent, never claimed.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` as you pasted from their About page; not checked here |
| Mandate | Build and run pipelines behind tutoring reporting: app and CRM ingestion, dbt-modelled BigQuery warehouse, analyst data contracts | `[grounded]` JD |
| First-year outcomes | None stated | — |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | One reporting domain across ingestion, modelling and contracts; no reports mentioned, which is the usual pattern for this title | `[inferred]` from the JD's responsibilities against the role-family pattern |
| Market calibration | Datawright 2026 (US, n=2,310), Senior at Series B–D: base median $151,000, IQR $139,000–$163,500. The posted range sits around the median, and its top end is above the upper quartile. "Senior" typically means 5–8 years; you have 6 | `[generic]` band from the figures you pasted, not checked online; `[grounded]` posted range |
| Unknowns | Hiring manager, team, equity size and vesting, first-year outcomes, contract type | — |
| Contradictions | None found between the JD and the company facts you pasted | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | Six years, stated; no artifact yet | `[grounded]` your statement | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated | `[grounded]` your statement | none |
| R3 | dbt | must_have | direct | medium | none | ~180-model dbt project you built | `[grounded]` your statement | none |
| R4 | Cloud warehouse | must_have | direct | medium | none | Snowflake | `[grounded]` your statement | none |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, stated | `[grounded]` your statement | none |
| R6 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite | `[grounded]` your statement | none |
| R7 | BigQuery warehouse (in the role description) | important | adjacent | medium | transferability | Snowflake dbt carries over; no BigQuery use, so the limit is BigQuery itself | `[grounded]` your statement; `[generic]` that dbt work mostly transfers across warehouses | G1 |
| R8 | Ingestion from app and CRM | important | unclear | low | discovery | Not mentioned | `[grounded]` silence in your material | G2 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Not mentioned; may overlap with the GE suite | `[grounded]` silence in your material | G3 |
| R10 | Location: Remote (US) or Denver | hard_gate | unclear | none | hard_gate | Your location and status not given | `[grounded]` JD | Q1 |
| R11 | Pay $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your floor not given | `[grounded]` JD | Q1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R7) | transferability | Snowflake dbt at ~180 models; no BigQuery | The posting names BigQuery in the role itself | Any dbt model run on BigQuery, including a port or a sandbox project | A small BigQuery dbt project, or a migration note you wrote | `[grounded]` your statement; `[generic]` that the gap is mostly platform-specific |
| G2 | App and CRM ingestion (R8) | discovery | No ingestion work mentioned | Named first in the responsibilities | Pulling from an app database or a SaaS API; incremental loads; change data capture | A pipeline config or DAG; an ingestion design note | `[grounded]` silence in your material |
| G3 | Data contracts (R9) | discovery | Not mentioned | Analysts depend on it, so it is a stated outcome | Schema agreements with downstream users; handling breaking changes; GE suites or dbt model contracts consumers relied on | A contract doc, or a suite that consumers used | `[grounded]` silence in your material |

The hard gates (R10, R11) are surfaced in the snapshot, not queued: the one question they allow is whether they are met.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Hiring manager and team not named | unknown | — | "The posting names no hiring manager" | Reporting line and team size are unknown | `[generic]` that postings often omit this | Who would I report to, and who else owns the reporting pipelines? | unresolved |
| RR2 | Concrete, single-domain scope | positive_signal | — | "Build and run the pipelines behind our tutoring platform's reporting" | Scope is one named domain with a named stack | `[grounded]` JD | Which pipelines would I own end to end in year one? | noted |
| RR3 | Posted range inside the role-family band | positive_signal | — | "$148,000–$166,000 plus equity" | The range sits near the Series B–D median, so it is not a mismatch | `[grounded]` posted range; `[generic]` band from the pasted report | Is $148,000 the budgeted start of the range? | noted |
| RR4 | Equity terms not stated | unknown | — | "plus equity" | Equity could be a small or a large part of total pay | `[inferred]` from the posting's silence on size | What equity is offered, and on what vesting schedule? | unresolved |
| RR5 | Employer and posting not verified here | unknown | — | pellucidlearning.com/careers/senior-data-engineer | The company facts and the live posting are unchecked; nothing was independently confirmed | `[grounded]` search refused in this session | Is this posting live on your careers page, and which address sent it? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm your pay floor and location against the posted range and US-remote or Denver | see R10, R11, RR3 | `[grounded]` JD | pending your approval |
| A2 | Lead with the ~180-model dbt project on Snowflake; name BigQuery as adjacent, never claimed | see R3, R7 | `[grounded]` your statement | pending your approval |
| A3 | Build one small BigQuery artifact (a ported dbt model or a migration note) | see G1; a work sample narrows the limit | `[generic]` pattern | pending your approval |
| A4 | Do not claim ingestion or data-contract experience until G2 and G3 are answered | see R8, R9 | `[grounded]` rows | pending your approval |
| A5 | Put RR1, RR4 and RR5 to the recruiter before investing in the loop | see register | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for the company and the posting; both refused, since web search isn't permitted in this session. Would have moved RR5 and checked the About-page facts |
| 2. Role-family sweep | skipped | The Datawright figures you pasted are in hand and fix the band and the scope norm for this seniority. The paste itself is not checked against the report |
| 3. Hiring manager's public footprint | n/a | No name given |

Dossier offer: I can save this as `tuesday-dossier.md` so it carries into interview prep.

## Upgrade menu

- Web search permission in this session → target 1 can verify the company, the posting and RR5. Deeper diligence (funding, leadership changes, reports) would be a further offer of up to 5 searches and 2 fetches, once search is available.
- Your pay floor and location or work status → R10 and R11 close; the decision moves to `go` or `no_go`.
- A description of any app or CRM ingestion, or any owned data contract → R8 and R9 close.
- A small BigQuery artifact → R7 becomes a stronger bridge.
- The live posting link or the sending address → RR5 closes.

Q1 — R10 and R11: Does $148,000 base clear your floor, and is a US-remote or Denver arrangement workable for you?
Q2 — R8 and R9: Have you built ingestion from an app database or a CRM API, or owned a schema agreement analysts relied on?
Q3 — RR5: Where did this posting come from, your careers page or a recruiter's email, and can you send its link?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.