**Apply, once the employer checks out. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5
- `important` — direct: R6 · adjacent: R7 (build and monitor rating models)
- `preferred` — direct: R8

R1 — location and right to work aren't in what you gave me; R7 — the build is evidenced, monitoring isn't described; R4 (`medium`) — the GLM build is strong, and an artifact would raise it.

**Opportunity ledger.** The employer isn't established from attributable sources (RR1), the salary isn't in the JD as pasted (RR2), and the posting doesn't say whether pet-insurance experience is expected (RR3). Team size and reporting lines are also unstated (RR4). None of these reads as a red flag.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor confirmed as a live hiring employer, RR1; (2) R1 confirmed, location and right to work; (3) pet-insurance framed as a gap you name, never as experience you have, RR3.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech, pet-insurance product | `[grounded]` JD |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, recommend to underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | Normal for a senior analyst; no team, reporting line or book size stated | `[inferred]` from what the JD omits |
| Market calibration | Senior pricing analyst at UK insurers and insurtechs: median £58,400, interquartile range £52,100–£64,900 (n=612) | `[generic]` Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey (pricewell.example/2026-uk-pricing-analytics-pay-survey), one source; this is what to expect, not this employer's offer |
| Employer | Not established: the company search returned nothing | `[grounded]` search "Brindlemoor insurtech pet insurance" |
| Hiring manager | Odile Varga, Director of Pricing at Brindlemoor, per a public profile snippet (not opened) | `[grounded]` search result, linkedin.example/in/odile-varga |
| Unknowns | Salary, team, book size, reporting line, contract type, your location and right to work | — |
| Contradictions | None between the JD and anything found. The hiring manager's profile names Brindlemoor, but the company itself returned no results | `[grounded]` searches |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK (location gate) | hard_gate | unclear | low | hard_gate | The JD says fully remote UK; no constraint given on your location or right to work | `[grounded]` JD | Question R1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years pricing analytics, the last two as senior analyst | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Both used daily; no artifact yet | `[grounded]` your background | a sanitised query or script would raise this |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book | `[grounded]` your background | a model-documentation extract would raise this |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R6 | Design and read price tests | important | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your background | none |
| R7 | Build and monitor rating models | important | adjacent | medium | transferability | The build is evidenced by R4; monitoring after launch is not described | `[inferred]` from "maintained" | gap G1 |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Five years in UK motor insurance | `[grounded]` your background | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R7, important) | transferability | The build is clear; what happened to the young-driver model after launch is not | Monitoring is named in the mandate and is the least evidenced part of it | Post-launch checks on a live model, a performance review, a drift or A/E review you ran | A monitoring pack, a dashboard screenshot, a review note | `[inferred]` from "maintained"; `[generic]` that monitoring is the likely probe |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on Brindlemoor's own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | No salary in the JD as pasted | The budget may sit below the band, or the figure may just be unpublished | `[inferred]` from the absence, against the `[generic]` band | What salary is budgeted for this role? | unresolved |
| RR3 | Pet-insurance experience expectation not stated | unknown | — | "our pet-insurance product" | The role may expect pet-specific pricing knowledge, or pricing in another personal-lines book may be accepted | `[inferred]` from the product named against the silence on experience | Is pet-insurance experience expected, or is pricing experience in another personal-lines book acceptable? | unresolved |
| RR4 | Team, reporting line and book size not stated | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may own pricing alone on a small book, which changes the scope | `[inferred]` from the JD's silence | What team does this role sit in, who does it report to, and how large is the book it rates? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the live posting on Brindlemoor's own careers site before applying | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the recruiter for the budgeted salary and the team structure | see RR2, RR4 | `[grounded]` RR2, RR4 | pending your approval |
| A3 | Lead with the GLM build and the underwriting review; name pet as a gap you would close, never as experience | see R4, R5, RR3 | `[grounded]` R4, R5 rows | pending your approval |
| A4 | Read Odile's published talk, "Small Books, Loud Errors" (2025 Insurance Pricing Forum), before any interview | Monitoring rating models in small books is close to G1 | `[grounded]` search snippet; talk not read | pending your approval |

**Evidence status**

Verified: none yet. Unverified leads: the "Small Books, Loud Errors" talk and Odile's six years at Calloway Re, both from a search snippet only. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance": no results, no company page. Employer not established; RR1 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary GLM": the Pricewell 2026 survey. Market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing insurance": a profile snippet names Brindlemoor and the 2025 talk. Application plan A4 |

**Upgrade menu**

- A live posting link, or Brindlemoor's own careers page → RR1 clears, and the employer cap lifts.
- The budgeted salary → RR2 closes, and the figure is set against the band above.
- An artifact of post-launch monitoring (G1), such as a sanitised monitoring pack → R7 moves to direct.
- Your location and right to work → R1 closes, and the hard-gate line becomes a real check.
- Reading Odile's talk and profile → positioning for this reader, which is A4.
- A deeper pass on Brindlemoor (funding, leadership, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs. This is offered once.

Do you want the full `tuesday-dossier.md` for this role? It's a file you can keep and bring to interview prep later.

Three questions, the ones that could move the decision:

G1 — After the young-driver GLM went live, how did you monitor it: what did you check, how often, and what would have triggered a rebuild?

R1 — Where are you based, and do you have the right to work in the UK without sponsorship?

RR3 — Have you done any non-motor pricing, such as pet, home or another personal-lines book? If so, what did you own and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.