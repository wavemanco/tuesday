**Decision snapshot: worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger** (fit is not a score)
- `hard_gate`: unclear: location (Bristol, two days a week in office), right to work, and salary floor. You haven't told me these, so they're unchecked.
- `must_have`: direct: 4+ years in RevOps or sales ops, Salesforce admin, SQL and spreadsheets. Adjacent: experience with finance on revenue data. Adjacent (weak): owning a forecast.
- `important`: none identified.

**Opportunity ledger.** The role is credible. Quillfield exists as described, the salary is stated and sits mid-band, and the hiring manager has a similar background. The open question is scope: the posting asks for the forecast and billing data, which your current role doesn't cover.

- **Hard gates:** none failed; unconfirmed: location, right to work, salary floor (you haven't given these).
- **Severe red flags:** none found.
- **Conditions for go:**
  1. You can show concrete forecast-input work (pipeline coverage, weighted pipeline, the monthly review's outputs) without claiming ownership of a company forecast.
  2. You can describe real collaboration with finance on revenue, invoicing or reconciliation data, even if not billing itself.
  3. Location and pay constraints check out.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield, invoicing and payments software for UK builders' merchants; Bristol; 96 staff; Series A (£11M), April 2025 | `[grounded]` company About page |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in Bristol | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options | `[grounded]` posting |
| Market calibration | Ledgerline's 2026 UK pay guide for revenue-ops leads at B2B software firms (n=438): median £64,200, IQR £57,800–£70,400. One source, so treat as a rough check | `[generic]` |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations; public profile shows four years as sales ops manager at a payments company before this | `[grounded]` public profile snippet |
| Scope read | Four distinct jobs under one title (CRM admin, billing data, reporting, forecast with the CFO). Broad for the salary band | `[inferred]` from the responsibilities list |
| Unknowns | Whether this role owns the forecast number or feeds finance's; who owns billing data; reporting line; whether the posting appears on Quillfield's own careers page (my search didn't find it) | — |
| Contradictions | None between the posting and the company's About page | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | 4+ years RevOps / sales ops at a B2B software company | must_have | direct | medium | presentation | Five years in sales ops and two running RevOps, but at a B2B *payments* company. Likely to count; the word "software" is the risk | `[grounded]` CV |
| R2 | HubSpot or Salesforce admin | must_have | direct | high | none | Salesforce admin certified; rebuilt pipeline and renewal dashboards | `[grounded]` CV |
| R3 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily. Modelling is implied by the dashboards but not shown | `[grounded]` CV; `[inferred]` modelling |
| R4 | Experience owning a forecast | must_have | adjacent | low | capability | You never owned the company forecast (finance did). The monthly pipeline review with the sales director is real forecast-adjacent input, not ownership | `[grounded]` user statement |
| R5 | Experience working with finance on billing or revenue data | must_have | adjacent | low | capability | Never worked on billing data. Renewal and pipeline dashboards are revenue-adjacent; finance collaboration is not stated | `[grounded]` user statement; `[inferred]` adjacency |
| R6 | Owns CRM and billing data (responsibility) | must_have | unclear | low | capability | Billing data is the gap; CRM ownership matches your admin work | `[grounded]` posting |
| R7 | Location: Bristol, two days a week | hard_gate | unclear | none | none | Not stated by you | — |
| R8 | Right to work in the UK | hard_gate | unclear | none | none | Not stated by you | — |
| R9 | Salary floor | hard_gate | unclear | none | none | Not stated by you; posted range is £61.5k–£67k | `[grounded]` posting |

**Gap recovery queue**
- **G1: Forecast ownership (R4).** Closes with evidence of forecast-input work you did, described accurately. Not closable by claiming ownership.
- **G2: Billing and finance data (R5, R6).** Closes with any finance-facing revenue or invoicing reconciliation work you can describe, even if you never touched billing itself.
- **G3: Modelling evidence (R3).** Closes with one example of a model or pipeline-weighting sheet you built.
- **G4: "Software" vs "payments" (R1).** Closes with a clear, accurate description of the product's SaaS nature. This is presentation, not a claim you can inflate.

**Opportunity risk register**

| ID | Class | Severity | Finding | Source |
|---|---|---|---|---|
| RR1 | risk signal | medium | Scope bundles four jobs and does not say who owns the forecast number versus finance. Ask in interview. | Posting |
| RR2 | unknown | low | Not found on Quillfield's own careers page in search. The posting is hosted on Tallyboard. Not a red flag; verify via the company's careers page or the recruiter's email domain. | Search |
| RR3 | positive signal | — | Pay stated and mid-band. Hiring manager's public background is in sales ops at a payments company, similar to yours. | Posting; public profile |
| RR4 | positive signal | — | Funded, 96 staff, named CFO partnership. Resources look real. | Company About page |

**Application plan**
- **Lead with:** Salesforce admin, renewal and pipeline dashboards, SQL, and the monthly pipeline review. These are the direct matches.
- **Address directly:** forecasting and billing. Don't claim ownership of either. Say what you did (the pipeline review, the input you gave to the forecast process, if accurate) and what you'd need to learn.
- **Interview framing:** ask who owns the forecast number and where billing data sits.
- **Proposed CV language (pending your approval, not yet final):** "Ran the monthly pipeline review with the sales director" (only if the review fed forecast decisions). Confirm before use.

**Evidence status**

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Quillfield's official site and careers page | yes | About page fetched. Careers-page search returned nothing, so posting status on the company's own site is unconfirmed |
| 2 | Role-family sweep (pay and scope) | yes | Ledgerline 2026 UK pay guide snippet only; no fetch |
| 3 | Hiring manager's public footprint | yes | Tamsin Achebe search; one public profile snippet |

**Upgrade menu** (what each input unlocks)
- A forecast or pipeline-coverage sheet you built → raises R4 from adjacent to direct.
- Any finance-facing reconciliation or invoicing work → raises R5.
- Your location, right to work, and salary floor → resolves R7–R9.
- A link to the live posting on Quillfield's careers page → resolves RR2.
- L2 deeper diligence on Quillfield (funding, leadership churn, employee reports, recent news): up to 5 more searches and 2 more fetches. I can run this if you want it.

If you want this kept as a formal dossier, I can emit it as `tuesday-dossier.md`.

**Questions**
1. (R4 / G1) Did your monthly pipeline review feed any forecast decisions, even if finance owned the number? If so, what did you produce?
2. (R5 / G2) Did you work with finance on any revenue, invoicing or reconciliation data, even if not billing itself?
3. (R7–R9) What are your location, right-to-work and salary constraints? Answer in prose, or say "skip" to leave any of these.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.