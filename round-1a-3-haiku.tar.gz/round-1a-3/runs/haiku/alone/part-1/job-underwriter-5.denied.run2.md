## Decision snapshot

**Yes, worth applying, on two checks about you. Status: `conditional_go`.** The role's stack matches your background closely. The main gap is BigQuery, and it's a limit to state, not a blocker. Neither gate has been checked against your own location or pay floor, and I couldn't verify the company.

**Fit ledger.**

- `hard_gate`: unclear: R1 (remote US or Denver location), R2 (base salary $148,000–$166,000)
- `must_have`: direct: R3 (5+ years), R4 (SQL and Python), R5 (dbt and a cloud warehouse), R7 (Airflow orchestration), R8 (data quality testing)
- `important`: adjacent: R6 (BigQuery warehouse) · unclear: R9 (app and CRM ingestion), R10 (data contracts)

R6 — Snowflake and dbt transfer, BigQuery itself `low`; R9 and R10 — nothing in your background either way; R1 and R2 — your own constraints, not given.

**Opportunity ledger.** Sound on what's disclosed: the pay range and stack are named (RR6). Scope is broader than a typical Senior post and authority is unstated (RR1, RR2). Whether the warehouse is moving to BigQuery is unknown (RR3). The company facts are unverified (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver location), R2 (base salary range); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you're US-based or can work from Denver, R1; (2) the posted base works against your floor, R2; (3) BigQuery is stated as a limit, never as experience, R6.
- **What would change this:** a location outside the US turns R1 to `hard_gate_fail` and the status to `no_go`. A floor above $166,000 does the same to R2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` pasted About page; not independently checked |
| Mandate | Build and run reporting pipelines: app and CRM ingestion, a dbt-modelled BigQuery warehouse, and data contracts analysts depend on | `[grounded]` JD |
| Stack named | dbt, BigQuery, orchestration (Airflow or similar), data quality testing, SQL, Python | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | Broader than typical: it covers several source systems plus the warehouse and contracts, where the report's typical Senior owns one domain's pipelines | `[inferred]` from the JD's scope against the `[generic]` norm |
| Seniority | "Senior" with 5+ years sits inside the report's 5–8-year norm; your six years fall inside it | `[generic]` Datawright 2026, Series B–D; `[grounded]` your background |
| Market calibration | Report median base $151,000; IQR $139,000–$163,500. The posted $148,000–$166,000 has its low end just under the median and its high end above the top quartile; midpoint $157,000. This is a band to expect, not this employer's offer | `[generic]` the recruiter-sent report (US, n=2,310); `[grounded]` the posted range |
| Unknowns | Authority and team; hiring manager (none named); warehouse migration status; ingestion and contracts scope; equity size; your location and floor | — |
| Contradictions | None found between the JD and the About page as pasted. The careers page was not checked | `[grounded]` pasted text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | Your location isn't in the material, so the gate isn't established | `[grounded]` JD term; location not given | Q1 |
| R2 | Base salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your floor isn't given. Posted range is set against the band in Role reality | `[grounded]` JD figure | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated at intake and not yet inspected | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both, stated; no artifact | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake | `[grounded]` your background; `[generic]` Snowflake as a cloud warehouse | none |
| R6 | A dbt-modelled warehouse in BigQuery (responsibility) | important | adjacent | low | transferability | Snowflake and dbt carry over. You've never used BigQuery, so BigQuery-specific experience is `none`; the lower band applies. Limit: BigQuery's own features, cost and access model are untested | `[grounded]` your background; `[generic]` that dbt runs on both and their specifics differ | A1; G1 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow for orchestration, stated | `[grounded]` your background | none |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up a Great Expectations suite, stated. What you maintained afterward isn't stated | `[grounded]` your background | none; expect a probe on upkeep |
| R9 | Ingestion from our app and CRM (responsibility) | important | unclear | none | discovery | Your background is silent on sources you ingested | `[grounded]` JD; background silent | Q3 |
| R10 | Data contracts analysts depend on (responsibility) | important | unclear | none | discovery | Your background is silent on contracts. `[generic]`: dbt has a model-contract feature, so ask whether you used one | `[grounded]` JD; background silent; `[generic]` dbt feature | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | BigQuery warehouse (R6, important) | transferability | Snowflake and dbt work; no BigQuery | A small dbt project on BigQuery, or a note on a migration you took part in | `[inferred]` bridge from your Snowflake work; `[generic]` that a BigQuery-specific question is the likeliest probe |
| G2 | Ingestion and data contracts (R9, R10, important) | discovery | Background silent on both | One example of an ingestion you built or ran, and any contract consumers relied on | `[grounded]` background silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Scope broader than typical for the title | risk_signal | medium | "Build and run the pipelines behind our tutoring platform's reporting: ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts…" | Ownership may span several source systems and the warehouse, not one domain | `[inferred]` from the JD's scope against the `[generic]` norm | Which of these sources and models would I own end to end, and which are shared with other teams? | unresolved |
| RR2 | Authority and team not stated | unknown | — | "Build and run the pipelines" | May be a solo owner or one post inside a team; no hiring manager named | `[grounded]` posting silent on team and reporting line | Who would I report to, and who else works on these pipelines? | unresolved |
| RR3 | Warehouse state unclear | unknown | — | "a dbt-modelled warehouse in BigQuery" | The role may build on an existing BigQuery warehouse, or include moving to it | `[grounded]` posting names BigQuery only | Is the warehouse already on BigQuery, or does this role include moving it? | unresolved |
| RR4 | Company facts unverified | unknown | — | "Series C ($52M, February 2026)"; "264 employees" | Facts come from the pasted About page only; no independent check ran | `[grounded]` pasted page; search declined | Can you point me to the Series C announcement and the live posting on your careers site? | unresolved |
| RR5 | Equity unstated | unknown | — | "plus equity" | Equity could be material; size and vesting aren't given | `[grounded]` posting | What equity is offered, and on what vesting schedule? | unresolved |
| RR6 | Pay range and stack named | positive_signal | — | "$148,000–$166,000 plus equity" | Pay is disclosed and the stack is specific: fewer surprises later | `[grounded]` posting | Is the range base only, and how is it set against level? | noted |

Severe red flags: none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume line: "Built a dbt project on Snowflake, about 180 models; set up a Great Expectations test suite; used Airflow for orchestration" | Every clause traces to your sentences; "maintain" and "own" are left out | `[grounded]` your background; audit run clause by clause | pending your approval |
| E2 | Cover-letter line on BigQuery: "I haven't worked in BigQuery. My warehouse work is on Snowflake, and the dbt and testing work is the part I'd bring across" | States the limit plainly, as the bridge rule requires | `[grounded]` "never used BigQuery"; "the part I'd bring across" is a judgement, stated as one | pending your approval |
| A1 | Ask the recruiter whether the warehouse is on BigQuery already or is moving | Closes RR3 and R6 | `[grounded]` RR3 | pending your approval |
| A2 | Confirm the posting is live on the careers site and check the Series C announcement before applying | Closes RR4 | `[grounded]` RR4 | pending your approval |
| A3 | Strengthener for G1: a small dbt project on BigQuery, using public data, if you choose to build one | Narrows R6's stated limit with a real artifact | `[generic]` that an inspectable artifact is the usual way to narrow this | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The one search was refused at the permission prompt, so it returned nothing. It would have checked that the posting is live and the Series C facts; that moves RR4 and the employer check |
| 2. Role-family sweep | skipped | The recruiter's Datawright report is in hand and already fixes the band, the seniority norm and the scope norm. A search would re-source the same numbers |
| 3. Hiring manager's public footprint | n/a | No hiring manager was named, so there is no query to form |

## Dossier offer

If you want this kept as a file, I can write it out as `tuesday-dossier.md` for your records or a later session.

## Upgrade menu

- Allowing web search: I'd re-run the target 1 check, up to 5 searches and 2 fetches, covering the posting's live status and the Series C announcement. That moves RR4.
- Your location and your pay floor → R1 and R2 close, and the status likely becomes `go` or `no_go`.
- A BigQuery project or any BigQuery work sample → R6 moves above `low`.
- The recruiter's answer on warehouse state → R6 and RR3 close.
- One concrete ingestion or data-contract example → R9 and R10 move off `unclear`.
- The hiring manager's name → the scope read in Role reality can be checked, and the application plan can lead with the story that fits that reader.

## Questions

**R1** — Are you based in the US, and does remote US work, or a move to Denver, suit you?

**R2** — What base salary is your floor, and does the posted $148,000–$166,000 meet it?

**R9, R10** — Have you built or run ingestion from an app or a CRM, or defined data contracts that analysts or other teams relied on? Tell me what you built, your part in it, and what it fed.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.