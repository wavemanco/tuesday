## Decision snapshot

**Worth applying to, on three conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (fully remote UK role; your location and right to work are not stated)
- `must_have`: direct: R2, R3, R5, R6, R7 · adjacent: R4 (pet-insurance rating models)
- `important`: direct: R8 (insurance experience) · unclear: R9 (line management, if the role has reports)
- `preferred`: absent: R10 (pet-insurance domain)

**Opportunity ledger.** The role is clearly scoped, but the posting is thin on terms. The salary is not stated (RR1), the reporting line is not stated (RR2), and the employer is not verified (RR3). I found no red flags in the posting text itself.

- **Hard gates:** none failed; unconfirmed: R1 (fully remote UK role; your location and right to work)
- **Severe red flags:** none found in the posting text
- **Conditions for go:**
  1. Confirm you are based in the UK and eligible to work there (R1).
  2. Confirm whether the role has direct reports (RR2, R9). If it does, decide whether that is acceptable.
  3. Verify the employer and the live posting (RR3). This is a standing failed-attribution entry, not a finding. No research has run, so Brindlemoor is unconfirmed.

On the stated requirements you are a strong fit. The one real gap is the pet-insurance domain, and that is transferable rather than disqualifying.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; the product is pet insurance | `[grounded]` JD |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your input; no public-footprint research run |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | An IC analytics-ownership role as written. The JD lists no reports, but it does not rule them out | `[inferred]` from the responsibilities, which describe analysis and recommendations, not people |
| Market calibration | Not run. No salary or remit band has been checked against the role family | — |
| Compensation | Not stated in the posting. Cannot be calibrated against your floor yet | `[grounded]` JD silence |
| Unknowns | Salary; reporting line; contract basis; whether rating-model ownership is shared with actuarial; employer's stage and size | — |
| Contradictions | None found within the JD | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based work and eligibility | hard_gate | unclear | none | unknown | Your location and right to work are not stated in this engagement | `[grounded]` JD; your location not given | Confirm (Q2) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, last two as senior analyst. CV-level claim, not yet checked | `[grounded]` your statement | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both | `[grounded]` your statement | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for a young-driver book | `[grounded]` your statement | none |
| R5 | Build and monitor rating models | must_have | adjacent | medium | transferability | Direct for motor rating. Pet-specific rating (perils, vet-cost inflation, claim patterns, lifetime or annual cover) is untested | `[inferred]` from motor GLM work against the pet product | Positioning (below) |
| R6 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your statement | none |
| R7 | Present to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your statement | none |
| R8 | Insurance experience (a plus) | important | direct | medium | none | Five years in UK motor insurance | `[grounded]` your statement | none |
| R9 | Line management of others | important | unclear | low | discovery | Not stated in the JD. You have never managed anyone, so this matters only if the role has reports | `[grounded]` JD silence; your statement | Confirm (Q1) |
| R10 | Pet-insurance domain | preferred | absent | none | capability | No pet-insurance experience | `[grounded]` your statement | Closure path: see gap queue |

Confidence is `medium` on every CV-level claim. That is the ceiling for claims you have stated but not evidenced; a work sample would raise it.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance domain (R10, R5) | capability | Motor only | The JD names the pet product specifically | Any pricing work on a non-motor line, or a pet product's loss data reviewed in a price test | A one-page note on a rating decision you made, with the drivers you chose and why | `[inferred]` the transferable core is the same GLM and test method; `[generic]` that domain knowledge is the usual objection |
| G2 | Line management (R9) | discovery | No management experience | Matters only if the role has reports | Leading a project or a review with other analysts | Confirmed scope from the recruiter | `[grounded]` your statement; `[inferred]` that the JD is IC-shaped |

The queue holds no questions. The questions are in the closing block, tagged with their row IDs.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Salary not stated | unknown | — | "Fully remote (UK)" with no pay figure | The posting may withhold pay until interview | `[grounded]` JD silence | What is budgeted for this post? | unresolved |
| RR2 | Reporting line not stated | unknown | — | "Own pricing analytics" | The role could carry reports despite the IC-style responsibilities | `[inferred]` from the responsibilities against the silence | Does this role have direct reports? | unresolved (Q1) |
| RR3 | Employer not verified | unknown | — | "Brindlemoor (insurtech)" | Not checked: the company could be new, small, or the posting stale | `[inferred]` no research run | Link to the live posting and the careers page? | unresolved (Q3) |
| RR4 | Responsibilities concrete and specific | positive_signal | — | "build and monitor rating models, design and read price tests" | The scope is defined, and it maps closely to your work | `[grounded]` JD | Who owns the rating model today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the GLM you built and maintained, the 14 price tests, and the quarterly review to the head of underwriting. These match the three must-haves most directly | See R4, R6, R7 | `[grounded]` your statements | pending your approval |
| P2 | Describe the pet work as transferable method (GLM, test design, presenting to underwriting), not as pet experience. Do not write "pet insurance" anywhere in the application | See R5, R10 | `[grounded]` R5 row | pending your approval |
| P3 | Confirm the reporting line before applying | See RR2, R9 | `[grounded]` RR2 | pending your approval |
| P4 | Ask the recruiter for the salary before a final-round interview | See RR1 | `[grounded]` RR1 | pending your approval |

Reframing check on P1: "built and maintained" is accurate for your GLM work. Do not upgrade it to "owned pricing for" or "led" unless you led it. Any CV wording needs your approval before it is used.

## Evidence status

Verified: none yet. Every claim above is from your statement in this engagement; none has a supporting artifact.

Research tier: L0 — no searches; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | skipped | Would confirm that Brindlemoor exists as described and that the posting is live (RR3). Not run; research consent rides with Q3 |
| 2. Role-family sweep | skipped | Would give a `[generic]` salary and remit band for this seniority (RR1, market calibration). Not run |
| 3. Hiring manager's public footprint | skipped | Odile Varga was named, so a query could be formed. Would inform positioning for this reader. Not run |

## Dossier offer

If you want, I can write this assessment to `tuesday-dossier.md` so it is ready for interview prep later.

## Upgrade menu

- A live posting link, or the company's careers page → RR3 closes or the standing entry stands.
- Research at L1 (up to 5 searches and 2 page fetches) → checks the employer, gives a role-family salary band (RR1), and looks at Odile Varga's public professional footprint for positioning.
- The budgeted salary or banded range → RR1 closes; compared against your floor.
- A one-page note on a rating decision you made, with the drivers you chose → raises R5 and gives G1 a usable artifact.
- Any pricing work on a non-motor line, or pet loss data you have reviewed in a test → R10 moves from `absent` toward `adjacent`.

## Questions

1. (RR2, R9) Does this role have direct reports? If it does, would that be a dealbreaker for you?
2. (R1) Are you based in the UK and eligible to work there? Is fully remote UK work your only location constraint?
3. (RR3) Can you send the live posting link? If you'd like me to check Brindlemoor and the salary band, I can run the L1 research (up to 5 searches, 2 page fetches) with your go-ahead.

Answer in any order; "skip" is a fine answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.