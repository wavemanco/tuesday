**Yes, apply, on conditions: `conditional_go`.** Your must-have evidence maps directly onto this role. The open items are the location and right-to-work terms, the pay and reporting line, which the posting you pasted doesn't give, and the employer itself, which I couldn't check.

**Fit ledger.**

- `hard_gate`: unclear: R1 (fully remote, UK location), R2 (UK right to work)
- `must_have`: direct: R3, R4, R5, R6, R7; adjacent: R8 (turning test results into product recommendations)
- `important`: adjacent: R10 (pet-insurance context)
- `preferred`: direct: R9

R3–R7 are direct at `medium`, because they rest on your own account and nothing has been inspected yet. R8 and R10 are credible bridges with their limits named. R1 and R2 are waiting on your answer.

**Opportunity ledger.** The scope is specific and nothing in the posting is a red flag. The unknowns are pay and reporting (RR2, RR1), and the employer check is unrun (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (fully remote, UK location), R2 (UK right to work); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the role appears on Brindlemoor's own careers page, RR3; (2) R1 and R2 check out for you; (3) the pay and reporting answers are acceptable, RR2 and RR1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech selling pet insurance | `[grounded]` your message; employer not yet checked |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Pay | Not in the posting you pasted | `[grounded]` JD text |
| Management | No line management stated. The title says "Senior", not "Lead" | `[inferred]` from JD silence |
| Market calibration | Not run. Both searches were refused | — |
| Unknowns | Pay, reporting line, location and right-to-work terms, who the hiring manager's team is | — |
| Contradictions | None in what you pasted | `[grounded]` |

Management isn't in the JD, so it isn't a gap row. It matters only if RR1 shows the role has reports.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK location | hard_gate | unclear | high | hard_gate | Your constraint is not in your message, so the check is unknown. Confidence grades the constraint, not the role | `[grounded]` JD; constraint not given | Answer the question below |
| R2 | UK right to work | hard_gate | unclear | high | hard_gate | Not stated in the JD or by you | `[inferred]` from the UK-only posting | Answer the question below |
| R3 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years at a UK motor insurer, last two senior. Self-reported | `[grounded]` your message | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your message | none |
| R5 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM for a young-driver motor book. The method is direct; pet data is untested | `[grounded]` your message | none |
| R6 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your message | none |
| R7 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with underwriting | `[grounded]` your message | none |
| R8 | Turn results into recommendations for product | must_have | adjacent | medium | transferability | Your recommendations went to underwriting. Product-side recommendations are not evidenced | `[inferred]` from R6 | G1 |
| R9 | Insurance experience | preferred | direct | medium | none | UK motor insurer | `[grounded]` your message | none |
| R10 | Pet-insurance product context | important | adjacent | medium | transferability | Motor pricing carries the method. It doesn't carry pet risk knowledge, and you have no pet claims | `[inferred]` from the product named in the JD | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product-side recommendations (R8, must_have) | transferability | Recommendations go to underwriting. Nothing shows product decisions | A must-have. A product example narrows it | A price change or product-rule recommendation that product adopted | A product recommendation note or review outcome | `[inferred]` bridge from R6 |
| G2 | Pet-insurance context (R10, important) | transferability | Motor only. No pet pricing or claims experience | The likeliest objection. Pet risk drivers differ from motor `[generic]` | Any work on a non-motor or low-frequency book; any analysis of claim severity or lapse | A sanitized note on a non-motor analysis | `[inferred]` from the JD; `[generic]` that the risk drivers differ |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Reporting line not stated | unknown | — | "Own pricing analytics" | The role may be individual or may carry reports, which would make the management gap real | `[inferred]` JD silence | Does this role line-manage anyone, and who would I work alongside day to day? | unresolved |
| RR2 | Pay not in posting | unknown | — | (no pay line in the pasted JD) | The band may be below your expectation, or simply unpublished | `[grounded]` JD text | What base salary is budgeted for this role? | unresolved |
| RR3 | Employer not established | risk_signal | medium | "Senior Pricing Analyst — Brindlemoor (insurtech)" | The check did not run, so the employer is unverified. The posting may be stale or aggregated, or the company may be too new or small to have a footprint | `[generic]` pattern for companies of this size | Can you point me to the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR4 | Responsibilities specific and measurable | positive_signal | — | "build and monitor rating models, design and read price tests" | Scope is defined and checkable | `[grounded]` JD | What would success look like after the first year? | noted |

Severity is `—` on RR1, RR2 and RR4 because the field applies only to risk signals.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the role is live on Brindlemoor's careers site before applying | see RR3 | `[grounded]` RR3 | pending your approval |
| P1 | Lead with the GLM work, the 14 price tests and the underwriting presentations. Present pet as adjacent, with no pet claims | see R5, R7, R10 | `[inferred]` from the rows | pending your approval |
| Q1 | Ask RR1, RR2 and RR4 in the loop, verbatim | the register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your claims are self-reported, so they stand at `medium` until you give an artifact.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused at the permission check, so the employer could not be checked. Would have settled RR3 |
| 2. Role-family sweep | unavailable | Same refusal. Would have set the market calibration for pay and scope |
| 3. Hiring manager's public footprint | unavailable | Odile Varga was named, so a query could be formed. Not sent: the host refused the search before it ran |

Nothing above is evidence against Brindlemoor. The check is simply open.

I could run the research again if search is allowed, with up to 3 more searches and 2 fetches on the L1 budget. That would close RR3 and the market calibration.

Dossier: I can save this as `tuesday-dossier.md` if you'd like it kept.

## Upgrade menu

- A check of Brindlemoor's careers page or the live posting → RR3 closes. This is the one check that could move the status to `no_go`.
- The budgeted pay band → RR2 closes.
- A sanitized pricing-test write-up or GLM validation output → R5 and R7 move to `high`.
- A product-facing recommendation example → R8's bridge becomes direct.
- Permission for the search tool → the three research targets run, and the market calibration is sourced.

**Questions:**

- R1 and R2 — Are you based in the UK and eligible to work here without sponsorship, and is fully remote the only arrangement you'd take?
- RR2 — What base salary is budgeted for this role?
- RR1 — Does this role line-manage anyone, and who would you work alongside day to day?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.