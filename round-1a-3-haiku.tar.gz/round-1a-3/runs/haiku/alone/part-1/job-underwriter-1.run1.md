## Decision snapshot

**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**
- `must_have`: direct R1, R2, R3, R4, R5; adjacent R6
- `important`: unclear R7; adjacent R8
- `preferred`: adjacent R9

R3 (`medium`) is the core claim: a 30+ tests-a-year program with an 11% retention result, awaiting an inspectable artifact.

**Opportunity ledger.** The role is clearly scoped and the responsibilities are concrete. Three things are missing from the posting: compensation, location and contract type. The job's day-to-day centre is healthcare data, where you have no direct experience.

- **Hard gates:** none identified in the JD. Unconfirmed: work authorization, location and salary. No candidate constraints were given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Research:** both searches were refused (permission not granted), so company existence and the salary band are not established. This is not a failed attribution.
- **Conditions for go:** (1) the recruiter confirms pay, location and contract type; (2) the mentoring and clinician-partnership parts of the job are checked in the first conversation (RR3); (3) healthcare is described as consumer privacy work, not as health-data experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD as you pasted it; not verified externally |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, Looker self-serve, PM and clinician partnership, mentoring two junior analysts | `[grounded]` JD |
| Scope read | Senior IC with people leadership of two analysts, in a regulated domain | `[inferred]` from the responsibility list |
| First-year outcomes | Not stated | `[grounded]` absence in JD |
| Market calibration | Not established: the salary search was refused. No band is given here | — |
| Unknowns | Pay, location and remote policy, contract type, whether clinicians are data consumers or partners, whether "metrics layer" means a formal semantic layer | — |
| Contradictions | None between the JD and your background | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years, consumer subscription, stated on your CV | `[grounded]` your CV | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake, stated | `[grounded]` your CV | optional: one anonymised query sample |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year, a program you designed and ran, and a pricing test behind an 11% retention lift. Strongest claim, but no artifact yet | `[grounded]` your CV | a test-design doc or results summary, redacted |
| R4 | Looker or similar BI | must_have | direct | medium | none | You built the instance and 40+ governed dashboards | `[grounded]` your CV | a screenshot or a redacted dashboard list |
| R5 | Written communication to non-technical readers | must_have | direct | medium | none | Monthly metrics memo read by the exec team; monthly presentations to the VP Product | `[grounded]` your CV | a redacted memo excerpt |
| R6 | Define and maintain the metrics layer | must_have | adjacent | medium | presentation | You built governed dashboards and a metrics memo, but the CV never says you defined and owned metric definitions | `[inferred]` from the governed-dashboard claim | name the metric definitions you owned |
| R7 | Mentor two junior analysts | important | unclear | low | discovery | Nothing on the CV. Not a gap until you say whether you have done it | `[grounded]` CV silence | your answer to Q1 |
| R8 | Partner with clinicians | important | adjacent | low | transferability | You partnered with PMs and executives. Clinicians are a different audience | `[inferred]` | your answer to Q2 |
| R9 | Healthcare data, HIPAA | preferred | adjacent | medium | capability | GDPR/CCPA consumer PII handling and a consent-state model in the warehouse. No HIPAA or clinical data | `[grounded]` your CV; the HIPAA gap is `[grounded]` absence | none you can close quickly; answer Q2 |

## Gap recovery queue

- **G1 (R9, capability):** no HIPAA or clinical-data work. What would close it: a description of how you handled consent and access controls for sensitive consumer data, which is adjacent evidence, not a substitute.
- **G2 (R8, transferability):** no clinician work. What would close it: any pilot, advisory, or research with clinical staff, however small.
- **G3 (R7, discovery):** mentoring is unknown. What would close it: any formal or informal mentoring of analysts.
- **G4 (R6, presentation):** the metric-definition ownership is implied, not stated. What would close it: naming the definitions and governance process you owned.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Compensation not stated | unknown | — | JD silent on pay | The posting may withhold pay as a matter of policy | `[grounded]` absence | What is the budgeted range? | unresolved |
| RR2 | Location and contract type not stated | unknown | — | JD silent | Remote, hybrid or office-based, and permanent or fixed-term, are open | `[grounded]` absence | Where is the role based, and is it permanent? | unresolved |
| RR3 | Healthcare data is central to the job, not peripheral | risk_signal | medium | "care-navigation app", "HIPAA a plus" | Interviewers may probe HIPAA and clinician work harder than the "plus" wording suggests | `[inferred]` from the job's domain against the preferred label | How much of the work touches clinical or PHI data day to day? | unresolved |
| RR4 | Company existence and scale not verified | unknown | — | Search refused | The company may be as described. This run cannot confirm it | `[grounded]` refused search | Can you share the company's careers page or the live posting? | unresolved |
| RR5 | Defined scope and stated responsibilities | positive_signal | — | Responsibilities list | The role is concrete, which makes interview preparation easier | `[grounded]` JD | Who owns the metrics layer today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the experimentation program and the Looker build | These are your strongest direct matches (R3, R4) | `[grounded]` CV | pending your approval |
| A2 | Describe the consent-state work as consumer privacy (GDPR/CCPA), not as health-data experience | R9 is adjacent, not direct; overclaiming here is the fastest way to lose the interview | `[grounded]` CV | pending your approval |
| A3 | Prepare a redacted memo excerpt for R5 | Turns a stated claim into an artifact | `[grounded]` R5 | pending your approval |
| A4 | Ask the recruiter about pay band, location, contract type, whether clinicians use the data, and whether mentoring is part of the role | Closes RR1, RR2, RR3 before the loop | `[grounded]` RR1–RR3 | pending your approval |
| A5 | Answer the mentoring question honestly. If you have no formal experience, say so and name any informal mentoring | Avoids inflating R7 | `[inferred]` | pending your approval |

**Approval:** nothing above is final until you approve it. Say which rows to use.

## Evidence status

Verified: none yet. Every claim above is from your CV or the JD, and none has been checked against an external source.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both calls refused (permission not granted). Would have confirmed the company's existence, stage and that the posting is live (RR4) |
| 2. Role-family sweep | unavailable | The salary search was refused. Would have set the market calibration and the pay read (RR1) |
| 3. Hiring manager's public footprint | n/a | No name given, so there was no query to form |

## Upgrade menu

- **Research access:** if you grant search permission, I will retry targets 1 and 2. That would confirm the company and set a pay band.
- **A redacted memo excerpt or a dashboard screenshot:** raises R5 and R4 from `medium` to `high`.
- **The recruiter's answers on pay, location and contract:** closes RR1 and RR2 and likely settles the decision.
- **A deeper pass on Harborlight Health** (funding, leadership changes, public candidate reports; up to 5 more searches and 2 more fetches), once search access is granted.

If you want a full evidence file for this role, I can write `tuesday-dossier.md` at the end of this engagement.

Three questions, each tagged to a row (answer in text, or say skip):

1. **R7:** Have you managed or formally mentored junior analysts, even informally?
2. **R8, R9:** Have you worked with clinical, patient or regulated health data, or directly with clinicians, even in a pilot?
3. **Hard gates:** What are your non-negotiables on location, work authorization and minimum pay? The JD gives none of these, so I cannot check them yet.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.