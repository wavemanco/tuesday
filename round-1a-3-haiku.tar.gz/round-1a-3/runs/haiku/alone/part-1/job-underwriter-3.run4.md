**Decision: `no_go` on the posting's stated terms.** Two hard gates fail, and no amount of fit can close either one.

**Hard-gates:** 2 failed. Pay: posted $70–85k base against your $150k floor [grounded]. Location: on-site in Austin 5 days a week, "no exceptions," against your remote-only requirement [grounded].

**Fit ledger**

| # | Priority | Fit | Requirement |
|---|---|---|---|
| 1 | Must | Strong | 8+ years growth leadership: 9 years, growth lead then Head of Growth |
| 2 | Must | Supported | Paid acquisition: owned paid |
| 3 | Must | Supported | Lifecycle/CRM: owned lifecycle, deep in Braze |
| 4 | Must | Supported | Revenue ownership at scale: $8M→$40M ARR with a budget he controlled |
| 5 | Must | Partial | Team leadership: built and managed teams of 3–7, but this is a team of one to start |
| 6 | Preferred | Unevidenced | SEO/content |
| 7 | Preferred | Unevidenced | PR |
| 8 | Preferred | Unevidenced | Partnerships |
| 9 | Preferred | Unevidenced | Sales ops |
| 10 | Preferred | Unevidenced | Brand |
| 11 | Hard gate | Fail | Base pay at or above $150k |
| 12 | Hard gate | Fail | Remote-only work |

Rows 6–10 are not evidenced in what you gave me. That may be a gap in what I was shown, not in your experience, so it is a question, not a finding.

**Role reality**
- The remit is broad for one person: all revenue channels, including sales ops, PR and brand, with no team [grounded from the posting; the breadth as a risk is inferred].
- "Evenings and weekends when it matters is just who we are" is a stated schedule expectation [grounded quote].
- "Success metrics will evolve as we learn" means no stated success criteria yet [grounded quote].
- Compensation: $70–85k base is posted and "meaningful equity" is unquantified. The posted base is $65–80k below your floor, or 43–53% under it [grounded arithmetic].
- Market calibration: not established. I ran no research, and I won't give a market number from memory.

**Opportunity risk register**

| Risk | Class | Severity |
|---|---|---|
| Base pay $65–80k below your floor | hard_gate | high |
| On-site 5 days, "no exceptions," against remote-only | hard_gate | high |
| Evenings/weekends expectation | schedule | medium |
| Solo role carrying the full revenue remit | scope | medium |
| No defined success metrics | clarity | medium |
| Equity unquantified | compensation | low |
| Company (Series A, profitable, e-commerce) unverified | unverified | open |

The last row is not a failed attribution. It is untested.

**Application plan:** Don't apply on these terms. If you want one cheap check before ruling it out, ask the recruiter in writing whether remote work and a $150k+ base are possible. The posting says "no exceptions," so I'd expect no.

**Evidence status**

Research tier: L0 — no searches

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | n/a | L0: no research run |
| 2. Role-family sweep | n/a | L0: no research run |
| 3. Hiring manager footprint | n/a | No name given; L0 |

Dossier: I can save this underwriting as `tuesday-dossier.md` if you want to reuse it in other evaluations.

**Upgrade menu**
- L1 research (up to 5 searches, 2 page fetches) would check that Novaline exists as described and pull a Head of Growth pay band for Series A. It cannot change the two hard-gate failures.
- The live posting link, or the recruiter's email domain, would let me confirm the posting is live.
- Evidence for SEO, PR, partnerships, sales ops or brand would move rows 6–10 from unevidenced.

**Questions**
1. Do you have a link to the live posting, or the recruiter's email domain?
2. Do you have any evidence, even a sentence, for SEO/content, PR, partnerships, sales ops or brand?
3. Do you want L1 research on the company and pay band? Reply yes, skip, or "no research."

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.