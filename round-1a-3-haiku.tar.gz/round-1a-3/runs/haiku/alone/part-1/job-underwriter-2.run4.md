## Decision snapshot

**Decision: `conditional_go`.** Applying isn't a waste of time, but this is a stretch application. Your record is strong on the technical and stakeholder requirements. The one must-have you can't meet by title is the 3+ years of PM experience, so expect screening risk there.

The two ledgers stay separate:

- **Candidate fit (your side):** strong on technical fluency and stakeholder work, partial on platform products and most of the duties, a gap on the PM years and on adoption metrics.
- **Opportunity (the role's side):** no red flags in the posting text. Pay, location and schedule are missing, and the company is unchecked.

**Hard gates:** none stated in the JD. Your own constraints (pay floor, location, schedule) weren't given, so they're unknown, not cleared.

**Fit ledger** (must-have = listed requirements; implied = duties the role asks you to own):
- **must-have:** strong #3, #4 · partial #2 · unknown #5 · gap #1
- **implied:** partial #6, #7, #8, #10 · gap #9

**Confidence:** medium. Every claim about your work comes from your CV, so it stays at medium until a work sample or a second source backs it.

## Role reality

- **Title and org:** Product Manager, Platform APIs, Quartzline (B2B logistics-tech, ~150 people, Series B). `[grounded]`
- **Scope:** one PM owns the partner API roadmap, partner discovery, specs, two engineering squads, adoption metrics and launches with sales and support. `[grounded]`
- **Scope read:** broad for one person. It may mean this is an early platform-PM seat. `[inferred]`
- **Market calibration:** platform PM roles at this stage commonly ask for 3+ years of PM experience and screen on that title. `[generic]` This is a pattern, not a claim about this employer.
- **Compensation:** not stated in the posting. `[grounded]`

## Evidence map

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence (source) | Provenance |
|---|---|---|---|---|---|---|---|
| 1 | must-have | 3+ yrs PM experience | gap | — | transferability | No PM title. Adjacent: implementation lead, roadmap-input sessions, requirements docs | `[grounded]` |
| 2 | must-have | Shipped API or platform products | partial | medium | transferability | 30+ REST API client integrations, end to end. You didn't own a product | `[grounded]` |
| 3 | must-have | Technical fluency (API docs, schemas) | strong | medium | — | Postman, SQL, OpenAPI, integration architecture | `[grounded]` |
| 4 | must-have | Stakeholders: eng, sales, customers | strong | medium | — | Coordinated your engineers, client engineers and PMs. Sales not evidenced | `[grounded]` |
| 5 | must-have | Agile delivery experience | unknown | — | discovery | Not stated on the CV | `[grounded]` |
| 6 | implied | Own the partner API roadmap | partial | medium | transferability | Ran quarterly client roadmap-input sessions. Input, not ownership | `[grounded]` |
| 7 | implied | Partner discovery | partial | medium | transferability | Scoping workshops and client feedback sessions | `[grounded]` |
| 8 | implied | Specs and delivery with two squads | partial | medium | presentation | Requirements documents and go-live delivery | `[grounded]` |
| 9 | implied | Define and track adoption metrics | gap | — | capability | No metrics on your record | `[grounded]` |
| 10 | implied | Launches with sales and support | partial | medium | presentation | Go-live coordination across 30+ clients. Support not evidenced | `[grounded]` |

**Excluded:** the unconfirmed request-triage tool from prior memory. It's a lead for a question, not evidence, so it isn't in the map.

## Gap recovery queue

- **#1 (PM years):** closes only by showing you owned product decisions, even informally. Asked in the questions below.
- **#9 (metrics):** closes if you have any usage or go-live numbers from past work. Asked below.
- **#2, #6, #8:** a work sample (an anonymized requirements doc or playbook excerpt) raises confidence on these.
- **#5 (agile):** a line about the delivery process you ran would settle it.

## Opportunity risk register

| Class | Severity | Entry | Provenance |
|---|---|---|---|
| Screening | high | Must-have #1 is unmet by title. Adjacent experience may not get past an initial screen | `[generic]` + `[inferred]` |
| Unchecked | unknown | The company is not verified. Research hasn't run, so this is not a failed attribution. Nothing has been confirmed or refuted | `[grounded]` |
| Mismatch | unknown | Pay isn't stated, so it can't be compared with your floor. Ask at the recruiter stage | `[grounded]` |
| Scope | medium | One PM across roadmap, discovery, two squads, metrics and launches. Check whether a platform team already exists | `[inferred]` |

**Positive signals:** the domain is partner-facing integrations, which is your strongest work, and partner discovery is real customer-facing work.

## Application plan

**Lead with:** the bridge from implementation to platform product. You know how partners actually integrate and what breaks. That's the angle to press, not "PM-in-waiting."

**Proposed CV lines** (`resume_edits_pending_approval`; nothing goes into a CV or outreach until you approve it):
- "Led 30+ REST API integrations end to end, from scoping workshops through UAT and go-live."
- "Collected client feedback for the product roadmap each quarter."

**Avoid unless confirmed:** "owned," "shipped," "PM," "drove adoption." Each one overstates what the record supports.

## Evidence status

Research tier: L0 — no searches

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company official site and careers page | skipped | L0: no research run. Offered in the upgrade menu |
| 2 | Role-family sweep (scope, title, pay) | skipped | L0: no research run |
| 3 | Hiring manager's public footprint | n/a | No hiring manager named |

*Reference files for the full worked format weren't all loaded in this pass, so the labels above are the plain ones.*

If you want, I can write this assessment into a `tuesday-dossier.md` so a later rehearsal can pick it up.

## Upgrade menu

- **Your pay floor and non-negotiables** (location, schedule): clears the hard-gate check, which is unknown right now.
- **Link to the live posting:** confirms the wording and the posting itself.
- **Research at L1** (up to 5 searches and 2 page fetches): the company's site and careers page, plus a pay and scope sweep for this role. This would confirm the company exists and calibrate must-have #1. Offered once.
- **A work sample** (anonymized requirements doc or playbook excerpt): raises rows 2, 3 and 8 from medium.
- **Any metrics from past work:** could move row 9 from gap to partial.

## Questions

1. **[Row 1]** Have you ever owned a decision about what got built or prioritized, even informally, such as choosing which client requests went into a release?
2. **[Row 9]** Did you track any numbers for your integrations or playbook, such as go-live time, integrations live, or team adoption?
3. **[Memory lead]** Did you build an internal request-triage tool that support agents adopted? If so, what did it do and how many people used it?

Answer any of them, skip any, or say "skip." Silence counts as an answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.