**Decision: no_go.** The posting fails both of your hard constraints on its own stated terms. Nothing in your background changes that, and wording can't fix either one.

Research tier: L0, no searches. Everything below is from the posting and your message.

**Hard gates (fail)**
- **Pay:** The posting states $70–85k base. Your floor is $150k base. That is $65–80k short. `[grounded]`
- **Location:** The posting requires on-site in Austin 5 days a week, "no exceptions." You are remote-only in Portland and not relocating. `[grounded]`

**Candidate fit (separate ledger)**
- **Meets:** The 8+ years of growth leadership requirement. You have 9 years and Head-level titles at two companies.
- **Meets, with evidence:** Paid acquisition, lifecycle/CRM, experimentation, and SQL/GA4/Braze. Your CV supports these, but the claims are unverified.
- **No evidence in what you gave me:** SEO/content, brand, PR, partnerships, and sales ops. I can't tell whether this is a gap in experience or just a gap in how you described it.
- **Scope mismatch:** The posting wants someone who doesn't "need a bench," starting as a team of one. Your record is building and managing teams of 3–7. That's a difference in how you'd work, not a missing capability.
- **Equity:** "Meaningful" is unquantified, so I can't weigh it.

**Opportunity ledger (separate)**
- **Contradiction:** The posting requires 8+ years of leadership and offers $70–85k. I have no market data here (no research run), so this is a contradiction within the posting, not a market claim. It is also far below your floor.
- **Schedule and culture signals:** "Evenings and weekends when it matters is just who we are," plus "thrive on ambiguity" and metrics that "will evolve." These are the employer's own framing and I haven't checked them.
- **Unverified claims:** "Series A, profitable since day one" is the employer's statement. I haven't confirmed it, and I haven't confirmed the company or posting is live.

**Application plan:** None recommended. Applying would mean spending effort on a role that fails two terms you've set as non-negotiable.

**Reopening condition:** Only written confirmation from the company, through its own site or careers contact (not the sender), that both pay and location are different from the posting would change this. Given "no exceptions" on location, I'd expect that to be unlikely.

**Research option:** At L1, I could check whether the posting is live on the company's careers page, whether the company matches its description, and how typical the pay band is for this seniority. That would take up to 5 searches and 2 page fetches. It would confirm the decision rather than change it, so I'd only run it if you want the posting verified before you drop it.

**Dossier:** I can save this assessment to `tuesday-dossier.md` if you want a record for future roles.

**Question:** Did the recruiter or company say anything about pay or location being flexible, or did this come as a cold listing? Reply with what they said, or "skip."

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.