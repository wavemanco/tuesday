**Decision snapshot**

**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger**
- `hard_gate`: unclear: H1 (fully remote UK; your location isn't stated)
- `must_have`: direct: R1 (pricing analytics years), R2 (SQL and Python), R3 (GLM), R4 (presenting to underwriting)
- `important`: direct: R5 (price tests); adjacent: R6 (building and monitoring rating models); absent: R8 (pet-specific pricing)
- `preferred`: direct: R7 (insurance experience, motor only)

You meet all four must-haves on the evidence you've given. The gap is the pet domain, not the method.

**Opportunity ledger.** The role is specific and reads as a real analytics job, but the employer is unverified (RR1), the salary is withheld (RR2), and "own pricing analytics" could mean setting pricing or leading analysts (RR3).

- **Hard gates:** none failed. H1 is unconfirmed, because I have assumed you're UK-based and you haven't said so.
- **Research:** web search was refused, so Brindlemoor's existence could not be checked. Under the rules, that caps a `go` at `conditional_go` until it is verified.

**Role reality** `[grounded]` unless marked
- Title: Senior Pricing Analyst, Brindlemoor (insurtech), pet-insurance product. Reports to Odile Varga, Director of Pricing.
- Responsibilities: build and monitor rating models; design and read price tests; turn results into recommendations for underwriting and product.
- Must-haves: 4+ years pricing or actuarial analytics, strong SQL and Python, GLM experience, presenting to underwriting or actuarial leads. Insurance is a plus.
- Not stated: management, salary, location, and the employer's own details.
- Market calibration: `[generic]`. A senior pricing analyst at this scope usually works with a lead or head of pricing above them. Whether you would be expected to lead analysts is unknown and worth asking.

**Evidence map**

| # | Priority | Fit | Confidence | Gap | Requirement | Evidence | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | must_have | direct | medium | none | 4+ yrs pricing or actuarial analytics | 5 yrs pricing analytics, last 2 as senior analyst | stated, unverified |
| R2 | must_have | direct | medium | none | Strong SQL and Python | Daily use of both | stated, unverified |
| R3 | must_have | direct | medium | none | GLM experience | Built and maintained the young-driver GLM (motor) | stated, unverified |
| R4 | must_have | direct | medium | none | Presenting to underwriting or actuarial leads | Quarterly pricing review to head of underwriting | stated, unverified |
| R5 | important | direct | medium | none | Design and read price tests | 14 price tests last year with underwriting | stated, unverified |
| R6 | important | adjacent | medium | transferability | Build and monitor rating models for pet | Motor GLM work; method likely transfers, no pet data | `[inferred]` |
| R7 | preferred | direct | medium | none | Insurance experience | UK motor insurer, 5 years | stated, unverified |
| R8 | important (implied) | absent | — | discovery | Pet-specific pricing knowledge | None | gap |
| H1 | hard_gate | unclear | — | hard_gate | Fully remote, UK | Location not stated | unconfirmed |

**Gap recovery queue** (no questions here; they are asked below)
- **R6, transferability.** Adjacent evidence: GLM build and monitoring. Limit: pet risk drivers differ. Pet lines typically involve breed, species, age-related claim patterns and lifetime or annual cover, which motor work didn't exercise `[generic]`. Strengthener: any non-motor pricing or claims work, or a short self-directed pet dataset analysis you can describe.
- **R8, discovery.** Pet-specific knowledge is absent from what you've told me. The question below asks whether any adjacent non-motor work exists.
- **H1, hard gate.** Confirm your location and that the role is UK-based.

**Opportunity risk register**

| Class | Severity | Entry |
|---|---|---|
| Failed attribution | high | Brindlemoor not verified. Reasons open: too new or small, stale posting, or not a real hiring employer. Resolves with a live job link or the company careers page. |
| Mismatch | medium | Salary not stated. Band against your floor cannot be calibrated. |
| Scope | medium | "Own" may imply leading analysts; you have never managed people. |
| Domain ramp | medium | Pet pricing is new to you. The product side will expect fast ramp-up. |

No red flags are present in the JD text itself.

**Application plan** (positioning pending your approval)
- **Lead with:** GLM rating model ownership, 14 price tests, and presenting to a head of underwriting. These are the strongest direct matches.
- **Name the pet gap yourself:** "New to pet insurance; the GLM and test-design method transfers, and I would ramp on pet claim and risk drivers." Do not imply pet experience.
- **Avoid "own" or "led" language** for anything you didn't lead. Describe the GLM as built and maintained, which is what you did.
- **Proposed CV language** (`resume_edits_pending_approval`): "Built and maintained GLM rating model for young-driver motor book; ran 14 price tests with underwriting in the last year." Nothing added. Approve or change before any use.

**Evidence status**

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | unavailable | Search sent; permission was refused. Existence and posting not checked. |
| 2 | Role-family sweep (scope, title, pay) | unavailable | Not sent; search permission refused. Would have calibrated pay. |
| 3 | Hiring manager's public footprint | unavailable | Search sent; permission refused. Would have informed positioning. |

**Upgrade menu**
- A live job link or the company's careers page: closes the failed-attribution entry.
- Salary range, or confirmation that you'll see one: moves the mismatch entry.
- Web search permission: would let me check the employer and the role-family pay band.
- Any non-motor pricing, claims or health-cost work: would move R8 from absent to adjacent.

I can save this assessment as `tuesday-dossier.md`, which you can carry into later steps; say the word whenever suits.

Questions:

1. Do you have a link to the live job ad or Brindlemoor's careers page, or the recruiter's email domain? Without one, I can't verify the employer.
2. Have you done any non-motor pricing, claims or health-cost work, even if it wasn't pet? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. Does "own pricing analytics" mean you'd set pricing decisions alone, or lead other analysts? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

I've assumed you're UK-based; tell me if not.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.