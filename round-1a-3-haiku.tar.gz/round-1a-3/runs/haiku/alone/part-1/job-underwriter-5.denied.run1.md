**Hold: `hold_pending_answers`.** On the evidence so far this looks worth applying to. Two hard gates are unconfirmed, and two quick answers from you would settle them.

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Pay $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.

**Fit ledger.**

- `hard_gate` — unclear: R1, R2
- `must_have` — direct: R3, R4, R6, R7, R8
- `important` — adjacent: R5 (BigQuery specifically) · unclear: R9 (Ingestion from our app and CRM), R10 (Data contracts our analysts depend on)

R5 — a credible bridge, its limit named; R9 and R10 — discovery, waiting on your answer.

**Opportunity ledger.** The role is specific about its stack and scope (RR2), and the posted pay sits inside the pay report's interquartile range (RR2 also). The employer is not established from attributable sources (RR1, standing entry). The hiring manager is not named (RR3). Nothing found is a severe red flag.

**Research tier: L1 — searches 2 of 5, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both search calls were refused, so the live posting and the company's own site were not checked. It would have moved RR1 and whether the entity matches the about page. |
| 2. Role-family sweep | skipped | The pay report you sent already fixes the band, the title norm and the scope norm this sweep would feed. The band is labelled `[generic]`. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form. |

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016; Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` company about page, as you pasted it; not checked live |
| Mandate | Build and run ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts analysts depend on | `[grounded]` JD |
| Stack | dbt, BigQuery, Airflow or similar, data quality testing, SQL and Python | `[grounded]` JD |
| Scope read | Spans ingestion, warehouse and contracts, which is wider than one domain's pipelines. That is a reading of the JD's three clauses | `[inferred]` from the JD's three responsibility clauses |
| Market calibration | Posted range $148,000–$166,000; midpoint $157,000 sits inside the $139,000–$163,500 interquartile range, above the $151,000 median | `[generic]` Datawright 2026 pay report, as you pasted it; `[grounded]` posted range |
| Unknowns | Location of the role for you; whether it has direct reports; contract type; who the hiring manager is; whether ingestion is built or greenfield | — |
| Contradictions | None found between the JD and the about page as pasted. The live careers page was not checked | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location is not in the material, so the gate is not settled | `[grounded]` JD; no candidate claim | Q1 |
| R2 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor is not in the material | `[grounded]` JD; no candidate claim | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; self-reported, limited proof | `[grounded]` your intake | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | Built a dbt project of about 180 models on Snowflake; self-reported | `[grounded]` your intake | none |
| R5 | BigQuery warehouse (named in the JD's mandate) | important | adjacent | medium | transferability | Snowflake is a cloud warehouse you ran dbt on; you have not used BigQuery. Limit: no BigQuery-specific work claimed | `[grounded]` your intake; `[generic]` that the warehouses differ in ways that matter for this work | Bridge case; see upgrade menu |
| R6 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both, self-reported | `[grounded]` your intake | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Set up Airflow orchestration; self-reported | `[grounded]` your intake | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite; self-reported | `[grounded]` your intake | none |
| R9 | Ingestion from our app and CRM | important | unclear | none | discovery | Not in the material. The JD names it as a responsibility, not a requirement | `[grounded]` JD; no candidate claim | Q3 |
| R10 | Data contracts our analysts depend on | important | unclear | none | discovery | Not in the material | `[grounded]` JD; no candidate claim | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R5, important) | transferability | Snowflake dbt work at about 180 models; no BigQuery | The JD names BigQuery in the mandate, so the bridge has to be made and its limit stated | Any dbt or warehouse work on BigQuery, including a side project or a migration you scoped | A BigQuery project, a repo, or a migration note | `[grounded]` intake; `[generic]` that the warehouses differ in ways that matter |
| G2 | Ingestion and data contracts (R9, R10) | discovery | Not in your intake | These are two of the three mandate clauses | Pipelines pulling from an application database, a CRM, or a third-party API; agreed schemas or contracts with downstream analysts | A pipeline README, a schema doc, or a contract example | `[grounded]` JD; no candidate claim |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring…" | Research was refused, so the employer is unverified. The entity may be too new or small for a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers page, and who would I be interviewing with? | unresolved |
| RR2 | Specific stack and scope stated | positive_signal | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role's scope is concrete, which makes it easier to test in interviews | `[grounded]` JD | Which of the three mandate areas would this role own end to end? | noted |
| RR3 | Hiring manager and reporting line not named | unknown | — | (no name in the posting) | Reporting line and direct reports are not stated | `[grounded]` JD silence | Does this role manage anyone, and who does it report to? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the dbt project on Snowflake (about 180 models), the Airflow orchestration, and the Great Expectations suite | R4, R7, R8 are direct rows | `[grounded]` intake | pending your approval |
| P2 | Name Snowflake as the warehouse you built on. Do not claim BigQuery; state it as a bridge with its limit | R5 | `[grounded]` intake; `[generic]` on how warehouses differ | pending your approval |
| P3 | Confirm the posting on Pellucid's own careers page before spending application effort | RR1 | `[generic]` pattern | pending your approval |

Nothing above adds a claim to your CV. Every line of P1 and P2 is your own wording or a restatement of it, and the approval covers the prose advice as well as any text.

## Evidence status

Verified: none yet. Your intake is self-report and has not been probed.

**Dossier offer:** I can write this up as a `tuesday-dossier.md` so it carries into later sessions, if you want that.

**Upgrade menu**

- An answer to Q1 and Q2 → R1 and R2 leave `unclear`; the status moves to `conditional_go` or `no_go`.
- A BigQuery project, repo or migration note → R5's bridge narrows, and its confidence can rise.
- A dbt project repo or sanitized model docs and tests → R4 and R8 from `medium` toward `high`.
- Permission to search again → a two-search check of the live posting and Pellucid's careers page, which closes RR1 or confirms it.

**Questions**

Q1 (R1): Where are you based, and can you work remote in the US or from the Denver office?

Q2 (R2): What is your base pay floor, and does $148,000–$166,000 plus equity clear it?

Q3 (R9, R10): Have you built ingestion from an application database or a CRM, or published a data contract that analysts depend on? Give one example, with what you owned and what broke.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.