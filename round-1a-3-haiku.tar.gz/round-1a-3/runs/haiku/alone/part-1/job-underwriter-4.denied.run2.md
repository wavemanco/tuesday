## Decision snapshot

**Decision: `conditional_go`. Apply.** On the stated requirements you are a strong match. The conditions are that the posting and employer check out, and that your location and pay floor fit, since the JD states neither. The real gap is pet-insurance domain knowledge, which you can address in the application.

- **Fit ledger**
  - must: strong, rows 1–5; partial, row 6
  - preferred: strong, row 7
  - implied: gap, row 8
- **Hard gates:** none failed. Two are unknown: row 10 (remote UK, your location not stated) and row 11 (pay, none stated in the JD).
- **Confidence band:** medium across the fit rows. Every candidate claim comes from your CV alone, so it is a lead until it is evidenced.
- **Opportunity side:** Brindlemoor and the posting are unverified. I ran no searches.

Research tier: L0, provided material only. No searches.

## Role reality

- **Role:** Senior Pricing Analyst at Brindlemoor, an insurtech. The scope is rating models, price tests, and recommendations to underwriting and product, for a pet-insurance product. Fully remote, UK. Hiring manager is Odile Varga, Director of Pricing.
- **Requirements stated:** 4+ years pricing or actuarial analytics, strong SQL and Python, GLM experience, presenting to underwriting or actuarial leads. Insurance experience is a plus.
- **Not a requirement:** people management. The JD does not mention managing anyone, so it is not a gap and is left off the map.
- **Scope read `[inferred]`:** the JD reads as a single-product role that owns the pricing analytics end to end, not a role inside a large team. "Design and read price tests" suggests you would set the test agenda, not only run tests someone else specified.
- **Market calibration:** not run. It needs the L1 sweep.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | 4+ years pricing or actuarial analytics | must | strong | medium | none | 5 years; last 2 as senior analyst (CV) |
| 2 | Strong SQL and Python | must | strong | medium | none | Daily use stated; no sample work provided |
| 3 | GLM experience | must | strong | medium | transferability | Built and maintained a young-driver GLM (motor) |
| 4 | Presenting to underwriting or actuarial leads | must | strong | medium | none | Quarterly pricing review to the head of underwriting |
| 5 | Build and monitor rating models | must | strong | medium | transferability | Built and maintained one in motor, not pet |
| 6 | Design and read price tests | must | partial | medium | presentation | 14 tests run with underwriting; your design ownership is not stated |
| 7 | Insurance experience | preferred | strong | medium | none | UK motor insurer |
| 8 | Pet-insurance domain knowledge | implied | gap | low | capability | No pet, health or non-motor work stated |
| 10 | Remote UK (hard gate) | hard_gate | unknown | — | hard-gate | Your location is not stated |
| 11 | Pay acceptable to you (hard gate) | hard_gate | unknown | — | hard-gate | Pay not stated in the JD; your floor is unknown |

## Gap recovery queue

- **Row 8, pet domain (capability):** closes with evidence of any non-motor pricing, or a short, specific account of how you would learn pet drivers. Motor GLM skills are transferable; pet-specific drivers are not yet evidenced.
- **Row 6, test design (presentation):** closes if you can show you designed tests, not only executed them. This also strengthens the "design" half of the JD.
- **Row 10 and row 11 (hard-gate):** close with your location and pay floor. These are checks, not proof of fit.

## Opportunity risk register

| Class | Severity | Entry |
|---|---|---|
| Unverified opportunity | medium | Brindlemoor's existence, stage and the posting's live status are not checked. Resolve with the live posting link, its careers page, or the recruiter's email domain. This caps the decision at `conditional_go` until resolved. |
| Fit (domain) | medium | Pet insurance is a different product: different rating drivers and claims patterns. Learning curve is real. |
| Compensation | medium | No pay stated. Check against your floor before investing in the process. |
| Scale `[inferred]` | low | Insurtech pet books may have thinner data than a large motor book. Ask in interview. |

## Application plan

- **Lead with:** your GLM build and maintenance, the 14 price tests, and presenting to the head of underwriting. These are your strongest, verifiable-in-interview proof points.
- **Address the pet gap head-on, do not hide it.** Frame it as transferable method, not claimed domain knowledge. `[generic]`: pet pricing typically turns on breed, age, and vet-cost inflation. Verify those drivers before you cite them.
- **Avoid:** calling yourself a pet-insurance pricing expert, or implying any people-management experience. Neither is evidenced.
- **Resume edits:** none drafted yet. Any CV language is proposed as `resume_edits_pending_approval` and needs your explicit approval before use.

## Evidence status

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Brindlemoor official site and careers page | skipped | L0: provided material only; no search consented |
| 2 | Role-family sweep (scope, title, pay) | skipped | L0: no search consented |
| 3 | Hiring manager public footprint (Odile Varga) | skipped | L0: no search consented |

## Upgrade menu

- **Brindlemoor check (L1):** confirms the employer exists as described, the posting is live, and the hiring pattern. Up to 5 searches and 2 page fetches. This resolves the unverified-opportunity entry.
- **Pay and scope calibration (L1):** a role-family pay band and market-normal scope for this seniority. Up to 5 searches and 2 page fetches, the same L1 budget.
- **Hiring manager footprint (L1):** public professional background for Odile Varga, public information only, to choose the lead story for this reader.
- **Your location and pay floor:** closes rows 10 and 11.
- **A pet or non-motor artifact:** any pet, health or home pricing work, even a data review, would raise row 8.

Say yes to L1 and I will run the first two checks. The 1-2 I'd prioritise is the employer check, because the decision is capped until it is done.

## Questions

1. Where are you based, and what is your minimum base salary? The JD states neither, so the two hard gates are unchecked.
2. For the 14 price tests and the young-driver GLM, which parts did you design yourself (test hypothesis, test design, model specification), and which did you execute?
3. Have you done any non-motor pricing, such as home, travel, health or pet, even a data review or side project?

Respond with answers, or with "skip" to any question. Skipping leaves the related row as it is.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.