## Decision snapshot

**Decision: `no_go` as posted.** Two hard gates fail, and each one is a stated term of the role, not a judgment call.

- **Location:** fails. The posting requires on-site in Austin 5 days a week, "no exceptions." You are remote-only in Portland. [grounded]
- **Pay:** fails. The posting offers $70–85k base. Your floor is $150k, so the gap is $65–80k below it. [grounded]

**Fit ledger (candidate side, separate from the decision):** strong on paper. Nine years of growth work, a $8M→$40M ARR scale-up with a budget you controlled, managed teams of 3–7, and hands-on depth in SQL, GA4 and Braze. Fit is high for paid, lifecycle and experimentation. I have no evidence in what you've given me for PR, brand, partnerships or sales ops, so those rows are unknown, not weak.

**Hard-gates:** location fails; base pay fails. Equity cannot offset either gate. "Meaningful equity upside" is undefined and is not base pay.

**Opportunity ledger:** the posting itself carries several risk signals, covered in the register below. They are signals about the role's design, not findings about the company's intent.

## Role reality

- **Title and scope:** Head of Growth, owning seven functions (paid, SEO/content, lifecycle, brand, PR, partnerships, sales ops) with a team of one to start. [grounded]
- **Seniority signal:** "8+ years growth leadership required" for a team-of-one role. [grounded]
- **Reporting:** CEO, with a dotted line to the board. [grounded]
- **Stated pay:** $70–85k base. For a Head-level title at a Series A company, this sits well below typical bands for the seniority. [generic] I have not checked current figures, so treat this as a pattern, not a number.
- **Unstated:** no information on the company's size, funding details, or revenue. The posting withholds these. [grounded]
- **Stated working pattern:** evenings and weekends "when it matters," on-site five days. [grounded]
- **Contradictions inside the posting:** it asks for an 8+ year leader, pays like a senior IC, and requires a single person to cover seven functions with no bench. That combination is worth noticing. [inferred]

## Evidence map

| # | Priority | Fit | Requirement | Evidence | Confidence | Gap |
|---|---|---|---|---|---|---|
| 1 | hard_gate | fails | Base pay ≥ $150k | JD states $70–85k | — | — |
| 2 | hard_gate | fails | Remote-only | JD requires 5 days on-site, "no exceptions" | — | — |
| 3 | must | fits | 8+ years growth leadership | 9 years, two Head/lead-level roles | high (from your account) | none |
| 4 | must | fits | Paid acquisition | Owned paid at two companies | medium-high | none |
| 5 | must | fits | Lifecycle/CRM | Owned lifecycle, deep in Braze | high | none |
| 6 | must | fits | Revenue scale and team leadership | $8M→$40M ARR; teams of 3–7 | high | none |
| 7 | preferred | unknown | SEO/content | Not in your material | — | evidence missing |
| 8 | preferred | unknown | Brand and PR | Not in your material | — | evidence missing |
| 9 | preferred | unknown | Partnerships | Not in your material | — | evidence missing |
| 10 | preferred | unknown | Sales ops | Not in your material | — | evidence missing |
| 11 | implied | unknown | E-commerce / B2B enablement domain | Your background is B2C subscription | — | domain gap [inferred] |

Confidence reflects only what you told me; I did not verify any of it.

## Gap recovery queue

- **Row 7–10 (SEO, brand/PR, partnerships, sales ops):** these would close if you have any real work in those areas, such as a content program, a press placement, a partner channel, or a sales handoff you ran. These gaps only matter if the role were otherwise viable, which it isn't yet.
- **Row 11 (domain):** a real gap if the company sells to merchants rather than consumers. Closing it would take the company's own description of its customers, which I don't have.

## Opportunity risk register

| Class | Severity | Signal | Basis |
|---|---|---|---|
| Pay mismatch | high | $70–85k against a $150k floor, for an 8+ year leadership role | [grounded] JD figure; [generic] band |
| Location mismatch | high | On-site 5 days, "no exceptions," against remote-only | [grounded] |
| Scope vs. resourcing | medium | Seven functions, team of one, "no bench" | [grounded] + [inferred] |
| Hours expectation | medium | "Evenings and weekends... is just who we are" | [grounded] |
| Undefined success | medium | "Success metrics will evolve as we learn" | [grounded] |
| Equity-led pitch | medium | "Meaningful equity upside" in place of market base pay | [grounded] |
| Unverified employer | open | I have not confirmed that Novaline exists as described, is hiring, or that this posting is live | not yet researched |

None of these is a finding about the company's honesty. Each is a term of the role as written.

## Application plan

Don't apply on this posting as written. Both hard gates fail, and no reframing of your CV changes either one. If you want to keep the company in view, the only useful step is a single written question to the recruiter: "Is the base range and the on-site requirement negotiable for a remote candidate?" If the answer is no, the decision stands.

## Evidence status

Research tier: L0 — no searches

| Target | Status | Reason |
|---|---|---|
| L1-1: Company site and careers page | skipped | Not run; research consent not yet given |
| L1-2: Role-family sweep (scope, title, pay) | skipped | Not run; research consent not yet given |
| L1-3: Hiring manager footprint | n/a | No hiring manager named |

The pay band and "market" comments above are [generic] patterns from my general knowledge, not checked against current data.

## Dossier offer

If you want, I can save this underwriting as `tuesday-dossier.md` so it carries into later steps.

## Upgrade menu

- **L1 research (up to 5 searches, 2 page fetches):** confirms Novaline exists as described, checks whether the posting is live, and pulls current role-family pay so the band is checked rather than estimated.
- **The live posting link or the recruiter's email domain:** lets the employer check run against the actual listing.
- **Evidence for SEO, PR/brand, partnerships or sales ops:** would raise rows 7–10 from unknown to a confident fit. This only matters if the location and pay gates change.

## Questions

1. Do you want me to run L1 research on Novaline and the pay band? It is capped at 5 searches and 2 fetches.
2. Do you have any real work in SEO, PR/brand, partnerships or sales ops? Even one example would move those rows from unknown.
3. Would you like me to draft the one-line question for the recruiter about pay and location?

*Response mode: reply with any of the three numbers, or "skip" to leave it.*

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.