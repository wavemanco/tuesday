**Decision: `conditional_go`.** Worth applying, but only if you can show forecasting and billing-data work. Your background matches the role's core. Two of its must-haves, owning the forecast and billing data, are gaps you'd need to answer for in interviews.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

**Fit ledger.** Read off the evidence map below.
- `hard_gate`: unclear: R7 (Bristol office, two days a week)
- `must_have`: direct: R2, R3 · adjacent: R1 · unclear: R4 · absent: R5
- `important`: direct: R6

R2 and R3 are your strongest matches. R1 is a credible bridge with a stated limit. R4 and R5 are the gaps that matter.

**Opportunity ledger.** The role is sound and the employer checks out: Quillfield is an established Bristol company, and the salary sits in the market band. Two open questions remain about how forecast accountability is shared with the CFO and what the role owns on the billing side (RR1, RR2).

- **Hard gates:** none failed; unconfirmed: R7 (Bristol office, two days a week); candidate constraints not given. I don't have your non-negotiables, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can show a forward-looking revenue view you built or owned, even a pipeline-weighted commit forecast (R4); (2) you have a credible account of billing or payments-transaction work with finance, or you present it honestly as a learning gap (R5); (3) the Bristol commute works for you (R7).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield, invoicing and payments software for UK builders' merchants; founded 2018, Bristol, 96 employees, Series A (£11M) April 2025 | `[grounded]` company About page (search snippet) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options | `[grounded]` posting |
| Market calibration | Median base £64,200, IQR £57,800–£70,400 for UK RevOps leads at B2B software companies | `[generic]` Ledgerline 2026 UK pay guide (n=438) — a band, not this employer's offer |
| Unknowns | Whether the role owns the forecast or prepares it for the CFO; reporting line; the billing-data scope | — |
| Contradictions | None found between posting and the sources checked | — |

The hiring manager, per the recruiter, is Tamsin Achebe. A public profile lists them as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. That makes it worth asking whether this role sits under them.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years in RevOps or sales ops at a B2B software company | must_have | adjacent | medium | transferability | Five years in sales ops at a B2B payments company, two of them running RevOps for the UK team. Payments is close to invoicing software, but it is not software, and the posting asks for software | `[grounded]` CV; `[inferred]` adjacency | Bridge case: name the payments-to-invoicing overlap, don't claim software experience |
| R2 | HubSpot or Salesforce administration | must_have | direct | high | none | Salesforce admin certified; rebuilt pipeline and renewal dashboards | `[grounded]` CV | none |
| R3 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily. "Modelling" isn't described, so confidence stays at medium | `[grounded]` CV | Work sample of a model you built would raise to high |
| R4 | Experience owning a revenue forecast (and running the quarterly forecast with the CFO) | must_have | unclear | low | discovery | You've never owned the company forecast, which finance did. You run the monthly pipeline review with the sales director, which is an input to a forecast, not one | `[grounded]` CV; `[inferred]` pipeline review as adjacent input | Gap G1 |
| R5 | Working with finance on billing or revenue data | must_have | absent | none | discovery | No billing data experience; revenue-data work with finance is not described | `[grounded]` CV | Gap G2 |
| R6 | Pipeline and renewal reporting for sales and finance | important | direct | high | presentation | Rebuilt pipeline and renewal dashboards. This is the posting's core reporting duty | `[grounded]` CV | Lead with it |
| R7 | Bristol office, two days a week (hybrid) | hard_gate | unclear | low | hard_gate | The posting states the location. Your location and willingness are not in what you've given me | `[grounded]` posting; candidate constraint not given | Gap G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R4, must_have) | discovery | Pipeline review with the sales director; no forecast ownership | The posting names a quarterly forecast with the CFO as a core duty, and it's the requirement most likely to be probed | Any commit or pipeline-weighted forecast you presented; a bookings or renewal forecast; a scenario model for a sales target | A forecast sheet, a pipeline-review deck, or a commit-vs-actual table | `[grounded]` CV; `[inferred]` that it's probed |
| G2 | Billing and revenue data with finance (R5, must_have) | discovery | No billing data; no finance-facing revenue work described | Billing data is named as a core duty and this is a must-have | Reconciling bookings to invoices or payments; revenue or deferred-revenue questions raised with finance; payments-transaction data | A reconciliation note, a finance-facing report, or a data dictionary | `[grounded]` CV; `[generic]` that invoicing-software roles weigh this heavily |
| G3 | Office attendance (R7, hard_gate) | hard_gate | Not in what you've given me | The Bristol two-day requirement is a hard gate if you can't meet it | — | — | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast ownership split with the CFO | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may build and present the forecast, with the CFO owning the number, or it may own the number outright | `[inferred]` from the duty against the absence of any stated decision rights | Does this role own the final forecast number, or prepare it for the CFO to sign off? | unresolved |
| RR2 | Reporting line under the Head of RevOps | unknown | — | Posting does not name a manager | The role may sit under Tamsin Achebe, which would change the scope and seniority read | `[grounded]` public title; `[inferred]` reporting line | Does this role report to the Head of Revenue Operations, and which parts of the function does that leader keep? | unresolved |
| RR3 | Billing data ownership | unknown | — | "own our CRM and billing data" | Ownership of billing data may be shared with finance, which would narrow the role's day-to-day | `[inferred]` from the duty against the absence of finance detail | Who owns the billing data day to day, and how does it reconcile with finance's ledger? | unresolved |
| RR4 | Salary in market band | positive_signal | — | "£61,500–£67,000 plus share options" | Pay is in line with the band for this role | `[generic]` Ledgerline band; `[grounded]` posting | none needed | noted |
| RR5 | Employer established | positive_signal | — | "Quillfield" | The employer exists as described and has funding and a headcount | `[grounded]` company About page (search snippet only) | none needed | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the renewal and pipeline dashboards (R6) and the SQL work (R3) | These are the strongest direct matches | `[grounded]` CV | pending your approval |
| E2 | Describe payments-company RevOps as the bridge to invoicing software; state the limit (no software-company experience) | Honest adjacency (R1) | `[inferred]` | pending your approval |
| E3 | Do not claim forecast ownership or billing-data work | Neither is on the CV (R4, R5) | `[grounded]` CV | — |
| Q1 | Ask RR1 and RR2 in the first screen | They decide the role's scope | `[grounded]` register | pending your approval |

Every line above needs your approval before it goes into a CV or application.

## Evidence status

Verified: R2, R3, R6 claims (from your CV). Unverified: R1 bridge (adjacent, not verified as software experience); R4 and R5 are gaps, not claims.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol", which returned the About page (quillfield.co.uk/about). Confirmed the employer exists and has 96 staff. I did not fetch the careers page, so the posting's live status is unverified |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software £60,000", which returned the Ledgerline 2026 pay guide. Market calibration for the salary line |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned a public profile (linkedin.example). Confirmed title and prior employer, used only for the reporting-line question |

## Upgrade menu

- A forecast sheet, commit-vs-actual table, or pipeline-review deck → R4 moves from `unclear` toward `adjacent`, or `direct` if you owned it.
- A reconciliation note or finance-facing report with billing or payments data → R5 moves from `absent` toward `adjacent`.
- A model or dashboard you built in Excel or SQL → R3 rises from `medium` to `high` confidence.
- The careers page fetch and the live posting → would close the posting's live status.
- Your Bristol availability and any salary floor or contract preference → R7 and the hard-gates line become checkable.
- Deeper research on Quillfield (funding rounds, leadership changes, recent hires; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want to prepare for the interview, the mock-interview skill handles rehearsal; this assessment doesn't cover that.

Three questions, tagged to their gaps:

1. **G1 (R4):** Have you ever built or owned any forward-looking revenue view, such as a pipeline-weighted commit forecast you presented to leadership? What did it get right or wrong? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. **G2 (R5):** Have you worked with invoice, billing, or payments-transaction data with finance, for example reconciling bookings to invoices? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. **G3 (R7):** Can you work in Bristol two days a week, and are there other constraints I should check, such as a salary floor or contract type? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.