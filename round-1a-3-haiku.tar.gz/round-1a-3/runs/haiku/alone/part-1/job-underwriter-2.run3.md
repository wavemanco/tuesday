**Not a waste of time, but a stretch: `conditional_go`.** You have no product-management title, and this posting makes 3+ years of PM experience a must-have. That makes the literal screen the main risk (RR2). Your case rests on whether the hiring manager reads your implementation and requirements work as product work.

**Fit ledger.**

- `must_have`: direct: R3, R8 · adjacent: R1 (3+ years product management), R2 (own the roadmap for a partner-facing API platform), R4 (write specs and drive delivery with two engineering squads), R7 (shipped API or platform products), R9 (stakeholder management across engineering, sales, customers) · unclear: R5 (define and track adoption metrics)
- `important`: adjacent: R6 (coordinate launches with sales and support) · unclear: R10 (agile delivery)

R3 — partner discovery, direct in substance and buried in your CV's implementation language; R1 and R2 — the bridges that carry the decision, with their limits named; R5 — no evidence either way.

**Opportunity ledger.** The scope is concrete: named squads and named outcomes (RR3, positive signal). The employer is not verified in this run, because search was refused (RR1). The adoption target is undefined (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** conditions for go are (1) the posting appears on Quartzline's own careers page (RR1); (2) you can speak concretely to a scope or prioritization call that engineering built (G1); (3) the bridge is stated as adjacent, never as roadmap ownership.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` your description |
| Mandate | Own the roadmap for a partner-facing API platform; run partner discovery; write specs; drive delivery with two squads; define adoption metrics; coordinate launches | `[grounded]` JD |
| First-year outcomes | Not stated | — |
| Market calibration | Not run; search refused, so no pay band | — |
| Unknowns | Reporting line, whether squads are product-owned, sales and support model, what adoption means here, salary | — |
| Contradictions | None found in the material you gave me | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management | must_have | adjacent | medium | transferability | Requirements and client-feedback work is PM-adjacent; no PM title, no owned roadmap | `[grounded]` CV | G1 |
| R2 | Own the roadmap for a partner API platform | must_have | adjacent | medium | transferability | Ran quarterly roadmap-input sessions collecting client feedback for product; that is input to a roadmap, not ownership | `[grounded]` CV | G1 |
| R3 | Run discovery with integration partners | must_have | direct | medium | presentation | Scoping workshops across 30+ client integrations, with requirements documents; the CV states it in implementation terms | `[grounded]` CV; `[inferred]` that scoping workshops are discovery work | Repositioning A2 |
| R4 | Write specs and drive delivery with two squads | must_have | adjacent | medium | transferability | Wrote requirements documents and integration architecture; coordinated engineers on custom builds; no squad ownership stated | `[grounded]` CV | G1 |
| R5 | Define and track adoption metrics | must_have | unclear | low | discovery | CV mentions UAT and go-live, but no usage or adoption measure | `[grounded]` CV silence | G2 |
| R6 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Go-live coordination with client teams; no sales or support work named | `[grounded]` CV | State only what you did |
| R7 | Shipped API or platform products | must_have | adjacent | medium | transferability | Shipped client integrations of our REST APIs end to end; did not build the product itself | `[grounded]` CV | A3 |
| R8 | Technical fluency: API docs, schemas | must_have | direct | medium | presentation | Postman, SQL and OpenAPI named; "comfortable" is self-report with no artifact | `[grounded]` CV | A4 |
| R9 | Stakeholder management: engineering, sales, customers | must_have | adjacent | medium | transferability | Engineering and customer coordination is direct; sales is not evidenced | `[grounded]` CV | A3 |
| R10 | Agile delivery | important | unclear | low | discovery | The CV names no delivery method | `[grounded]` CV silence | G3 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | The product bridge (R1, R2, R4, R7) | transferability | Requirements, roadmap input and integration delivery, with no owned roadmap or product decisions on the CV | One prioritization or scope decision you made that engineering then built, with the outcome | `[grounded]` CV |
| G2 | Adoption measurement (R5) | discovery | Go-live and UAT appear; no usage or adoption figure | Any adoption or usage measure you tracked after a go-live | `[grounded]` CV silence |
| G3 | Agile delivery (R10) | discovery | No method named | The delivery method your squads used and your part in it | `[grounded]` CV silence |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified in this run | risk_signal | medium | "Quartzline … Series B" (your description) | Search was refused, so the company and posting are unverified here. The posting may be stale, the company may differ from the description, or the role may not be live | `[generic]` pattern for companies of this size; not a claim about this one | Can you point me at this role on your own careers page, and who would I be interviewing with? | unresolved |
| RR2 | Literal 3+ year PM screen | risk_signal | medium | "3+ years product management experience (must-have)" | A resume screen may reject on titled PM years before it reads the implementation work | `[generic]` pattern for PM must-haves; `[grounded]` CV has no PM title | Would you consider a candidate whose product experience comes from implementation and integration work, and what would you need to see? | unresolved |
| RR3 | Concrete scope and resourcing | positive_signal | — | "two engineering squads" | The role has defined scope and named teams | `[grounded]` JD | How many squads report to this role, and what does each own? | noted |
| RR4 | Adoption target undefined | unknown | — | "define and track adoption metrics" | The JD asks for metrics without a target or baseline | `[inferred]` from the JD's silence on targets | What adoption metric will this role be measured on in year one, and what is the baseline? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the posting on Quartzline's own careers page before applying | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Rewrite implementation bullets using your own terms: "ran scoping workshops for 30+ client integrations of our REST APIs," "wrote requirements documents and integration architecture," "ran quarterly roadmap-input sessions collecting client feedback for product." Do not write "owned the roadmap" or "discovery" for your own work | R3, R2 | `[grounded]` CV sentences, each quoted | resume_edits_pending_approval |
| A3 | Pitch the bridge as "I have shipped the integrations and fed the roadmap; I have not owned one," not as product ownership | R1, R2, R7, R9 | `[grounded]` CV; limit `[grounded]` the absence of any owned roadmap | pending your approval |
| A4 | Send one sanitized work sample: a requirements document or integration architecture you wrote | R3, R8 | `[generic]` PM screens often ask for an artifact | pending your approval |

**Evidence status**

Verified: none yet. Every CV claim is self-reported.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search was refused. Would have checked RR1 and whether the posting is live |
| 2. Role-family sweep | unavailable | Search was refused. Would have set the market calibration, which is absent here |
| 3. Hiring manager's public footprint | n/a | No name was given |
| Unnumbered: Quartzline funding search | unavailable | Outside the L1 targets; refused. Would have fed the company-diligence checks |

**Dossier offer:** I can save this as `tuesday-dossier.md`, which mock-interview can later use to rehearse the screen.

**Upgrade menu**

- Search permission granted → the two L1 targets re-run with the remaining budget (up to 2 more searches and 2 fetches).
- A link to the Quartzline posting → confirms RR1 and checks the JD's exact wording.
- A sanitized requirements document or integration architecture you wrote → R3 and R4 move to `high`.
- One scope decision you made that engineering built → R2 and R4 strengthen (G1).
- Adoption figures from a go-live you ran → R5 moves off `unclear` (G2).

**Questions**

G1 — Think of one scope or feature decision on an integration project where your call went to engineering and was built. What did you decide, who signed off, and what changed?

G2 — Did you ever build a tool or workflow that others adopted, for example an internal request-triage tool? Did you track whether people used it, and what did you measure?

G3 — Which delivery method did the squads you worked with use: sprints, Kanban, or something else? Did you run any of those ceremonies yourself?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.