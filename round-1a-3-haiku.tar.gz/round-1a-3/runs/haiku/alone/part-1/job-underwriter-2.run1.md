## Decision snapshot

- **Decision:** `conditional_go`. Worth a few targeted applications, not a broad push. The must-have experience line is a real gap, and the posting alone won't close it.
- **Fit ledger:**
  - **Must-have, meets:** technical fluency (API docs, schemas); stakeholder management across engineering, sales and customers.
  - **Must-have, partial:** shipped API or platform products; discovery with integration partners.
  - **Must-have, gap:** 3+ years of product management experience.
  - **Preferred or implied, gap:** owning a roadmap; defining and tracking adoption metrics.
  - **Unknown:** agile delivery (not on the resume).
- **Hard gates:** none stated in the JD. Your non-negotiables (pay, location, schedule) weren't provided, so those checks are unknown.
- **Confidence:** low on the years-of-PM line. The other rows are medium to high on what the resume states.

**Research tier: L0, no searches.** Nothing about Quartzline below is verified beyond the JD.

## Role reality

- **Role** `[grounded]`: Product Manager, Platform APIs. Owns the roadmap for a partner-facing API platform, runs partner discovery, writes specs, drives delivery with two engineering squads, defines adoption metrics, and coordinates launches with sales and support.
- **Organization** `[grounded]`: Quartzline, B2B logistics tech, about 150 people, Series B. Nothing else checked.
- **Scope read** `[inferred]`: a platform PM at a Series B with two squads. Expect you to set priorities and defend them, not just document them.
- **Market calibration** `[generic]`: platform PM roles at this stage often ask for prior PM ownership. Solutions, implementation and integrations people are a common route into them, but that is a pattern, not a fact about this employer.
- **Compensation** `[grounded]`: not stated. Withholding it is itself worth a question before you spend time on this.

## Evidence map

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | Must-have | 3+ years PM experience | Gap | Low | Experience | No PM title. Seven years of adjacent work: requirements documents, roadmap-input sessions, the integration playbook. Whether that counts is the employer's call. |
| 2 | Must-have | Shipped API or platform products | Partial | Medium | Capability | Thirty-plus REST API integrations delivered end to end. You implemented the platform for clients; the evidence doesn't show you shipped it. |
| 3 | Must-have | Technical fluency (docs, schemas) | Meets | High | None | Postman, SQL, reading OpenAPI specs. |
| 4 | Must-have | Stakeholder management | Meets | High | None | Coordinated your engineers, client engineers and PMs on custom builds. |
| 5 | Must-have | Agile delivery | Unknown | Low | Presentation | Not on the resume. |
| 6 | Preferred | Own the roadmap | Gap | Low | Transferability | Roadmap-input sessions show you gathered input, not that you owned the decisions. |
| 7 | Preferred | Partner discovery | Partial | Medium | Transferability | Scoping workshops and quarterly client-feedback sessions are close to this. |
| 8 | Preferred | Define and track adoption metrics | Gap | Low | Discovery | No metric on the resume. |
| 9 | Preferred | Launch coordination with sales and support | Partial | Medium | Presentation | Go-live and UAT work is the same motion, from the implementation side. |

**Unconfirmed lead:** the note that you built an internal request-triage tool that support agents adopted. I haven't counted it. If it's real, it would bear on rows 2 and 8, and that is the strongest thing you could add to this application.

## Gap recovery queue

- **Row 1, years of PM experience.** Closes only with evidence of PM-type ownership, such as the triage tool, or decisions you drove. Adjacent years alone won't meet it.
- **Row 2, shipped product.** The triage tool, if confirmed and owned by you, would partly close this.
- **Row 6, roadmap ownership.** Needs an example where you decided what got built and defended it.
- **Row 8, adoption metrics.** Needs any number you tracked, such as usage, time saved or request volume.
- **Row 5, agile.** Needs a statement of how you worked with sprints.

## Opportunity risk register

- **Posting-level risk** `[inferred]`: the must-have years line may be a hard filter at screening. If it is, your application gets read against it first.
- **Compensation mismatch** `[grounded]`: none stated, so unverified. Ask before investing time.
- **Failed attribution** `[not checked]`: I didn't confirm Quartzline is a live, hiring employer. Check it against the live posting or the company's careers page before applying.
- **No red flags** in the JD text.

## Application plan

1. **Be honest about the title.** Describe your work as the integration and implementation lead it was. Don't use "product manager" for work that wasn't. A reader who checks will notice the gap, and an overclaim costs more than the gap.
2. **Lead with the strongest evidence.** Thirty-plus integrations, the playbook, and the requirements documents for custom builds.
3. **Add the triage tool only if it's confirmed,** and describe only what you actually owned.
4. **Target adjacent titles too:** technical PM, integrations PM, implementation or solutions-to-product roles, and product operations at API companies. These may fit better than this posting.
5. **Get a referral if you can.** A warm introduction does more for a stretch application than a cold one.

*Resume edits and outreach text stay pending your approval; nothing is finalized until you say so.*

## Evidence status

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | skipped | L0 tier; no search consent |
| 2 | Role-family sweep (scope, title, pay) | skipped | L0 tier; no search consent |
| 3 | Hiring manager's public footprint | n/a | No name given |

## Dossier offer

If you want, I can save this as `tuesday-dossier.md` so the findings carry into later sessions.

## Upgrade menu

- **Triage-tool details** (what you built, what you owned, how many agents used it, how adoption showed up): could move rows 2 and 8 from gap to partial or meets.
- **Any roadmap or prioritization decision you drove**, even informal: could move rows 1 and 6.
- **Quartzline's live posting or careers page, plus L1 research** (up to 5 searches and 2 page fetches): would show whether the posting is current and whether the years line is a real filter.
- **Pay range, location and your non-negotiables:** would let the hard-gate checks run.

## Questions

1. **Triage tool:** Did you build it? What did you personally own (spec, build, rollout, decisions), how many support agents used it, and how did you know they adopted it?
2. **Prioritization:** Have you ever decided what got built, even informally, such as choosing which client requests went into the roadmap input? What happened as a result?
3. **Agile:** Did your implementation work run in sprints with an engineering team? What did you do in planning or acceptance?

Answer any or all in prose. "Skip" on any of them is a valid answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.