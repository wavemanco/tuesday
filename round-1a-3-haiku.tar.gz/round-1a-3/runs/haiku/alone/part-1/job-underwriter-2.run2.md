**Short answer: not wasted, but expect a screen on the 3+ years. Status: `conditional_go`.** You have real product-adjacent evidence and strong technical and stakeholder evidence. The must-have that you cannot word your way past is the titled product-management years (R1). Applying is worth it if you target roles where that requirement is negotiable, and you go in with the transfer case stated plainly.

Research tier: L1 — searches 2 of 5, fetches 0 of 2. Both searches were refused by a permission prompt, so the employer and market checks did not run.

## Decision snapshot

- **Status:** `conditional_go`. Apply, once the employer checks below pass and the screen question is answered. R1 is the one row your wording cannot fix.
- **Fit ledger:**
  - `must_have` — direct: R3, R4 · adjacent: R2 (shipped API or platform products) · absent: R1 (3+ years product management experience)
  - `important` — direct: R5, R6 · unclear: R7 (agile delivery)
  - `preferred` — adjacent: R9 (launch coordination with sales and support) · unclear: R8 (define and track adoption metrics)

  R1 — absent, the titled years; R2 — adjacent, limit named; R7 and R8 — unclear, questions below.
- **Opportunity ledger:** The posting is concrete, with two squads, partner discovery and adoption metrics (RR4, positive). Two entries carry risk: the employer is unverified (RR1) and the 3+ years may be screened literally (RR2). Decision rights are unknown (RR3).
- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** For `conditional_go`, the conditions are: (1) the employer verifies on its own site (RR1); (2) the recruiter says whether the 3+ years is a hard screen or can be met by platform-integration experience (RR2); (3) you can show at least one roadmap decision you influenced, not just requests you passed along (RR3). If (2) is a hard screen, the status moves toward `no_go` for titled-PM roles.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD; not verified, searches refused |
| Mandate | Own the roadmap for a partner-facing API platform | `[grounded]` JD |
| Scope | Two engineering squads; partner discovery; launch coordination with sales and support | `[grounded]` JD |
| Outcomes | Define and track adoption metrics | `[grounded]` JD |
| Market calibration | Not run: the salary and role-family searches were refused, so there is no band to compare against | — |
| Unknowns | Decision rights, whether 3+ years is screened literally, salary, contract basis, reporting line | — |
| Contradictions | None visible in the JD alone | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management experience | must_have | absent | none | transferability | No PM title in seven years. Adjacent work exists (R2, R6), but it does not count as PM years. A titled-years requirement is not a gate, so it stays a must-have, graded on fit | `[grounded]` CV; `[generic]` that titled years are often screened literally | G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ REST integrations delivered end to end. She shipped client integrations, not a platform product she owned | `[grounded]` CV, self-reported; limit: no platform release ownership stated | G2 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI named. CV self-report, not yet probed | `[grounded]` CV | none |
| R4 | Stakeholder management across engineering, sales, customers | must_have | direct | medium | presentation | Coordinated vendor engineers, client engineers and PMs; client feedback sessions. Sales is not claimed | `[grounded]` CV | Add sales coordination only if true |
| R5 | Partner and customer discovery | important | direct | medium | presentation | Quarterly roadmap-input sessions collecting client feedback for product. The CV buries this in one line | `[grounded]` CV | Proposed edit A4 |
| R6 | Write specs, drive delivery with engineering | important | direct | medium | none | Requirements documents and integration architecture; coordinated engineers on builds | `[grounded]` CV | none |
| R7 | Agile delivery | important | unclear | low | discovery | Not stated in the CV | `[grounded]` CV silence | Q3 |
| R8 | Define and track adoption metrics | preferred | unclear | low | discovery | No metric work stated. The integration playbook may have included adoption tracking; unknown | `[grounded]` CV silence; `[inferred]` that it may exist | Q3 |
| R9 | Launch coordination with sales and support | preferred | adjacent | medium | transferability | Go-live and UAT coordination with client teams; not sales or support launches | `[grounded]` CV | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Titled PM years (R1) | transferability | Seven years in implementation and requirements work; no PM title | A must-have that screening may apply literally | A feature you specified from client input that product built; a roadmap call you influenced; a prioritization you ran for a client's custom build | A spec or requirements doc that shipped; a roadmap-input summary showing what product did with it | `[grounded]` CV; `[generic]` that screens often read titles first |
| G2 | Platform product shipping (R2, R9) | transferability | 30+ integrations delivered; you did not own the platform release | Limit: you carried client builds, not a product's release cycle | An integration pattern that became a reusable template; a go-live you ran that changed the next client's scope | Your integration playbook (sanitized); one integration spec with its go-live outcome | `[grounded]` CV; `[inferred]` the limit from the CV's wording |

The memory lead about a request-triage tool is not in this queue as evidence. It is unconfirmed; Q2 asks about it.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The employer may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer. Searches were refused, so this is unverified, not disproved | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | 3+ years may be screened literally | risk_signal | medium | "3+ years product management experience (must-have)" | The requirement may filter applications before a human reads the platform work | `[generic]` pattern for PM postings; `[inferred]` from the JD's must-have label | Is the 3+ years of product management a hard screen, or would strong platform-integration experience be considered? | unresolved |
| RR3 | Decision rights unstated | unknown | — | "Own the roadmap for our partner-facing API platform" | The role may own input and prioritization while engineering or sales sets the final order | `[inferred]` from the JD's ownership language against its silence on decision rights | Which roadmap decisions does this role make alone, and which go to engineering leadership or sales? | unresolved |
| RR4 | Concrete scope and metrics | positive_signal | — | "define and track adoption metrics" | Success is defined and measurable, which makes the role easier to evaluate | `[grounded]` JD | What adoption metric is this role accountable for in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the posting on Quartzline's own careers page before investing effort | RR1 | `[generic]` cheap-loss rule | pending your approval |
| A2 | Ask the recruiter whether 3+ years is a hard screen | RR2, R1 | `[generic]` pattern | pending your approval |
| A3 | Lead applications with the transfer case: integrations, requirements and roadmap-input work, stated with its limit | R1, R2 | `[grounded]` CV rows | pending your approval |
| A4 | Proposed CV edit: "Ran quarterly roadmap-input sessions that carried client feedback to product" moved up to a headline bullet. Do not add "product manager", "owned the roadmap" or any metric you cannot document | R5 | `[grounded]` CV; reframing audit: no new claims | pending your approval |
| A5 | Build a one-page work sample from your own integration work: an adoption or time-to-go-live analysis, sanitized | R8, R2 | `[inferred]` that it would raise R2 | pending your approval |

Do not present this as "PM experience". The honest line is "product-adjacent integration work with a stated limit". Approve each proposed wording before any of it goes into a CV or outreach.

## Evidence status

Verified: none yet. Unverified leads: a request-triage tool that support agents adopted (prior conversation, `memory_lead`; not evidence until you confirm it). Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused by a permission prompt. Would have verified the employer and the live posting (RR1) |
| 2. Role-family sweep | unavailable | Refused; would have set the market band for PM pay and scope at this seniority (no band is given here) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Allowing web search would verify Quartzline and its posting (RR1), and set a market band for the role (role reality).
- The recruiter's answer on the 3+ years screen would settle RR2 and R1's path.
- A roadmap-input summary or a shipped spec would move R1 and R5 toward a stronger claim.
- The hiring manager's name would let the application lead with the verified story for that reader.
- An adoption metric or work sample would move R8 from unclear and R2 from adjacent.

Tell me whether to run the two blocked searches, and I'll rerun the employer and market checks.

Q1 (R1, R2, RR3): Have you ever decided what a product team built, not just reported what clients asked for? Name one roadmap call, what you decided, who else was in it, and what happened.

Q2 (memory lead, R2): Did you build an internal request-triage tool that support agents adopted? If so: what it did, roughly when, how many agents used it, and whether you have a copy or a description.

Q3 (R7, R8): Did you define or track adoption of any integration or API, such as usage, time to go-live or failed calls? Give one example and the number you watched.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.