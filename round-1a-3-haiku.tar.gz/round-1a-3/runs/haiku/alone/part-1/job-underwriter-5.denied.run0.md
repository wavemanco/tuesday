# Senior Data Engineer, Pellucid Learning

## Decision snapshot

**Worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1, R2
- `must_have`: direct: R3, R4, R5, R6, R7 · unclear: R8
- `important`: adjacent: R9, R10

Your core stack matches the posting. The gaps are BigQuery (R10), which you've never used, and ingestion from app and CRM sources (R8), which your CV doesn't mention.

**Opportunity ledger.** A specific, reasonably paid posting. It doesn't show who you'd report to, and its scope is wider than a typical senior remit.

- **Hard gates:** none failed. Unconfirmed: R1 (location and work authorization for remote US or Denver) and R2 (base pay floor against $148,000–$166,000). Your constraints weren't given, so checks against them are unknown.
- **Severe red flags:** none in the posting text.
- **Conditions for go:** (1) R1 and R2 confirmed against your constraints; (2) the posting and company checked on the company's own careers page or against the recruiter's email domain (RR1; web search was not available, so this check is yours); (3) R8 and R9 confirmed: either you've built this work, or you know this role won't own it (RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver. 264 employees. Series C, $52M, February 2026 | `[grounded]` About page as you pasted it; not checked against any other source |
| Mandate | Build and run the pipelines behind tutoring reporting: ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts analysts depend on | `[grounded]` JD |
| First-year outcomes | Not stated | — |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | Three areas in one role: source ingestion, warehouse, and contracts. Typical senior scope is one domain's pipelines | `[inferred]` from the JD's three named areas, against the `[generic]` pattern |
| Market calibration | Posting band $148,000–$166,000, midpoint $157,000. Pay report for Senior at Series B–D: median $151,000, IQR $139,000–$163,500. The midpoint sits above the median, and the top of the band is above the IQR top. "Senior" typically means 5–8 years; you have 6 | `[generic]` Datawright 2026 report, recruiter-supplied and not verified by me; `[grounded]` JD for the band |
| Unknowns | Hiring manager (none named); team size; whether you'd be the only data engineer; whether BigQuery is in place now or being moved to; equity value; whether the role defines contracts or only consumes them | — |
| Contradictions | None found between the JD and the About page as provided. Live careers page not checked | `[grounded]` provided text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location and work authorization for remote (US) or Denver | hard_gate | unclear | none | hard_gate | Nothing in your background covers location or authorization, so the gate can't be checked | `[grounded]` JD; candidate input missing | You state location and work authorization |
| R2 | Base pay floor against $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your floor isn't given, so the gate can't be checked | `[grounded]` JD; candidate input missing | You state your base floor |
| R3 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a B2B payroll company, stated. No dates or references checked | `[grounded]` CV | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Both used daily, stated. No sample work to inspect | `[grounded]` CV | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | About 180 dbt models on Snowflake, stated. The posting says "a cloud warehouse" generically, so Snowflake meets it. BigQuery is G1 | `[grounded]` CV | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration, stated | `[grounded]` CV | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, stated. No artifact to inspect | `[grounded]` CV | none |
| R8 | Pipelines ingesting from the app and CRM | must_have | unclear | none | discovery | The JD makes this the first build task. The CV names no source systems | `[grounded]` JD; CV silent | G2 |
| R9 | Data contracts analysts depend on | important | adjacent | low | transferability | Great Expectations is the nearest neighbour, but a test suite isn't a contract with consumers. The CV doesn't say you defined or versioned contracts | `[inferred]` adjacency from R7 | G3 |
| R10 | Warehouse in BigQuery (named in the mandate) | important | adjacent | medium | transferability | Your Snowflake dbt and SQL work carries over. You've never used BigQuery | `[grounded]` CV (Snowflake, no BigQuery); `[generic]` on what transfers | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R10) | transferability | Snowflake dbt and SQL work, no BigQuery | The JD names it as the warehouse. The gap is tool-specific, not capability | Snowflake dbt modelling and warehouse work | A small BigQuery project you can describe accurately, or any BigQuery work from before | `[grounded]` CV; `[generic]` on what transfers |
| G2 | Source-system ingestion (R8) | discovery | Nothing on app or CRM ingestion | The first responsibility in the JD. If it's absent from your work, it's the biggest fit question | Any ingestion you ran at the payroll company from a SaaS or product source, if there was one. The CV doesn't say | A sanitized description of one ingestion pipeline: source, volume, schedule, failure handling | `[grounded]` JD; CV silent |
| G3 | Data contracts (R9) | transferability | Great Expectations validation, no stated contracts with consumers | The JD lists contracts as something analysts depend on | Schema or freshness checks that downstream consumers relied on, if you had any | One sanitized example of a contract or consumer-facing check | `[inferred]` adjacency from R7 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not independently checked | unknown | — | "Series C ($52M, February 2026)" | Hypotheses, none ranked: the posting is live and the company is as described; the posting is stale or closed; the company differs from its About page. No search could rule any of these out | `[grounded]` web search not granted | Check the live posting on the company's careers page, and check the recruiter's email domain against the company | unresolved |
| RR2 | Base band against the market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The band sits inside the Series B–D senior range; the midpoint is above the median. Equity value unknown | `[grounded]` JD; `[generic]` pay report | Compare your floor to the band (R2) | noted |
| RR3 | Hiring manager and team not named | unknown | — | "the data contracts our analysts depend on" | You may be the only data engineer, carrying the whole pipeline estate | `[inferred]` from the JD's breadth and the unnamed manager | Team size, and whether there's a manager and other data engineers | unresolved |
| RR4 | Scope spans three areas | risk_signal | medium | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | More than the usual senior remit of one domain. The first year could be heavier than the title suggests | `[inferred]` JD scope against `[generic]` typical senior scope | Whether ingestion and contracts sit with this role or with others | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the posting is live on the company's careers page, and that the recruiter's email domain matches the company | RR1. Until this is done, a go stays conditional | `[grounded]` RR1 | proposed |
| A2 | Tell me your location, work authorization and base floor | R1, R2 are hard gates and unconfirmed | `[grounded]` evidence map | proposed |
| A3 | Ask the recruiter: is BigQuery live now or being migrated to? Is this the only data engineering role? Who's the hiring manager? Does this role own ingestion and contracts? | R8, R9, RR3, RR4 | `[grounded]` gaps and risks | proposed |
| A4 | Before applying, build a small BigQuery project you can describe accurately | G1. Built work, not a claim. Until then, R10 stays adjacent | `[generic]` pattern | proposed |

## Evidence status

Verified: none yet. Every claim rests on your CV or the text you pasted, not on checked sources.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page: entity, stage, posting live and consistent | unavailable | Web search wasn't granted. The one search for this target was refused, and I didn't retry. Would move: organization and contradictions rows, RR1 |
| 2 | Role-family sweep: market scope, title, pay for this seniority | unavailable | Same refusal. Would move: market calibration, RR2 |
| 3 | Hiring manager's public professional footprint | n/a | No name given. The posting names none |

## Upgrade menu

- **Location and work authorization (your statement):** resolves R1, the remote-US or Denver gate.
- **Base pay floor (your statement):** resolves R2.
- **Live careers-page link or the recruiter's email domain:** runs the RR1 check. Without it, the decision stays conditional.
- **Web search permission:** unlocks targets 1 and 2. At L1 that's up to 5 searches and 2 page fetches, to confirm the employer and the pay band.
- **Deeper diligence (L2), offered once:** funding, leadership churn, public employee reports and recent news. Up to 5 more searches and 2 more fetches. Run only on your say-so.
- **A sanitized ingestion example (G2):** moves R8 from unclear toward direct, if it's real work.
- **A sanitized contract or consumer check (G3):** moves R9 from adjacent toward direct.
- **A BigQuery project (G1, after you build it):** moves R10 toward direct.
- **A reference or dated CV entry:** lifts R3 to high confidence.

If you want this saved as a file, I can write `tuesday-dossier.md` once these answers are in.

1. Where are you based, and can you work in the US without sponsorship? (R1)
2. What base salary is your floor, and does equity change your answer? (R2)
3. Have you built ingestion from application or CRM sources, or defined data contracts that consumers relied on? If so, name the sources and what the contracts covered. (R8, R9)

Answer any, all or none. "Skip" is a fine answer, and each question stands alone.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.