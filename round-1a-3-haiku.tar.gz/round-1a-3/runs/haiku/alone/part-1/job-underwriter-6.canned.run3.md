**Yes, on conditions: `conditional_go`.** R2, R3, R4a and R7 are direct, so your years, Salesforce work, SQL and pipeline and renewal reporting match. R5 (owning the forecast) and R6 (billing data with finance) are the gaps that decide it.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, two office days a week)
- `must_have`: direct: R2, R3, R4a · adjacent: R4b (spreadsheet modelling), R5 (owning a forecast) · absent: R6 (working with finance on billing or revenue data)
- `important`: direct: R7 (pipeline and renewal reporting)

R2, R3, R4a, R7 are direct on years, Salesforce, SQL and reporting; R4b and R5 are adjacent with limits named; R6 is absent; R1 is unconfirmed.

**Opportunity ledger.** Mostly sound, with one open hole: the role isn't confirmed on the employer's own careers page (RR2), and who signs off the forecast number is unknown (RR3). Two entries run the other way: the stated pay sits near the market median (RR1), and the hiring manager's public background overlaps yours (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, two office days a week); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1: you can do two office days a week in Bristol; (2) RR2: the role is live on Quillfield's careers page before you invest in the application; (3) R5 and R6 are presented as adjacent, never as owned forecast or billing experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; Bristol; about 96 staff; Series A (£11M, April 2025) | `[grounded]` search snippet of the company's About page (not fetched) |
| Mandate | Own the CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Working pattern | Bristol hybrid, two days a week in the office | `[grounded]` JD |
| Pay | £61,500–£67,000 plus share options | `[grounded]` JD |
| Scope read | Data ownership plus a finance-facing forecast is broader than a pure RevOps analyst role | `[inferred]` from the responsibilities listed |
| Market calibration | The stated band sits inside the interquartile range for this title, close to the median: median £64,200, IQR £57,800–£70,400 | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide (search snippet, n=438), one survey, not this employer's offer |
| Unknowns | Who signs off the forecast; whether billing data sits with finance or with this role; reporting line | — |
| Contradictions | None between the JD and the company's About page | `[grounded]` search snippet; careers page role not found (RR2) |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two office days a week | hard_gate | unclear | none | hard_gate | Your location and travel constraint weren't given, so the gate is not settled | `[grounded]` JD | Closing question Q1 |
| R2 | 4+ years in RevOps, sales ops or analytics at a B2B software company | must_have | direct | medium | none | Five years in sales ops, last two leading UK RevOps. Years and function are direct; the sector is B2B payments, which is adjacent to software | `[grounded]` your intake prose (self-report) | E2 |
| R3 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified; self-reported, not yet inspected | `[grounded]` intake | none |
| R4a | Strong SQL | must_have | direct | medium | none | SQL weekly | `[grounded]` intake | none |
| R4b | Strong spreadsheet modelling | must_have | adjacent | low | transferability | Excel daily is use, not evidenced modelling. The limit is that no model build is stated | `[inferred]` from "Excel daily" | Attach a model you've built, if you have one |
| R5 | Experience owning a forecast; running the quarterly forecast with the CFO | must_have | adjacent | low | transferability | You've never owned the company forecast; finance did. The monthly pipeline review with your sales director is the input side. Limit: no forecast ownership and no CFO-facing sign-off | `[grounded]` intake; `[inferred]` adjacency | Closing question Q2; G1 |
| R6 | Working with finance on billing or revenue data | must_have | absent | medium | capability | You've never worked on billing data. Renewal and pipeline data are revenue-side but not billing | `[grounded]` intake | G2 |
| R7 | Building pipeline and renewal reporting | important | direct | medium | none | Rebuilt the pipeline and renewal dashboards | `[grounded]` intake | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R5, must_have) | transferability | Monthly pipeline review with the sales director; no forecast ownership | A must-have, and the JD makes the quarterly forecast a core duty | Building forecast inputs, pipeline-to-forecast reconciliation, forecast-vs-actual reviews with sales | A forecast pack or review deck you helped prepare | `[grounded]` intake; `[inferred]` adjacency |
| G2 | Billing and revenue data with finance (R6, must_have) | capability | No billing data work | The JD names billing data as owned by the role, so this is the largest difference | Revenue reconciliations with finance; renewal-to-invoice checks | A finance-facing reconciliation or data dictionary you worked on | `[grounded]` intake; `[generic]` that billing ownership is probed in this role family |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Stated pay inside the market band | positive_signal | — | "£61,500–£67,000 plus share options" | Pay sits near the median for this title | `[grounded]` JD figure; `[generic]` band from one 2026 survey | Is £61,500–£67,000 fixed for this role, and how do the share options vest? | noted |
| RR2 | Role not confirmed on the employer's careers page | risk_signal | medium | "Revenue Operations Lead, Quillfield" | The posting may be stale or aggregated, or the role may not sit on the company's own careers site. The company itself appears real (Bristol, about 96 staff, Series A) | `[generic]` pattern for aggregator postings; `[grounded]` search results | Is this role live on Quillfield's own careers page, and who would I be interviewing with? | unresolved |
| RR3 | Forecast sign-off split unknown | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may prepare the forecast while the CFO holds the number, or may own it outright | `[inferred]` from "with the CFO" against silence on sign-off | Who signs off the quarterly forecast number, and what does this role own versus the CFO? | unresolved |
| RR4 | Hiring manager's background overlaps yours | positive_signal | — | Public profile: "Head of Revenue Operations, Quillfield … previously sales operations manager at Corvane Payments" | The hiring manager came up through sales operations at a payments firm, as you did | `[grounded]` public profile snippet (not fetched) | What would the first 90 days need to deliver on the forecast and billing data? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Present the pipeline and renewal dashboards and the monthly pipeline review as forecast-input work; don't call it forecast ownership | see R5, R7 | `[grounded]` intake | pending your approval |
| E2 | Describe the sector as B2B payments, not software | see R2 | `[grounded]` intake | pending your approval |
| A1 | Before investing in the application, confirm the role is live on Quillfield's careers page and ask the recruiter for the link | see RR2 | `[generic]` aggregator pattern | pending your approval |
| A2 | Prepare a straight answer on billing data: no billing work yet, and a specific plan to learn their data model | see R6, G2 | `[grounded]` intake | pending your approval |
| P1 | Lead with the sales-ops-to-RevOps path; the hiring manager's public background is in the same kind of role | see RR4 | `[grounded]` profile snippet | pending your approval |

## Evidence status

Verified: none yet. Everything above is your self-report at intake, so it stays at `medium`.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol" (returned quillfield.co.uk/about, from its snippet, not fetched) and "Quillfield careers Revenue Operations Lead" (no results). Moved organization and RR2 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software 2026" → Ledgerline 2026 UK Revenue Operations Pay Guide (ledgerline.example/2026-uk-revenue-operations-pay-guide), snippet. Moved market calibration and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" → public profile (linkedin.example/in/tamsin-achebe), snippet, matching name and employer. Moved RR4 and P1 |

The user link read is the posting at jobs.tallyboard.example, which is an aggregator page.

I haven't fetched the company's About page or the salary guide, so those facts rest on search snippets.

The posting is on an aggregator; the company itself was found, but the role was not.

Dossier: I can write this up as `tuesday-dossier.md`, so the register and the open questions travel with you.

## Upgrade menu

- Confirming the Bristol office pattern → R1 closes.
- A live careers-page link or the recruiter's confirmation → RR2 closes.
- Who signs off the forecast → RR3 and R5 might move from adjacent to direct-with-limits.
- Any artifact showing billing or revenue reconciliation work, even done alongside finance → R6 could move from absent.
- A deeper research pass on Quillfield (leadership changes, funding, staff reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

**Q1 (R1):** Can you work two office days a week in Bristol? Is that a problem for you?

**Q2 (R5):** Have you ever contributed inputs to a forecast, or reviewed one with finance, even without owning the number? What did you do?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.