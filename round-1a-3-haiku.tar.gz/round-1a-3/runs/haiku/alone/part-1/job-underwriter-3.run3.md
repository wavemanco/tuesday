**Decision: no-go.** Two of your hard constraints fail on the posting's own terms, and no fit on the rest of the page changes that.

**Decision snapshot**
- **Fit:** strong on experience. Nine years, $8M→$40M ARR, SQL/GA4/Braze, paid and lifecycle ownership, and the 8+ years requirement is met. [grounded]
- **Hard gates:** two fail.
  - **Pay:** posted $70–85k base against your $150k floor. The top of the range is $65k below your floor, about 43% under it. [grounded]
  - **Location:** on-site in Austin 5 days a week, "no exceptions," against remote-only from Portland. [grounded]
- **Opportunity:** pay and location are the two terms the role states as fixed, so there is no negotiation path I can see from the posting. The "team of one" scope and the evenings-and-weekends language are secondary signals, not gates.

**Research tier:** L1 — searches 2 of 5, fetches 0 of 2. Both searches were refused by a permission denial, so no results came back.

**Role reality**
- **Scope:** Head-level ownership of seven functions (paid, SEO/content, lifecycle, brand, PR, partnerships, sales ops) with no team to start. Your track record is leading teams of 3–7 with a budget you controlled, so the role is a different shape from what you've run. [grounded]
- **Compensation:** $70–85k base is low for a Head-level growth role at a Series A company. [generic, from general market pattern, not verified this session]
- **Stated profitability:** "profitable since day one" is the company's claim, unverified. [grounded as claim]
- **Contradictions:** the title and the 8+ year requirement point to a senior leader; the pay and "team of one" point to a much more junior, stretched hire. [inferred]

**Evidence map** (condensed)

| # | Requirement | Priority | Fit | Gap | Confidence |
|---|---|---|---|---|---|
| 1 | 8+ years growth leadership | must-have | met | none | high (CV) |
| 2 | Revenue growth across paid, SEO, lifecycle, brand, PR, partnerships, sales ops | must-have | partial | breadth in PR, brand, sales ops, partnerships unstated | medium |
| 3 | Team-of-one operating model | must-have | partial | you've led teams; solo-operator evidence not in your CV | medium |
| 4 | Ambiguity tolerance, metrics that evolve | preferred | likely met | not evidenced by you directly | low |
| 5 | Austin on-site, 5 days | hard_gate | **fails** | location | high (posting) |
| 6 | Base ≥ $150k | hard_gate | **fails** | top of range $85k | high (posting) |

**Opportunity risk register**
- **Pay mismatch** — high severity, confirmed by posting: $70–85k vs $150k floor. [grounded]
- **Location mismatch** — high severity, confirmed by posting: "no exceptions." [grounded]
- **Overwork signal** — medium severity: "evenings and weekends when it matters is just who we are." [grounded as stated]
- **Standing entry: failed attribution** — the company's existence, stage and size could not be checked this session, so the role's details rest on the posting alone. This would cap any `go` at `conditional_go`; here it is moot because the gates already decide the outcome. [grounded as limitation]

**Application plan:** none recommended. If you still want to test the role, the only useful question is whether Novaline would consider remote and a range near $150k. The posting already answers both with "no exceptions" and "$85k top," so I'd expect a no.

**Evidence status**

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | unavailable | Search permission denied; no results |
| 2. Role-family pay and scope sweep | unavailable | Search permission denied; no results |
| 3. Hiring manager's public footprint | n/a | No name given |

**Upgrade menu** (what would change the picture)
- The live posting link, or Novaline's careers page: confirms the role is current and matches what you pasted. Unlocks the failed-attribution check.
- Permission to run web search: unlocks the company-existence check and a current pay benchmark for Head of Growth roles. This is research, not a change to the decision, since the two gates stand either way.
- Whether a recruiter or hiring manager contacted you, and from what email domain: unlocks the attribution check on the sender.

**Questions**
1. Do you have a link to the live posting, or the recruiter's email domain? That lets me check the company's existence without web search.
2. Should I retry research if you grant web search permission? It would check the company and a current pay benchmark, but I don't expect it to change the no-go.

**Dossier offer:** I can write a `tuesday-dossier.md` summarizing this assessment for your records if you want one.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.