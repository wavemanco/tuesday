**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (location and work authorization)
- `must_have`: direct: R2, R3, R4, R5, R6
- `important`: direct: R7 · adjacent: R8 · unclear: R10
- `preferred`: adjacent: R9

R4 and R5 are your strongest matches. R10 (mentoring) and R9 (healthcare data) are the gaps.

**Opportunity ledger.** The posting is clear about scope but silent on pay, location, and team structure. Nothing in the JD asks for payment or personal financial details.

- **Hard gates:** none failed; unconfirmed: R1 (location and work authorization). Your constraints weren't given, so checks against them are unknown.
- **Severe red flags:** none found in the posting.
- **Conditions for go:** (1) a live posting link or the company's careers page confirms Harborlight Health and this role (RR4); (2) you confirm location and work authorization (R1); (3) the 11% retention figure is stated with its test definition before you use it anywhere (see Application plan).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up, ~400 people, Series C | `[grounded]` JD header; not independently verified this run |
| Mandate | Own product analytics for a care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, PM and clinician partnership, mentoring two junior analysts | `[grounded]` JD |
| First-year outcomes | None stated | `[grounded]` JD silent |
| Scope read | Broad for one senior role: a metrics layer, experimentation, BI, stakeholder work, and people management at once. Whether this is a first dedicated analytics hire or a team seat is unknown | `[inferred]` from the responsibility count against the absence of team detail |
| Market calibration | Not established. No role-family sweep ran this session, so there is no pay band or scope norm to set this against | — |
| Unknowns | Pay, location and remote policy, team and data-platform support, whether clinicians are internal or external, who owns metric definitions today | — |
| Contradictions | None within the JD. Nothing to compare against the careers page, since it could not be checked | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location and work authorization | hard_gate | unclear | none | hard_gate | JD states no location or schedule, and your constraints weren't given | `[grounded]` JD silent; you did not state them | Question 1 |
| R2 | 5+ years product analytics | must_have | direct | medium | none | Six years at a consumer-subscription company; stated, not yet inspected | `[grounded]` your background | Keep dates precise on the CV |
| R3 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake. "Expert" is the JD's word; your evidence supports "daily SQL on Snowflake" | `[grounded]` your background | A sanitized query sample would raise to high |
| R4 | Experiment design at scale | must_have | direct | medium | none | 30+ A/B tests a year; a pricing test tied to an 11% retention lift. The test design and how the lift was measured are not yet described | `[grounded]` your background | Methodology note for the 11% test would raise to high |
| R5 | Looker or similar BI tool | must_have | direct | medium | none | Built the company's Looker instance from scratch; 40+ governed dashboards | `[grounded]` your background | Sanitized dashboard list would raise to high |
| R6 | Written communication with non-technical stakeholders | must_have | direct | medium | none | Writes the monthly metrics memo the exec team reads; presents monthly to the VP Product | `[grounded]` your background | Sanitized memo excerpt would raise to high |
| R7 | Metrics layer: definition and maintenance | important | direct | medium | none | Governed dashboards imply metric-definition work. Whether you owned definitions as code is not stated | `[inferred]` from governed Looker work | Confirm ownership in interview |
| R8 | Partner with PMs and clinicians | important | adjacent | medium | transferability | PM partnership is direct (monthly VP Product work). No clinician partnership is stated | `[inferred]` | See G1 |
| R9 | Healthcare data, HIPAA (a plus) | preferred | adjacent | low | transferability | GDPR/CCPA consumer PII and a consent-state model are adjacent. No HIPAA or patient data is stated | `[inferred]` | See G2; Question 3 |
| R10 | Mentor two junior analysts | important | unclear | none | discovery | Named in the JD's responsibilities; nothing in your background speaks to it | `[grounded]` JD | Question 2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Clinician partnership (R8) | transferability | PM partnership is evidenced; no work with domain experts outside product | Clinicians are named in the JD's core responsibilities | Any project run with a non-product expert team, such as nutrition, ops or finance reviewers, where your analysis changed a decision | A sanitized project brief | `[inferred]` |
| G2 | Healthcare data (R9, preferred) | transferability | Consumer privacy work only | A plus, not a gate, but it is the first thing a healthcare interviewer will probe | Specifics of the consent-state model and how PII was handled | A sanitized design note on the consent model | `[inferred]` |
| G3 | Mentoring (R10, important) | discovery | Nothing stated | The JD names it as a responsibility | Informal coaching of analysts, onboarding, reviewing their SQL or analyses | A short example | `[grounded]` JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team and data support not described | unknown | — | "Own product analytics for our care-navigation app" | The role may be the first dedicated analytics hire, or one seat in a team with a data platform | `[inferred]` from the scope against the silence on team size | Is there an existing data team and warehouse, and who else owns metric definitions? | unresolved |
| RR2 | Regulated data context | risk_signal | low | "healthcare data experience (HIPAA) a plus" | Access controls and approvals may slow analysis compared with a consumer company. Severity is low because the JD treats HIPAA as a plus | `[inferred]` | How is patient-level data access granted to analysts? | unresolved |
| RR3 | Pay and location not stated | unknown | — | JD states neither | Cannot check pay against your floor. No band was established this session | `[grounded]` JD silence | What is the base pay band, and what is the location and remote policy? | unresolved |
| RR4 | Employer and posting not verified | unknown | — | JD header only | The posting may be correct; this run could not check it. Until verified, this caps the decision at `conditional_go` | `[grounded]` JD header; research unavailable | Can you share the live posting link or the careers page? | unresolved |
| RR5 | Defined responsibilities and named scope | positive_signal | — | "define and maintain the metrics layer" | The role's core work is concrete, and you can speak to each part | `[grounded]` JD | Who reviews metric definitions today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the pricing test: its design, sample, duration, and what the 11% measured | R4 is your strongest match; the lift needs its definition to hold up | `[grounded]` R4 | pending your approval |
| E2 | Use "daily SQL on Snowflake" and "built the Looker instance, 40+ dashboards", not "expert" | Keeps claims within what you can show | `[grounded]` R3, R5 | pending your approval |
| E3 | Present the consent-state model as consumer privacy work (GDPR/CCPA). Do not describe it as HIPAA or healthcare experience | R9 is adjacent only; overstating it is the first thing a healthcare interviewer would test | `[inferred]` R9 | pending your approval |
| E4 | Prepare one mentoring example, even an informal one, before the interview | R10 has no evidence yet | `[grounded]` R10 | pending your approval |
| A1 | Ask the recruiter for the location policy, pay band, and whether the team has a data platform | RR1, RR3, R1 | `[grounded]` risk register | pending your approval |

Nothing in this plan is final until you approve it. Each item is a proposal.

## Evidence status

Verified: none yet. Every claim so far comes from your message and the JD, and nothing has been checked against an artifact.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused because search permission was not granted. Would have confirmed the company exists as described and that the posting is live (RR4) |
| 2. Role-family sweep | unavailable | Same refusal. Would have set a `[generic]` pay band and scope norm for this title (RR3 and role reality) |
| 3. Hiring manager's public footprint | n/a | No name was given |

Dossier offer: I can write this assessment to a `tuesday-dossier.md` file for later interview prep, if you want one.

## Upgrade menu

- Granting search permission: runs the L1 checks (up to 5 searches and 2 fetches). Would confirm the company, the live posting, and a pay band.
- A live posting link or the careers page: resolves RR4 and lifts the cap on the decision.
- Your location and work-authorization constraints: resolves R1 and the hard-gate check.
- A methodology note for the 11% test: moves R4 to high and makes the headline defensible.
- A sanitized dashboard list or memo excerpt: moves R5 and R6 to high.

**Questions**

1. [R1] What are your location and work-authorization constraints, and what are your non-negotiables (pay floor, remote, contract type)?
2. [R10] Have you mentored or managed junior analysts, formally or informally? What did that involve?
3. [R9] Have you worked with patient, clinical or health-adjacent data, or with clinicians directly, even briefly?

Reply in prose, or say "skip" to any question.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.