**Yes, apply, on conditions. Status: `conditional_go`.** Your core experience matches the job's center: Salesforce, SQL, pipeline and renewal reporting, and running revenue operations. The two things you haven't done are the two things the JD asks you to own: the forecast and the billing data. Whether those gaps are a dealbreaker depends on one answer about how the role is scoped.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, hybrid two days a week), R2 (salary £61,500–£67,000)
- `must_have`: direct: R4 (Salesforce or HubSpot admin), R5 (strong SQL); adjacent: R3 (4+ years in B2B software, where your sector is payments); unclear: R8 (finance work on billing or revenue data); absent: R6 (owning a forecast), R7 (billing data)
- `important`: direct: R9 (pipeline and renewal reporting); adjacent: R10 (spreadsheet modelling)

R6 and R7 are the two must-haves with no evidence behind them; R3 is a credible bridge with its sector limit named.

**Opportunity ledger.** The employer checks out, and the posting has no red flags. The open items are how much forecast and billing ownership the role carries (RR1, RR2) and whether the posting appears on Quillfield's own careers page (RR3). Positive signals are a funded company and a hiring manager with a relevant background (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, hybrid two days a week), R2 (salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the forecast is either a shared process with the CFO or you're comfortable learning it on the job (RR1, R6); (2) the billing-data scope is one you can ramp on (RR2, R7); (3) the Bristol hybrid pattern and the salary work for you (R1, R2); (4) the role appears on Quillfield's own site (RR3).
- **What would change this:** if the role owns the forecast outright from day one with no finance partner, or billing data is central and you'd have no ramp time, I'd move to `hold_pending_answers` and reconsider.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield, invoicing and payments software for UK builders' merchants; founded 2018 in Bristol; 96 staff; £11M Series A closed April 2025 | `[grounded]` Quillfield's about page (search snippet) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` JD |
| Reporting line | Probably to the Head of Revenue Operations, who is the hiring manager | `[inferred]` from Tamsin Achebe's title against the role's scope |
| Market calibration | Ledgerline's 2026 UK survey puts the median base for this role at £64,200, interquartile range £57,800–£70,400 (n=438). The posted £61,500–£67,000 sits inside that range, below the median | `[generic]` role-family sweep; `[grounded]` JD for the posted figure |
| Unknowns | Whether the role owns the forecast or supports the CFO's; how much billing data it owns; the team's size | — |
| Contradictions | None found between the JD and what I could see of the company | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid two days a week | hard_gate | unclear | none | hard_gate | Your location and constraints weren't given, so this can't be checked | `[grounded]` JD; constraint not given | Ask: is this workable? (H1) |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | Your pay floor wasn't given. The figure is inside the market band | `[grounded]` JD; `[generic]` band | Ask: is this workable? (H1) |
| R3 | 4+ years in RevOps or sales ops at a B2B software company | must_have | adjacent | medium | transferability | Five years in sales ops and two running RevOps, but at a payments company rather than software. Take the lower band | `[grounded]` CV | Bridge G3 |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, with pipeline and renewal dashboards rebuilt. CV claim, no artifact yet | `[grounded]` CV | none |
| R5 | Strong SQL | must_have | direct | medium | none | SQL weekly. CV claim, no artifact yet | `[grounded]` CV | none |
| R6 | Experience owning a company revenue forecast | must_have | absent | none | capability | You've never owned one; finance did it. The pipeline review you run feeds forecast inputs, which is the closest adjacency | `[grounded]` intake; `[inferred]` adjacency | G1 |
| R7 | Experience working with billing data | must_have | absent | none | capability | You've never worked on billing data | `[grounded]` intake | G2 |
| R8 | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | Revenue data is plausible from pipeline work, but finance collaboration isn't stated | `[grounded]` CV silence | Question: what did you do with finance? |
| R9 | Building pipeline and renewal reporting | important | direct | medium | none | Rebuilt the pipeline and renewal dashboards. CV claim | `[grounded]` CV | none |
| R10 | Spreadsheet modelling | important | adjacent | medium | discovery | Excel daily; modelling not described | `[grounded]` CV | Ask for an example model |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R6, must_have) | capability | Monthly pipeline review with the sales director; no forecast ownership | The JD asks you to run it with the CFO. Owning it on day one is the largest risk | Any pipeline-to-forecast reconciliation; stage-weighting or commit calls | A sample forecast pack, or a pipeline-to-forecast bridge | `[inferred]` closure path from the pipeline review |
| G2 | Billing data (R7, must_have) | capability | No billing data work stated | The JD says the role owns billing data | Any invoice or payment-reconciliation reporting you consumed | A billing-data extract or report you used | `[grounded]` intake |
| G3 | B2B software sector (R3, must_have) | transferability | Years and scope match; sector is payments | Interviewers may probe whether payments transfers to invoicing software | Subscription or renewal work; invoicing-adjacent customer data | A renewal or pipeline dashboard screenshot | `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast ownership scope not stated | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may own the numbers, or may supply inputs that the CFO signs off | `[inferred]` from the JD's wording | Does this role own the forecast numbers, or prepare inputs for the CFO to sign off? | unresolved |
| RR2 | Billing data scope not stated | unknown | — | "own our CRM and billing data" | The role may carry sole ownership of billing data with no finance partner | `[inferred]` from the JD's wording | What billing system does the role own, and who has write access to it? | unresolved |
| RR3 | Posting not found on the employer's careers page | risk_signal | low | "Revenue Operations Lead, Quillfield" | The listing may be stale or the page may simply not be indexed | `[grounded]` careers page fetch returned no page | Is this role listed on Quillfield's own careers page, and who would I interview with? | unresolved |
| RR4 | Funded company with a named hiring manager who has a payments sales-ops background | positive_signal | — | Hiring manager's public profile, search snippet | Shared background may make the bridge easier to make | `[grounded]` search snippet, not fetched | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead positioning with the Salesforce and pipeline-reporting work, and present the payments background as the bridge to invoicing software | Matches R3, R4, R9 without overclaiming | `[grounded]` CV; `[inferred]` shared background | pending your approval |
| P2 | Ask the recruiter whether the forecast is owned by this role or supported by finance, before the first interview | RR1 and R6 | `[grounded]` RR1 | pending your approval |
| P3 | Confirm the posting on Quillfield's own careers site before investing in the application | RR3 | `[grounded]` RR3 | pending your approval |

No proposed wording claims forecast or billing experience you don't have. Nothing here goes out until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol" (quillfield.co.uk/about) and "Quillfield careers Revenue Operations Lead" (no results). Fetched quillfield.co.uk/careers: no page. Moved RR3 and the employer-exists check: the company is real, but the posting isn't on its own site |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software £60,000", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example). Moved the market calibration in role reality |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned a public profile (linkedin.example) as a snippet only; not fetched. Moved RR4 and the positioning in P1 |

## Upgrade menu

- A sample forecast or pipeline-to-forecast bridge → R6 moves up and G1 closes
- A billing-data extract or report you have used → R7 moves up and G2 closes
- An example Excel model → R10 moves to direct
- Your Bristol and pay constraints → R1 and R2 close (H1)
- Confirmation of the role on Quillfield's careers page → RR3 closes
- A deeper pass on Quillfield (funding, leadership changes, the forecast process) would use up to 5 more searches and 2 more fetches. Say the word and it runs.
- I can also save this as `tuesday-dossier.md` whenever you want it.

## Questions

1. **G1 / RR1:** Does this role own the quarterly forecast numbers, or does it prepare the inputs for the CFO? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. **G2 / R7:** Has any of your work touched billing or invoice data, even as a report consumer? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. **H1 / R1, R2:** Are Bristol hybrid (two days a week) and £61,500–£67,000 workable against your constraints? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.