**Decision snapshot: `conditional_go`.** Worth applying if the employer checks out. Your must-have requirements are mostly met on your stated experience. The gaps are narrow and fixable, and nothing in the posting is a red flag.

**Fit ledger** (per requirement, detailed in the evidence map):
- **Met on stated evidence:** 5+ years data engineering, SQL and Python, dbt, Airflow, data quality testing.
- **Transferable gap:** BigQuery. You have Snowflake, and the posting names BigQuery in its responsibilities.
- **Unknown from your background:** ingestion from app and CRM, data contracts, and owning a domain's pipelines end to end.

**Hard gates:**
- **Location** (remote US or Denver): your location wasn't provided, so this is unknown.
- **Pay floor:** your minimum wasn't provided. The posted $148,000–$166,000 is `[grounded]` from the JD.

**Opportunity ledger:** No red flags in the posting. Positives are the stated Series C and headcount, `[grounded]` from the company's About page and not independently checked. Unknowns: no hiring manager named, equity unquantified, employer not verified.

**Research tier: L0 — no searches.** I did not run research. The employer's existence and the posting's liveness are unverified, which is why this is capped at `conditional_go`.

## Role reality
- **Organization:** Pellucid Learning, live online K-12 tutoring in 31 states, Denver, 264 employees, Series C ($52M, February 2026). `[grounded]`, company-stated.
- **Stated responsibilities:** build and run reporting pipelines, ingest from app and CRM, a dbt-modelled warehouse in BigQuery, data contracts for analysts.
- **Implied requirements:** BigQuery fluency, contract design, CRM integration.
- **Scope:** "build and run" suggests end-to-end ownership of reporting. `[inferred]`
- **Contradiction:** BigQuery appears in responsibilities but not in the listed requirements.
- **Market calibration** `[generic]`: the Datawright report puts Senior Data Engineers at Series B–D companies at a $151,000 base median, IQR $139,000–$163,500, with senior meaning 5–8 years and typical scope as one domain's pipelines with no direct reports. Your 6 years fits that seniority band. The posted midpoint of $157,000 sits in the upper half of the IQR.

## Evidence map
| # | Priority | Fit | Requirement | Evidence | Gap | Confidence |
|---|---|---|---|---|---|---|
| 1 | Must | Met | 5+ years data engineering | 6 years, B2B payroll company | none | stated |
| 2 | Must | Met | Strong SQL | Daily use | none | stated |
| 3 | Must | Met | Strong Python | Daily use | none | stated |
| 4 | Must | Met | dbt | ~180-model dbt project, built | none | stated |
| 5 | Must | Transferable | Cloud warehouse (BigQuery named) | Snowflake; no BigQuery | transferability | stated |
| 6 | Must | Met | Airflow or similar | Used for orchestration | none | stated |
| 7 | Must | Met | Data quality testing | Set up Great Expectations suite | none | stated |
| 8 | Implied | Unknown | Ingestion from app and CRM | Not in CV | discovery | none |
| 9 | Implied | Unknown | Data contracts for analysts | Not in CV | discovery | none |
| 10 | Scope | Partial | Owns a domain's pipelines | Inferred from model count | presentation | inferred |

## Gap recovery queue
- **Row 8, discovery:** ingestion from app and CRM. Closes with one concrete example: source systems, tooling, sync method, volume.
- **Row 9, discovery:** data contracts. Closes with one example of a schema or SLA agreement with analysts or other consumers.
- **Row 5, transferability:** BigQuery. Closes with any BigQuery use or a credible ramp plan. Your dbt and SQL skills carry over; BigQuery experience should not be claimed.
- **Row 10, presentation:** ownership. Closes with an explicit ownership line in your CV.

## Opportunity risk register
| # | Class | Severity | Item | Status |
|---|---|---|---|---|
| R1 | Verification | Medium | Employer existence and live posting not verified (L0) | Open; caps `go` |
| R2 | Mismatch | Low | Posted pay in market range; your floor unknown | Open |
| R3 | Unknown | Low | No hiring manager named | Open |
| R4 | Unknown | Low | Equity unquantified | Open |
| R5 | Hard gate | Unknown | Location versus remote US or Denver | Open |

To resolve R1, send the live posting link, the company's careers page, or the recruiter's email domain.

## Application plan
- **Lead with:** the ~180-model dbt project, Great Expectations, Airflow, and daily SQL and Python. Your strongest evidence is stated and verifiable.
- **Do not claim:** BigQuery, data contracts, or CRM ingestion until you confirm them.
- **Proposed CV line** `resume_edits_pending_approval`: "Built and owned a ~180-model dbt project on Snowflake." Confirm that "owned" is accurate before using it. I have not finalized this; it needs your approval.

## Evidence status
Research tier: L0 — no searches

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company official site and careers page | skipped | Research not run; no consent given |
| 2 | Role-family sweep | skipped | Same; the pay figures above come from your recruiter's report |
| 3 | Hiring manager's public footprint | n/a | No name given |

You can take the dossier offer at any point, and I can write `tuesday-dossier.md` for you. It keeps your evidence, gaps, and decision in one file.

**Upgrade menu**, what each missing input unlocks:
- **Live posting link or careers page:** verifies the employer and posting, and lifts the `conditional_go` cap if confirmed.
- **CRM and app ingestion, and contract examples:** moves rows 8 and 9 from unknown to evidenced.
- **Your location and pay floor:** completes the hard-gate check.
- **L1 research (up to 5 searches, 2 fetches):** verifies the employer and gives a market-pay check beyond the recruiter's report.
- **L2 research, offered once (up to 5 more searches, 2 more fetches):** funding and leadership churn, recent news. Run only if you say yes.

**Questions:**
1. (Row 8) Have you built or owned ingestion from a product database or a CRM? Which systems, and how?
2. (Row 9) Have you defined data contracts or schema or SLA agreements with analysts or other consumers?
3. (R5 and R2) Where are you located, and what base-pay floor applies?

You can answer any of these, or say "skip."

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.