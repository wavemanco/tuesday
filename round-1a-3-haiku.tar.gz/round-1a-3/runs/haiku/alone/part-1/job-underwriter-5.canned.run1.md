**Decision snapshot: `conditional_go`.** Yes, it's worth applying. Fit and opportunity are scored separately below.

- **Fit:** Strong on four of five stated must-haves. The one real gap is BigQuery. Confidence is `medium` throughout because everything comes from your CV, not from checked evidence.
- **Opportunity:** The pay range sits at market norms and the seniority and scope match. Company facts are unverified.
- **Hard gates:** Location and work authorization are unknown. Your pay floor is unknown. Neither has failed.
- **Condition:** The posting and company are unverified, which caps this at `conditional_go`.

Research tier: L0, no searches. I used only the JD, the about page and the pay report you pasted. I did not check that the company or posting is live.

**Role reality** `[grounded]` unless marked
- Senior Data Engineer, Pellucid Learning. Live online K-12 tutoring in 31 states, founded 2016, 264 employees, Series C ($52M, Feb 2026). These are company claims, not verified.
- Stated scope: build and run pipelines for reporting, covering app and CRM ingestion, a dbt warehouse on BigQuery, and data contracts for analysts.
- Pay: posted $148k–$166k base plus equity. Midpoint $157k.
- Market calibration `[generic]`: the Datawright report gives a median of $151k and an IQR of $139k–$163.5k for Senior DEs at Series B–D companies. The posted range sits inside the IQR, with the midpoint slightly above the median. Equity is unquantified.
- Seniority: "Senior" typically means 5–8 years, and you have 6. The scope (ownership of a domain's pipelines, no direct reports) is the typical norm, `[generic]`.
- Contradictions: none found between the JD and the about page. No hiring manager is named.

**Evidence map**

| # | Priority | Fit | Requirement | Evidence | Confidence | Gap |
|---|---|---|---|---|---|---|
| R1 | must-have | direct | 5+ years data engineering | 6 years, B2B payroll | medium | none |
| R2 | must-have | direct | Strong SQL and Python | Daily use, both | medium | none stated |
| R3 | must-have | transferable | dbt and a cloud warehouse | dbt, ~180 models, on Snowflake | medium | warehouse is Snowflake, not BigQuery |
| R4 | must-have | direct | Airflow or similar | Airflow orchestration | medium | none |
| R5 | must-have | direct | Data quality testing | Set up the Great Expectations suite | medium | none |
| R6 | responsibility | unknown | Data contracts analysts depend on | Not in your background | none | unknown |
| R7 | responsibility | unknown | Ingestion from app and CRM | Not in your background | none | unknown |
| R8 | named tool | transferable | BigQuery | Never used | none | capability gap, closable by ramp-up |
| H1 | hard gate | unknown | Remote (US) or Denver | Not stated | none | unknown |
| H2 | hard gate | unknown | Pay against your floor | Not stated | none | unknown |

**Opportunity risk register**
- Unverified company and posting (standing entry): I did not confirm the company exists as described or that the posting is live. Likely reasons include a very new or small company, a stale posting, or not a current hiring entity. This is open until checked. Severity: medium.
- Equity value unknown. Severity: low.
- No hiring manager named. Severity: low.
- Scope risk: "data contracts" and ingestion ownership may be broader than your current experience. Severity: medium.
- No red flags found. Nothing asks for payment or personal banking details.

**Application plan** (for review, nothing external has been drafted)
- Lead with the 180-model dbt project and the Great Expectations suite. Both match the stated requirements directly.
- Address BigQuery directly as a ramp-up on a warehouse you already run in production. Do not claim BigQuery experience.
- Before applying, confirm the posting is live on the company's careers page. Ask the recruiter for the hiring manager and the team's stack.
- Claim data contracts and ingestion only if they are true for you.

**Evidence status**

| Target | Status | Reason |
|---|---|---|
| 1. Official site and careers page | skipped | L0 selected; no searches run |
| 2. Role-family sweep | skipped | L0; pay band taken from the pasted report |
| 3. Hiring manager footprint | n/a | No name given |

**Upgrade menu**
- Running L1 research (up to 5 searches, 2 fetches) would check that the company and posting are live, and sweep pay for this exact title. This is the main way to lift the `conditional_go`.
- Your location and work authorization would resolve H1.
- Your pay floor would resolve H2.
- Any ingestion or data-contract work would move R6 and R7 from unknown to evidenced.
- Any BigQuery exposure, even a side project, would move R8 to direct.

I can also save this assessment as `tuesday-dossier.md` so other tools can use it.

**Questions**
1. Are you eligible to work in the US, and would you consider Remote (US) or relocating to Denver?
2. Have you built ingestion from application or CRM sources, or owned data contracts with downstream consumers?
3. What base pay is your floor, and how much does equity matter to you?

You can answer any of these or say "skip" to any. Skipping counts as an answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.