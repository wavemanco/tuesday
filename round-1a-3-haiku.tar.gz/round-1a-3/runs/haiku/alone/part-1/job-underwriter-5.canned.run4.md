## Decision snapshot

**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: H1 (work authorization and location for remote US or Denver), H2 (pay floor)
- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: adjacent: R6 · unclear: R7, R8

Your core stack matches the posting's requirements: dbt on a cloud warehouse, Airflow, data-quality testing, SQL and Python, and six years. The gaps are BigQuery and two responsibilities the posting names that your background doesn't mention.

**Opportunity ledger.** The company checks out and the pay is at market. The open questions are scope and whether the posting's responsibilities match a single-domain senior role.

- **Hard gates:** none failed; unconfirmed: H1 and H2. Candidate constraints were not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) confirm work authorization and location for the remote or Denver option (H1); (2) confirm who owns ingestion and data contracts (R7, R8, RR4); (3) confirm the base salary against your floor (H2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` pasted About page; the careers page fetched and the About page matched in search |
| Mandate | Build and run ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and analyst data contracts | `[grounded]` posting |
| Stack | dbt, BigQuery, Airflow or similar, data-quality testing | `[grounded]` posting |
| Working pattern | Remote (US) or Denver office | `[grounded]` posting |
| Market calibration | Posted base of $148k–$166k sits inside the $139k–$163.5k IQR; midpoint about $157k against a $151k median. Senior roles at this stage typically own one domain's pipelines with no direct reports, so this posting's breadth is above that norm | `[generic]` Datawright 2026 report, as pasted; `[grounded]` posted band |
| Unknowns | Equity terms (unquantified); team size; who owns ingestion and contracts; hiring manager (not named) | none |
| Contradictions | None found between the pasted posting and the live careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | Six years stated; no artifact | `[grounded]` your statement | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no artifact | `[grounded]` your statement | none |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | 180-model dbt project on Snowflake. The posting asks for "a cloud warehouse", and Snowflake meets that wording; BigQuery is covered in R6 | `[grounded]` your statement; `[inferred]` Snowflake meets the wording | A sanitized dbt excerpt would raise this to high |
| R4 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow stated | `[grounded]` your statement | none |
| R5 | Data-quality testing | must_have | direct | medium | none | Great Expectations suite set up and owned, stated | `[grounded]` your statement | none |
| R6 | BigQuery warehouse (named in responsibilities) | important | adjacent | high | transferability | You have never used BigQuery. dbt and warehouse work transfer, but BigQuery's own specifics do not | `[grounded]` your statement; `[inferred]` transfer | none; ramp only |
| R7 | Ingestion from app and CRM | important | unclear | low | discovery | Not in your background | `[grounded]` silence | Q2 |
| R8 | Data contracts analysts depend on | important | unclear | low | discovery | Not in your background | `[grounded]` silence | Q2 |
| H1 | Work authorization and location (US remote or Denver) | hard_gate | unclear | none | hard_gate | Your constraint was not given | `[grounded]` posting | Q1 |
| H2 | Base pay against your floor | hard_gate | unclear | none | hard_gate | Your floor was not given; the posted band is $148k–$166k | `[grounded]` posting | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | What would close it | Provenance |
|---|---|---|---|---|---|---|
| G1 | BigQuery (R6) | transferability | Snowflake and dbt experience, no BigQuery | The posting names BigQuery as the warehouse | A stated ramp plan, or a BigQuery project of any size | `[inferred]` transfer; `[generic]` that BigQuery has its own specifics, such as partitioning and cost controls |
| G2 | Ingestion and data contracts (R7, R8) | discovery | Your background does not mention either | Both are responsibilities the posting names | A description of any app or CRM ingestion, or contracts you have written or maintained | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posted base sits within the market IQR | positive_signal | — | "$148,000–$166,000 plus equity" | Pay is at market and not below norm | `[grounded]` posting; `[generic]` IQR | What is the budgeted base for this role? | noted |
| RR2 | Equity is offered with no terms | unknown | — | "plus equity" | Equity could be material or nominal | `[inferred]` from the unquantified offer | What are the grant size, vesting and strike terms? | unresolved |
| RR3 | Hiring manager not named | unknown | — | none given | Normal for an applicant-tracking posting; says little about the team | `[generic]` common posting practice | Who is the hiring manager, and what is the team size? | unresolved |
| RR4 | Scope is broader than the title's usual norm | risk_signal | medium | "Build and run the pipelines … the data contracts our analysts depend on" | The role may be the main data engineer across ingestion, modelling and contracts, not a single domain | `[inferred]` from the posting's scope against the `[generic]` norm | Who else owns pipelines today, and how big is the data team? | unresolved |
| RR5 | BigQuery ramp | risk_signal | low | "dbt-modelled warehouse in BigQuery" | Expect a short ramp on BigQuery-specific tooling | `[inferred]` from G1 | Is BigQuery expected from day one? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the 180-model dbt project, Airflow and Great Expectations | These are the direct matches | `[grounded]` R3–R5 | pending your approval |
| P2 | Say plainly that BigQuery is new for you; claim no experience with it | G1, R6 | `[grounded]` your statement | pending your approval |
| P3 | Ask the recruiter about hiring manager, team size, equity and contract type before the first interview | RR2–RR4 | `[generic]` common screening practice | pending your approval |

Nothing here is externally visible yet. Any resume line or outreach text would need your approval before use.

## Evidence status

Verified: none yet from your own materials. The posting is confirmed live and consistent, and the company's About details are confirmed against a search result. Your background is still your own statement.

Research tier: L1 — searches 1 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched pellucidlearning.com/careers/senior-data-engineer: the posting is live and matches the pasted text. Searched "Pellucid Learning live online tutoring K-12 Denver Series C", which returned pellucidlearning.com/about with the same figures as the pasted page. The About page was seen as a search snippet, not fetched. Role reality, contradictions: none |
| 2. Role-family sweep | skipped | The Datawright report was pasted in full, which fixes the band and scope norm it feeds |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

The $52M Series C and the headcount are the company's own claims. Only the About page confirms them, and no independent source has checked them.

## Upgrade menu

- Your work authorization and location, plus your pay floor → H1 and H2 close, and the decision can move to `go`.
- A sanitized dbt excerpt or model-test example → R3 rises to high.
- The recruiter's answers on hiring manager, team size, equity and contract type → RR2–RR4 close.
- A BigQuery project or a stated ramp plan → G1 and RR5 close.
- A deeper research pass on Pellucid Learning (funding, leadership changes, public reviews, recent news; up to 5 more searches and 2 more fetches) would test the Series C and headcount claims independently. Say the word and it runs.

If you want, I can write this up as `tuesday-dossier.md` so it carries forward into later sessions.

**Questions**

1. **H1:** Are you authorized to work in the US without sponsorship, and are you based in the US or Denver?
2. **G2 (R7, R8):** Have you built or owned ingestion from a product app or CRM, or written data contracts that analysts depend on?
3. **H2:** Is a base of $148k–$166k above your floor?

Reply in text, or say skip for any of these. I'll proceed on whatever you leave unanswered.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.