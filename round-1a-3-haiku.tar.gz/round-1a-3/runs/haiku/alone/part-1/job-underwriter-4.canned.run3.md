**Yes, apply, once the posting checks out: `conditional_go`.** Your method background matches most of the must-haves. The real gap is pet insurance, and it is a domain gap you can address directly.

## Decision snapshot

**Status: `conditional_go`**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK-based)
- `must_have`: direct: R2, R3, R4, R5, R8
- `important`: adjacent: R7 (Pet-insurance product pricing), R9 (Recommendations for product)
- `preferred`: direct: R10 (Insurance experience)

R4 is direct on method, not on product: motor GLM work transfers, pet does not yet. R7 (`low`) is the pet gap; its bridge is motor method only. R1 is unconfirmed because your location and right to work are not in the material.

**Opportunity ledger.** Sound on what it says: the responsibilities are concrete (RR5, positive). It is thin where it matters: decision rights, reporting line and pay are unstated (RR1, RR2, RR3), and the employer has not been checked (RR4).

**Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK-based); candidate constraints not given — checks against them unknown.

**Severe red flags:** none found.

**What would change this.** Conditions for go:
1. The role is live on Brindlemoor's own careers page (RR4).
2. You confirm you meet the location and right-to-work gate (R1).
3. The first conversation settles decision rights, reporting line and a pay band (RR1–RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech | `[grounded]` JD header |
| Mandate | Own pricing analytics for the pet-insurance product | `[grounded]` JD |
| Scope | Build and monitor rating models; design and read price tests; turn results into underwriting and product recommendations | `[grounded]` JD |
| Scope read | A senior individual-contributor analytics role; the JD names no team | `[inferred]` from the responsibilities against the silence on team |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` name you gave; footprint not checked |
| Market calibration | Not run in this pass | — |
| Unknowns | Team size, decision rights, reporting line, pay, contract type, your location | — |
| Contradictions | None visible in the JD as provided; not checked against the careers page | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based | hard_gate | unclear | none | hard_gate | Your location and right to work are not in the material | `[grounded]` JD | Confirm (Q1) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, last two senior; CV statement, no artifact | `[grounded]` your CV | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Used daily; no artifact yet | `[grounded]` your CV | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM rating model for the young-driver motor book. The JD asks for GLM experience, not pet GLMs | `[grounded]` your CV | none |
| R5 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your CV | Q3 |
| R6 | Build and monitor rating models (pet product) | must_have | direct | medium | none | Method covered by R4; the product gap sits in R7 | `[inferred]` from R4 | none |
| R7 | Pet-insurance product pricing | important | adjacent | low | transferability | No pet work. Motor pricing method transfers; pet claim behaviour differs from motor | `[inferred]` adjacency from motor pricing; `[generic]` that pet claims behave differently | G1, Q2 |
| R8 | Present to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your CV | none |
| R9 | Turn results into product recommendations | important | adjacent | medium | transferability | Underwriting recommendations evidenced; product-facing ones not stated | `[inferred]` from R8 | G2 |
| R10 | Insurance experience | preferred | direct | medium | none | Motor insurer, five years | `[grounded]` your CV | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance pricing (R7) | transferability | No pet work; motor method only | The product is pet, so this is the objection most likely to come up | Any non-motor pricing, claims-frequency or severity modelling, or work with ongoing-condition or vet-cost data | A sanitized method note from any non-motor project | `[inferred]` from the CV; `[generic]` that pet claims differ |
| G2 | Product recommendations (R9) | transferability | Underwriting recommendations evidenced; product not | The role turns results into product recommendations | Any price test that changed cover terms, excess or limits | One sanitized test summary with the product decision it fed | `[inferred]` from R8 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Decision rights and team unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | You may be the only pricing analyst, with rating decisions sitting with the Director of Pricing | `[inferred]` from "own" against the silence on team | Who else works on pricing here, and which rating and price-test decisions does this role make alone? | unresolved |
| RR2 | Reporting line and direct reports unstated | unknown | — | "Senior Pricing Analyst" (no reports stated) | The role may carry direct reports the posting omits; that matters because you have not managed anyone | `[inferred]` from title and silence on reports | Does this role have direct reports now, or planned in the next year? | unresolved |
| RR3 | Pay and contract type not stated | unknown | — | No salary in the posting as provided | The band may sit below senior pricing norms, or the figure may be unpublished | `[generic]` that senior postings often publish a range; `[inferred]` from the absence | What is the salary range and contract type for this role? | unresolved |
| RR4 | Employer and live posting not checked | unknown | — | "Brindlemoor (insurtech)" | An early-stage firm may have a thin footprint, or the posting may be stale; this cannot be told without checking | `[generic]` pattern for young insurtechs; not a claim about Brindlemoor | Can you point me at this role on Brindlemoor's own careers page? | unresolved |
| RR5 | Concrete scope and named hiring manager | positive_signal | — | "Own pricing analytics… design and read price tests, and turn the results into recommendations" | The scope is specified and the manager is named | `[grounded]` JD | What would a strong first six months look like in this role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the posting on Brindlemoor's own careers page before applying | see RR4 | `[generic]` pattern | pending your approval |
| A2 | Lead with the GLM build, the 14 tests and the underwriting presentations | these cover the must-haves | `[grounded]` your CV | pending your approval |
| A3 | Name the pet gap yourself, framed as method transfer: motor pricing built on GLMs, pet claims behave differently, and what you would learn first. Avoid "pet pricing experience" | see R7 | `[inferred]` from R7; `[generic]` on pet claims | pending your approval |
| E1 | Add a CV line with outcomes of one or two price tests, if the outcomes are on record | see R5 | `[grounded]` your CV | pending your approval |
| Q1 | Ask RR1–RR3 verbatim in the first conversation | the register doubles as interview prep | `[grounded]` register | pending your approval |

Nothing here changes your CV or goes out until you approve it.

## Evidence status

Verified: none yet.

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | skipped | Would confirm Brindlemoor exists and the posting is live (RR4) |
| 2. Role-family sweep | skipped | Would give a pay band for this seniority (RR3) and a market scope read |
| 3. Hiring manager's public footprint | skipped | Odile Varga's name was given, so this could run; it would shape which story leads with her |

This first pass ran without searches. The default check on the employer is still open.

If you want this kept, I can write it out as a `tuesday-dossier.md` with the map, register and plan.

## Upgrade menu

- **Run the employer check (up to 5 searches, 2 page fetches):** confirms Brindlemoor exists and the posting is live (RR4), gives a pay band (RR3), and sources R1 → RR4 and RR3 close or firm up.
- **A sanitized write-up of one price test** (method, result, decision it fed) → R5 to `high`.
- **A GLM documentation excerpt or validation summary** → R4 to `high`.
- **Any non-motor pricing or claims work** → R7 rises, G1 closes.
- **Odile Varga's public professional footprint**, within the people-research limits → which story leads with her.

## Questions

1. (R1) Are you UK-based now, and do you have other hard constraints, such as a pay floor, contract type or notice, I should check against?
2. (G1) Have you worked on any non-motor product, such as home, travel, or a claims-cost model outside motor?
3. (R5) Could you share a sanitized write-up of one of the 14 price tests: the method, the result, and the decision it fed?

Answer in prose, or say skip on any; silence counts as an answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.