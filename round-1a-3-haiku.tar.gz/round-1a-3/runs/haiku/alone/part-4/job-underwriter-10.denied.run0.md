**Worth applying to, on conditions. Status: `conditional_go`.** I could not confirm that Fernquay exists as described. Web search was refused in this session, so the company checks did not run. That is not evidence the company is fake. Nothing in the posting or the messages asks you for money, bank details or ID, and the WhatsApp message is a normal scheduling note from a co-founder.

**Fit ledger.**

- `hard_gate`: direct: H1 (Galway, hybrid) · unclear: H2 (salary against your floor)
- `must_have`: direct: R1, R2, R3, R4 · adjacent: R5 · absent: R6
- `important`: adjacent: R7

**Hard gates:** none failed. H2 is unclear because you haven't given a salary floor.

**Severe red flags:** none found.

**Conditions for go:**
1. The company is confirmed to exist as described (RR1).
2. You are comfortable being the only designer, which you have never been (R6).
3. Salary and equity terms are stated in writing (RR3, RR4).

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting; not checked externally |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Scope read | First designer, so the role includes setting up design practice as well as doing the work | `[inferred]` from "first designer" against the listed duties |
| Working pattern | Two office days a week in Galway, the rest remote | `[grounded]` posting |
| Market calibration | Not run. The €52–60k band could not be checked against role-family norms | — |
| Unknowns | Decision rights, tooling budget, equity share count and vesting, contract type, who the co-founder is in the company | — |
| Contradictions | None found between the posting and the messages | `[grounded]` |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product design | must_have | direct | medium | none | Four years stated, CV only | `[grounded]` CV | none |
| R2 | Strong Figma | must_have | direct | medium | none | Daily use stated; no file seen by me | `[grounded]` CV | Share one project (see plan) |
| R3 | Has run own user research | must_have | direct | medium | transferability | Monthly usability sessions, but with travel-booking customers, not school owners | `[grounded]` CV; transferability `[inferred]` | Describe the method, not the customer type |
| R4 | Works directly with engineers | must_have | direct | medium | none | Four-engineer squad | `[grounded]` CV | none |
| R5 | Owns a booking flow end to end | must_have | adjacent | medium | capability | Redesigned checkout, one part of a flow, inside a squad | `[grounded]` CV; `[inferred]` on scope | Don't claim end-to-end ownership |
| R6 | Works as the only designer (implied) | must_have | absent | medium | capability | You have never been the only designer; no record of building a design practice alone | `[grounded]` CV | Real answer needed (Q1) |
| R7 | Research calls with school owners | important | adjacent | low | discovery | No small-business or B2B research recorded | `[inferred]` | Propose a concrete interview plan |
| H1 | Galway location, hybrid | hard_gate | direct | medium | none | You live in Galway | `[grounded]` CV and posting | none |
| H2 | Salary against your floor | hard_gate | unclear | — | none | Your floor is not stated | `[grounded]` posting | Q2 |

### Gap recovery queue

- **G1 (R6, capability):** No solo design record. Closes with a concrete example of setting up process or deciding without a senior designer to check with.
- **G2 (R7, discovery):** No school-owner research. Closes with a short interview plan you can describe on the call.
- **G3 (R5, capability):** No end-to-end ownership. Closes by describing which parts of the flow you led and which you didn't.

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not confirmed to exist as described | risk_signal | medium | "six people in Galway" | Reasons, none ranked as likely: too new or small, a stale posting, or not a real hiring employer | `[grounded]` posting; no search completed | Does a CRO entry exist for Fernquay, and does the careers page list this role? | unresolved |
| RR2 | Only designer, no design peers | risk_signal | medium | "You would be our first designer" | Decision rights and design review may be unclear; you would be the design function | `[inferred]` from "first designer" | Who signs off design decisions, and is there any design budget? | unresolved |
| RR3 | Salary stated, not checked against market | unknown | — | "€52,000–€60,000" | The band may sit above or below typical for this seniority; not checked here | `[grounded]` posting | What is the budgeted range, and how is it set? | unresolved |
| RR4 | Equity figure has no context | unknown | — | "0.5–1% equity" | Value depends on total shares, vesting, dilution and share class | `[inferred]` | What is the total share count, vesting schedule and strike price? | unresolved |
| RR5 | Explicit scope and a named CTO in the process | positive_signal | — | "Saoirse, our CTO" | The process includes technical leadership, which suggests a real hiring loop | `[grounded]` WhatsApp message | — | noted |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Check the company yourself: a CRO search for "Fernquay", whether the domain matches the email from Ronan, and whether the role appears on the company's own careers page | Closes RR1 | `[grounded]` RR1 | proposed |
| E2 | Choose one real project for the call, even a messy one, and share a sanitised version if the work is confidential | Raises R2 and R5 evidence | `[grounded]` posting asks for "one messy real project" | pending your approval |
| E3 | Lead with squad experience and the research cadence; don't claim end-to-end ownership or design leadership you didn't have | Avoids overclaiming on R5 and R6 | `[grounded]` CV; reframing audit | proposed |
| E4 | Describe a school-owner research plan as a plan, not as past experience | Covers R7 honestly | `[inferred]` | proposed |
| E5 | Prepare questions for the call on decision rights, tooling budget, equity terms and contract type | Closes RR2, RR3, RR4 | `[grounded]` risk register | proposed |

The `mock-interview` skill can rehearse the 45-minute call if you want that.

### Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Web search was refused by permission, so the company's existence was not established. Would move RR1 and the contradictions row. |
| 2. Role-family sweep | unavailable | Refused. Would have set the market calibration for the €52–60k band. |
| 3. Hiring manager's public footprint | unavailable | Ronan Kehoe was named; the search was refused. Would have informed positioning. |

I stopped sending searches after the refusal rather than retrying.

**Dossier offer:** I can save this assessment as a `tuesday-dossier.md` if you want it to carry into interview prep.

**Upgrade menu:**
- **Allow web search:** 2 more searches and 2 fetches at L1 would cover the company registry, the careers page and the salary band. That would move RR1 and RR3.
- **Your salary floor and any non-negotiables:** closes H2.
- **One project, or the checkout case study sanitised:** moves R2 and R5 toward higher confidence.
- **Equity terms in writing:** closes RR4.
- **Deeper company research (one offer):** funding, leadership changes, past hiring reports, up to 5 more searches and 2 more fetches. Say the word if you want it.

**Questions**

- **R6:** Have you ever set up a design practice or made product decisions with no senior designer to check with? What happened?
- **H2:** What is your base salary floor, and is €52,000 above it?
- **R2:** Do you have one real project, even a messy one, that you could show on the call?

Answer any, all, or say "skip" and I won't re-ask.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.