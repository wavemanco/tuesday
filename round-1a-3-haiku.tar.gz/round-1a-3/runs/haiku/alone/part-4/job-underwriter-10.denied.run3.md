**Decision: conditional_go.** Apply, and take the 45-minute call, but confirm the company is real through channels you find yourself before you share anything beyond what you've already sent. Web research was blocked (WebSearch permission was not granted), so the company checks below are still open.

**Hard gates:** Location is met: Galway, two days a week in office, and you already live there `[grounded]`. Pay is €52,000–€60,000 stated in the posting `[grounded]`; I don't know your floor. Schedule is unknown.

## Role reality

- **Role:** First product designer at a six-person Galway company making booking software for sea-kayak and surf schools `[grounded]`. You would own the booking flow end to end, run research with school owners, and work directly with two engineers `[grounded]`.
- **Scope:** Solo design ownership with no design peers. The posting says so plainly `[grounded]`.
- **Market calibration:** Not established. Research was unavailable, so I have no verified market band for this title or salary. Any comparison would come from my memory, which I'm not using as a source.
- **Contradictions:** None in the posting itself. The posting doesn't mention WhatsApp as a contact channel; the first contact came that way `[grounded]`.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | 3+ years product design | must-have | strong | high (as stated) | none | 4 years at a Dublin travel-booking company `[grounded]` |
| 2 | Strong Figma | must-have | strong | medium | none | Daily Figma use `[grounded]`; no portfolio reviewed |
| 3 | Ran your own user research | must-have | strong | medium | transferability | Monthly usability sessions with customers `[grounded]`; these were with travellers, not school owners |
| 4 | Works directly with engineers | must-have | strong | medium | none | Squad of four engineers `[grounded]` |
| 5 | Owns a product area end to end | implied | partial | medium | capability | Redesigned the checkout flow `[grounded]`; you've never been the only designer |
| 6 | Comfortable as the only designer | implied | unknown | low | capability | No evidence either way |
| 7 | Location and hybrid pattern | hard gate | strong | high | none | Lives in Galway `[grounded]` |

**Gap recovery queue:** Row 6 and row 3's domain shift are the two real gaps. Both are answerable in a conversation, not a credential problem.

## Opportunity risk register

- **Failed attribution (open):** I could not confirm Fernquay exists as described (stage, size, product) because research was blocked. Possible reasons, none ranked: too new or small, a stale posting, or not a live hiring employer. This caps the decision at `conditional_go` until verified.
- **Channel mismatch (low):** Recruiting contact by WhatsApp is unusual for a formal process but is not in itself a warning sign. Treat it as something to verify, not a conclusion.
- **Case study reference (verify):** Ronan says they "loved the checkout case study." Confirm you sent it, and through which route, so you know which email or application this refers to.
- **Pay (unknown):** Stated range is `[grounded]`; whether it meets your floor is your call.
- **Red flags checked:** No demand for payment, equipment money, bank details, or ID before an offer. No hiring entirely by chat. None present `[grounded]`.

**How to verify the company without relying on the contact:**
1. Find the company's website yourself through a search, not from the message, and check that it describes the same product and team.
2. Check that Ronan Kehoe and Saoirse (the CTO) appear with that company on LinkedIn or the company site.
3. Search the Companies Registration Office (CRO) for a registered Fernquay entity in Ireland.
4. Confirm the calendar invite and video link come from the company's own domain, not a free email address.
5. Find the original job listing on the platform where you saw it.

**Application plan:** Proceed with the call. Lead with the checkout redesign and the monthly customer research sessions. For the research gap, frame it as "I've run research with customers in a booking flow; I'd expect school owners to be a different but familiar audience." Don't claim experience you don't have. Share nothing sensitive (ID, bank, tax details) before a written offer.

## Evidence status

Research tier: L1 — searches 3 of 5, fetches 0 of 2; all searches refused by permission (WebSearch not granted).

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | unavailable | WebSearch permission not granted |
| 2. Role-family sweep (scope, title, pay) | unavailable | WebSearch permission not granted |
| 3. Hiring manager's public footprint | unavailable | WebSearch permission not granted; no lookup done |

## Dossier offer

If you want, I can save this assessment as a `tuesday-dossier.md` you can carry into later stages.

## Upgrade menu

- **Grant WebSearch** and I can check the company site, the CRO record, and Ronan's and Saoirse's public profiles. This would move the failed-attribution entry.
- **Your checkout case study** (or a link), so I can check the claims the posting refers to.
- **Your pay floor** and any non-negotiables (schedule, travel, hours), so I can test the salary gate.

## Questions

1. What is your minimum acceptable salary, and are there any other hard limits on schedule or travel? *(Response modes: answer, skip, or tell me to continue without it.)*
2. Did you send the checkout case study to Fernquay yourself, and through which route: an application form, email, or a job board? Could you share the original job listing link?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.