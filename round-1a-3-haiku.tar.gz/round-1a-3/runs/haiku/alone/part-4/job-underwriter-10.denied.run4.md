## Decision: conditional go

Keep going, but verify the company before you share more than you already have. The role fits your background well. What's unverified is whether Fernquay is the company it describes, and that is the one thing a 45-minute call can't settle on its own.

**Hard gates:** location meets the hybrid Galway requirement `[grounded]`. Pay is unknown against your floor, which you haven't stated. Authorization isn't addressed in the posting or your background, so it's unknown.

**Fit ledger:**

| Priority | Fit | Requirements |
|---|---|---|
| Must-have | Meets | 3+ years, strong Figma, works with engineers |
| Must-have | Partly | Own user research (you have it, but with customers, not school owners), owns booking flow end to end (scope unverified) |
| Implied | No evidence | Working as the only designer |
| Preferred | Unknown | Messy real project (you have one case study, not yet in hand) |

**Research tier: L1 — searches 3 of 5, fetches 0 of 2.** All three searches were refused by the permission setting, so nothing about the company or the market has been checked. This is not a finding about Fernquay.

## Role reality

- **Organization:** six people, Galway, sea-kayak and surf school booking software `[grounded]`. Existence and stage are not established (see the failed-attribution entry below).
- **Scope:** first designer, owns the booking flow, runs research with school owners, ships with two engineers `[grounded]`. That is a broad remit with no design peers.
- **Contradictions:** none found in the posting itself.
- **Market calibration:** not run. I can't check €52,000–€60,000 against role-family norms without search, and I won't use memory for a market value.
- **Compensation:** the band is stated in the posting `[grounded]`. Equity at 0.5–1% has no stated value, vesting or share class `[grounded]`.

## Evidence map

| # | Priority | Fit | Requirement | Your evidence | Gap | Confidence |
|---|---|---|---|---|---|---|
| R1 | Must | Meets | 3+ years product design | 4 years at a Dublin travel-booking company `[grounded]` | None | Medium (stated, not verified) |
| R2 | Must | Meets | Strong Figma | Daily use, stated `[grounded]` | No artifact shown yet | Medium |
| R3 | Must | Partly | Has run own user research | Monthly usability sessions with customers `[grounded]` | Domain: school owners, not travel customers `[inferred]` | Medium |
| R4 | Must | Meets | Works directly with engineers | Squad of four engineers `[grounded]` | None | Medium |
| R5 | Must | Partly | Owns booking flow end to end | Redesigned checkout, which is one stage of booking `[grounded]` | Scope of ownership unverified; checkout is not the whole flow | Low–medium |
| R6 | Implied | No evidence | Works as the only designer | Never been the only designer `[grounded]` | Capability: no solo-practice record `[inferred]` | Low |
| R7 | Preferred | Unknown | Shows a messy real project | Checkout case study, which Ronan says they liked `[grounded]` | Not yet shared or checked | Unknown |
| H1 | Hard gate | Meets | Location (Galway, two days/week) | Moved back to Galway last year `[grounded]` | None | Stated |
| H2 | Hard gate | Unknown | Pay vs your floor | Floor not stated | Hard-gate check cannot run | — |
| H3 | Hard gate | Unknown | Authorization | Not in the posting or background | Not asked | — |

## Gap recovery queue

- **G1 (company existence):** no live posting, company site or search results checked. Closed by: the company's own domain, a live posting link, and confirming the sender's domain.
- **G2 (checkout scope):** you may have led the design or contributed to it. Closed by: stating what you decided versus shared, and showing the case study.
- **G3 (school-owner research):** your research is with travel customers, not small operators. Closed by: a short story on how you'd adapt usability sessions to school owners.
- **G4 (solo practice):** no record of working alone as a designer. Closed by: a concrete account of how you'd set up design decisions, review and feedback without peers.
- **G5 (pay and equity):** your floor is unknown, and the equity has no stated value. Closed by: your floor, and asking the company for the share class, vesting and strike terms.

## Opportunity risk register

| Class | Item | Severity | Notes |
|---|---|---|---|
| Failed attribution | Company existence not confirmed | Medium | Reasons, none ranked as likely: too new or small, a stale posting, or no public web presence. Caps this at conditional go until verified. What resolves it: the company's own domain, a live posting link, the sender's email domain, and a registry check (Ireland's CRO register for "Fernquay") |
| Scope mismatch | First designer, owns the whole booking flow, two engineers | Medium | Demanding for someone who has always worked in a squad `[inferred]` |
| Compensation | Band not calibrated against market | Unknown | Search needed |
| Equity | 0.5–1% with no stated terms | Unknown | Ask for the share class, vesting and strike terms |

**The WhatsApp message:** not a red flag. A co-founder following up a case-study application on WhatsApp is a common channel at a small company. The skill's red-flag test is paying for anything, depositing money, giving bank or ID details before an offer, or being hired entirely by chat. None applies here. Confirm the calendar invite comes from a company-domain address, since that's the real check.

**Positive signals:** they read your checkout case study before contacting you, the next step is a call with the CTO, the hybrid pattern fits your move back to Galway, and the posting says it values a real messy project over a polished deck `[grounded]`.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Before sharing more, check the company: its domain, the live posting, the sender's address, a CRO search | Closes the failed-attribution entry | `[generic]` standard diligence | Yours to do |
| P2 | Prepare the checkout story with explicit scope: what you decided, what you proposed, what shipped | Closes G2; checks R5 | `[grounded]` posting and background | Pending your approval |
| P3 | Prepare a short answer on working without design peers, and how you'd adapt usability sessions to school owners | Closes G3, G4 | `[inferred]` from R3, R6 | Pending your approval |
| P4 | Ask on the call for the salary range, equity terms and what "first designer" means for decisions | Closes G5 | `[grounded]` posting | Pending your approval |
| P5 | Hold work samples until the company is verified | Limits what leaves your hands | `[generic]` | Pending your approval |

For rehearsing the 45-minute call itself, mock-interview is the right tool; this assessment doesn't cover that.

## Evidence status

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company official site and careers page | unavailable | Web search permission was denied for this session |
| 2 | Role-family sweep (scope, title, pay) | unavailable | Same |
| 3 | Co-founder's public footprint | unavailable | Same; search was refused before the name could be checked |

## Upgrade menu

- **Search permission:** lets me check the company, the posting and the market band for €52,000–€60,000. This is the input that unlocks most of the open rows.
- **Live posting link and company website:** lets me check whether the posting is live and consistent with what you were sent.
- **The checkout case study:** raises R5 and R2 from stated to shown.
- **Your salary floor:** lets the pay hard gate be checked.

Dossier offer: I can write `tuesday-dossier.md` to carry this assessment forward if you want it.

## Questions

1. **[G1]** Can you share the company's website and the job-post link, and tell me which address the invite came from? Answer in your own words, or say "skip".
2. **[G5]** What's your salary floor, and do you want the equity terms tested?
3. **[G2]** On the checkout redesign, which parts did you decide, which did you propose, and what shipped?

Answer in your own words, or say "skip". Silence is also an answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.