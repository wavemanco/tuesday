**Research note:** Both company searches and both role-pay searches were refused, so nothing about either employer or market pay is verified. Everything below rests on the two postings and your background as you described it.

# 1. Operations Analyst, Duinvaart Cold Chain (Rotterdam)

## Decision snapshot

**Worth applying to, on conditions. Status: `conditional_go`.** You clear the four must-haves on your CV. The open questions are the Rotterdam office schedule, temperature data (which you haven't worked with), and whether this employer is real.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Rotterdam office, three days a week)
- `must_have` — direct: R2 (2+ years in logistics or operations analysis), R3 (SQL), R4 (Power BI or Tableau), R5 (track on-time delivery)
- `important` — direct: R7 (weekly dashboards), R8 (route changes with depot managers) · adjacent: R6 (temperature compliance across refrigerated fleet)
- `preferred` — adjacent: R9 (Dutch, a plus)

R6 (`low`) — no temperature evidence on your CV, so the honest claim is adjacent KPI monitoring only; R9 — conversational, not fluent, limit named.

**Opportunity ledger.** The posting is specific: named responsibilities and measurable outcomes (RA2, positive). Two things hold the decision back: no salary is stated (RA1), and the employer is not verified because the search was refused (RA3, standing entry, `severity: medium`), which caps the decision at `conditional_go`.

- **Hard gates:** none failed; unconfirmed: R1 (Rotterdam office, three days a week); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 confirmed: you can commute to Rotterdam three days a week; (2) RA3 cleared: the role appears on Duinvaart's own careers site, and you can get the interviewer's name there; (3) R6 is framed as transferable KPI monitoring, never as cold-chain experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam | `[grounded]` JD header |
| Mandate | Track on-time delivery and temperature compliance across a refrigerated fleet; build weekly Power BI dashboards; work with depot managers on route changes | `[grounded]` JD |
| Scope read | A standard analyst remit: KPIs, dashboards, and route input, with no decision rights stated | `[inferred]` from the responsibility list |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Market calibration | Not run; no salary or scope band for this role | — |
| Unknowns | Salary; whether the analyst owns route decisions or only advises; what the temperature KPI measures | — |
| Contradictions | None found within the posting | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | none | hard_gate | Your location and commute were not given, so the gate is not settled | `[grounded]` JD; constraint not given | Q1 |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier; CV claim, not yet probed. The carrier is parcel, not cold chain | `[grounded]` CV | none |
| R3 | Strong SQL | must_have | direct | medium | none | Daily SQL use is specific; "strong" is self-assessed | `[grounded]` CV | none |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use, on a dashboard depot managers use | `[grounded]` CV | none |
| R5 | Track on-time delivery | must_have | direct | medium | none | The on-time dashboard is the same kind of KPI work | `[grounded]` CV | none |
| R6 | Track temperature compliance across refrigerated fleet | important | adjacent | low | transferability | Your CV has no temperature or cold-chain data. Adjacency is general KPI monitoring only, and the limit is the data type | `[inferred]` from CV silence on temperature | Q2 |
| R7 | Build weekly dashboards in Power BI | important | direct | medium | none | Weekly reporting on route performance | `[grounded]` CV | none |
| R8 | Work with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review; the decision rights are not stated | `[grounded]` CV | none |
| R9 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational, not fluent. Limit: you cannot run the depot conversation in Dutch yet | `[grounded]` your intake | upgrade menu |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R6, important) | transferability | Parcel on-time work only; no temperature, cold-storage, or reefer data | Likeliest interview probe; the bridge narrows it | Any tracking of a non-timing compliance KPI; alerts or exception reports you triaged | An anonymised exception report or KPI sheet | `[inferred]` bridge from the CV; `[generic]` that interviewers probe this |
| G2 | Office location (R1, hard_gate) | hard_gate | No constraint given | Decides whether the role is open to you at all | — | A stated commute limit | `[grounded]` JD; constraint not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RA1 | Salary not stated | unknown | — | (JD silent on pay) | Pay may sit outside your target range | `[grounded]` the JD states no pay | What is the salary range for this role? | unresolved |
| RA2 | Outcomes defined and measurable | positive_signal | — | "Track on-time delivery and temperature compliance across our refrigerated fleet" | Scope and success measures are concrete | `[grounded]` JD | Which two numbers must this role move in its first year? | noted |
| RA3 | Employer not verified | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. Research was refused, so this is an unverified claim, not a finding about the employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume line, proposed: "Ran the weekly route-performance review." Clause traces to your sentence "I ran our weekly route-performance review." | R8 | `[grounded]` your intake | `resume_edits_pending_approval` |
| E2 | Resume line, proposed: "Used SQL and Power BI daily, including the on-time delivery dashboard depot managers use." Clauses trace to your sentence. Not "built" or "maintained" until you say which | R3, R4, R5 | `[grounded]` your intake | `resume_edits_pending_approval` |
| W1 | Before applying, find the role on Duinvaart's own careers site and use that contact route | RA3 | `[generic]` pattern | pending your approval |
| W2 | For R6, say what you have, not what you lack: parcel on-time monitoring, plus the limit that no temperature data was involved | R6 | `[inferred]` from CV silence | pending your approval |

## Evidence status (Duinvaart)

Verified: none yet.

---

# 2. Supply Planner, Kroonhaven Foods (Utrecht)

## Decision snapshot

**Not worth applying to now. Status: `no_go`, on fit.** Your background does not hold the core of this role: the 13-week plan ownership (R3) and the forecast-to-capacity balance (R4) are planning work you have not done. Fluent Dutch (R7) is short of the bar. A planning history cannot be built in the time between now and an application. This is a recommendation; the call is yours.

**Fit ledger.**

- `hard_gate` — unclear: R1 (on-site in Utrecht)
- `must_have` — adjacent: R2 (3+ years of FMCG planning, `low`), R4 (balance capacity against forecast, weekly S&OP), R7 (fluent Dutch) · unclear: R5 (advanced Excel), R6 (SAP IBP or similar planning system) · absent: R3 (own the 13-week supply plan)

R3 — the core ownership requirement, with no planning history; R2 — delivery analysis is near planning but not planning.

**Opportunity ledger.** The posting is clear: the plan, the S&OP meeting, and the capacity balance are defined (RB2, positive). Pay and contract type are not stated (RB1, unknown). Employer not verified, as for Duinvaart (RB3, standing, `severity: medium`).

- **Hard gates:** none failed; unconfirmed: R1 (on-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a planning-adjacent history you have not yet told me about (forecasts, capacity or stock figures you have built), plus a realistic Dutch fluency timeline. Neither is in your background as you described it.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht | `[grounded]` JD header |
| Mandate | Own the 13-week supply plan for chilled ready meals; balance production capacity against forecast; run weekly S&OP | `[grounded]` JD |
| Scope read | A full planning-owner role, not an analyst support role | `[inferred]` from "own" and "run" |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Market calibration | Not run; no band | — |
| Unknowns | Salary; contract type; who owns the forecast the plan uses | — |
| Contradictions | None found within the posting | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Your location and commute were not given | `[grounded]` JD; constraint not given | Q1 |
| R2 | 3+ years supply or demand planning in FMCG | must_have | adjacent | low | transferability | Delivery and route-performance analysis is near planning, but it is not forecasting or FMCG. Years are a length requirement, not a gate | `[inferred]` from CV | none |
| R3 | Own a 13-week supply plan for chilled ready meals | must_have | absent | medium | capability | You have said you have never worked in planning; no ownership of any plan on your CV. Closure needs a planning role or a scoped project, not a CV edit | `[grounded]` your intake | none; closure path below |
| R4 | Balance production capacity against forecast; run weekly S&OP | must_have | adjacent | medium | transferability | You ran a weekly cross-functional review. Limit: no capacity or forecast work | `[grounded]` CV | none |
| R5 | Advanced Excel | must_have | unclear | low | discovery | Excel is not on your CV at all | `[grounded]` CV silence | Q3 |
| R6 | SAP IBP or similar planning system | must_have | unclear | low | discovery | No planning system on your CV; "similar" is broad | `[grounded]` CV silence | Q3 |
| R7 | Fluent Dutch | must_have | adjacent | medium | capability | Conversational is a real base; fluent is a higher bar, and the posting states it | `[grounded]` your intake | upgrade menu |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G3 | Planning ownership (R3, must_have) | capability | No planning history; you have said so | Core of the role; a CV edit cannot close it | A planning-adjacent role or a scoped demand-forecast project; a planning course with a real plan as output | A plan or model you built, even for a non-work purpose | `[generic]` closure routes in planning roles |
| G4 | Dutch fluency (R7, must_have) | capability | Conversational | The posting says fluent; this is a stated bar | Dutch study with a recognised exam | An exam result | `[grounded]` JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RB1 | Pay and contract not stated | unknown | — | (JD silent) | Pay and contract may be outside your range | `[grounded]` the JD states neither | What is the salary and contract type for this role? | unresolved |
| RB2 | Planning scope defined | positive_signal | — | "Own the 13-week supply plan" | Scope and cadence are concrete | `[grounded]` JD | Who owns the forecast the plan is built on? | noted |
| RB3 | Employer not verified | risk_signal | medium | "Kroonhaven Foods, Utrecht" | As RA3: may be too new or small, stale, or not a real hiring employer. Research was refused; this is unverified, not a finding | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Do not apply yet. Redirect to roles whose requirements do not ask for planning years, and that match your analysis background | R2, R3 | `[generic]` role-family pattern | pending your approval |
| P2 | If you do have any forecasting or Excel model work, tell me. It would change R5 and R2 | R2, R5 | `[inferred]` from the gap | pending your approval |

## Evidence status (Kroonhaven)

Verified: none yet.

---

# Research and evidence status

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht chilled ready meals"; both refused, no result. Employer existence (RA3, RB3) unverified |
| 2. Role-family sweep | unavailable | Searched "operations analyst cold chain logistics Rotterdam salary" and "supply planner FMCG Netherlands salary S&OP SAP IBP"; both refused, no result. No market band for either role (RA1, RB1) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Verified: none yet.

# Upgrade menu

- **Search permission** (or you confirm the two careers pages yourself): verifies both employers (RA3, RB3) and gives market pay bands for RA1 and RB1.
- **Your commute and location limits** for Rotterdam three days a week and on-site Utrecht: decides R1 on both postings; both gates stay unconfirmed without it.
- **The on-time dashboard, built or maintained, and one number it moved:** raises R5 from `medium`, and the bullet in E2 can then say what you did.
- **Any temperature, cold-storage or refrigerated-vehicle data work, even one KPI:** would move R6 from `low`.
- **A sample of any forecast, capacity or Excel model you have built:** would answer R5 and R6 and could reopen R2.
- **A Dutch exam result or certificate:** an inspectable artifact that would firm up R9 and R7.

# Questions

- **R1 (both postings):** Can you commute to Rotterdam three days a week, and to Utrecht on site?
- **R6 (Duinvaart):** Have you ever tracked temperature, cold-storage or refrigerated-vehicle data, even as one KPI among others?
- **R5 and R6 (Kroonhaven):** Have you built forecasts, capacity or stock figures in Excel or a planning tool, even informally?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.