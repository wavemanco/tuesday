## Decision: no-go as presented. Send nothing.

**Hard gates:** Your €30,000 floor is at risk. At the €26/hour ceiling, 30 hours a week gives about €40,500 a year, and 15 hours gives about €20,300. You would need about 23 hours a week at the maximum rate to reach €30,000, before any commission, which the posting doesn't quantify. [grounded]

**Fit on paper:** Your background matches most of the stated requirements. Three years of ticket handling in Zendesk, a weekly Excel tracker and training two new starters line up with attention to detail, spreadsheets and onboarding. Order processing itself is not evidenced, and written English is only shown by your CV, not by a work sample. [inferred from your background]

**Opportunity ledger: the messages are the problem.** Each of these is a quoted red flag at high severity:

1. **Payment for equipment:** "Please pay €349 by bank transfer to our equipment partner." Legitimate employers don't ask new hires to pay for their own work kit.
2. **Cheque overpayment:** "Lodge it to your account, keep €350 … transfer the rest to our equipment partner." You would be sending real money from your account against a cheque that hasn't cleared. A cheque can be returned after the money has left your account, and you would be the one out of pocket. [generic pattern]
3. **Sensitive details before any offer:** IBAN, PPS number and passport photo were requested before any interview. Don't send these.
4. **Hiring entirely by Telegram,** with no calls, video or company email domain. The contact address is a generic mail domain, not a company one. [grounded]

**On whether it's a scam:** I can't tell from here who is behind these messages, and I'm not making a claim about Velloway Logistics itself. But the requests are the ones a fake-job scam makes: an offer that's easy to get, a cheque, and money to send out. I'd treat the offer as unsafe and do nothing further with it.

**What to do now:**
- Don't send your IBAN, PPS number, passport photo or any money.
- If a cheque arrives, don't deposit it.
- Check whether the company exists through its own website, a registry such as the CRO, or a phone number you find there, not through Telegram or the email in the message.
- If you have already sent anything, call your bank now and report the Telegram account. In Ireland, report it to the Gardaí.

**Research tier: L0, no searches.** I haven't checked whether Velloway Logistics is registered or has a live posting, so that check is still open.

**Dossier offer:** I can write a `tuesday-dossier.md` for this role so the reasoning is on record.

**Upgrade menu:**
- A link to the company's own website or careers page would let me check that the company exists without going through Telegram.
- A link to where you found the posting would let me check whether it's still live.
- If you want the fit assessment to be firmer, a CV file would raise the confidence of the evidence rows.

**Questions:**
1. Do you have a link to Velloway's own website or careers page? If so, I'll check the company against it.
2. Do you want me to run the L1 check on the company's registration and live postings? It's up to 5 searches and 2 page fetches.

Reply with a link, yes or no, or skip either one. Skipping is an answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.