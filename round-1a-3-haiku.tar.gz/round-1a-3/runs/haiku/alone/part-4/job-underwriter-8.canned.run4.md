**Decision: no_go on this offer. Don't send anything else to @VellowayHiring.** Don't send the IBAN, PPS number, or passport photo, don't pay the €349, and don't deposit the cheque.

**Research tier: L0, no searches.** Everything below comes from the text you pasted. Nothing about Velloway Logistics has been checked against the outside world.

**Decision snapshot**

| Ledger | Read |
|---|---|
| Opportunity | no_go, on the posting's own terms |
| Candidate fit | Strong on the core work, unverified on written English and on order processing |
| Hard gates | Pay floor (€30,000/yr) is unconfirmed by the posting (`hard_gate`, unknown) |

**Role reality**

- **Stated:** remote order processing, 15–30 hours/week, "up to" €26/hr plus commission per order, no experience needed, hiring entirely on Telegram.
- **Arithmetic [grounded]:** at €26/hr, 15–30 hours/week is about €20,300–€40,600/yr at the top rate. Base pay and commission are unstated, so the posting does not show whether €30,000 is reachable.
- **Process [grounded]:** the sequence is a Telegram chat, then a request for IBAN, PPS and passport before any interview, then a cheque to deposit, a cut kept, and the rest sent to a third-party "equipment partner."

**Opportunity ledger: red flags (all quoted from the messages)**

1. **Money from you to them:** "Pay €349 by bank transfer to our equipment partner." A legitimate employer supplies its own equipment or reimburses after verified receipts. It does not ask a new hire to pay a third party.
2. **Cheque, then transfer:** "Lodge it to your account, keep €350… transfer the rest to our equipment partner." Cheques can be returned unpaid days or weeks later, and the bank then debits the amount you already sent on. The transfer is the money going out.
3. **Sensitive data before any offer:** IBAN, PPS and passport photo requested before the "chat interview." Those details belong only after a written offer from a verifiable company channel.
4. **Hiring wholly by chat:** no call, no video, no company email in the process. The only contact address is a Gmail-style postmail address for "problems."
5. **Pay is vague:** "up to" plus commission, with no base or contract terms.

Routine steps after a credible written offer, such as payroll forms through the employer's own portal, are not red flags. This posting skipped the written-offer stage and asked for the sensitive items first.

**Evidence map (candidate side, from your CV text; all `[grounded]` as stated, not verified)**

| Requirement | Your evidence | Fit | Gap |
|---|---|---|---|
| High-volume ticket handling | ~60 Zendesk tickets/day, 3 years at a parcel courier | Strong | Order processing specifically not shown |
| Training others | Trained two new starters | Strong | None |
| Spreadsheets | Keeps team's weekly Excel tracker | Strong | Formula depth unstated |
| Attention to detail | Implied by tracker and ticket volume | Partial | No error-rate or audit evidence |
| Good written English | Not evidenced in the material you gave me | Unknown | Needs a sample you're comfortable sharing |
| Quiet home workspace | Not addressed | Unknown | Your own confirmation |
| €30,000/yr floor | Your stated minimum | Unknown | Posting withholds the base |

**Gap recovery queue**

- **G1, pay floor:** closes only if the employer states a base salary or contract terms in writing from a verifiable channel.
- **G2, written English:** closes with a short written sample you choose to share. Nothing here needs sending to the employer.
- **G3, order processing:** the closest real-world proof is your ticket and tracker work. Frame it as transferable, not as prior order-processing experience.

**Risk register**

- **R1, pay-to-work demand (high, confirmed in the messages):** do not pay. A legitimate employer will not require a payment to a third party to start work.
- **R2, cheque-overpayment mechanics (high, confirmed):** do not deposit. Depositing and transferring funds exposes your account even if the cheque later bounces.
- **R3, identity documents requested pre-offer (high, confirmed):** do not send. If you already sent any of them, contact your bank and consider reporting the exchange to the Gardaí.
- **R4, unverified employer (standing entry):** I could not confirm that Velloway Logistics exists as described. Check the Companies Registration Office register and the company's own website, using contacts you find there, not the Telegram account or the postmail address.

**Application plan:** none recommended for this posting. If you want to pursue remote order-processing or support roles, search for postings that name a salaried contract, a company careers page, and a recruiter email on the company's own domain.

**Evidence status**

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | skipped | No research consent yet |
| 2 | Role-family pay and scope sweep | skipped | No research consent yet |
| 3 | Hiring contact's public footprint | n/a | No named hiring person |

**Dossier offer:** If you want, I can save this assessment as `tuesday-dossier.md` for later reference.

**Upgrade menu** (each input and what it unlocks)
- **Research (L1):** company site, careers page, and role-family pay; this would test whether the employer exists as described.
- **Original listing link:** would show whether the posting still exists on the jobs site.
- **A written sample:** would move G2 from unknown to evidenced.

**Questions**
1. Which jobs site did you find the listing on, and do you have its URL?
2. Have you sent Telegram anyone any of the three items, or any money, since the first message?
3. Would you like help drafting a reply that asks for a written contract from a company email domain?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.