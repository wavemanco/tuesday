**Yes, it looks like a real company, and it's worth applying to. Status: `conditional_go`.** Your skills map well onto the role. The open questions are your salary floor, whether you're comfortable being the only designer, and what the equity is worth. The WhatsApp message is routine interview scheduling, not a warning sign.

**Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 0**

## Decision snapshot

**Worth applying to: Status: `conditional_go`.** Fernquay's own site and live careers page match the posting, and I could attribute the co-founder to a public profile. So the employer is established, which clears the standing check. The footprint is still small, and that's consistent with a six-person company founded in 2023.

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (salary, against your floor, which I don't have)
- `must_have` — direct: R3, R4, R5 (usability work, not school-owner calls), R6, R7
- `important` — unclear: R8 (working as the only designer, never done)
- `preferred` — adjacent: R9 (booking for activity schools, not travel)

R5 — direct on customer research, with the school-owner gap named; R8 (`low`) — no sole-designer evidence yet.

**Opportunity ledger.** Checkable and mostly clean: the employer is established (RR5), the posting matches the JD (RR4), and the stated pay sits inside the market band for 3 to 5 years' experience (RR3). Open: how much design authority a first designer holds (RR1), the small-team reliance on Ronan (RR2), and what the equity is worth (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (€52,000–€60,000 against your salary floor); your salary floor was not given, so checks against it are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the base meets your floor (R2); (2) the call confirms what design decisions are yours alone (RR1); (3) the equity terms are clear enough to value (RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, makes Kelproster booking software for sea-kayak, surf and sailing schools in Ireland and Scotland, founded 2023 | `[grounded]` fernquay.example/about |
| Mandate | First designer: own the booking flow, run research with school owners, ship with two engineers | `[grounded]` posting, matches the live careers page |
| Working pattern | Hybrid, two days a week in Galway office | `[grounded]` posting and careers page |
| Scope read | A first design hire at a small team is a normal scope for this title; the work is defined, but nobody reviews your design day to day | `[inferred]` from team size against "first designer" |
| Market calibration | Ireland 3–5 years' experience: median base €57,000, interquartile range €51,500–€62,000 | `[generic]` Tillerby 2026 Ireland survey (n=520, not Galway-specific) |
| Pay | Posted €52,000–€60,000 sits inside that band; equity of 0.5–1% has no stated terms | `[grounded]` posting; `[generic]` band |
| Unknowns | Design decision rights, equity terms and vesting, your salary floor, whether there is any design review | — |
| Contradictions | None found. The message calls Saoirse CTO; the About page lists Saoirse as a co-founder, which is not a conflict | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Galway hybrid, two days a week | hard_gate | direct | high | none | You moved back to Galway last year | `[grounded]` your background | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | medium | discovery | Posted figure is in band; your floor is unknown | `[grounded]` posting | Q1 |
| R3 | 3+ years product design | must_have | direct | high | none | Four years at a Dublin travel-booking company | `[grounded]` your background | none |
| R4 | Own a booking flow end to end | must_have | direct | high | none | Redesigned the checkout flow at a booking company | `[grounded]` your background | none |
| R5 | Run your own user research | must_have | direct | medium | transferability | Monthly usability sessions with customers; no research with business owners | `[grounded]` your background | Q2 |
| R6 | Strong Figma | must_have | direct | high | none | Daily use | `[grounded]` your background | none |
| R7 | Work directly with engineers | must_have | direct | high | none | Four years in a squad with four engineers | `[grounded]` your background | none |
| R8 | Work as the only designer, shipping with two engineers | important | unclear | low | capability | Always embedded in a design team; never the only designer | `[grounded]` your background | Q3 |
| R9 | Activity-school booking domain | preferred | adjacent | medium | transferability | Travel booking, not school booking | `[inferred]` from your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Sole-designer work (R8) | capability | Team-embedded design only | The biggest practical risk to day-to-day success | Any time you set direction without a design lead, or ran a project alone | A short written note on how you'd run design review with no peers | `[inferred]` from your background |
| G2 | School-owner research (R5) | transferability | Customer-facing research only | The posting names this explicitly | Interviews with B2B or small-business users | A sanitized interview guide or summary | `[inferred]` from your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Design decision rights unstated | unknown | — | "You would be our first designer" | Design calls may sit with Ronan or the whole team, not with the designer | `[generic]` pattern for first design hires at small companies | Which design decisions are mine to make alone, and who reviews them? | unresolved |
| RR2 | Founder-led small team | risk_signal | low | "work most closely with our co-founder, Ronan Kehoe" | Your day-to-day feedback may come from one person | `[generic]` pattern for six-person companies | How do the founders and engineers review design work each week? | unresolved |
| RR3 | Pay inside the market band | positive_signal | — | "€52,000–€60,000" | Stated pay is fair for the experience | `[generic]` Tillerby 2026 band; `[grounded]` posting | What is the base range for this hire, and is it negotiable? | noted |
| RR4 | Equity terms not stated | unknown | — | "plus 0.5–1% equity" | The equity may be worth little or a lot depending on the cap table | `[inferred]` from the posting's silence on terms | What is the strike price, vesting schedule and cap-table size? | unresolved |
| RR5 | Employer established | positive_signal | — | "We are six people in Galway" | Employer exists and the posting is live | `[grounded]` fernquay.example pages | — | reduced |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Bring the checkout redesign to the call, with the usability sessions that shaped it | Recruiter said they loved the checkout case study | `[grounded]` the message and your CV | pending your approval |
| P2 | Prepare an honest answer to RR1: how you'd work when no design peer is there | Covers R8 without overclaiming | `[grounded]` R8 row | pending your approval |
| P3 | Reply on WhatsApp to confirm the time; check that the invite comes from fernquay.example | Scheduling by chat for a call held elsewhere is routine | `[grounded]` posting and the message | advice only |
| P4 | Rehearse the 45-minute call with Ronan and Saoirse using the mock-interview skill | Call prep is its job, not this one | — | optional |

## Evidence status

Verified: none yet. Your CV claims are stated in this conversation, not backed by an artifact.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software Galway sea kayak surf schools" and "Fernquay Product Designer job Galway"; fetched "About Fernquay" (fernquay.example/about) and "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Posting is live and matches; employer established (RR5) |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3 years experience Galway", which returned the Tillerby 2026 Ireland Design Salary Report (tillerby.example/2026-ireland-design-salary-report). Market calibration and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned a public profile (linkedin.example/in/ronan-kehoe), not fetched. Ronan is listed as co-founder and CEO, previously product lead at a Galway travel-software company for five years. Used for the positioning in P1 |

**Closing**

Want me to save this as `tuesday-dossier.md`?

**Upgrade menu**

- A sanitized note on how you'd run design review alone, or any project you've led solo → R8 moves up from `low`
- Anonymized notes from school-owner or business-user research → R5 moves to full direct
- Your salary floor → R2 resolves, and the decision could move to `go`
- Deeper research on Fernquay (funding, leadership changes, team size over time; up to 5 more searches and 2 more fetches) → say the word and it runs

**Questions**

1. (R2) What's the lowest base salary you'd accept?
2. (R5) Have you run research with business owners, or only with end customers?
3. (R8, RR1) Would you want a design peer, or are you comfortable working alone?

Answer in text, or say skip for any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.