## Decision snapshot

**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 (NMC registration), R2 (full UK driving licence)
- `must_have`: direct: R3 (one year post-registration), R4 (wound care), R5 (catheter care), R6 (insulin administration), R7 (home visiting). Adjacent: R8 (caseload ownership). Unclear: R9 (clear, timely written records)
- `important`: adjacent: R10 (care planning). Unclear: R11 (continence care), R12 (end-of-life visits), R13 (electronic patient record)
- `preferred`: absent: R14 (Doppler assessment)

R8 is a credible bridge with its limit named: you have never held a caseload. R1 and R2 are stated, not yet checked (`medium`).

- **Hard gates:** met, `direct`: R1, R2. Nothing failed. You did not state any personal constraints, so no constraint rows exist.
- **Opportunity ledger.** Sound. The employer exists as described, the pay range sits near the role-family middle, and the contact is a named team lead. The open items are whether the post is live, how much caseload support you get, and what Doppler training is provided.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a CIC running adult community nursing under an NHS contract across Calderdale. Founded 2015; about 410 staff; four locality hubs | `[grounded]` the company's About page, via search |
| Mandate | Adult district nursing for housebound patients: wounds and leg ulcers, catheters and continence, end-of-life visits, insulin, care planning, all on the EPR | `[grounded]` JD |
| Caseload | You hold your own small caseload, supported by a senior community nurse | `[grounded]` JD |
| Working pattern | Home visits; pool cars provided; mileage paid | `[grounded]` JD (mileage stated, rate not given) |
| Scope read | A normal scope for a band-5 community staff nurse post: own caseload, senior support, no service-lead duties | `[inferred]` from the JD's listed duties against its supervision line |
| Pay | £31,050–£37,800 plus mileage. The survey's median for this post is £34,300, with an interquartile range of £32,400–£36,600 (1,240 respondents). The posting's range sits around that middle | `[grounded]` JD; `[generic]` Wardround 2026 pay guide |
| Contact | Rhiannon Mabbott, Community Nursing Team Lead, who leads the Halifax district nursing team | `[grounded]` a forum speaker page, via search |
| Unknowns | Whether the post is live; caseload size; supervision frequency; EPR training; Doppler training; mileage rate | — |
| Contradictions | None found between the JD and the sources reached | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | NMC registration as Adult Nurse | hard_gate | direct | medium | none | Stated on the CV as active. Registration is checkable on the NMC register by you, not by this skill | `[grounded]` CV, stated | check your own register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Stated as category B, full. Checkable against your own licence | `[grounded]` CV, stated | check your own licence |
| R3 | One year or more post-registration experience | must_have | direct | medium | none | Five years as a staff nurse, stated | `[grounded]` CV | none |
| R4 | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds, stated. Leg ulcers not stated | `[grounded]` CV | see the leg-ulcer row in the risk register |
| R5 | Catheter care | must_have | direct | medium | none | Stated | `[grounded]` CV | none |
| R6 | Insulin administration | must_have | direct | medium | none | Stated | `[grounded]` CV | none |
| R7 | Home visiting (community setting) | must_have | direct | medium | none | Visits to patients at home in their first week after discharge, for 18 months | `[grounded]` CV | none |
| R8 | Holding a caseload | must_have | adjacent | medium | transferability | You have never held your own caseload. Home visiting is the nearest adjacency, and it is a bridge, not the same thing | `[inferred]` from the CV's home-visiting role against the JD's caseload duty | see the caseload question below |
| R9 | Clear, timely written records | must_have | unclear | low | discovery | The CV is silent on record-keeping quality, and the EPR system is not named | `[grounded]` CV silence | question Q1 |
| R10 | Care planning | important | adjacent | medium | transferability | Discharge planning for the first week at home is related but is not community care planning | `[inferred]` from the CV | none |
| R11 | Continence care | important | unclear | low | discovery | Catheter care is stated; continence assessment is not | `[grounded]` CV silence | question Q2 |
| R12 | End-of-life visits | important | unclear | low | discovery | Not stated | `[grounded]` CV silence | question Q2 |
| R13 | Electronic patient record | important | unclear | low | discovery | Not stated. Most acute trusts use an EPR, but the one you used is unknown | `[grounded]` CV silence | question Q1 |
| R14 | Doppler assessment for leg ulcers | preferred | absent | none | capability | Not held, and not claimed. Training provision unknown | `[grounded]` CV; JD says desirable | question in the risk register |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Caseload (R8, must_have) | transferability | Home visits and discharge planning, with no caseload held | This is the objection most likely to be raised | Any patient list you managed in discharge-to-assess, even informally | A sanitised note of a week's visit list and the follow-up you led | `[inferred]` bridge from the CV |
| G2 | Records and EPR (R9, R13, must_have and important) | discovery | Silent on both | The JD names clear, timely records as essential | Visit notes you wrote and how timely they were | An anonymised example of a visit note, with identifiers removed | `[grounded]` CV silence |

The questions for these rows go in the closing block, not here.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting liveness not confirmed | unknown | — | "For an informal chat about the role, contact…" | The post may be filled, paused, or no longer advertised. A careers page was not located by search | `[grounded]` search found the About page only | Can you send the link to the live posting or the application page? | unresolved |
| RR2 | Caseload support unstated | unknown | — | "supported by a senior community nurse" | Caseload size and supervision frequency may be set at interview | `[inferred]` from the JD's silence on both | What caseload size and supervision would I expect in the first year? | unresolved |
| RR3 | Doppler training not stated | risk_signal | low | "Desirable: Doppler assessment for leg ulcers" | Training may or may not be provided. The role is still open to you without it | `[inferred]` from the JD's wording | Is Doppler training provided, and is it expected in the first year? | unresolved |
| RR4 | Pay within the middle of the role-family range | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Pay is unlikely to be a barrier | `[grounded]` JD; `[generic]` survey | — | noted |
| RR5 | Employer established | positive_signal | — | "Calderbrook Community Health CIC" | The company exists as described, with 410 staff under an NHS contract | `[grounded]` About page, via search | — | noted |

Severity reads `—` on the unknown and positive rows, because the field applies to risk signals and red flags only.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put your home-visit wound, catheter and insulin work into specific outcome bullets. Do not describe the discharge-to-assess role as holding a caseload | see R4 to R8 | `[grounded]` CV | pending your approval |
| E2 | Check your NMC register entry and licence before you apply | see R1, R2 | `[grounded]` gate rows | pending your approval |
| A1 | Ask Rhiannon Mabbott about caseload size, supervision, EPR training, and Doppler training, in the informal chat | see RR2, RR3 | `[grounded]` contact and RR rows | pending your approval |
| A2 | Ask for the live posting link before you invest in an application | see RR1 | `[grounded]` RR1 | pending your approval |

No CV or outreach text will be finalised until you approve it.

## Evidence status

Verified: none yet from your side. Your CV claims are leads until you check them against your NMC register entry and licence, and until you can show a record or outcome for them. Employer facts (existence, size, NHS contract, the contact's role) are sourced from search results, not your documents.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "calderbrookhealth careers Community Staff Nurse vacancy". The About page (calderbrookhealth.example/about) confirms the company. The careers page was not found, so posting liveness is unverified (RR1) |
| 2. Role-family sweep | yes | Searched "Community Staff Nurse Band 5 district nursing Halifax salary £31,050 £37,800". The Wardround 2026 UK Community Nursing Pay Guide (wardround.example/2026-uk-community-nursing-pay-guide) gave the median and interquartile range (RR4) |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead". The speaker page (communitynursingforum.example/speakers/rhiannon-mabbott) confirms her public role. Public professional footprint only |

## Upgrade menu

- Your own NMC register entry and licence check → R1 and R2 move from `medium` to verified.
- The live posting link, or the company's careers page → RR1 closes.
- An anonymised visit note or caseload-style list from discharge-to-assess → R8 and R9 rise from `low` and `medium`.
- Answers on caseload, supervision, EPR and Doppler training, from the informal chat → RR2 and RR3 close.
- A deeper research pass on Calderbrook (staff reports, inspection history, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

A dossier file can be produced at the end of this engagement, as a record of this assessment and its evidence. Say so when you want one.

Answer each question in text, or say skip for any of them.

1. **[RR1]** Can you send the link to the live posting or the application page?
2. **[R12, R11]** In discharge-to-assess, did you do any end-of-life visits, continence assessments, or care planning that you led yourself?
3. **[R13, R9]** Which electronic record system did you use in discharge-to-assess, and were your visit notes timely?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.