**Decision snapshot: `no_go` on the opportunity as described. Don't send the IBAN, PPS number or passport, don't pay the €349, and don't lodge the cheque or forward any money.**

- **Fit (candidate side, separate from the decision):** Strong on the stated requirements. Customer service for about 3 years, Zendesk at about 60 tickets a day, training two starters, and an Excel tracker all map onto the posting. This is your own account and is unverified.
- **Opportunity:** The hiring process itself is the problem. The employer asks for bank, tax and ID details before any interview, asks you to pay for your own equipment, and asks you to deposit a cheque and send part of it onward. Those terms are not ones a legitimate employer sets.
- **Hard gates:** None stated. The €30,000 floor is not met by the posting's own terms (see below).

**Research tier: L1, searches 2 of 5, fetches 0 of 2; user links read 0**

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company's official site and careers page | unavailable | Searches for "Velloway Logistics" returned no results. I could not confirm the company exists as described, and no live posting was found. |
| 2 | Role-family sweep (scope, title, pay) | skipped | Pay check below uses the posting's own figures; no market data needed to decide. |
| 3 | Hiring manager's public footprint | n/a | No name was given; only the Telegram handle. |

**Role reality (`[grounded]` from the posting)**
- Pay: "up to €26/hour plus commission." At the maximum rate, 30 hours a week gives about €40,560 a year before commission; 15 hours gives about €20,280. Reaching €30,000 needs roughly 22–23 paid hours a week at the top rate, with commission unstated. The posting doesn't say what commission is worth.
- Contract basis, employer type and any employment contract are not stated anywhere.

**Evidence map (requirements against your background)**

| # | Requirement | Fit | Basis |
|---|---|---|---|
| 1 | Attention to detail | Likely | Your tracker and ticket volume (self-reported) |
| 2 | Spreadsheets | Likely | Weekly Excel tracker (self-reported) |
| 3 | Written English | Likely | Customer-service writing (self-reported) |
| 4 | Quiet workspace | Unknown | Not stated |
| 5 | Training | Met by the posting itself | "Full training provided" |

**Opportunity risk register**

| Class | Severity | Status | Finding |
|---|---|---|---|
| Red flag | high | confirmed | Quoted from the messages: pay €349 for equipment "refunded with first wages." Held while you check who sent it. |
| Red flag | high | confirmed | Quoted: "lodge" a €2,850 cheque, keep €350, transfer the rest to the "equipment partner." Moving money you receive for a third party is a serious risk to you even if the cheque later bounces. |
| Red flag | high | confirmed | Bank, PPS and passport details requested before any interview or written offer. |
| Red flag | high | confirmed | Hired wholly by chat, with no call, video or verifiable company contact. |
| Failed attribution | standing | open | The employer could not be found by name in search. This caps any `go` and must be resolved before you proceed. |
| Mismatch | medium | open | Contact is a generic address (velloway.hr@postmail.example), not a company domain I could check. |

**Application plan:** Don't apply through this route. If you still want this kind of role, look for postings that name a company with a findable website, careers page and phone number, and interview by call or video before any financial or ID details come up.

**Immediate actions, regardless of the decision**
- Don't send anything listed above, and don't paste your IBAN into the chat.
- If a cheque arrives, don't lodge it or send any part of it on. Contact your bank about it first.
- If you've already sent details, contact your bank and consider reporting it to your national police service and the Data Protection Commission about your PPS and passport data. Keep screenshots of the Telegram messages.

**Dossier offer:** If you want, I can produce a `tuesday-dossier.md` file of this assessment to keep or share.

**Upgrade menu (what would change the decision)**
- A live posting on a company-owned website, or the company's own careers page, plus a phone number that belongs to the company. Searches have found nothing so far.
- A contract or written offer from a company with a verifiable address and registration, sent through a channel that isn't Telegram, and dated after a call or video interview.
- A search for the company on the public company register in your country. I can't run this from here, but you can.

**Questions**
1. Has anything been sent yet: money, the IBAN, PPS or passport? Has a cheque arrived? *(gap recovery row: current exposure)*
2. Do you have a company website or careers page link for Velloway that didn't come through Telegram? *(row: failed attribution)*

Response modes: reply with answers, "skip", or "no more questions" to stop.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.