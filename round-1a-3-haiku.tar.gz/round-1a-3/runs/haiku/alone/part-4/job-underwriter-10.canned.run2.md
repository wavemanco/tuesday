**Decision: conditional_go.** Take the call, but verify the recruiter's identity and the company's details first. Nothing I found is a red flag.

**Decision snapshot**
- **Candidate fit:** Strong on the core requirements. Partial on the two domain requirements and on "only designer."
- **Opportunity:** The company and role check out on its own site. The main open items are equity terms and the first-contact channel.
- **Hard gates:** None failed. Galway location and two-day hybrid match her move back to Galway. Pay is stated, but her own salary floor is unknown to me, so that check is open.

**Role reality**
- **Company:** Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers. [grounded: fernquay.example/about]
- **Posting:** The careers page lists the same role, pay, hybrid terms and "apply with one real project" to jobs@fernquay.example. Consistent with the posting you pasted. [grounded]
- **Ronan Kehoe:** A public profile lists him as co-founder and CEO, previously product lead at a Galway travel-software company for five years. The WhatsApp message doesn't name a title, and nothing I found gives Saoirse's CTO title. [grounded, unverified title]
- **Market calibration:** Tillerby 2026 Ireland salary data, product designers with 3–5 years: median €57,000, interquartile range €51,500–€62,000. The posted €52,000–€60,000 sits inside that range, near the middle. [generic band; posted figure grounded]
- **Equity:** 0.5–1% is stated with no vesting, strike or share-class terms. [unknown]
- **Scope:** "First designer, own the booking flow end to end" is a large remit for a six-person team. [inferred from posting]

**Evidence map**

| # | Priority | Fit | Requirement | Evidence | Confidence | Gap |
|---|---|---|---|---|---|---|
| 1 | Must-have | Meets | 3+ years product design | 4 years at a Dublin travel-booking company | High (CV) | none |
| 2 | Must-have | Meets | Strong Figma | Daily use | High (CV) | none |
| 3 | Must-have | Meets | Has run own user research | Monthly usability sessions with customers | Medium (CV, no artifact) | none |
| 4 | Must-have | Meets | Works directly with engineers | Squad of four engineers | Medium (CV) | none |
| 5 | Must-have | Partial | Owns a booking flow end to end | Redesigned a checkout flow, not a full booking flow | Medium | transferability |
| 6 | Must-have | Partial | Research calls with school owners (B2B) | Research was with travel customers (consumers) | Medium | transferability |
| 7 | Implied | Gap | Works as the only designer | Never done it | None | capability |

**Gap recovery queue**
- **Row 7, sole designer:** No evidence either way. Closes with any example of making product decisions without a design lead above you, even on a short project.
- **Row 6, B2B research:** Closes with any interview work with business buyers. Consumer usability sessions are relevant but not the same.
- **Row 5, booking ownership:** Checkout is adjacent to booking. Claim what you did, not "end-to-end booking." This is a positioning point, not a hard gate.

**Opportunity risk register**
- **Risk signal (low):** First contact came by WhatsApp from a co-founder, with a calendar invite by email. Ordinary for a small Irish company, but verify it.
- **Unknown:** Equity terms, and whether the CTO is Saoirse Doyle.
- **Positive signals:** Company exists and is consistent across its site, careers page and posting. Founders are named publicly. Pay sits inside the market band.
- **Red flags:** None. Nothing asks you to pay, send bank details, deposit anything or share ID before an offer.

**Verifying the call**
- The invite should come from a fernquay.example address (the domain on the careers page), not a personal or free-mail account.
- The video link should be on a standard platform, with the same people named in the invite as in the message.
- Before any written offer, don't send bank, tax or ID details. Ask for the offer in writing first.

**Application plan**
1. Take the 45-minute call. It's a reasonable next step for a company that named a specific case study.
2. Bring one messy real project, not only the checkout case study. They asked for this explicitly.
3. Answer the sole-designer and B2B research questions honestly. Don't claim booking-flow ownership or school-owner research you haven't done.
4. Ask about equity: vesting, strike price, share class, and what 1% means at the latest valuation.
5. Ask what "first designer" means in practice: who sets priorities, and who reviews your work.

**Evidence status**

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | yes | Queries: "Fernquay booking software Galway sea kayak surf schools", "Fernquay careers product designer Galway". Pages: fernquay.example/about, fernquay.example/careers/product-designer |
| 2. Role-family sweep (salary, scope) | yes | Query: "product designer salary Ireland mid-level 3 years Galway". Page: Tillerby 2026 Ireland Design Salary Report |
| 3. Hiring manager public footprint | yes | Query: "Fernquay Galway Ronan Kehoe". Page: Ronan Kehoe public profile (linkedin.example). Professional facts only. |

Research so far is L1. An L2 run (funding history, hiring patterns, recent news, candidate reports) is available on your say-so, up to 5 more searches and 2 more fetches.

**Dossier offer:** If you want, I can save this assessment as a `tuesday-dossier.md` file that can carry into later prep.

**Upgrade menu**
- A messy real project to show: this would raise the "owns the booking flow" row and the research row.
- Any interview work with business buyers, or a sole-decision example: this would close rows 6 and 7.
- Equity terms from the company: this would clear the main unknown.
- Your salary floor: this lets me check the pay gate properly.

**Questions** (response mode: answer in prose, or skip any)
1. (row 7) Have you ever made product decisions with no design lead above you, even briefly? What happened?
2. (row 6) Have you ever interviewed business customers rather than consumers?
3. (gate) What's your minimum acceptable base salary? That lets me check the pay gate properly.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.