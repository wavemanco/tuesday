**Decision: conditional_go.** Apply if you want the role, but check the company before you share more than your CV. I can't confirm the company is legitimate, and nothing I have shows that it isn't. Nothing in what you've shared asks you to pay, send bank or ID details before an offer, or accept an offer over chat.

**Decision snapshot**

| Ledger | Result |
|---|---|
| Candidate fit | Strong on the stated requirements, with one real gap (being the only designer) |
| Opportunity quality | Unverified employer; the posting itself is specific and plausible |
| Hard gates | Location and hybrid pattern met [grounded]. Salary floor unknown: you haven't stated one |
| Research | None completed (see evidence status) |

**Role reality**
- Product Designer, first design hire at a six-person Galway company making booking software for sea-kayak and surf schools. Owns the booking flow, runs research with school owners, works directly with two engineers, reports closely to co-founder Ronan Kehoe. CTO is Saoirse [grounded, from your message].
- Pay is €52,000–€60,000 plus 0.5–1% equity. The salary band is [grounded] from the posting. Whether it's market-normal is not established, since I had no research access, so I can't calibrate it. Equity at 0.5–1% for a six-person company is common in early-stage startups but its value is unknown [generic].
- Contradiction to note: "first designer" and "work closely with engineers" are consistent, but a small team with no design lead means the role sets its own process. Ask about that.

**Evidence map**

| # | Priority | Fit | Requirement | Your evidence | Confidence | Gap |
|---|---|---|---|---|---|---|
| R1 | must-have | Strong | 3+ years product design | 4 years at a Dublin travel-booking company [grounded] | high | none |
| R2 | must-have | Strong | Strong Figma | Daily use [grounded] | high | none |
| R3 | must-have | Strong | Run your own user research | Monthly usability sessions with customers [grounded] | high | Customers were travel buyers, not school owners; transferability |
| R4 | must-have | Strong | Work directly with engineers | Squad of four engineers [grounded] | high | none |
| R5 | must-have | Partial | Own the booking flow end to end | You redesigned checkout [grounded]; end-to-end ownership not stated | medium | Confirm scope (Q3) |
| R6 | important | Gap | Be the only designer | Never been the only designer [grounded] | n/a | capability: no direct evidence |
| R7 | hard gate | Met | Based in or near Galway (2 days/week in office) | Moved back to Galway last year [grounded] | high | none |
| R8 | hard gate | Unknown | Salary acceptable | No floor stated | unknown | Q2 |

**Gap recovery queue**
- **G1 (R5, transferability):** Checkout redesign shows you can own a high-stakes flow. What it didn't exercise is owning the whole flow from research through shipping alone. Closing path: a case study that shows the full loop, including where you made the call.
- **G2 (R6, capability):** No direct evidence of solo design work. Closing path: be honest about it and describe how you'd set your own cadence with two engineers and no design peer.
- **G3 (R3, transferability):** Customer type differs. Closing path: say how you'd adapt interview guides to business owners who are also operators.

**Opportunity risk register**
- **Employer existence: not established** (class: verification, severity: high). I could not search, so I can't confirm Fernquay exists as described. Possible reasons include a very new or small company, a stale posting, or no real hiring entity; I'm not ranking them. This caps the decision at conditional_go until verified.
- **Contact channel** (severity: low). Recruiting contact by WhatsApp plus an emailed invite is common for small companies. It isn't a red flag by itself, but the sender's identity hasn't been checked.
- **Equity uncalibrated** (severity: low). Value unknown.

**Application plan**
- Lead with checkout ownership and monthly usability research, both verifiable.
- Prepare one "messy real project" to show. The posting asks for it, and your checkout case study may serve if you can show your decisions and what you'd change.
- For the solo gap, say what you did in the squad and what you'd need to set up, rather than claiming solo experience.

**Verify before the call** (advice, not findings):
- Find the company's own website and careers page, and check the posting appears there.
- Search the Irish Companies Registration Office (CRO) register for the company name.
- Check that the calendar invite's sender domain matches the company's domain.
- Look up Ronan and Saoirse on LinkedIn to confirm their roles.
- Never send bank, tax or ID details before a written offer.

**Research tier: L1 — searches 2 of 5, fetches 0 of 2** (both searches were refused for lack of permission)

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | unavailable | Web search permission was denied |
| 2. Role-family sweep (pay, scope) | unavailable | Web search permission was denied |
| 3. Hiring manager's public footprint | skipped | Not run; the company check comes first |

I can save this assessment as `tuesday-dossier.md` for a later prep session if you'd like.

**Upgrade menu**
- **Company's live posting link or careers page:** lets me check that the posting exists and matches what you were sent.
- **Web search permission:** lets me run the company check and the salary-market comparison.
- **Salary floor:** lets me test R8, the hard gate that's currently unknown.
- **Checkout case study or a work sample:** raises R1, R3 and R5 from stated to verifiable.

**Questions**
1. (G1) Did you own the checkout redesign end to end, from research through shipping, or contribute within a team? Tell me which parts were yours.
2. (R8) What is your salary floor? I'll test the offer against it.
3. (verification) What is the company's website URL, and what domain did the calendar invite come from?

Answer in text, or say skip for any of these.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.