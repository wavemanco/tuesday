**Decision: no-go as posted. Don't send anything to this recruiter.** Your background fits the skills the role asks for, but the process asks you to pay, and to hand over bank and ID details, before any real offer exists. That is a risk to you whatever the intent behind it.

**Decision snapshot**
- **Opportunity:** no-go as posted. Reassess only if the employer verifies itself through channels you find yourself and drops the payment and advance-detail requests.
- **Candidate fit (separate ledger):** strong on the skills the posting lists.
- **Hard-gates:** the €30,000 floor is not met on the posting's own terms. The pay is "up to €26/hour" plus unspecified commission, for 15–30 hours a week. [inferred] At 46 paid weeks that is roughly €18k–€36k base before commission, so the floor depends on the top of the hours range and on commission you can't see.
- **Research tier:** L0, no searches. I did not check whether Velloway Logistics exists. The decision above doesn't depend on that check.

**Red flags (quoted, from the posting and messages)**
1. "Please pay €349 by bank transfer to our equipment partner." A job should not cost you money to start.
2. "Send your IBAN, your PPS number and a clear photo of your passport" before the chat interview. Bank and ID details belong only after a written offer from a verified employer.
3. "We are posting you a cheque for €2,850… transfer the rest to our equipment partner." Forwarding money from a cheque before it clears is a known loss pattern. A cheque can bounce after the money has gone out, and the loss is yours.
4. Hiring entirely by Telegram, with "no calls or video interviews," and a contact address on a generic free-mail domain (`postmail.example`), not a company domain.
5. Pay described as "up to," with commission on "orders" that is never defined.

Each of these is a confirmed high-severity red flag on the posting itself. Verify the company only through contacts you find on its own website or a public company register, not through the Telegram handle or the email address they gave you.

**What to do now**
- Don't paste your IBAN, PPS number or passport anywhere in this conversation. You don't need to, and you shouldn't.
- Don't pay the €349 and don't transfer any money.
- If a cheque arrives, don't deposit it or forward any part of it.
- If you've already sent any details or money, call your bank now, report it to Gardaí, and ask your bank whether the transfer can be recalled.
- Report the listing to the jobs site.

**Your background against the role**
- Attention to detail and spreadsheets: supported by your Excel tracker and 60 Zendesk tickets a day. [grounded, from what you told me; not yet verified by a third party]
- Good written English and a quiet workspace: not evidenced yet.
- Training two new starters and handling customer tickets at volume are transferable to real operations-coordinator and support roles. [generic]

**Dossier offer:** I can save this assessment as `tuesday-dossier.md` so you can carry it into later applications.

**Upgrade menu**
- A research check (L1: up to 5 searches and 2 page fetches) on whether Velloway Logistics exists as described, and whether the posting appears on its own site.
- Your written English and a sample of your work, to firm up the two unevidenced requirements.
- A few real listings you're considering, so I can test them against the same checks.

**Questions** (answer any, or say "skip"):
1. Do you want the L1 research check on Velloway?
2. Have you already sent any details or money to this contact?
3. Can you share the original jobs-site listing, so I can compare it with what Telegram told you?

Respond with numbers, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.