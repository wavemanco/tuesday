**Decision snapshot**

- **Opportunity: `no_go` as posted.** Three requests in this conversation are red flags on their own: a €349 equipment payment before any start, IBAN/PPS/passport before a written offer, and a cheque to deposit with a share of it sent on to a third party. Do not send anything through this channel.
- **Fit (separate ledger): strong on the listed requirements.** Your Zendesk volume, your training of new starters and your Excel tracker map onto the stated requirements. Written English and a quiet workspace are not yet evidenced.
- **Pay floor: at risk on the posting's own terms.** €26/hour × 15–30 hours is about €20k–€40k a year before commission. Reaching €30k needs roughly 23 or more hours a week, and "up to" means that is not guaranteed.
- **Hard-gates line:** pay floor (€30k), fit: at risk, unverified (`hard_gate`). Work authorization and location: not raised, not checked.
- **Research tier: L0, no searches run.** Nothing about Velloway Logistics has been checked outside what you pasted.

**Role reality**

- **Stated role** `[grounded]`: "Remote Order Processing Coordinator," 15–30 hours a week, up to €26/hour plus commission per order, training provided, no experience needed.
- **Process** `[grounded]`: all contact on Telegram, no calls or video. You were told you "passed screening" before any interview, then "passed the interview" after chat answers.
- **Organization** `[grounded]`: the posting gives a company name and a Telegram handle. It gives no website, no registration details, and no address. The contact email, `velloway.hr@postmail.example`, is not on a company domain.
- **Compensation calibration:** the €30k figure is your floor. Stated pay at 15 hours a week is below it; at 23+ hours it reaches it. Commission is unquantified `[grounded]`, so total pay cannot be calculated.
- **Market calibration:** not run. Role-family pay norms are `[generic]` only, pending research.

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | Attention to detail | Must-have | Likely | Medium | Presentation | Keeps the team's weekly Excel tracker (stated) |
| 2 | Confident with spreadsheets | Must-have | Likely | Medium | Presentation | Excel tracker (stated); no formula or level detail |
| 3 | Good written English | Must-have | Unverified | Low | Discovery | English CV prose only; no writing sample |
| 4 | Order or ticket processing | Preferred | Transferable | Medium | Transferability | ~60 Zendesk tickets/day at a parcel courier (stated) |
| 5 | Quiet place to work | Must-have | Unknown | None | Discovery | Not raised in your background |
| 6 | Hours 15–30/week | Structural | Fits | High | None | Schedule terms match your availability `[inferred]` |
| 7 | Pay ≥ €30k/yr | Hard gate | At risk | Low | Capability | See Role reality; depends on hours and unstated commission |
| 8 | Trains and onboards new staff | Preferred | Strong | High | None | Trained two new starters (stated) |

**Gap recovery queue**

- **Row 3, written English:** a short writing sample from your work would raise this. Anything a customer could have read, shared as you like.
- **Row 5, quiet workspace:** a fact only you can supply. It closes the row either way.
- **Row 7, pay floor:** closes only with a written, quantified pay offer and hours you would actually work, not a range.
- **Row 1–2, spreadsheets:** naming one concrete tracker outcome (what you built, what it tracked, for whom) would move these from "likely" to "strong."

**Opportunity risk register**

1. **Red flag, `severity: high`, `confirmed`:** "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." `[grounded]` Paying for equipment before employment is not a step to take on this basis.
2. **Red flag, `severity: high`, `confirmed`:** "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport." `[grounded]` Bank, tax and ID details go to an employer only after a credible written offer.
3. **Red flag, `severity: high`, `confirmed`:** "We are posting you a cheque for €2,850. Lodge it to your account, keep €350… and transfer the rest to our equipment partner." `[grounded]` A cheque can take weeks to clear. Sending money out before it clears leaves you carrying the loss if it bounces.
4. **Red flag, `severity: high`:** hired entirely over Telegram, with a job offer made after a chat. `[grounded]`
5. **Failed attribution, standing entry:** the employer cannot be confirmed from the material you gave. Possible reasons, none ranked: a new or very small firm, a stale posting, or a recruiter who is not an employee of the named company. This caps any `go` at `conditional_go` until verified. What would resolve it: a company website you find yourself (not linked from the chat), a careers page, and an official contact number for the company. Ask those contacts, not the Telegram account, to confirm the role and the equipment arrangement.
6. **Mismatch:** pay against your €30k floor, per Role reality.

**Application plan**

- Do not apply via this Telegram channel and do not send the IBAN, PPS number, passport photo or any payment.
- If you want to test whether the role is real: find the company's own website and careers page through a search you run yourself, and check the company's registration on the Irish Companies Registration Office (CRO) register. Apply only through the company's own careers page.
- If it checks out, lead with your ticket volume, your training of new starters, and your Excel tracker. These are stated, not verified, so back them with a sample before you claim them in writing.
- Nothing in this plan changes your CV. Any CV or outreach wording is `resume_edits_pending_approval`, to be finalized only on your explicit approval.

**Evidence status**

| Target | Status | Reason |
|---|---|---|
| 1. Company official site and careers page | skipped | Research not run; needs your consent |
| 2. Role-family sweep (scope, title, pay) | skipped | Research not run; needs your consent |
| 3. Hiring manager's public footprint | n/a | No named hiring manager; only a Telegram handle was given |

**Research tier: L0 — no searches**

Dossier offer: I can save this assessment as `tuesday-dossier.md` for later, if you want it.

**Upgrade menu**

- **Research at L1** (up to 5 searches and 2 page fetches): checks whether Velloway Logistics exists as described and whether its careers page lists this role. This is the most useful next step.
- **L2 on top** (up to 5 more searches and 2 more fetches): company history, public candidate and employee reports, and recent news.
- **A writing sample** from your work: closes row 3.
- **A tracker example:** closes the spreadsheet rows at "strong."

**Questions**

1. Do you have a company name, website or phone number for Velloway Logistics that you found outside Telegram?
2. May I run the L1 research on the company (up to 5 searches and 2 page fetches)?
3. How many hours a week would you actually work, and is €30k a base-pay figure or does it depend on commission?

Answer any of these, or skip any; a skip is an answer.

If you have already sent any of your IBAN, PPS number, passport or money, contact your bank now, and consider reporting the messages to the Gardaí.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.