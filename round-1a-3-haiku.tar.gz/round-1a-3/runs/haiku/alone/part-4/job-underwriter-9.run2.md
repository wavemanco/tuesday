**Short answer: yes, this is normal.** After a written offer, an Irish employer will ask for bank details for salary, a PPS number for Revenue, and an ID check to meet its right-to-work obligation. Asking to see the original passport on day one is also standard. Your instinct is right for the period before an offer, not for this stage. `[generic]`

Two things still matter. Enter the details only in the portal at the address on Marrowgate's own website, not through a link you were emailed. And never email a passport scan or PPS number as an attachment.

**Decision: `conditional_go`.** Apply and accept, once you've confirmed the employer through its own website. The fit is strong on the core of the role. Pension changes are the one real gap.

**Hard gates:** none stated in the posting. Your constraints (notice period, pay floor, hybrid) weren't given, so checks against them are unknown.

**Severe red flags:** none found. Your two in-person interviews at their office, and an offer that names the role, salary, manager, hours and start basis, all count against the chat-scam pattern. `[grounded]`

### Research tier
Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

Searches were refused by the host (permission not granted), so the company check and the market salary band could not run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search permission was refused. Would have confirmed the entity, its size, and that the posting is live. |
| 2. Role-family sweep | unavailable | Search permission was refused. Would have set the €38–42k band against Limerick payroll norms. |
| 3. Hiring manager's public footprint | unavailable | Not searched. Declan Garvagh's name was given, but search permission was refused. |

### Role reality
| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, housing association, Limerick | `[grounded]` posting |
| Scope | Monthly payroll for 240 staff; starters, leavers, pension changes; payroll-to-GL reconciliation; staff queries | `[grounded]` posting |
| Pay | €40,000 offered, inside the posted €38–42k band | `[grounded]` offer and posting |
| Reporting | Declan Garvagh, Finance Manager | `[grounded]` offer |
| Unknowns | Whether the employer is verified; who runs pensions day to day; whether Irish statutory payroll is run in-house | — |

### Evidence map
| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years running payroll | must_have | direct | high | none | Three years fortnightly payroll for 90 staff | `[grounded]` CV | none |
| R2 | Starters and leavers | must_have | direct | high | none | Covered in the hotel role | `[grounded]` CV | none |
| R3 | Monthly payroll-to-ledger reconciliation | must_have | direct | high | none | Done in the hotel role | `[grounded]` CV | none |
| R4 | Pension changes | must_have | unclear | low | discovery | Never run yourself; your manager handled them | `[grounded]` CV and your statement | see G1 |
| R5 | Irish PAYE, PRSI, USC | must_have | unclear | medium | discovery | Payroll certificate held; Irish statutory deductions not explicitly stated in your background | `[inferred]` from certificate | see G2 |
| R6 | Strong Excel | important | direct | high | none | Daily pivot tables and XLOOKUP | `[grounded]` CV | none |
| R7 | Payroll qualification or working towards one | important | direct | high | none | Payroll Technician certificate, 2024 | `[grounded]` CV | none |
| R8 | Staff payroll queries | important | adjacent | medium | transferability | Payroll support is implied, but not described as query handling | `[inferred]` from role scope | none |
| R9 | Scale of 240 staff | preferred | adjacent | medium | transferability | Your payroll covered 90 staff; the same process at a larger scale is a step up | `[inferred]` | none |

### Gap recovery queue
| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pension changes (R4, must_have) | discovery | Pension changes are not on your CV; your manager handled them | A must-have the interviewers will probe | Checking pension deductions or contribution-rate changes before they went through payroll; supplying the data for a pension scheme change; liaising with a pension provider | A pension change checklist, a provider letter, or a payroll change log | `[grounded]` CV silence; `[generic]` that this is probed |
| G2 | Irish PAYE, PRSI, USC (R5, must_have) | discovery | The certificate exists, but your CV doesn't describe running Irish statutory deductions | Core to the job and likely checked early | Calculating PAYE, PRSI and USC on pay runs; Revenue returns (RPN/ROS) | A payslip sample (anonymised), a Revenue return summary | `[grounded]` CV; `[inferred]` |

### Opportunity risk register
| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The entity may be small or new, the posting may be stale, or the employer may not be verified. Search was refused, so this is unresolved, not a finding. | `[generic]` pattern for small employers | Can you point me to the role on your own careers page, and confirm the people I'd report to? | unresolved |
| RR2 | Offer-stage request for bank, PPS and passport | routine (no entry) | — | "add your bank details ... PPS number ... passport" | Routine after a written offer naming role and pay; no entry, per the skill's rule | `[generic]` Irish onboarding practice | — | — |

### Application plan
| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the email domain against the company's own website, and find the careers page yourself | Confirms the offer is genuine | `[grounded]` RR1 | pending your approval |
| A2 | Enter bank, PPS and ID details only in the portal at the address on the company's website | Keeps your data with the employer | `[generic]` | pending your approval |
| A3 | Prepare one honest answer on pensions (what you did, what you didn't) | Closes G1 without overstating | `[grounded]` CV | pending your approval |

### Evidence status
Verified: R1, R2, R3, R6, R7 (CV and certificate). Verified: none yet for R4 and R5, both still leads.

### Upgrade menu
- The company's own careers page or the live posting → RR1 closes.
- A pension change checklist or provider letter → R4 moves toward direct.
- A payslip sample or Revenue return summary → R5 moves toward direct.
- Your notice period and pay floor → hard-gate checks run.
- Search access on a later turn → the company check and the market salary band run.

**Questions**
G1 — Have you ever checked, prepared or supplied data for a pension change, even if your manager made the final call? What did you do, and what didn't you touch?
G2 — Have you calculated or submitted Irish PAYE, PRSI and USC on pay runs? If so, which Revenue submissions did you handle?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.