**Decision: conditional_go.** The role is worth pursuing and the company checks out on public pages. Take the call, but verify the invite and ask about runway and equity before you commit.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

## Decision snapshot

- **Fit:** strong on the core requirements (Figma, research, working with engineers, 4+ years). The gap is being the only designer, which is a transferability gap, not a missing skill.
- **Opportunity:** no red flags found. Two open risks: equity value is unknown, and the company is small and thinly documented.
- **Hard gates:** location (Galway), hybrid schedule (2 days in office) and pay (within band) all pass on what's stated. No hard gate fails.
- **Confidence:** the company and posting are consistent across the sources I could reach.

## Is it legit?

- **Company:** a public About page describes Fernquay as a six-person Galway company making booking software for sea-kayak, surf and sailing schools, founded 2023 by Ronan Kehoe and Saoirse Doyle. `[grounded]` (search snippet; I did not fetch this page)
- **Co-founder:** a LinkedIn result lists Ronan Kehoe as co-founder and CEO, previously a product lead at a Galway travel-software company. `[grounded]` (search snippet)
- **Posting:** the careers page is live and matches your posting word for word on role, hybrid pattern, salary and equity. `[grounded]` (fetched)
- **WhatsApp:** a co-founder reaching out on WhatsApp is a normal channel at a company this size. It is not itself a warning sign. The one thing to check is that the calendar invite comes from a Fernquay email address and not a personal one. I have no evidence that anything is wrong with the message.
- **Red flags:** none. Nothing asks you to pay, send bank or ID details, or hand over anything before an offer.

## Role reality

- **Pay:** €52–60k. A 2026 Irish design salary survey (n=520) puts the median for product designers with 3–5 years at €57k, IQR €51.5–62k. `[generic]` The posted band sits in the middle of that. `[grounded]`
- **Equity:** 0.5–1%, with no information on the cap table, funding or vesting. The About page says the company is funded by its customers, which suggests no outside investors. `[grounded]` Whether 0.5–1% is worth anything depends on figures you don't have.
- **Scope:** the first designer owns the booking flow end to end, runs research with school owners, and ships with two engineers. That is a wide remit with no design team around you. `[grounded]`

## Evidence map (abbreviated)

| Requirement | Fit | Basis |
|---|---|---|
| 3+ years product design | Met | 4 years at a Dublin travel-booking company |
| Strong Figma | Met | Daily use |
| Own research | Met, with a transfer step | Monthly customer usability sessions. These were consumer-facing, not school owners, so you'll need to explain the transfer. |
| Works directly with engineers | Met | Four-engineer squad |
| First/only designer | Gap, transferable | Never been the sole designer |

## Gap recovery queue

- **Sole-designer gap:** closes with a concrete example of working without design peers (for instance, how you set standards or got engineers to adopt a flow).
- **Research with business customers:** closes by showing that customer usability work carries over to school owners.

## Risk register

- **Thin public footprint** (`severity: medium`, `confirmed` that little is online): verify the invite and ask for a live customer or product link during the call.
- **Equity value unknown** (`severity: medium`): ask about funding, revenue and how the option is structured.
- **Sole-designer scope** (`severity: low`, a judgement call about your preferences): you have never done this, so decide whether you want it.

## Application plan

- **Lead with:** the checkout redesign and the monthly customer sessions. Show that you have run research and shipped flows.
- **Address the sole-designer point directly** and don't hide it.
- **Proposed wording** is a resume edit and waits for your approval before you use it.

## Evidence status

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | yes | Queries: "Fernquay Galway booking software…", "Fernquay careers product designer". Fetched the careers page. |
| 2 | Role-family sweep | yes | Query: "product designer salary Ireland Galway 3 years experience". Tillerby 2026 snippet. |
| 3 | Hiring manager's public footprint | yes | Query: "Ronan Kehoe Fernquay co-founder". LinkedIn snippet. |

## Dossier offer

If you want, I can save this as a `tuesday-dossier.md` to carry into interview prep.

## Upgrade menu

- **Deeper company diligence (L2, up to 5 more searches and 2 more fetches):** funding, leadership changes and public employee or candidate reports. This would show whether the company is stable.
- **Your portfolio or the checkout case study:** would raise the confidence on the research and Figma rows.

## Questions

1. Does the calendar invite come from a Fernquay email address, and did you apply through jobs@fernquay.example?
2. What is the company's runway, and how does the equity work (vesting, cap table, what happens if it isn't sold or floated)?
3. Are you comfortable being the only designer, or does that part worry you?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.