**Yes, it's routine: asking for bank details, PPS number and a passport scan after a written offer is standard onboarding. Accept only after you've checked the employer on its own website, because I could not verify Marrowgate from here.** `conditional_go`

**Fit ledger.**

- `hard_gate`: unclear: R1, R2, R3
- `must_have`: direct: R4, R7, R8 · adjacent: R6 · unclear: R5
- `important`: direct: R11, R12 · unclear: R10 · absent: R9

R4, R7 and R8 meet the bar on your own account; R6 transfers from 90 staff fortnightly to 240 monthly; R5 is the one that matters most and is unclear; R9 is the duty you have not done.

**Opportunity ledger.** The role terms are clear and the offer sits inside the published band (RR4), and the two in-person interviews are a positive sign (RR4). The employer is not established: the searches were refused, so Marrowgate's existence and the offer's sender domain are unchecked, not disproved (RR1). Pension scheme details and the monthly scale are unstated (RR2, RR3).

- **Hard gates:** none failed; unconfirmed: R1 (reaching the Limerick office two days a week), R2 (right to work in Ireland), R3 (salary against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 clears: the role and the portal address appear on Marrowgate's own website, and the offer's sender domain matches it; (2) R1 and R2 are confirmed on your side; (3) R5 holds up when you describe the Irish PAYE, PRSI and USC work you have actually done.

**Role reality.**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick; existence not established | `[grounded]` posting; `[generic]` standing failed-attribution pattern |
| Mandate | Monthly payroll for 240 staff, starters, leavers, pension changes, monthly payroll-to-GL reconciliation, staff queries | `[grounded]` posting |
| Working pattern | Permanent, hybrid, two days a week in the Limerick office, reporting to Declan Garvagh (Finance Manager) | `[grounded]` posting and offer |
| Scope read | Solo payroll administration at about 2.7 times your current headcount, with a monthly cadence you have not run | `[inferred]` from the posting against your CV |
| Market calibration | Not run: no role-family sweep, so no market band | — |
| Compensation | €40,000 offered against a posted €38,000–€42,000; your floor not given | `[grounded]` offer and posting |
| Unknowns | Pension scheme and provider; payroll software; the share of queries the role owns; how the right-to-work check is done | — |
| Contradictions | None between the posting and the offer letter | `[grounded]` |

**Evidence map.**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Reach the Limerick office two days a week | hard_gate | unclear | none | hard_gate | Your location was not stated | `[inferred]` from the posting's terms | Q1 |
| R2 | Right to work in Ireland without sponsorship | hard_gate | unclear | none | hard_gate | Not stated; the offer asks for a passport scan for a right-to-work check | `[inferred]` from the offer | Q1 |
| R3 | Salary against your floor | hard_gate | unclear | none | hard_gate | Your floor was not given; €40,000 sits mid-band | `[grounded]` offer and posting | Q2 |
| R4 | Two or more years running payroll | must_have | direct | medium | none | Three years fortnightly payroll for 90 staff; self-reported | `[grounded]` your message | Confirm with a run example at interview |
| R5 | Working knowledge of Irish PAYE, PRSI, USC | must_have | unclear | low | discovery | Certificate is the nearest evidence; the tax regime you ran is not stated | `[inferred]` from the certificate title | Q3 |
| R6 | Monthly payroll for 240 staff | must_have | adjacent | medium | transferability | Your payroll is fortnightly for 90; the volume and cadence are not run. Limit: no monthly run at this scale | `[grounded]` your message; `[inferred]` transfer | Describe the steps you already run, at your scale |
| R7 | Starters and leavers | must_have | direct | medium | none | Three years of starters and leavers | `[grounded]` your message | none |
| R8 | Monthly payroll-to-GL reconciliation | must_have | direct | medium | none | Monthly reconciliation to the ledger | `[grounded]` your message | none |
| R9 | Pension changes | important | absent | none | capability | You have not done them; your manager handled them. Closure path: learn the scheme's change process | `[grounded]` your message | Say so plainly at interview |
| R10 | Answering staff payroll queries | important | unclear | low | discovery | Not stated | `[inferred]` | Ask at interview |
| R11 | Strong Excel | important | direct | medium | none | Daily use, pivot tables, XLOOKUP; no artifact | `[grounded]` your message | none |
| R12 | Payroll qualification or working towards one | important | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your message | none |

**Gap recovery queue.** Its questions sit in the closing block, tagged by row.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish tax regime (R5) | discovery | Certificate only; no tax-regime detail | Must-have and the main gap in the fit ledger | Running PAYE and USC changes after a rate change; PRSI class questions raised by staff | A payslip or run checklist with names removed | `[inferred]` |
| G2 | Pension changes (R9) | capability | You have not done them | Important; closure path needed | Assisting a manager with scheme joiners or opt-outs; a pension-provider file | A procedure note | `[grounded]` |

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The employer may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. Searches were refused, so this is unchecked, not negative | `[generic]` pattern for employers of this size | Can you point me to this role on your careers page, and confirm the address of your onboarding portal? | unresolved |
| RR2 | Scale and cadence | risk_signal | low | "run the monthly payroll for our 240 staff" | Fortnightly for 90 and monthly for 240 are different workloads; the team may be thin | `[inferred]` from the posting against your CV | How many pay runs a month do you process, on which software, and how are the 240 staff split across pay groups? | unresolved |
| RR3 | Pension scheme unstated | unknown | — | "process ... pension changes" | The scheme's complexity sets how much of R9 the role carries | `[inferred]` from the posting's silence | Which pension scheme and provider do you use, and who approves pension changes? | unresolved |
| RR4 | Compensation within band, two-stage interview | positive_signal | — | "€40,000 a year" against "€38,000–€42,000"; "two interviews in person at their office" | The offer is set against a published band; the in-person process is harder to fake | `[grounded]` posting, offer and your account | Who will I work with day to day, and what is the review process for the post? | noted |

Onboarding requests are not register entries: they are routine after a written offer that names the role and pay.

**Application plan.** All rows are proposals; nothing is sent or saved without your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check Marrowgate on its own website: the role, the People Team contact, and that the offer's sender domain matches | RR1 | `[grounded]` the offer's domain; `[generic]` check pattern | proposed |
| A2 | Enter bank, PPS and passport details only in the portal at the address the employer's website gives; never by reply email | Routine step, done safely. Payroll needs a PPS number for Revenue reporting | `[generic]` Irish PAYE practice | proposed |
| A3 | Ask the People Team how the right-to-work check is done (scan, original, or in person) | The offer asks for both the scan and the original | `[grounded]` offer | proposed |
| A4 | Lead with three years of fortnightly payroll for 90 staff, starters and leavers, and monthly reconciliation; state the Irish tax work only as far as you have done it; say pension changes are new to you | Avoids inflating R5 or R9 | `[grounded]` your message | proposed |
| A5 | Reply to accept within five working days only after A1 clears | The offer asks for a reply within five working days | `[grounded]` offer | proposed |

**Evidence status.** Verified: none yet. Everything above rests on your account, which counts as a lead until you confirm it in your own words.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | All four searches were refused because search permission was not granted. Would have moved RR1 (does Marrowgate exist as described, and is the posting live) and A1 (whether the offer's domain matches its site) |
| 2. Role-family sweep | unavailable | Same refusal. Would have set a market band for this title, scope and location against €38,000–€42,000 |
| 3. Hiring manager's public footprint | unavailable | Same refusal. Declan Garvagh was named; would have moved the scope read and which story to lead with for this reader |

**Dossier offer.** If you want this kept as a file, I can write it up as `tuesday-dossier.md`.

**Upgrade menu.**

- Your right-to-work status and your floor salary → R2 and R3 move off unclear.
- Where you live relative to Limerick → R1 moves off unclear.
- A sanitized payroll run checklist or reconciliation workbook → R8 to `high`, and R5 gets a basis.
- A copy of the Payroll Technician certificate → R12 to `high`.
- The live posting link and Marrowgate's careers page → RR1 closes or stays open.
- Permission to search → reruns targets 1 to 3 on this same plan; a deeper pass at L2 is available on request, up to five more searches and two more fetches.

**Questions.**

- Q1 (R1, R2): Can you reach the Limerick office two days a week, and do you have the right to work in Ireland without sponsorship?
- Q2 (R3): What's the lowest salary you'd accept for this post?
- Q3 (R5): Which Irish payroll rules have you run end to end, PAYE, PRSI and USC, and in what software?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.