## Decision snapshot

**Job 1: Operations Analyst, Duinvaart Cold Chain (Rotterdam)**
Status: `conditional_go`. Apply once the posting checks out and the three-day Rotterdam schedule works for you.
- Fit: R1, R2, R3 and R4 are `direct` (must-haves). R5 (temperature compliance) is `absent`.
- Hard gates: R9 `unclear` (three office days a week in Rotterdam; your home location and commute are not stated).
- Opportunity: no red flags in the posting. No pay is stated. The employer is not yet verified (standing entry, below).

**Job 2: Supply Planner, Kroonhaven Foods (Utrecht)**
Status: `no_go` as posted. The gap is in fit, not in the role. The posting shows no red flags.
- Fit: R1 (3+ years FMCG planning) and R4 (SAP IBP or similar) are `absent`. R5 (fluent Dutch) is `adjacent`. R3 (advanced Excel) is `unclear`.
- Hard gates: R6 `unclear` (on-site Utrecht; your home location is not stated).
- Opportunity: no red flags. No pay is stated. The employer is not yet verified.

Research tier: L0, no searches. Neither employer has been checked, and no market pay band is given, because model memory is not a source for either.

---

## Job 1: Duinvaart Cold Chain

**Fit ledger**
- hard_gate: `unclear`: R9
- must_have: `direct`: R1, R2, R3, R4; `absent`: R5
- important: `direct`: R6, R7
- preferred: `adjacent`: R8

**Evidence map**

| # | Priority | Fit | Confidence | Gap | Requirement and evidence |
|---|---|---|---|---|---|
| R1 | must_have | direct | high | none | 2+ years in logistics or ops analysis. Four years as an ops analyst at a parcel carrier. |
| R2 | must_have | direct | high | none | Strong SQL. Used daily. |
| R3 | must_have | direct | high | none | Power BI. Used daily. |
| R4 | must_have | direct | high | none | On-time delivery tracking. You built the dashboard depot managers use. |
| R5 | must_have | absent | medium | transferability | Temperature compliance across a refrigerated fleet. Nothing in your background covers it. Monitoring compliance metrics may transfer. |
| R6 | important | direct | high | none | Weekly Power BI dashboards. |
| R7 | important | direct | high | none | Working with depot managers on route changes. You ran the weekly route-performance review. |
| R8 | preferred | adjacent | medium | capability | Dutch. Conversational, not fluent. Counts as a plus, not a match. `[inferred]` |
| R9 | hard_gate | unclear | low | hard_gate | Three days a week in the Rotterdam office (inferred from the posting). Your location and commute are not stated. |

**Opportunity risk register**
- **Employer not established (standing entry).** Not checked at L0. Possible reasons, none ranked as likely: the company is too new or small, the posting is stale, or it is not a real hiring employer. This caps the decision at `conditional_go`. *Verification question for the employer:* "Is this role open now, and can you confirm it on your careers page?" Route it through the company's own site, not through any recruiter contact.
- **Pay not stated (`risk_signal`, low).** *Question:* "What is the pay range for this role?"
- **Cold-chain gap (R5).** Not a risk to the employer; a risk to you if the interview goes deep on temperature compliance. *Question:* "What do compliance monitoring and escalation look like day to day?"

**Application plan (as far as evidence allows)**
- Lead with the on-time delivery dashboard and the route-performance review. Those are the verified stories that match R4 and R7.
- Say plainly that cold-chain temperature work is new to you. Do not describe it as experience.
- Describe Dutch as conversational, not fluent.
- Apply only after the posting verifies and your schedule question (R9) is answered.

---

## Job 2: Kroonhaven Foods

**Fit ledger**
- hard_gate: `unclear`: R6
- must_have: `absent`: R1, R4; `unclear`: R3; `adjacent`: R5
- important: `adjacent`: R2, R7

**Evidence map**

| # | Priority | Fit | Confidence | Gap | Requirement and evidence |
|---|---|---|---|---|---|
| R1 | must_have | absent | high | capability | 3+ years of supply or demand planning in FMCG. You have never worked in planning. This needs time, not wording. |
| R2 | important | adjacent | medium | transferability | Running a recurring weekly review (S&OP-style meeting). The route-performance review is the closest match. |
| R3 | must_have | unclear | low | discovery | Advanced Excel. Not mentioned in your background. Your level is unknown. |
| R4 | must_have | absent | high | capability | SAP IBP or a similar planning system. Not in your background. |
| R5 | must_have | adjacent | medium | capability | Fluent Dutch. Conversational, not fluent. |
| R6 | hard_gate | unclear | low | hard_gate | On-site in Utrecht. Your location is not stated. |
| R7 | important | adjacent | medium | transferability | Balancing capacity against forecast. Route capacity reasoning is close, but it is not production planning. `[inferred]` |

**Decision reasoning.** R1, R4 and R5 are three must-haves with no realistic closure in a search window. That is why this is `no_go`. The role itself is not flagged.

**Opportunity risk register.** Same standing employer-not-established entry as Job 1 (it does not change the `no_go`).

**Application plan.** Do not apply now. Reconsider only if you have planning-adjacent evidence (forecasting, capacity, inventory, or S&OP-style work) that is not on your CV yet. Do not describe the route review as supply planning.

---

## Evidence status

| Target | Status | Reason |
|---|---|---|
| 1. Company official site and careers page | skipped | L0 tier; no research consent yet |
| 2. Role-family sweep (scope, title, pay) | skipped | L0 tier; no research consent yet |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- **Home location and commute tolerance:** closes R9 (Job 1) and R6 (Job 2).
- **Any planning-adjacent work:** could move Job 2's R1, R2 and R7 up. Only evidence you can confirm counts.
- **Your Excel level, with named features:** resolves Job 2's R3 from `unclear`.
- **Live posting link or the company's careers page:** closes the standing employer entry for either job.
- **Salary floor:** lets the pay comparison happen. A market band needs research (L1).
- **Cold-chain or temperature data exposure:** could move Job 1's R5 from `absent`.
- **Research at L1 or deeper:** checks each employer's existence and the market pay band. L2 adds funding, leadership changes and recent news, on request.

If you want, I can save the full analysis as `tuesday-dossier.md` for later use.

**Questions**
1. For Duinvaart: can you work three days a week in the Rotterdam office from where you live? (R9)
2. Have you done any forecasting, capacity planning, inventory, or S&OP-style work, even if it was never called planning? And how would you rate your Excel: formulas, pivot tables, Power Query? (Job 2, R1, R2, R3, R7)
3. May I run a light research check on both companies (up to 5 searches and 2 page fetches in total) to confirm they exist as posted and are hiring for these roles?

Answer any, all, or none in prose. Say "skip" to drop a question.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.