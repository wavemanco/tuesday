**Worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**
- `hard_gate`: direct: E1 (NMC registration), E2 (full UK driving licence). Both stated, not checked.
- `must_have`: direct: E3 (post-registration experience), E7 (insulin), E12 (home visiting). adjacent: E5 (wound care), E6 (catheter and continence). unclear: E4 (written records). absent: E9 (own caseload).
- `important`: unclear: E8 (end-of-life visits), E10 (electronic patient record).
- `preferred`: absent: E11 (Doppler).

**Opportunity ledger.** The employer is confirmed as a real operator, and the stated pay is in a normal range. Nothing here asks for money or personal bank details. The open items are whether the vacancy is still live and what the caseload and on-call expectations are.

- **Hard gates:** none failed; direct: E1, E2. Nothing is unconfirmed.
- **Severe red flags:** none found.
- **Conditions for go:** (1) confirm the advert is live, RR1; (2) ask about caseload size, supervision and Doppler training, RR3; (3) describe the home visiting you have done as exactly that, never as a caseload you have held.

**Research tier: L1 — searches 3 of 5, fetches 2 of 2; user links read 0**

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, Halifax. Adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff in four locality hubs | `[grounded]` the company's About page |
| Mandate | Join the district nursing team; hold a small caseload supported by a senior community nurse | `[grounded]` advert |
| Working pattern | Home visits to housebound adults; pool cars provided, plus mileage | `[grounded]` advert |
| Market calibration | Stated band £31,050–£37,800 sits around a 2026 survey median of £34,300 (interquartile £32,400–£36,600). 61% of respondents were paid mileage | `[generic]` Wardround 2026 community nursing pay guide, n=1,240 |
| Unknowns | Caseload size; on-call or weekend cover; supervision; whether Doppler training is provided; whether pool cars and mileage both apply | — |
| Contradictions | None found between the advert and the About page. The careers page at the address I tried did not load, so the vacancy is not confirmed live | `[grounded]` fetch result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| E1 | Current NMC registration as Adult Nurse | hard_gate | direct | high | none | Stated as active on the CV | `[grounded]` CV | Check your register entry yourself |
| E2 | Full UK driving licence | hard_gate | direct | high | none | Category B, stated | `[grounded]` CV | Check your licence record yourself |
| E3 | At least one year post-registration | must_have | direct | high | none | Five years as a staff nurse | `[grounded]` CV | none |
| E4 | Clear, timely written records | must_have | unclear | low | discovery | The CV is silent on documentation. The home-visit role implies visit notes | `[inferred]` from the role | Question Q2 |
| E5 | Wound care, including leg-ulcer | must_have | adjacent | medium | transferability | Pressure ulcers and surgical wounds are direct. Leg ulcers are not claimed | `[grounded]` CV for the wound types; `[inferred]` for the bridge | G3 |
| E6 | Catheter and continence care | must_have | adjacent | medium | discovery | Catheter care is stated. Continence is not mentioned | `[grounded]` CV | none yet |
| E7 | Insulin administration | must_have | direct | high | none | Stated | `[grounded]` CV | none |
| E8 | End-of-life visits | important | unclear | low | discovery | Not in the CV | `[grounded]` CV silence | Question Q3 |
| E9 | Own small caseload | must_have | absent | none | capability | You state you have never held one | `[grounded]` CV | G1 |
| E10 | Electronic patient record | important | unclear | low | discovery | The CV does not name a system | `[grounded]` CV silence | Question Q2 |
| E11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You state you have never done one | `[grounded]` CV | G2 |
| E12 | Home visiting to adults in their own homes | must_have | direct | high | none | First-week home visits after discharge, 18 months | `[grounded]` CV | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own caseload (E9) | capability | No caseload held | The role's core shape is a caseload | Home visits with a senior nurse's oversight; discharge planning | A brief description of how you prioritised visits | `[grounded]` CV |
| G2 | Doppler (E11) | capability | Never performed | Preferred, not essential | Wound and vascular assessment in practice | Any training you could start | `[grounded]` CV |
| G3 | Leg ulcers (E5) | transferability | Pressure and surgical wounds only | Leg ulcers are named in the advert | Wound assessment and dressing choice | Any leg-ulcer exposure, even observed | `[inferred]` bridge from wound care |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Vacancy liveness not confirmed | unknown | — | "current vacancies are listed on our careers page" | The advert may be closed or moved. The careers page I tried did not load | `[grounded]` fetch result | Can you send the live advert link? | unresolved |
| RR2 | Pool car and mileage wording | unknown | — | "pool cars are provided" and "plus mileage" | Both may not apply | `[grounded]` advert | Which applies to this post? | unresolved |
| RR3 | Caseload size, on-call and supervision not stated | unknown | — | none | Typical community posts vary here | `[grounded]` advert silence | What caseload size and supervision does the post have, and is there on-call? | unresolved |
| RR4 | Stated pay in normal range | positive_signal | — | "£31,050–£37,800 a year" | Pay is within the survey's band | `[generic]` Wardround median | none needed | noted |
| RR5 | Employer confirmed as an operating NHS-contracted provider | positive_signal | — | About page | The employer is real, established and staffed | `[grounded]` About page | none | noted |

No red flags. The advert asks for no payment, deposit or bank details.

## Application plan

- **Lead with** home visiting after discharge, pressure-ulcer and surgical-wound care, catheter care and insulin. Each is evidenced.
- **State plainly** that you have not held a caseload and have not done a Doppler assessment. Say you would train in Doppler. Do not describe home visits as caseload management.
- **For the interview or the informal chat,** ask about caseload size, supervision, on-call, and Doppler training.
- **CV edits:** none drafted yet. Any wording change would be `resume_edits_pending_approval` until you approve it.

## Evidence status

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | yes | About page confirms the employer. Queries: "Calderbrook Community Health CIC Halifax", "Calderbrook Community Health careers Community Staff Nurse Band 5 district nursing". Pages: the About page. The careers address I tried did not load |
| 2 | Role-family sweep (pay and scope) | yes | Query: "NHS Agenda for Change Band 5 pay scale 2026 nurse". Page: Wardround 2026 community nursing pay guide |
| 3 | Hiring manager's public footprint | skipped | Not run this pass. Rhiannon Mabbott is named in the advert and could be checked if useful |

## Upgrade menu

- **Live advert link** would settle RR1.
- **Your NMC register entry and driving licence record,** checked by you, would move E1 and E2 from stated to checked.
- **An anonymised example of your visit notes** would raise E4 from low to medium.
- **Any leg-ulcer or Doppler exposure,** even observed, would move E5 and G2.
- **Deeper diligence on Calderbrook (L2):** up to 5 more searches and 2 more fetches, covering the company's recent news, leadership and public staff reports. I'm offering it once. Say if you want it.

If you want, I can also write a `tuesday-dossier.md` capturing this assessment.

1. Can you send the live advert link, or tell me where you saw the vacancy? (RR1)
2. Which electronic record system have you documented in, and did you write your own visit notes in the discharge-to-assess role? (E4, E10)
3. Have you ever been responsible for a patient list, even informally, or seen a Doppler assessment done? (E9, E11)

Answer each question, say skip, or ask me to park it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.