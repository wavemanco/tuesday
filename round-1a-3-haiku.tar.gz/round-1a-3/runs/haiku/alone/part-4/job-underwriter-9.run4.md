**Decision: conditional go.** The role fits you well. Before you give bank, PPS or passport details, confirm the offer through a channel you find yourself. Research tier: L0, no searches run, so the employer's existence is unverified by me.

## Your question: is this normal?

Yes, the data requests are routine for a permanent hire who has received a written offer. Employers need your PPS number for Revenue and PAYE, bank details for salary, and a right-to-work check before you start. Asking for these through an onboarding portal after the offer is standard. Asking you to pay anything, deposit a cheque, or give these details before any offer, or hiring you through chat alone, would be a red flag. Nothing you describe does that.

Still, check these before you submit:

- **Confirm the offer yourself.** Find Marrowgate Housing's phone number and careers page on their official website, not from the email. Call and ask them to confirm the offer and that Declan Garvagh is Finance Manager. Do not use any number or link in the offer email.
- **Check the portal address.** It should be on the same domain as their website and start with https. Do not enter details through a link that goes somewhere else.
- **Send the passport scan only through the portal.** Never by plain email, and never send PPS number this way.
- **Ask what they keep.** Ask what is stored from the passport check, how long it is kept, and who can see it. Employers handling personal data should be able to answer this under GDPR.
- **Originals on day one** is normal. The right-to-work check is about seeing the document.

## Decision snapshot

- **Candidate fit:** strong on most requirements; gaps in pension changes, Irish PAYE/PRSI/USC evidence, and scale (240 staff, monthly, versus 90 staff, fortnightly).
- **Opportunity:** consistent with the advert (salary inside the €38k–€42k band, hybrid pattern as advertised, two in-person interviews). Existence not yet verified.
- **Hard gates:** location and right to work unknown from your side; notice period unknown. None failed.
- **Decision:** conditional go, pending verification of the offer through the company's own channels.

## Role reality

- **Role:** Payroll Administrator, permanent, reporting to the Finance Manager. Duties: monthly payroll for 240 staff, starters and leavers, pension changes, payroll-to-ledger reconciliation, staff payroll queries.
- **Salary:** €40,000 offered, inside the advertised range. `[grounded]` from the offer and ad.
- **Scope read:** a single-person payroll function at 240 staff, more than 2.5 times your current 90. `[inferred]` from the headcount.
- **Market calibration:** a payroll administrator at this level usually owns the end-to-end monthly run and pension admin. `[generic]`, not a claim about this employer.
- **Contradictions:** none found between the ad and the offer.

## Evidence map

| # | Priority | Requirement | Fit | Confidence | Evidence / gap |
|---|---|---|---|---|---|
| 1 | Must | 2+ years running payroll | Met | High | 3 years, fortnightly, 90 staff |
| 2 | Must | Working knowledge of PAYE, PRSI, USC | Partly met | Medium | Not stated in your background; depends on whether the hotel payroll was Irish |
| 3 | Must | Strong Excel | Met | High | Daily use; pivots and XLOOKUP |
| 4 | Must | Payroll qualification or working towards one | Met | High | Payroll Technician certificate, 2024 |
| 5 | Must | Starters and leavers | Met | High | Stated in your background |
| 6 | Must | Payroll-to-GL reconciliation, monthly | Met | High | Stated; monthly reconciliation at the hotel group |
| 7 | Core | Monthly payroll for 240 staff | Partly met | Medium | Fortnightly at 90; monthly and larger scale are a transfer, not a proven fact |
| 8 | Core | Pension changes | Not evidenced | Low | You have not done these; your manager did |
| 9 | Core | Staff payroll queries | Likely met | Low | Not stated explicitly; confirm |
| 10 | Hard gate | Location, Limerick hybrid two days | Unknown | — | Your location and commute not stated |
| 11 | Hard gate | Right to work in Ireland | Unknown | — | Not stated; the onboarding check will test it |

## Gap recovery queue

- **Row 2 (PAYE, PRSI, USC):** presentation gap. If the hotel payroll was Irish, this closes on your CV. Otherwise it is a capability gap you would need to close before the first run.
- **Row 7 (monthly, 240 staff):** transferability gap. Closes with a description of the hotel group's payroll calendar and any larger or monthly runs you have handled.
- **Row 8 (pension changes):** capability gap. Closes by learning the scheme's rules and joining changes to the ledger. Ask the employer what pension scheme they run and whether there is a handover.
- **Row 9 (queries):** discovery gap. Closes with one line on the queries you handled at the hotel.

## Opportunity risk register

- **Employer existence (unverified):** standing entry. Until you confirm the offer through the company's website, treat the decision as conditional. Resolves with a call to the switchboard on their official site and confirmation of the offer.
- **Portal and data requests:** routine after a written offer. Advice only: use the checks listed above.
- **Salary:** €40k is inside the advertised band. No mismatch.

## Application plan

- **Accept only after verification.** Reply within the five working days. Ask in your reply for the portal link to be sent from the same domain and confirm the start date after your notice period.
- **Lead with:** three years of end-to-end fortnightly payroll, reconciliation, and Excel depth. Do not claim pension experience you do not have. Say you have not run pension changes yourself and describe how you would learn them.
- **Do not claim** Irish PAYE/PRSI/USC experience until you confirm the hotel payroll was Irish.

## Evidence status

Research tier: L0 — no searches. No declared research targets; nothing above is verified against the web.

## Dossier offer

If you want, I can save a `tuesday-dossier.md` file of this assessment for later use.

## Upgrade menu

- **Verification of the employer (L1):** up to 5 searches and 2 page fetches on Marrowgate's official site and careers page, to check the posting and entity. This is the most useful next step.
- **Your CV or a note on the hotel payroll:** would settle rows 2, 7 and 9.
- **Your location and right-to-work status:** would settle the two hard gates.

## Questions

1. Was the hotel group's payroll run under Irish PAYE, PRSI and USC? If so, how did you handle them?
2. Do you have the right to work in Ireland, and where are you based relative to Limerick?
3. Would you like me to run the L1 check on Marrowgate's website and careers page? It is up to 5 searches and 2 page fetches.

Response mode: answer any or all of these, or skip them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.