**Short answer:** The Operations Analyst role at Duinvaart is worth applying to, with conditions. The Supply Planner role at Kroonhaven is not worth your time right now.

Research was not available in this session, so neither employer has been checked against the web. Everything about the companies comes from the postings and what you told me.

---

## Posting 1: Operations Analyst, Duinvaart Cold Chain (Rotterdam)

**`conditional_go`.** Your must-haves (D1, D2, D3) read as direct on your own account, and the Power BI dashboard work is close to the job. The employer is unverified from here, and two core responsibilities (D4, D6) depend on things you haven't told me yet.

**Fit ledger.**

- `hard_gate`: unclear: D-G1 (hybrid, three office days a week in Rotterdam)
- `must_have`: direct: D1, D2, D3 · unclear: D4 (weekly Power BI dashboards), D6 (temperature compliance across the refrigerated fleet)
- `important`: adjacent: D5 (route changes with depot managers)
- `preferred`: adjacent: D7 (Dutch, a plus)

D4 and D6 are unconfirmed on the evidence you've given; D5 is a bridge, and its limit is that a route-performance review isn't a route-change decision; D7 is conversational Dutch, not fluent.

**Opportunity ledger.** The scope is concrete, with named tools and stakeholders (RR3). Pay is withheld (RR4). It's unclear whether this role decides route changes or only analyses them (RR2). The employer is not yet established (RR1).

- **Hard gates:** none failed; unconfirmed: D-G1 (hybrid, three office days a week in Rotterdam); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 clears, meaning the role appears on Duinvaart's own careers page; (2) D-G1 works for you, meaning the commute and the three-day pattern; (3) D4 and D6 hold up in interview, meaning you can say what you built or used and whether you've touched temperature data.

**Role reality.**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam, refrigerated fleet | [grounded] posting |
| Mandate | Track on-time delivery and temperature compliance; build weekly dashboards; work with depot managers on route changes | [grounded] posting |
| First-year outcomes | None stated | — |
| Working pattern | Hybrid, three days a week in the Rotterdam office | [grounded] posting |
| Scope read | A single analyst role reporting into operations, with a defined remit | [inferred] from the listed responsibilities |
| Market calibration | Not run; no pay band | [generic] research unavailable |
| Unknowns | Pay, team size, reporting line, whether analysts decide route changes, language of day-to-day work | — |
| Contradictions | None visible in the posting; careers page not checked | — |

**Evidence map.**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D1 | 2+ years logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier | [grounded] your intake | none |
| D2 | Strong SQL | must_have | direct | medium | none | Daily use, stated; not yet inspectable | [grounded] your intake | none |
| D3 | Power BI or Tableau | must_have | direct | medium | none | Daily use, stated | [grounded] your intake | none |
| D4 | Build weekly dashboards in Power BI | must_have | unclear | medium | discovery | You use the on-time dashboard depot managers rely on; whether you built it is not stated | [grounded] your intake | Q2 |
| D5 | Work with depot managers on route changes | important | adjacent | medium | transferability | You ran the weekly route-performance review with depot managers; you haven't said you changed routes | [inferred] from your review role | Gap queue G2 |
| D6 | Track temperature compliance across refrigerated fleet | must_have | unclear | low | discovery | Nothing in your background touches temperature data | [grounded] absence in intake | Q3 |
| D7 | Dutch, a plus | preferred | adjacent | low | transferability | Conversational, not fluent | [grounded] your intake | Gap queue G3 |
| D-G1 | Hybrid, three office days a week in Rotterdam | hard_gate | unclear | none | hard_gate | You haven't stated your constraints, so this is unchecked | [grounded] posting | Q1 |

**Gap recovery queue.**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Dashboard build (D4) | discovery | Daily Power BI use; build vs. use unclear | Interviewers will probe "build weekly dashboards" directly | Any dashboard you created, extended, or maintained; metric definitions you set | A screenshot description or metric list | [inferred] that interviewers probe this |
| G2 | Route changes (D5) | transferability | Route-performance review with depot managers | The closest bridge; the limit is decision rights | Routes you proposed or changed after a review; depot feedback that led to a change | A review deck or a decision log | [inferred] bridge from the review |
| G3 | Dutch (D7) | transferability | Conversational | Day-to-day work with depot managers may be in Dutch | Recent Dutch correspondence or a short Dutch work sample | A written sample in Dutch | [generic] that Dutch-language depot work is common |
| G4 | Temperature data (D6) | discovery | No temperature-controlled work in intake | Cold-chain compliance is a core responsibility | Any temperature-sensitive shipments, alarm handling, or excursion reports | A sample report or dataset description | [generic] that cold-chain roles track excursions |

**Risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | Not checked here: the company may be too new or small to have a footprint, the posting may be stale, or it may not be a live hiring entity. Research was unavailable, so this is unchecked, not a finding against them | [generic] pattern for companies this size | Can you point me to this role on your own careers page, and who would I be interviewing with? | unresolved |
| RR2 | Route-change authority unclear | unknown | — | "work with depot managers on route changes" | The role may analyse route changes without deciding them | [inferred] from scope language | Which route changes does this role decide itself, and which go to depot managers or operations leadership? | unresolved |
| RR3 | Concrete scope and named tools | positive_signal | — | "Track on-time delivery and temperature compliance… build weekly dashboards in Power BI" | Clear, measurable scope | [grounded] posting | Which two metrics would you judge this role on in its first year? | noted |
| RR4 | Pay withheld | unknown | — | Not stated | The posting may withhold pay as a default | [grounded] absence | What is the salary range for this role? | unresolved |
| RR5 | Hybrid commute pattern | unknown | — | "three days a week in our Rotterdam office" | Commute cost and time may be a real constraint | [grounded] posting | Is the three-day pattern fixed, and which days? | unresolved |

**Application plan** (nothing is applied until you approve).

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the role on Duinvaart's own careers page before applying | RR1 | [generic] advice | your call |
| A2 | Resume line, from your words: "Use SQL and Power BI daily, including the on-time delivery dashboard depot managers rely on." Don't say "built" until G1 is answered | D4 | [grounded] your intake | resume_edits_pending_approval |
| A3 | Describe Dutch as "conversational Dutch"; don't write "Dutch" alone | D7 | [grounded] your intake | resume_edits_pending_approval |
| A4 | Ask RR2 and RR4 in the first conversation | Decision rights and pay | [grounded] register | pending your approval |

---

## Posting 2: Supply Planner, Kroonhaven Foods (Utrecht)

**`no_go`.** K1, K3 and K5b are must-haves at `absent`: three years of FMCG planning, SAP IBP or a similar planning system, and owning a 13-week plan against capacity. Your background shows none of these, and I can't see a route to closing them before this application.

**Fit ledger.**

- `hard_gate`: unclear: K-G1 (on-site in Utrecht)
- `must_have`: adjacent: K4 (fluent Dutch), K5a (weekly S&OP meeting) · unclear: K2 (advanced Excel) · absent: K1 (3+ years FMCG planning), K3 (SAP IBP or similar), K5b (13-week plan balancing capacity against forecast)

K4 is conversational, not fluent; K5a matches the meeting shape only, not S&OP content; K2 is unconfirmed on the evidence you've given.

**Opportunity ledger.** The scope is specific and named (RR-K3). Pay is withheld (RR-K2). The employer is not yet established (RR-K1).

- **Hard gates:** none failed; unconfirmed: K-G1 (on-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.

**Role reality.**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht, chilled ready meals | [grounded] posting |
| Mandate | Own the 13-week supply plan; balance production capacity against forecast; run the weekly S&OP meeting | [grounded] posting |
| First-year outcomes | None stated | — |
| Working pattern | On-site in Utrecht | [grounded] posting |
| Scope read | A planning-owner role with a defined remit | [inferred] from the listed responsibilities |
| Market calibration | Not run; no pay band | [generic] research unavailable |
| Unknowns | Pay, planning system in use, reporting line, team size | — |
| Contradictions | None visible in the posting | — |

**Evidence map.**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K1 | 3+ years supply or demand planning in FMCG | must_have | absent | medium | capability | You've said you've never worked in planning; route and on-time analytics are not planning | [grounded] your intake | Gap queue G1 |
| K2 | Advanced Excel | must_have | unclear | low | discovery | SQL and Power BI are stated; Excel is not | [grounded] absence in intake | Gap queue G2 |
| K3 | SAP IBP or similar planning system | must_have | absent | medium | capability | No planning system in your background | [grounded] your intake | Gap queue G1 |
| K4 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, not fluent | [grounded] your intake | Gap queue G3 |
| K5a | Weekly S&OP meeting | must_have | adjacent | low | transferability | You ran a weekly review with stakeholders; S&OP content is different | [inferred] from your review role | Gap queue G3 |
| K5b | Own the 13-week plan, balancing capacity against forecast | must_have | absent | medium | capability | No planning or capacity work in your background | [grounded] your intake | Gap queue G1 |
| K-G1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Constraint not stated | [grounded] posting | none |

**Gap recovery queue.**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Planning years and systems (K1, K3, K5b) | capability | No planning work | Three must-haves at `absent` | Forecasting, capacity or inventory work you may have done informally | None that would change the decision | [inferred] that no closure fits this application's timeline |
| G2 | Excel (K2) | discovery | Not stated | A cheap gap to close | Excel models you've built for reporting | A sample model | [generic] |
| G3 | Dutch and weekly review (K4, K5a) | transferability | Conversational Dutch; weekly review | The meeting shape is similar; the content isn't | Recent Dutch work; the review's decision outputs | A Dutch sample | [generic] |

**Risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR-K1 | Employer not established | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Not checked here; the company may be too new or small, the posting stale, or not a live hiring entity | [generic] pattern | Can you point me to this role on your own careers page, and who is the hiring manager? | unresolved |
| RR-K2 | Pay withheld | unknown | — | Not stated | The posting may withhold pay as a default | [grounded] absence | What is the salary range for this role? | unresolved |
| RR-K3 | Concrete scope | positive_signal | — | "Own the 13-week supply plan for our chilled ready-meals range" | Clear, measurable scope | [grounded] posting | What would success look like at 13 weeks? | noted |

**Application plan.**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| B1 | Don't use an application on this role as it stands | K1, K3, K5b | [inferred] | your call |
| B2 | Look for planning-adjacent roles where analytics is the core ask (demand or S&OP analyst, supply analyst) | Closes the gap by changing the target | [generic] pattern | your call |
| B3 | If you apply anyway, the honest line: "On-time delivery and route-performance analytics in a parcel network; no FMCG or planning experience." Don't claim S&OP | K1, K5a | [grounded] your intake | pending your approval |

---

## Evidence status

Verified: none yet. Your intake is self-report, so these are leads to confirm, not verified claims. No rejected inferences.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht chilled ready meals" were refused. Would have moved RR1 and RR-K1 (employer not established) |
| 2. Role-family sweep | unavailable | Searches for supply-planner and operations-analyst pay and scope were refused. Would have set market calibration and the pay band for both roles |
| 3. Hiring manager's public footprint | n/a | No name was given |

If you grant search permission, I can retry targets 1 and 2 on your say-so.

---

**Dossier offer:** If you want, I can save this analysis as a `tuesday-dossier.md` file so it carries into later sessions.

**Upgrade menu:**
- Your answers to Q1–Q3 close D-G1, D4 and D6, and may move Duinvaart to `go` or `no_go`.
- A link to each live posting, or to each company's careers page, closes RR1 or RR-K1.
- Search permission lets targets 1 and 2 run; the company checks and the pay band would then be sourced rather than unchecked.
- A sanitized description of the dashboard (what you built, what you maintain, which metrics) would raise D4's confidence.
- A Dutch writing sample would settle D7 and K4.

**Questions:**

**Q1 (D-G1, hard constraints):** Which of these are fixed for you: three office days a week in Rotterdam, a minimum salary, a start date, or anything else you won't trade?

**Q2 (D4, dashboard):** On the on-time delivery dashboard, did you build it, maintain it, or mostly use it? What was your part?

**Q3 (D6, temperature):** Have you worked with temperature data or temperature-controlled shipments, even as a small part of a job?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.