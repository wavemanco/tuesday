**Yes, it's worth applying for, on three conditions. You meet both hard gates and the core clinical duties on what you've stated. The two real gaps are that you've never held a caseload and have no Doppler experience. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R4, R6a, R7a; adjacent: R5, R8; unclear: R6b, R7b, R11
- `important`: direct: R9; unclear: R10
- `preferred`: absent: R12

R5 (leg-ulcer care, `adjacent`) and R8 (own caseload, `adjacent`) are bridges with limits named below; R12 (Doppler, `absent`) is a closure path, not a claim.

**Opportunity ledger.** Sound. The employer exists as described (RR4), and the stated pay sits around the surveyed Band 5 median (RR2). Unknowns are caseload size and supervision (RR1) and whether the advert is still live (RR3). No severe red flags.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) caseload size and senior-nurse support confirmed (RR1); (2) the posting confirmed live on the careers page before you apply (RR3); (3) leg-ulcer and Doppler framed as adjacent or as a training route, never as experience you have.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing across Calderdale under an NHS contract, founded 2015, 410 staff, four locality hubs | `[grounded]` calderbrookhealth.example/about |
| Role | Band 5 community staff nurse; housebound adults at home; own small caseload with senior community nurse support | `[grounded]` advert |
| Working pattern | Home visits by pool car; mileage listed in the pay line | `[grounded]` advert |
| Market calibration | Surveyed Band 5 community staff nurses (England, n=1,240, 2026): median £34,300, middle half £32,400–£36,600; 61% paid mileage, 24% had a pool or lease car | `[generic]` Wardround 2026 pay guide |
| Pay comparison | The advert's £31,050–£37,800 spans the surveyed middle half; the posting's figure is `[grounded]`, the band is `[generic]` | `[grounded]` advert; `[generic]` survey |
| Unknowns | Caseload size; supervision frequency; pay point within Band 5; whether this post is still open | — |
| Contradictions | None found between the advert and the employer's About page | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | high | none | Stated registration, active, revalidation due March 2028; not checked against the register | `[grounded]` your CV, stated | You check the NMC register entry yourself |
| R2 | Full UK driving licence | hard_gate | direct | high | none | Category B stated; not checked | `[grounded]` your CV, stated | You check your own driving record |
| R3 | At least one year post-registration experience | must_have | direct | high | none | Five years as staff nurse on an acute medical ward | `[grounded]` CV | none |
| R4 | Wound care | must_have | direct | high | none | Pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R5 | Leg-ulcer care | must_have | adjacent | medium | transferability | Wound care carries over; leg-ulcer-specific work is not in your CV. Limit: no leg-ulcer assessment or compression work named | `[inferred]` from R4 | Gap queue G1 |
| R6a | Catheter care | must_have | direct | high | none | Stated on CV | `[grounded]` CV | none |
| R6b | Continence care | must_have | unclear | low | discovery | Not on CV | `[grounded]` CV silence | Gap queue G2 |
| R7a | Insulin administration | must_have | direct | high | none | Stated on CV | `[grounded]` CV | none |
| R7b | Care planning | must_have | unclear | low | discovery | Not on CV as a stated task | `[grounded]` CV silence | Gap queue G3 |
| R8 | Holding a small caseload with senior-nurse support | must_have | adjacent | medium | transferability | Seconded to discharge-to-assess home visits for 18 months. Limit: visits were to patients referred to you, not a caseload you owned and scheduled | `[inferred]` from the secondment | Gap queue G3 |
| R9 | Home visiting to housebound patients | important | direct | high | none | 18 months of home visits in the first week after discharge | `[grounded]` CV | none |
| R10 | End-of-life visits | important | unclear | low | discovery | Not on CV | `[grounded]` CV silence | Gap queue G2 |
| R11 | Clear, timely written records; electronic patient record | must_have | unclear | low | discovery | Essential in the advert; CV silent on documentation or EPR | `[grounded]` CV silence | Gap queue G4 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | No evidence after reviewing the CV | `[grounded]` CV | Closure path named; minor risk |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R5, must_have) | transferability | Wound care is direct; leg-ulcer-specific work is not on the CV | Leg ulcers are named first in the duties | Any leg-ulcer dressing or compression work, or an assessment note; care of venous or diabetic wounds on a ward | A sanitised wound assessment or care plan | `[inferred]` bridge from R4; `[generic]` that this is a likely interview probe |
| G2 | Continence and end-of-life work (R6b, R10) | discovery | Neither appears on the CV | Both are listed duties | Continence assessments or products on the ward; end-of-life care or family discussions in the discharge work | A sanitised care plan or handover | `[grounded]` CV silence |
| G3 | Caseload and care planning (R7b, R8, transferability and discovery) | transferability | Discharge-to-assess visits were referred patients, not an owned caseload | This is the first thing a community-team interview tests | Prioritising several home visits in a day; follow-up calls and referrals you owned; any discharge care plan you wrote | A sanitised care plan, or your visit log format | `[inferred]` from the secondment; `[generic]` that caseload is the probe |
| G4 | Records and EPR (R11, must_have) | discovery | CV does not say what system you documented in | The advert names timely records as essential | Electronic records on the ward or in discharge; timeliness standards you worked to | A sample redacted note format | `[grounded]` CV silence |

The queue holds no questions. The questions for G2, G3 and G4 are in the closing block.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Caseload size and support unstated | unknown | — | "a small caseload of your own, supported by a senior community nurse" | Caseload may be large for a first post, or the senior nurse may be remote | `[inferred]` from the advert's vagueness on size | What is a typical caseload size for this post, and how often do I see the senior community nurse? | unresolved |
| RR2 | Pay band and pay point | unknown | — | "£31,050–£37,800 a year plus mileage" | Start point may sit at the low end of Band 5; mileage terms unstated | `[generic]` survey band against `[grounded]` advert | Which pay point would I start on, and how is mileage paid? | unresolved |
| RR3 | Posting not confirmed live | unknown | — | "contact Rhiannon Mabbott" | The posting may be closed or the careers page may list it differently | `[grounded]` careers page not yet checked | Is this post still open, and who would I be interviewing with? | unresolved |
| RR4 | Employer established | positive_signal | — | "Calderbrook Community Health is a community interest company running adult community nursing" | Established provider with an NHS contract and four hubs | `[grounded]` About page | none | noted |

Severe red flags: none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the NMC register and your own driving record before applying | Both hard gates are stated, not checked | `[grounded]` R1, R2 | pending your approval |
| A2 | Check the careers page for the live post | RR3 | `[grounded]` RR3 | pending your approval |
| A3 | Ask Rhiannon Mabbott RR1 and RR2 in the informal chat | These decide whether the conditions hold | `[grounded]` register | pending your approval |
| A4 | Write the caseload story from the secondment, true in its scope: how you prioritised and followed up home visits | Frames R8 as adjacent, not as caseload experience | `[inferred]` R8 | pending your approval |
| A5 | Consider a Doppler training route, asked about at interview | R12 closure path | `[generic]` typical community-nursing route | pending your approval |

Every row is proposed. Nothing goes into your CV or any outreach until you approve it.

## Evidence status

Verified: none yet. Every claim on your side is stated and unchecked.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax"; fetched "About Calderbrook Community Health" (calderbrookhealth.example/about). The employer exists as described. The careers page was not fetched, so RR3 remains open |
| 2. Role-family sweep | yes | Searched "Agenda for Change Band 5 pay scale 2026/27 pay point", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Searched "Community Staff Nurse Band 5 Halifax district nursing job advert", which returned nothing. Market calibration and RR2 rest on the first result |
| 3. Hiring manager's public footprint | n/a | The advert names a contact, not a hiring manager, and no footprint search was run |

## Upgrade menu

- Your CV with the caseload-adjacent visit work set out in detail → R8 may move to a clearer `adjacent`, with its limit still named.
- A sanitised care plan or wound assessment → R5 and R7b move up.
- The careers-page listing → RR3 closes.
- The caseload size and supervision pattern → RR1 closes, and the conditions simplify.
- A deeper research pass on Calderbrook (inspection reports, staff reviews, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want the full write-up saved, I can emit it as `tuesday-dossier.md`.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

1. **G3:** When you did the home visits after discharge, how did you decide which to see first, and what follow-up did you own afterwards?
2. **G2:** Have you been involved in continence assessments or end-of-life care in your ward or discharge work? If so, what was your part?
3. **G4:** Which record system did you document in, and how quickly did notes need to be completed?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.