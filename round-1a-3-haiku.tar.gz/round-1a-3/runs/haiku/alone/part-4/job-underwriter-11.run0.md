## Decision snapshot

| Role | Decision | Fit | Hard gates |
|---|---|---|---|
| 1. Operations Analyst, Duinvaart Cold Chain (Rotterdam) | **conditional_go** | Strong on the core job. Cold-chain domain unproven. | Schedule/location: 3 office days a week in Rotterdam. Unknown, not yet confirmed. |
| 2. Supply Planner, Kroonhaven Foods (Utrecht) | **no_go** (for now) | Weak. No planning experience, no SAP IBP, Dutch short of "fluent." | Location: on-site in Utrecht. Unknown, not yet confirmed. |

Research tier: L0, no searches. Claims about either company come only from the posting text you pasted and are labeled `[generic]` where they go beyond it.

Source labels: JD = posting text `[grounded]`. CV = your account as you gave it `[grounded, unverified]`. Derived claims are `[inferred]`.

## 1. Operations Analyst, Duinvaart

**Decision: conditional_go.** Two things decide it: whether you can do Rotterdam three days a week, and how much cold-chain knowledge the role needs.

| Requirement | Priority | Fit | Evidence | Gap |
|---|---|---|---|---|
| 2+ years logistics or ops analysis | Must | Met | 4 years as ops analyst (CV) | None |
| Strong SQL | Must | Met | Daily use (CV) | None |
| Power BI or Tableau | Must | Met | Daily Power BI (CV) | None |
| Track on-time delivery | Core | Strong | Built the on-time dashboard depot managers used (CV) | None |
| Weekly dashboards, depot managers | Core | Strong | Ran the weekly route-performance review (CV) | None |
| Route changes with depot managers | Core | Strong | Same review (CV) | None |
| Temperature compliance, refrigerated fleet | Core | Unknown | Nothing in your background | Cold-chain domain `[inferred]` |
| Dutch | Preferred ("a plus") | Partial | Conversational (CV) | Not a gate |

**Gap recovery:** The temperature-compliance gap closes with any exposure to temperature logs, cold-chain KPIs, or food-safety audits. If you have none, say so in one line and argue the transferable part: exception and on-time tracking for a time-critical network. Do not write "cold-chain experience."

**Risk register (brief):**
- The posting has no red flags: no fees, deposits, or bank-detail requests.
- Company existence is unverified, because no research has run. Check the role on Duinvaart's own careers page.
- Pay is not stated. Ask at first contact.

**Application plan:**
- Lead with the on-time dashboard depot managers used. It is almost the same job.
- Follow with the route-performance review, which maps to "route changes with depot managers."
- Put the cold-chain gap in the cover note in one line. Don't bury it.
- Describe your Dutch as it is. Ask the recruiter whether Dutch is used day to day.
- Add numbers only if you have them. Don't invent improvement figures.

## 2. Supply Planner, Kroonhaven

**Decision: no_go for now.** The reason is three missing must-haves, not presentation: FMCG planning experience, SAP IBP or a similar planning system, and fluent Dutch. Years of experience is not a hard gate, so this is a capability gap, not a disqualifier by terms.

| Requirement | Priority | Fit | Gap |
|---|---|---|---|
| 3+ years supply or demand planning, FMCG | Must | Not met | Capability: no planning experience |
| Advanced Excel | Must | Unknown | Not stated. SQL and Power BI don't prove it. |
| SAP IBP or similar | Must | Not met | Tool gap |
| 13-week plan, capacity vs forecast | Core | Adjacent only | Route and dashboard work is monitoring, not planning |
| Weekly S&OP | Core | Adjacent only | A performance review is a different meeting |
| Fluent Dutch | Must | Partial | Conversational vs. fluent |
| On-site Utrecht | Location | Unknown | Commute |

**Reframing caution:** Don't describe the route review as planning or S&OP. Accurate wording is "ran a weekly route-performance review."

**What would change this:** planning-adjacent work you haven't mentioned yet, such as forecasting, production scheduling, or S&OP inputs. Even then, the Dutch requirement remains. I'd spend your application time on role 1 and similar analyst roles.

## Dossier offer

If you want, I can save this assessment as `tuesday-dossier.md`, a reusable file for later applications and interview prep.

## Upgrade menu

- **Commute and location answer:** settles the hard-gate line for both roles. Duinvaart moves from conditional_go to go or no_go.
- **Any cold-chain evidence** (temperature logs, KPIs, food-safety audits): turns the Duinvaart temperature row from unknown to a fit.
- **Any planning, forecasting, or S&OP work:** the only route to reopening Kroonhaven.
- **Research at L1** (up to 5 searches and 2 page fetches): checks that both companies exist as described and that the postings are live. L2 adds funding, hiring patterns, and recent news.

## Questions

1. Where do you live now, and can you do three days a week in Rotterdam, and on-site in Utrecht for the other role?
2. Have you done any cold-chain, temperature-monitoring, or food-safety work, even one project or audit?
3. Do you want a research pass at L1 to check both companies and postings? It costs up to 5 searches and 2 page fetches.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.