**Decision: conditional go.** The role fits you well. Legitimacy looks plausible, but I could only partly verify it, so confirm a few things before you invest time.

**Decision snapshot**
- Fit: strong on 3+ years, Figma, working with engineers, and Galway-hybrid. Partial on user research, since your sessions were with travel customers and not school owners. Gap on being the only designer, which you've never done.
- Hard gates: none failed. Your pay floor isn't known, so the €52–60k band is unchecked against it.
- Opportunity: plausible and consistent so far, with the verification gaps below.

**Legitimacy: what checks out**
- The company's own About page (fernquay.example/about) describes the same thing: booking software for sea-kayak, surf and sailing schools, six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle. That matches the posting and the WhatsApp message, including Saoirse as CTO. Note that the About page doesn't name a CTO, so that role is unconfirmed.
- A search snippet shows a LinkedIn profile for Ronan Kehoe as co-founder and CEO of Fernquay, previously a product lead at a Galway travel-software company. I didn't open the profile itself.
- The WhatsApp message asks for nothing unusual. It doesn't ask for money, bank details, ID, or payment. It's a normal scheduling message, if a more informal channel than most.

**Legitimacy: what's still unverified**
- I couldn't find a careers page or a live posting that I could confirm. Ask Ronan for the link to the posting on Fernquay's own site.
- The only independent sources are the company's own site and the LinkedIn snippet. Two sources is thin for a company founded in 2023, and that's why I'm holding at conditional go.
- The calendar invite should come from a Fernquay email domain. Check that it matches the domain on their site.
- I didn't run a salary check, so I can't say whether €52–60k is typical for this seniority in Ireland. I'd treat that as an open question rather than a red flag.

**Fit against your background**
- Strong: 4 years in product design, the checkout redesign, Figma daily, and four engineers in a squad. That last one is directly relevant to "ship alongside our two engineers."
- Partial: monthly usability sessions are close to "research calls with school owners," but the customer type differs. Bring one example of talking to business customers, if you have one.
- Gap: you've never been the only designer. This is a capability and discovery gap, not a deal-breaker. The question is how much you want a senior designer or design lead around you.

**Application plan**
1. Before the call, ask Ronan for the live posting link and confirm the invite's email domain.
2. On the call, ask who you'd be working with on the booking flow. Also ask what research has already been done with school owners and what the first 90 days look like.
3. Bring the checkout case study. They asked for "one messy real project," so a candid walk-through of trade-offs will suit them better than a polished deck.
4. Decide your pay floor before any offer discussion.

**Upgrade menu:** If you're willing, I can run a deeper check on funding, leadership and recent news (up to 5 more searches and 2 more fetches), or a salary-band check for Irish product design roles. Either would strengthen the verdict.

**Questions**
1. What's your pay floor? Is €52k the bottom of what you'd accept, or is there room to negotiate?
2. How do you feel about being the only designer? Would you want a design lead or an external mentor?
3. Do you have an example of research with business customers, beyond consumer-facing usability sessions?

**Research tier:** L1 — searches 2 of 5, fetches 1 of 2. Company site: yes (About page). Role-family pay sweep: skipped. Hiring-manager footprint: yes, from a search snippet only.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.