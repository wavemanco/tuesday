**Decision: conditional_go.** Apply, but confirm the employer is real and check the pay against your floor first.

**Decision snapshot**

- **Fit (per requirement, not a score):**
  - *Essential, met as stated:* NMC Adult registration, 5 years post-registration, wound care, catheter care, insulin administration.
  - *Essential, partly met or gap:* written records (no example in the CV), holding your own caseload (never done).
  - *Desirable, gap:* Doppler assessment.
  - *Role terms not evidenced:* leg-ulcer care, end-of-life visits, continence care beyond catheters, electronic patient record.
- **Hard gates:** NMC registration, met as stated (check the NMC register). Full UK licence, met as stated but not checked (check your own licence record). Location, met (Halifax). Pay, unknown against your floor, which you haven't given.
- **Confidence:** Your CV claims are stated, not verified. Anything I infer from them is marked as inferred.

**Role reality** `[grounded]` from the advert: Band 5 community staff nurse, housebound adults at home, a small caseload with senior nurse support, EPR documentation, pool car and mileage. £31,050–£37,800 plus mileage.

**Evidence map**

| # | Priority | Fit | Requirement | Evidence | Confidence | Gap type |
|---|---|---|---|---|---|---|
| 1 | Essential | Met | NMC registration, Adult | Stated PIN, active, revalidation March 2028 | Medium, stated | hard_gate |
| 2 | Essential | Met | Full UK driving licence | Category B, stated | Medium, not checked | hard_gate |
| 3 | Essential | Met | 1+ year post-registration | 5 years, acute medical ward | Medium | none |
| 4 | Essential | Partly | Clear, timely written records | No example in CV; DTA visits imply documentation | Low, inferred | presentation |
| 5 | Essential (role core) | Gap | Holding own caseload | Never held one; DTA visits were home visits, not a caseload | Medium | transferability |
| 6 | Essential (role core) | Met | Wound care | Pressure ulcers, surgical wounds | Medium | none |
| 7 | Role term | Not evidenced | Leg-ulcer care | Not in CV | n/a | discovery |
| 8 | Role term | Partly | Catheter and continence care | Catheter stated; wider continence not | Medium | discovery |
| 9 | Role term | Met / partly | Insulin; care planning | Insulin stated; care planning not | Medium | presentation |
| 10 | Role term | Not evidenced | End-of-life visits | Not in CV | n/a | discovery |
| 11 | Role term | Not evidenced | Electronic patient record | Not in CV | n/a | discovery |
| 12 | Desirable | Gap | Doppler assessment | Never done | High, stated | capability |
| 13 | Hard gate | Unknown | Pay vs your floor | Floor not stated | n/a | hard_gate |
| 14 | Hard gate | Met | Location | Halifax, both | Medium | hard_gate |

**Gap recovery queue** (what closes each gap, no questions here)
- Row 4: one written example you're proud of, with the anonymised record detail.
- Row 5: your DTA visit planning and any decisions you made alone (see question 1).
- Row 7 and 10: any leg-ulcer or end-of-life visits in the DTA work, even as a minority of visits.
- Row 11: any EPR use, even a different system.
- Row 12: a Doppler course before interview would reduce this. It's desirable, not essential.

**Opportunity risk register**
- **Employer unverified** (severity medium, opportunity class). I haven't checked that Calderbrook Community Health CIC exists as described. That's not a finding against them, just untested. It caps this at conditional_go. To resolve it: a link to the live posting or the employer's careers page.
- **Pay unverified** (severity low). The figure is posted `[grounded]`, but I haven't calibrated it against a published scale in this session. Your floor decides whether it's a hard-gate problem.
- **No red flags in the posting text.** The contact is a named team lead for an informal chat, which is normal.

**Application plan** (no CV text drafted yet; any wording needs your approval)
- Lead with DTA home visits: wound care, catheter care, insulin, and documenting independently in a home setting.
- Don't claim a caseload, Doppler, or leg-ulcer or end-of-life experience. Describe the DTA work as home visits, not "managed a caseload."
- Use the informal chat with Rhiannon Mabbott to ask what "small caseload" means at the start.

**Evidence status**

Research tier: L0 — no searches; user links read 0

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | Research not run; needs your consent |
| 2. Role-family sweep (scope, title, pay) | skipped | Research not run; needs your consent |
| 3. Hiring manager footprint | n/a | No name given |

**Dossier offer:** If you want, I can save this as a `tuesday-dossier.md` for later sessions.

**Upgrade menu**
- Say yes and I'll run L1 research (up to 5 searches, 2 page fetches): it checks the employer exists and the pay against a role-family range. This would clear or confirm the employer risk.
- Send the live posting link, if you have it.
- Check your NMC register entry and your driving licence record yourself. I have only your word for both.

**Questions**
1. [Row 5] In your DTA secondment, did you plan your own visit list and make decisions on individual patients without a senior signing off each one? Give one example.
2. [Rows 4, 11] Have you used an electronic patient record, and can you point to one written entry you'd call clear and timely?
3. [Row 13] Is £31,050 the lowest you'd accept, or is your floor higher?

Answer in prose, or say "skip" to any question.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.