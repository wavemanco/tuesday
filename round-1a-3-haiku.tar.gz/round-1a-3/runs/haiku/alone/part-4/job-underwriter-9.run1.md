## Decision snapshot

- **Opportunity:** conditional go. The role reads as a legitimate payroll post. The offer is conditional on independent verification of the employer, which I could not run here.
- **Candidate fit:** strong on the core duties. Two real gaps: pension changes, and scale (240 monthly staff against your 90 fortnightly).
- **Hard gates:** none failed. Three are unknown to me: Limerick location and the two-day office pattern, your right to work in Ireland, and your notice period.
- **Research tier: L0, no searches.** My web search was not permitted in this session, so nothing below about Marrowgate itself is checked.

## Your direct question: is the data request normal?

Mostly yes, but the timing and channel are what you should check.

- **Bank details for salary** and **PPS number for Revenue** are routine for a permanent employee. Payroll cannot run without them, and PAYE and PRSI are reported under your PPS. `[generic]`
- **Passport for right-to-work** is common practice for Irish employers. Many ask for a copy, and some ask to see the original on day one. `[generic]`
- **Your rule was about not handing these to unverified parties.** Your rule is a good one, and it still applies here. The question is whether this request reaches you through a channel you have confirmed belongs to the employer.

What makes this look like a real process: a written offer with a named manager (Declan Garvagh), a specific salary inside the posted band, and two in-person interviews at their office. `[grounded]` These are not proof. I cannot confirm them independently from here.

**What to verify before you accept or send any details:**

1. Go to Marrowgate's official website yourself, not via the email or any link in it. Confirm the People team email, phone number, and that Declan Garvagh is listed as Finance Manager.
2. Phone the switchboard number from that website and ask them to confirm the offer and the onboarding process.
3. Check the onboarding link's domain letter by letter against marrowgatehousing.ie. A lookalike domain is the usual trap, and this is the only place a fake could do harm.
4. Do not send your passport, PPS or bank details by ordinary email. Use the official portal only, after step 1–3 pass.
5. Ask whether the offer is also in the employer's own system, and when the original passport check happens.

If any of these fail, stop and do not send details. I am not saying that is the case here; I can only say it is worth doing before you give any details.

## Role reality

- **Title and scope:** payroll for 240 staff, monthly. Starters, leavers, pension changes, payroll-to-GL reconciliation, staff queries. `[grounded]`
- **Pay:** €40,000 offered against a posted €38,000–€42,000 band. `[grounded]` No market check was run, so I cannot say whether the band is typical. `[generic]`
- **Location:** hybrid, two days a week in the Limerick office. `[grounded]`
- **Contradictions:** none found within the material you gave me.

## Evidence map

| # | Priority | Fit | Confidence | Gap | Requirement and evidence |
|---|---|---|---|---|---|
| 1 | must-have | Met | high | none | 2+ years running payroll. Three years, fortnightly, 90 staff. |
| 2 | must-have | Likely | medium | presentation | Working knowledge of Irish PAYE, PRSI, USC. Implied by the hotel role, but the detail is not stated. |
| 3 | must-have | Met | high | none | Strong Excel. Daily use, pivot tables, XLOOKUP. No scale or example stated. |
| 4 | must-have | Met | high | none | Payroll qualification. Payroll Technician certificate, 2024. |
| 5 | core duty | Partial | medium | transferability | Monthly payroll for 240 staff. You have fortnightly for 90. Same work, larger and less frequent cycle. |
| 6 | core duty | Met | high | none | Starters and leavers. |
| 7 | core duty | Gap | low | capability | Pension changes. You have not done these yourself. |
| 8 | core duty | Met | high | none | Monthly payroll-to-ledger reconciliation. |
| 9 | core duty | Likely | low | presentation | Staff payroll queries. Implied by the role, not in your background. |
| H1 | hard_gate | Unknown | — | — | Limerick location and two office days a week. |
| H2 | hard_gate | Unknown | — | — | Right to work in Ireland. Not stated. |
| H3 | hard_gate | Met | high | none | Pay within the posted band. |

## Gap recovery queue

- **Row 7, pension changes (capability).** Closes with: a short account of what you saw your manager do, or a course or hands-on practice before you start. Do not claim pension experience you do not have.
- **Row 5, scale (transferability).** Closes with: any evidence you have of batch processing or monthly cycles at higher volume. Otherwise state the gap plainly and say how you would ramp up.
- **Row 2, Irish PAYE/PRSI/USC (presentation).** Closes with: examples of Irish rate changes or statutory returns you have processed, in the hotel role.

## Opportunity risk register

- **Standing entry: employer not verified.** Class: unverified attribution. Severity: high until checked. Reasons, none ranked as likely: a real but small or new employer, a stale or cloned posting, or a sender who is not the employer. This caps the decision at conditional go until the verification steps above are done. The fastest closer is the switchboard check on their own website.
- **Mismatch check:** none run without research.

## Application plan

Only if verification passes. Lead with the payroll-run and reconciliation record, which is your strongest match. Name the pension gap in your first conversation with Declan Garvagh rather than leaving them to find it.

## Evidence status

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Official site and careers page | unavailable | Web search was not permitted in this session. |
| 2 | Role-family sweep | unavailable | Same. |
| 3 | Hiring manager footprint | n/a | No research run. |

## Dossier offer

If you want, I can write a `tuesday-dossier.md` file capturing this assessment, so you can carry it into later conversations.

## Upgrade menu

- **Research at L1 (default):** up to 5 searches and 2 page fetches to confirm Marrowgate exists as described, check the posting is live, and calibrate the salary band. This would need you to allow web search in this session.
- **Your Irish PAYE/PRSI/USC examples:** would move row 2 from likely to met.
- **A payroll example at larger volume:** would move row 5 up.

## Questions

1. Do you live within commuting range of Limerick, and do you have the right to work in Ireland without sponsorship? *(Response modes: answer in prose, or say skip. Either is fine.)*
2. Did you get the People team email from Marrowgate's website, or from somewhere else?
3. Can you give an example of an Irish statutory return or rate change you handled at the hotel group?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.