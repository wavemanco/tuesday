**Decision: conditional go.** Apply, but confirm the live posting and the invite's sender before you commit time to the call.

**Hard gates:** None fail on what you've given me. Galway and two office days fit your location. Pay is the open item: you haven't stated a floor, so I can't check it against the €52,000–€60,000 range.

**Fit (your ledger)**
- **Strong:** 3+ years of product design (4 years), daily Figma, and your own user research (monthly customer usability sessions). You've worked in a squad with four engineers, which covers "ship alongside engineers."
- **Transferable, with a limit:** You redesigned checkout, which sits inside a booking flow, so owning the booking flow is a close bridge. The limit is that you owned checkout inside a team, not end-to-end from discovery to shipping, and your research subjects were travellers, not business owners. Running research calls with school owners is a different audience. A short note on how you'd recruit and run those calls would narrow that gap.
- **Capability gap:** Being the only designer. You've never done it. The closure path is to show how you'd set up design practice alone: which decisions you'd make first, how you'd get engineering feedback, and what you'd stop doing. Ask Ronan how they've handled design so far.

**Opportunity (the role's ledger)**
- **The company exists as described** `[grounded]`: its About page says it makes Kelproster, booking software for sea-kayak, surf and sailing schools; it has six people in Galway; it was founded in 2023 by Ronan Kehoe and Saoirse Doyle; and it's customer-funded. Ronan's public LinkedIn lists him as co-founder and CEO, previously product lead at a Galway travel-software company for five years. "Co-founder" in the posting and "CEO" on LinkedIn don't conflict.
- **The posting isn't confirmed live.** The company's careers page returned no page. This is a standing entry, and it caps the decision at conditional go until you verify it. Ask for the live posting link or the careers page.
- **The WhatsApp message** is a plausible way for a small company to schedule a call. It isn't a red flag by itself. What would be a red flag is a request to pay for equipment or a deposit, or to send bank or ID details before a written offer. Nothing like that has happened. To check the invite, confirm it comes from an address on the company's domain and that the attendees are Ronan and Saoirse.
- **Pay and equity:** The market band for this role wasn't checked. Before you count the equity, ask about vesting, the share class, and the current valuation.

**Application plan**
- Reply to Ronan on WhatsApp: ask for the live posting link, and confirm the invite is coming from the company email.
- Prepare the checkout case study as a story about what you owned and decided, and say which parts were a team's.
- Prepare one answer on how you'd run research with school owners and what you'd need to start.

**Evidence status**

Research tier: L1 — searches 2 of 5, fetches 2 of 2; user links read 0

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | yes | About page fetched (fernquay.example/about); careers page returned no page |
| 2 | Role-family sweep (pay and scope norms) | skipped | Not run this turn; I can run it if you want a market pay band |
| 3 | Hiring manager's public footprint | yes | Search on Ronan Kehoe; LinkedIn snippet only, page not fetched |

**Options to strengthen this**
- The live posting link or the company's careers page: would verify the posting and lift the cap on the decision.
- The sender's email domain: would check the invite.
- Your pay floor and equity expectations: would make the pay check real.
- A market pay sweep (run on your OK): would give a band for the salary range.

I can also write this up as a `tuesday-dossier.md` to keep for the interview stage.

1. Can you share the live posting link, or the email address the invite came from?
2. What's the lowest total pay you'd accept, and how much weight do you give the equity?

Answer in text, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.