**Decision snapshot**

- **Decision:** `hold_pending_answers`. The fit is strong. Accepting should wait until you've verified the employer independently. Nothing you've shown me is a red flag. The employer just hasn't been checked yet.
- **Fit:** strong on the core requirements, with one real gap (pension changes).
- **Hard gates:** none failed. Salary (€40,000) sits inside the advertised €38,000–€42,000 band `[grounded]`. Hybrid pattern matches `[grounded]`. Start date and notice period are open, not failed.
- **Employer identity:** not yet verified. My web searches were refused, so I could not confirm that Marrowgate Housing exists, its domain, or the people named in the offer. This is an unverified check, not a failed one.

**Research tier: L1, searches 2 of 5, fetches 0 of 2. Both searches were refused because web search permission was not granted.**

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company's official site and careers page | unavailable | Search permission not granted; two attempts refused |
| 2 | Role-family sweep (payroll administrator, Limerick, €38–42k) | unavailable | Same |
| 3 | Hiring manager's public footprint (Declan Garvagh) | n/a | Not run; checks a named person's public role, which you can do yourself |

**Role reality**

- **Role:** Payroll Administrator, permanent, reporting to the Finance Manager. Duties: monthly payroll for 240 staff, starters and leavers, pension changes, monthly payroll-to-ledger reconciliation, staff queries `[grounded]`.
- **Scope read:** 240 staff against your 90 is a real step up in volume, but the duties are the same shape you already run `[inferred]`.
- **Market calibration:** not run (research unavailable).

**Evidence map**

| Requirement | Fit | Confidence | Evidence |
|---|---|---|---|
| 2+ years running payroll | Met | High | Three years fortnightly payroll, 90 staff |
| Irish PAYE, PRSI, USC | Likely met | Medium | Payroll Technician certificate 2024; working knowledge not yet tested in your own words `[inferred]` |
| Strong Excel | Met | High | Daily use; pivot tables; XLOOKUP |
| Payroll qualification or working towards one | Met | High | Payroll Technician certificate |
| Starters and leavers | Met | High | Direct experience |
| Monthly reconciliation to the general ledger | Met | High | Direct experience |
| Staff payroll queries | Likely met | Medium | Not stated directly `[inferred]` |
| Pension changes | Gap | n/a | Never done yourself; your manager handled them |
| Scale (240 staff) | Partial | Medium | Larger than your current 90 |

**Gap recovery queue**

- **Pension changes** (capability gap, moderate). Closes with a concrete example of pension admin, even if observed rather than run yourself, or a recent course. Ask the employer which scheme and provider they use, and whether there is a handover.

**Opportunity risk register**

| Risk | Class | Severity | Note |
|---|---|---|---|
| Employer existence and sender domain unverified | Unverified | High (until checked) | Caps the decision at hold; see steps below |
| Sensitive-data request arrives before you've verified the employer | Process | Medium | The request itself is routine after a credible written offer; the timing and channel are what to check |
| Start date and notice period unstated | Terms | Low | Normal at offer stage |

**On the sensitive data request.** Asking for a PPS number, bank details and passport details after an offer is standard practice in Ireland `[generic]`. Your rule is still a good one: share them only after you've verified who you're sending them to, and never by replying to an email. Your in-person interviews are a point in the employer's favour. The check that matters is whether the portal and sender really belong to Marrowgate.

**Application plan: steps before you reply**

1. **Verify through a channel you find yourself.** Call Marrowgate's switchboard, using the number on their official website or the one from your interview invitation, and ask for People Team and Declan Garvagh. Don't use a number or link from the offer email.
2. **Check the sender domain.** Compare `marrowgatehousing.ie` against the domain on your interview correspondence and their website. Watch for lookalikes.
3. **Check the regulator register.** Housing associations in Ireland are often registered with the Approved Housing Bodies Regulatory Authority `[generic]`. Confirm this one if it applies.
4. **Ask for the written terms first.** Reply to accept only after step 1, and ask for the written contract and the portal provider's name before you enter anything.
5. **Ask about passport handling.** Ask whether the right-to-work check can be done in person on day one with the original, rather than by portal scan. Many employers accept this, and it means you don't upload a scan.
6. **Keep sensitive details out of email.** Enter bank, PPS and passport details only on a portal you've verified.

**Questions (up to 3)**

1. Who did you meet at the interviews, and do you have a direct contact or a switchboard number you can use to confirm the offer? (Gap: employer verification.)
2. Does the sender address and any portal link match the domain on your interview invitations and the company website? (Gap: domain check.)
3. Would Marrowgate accept an in-person right-to-work check on day one, in place of a passport scan? (Gap: passport handling.)

Response modes: answer after each question, or all together.

**Upgrade menu**

- Web search (permission granted): would confirm the employer exists, its website and careers page, and a market-pay check. Costs up to 5 searches and 2 page fetches.
- Your notice period and preferred start date: sharpens the timeline before the five-day window closes.
- Pension scheme details, if the employer shares them: would let us assess the pension gap concretely.

**Dossier offer:** I can save this assessment as a `tuesday-dossier.md` file if you want it for later use.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.