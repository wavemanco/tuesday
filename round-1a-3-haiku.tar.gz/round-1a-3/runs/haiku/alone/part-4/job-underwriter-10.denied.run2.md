**Decision: conditional_go.** Apply and take the call, but verify the company before you share anything beyond what you've already sent. This is a screening-call decision, not an offer decision.

**Decision snapshot**

- **Fit (candidate vs. role):** Strong on the core craft requirements. The real gaps are "first designer" (you've never been the only designer) and B2B research with school owners.
- **Opportunity:** Plausible small-company role with a live-looking posting. Existence and terms are not yet verified, and the equity terms are unstated.
- **Hard gates:** None failing on what you've given me. Location fits (you're in Galway, hybrid is two days a week). Salary and equity are unknown against your floor, which I don't have.
- **Research tier:** L1 declared, but no research ran (see evidence status). Nothing about Fernquay, Ronan Kehoe or Saoirse is verified.

**Role reality**

- Product Designer, first design hire at a six-person company. Owns the booking flow end to end, runs research with school owners, ships with two engineers, works most closely with co-founder Ronan Kehoe. [grounded, from the posting]
- Salary €52k–€60k plus 0.5–1% equity. The posting gives no vesting, strike price, option-plan terms or employment type (employee vs. contractor). [grounded, absence noted]
- Scope signal: a first designer at a six-person startup usually means setting up the design practice alone, with no design lead to review your work. [generic]
- Market calibration: I could not run the role-family sweep, so I cannot say whether €52k–€60k is normal for Galway. Treat it as unverified. [generic, unverified]
- Contradictions: none inside the posting. The "hard to find online" note is itself unresolved (see risk register).

**Evidence map**

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | Must-have | 3+ years product design | Met | High | None | 4 years as product designer, Dublin travel-booking company [grounded, your statement] |
| 2 | Must-have | Strong Figma | Met | Medium | Presentation | Figma daily [grounded]; needs a work sample to show it |
| 3 | Must-have | Has run own user research | Met | Medium | Discovery | Ran monthly usability sessions with customers [grounded]; consumer or B2B unstated |
| 4 | Must-have | Works directly with engineers | Met | High | None | Squad with four engineers [grounded] |
| 5 | Must-have | Own the booking flow end to end | Partial | Medium | Transferability | Redesigned the checkout flow [grounded]; checkout is one slice of booking, and "end to end" ownership is unconfirmed |
| 6 | Must-have | Research calls with school owners | Unknown | Low | Transferability | No evidence of small-business or B2B research; consumer research is adjacent |
| 7 | Implied | Working as the only designer | Gap | High | Capability | You've never been the only designer [grounded, your statement] |
| 8 | Implied | Location / hybrid | Met | High | None | Moved back to Galway last year [grounded] |
| 9 | Stated term | Salary €52k–€60k | Unknown | — | Hard-gate check | Your floor is not known to me |
| 10 | Stated term | 0.5–1% equity | Unknown | — | Hard-gate check | No vesting or strike terms |

**Gap recovery queue**

- **Row 5:** Put the checkout work in its real scope (which steps, which decisions you owned). Closes with a portfolio link or a case-study excerpt.
- **Row 6:** Name any B2B, small-business or operator research you've done, even informal. If none, say so and describe how you'd run the school-owner calls. Don't claim B2B research you haven't done.
- **Row 7:** Frame it as "I've worked inside a squad with design peers; I haven't been the sole designer" and list the things you'd do solo (own your review loop, make the research case to founders). Don't claim sole-designer experience.
- **Rows 9–10:** Need your salary floor and minimum acceptable equity/vesting terms.

**Opportunity risk register**

- **Standing entry, failed attribution (severity: high, unresolved):** The employer's existence as described is not verified, because I could not search. Reasons it may be unconfirmed, none ranked as likely: very new or very small company; a stale or limited posting; the company not having a public web presence yet. This caps a `go` at `conditional_go` until verified.
- **Outreach channel (severity: low):** The co-founder's WhatsApp message is a common way small Irish companies schedule. It is not a red flag on its own. The invite was supposed to arrive by email, so check that it did, and from which domain.
- **Unstated terms (severity: medium):** Equity vesting, option type, employment type and a salary band are not given. Ask before you go past the call.
- **Mismatch check (severity: medium):** Posting asks for research with school owners and end-to-end booking ownership; your evidence is consumer research and one checkout flow.

No red flags in the posting itself: nobody has asked you to pay, deposit money, or send bank, tax or ID details before an offer.

**Verification you can do yourself (advice, not research)**

1. **Companies Registration Office (cro.ie):** Search for "Fernquay" and check it's a registered Irish company, its incorporation date, and its directors. Check whether Ronan Kehoe is listed.
2. **The invite:** Find the calendar email. Note the sender domain. Check it matches a domain on the company's own website. If there's no company website, that's your answer to ask about.
3. **Ask Ronan by email (not WhatsApp):** Send the live posting link, the company website or careers page, and the employment type and equity terms. Reasonable founders will answer this without fuss.
4. **Public footprint:** Check Ronan's and Saoirse's LinkedIn for roles that match what they say. Check whether the company page shows about six people.
5. **Before the call, don't send:** ID, PPS number, bank details or anything else, until there is a written offer.

**Application plan**

- **Lead with:** the checkout redesign, the monthly customer usability sessions, and four years of squad work with engineers. These are verified-by-you and specific.
- **Be honest about:** no B2B research and no sole-designer experience. Say how you'd close each gap. Don't claim either.
- **On the call, ask:** runway and how long the company has been running; how many schools use the product now; what "first designer" means for product decisions; equity vesting, strike price and employment type.
- **Interview prep** for the 45-minute call with Ronan and Saoirse can go to mock-interview, which is a separate skill. I haven't done that work here.
- **Resume edits:** none proposed yet. Any CV language is pending your approval.

**Evidence status**

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | unavailable | Web search was not permitted in this session, so nothing was checked |
| 2. Role-family sweep (scope, title, pay for this seniority) | unavailable | Same |
| 3. Hiring manager's public footprint (Ronan Kehoe) | unavailable | Same |

No L2 targets were run or offered. Everything above that is not tagged as yours or from the posting is `[generic]` or unverified.

**Dossier offer:** If you'd like, I can save this assessment as `tuesday-dossier.md` so it carries into later prep.

**Upgrade menu**

- **Live posting link or Fernquay's website:** verifies the company exists as described. Unlocks the failed-attribution entry.
- **CRO record for Fernquay:** verifies registration and directors.
- **Portfolio or checkout case-study excerpt:** raises rows 2, 3 and 5 from medium to high.
- **Your salary floor and minimum equity/vesting:** resolves rows 9 and 10.
- **Any B2B or operator research:** resolves row 6.
- **Live product or demo access:** tests whether the booking flow exists and is live.

**Questions**

1. What's your salary floor, and what's the minimum equity or vesting you'd accept? (Rows 9–10.)
2. Have you ever run research with business owners, or only with consumers? (Row 6.)
3. What domain did the calendar invite come from, and does it match a website you can find for Fernquay? (Verification step 2.)

Response modes: answer in text, or say skip for any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.