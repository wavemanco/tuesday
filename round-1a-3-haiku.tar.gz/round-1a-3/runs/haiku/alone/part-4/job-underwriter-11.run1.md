**Short answer:** The Duinvaart role is worth applying to, on conditions. The Kroonhaven planner role isn't worth your time right now. Neither employer was checked: the search tool was denied, so this is based only on the two postings and your background.

## 1. Duinvaart Cold Chain, Operations Analyst: `conditional_go`

**Fit ledger.**

- `hard_gate`: unclear: D8 (Hybrid, three days a week in the Rotterdam office)
- `must_have`: direct: D1, D2, D3, D5a · unclear: D5b (Track temperature compliance across a refrigerated fleet)
- `important`: direct: D4, D6
- `preferred`: adjacent: D7 (Dutch a plus)

Your analytics work covers most of the role. The open question is temperature data, which your background doesn't mention.

**Opportunity ledger.** The scope is concrete and matches your tools (DR3). The employer is unverified (DR1, unresolved). The temperature duty doesn't say who acts on a breach (DR2, unknown).

- **Hard gates:** none failed; unconfirmed: D8 (Hybrid, three days a week in the Rotterdam office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) you can work in Rotterdam three days a week (D8); (2) the role appears on Duinvaart's own careers page (DR1); (3) you describe temperature work as a gap, not experience (D5b)

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; refrigerated fleet | `[grounded]` JD; not checked, search denied |
| Mandate | Track on-time delivery and temperature compliance; weekly Power BI dashboards; route changes with depot managers | `[grounded]` JD |
| Scope read | An analyst role that reports and advises, with no stated authority over routes | `[inferred]` from the JD's verbs |
| Working pattern | Hybrid, three days a week in Rotterdam | `[grounded]` JD |
| Compensation | Not stated; no band checked | — |
| Contradictions | None found in the posting | `[grounded]` JD |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning and provenance | Next action |
|---|---|---|---|---|---|---|---|
| D1 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as operations analyst at a parcel carrier. `[grounded]` CV | none |
| D2 | Strong SQL | must_have | direct | medium | none | Daily SQL use. `[grounded]` CV | A sanitized query would raise to high |
| D3 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use. `[grounded]` CV | A sanitized dashboard screenshot would raise to high |
| D4 | Build weekly dashboards in Power BI | important | direct | medium | none | Built the on-time dashboard depot managers use. `[grounded]` CV | As D3 |
| D5a | Track on-time delivery | must_have | direct | medium | none | Owned the on-time dashboard. `[grounded]` CV | none |
| D5b | Track temperature compliance across a refrigerated fleet | must_have | unclear | none | discovery | Nothing in your background covers temperature data. `[grounded]` CV silence | Q1 below |
| D6 | Work with depot managers on route changes | important | direct | medium | none | Ran the weekly route-performance review. `[grounded]` CV | none |
| D7 | Dutch a plus | preferred | adjacent | low | transferability | Conversational, below working level. Limit: not fluent. `[grounded]` your statement | Describe it as conversational |
| D8 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | The posting states it; you haven't given a constraint, so it's unchecked. `[grounded]` JD | Q2 below |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis and provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|
| DR1 | Employer not checked | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The employer may be too new or small for a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. The check didn't run, so this isn't a finding. `[generic]` pattern | "Can you confirm this role on your own careers page, and who would I interview with?" | unresolved; caps the decision at `conditional_go` |
| DR2 | Temperature duty has no visible owner | unknown | — | "track on-time delivery and temperature compliance across our refrigerated fleet" | The role may report temperature data without authority over the units or depots that act on a breach. `[inferred]` from the JD's verbs against its silence on who acts | "When temperature drifts out of range, who acts, and what does this role own in that process?" | unresolved |
| DR3 | Concrete scope and tools | positive_signal | — | "build weekly dashboards in Power BI" | The scope is specific and matches your CV. `[grounded]` JD | "How is a good month for this role measured?" | noted |

**Application plan** (proposed; nothing is final until you approve it)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your CV bullets with the on-time dashboard and the route-performance review; add numbers only if you have them | D4, D6 | `[grounded]` CV | pending your approval |
| E2 | Describe the dashboard by its users (depot managers) and the decisions it fed | D4, D6 | `[grounded]` CV | pending your approval |
| A1 | Answer the temperature question with what you did: you haven't tracked temperature data; name the nearest thing you did handle. Don't imply cold-chain experience | D5b, DR2 | `[grounded]` CV silence | pending your approval |
| A2 | Find the posting on Duinvaart's own careers site before applying | DR1 | `[generic]` standing check | advice |

Reframing check: "conversational Dutch" stays "conversational Dutch." Don't rephrase it as working or business Dutch.

## 2. Kroonhaven Foods, Supply Planner: `no_go`

Recommendation: no, not for this posting. Two must-haves are absent from your background (K1, K3), one is short of the bar (K6), and one is unexamined (K4).

**Fit ledger.**

- `hard_gate`: unclear: K7 (On-site in Utrecht)
- `must_have`: adjacent: K6 (Fluent Dutch) · unclear: K2 (Advanced Excel), K4 (Own a 13-week supply plan, balancing capacity against forecast) · absent: K1 (3+ years of FMCG supply or demand planning), K3 (SAP IBP or similar planning system)
- `important`: adjacent: K5 (Run the weekly S&OP meeting)

**Opportunity ledger.** The scope is concrete (KR2). The employer is unverified (KR1, unresolved).

- **Hard gates:** none failed; unconfirmed: K7 (On-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** real volume or peak-capacity planning, or a planning tool, would move K3 and K4. K1 (FMCG planning years) and K6 (fluent Dutch) stand either way.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; chilled ready meals | `[grounded]` JD; not checked |
| Mandate | Own the 13-week supply plan; balance capacity against forecast; run the weekly S&OP meeting | `[grounded]` JD |
| Scope read | A planning owner role; "3+ years" sets the seniority | `[inferred]` from the JD's stated years |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Compensation | Not stated; no band checked | — |
| Unknowns | Planning system in use; who owns production capacity; the forecast source | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning and provenance | Next action |
|---|---|---|---|---|---|---|---|
| K1 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | transferability | No planning or FMCG work in the CV. The nearest adjacency is delivery-performance analysis, which isn't planning. `[grounded]` CV silence | Not closable quickly for this posting |
| K2 | Advanced Excel | must_have | unclear | none | discovery | Excel isn't mentioned; SQL and Power BI are. `[grounded]` CV silence | Ask about Excel depth |
| K3 | SAP IBP or similar planning system | must_have | absent | none | discovery | No planning system named. `[grounded]` CV silence | Q2 below |
| K4 | Own the 13-week supply plan; balance capacity against forecast | must_have | unclear | low | discovery | Peak or volume capacity planning at a parcel carrier would be the nearest work, and the CV is silent on it. `[generic]` that parcel carriers plan peak capacity; not a claim about you | Q2 below |
| K5 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | Ran the weekly route-performance review. Limit: it reviewed past performance; it made no supply or production decisions. `[grounded]` CV | none |
| K6 | Fluent Dutch | must_have | adjacent | medium | capability | Your conversational Dutch is below the fluent bar the posting sets. `[grounded]` your statement | Sustained language work; a CV edit can't close it |
| K7 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | The posting states it; you haven't given a constraint. `[grounded]` JD | Q3 below |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis and provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|
| KR1 | Employer not checked | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Same as DR1. `[generic]` pattern | "Can you confirm this role on your careers page, and who would I interview with?" | unresolved |
| KR2 | Concrete scope | positive_signal | — | "Own the 13-week supply plan" | Horizon, meeting and owner are all named. `[grounded]` JD | "Who sets the forecast the plan balances against?" | noted |

## Evidence status

Verified: none yet. Your background is at intake level; nothing has been probed or inspected.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for both employers were refused by the host, so neither was checked. Would have moved DR1 and KR1 and the contradictions check. |
| 2. Role-family sweep | unavailable | Searches for supply-planner and operations-analyst pay in the Netherlands were refused. Neither posting states pay, so there is no market calibration. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

Every call was refused, so the 4 searches count against the budget but produced no results.

I can save this as `tuesday-dossier.md`, so the conditions and the register carry into later prep.

## Upgrade menu

- A sanitized dashboard screenshot or a sanitized query → D2–D4 move to `high`.
- Duinvaart's live posting or careers-page link → DR1 resolves, and the `conditional_go` cap lifts.
- Search permission, so the two employer checks and the pay sweep can run → DR1 and KR1 resolve, and the pay band can be set against the postings. Neither posting states pay.
- A pay figure from the recruiter → the calibration row can be filled in.

## Questions

**Q1 (D5b):** Have you handled temperature or sensor data for any shipments, in any job?

**Q2 (K3, K4):** Did your parcel-carrier work include volume forecasting or peak capacity planning, and did you use any planning tool?

**Q3 (D8, K7):** Can you commute to Rotterdam and work there three days a week, and can you work on-site in Utrecht?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.