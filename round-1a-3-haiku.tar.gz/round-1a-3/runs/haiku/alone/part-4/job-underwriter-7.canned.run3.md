**Yes, apply. Status: `conditional_go`.** Your essentials are met on your own record. The gaps are a caseload you have never held and Doppler, which the advert only lists as desirable. Stage assumed: evaluating.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: direct: R1, R2, R3
- `must_have`: direct: R4; adjacent: R13 (own caseload); unclear: R5 (written records)
- `important`: direct: R6, R8, R10; adjacent: R7 (leg-ulcer care), R9 (continence care), R11 (care planning); unclear: R12 (end-of-life visits), R14 (electronic record)
- `preferred`: absent: R15 (Doppler assessment)

R13 (`low`): a real bridge with its limit named (no caseload held); R5 (`low`): records are not evidenced; R15: absent, but desirable only.

**Opportunity ledger.** Clean and specific. Pay, scope, senior support and a named contact are all stated (RR4). Caseload size, out-of-hours expectations and mileage are unstated (RR1, RR3), and the employer has not been verified here (RR2). No red flags.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) your answers on home-visit clinical scope and your record system (R13, R5, R14) hold up; (2) you confirm the post on the employer's own careers page (RR2); (3) the caseload size and support model (RR1) are concrete when you ask.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, Halifax; district nursing | `[grounded]` advert; existence not checked |
| Role | Community Staff Nurse, Band 5: own small caseload of housebound adults at home, with a senior community nurse | `[grounded]` advert |
| Duties | Wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, electronic patient record | `[grounded]` advert |
| Pay and terms | £31,050–£37,800 a year plus mileage; pool cars provided | `[grounded]` advert |
| Scope read | A caseload role with senior support; no outcomes are set out | `[inferred]` from the advert's wording |
| Market calibration | Not run. No research at this tier, so the stated pay is not checked against the market | — |
| Unknowns | Caseload size, out-of-hours expectations, mileage rate, employer existence | `[grounded]` advert silence |
| Contradictions | None found within the advert | `[grounded]` advert read |

## Evidence map

Confidence is `medium` where the claim rests only on your CV as written, because nothing has been checked.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult | hard_gate | direct | medium | none | Stated as active; not checked here | `[grounded]` CV | Check the NMC register yourself |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B, stated; not checked | `[grounded]` CV | Check your licence status yourself |
| R3 | Based in Halifax | hard_gate | direct | medium | none | You live in Halifax; the role is Halifax | `[grounded]` CV, advert | none |
| R4 | At least one year post-registration | must_have | direct | medium | none | Five years as a staff nurse | `[grounded]` CV | none |
| R5 | Clear, timely written records | must_have | unclear | low | discovery | The CV does not describe your documentation | `[grounded]` CV silence | Q2 |
| R6 | Wound care | important | direct | medium | none | Pressure and surgical wounds on the ward; home wound care not stated | `[grounded]` CV | see R13 |
| R7 | Leg-ulcer care | important | adjacent | low | transferability | Wound skills carry over; no venous or arterial leg-ulcer work is stated | `[inferred]` from R6 | Q1 |
| R8 | Catheter care | important | direct | medium | none | Stated | `[grounded]` CV | none |
| R9 | Continence care | important | adjacent | low | transferability | Catheter care is related; no continence assessment or product work is stated | `[inferred]` | Q1 |
| R10 | Insulin administration | important | direct | medium | none | Stated | `[grounded]` CV | none |
| R11 | Care planning | important | adjacent | low | transferability | Discharge visits imply planning; the CV does not say you wrote care plans | `[inferred]` | Q1 |
| R12 | End-of-life visits | important | unclear | low | discovery | The CV is silent | `[grounded]` CV silence | Q1 (if relevant) |
| R13 | Own small caseload, with senior support | must_have | adjacent | low | transferability | Independent home visits in the first week after discharge; you say you have never held a caseload | `[inferred]` | Q1 |
| R14 | Electronic patient record | important | unclear | low | discovery | The CV names no record system | `[grounded]` CV silence | Q2 |
| R15 | Doppler assessment for leg ulcers | preferred | absent | medium | capability | Stated as never done; desirable only | `[grounded]` CV | closure path below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own caseload (R13) | transferability | Independent home visits after discharge; no caseload held | Caseload is the core of the role; the bridge needs a stated limit | Planning and prioritising your own visit list; follow-up of patients you saw at home | A redacted visit log or handover note | `[inferred]` |
| G2 | Written records (R5) | discovery | Records are not described in the CV | Essential, and the advert says "clear, timely" | Discharge summaries; home-visit notes; records you completed on time | A redacted note or template | `[grounded]` CV silence |
| G3 | Electronic record (R14) | discovery | No system named | Day-to-day work is on the EPR | Any electronic record you have used | The system's name | `[grounded]` CV silence |
| G4 | Leg-ulcer care (R7) | transferability | Wound skills; no venous or arterial work stated | Leg ulcers are named in the duties | Dressing and wound assessment of any kind; compression if you have used it | Any wound-assessment record | `[inferred]` |
| G5 | Continence (R9) | transferability | Catheter care only | Named in the duties | Catheter care decisions; bladder assessments | A care-plan excerpt | `[inferred]` |
| G6 | Care planning (R11) | transferability | Discharge visits only | Care planning is a named duty | Discharge plans you drew up | A discharge plan excerpt | `[inferred]` |
| G7 | End-of-life (R12) | discovery | Not in the CV | Named duty | Any end-of-life or palliative discharge | — | `[grounded]` CV silence |
| G8 | Doppler (R15) | capability | Never done | Desirable only; not essential | None stated | — | `[grounded]` CV; closure path `[generic]`: a short course or supervised practice, often arranged after appointment |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Caseload size and out-of-hours expectations unstated | unknown | — | "a small caseload, supported by a senior community nurse" | The workload or on-call burden may be heavier than the wording suggests | `[grounded]` advert silence | How many patients does a typical caseload carry, and what is expected out of hours? | unresolved |
| RR2 | Employer and posting not verified | unknown | — | "Calderbrook Community Health CIC, Halifax" | The listing's existence is untested here | `[grounded]` no lookups run, at your request | Is this post on your own careers site, and who would I be interviewing with? | unresolved |
| RR3 | Mileage rate and pool-car arrangement unstated | unknown | — | "plus mileage"; "pool cars are provided" | Travel cost and car allocation are unknown | `[grounded]` advert silence | What is the mileage rate, and how are pool cars shared across the team? | unresolved |
| RR4 | Pay and support stated | positive_signal | — | "£31,050–£37,800 a year"; "supported by a senior community nurse" | Terms and support are stated, which is a transparent posting | `[grounded]` advert | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Describe the caseload gap plainly, e.g. "I have not held a caseload; I visited patients at home in their first week after discharge" | R13 | `[grounded]` CV; reframing check passed | pending your approval |
| A2 | Add home-visit clinical tasks to your CV only if they were part of your visits (Q1 answer) | R7, R9, R11 | `[grounded]` CV silence | pending your answer |
| A3 | State plainly that you have not done Doppler, and ask whether training is provided | R15 | `[generic]` community teams often train in Doppler after appointment; not a fact about this employer | pending your approval |
| A4 | Check your NMC register entry and licence status yourself before applying | R1, R2 | `[grounded]` stated, not checked | your action |
| A5 | Confirm the post on the employer's own careers page before investing effort | RR2 | `[grounded]` | your action |

## Evidence status

Verified: none yet. Every candidate claim here comes from your CV as written. Your National Insurance number isn't needed for this assessment, so I haven't used it.

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | skipped | Would confirm the employer exists and the post is live (RR2). You asked for no external lookups |
| 2. Role-family sweep | skipped | Would set the pay band against this title's norms (market calibration) |
| 3. Hiring manager's public footprint | skipped | A name was given (Rhiannon Mabbott, Community Nursing Team Lead); not searched, per your request |

I'm offering to write this up as a `tuesday-dossier.md` file you can carry through your applications.

## Upgrade menu

- Answers to Q1 and Q2 → R13, R7, R9, R11, R5 and R14 move
- A redacted visit log, handover note or discharge plan → R13 and R11 move toward `direct` (confidence `high` only once checked)
- The post on Calderbrook's own careers page → RR2 closes
- A lookup at L1 (up to 5 searches and 2 fetches) → checks the employer exists and sets the pay against the market. Say the word and it runs
- Mileage rate and caseload size from the employer → RR1 and RR3 close

## Questions

R13 — On your discharge-to-assess visits, did you do dressings, catheter care or insulin in people's homes, and did you write up the visit and the next steps yourself? (The answer also bears on R7, R9 and R11.)

R5 — Which record system have you used, and how did you write up visits and care plans, and how quickly? (The answer also bears on R14.)

Constraints (no row yet) — What is your stage: evaluating or applying? Is there a pay floor or any other non-negotiable I should check the role against?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.