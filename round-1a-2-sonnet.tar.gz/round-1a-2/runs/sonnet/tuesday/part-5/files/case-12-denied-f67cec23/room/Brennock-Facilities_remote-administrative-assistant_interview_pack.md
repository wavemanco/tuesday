# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Round: one 30-minute video call, per the invite. Interviewer: the office manager, name not given. Built on one assumption: the office manager is your day-to-day boss or works closely alongside you, so the pack uses the hiring-manager round type and lifts the Peer persona. If that is wrong, the persona weights below change.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. The ad's requirements come from your description of it, not its verbatim text.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values. None were found, so no question carries this tag |
| EXP | Whether your experience holds up under questions, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | What you know about the company and its strategy. None here: company research was unavailable |
| CASE | A live problem from the role, scored on structure and reasoning |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — ad, as you described it | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Say it at the quote's own scope: "I ran the appointment book for four physios." The ad's wording differs from your sentence, so describe yours as it is. A line with nothing inspected behind it draws a probe. Answer slot: expect to be asked what running the book involved day to day. Say what you did in your own words. If any part was not yours, say so plainly and stay with the book you ran |
| F2 | "booking travel" — ad, as you described it | none given | none | [grounded] | discovery | Your material does not show whether any travel booking was yours. Answer slot: if you have arranged travel for someone, say who it was for and what you did, in your own words. If you have not, or it was not yours, say so plainly, then say what you would ask to be shown first |
| F3 | "preparing documents in Word and Excel" — ad, as you described it | "I'm good with Word" — your message | low | [inferred] | discovery | Keep to the quote's words: "I'm good with Word." It is a self-rating with no document behind it. Answer slot: the ad has you preparing documents, so expect to be asked what you have made. If you have a document in mind, say what it was and who it was for, in your own words. If you do not, say so plainly and say how you would check your work before sending it |
| F4 | "preparing documents in Word and Excel" — ad, as you described it | "okay with Excel" — your message | low | [inferred] | discovery | Keep your own hedge at its own scope: "okay with Excel." Do not round it up. Answer slot: if you have used Excel for something specific, say what, in your own words. If not, or it was not yours, say so plainly and say what you would do to get quicker at it |
| F5 | "processing supplier invoices" — ad, as you described it | "chased unpaid invoices" — your message | low | [inferred] | transferability | Your material says chasing unpaid invoices, not processing supplier invoices, and does not say which side of the invoice you were on. Words: "At the clinic I chased unpaid invoices." Answer slot: if you have dealt with invoices from suppliers, say what you did. If you have not, or it was not yours, say so plainly and stay with the chasing |
| F6 | "Remote Administrative Assistant" — invite | none given | none | [grounded] | hard_gate | Your material does not establish whether working remotely suits your situation. This is a term you meet or do not, not something wording can change |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the thin rows | High. The hiring-manager prior puts it first, and F2, F4 and F5 are the thinnest rows | Rehearse the invoice objection until it is boring. Bridge only from your own sentences, and say the limit plainly |
| Case / Strategist | Live admin scenarios built from the ad's task list | High. The hiring-manager prior puts it first, and the ad lists tasks that turn directly into scenarios | Clarify first, then structure, then answer. Think aloud |
| Peer Evaluator | How the work is handed over and where you would disagree | Medium. Lifted from the prior because a remote assistant works with the office manager daily | Say what you bring as well as what you need. Propose how hand-offs should work rather than claiming to know their set-up |
| Conversational | Chatty opener, such as walk me through your journey | Medium. A 30-minute call usually opens this way, and casual questions are still scored | A 90-second arc built only from your own sentences |
| Values / Behavioral | Scenario probes | Low. No published values were found and the invite names no values round | Pick stories only where you can stand behind every detail |
| Data-Driven Prober | Line-by-line checks of your claims | Low. The figure "four physios" is the one number to defend | Know what you can and cannot say about it |
| Pressure | Time-boxed challenges | Low. Nothing in the invite points to a stress format | Pause, hold your position through two follow-ups, concede only what is true |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "okay with Excel", "chased unpaid invoices" | Pick the part by your own honest judgement and keep it at its own scope. If it is Excel, the words are "okay with Excel" and nothing stronger. If it is invoices, "I chased unpaid invoices". Answer slot: if you have done any travel booking, say what. If not, or it was not yours, say so plainly. Then give a plan stated as a plan: what you would ask to be shown in week one | F2, F4 and F5 are the thinnest rows, so this arrives in some form. JD because it scores the ad's list |
| A2 | "I don't see supplier invoices in your background. How would you handle the invoice work in this role?" | JD | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack. The hold is only what the quote carries: "At the clinic I chased unpaid invoices." Name the limit before it is asked for: your material says chasing, not processing. Answer slot: if you have dealt with invoices from suppliers, say what you did, in your own words. If you have not, or it was not yours, say so plainly. Hold through two follow-ups by returning to the chasing, never by adding to it. Then a plan stated as a plan | F5 is where the ad presses hardest against what your material shows, so this objection will come. JD because it scores a stated requirement |
| A3 | "Why this role, and why now?" | JD | [generic] | Give your own reasons, in your own words. The pack supplies none. This pack holds no facts about the company, so use only what you have checked yourself, and if you have checked nothing, say what drew you to the listed tasks | A motivation probe is standard for a change of role. F1 to F5 are the tasks it is likely to touch. JD because it scores fit to the listed job |
| A4 | "How comfortable are you with Excel, honestly?" | JD | [grounded] "okay with Excel" | Hold at the quote: "I'm okay with Excel." Answer slot: the ad pairs Excel with preparing documents, so expect to be asked what you have done in it. If you have something specific, say what, in your own words. If not, say so plainly and say what you would do to get quicker | F4 is a hedge in your own words, and a hedge draws a direct probe |
| A5 | "Tell me about a time you arranged travel for someone else." | JD | [generic] | Selection scaffold: pick an occasion with a named traveller, a real constraint and a clear outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F2 has no evidence behind it, so the honest branch matters. JD because it scores a listed task |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two colleagues ask for the same time slot and both say theirs is urgent. What do you do?" | JD | [generic] | Structure it: what you would ask each of them first, what you would do with the slot today, how you would tell both people, and what you would note afterwards. The question needs no claim about your past, so the guidance makes none | A live problem from F1's requirement. JD content, CASE delivery |
| B2 | "A supplier invoice arrives for a different amount from what was ordered. What do you do?" | JD | [generic] | Structure it: what you would check first and with whom, whether you would pay, hold or query, what you would tell the supplier, and what you would record. If you do not know the company's process, say what you would ask to be shown. The guidance makes no claim about your past | A live problem from F5's requirement. JD content, CASE delivery |
| B3 | "You are booking a trip and the cheapest option leaves a very tight connection. How do you decide?" | CASE | [generic] | Clarify first: who is travelling, what the trip is for, what the traveller prefers. Then set out the options, say which you would choose and why, and say how you would confirm with the traveller. The guidance makes no claim about your past | A live problem from F2's requirement |
| B4 | "You are handed a rough draft and a spreadsheet of figures an hour before a meeting. Walk me through it." | JD | [generic] | Clarify the purpose and the audience, then the order you would work in, how you would check the figures against their source, and what you would flag rather than guess. The guidance makes no claim about your past | A live problem from F3 and F4's shared requirement. JD content, CASE delivery |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What would you need from me to do this job well, and what can I count on from you?" | EXP | [generic] | Answer both halves in your own words. Offer only what you can stand behind from what you have really done. The pack supplies no strengths for you | The peer persona prices what the hire costs and gives. EXP because it tests whether your answer is real |
| C2 | "You would be working remotely. Where is the seam between your work and mine, and what happens when we disagree?" | JD | [generic] | Propose principles for hand-offs, such as how work is assigned, how you confirm you have understood it, and how you flag a clash, rather than pretending to know their set-up. Offer to agree the seam with them in the first week | F6's requirement is the remote term, and this is how it comes up collegially. JD content, Peer delivery |
| C3 | "Tell me about a time you disagreed with a colleague and how it ended." | EXP | [generic] | Selection scaffold: pick a disagreement with a named point at issue, what you said, and a working relationship that survived. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Disagreement with equals is the peer persona's own theme. EXP because it scores what you actually did |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic", "I ran the appointment book for four physios", "chased unpaid invoices" | A 90-second arc built from those three sentences and nothing else, in your own words. Answer slot: why this role, in your own reasons. Do not borrow reasons from this pack | F1 and F5 are the evidence the arc rests on. EXP because it is your story, told casually and scored anyway |
| D2 | "In your time as a receptionist, what does a normal day look like?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | The beats the quote states are the role, the clinic and the two years. Answer slot: describe a normal day from your own memory, in your own words. If part of what you describe was not yours, say so plainly | The usual friendly follow-up to D1. F1 is the nearest row. EXP because it tests what the role actually involved |
| D3 | "What would you enjoy most about this job?" | JD | [generic] | Answer in your own words, tied to the listed tasks you would honestly enjoy. The pack names none for you | A casual question about the ad's task list, scored for genuine interest. JD because it follows the listed tasks |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not back down, and a working relationship that was intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural probe. EXP because no published company values were found, so it scores your history, not a value |
| E2 | "When did you put a customer ahead of an internal metric?" | EXP | [generic] | Selection scaffold: pick a decision with a named customer, a named internal target, and what you chose. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The second standard behavioural stem. EXP for the same reason as E1 |

### F. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk me through how you ran the appointment book for four physios." | EXP | [grounded] "I ran the appointment book for four physios" | Story-mapped on F1: the book and the four physios are the beats the quote states. Tell them in your own words. Defend the number: say what "four" counted and which part of the book was yours. If you do not know how something was set up, say plainly that you do not know | F1 carries the only figure in your material, and probers go there first. EXP because it tests what was actually yours |
| F2 | "Walk me through how you chased unpaid invoices." | EXP | [grounded] "chased unpaid invoices" | Story-mapped on F5: the chasing of unpaid invoices is all the quote states. Tell it in your own words. If asked how many or how much, give only what you know, or say plainly that you do not know | F5 is the evidence for the invoice requirement and a prober will test its edges. EXP because it tests what you did |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over someone with more admin experience?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic", "I ran the appointment book for four physios" | Pause and restate the question. Hold only what the quotes carry: two years as a receptionist at a physiotherapy clinic, and you ran the appointment book for four physios. Hold through two follow-ups by returning to those facts. Concede plainly any task a follow-up names that your material does not show | F1 is the strongest row, and the question tests whether you hold it without inflating. JD because it scores fit to the job |
| G2 | "How much of running that appointment book was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold the quote: "I ran the appointment book for four physios." Answer slot: say which part was yours, in your own words. If part was shared, say so plainly. Hold through two follow-ups and concede only what is true | An attribution probe aimed at F1. EXP because it tests precise ownership |

## Requirement coverage

| Requirement | Questions covering it |
|---|---|
| F1 managing calendars | B1, F1, G1, G2 |
| F2 booking travel | A5, B3 |
| F3 Word | B4 |
| F4 Excel | A4, B4 |
| F5 supplier invoices | A2, B2, F2 |
| F6 remote term | C2 |
| Company strategy | none, and why: company research was unavailable, so no CO question could be grounded |

## Reverse questions

| # | Question to ask them | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like in this role?" | It shows you are thinking about results, and the answer tells you what really matters |
| R2 | "Who would I report to day to day, and who decides priorities when two requests clash?" | It shows you have thought about the seam C2 probes, and gets you the real answer |
| R3 | "How is equipment and a work set-up provided for remote staff, and who arranges it?" | A practical onboarding question. The answer, in their own words, is information you can check |
| R4 | "Which of the tasks in the ad takes most of the week?" | It tells you where to focus your first weeks and shows you listened to the ad |
| R5 | "How are supplier invoices approved and paid here, and what would my part be?" | F5 is your thinnest requirement, and this gets the real process on the table before you commit |
| R6 | "What could a new person do in their first month that would genuinely help you?" | A reciprocity question for an interviewer you would work alongside |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Processed or approved supplier invoices | Inflated form of F5 | F5's quote at its own scope: "chased unpaid invoices." The limit is the pack's observation, not words for you: your material says chasing, not processing. A2 and F2 stay inside the chasing |
| Advanced or expert skills in Word or Excel | Inflated form of F3 and F4 | The quotes at their own scope: "I'm good with Word" and "okay with Excel." A4 holds at the quote |
| Managed calendars for an executive or a team | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." G1 and G2 hold there |

## Sources

Provided documents: your message, containing the invite email, your description of the ad, and your background.

Searches sent:

- `Brennock Facilities Ltd values` — refused
- `Brennock Facilities Ltd strategy news` — refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | Search refused. It would have fed a values cheat sheet and VAL questions. Neither is in this pack |
| 2. interview process, office administration | skipped | The invite already fixes the loop: one 30-minute video call with the office manager |
| 3. `Brennock Facilities Ltd strategy news` | unavailable | Search refused. It would have fed a CO question and company-specific reverse questions |
| 4. interviewer name and company | n/a | No name was given |
| 5. representative Administrative Assistant JD | skipped | Your description of the ad fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's full text → F1 to F5's requirement quotes become verbatim, and any requirement you did not mention gets a row and a question
- Your CV → F1 to F5 get evidence beyond your message, and scaffolds such as A5, C3, E1 and E2 can become story maps
- Your answers to the slots in F2, F4 and F5 → those rows get quotes of your own and regenerate
- The interviewer's name and role → a tailored reverse question and persona weights read from their public footprint
- Permission to search, or a pasted about page or values page → a values cheat sheet, CO questions, and company-specific reverse questions; a deeper pass would add up to 6 more searches and 2 more fetches, taking several more minutes
- The recruiter's prep email → whether any test task or deliverable is planned
- A `tuesday-dossier.md` → the evidence you have already confirmed and the objection to rehearse most
