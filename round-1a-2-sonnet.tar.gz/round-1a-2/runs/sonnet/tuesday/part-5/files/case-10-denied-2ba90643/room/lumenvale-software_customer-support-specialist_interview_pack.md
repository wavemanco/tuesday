# Interview prep pack: Customer Support Specialist, Lumenvale Software

Interviewer: your support team lead (name not given). Format: a text chat on Telegram, per the invite. Relationship assumed: hiring-manager round, because the lead of the support team is the person most likely to be your manager. Reweight if that is wrong (question 1 of the closing questions in the message that came with this file).

## How to use this pack

- Personas are how a question is asked. Types are what it is scoring.
- JD: the stated requirements, including your gaps. EXP: whether your own claims survive scrutiny. CASE: a live problem from the job. CO: company and strategy knowledge. VAL: published values. No CO or VAL questions appear, because no company research could run and no values-style round is detected.
- Guidance is scaffolding, not a script. Say it in your own words. This interview is a text chat, so your written answers are also a sample of the clear written communication the ad asks for: short, plain, answer the question first.
- Where a cell says "Answer slot", it is an instruction for the interview, not a question for you now. Answer from your real experience, or say plainly it was not yours.

## Fit snapshot

The requirements are the four you listed from the ad, quoted from your message. The full ad text was not supplied, so mid-list items may be missing (see the upgrade menu).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad, as you gave it in your message | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap, but a line from your message with nothing inspected behind it, so expect a probe. Lead with the role and the years in the quote's own terms: three years as a customer service advisor at an energy supplier. Keep your own job title; the ad says customer support, your line says customer service advisor |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad, as you gave it in your message | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Say it in the quote's terms and name the tool: "I use Freshdesk every day." The ad names Zendesk, so expect a follow-up on it; C2 holds the answer slot for that |
| F3 | "clear written communication" — the ad, as you gave it in your message | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote shows emails among the contacts, not how clearly they were written, so it is a lead and not a claim about your writing. Answer slot: expect a probe on how you write to customers. Say what you do when you write a reply, in your own words; if there is no particular routine, say so plainly and describe how you write |
| F4 | "confidence handling escalations" — the ad, as you gave it in your message | none given | none | [grounded] | discovery | Nothing in your material speaks to escalations. Answer slot: the ad raises escalations, so expect a probe. If you have handled a contact that went beyond what you could resolve yourself, say what happened and what part was yours; if you have not, or none of it was yours, say so plainly and say how you would handle one |
| F5 | Working at a software company (a role-family expectation; the ad as you gave it does not state it) | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Persona table

Loop source: your message says the interview is one text chat with the support team lead, so the loop is one session and no archetype fallback is used.

| Persona | How it shows up here | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | Live support scenarios typed into the chat: an angry customer, a stuck escalation, a product problem you do not know | Highest, 5 questions. The hiring-manager prior is Case plus Skeptic, and the job is a live-problem job | Clarify, then structure, then answer; think aloud in short lines |
| Skeptic (B) | Probing the software-company gap and the escalations requirement | High, 4 questions. Same prior; F5 and F4 are the two thinnest rows | Rehearse the day-one-weakness question until it is boring; bridge only from what you stated |
| Data-Driven Prober (C) | Two figures in your message, 60 a day and four starters, invite "how was that counted" | Mid, 3 questions. A pack-side judgement: a manager reading your message will pick up the numbers | Know what you can and cannot say about each figure; say plainly when you do not know |
| Conversational / Rapport Builder (D) | Friendly openers: the journey, the training, the first month | Mid, 3 questions. Casual chat questions are still scored | Short pre-planned arcs from the quotes you gave |
| Pressure (E) | A time-boxed challenge: why you, over someone from software | Low, 2 questions. A pack-side judgement: a text chat gives less room to interrupt, so I weight it down | Hold a challenged position through two follow-ups, then concede only the specific thing that is true |
| Peer Evaluator (F) | Hand-off and credit questions with a colleague's eye | Low, 2 questions. A team lead may bring peer-style questions, but nothing in your message says so | Principles for hand-offs; do not pretend to know their seams |

Not weighted: Values / Behavioral. Your message names no values round, and no company values were read.

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes: I've been charged twice and I want to cancel today. Reply as you would, then tell me what you'd do next." | CASE | [generic] | Structure the reply in a few short lines: acknowledge both the double charge and the wish to cancel; say what you will check first; say what happens next and roughly when, without promising what you cannot control; ask only the one thing you need. The question needs no claim about your past, so the guidance makes none | A live problem from the job, delivered as written text; CASE with JD content because it scores written clarity (F3's requirement) |
| A2 | "A customer has been passed between three agents and now demands a manager. What do you do in the next ten minutes?" | CASE | [generic] | Clarify first: what has been done, what the customer actually wants. Then take ownership of the conversation, restate the issue so they do not repeat it, separate what you can resolve from what needs someone else, and tell them honestly who and when. Challenge one premise respectfully, for example whether the team already has a route for this. The guidance makes no claim about your past | The ad raises escalations (F4), and this tests the reasoning without presupposing any you have done; CASE with JD content |
| A3 | "A customer says a feature just stopped working after an update. You're new and you don't know the product well. What do you do before you reply?" | CASE | [generic] | Clarify what exactly stopped, since when and what they see. Look for what the team already knows about it before answering. Do not promise a fix or guess at a cause. If it needs someone else, hand it over with a clear summary and tell the customer what happens next. The guidance makes no claim about your past | F5 is the biggest gap, and this is the day-one situation it describes; CASE |
| A4 | "Two angry customers write in at the same moment and you have forty tickets waiting. Which do you answer first, and why?" | CASE | [generic] | Say the principle aloud before choosing: what you would want to know about each, and what is time-bound or has most impact. Then concede that the team's own priority rules would override your instinct, and that you would ask what they are. The guidance makes no claim about your past | Tests structured prioritisation in a ticket-queue setting; CASE |
| A5 | "A customer sends a long, emotional, unclear message. How do you write back so it's clear?" | CASE | [generic] | This is your view, in your own words, and the answer itself is the sample: answer their actual question first, short paragraphs, plain words, one clear next step. Keep your reply as short as you would want theirs to be. The guidance makes no claim about your past | The ad raises clear written communication (F3); a text-chat interview makes it unusually visible; CASE with JD content |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked for a software company. What's going to be hardest for you in this job?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier"; "answering around 60 calls and emails a day"; "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I've never worked for a software company." Then hold only what your quotes carry: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day, Freshdesk every day. Then the ramp as a plan, never a past: what you would ask, read and watch in your first weeks. Answer slot: say how you would start learning the product, in your own words. Follow-up one, "Software customers ask different things": concede you do not yet know this product's customers, and hold that the three years are real at their own scope. Follow-up two, "How long until you're independent?": give no figure you do not believe; either give your honest estimate or ask what the team expects of a new starter | F5 is the thinnest row and the most predictable objection; this question will arrive in some form. JD because it scores the stated fit, with Skeptic delivery |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Name what your material shows: knowing the product. Say it as a plain limit, then say in a line how you would close it. Do not offer a strength dressed as a weakness | The standard Skeptic opener; ties to F5, and answering it plainly is what it scores |
| B3 | "Tell me about a time a customer's issue went beyond what you could resolve yourself." | JD | [grounded] | A selection scaffold, because none of your quotes carries this story. Pick a time with a named stake, a moment you decided what to do, and an outcome you can state; it needs to be yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The ad raises escalations (F4) and your material is silent on it, so an open prompt is how it will arrive; JD with EXP delivery |
| B4 | "Why move from energy to software support, and why now?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Hold only the quote: three years at an energy supplier. Answer slot: give your actual reason in your own words; if there is no single reason, say what is true. Do not borrow company facts you have not read | Motivation consistency is what a Skeptic scores, and F5 makes the question likely; EXP because it tests whether your story holds together |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said around 60 calls and emails a day. How was that number counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Keep your own word, "around". Answer slot, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly | A headline figure is a magnet for probers (F3's evidence); EXP |
| C2 | "The ad names Zendesk. You use Freshdesk every day. What do you use it for, and have you used Zendesk?" | JD | [grounded] "I use Freshdesk every day" | Say what you use Freshdesk for in your own words, and name only what you actually use. Answer slot: if you have used Zendesk, say how; if you have not, say so plainly and stay with Freshdesk | F2's requirement names Zendesk and the evidence names another tool; JD because it scores the stated requirement |
| C3 | "You trained four new starters. What part was yours, and what was the team's?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold the sentence as it stands: four new starters, your refunds process, last year. Answer slot: say which part was yours, in your own words; if someone else set up or shared the training, say so plainly and stay with the four you trained. Do not call it onboarding or a programme | A second figure invites an attribution probe; EXP |

### D. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey into customer support." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | A short arc built on the quote: the role, the three years, the energy supplier. Answer slot: say in your own words how you came to it and where you want to go next; if there is no neat story, say what is true | The standard biography question, asked casually; EXP |
| D2 | "Tell me about the refunds training you did." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell the beats the sentence states: four new starters, the refunds process, last year. Answer slot: if you set out how the training would run, say how; if it ran another way or someone else set it, say so plainly and stay with the four you trained | The one teaching line in your material, and a likely warm-up question; EXP |
| D3 | "What would you like to have learned by the end of your first month?" | JD | [generic] | A plan, not a past. Name the kinds of things you would want to know: the product, the common contact types, how the team handles escalations. Keep it short and honest about what you do not know yet. The guidance makes no claim about your past | A friendly question that still scores the F5 ramp; JD |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I've never worked for a software company" | Pause and restate the question. Hold on the quotes: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day, Freshdesk every day. Hold through two follow-ups. Concede the one specific thing that is true, "I've never worked for a software company", and do not fold on the rest | F5 invites this challenge; JD with Pressure delivery, scoring composure |
| E2 | "Sixty contacts a day sounds like volume. What shows you handled them well?" | EXP | [grounded] "answering around 60 calls and emails a day" | Hold the sentence at its own scope and do not add a result it does not state. Answer slot: if there is something you can point to showing how well those were handled, say what it is; if not, say so plainly and describe how you try to. Concede only what is true | A Pressure version of the figure probe; EXP |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "When a ticket needs someone in another team to fix it, how do you hand it over?" | CASE | [generic] | Principles: what the other person needs to act without asking the customer again, a clear summary, what the customer is told, and following up. Say them as how you would work, not as a history. The guidance makes no claim about your past | Software support involves hand-offs, a seam your material does not show (F5, F4); CASE |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Principles only: use we for context and name your own part only where it is true; credit the other side by name. The guidance makes no claim about your past | Standard peer probe about partnership; VAL in delivery, though no company values were read |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" (F1) | B4, C1, D1, E1 |
| "experience with Zendesk or a similar ticketing tool" (F2) | C2 |
| "clear written communication" (F3) | A1, A5 |
| "confidence handling escalations" (F4) | A2, B3, F1 |
| Working at a software company, not stated in the ad (F5) | A3, B1, B2, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like for someone new on the team?" | It shows you plan to learn the product, which is the F5 gap, and gives you the team's real expectations |
| R2 | "What do customers write in about most, and what takes new starters longest to learn?" | It turns the software gap into a learning question and shows you think about the work |
| R3 | "How does the team handle escalations: who takes them, and when?" | It shows interest in the F4 requirement without claiming experience of it |
| R4 | "Which tool does the team use for tickets?" | It follows up on the Zendesk line in the ad and your Freshdesk daily use |
| R5 | "After this chat, are there other steps, such as a call or video with the team, before an offer?" | A normal question about process; the answer shows how the rest of the hiring runs and who else you would speak to |
| R6 | "How would you know, a few months in, that someone is doing well in this role?" | It shows you want a clear standard, and gives you the thing to aim at |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Experience of working at a software company | Negative you stated, F5 | The plain acknowledgment: "I've never worked for a software company." Then a plan for learning, never a past |
| Onboarded or ran training for the team, or owned a training programme | Inflated form of F-row evidence "I trained four new starters on our refunds process last year" | The quote at its own scope: four new starters, your refunds process, last year. The limit is the pack's observation: your message says the four and the refunds process, not onboarding in general |
| Hit targets, or handled 60 contacts a day to a high standard | Inflated form of "answering around 60 calls and emails a day" | The quote at its own scope, keeping "around". The pack's observation: your message gives a volume, not a result. E2's slot stays inside that |
| Expert in ticketing systems generally, or equivalent to Zendesk | Inflated form of "I use Freshdesk every day" | The quote at its own scope: you use Freshdesk every day. C2's slot asks only about Zendesk use and what you use Freshdesk for |

## Sources

Provided documents: your message, including the invite text and what you said about your experience. No dossier or prior pack was supplied.

Searches sent (all refused, nothing returned): `Lumenvale Software values`; `Lumenvale Software interview process customer support`; `Lumenvale Software strategy news`. No pages were fetched.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | All calls refused. Would have named the company's published values for VAL questions |
| 2. `Lumenvale Software interview process customer support` | unavailable | All calls refused. Would have shown whether other rounds exist; the loop here rests on your message alone |
| 3. `Lumenvale Software strategy` / recent news | unavailable | All calls refused. Would have fed CO questions; none are in this pack |
| 4. interviewer name and company | n/a | The invite does not name the support team lead, so there was no query to form; there is no interviewer read |
| 5. representative `Customer Support Specialist` JD | skipped | The four requirements you gave fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full text of the job ad → F1 to F4's requirements become exact quoted ad lines, and any mid-list requirement gets a question or a stated reason it does not
- Your CV → F1 to F5's evidence cells draw on your CV as well as your message, and more rows can move above low or medium
- Your answers to the answer slots on F3 and F4 → those rows move from discovery toward grounded story-mapping
- The interviewer's name → an interviewer read and a reverse question tied to their own path
- Permission for company research, and a deeper pass of up to 6 more searches and 2 more fetches, several more minutes → company values, loop structure and strategy, so CO and VAL questions replace generic ones
- Any recruiter guidance on focus areas or pre-declared tasks → coverage beyond the round-type assumption
- A tuesday-dossier.md → verified evidence, a sourced objection list in place of the inferred one, and a limit per weak area
