# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

- Role: Remote Administrative Assistant
- Company: Brennock Facilities Ltd
- Candidate: Aoife
- Interviewer: "our office manager", name not given. Round: "a 30-minute video call", one session, as the invite states it
- Built as a hiring-manager-style round, because the interviewer is named only by that title

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Each question carries one of five type tags:

| Tag | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your background claims survive follow-up questions |
| JD | Whether you can do the listed job, including its gaps |
| CO | How well you know the company and its strategy |
| CASE | How you reason through a live problem from the role |

No VAL or CO questions appear, because no published values or strategy source was available (see Sources).

The guidance is scaffolding, not a script. Where it says Answer slot, that is an instruction for the interview itself: it asks for no reply here, and both of its branches are fine to say aloud. Rehearse only what you actually did, in your own words.

## Fit snapshot

Requirements are quoted from your description of the ad. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — ad, as you described it | "ran the appointment book for four physios" — your message | medium | [grounded] | presentation | A quote that already reaches the requirement in other terms, with nothing inspected behind it, so expect a probe. Keep the quote's own terms: "I ran the appointment book for four physios." Let the interviewer make the link to calendars; do not translate it for them |
| F2 | "booking travel" — ad, as you described it | none given | none | [grounded] | discovery | Your material is silent on travel. Answer slot: the ad's travel line makes a probe on travel you have booked likely. If you have booked travel for anyone, say whose and what you arranged, in your own words; if you have not, or it was never yours to book, say so plainly and say how you would go about it |
| F3 | "preparing documents in Word and Excel" — ad, as you described it (Word) | "I'm good with Word" — your message | low | [inferred] | discovery | A self-rating with no document behind it, so it can be asked about and not asserted. Answer slot: the ad says preparing documents, so expect a probe on what you have prepared. If you have prepared documents in Word, say which kinds, in your own words; if your use has been light, say so plainly and say what you would show or learn first |
| F4 | "preparing documents in Word and Excel" — ad, as you described it (Excel) | "okay with Excel" — your message | low | [inferred] | discovery | Your own word is "okay", and the words stay there. Answer slot: if you have done particular tasks in Excel, name one or two, in your own words; if your use has been light, say so plainly and say what you would learn first |
| F5 | "processing supplier invoices" — ad, as you described it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says the chasing, not the processing, and does not say whose invoices they were, so the words stay at "I chased unpaid invoices." Answer slot, inside that scope: which part of chasing the unpaid invoices was yours, and which part someone else's. If little of it was yours, say so plainly and describe what you did |
| F6 | "Remote Administrative Assistant" — invite | none given | none | [grounded] | hard_gate | Your material does not establish whether you can work remotely from a suitable setup. Surfaced, not bridged: no wording closes it, and the pack adds none |

## Persona table

The loop is the one your invite states: a single 30-minute video call with the office manager. The weights rest on that and on the relationship prior for a hiring-manager-style interviewer. No interviewer signal adjusts them.

| Persona | How it shows up | Weight and reasoning | Counter-strategy (a rehearsal method) |
|---|---|---|---|
| Case/Strategist | Live problems built from the ad's four duties | High, 5 questions. The prior for a hiring-manager-style round is Case plus Skeptic, and the four duties are concrete enough to set as problems | Clarify first, then structure, think aloud, challenge one premise politely. Rehearse A1 to A5 aloud |
| Skeptic | Quiet probing of travel, invoices and Excel | High, 5 questions. The other half of the prior, and F2 to F5 are the rows where the material is thin or adjacent | Rehearse B2 until it is boring: hold the quote at its scope, concede the limit plainly, give a plan |
| Conversational | A friendly opening, "walk me through" | Medium, 3 questions. A short call still opens somewhere, and casual-register questions are still scored | A 90-second arc made only of your own quoted sentences (C1) |
| Data-Driven Prober | Asks which part was actually you, and how a figure was counted | Medium, 3 questions. "four physios" is the one figure in your material | Know what you can and cannot say about each figure, and say plainly when you do not know |
| Pressure | Time-boxed challenges to your fit | Low, 2 questions. Nothing in the invite signals a stress style, but one challenge is plausible | Pause, restate, hold the position through two follow-ups, then concede one specific thing |

Not banked: Values/Behavioral, because no values round is documented in the invite and no published values were available. Peer Evaluator, because the invite names the interviewer as the office manager and gives no peer signal.

## Question banks

### Bank A — Case/Strategist (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two managers each ask you to book the same 10am Thursday slot with a client, and you can't reach either of them for an hour. What do you do?" | CASE | [generic] | Say aloud what you would ask first, what you do with the slot in the meantime, who you tell and in what order, and what you record so it does not repeat. The question needs no claim about your past, so the guidance makes none | F1's requirement, asked as a decision rather than a history; generic because it is a pattern for the problem, not a fact about this employer |
| A2 | "A manager asks you to book a return trip to Cork next week: arriving before 9am Tuesday, back the same evening, on a modest budget. What would you need to ask first, and how would you go about it?" | CASE | [generic] | Structure it as a plan, said as "I would": what you ask first (who travels, how flexible the times are, the budget limit, whether changes are allowed, who approves), two options compared with one recommended, confirmation before anything is bought, and the confirmed times put in the calendar. It makes no claim about your past | F2 has no evidence behind it, so the question is asked as a live problem. CASE with JD content |
| A3 | "An invoice arrives from a supplier and the amount differs from what your manager told you to expect. What do you do before anything is paid?" | CASE | [generic] | Structure it as a plan: hold it, check it against what you were told to expect, ask the person who placed the order, record the difference, and find out who approves payment. Say what you would do, not what you have done | F5's requirement, asked as a decision. It rehearses the control side of invoices without a claim about your past |
| A4 | "You're asked to build a one-page weekly schedule in Excel for three people, covering their meetings, leave days and deadlines. What do you need to know first, and how would you lay it out?" | CASE | [generic] | Say what you would ask first (who it is for, what must be visible, how often it changes), the simple layout you would use, and where you would check your work. Say only what you would actually do, and name any part you would look up | F4's requirement as a live problem. It lets you show reasoning without claiming more than "okay" |
| A5 | "Your manager hands you rough notes from a meeting and asks for a clean one-page summary by end of day. How do you go about it?" | CASE | [generic] | Say what you would ask first (who reads it, what it is for, how long), how you would order it, what you check before sending (names, dates, figures against the notes), and who sees it first | F3's requirement as a live problem. It makes no claim about your past |

### Bank B — Skeptic (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [inferred] "okay with Excel" "chased unpaid invoices" | Choose, from the ad's four duties, the one your own material carries least, and name it plainly. Your material has "okay with Excel" against the ad's document work and "chased unpaid invoices" against its supplier invoices, and nothing on travel. Concede that one thing specifically, then give a ramp as a plan: what you would learn first and from whom, said as "I would". Answer slot: say which duty is least yours, in your own words | The standard Skeptic opener, and the pack's comparison of the ad against F2 to F5 is the derivation, so it is inferred. JD because it scores the stated duties |
| B2 | "At the clinic you chased unpaid invoices. How does that compare with processing supplier invoices?" | JD | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack. Hold the sentence at its own scope: "I chased unpaid invoices." Compare only as far as it lets you. Answer slot: which part of chasing the unpaid invoices was yours, and which part someone else's; if little was yours, say so plainly and describe what you did. Then a plan: what you would ask on day one about how invoices are checked and approved here. Hold through two follow-ups by returning to the chasing, never by adding to it | F5 is where the ad's invoice line presses hardest, so this objection arrives in some form. JD because it scores a stated duty, with EXP delivery |
| B3 | "Tell me about a time you organised something that depended on other people's fixed times and several bookings." | JD | [generic] "ran the appointment book for four physios" | Selection scaffold: pick an occasion with named dates, at least two people's constraints, and a point where the plan had to change. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "ran the appointment book for four physios", or how you would handle it | The ad's travel line raises it, and F2 has no evidence, so this is a scaffold and not a story map. JD because it scores a listed duty |
| B4 | "How would you rate yourself in Excel, and what could you do in it on your first day?" | JD | [inferred] "okay with Excel" | Hold at the sentence's own scope, "okay with Excel", with no upgrade. Answer slot: name one or two things you have done in Excel, in your own words; if your use has been light, say so plainly and say what you would learn first, as a plan | F4 rests on a self-rating, so the probe is likely. Inferred because low-confidence evidence can only be coached as a clarify note |
| B5 | "Why this role, and why now?" | EXP | [generic] | Give your actual reasons in your own words, in two or three sentences. A reason you would not repeat under a second question is the wrong one to give. If working remotely is part of why, say so only if it is true | Motivation consistency is what the Skeptic scores. EXP because it tests whether your story holds together |

### Bank C — Conversational (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey so far." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" "ran the appointment book for four physios and chased unpaid invoices" | A 90-second arc whose beats are your own sentences: the two years as a receptionist at a physiotherapy clinic, the appointment book for four physios, the unpaid invoices you chased, each at that scope and in your own words. Close with one sentence on why this role (see B5). Add no beat you could not stand behind | The opening question every call has, asked casually and still scored. F1 and F5 are the rows it draws on |
| C2 | "What did running the appointment book for four physios involve, day to day?" | EXP | [grounded] "ran the appointment book for four physios" | Tell the day in your own words, at the sentence's scope. Answer slot: which parts of keeping the book were yours to decide and which were set by the physios or the clinic; if none were yours to decide, say so plainly and describe how you kept the book | The ad's calendar line makes this likely. F1 is the evidence, and EXP because it tests what was actually yours |
| C3 | "This role is remote. What does your working setup at home look like?" | JD | [generic] | Describe your actual setup in your own words and nothing more. If something you would need is not in place, say so plainly and say how you would sort it out. The question needs no claim about your past, so the guidance makes none | F6 is a term of the job, and your material does not establish it, so it is asked plainly |

### Bank D — Data-Driven Prober (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You ran the appointment book for four physios. Which part of that was actually you?" | EXP | [grounded] "ran the appointment book for four physios" | Hold the sentence, then use the four slots a figure raises, each in your own words. How "four" was counted: four at one time, or over a period. What would change if it were a different number. The assumption about it you would defend least. Which part of running the book was yours and which belonged to others. If you do not know how the figure was counted, say that plainly | "four physios" is the one figure in your material, and probers go to figures first. F1 is the row. EXP because it tests attribution |
| D2 | "You say you're good with Word. What would you point to as evidence of that?" | JD | [inferred] "I'm good with Word" | Answer slot: name a kind of document you have produced in Word, in your own words, and say if you have a sample you can show; if your use has been light, say so plainly and say what you would learn first. Do not upgrade the sentence | F3 is a self-rating with no artifact behind it, so the probe asks for one. Inferred because the evidence is low-confidence |
| D3 | "Walk me through what chasing an unpaid invoice meant at the clinic." | EXP | [grounded] "chased unpaid invoices" | Tell it in your own words at the sentence's scope. Answer slot: which part was yours and which part someone else's; if the whole of it was yours, say so; if little was, say so plainly and say what you did | F5's detail, probed from the other side than B2. EXP because it tests what was actually yours |

### Bank E — Pressure (weight low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you rather than someone with more admin experience?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic" "ran the appointment book for four physios" | Pause and restate the question. Hold on what those two sentences carry, at their own scope. If pressed twice, concede one specific thing you can say truthfully: name the duty you would be newest to, in your own words (B1 is the drill for that), and the first thing you would do about it | A time-boxed challenge to fit. JD because it scores fit to the listed job; the hold-then-concede structure is the rehearsal |
| E2 | "The ad asks for documents in Excel as well as Word, and you've said you're okay with it. Is that enough?" | JD | [inferred] "okay with Excel" | Hold at "okay", with no upgrade and no "advanced". Through two follow-ups, return to what you can name having done in Excel (the B4 slot) and concede specifically what you would learn first, as a plan | F4's thin evidence under pressure. Inferred for the same reason as B4 |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 "managing calendars" | A1, C2, D1 |
| F2 "booking travel" | A2, B3 |
| F3 "preparing documents in Word and Excel" (Word) | A5, D2 |
| F4 "preparing documents in Word and Excel" (Excel) | A4, B4, E2 |
| F5 "processing supplier invoices" | A3, B2, D3 |
| F6 "Remote Administrative Assistant" | C3 |

B1, B5, C1 and E1 cover the whole ad rather than one requirement.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which of the four duties would take most of my week?" | It shows you are thinking about the job, not the title, and the answer tells you where your preparation matters most |
| R2 | "What would a good first month look like?" | It turns the call into a conversation about doing the work together |
| R3 | "Who would I be supporting day to day, and how does the team stay in touch when people work remotely?" | It shows you are thinking about how remote work actually runs |
| R4 | "How are supplier invoices checked and approved here before they are paid?" | It shows respect for the control side of invoices, and it ties to F5 as a question to learn from, not a claim |
| R5 | "What do remote staff work with, and how is that equipment supplied?" | It is a practical remote-readiness question, and you should hear the answer stated plainly before you agree to anything |
| R6 | "Could you tell me which company would employ me, and send the contract terms to read before any start date?" | It is a reasonable question from any candidate, and the answer gives you something concrete to verify |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "I chased unpaid invoices." The limit is the pack's observation, not words for you: the material says the chasing, not the processing |
| Managed calendars across the business | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." |
| Advanced or strong Excel | Inflated form of F4 | F4's quote at its own scope: "okay with Excel" |
| Expert with Word | Inflated form of F3 | F3's quote at its own scope: "I'm good with Word" |

## Sources

Provided documents: the invite as you pasted it, your description of the ad, and your description of your background. No dossier was present.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

Searches sent:

| Query | What came back |
|---|---|
| `"Brennock Facilities Ltd" values` | refused |
| `"Brennock Facilities Ltd" Ireland company news` | refused |

Nothing about the company beyond what the invite says is in this pack.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | The search was refused. It would have fed VAL question themes; no values-style round is documented, so no cheat sheet would have followed |
| 2. `Brennock Facilities Ltd interview process remote administrative assistant` | skipped | Your invite fixes the loop (one 30-minute video call with the office manager), which fixes the persona weights and bank structure |
| 3. `Brennock Facilities Ltd strategy` / recent news | unavailable | The search was refused. It would have fed a CO question and the Grounding brief, both absent here |
| 4. `{interviewer name} Brennock Facilities Ltd` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Remote Administrative Assistant` JD | skipped | Your description of the ad fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's full text → F1 to F5 requirement cells become the ad's own lines, and the JD-tagged questions are re-aimed at them
- Your CV → evidence cells move from your message to your CV lines, and F1 and F5 can be checked against them
- A Word document or Excel spreadsheet you built and could show → F3 and F4 can rise from low toward medium, and D2 and B4 get a story to map
- What the invoices you chased were for, and who owed them → F5's bridge and B2's slot can be sharpened
- Any travel you have booked, for anyone, said in your own words → F2 moves from none given to a story-mapped answer
- Your answer on your home working setup → F6 can be settled, and C3 tuned
- The office manager's name → an interviewer read, tuned persona weights and a reverse question tied to their path
- What the 30 minutes will cover, if the employer says, for example a task or test → a build section for any pre-declared deliverable
- Search access, or a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → values and strategy rows, a CO bank, and a Grounding brief
- A tuesday-dossier.md, if you have one → verified evidence and a named top objection would replace this pack's inferred ones; the pack stands without it
