# Operations Coordinator, Quillmoor Diagnostics: recruiter screen prep pack

**Interviewer:** Hannah Lowther, Talent Partner (recruiter screen)
**Format:** Thursday, 2pm, a 30-minute phone call. She rings the mobile number on your application.
**Built on:** the advert you pasted, Hannah's LinkedIn message and your own notes. No web research ran (see Sources), so nothing here is a claim about Quillmoor beyond its advert.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words.

| Tag | What it scores | In this pack |
|---|---|---|
| VAL | Past behaviour against the company's published values | No questions: no values round is documented and no values page was read |
| EXP | Whether your own account of your work holds up | A4, A5, B5, C1, C2, C3 |
| JD | The advert's stated duties and requirements, including its terms | A1, A2, A3, B1, B2, B3, B4, E1, E2 |
| CO | Knowledge of the company and its strategy | No questions: the research that would ground them was declined |
| CASE | A live problem from the role | D1, D2, D3 |

Two kinds of instruction recur in the guidance. An **answer slot** names what the interviewer may probe and gives two honest branches: say how, in your own words, or say plainly that it was not a step you took or not yours to take. A **logistics slot** is the same idea for pay, notice, location and your reason for moving: the answer is your own, and the pack supplies no figure or reason you did not give.

**Highest-ROI prep: B1.** It goes at the weakest point of the fit snapshot and is the one question most likely to arrive in some form. Rehearse it until it is boring.

## Fit snapshot

Requirements are quoted from the advert or from Hannah's message. Evidence is your own words, quoted. Nothing in the evidence column is paraphrased.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says deliveries for three depots, not production schedules, and it names none of the three functions. Words stay at the quote's scope: "I schedule deliveries for our three depots." Answer slot: the advert names planning, the warehouse and QA, so expect a probe on whether any of your scheduling involved production or those teams. If it did, say which and what your part was; if it did not, or none of it was yours, say so plainly and stay with the deliveries |
| F2 | "track supplier deliveries and chase late orders" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | presentation | The quote already reaches the chasing half in other terms. Words: "I chase suppliers when orders slip." The pack's observation is that your material says chasing, not tracking, and nothing is added to cover the tracking half. C2 carries the probe on what follows a chase |
| F3 | "keep stock records accurate" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe on the figure. Lead in the quote's own terms: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. C1 rehearses the figure |
| F4 | "confident with Excel" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | Inferred because the quote says a spreadsheet and does not say which tool it was built in. Answer slot: the advert asks for Excel, so expect a probe on which tool the spreadsheet was in and what you did in it. If it was Excel, say what you did there, naming only what you used; if it was another tool, or you cannot say, say so plainly and stay with the spreadsheet you rebuilt |
| F5 | "ERP experience (SAP or similar) a plus" — the advert | "Never used SAP — we run our own in-house stock system." — your message | low | [grounded] | transferability | Your message states you have not used SAP, and the pack gives that back: "I've never used SAP. We run our own in-house stock system." The pack's observation is that your material does not say the in-house system is an ERP, so it is not offered as one. C3 carries the slot on what you do in it. The advert's own wording makes this a plus |
| F6 | "2+ years in operations or logistics coordination" — the advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap. A length-of-experience requirement is graded on evidence like any other row, and your own line reaches it in the advert's terms. Lead with the four years and the role title as you stated them |
| F7 | "report weekly on on-time dispatch" — the advert | none given | none | [grounded] | discovery | Nothing in your material shows regular reporting on deliveries or dispatch. Answer slot: the advert names a weekly on-time dispatch report, so expect a probe on reporting you have done. If you did regular reporting on deliveries, say what it covered and who read it; if you did not, say so plainly and say what you would track first. B4 and D3 carry it |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" — the advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | The pattern is met on your own statement, with a limit you set. Keep both halves together as you said them, two days is fine and you wouldn't want more than three, and do not soften the limit into flexibility |
| F9 | "£38,000–£44,000" — the advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your figure is your own statement of what you want. Give it as you said it, a hope and not a floor, and add no salary history or claim of flexibility |
| F10 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | No gap. Say the beats the sentence states and stop: the office is closing next year, the only offer is relocating to Reading, you don't want that |

## Persona table

The session is one 30-minute call with Hannah. Her message names its content: "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move", with the team and next steps coming after. That message is the loop source. Weights below rest on it and on the recruiter-screen prior, not on any documented Quillmoor process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport (A) | Friendly, unhurried questions on pay, notice, hybrid and your move, plus an opening "walk me through your background" | Highest. Hannah's own list is logistics and motive, asked as a conversation, and each item is scored even in a casual register | Answer each logistics item in one or two sentences from your own words, then stop. Do not treat it as unscored |
| Skeptic (B) | Quiet probing of the gaps against the advert: production scheduling, ERP, Excel, reporting, why this industry | Second. The advert lists requirements a screen checks, and F1, F4, F5 and F7 are where your material is thinnest | Rehearse B1 until it is boring. State the limit of your material plainly, then a plan for what you would learn, said as a plan |
| Data-Driven Prober (C) | Digs into the one figure you gave and the systems you used | Lower. You gave one headline figure in F3, and a recruiter may probe it lightly | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| Case / Strategist (D) | A short live problem from the role: a late delivery, a stock mismatch, a report | Lower. The advert's duties give the cases, but a screen is less likely to run them than a later round | Clarify first, state the objective, then approach and record. Think aloud and ask one question |
| Pressure (E) | A time-boxed "why you" or a push on your office-days limit | Lowest. Nothing in Hannah's message suggests a stress register | Pause, restate, hold the position the quotes carry through two follow-ups |

## Question banks

### A. Conversational (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot, filled by your own sentence: "I'm hoping for £42,000." Say it plainly, then stop and let her respond. Do not add a minimum, a history or a claim of flexibility. If you would rather hear her band first, ask her to confirm it, then give your figure | F9 sets the figure. JD because pay is a term of the listed job and Hannah named it |
| A2 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period in your own words. Check it before Thursday so you can state it without hesitating. If you are not sure, say so plainly and say you will confirm it | Hannah named it as one of her four topics. No fit-snapshot row carries it, because your material states none. JD because it is a hiring term of the listed job |
| A3 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot, filled by that sentence: where you live, two days is fine, and you wouldn't want more than three. Say both halves together. Add no commute detail or transport arrangement, as your material has none | F8 meets the advert's pattern and carries your limit. JD because the advert states the pattern and Hannah named it |
| A4 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Story-mapped on F10, using only the beats the sentence states: the office is closing next year, the only offer is relocating to Reading, and you don't want that. Say them in that order, in your own words, then stop. Add no redundancy, no other options considered and no view of your employer, as none is in your material | F10 is the reason in your own words. EXP because it tests your own account, and Hannah named it, so it arrives |
| A5 | "Walk me through your background and why this role." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | A 90-second arc told in your own words, with only the beats these sentences state: four years as a logistics coordinator at a building-supplies wholesaler, scheduling deliveries for three depots, chasing suppliers when orders slip, and the stock-count spreadsheet you rebuilt. If you include the third, the C1 slots apply to it. Answer slot: why this role, in your own words. If what draws you is the job's scope or the location rather than the industry, say so plainly | F6 supplies the experience beat and F1 to F3 the content. EXP because a background question tests how you tell your own history |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role coordinates production schedules between planning, the warehouse and QA. What have you coordinated that comes closest?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal in this pack. The hold is only what the quote carries: "I schedule deliveries for our three depots." Answer slot: if any of that scheduling involved production or the three functions, say which and what your part was, in your own words; if it did not, or none of it was yours, say so plainly and describe the deliveries and the supplier chasing as you do them. Follow-up one asks whether that was production scheduling or delivery scheduling: return to the deliveries and the same slot. Follow-up two asks which teams you worked with: say which, or say plainly none of these, and stay with what the quote carries. Follow-up three asks what you would do first in the role: say it as a plan for learning the production side, never as a past, and do not name a method you have not used. Hold by returning to the quote, never by adding to it | F1 is where the advert's central duty presses hardest on your material, so this objection arrives in some form. JD because it scores a stated requirement |
| B2 | "The advert says SAP or similar is a plus. What's your ERP experience?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Open with the acknowledgment from your own words: "I've never used SAP. We run our own in-house stock system." Then say, as a plan and not a past, how you would learn the team's system. Do not call the in-house system an ERP. Answer slot is C3's, on what you do in it | F5 is a stated gap plus an adjacent system. JD because the advert names it, as a plus |
| B3 | "How confident are you with Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say what the quote says: "I rebuilt our stock-count spreadsheet." Answer slot: expect a probe on which tool it was in and what you did in it. If it was Excel, say what you did there, naming only what you used; if it was another tool, or you cannot say which, say so plainly and stay with the spreadsheet you rebuilt | F4 is thin because the quote says spreadsheet and not Excel. JD because the advert asks for Excel |
| B4 | "Tell me about any regular reporting you've done on deliveries or dispatch." | JD | [grounded] | No quote carries this, so it is an open prompt. Answer slot: the advert names a weekly on-time dispatch report. If you did regular reporting on deliveries, say what it covered, how often and who read it, in your own words; if you did not, say so plainly, then say what you would track first if asked for that report, as a plan | F7 has no evidence, so the honest answer is rehearsed before the probe. JD because it scores a stated duty |
| B5 | "You've come from building supplies. Why a diagnostics manufacturer?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." | The quote carries the background and nothing about the industry change. Answer slot: why this move, in your own words. If the draw is the job's scope or its location rather than the industry, say so plainly. Say only what you know about Quillmoor from the advert itself, which describes a diagnostic-test manufacturer of about 400 staff, and claim no interest in diagnostics that is not yours | F6 is the background the question starts from. EXP because it tests your own reason, and the rationale for the question is the F1 gap on production |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Defend-the-number slots, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. "I don't know how it was counted" is an honest branch. Keep the figure as stated, about a third over a year, and do not turn it into a percentage or a cause | F3 holds the figure. EXP because probers test the number first |
| C2 | "When a supplier's order slips, what do you actually do?" | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Story-mapped on F2: orders slip and you chase suppliers, in your own words. Answer slot: the advert asks you to track deliveries and chase late orders, so expect "what happens next". If you do anything after the chase, say what it was; if you do not, or it is not yours to do, say so plainly and stay with the chasing. Name one real instance if one comes to mind; if none does, say so | F2 reaches the chasing half. EXP because it tests what you actually do |
| C3 | "What does your in-house stock system do, and what do you use it for?" | EXP | [grounded] "Never used SAP — we run our own in-house stock system." | Say what the quote says: "we run our own in-house stock system". Answer slot: what you use it for day to day, in your own words. If you use it little, or someone else owns it, say so plainly | F5 is the adjacent evidence for the ERP line. EXP because it tests your own account of the system |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A key supplier says a delivery will land three days late. Planning has a run booked, QA is waiting on it and the warehouse has booked the dock. What do you do?" | CASE | [generic] | Structure it aloud: ask what exactly has slipped, how late and what depends on it; state the objective; say who you would tell among planning, the warehouse and QA; set out the options; say what you would record. The question needs no claim about your past, so the guidance makes none | The advert's coordination and late-order duties (F1, F2) as a live decision. CASE because it scores structure |
| D2 | "The stock record says 120 of an item and the shelf says 112. What do you do?" | CASE | [generic] | Structure it aloud: confirm the count, look at the recent movements, find who last touched the record, change the record only once you know why, record what you changed, and watch for it recurring. No claim about your past is made | The advert's stock-accuracy duty (F3) as a live problem. CASE because it scores reasoning |
| D3 | "If I asked you to build a weekly on-time dispatch report from scratch, what would you want to know first?" | CASE | [generic] | Structure it aloud: what counts as on time, where the data comes from, who reads it and how often, and how you would cut it. Ask one clarifying question before answering. No claim about your past is made | F7 has no evidence, so a structure is rehearsed in its place. CASE because it scores clarifying before answering |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we pick you for this job?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Pause and restate the question. Hold the claim the quotes carry: four years as a logistics coordinator, scheduling deliveries for three depots and chasing suppliers when orders slip. Hold through two follow-ups by returning to those sentences, never adding to them. Concede only where the quotes end: if a follow-up goes to production, planning or QA, use B1's slot | F6 and F1 are the claim held. JD because it scores fit against the advert |
| E2 | "What if the team needed you on site more than two days?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Hold the sentence as said: two days is fine and you wouldn't want more than three. Do not fold into "I'm flexible" and do not harden it into "I can't". Answer slot: if three days would work for you, say so in your own words; if not, say so plainly | F8 carries the limit. JD because it tests the advert's hybrid term |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "Coordinate production schedules between planning, the warehouse and QA" | B1, D1, E1 |
| "track supplier deliveries and chase late orders" | C2, D1 |
| "keep stock records accurate" | C1, C3, D2 |
| "report weekly on on-time dispatch" | B4, D3 |
| "2+ years in operations or logistics coordination" | A5, E1 |
| "confident with Excel" | B3 |
| "ERP experience (SAP or similar) a plus" | B2, C3 |
| "£38,000–£44,000" | A1 |
| "Hybrid: two days a week at our Avonmouth site in Bristol" | A3, E2 |
| "your notice period" — Hannah's message | A2 |
| "what's prompting a move" — Hannah's message | A4, A5, B5 |

## Reverse questions

| # | Question to ask Hannah | Why it lands |
|---|---|---|
| R1 | "Which of planning, the warehouse and QA would this role spend most of its week with?" | It uses the advert's own three-way coordination line and shows you read it closely |
| R2 | "Who reads the weekly on-time dispatch report, and what do they do with it?" | It ties to the advert's reporting line and shows you think about the report's audience |
| R3 | "Which system does the team work in day to day?" | It puts the advert's SAP line in the open and gives you what you would need to learn |
| R4 | "How do the two days at Avonmouth usually fall, fixed days or agreed with the team?" | F8 is a term you set, and the answer tells you how it would sit in practice |
| R5 | "Is the £38,000–£44,000 range fixed for the role, or does it move with experience?" | It follows from the figure you gave and shows you read the band |
| R6 | "What would tell you, a month in, that this hire was the right one?" | It moves a recruiter from screening to describing the job |

## Prohibited claims

What this pack will not coach, and why. The first column is the claim, the second its basis, the third the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says deliveries for three depots, not production schedules or those functions. B1's slot stays inside the deliveries |
| Tracked supplier deliveries as a process | Inflated form of F2 | F2's quote at its own scope: "I chase suppliers when orders slip." C2's slot asks only what follows the chase |
| Cut stock discrepancies by exactly a third, or by a stated percentage, because of the rebuild | Inflated form of F3 | F3's quote at its own scope: discrepancies fell by about a third over a year. C1's slots ask only how it was counted |
| Built the stock-count spreadsheet in Excel, or has advanced Excel skills | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says spreadsheet, not which tool. B3's slot asks which tool |
| Has used SAP | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I've never used SAP." No slot |
| The in-house stock system is an ERP, or equivalent to SAP | Inflated form of F5 | F5's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation: your material does not call it an ERP. C3's slot asks only what you use it for |
| £42,000 is a minimum or non-negotiable | Inflated form of F9 | F9's quote at its own scope: "I'm hoping for £42,000." |
| Flexible on office days beyond three | Contradicted by F8's quote | The quote alone: "I wouldn't want more than three." |
| Have been made redundant | Inflated form of F10 | F10's quote at its own scope: the office is closing next year and the only offer is relocating to Reading |

## Sources

**Provided documents:** the advert for Operations Coordinator at Quillmoor Diagnostics, pasted by you; Hannah Lowther's LinkedIn message, pasted by you; your own notes about your background and what you would tell her. No `tuesday-dossier.md` was present.

**Searches sent, by query:**

- "Quillmoor Diagnostics values" — refused
- "Quillmoor Diagnostics interview process operations coordinator" — refused
- "Quillmoor Diagnostics Avonmouth news" — refused
- "Hannah Lowther Quillmoor Diagnostics" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The one search was refused. It would have moved the VAL questions and the values cheat sheet, though no values round is documented. Neither is in this pack |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | The one search was refused. It would have moved the loop structure for later rounds. This session's weights rest on Hannah's own message instead |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | The one search was refused. It would have moved the CO questions, so none are in this pack |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | The one search was refused. It would have moved an interviewer read and one reverse question tied to her own path. Both are absent |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web search access, or pasted pages from Quillmoor's own site (values, careers, news) → CO questions grounded in current strategy, and an interviewer read for the persona table
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, run only if search access is granted → strategy brief, loop reports and recent organisation context
- Hannah's LinkedIn profile text, pasted → a reverse question tied to her own path and persona weights read from her public footprint
- Your CV → F1 to F7 and F10 evidence cells quoting CV lines in place of message lines, and any row where it says more than your notes
- The stock-count spreadsheet itself, or a before-and-after count of discrepancies → F3 could move from medium to high, because a count report is the inspectable artifact this field keeps
- Your actual notice period → A2 filled in your own words, quoted
- Your answers to the slots on F1, F4, F5 and F7 (which tool the spreadsheet was in, what you use the in-house system for, whether you have reported on deliveries) → those rows regenerated from your own words
- A `tuesday-dossier.md` from an earlier job-underwriter run, if you have one → verified evidence and a named top objection for the banks, never required for a pack like this one
