# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: "our office manager", name not given. Relationship: not stated, so this pack assumes a hiring-manager-style round with the person you would work for day to day. Format, in the invite's words: "a 30-minute video call".

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

An answer slot is an instruction for the interview, not a question for you now. It names what an interviewer is likely to probe and gives you two honest branches: say what you did, or say plainly that it was not yours or did not exist.

| Type | What it tests |
|---|---|
| VAL | Whether past behaviour shows the company's published values. No published values were available, so this pack has no VAL questions |
| EXP | Whether what you say about your own work survives follow-up questions |
| JD | Whether you can do the listed job, including the parts you have not done yet |
| CO | How much you know about the company |
| CASE | How you think through a live problem from the role |

Provenance labels: `[grounded]` rests on something you or the invite said, `[inferred]` is this pack's derivation, `[generic]` is a pattern with no claim about you or this employer.

## Fit snapshot

The ad's duties are quoted from your description of it, not from the ad itself.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" — your message | medium | [grounded] | presentation | Say it in the quote's own terms: "I ran the appointment book for four physios." Your material says appointment book, not calendars, so the words stay with the book. Expect a probe, since a line like this has nothing inspected behind it |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show travel booking either way. Answer slot: the ad lists it, so a probe is likely. If you have booked travel for anyone, say what and for whom, in your own words; if you have not, or it was not part of your work, say so plainly and return to the appointment book you ran |
| F3 | "preparing documents in Word and Excel" — the ad, as you described it | "I'm good with Word, okay with Excel" — your message | low | [inferred] | discovery | Derived from your own rating alone. Keep it at its scope: "I'm good with Word, okay with Excel." The material says nothing about what you have prepared in either. Answer slot: the ad lists both, so expect a probe on what you have made. If you have prepared documents or spreadsheets, say what kind and for whom, in your own words; if not much, say so plainly and say what you would practise first |
| F4 | "processing supplier invoices" — the ad, as you described it | "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" — your message | medium | [grounded] | transferability | The words stay with the quote: "I chased unpaid invoices." Your material does not show whether those invoices were owed to the clinic or by it, or any processing of them. Answer slot: the ad's processing line makes a probe on your part in invoices likely. If any processing was yours, say which part, in your own words; if your part was chasing only, or it was not yours, say so plainly and stay with the chasing |
| F5 | "Remote Administrative Assistant" — the invite | none given | none | [grounded] | discovery | Your material does not show remote or independent working. Answer slot: the title makes a probe on working remotely likely. If you have worked remotely or without a colleague beside you, say when, in your own words; if you have not, say so plainly and say how you would organise a day at home |

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the thin rows: travel, Excel, supplier invoices | High. The hiring-manager prior is Case plus Skeptic (persona model), and F2, F3 and F4 are where your material is thinnest | Rehearse the weakest-part question until it is boring. Say what your material carries, say plainly what it does not, then give a plan said as a plan |
| B. Case / Strategist | Live mini-problems from the job: a double-booked day, a trip to arrange, an invoice that does not match | High, for the same prior. The ad's four duties turn into four easy scenarios | Clarify first, then say your order of steps aloud, then say who you would tell. Think aloud and say where you would look something up |
| C. Conversational | Friendly opener, why this role, why remote | Medium. A 30-minute call with an office manager usually starts here, and the opener is still scored | Prepare a 90-second answer to the journey question from the sentences you have said about yourself |
| D. Data-Driven Prober | Goes line by line through the background: how many, whose, what part was yours | Medium. Your background is short, so each line gets pressed | Know what you can and cannot say about each line, and say plainly when you do not know a figure |
| E. Pressure | Time-boxed challenge: why you over someone with more experience | Low. Nothing in the invite suggests a stress style, so it gets two questions | Pause, restate the question, hold what your material carries, concede specifically where it stops |

The weights rest on the relationship prior and on the invite's own description of one 30-minute video call. They do not rest on this company's documented process: the searches for it were refused. If you know the office manager is a peer instead, tell me and the banks reweight.

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you ran the appointment book." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Story-mapped on F1, with only the beats the quote states: you were the receptionist, the book was for four physios, and you ran it. Tell it in your own words. Answer slot: expect follow-ups on the detail; wherever one asks about a step you did not take, or something that did not exist, say so plainly and return to the book you ran | F1 is the evidence for the calendars duty and the first line an interviewer reads. EXP because it tests what was actually yours |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I'm good with Word, okay with Excel" | The highest-ROI rehearsal in this pack. Choose the part that is truest and say it before they do. Your one rating to hold at its scope: "I'm good with Word, okay with Excel." Answer slot: for any other part you name, say whether you have done it, in your own words; if you have not, say so plainly. Then give a plan, said as a plan: what you would ask to be shown first | F2, F3 and F4 are the thinnest rows, so this question arrives in some form. JD because it scores the stated duties, including the gaps |
| A3 | "What part of processing supplier invoices have you done yourself?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | The hold is only what the quote carries: "I chased unpaid invoices." Answer slot: if any processing was yours, say which part and how, in your own words; if your part was chasing only, or none was yours, say so plainly and describe the chasing. Hold through two follow-ups by returning to the chasing, never by adding to it | F4 is where the supplier-invoices duty presses hardest. JD because it scores a stated duty |
| A4 | "Excel is on the list. Where would you put yourself with it?" | JD | [grounded] "I'm good with Word, okay with Excel" | Say your own rating, as you gave it: "okay with Excel." Do not round it up. Answer slot: expect a probe on what you have done in it. If you have used spreadsheets for anything, say what, in your own words; if not much, say so plainly and say what you would practise first | F3's Excel half is the weaker one. JD because the ad names the tool |
| A5 | "Tell me about any travel you have booked, for yourself or for someone else." | JD | [generic] | Selection scaffold: pick the nearest real example, if one exists. It needs who the trip was for, what you arranged and what you checked. If none comes to mind, say so plainly, then give the nearest thing you have done, the appointment book you ran, or how you would handle it | F2 has no evidence, so the answer has to be honest either way. JD because travel is a stated duty |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two managers each ask for the same afternoon of your time, and a supplier invoice is due today. What do you do first?" | CASE | [generic] | Structure it: what you would ask first (what is urgent, who decides priorities), what you would do now, who you would tell and what you would record. The question needs no claim about your past, so the guidance makes none | A live problem built from the duties in F1 and F4. Generic because it is a pattern, not a fact about this employer |
| B2 | "You are booking a trip for someone: flights, a hotel and a meeting that might move. What do you ask first?" | CASE | [generic] | Structure it: fixed dates, budget and any rules, preferences, what happens if the meeting moves, and how you confirm the plan to the traveller. Think aloud. The guidance makes no claim about your past | Covers F2 without asking for experience you may not have |
| B3 | "A supplier invoice arrives that does not match what was ordered. Walk me through it." | CASE | [generic] | Structure it: what you would check, who you would ask, what you would do with the invoice meanwhile, and what you would record. Say where you would ask for help. The guidance makes no claim about your past | Covers F4 as a decision rather than a record |
| B4 | "You need to send the team a summary of last month's supplier invoices, with totals, by tomorrow. How would you build it in Excel?" | CASE | [generic] | Clarify first: what the summary is for and what the team needs to see. Then say your steps aloud, and say plainly which steps you could do now and which you would look up. Do not name a feature you have not used | Covers F3's weaker half in a way that rewards honesty about limits |
| B5 | "A manager's diary is full, and a request arrives from someone more senior. What do you do?" | CASE | [generic] | Structure it: what you would ask the manager before moving anything, what you would offer the requester, how the change gets communicated, and how you would keep a record. The guidance makes no claim about your past | Covers F1 as a decision, from the duty "managing calendars" |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey: how did you come to be applying for this?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | A 90-second arc with only the beats the quote states: two years as a receptionist at a physiotherapy clinic, running the appointment book for four physios, chasing unpaid invoices. Answer slot: your material does not say why you want to move to remote admin work, so give your actual reason, in your own words | The opener is scored for economy and honesty, and F1 and F4 are its raw material |
| C2 | "What interests you about working remotely?" | JD | [generic] | Selection scaffold: pick a real reason, and if you have worked remotely, say when. If no such time comes to mind, say so plainly, then say how you would organise a working day at home | F5 has no evidence, and the title makes this likely |
| C3 | "What do you know about what we do?" | CO | [generic] | Use only what you have found on the company's own website and careers page before the call. If you have found little so far, say so plainly and say what you plan to look at. Do not repeat anything from the invite as though it were research | No research could be run, so this stays generic. The honest cost is that it cannot be tailored |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How many appointments went through that book on a typical day?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Answer slot: if you know roughly, give it as roughly; if you did not track it, say so plainly and describe how the book ran, in your own words. Never estimate to sound impressive | The only number in F1 is the four physios, and a prober presses for the next one |
| D2 | "What did running the appointment book actually cover, and what was not yours?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | The hold is the quote: "I ran the appointment book for four physios." Answer slot: if any part belonged to a physio, a manager or the booking system, say which, in your own words; if all of it was yours, say so | Attribution is the prober's main target, and F1 has no inspected proof behind it |
| D3 | "Tell me about the invoices you chased." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Say what you did with them in your own words. Answer slot: where a follow-up asks about a step you did not take, or something that did not exist, say so plainly and return to chasing unpaid invoices | F4's evidence is one clause, and the follow-ups go two levels deep |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone with more office experience?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Pause and restate the question. Hold what the quote carries: two years as a receptionist at a physiotherapy clinic, running the appointment book for four physios and chasing unpaid invoices. Hold it through two follow-ups. Answer slot: name from your own experience which parts of this job would be new to you, and say it plainly | A time-boxed challenge to the whole background. It tests composure more than content |
| E2 | "How much of that appointment book was actually you?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Hold-then-concede on the quote: "I ran the appointment book for four physios." Hold it through two follow-ups. Answer slot: if some of it was shared, say which part and with whom; if it was not, say so plainly | A stem from the persona model. F1 is the line it targets |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "managing calendars" (F1) | A1, B1, B5, D1, D2, E1, E2 |
| "booking travel" (F2) | A5, B2 |
| "preparing documents in Word and Excel" (F3) | A2, A4, B4 |
| "processing supplier invoices" (F4) | A2, A3, B1, B3, D3 |
| "Remote Administrative Assistant" (F5) | C2 |
| The company itself | C3 |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | What does a good first month look like in this role? | It shows you are thinking about doing the job well from the start, and it tells you what the first tasks are | [generic] |
| R2 | Which tools do you use today for calendars, travel and supplier invoices? | It shows practical interest and tells you how much of the Excel gap matters on day one | [generic] |
| R3 | How is equipment provided to remote staff, and who pays for it? | A practical question for a remote role, and the answer is something you can check against what the invite says | [generic] |
| R4 | Who would I report to, and how often would we check in? | It shows you want clear expectations, and it settles the relationship this pack had to assume | [generic] |
| R5 | When would I get a written contract, and which documents or details are needed at which stage? | A careful candidate asks this, and a straight answer is easy to give | [generic] |
| R6 | What happens after this call? | It closes the conversation with a next step and gives you the timeline | [generic] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars | Inflated form of F1, using the ad's own word for your history | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation, not words for you: the material says appointment book, not calendars |
| Processed supplier invoices, or handled the clinic's invoicing | Inflated form of F4 | F4's quote at its own scope: "I chased unpaid invoices." The material shows chasing, not processing |
| Advanced or proficient Excel | Inflated form of F3 | F3's quote at its own scope: "okay with Excel" |

## Sources

Provided documents: your message, containing the invite's text, your description of the ad and your background. No `tuesday-dossier.md` was present.

Searches sent:

- `Brennock Facilities Ltd values`: refused
- `Brennock Facilities Ltd interview process administrative assistant`: refused
- `Brennock Facilities Ltd news`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | Every call was refused. It would have fed a values cheat sheet, which this pack does not have |
| 2. `Brennock Facilities Ltd interview process administrative assistant` | unavailable | Every call was refused. It would have documented the loop. The weights rest on the invite's own description instead |
| 3. `Brennock Facilities Ltd news` | unavailable | Every call was refused. It would have fed a company-specific CO question, so C3 stays generic |
| 4. interviewer name and company | n/a | No name was given, only the title "office manager", so there was no query to form |
| 5. representative `Remote Administrative Assistant` JD | skipped | Your description of the ad already fixes the fit snapshot rows and the JD-tagged questions |

## Upgrade menu

- The full ad text → the F rows quote the ad itself instead of your description of it, and any duty missing from your summary gets a row
- Anything you have done with booking travel, spreadsheets, supplier invoices or working remotely → F2 to F5's answer slots become `[grounded]` rows with a story to map
- The office manager's name → an interviewer read and a reverse question tied to their path
- Whether the office manager is your future manager or a peer → persona weights recomputed across every bank
- How much prep time you have → a prioritised schedule
- The company's own website and careers page, pasted → a CO question and a values check built on its words; or a deeper research pass of up to 6 more searches and 2 more fetches, several more minutes, if search is permitted
- A `tuesday-dossier.md` → verified evidence and absolute prohibited claims carried in, and the most likely objection taken from evidence rather than inferred
