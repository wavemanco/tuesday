# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, Thursday 2pm, a 30-minute phone call with Hannah Lowther (Talent Partner), who will ring the mobile number on your application.
**Built on:** the advert you pasted, Hannah's LinkedIn message and your own notes. No CV was supplied, so every candidate quote below is a sentence from your message.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- The five type tags:
  - VAL: whether past behaviour shows a published value.
  - EXP: whether your account of your own work holds up.
  - JD: the advert's stated job, terms and requirements.
  - CO: knowledge of the company and its strategy.
  - CASE: a live problem set in the role.
- Provenance labels: `[grounded]` traces to something you supplied, `[inferred]` is this pack's derivation, `[generic]` is a pattern with no claim about you or Quillmoor.
- Guidance is scaffolding, not a script. An answer slot is an instruction for the interview, not a question for this chat: say it in your own words, and if the honest answer is that you did not do the thing, say that plainly.
- Question letters skip F, because F1 to F12 name the fit-snapshot rows.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — JD | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says delivery scheduling for three depots, not production schedules, and says nothing about planning or QA. The words stay at that scope: "I schedule deliveries for our three depots." Answer slot: the JD's planning, warehouse and QA line makes a probe on who you worked with likely. If any of your scheduling put you in touch with any of those teams, say which and what it involved, in your own words; if none did, say so plainly and stay with the depots |
| F2 | "track supplier deliveries" — JD | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | The quote touches deliveries without showing whether you tracked them. Answer slot: the JD line makes a probe on how you knew what was due or late likely. If you keep any record or view of what is due in, say what it is and what it shows, in your own words; if you do not, say so plainly and stay with scheduling deliveries and chasing suppliers |
| F3 | "chase late orders" — JD | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you chase suppliers when orders slip. A named action beats an adjective |
| F4 | "keep stock records accurate" — JD | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | The quote already reaches the requirement. Keep its words: "rebuilt", "fell", "about a third", "over a year". "Fell" does not become "I cut". The figure raises the defend-the-number slots in C1 |
| F5 | "report weekly on on-time dispatch" — JD | none given | none | [grounded] | discovery | Your material is silent on reporting. Answer slot: the JD's weekly-reporting line makes a probe on regular reports likely. If you produce any regular report, say what it covers and who reads it, in your own words; if you do not, say so plainly and stay with the stock-count spreadsheet |
| F6 | "2+ years in operations or logistics coordination" — JD | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | A length-of-experience requirement, not a gate. The quote reaches it in the same terms. Lead with it as written |
| F7 | "confident with Excel" — JD | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The quote shows a spreadsheet, not that it was Excel. Answer slot: the JD's Excel line makes a probe on what you do in it likely. If the spreadsheet was in Excel, say so and what you did in it, in your own words; if it was another tool, say so plainly and stay with the rebuild |
| F8 | "ERP experience (SAP or similar) a plus" — JD | "Never used SAP — we run our own in-house stock system." — your message | low | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used SAP." Then your quote at its own scope: "we run our own in-house stock system." The pack's observation: your material says an in-house stock system, not what you did in it or that it resembles SAP. After that, how you would learn the system you are given, said as a plan and never as a past |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" — JD | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | A gate (schedule and location), shown met on your own statement. Say it as you said it: two days is fine, and you wouldn't want more than three. That is a stated ceiling, not "flexible" and not "can't" |
| F10 | "£38,000–£44,000" — JD | "I'm hoping for £42,000." — your message | high | [grounded] | none | A gate (pay), shown met: your figure sits inside the quoted band. Keep "hoping for". Add no range and no salary history |
| F11 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish it |
| F12 | "what's prompting a move" — Hannah's message | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | The quote already answers it. Say it in its own terms: the office is closing next year, the only offer is Reading, and you don't want it |

## Persona table

Hannah's message names one session: a 30-minute call, four topics from her (pay, notice, hybrid, reason for moving), then the team and next steps. The weights rest on that, not on an archetype.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport | Friendly, runs down her list in order | Highest. All four of her named topics are logistics or motivation, asked casually but scored | Treat each as scored. Build the 90-second arc only from the quotes in F6, F3, F4 and F12 |
| B. Skeptic | Quiet probing of the gaps: SAP, wholesale versus manufacturing, why now | Second, and light. F8 is a negative you stated and F12 is a push motive, but her list names no skills probe | Rehearse B1 until it is boring. Bridges come only from the F-row quotes, with the limit said plainly |
| C. Data-Driven Prober | Asks how a figure was counted; checks Excel and reporting | Mid. Her list names none of it, but the advert puts Excel and weekly reporting up front and F4 carries a figure | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| D. Pressure / Stress | Time-boxed, "how much was you" | Low. Nothing in her message suggests a stress style | Pause, restate, return to the quoted sentences, concede only what the material shows |
| E. Case / Strategist | A live problem from the role | Low. Her list names no live problem. The two cases rehearse the advert's coordination and reporting lines | Clarify first, then structure, then answer |
| G. Values / Behavioral | "Tell me about a time" prompts | Low. No values-style round is detected: her message names none and no values page was read | Choose one specific occasion you can tell from start to finish |

Peer Evaluator is omitted: the only named interviewer is a recruiter.

## Question banks

### A. Conversational / Rapport (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What salary are you expecting?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot filled by your own figure. Say it in the words you gave: "I'm hoping for £42,000." Then stop. Add no range and no salary history. If she asks whether it is flexible, give your actual position in your own words | F10 is shown met. Hannah's message names salary first. JD because it scores the listed job's terms |
| A2 | "What's your notice period?" | JD | [grounded] | Logistics slot. Give your actual notice period, exactly as it stands today. Nothing in your material states it, so the pack supplies no figure and no start date | F11 is the one gate your material does not establish. JD because it is a term of the job |
| A3 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Say it in that order: north Bristol, two days is fine. Then the ceiling as you stated it: you wouldn't want more than three. Do not harden it into "can't" or soften it into "flexible" | F9 is shown met. It is on Hannah's list by name. JD because the advert sets the pattern |
| A4 | "What's prompting you to look for a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Three beats, all in the sentence: the office closes next year, the only offer is Reading, you don't want it. Add no "redundant" and no blame. Answer slot: if she asks what you want from the next role, say what you are looking for in your own words; if you have not pinned it down, say so plainly and stay with what the advert asks for | F12 is the answer and Hannah's own wording. EXP because it tests your account of your own situation |
| A5 | "So, walk me through your background and what's drawn you to this role." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | A 90-second arc in three beats, in this order: the four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet while discrepancies fell by about a third over a year. Keep "fell"; do not turn it into "I cut". Answer slot for the second half: the advert's lines raise what drew you. Say which line you actually care about and why, in your own words; if none stands out, say so plainly | F6, F3 and F4 carry the arc. EXP for the background, JD for the role half |

### B. Skeptic (weight: second)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | The highest-ROI rehearsal in this pack. Hold: "I haven't used SAP." Do not add an apology or a comparison. Follow-up 1, "what have you used instead": say "we run our own in-house stock system" and stop at that scope. Answer slot: if you worked in that system, say what you did in it, in your own words; if you mostly did not, say so plainly. Follow-up 2, "how would you get up to speed": say what you would do in your first weeks to learn the system you are given, as a plan and not a past. The limit, named before it is asked: your material says an in-house stock system, not that it resembles SAP, so do not compare them | F8 is the stated negative, and some form of this question is the likeliest of the pack. If she names a different weakest area, F1 holds the other limit. JD because it scores the listed requirement, Skeptic delivery |
| B2 | "This role sits between planning, the warehouse and QA. What's your experience of working with teams like those?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Say what the sentence says: scheduling deliveries for three depots and chasing suppliers when orders slip. Answer slot: if any of that work put you in touch with planning, the warehouse or QA, say which team and what it involved, in your own words; if none did, say so plainly and stay with the depots and the suppliers | F1 is where the advert's coordination line presses hardest. JD because it scores the stated requirement |
| B3 | "You've been at a wholesaler and we make diagnostic tests. How would you get up to speed on a manufacturing environment?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." | Start from the plain fact: your four years were as a logistics coordinator at a building-supplies wholesaler. Then say how you would learn a manufacturing setting, as a plan in your own words. Claim no manufacturing experience | F6 and F1 together make the sector change the natural follow-up. JD because the advert sets the environment |
| B4 | "Why now, and why Quillmoor rather than something else in Bristol?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | "Why now" is answered by the sentence: the office closes next year. Answer slot for "why here": say what actually drew you to this job in your own words; if the main reason is staying in Bristol, say that plainly | F12 covers the push, and the pull is not in your material. EXP because it tests motivation consistency |

### C. Data-Driven Prober (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through that stock-count figure. How was 'about a third' counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Four defend-the-number slots, each in your own words. How it was counted: say how if you know, and if you don't, say plainly that you don't know how it was counted. What it is most sensitive to. The assumption behind it you would defend least, named before she does. Which part was yours: the sentence says you rebuilt the spreadsheet, and whether the rebuild caused the fall is yours to say or to say you can't be sure of. The pack names no method and no baseline | F4 is the one headline figure in your material. EXP because it tests whether the claim survives scrutiny |
| C2 | "How comfortable are you in Excel? What do you actually use it for?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if the spreadsheet was in Excel, say so and what you did in it, in your own words; if it was another tool, or you use Excel lightly, say so plainly and stay with the rebuild | F7 is open: the quote shows a spreadsheet, not Excel. JD because Excel is a listed requirement |
| C3 | "The role tracks supplier deliveries and reports weekly on on-time dispatch. What do you track and report today?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if you keep any record of what is due in, or produce any regular report, say what it covers, who reads it and how often, in your own words; if you do neither, say so plainly and stay with the stock-count spreadsheet | F2 and F5 are both silent in your material, and both are listed duties. JD because it scores two stated responsibilities |

### D. Pressure / Stress (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we take you forward?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Pause and restate the question. Answer from the two sentences: four years as a logistics coordinator at a building-supplies wholesaler, scheduling deliveries for three depots and chasing suppliers when orders slip. Hold through two follow-ups by returning to those sentences, not by adding to them. Concede what the material shows is missing: "I haven't used SAP." | F6 and F3 are the strongest rows against the advert's duties. JD because it scores fit to the listed role |
| D2 | "That spreadsheet result. How much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold the part the sentence carries: "I rebuilt our stock-count spreadsheet." Say the fall as stated: discrepancies fell. Answer slot: if other people or other changes contributed to the fall, say what, in your own words; if you don't know what else contributed, say so plainly and return to the rebuild. Never fold on the rebuild | F4's attribution is the standard pressure target. EXP because it tests attribution honesty |

### E. Case / Strategist (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier says a part for next week's production run will arrive three days late. Planning wants to hold the schedule, the warehouse is short of space and QA hasn't signed off the last batch. What do you do first?" | CASE | [generic] | Structure it aloud. Clarify first: what the part is, how many runs depend on it, whether an alternative supply exists. Then the objective, who needs to know and in what order, the options with their costs, and what you would record. Challenge one premise politely. The question needs no claim about your past, so the guidance makes none | A live problem built from the advert's coordination and late-order lines (F1, F3). `[generic]` because it is a pattern for the problem, not a fact about this employer |
| E2 | "On-time dispatch has dropped against last month's report. How would you find out why?" | CASE | [generic] | Clarify what counts as on time and over what window. Then split the drop by product, customer and stage, and ask what is late and where it waits. Say what you would report back and to whom. No claim about your past | A live problem from the advert's weekly-reporting line (F5). `[generic]` for the same reason |

### G. Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time a supplier let an order slip and you had to get it back on track." | VAL | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Your sentence carries the practice, not one occasion, so this is a selection scaffold. Pick one occasion you can tell from start to finish: what was due, what you did to chase it, what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | F3 is the advert's chase-late-orders line. The theme comes from the advert, not from a published value |
| G2 | "Tell me about a time you had to get different teams to agree on a schedule." | VAL | [generic] | Selection scaffold: pick an occasion with a named disagreement, what you proposed and where it ended up. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | F1's requirement. `[generic]` because your material carries no sentence for it |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Coordinate production schedules | B2, E1, G2 |
| F2 Track supplier deliveries | C3 |
| F3 Chase late orders | A5, D1, G1 |
| F4 Keep stock records accurate | A5, C1, D2 |
| F5 Report weekly on on-time dispatch | C3, E2 |
| F6 2+ years in coordination | A5, B3, D1 |
| F7 Confident with Excel | C2 |
| F8 ERP experience (a plus) | B1 |
| F9 Hybrid, two days at Avonmouth | A3 |
| F10 Pay | A1 |
| F11 Notice period | A2 |
| F12 What's prompting a move | A4, B4 |

## Reverse questions

| # | Question to ask her | Why it lands |
|---|---|---|
| R1 | "How do the Avonmouth days work in practice: fixed days for the team, or agreed individually?" | The hybrid pattern is on her list, and the answer lets you check it against the ceiling you stated in F9 |
| R2 | "Which system does the team use for stock and orders today, and what training comes with it?" | The advert names SAP or similar as a plus. This finds out what you would actually learn and treats F8 as a plan |
| R3 | "Who would I work with most closely across planning, the warehouse and QA?" | It turns the advert's coordination line into a concrete picture, and shows interest without claiming experience |
| R4 | "What does the weekly on-time dispatch report look like today, and who reads it?" | It engages with the reporting line (F5) without claiming you have produced one |
| R5 | "What would a good first three months look like in this role?" | It invites her to state the success criteria you can then address |
| R6 | "Is there anything in what I've said that you'd like me to expand on?" | It gives you a chance to meet a concern before the call ends |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has SAP experience | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't used SAP." Your quote at its own scope: "we run our own in-house stock system." |
| Has ERP experience | Inflated form of F8 | F8's quote at its own scope. The limit is the pack's observation: your material says an in-house stock system, not that it is an ERP or what you did in it. B1's slot stays inside that system |
| Coordinated production schedules across planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: your material says delivery scheduling, not production schedules. B2's slot stays inside the depots and suppliers |
| Advanced Excel skills | Inflated form of F7 | F7's quote at its own scope: you rebuilt a stock-count spreadsheet. The limit is the pack's observation: your material says spreadsheet, not Excel |
| Cut discrepancies by a third | Inflated form of F4 | F4's quote at its own scope: "discrepancies fell by about a third over a year." C1 and D2 ask only what part was yours |
| Being made redundant, or your employer closing | Inflated form of F12 | F12's quote at its own scope: the Bristol office is closing next year and the only offer is Reading |
| Flexible on any number of office days | Claim F9's quote contradicts | F9's quote: "I wouldn't want more than three." |

## Sources

Provided documents: the advert pasted in your message; Hannah Lowther's LinkedIn message; your own background and what you would tell her. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Every search was refused (the host did not grant permission), so nothing about Quillmoor came from research. No fact about the company's values, process or strategy is in this pack, and none comes from memory.

Searches sent:

- `Quillmoor Diagnostics values` — refused
- `Quillmoor Diagnostics interview process operations coordinator` — refused
- `Quillmoor Diagnostics Avonmouth news` — refused
- `Hannah Lowther Quillmoor Diagnostics` — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Every call was refused. It would have moved the VAL questions' themes and a values cheat sheet, if a values-style round had been detected |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Every call was refused. It would have moved loop structure for later rounds. This session's weights stand on Hannah's own message |
| 3. `Quillmoor Diagnostics Avonmouth news` | unavailable | Every call was refused. It would have moved a CO question grounded in current strategy; the pack has none |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Every call was refused. It would have moved an interviewer read and a reverse question tied to her path |
| 5. representative Operations Coordinator JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → F11 and A2 get your actual words, and the one hard-gate row is settled
- Your CV → the rows resting on sentences from your message (F3, F4, F6) gain inspected evidence
- The stock-count spreadsheet, or its discrepancy log → F4 could move from medium to high, and C1's slots could be answered from the record
- Your answers to the slots in F1, F2, F5, F7 and F8 (whether your scheduling touched planning, the warehouse or QA; whether you track deliveries or write any report; whether the spreadsheet was Excel; what you did in the in-house stock system) → those rows become `[grounded]` with your own quotes behind them
- Web search access → the company's values, interview process and current strategy, Hannah's public footprint (a tailored reverse question), and one CO question. A deeper pass is available once: up to 6 more searches and 2 more fetches, several more minutes
- A `tuesday-dossier.md` from an earlier review of this role → verified evidence and absolute prohibited claims in place of the ones built here
