# Interview pack: Operations Coordinator, Quillmoor Diagnostics

Round: recruiter screen. Interviewer: Hannah Lowther, Talent Partner. Thursday 2pm, a 30-minute phone call to the mobile number on your application. Hannah's own agenda: salary expectations, notice period, how the hybrid pattern would work for you, what's prompting a move, then the team and next steps.

Built on one assumption: Hannah is a recruiter running a screen, not the hiring manager. Web research was not available when this was built, so nothing here is drawn from Quillmoor's own pages or from Hannah's public footprint.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script.
- Type key: VAL = values alignment. EXP = work-experience deep-dive. JD = the advert's stated requirements and terms. CO = company and strategy knowledge. CASE = a live problem. (No VAL or CO question appears: no values round is documented, and company research was not available.)
- An answer slot is an instruction for the call, not a question for you: it names what Hannah is likely to probe, and gives two honest branches, one if you did it and one if you did not. Either branch is a good answer.
- Provenance: grounded = traceable to something you or the advert said. inferred = derived from it, derivation named. generic = a pattern for the problem, no claim about you or Quillmoor. Where guidance rests on your own words, they are quoted beside the label.
- Highest-ROI prep in this pack: B2. It is the question aimed at the widest distance between the advert's first duty and what your material shows, and it gets the deepest rehearsal.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | transferability | Your material says delivery scheduling for three depots, not production scheduling, and the words stay at the quote: "I schedule deliveries for our three depots." Answer slot: the advert's first duty makes a probe on how your scheduling fits with other teams likely. If any of it involved working with other teams on timing, say how, in your own words; if not, or it was not yours, say so plainly and stay with the three depots |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on how you chase. Lead with the quote's own terms: you chase suppliers when orders slip, because a named action beats an adjective |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap in wording, but a figure with nothing inspected behind it, so expect the defend-the-number probes: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, each in your own words. Keep "about a third over a year" at its own precision |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show any reporting on dispatch or deliveries. Answer slot: the advert's weekly line makes a probe on reporting likely. If you have reported regularly on any delivery or dispatch measure, say what it measured and how often, in your own words; if not, or it was not yours, say so plainly and stay with the delivery scheduling for three depots |
| F5 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap: the quote gives the years and the role in the advert's terms. Say it as it stands, four years as a logistics coordinator at a building-supplies wholesaler |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | low | [inferred] | discovery | The quote says a spreadsheet and does not say which tool. Answer slot: the advert's Excel line makes a probe on what you use it for likely. If the spreadsheet was in Excel, say so and what it does, in your own words; if it was another tool, or you use Excel little, say so plainly and stay with the rebuild |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used SAP." Then how you would learn it, said as a plan and never as a past. The advert lists ERP as a plus, so this is a risk to name, not a bar |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system" — your message | low | [inferred] | discovery | The same sentence touches "or similar" without showing whether it reaches it. Answer slot: if you work in your company's in-house stock system day to day, say what you do in it, in your own words; if you do not use it directly, or it is not comparable, say so plainly and return to the stock-count spreadsheet |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | The figure sits inside the advert's band. Say it as a hope, as you said it: "I'm hoping for £42,000." Your material gives a hope, not a minimum, so decide before the call what you would do if the offer came lower, and keep that decision in your own words |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | The advert's pattern is met. Say it in your own terms: two days at Avonmouth is fine, and you wouldn't want more than three. Whether three would be acceptable or a firm stop is not in your material, so settle your own answer before the call |
| F11 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | No gap. A stated reason with nothing inspected behind it, so say it as told and stop where the sentence stops |

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport (A) | Friendly, unstructured: the journey, then pay, notice, days, why you are moving | High. The recruiter-screen prior is Conversational plus a light Skeptic, and Hannah's message lists four logistics topics before the team and next steps. Four of its seven questions are those logistics rows, which is why it runs longer than the others | A 90-second arc built only from your four quoted sentences (A1); logistics answered in your own words and short |
| Skeptic (B) | Quiet probing of the gaps: day-one weakness, the production side of the role, SAP, why here | Medium. The prior says light; the SAP line is in the advert and you have said you have not used it, and "what's prompting a move" is a motivation-consistency check | Rehearse B2 until it is boring; bridges only from the sentences you wrote; where there is no sentence, say the limit plainly and give a plan |
| Data-Driven Prober (C) | Walks the one number you have, and the advert's weekly reporting line | Low to medium. Recruiters rarely go two levels deep, but the stock-discrepancy figure is the only number in your material and the weekly reporting line is in the advert | Know what you can and cannot say about how the figure was counted, and say plainly where you do not know |
| Case / Strategist (D) | A short live problem from the role | Low. Hannah's agenda names no live problem; included because the advert's duties make a quick scenario easy to ask | Clarify first, then structure, then answer; think aloud |
| Pressure (E) | Pushes on the pay figure or asks for a 60-second case | Low. Nothing in Hannah's message signals it; a pay figure near the top of a band can draw a challenge | Hold what you said through two follow-ups, concede specifically, do not fold on the figure |

## Question banks

### A. Conversational / rapport (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey: where are you now and how did you get here?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year"; "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Four beats, in order, one or two sentences each, in your own words: the four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling by about a third over a year; the office closing next year, Reading the only offer, which you don't want. Stop when the beats stop: add no scale, tool or outcome the sentences do not carry | F5 and F11 are the first things she will hear, and F2 and F3 are the lines the advert's duties will be matched against. EXP because it tests what the CV-style claims actually say; JD secondary through F5's years |
| A2 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say the reason as you told me: the Bristol office is closing next year, the only offer is relocating to Reading, and you don't want that. Say it factually and stop where the sentence stops; add nothing about your employer beyond it | Hannah named this topic herself, so it is certain, and F11 is the whole answer. EXP because it checks that the story is consistent with the rest of your account |
| A3 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000" | Say the figure as you said it to me: you're hoping for £42,000. Say it once, plainly, then stop and let her respond; do not call it your minimum, because your own words call it a hope. If she pushes lower, use the decision you settled in F9 before the call, in your own words | Hannah named salary expectations as the first topic, and F9 is the whole answer. JD because the advert states the band; no defend-the-number slot, because a figure for the job's terms raises none |
| A4 | "What's your notice period?" | JD | [grounded] | Give your actual notice period, as your contract states it. If you are not certain, read the contract before Thursday rather than estimating on the call. Offer an earlier date only if it is true | Hannah named notice as a topic, and your material says nothing on it, so the answer has to be yours. JD because it is a term of the job's start |
| A5 | "The role is two days a week at Avonmouth. How would that work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Say it in those terms: you live in north Bristol, two days at Avonmouth is fine, and you wouldn't want more than three. State the limit as you said it, plainly and without apology. Add nothing about the journey, which your material does not give | Hannah named the hybrid pattern as a topic, and F10 is the whole answer. JD because the advert states the pattern |
| A6 | "What does a typical week look like for you now?" | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Two beats the sentence carries: scheduling deliveries for three depots, and chasing suppliers when orders slip. Answer slot: the advert's line on tracking supplier deliveries and chasing late orders makes a probe on how you go about it likely. Say how, in your own words; if there is no set routine, or part of it is not yours, say so plainly and stay with the three depots and the supplier chasing | F2 is the closest match to the advert's second duty. EXP because it tests what your week actually contains; JD secondary |
| A7 | "What are you actually doing in Excel these days?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | The quote says a spreadsheet and does not say which tool or what is in it. Answer slot: the advert's "confident with Excel" makes this probe likely. If the stock-count spreadsheet is an Excel workbook, say so and say what it does, in your own words; if it was another tool, or you use Excel little, say so plainly and stay with the rebuild | F6 is the one requirement the quote touches without showing. JD because it scores the advert's named skill; inferred because the link from spreadsheet to Excel is this pack's derivation |

### B. Skeptic (weight: second)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Pick the line of the advert you can least evidence from your own experience, say it plainly, then say how you would close it, as a plan. Your material gives one such line: "I've never used SAP." If you choose it, say that sentence, then how you would learn it, in your own words. If something else comes to mind that your material does not show, say so plainly | F7 is the gap you have stated yourself, so it is the one you can answer without risk. JD because it scores the advert's own list, including its gaps |
| B2 | "The role coordinates production schedules between planning, the warehouse and QA. What's the closest thing you've done?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | **Highest-ROI prep in this pack.** The limit, named before she asks: your material says delivery scheduling for three depots, not production, planning or QA. Hold what the quote carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." Say it in those terms and let her draw the comparison. Follow-up one, "is that really the same?": answer slot: if any of your scheduling involved working with other teams on timing, say how, in your own words; if not, or it was not yours, say so plainly and stay with the three depots. Follow-up two, "how would you get up to speed on the production side?": a plan in your own words, never a past. Follow-up three, "what would you want to know first?": ask how the sequence between those teams works today. Hold through all three by returning to the three depots, never by adding to them | F1 is the widest distance between the advert's first duty and your quote, so this objection arrives in some form. JD because it scores the first stated duty; the hold is a limit, not a confession |
| B3 | "You've not used SAP. How would you get up to speed?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Start with your own sentence: "I've never used SAP." Then answer slot: if you work in your company's in-house stock system day to day, say what you do in it, in your own words; if you do not use it directly, say so plainly. Then how you would learn SAP, said as a plan and never as a past | F7 and F8 together. The question's premise is your own stated negative, so it carries a plain acknowledgment. JD because the advert lists ERP as a plus |
| B4 | "Why this role, rather than taking the Reading offer?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | State the reason you gave: the office is closing next year, the only offer is Reading, and you don't want it. Answer slot: if something in the advert draws you, say what and why, in your own words; if the move is mainly the closure, say so plainly. Both are honest. Do not borrow warm words about Quillmoor you cannot back, since this pack holds no facts about it | F11 is the answer; the probe is why-here-why-now, the Skeptic's standard stem. EXP because it checks motivation consistency |

### C. Data-Driven Prober (weight: third)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that discrepancy figure was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Answer slot, in your own words: if you know how it was counted, say how, and what it depends on; if you do not know, say so plainly. Keep the precision of your own sentence: about a third, over a year. Say which part was your rebuild, as you would describe it | F3 is the only figure in your material, so it is where a prober goes. EXP because it tests whether the claim survives scrutiny |
| C2 | "Which assumption behind 'about a third' would you defend least?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Name, in your own words, the assumption you would defend least, before she does; it turns a gotcha into credibility. If you do not know of one, say you do not know how it was counted beyond what you have said. This pack does not name the assumption for you | F3 again, at its weakest point. EXP because it scores whether you know your own number's limits |
| C3 | "The role reports weekly on on-time dispatch. What have you reported on?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Answer slot: if you have reported regularly on any delivery or dispatch measure, say what it measured and how often, in your own words; if not, or it was not yours, say so plainly and stay with the delivery scheduling for three depots | F4 is a requirement your material is silent on, so the honest answer is yours alone. JD because the advert states the duty |

### D. Case / Strategist (weight: fourth)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier rings at 4pm: tomorrow's delivery will be a week late, and the warehouse and QA are both waiting on it. What do you do?" | CASE | [generic] | Structure it: what you would ask the supplier first, who needs to know and in what order, what options you would put to them, and what you would record and chase afterwards. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's duties on supplier deliveries and late orders (F2's requirement). CASE because it asks for structure on a problem, not a story |
| D2 | "The stock record says 40 units and the shelf shows 35. What do you do?" | CASE | [generic] | Structure it: recount before changing the record, look at what moved since the last count, log the difference, say who needs to know, then what would stop it recurring. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's duty on stock records (F3's requirement). CASE because it scores reasoning, not experience |

### E. Pressure (weight: lowest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That's towards the top of our range. What makes you worth £42,000?" | JD | [grounded] "I'm hoping for £42,000"; "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip" | Hold: restate the figure as your hope, then what you have said you do: four years as a logistics coordinator at a building-supplies wholesaler, scheduling deliveries for three depots, chasing suppliers when orders slip. Describe it and let her draw the inference. Hold through two follow-ups without adding to it. Concede specifically where it is true: "I've never used SAP." If she offers a lower figure, use the decision you settled in F9 | F9 and F2 meet here. JD because the band is the advert's; the hold is only what your own sentences carry |
| E2 | "Sixty seconds: why should we put you through to the next stage?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Three beats, one sentence each: the four years at a building-supplies wholesaler, the delivery scheduling and supplier chasing for three depots, the stock-count spreadsheet rebuild and the fall of about a third over a year. Describe what you did and stop; do not tell her what it proves | F5, F2 and F3 are the whole of your quoted material for the advert's duties. JD because it scores fit against the stated requirements |

### Requirement coverage

| Advert requirement | Covered by |
|---|---|
| "Coordinate production schedules between planning, the warehouse and QA" | B2, B1, D1 |
| "track supplier deliveries and chase late orders" | A6, D1 |
| "keep stock records accurate" | C1, C2, D2 |
| "report weekly on on-time dispatch" | C3 |
| "2+ years in operations or logistics coordination" | A1, E2 |
| "confident with Excel" | A7 |
| "ERP experience (SAP or similar) a plus" | B3, B1 |
| "£38,000–£44,000" | A3, E1 |
| "Hybrid: two days a week at our Avonmouth site in Bristol" | A5 |
| Hannah's topics: notice period, what's prompting a move | A4, A2, B4 |

## Reverse questions

When she asks whether you have questions, pick two or three; if she has already covered one, say so and move to the next.

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "Which teams would this role work with most day to day, across planning, the warehouse and QA, and who would I report to?" | It follows the advert's first duty and tells you how the coordination is organised | [grounded] |
| R2 | "What does the weekly on-time dispatch report look like today, and who reads it?" | It follows the advert's reporting duty and shows what the output is | [grounded] |
| R3 | "Which system holds stock and supplier records today, and how is training handled for someone new to it?" | It follows the advert's ERP line and gives you a straight answer on how the gap would be handled | [grounded] |
| R4 | "How are the two Avonmouth days usually decided, fixed days for the team or agreed individually?" | It follows the advert's hybrid pattern and your own limit of three days | [grounded] |
| R5 | "What would you want someone in this role to have handled well by the end of their first three months?" | It asks for the measure of success in her words | [generic] |
| R6 | "Who would I meet next, and what would that conversation cover?" | It gets the process in her words and tells you what to prepare | [generic] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots and chase suppliers when orders slip." The limit is this pack's observation, not words for you: your material says delivery scheduling, not production, planning or QA. B2's slot stays inside the deliveries |
| Has used SAP | Negative you stated, F7 | The plain acknowledgment F7 gives: "I've never used SAP." Then a plan for learning it, never a past |
| Has ERP experience | Inflated form of F8 | F8's quote at its own scope: "we run our own in-house stock system." The limit is this pack's observation: your material does not show what you do in it. B3's slot asks only what you do in it |
| Is confident or advanced in Excel | Inflated form of F6 | F6's quote at its own scope: you rebuilt a stock-count spreadsheet. The limit is this pack's observation: your material does not say which tool. A7's slot asks only which tool and what it does |
| Cut stock discrepancies by a third, stated exactly or more widely than your sentence | Inflated form of F3 | F3's quote at its own scope: "about a third over a year." The limit is this pack's observation: your material gives the figure, not how it was counted. C1 and C2 ask only how it was counted |
| Can work any number of days on site | Contradicted by F10 | F10's quote: "I wouldn't want more than three" |
| £42,000 is your minimum | Contradicted by F9 | F9's quote: "I'm hoping for £42,000" |

## Sources

Provided documents: the advert you pasted; Hannah Lowther's LinkedIn message; your background and what you plan to tell her. No `tuesday-dossier.md` was present.

Searches sent, all refused (the host did not permit web search in this session):

- "Quillmoor Diagnostics values" — refused
- "Quillmoor Diagnostics Avonmouth Bristol news" — refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Search refused. Would have given B4 and the reverse questions company-specific lines; no values-style round is documented, so no cheat sheet was due either way |
| 2. `Quillmoor Diagnostics interview process operations` | skipped | Hannah's message fixes the session: one 30-minute phone call with her, four named topics. That fixes the persona weights and banks |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | Search refused. Would have fed a company question and sharper reverse questions; none are in the pack |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Search refused. Would have fed an interviewer read and one reverse question tied to her path; the interviewer read is absent |
| 5. representative `Operations Coordinator` JD | skipped | The advert you pasted fixes the fit snapshot and every JD-tagged question |

## Upgrade menu

- Permission to search the web → rows 1, 3 and 4 above run: Quillmoor's published values and recent news, and Hannah's public professional footprint, which would add an interviewer read, a company question and a reverse question tied to her path (up to six searches and two page fetches, a few minutes)
- Your notice period as your contract states it → A4's slot becomes your own words
- Whether three days a week is a firm limit or a preference → A5 and F10 get your exact stance
- Your answers on four points → F1 (whether your scheduling involved other teams), F4 (any delivery or dispatch reporting), F6 (whether the spreadsheet is Excel) and F8 (what you do in the in-house system); each answer you send becomes quoted evidence and those rows regenerate with story-mapped guidance
- Your CV → the evidence column quotes CV lines as well as your message, and rows now at low or medium confidence can be re-graded
- How many hours you have before Thursday → a prioritised prep schedule tied to question IDs
- Anything Hannah sends ahead about the call or the process → coverage beyond her four named topics
- A `tuesday-dossier.md` from an earlier fit check → verified evidence would replace inferred rows and sharpen the objection B2 rehearses
