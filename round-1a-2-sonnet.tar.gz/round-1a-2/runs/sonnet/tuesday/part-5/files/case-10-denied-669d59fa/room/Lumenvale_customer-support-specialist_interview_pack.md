# Interview pack: Customer Support Specialist (remote), Lumenvale Software

Interviewer: the support team lead, name not given. Format: a text chat on Telegram. Relationship assumed: hiring manager, because the invite does not say whether the lead is your future manager or a peer.

## How to use this pack

Personas describe how a question arrives. Types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did. In a text interview your typed answers are also a writing sample, so how you write counts as well as what you say.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: whether past behavior shows the company's published values |
| EXP | Work-experience deep-dive: whether your CV claims survive scrutiny |
| JD | Role or JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, answered on the spot |

## Fit snapshot

The requirements are the ad's lines as you listed them in your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as you listed it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap in the quote's terms, but a CV line with nothing inspected behind it, so expect a probe. Lead with it as you wrote it: three years, customer service advisor, an energy supplier. The ad says customer support and your sentence says customer service advisor, and the words stay as you wrote them |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as you listed it | "I use Freshdesk every day" — your message | medium | [grounded] | none | The quote names Freshdesk, and the ad names Zendesk first and then leaves room for a similar tool. Say Freshdesk and say every day: "I use Freshdesk every day." Your material does not establish any other tool, so none goes in your words |
| F3 | "clear written communication" — job ad, as you listed it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote puts calls and emails together and says nothing about the writing itself. Answer slot: expect a probe on how your written replies stay clear. Say how you do it in your own words; if you have no set way of doing it, say so plainly and say what you would aim for in a reply |
| F4 | "confidence handling escalations" — job ad, as you listed it | none given | none | [grounded] | discovery | Your material says nothing about escalations. Answer slot: expect a probe on this line of the ad. If you dealt with contacts that had been escalated, say what you did in your own words; if there was no escalation step, or it was not yours, say so plainly and say how you would handle one |
| F5 | "Customer Support Specialist" at "Lumenvale Software" — the invite | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap your words already state, and the wording cannot close it. Say it plainly: "I've never worked for a software company." Then a plan for learning the product, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | A ticket or a customer message handed to you to answer live | High. The hiring-manager prior puts it first, and a support role's daily work is live tickets that a text chat can reproduce directly | Ask what you need to know, name the goal, then answer; think aloud in the chat |
| Skeptic | Quiet probing of the software-company gap and of what your material does not show | High. The same prior puts it first, F5 is a gap your own words state, and F4 is a silence the ad's wording will press on | Rehearse B1 until it is boring; hold only what your sentences carry; state limits before they are extracted |
| Conversational | Friendly openers such as the journey question | Medium. A chat opening is likely, and casual questions are still scored | A short arc built only from your own sentences; treat casual questions as scored |
| Pressure | Pushback on a reply, or a question about how much was you | Medium-low. The escalations line makes composure under pushback relevant, and the text format lets the lead challenge a reply directly | Pause, restate, hold a challenged position through two follow-ups, concede specifically |
| Values/Behavioral | Open prompts about customers and hard truths | Low. No published values were researched, and the invite documents no values round, so these prompts are generic | A selection scaffold that ends in the honest branch |

Prober and Peer get no bank: the one figure in your material is covered in B3, and the invite names a team lead, not a peer. The weights rest on the relationship prior and on the invite's own words: one session, a text chat with the support team lead.

## Question banks

### A. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same unresolved problem, and they are clearly annoyed. What do you reply, and what do you do with the ticket?" | CASE | [generic] | Structure it: acknowledge the repeat contact, say what you would check first, say what happens next and when, and say whether it needs someone beyond you. The question needs no claim about your past, so the guidance makes none | The live form of F4's escalations line; CASE because it asks for a decision, not a history |
| A2 | "You are handling a ticket you cannot solve with what you know. What do you do in the next ten minutes?" | CASE | [generic] | Structure it: what you would try yourself, who or what you would ask, what you tell the customer meanwhile. No claim about your past | F4's line again, asked from the angle of knowing your limits; CASE |
| A3 | "Two tickets arrive together: one customer cannot log in at all, another reports a cosmetic problem. How do you order them, and why?" | CASE | [generic] | Say what you would clarify first, what decides the order, and what each customer is told. No claim about your past | Tests judgment on a software-flavored problem, which bears on F5; CASE |
| A4 | "A customer writes: 'The export is broken and I need it in an hour.' Type me your first reply." | CASE | [generic] | Write it in the chat: acknowledge the deadline, say what you will check first, say when you will update them. Keep it short, and do not promise a fix or name a technical cause you have not been given | F3's written-communication line, tested live because the interview is in writing; CASE |
| A5 | "A customer demands a refund the policy does not allow. What do you say?" | CASE | [generic] | Structure it: hear the reason, state what the policy allows without arguing, offer what you can do, say whether anyone else needs to look. No claim about your past | A common support decision that tests tone and firmness together; CASE |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I see your background is at an energy supplier. What would be hardest about supporting a software product?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" and "I've never worked for a software company" | The highest-ROI prep in this pack, and the deepest rehearsal. Say it plainly: "I've never worked for a software company." Hold the quoted three years as a customer service advisor at an energy supplier. Then a ramp plan in your own words, said as a plan and never as something already done: how you would learn the product and who you would ask. Follow-up 1: "What would you do in your first two weeks?" Follow-up 2: "And if you were still stuck on a technical ticket in week four?" Concede specifically that the product is new to you, and do not concede that you cannot learn it. The limit, named before it is asked: your material shows no software-product experience | F5 is the biggest gap and the most predictable objection, so this arrives in some form; JD because it scores the ad's own context |
| B2 | "The role involves handling escalations. What have you owned in an escalation yourself?" | JD | [grounded] "answering around 60 calls and emails a day" | Answer slot: the ad's escalations line raises this probe. If you dealt with escalated contacts, say what you did in your own words; if there was no escalation step, or it was not yours, say so plainly and return to the quoted 60 calls and emails a day, at that scope | F4 is a silence in your material and this is where the ad presses on it; JD because it scores a stated requirement |
| B3 | "You mention around 60 calls and emails a day. How was that figure counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Keep the quote's own hedge: around 60, calls and emails together. Answer slots: how you know the figure, what it would change with, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Never give a split between calls and emails you were not given | A headline figure on a CV draws a defend-the-number question; EXP because it tests attribution |
| B4 | "Tell me about training those four new starters on refunds." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell it with the beats the sentence states: four new starters, your refunds process, last year, and that you trained them. Use your own words for the rest, and add no detail the sentence does not carry | F1's adjacent evidence and the likeliest story the lead will ask to hear; EXP because it tests what was actually yours |
| B5 | "Why customer support at a software company, and why now?" | EXP | [generic] | Give your actual reason, in your own words. Your material states none, so the pack supplies none. If you have no reason beyond wanting the role, say so plainly and say what you hope to learn | Motivation consistency is the Skeptic's standard question; EXP because it tests your own account of your move |

### C. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier", "I use Freshdesk every day" and "I trained four new starters on our refunds process last year" | A short arc built from those sentences and no more: three years as a customer service advisor at an energy supplier, Freshdesk every day, four new starters trained on refunds last year. End with why this role, in your own words | The usual chat opener, and the arc is where F1, F2 and the training evidence meet; EXP |
| C2 | "What do you actually use day to day for tickets?" | JD | [grounded] "I use Freshdesk every day" | Say it is Freshdesk and that you use it every day. Answer slot: the ad names a different tool first, so expect a probe on any other tool. Say which others you have used, in your own words; if Freshdesk is the only one, say so plainly | F2's requirement asked casually; JD because it scores a stated tool |
| C3 | "Have you had a look at our product yet?" | CO | [generic] | Say what you have actually looked at. Nothing in this pack is researched, so it supplies no facts about the company or the product. If you have not looked yet, say so plainly and say what you would look at first | A casual homework check that is still scored; CO because it tests how you came to the company |

### D. Pressure (weight: medium-low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You trained four people on refunds. How much of that was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold the sentence at its own scope: you trained four new starters on the refunds process last year. Hold it through two follow-ups. Concede specifically if someone else shared the training or set the process, and say so plainly; do not concede the training itself. The limit, named before it is asked: your material says you trained them, and nothing about who else was involved | The attribution probe is built to catch inflation; EXP because it tests what was yours |
| D2 | "Sixty seconds: why you over someone who already works in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier", "I use Freshdesk every day" and "I've never worked for a software company" | Hold what the quotes carry: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Concede plainly: "I've never worked for a software company." Do not claim to be stronger than a candidate you have not met | F5's gap in its harshest form; JD because it scores fit against the role |
| D3 | "That reply is too long. Redo it in two sentences." | CASE | [generic] | Pause and restate what you were asked. Cut to the next step and the time you will update, and keep the acknowledgment. Concede that the first version was long without folding on the content. No claim about your past | F3's writing line under pressure in the interview's own medium; CASE |

### E. Values/Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time you faced that choice: it needs a named stake, what you chose, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard customer-versus-metric prompt; no published values were researched, so VAL here is generic behavioral |
| E2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time you told someone senior something unwelcome: it needs what the truth was, how you said it, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard hard-truth prompt; VAL because it scores behavior, generic because no values were found |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| "2+ years in customer support" | B1, C1, D2 |
| "experience with Zendesk or a similar ticketing tool" | C2 |
| "clear written communication" | A4, D3, B3 |
| "confidence handling escalations" | A1, A2, B2 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "Which team and tools would I work in, and who would I report to?" | It shows you are weighing the job, and the answer fills in the part of the role the invite leaves open |
| R2 | "How are escalations handled here, and who owns them?" | It follows the ad's escalations line and shows you are thinking about the work itself |
| R3 | "What does good look like in the first month?" | It turns the interview toward what success looks like, which is the interviewer's own scoring |
| R4 | "How does the team judge a good written reply?" | It ties to the ad's written-communication line and shows you care about the standard |
| R5 | "After this chat, what are the next steps, and will any offer come as a written contract I can read before agreeing?" | A plain process question; a clear answer is useful whoever you are talking to |
| R6 | "Could we confirm the next step by email from a company address?" | A reasonable request that helps you check who you are dealing with; it costs the real employer nothing |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has Zendesk experience | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material says Freshdesk, not Zendesk |
| Has worked in a software or SaaS support team | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |
| Designed or ran a refunds training programme | Inflated form of the training sentence in B4 | The quote at its own scope: "I trained four new starters on our refunds process last year." The limit is the pack's observation: your material says you trained them, not that you built the programme |
| Handled exactly 60 contacts a day, or a stated split between calls and emails | Inflated form of F3's figure | The quote at its own scope: "answering around 60 calls and emails a day." The limit is the pack's observation: the figure is hedged and the split is not given |

## Sources

Provided documents: the invite message, and your own description of the ad and your background. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent: "Lumenvale Software values" refused; "Lumenvale Software interview process customer support" refused; "Lumenvale Software news strategy" refused. Nothing in this pack is researched.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | The search was refused. It would have fed a values cheat sheet if a values round were documented, and the VAL bank |
| 2. `Lumenvale Software interview process customer support` | unavailable | The search was refused. It would have checked the loop and the persona weights, which rest on the invite's own words and the hiring-manager prior |
| 3. `Lumenvale Software strategy` or recent news | unavailable | The search was refused. It would have fed the CO bank, which holds one generic question, C3 |
| 4. `{interviewer name} Lumenvale Software` | n/a | No interviewer name was given, only the title support team lead, so there was no query to form |
| 5. representative `Customer Support Specialist` JD | skipped | The four ad lines you listed fix the fit snapshot and the JD-tagged questions |

The persona weights rest on a relationship prior and on the invite's own words, not on a documented loop for this company.

## Upgrade menu

- The ad's full text → the four requirement rows quote the ad itself instead of your summary of it, and any line you did not list gets a row and a question
- The support team lead's name and your relationship to them → a tailored interviewer read, persona weights adjusted to a manager or a peer, and a reverse question tied to their path
- Any focus areas or process details the recruiter gave you → coverage of what they will actually test
- Permission to search the web → researched values, loop, and recent company news, which would replace C3's generic footing and could add a values cheat sheet
- An answer on escalations or on how you keep written replies clear → F3 and F4 upgrade from answer slots toward quoted evidence
- A tuesday-dossier.md → verified evidence and objections carried between sessions; none is needed to use this pack
