The web searches were refused, so I'm building the pack from your message only. I'm saving it now.
Before the prep, one thing in the invite. It says the process is "carried out entirely on Telegram", that your interview "will be a text chat here with our support team lead", and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern. Because the offer and onboarding happen in the same chat, any request for money, documents or bank details would also arrive there. Until the invite is checked, hold off on paying anything, depositing a cheque, or sending documents or bank details. Check it with Lumenvale using contact details you find yourself, such as the careers page you applied through. Don't use the chat or the sender's number for the check. The message may not come from who it names. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `lumenvale-software_customer-support-specialist_interview_pack.md`, in the working directory. I built it for a hiring-manager-style round, since the invite doesn't say whether the support team lead would manage you. My web searches were refused, so it uses only what you told me, and the research rows in its Sources section say so.

The biggest rehearsal item is B1, the question about never having worked for a software company. Your answer is to say that plainly and follow it with a plan for learning the product.

Say the word and I'll play the Skeptic on B1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Who is the support team lead to you, and what, if anything, were you told about what the chat will cover? Can you paste the full job ad and your CV, or shall I carry on without them?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview pack: Customer Support Specialist, Lumenvale Software

Interviewer: the support team lead (name not given). Round: one text chat on Telegram, per the invite. Relationship to you: not stated, so this is built as a hiring-manager-style round.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and rehearse only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the company's published values |
| EXP | Work-experience deep-dive: do the claims about your past survive scrutiny |
| JD | Role or job-ad driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem set in the role, answered on the spot |

Answer slots in the guidance are instructions for the interview, not questions for you. Where one offers two branches, either branch is a good answer if it is true.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad, as you described it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap, but a line in a message with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: the role, the three years, around 60 calls and emails a day. The figure raises the defend-the-number questions in D1 and D2 |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad, as you described it | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | The words stay at the quote: "I use Freshdesk every day." Answer slot: the ad names Zendesk, so expect a probe on it. If you have used Zendesk, say where and for how long; if not, say so plainly and stay with Freshdesk |
| F3 | "clear written communication" — the ad, as you described it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Answering emails touches written communication without showing whether it was judged clear, and the interview itself is a written sample. Answer slot: if any of your written replies were reviewed, scored or praised, say what and by whom; if none were, say so plainly and stay with the emails you answered |
| F4 | "confidence handling escalations" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show escalations either way. Answer slot: the ad names escalations, so expect a probe. If escalated cases came to you or you passed cases on, say how it worked, in your own words; if that was not part of your job, say so plainly and say how you would approach one |
| F5 | Familiarity with supporting a software product: the employer is a software company, and this is a role-family expectation, not a line in the ad as you gave it | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan in the future tense and never as a past. Never a claim to software-support work, and nothing added to make the gap feel smaller |
| F6 | Helping teammates and new starters learn the work: a role-family expectation, not a line in the ad as you gave it | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | No gap, and the row raises no probe by itself. If asked, the sentence stays at its own scope: you trained four new starters on the refunds process. The figure raises the which-part-was-yours question in E2 |

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live support scenarios typed into the chat: an angry customer, an escalation note, a rewrite | Highest. The hiring-manager prior is Case plus Skeptic, and a support team lead can set live problems quickly in a text chat | Clarify before answering, then structure: acknowledge, find out, act, tell the customer what happens next |
| Skeptic | Quiet probing of the software gap, escalations and why this move | Highest. Same prior, and F4 and F5 are the thinnest rows | Rehearse B1 until it is boring: plain acknowledgment, then a plan in the future tense |
| Conversational / Rapport Builder | Friendly openers such as "walk me through the journey" | Medium. A chat opening usually starts here, and these questions are still scored | A pre-built arc from your own sentences; treat casual questions about Freshdesk and writing as scored |
| Data-Driven Prober | Pulls on "around 60 calls and emails a day" and "four new starters" | Medium. The figures are the easiest lines in your message to test | Know how each figure was counted, and say plainly when you do not know |
| Pressure | Time-boxed "why you" and "how much was actually you" | Lower. Possible but not signalled by anything in the invite | Pause, restate, hold the sentence through two follow-ups, concede one specific limit |

Persona weights rest on the invite's own words: one session, a text chat with the support team lead. The invite names no values round, so there is no values cheat sheet.

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in, frustrated: the app keeps logging them out and they have lost work. What do you write back first, and what do you want to know before you answer properly?" | CASE | [generic] | Structure it: one line that acknowledges them; what you need to find out, as questions (what they were doing, what they saw, when it started); what happens next and when they will hear back. Keep it short enough to read on a phone. The question needs no claim about your past, so the guidance makes none | A software-product problem, the setting where F5 is thinnest, asked as reasoning rather than product knowledge. CASE because it is live |
| A2 | "A customer says they want someone more senior and will cancel today. You cannot fix it yourself. Write the note you would hand to the team lead." | CASE | [generic] | Structure the note: who the customer is and what they want; what has already been said and tried in this conversation; what you need from the lead and by when; what you told the customer. The question needs no claim about your past, so the guidance makes none | The ad's escalation line (F4) in live form, so you can show the handover without a story. CASE because the scoring is the structure of the note |
| A3 | "Make this reply clearer: 'Unfortunately we are unable to process your request as it falls outside our policy.'" | CASE | [generic] | Say what you can do first, say what happened in plain words, give the next step, and keep the tone warm without padding. Type a short rewrite, then one line on what you changed. The question needs no claim about your past, so the guidance makes none | The ad's written-communication line (F3), tested live in the same channel as the interview. JD content, CASE delivery |
| A4 | "Monday morning: forty tickets in the queue, one customer has chased three times, one report might be an outage, and a colleague asks for help. What do you do first, and why?" | CASE | [generic] | Separate urgent from important aloud; say your first move and the reason; say what you would tell the chasing customer and the colleague; say who you would tell about the possible outage. The question needs no claim about your past, so the guidance makes none | A queue-prioritisation problem is the everyday shape of the job the ad describes. CASE because it scores structure under load |
| A5 | "A customer asks whether something is a bug or whether they are using the product wrongly, and you do not know the product well enough to say. What goes in your next message?" | CASE | [generic] | Say plainly what you do not know yet, what you are doing to find out, and when they will hear back. Do not guess to sound confident. The question needs no claim about your past, so the guidance makes none | F5 in live form: the interviewer sees how you behave at the edge of your product knowledge. CASE because it asks for the message itself |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have not worked for a software company before. How would you get up to speed on our product?" | JD | [grounded] "I've never worked for a software company" | The highest-ROI rehearsal in this pack. Level one: "I haven't worked for a software company." Then your plan, in your own words and the future tense: what you would learn first, how you would check you had it, who you would ask. Follow-up "what makes you think you would pick it up quickly": do not argue a trait; return to the plan and let the interviewer judge it. Follow-up "our customers are more technical than yours": if you do not know how technical Lumenvale's customers are, say so plainly and say you would find out early; never claim the customers are similar. Never imply software-support work | F5 is where this role presses hardest, so the objection arrives in some form. JD because it scores a stated gap, and the deepest rehearsal because the stated negative gives the answer a sourced starting point |
| B2 | "The ad asks for 2+ years in customer support. Your three years were at an energy supplier. What carries over to a software company's customers?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Hold the sentence's own terms: the role, the three years, the volume and the channels, and leave the mapping to the interviewer. Answer slot: if you know how Lumenvale's customers differ from yours, say what you know and where you learned it; if you do not, say so plainly and say what you would ask the team lead | F1 meets the years requirement, and the probe is about transfer. JD because it scores the stated requirement |
| B3 | "The role asks for confidence handling escalations. Tell me about a time you dealt with one." | JD | [grounded] | Selection scaffold: pick one case that was passed up or came to you; it needs what the customer wanted, what you did yourself, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 has no evidence in the material, and the ad's own wording raises the probe. JD because it scores a stated requirement; an open prompt, so it supplies no event |
| B4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Choose honestly. Your message names one candidate, the software gap: say it plainly and add the first step you would take. If something else is weaker for you, say that instead. Do not pick a made-up weakness | The standard Skeptic stem, and F5 and F4 are the likeliest answers. JD because it scores honest self-assessment against the ad |
| B5 | "Why customer support, why software, and why now?" | EXP | [generic] | Slot: give your actual reasons, in your own words. Nothing in this pack supplies them. If one of the three has no strong reason, say that plainly rather than inventing one | Motivation consistency across a sector change. EXP because it tests whether the career story holds together |

### C. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | A three-beat arc from those sentences: the role and the three years, with around 60 calls and emails a day; Freshdesk every day; the four new starters on the refunds process. The fourth beat is yours, why this role, in your own words. In a text chat, three short paragraphs read better than one long one | The usual opener, and it is scored. F1, F2 and F6 are the sentences the arc can rest on. EXP because it tests the story's coherence |
| C2 | "How are you using Freshdesk day to day?" | JD | [grounded] "I use Freshdesk every day" | The beat is the quote. Answer slot: the ad asks for a ticketing tool, so expect a probe on which parts you rely on. If there are parts you rely on, say which and what for, in your own words; if there is nothing more to say, say so plainly and stay with the fact that you use it every day | F2 is the evidence for the ticketing-tool requirement. JD because it scores a stated requirement in casual register |
| C3 | "Customers will read what you write. How do you keep a written reply clear?" | JD | [grounded] | Answer slot: the ad asks for clear written communication, so expect this probe. If you have a way of checking a reply before it goes, say what it is, in your own words; if you do not, say so plainly and say what you would do. This chat is itself a sample of your writing | F3 is a thin row and the channel is written, so the question is likely. JD because it scores a stated requirement |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You say around 60 calls and emails a day. How was that number counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Keep the figure at its own scope: "around", and both calls and emails. Say how it was counted, in your own words, or say plainly that you do not know how it was counted. Say which part of it was yours. Say what the figure does not tell you, if you know | F1's figure is the line most open to a probe. EXP because it tests whether the claim survives scrutiny |
| D2 | "What would have moved that number up or down?" | EXP | [grounded] "answering around 60 calls and emails a day" | Name the assumption you would defend least before the interviewer does, in your own words. If you do not know what moves it, say so plainly and stay with "around 60 calls and emails a day" | The second level of probing on F1. EXP because it tests the sensitivity of the figure |
| D3 | "Walk me through a normal day in that job." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | The beats the sentence states: advisor at an energy supplier, calls and emails, around 60 a day. Anything beyond that is your own account of your own day, told truthfully; add no routine you could not stand behind under a follow-up | F1 is the only description of the day in your material. EXP because it checks the line against how you tell it |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I've never worked for a software company" | Hold, then concede. Hold what the quotes carry: the three years as a customer service advisor at an energy supplier, around 60 calls and emails a day, and Freshdesk every day, with no comparison to other candidates. Hold it through two follow-ups by returning to those sentences. Concede once, specifically: "I haven't worked for a software company." Do not fold on the three years | F5 makes this the pressure version of B1. JD because it scores fit against the ad under time pressure |
| E2 | "You say you trained four new starters. How much of that was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold, then concede. Hold the sentence: "I trained four new starters on our refunds process last year", and return to it through two follow-ups. Slot: say which part was yours, in your own words; if someone else set or ran any part of it, say which part, plainly; if you ran all of it, say that and stay with the sentence | F6's figure and verb are the attribution probe's target. EXP because it tests what was actually yours |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| "2+ years in customer support" | B2, C1, D1, D2, D3 |
| "experience with Zendesk or a similar ticketing tool" | C2 |
| "clear written communication" | A3, C3 |
| "confidence handling escalations" | A2, B3 |
| Familiarity with supporting a software product | A1, A5, B1, B4, E1 |
| Helping teammates and new starters learn the work | C1, E2 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like for someone in this role?" | It signals you are thinking about delivery, and the answer tells you what the team measures first |
| R2 | "Which kinds of tickets reach you, and which do you expect me to resolve myself?" | It shows you think about where the escalation line sits, which is the ad's own wording |
| R3 | "How would I learn the product in my first weeks: training, shadowing, a knowledge base?" | It turns B1's learning plan into a conversation and shows the gap is something you are already planning for |
| R4 | "How does the team judge whether support was good: response time, resolution, customer feedback?" | A support lead hears this as interest in the job's real measure |
| R5 | "What do the strongest people on the team do that is hard to see from the outside?" | It invites a candid answer rather than a pitch, and it gives you something to take away |
| R6 | "What are the next steps after this chat, and who from Lumenvale will be in touch, and how?" | An ordinary process question, and the answer is the information you need about how the rest of the process runs |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked for or supported a software company | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't worked for a software company." No slot |
| Resolved around 60 cases a day | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says answering calls and emails, not resolving cases |
| Ran the new-starter training programme | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: the material says you trained four new starters on the refunds process, not that you designed a programme. E2's slot stays inside the sentence |

## Sources

Provided documents: your message, which holds the invite's text, your summary of the ad's requirements, and your background. No CV and no full ad text were provided. The loop is established by the invite's own words: one session, a text chat with the support team lead.

Searches sent, all refused, so nothing from outside your message is used:

- `Lumenvale Software values` — refused
- `Lumenvale Software interview process customer support` — refused
- `Lumenvale Software strategy news` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Search refused. It would have supplied value names for VAL-themed questions; none are in this pack |
| 2. `Lumenvale Software interview process customer support` | unavailable | Search refused. It would have checked the loop against a documented one; the loop here rests on the invite's words |
| 3. `Lumenvale Software strategy` / recent news | unavailable | Search refused. It would have fed a CO question; the pack has none and relies on CASE questions |
| 4. interviewer name and company | n/a | The invite does not name the support team lead, so there was no query to form; the interviewer read is absent |
| 5. representative Customer Support Specialist JD | skipped | The ad's requirements, as you described them, fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full text of the ad → the four requirement rows quote the ad itself instead of your summary, and any requirement you did not mention gets a row and a question
- Your CV → F1, F2 and F6 quote it, and a performance review or customer-satisfaction report that covers your volume is the artifact that could raise F1 above medium
- Your own account of any escalated case → F4 gets a mapped story and B3 becomes story-mapped instead of a selection scaffold
- Whether you have used Zendesk → C2 and F2 stop being a slot
- Who the support team lead is to you, and their name → persona weights are reweighted from that and the interviewer read, and a reverse question can be tied to their path
- Lumenvale's own careers page, pasted, or search access → values, loop and a CO question, all from the company's own material; a deeper research pass would add up to 6 more searches and 2 more fetches, several more minutes
- A `tuesday-dossier.md` from an earlier session → verified evidence and any stated limits would sharpen the banks without being required
