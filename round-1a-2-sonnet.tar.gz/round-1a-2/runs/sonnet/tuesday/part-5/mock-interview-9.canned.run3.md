Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/tuesday/part-5/rooms/case-9-canned-c07b6ea6/Halvering_fourth-grade-teacher_interview_pack.md`.

I built it for the 45-minute panel the district's hiring page describes: the principal plus two grade-level teachers. I don't have Halvering's own posting, so the duties come from the invite, the district's published pages and a typical fourth-grade posting, marked `[inferred]`.

Your SSN isn't needed for any of this. I didn't use it and left it out of the pack. I also kept your license number out of the pack and every search.

The pack has 21 questions across seven personas, plus reverse questions, a prohibited-claims table and a prep triage. Two things are worth knowing before you open it:
- **The fourth-grade gap:** your own statement that you've never taught fourth grade is the likeliest objection. A1 is the deepest rehearsal, and it opens with the plain acknowledgment "I haven't taught fourth grade."
- **Team lead:** you said you've never been a team lead, so your 2024 curriculum move stays at "I led our grade level's move." The pack never turns it into leading the team.

Your license (an active Illinois PEL with an elementary endorsement for grades 1–6, through June 30, 2029) matches the invite's one stated requirement. I haven't inspected it, so checking your own record is yours to do.

Say the word and I'll play the Skeptic on A1, the question the pack names as your highest-ROI prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste Halvering's own posting for this job, if you have it? It would turn several `[inferred]` rows into `[grounded]` ones.

Do you want a deeper research pass, with up to 6 more searches and 2 more fetches and several more minutes, on the district's strategy, the principal's talks and recent changes?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Employer:** Orrinsford Community School District
**Round:** one 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given)
**Relationship read:** hiring manager (the principal) plus peers (two fourth-grade teachers)

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored. The five type tags: **VAL** (behavior that shows the district's published beliefs), **EXP** (your experience holds up under follow-up), **JD** (the stated duties and the role), **CO** (knowing the district and its plans), **CASE** (a live problem set in the role).
- Guidance is scaffolding, not a script. Every sentence in quotation marks that describes your past is one you wrote. Answer slots (the instructions that begin "Answer slot") are for the interview itself: they ask nothing of you here.
- Fit-snapshot rows are F1 to F9. Question IDs are letters by persona, with no F bank, so an F-number always means a fit row.

## Prep triage

Work in this order, aloud, before Thursday. Everything else in the pack is insurance.

1. A1, the highest-ROI rehearsal: the fourth-grade objection, until it is boring.
2. E1, your 90-second arc, using only the beats it names.
3. G1 and H1: what was yours in the 2024 curriculum move, said at the scope of your sentence.
4. C2 and reverse questions RQ1 to RQ3: the district's literacy plan and the principal's reading background.
5. D1 to D3: pick your three real stories, or note plainly that none comes to mind.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Your material shows this gate met: an Illinois PEL with an elementary endorsement for grades 1–6, registered and active through June 30, 2029. Nothing was inspected here, and checking your own record is yours to do. Words: "I hold an Illinois Professional Educator License with an elementary endorsement for grades 1–6, active through June 30, 2029." The license number is not needed and is left out |
| F2 | "Fourth Grade Teacher position" — the invite | "I've never taught fourth grade and I've never been a team lead." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would learn it, said as a plan and never as a past. Your third-grade work is separate evidence at its own scope: see F3 |
| F3 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board representative posting | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | discovery | Your quote gives the grade and the years, not the subjects, and the bridge stays there. Answer slot: the representative posting lists five subjects, so expect a probe on which you taught. If you taught several, say which, in your own words; if you taught only some, or a different split, say so plainly and stay with the six years in third grade |
| F4 | "differentiate instruction using assessment data" — K12 Jobs Board representative posting | none given | none | [inferred] | discovery | Your material does not speak to assessment. Strong evidence would be one concrete instance of changing teaching after looking at results. Answer slot: the district's beliefs page says assessments inform teaching and never replace it, so expect a probe. If assessment results changed what you taught, say what and how, in your own words; if they did not, or it was not yours to decide, say so plainly and say how you would start |
| F5 | "keep clear classroom routines" — K12 Jobs Board representative posting | none given | none | [inferred] | discovery | Your material says nothing about routines, and the district's hiring page says panels ask about classroom routines. Strong evidence would be one routine you can describe in under a minute. Answer slot: if you keep routines, say what they are in your own words; if part of the day has no settled routine, say so plainly and say what you do instead |
| F6 | "communicate regularly with families" — K12 Jobs Board representative posting | "I write a weekly email to families." — your CV | medium | [inferred] | none | No gap, but a CV line with nothing inspected behind it, so expect a probe on it. Lead with it in the quote's own terms: you write a weekly email to families. Add nothing about its content, replies or results |
| F7 | "Families Are Partners: each teacher speaks with every family each term" — Orrinsford beliefs page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | Your quote is a weekly written email, not conversations, and the words stay there: "I write a weekly email to families." Answer slot: the belief says teachers speak with every family, so expect a probe on conversations. If you also speak with families, say how and when, in your own words; if you do not, or it was not yours to arrange, say so plainly and stay with the weekly email |
| F8 | "work with the grade-level team" — K12 Jobs Board representative posting | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [inferred] | transferability | Your quote is a move at grade level that you led, and the words stay there: "In 2024 I led our grade level's move to a new reading curriculum." It does not say what working beside teammates day to day looks like. Answer slot: expect a probe on how that move was run and which part was yours. Say which parts, in your own words; if a part was not yours, or there was no such step, say so plainly and return to the move |
| F9 | "Panels ask about reading instruction" — Orrinsford hiring page | "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years." — your CV | medium | [grounded] | transferability | Your quotes are a curriculum move and a club, not the daily teaching of reading, and the words stay at those scopes. Answer slot: expect a probe on how you teach reading. Describe what you actually do, in your own words; if part of the move or the club was not yours, say so plainly and return to the part that was |

## Persona table

Relationship priors for a panel blend the top two personas of each member's relationship. The principal reads as hiring manager and the two teammates as peers. The district's hiring page establishes this loop: one 45-minute building panel of the principal and two grade-level teachers.

| # | Persona | How it shows up here | Weight and reasoning | Counter-strategy |
|---|---|---|---|---|
| A | Skeptic | Quiet probing of the fourth-grade gap and the team role | Highest. Hiring-manager and panel priors put it in the top two, and F2 is a gap you stated | Rehearse the A1 objection until it is boring; bridge only from the adjacent quotes you gave; concede plainly |
| B | Peer Evaluator | Teammates asking what working beside you would be like | High. The peer prior, and the invite names two fourth-grade team members | Reciprocity framing: what you would bring, not only what you need; seam principles, not a pretended knowledge of their seam |
| C | Case/Strategist | The principal posing a classroom scenario or asking about the literacy plan | Medium. Hiring-manager prior; the hiring page says panels ask about reading instruction, classroom routines and families, and the principal's public footprint centers on reading | Clarify first, think aloud, use the district's own words |
| D | Values/Behavioral | Open prompts themed on the three beliefs | Medium. No values-style round is detected: the hiring page names reading instruction, routines and families, not a values round. The beliefs page says the beliefs guide every hire, so themed prompts are plausible. No values cheat sheet is built | A selection scaffold ending in the honest branch; "we" for context, "I" for contribution |
| E | Conversational | The opener "walk me through the journey" and casual questions about reading | Medium. Panels commonly open this way, and casual questions are still scored | A pre-scripted 90-second arc; never answer the reverse-question slot with "I think you've covered everything" |
| G | Data-Driven Prober | Teammates reading your CV line by line | Low. Your CV lines carry few figures, so the probing lands on what you actually did | Know what you can and cannot say about each line; say plainly when you do not know |
| H | Pressure | A time-boxed "why you" or "how much was actually you" | Low. Nothing in the sources suggests a stress style; two items are included so the style is not met cold | Pause, restate, hold a position through two follow-ups, concede specifically |

## Reading the interviewer

Public professional footprint only, for the principal. The two teammates are unnamed, so nothing is read for them.

| Fact or implication | Source or derivation | Provenance |
|---|---|---|
| Dolores Vantongeren has been principal of Halvering Elementary School since 2022, after nine years as a reading specialist | ilprincipalsforum.example speaker page | [grounded] |
| Her 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5 | ilprincipalsforum.example speaker page | [grounded] |
| Reading is the ground she has worked longest, so expect depth on how you teach reading; plain descriptions of what you actually do will hold up better than polished ones | Derived from the two rows above | [inferred] |
| The themes of a published talk tend to return as questions, so expect reading groups and conferences to come up; grades 3 to 5 includes fourth grade | Derived from the talk row | [inferred] |
| Mirror opportunity, shared professional ground: reading. Pair her reading-specialist path with F9's "I led our grade level's move to a new reading curriculum in 2024", at its own scope and nothing wider | F9 evidence cell; her path from the first row | [inferred] |

## Question banks

### A. Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. What do you expect to be hardest in your first month, and how will you handle it?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." "Six years teaching third grade at a public elementary school in Joliet." | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't taught fourth grade." Then the adjacent fact at its scope: "I've taught third grade for six years at a public elementary school in Joliet." Then name the one thing you honestly expect to be hardest and say what you would do about it as a plan, in the future tense, never as something already done. A follow-up will ask for more detail on the plan: add only steps you would really take. A second follow-up will test whether a teacher who has taught the grade is the safer hire: hold by returning to those two sentences, and concede the real difference plainly, that you have not taught the grade, without adding a claim to close it. If no hardest part comes to mind, say so plainly and say how you would find out in your first weeks | F2 is the largest gap and the panel includes fourth-grade teammates, so this objection will arrive in some form. JD because it scores the stated role |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." | Choose the part that is truly weakest rather than a safe one. If it is the grade, the plain acknowledgment is "I haven't taught fourth grade." If it is something else, say it in your own words and stay inside what your material carries. Whatever you choose, close with what you would do in week one, as a plan. If no part comes to mind, say so plainly and say what you would ask the team in your first week | F2 and F8 are where the material is thinnest. JD because it asks you to read the job against yourself |
| A3 | "You haven't been a team lead. How do you see your role on a grade-level team?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." "I led our grade level's move to a new reading curriculum in 2024" | Open with the plain acknowledgment: "I haven't been a team lead." Then the move at its own scope: "In 2024 I led our grade level's move to a new reading curriculum." Describe the teammate you want to be in your own words, and only what you can show. Answer slot: expect a probe on how the move was run and which part was yours. Say which parts, in your own words; if a part was not yours, or there was no such step, say so plainly and return to the move. Never turn the move into leading the team | The team requirement in F8 meets a stated negative in F2. JD because it scores the stated team duty |
| A4 | "Why fourth grade, and why now?" | JD | [generic] | Your material states no reason, so the pack supplies none. Selection criteria: one reason about the grade and one about this school, each something you can say without a follow-up exposing it, in under 60 seconds. Any fact you cite about the district should be one you have read, such as the board's August 2026 literacy plan in Sources. If you cannot name a reason about this school yet, say so plainly and say what you have read about it so far | Motivation consistency is what a skeptic scores, and F2 makes the question likely. JD because it concerns the stated role |

### B. Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What would you want from the team in your first month, and what could you bring?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I write a weekly email to families." "I've run the after-school reading club for the last two years." | Reciprocity framing, in two halves. What you would want: your own short list of asks, said as asks, not as needs. What you could bring: pick from your quotes and say them at scope, for example "I've run the after-school reading club for the last two years" or "I write a weekly email to families". Say nothing about their results or reception | F8 and F9 carry what you can offer a team. JD because it scores the work-with-the-team duty; the reciprocity half is the peer persona's test |
| B2 | "Where do you draw the line between what you decide in your own classroom and what the team decides, and what do you do when you disagree with a teammate?" | JD | [generic] | Offer seam principles, not a claimed knowledge of their seam: say you would ask how the team splits it now, and say how you would raise a disagreement. For a disagreement story, use selection criteria: a real disagreement with a colleague, what you did, and the relationship intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Peers price the cost of a new teammate. F8 gives no evidence of day-to-day teamwork, so the answer rests on principles. JD because it scores the team duty |
| B3 | "How do you handle credit when work spans teachers or grade levels?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Use "we" for context and "I" for contribution. If you use the move, "our grade level's move" is the context and "I led" is your part, at the quote's scope. Answer slot: if you shared credit for part of it, say how, in your own words; if there was nothing to share, or the credit was not yours, say so plainly and return to the move | A standard credit probe from peers, aimed at F8's thin bridge. JD because it scores working with the team |
| B4 | "Walk us through the first ten minutes of a normal morning in your classroom." | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet." | The hiring page says panels ask about classroom routines, and the representative posting lists keeping clear routines. Your quote gives only the six years, so describe the morning as it actually runs, in your own words. Answer slot: if you have a settled routine for that part of the day, say what it is; if you do not, say so plainly and say what you do instead | F5 has no evidence, so this is a discovery gap and the answer comes from you. JD because routines are a listed duty |

### C. Case/Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A fourth grader is reading well below grade level in September, and you have two weeks before the first family conversation. What do you do first?" | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Structure: clarify first (what do we already know about this reader, from which results), then the objective, then a plan for the child, then how you would speak with the family, then how you would check progress. Use the district's own words where they fit: "Every Child a Reader", and "assessments inform teaching and never replace it" | A live problem built from the district's published beliefs and F4's requirement. CASE because it tests structure and reasoning |
| C2 | "The board adopted a literacy plan in August 2026, with a new grades 3–5 reading curriculum from fall 2027 and a family reading night each term. How would you get ready for that as a fourth-grade teacher?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | State the plan's facts as the board published them (see Sources), then your own experience at its scope: "In 2024 I led our grade level's move to a new reading curriculum." Do not say it was the same curriculum or that it prepared you for this one. Answer slot: expect a probe on what your move involved and how it compares. Say what part was yours, in your own words; if it does not compare, say so plainly and say how you would learn the new curriculum | A differentiator question grounded in current strategy, with F9 as the bridge. CO because it tests homework depth |
| C3 | "This role teaches reading, writing, math, science and social studies. What has your teaching covered?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet." | Say the quote at its scope: "I've taught third grade for six years at a public elementary school in Joliet." Answer slot: say which subjects you taught, in your own words; if you taught only some, or a different split, say so plainly and stay with the six years | F3 is a discovery gap, so the answer comes from you. JD because it scores the listed duty |

### D. Values/Behavioral (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Families Are Partners. Tell me about a time you built a partnership with a family." | VAL | [grounded] "I write a weekly email to families." | No quote carries a partnership story, so this is a scaffold. Pick an instance from your own work with a named stake, what you did, and a relationship intact afterward. You may name the email at its scope: "I write a weekly email to families." If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is the weekly email, or how you would handle it | The first belief on the district's page that touches your material is F7. VAL because it maps to a published belief |
| D2 | "Every Child a Reader. When have you helped a student who was behind in reading?" | VAL | [grounded] "I've run the after-school reading club for the last two years." | No quote carries a student story, so this is a scaffold. Pick a student and a moment you can describe without adding to it: what you saw, what you did, what you can truthfully say happened. The club can be named at its scope: "I've run the after-school reading club for the last two years." Do not say it helped struggling readers unless that is true and you can say how. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The belief names reading and your third-grade work sits next to it (F9). VAL because it maps to a published belief |
| D3 | "Teach for Tomorrow, Not for the Test. Tell me about a time assessment results changed what you taught." | VAL | [grounded] | The guidance makes no claim about your past. Selection criteria: one real instance, what the results showed, what you changed, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. Do not describe a change you did not make | F4 has no evidence, so this prompt is where a probe lands. VAL because it maps to a published belief |

### E. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." | A 90-second arc using only beats your quotes state, in this order: your Illinois license with the elementary endorsement for grades 1–6, active through June 30, 2029; six years teaching third grade at a public elementary school in Joliet; in 2024 you led your grade level's move to a new reading curriculum; for two years you have run the after-school reading club. Close with why this role, in your own words. Say nothing the quotes do not say | The opener is scored even when it feels casual, and it also states the F1 license in its own terms. EXP because it tests whether the story is yours |
| E2 | "What are you actually playing with in reading these days?" | JD | [grounded] "I've run the after-school reading club for the last two years." | Name the club at its scope. Answer slot: if you are trying something in reading now, say what, in your own words; if you are not, say so plainly and say what you would like to learn | The hiring page says panels ask about reading instruction (F9), and a casual register still scores it. JD because it asks about a listed topic |
| E3 | "How do you like to communicate with families?" | JD | [grounded] "I write a weekly email to families." | Say it as written: "I write a weekly email to families." Answer slot: the district's belief says teachers speak with every family each term, so expect a probe on conversations. If you also speak with families, say how and when; if you do not, or it was not yours to arrange, say so plainly and stay with the weekly email | F6 and F7 together. JD because it scores the listed duty |

### G. Data-Driven Prober (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through the 2024 reading curriculum move. What did you actually do?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on F8 and F9: the grade level's move, the new reading curriculum, the year 2024, and "I led" at the quote's scope. Answer slot: expect probes on how the move was run and which part was yours. Say which parts, in your own words; if a part was not yours, or there was no such step, say so plainly and return to the move you led | The most probe-able line on the CV. EXP because it tests attribution |
| G2 | "Tell me about the reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years." | Describe it in your own words, at the scope of the quote: after school, a reading club, run by you for two years. Add nothing you could not repeat under a second question, and where you do not know a detail, say so plainly | F9's second quote, offered by the CV and therefore open to the probe. EXP because it tests what you actually did |

### H. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold-then-concede. Pause and restate the question. Hold the position at the quote's scope, "I led our grade level's move to a new reading curriculum in 2024", through two follow-ups by returning to that sentence. Concede specifically: say plainly which parts were yours and which were not, in your own words. Never fold on the sentence just to restore harmony, and never widen it to hold | Attribution probes exist to catch inflation, so the rehearsal is candor. EXP because it tests what was yours |
| H2 | "Sixty seconds: why you over a teacher who has already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." "Six years teaching third grade at a public elementary school in Joliet." | Pause, restate, then answer in under a minute. Open with "I haven't taught fourth grade." Then "I've taught third grade for six years at a public elementary school in Joliet." Then one reason from your own material that you can say without a follow-up exposing it. Hold through two follow-ups; concede the real difference plainly and add nothing to close it | The same F2 objection under time pressure. JD because it scores fit for the stated role |

## Requirement coverage

| Requirement | Questions |
|---|---|
| License gate (F1) | E1 states it; no separate question, because the gate is shown met on your statement and the hiring page lists no licensure topic |
| Teach fourth grade (F2) | A1, A2, A4, H2 |
| Plan and teach five subjects (F3) | C3 |
| Differentiate using assessment data (F4) | C1, D3 |
| Keep clear classroom routines (F5) | B4 |
| Communicate regularly with families (F6) | E3, D1 |
| Speak with every family each term (F7) | E3, D1 |
| Work with the grade-level team (F8) | A3, B1, B2, B3 |
| Reading instruction (F9) | C2, D2, E2, G1, G2, H1 |
| Three published beliefs | D1 (Families Are Partners), D2 (Every Child a Reader), D3 (Teach for Tomorrow, Not for the Test) |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| RQ1 | "You came to the principal's role from nine years as a reading specialist. How does that shape what you look for in reading instruction in a fourth-grade classroom?" | Ties to the principal's own path and shows you researched her, not only the district | [grounded] ilprincipalsforum.example speaker page |
| RQ2 | "Your 2025 talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5. What does that look like in fourth grade here?" | Turns an interview into a conversation about her published work | [grounded] ilprincipalsforum.example speaker page |
| RQ3 | "The board's literacy plan brings a new grades 3–5 reading curriculum from fall 2027. What will fourth-grade teachers be asked to do between now and then?" | Shows current-strategy homework and asks about the near term | [grounded] orrinsfordschools.example news page |
| RQ4 | "What could a new person do in their first month that would genuinely help the fourth-grade team?" | The reciprocity question for the peers on the panel | [generic] |
| RQ5 | "The district's beliefs say each teacher speaks with every family each term. How do teachers here usually do that?" | Shows you read the beliefs and takes the family duty seriously | [grounded] orrinsfordschools.example beliefs page |
| RQ6 | "What would a successful first year look like for a new fourth-grade teacher here?" | A standard close that signals you are planning to stay | [generic] |

## Prohibited claims

Built before the question banks and binding on every cell.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative the candidate stated, F2 | The plain acknowledgment F2 gives: "I haven't taught fourth grade." No slot |
| Has been a team lead | Negative the candidate stated, F2 | The plain acknowledgment F2 gives: "I haven't been a team lead." Beside it, F8's quote at its own scope: "In 2024 I led our grade level's move to a new reading curriculum." No slot |
| Led the grade-level team | Inflated form of F8 | F8's quote at its own scope. The limit is the pack's observation, not words for you: the material says the move, not the team. A3's slot stays inside the move |
| Led the school's reading curriculum change | Inflated form of F9 | F9's quote at its own scope. The limit is the pack's observation: the material says your grade level's move, not the school's. G1's slot stays inside the move |
| Speaks with every family each term | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: the material says a weekly written email, not conversations. E3's slot stays inside the email |

## Sources

Provided: the invite from Human Resources, Orrinsford Community School District; your resume as pasted in your message. No `tuesday-dossier.md` was present. A government ID number appeared in your message; it is not needed, was not used, and appears nowhere in this pack. Your license number is likewise left out of the pack and of every search.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

Queries sent and what came back:

- "Orrinsford Community School District mission values" — https://orrinsfordschools.example/about/mission-and-beliefs
- "Halvering Elementary School Orrinsford interview process fourth grade teacher" — https://orrinsfordschools.example/careers/how-we-hire-teachers
- "Orrinsford Community School District strategic plan news" — https://orrinsfordschools.example/news/board-adopts-literacy-plan
- "Dolores Vantongeren principal Halvering Elementary" — https://ilprincipalsforum.example/speakers/dolores-vantongeren
- "Fourth Grade Teacher job posting Illinois elementary school responsibilities qualifications" — https://k12jobsboard.example/listings/fourth-grade-teacher

Fetched in full: the beliefs page and the hiring page above. The literacy-plan, principal and representative-posting results were read as search snippets only; the snippet of the representative posting cut off in its qualifications line, and nothing from that line is used.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford values` | yes | The three beliefs by name: D1 to D3 and RQ5. No values cheat sheet, because no values-style round is detected |
| 2. `Orrinsford interview process teacher` | yes | Established the loop as one 45-minute panel of the principal and two grade-level teachers, and the topics it asks about: persona weights, B4, E2 |
| 3. `Orrinsford strategy` / recent news | yes | The August 2026 literacy plan: C2 and RQ3 |
| 4. `Dolores Vantongeren Halvering` | yes | Her path and her 2025 talk: the interviewer read, RQ1 and RQ2 |
| 5. representative `Fourth Grade Teacher` JD | yes | No JD was supplied, so F3 to F6 and F8 rest on this typical posting and are `[inferred]`. It is not Halvering's own posting |

## Upgrade menu

- Halvering's own posting text → the `[inferred]` rows F3 to F6 and F8 become `[grounded]`, and any requirement or term the typical posting does not carry appears in the snapshot
- The names of the two fourth-grade teachers on the panel → an interviewer read for them, tuned persona weights, and reverse questions tied to their paths
- Your answers to the answer slots in F3, F4, F5, F7, F8 and F9 → each answer is quoted into the snapshot, those rows are upgraded, and the slots become story maps
- Any note from HR or the principal about what the panel will cover, or a task to prepare → coverage of that focus and, if a task was announced, its own build section
- A `tuesday-dossier.md` from an earlier session → verified evidence and any recorded objections to rehearse, without making the pack depend on one
