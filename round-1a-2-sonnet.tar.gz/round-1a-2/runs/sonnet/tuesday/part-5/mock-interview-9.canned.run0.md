Your prep pack is saved as `halvering-elementary_fourth-grade-teacher_interview_pack.md`. I built it as a hiring-manager-style round with the principal and a peer-style round with the two fourth-grade teachers, since the invite doesn't say more about them.

Your license meets the invite's one stated requirement, as written on your resume. The pack treats fourth grade being new to you as the biggest gap, so its top rehearsals are:
- **A1:** "What will be new to you in fourth?" You hold the two sentences you gave me and concede the rest plainly.
- **A3:** "Were you the team lead?" You say you led the grade level's reading-curriculum move, and that you've never been a team lead.

The pack has 21 questions, six reverse questions and a list of claims it won't coach. It also covers the principal's background as a reading specialist and the district's August 2026 literacy plan.

Your SSN wasn't needed, and I haven't used it. I'd keep it off anything you send ahead of the interview.

Say the word and I'll play the principal on A1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Do you have Halvering's actual posting? If you paste it, the three rows built from a similar fourth-grade posting get rewritten in its own words. If not, the pack stands as it is.
2. Do you want a deeper research pass on the district's literacy plan and the principal's published talks? It would use up to 6 more searches and 2 more fetches, and take several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. A 45-minute panel on Thursday with Principal Dolores Vantongeren (hiring-manager relationship) and two members of the fourth-grade team (peer relationship; names not given).

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: speak it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs |
| EXP | Whether the lines on your CV hold up when probed |
| JD | The stated job, including its gaps |
| CO | Whether you know the district's current direction |
| CASE | Reasoning on a live classroom problem |

Provenance labels: `[grounded]` traces to a document you gave or a source named in Sources. `[inferred]` is derived from a similar posting or a reasonable extension, with the derivation named. `[generic]` is a role-family pattern with no claim about this school or about you. Highest-ROI prep: A1, then A3.

## Fit snapshot

The district's own posting was not supplied. Rows F2, F4 and F9 take their requirement from a sample fourth-grade posting (K12 Jobs Board), so they are inferred, not this school's words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Your CV already states kind, endorsement, status and expiry, and the pack's observation is that grades 1–6 include fourth grade. It is a CV line with nothing inspected behind it, so the school will check it; confirming it against your own license record before Thursday is yours to do. Say it in the quote's own terms |
| F2 | "plan and teach reading, writing, math, science and social studies" — sample fourth-grade posting, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | discovery | The quote says third grade, not which subjects. Answer slot: the sample posting lists five subject areas, so expect a probe on which you taught. Say which, in your own words; if some were taught by others or not at all, say so plainly and stay with the six years of third grade |
| F3 | "Fourth Grade Teacher" — invite | "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet" — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." The third-grade quote stays at its own scope: it is another grade, and the pack does not call it equivalent. Then how you would learn fourth grade, said as a plan and never as a past |
| F4 | "differentiate instruction using assessment data" — sample fourth-grade posting, K12 Jobs Board | none given | none | [inferred] | discovery | Your material is silent on this. Answer slot: if you have used assessment results to change what you taught, say what and how, in your own words; if you have not, or it was not yours to decide, say so plainly and say what you would look at first in a new class |
| F5 | "reading instruction" — district hiring page: Panels ask about reading instruction, classroom routines and how you work with families | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Your material says the curriculum move and the club, and the words stay there: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: expect follow-ups on the move and on the club themselves. Say what you did in each, in your own words; if the parts you did sit elsewhere, say so plainly and stay with the two sentences |
| F6 | "classroom routines" — district hiring page | none given | none | [grounded] | discovery | Your material is silent on this, and the page says the panel asks about it. Answer slot: if you set routines in your own classroom, say which and why, in your own words; if you did not set them, say so plainly and say how you would set them in a fourth-grade room, as a plan |
| F7 | "how you work with families" — district hiring page | "I write a weekly email to families" — your CV | medium | [grounded] | none | No gap, but a CV line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: a weekly email, to families |
| F8 | "each teacher speaks with every family each term" — district Mission and Beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | discovery | The belief names spoken contact each term and the quote is an email, so your material does not show whether you also speak with families. Answer slot: if you do, say how, in your own words; if not, say so plainly and stay with the weekly email |
| F9 | "work with the grade-level team" — sample fourth-grade posting, K12 Jobs Board | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [inferred] | presentation | The first quote already carries grade-level team work in other terms; say it as written and add no practice or title. If asked about a lead role, the plain acknowledgment is "I've never been a team lead" |
| F10 | "assessments inform teaching and never replace it" — district Mission and Beliefs page | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: if an assessment result ever changed what you taught, say what the result was and what changed, in your own words; if none did, or it was not yours to change, say so plainly and say how you would want results to inform a plan |
| F11 | "no student leaves third grade without a reading plan" — district Mission and Beliefs page | "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | discovery | The quote shows a reading club and does not show whether reading plans were part of it. Answer slot: if students' reading plans were yours to write or follow, say how, in your own words; if not, say so plainly and stay with the club |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 license | E2 |
| F2 subjects | E3 |
| F3 fourth grade | A1, A2, A4, A5, B4 |
| F4 assessment data | C1, C3 |
| F5 reading instruction | C4, D1, G1, G2 |
| F6 classroom routines | C2 |
| F7 working with families | D2, E1 |
| F8 speaking with every family | D2 |
| F9 grade-level team | A3, A5, B1, B2, B3 |
| F10 assessments inform teaching | C3, D3 |
| F11 reading plans | D1 |

## Reading the interviewer

Public professional footprint only. The two team members are unnamed, so nothing is read for them.

| Item | What the source says | What it means for you | Provenance |
|---|---|---|---|
| Career | Principal of Halvering Elementary School since 2022, after nine years as a reading specialist — ilprincipalsforum.example profile | Expect reading questions asked by someone with a reading specialist's background; weight the reading bank accordingly | [grounded] |
| Talk | 2025 forum talk, Small Groups, Big Readers, covering weekly reading conferences in grades 3 to 5 — same profile | Grades 3 to 5 reading is her stated topic. Your own reading sentences are in F5; if you hold reading conferences or small groups, say how in your own words, and if you do not, say so plainly. Do not claim them because her talk names them | [grounded] |
| Mirror opportunity | Her talk spans grades 3 to 5 | Pair it with one sentence from F5: "I've run the after-school reading club for the last two years" | [grounded] |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet, persistent probing of fourth grade being new and of what "led" means | High, 5 questions. Hiring-manager prior for the principal, and F3 is a stated gap | Rehearse A1 until it is boring: hold the two quoted sentences through two follow-ups and concede the specific thing |
| Peer Evaluator (B) | Two fourth-grade teammates asking what you bring them and need from them | High, 4 questions. Peer prior for the two teachers on the panel | Reciprocity: say what you bring and what you would learn from them; offer seam principles, not claims to know their seam |
| Case / Strategist (C) | Live classroom problems, routines, the district's literacy plan | Mid, 4 questions. Hiring-manager prior, and the hiring page says panels ask about classroom routines | Clarify, then objective, approach, how you would know it is working, family contact |
| Values / Behavioral (D) | Questions themed on the district's three beliefs | Mid, 3 questions. The Mission and Beliefs page says three beliefs guide every hire, and the hiring page names families and reading as panel topics | Tell a story only where one of your sentences carries it; otherwise use the scaffold and its honest branch |
| Conversational (E) | Opening biography, license confirmation, which subjects you taught | Mid, 3 questions. Panels open in a friendly register and these are scored anyway | A 90-second arc built only from your four CV sentences |
| Data-Driven Prober (G) | Pressing on the curriculum move line | Low, 2 questions. Your CV carries no figures, which lowers the prior, and the principal's reading background raises it a little | Know what you can and cannot say about the move, and say plainly when you do not know |

Loop: the district's hiring page, read, describes one 45-minute building panel of the principal and two grade-level teachers, so weights rest on a documented session. No round is documented as assessing values as such, so there is no values cheat sheet; the D bank is themed on the published beliefs instead. No pressure-style persona is weighted, because no source read points to one.

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade. What will be new to you in fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" "I've never taught fourth grade" | The highest-ROI rehearsal in this pack, and the hold is only what the quotes carry: "I've never taught fourth grade," and "Six years teaching third grade at a public elementary school in Joliet." Then say, as a plan and never as a past, what you would learn first in a fourth-grade room, in your own words. Hold through two follow-ups by returning to those two sentences; concede specifically that fourth grade is new to you. Do not call third grade the same work | F3 is the stated gap and the objection a panel arrives with; JD because the title is the requirement |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Name a real weakness early and plainly; fourth grade is the one your material shows: "I've never taught fourth grade." Answer slot: if another part of the job feels thinner to you, name it in your own words; if none does, say so plainly and stay with fourth grade. Close with your first weeks as a plan | F3 again, asked in the Skeptic's own stem; JD because it scores the listed job |
| A3 | "You led your grade level's move to a new reading curriculum. Were you the team lead?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've never been a team lead" | Answer in two sentences, both yours: "I led our grade level's move to a new reading curriculum in 2024." "I've never been a team lead." Answer slot: if the move gave you a defined role, say what it was, in your own words; if it was informal, or the decisions were made elsewhere, say so plainly and stay with the first sentence. Do not let "led" become a title | F9 is the evidence and the likeliest place a teammate tests "led"; EXP because it tests attribution | 
| A4 | "After six years in third grade, why fourth grade, and why Halvering?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | A selection scaffold, not a script: your actual reason for fourth grade and your actual reason for this school, a sentence each. Your material states neither, so none is supplied here. If one is thin, say so plainly rather than reaching for one | F3 raises the why-change question; JD because the title asks for fourth grade |
| A5 | "What would you want to learn from our fourth-grade team in your first month?" | JD | [generic] | Group your questions in three: what fourth graders are expected to leave with, how the team plans together, and how it uses its reading curriculum; then say what you could offer back. The question needs no claim about your past, so the guidance makes none | F3 and F9: a ramp plan stated as questions to the team is the honest answer to a grade you have not taught; JD because it scores readiness for the job |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our fourth-grade team plans together. What would you bring us, and what would you need from us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've never taught fourth grade" | Bring: the first sentence, as written. Need: say what you would need to learn from them, tied to the second: "I've never taught fourth grade." Put what you bring first; it is the reciprocity peers listen for | F9 is what you bring and F3 is what you need; JD because it scores the team requirement |
| B2 | "Tell us about a time you disagreed with a teammate on your grade level." | JD | [inferred] | Pick a time you disagreed with a colleague about what to do for students: what each of you wanted, what you did, and how you worked together afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F9; the theme comes from the sample posting's team line, so it is inferred, and JD because it scores teamwork |
| B3 | "When work spans a team, how do you handle credit?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Use we for context and I for contribution; the sentence already does: "our grade level's move" and "I led". Answer slot: if you can say which parts were your own work, say them in your own words; if you cannot separate them, say so plainly and stay with the sentence | F9; EXP because it tests attribution collegially |
| B4 | "Where does the third-grade team hand off to fourth, and how would you make that handoff work?" | CASE | [generic] | Offer principles, not claims to know their seam: ask what students arrive able to do, agree on what is shared, set a regular check-in. The question needs no claim about your past, so the guidance makes none | F3 and F9: the seam is where a newcomer to fourth grade is tested; CASE because it is a live problem |

### C. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A fourth grader reads well below the rest of the class. What do you do in the first two weeks?" | CASE | [inferred] | Clarify first: what is known about the student, what data exists, what the family says. Then objective, small steps, how you would know it is working, and when you contact the family. The question needs no claim about your past, so the guidance makes none | F4 and F11; the theme is the sample posting's differentiation line, so inferred |
| C2 | "Walk us through how you would set up the first week so routines are clear." | JD | [grounded] | Structure it: what the day looks like, what students do without being asked, how you teach and practise a routine. Answer slot: the hiring page says panels ask about classroom routines, so if you set routines in your own classroom, say which and why; if you did not, say so plainly and describe how you would set them in a fourth-grade room | F6; JD because the page names routines as a panel topic |
| C3 | "Half your class missed the same math skill on a short check. What changes tomorrow?" | CASE | [inferred] | Clarify what the check measured, decide what the result changes in tomorrow's lesson, and say how you would find out whether it worked. Keep to the district's phrasing: assessments inform teaching and never replace it. No claim about your past is made | F4 and F10; CASE because it is a live problem; inferred from the sample posting's assessment line |
| C4 | "The board adopted a literacy plan with a new grades 3–5 reading curriculum from fall 2027. How would you approach joining a team heading into that?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Show you have read the plan in its own terms: a new grades 3–5 reading curriculum from fall 2027 and a family reading night at every school each term. Then your sentence, as written. Answer slot: if you can say what you would do the same or differently in a move like that, say so in your own words; if not, say plainly that you would want to learn the team's plan first | F5 is the evidence; CO because it tests whether you know the district's current direction |

### D. Values / Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Every Child a Reader: tell us about a time you helped a student become a stronger reader." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Story-mapped on the club: the club, and the two years, the beats the sentence states, told in your own words. Answer slot: the belief is a reading plan for every student, so if you wrote or followed plans, say how; if not, or if it was not yours, say so plainly and stay with the club | F5 and F11; VAL because it maps to a published belief |
| D2 | "Families Are Partners: tell us about a time you brought a family into their child's learning." | VAL | [grounded] "I write a weekly email to families" | Story-mapped on the email: it is weekly, and it goes to families. Answer slot: the belief is that each teacher speaks with every family each term, so if you also speak with families, say how, in your own words; if not, say so plainly and stay with the email | F7 and F8; VAL because it maps to a published belief |
| D3 | "Teach for Tomorrow, Not for the Test: tell us about a time assessment results changed what you taught." | VAL | [grounded] | Pick a time a result changed your plan: name the result, what you changed, and what you saw afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would let results inform teaching without replacing it | F10; VAL because it maps to a published belief; no sentence of yours carries it, so it is a scaffold |

### E. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk us through your last six years of teaching." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years" "I write a weekly email to families" | A 90-second arc made of those four sentences, in the order you choose, each at its own scope. Add no outcome, number or event they do not state. Close on why fourth grade is yours to say, as in A4 | F2, F5, F7 and F9 supply the sentences; EXP because it is the CV walked aloud |
| E2 | "Can you confirm your license for us?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | State it as your CV does: kind, endorsement, status and expiry. Keep to the quote | F1; JD because it is the one requirement the invite names |
| E3 | "Which subjects did you teach in third grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: the sample posting lists reading, writing, math, science and social studies, so say which of those you taught, in your own words; if some were taught by others or not at all, say so plainly and stay with the six years | F2; JD because it scores the listed subjects |

### G. Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk us through the move to a new reading curriculum in 2024." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The beats are the sentence's: a new reading curriculum, 2024, your grade level's move, and that you led it. Answer slot: expect a follow-up on what the move involved for you; if you can say what you did, say it in your own words; if parts were decided or done by others, say so plainly and stay with the sentence | F5; EXP because it tests the line a reading specialist will read closely |
| G2 | "Which part of that move would you defend least?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The weakest-assumption move: name, in your own words, the part you would defend least. Answer slot: your material states no figure and no result, so the part is yours to name; if nothing comes to mind, say plainly that you do not know how it would be judged, and stay with the sentence | F5 and F9; EXP because it converts a gotcha into candor |

## Reverse questions

| Question | Why it lands | Provenance |
|---|---|---|
| "Your talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5. What does that look like in fourth grade at Halvering?" | Tied to the principal's own path; it shows you read her published work and moves the conversation onto her ground | [grounded] |
| "The board's literacy plan brings a new grades 3–5 reading curriculum from fall 2027. How is the fourth-grade team preparing, and where would a new teacher fit?" | Shows current knowledge of the district and asks where you would be useful | [grounded] |
| "What could a new person do in their first month that would genuinely help the fourth-grade team?" | The reciprocity question for the two teammates on the panel | [generic] |
| "The district says each teacher speaks with every family each term. How does that work in practice on a fourth-grade team?" | Takes a published belief seriously and asks for how it is lived | [grounded] |
| "How does the team use assessment results without letting them replace teaching?" | Uses the district's own words and asks about the team's practice | [grounded] |
| "What happens after the panel, and when are references taken up?" | Process clarity; the hiring page says references are taken up after the panel | [grounded] |

## Not coached

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative the candidate stated, F3 | The plain acknowledgment: "I've never taught fourth grade." No slot |
| Has been a team lead | Negative the candidate stated, F9 | The plain acknowledgment: "I've never been a team lead." "I led our grade level's move to a new reading curriculum in 2024" stays at its own scope: the move, not the team. No slot |
| Led reading instruction for the grade level | Inflated form of F5 | F5's quotes at their own scope. The limit is the pack's observation: the material says the curriculum move and the club. G1's slot stays inside the move |
| Chose or wrote the new reading curriculum | Inflated form of F5 | The sentence at its own scope: "I led our grade level's move to a new reading curriculum in 2024." The limit is the pack's observation, not words for you: the material says the move, not who chose or wrote the curriculum |

## Sources

Provided: the invitation text and your resume and message. A government ID number you included was not needed and was not used. No `tuesday-dossier.md` was present.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Query or fetch | What came back |
|---|---|
| Search: Orrinsford Community School District mission values | https://orrinsfordschools.example/about/mission-and-beliefs |
| Search: Halvering Elementary School Orrinsford interview process teacher | https://orrinsfordschools.example/careers/how-we-hire-teachers |
| Search: Dolores Vantongeren principal Halvering Elementary School | https://ilprincipalsforum.example/speakers/dolores-vantongeren |
| Search: Fourth Grade Teacher job posting Illinois elementary school responsibilities qualifications | https://k12jobsboard.example/listings/fourth-grade-teacher (text cut off in the result) |
| Search: Orrinsford Community School District strategic plan recent news | https://orrinsfordschools.example/news/board-adopts-literacy-plan (result text only, page not fetched) |
| Fetch: Mission and Beliefs page | Page text returned |
| Fetch: How we hire teachers page | Page text returned |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. District values | yes | The three beliefs by name; the D bank, and rows F8, F10 and F11 |
| 2. Interview process | yes | One 45-minute building panel with named topics; persona weights and the C2 and D questions |
| 3. Strategy or recent news | yes | August 2026 literacy plan from the result text; C4 and a reverse question. The page itself was not fetched |
| 4. Interviewer name | yes | The principal's career and talk; the interviewer read and a reverse question. No names were given for the two teammates |
| 5. Representative posting | yes | Rows F2, F4 and F9, labeled inferred; Halvering's own posting was not supplied |

## Upgrade menu

- Halvering's actual posting text → rows F2, F4 and F9 become `[grounded]` and the JD-tagged questions are retuned to its own words
- The two teammates' names and roles → a tuned peer bank and an interviewer read for each, plus a reverse question tied to their paths
- Anything the recruiter said about focus areas or a demo lesson → a build section for any pre-declared deliverable
- Your answers to the slots in F2, F4, F5, F6, F8, F10 and F11 → those rows are regenerated from your own words
- One inspectable item for F5, F7 or F9, such as the curriculum-adoption memo, a lesson plan or a sample family email → raises those rows from `medium` toward `high`
- A `tuesday-dossier.md` from a prior fit check → verified evidence and a named objection would replace the objection inferred here
