You didn't need to include your SSN, and I haven't used it. I also left your licence number out of the pack and out of every search.

Your prep pack is saved at `/var/tmp/tuesday-measure/1a2/runs/sonnet/tuesday/part-5/rooms/case-9-canned-00f316aa/halvering-elementary_fourth-grade-teacher_interview_pack.md`. It has 22 questions, the five reverse questions plus one more, and a list of claims the pack won't coach. I built it for a panel on the assumption that Principal Vantongeren is in the hiring-manager seat and the two team members are peers.

The pack rests on a few facts I found online:
- **Principal:** she was a reading specialist for nine years, and her 2025 forum talk was on weekly reading conferences in grades 3 to 5.
- **District:** it has a published reading belief, "Every Child a Reader." Its 2026–2029 literacy plan brings a new grades 3–5 reading curriculum in fall 2027. The principal and district details are in the pack's interviewer section and question banks.
- **School:** my search for Halvering Elementary returned nothing, so no school-level facts are included.

The most likely hard moment is "I don't see fourth grade in your background" (A2). The pack has you say "I've never taught fourth grade." plainly, then give your six third-grade years at their own scope. Because you also said you've never been a team lead, the pack never describes your curriculum move as leading the team.

Say the word and I'll play the Skeptic on A2 so you can rehearse it live. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full job posting? Six rows rest on a typical fourth-grade posting I found online, and yours would replace it.
Did HR mention a demo lesson, writing sample or anything to bring on Thursday?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview pack: Fourth Grade Teacher, Halvering Elementary School

**Interviewers:** Principal Dolores Vantongeren, plus two members of the fourth-grade team (names not given). **Format:** one 45-minute panel, Thursday, from the invite. **Built on this assumption:** the principal sits in the hiring-manager seat and the two team members are peers. If that is wrong, the persona weights change.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say only what you actually did, in your own words. Fit-snapshot rows are numbered S1 to S10, and question IDs run by persona (A1, B2, and so on).

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the district's published beliefs |
| EXP | Whether what your CV says survives follow-up, and what was actually you |
| JD | The stated role and its requirements, gaps included |
| CO | Whether you know the district's current direction |
| CASE | A live problem from the real job, reasoned aloud |

## Fit snapshot

No posting was supplied. The invite's own words, the district's published pages and a representative posting found online supply the requirements, and each row says which. Rows from the representative posting are `[inferred]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| S1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate, and your material shows it met. Say it as written. Checking the licence record is yours to do before Thursday; the pack does not look it up |
| S2 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board listing, a representative posting | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [inferred] | discovery | Your material shows the grade, not which subjects. Words stay at the quote: "I have six years teaching third grade at a public elementary school in Joliet." Answer slot: the posting lists five subjects, so a probe on each is likely. For any you taught, say which and how, in your own words; if you did not teach one, or it was not yours, say so plainly and stay with the grade you taught |
| S3 | "differentiate instruction using assessment data" — K12 Jobs Board listing, a representative posting | none given | none | [inferred] | discovery | Your material is silent on this, so the words are an answer slot. If you adjusted what you taught from assessment results, say what and how, in your own words; if there was no such step, or it was not yours, say so plainly and say what you would look at first in a new class |
| S4 | "communicate regularly with families" — K12 Jobs Board listing, a representative posting | "I write a weekly email to families." — your CV | medium | [inferred] | none | No gap on the quote, but a CV line with nothing inspected behind it, so expect a probe. Lead with it as written: "I write a weekly email to families." |
| S5 | "Families Are Partners: each teacher speaks with every family each term." — district Mission and Beliefs page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | Your material says an email, not a conversation, so the words stay at the quote. Answer slot: a probe on how families respond to the email is likely. Say what actually happens, in your own words; if the email goes one way, or you see no reply, say so plainly and stay with the email |
| S6 | "Every Child a Reader: no student leaves third grade without a reading plan." — district Mission and Beliefs page | "I've run the after-school reading club for the last two years." — your CV; "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | transferability | Both quotes are reading work and neither is a plan for a student, so the words stay at the quotes. Answer slot: the belief makes a probe on individual students' reading plans likely. If any student had one in your classroom, say who made it and what was in it, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the club and the curriculum move |
| S7 | "a new grades 3–5 reading curriculum from fall 2027" — district news page, the 2026–2029 literacy plan | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | presentation | Reword only the quote: "In 2024 I led our grade level's move to a new reading curriculum." Your material does not show which curriculum it was or how it compares with the one the district will adopt, and the words make no claim about that |
| S8 | "work with the grade-level team" — K12 Jobs Board listing, a representative posting | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead." — your message | medium | [inferred] | none | No gap on working with a grade-level team: lead with the move as quoted. The limit is yours, and you have stated it: "I've never been a team lead." |
| S9 | "Fourth Grade Teacher position" — the invite | "I've never taught fourth grade." — your message; "Six years teaching third grade at a public elementary school in Joliet." — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." Then how you would learn it, said as a plan and never as a past. The third-grade years stay at their own scope, and nothing is added to make the gap feel smaller |
| S10 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." — district Mission and Beliefs page | none given | none | [grounded] | discovery | Your material is silent on this, so the words are an answer slot. If assessment results ever changed what you taught, say what changed and how you knew, in your own words; if no such time comes to mind, or it was not yours, say so plainly and say what you would check first |

## Reading the interviewer

Principal Dolores Vantongeren: the Illinois Principals Forum speaker page says she has been principal of Halvering Elementary since 2022, after nine years as a reading specialist, and that her 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5. Nothing else about her was checked. The two team members are unnamed, so nothing is read for them.

- Expect reading to be the lane where she probes hardest. C2, E2 and D1 are built for it.
- Mirror opportunity, a shared professional path: her public path is nine years as a reading specialist. Your side is the sentence "I've run the after-school reading club for the last two years." (S6). Pair them as two reading paths, and do not say the club works the way her talk describes, because your material does not say that.
- Second pairing: her talk covers grades 3 to 5, and your sentence is "I led our grade level's move to a new reading curriculum in 2024" (S7). Say the sentence, and let her draw the link.
- Public professional footprint only. Nothing about her personal life or temperament is inferred.

## Persona table

The invite establishes the loop: one 45-minute panel of three. Weights blend the top two personas of each member's relationship (`references/personas.md`): principal as hiring manager, team members as peers. No values-style round is documented, so no values cheat sheet is built. The published beliefs still theme the D bank.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of the move from third to fourth grade, and of subjects beyond reading | High (5 questions). S9 is a stated gap and the principal's seat is built to derisk it | Rehearse the one predictable objection (A2) until it is boring; bridge only from adjacent evidence you stated (S9) |
| B. Peer Evaluator | Teammates ask what you bring to their grade and how you handle disagreement | High (4 questions). Two of three panelists are fourth-grade teammates, and you have said you have not led a team (S8) | Reciprocity: what you bring and what you need; propose principles for where work meets, not a claim to know their seams |
| C. Case/Strategist | Live problems drawn from the district plan and the role | Mid (3 questions). The principal is the likely source, and the literacy plan gives her material | Clarify, then objective, approach and risks; think aloud; challenge one premise respectfully |
| D. Values/Behavioral | Scenario probes on the three published beliefs | Mid (3 questions). The beliefs say "every hire", but no values round is documented | Where no quoted sentence carries a story, use the selection scaffold and its honest branch |
| E. Conversational | Friendly openers about your path, the reading club and the family email | Mid (3 questions). Panels open this way, and casual questions are still scored | A 90-second arc built only from S6, S7 and S9's quotes; never answer "I think you've covered everything" in the closing slot |
| F. Data-Driven Prober | Licence confirmation and a walk through a typical day | Low (2 questions). Your material has no outcome figures, only durations | Say how each duration was counted and when you do not know |
| G. Pressure | A sixty-second challenge on why you | Low (2 questions). Nothing in the invite signals stress, but teammates can press collegially | Pause, restate, hold through two follow-ups, then concede the specific thing |

## Question banks

Your material holds no outcome figures, only durations (six years, two years, 2024), so there is no defend-the-number question. The durations stay at their own scope in every row.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade." | Name it plainly before they do: "I've never taught fourth grade." Then the plan, said as a plan: what you would ask the two fourth-grade teachers to show you in week one and what you would read first, in your own words. Answer slot: if a follow-up asks what you do know about the grade, say only what you know and how you came to know it; if nothing, say so plainly and return to the plan | S9 is the biggest gap in the material and the Skeptic's first target; JD because it scores the stated role |
| A2 | "I don't see fourth grade anywhere in your background. What would your first month look like?" | JD | [grounded] "I've never taught fourth grade." "Six years teaching third grade at a public elementary school in Joliet." | The highest-ROI rehearsal in this pack. Open with the acknowledgment, then the facts: "I've never taught fourth grade. I have six years teaching third grade at a public elementary school in Joliet." Hold through two follow-ups by returning to those two sentences, never by saying the grades are the same. Concession wording to rehearse: "I haven't done it, and here is how I would find out." The limit, named before it is asked: the material shows the grade you taught, not what changes a year up. Answer slot: if a follow-up asks what changes between the grades, say what you actually know, in your own words; if you do not know, say so plainly and say who you would ask | S9 is where the role's title presses hardest, so this objection arrives in some form; JD because it scores the stated role |
| A3 | "What do fourth graders need that third graders do not?" | JD | [generic] | A question about the grade itself, so it asks nothing about your past. Answer only what you know; where you do not know, say that and say what you would ask the teachers on this panel. Answer slot: if you know of a difference from your own classroom, say what and how you saw it; if not, say so plainly | A follow-up to A2 in plainer packaging (S9); `[generic]` because it is a role-family pattern, not a fact about this school |
| A4 | "Why Halvering, and why now?" | JD | [grounded] the district's Mission and Beliefs page and literacy plan page, named in Sources | Your reason is yours; the pack supplies none. If the district's beliefs or its 2026–2029 literacy plan are part of why, say which and why, in your own words; if they are not, leave them out. Answer slot: give your own reason for moving up to fourth grade; if the reason is simply that the position is open, say so plainly | Motivation consistency is the Skeptic's core test; JD because it scores fit with this job. S9 and S7 are the rows it touches |
| A5 | "Most of what's on your resume is about reading. How comfortable are you teaching math, science and social studies?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: the representative posting lists math, science and social studies alongside reading and writing, so a probe on each is likely. For any you taught, say which and how, in your own words; if you did not teach one, or it was not yours, say so plainly and stay with "six years teaching third grade at a public elementary school in Joliet." | S2 is a discovery row; the material is reading-heavy, so the Skeptic goes where it is thin. JD because it scores a listed duty |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you and a colleague disagreed about how to teach something." | EXP | [generic] | A selection scaffold: pick a disagreement with an equal. It needs the position you held, how you listened, and a working relationship intact afterward. Your material has no such sentence, so none is supplied. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peers test disagreement style with equals (S8); EXP because it asks for a real instance |
| B2 | "How did your grade level come to move to the new reading curriculum, and what was your part?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on S7 and S8, with only the beats the quote states: your grade level, the move, the new reading curriculum, 2024, and that you led it. Tell it in your own words. Answer slot: the probe is what leading the move meant. Say what you did, in your own words; if some part was not yours, say so plainly and stay with the move | S7 and S8 are your strongest team-facing evidence and the likeliest place a teammate checks "led"; EXP because it tests attribution |
| B3 | "You haven't been a team lead. What would you bring to a team of peers, and what would you need from us?" | JD | [grounded] "I've never been a team lead." "I led our grade level's move to a new reading curriculum in 2024" "I write a weekly email to families." | Reciprocity framing. Acknowledge at the quote's scope: "I've never been a team lead." What you bring is the move you led and the weekly family email, as those two quotes state them. What you need is yours to say; propose how you and the team would settle where your work meets theirs, as principles, and do not claim to know their seams | S8 carries the stated limit and S4 the family email; JD because it scores the team requirement |
| B4 | "How do you handle credit when work spans teams?" | EXP | [generic] | A selection scaffold: pick a time work crossed classrooms or teams. It needs what each side did, who was named, and how you handled it. Your material has no such sentence, so none is supplied. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard peer probe on credit-sharing; `[generic]` because no raising source is specific to this school |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The district's 2026–2029 literacy plan brings a new reading curriculum to grades 3–5 in fall 2027. How would you help a fourth-grade team get ready?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | A live problem set in the district's own plan. Clarify what is known about the curriculum and the team's timetable, state an objective, sequence the work, name a risk, and think aloud. Your one past beat is the quote as it stands. Answer slot: the probe is what part of that move was yours; say it in your own words, and if some part was not yours, say so plainly and answer the rest as a plan | The strategy-grounded differentiator (S7); CO because it tests knowledge of the plan, CASE in delivery |
| C2 | "It's mid-September and a fourth grader reads well below grade level. What do you do in the first two weeks?" | CASE | [inferred] derived from the principal's public talk topic, weekly reading conferences in grades 3 to 5 | Structure it as a plan: what you would find out first, how you would decide what to try, what you would tell the family, what you would check after two weeks. The question asks nothing about your past, so the guidance makes no claim about it | Built around the principal's published theme (see Reading the interviewer); `[inferred]` because the link from her talk to this question is the pack's derivation |
| C3 | "A family hasn't answered any message for three weeks and the student is slipping. What happens next?" | CASE | [inferred] derived from the district's Families Are Partners belief | A live problem; structure it as a plan: what you would try first and why, who else at the school you would involve, and what you would do if nothing changed. It asks nothing about your past | The belief makes family contact a scored topic (S4, S5); `[inferred]` because the scenario is the pack's own |

### D. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you made sure a student who was behind in reading got what they needed." | VAL | [grounded] "I've run the after-school reading club for the last two years." | A selection scaffold, themed on Every Child a Reader. It needs a student situation without names, what you saw, what you did and what changed. Your material has no such sentence. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I've run the after-school reading club for the last two years", or how you would handle it | S6 is the row this belief maps to; VAL because the theme is a published belief |
| D2 | "Tell me about a time a family's view changed what you did." | VAL | [grounded] "I write a weekly email to families." | A selection scaffold, themed on Families Are Partners. It needs the family's view, what you did differently and how it turned out. Your material has no such sentence. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I write a weekly email to families", or how you would handle it | S5 is the row this belief maps to; VAL because the theme is a published belief |
| D3 | "Tell me about a time assessment results changed what you taught." | VAL | [grounded] the district's Mission and Beliefs page, named in Sources | A selection scaffold, themed on Teach for Tomorrow, Not for the Test. It needs what the results showed, what you changed and how you knew it helped. Your material has no such sentence. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | S10 and S3 are discovery rows; VAL because the theme is a published belief |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey. How did you get here, and why fourth grade?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." | A 90-second arc built from these three sentences only, each told at its own scope: the grade you've taught, the move you led, the club you run. The why-fourth-grade beat is yours. Answer slot: give your own reason for fourth grade; if there is no reason beyond wanting the move, say so plainly | The opener is scored for economy and honesty (S9, S7, S6); EXP because it asks for your path |
| E2 | "I hear you run an after-school reading club. What are you playing with in reading these days?" | EXP | [grounded] "I've run the after-school reading club for the last two years." | Story-mapped on S6, with the beats the quote states: the club, after school, the last two years. Answer slot: a casual follow-up on what the club does is likely. Say what it actually does, in your own words; if you do not know how to describe it, say so plainly and stay with the quote | Casual questions on a hot topic for this principal are scored (S6); EXP because it tests what you did |
| E3 | "You write a weekly email to families. Tell me about that." | EXP | [grounded] "I write a weekly email to families." | Story-mapped on S4 and S5, with the beats the quote states: weekly, an email, to families. Answer slot: a probe on how families respond is likely. Say what actually happens, in your own words; if the email goes one way, or you see no reply, say so plainly and stay with the email | S4 is a clean row and S5 the stretch; EXP because it tests what the line means |

### F. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Can you walk us through your licence and endorsement?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it as written, with nothing added: the Illinois Professional Educator License, the Elementary Education endorsement for grades 1–6, registered and active through June 30, 2029. The pack does not look up the record, so check yours before Thursday | S1 is the invite's one stated requirement; JD because it scores a listed term |
| F2 | "Walk me through a typical day in your third-grade classroom, and how you decide what to teach next." | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Story-mapped only to what the quote states: third grade, a public elementary school, six years. Answer slot: the representative posting lists five subjects and asks for instruction differentiated using assessment data, so a probe on both is likely. Describe the day as it actually ran, in your own words; for any subject you did not teach, or any decision about what came next that was not yours, say so plainly and stay with the grade you taught | S2 and S3 are the two discovery rows the posting raises; JD because it scores listed duties |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a candidate who has already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." "I write a weekly email to families." | Pause, restate, anchor. Concede the true thing first: "I've never taught fourth grade." Then only what the quotes carry: the move you led, the club you run, the weekly email. Hold through two follow-ups by repeating those, never by claiming fourth-grade equivalence. Concede uncertainty specifically: what you have not done, and how you would find out | S9 is the gap a pressure interviewer leans on; JD because it scores the stated role |
| G2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold the quote's scope: you led your grade level's move. Hold through two follow-ups. Answer slot: say which parts were yours, in your own words; if a part was not yours, say so plainly and stay with the move you led. Concede that part specifically and do not fold on the rest | Attribution probes exist to catch inflation (S7, S8); EXP because it tests what was yours |

### Requirement coverage

| Requirement | Questions |
|---|---|
| S1 licence | F1 |
| S2 subjects | A5, F2 |
| S3 assessment data | F2, D3 |
| S4 families, regularly | E3, C3 |
| S5 Families Are Partners | E3, D2, C3 |
| S6 Every Child a Reader | D1, E2, C2 |
| S7 new reading curriculum | C1, B2, G2 |
| S8 grade-level team | B2, B3, G2 |
| S9 fourth grade | A1, A2, A3, A4, G1 |
| S10 Teach for Tomorrow | D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "You spent nine years as a reading specialist before becoming principal. How does that show up in how Halvering handles reading in grades 3 to 5, and where would a new fourth-grade teacher plug in?" | Tied to her own public path, per the forum page, so it reads as a conversation between two reading people |
| RQ2 | "What could a new person on this team do in their first month that would genuinely help you?" | The reciprocity question for the two peers: it asks about their load, not only your needs |
| RQ3 | "The board's 2026–2029 plan brings a new reading curriculum to grades 3–5 in fall 2027. What would a fourth-grade teacher's part be between now and then?" | Shows you read the district's plan, and answers what the role involves before you accept it |
| RQ4 | "The plan also has a family reading night at every school each term. How does Halvering run it, and what do fourth-grade teachers do there?" | Ties to the district's Families Are Partners belief and shows homework on a specific commitment |
| RQ5 | "How does your fourth-grade team plan together, and what does a new teacher usually lean on you for?" | Turns your stated gap (S9) into a practical question about the seam, with teammates in the room |
| RQ6 | "What would a good first semester look like for the person in this seat?" | Shows you are thinking about the job, not only the hire |

## Prohibited claims

This pack will not coach these, because each outruns what you have said.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or something equivalent | Negative the candidate stated, S9 | The plain acknowledgment: "I've never taught fourth grade." The third-grade years stay at their scope: "Six years teaching third grade at a public elementary school in Joliet." No slot |
| Has been a team lead | Negative the candidate stated, S8 | The plain acknowledgment: "I've never been a team lead." The move stays at its scope: "I led our grade level's move to a new reading curriculum in 2024" |
| Ran the school's reading programme | Inflated form of S6 | The quote at its scope: "I've run the after-school reading club for the last two years." The limit is the pack's observation, not words for you: the material says the club, not a programme |
| Chose or designed the new reading curriculum | Inflated form of S7 | The quote at its scope: "I led our grade level's move to a new reading curriculum in 2024". The limit is the pack's observation: the material says the move, not the curriculum's choice or design |
| Speaks with every family each term | Inflated form of S5 | The quote at its scope: "I write a weekly email to families." The limit is the pack's observation: the material says an email, not conversations. E3's slot stays inside the email |

## Sources

**Provided documents:** the invite (HR, Orrinsford Community School District) and your resume as pasted. No dossier was present. Your SSN was not used, and your licence number was left out of the pack and out of every search.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | The district's three beliefs by name: S5, S6 and S10, and the D bank's themes. No values-style round is documented, so no cheat sheet |
| 2. `{company} interview process {role family}` | skipped | The invite fixes the session (one 45-minute panel) and who is in it, which fixes the persona weights |
| 3. `{company} strategy` / recent news | yes | The 2026–2029 literacy plan: S7, C1, RQ3 and RQ4 |
| 4. `{interviewer name} {company}` | yes | The principal's public path and talk topic: the interviewer read, C2, RQ1 |
| 5. representative `{role title}` JD | yes | Rows S2, S3, S4 and S8, all `[inferred]`; the posting text is a search snippet and was cut off mid-sentence |
| Un-numbered: school-level search | yes | "Halvering Elementary School Orrinsford Community School District" returned no results, so school-level facts are not established. It moved nothing, and the upgrade menu lists what would fill the gap |

Queries and what came back:

- "Orrinsford Community School District values mission": https://orrinsfordschools.example/about/mission-and-beliefs
- "Halvering Elementary School Orrinsford Community School District": no results
- "Dolores Vantongeren principal Halvering Elementary": https://ilprincipalsforum.example/speakers/dolores-vantongeren
- "fourth grade teacher job posting Illinois elementary school responsibilities qualifications": https://k12jobsboard.example/listings/fourth-grade-teacher
- "Orrinsford Community School District strategic plan news": https://orrinsfordschools.example/news/board-adopts-literacy-plan

Fetches: the Mission and Beliefs page and the principal's forum page, both returned. Source quality: the district pages are official; the forum page is a speaker bio; the job-board listing is a representative posting, not this school's.

## Upgrade menu

- The posting text → the four `[inferred]` rows (S2, S3, S4, S8) become `[grounded]`, and any requirement the posting adds gets its own question
- The two team members' names and roles → personas assigned per person, and reverse questions tailored to each
- Anything HR said about a demo lesson, writing sample or other thing to bring → a build section for each announced deliverable
- Your answers to the slots (which subjects you taught, how assessment results shaped your teaching, what the club and the curriculum move involved) → S2, S3, S5, S6, S7 and S10 move from discovery or transferability toward story-mapped rows
- A lesson plan or unit you wrote, your latest evaluation summary, or a sample family email → the inspectable artifacts in teaching; they would lift medium rows toward high
- School-level facts about Halvering (the posting or the recruiter can supply them) → a grounded school brief, which this pack cannot build because the school search returned nothing
- Deeper research, up to 6 more searches and 2 more fetches, several more minutes → a strategy brief on the literacy plan, the principal's talks and writing, and recent district context
- A saved `tuesday-dossier.md` from an earlier session → verified evidence and constraints on weak areas, and a sharper highest-ROI objection
