Running the company searches now, then I'll write the prep pack.
Before the prep, one thing in the invite: it asks you to "please transfer the €95 equipment registration fee to our supplier's account, IBAN ...", to "reply with a photo of your passport and your bank details before the interview", and says that with "a cheque for €1,850" "you deposit the cheque and send the balance on to the vendor". Each of these has money or documents leaving you before any offer, and this cheque arrangement has you forwarding part of what you deposit. Requests like these are a known scam pattern, and the fee, the cheque arrangement and the passport and bank-details request are very likely a scam. Hold all three until you have checked the invite with the employer, using contact details you find on its own website or careers page rather than the address or reply link in the invite. Your passport isn't needed for interview prep, and I haven't used it. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as /var/tmp/tuesday-measure/1a2/runs/sonnet/tuesday/part-5/rooms/case-12-denied-b5331f3c/Brennock-Facilities_remote-administrative-assistant_interview_pack.md. I built it for a hiring-manager round, assuming the office manager would be your manager. Expect scenario questions on diary clashes, travel disruption, mismatched invoices and a spreadsheet. Expect probes on your gaps, mainly that you've chased invoices and the job is processing them. The pack rehearses the honest version of each answer from your own words. Search permission wasn't granted, so the company research rows are marked unavailable and the company question is generic.

Say the word and I'll play the Skeptic on B1, the question the pack names as your highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the office manager the person you'd report to, or a peer on the team? The answer reweights the banks.
Can you paste the full text of the ad? It would replace my reading of your summary.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock-Facilities_remote-administrative-assistant_interview_pack.md -----
# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager (name not given). Format: one 30-minute video call. Relationship assumed: hiring manager, meaning the person you would work for. If that is wrong, the persona weights below change.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Every question carries one of five type tags:

- VAL: whether past behaviour shows the company's published values. No values round was established for this call, so this pack has no VAL questions.
- EXP: whether what you said about your experience survives follow-up questions, and what was actually yours.
- JD: whether you can do the listed job, gaps included.
- CO: what you know about the company.
- CASE: a live problem from the role, scored on structure and reasoning.

Guidance is scaffolding, not a script. Where a guidance cell says "answer slot", it is an instruction for the interview: answer from your own experience, or say plainly that the practice was not yours. Either answer is a good answer.

## Fit snapshot

Requirements are the ad as you described it in your message. Your evidence is your own words from the same message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" — your message | medium | [grounded] | presentation | Say it in the quote's own terms: "I ran the appointment book for four physios." The ad's word is calendars and your quote's word is appointment book, so the words stay with the quote and add nothing about how the book was run |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: the ad's travel line makes a probe on what you have booked likely. If you have booked travel for anyone, say what and for whom, in your own words; if you have not, or it was never yours to do, say so plainly and say what you would ask first |
| F3 | "preparing documents in Word" — the ad, as you described it | "I'm good with Word, okay with Excel" — your message | low | [inferred] | discovery | Your message says you are good with Word and nothing about what you made in it. Answer slot: the ad's documents line makes a probe on what you have prepared likely. If you prepared documents in Word, say what kinds, in your own words; if none, say so plainly and stay with "I'm good with Word" |
| F4 | "preparing documents in ... Excel" — the ad, as you described it | "I'm good with Word, okay with Excel" — your message | low | [inferred] | discovery | The words stay at "okay with Excel". Answer slot: the ad's Excel line makes a probe on what you have done in it likely. If you have built or kept spreadsheets, say what they held, in your own words; if your use has been basic or outside work, say so plainly |
| F5 | "processing supplier invoices" — the ad, as you described it | "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" — your message | medium | [grounded] | transferability | Your quote says chasing, not processing; that limit is the pack's observation, not words for you. The words: "I chased unpaid invoices." Answer slot, inside that scope: expect a probe on whose invoices they were and how you kept track of which were outstanding. If you kept a record, say what it was; if there was no record or it was not yours, say so plainly and describe how you chased them |

The ad as you described it names no eligibility term, such as a licence, a location or a schedule, so no row is a gate.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems from the job: a diary clash, a cancelled flight, a mismatched invoice, a spreadsheet to build | Highest. The relationship prior for a hiring-manager round is Case/Strategist plus Skeptic. The ad lists four concrete tasks, and each converts easily into a live problem | Clarify first, state the objective, then the options, then what you would tell each person and what you would record. Think aloud |
| B. Skeptic | Quiet probing of the gap between what you have done and what the ad lists | Highest, same prior. Your material reaches the calendar line directly and the invoice line only adjacently, and travel is not shown at all, so the probe has somewhere to land | Rehearse the invoice question until it is boring. Hold what your quotes say, name the limit plainly, then give a short ramp plan |
| C. Conversational | Friendly opening such as "walk me through your journey", then casual questions about Word and Excel | Medium. A 30-minute video call has an opening and a close, and casual questions are still scored | Prepare a 90-second arc built only from your own sentences. Treat "what do you use Excel for" as a scored question |
| D. Data-Driven Prober | Line-by-line questions on what you did at the clinic, one level deeper each time | Medium. The ad's invoices and Excel lines invite detail questions, and your CV-style lines are short | Know what each line covers and where it stops. Say plainly when something was not yours |
| E. Pressure | Time-boxed "why you over someone with more experience" and "how much of that was you" | Low. An admin screen of 30 minutes is rarely run as a stress round, but the two stems are cheap to rehearse | Pause, restate the question, hold your quoted position through two follow-ups, then concede the specific limit |

Not included: Values/Behavioral, because no values round is documented for this call, and Peer Evaluator, which rises to medium if the office manager is a peer rather than your manager. Weights rest on the relationship prior and on your own account of one 30-minute call with the office manager.

## Question banks

The highest-ROI rehearsal in this pack is B1: the probe on chasing invoices versus processing them.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two managers both need the same 10am slot for an important meeting, and neither will move. What do you do?" | CASE | [generic] | Structure it aloud: ask what each meeting is for and how fixed each is; look for a third slot or a shorter meeting; tell both people what you found and what you need from them; if they still cannot agree, say who decides and put it to them with the facts. Record the outcome. The question asks about no past, so the guidance makes no claim about yours | Covers the ad's "managing calendars" (F1) as a decision rather than a record. CASE because it scores structure |
| A2 | "A director's flight is cancelled the night before a client meeting abroad. You have 20 minutes. Walk me through it." | CASE | [generic] | Clarify before acting: the latest acceptable arrival, budget and approval limits, whether the traveller has a preference. Then options, who you tell and when, how you confirm the new booking, and what you record. The question asks about no past, so the guidance makes no claim about yours | Covers the ad's "booking travel" (F2), where your material shows nothing, so a live problem lets you show reasoning without a claim |
| A3 | "A supplier invoice arrives and the amount does not match what was ordered. What do you do?" | CASE | [generic] | Say what you would check first and what you would hold until it is checked. Ask what the company's own matching and approval process is, because it should not be guessed. Then say who you would tell, what you would send the supplier, and what you would record. The question asks about no past | Covers the ad's "processing supplier invoices" (F5) as a decision. CASE because the interviewer is scoring order of thinking, not a right answer |
| A4 | "I need a spreadsheet by end of day tracking 40 supplier invoices: who approved each one and when it is due. How would you set it up?" | CASE | [generic] | Clarify what decisions the sheet supports and who will update it. Then describe the columns, how due dates will be flagged, and how you would check it for mistakes. Answer slot: the ad's Excel line makes a probe on which features you have used likely. Name only features you have used; if your use has been basic, say so plainly and say how you would learn the rest | Covers the ad's Excel line (F4). The honest limit for F4 is rehearsed here so it arrives before the probe does |
| A5 | "Take this rough set of notes from a meeting and prepare a one-page summary for my manager. What do you check before it goes out?" | JD | [generic] | Name what you would confirm before sending: names, dates, actions and owners, then tone and layout for a reader with two minutes. Answer slot: the ad's documents line makes a probe on what you have prepared in Word likely. If you have prepared documents, say what kinds, in your own words; if none, say so plainly and describe how you would work | Covers the ad's Word line (F3). JD because it scores the stated task |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The job is processing supplier invoices, and you have chased unpaid ones. How does the one prepare you for the other?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | The highest-ROI rehearsal in this pack. The hold is only what the quote carries: "I chased unpaid invoices." Do not describe the job's tasks as things you did. Likely follow-ups, in order: whose invoices they were, then how you kept track of which were outstanding, then what you did when one stayed outstanding. Answer slot for each: if there was a record, a step or an outcome, say what it was, in your own words; if there was none, or it was not yours, say so plainly and return to the chasing. Then give a short plan for learning the rest. Hold through two follow-ups by returning to the chasing, never by adding to it | F5 is the likeliest place this call is probed, because the ad's invoices line is adjacent to your evidence and not matched by it. JD because it scores the stated requirement |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] | Choose from the ad's four items, calendars, travel, Word and Excel, and supplier invoices, the one your own material reaches least. Say it plainly, then give your first-month plan in two steps. If more than one is true, name the one you can speak to most honestly. The question needs no claim about your past | The Skeptic's standard stem. F2 and F5 are where your material is thinnest, and a calm, specific answer is the point. JD because it scores fit against the listed duties |
| B3 | "Tell me about a time two people needed the same appointment slot and you had to choose." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | The story has only the beats the quote states: you ran the appointment book, for four physios. Answer slot: the ad's calendar line makes a probe on clashes likely. If a clash came up, say what it was and what you decided, in your own words; if none did, or the choice was not yours, say so plainly and describe how you ran the book | F1 is the strongest row, and a probe on it tests what was actually yours. EXP because it tests attribution |
| B4 | "I don't see travel anywhere in your background. How would you handle the travel side of this role?" | JD | [grounded] | Say what you would ask a traveller first and what you would confirm after booking; that is a plan, not a past. Answer slot: if you have booked travel for anyone, say what and for whom; if you have not, say so plainly and stay with the plan | The stem names an absence the pack has only observed, not one you stated, so the guidance never says "you have never". F2 is the gap the interviewer can see on paper |
| B5 | "Why a remote admin role, after working at a clinic front desk?" | EXP | [generic] | Give your own reason, in your own words, in two sentences. Your material does not carry one and the pack will not write it for you. Then say what you would have in place to work well from home. Do not describe remote work you have not done | Motivation consistency is what the Skeptic scores. A vague answer reads as not having thought about it |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices"; "I'm good with Word, okay with Excel" | A 90-second arc with four beats, each a clause the quotes state: two years as a receptionist at a physiotherapy clinic; "I ran the appointment book for four physios"; "chased unpaid invoices"; "I'm good with Word, okay with Excel". Why you are looking at this role is your own reason, said in your own words | The biography question is scored for economy even when it sounds casual. F1, F3 and F5 supply the beats |
| C2 | "What do you know about us?" | CO | [generic] | Company research did not run for this pack, so nothing here is a fact about the company. Use only what you find yourself on the company's own website or careers page, and say where you found it. If you cannot find anything you can confirm independently, say that plainly and ask the interviewer to tell you about the company | A CO question is near-certain in a first call. An honest "here is what I found, and here is what I'd like to learn" beats recited homework |
| C3 | "Tell me about something you've put together in Word or Excel that you were pleased with." | JD | [grounded] "I'm good with Word, okay with Excel" | Pick a document or sheet where you can say what it was for, who read it and what you did yourself. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I'm good with Word, okay with Excel", or describe how you would approach one | The ad names Word and Excel, so a casual version of the question is likely. F3 and F4 are low-confidence rows, so the answer must come from you |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you ran the appointment book for four physios." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | The beats the quote states: the appointment book, four physios. Answer slot: the ad's calendar line makes a probe on how changes were handled likely. If you set a rule, a routine or a way of recording changes, say what it was, in your own words; if you worked to rules someone else set, or there was no routine, say so plainly and describe how you ran the book | F1 premised on its own quote and the likeliest line-by-line probe. EXP because it tests what was yours |
| D2 | "You say you're okay with Excel. What have you actually done in it?" | JD | [grounded] "I'm good with Word, okay with Excel" | Keep to the quote's word, "okay with Excel". Answer slot: name what you have done in Excel, in your own words, and only what you have done; if your use has been basic or outside work, say so plainly and say what you would learn first. Never name a feature you have not used | F4 is the weakest-evidenced skill row, so the probe on it is cheap for the interviewer and costly for an inflated answer |
| D3 | "Of calendars, travel, documents and invoices, which have you done most of?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Rank from your own sentences only: the appointment book reaches the calendar line most directly, and invoice chasing is the nearest thing to the invoice line. For travel, say plainly what your material does or does not carry. Answer slot: if you have done any of the four beyond what your quotes say, say what, in your own words | A ranking question forces a plain statement of the evidence. It checks the answers in A and B against each other |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already booked travel and processed invoices?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Pause and restate the question. Hold only what the quote carries: "I ran the appointment book for four physios" and "chased unpaid invoices". Concede the specific limit when pressed, in your own words, and keep to what you have done. Do not claim the other person's experience as your own | The Pressure stem tests composure. F2 and F5 are where the comparison bites |
| E2 | "That appointment book: how much of it was actually you?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Hold: "I ran the appointment book for four physios." Answer slot: if any part of it was set by someone else, such as the rules or the system, say which part, plainly; if all of it was yours, say so without adding to it. Hold through two follow-ups, then concede only the specific part that was not yours | The attribution stem exists to catch inflation. F1 is the row the pack leans on most, so it is the row to defend precisely |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| "managing calendars" (F1) | A1, B3, D1, E2 |
| "booking travel" (F2) | A2, B4, D3 |
| "preparing documents in Word" (F3) | A5, C3 |
| "preparing documents in ... Excel" (F4) | A4, C3, D2 |
| "processing supplier invoices" (F5) | A3, B1, D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like in this role, and who would I work with most?" | It shows you are thinking about being useful quickly, and the answer tells you whether the role is what the ad says |
| R2 | "Of calendars, travel, documents and invoices, which takes most of the week?" | It shows you are weighing the four duties, and the answer tells you where to put your ramp-up |
| R3 | "How are supplier invoices handled here today: who approves them, and where do they sit?" | It shows process thinking on the duty where your evidence is adjacent rather than direct |
| R4 | "How do equipment and onboarding work for new starters, and is anything expected from me before a contract is signed?" | It puts the invite's equipment and cheque arrangements to the interviewer in one plain question, and you can compare the answer with what the invite said |
| R5 | "How is remote work organised here: hours, how the team keeps in touch, who I check in with?" | It shows you have thought about working from home as a set-up, not just a location |
| R6 | "When two priorities collide in someone's diary, how would you like me to handle it?" | It picks up A1 and asks for the manager's own preference, which is what a good assistant needs to know |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Strong or advanced Excel skills | Inflated form of F4 | F4's quote at its own scope: "okay with Excel". The limit is the pack's observation: your message says okay, not strong. D2's slot stays inside what you have done |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "chased unpaid invoices". The limit is the pack's observation: your material says chasing, not processing. B1's slot asks only whose invoices they were and how you tracked them |
| Managed managers' or executives' calendars | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios". The limit is the pack's observation: your quote says appointment book, not anyone's own calendar |

## Sources

Provided documents: the interview invite text, the ad as you described it, and your background as you described it, all from your message. The loop rests on your own words: one 30-minute video call with the office manager.

Searches sent, all refused:

- "Brennock Facilities Ltd values": refused
- "Brennock Facilities Ltd interview process administrative assistant": refused
- "Brennock Facilities Ltd news": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Search was refused. It would have fed a values cheat sheet, which only a documented values round triggers, and none was established, so no section is missing |
| 2. Interview process for the role family | unavailable | Search was refused. It would have checked the loop and persona weights; they rest on your account of the call instead |
| 3. Company strategy or recent news | unavailable | Search was refused. It would have fed a company-grounded CO or CASE question; C2 is generic as a result |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative job ad | skipped | The ad as you described it fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full text of the ad → rows sourced from your description become sourced from the posting itself, and any requirement you did not mention gets a question
- A sentence on what you have done for each of F2 to F5 → those rows upgrade from discovery or transferability to quoted evidence, and the answer slots become story maps
- Whether the office manager would be your manager or a peer → persona weights recomputed and, for a peer, a Peer Evaluator bank added
- Anything the sender says about what the call will cover → coverage of any named exercise
- Search access in this session, and a deeper research pass if you want one (up to 6 more searches and 2 more fetches, several more minutes) → rows 1 to 3 above, a grounded C2, and a company-specific CASE question
- A tuesday-dossier.md from an earlier session → verified evidence for the F rows, and a stated highest-ROI objection in place of the inferred one
