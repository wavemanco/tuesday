Search access was refused, so I'm building the pack from what you pasted and Hannah's message alone. I'm writing it now.
Your prep pack is saved as `quillmoor-diagnostics_operations-coordinator_interview_pack.md`. It has 18 questions, built for a recruiter screen. Search access was refused, so nothing about Quillmoor beyond the advert is in it. Hannah's profile and Quillmoor's values and strategy are all missing, and the pack's Sources section says so.

- **Highest-ROI prep:** B1, where your delivery scheduling meets the advert's production scheduling across planning, the warehouse and QA. The pack gives you a hold, three follow-ups and a plain way to say what would be new.
- **Your logistics answers:** pay, the reason for moving and the hybrid pattern are filled from your own sentences, kept at the scope you gave. Notice is a slot waiting on your answer.
- **SAP:** B2 uses your own words, "Never used SAP — we run our own in-house stock system." The advert calls ERP a plus.
- **Claims the pack won't coach:** these include having used SAP, having coordinated production schedules, and £42,000 being a firm minimum. The full list is in the pack.

Say the word and I'll play Hannah on B1 as a drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What notice period does your current contract give you? Your answer replaces the slot in A4 with your own figure.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Interviewer and round:** Hannah Lowther, Talent Partner. Recruiter screen, a 30-minute phone call on Thursday at 2pm; she rings the mobile number on your application.
**Her stated agenda, in her words:** "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move", then she describes the team and next steps.
**Built on this assumption:** a single recruiter session, as Hannah described it. No research on Quillmoor could run (see Sources), so everything about the company comes from the advert.

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the values an employer cares about |
| EXP | Whether your experience claims survive follow-up, and what was actually you |
| JD | Whether you can do the job as advertised, gaps included |
| CO | What you know about the company and why you want this role |
| CASE | How you structure a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now. Where a slot gives two branches, either one is a good answer if it is true.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material says deliveries across three depots, not production schedules, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert names planning, the warehouse and QA, so expect a probe on whether your scheduling involved teams that make or check what is delivered. If it did, say which and how, in your own words; if it did not, say so plainly and stay with the deliveries |
| F2 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | discovery | The quote shows scheduling and chasing, and does not show how supplier deliveries were followed. Answer slot: if you kept a record or view of what was due from suppliers, say how; if you did not, say so plainly and stay with the chasing |
| F3 | "chase late orders" — advert | "chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you chase suppliers when orders slip |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap, with a figure that will be probed. Keep the figure at its scope: about a third, over a year, and the rebuild is yours. The quote states both facts side by side and does not state that one caused the other, so the cause is an answer slot in C1 and F2 |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: if you have produced a regular report on deliveries, say what it covered; if you have not, say so plainly and say what you would put in one first |
| F6 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap. Say it in the quote's own terms: four years as a logistics coordinator at a building-supplies wholesaler |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | low | [inferred] | discovery | The quote says spreadsheet, not Excel, and shows nothing about how it was built. Answer slot: if the spreadsheet was in Excel, say what you did in it, in your own words; if it was another tool, say which and say so plainly |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system" — your message | medium | [grounded] | transferability | You stated the SAP absence, so the plain words are yours: "I haven't used SAP; we run our own in-house stock system." Whether the in-house system counts as similar is the interviewer's call. Answer slot: if you work in that system yourself, say what you do in it; if you do not, say so plainly. The advert marks this as a plus, which is a quote from the advert and not a reassurance |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | Your figure sits inside the advertised band. Say it at its own scope: "I'm hoping for £42,000." It fills the pay slot in A3 and raises no defend-the-number slot |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | The advertised pattern is met by your own words. Both halves stay: two days is fine, and more than three is not wanted. It fills the location slot in A5 |
| F11 | "your notice period" — recruiter message from Hannah Lowther | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. It is a term the recruiter will ask about, and A4 holds the slot for it |
| F12 | "what's prompting a move" — recruiter message from Hannah Lowther | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | No gap. The reason is stated plainly in your own words, and A2 says it at that scope |

## Persona table

Weights start from the recruiter-screen prior in the persona model: Conversational plus a light Skeptic. No interviewer profile was available, so no signal adjustments were made. The loop is established by Hannah's own message as one 30-minute session with her, so no further rounds are assumed and no values-style round is detected.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational | Friendly logistics: journey, reason for moving, pay, notice, hybrid | Highest. It is the recruiter-screen prior, and her agenda is these four items in a friendly register. Casual questions are still scored | Pre-script the 90-second journey; answer each logistics item in your own words; use the reverse-question slot |
| B. Skeptic | Quiet probing of the gaps: production schedules versus deliveries, SAP, why Quillmoor, whether the move is settled | High, weighted up from the light prior: F1, F8 and F12 are exactly the knock-out checks a screen runs. Depth 4 | Rehearse B1 until it is boring; bridge only from what you stated; name the limit plainly |
| C. Data-Driven Prober | Reads your numbers, asks how the stock figure was counted, asks about Excel and tracking | Medium. The advert asks for stock accuracy and Excel, and F4 carries a figure. It is not on her stated agenda, so depth is 3 | Know what you can and cannot say about how the figure was counted; say plainly where you do not know |
| D. Case / Strategist | A small live problem from the role, such as a late supplier or the weekly report | Low to medium. A hiring manager is likelier to run these in a later round, but one quick scenario is cheap to rehearse. Depth 2 | Clarify, structure, then answer; think aloud |
| E. Values / Behavioral | Tell-me-about-a-time on chasing suppliers or cross-team work | Low. No values page could be read and no loop source names a values round. Depth 2 | Choose one real occasion; if none comes to mind, say so |
| F. Pressure | Time-boxed challenge on why you over someone with manufacturing experience | Low in a recruiter screen. Depth 2, for composure only | Pause, restate, hold the position through two follow-ups, concede only what is true |

## Question banks

Highest-ROI prep in this pack: **B1**. It is the objection most likely to be aimed at you, and the one where your material is thinnest.

### A. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey so far." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | A 90-second arc with one beat per quoted sentence, in your own words: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies down about a third over a year. Add no team size, volumes or tools. End on the part of the advert your work is closest to, and let her draw the conclusion | The biography question opens most screens and is scored. F6 and F3 are the likeliest rows to be heard first; EXP because it tests what you did |
| A2 | "What's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Reason-for-leaving slot, filled from your own sentence: "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Say it plainly and stop. Add no account of how the closure was announced and no characterisation of your employer | It is on Hannah's stated agenda, and F12 holds the reason in your words; EXP because motivation consistency is checked against your history |
| A3 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000" | Pay slot, filled from your own sentence: "I'm hoping for £42,000." Keep the word hoping. Give no salary history and no reasons you were not asked for. If she asks whether that moves, answer in your own words: your sentence carries no flexibility either way, so say only what is true for you | Pay is the first item on her list; F9 shows the figure and the advertised band side by side; JD because pay is the listed job's own term |
| A4 | "What's your notice period?" | JD | [grounded] | Notice slot: give your actual notice period, the one your contract states, in your own words, and say if there is any way it could change. If you do not know, say so plainly and say you will confirm it | Pay, notice, location and the reason for leaving are the four logistics a recruiter screen checks; F11 shows your material does not yet establish this one |
| A5 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Location slot, in your own words from the quote: two days at Avonmouth is fine, and you would not want more than three. Lead with the two days the advert names. Give the three-day limit if she asks about flexibility or the pattern changes, and do not turn it into a promise of more | F10 shows the advertised pattern met. She named this item herself; JD because the pattern is stated in the advert |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background is scheduling deliveries for a wholesaler. This role coordinates production schedules between planning, the warehouse and QA. What would be new for you?" | JD | [grounded] "I schedule deliveries for our three depots" | The highest-ROI rehearsal in this pack, and the hold is only what the quote carries: "I schedule deliveries for our three depots." Answer slot: the advert names planning, the warehouse and QA, so expect a probe on whether your scheduling involved teams that make or check what is delivered. If it did, say which and how, in your own words; if it did not, say so plainly and stay with the deliveries. Follow-ups in order: what part of production scheduling is new to you; what would you ask to see first in your first week; who would you need to talk to first. Answer the last two as a plan, never as a past. Hold through them by returning to the deliveries, never by adding to them | F1 is where the advert's central duty presses hardest, so this objection arrives in some form; JD because it scores the stated requirement |
| B2 | "ERP experience, SAP or similar, is a plus. Where do you stand on that?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Plain acknowledgment, sourced to your own sentence: "I haven't used SAP; we run our own in-house stock system." Answer slot: whether the in-house system counts as similar is her call. If you work in it yourself, say what you do in it; if you do not, say so plainly. Then give a plan: say what you would ask about how new systems are taught, in your own words | F8 carries your stated absence and the advert's own word plus. The row is a gap you have already named, so the rehearsal is saying it without apology |
| B3 | "What do you know about Quillmoor, and why this role?" | CO | [grounded] | The only company facts in hand come from the advert: a diagnostic-test manufacturer of about 400 staff, with a Bristol site at Avonmouth. Say that much and no more, and say you are glad she is going to describe the team. Answer slot: what draws you to the role; if the honest answer is mostly the work itself, or that it keeps you in Bristol, say so plainly. Spend ten minutes on the company website before Thursday and say only what you read there | A CO question is likely in any screen. It is grounded on the advert alone because research could not run |
| B4 | "If your employer came back with another option, would you still be looking?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | The quote carries one fact: Reading is the only offer, and you do not want it. Answer slot: your material says nothing about any other option, so do not invent one. If another option exists, say what it is and why you are still looking; if none does, say so plainly | A recruiter tests whether a reason holds under a what-if. F12 is the row it draws on; EXP because it checks motivation against your history |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say the sentence at its scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." Answer slots, in your own words: how it was counted; what the figure is sensitive to; the assumption behind it you would defend least; and which part was yours. Where you do not know how it was counted, say so plainly. Name the weakest assumption before she does | F4 holds the only headline figure; EXP because probers test attribution |
| C2 | "The advert asks for someone confident with Excel. Where does that stand?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | The quote says spreadsheet, so start there: you rebuilt your stock-count spreadsheet. Answer slot: if it was in Excel, say what you did in it; if it was another tool, say which and say so plainly. Add no feature you did not use | F7 is low confidence: the evidence touches the requirement without showing it. JD because Excel is a stated requirement |
| C3 | "How do you keep track of what suppliers owe you?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Say what the quote carries: you schedule deliveries for three depots and chase suppliers when orders slip. Answer slot: the advert names tracking supplier deliveries, so expect a probe on how. If you kept a record or view of what was due, say what it was; if you did not, say so plainly and stay with the chasing | F2 is the tracking half of the advert's sentence, and the quote shows only the chasing |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A key supplier tells you on Monday that a component for Friday's production run will be three days late. Walk me through what you'd do." | CASE | [generic] | Structure it aloud: ask what depends on the component and what stock exists; say who needs to know, using the advert's own three groups, planning, the warehouse and QA; set out the options; record the new date; follow up with the supplier. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's schedule-and-chase duties (F1, F3); generic because it is a pattern for the problem, not a fact about this employer |
| D2 | "If you were producing a weekly report on on-time dispatch, what would be in it?" | CASE | [generic] | Structure it aloud: say what on time is measured against; the count shipped on time over the count shipped; the reasons for the late ones; the trend over weeks; who reads it. Say what you would ask her team first. It asks about no past, so the guidance makes none | The advert names the weekly report, and F5 shows your material is silent on it, so a rehearsed structure is the honest preparation |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time a supplier let you down and you had to chase." | VAL | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Selection scaffold: pick one occasion with a named order, what you did to chase, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: you chase suppliers when orders slip, in the quote's own words. Add no incident you cannot name | The advert's chase-late-orders duty is the raising source. F3 holds the quote, which carries no single occasion, so this is a scaffold and not a story map |
| E2 | "Tell me about a time you worked with a team that did not report to you." | VAL | [generic] | Selection scaffold: pick one occasion with a named team, what you needed from them, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing you actually did, or how you would approach it. Add nothing you cannot name | The advert's cross-team coordination line raises it (F1). No quote carries it, so the guidance is a scaffold |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why should we pick you over someone who has run production schedules?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip" | Pause, restate, then hold on what the quotes carry: four years as a logistics coordinator, scheduling deliveries for three depots, chasing suppliers when orders slip. Hold through two follow-ups by returning to those facts, not by adding to them. Concede in your own words the part of the advert you would learn first, and name it plainly | F1 is the gap the question presses on; JD because it scores the stated requirement. The concession is a slot because your material states no negative here |
| F2 | "That stock result, how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold the part the sentence states: "I rebuilt our stock-count spreadsheet." Answer slot: the quote states the fall alongside the rebuild and not that the rebuild caused it. Say how much of the fall came from the rebuild, in your own words; if other things changed during the year, say so plainly; if you cannot split it, say that. Concede uncertainty specifically and keep the core claim | F4 is the headline figure, so attribution gets asked in some form; EXP because it tests exactly that |

## Requirement coverage

| Stated requirement | Questions |
|---|---|
| "Coordinate production schedules between planning, the warehouse and QA" | B1, D1, E2, F1 |
| "track supplier deliveries" | C3, D1 |
| "chase late orders" | E1, D1 |
| "keep stock records accurate" | C1, F2 |
| "report weekly on on-time dispatch" | D2 |
| "2+ years in operations or logistics coordination" | A1, F1 |
| "confident with Excel" | C2 |
| "ERP experience (SAP or similar) a plus" | B2 |
| "£38,000–£44,000" | A3 |
| "Hybrid: two days a week at our Avonmouth site in Bristol" | A5 |
| Recruiter items: notice period, reason for moving | A4, A2, B4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week of coordinating between planning, the warehouse and QA look like in this role?" | It uses the advert's own three groups and shows you are thinking about the work |
| R2 | "How is on-time dispatch measured and reported today, and who reads the weekly report?" | It targets the one duty where your material is silent, and shows you would own it |
| R3 | "Which system does the team work in day to day, and how are new starters trained on it?" | It deals with the SAP question openly and as a plan |
| R4 | "Are the two days at Avonmouth fixed days or agreed with the team?" | It follows from the pattern she asked about and shows you have planned for it |
| R5 | "What would you want to see from someone in their first month?" | It turns the end of the call into the role's real priorities |
| R6 | "What are the next steps after this call, and what does the next stage look at?" | It is her stated close; it also tells you whether a manager round or a task follows |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP | Negative the candidate stated, F8 | The plain acknowledgment F8 gives: "I haven't used SAP; we run our own in-house stock system." B2's slot stays on the in-house system |
| Coordinated production schedules with planning and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation, not words for you: the material says deliveries, not production schedules. B1's slot stays inside the deliveries |
| Cut stock discrepancies by a third because of the rebuild | Inflated form of F4 | F4's quote at its own scope: the rebuild, and about a third over a year. The quote does not state a cause; C1 and F2 ask only what was yours |
| Has advanced Excel skills such as macros or pivot tables | Inflated form of F7 | F7's quote at its own scope: a stock-count spreadsheet. The material says spreadsheet, not Excel or any of its features |
| £42,000 is my minimum | Inflated form of F9 | F9's quote at its own scope: "I'm hoping for £42,000." |
| Any number of office days is fine | Inflated form of F10 | F10's quote at its own scope: two days is fine, and more than three is not wanted |
| I am being made redundant | Inflated form of F12 | F12's quote at its own scope: the office is closing next year, and the only offer is relocating to Reading |

## Sources

**Provided documents:** the Quillmoor advert as pasted; your own background notes in your message; Hannah Lowther's LinkedIn message.

**Searches sent, all refused** (the host did not grant search permission, and none was retried):

- `Quillmoor Diagnostics values` — refused
- `Quillmoor Diagnostics Avonmouth Bristol news strategy` — refused
- `Hannah Lowther Talent Partner Quillmoor Diagnostics` — refused
- `Quillmoor Diagnostics interview process operations coordinator` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Would have named published values for the E bank and, if a source documented a values round, a cheat sheet. Neither is in this pack |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Would have shown the rounds after this screen. The session itself is fixed by Hannah's own words, so persona weights rest on them and on the recruiter-screen prior |
| 3. `Quillmoor Diagnostics strategy / recent news` | unavailable | Would have grounded B3 and any CO or CASE question in current priorities. B3 rests on the advert alone |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Would have supplied an interviewer read and a reverse question tied to her path. Both are absent |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → A4 and F11 quote your own figure instead of holding a slot
- Search access, so the default research pass can re-run → B3, E1 and E2 gain company-specific grounding, and a values cheat sheet appears if a source documents a values round; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is available once, on your say-so
- Your answers to the slots in F1, F2, F5, F7 and F8 (production or QA contact, how supplier deliveries were tracked, any regular reporting, the spreadsheet tool, whether you use the in-house system) → those rows become grounded in your own words, and the B1, C2, C3 and B2 slots get tighter
- Your CV → the fit snapshot would quote your written words instead of your message
- Hannah's public profile → an interviewer read and a reverse question tied to her own path
- The time you have to prepare → a prep triage sized to it
- A tuesday-dossier.md from an earlier underwriting of this role → verified evidence and a named objection in place of the ones inferred here
- The schedule of any rounds after this screen → a mini-pack per round
