Loading is done. I'm running two quick company searches, then I'll build your prep pack.
Before the prep, one thing in the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." and to "reply with a photo of your passport and your bank details before the interview". It also says "you deposit the cheque and send the balance on to the vendor". Each of these asks you to pay, hand over identity and bank details, or move your own money onward before any offer or contract. Requests like these are a known scam pattern. The fee, the passport and bank-details request, and the cheque arrangement are very likely a scam, and the invite may not come from who it names. Hold all three until you have checked the invite with the employer. That means paying nothing, depositing no cheque, and sending no passport photo or bank details. Use contact details you find on the employer's own website or careers page, not the email address or any number in the invite. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/tuesday/part-5/rooms/case-12-denied-f9b27225/brennock-facilities-ltd_remote-administrative-assistant_interview_pack.md`. I built it for a hiring-manager round, since the invite names the office manager but not how they relate to you. It has 19 practice questions, six questions for you to ask them, and a table showing how each of the ad's duties is covered. Both company searches were refused, so the pack has no company research.

Say the word and I'll play the Skeptic on B1, the question the pack names as your highest-ROI prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is the office manager your future manager, or a peer on the team? The answer reweights every question bank. Can you paste the ad itself? I worked from your list of its duties, and the full text would let me check every requirement against it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock-facilities-ltd_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager, name not given, relationship to you not stated. Format: a 30-minute video call. Built as a hiring-manager round on that assumption.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Every guidance cell is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether the claims about your experience hold up, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Knowledge of the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

Highest-ROI prep: B1. It is the question most likely to be asked in some form, and it is aimed at exactly where your material is thinnest.

## Fit snapshot

Requirements come from the duties you listed from the ad. Evidence is your own words and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — your message | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | The ad says calendars where your sentence says appointment book. Keep your own words: "I ran the appointment book for four physios." It is a CV-style claim with nothing inspected behind it, so expect a probe on what the book covered; answer from what you did and add nothing the sentence does not say |
| F2 | "booking travel" — your message | none given | none | [grounded] | discovery | Your material does not show travel booking either way, so the words are an answer slot: the ad lists booking travel, so expect a probe. If you have booked travel for anyone, say for whom and what you handled, in your own words; if you have not, or it was not yours, say so plainly and say how you would learn it first |
| F3 | "preparing documents in Word and Excel" — your message | "I'm good with Word, okay with Excel" — your message | medium | [grounded] | discovery | A self-rating with no document behind it, so expect a probe. Say each at its own level, as you rated it. Answer slot: the ad's Word and Excel line makes a probe on what you have prepared likely. If you prepared documents or spreadsheets in either, say which kind, in your own words; if you did not, or it was not part of your role, say so plainly and stay with the rating you gave |
| F4 | "processing supplier invoices" — your message | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices, not processing supplier invoices, and the words stay at that scope: "I chased unpaid invoices." Answer slot: the ad's invoice line makes a probe on what you did with the invoices likely. Say what you did when an invoice stayed unpaid, in your own words; if the part you handled was narrower than that, or someone else's, say so plainly and describe only what you chased |

## Persona table

Weights come from three passes. Relationship prior: the invite names the office manager but not how they relate to you, so the hiring-manager row of the priors applies (Case/Strategist and Skeptic). Interviewer signals: none, no name or profile. The loop: the invite describes one 30-minute video call with the office manager, so the pack prepares for one session and no values round is detected.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Small live problems from the ad's four duties: a clash in a calendar, a trip to book, an invoice that does not match, a document to turn around | High. The hiring-manager prior puts it first, and a 30-minute call leaves room for scenarios on the ad's own duties | Clarify, state the objective, approach, check and record. Think aloud and ask one clarifying question per case |
| B. Skeptic | Quiet probing of where the ad runs past your material: travel, invoices, Excel, and why this role now | High. The same prior puts it second, and F2 to F4 are the rows where the ad outruns the material | Rehearse B1 until it is boring. Bridge only from what you have said, say the limit before you are asked for it, and give a plan for closing it |
| C. Conversational | A friendly opener and a chatty feel, with casual questions that are still scored | Medium. A short video call for a remote role usually opens this way, and the casual register is where answers run long | A 90-second arc built only from your own sentences. Treat casual questions on the ad's topics as scored |
| D. Peer Evaluator | Collaboration scenarios, competing requests, what you would need from them | Medium. The office manager may be your day-to-day colleague rather than your manager, and the answer to the closing question reweights this bank | Reciprocity: what you would bring as well as what you would need. Propose principles for competing requests rather than pretending to know the office |
| E. Data-Driven Prober | Line-by-line questions on what you wrote: the appointment book, the two years | Low. Nothing in the invite signals a CV audit, but your sentences carry figures and a prober would test them | Say what you can and cannot say about each figure, in your own words, and say plainly when you do not know |
| F. Pressure | Time-boxed answers and attribution challenges | Low. Nothing in the invite signals a stress style, so two questions cover it | Pause, restate the question, anchor in what you stated, hold through two follow-ups, concede only what is true |
| Values/Behavioral | Not banked | Low. The invite names no values round and no published values are in hand | None needed |

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two colleagues ask you for the same Thursday hour in a shared calendar, and one of them is the person you report to. What do you do?" | CASE | [generic] | Clarify first: is either request movable, and is there a standing rule on whose comes first. Then state the objective (nobody double-booked, nobody told late), propose which one you would move and why, confirm the change in writing to both, and record it in the calendar. The question needs no claim about your past, so the guidance makes none | F1's requirement asked as a live decision rather than a record of the past; JD content, CASE delivery |
| A2 | "A manager asks you to book a trip for Thursday and the only cheap flight leaves at 6am. Walk me through it." | CASE | [generic] | Ask before you book: the purpose, the budget, who approves a higher cost, whether an earlier departure is acceptable. Offer two options with the trade-off in one line each, get a yes in writing, then book and send the itinerary. The question needs no claim about your past, so the guidance makes none | F2 is silent in the material, so this gives a method to rehearse; B2 asks the direct question; JD content, CASE delivery |
| A3 | "A supplier invoice arrives for more than the purchase order says. What happens next?" | CASE | [generic] | Clarify what the order covered and who raised it. Hold the invoice rather than pay or reject it, check the order against the invoice, ask the person who raised the order and the supplier, record what was agreed, and say who signs it off. The question needs no claim about your past, so the guidance makes none | F4's requirement as a live problem, so the answer rests on method; JD content, CASE delivery |
| A4 | "I've sent you last month's supplier invoices in a spreadsheet. I need the total per supplier by tomorrow. How do you go about it?" | CASE | [generic] | Clarify first: which columns, what cut-off date, whether duplicates or credit notes are in it. Then give your approach in plain steps at the level you are comfortable with, and say plainly where you would check something or look it up. Name nothing you would not use on the day. The question needs no claim about your past, so the guidance makes none | F3 and F4 meet here, and a method answer is the honest form while F3 is a self-rating; JD content, CASE delivery |
| A5 | "You get rough notes from a manager and need a one-page Word document for a client by end of day. What do you ask before you start?" | CASE | [generic] | Ask about the audience, the purpose, any template or house style, who reviews it and by when. Draft, check, and send it with a one-line cover note. The question needs no claim about your past, so the guidance makes none | F3's Word requirement as a live task; JD content, CASE delivery |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I'm good with Word, okay with Excel"; "chased unpaid invoices" | The highest-ROI rehearsal in this pack. Choose the one area your own sentences support least and say it at their scope: "I'm okay with Excel" or "I chased unpaid invoices". Say the limit before you are asked for it, then give a plan for closing it, as a plan and never as a past. First follow-up, how you would close it: name the first thing you would learn and who you would ask. Second follow-up, what if that takes longer than expected: say what you would do in the meantime. Hold by returning to the sentence, never by adding to it. Answer slot: the ad lists booking travel and your material is silent on it. If you have booked travel, say for whom and what you handled, in your own words; if you have not, or it was not yours, say so plainly and say how you would learn it first | F3 and F4 are where the ad's lines run past the material and F2 is where it is silent, so some form of this question is likely; JD because it scores the stated requirements, Skeptic in delivery |
| B2 | "Have you booked travel for anyone before?" | JD | [grounded] | Answer slot: the ad's travel line makes this direct question likely. If you have, say for whom and what you handled, in your own words; if you have not, or it was not yours, say so plainly and say how you would learn the process in your first weeks. A plain answer in two sentences beats a stretched one | F2 has no evidence, so the honest answer is built before the probe arrives |
| B3 | "The job is processing supplier invoices. You chased unpaid ones. Where does that overlap, and where does it stop?" | EXP | [grounded] "chased unpaid invoices" | Hold what the sentence carries: "I chased unpaid invoices." Answer slot: the ad's invoice line makes a probe on what you did with the invoices likely. Say what you did when an invoice stayed unpaid, in your own words; if the part you handled was narrower than that, or someone else's, say so plainly and describe only what you chased. Then say how you would learn the employer's own process, as a plan | F4's transferability gap, rehearsed so the limit is said first; the premise that chasing overlaps with the role is the question's, and the guidance does not adopt it |
| B4 | "Why this role, and why now?" | JD | [generic] | The reason is yours to give and the pack does not supply one. Answer slot: give your own reason in one or two sentences; if the honest answer is what appealed in the ad, say what, and do not add a longer-term plan you do not have | The standing Skeptic motivation probe; the guidance makes no claim about your past |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios"; "chased unpaid invoices"; "I'm good with Word, okay with Excel" | A 90-second arc using only these beats, in your own words: the two years as a receptionist at a physiotherapy clinic, the appointment book you ran for four physios, the unpaid invoices you chased, and Word and Excel at the levels you rated them. Close with one sentence of your own on why this role. Answer slot: if you want a beat beyond these, say it only if it is something you did | F1, F3 and F4 supply every beat; EXP because it tests whether the story is told at the scope you stated |
| C2 | "This role is remote. How would you organise a working day?" | JD | [generic] | Structure it as a routine: when you check the calendar and messages, how you flag anything that clashes or is missing, and how you stay reachable. Answer slot: if you have worked remotely, say how, in your own words; if you have not, say so plainly and describe how you would set up the day. The question needs no claim about your past, so the guidance makes none | The role title says remote, so how you would work unsupervised is likely; no fit row speaks to it |
| C3 | "How do you feel about Excel? Where are you comfortable, and where would you want practice?" | JD | [grounded] "I'm good with Word, okay with Excel" | Say it at the level you rated it: "I'm okay with Excel." Answer slot: name what you are comfortable doing in it, in your own words; if nothing specific comes to mind, say so plainly and say what you would practise first. Never name a feature to sound stronger | F3's Excel half in a casual register, where an over-claim comes out most easily |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our team and the finance side both send you urgent work in the same morning. How do you decide what goes first?" | CASE | [generic] | Ask who owns each deadline and what each costs if late. If it is still unclear, put the choice to both in one line each and let them settle it, then record the decision. The question needs no claim about your past, so the guidance makes none | The standing Peer seam question set in the ad's invoice and calendar duties; CASE delivery |
| D2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Pick a time when a piece of work passed through more than one person's hands. It needs a named piece of work, the part that was yours, and how the credit was shared. Use "we" for the context and "I" for your own part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The standing Peer credit-sharing probe; EXP because it scores attribution |
| D3 | "What would you need from me in your first month to do this job well?" | JD | [generic] | Say what you would need in one sentence each (access, the tools, who to ask), then what you would give back: early flags when something clashes or is missing. That is a commitment about the future, not a claim about your past | The reciprocity move, which lands when the office manager turns out to be a peer |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through how you ran the appointment book for four physios." | EXP | [grounded] "I ran the appointment book for four physios" | Story-mapped on F1, using only what the sentence states: the appointment book and the four physios, told in your own words. Answer slot: expect follow-ups on what the book covered. Say what you did, in your own words; if any part of it was set or handled by someone else, or there was no such part, say so plainly and stay with the book you ran | F1 is the evidence for the calendar requirement and the likeliest place to be probed; EXP because it tests what was actually yours |
| E2 | "Tell me what a typical week looked like in those two years." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | The sentence gives the role, the clinic and the two years, and nothing about the week. Answer slot: say what a normal week held, in your own words; if you cannot say, say so plainly rather than reconstruct it | A prober checks the span and the role against the detail; the guidance supplies no detail |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has already done this exact job?" | JD | [grounded] "I ran the appointment book for four physios"; "chased unpaid invoices"; "I'm good with Word, okay with Excel" | Pause and restate the question. Hold only what your sentences carry: "I ran the appointment book for four physios" and "I chased unpaid invoices", with Word and Excel at your own ratings. Hold through two follow-ups by returning to those sentences, never by adding to them. Concede specifically: your material carries the appointment book and the chasing, not travel booking or supplier-invoice processing, so concede that someone may be further ahead there and say what you would do about it. Never fold on what you did | F1, F3 and F4 supply the hold and the limit; JD content, Pressure delivery |
| F2 | "How much of the appointment book was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" | Pause, then anchor: "I ran the appointment book for four physios." Hold through two follow-ups by returning to the sentence. Answer slot: if any part of the book was set, covered or checked by someone else, say which part, plainly; if none was, say so and stay with the book you ran. Concede only what is true | The standing attribution challenge; F1's sentence is the only thing to hold |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "managing calendars" | A1, D1, E1, F2 |
| "booking travel" | A2, B1, B2 |
| "preparing documents in Word and Excel" | A4, A5, B1, C3 |
| "processing supplier invoices" | A3, A4, B1, B3, D1 |
| "Remote Administrative Assistant", the role title in the invite | C2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like in this role, and how would you tell I was on track?" | It shows you are thinking about delivering, and it gets you the yardstick in their words |
| R2 | "Which tools do you use for calendars, travel booking and invoices, and which would I be trained on?" | A practical question that brings the tools into the open on your terms |
| R3 | "How does a supplier invoice get from arriving to being paid here, and which step would be mine?" | It shows care about the invoice line and gets the scope of the duty from them |
| R4 | "Who would I report to day to day, and how often would we check in while I work remotely?" | It settles the relationship and shows you are planning for a remote role |
| R5 | "What equipment and software do you supply to remote staff, and is anything I would need paid for by the employee? Where would that be written in my contract?" | It puts the equipment arrangement on the record in the interviewer's own words, where you can compare it with what you were sent |
| R6 | "What could a new person do in their first month that would genuinely help you?" | The reciprocity question, which lands when the office manager is a peer |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars for an office or a team | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation, not words for you: the material says the appointment book, not calendars in general. A1 asks for method only |
| Processed supplier invoices | Inflated form of F4 | F4's quote at its own scope: "I chased unpaid invoices." The limit is the pack's observation: the material says chasing, not processing supplier invoices. B3's slot stays with what you did about an unpaid invoice |
| Strong or advanced Excel skills | Inflated form of F3 | F3's quote at its own scope: "I'm good with Word, okay with Excel." The limit is the pack's observation: a self-rating with no spreadsheet behind it. A4 and C3 stay with method and your own level |

## Sources

Provided documents: the invite email as you pasted it, and your message (the ad's duties as you listed them, and your background). No dossier was present.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Query | Outcome |
|---|---|
| Brennock Facilities Ltd company values | refused |
| Brennock Facilities Ltd strategy news | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | The search was refused. It would have moved published values for VAL questions; no values cheat sheet applies, since the invite names no values round |
| 2. `Brennock Facilities Ltd interview process administrative assistant` | skipped | The invite's own words fix the loop: one 30-minute video call with the office manager. That decides the persona weights and the absence of a values round |
| 3. `Brennock Facilities Ltd strategy` / recent news | unavailable | The search was refused. It would have moved CO questions, so the banks hold none |
| 4. `{interviewer name} Brennock Facilities Ltd` | n/a | No name was given, only a title, so there was no query to form; the interviewer read is absent |
| 5. representative `Administrative Assistant` JD | skipped | The duties you listed fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's full text → the requirement rows quote the ad itself instead of your list of its duties, and any requirement you did not list gets a question
- Whether the office manager is your future manager or a peer → persona weights recomputed and the banks reweighted
- The office manager's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their path
- Anything the call has been said to cover, in the invite or from the hiring side → coverage of those focus areas in place of round-type priors
- Your own answers to the slots in F2, F3 and F4 → those rows regenerate with your words in place of the slots
- Search access (the two searches I tried were refused) → company values and strategy, so CO questions replace the generic ones; a deeper pass would add up to 6 more searches and 2 more fetches, several more minutes
- How much prep time you have → a prioritised schedule sized to it
- A `tuesday-dossier.md` → verified evidence and recorded objections the pack would build on, instead of inferring B1 from your message
