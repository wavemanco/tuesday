I've run the district, interviewer and role searches. The values snippet cut off mid-sentence, so I'm fetching that page, along with the principal's profile page, before I write the pack.
Research is done. Before I offer to save the dossier, I'm reading its handoff spec. Then I'll write the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/tuesday/part-5/rooms/case-9-canned-101a964f/Halvering-Elementary_fourth-grade-teacher_interview_pack.md`. It has 22 questions, built for a panel with the principal as hiring manager and the two fourth-grade teachers as peers. Your invite had no full posting, so the rows that need job requirements use a representative fourth-grade posting and are marked `[inferred]`.

- **Biggest objection:** "You've never taught fourth grade" is the one the pack rehearses most deeply (A1, with A2, A4 and H1 as variants). It also covers how much of the 2024 reading curriculum move was yours, since you also said you've never been a team lead.
- **Your license:** the invite makes the Illinois license a requirement. Your resume shows it active through June 30, 2029, and A5 rehearses saying so.
- **Social Security number:** your resume included one. I don't need it, so I didn't use or repeat it, and you can leave it out of anything you share for this.
- **Sources:** the pack draws on the district's published beliefs, its new literacy plan, and the principal's public profile (nine years as a reading specialist, a 2025 talk on reading conferences). Every page came from a `.example` host. The names match your invite, but check the district's own site before you quote its belief wording.

Say the word and I'll run a live drill as the Skeptic on A1, the question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full posting for the Fourth Grade Teacher job? It's fine to skip, since the pack stands without it.
Do you know who the two fourth-grade teachers on the panel are, or whether either leads the team?
Do you want a deeper research pass, with up to 6 more searches and 2 more fetches taking several more minutes?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering-Elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Role:** Fourth Grade Teacher, Halvering Elementary School, Orrinsford Community School District
**Round:** one 45-minute panel on Thursday
**Panel:** Principal Dolores Vantongeren, plus two members of the fourth-grade team (names not given)
**Relationship read:** the principal as hiring manager, the two teachers as peers and future teammates
**Built on this assumption:** no full posting was supplied, so rows that need a job requirement beyond the invite use a representative posting for this title and are marked `[inferred]`.

**The highest-ROI prep in this pack is A1.** The objection "you've never taught fourth grade" will be asked in some form. A1 gets the deepest rehearsal: the most follow-up levels, the exact concession wording, and a limit named before anyone asks for it. A2, A4 and H1 are the same objection in other registers.

## How to use this pack

- **Personas describe how a question is asked. Types describe what it scores.** Every question carries both.
- **Type key**
  - VAL: whether past behavior shows the district's published beliefs.
  - EXP: whether your CV claims hold up, and what was actually you.
  - JD: the job's stated requirements, gaps included.
  - CO: homework on the district and its current plan.
  - CASE: a live problem set in the role.
- **Guidance is scaffolding, not a script.** Every quoted sentence is your own, from your CV or your message. Where a cell says "answer slot", the interview will probe something your material does not show, and the honest answer is yours, in your words. If the practice was not yours or never existed, say so plainly.
- **Bank letters skip F** so a question ID never collides with a fit-snapshot row.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | This is a gate, and your CV shows it met, so the row routes by its evidence like any other. Say it in the CV's own terms and stop. Nothing has been inspected behind the sentence here, and checking a license is the employer's and yours, not this pack's. The pack's own observation: grades 1–6 spans fourth grade |
| F2 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board, a representative posting and not this school's | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | discovery | Your sentence gives the grade and the years, and does not show which subjects you taught. The words stay there: "For six years I taught third grade at a public elementary school in Joliet." Answer slot: the representative posting lists five subject areas, so expect a probe on which you planned and taught yourself. If you taught any of them, say which and how you planned them, in your own words; if some were taught by someone else, or not at all, say so plainly and stay with third grade as you taught it |
| F3 | "Fourth Grade Teacher position" — your invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." Then what you would learn first, said as a plan and never as a past. Nothing added to make the gap feel smaller. The pack's observation: the nearest work your material shows is in F2 |
| F4 | "work with the grade-level team" — K12 Jobs Board, a representative posting | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [inferred] | presentation | Say the sentence at its own scope: "I led our grade level's move to a new reading curriculum in 2024." The pack's observation: it is a sentence about a move your grade level made, and says nothing yet about how the team worked day to day. Let the panel's follow-up decide whether that comes up; B1 and B2 rehearse it |
| F5 | "reading instruction" — Orrinsford "How we hire teachers" page, naming what panels ask about | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | presentation | Both sentences already speak to reading in other terms, so the words stay at their scope: "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." The pack's observation: neither says how you teach reading day to day. C1 holds that slot |
| F6 | "differentiate instruction using assessment data" — K12 Jobs Board, a representative posting; and "assessments inform teaching and never replace it" — Orrinsford "Mission and Beliefs" page | none given | none | [inferred] | discovery | Nothing in your material speaks to this. Answer slot: both the representative posting and the district's third belief raise assessment, so expect a probe. If you used assessment results to change what you taught, say what changed and what the results were, in your own words; if you did not, or it was not yours to do, say so plainly and say what you would look at first |
| F7 | "keep clear classroom routines" — K12 Jobs Board, a representative posting; "classroom routines" also names a panel topic on Orrinsford's hiring page | none given | none | [inferred] | discovery | Nothing in your material speaks to this. Answer slot: if you kept classroom routines, say which and how you taught them to the class, in your own words; if there were none in some part of the day, or they were set by someone else, say so plainly and say what you would set first |
| F8 | "communicate regularly with families" — K12 Jobs Board, a representative posting | "I write a weekly email to families" — your CV | medium | [inferred] | none | No gap on the requirement as worded. Lead with the sentence in its own terms, a weekly email to families, because a named rhythm beats an adjective. Expect a probe on what goes in it; E3 holds that slot |
| F9 | "each teacher speaks with every family each term" — Orrinsford "Mission and Beliefs" page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | An email and speaking with a family are different kinds of contact, so the words stay at the quote's scope: "I write a weekly email to families." Answer slot: the district's belief sets a standard for speaking with families, so expect a probe. If a family ever answered one of your emails, say what happened next, in your own words; if none did, or you did not follow up, say so plainly and stay with the weekly email |

## Reading the interviewer

Public professional footprint only. No self-described style was found, so none is inferred. The two fourth-grade teachers are not named in the invite, so nothing was researched about them.

| Fact | Source | Provenance | What it means for you |
|---|---|---|---|
| "principal of Halvering Elementary School since 2022" | Illinois principals forum speaker page | [grounded] | Context for the panel; no coaching hangs on it |
| "nine years as a reading specialist" before that | same page | [grounded] | Expect reading instruction asked with specificity; the Case bank (C) leans on this |
| 2025 forum talk "Small Groups, Big Readers", covering "weekly reading conferences in grades 3 to 5" | same page | [grounded] | Her likely vocabulary is small groups and reading conferences. C1 prepares for it, and reverse question R2 uses it |
| Mirror opportunity: reading is shared professional ground between her public path and F5's sentence "I've run the after-school reading club for the last two years" | derived from the rows above and F5 | [inferred] | Say your sentence as written when reading comes up, and ask about her approach. Do not borrow her methods or claim her vocabulary as your practice |

## Persona table

The weights come from the relationship priors, adjusted by the interviewer's public path and by the loop. The loop is established: the district's hiring page describes one 45-minute building panel of the principal and two grade-level teachers, so no archetype fallback is used. Recalibrate if you know something this does not.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic (5 questions) | Quiet, persistent probing of the fourth-grade gap and of how much the curriculum move was yours | High. The hiring-manager prior includes the Skeptic, and your own message states two negatives (never taught fourth grade, never a team lead) | Rehearse the single predictable objection (A1) until it is boring; bridge only from sentences you have stated; name the limit before it is extracted |
| C. Case / Strategist (4) | Live problems from the role: plan a reading week, respond to an assessment | High. The hiring-manager prior includes it, her nine years as a reading specialist tilt it toward reading, and the district page names reading instruction as a panel topic | Clarify first, then structure, then answer; think aloud; use her vocabulary only where you mean it |
| B. Peer Evaluator (3) | Teammates asking what you would need from them, and how disagreements get handled | Medium to high. Two of the three panelists are fourth-grade teachers | Reciprocity: say what you bring at the scope of your sentence as well as what you need; give seam principles, not claims to know their seam |
| D. Values / Behavioral (3) | Prompts themed on the district's three published beliefs | Medium. The beliefs page says they guide every hire, but no source describes a round that scores them, so no values-style round is detected and there is no values cheat sheet. The questions are themed on the beliefs only | Pick a real instance for each belief; where none comes to mind, say so plainly and give the nearest thing your material carries |
| E. Conversational (3) | Friendly openers: your journey, your routines, your families | Medium. The district page names routines and families as panel topics, and an opener like E1 is near-certain in any panel | Prepare a 90-second arc (E1); treat casual questions about routines and families as scored |
| G. Data-Driven Prober (2) | Teachers pressing on what a claim rested on | Low. Your CV carries no figures to probe, so the probing falls on the reading club and the curriculum move | Know what you can and cannot say about each of those two, and say plainly what you did not track |
| H. Pressure (2) | Time-boxed or devil's-advocate versions of the gap questions | Low. One 45-minute building panel with no documented stress format | Pause, restate, hold the sentence as written through two follow-ups, concede only what you have said yourself |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your six years are in third grade. What will be new for you on your first day in fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | The highest-ROI rehearsal in this pack. Open with both facts as written, so nobody has to extract the second: "For six years I taught third grade at a public elementary school in Joliet," and "I've never taught fourth grade." Then the plan, said as a plan: the first two or three things you would ask the fourth-grade team to show or explain, in your own words, with no claim about what fourth grade involves that you have not seen. Follow-up 1, what worries you most: name one thing, truthfully. Follow-up 2, what if our approach differs from yours: say how you would ask before you would change anything. The limit, named before it is asked for: you can describe third grade as you taught it, not fourth grade as you taught it. Answer slot: if any of your third-grade work already touched what fourth graders do, say what, in your own words; if none did, say so plainly and stay with third grade as you taught it | F3 is the one gap you have stated, and F2 holds the nearest work, so this objection arrives in some form. JD content, Skeptic delivery |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Choose from what you have said yourself, not from what sounds safe. The only gap your material states is fourth grade, so say it in your words, "I've never taught fourth grade," and follow it at once with the first thing you would do about it, as a plan. Do not shrink it. If you hold a different real weakness, name that one instead, in your own words; the pack does not supply one | F3 is the stated gap, and this stem is the Skeptic's standard way of reaching it. JD because it scores the job's own requirement |
| A3 | "You led your grade level's move to a new reading curriculum, but you haven't been a team lead. How much of that was you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Hold the sentence as written: "I led our grade level's move to a new reading curriculum in 2024." If they test the second half, say it plainly as you told me: "I've never been a team lead." Say the move, not the team, and hold through two follow-ups by returning to the sentence, never by adding to it. Answer slot: the follow-up will ask which parts of the move were yours; if you can say which, say them in your own words; if the work was shared, or you cannot separate it, say so plainly and return to the sentence | F4 and F5 hold the sentence, and your message states the second half. EXP because it tests attribution |
| A4 | "Why move from a grade you know to one you've never taught?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | The pack does not supply your reason. Answer slot: give your actual reason in one or two sentences, in your own words, and keep it about what draws you to fourth grade or to this school if either is true. If your reason is not specific to fourth grade, say that plainly rather than building one. Then stop, and do not apologize for the third-grade years | F3 raises the motivation probe. EXP because a reason for moving is a claim about your own history |
| A5 | "Does your license cover fourth grade?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Answer in the document's terms: "Illinois Professional Educator License, Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029." Then stop and let them read the range. If the panel asks for the license number, give it from your own license record; no number appears in this pack | F1 is the hard requirement in the invite, so it earns a question. JD because it scores the stated qualification |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A group of your students read at very different levels. Walk me through how you'd plan a week of reading." | CASE | [generic] | Clarify first, aloud: what you would want to know about each reader and what plan already exists for them. Then objective, grouping, what the week holds, how you would tell it is working, and what could go wrong; state your hypothesis early. Her published talk (see Reading the interviewer) covered small groups and weekly reading conferences, so expect those words and use them only if you mean them. Answer slot: if you have used small groups or reading conferences, say how, in your own words; if you have not, say so plainly and say how you would find out how this school does them | F5's slot, rehearsed. A live problem built from the district's own reading-instruction topic and the principal's public focus; `[generic]` because the problem is a pattern, and the question needs no claim about your past. CASE content, Case delivery |
| C2 | "The board adopted a three-year literacy plan with a new grades 3–5 reading curriculum from fall 2027. How would you get ready to teach through that change?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Know the plan's three pieces from the district's own news page: structured phonics from kindergarten to second grade, the grades 3–5 reading curriculum from fall 2027, and a family reading night at every school each term. Say what you would ask first, such as which curriculum and when training starts, rather than pretending to know. Say your own sentence as written: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if that move taught you something you would bring to this change, say what, in your own words; if it did not, or it does not carry over, say so plainly and stay with the sentence | F4 and F5 hold the sentence. CO because it needs the district's current plan, from research and not from memory |
| C3 | "A student's reading assessment shows slower progress than you expected. What do you do next?" | CASE | [generic] | Structure it, using the district's third belief in its own words: assessments inform teaching and never replace it. Ask what the assessment measured and what else you know about the child; choose a next step the result informs without dictating; bring the family in; check again after a set time. The question needs no claim about your past, so the guidance makes none | F6's requirement, asked as a decision. CASE because it is a live problem from the posting's assessment line and the district's belief |
| C4 | "Walk me through how you'd plan a week across reading, writing, math, science and social studies." | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Structure it: what each subject needs this week, how the time is shared, where subjects connect, how you will check understanding. Think aloud, and name one thing you would confirm with the team. Answer slot: a follow-up may ask which of these subjects you planned yourself; if you planned any, say which and how, in your own words; if some were planned by someone else, or you did not teach them, say so plainly and stay with third grade as you taught it | F2 is the evidence and the likeliest place for the posting's subject list to be probed. JD content, CASE delivery |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You'd be joining our fourth-grade team. What would you want from us in your first month, and what would you bring us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never taught fourth grade" | Reciprocity, in both directions. What you bring: your sentence as written, "I led our grade level's move to a new reading curriculum in 2024," and let them decide what it is worth to their team. What you need: say plainly "I've never taught fourth grade," and ask for what you would want to see first, in your own words | F4 and F3. JD because the posting asks you to work with the grade-level team |
| B2 | "Tell me about a time you disagreed with a colleague about how to teach something." | VAL | [generic] | Pick a real disagreement. Name what was at stake for students, what you said and how you said it, and where the working relationship stood afterwards. Use "we" for context and "I" for your own part. If no such time comes to mind, say so plainly, then say how you would handle one, as a plan | The Peer stem about disagreement, aimed at F4's thin day-to-day team evidence. VAL because it tests behavior with equals, and `[generic]` because the prompt supplies no event |
| B3 | "Where would you expect a fourth-grade team to decide together, and where would each teacher decide alone?" | CASE | [generic] | Offer seam principles, not a claim to know their seam: decisions that shape every student's path are shared, choices inside one classroom are each teacher's. Say you would ask where this team draws the line, and end by inviting their view. Think aloud | The Peer stem about where the seam is. CASE because it is a live question about the role. It needs no claim about your past |

### D. Values / Behavioral

The prompts are themed on the district's three published beliefs, by name.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "One of our beliefs is Every Child a Reader. Tell me about a time you helped a child who was behind in reading." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Pick one child or one small group, name what was at stake, what you did, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I've run the after-school reading club for the last two years," or how you would handle it. The belief's own definition is "no student leaves third grade without a reading plan" | The first of the three published beliefs, raised by the district's own page. VAL because it tests behavior against a stated value |
| D2 | "Families Are Partners is another of our beliefs. Tell me about a time you worked with a family through something difficult." | VAL | [grounded] "I write a weekly email to families" | Pick one family and one real difficulty, and say what you did and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I write a weekly email to families," or how you would handle it | The second published belief, tied to F8 and F9. VAL because it tests behavior against a stated value |
| D3 | "Tell me about a time what your students needed changed what you taught." | VAL | [generic] | Pick a real instance: what you noticed, what you changed, and what followed. If no such time comes to mind, say so plainly, then say how you would handle it, as a plan | The third published belief, that assessments inform teaching and never replace it, tied to F6. VAL, and `[generic]` because the prompt supplies no event |

### E. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through your journey to teaching, and to this school." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" | A 90-second arc with the three beats your sentences state: the six years of third grade in Joliet, the 2024 reading curriculum move that you led for your grade level, and the reading club you have run for two years. The close is your own reason for fourth grade and this school. Answer slot: the pack does not have why you became a teacher or why this school; give your own, a sentence each. If a reason is not one you can state, say so plainly and stay with the three beats | The opener is near-certain in any panel. F2, F4 and F5 are the beats. EXP because it tests the CV's story |
| E2 | "Walk me through the first ten minutes of your school day with a class." | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: a routine is the likely probe, since the representative posting lists clear classroom routines and the district's hiring page lists classroom routines as a panel topic. If you kept a routine at the start of the day, describe it in your own words; if the start of your day had no set routine, or it was not yours to set, say so plainly and describe what you did do | F7's requirement, asked casually, which is how a rapport-style panelist asks it and still scores it. JD because it scores a stated topic |
| E3 | "How do you keep families in the loop?" | JD | [grounded] "I write a weekly email to families" | Say it as written: "I write a weekly email to families." That is a rhythm and a channel, so lead with both. Answer slot: the follow-up is likely what goes in it. Say what you actually put in it, in your own words; if it varied or you cannot recall, say so plainly and stay with the weekly email | F8 is the evidence. JD because it scores the families requirement |

### G. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me more about the reading club: who comes, what happens, and what you've seen." | EXP | [grounded] "I've run the after-school reading club for the last two years" | Say the sentence as written, then answer only what you can. Answer slot: if you can say who attends and what a session looks like, say it in your own words; if you did not track something, say so plainly and stay with "I've run the after-school reading club for the last two years." No figure is on your CV, so none is offered here | F5's second sentence, the one a teacher-peer can ask about most easily. EXP because it tests what was actually yours |
| G2 | "How did you know the new reading curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say what the sentence says: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if you looked at anything after the move to see how it was going, say what, and what it showed, in your own words; if you did not, or it was not yours to look at, say so plainly and stay with the sentence. Never describe a measure you did not track | F4 and F5 hold the sentence. EXP because it probes the claim's basis |

### H. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over a teacher who has already taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've never taught fourth grade" | Pause and restate the question. Hold on what your sentences carry, in those words: six years of third grade in Joliet, and you led your grade level's move to a new reading curriculum in 2024. Concede the one thing you have said yourself, "I've never taught fourth grade," and stop. Hold through two follow-ups by returning to those sentences, never by adding to them and never by claiming to be the stronger candidate | The Pressure version of A1's objection. JD because it scores fit for the stated role, Pressure delivery |
| H2 | "Our belief is that each teacher speaks with every family each term. An email isn't speaking with them, is it?" | VAL | [grounded] "I write a weekly email to families" | Pause, then hold on the sentence as written: "I write a weekly email to families." Do not stretch it into something it is not, and do not fold into agreement just to ease the moment. Answer slot: if a family ever answered one of the emails, say what happened next, in your own words; if none did, or you did not follow up, say so plainly and stay with the weekly email | F9's gap, pressed. VAL because the district's published belief is the standard being applied |

### Requirement coverage

| Requirement | Fit row | Questions |
|---|---|---|
| Illinois PEL with an elementary endorsement | F1 | A5 |
| Fourth Grade Teacher position | F3 | A1, A2, A4, H1 |
| "plan and teach reading, writing, math, science and social studies" | F2 | C4, C1 |
| "differentiate instruction using assessment data" | F6 | C3, D3 |
| "keep clear classroom routines" | F7 | E2 |
| "communicate regularly with families" | F8 | E3, D2 |
| "work with the grade-level team" | F4 | A3, B1, B2, B3 |
| "reading instruction" | F5 | C1, C2, D1, G1, G2 |
| "each teacher speaks with every family each term" | F9 | H2, D2 |
| Qualifications after the license clause of the representative posting | none | none, and why: the search result was cut off mid-sentence, so nothing beyond the license clause can be quoted; the upgrade menu asks for the full posting |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You spent nine years as a reading specialist before becoming principal. What do you look for first when a fourth-grade teacher teaches reading?" | It ties to her own path and shows you read about her, not only the school | [grounded] |
| R2 | "Your 2025 talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5. What does that look like in a fourth-grade classroom here?" | It turns her published work into a conversation about the job and tells her you looked for it | [grounded] |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | It is the reciprocity question for the two teammates, and it shows you are thinking about their load | [generic] |
| R4 | "The board's literacy plan brings a new grades 3–5 reading curriculum from fall 2027. How is the fourth-grade team getting ready for it?" | It shows you know the district's current plan and asks about the team's real work | [grounded] |
| R5 | "How does the fourth-grade team plan together, and where does each teacher decide alone?" | It asks about the seam instead of guessing at it, and it answers B3's ground for real | [generic] |
| R6 | "What does a strong first term look like for a teacher who is new to fourth grade here?" | It names your gap yourself and asks for the bar, which turns the objection into a mentoring conversation | [generic] |

## Prohibited claims

What this pack will not coach, with the basis and the honest form for each. It was built before the question banks.

| Not coached | Basis | Honest form |
|---|---|---|
| Served as a team lead, or led the grade-level team | Negative you stated: "I've never been a team lead" — your message | The plain acknowledgment, as you said it: "I've never been a team lead." No answer slot |
| Has taught fourth grade | Negative you stated: F3, "I've never taught fourth grade" | The plain acknowledgment, as you said it: "I've never taught fourth grade." No answer slot |
| Chose or designed the new reading curriculum | Inflated form of F4 and F5 | The sentence at its own scope: "I led our grade level's move to a new reading curriculum in 2024." The limit is the pack's observation, not words for you: the material says the grade level's move. A3's slot stays inside the move |
| Ran a school-wide reading program | Inflated form of F5 | The sentence at its own scope: "I've run the after-school reading club for the last two years." The limit is the pack's observation: the material says an after-school club. G1's slot stays inside the club |
| Spoke with every family each term | Inflated form of F9 | The sentence at its own scope: "I write a weekly email to families." The limit is the pack's observation: the material says a weekly email. H2's slot stays inside the email |

## Sources

**Provided documents:** your invite; your resume text and message. No `tuesday-dossier.md` was present, so none was consumed. No license number appears in any search or fetch.

**Searches sent (5) and what came back**

1. `Orrinsford Community School District mission values` — returned https://orrinsfordschools.example/about/mission-and-beliefs
2. `Orrinsford Community School District teacher interview process` — returned https://orrinsfordschools.example/careers/how-we-hire-teachers
3. `Orrinsford Community School District strategic plan news` — returned https://orrinsfordschools.example/news/board-adopts-literacy-plan
4. `Dolores Vantongeren principal Halvering Elementary School` — returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
5. `Fourth Grade Teacher job description Illinois elementary school` — returned https://k12jobsboard.example/listings/fourth-grade-teacher

**Fetches sent (2):** the Mission and Beliefs page (the fetch completed the third belief's wording, which the search snippet had cut off) and the principal's forum page.

**Source note:** every page returned sits on a `.example` host. The names match your invite, so I used them as the district's own, but open the district's site yourself before you rely on the belief wording.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | The three beliefs by name, which theme D1 to D3, C3 and H2. No values-style round is detected, so section 10, the values cheat sheet, is absent |
| 2. `{company} interview process {role family}` | yes | The loop: one 45-minute building panel, the principal and two grade-level teachers, with reading instruction, classroom routines and families as topics. This set the persona weights, with no archetype fallback |
| 3. `{company} strategy` / recent news | yes | The 2026–2029 literacy plan, which fed C2 and R4 |
| 4. `{interviewer name} {company}` | yes | The interviewer read, C1's slot and R1 and R2. The fetch of her page returned the same two sentences as the search snippet and added nothing |
| 5. representative `{role title}` JD | yes | The requirement text behind F2, F4, F6, F7 and F8, marked `[inferred]`. The result was cut off after the license clause, so only the responsibility phrases are quoted |

## Upgrade menu

- The full posting text for this job → rows F2, F4, F6, F7 and F8 move from `[inferred]` requirements to `[grounded]` ones, and the coverage table is rechecked against the real list
- The names and roles of the two fourth-grade teachers, and whether either leads the team → persona weights per panelist, and a reverse question tied to each one's public path
- Anything HR said about what the panel covers, or about bringing something such as a lesson plan or work sample → a build section for any deliverable they declared
- Your own words on the answer slots in A1, A3, C1, C4, E2, E3, G1, G2 and H2 → upgrades rows F2, F4, F5, F6, F7 and F9 from slots to quoted material
- How many hours you have before Thursday → a prep triage ordered to that time
- A `tuesday-dossier.md` from an earlier check on this role, if you have one → verified evidence and prohibited claims arrive pre-built; this pack stands without it
