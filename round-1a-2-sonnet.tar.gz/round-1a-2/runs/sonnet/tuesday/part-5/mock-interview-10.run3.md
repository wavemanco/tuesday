Web search was denied, so nothing about Lumenvale itself will go into the pack. I'm writing it from what you've told me and will say so in the sources section.
Before the prep, one thing in the invite: it says the process is "carried out entirely on Telegram" and that "if you are successful your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern. This doesn't show who sent it. You applied through Lumenvale's careers page, but this reached you on Telegram, so check that page for how they contact applicants. Hold off on paying anything, sending documents or giving bank details through the chat. Check the invite with Lumenvale using contact details from its own website or careers page, never ones from the chat. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved at `/var/tmp/tuesday-measure/1a2/runs/sonnet/tuesday/part-5/rooms/case-10-denied-e970662f/lumenvale-software_customer-support-specialist_interview_pack.md`. It has 18 questions and 6 questions for you to ask. I assumed a hiring-manager-style round with the support team lead. The web searches I tried were refused, so nothing about Lumenvale itself is in it, and the company-knowledge question is generic.

The question to rehearse most is B1, "You haven't worked in software before. What worries you most about starting here?" Your own words cover three years at the energy supplier and daily Freshdesk use. The pack won't stretch them into software experience. It gives you a plain acknowledgment and a learning plan instead.

Say the word and I'll play the Skeptic on B1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Will the support team lead be your direct manager, and has Marcus mentioned any focus areas or format for the chat? Either answer would reweight the question banks.
Can you paste the full job ad? I'll carry on without it if not.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview pack: Customer Support Specialist, Lumenvale Software

**Interviewer:** the support team lead, name not given. The invite says the interview is a text chat on Telegram with this person.
**Relationship assumed:** hiring-manager style. Your note does not say whether the support team lead would be your manager, so the weights below rest on that assumption.
**Format:** one session, a text chat. The invite is the only source for this, so the pack is built for one session and not a loop.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. This is a text chat, so rehearse by typing your answers, not just thinking them.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the values a company publishes |
| EXP | Work-experience deep-dive | Whether the claims about your past survive a follow-up |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company knowledge | How much homework you have done on the company |
| CASE | Live problem | Structure and reasoning on a problem from the actual role |

## Fit snapshot

The requirements are quoted from the ad as you listed it in your message. All evidence is your own words from your message. Nothing has been inspected behind them, such as a CV or a ticketing-tool record.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as you listed it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap in the words. Lead with the quote's own terms: three years as a customer service advisor at an energy supplier. Keep "customer service advisor" as you wrote it. Expect a probe on the daily volume, because a line with nothing inspected behind it gets tested (C1 and E2 rehearse it) |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as you listed it | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Your material names Freshdesk, and the ad names Zendesk or a similar tool. Say what you wrote: "I use Freshdesk every day." Stay at that scope, because the quote does not say which parts of it you use. Expect a probe on how |
| F3 | "clear written communication" — job ad, as you listed it | "answering around 60 calls and emails a day" — your message; "I trained four new starters on our refunds process last year" — your message | low | [inferred] | discovery | Your material says emails and training, and does not show whether any of it was written or reviewed. The interview is itself a text chat, so expect your writing to be read as you answer. Answer slot: if any of your written replies or training notes were checked or kept by someone else, say what; if none were, say so plainly and stay with what you did |
| F4 | "confidence handling escalations" — job ad, as you listed it | none given | none | [grounded] | discovery | Your material does not mention escalations. Answer slot: the ad's line makes a probe on one likely. If you handled any, say what it was and what you did, in your own words; if escalating was not part of your role, or you did not, say so plainly and say how you would handle one, as a plan |
| F5 | Software-company experience: not a line in the ad as you listed it; it is the gap you raised | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan and never as a past. Never a claim to software-company work, and nothing added to make the gap feel smaller |

None of these rows is a gate in the sense of a term you either meet or do not. "2+ years" is experience, so it is graded like any other row.

## Persona table

The relationship prior for a hiring-manager round is Case/Strategist plus Skeptic. Your own words (the invite) set the format as one text chat. Nothing about the interviewer's style is known, so no signal adjusts the weights.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live support scenarios you answer by typing | High: the hiring-manager prior, and the ad's escalation and written-communication lines are best tested live | Clarify first, then say your order of action, then what you would write back, then what you would record. Think aloud in short lines |
| B. Skeptic | Quiet, persistent probing of what is missing | High: you raised the software-company gap yourself (F5), and F3 and F4 are the thinnest rows | Rehearse the F5 question until it is boring. Use only the stated limit and a plan |
| C. Data-Driven Prober | Asks how a number was counted, and what was yours | Medium: "around 60 calls and emails a day" and "four new starters" are both figures (F1, F3) | Know what you can and cannot say about how each was counted, and say plainly when you do not know |
| D. Conversational | Friendly openers that are still scored | Medium: a chat usually opens with "tell me about yourself", and the prior is not strongly for it | Have a 90-second arc ready that uses only your own quoted lines |
| E. Pressure | Short, challenging, time-boxed | Low: not in the hiring-manager prior, and a text chat gives less room to interrupt | Pause, restate, hold your position through two follow-ups, concede only what is true |

## Question banks

Every question carries its provenance label. Where the guidance rests on something you said, the sentence is quoted beside the label.

### A. Case / Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in furious. They say the software lost a week of their work and they want a refund. What do you do first?" | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Structure it: what you would ask before acting, what you would say to acknowledge them, what you could fix yourself and what needs someone else, what you would write back, what you would record | A live problem from the escalation line (F4); CASE because it is a decision, not a history |
| A2 | "Five tickets land together: an outage report from a long-standing customer, a password reset, a feature request, an angry follow-up and a billing query. In what order do you take them, and why?" | CASE | [generic] | Say your order aloud and name the one rule behind it, such as who is affected or what cannot wait. Say what you would tell the customers who wait. No claim about your past is needed | Tests judgment under load for the JD's escalation line (F4); `[generic]` because it is a pattern, not a fact about this team |
| A3 | "Tell me about a time you escalated a customer issue." | JD | [grounded] | Open prompt, and no quoted sentence of yours carries an escalation, so this is a selection scaffold. Pick a time with a named issue, the moment you decided it needed someone else, what you told the customer and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The ad's escalation line makes this likely; F4 is the row it presses on. JD because it scores the stated requirement |
| A4 | "A customer asks a technical question you can't answer, and they want the answer now. What do you write?" | CASE | [generic] | Say what you do know, what you are checking, when they will hear back and who you would ask. Do not guess to fill the silence. No claim about your past is needed | F5 makes this the most natural way to test the software gap. CASE because the interviewer sets the problem |
| A5 | "Reply to this customer in two or three lines, and type it here: 'The app crashes every time I try to export. Fix it.'" | JD | [generic] | A live writing sample for the ad's written-communication line. Acknowledge, give one clear next step or one clarifying question, say what happens next. Plain words, no jargon, no promise you cannot keep. No claim about your past is needed | F3's requirement tested directly. JD with CASE delivery, because the chat itself is the sample |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked in software before. What worries you most about starting here?" | EXP | [grounded] "I've never worked for a software company"; "I use Freshdesk every day"; "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | The highest-ROI rehearsal in this pack. Hold, then concede. Concede first in your own stated words: "I haven't worked for a software company." Then hold only what your quotes carry: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Do not call either one software experience. Then give a plan for what you would learn first. Follow-up 1, "our customers are often technical, how would you cope": answer as a plan, not a past. Follow-up 2, "what if you can't fix their problem": say who you would ask and what you would tell the customer. Answer slot: if any of your day-to-day work already touched a product you supported, say what it was, in your own words; if none did, say so plainly and stay with the quotes | F5 is the likeliest objection and the thinnest row. EXP because it tests what was actually yours |
| B2 | "Which part of this job would be hardest for you on day one?" | JD | [generic] | Name the real answer. Your material is thinnest on escalations and on written work (F3, F4), but the answer is yours to choose. Say what you would do about it. Do not offer a weakness you do not have | A standard Skeptic stem that presses wherever the evidence is thin |
| B3 | "You've spent three years at an energy supplier. Why move to software support, and why now?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Answer slot: give your actual reason in one or two sentences, in your own words, because the pack will not supply one. Do not run down your current employer. If there is no single reason, say what is true | Motivation consistency is what a Skeptic scores (F1, F5). EXP because the reason for moving is yours to give |
| B4 | "The ad says Zendesk or something similar, and you've used Freshdesk. What would you need to pick up here?" | JD | [grounded] "I use Freshdesk every day" | Hold the quote: "I use Freshdesk every day." Answer slot: the ad's line makes a probe on how you use it likely. Say what you do in it day to day, in your own words; if a feature or step the interviewer names is not one you use, say so plainly and return to what you do. Then say how you would learn the team's tool, as a plan, with no timeline unless you have a basis for one | F2 is the evidence for this requirement. JD because it scores the stated tool line |
| B5 | "I don't see escalations anywhere in what you've told me. How would you handle your first one here?" | JD | [grounded] | Answer slot: if you have handled escalations, say how, in your own words; if you have not, or it was not yours, say so plainly. Then answer the question as a plan: what you would find out first, what you would tell the customer, what you would hand over and to whom. A plan is stated as a plan | F4 is the row this presses on, and the ad's escalation line makes it likely. JD because it scores the stated requirement |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Say "around", as you wrote it. Answer slot: if you know how the figure was counted, say so (a system report, an estimate, your own tally); if you do not know, say so plainly. Name the assumption behind it that you would defend least, and say what part was yours. Give a split between calls and emails only if you know it | F1 holds the figure. EXP because Probers test whether headline numbers survive |
| C2 | "Tell me about training the four new starters on refunds. What was your part?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Say it as it stands: four new starters, the refunds process, last year. Answer slot: the quote does not say what the training consisted of. If there were sessions, notes or shadowing, say which, in your own words; if it was informal, or shared with others, say so plainly. Say which part was yours | F3 holds the quote, and it is the only one that touches writing or explaining. EXP because it tests what was actually yours |
| C3 | "Walk me through the refunds process you trained them on." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Answer slot: walk through the steps as you actually know them, in your own words. If part of it was not yours, or you do not remember a detail, say so plainly and stay with what you do know. The pack supplies no steps | Tests whether you can explain clearly, which is the ad's written-communication line (F3). EXP because it checks the claim with a follow-up |

### D. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you get from there to here?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day" | A 90-second arc with three beats: the three years as a customer service advisor at an energy supplier; the tool you use every day, Freshdesk; and why this role, which is your own reason and the pack will not supply it. Type it once, then cut it by a third | F1 and F2 are the only career beats your material carries. EXP because it is the biography question |
| D2 | "What do you know about Lumenvale so far, and what made you apply?" | CO | [generic] | This pack could not look Lumenvale up, so it supplies no company facts. Selection scaffold: find one specific thing on Lumenvale's own website or careers page and say why it matters to you. If you have not found anything, say so plainly and say what drew you to the role itself | CO because it scores homework. `[generic]` because no research ran |
| D3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold. Pick a time with a named customer problem, the metric or rule that pulled the other way, what you chose and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard rapport stem on the support job's core tension. VAL because it scores values-style behavior, with no published values in hand |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's already worked in software support?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I've never worked for a software company" | Hold, then concede. Hold only what your quotes carry: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Concede in your stated words: "I haven't worked for a software company." Do not claim to be better than a candidate you have not met. Answer slot: if there is anything else you have actually done that bears on this role, say it in your own words; if not, do not reach for it | F5 is the gap a Pressure interviewer leans on, and F1 and F2 are what you can hold. EXP because it tests composure over content |
| E2 | "Around 60 calls and emails a day. How much of that was actually you?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Hold the sentence as you wrote it: you were answering around 60 calls and emails a day. Answer slot: if any of that load was shared, assisted or templated, say which, plainly; if it was all yours, say so. Hold through two follow-ups before conceding anything | F1 holds the figure. EXP because attribution is what this stem scores |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" | B3, C1, D1, E2 |
| "experience with Zendesk or a similar ticketing tool" | B4, D1 |
| "clear written communication" | A5, C2, C3 |
| "confidence handling escalations" | A3, B5, A1, A2 |
| Software-company gap (F5, not an ad line) | B1, A4, E1 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like for someone new to your product?" | It names the ramp-up plan that answers the F5 objection, and it shows you are thinking about learning, not defending |
| R2 | "What kinds of tickets get escalated here, and who do they go to?" | Escalations are an ad line (F4), and the answer shows you think about handoff |
| R3 | "How are written replies reviewed or coached on your team?" | Written clarity is an ad line (F3), and the answer tells you how you will be judged |
| R4 | "Which ticketing tool does the team use, and how do new people learn it?" | It speaks to the ad's tool line (F2) without claiming anything about the team's tool |
| R5 | "What are the working hours and time-zone expectations for this remote role?" | A practical question for a remote role, and a sign you are planning for the job |
| R6 | "After this chat, what are the next steps, and will there be a voice or video conversation with anyone before an offer?" | A sensible question for a remote role, and the answer tells you more about how the process runs |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked for a software company | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't worked for a software company." No slot |
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation, not words for you: your material says Freshdesk, not the tool the ad names. B4's slot stays inside what you use day to day |
| Owned or designed the refunds process | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says you trained four new starters on it, not that you set it. C2 and C3 stay inside the training |

## Sources

Provided documents: your message (the Telegram invite and your background, including the ad's requirements as you listed them). No dossier was present.

Searches sent:

- "Lumenvale Software values" — refused
- "Lumenvale Software interview process customer support" — refused
- "Lumenvale Software strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | Search refused. Would have moved: the published value names for VAL questions (D3 is `[generic]` as a result) |
| 2. Lumenvale Software interview process, customer support | unavailable | Search refused. Would have moved: whether a documented loop matches the invite. The session structure here rests on your own words |
| 3. Lumenvale Software strategy / recent news | unavailable | Search refused. Would have moved: the CO bank, so D2 is `[generic]` |
| 4. interviewer name and company | n/a | No interviewer name was given, so there was no query to form. The interviewer read is absent |
| 5. representative Customer Support Specialist JD | skipped | The ad's requirements, as you listed them, fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your full ad text → F1 to F4 quote your list of its requirements, and the full wording could add lines I have not seen
- Your CV → every evidence cell rests on your message alone; a CV adds inspectable detail that can raise the confidence bands
- The support team lead's name or public profile → an interviewer read, adjusted persona weights and a reverse question tied to their path
- Any focus areas or format notes from the sender of the invite → coverage for what the chat will actually test
- Your own answers to the slots in A3, B5 and F3 (escalations, reviewed writing) → F3 and F4 move from discovery, and the guidance can use your words
- Permission for web search → Lumenvale's published values, any documented process and recent news; D2 becomes `[grounded]` and a values section appears if a values round is documented
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, also needs search permission → strategy, interviewer and role-loop material for the CO and CASE banks
- A tuesday-dossier.md, if you have one → verified evidence and prohibited-claim constraints for these rows
