Your prep pack is saved as `halvering-elementary_fourth-grade-teacher_interview_pack.md`. I built it for a panel where the principal acts as hiring manager and the two fourth-grade teachers act as peers. I had no posting text, so the requirements come from your invite and the district's own pages. Your licence matches the invite's condition, and the pack states it in the invite's terms.

Your SSN isn't needed for interview prep. I haven't used or repeated it, and it isn't in the pack. I also left your licence number out of the pack and out of every search.

The pack's biggest rehearsal item is question A2, about moving from third to fourth grade. It also covers the missing team-lead role, which you'll want ready.

Say the word and I'll play the Skeptic on A2, the question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the full posting text for the role? If you paste it, the requirement rows are re-pinned to its wording, and if you'd rather skip it, the pack stands as is.
Did HR mention anything to prepare, such as a sample lesson or a plan to bring? If so, it gets its own build section.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Panel:** Principal Dolores Vantongeren and two members of the fourth-grade team (names not given). 45 minutes, Thursday. Orrinsford Community School District.
**Relationship assumed:** the principal as hiring manager, the two teachers as peers. Built from the invite and your resume only; no posting text was supplied, so requirements come from the invite and the district's own pages.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding for your own words, not a script. Where a cell quotes you, say it at that scope and no wider.

| Type | What it scores |
|---|---|
| VAL | Whether what you have done fits the district's published beliefs |
| EXP | Whether your resume claims hold up, and what was actually yours |
| JD | The listed job, gaps included |
| CO | Whether you know the district's current direction |
| CASE | Structure and reasoning on a live problem from the role |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The licence is the invite's stated condition, and your CV states it in the invite's own terms: kind, endorsement, status and expiry. Say it in those terms. Nothing was inspected here; checking the registration record is yours to do, and your licence number is used nowhere in this pack |
| F2 | "reading instruction" — district hiring page ("Panels ask about reading instruction, classroom routines and how you work with families") | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | The quotes carry a curriculum move and an after-school club, each at its own scope; neither says what you teach in a reading block. Words: "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years." Answer slot: reading instruction is the first topic the page names, so expect a probe on your own reading lessons. If you taught reading to your third graders, say how a lesson ran, in your own words; if reading was taught another way, or not by you, say so plainly and stay with the move and the club |
| F3 | "classroom routines" — district hiring page | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [inferred] | discovery | The quote gives the grade and the years, not how the room ran. Answer slot: the page names classroom routines, so expect a probe on yours. If you set routines, describe them as they ran, in your own words; if the school set them, or you did not, say so plainly and say how you would set up a fourth-grade room |
| F4 | "how you work with families" — district hiring page | "I write a weekly email to families" — your CV | medium | [grounded] | none | The quote reaches the page's family topic in role-relevant terms: you write, weekly, to families. Say it in those words. It is a CV line with nothing inspected behind it, so expect a probe; the quote does not say what the emails hold or who reads them, and the pack adds nothing |
| F5 | "each teacher speaks with every family each term" — district Mission and Beliefs page | "I write a weekly email to families" — your CV | medium | [inferred] | discovery | The quote touches family contact without showing whether it includes speaking with families. Answer slot: the belief makes a probe on conversations beyond the email likely. If you spoke with families beyond the email, say how and how often, in your own words; if not, or it was not yours, say so plainly and stay with the weekly email |
| F6 | "assessments inform teaching and never replace it" — district Mission and Beliefs page | none given | none | [grounded] | discovery | Your material says nothing about assessment. Answer slot: the belief makes a probe on how assessment shaped your teaching likely. If results changed what you taught, say what and when, in your own words; if they did not, or that was not yours to decide, say so plainly and say how you would use them |
| F7 | "no student leaves third grade without a reading plan" — district Mission and Beliefs page | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [inferred] | discovery | The quote says the grade, not whether your students had reading plans or who wrote them. Answer slot: the belief makes a probe on this likely. If your students had reading plans, say what a plan was and which part was yours, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the six years you taught third grade |
| F8 | "Fourth Grade Teacher" — invite (the position) | "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've never taught fourth grade" — your message | low | [grounded] | transferability | Adjacent work only, and the limit is yours to state: your material carries third grade, not fourth. Words: "For six years I've taught third grade at a public elementary school in Joliet, and I haven't taught fourth grade." Then a ramp plan, said in the future tense as your own plan; the pack supplies none and adds no claim about fourth-grade work |
| F9 | working with the grade-level team — role-family requirement, no source | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [generic] | presentation | Say the quote as it stands, and the formal-role limit with it. Words: "I haven't been a team lead. In 2024 I led our grade level's move to a new reading curriculum." Nothing is added about how the move went or who did what |

## Reading the interviewer

Public professional footprint only. The two fourth-grade teachers are unnamed, so nothing was researched on them.

| Fact | Provenance | What it means for you | Mirror opportunity |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | [grounded] source S4 in Sources | Reading instruction, the first topic the district's page names, is likely to get depth from her. Keep reading answers in your own words and at the scope of your quotes | Shared professional vocabulary is reading. Quote to pair with it: "I've run the after-school reading club for the last two years" (F2). The pack does not know your club's format, so say what it does in your own words |
| Her 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5 | [grounded] source S4 in Sources | Small-group and one-to-one conference themes may surface in C1 and C3, and reverse question 1 builds on the talk | None offered; your quotes do not carry your side of this |
| Two fourth-grade teachers, no names or profiles | [generic] | Peer-style questions about teamwork, credit and what you would need from them: bank B | None |

## Persona table

| Persona | How it shows up in this panel | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the fourth-grade gap and the missing team-lead role | high: hiring-manager prior, and F8 and F9 are gaps you stated yourself | Rehearse A2 until it is boring; bridges only from the adjacent work you stated, with the limit said plainly: "I haven't taught fourth grade" |
| Peer Evaluator | The two teachers asking what you would need from them, how you disagree, how credit is shared | high: peer prior for two grade-level teachers on a panel | Reciprocity framing; propose principles, not a seam you have not seen; disagreement stories only where you have one |
| Case / Strategist | Live classroom problems from the principal | mid: hiring-manager prior; the district page names reading instruction and routines | Clarify, objective, grouping, check, risks; think aloud |
| Data-Driven Prober | Line-by-line questions on the club and the curriculum move | mid: peer prior; your material has durations and no outcome figures, so questions land on scope and attribution | Know what you can and cannot say about each line; say plainly when you do not know |
| Values / Behavioral | Stories against the district's three beliefs | mid: the beliefs page says they guide every hire, but no source documents a values round | Map a story where one of your quoted sentences carries it; otherwise a scaffold ending in its honest branch |
| Conversational / Rapport | The opening biography question and a friendly aside on the weekly email | low: no source documents an unstructured opener in this panel | A 90-second arc built only from your quoted sentences |
| Pressure | A time-boxed "why you over someone with fourth-grade experience" | low: no signal of a stress style | Concede only what is true and specific; hold the rest through two follow-ups |

## Question bank A: Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would be newest to you on day one?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | Start from what the quotes carry: "For six years I've taught third grade at a public elementary school in Joliet, and I haven't taught fourth grade." Then name, in your own words, the one thing you would learn first, said as a plan in the future tense. Stop there; do not list fourth-grade content you have not taught | F8 is the gap you stated, and the question scores the role as the invite titles it |
| A2 | "Your experience is in third grade. How would you run a fourth-grade classroom?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | The highest-ROI rehearsal in this pack. Open with the two sentences: "I haven't taught fourth grade. I've taught third grade for six years at a public elementary school in Joliet." Follow-up one will ask what differs in fourth grade. Answer slot: if you know how fourth-grade expectations differ, say what you know and where it came from, in your own words; if you do not yet, say so plainly and say how you would find out in your first weeks. Follow-up two will ask what if it is harder than you expect. Hold the opening by restating it, concede only that you have not taught fourth grade, and never describe fourth-grade work you have not done | F8 is where the panel will press hardest, so this objection arrives in some form; JD because it scores the position. A rehearsed, non-defensive answer changes the interview |
| A3 | "I don't see a team-lead role in your background. How do you contribute on a team without one?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Say both sentences as they stand: "I haven't been a team lead. In 2024 I led our grade level's move to a new reading curriculum." Then, in your own words, say how you work with teammates. Add nothing about the move beyond the sentence | F9 holds both the stated limit and the one adjacent sentence you have |
| A4 | "Why leave third grade after six years, and why Halvering?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Both halves are your own reasons and the pack supplies neither. Answer slot: give your actual reason for moving to fourth grade and your actual reason for this school, in your own words; if one is not yet clear to you, say so plainly and name what you want to learn at the panel. The district's published reading focus is public, so you may name it as something you read; say only what you did read | F8 is the move; why here and why now are the Skeptic's standard motivation probes |
| A5 | "Which of the district's three beliefs would be the hardest for you to live out?" | VAL | [grounded] | Name one honestly: Every Child a Reader, Families Are Partners, or Teach for Tomorrow, Not for the Test. Say what makes it hard and what you would do about it, as a plan. If none feels hard, say so plainly, then say which you would want help with first. The question needs no claim about your past, so the guidance makes none | F5, F6 and F7 are the belief rows where your material is thinnest; VAL because it scores fit with the published beliefs |

## Question bank B: Peer Evaluator (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What would you need from the fourth-grade team in your first month, and what could you offer it?" | JD | [grounded] "I've run the after-school reading club for the last two years"; "I led our grade level's move to a new reading curriculum in 2024" | Reciprocity: say what you would need, in your own words, then what you bring. What you can say you bring is only the two quotes at their scope: the club you run and the move you led for your grade level. Do not describe what either would do for this team | F9 and F2 are the only team-facing evidence; JD because the role works with a team |
| B2 | "Tell me about a time you disagreed with a colleague about how to teach something." | VAL | [generic] | Selection scaffold: it needs a named disagreement, your position stated plainly, what the two of you did, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F9 carries no disagreement story, so this is the scaffold case; VAL because it scores how you work with equals |
| B3 | "You led your grade level's move to a new reading curriculum. How do you share credit when work spans a team?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Credit is an attribution probe. Use "we" for context and "I" for what you did; the sentence you can stand on is "I led our grade level's move to a new reading curriculum in 2024." Say which part you did, in your own words; if parts were others', say whose; if you are unsure how to divide it, say so plainly and stay with the sentence | F9 is the only row with shared work; EXP because it tests what was actually yours |
| B4 | "Say your class includes readers at very different levels. Plan a week of reading for them." | CASE | [generic] | Think aloud: what you would want to know first, the objective, how you would group students, how you would check it is working, and the risk you would watch. Challenge one premise respectfully. The question asks about no past, so the guidance makes none | F2 and F6 are the rows this problem exercises; CASE because it is a live problem from the role |
| B5 | "Walk us through the first week of a new classroom: what do students see and do?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: the district's hiring page names classroom routines, so a probe on yours is likely. If you set routines, describe them as they ran, in your own words; if the school set them, or there was no such step, say so plainly and say how you would set up fourth grade | F3 is the discovery row for routines |

## Question bank C: Case / Strategist (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A student is two levels behind in reading in October. Walk me through your first month with that student." | CASE | [generic] | Clarify first: what is known, how the gap was measured, what support exists. Then the objective, a small-group and one-to-one plan, how you would check progress, the risks, and how you would reach the family. Think aloud. The question asks about no past, so the guidance makes none | F2 and F6; the principal's public talk topic (Sources, S4) makes reading conferences a likely theme |
| C2 | "The board's literacy plan adopts a new grades 3–5 reading curriculum from fall 2027. How would you get ready to teach it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Start with what you would want to know first: which curriculum, what training, what timeline, as questions you would bring and not facts you hold. Then, at its own scope, the sentence "I led our grade level's move to a new reading curriculum in 2024", saying only what it says. Do not call the two curricula alike; the pack does not know | F2 supplies the one adjacent sentence; the plan is a published district source (Sources, S3, a search result only) and the question is the pack's current-strategy item |
| C3 | "Say you want every student to have a weekly reading conference. How would your week make room for that?" | CASE | [generic] | Think aloud about the shape of the week: what the rest of the class is doing while you confer, how students know the routine, how you would check it holds. The question asks about no past, so the guidance makes none | F3 and F2; the theme comes from the principal's public talk (Sources, S4) |

## Question bank D: Data-Driven Prober (mid weight)

Your material holds durations and no outcome figures, so there are no defend-the-number rows; the durations are quoted as you gave them.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me how you've run the after-school reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" | Tell it in the sentence's own terms: an after-school reading club, run by you, for two years. Any further detail is your own, in your own words, and each one should be a detail you could repeat under a second question. For anything the sentence does not state, say plainly what you would have to check | F2; EXP because the line is a magnet for follow-ups |
| D2 | "Walk me through the move your grade level made to a new reading curriculum in 2024." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on the quote: your grade level, a new reading curriculum, 2024, and that you led it; tell those beats in your own words and stay at the sentence's scope. Follow-ups go two levels deeper; where one asks for something the sentence does not state, say plainly what you know and what you do not | F2 and F9 are the rows that draw on this sentence |
| D3 | "What would you change if you ran the reading club again?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Name one real change and why, in your own words; the pack supplies none. If nothing comes to mind, say so plainly and say what you would look at first | F2; the weakest-assumption move, asked about a club and not a figure |

## Question bank E: Values / Behavioral (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "The district's belief is that no student leaves third grade without a reading plan. You've taught third grade — what did that look like in your classroom?" | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: if your students had reading plans, say what a plan was and which part was yours, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the six years you taught third grade | F7; the belief names third grade, which is the grade you have taught |
| E2 | "Tell me about a time a family's concern changed what you did in class." | VAL | [grounded] "I write a weekly email to families" | Selection scaffold: it needs a named family, what they raised, what you did, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I write a weekly email to families", or how you would handle it | F4 and F5; theme from the Families Are Partners belief |
| E3 | "Teach for Tomorrow, Not for the Test. Tell me about a time assessment results changed what you taught next." | VAL | [grounded] | Selection scaffold: it needs a named result, what it showed, what you changed, and what followed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would use results. The guidance makes no claim about your past | F6 has no evidence cell, so this is the scaffold case |

## Question bank G: Conversational / Rapport (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through the journey that brought you here." | EXP | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029"; "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc with five beats, each one of those sentences at its own scope, in your own words. Then add the reason you want fourth grade; the pack supplies none | F1, F2 and F8 are the rows the arc draws on; casual openers are still scored |
| G2 | "Tell us about the weekly email to families." | VAL | [grounded] "I write a weekly email to families" | Say it as the sentence says: a weekly email, to families. Answer slot: the district's belief that each teacher speaks with every family each term makes a probe on conversations beyond the email likely. If you spoke with families beyond the email, say how and how often, in your own words; if not, or it was not yours, say so plainly and stay with the email | F4 and F5; VAL because it maps to Families Are Partners |

## Question bank H: Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over a candidate who has taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families"; "I've never taught fourth grade" | Concede first, plainly: "I haven't taught fourth grade." Then hold on the four sentences at their own scope. Hold through two follow-ups by returning to them, never adding to them, and do not say what they prove; let the panel draw that | F8; composure is scored, so the concession is specific and the rest is held |
| H2 | "On the reading curriculum move — how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold the sentence: "I led our grade level's move to a new reading curriculum in 2024." Concede specifically: say which parts others did, if any; if you carried it, say so plainly. Never fold on "led" to restore harmony, and keep it at the sentence's scope | F9 and F2; attribution is what this stem exists to test |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 licence | G1 — none dedicated: the invite's own condition, shown met in your CV, and checked by HR |
| F2 reading instruction | B4, C1, C2, D1, D2, D3 |
| F3 classroom routines | B5, C3 |
| F4 how you work with families | E2, G2 |
| F5 speaks with every family each term | E2, G2 |
| F6 assessments inform teaching | A5, E3 |
| F7 reading plan by third grade | A5, E1 |
| F8 Fourth Grade Teacher | A1, A2, A4, H1 |
| F9 grade-level team | A3, B1, B2, B3, H2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Your 2025 talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5. What does a strong first month of that look like for a new fourth-grade teacher?" | Ties to the principal's own public work and shows you read it; it also tells you what the building expects of a reading block |
| 2 | "The board's literacy plan names a new grades 3–5 reading curriculum from fall 2027. How is the building getting ready for it?" | Shows you read the plan, and tells you what support a fourth-grade teacher would get |
| 3 | "The district's beliefs say each teacher speaks with every family each term. How does the fourth-grade team make that workable?" | Turns the family belief into a working question and shows you took it seriously |
| 4 | "What could a new person on the team do in their first month that would genuinely help you?" | The reciprocity question for the two teachers: it asks about their load, not only your needs |
| 5 | "What would a fourth-grade teacher new to this team need to have in place by the end of the first term?" | A concrete expectation to prepare against, from the people who would work beside you |
| 6 | "What happens after the panel, and when do you expect to decide?" | The district's hiring page says references follow the panel; this confirms the next step |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has been a team lead | Negative you stated, F9 | Your own sentence: "I've never been a team lead." No slot |
| Has taught fourth grade | Negative you stated, F8 | Your own sentence: "I've never taught fourth grade." No slot |
| Led the school's or district's move to a new reading curriculum | Inflated form of F2 and F9 | The quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." The limit is the pack's observation, not words for you: your material says your grade level's move |

## Sources

Provided: the invitation text, and your resume and message, including the two limits you stated.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | The three beliefs by name, from the fetched official page: banks A5 and E, rows F5 to F7 |
| 2. `{company} interview process {role family}` | yes | The loop: one 45-minute building panel of the principal and two grade-level teachers, with named topics; persona weights follow it |
| 3. `{company} strategy` / recent news | yes | The board's literacy plan, from a search result only (page not fetched, because both fetches went to targets 1 and 2): question C2 and reverse questions 1 and 2 |
| 4. `{interviewer name} {company}` | yes | The principal's public profile, from a search result only: the interviewer read, C1, C3 and reverse question 1. The two teachers are unnamed, so no query was possible for them |
| 5. representative `{role title}` JD | yes | One truncated job-board result; it supplied only the role-family requirement in F9, kept as plain prose and `[generic]`, and nothing quoted |

Queries and returns:

- S1. "Halvering Elementary School Orrinsford Community School District mission values": orrinsfordschools.example/about/mission-and-beliefs. Fetched in full.
- S2. "elementary school teacher panel interview process principal grade-level team Illinois": orrinsfordschools.example/careers/how-we-hire-teachers. Fetched in full.
- S3. "Orrinsford Community School District strategic plan news": orrinsfordschools.example/news/board-adopts-literacy-plan. Snippet only.
- S4. "Dolores Vantongeren principal Halvering Elementary School": ilprincipalsforum.example/speakers/dolores-vantongeren. Snippet only.
- S5. "fourth grade teacher job posting Illinois elementary school responsibilities qualifications": k12jobsboard.example/listings/fourth-grade-teacher. Snippet only, truncated.

Identifiers in your message, a licence number and a tax or social-security number, were not used, quoted or searched.

## Upgrade menu

- The full posting text → the `[generic]` and `[inferred]` requirement rows become `[grounded]`, and the JD-tagged questions are re-pinned to the posting's own words
- Any prep note from HR, such as a sample lesson or a plan to bring → a build section for that deliverable
- The names of the two fourth-grade teachers → a per-member persona read and a reverse question tied to their public professional paths
- Your answers to the answer slots, said outside a drill → rows F2, F3, F5, F6, F7 and F8 move from slots to your own quoted material
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes → a grounding brief from the published literacy plan itself instead of a search result, the principal's talks and writing in more depth, and reports on this district's teacher panels
- A `tuesday-dossier.md` from an earlier role review → verified evidence and prohibited claims replace what this pack infers; nothing here requires one
