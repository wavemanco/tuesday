I'm writing your prep pack now. The four company-research searches were refused, so the pack runs on your message alone and the company-specific parts are labelled generic.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/tuesday/part-5/rooms/case-13-denied-06c18571/Quillmoor-Diagnostics_operations-coordinator_interview_pack.md`.

I built it for a recruiter screen with Hannah, using her four topics (pay, notice, hybrid, reason for moving). I had no CV, so every quote comes from your message. The four web searches on Quillmoor and Hannah were refused. The company-specific questions (B3, D2, E1, E2) are therefore labelled generic.

- **Highest-ROI prep:** B1, the SAP question. Your own line is "Never used SAP — we run our own in-house stock system", so rehearse saying it plainly and not stretching it.
- **Your logistics answers:** A2 to A5 give your own words for pay (£42,000, as a hope, not a floor), hybrid (two days is fine, you wouldn't want more than three), and the Reading relocation. The pack adds nothing beyond what you said.

Say the word and I'll play Hannah on B1, with follow-ups, then give feedback.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed.
If you'd like the pack as a Word document, say so and I'll convert it.

What is your notice period? It fills A3 and settles the one gate row (F10) your message doesn't cover.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quillmoor-Diagnostics_operations-coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

Recruiter screen with Hannah Lowther, Talent Partner. Thursday at 2pm, 30 minutes, by phone to the mobile number on your application. Her stated agenda: salary expectations, notice period, how the hybrid pattern would work for you, what is prompting a move; then the team and next steps.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: whether past behavior shows what the company says it values |
| EXP | Work-experience deep-dive: whether your claims survive scrutiny and what was actually you |
| JD | Role or JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem set in the role |

Answer slots in the guidance are instructions for the call, not questions for you now: say the branch that is true.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — JD | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material says delivery scheduling across three depots, not production scheduling, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the JD's planning, warehouse and QA line makes a probe on cross-team coordination likely. If any of your scheduling involved other teams, say which and how, in your own words; if none did, say so plainly and stay with the depot scheduling |
| F2 | "track supplier deliveries and chase late orders" — JD | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in your own terms: you chase suppliers when orders slip |
| F3 | "keep stock records accurate" — JD | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap, but the figure is a magnet for probing: "about a third" stays "about a third", over a year. The sentence reports the rebuild and the fall; it does not say one caused the other, so do not say that unless you can stand behind it |
| F4 | "report weekly on on-time dispatch" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if you report on deliveries or supplier performance on any regular basis, say what and to whom, in your own words; if you do not, say so plainly and stay with the supplier chasing you described |
| F5 | "2+ years in operations or logistics coordination" — JD | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap. Say it as you said it: four years, logistics coordinator, building-supplies wholesaler |
| F6 | "confident with Excel" — JD | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | low | [inferred] | discovery | Your sentence says spreadsheet, not Excel, and the pack does not resolve that for you. Answer slot: if the rebuild was in Excel, say what you did in it, in your own words; if it was another tool, or you would not call yourself confident, say so plainly and stay with the rebuild |
| F7 | "ERP experience (SAP or similar) a plus" — JD | "Never used SAP — we run our own in-house stock system" — your message | medium | [grounded] | transferability | The advert marks this a plus. Plain acknowledgment, from your own words: "I've never used SAP." Then your in-house stock system, as you described it. Answer slot: whether that system is what the interviewer would call an ERP is open; if you worked in it, say what you did, in your own words; if you did not, or it is not that kind of system, say so plainly. If you say how you would pick up SAP, say it as a plan, never as a past |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol." — JD | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | Your words show the gate met. Keep them at their scope: two days is fine, and you wouldn't want more than three. That is a stated preference, so do not harden it into "can't" or soften it into "flexible" |
| F9 | "£38,000–£44,000" — JD | "I'm hoping for £42,000" — your message | high | [grounded] | none | Your figure sits inside the advert's band. It is a hope you stated, so it is not a floor or a "minimum" and the pack does not coach it as one |
| F10 | "your notice period" — recruiter message | none given | none | [grounded] | hard_gate | Your material does not establish it. The pack asks for it once in the closing message |
| F11 | "what's prompting a move" — recruiter message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | No gap. The reason is one you stated; say it at its own scope: office closing next year, the only offer being relocation to Reading, which you don't want |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport Builder | Friendly, unstructured; asks the journey, pay, notice, hybrid, reason for moving | High. The recruiter-screen prior is Conversational first, and Hannah named four logistics topics herself, so bank A is built on them. Casual questions here are still scored | Short arcs built only from your own sentences; give your own figure, constraint and reason in your own words (A1 to A5) |
| B. Skeptic | Quiet probing of the JD gaps: ERP, production scheduling, weekly reporting, why this company | High, weighted up from the prior's light Skeptic because F1, F4, F6 and F7 each carry a gap the JD names. It carries the highest-ROI item, B1 | Rehearse the SAP question until it is boring; bridge only from what you said; say the limit plainly rather than bluff |
| C. Data-Driven Prober | Reads the figure and the claims line by line | Medium. One headline figure (F3) and an Excel requirement (F6); a recruiter may check them lightly | Know how you counted the figure or say you do not; keep the figure at "about a third" |
| D. Values / Behavioral | Open "tell me about a time" prompts | Low. No loop source names a values round, and no company values were found, so there is no published value to map | Pick an instance only from your own material; say so if none comes to mind |
| E. Case / Strategist | A small live problem from the role | Low. A recruiter screen rarely sets cases, but the JD's supplier and stock lines make two plausible | Clarify first, structure, then answer; plans are not claims about your past |
| F. Pressure | Time-boxed challenge, "how much was you" | Low. Plausible as a quick test of the SAP gap and the figure | Hold what the quote carries through two follow-ups; concede the limit specifically |
| G. Peer Evaluator | Not weighted | This is a recruiter call, so there is no peer in the room; no bank | None needed |

Weights rest on the recruiter-screen prior and on Hannah's own stated agenda. The loop beyond this one call is unknown, so no later-round weighting is claimed.

## Question banks

Requirement coverage:

| JD requirement | Questions |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B2, E1, A1 |
| track supplier deliveries and chase late orders | D1, A1, C3, E1 |
| keep stock records accurate | C1, E2 |
| report weekly on on-time dispatch | B4 |
| 2+ years in operations or logistics coordination | C3, A1 |
| confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B1, F1 |
| Hybrid: two days a week at our Avonmouth site in Bristol. | A4 |
| £38,000–£44,000 | A2 |
| Recruiter topics: notice period, reason for moving | A3, A5 |

### A. Conversational (weight: highest, 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler", "I schedule deliveries for our three depots and chase suppliers when orders slip", "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | A 90-second arc on the beats your sentences state: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling by about a third over a year. Tell them in your own words and stop there; the move comes in A5. Answer slot: add a detail such as a volume or a team size only if it is yours and you can repeat it under a second question; if you do not know it, leave it out | The standard opener in a friendly register; F2, F3 and F5 are the evidence. EXP because it tests what you can say about your own work |
| A2 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000" | Logistics slot: give your own figure in your own words, as you gave it: you are hoping for £42,000. Keep it a hope, not a floor, and add no reasoning or salary history you were not asked for | F9 is the evidence and the advert states a band; JD because pay is a listed term of the job |
| A3 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, in your own words, and anything about it that you know to be true | F10 is open; JD because it is a term of the role the recruiter named |
| A4 | "The role is two days a week at our Avonmouth site. How would that work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Logistics slot: say it as you said it: you live in north Bristol, two days at Avonmouth is fine, and you wouldn't want more than three. Whether to volunteer the three-day line is your call; if you do, keep it a preference in those words | F8 is the evidence; JD because the pattern is a listed term |
| A5 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Logistics slot: your reason, in your own words, built on what the sentence states: the Bristol office closing next year, and the only offer being relocation to Reading, which you don't want. Add nothing the sentence does not say about how it was decided or by whom. Answer slot: if anything in this role specifically draws you, say what, in your own words; if nothing does beyond the reason you gave, say so plainly and return to that reason | F11 is the evidence; EXP because a stated reason is checked against the rest of your story |

### B. Skeptic (weight: high, 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The advert lists ERP experience, SAP or similar, as a plus. What's your experience there?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | The highest-ROI rehearsal in this pack. Say it plainly: "I've never used SAP." Then the in-house system as you described it: you run your own in-house stock system. Answer slot: if you worked in that system, say what you did, in your own words; if you did not, or it is not the kind of system the advert means, say so plainly. Follow-up one, how would you get up to speed: answer with a plan, never a past. Follow-up two, is the in-house system an ERP: take the slot's branch that is true. Follow-up three, does that worry you: concede only that you haven't used SAP, and hold on the quoted system without adding to it | F7 is the clearest gap you stated and the likeliest tick-box check in a screen; JD because the requirement is listed |
| B2 | "The role coordinates production schedules between planning, the warehouse and QA. What have you coordinated like that?" | JD | [grounded] "I schedule deliveries for our three depots" | Start from the sentence: "I schedule deliveries for our three depots." Answer slot: the JD's planning, warehouse and QA line makes a probe on cross-team coordination likely. If any of your scheduling involved other teams, say which and how, in your own words; if it was only delivery scheduling, say so plainly and stay with the depot scheduling. Do not call delivery scheduling production scheduling | F1 is a transferability gap; JD because it scores the first listed duty |
| B3 | "Why Quillmoor, and why diagnostic-test manufacturing?" | CO | [generic] | No company research could be run, so this is a selection scaffold. Answer slot: if something specific in the advert or the company draws you, name it, in your own words; if nothing does beyond the reason you gave in A5, say so plainly and return to it. Never recite company facts you have not checked | The why-us probe usually follows a reason for leaving; F11 is the link. CO because it tests homework, labelled generic because none could be done |
| B4 | "The job reports weekly on on-time dispatch. Have you reported on anything like that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Answer slot: if you report on deliveries or supplier performance on any regular basis, say what and to whom, in your own words; if you do not, say so plainly and stay with the quoted work: you schedule deliveries for three depots and chase suppliers when orders slip | F4 has no evidence either way, so this is where a probe lands; JD because the report is a listed duty |

### C. Data-Driven Prober (weight: medium, 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say discrepancies fell by about a third over a year. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | The beats the sentence states: you rebuilt the stock-count spreadsheet; discrepancies fell by about a third; over a year. Answer slots, each in your own words: how it was counted; what it is sensitive to; the assumption you would defend least; which part was yours. If you do not know how it was counted, say so plainly. Keep "about a third" as it is | F3's figure is the one a prober tests; EXP because it checks attribution |
| C2 | "How confident are you in Excel, and what do you use it for?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Answer slot: if the rebuild was in Excel, say what you did in it, in your own words; if it was another tool, or you would not say confident, say so plainly and stay with the rebuild | F6 is open on whether the spreadsheet was Excel; JD because Excel is a listed requirement |
| C3 | "What does a typical week look like in your current role?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler", "I schedule deliveries for our three depots and chase suppliers when orders slip" | Describe it from those sentences: scheduling deliveries for three depots and chasing suppliers when orders slip. The sentences carry no volumes, team size or systems, so the pack supplies none. Add a detail only if it is yours and you can repeat it under a second question | F2 and F5 are the evidence; EXP because it tests the day-to-day behind the CV line |

### D. Values / Behavioral (weight: low, 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time a supplier let you down." | VAL | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Story map: orders slip and you chase suppliers is the beat the sentence states. Answer slot: if one order comes to mind, say what happened and what you did, in your own words; if no one case comes to mind, say so plainly, then give the nearest thing your material does carry: you chase suppliers when orders slip | The JD's late-orders line raises this theme; F2 is the evidence. VAL because it asks for a chosen instance |
| D2 | "Tell me about a time you had to give someone bad news." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a plain message and a relationship still intact afterwards; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem for this style; nothing in your material names such a time, so the pack supplies none |

### E. Case / Strategist (weight: low, 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier says a key component will land three days late and QA needs it for a batch due out on Friday. What do you need to know first, and what do you do?" | CASE | [generic] | Structure it aloud: what you would ask first, what the objective is, who you would speak to, what you would tell the others, and how you would record it. It needs no claim about your past, so the guidance makes none | A live problem from the JD's supplier, planning, warehouse and QA lines (F1, F2) |
| E2 | "The stock record says 120 and the shelf has 112. What do you do?" | CASE | [generic] | Structure it: confirm the count, look for the cause, correct the record, and say what you would check so it does not recur. The guidance makes no claim about your past | The JD's stock-accuracy line (F3) as a decision, not a record |

### F. Pressure (weight: low, 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why should we pick you over someone who has used SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system", "4 years as a logistics coordinator at a building-supplies wholesaler" | Pause and restate the question. Hold on what the quotes carry: four years as a logistics coordinator at a building-supplies wholesaler. Concede the limit plainly and specifically: "I've never used SAP." Hold through two follow-ups by returning to the quoted work, never by adding to it | F7 is where the challenge presses; JD because it scores the listed ERP line under time pressure |
| F2 | "How much of that stock-count result was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | The rebuild is yours as you stated it. Answer slot: if you can say how much of the fall came from the rebuild, say how you know; if you cannot, say so plainly and stay with what you rebuilt. Concede that specifically and do not fold on the rebuild itself | F3's sentence reports both the rebuild and the fall without linking them; EXP because the question probes attribution |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which of planning, the warehouse and QA would this role work with most day to day?" | It uses the advert's own three teams and shows you read the duty list |
| R2 | "What does the weekly on-time dispatch report look like today, and who reads it?" | It goes to the one duty with a reporting output and tells you what the job is judged on |
| R3 | "What systems does the team use for stock and production scheduling?" | It surfaces the SAP question from your side, and a recruiter can often answer it |
| R4 | "Are the two Avonmouth days fixed, or do they vary?" | A practical question on the hybrid term that lets you hear how firm the pattern is |
| R5 | "What would a good first three months look like in this role?" | It signals you are thinking about delivery, not just the screen |
| R6 | "What are the next steps and the timeline after this call?" | It closes the loop, and Hannah said she would cover next steps, so use it only if something is left unsaid |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I've never used SAP." The in-house system is stated at its own scope. B1's slot covers only what you did in it |
| Coordinated production schedules | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says delivery scheduling, not production scheduling |
| My rebuild cut stock discrepancies by a third | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the sentence reports the rebuild and the fall, with "about a third", and does not link them |
| Advanced Excel user | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: the material says spreadsheet, not Excel |
| Needs a minimum of £42,000 | Inflated form of F9 | F9's quote at its own scope: "I'm hoping for £42,000". It is a hope you stated, not a floor |
| Happy with any number of office days | Claim a quote contradicts, F8 | The contradicting quote: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" |
| Was made redundant | Inflated form of F11 | F11's quote at its own scope. The limit is the pack's observation: the material says the office is closing and the only offer is relocation to Reading |

## Sources

Provided documents: your message, including the advert text and Hannah Lowther's LinkedIn message as you quoted it. No dossier was present. No CV was provided; every evidence quote comes from your message.

Searches sent, all refused (no permission granted for web search):

- `Quillmoor Diagnostics values` — refused
- `Quillmoor Diagnostics interview process operations coordinator` — refused
- `Quillmoor Diagnostics Avonmouth strategy news` — refused
- `Hannah Lowther Talent Partner Quillmoor Diagnostics` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Would have moved B3 and a values cheat sheet if a values round had been documented; the VAL bank is generic as a result |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Would have moved the loop beyond this call and the persona weights; Hannah's own words establish only this one 30-minute call |
| 3. `Quillmoor Diagnostics Avonmouth strategy news` | unavailable | Would have moved B3 and a grounded CO question; B3 is generic as a result |
| 4. `Hannah Lowther Talent Partner Quillmoor Diagnostics` | unavailable | Would have moved the interviewer read and a reverse question tied to her path; the section is absent |
| 5. representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → fills A3 and settles the gate row F10
- Your answers to the answer slots in B1, B2, B4 and C2 → upgrades F1, F4, F6 and F7 to quoted evidence and tightens those answers
- Your CV → adds quoted evidence to every fit-snapshot row that now rests on your message alone, and may settle whether the spreadsheet was Excel (F6)
- Permission to search the web → B3 and the CO and VAL material become grounded in Quillmoor's own pages; a deeper pass of up to 6 more searches and 2 more fetches, taking several more minutes, is available once
- Hannah's LinkedIn profile text, pasted → an interviewer read and a reverse question tied to her path
- A `tuesday-dossier.md` → verified evidence and prohibited claims already weighed, and a sharper highest-ROI objection
