Web search was refused here, so I'm building the pack from your JD and background alone and will mark anything company-specific as unavailable. Writing the pack file now.
Your prep pack is saved as `atlas-freight_operations-manager_interview_pack.md`. It has 23 questions across seven interviewer styles, a fit table for each JD requirement, six reverse questions and a prep order for the week. Your note didn't say who you're meeting, so I built it for a hiring-manager round.

Web search was refused in this session. All three searches were refused, so the pack has nothing about Atlas Freight beyond your JD, and the company question (E3) is labeled generic. Company values, interview format and strategy are also not covered. Question E3 lists what to look up yourself.

The question the pack names as highest-ROI is B1: you supervise three people now and the role leads twelve, across four sites.

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting, in what format, and did the recruiter say what the round will cover?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Interviewer:** not known. **Round:** not stated, so this pack assumes a hiring-manager round (the relationship prior is in the persona table). **Built from:** the JD text and background you pasted. No company research ran (see Sources).

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. An answer slot is an instruction for the interview, not a question for you now.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage (one week)

1. Rehearse B1 out loud until the 3-versus-12 answer is boring. It is the highest-ROI prep in this pack.
2. Settle your own answers to the slots on the 40% figure: C1, C2, D2. Write them down; nobody else can supply them.
3. Prepare B2 and the Power BI plan from F5: say the gap plainly, then the plan.
4. Practise the A1 and A2 structures aloud, ten minutes each.
5. Build the 90-second arc (E1) and do the company homework E3 asks for. Pick three reverse questions.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message, "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Self-reported, nothing inspected behind it, so expect a probe. Your material says warehouse and distribution operations and one site's surge plan; it does not say terminals or more than one site, and the words stay at that scope: "I have 7 years in warehouse and distribution ops." Answer slot: the JD's four-sites line makes a probe on terminal work and on multiple sites likely. If any of your work touched terminal-style operations or more than one site, say what and where, in your own words; if none did, say so plainly and stay with the warehouse and distribution operations you worked in |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Self-reported, nothing inspected behind it. Mis-pick rate is neither on-time performance nor cost-per-shipment, so the words stay in the quote: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD's on-time and cost lines make a probe on whether your results touched either likely. If any did, say what was counted and how, in your own words; if none did, say so plainly and stay with the mis-pick result |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Self-reported. Your material says 3 supervisors; the JD says 12. Words: "I'm currently a senior shift manager over 3 supervisors." Answer slot: expect a probe on the jump from 3 to 12. If you have led more supervisors at an earlier point, or supervisors at more than one site, say how many and when, in your own words; if not, say so plainly and stay with the three |
| F4 | "build reporting in Excel/Power BI" — JD, Excel half | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" states a skill level, not a report built, and the bridge should not be stretched. Answer slot: the JD asks you to build reporting, so expect a probe on what you have built. If you built reports in Excel, say what they showed and who used them, in your own words; if you did not, say so plainly, and say what the first report you would build here would show |
| F5 | "build reporting in Excel/Power BI" — JD, Power BI half | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never used Power BI." Then how you would get to working level, said as a plan and never as a past. Nothing added to make the gap feel smaller. The JD's slash may mean either tool; reverse question R3 asks |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message, "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Self-reported. The material shows 7 years in operations and a current supervisory role, not how many of the 7 years were in leadership, and the reading resolves downward. Answer slot: expect a probe on the leadership years. Say how many years you have held shift-manager or supervisor roles, in your own words; if it is fewer than five, say so plainly and stay with the roles you have held |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap on the requirement: the quote reaches it in the JD's terms. It is a self-reported certification with nothing inspected behind it, so expect a probe on what it covered. Lead with it as you said it: "I'm green belt certified." |

## Persona table

No loop source established this company's rounds (research did not run), so the weights rest on the generic archetype (screen, hiring manager, panel, flat tilt) and on the hiring-manager relationship prior. If you tell me the real round, they will be recomputed.

| Persona | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | high (4–5 questions) | Hiring-manager prior; the JD's on-time, cost and reporting lines are easy to turn into live problems | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | high (4–5 questions) | Hiring-manager prior; F1, F3 and F5 give it material | Rehearse the single most predictable objection (B1) until boring; limits said plainly; plans as plans |
| Data-Driven Prober | medium (3) | The 40% figure is a magnet; the JD is metric-heavy | Know how the figure was counted and say plainly when you do not; name the weakest assumption first |
| Pressure | medium (3) | The 3-versus-12 gap and the figure invite challenge | Pause, restate, hold through two follow-ups, concede only what you actually do not know |
| Conversational | medium (3) | Openers and the Lean/Six Sigma plus often arrive in a casual register | Pre-script the 90-second arc; treat casual questions as scored |
| Values / Behavioral | low (2) | No values round detected and no published values read | Selection scaffolds with an honest branch; "we" for context, "I" for contribution |
| Peer Evaluator | low (2) | Relationship assumed to be the hiring manager, not a peer | Propose seam principles rather than pretending to know the seam |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On-time performance at one of your four terminals has fallen ten points in a month. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify before structuring: what counts as on-time here and how it is measured, which terminal, which days, since when. Then segment the flow end to end, say where you would look first and why, name the data you would pull, separate a quick fix from a structural one, and say which supervisors you would involve. Challenge one premise respectfully, for instance whether the drop is real or a change in measurement. The question needs no claim about your past, so the guidance makes none | JD content, CASE delivery: the JD's on-time line, tested live. F2 is the related evidence row |
| A2 | "Cost-per-shipment is up 8% on last quarter with volume flat. Where do you look first?" | CASE | [generic] | Ask what is inside the number first, then break it down by cost line and by terminal and say which line you would test first and why. Name the trade-off: a saving that hurts on-time is not a saving, so say how you would check one metric does not move the other. The question needs no claim about your past, so the guidance makes none | JD content, CASE delivery: the JD pairs on-time with cost, and this question forces the pairing. F2 is the related evidence row |
| A3 | "You inherit four sites that each report their daily numbers their own way. How do you get one view in your first 60 days?" | CASE | [grounded] "solid Excel, never used Power BI" | Structure: find out what each site reports now and who uses it; agree a short common set of definitions with the supervisors; build a first version in the tool you are strong in, and you can say you are solid in Excel, in those words. If the company already uses Power BI, say plainly you have never used it, then give the plan to reach working level. Do not describe multi-site reports you have not built | JD content, CASE delivery: the JD's reporting and four-sites lines together. F4 and F5 are the evidence rows |
| A4 | "It's six a.m. and three of your four terminals each have a problem. How do you decide where you go first?" | CASE | [generic] | Clarify what each problem is, who is already on site, what is due out soonest and what the supervisors can already handle. State the rule you would use to choose, what you would delegate, and how you would tell the other two sites what to expect. The question needs no claim about your past, so the guidance makes none | JD content, CASE delivery: "own daily terminal operations across 4 sites" as a prioritization problem. F1 is the related evidence row |
| A5 | "How would you set daily targets for twelve supervisors so on-time and cost-per-shipment don't fight each other?" | CASE | [generic] | Name the tension first. Propose that each supervisor owns a small set of numbers they can actually influence, say how often you would review them, and say what happens when two numbers conflict. Ask what the company already tracks before proposing anything new. The question needs no claim about your past, so the guidance makes none | JD content, CASE delivery: combines the JD's twelve-supervisor and on-time and cost lines. F2 and F3 are the related evidence rows |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You're a shift manager over three supervisors today. This role leads twelve, across four sites. How do you get from there to here?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I'm currently a senior shift manager over 3 supervisors." State the difference as two numbers, three today and twelve in the role, without apology or softening. Answer slot: if you have led more supervisors earlier, or supervisors at more than one site, say how many and when, in your own words; if not, say so plainly and stay with the three. Then the ramp, as a plan and never a past: what you would do first with twelve people you have not met, and whom you would ask for help. Hold through two follow-ups by returning to the three, never by adding to them | F3 is the sharpest gap against the JD's headline line, so this objection arrives in some form; JD because it scores a stated requirement |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "solid Excel, never used Power BI" | Choose one weakness and say it plainly before they find it. Your own sentence supplies one: "I have never used Power BI." Say it in those words with no qualifier. Then give a plan, never a past: what you would use in the meantime, which can be the Excel you describe as solid, and how you would reach working level. Give a date only if you can stand behind it | F5 is the stated gap and F4 the Excel side; JD because it scores the reporting requirement |
| B3 | "Your experience is warehouse and distribution. What do you know about running a terminal?" | JD | [grounded] "7 years in warehouse and distribution ops" | Say what your material says: "I have 7 years in warehouse and distribution ops." Answer slot: the JD's terminal line makes a probe on what is different likely. If any of your work touched terminal-style operations, say what, in your own words; if none did, say so plainly, then say what you would need to learn first and whom you would ask: your supervisors and the site data | F1 is where the JD's terminal wording presses; JD because it scores a stated requirement |
| B4 | "Why leave a senior shift manager role, and why now?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors" | Start from where you are, in your words: "I'm currently a senior shift manager over 3 supervisors." The reason is yours alone and the pack supplies none. Selection criteria: forward-looking, tied to something the JD names, with nothing negative about your current employer. If no clear reason comes to mind yet, work it out before the interview | Motivation consistency is what a Skeptic scores; EXP because it tests the story of the move. F3 is the current-role row |
| B5 | "You ran your site's peak-season surge plan. What changes when it's four sites at once?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Tell it as the quote states: "I ran the site's peak-season surge plan two years running." One site, two years. The four-site part is a plan: say what you would need to know first about each site, what you would standardise, and what each site should decide for itself. Answer slot: expect follow-ups on what the plan covered and which parts were yours to set. If any were yours, say which and how you decided; if the plan was partly set elsewhere, say so plainly and describe what you ran | F1 holds the surge sentence; EXP because it tests the scope of what was run, and the question tests that scope against the JD's four sites |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut mis-pick rate 40% by redesigning the pick path. Walk me through how that number was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Your sentence is "I cut mis-pick rate 40% by redesigning the pick path." Answer slots, in your own words, with nothing supplied here: how the figure was counted, and what it is sensitive to. If you do not know how it was counted, say so plainly and say what you do know | The headline figure is the likeliest thing to be probed to its inputs; F2 holds it. EXP because it tests attribution and method honesty |
| C2 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Name it yourself before they do; it turns a gotcha into a credibility gain, and the pack does not name it for you. Answer slot: say the assumption you would defend least, in your own words; if you do not know of one, or do not know how the number was built, say that plainly and say what you would check | The weakest-assumption move for a figure; F2 holds it. EXP because it tests whether you know your own number |
| C3 | "Tell me about a time you built a report in Excel that changed a decision." | JD | [grounded] "solid Excel, never used Power BI" | Pick a report you actually built; it needs the question it answered, who used it and what changed afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "solid Excel", or how you would build the first report here. Do not stretch "solid Excel" into reports built | F4 is the evidence row; JD because the reporting line is stated and an open prompt lets you choose the instance |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has already run a terminal network?" | JD | [grounded] "7 years in warehouse and distribution ops", "ran the site's peak-season surge plan two years running" | Hold, don't defend. Use two quoted facts in your own words: "I have 7 years in warehouse and distribution ops" and "I ran the site's peak-season surge plan two years running". Close on what you would do in your first weeks, as a plan. Do not claim to be better; let them draw the inference. Hold through two follow-ups by returning to the two facts | F1 and F6 carry the facts; the probe tests composure against the role's terminal and years requirements |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause, restate the question, then hold the sentence: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: which part of the redesign was yours, in your own words; if any part was shared or someone else's, say so plainly and say exactly what you did. Concede only what you actually do not know, specifically, and never the core claim to restore harmony | Attribution under pressure; F2 holds the figure. EXP because it tests what was actually yours |
| D3 | "I need someone who can hold twelve supervisors to account. You've had three. Convince me." | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Pause and restate, then hold: "I'm currently a senior shift manager over 3 supervisors." Concede the gap in the two numbers, not in adjectives. Answer slot: expect a probe on how you hold supervisors to a target. If you have, say how, in your own words; if there was no such target, or it was not yours to set, say so plainly and return to the three you supervise | F3 again, in the Pressure register; the hard form of B1 |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors" | A 90-second arc with the beats the quotes state: seven years in warehouse and distribution ops, then where you are now, "currently a senior shift manager over 3 supervisors". The roles, sites and dates between are yours to say in your own words; the pack supplies none. Finish on why this role, which is your reason, tied to what the JD names, not a claim that you have done it | Casual openers are scored; F6 and F3 carry the facts. EXP because it tests the story's consistency |
| E2 | "What are you actually playing with in Lean and Six Sigma these days?" | JD | [grounded] "green belt certified" | Start with the fact: "I'm green belt certified." Answer slot: if you apply the methods in current work, say how, in your own words; if you do not, say so plainly and say what you would apply first across four sites. Keep it at the certification unless you can stand behind more | F7 is the evidence row; JD because the Lean/Six Sigma plus is stated and asked here in a casual register |
| E3 | "What do you know about Atlas Freight, and why us?" | CO | [generic] | The pack could not research the company and supplies nothing about it, so this answer is your homework. Scaffold: three facts you verified yourself on the company's own site or in recent news, one that connects to the on-time and cost mandate, and one thing you would ask. The JD itself states "regional logistics, 800 employees", which you can repeat | Company homework is scored in casual and formal rounds alike; `[generic]` until research can run |

### F. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time you told someone senior something they did not want to hear; it needs a named stake, what you said, and an intact working relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard behavioral stem; no published values were read, so the theme comes from the persona stem alone |
| F2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time with a named customer need, the internal number it cost you, and what you decided. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard behavioral stem; fits a role that pairs on-time with cost |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam between us, and what happens when we disagree?" | JD | [generic] | Offer principles rather than pretending to know the seam: ask where it sits today, say who decides what, and say how you would raise a disagreement early and privately. If you pick a disagreement story from your own work, it needs a named stake and an intact relationship; if none comes to mind, say so plainly, then say how you would handle it | Peer stem; low weight because the relationship is assumed to be the hiring manager |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Pick a time work spanned teams and name who did what. If no such time comes to mind, say so plainly, then say how you would handle credit. Use "we" for context and "I" only for your own part | Peer stem; low weight for the same reason as G1 |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A4, B3, B5 |
| "drive on-time performance and cost-per-shipment down" | A1, A2, A5 |
| "lead a team of 12 supervisors" | B1, D3, A5 |
| "build reporting in Excel/Power BI" | A3, B2, C3 |
| "5+ years operations leadership required" | B1, D1, E1 |
| "Lean/Six Sigma a plus" | E2 |
| Headline figure on your background (40%) | C1, C2, D2 |
| "regional logistics, 800 employees" (company context) | E3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does on-time performance look like today across the four sites, and which one is furthest from where you want it?" | Shows you think in the JD's own mandate and asks for the baseline you would own |
| R2 | "How is cost-per-shipment measured today, and who owns the number?" | Definitions decide what you would be held to; asking early is a sign of a manager who checks |
| R3 | "What does reporting look like now: what is built in Excel, what is in Power BI, and what would you expect me to build first?" | Raises the Power BI gap on your terms and settles what the JD's slash means |
| R4 | "The role leads twelve supervisors. How strong is that group, and where would you want my attention in the first 90 days?" | Turns B1 from an interrogation into a planning conversation |
| R5 | "How are peak-season surges handled across the four sites today?" | Connects your surge experience to their reality without claiming more than the sentence says |
| R6 | "What would make you say, a year from now, that this hire was the right call?" | Gets the real scoring criteria in the interviewer's own words |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team of 12 supervisors, or led supervisors across several sites | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: the material says 3 supervisors, not 12. B1's slot stays inside the three |
| Owned terminal operations across several sites | Inflated form of F1 | F1's quotes at their own scope. The material says warehouse and distribution operations and one site's surge plan; B3's slot stays inside the work you did |
| Reduced on-time performance or cost-per-shipment | Inflated form of F2 | F2's quote at its own scope. The material says mis-pick rate; D2 and C1 stay with that result |
| Built or used Power BI reporting | Negative you stated, F5 | The plain acknowledgment F5 gives: "I have never used Power BI." Then a plan, never a past. No slot |

## Sources

Provided documents: the JD text and background in your message. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Queries sent (all three refused, so nothing came back):

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight strategy news regional logistics terminals" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Would have fed a values cheat sheet and VAL stories by official name; without it F1 and F2 are generic |
| 2. `Atlas Freight interview process operations manager` | unavailable | Would have fixed the loop structure and persona weights; weights fall back to the generic archetype |
| 3. `Atlas Freight strategy` / recent news | unavailable | Would have grounded a CO question and a strategy-specific CASE; E3 is generic and is your homework |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who you are meeting (recruiter, future manager, panel, peer) → persona weights move from assumed to specific and banks are added or dropped
- The interviewer's name and role → an interviewer read, reweighted personas and a reverse question tied to their path
- Search access, or pasted pages from Atlas Freight's own site (values, careers, news) → a values cheat sheet if a values round is documented, a grounded CO question, a strategy-based CASE, and E3 becomes `[grounded]`
- The recruiter's prep notes (focus areas, any take-home or presentation) → coverage of any pre-declared deliverable and sharper weights
- Your own answers to the slots on F1 (terminal or multi-site exposure), F3 (earlier supervisory numbers), F4 (reports you built), F6 (years in leadership roles) and C1 (how the 40% was counted) → those rows and their questions become story-mapped answers instead of slots
- A `tuesday-dossier.md` from a prior evaluation of this role, if you have one → verified evidence and a named top objection in place of the inferred ones here; the pack does not need it
