Web search was refused on all four lookups, so I'm building the pack from your JD and background alone. I'll mark the company-specific parts as unresearched.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/tuesday/part-2/rooms/case-7-denied-0f1ae895/saltmarsh-games_live-operations-producer_interview_pack.md`. I assumed Tobias is your hiring manager, since you didn't say. The pack has 22 questions across seven interviewer styles. It also has a fit table against each JD line, six reverse questions and a list of claims it won't coach.

Web search was refused on all four lookups: Saltmarsh's values, its interview process, its strategy and Tobias's background. Nothing in the pack is about Saltmarsh or Tobias. The case questions are generic, and there are no company-knowledge questions or interviewer read. The upgrade menu says what search access would add.

The pack's top priority is B1, "Which part of this JD would you be weakest at on day one?" It aims at the two limits you stated: you have never led a team, and you have never worked on a game with in-app purchases. B2 is second. It covers the JD's "3+ years producing live-service games" line, because your two years on the weekly calendar and your four years in the role don't obviously match that.

Say the word and I'll play the skeptical interviewer on B1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to a Word document.

1. Is Tobias the person you'd report to, or a more senior or peer interviewer, and did the recruiter name any focus area or take-home?
2. Can you paste your CV so I can quote it in place of your summary, or say skip and I'll keep going on what you've given me?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

Prepared for Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Format: one 60-minute session. Relationship assumed to be hiring manager, not confirmed; the persona weights below rest on that assumption and reweight if it is wrong.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding for a spoken answer, not a script.

Type key:

| Tag | Meaning |
|---|---|
| VAL | Behavioral or values alignment: whether past behavior shows the behavior asked about |
| EXP | Work-experience deep-dive: whether your claims survive scrutiny and what was actually yours |
| JD | Role and JD-driven: whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge: none in this pack, because research did not run |
| CASE | A live problem set in the role, scored on structure and reasoning |

Provenance labels: `[grounded]` rests on your own quoted sentences or the JD; `[inferred]` is a derivation, named; `[generic]` is a role-family pattern with no claim about you or about Saltmarsh. An answer slot is an instruction for the interview, with two honest branches; it asks nothing of you here.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for the main title, not a live-events calendar and not two titles, with nothing inspected behind it, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's live-events line makes a probe on what went into a drop likely. If any part of it was yours to schedule, say which and how you decided, in your own words; if there was no such decision, or it was not yours, say so plainly and describe how you ran the weekly calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which teams you worked with on a drop. The JD's verb is coordinate, and the pack keeps that apart from leading. Answer slot: the JD names four teams, so expect a probe on which of them you worked with and what you needed from each. If you coordinated with any, name which and say what you needed from them, in your own words; if you did not work with a team, or it was not yours to coordinate, say so plainly and return to the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you owned a review or its KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-review line makes a probe on reviews likely. If any step in how those numbers were produced was yours, say which, in your own words; if none was, say so plainly and describe presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist QA still uses, not that you managed releases against it, and the words stay there: "I wrote the release checklist our QA team still uses." Answer slot: the JD's manage-with-QA line makes a probe on how the checklist worked in use likely. If you know how your QA team used it, say so in your own words; if you do not know, or it was not yours to see, say so plainly and stay with the checklist you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [inferred] | discovery | Your material gives four years as an associate producer at a puzzle-game studio, and the weekly calendar covers two of them; it does not say how the other two divide. Words: "I spent 4 years as an associate producer at a puzzle-game studio." Answer slot: expect a probe on how the four years divide. Say which years were which, in your own words; if the other two were different work, say so plainly and stay with the calendar years |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap in the wording, but a line from your message with nothing inspected behind it, so expect a probe. Lead with the calendar in the quote's own terms: weekly, the main title, the last two years, because specifics beat an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in the wording, but a line from your message with nothing inspected behind it, so expect a probe on how the numbers were counted; C1 holds the slots. Lead with the numbers in the quote's own terms: you presented them, monthly, to the studio head |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | transferability | Your material shows a written document still in use, not how it reads, and the words stay there: "I wrote the release checklist our QA team still uses." Answer slot: if you wrote anything else others relied on, say what it was, in your own words; if the checklist is the only such piece, say so plainly and stay with it |

## Persona table

Weights come from the hiring-manager relationship prior. Your message names one 60-minute session run by Tobias, so no other rounds are assumed. No interviewer adjustment was possible because the search for his public footprint was refused. No values-style round is detected: no loop source documents one and no published values are in hand.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from the role: plan a calendar, handle a slip, diagnose a result | High. Hiring-manager prior; the JD's calendar, coordination and KPI lines are the natural material. Bank A, 5 questions | Clarify, then objective, approach, metrics, risks; think aloud; challenge one premise politely |
| Skeptic | Quiet probing of the gaps: weakest on day one, the years, leading, why this move | High. Hiring-manager prior, plus the two limits your message states and the thin rows F2 and F5. Bank B, 5 questions | Rehearse the most predictable objection until it is boring; plain acknowledgment of limits; a plan, never a bluff |
| Data-Driven Prober | Reads your lines closely; asks how a number was counted | Medium. The JD names KPIs and retention metrics, and your message cites retention numbers (F3, F7). Bank C, 3 questions | Know what you can and cannot say about how each number was counted; say plainly when you do not know |
| Conversational | Friendly opener, biography, casual questions on JD topics | Medium. A 60-minute conversation opens with biography whatever the prior; this is a pattern, not a claim about Tobias. Bank D, 3 questions | A 90-second arc from your own sentences; treat casual questions as scored |
| Pressure | Time-boxed, devil's advocate, attribution probes | Low. Skip-level prior only; nothing indicates it here. Bank E, 2 questions | Pause, restate, hold through two follow-ups, concede specifically |
| Peer Evaluator | Seams between teams, what you need from them | Low. No peer is named; the JD's four-team coordination makes collegial seam questions plausible. Bank F, 2 questions | Offer principles for the seam, not claims about the studio's; say what you bring |
| Values / Behavioral | Open prompts about past behavior | Low. No values-style round detected; open prompts are included so the style is not new live. Bank G, 2 questions | Pick a story only where your material carries one; otherwise use the honest branch |

## Question banks

The highest-ROI prep in this pack is B1: it aims at the limits your message states, and it carries the most follow-up levels. B2 is second. The CASE rows are generic because company research did not run.

### Bank A: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your drop is locked for Thursday. On Tuesday, engineering says one feature won't be ready. What do you do?" | CASE | [generic] | Think aloud in order: what you need to know first (what slips, what players would see, what QA still has to cover), the objective for the drop, the options (hold, cut, replace), how you would choose, who has to hear the decision and in what order, and what you would record afterward. The question needs no claim about your past, so the guidance makes none | A live problem from the coordination line (F2's requirement); CASE because it scores structure under a fixed date, not recall |
| A2 | "Sketch the calendar for the next eight weeks of one mobile title. What do you need to know first?" | CASE | [generic] | Clarify before structuring: what the title needs from the eight weeks, what content already exists, what capacity each team has, what is already committed. Then objective, how you would divide the weeks, the plan, how you would measure it, the risks. Challenge one premise politely. The guidance makes no claim about your past | Tests planning directly, since F1 shows one weekly calendar and the interviewer can test the step up; CASE because it is a live problem |
| A3 | "An event ended last week and retention for players who joined during it looks flat. How do you work out whether it worked?" | CASE | [generic] | Clarify the retention window and what flat is measured against; compare against a baseline you can name; look for other releases or calendar items that overlap; split new from returning players; state your hypothesis early; say what you would report and what you would not conclude yet. The guidance makes no claim about your past | Metric diagnosis in the persona stem's shape, tied to the retention and post-event KPI lines (F3, F7) |
| A4 | "Suppose one of our titles sells event passes through in-app purchases. How would you plan the calendar and judge whether an event worked?" | CASE | [generic] | Start by asking what the event is meant to move, purchases, retention or both, and how each would be measured. Then objective, calendar constraints, the measures you would put in the review, and the risk of optimizing one measure at the cost of another. Keep it to questions and structure, and make no claim about purchase work you have done; B1 holds the words for that limit. The question presupposes nothing about your past | Tests the area your stated limits point at as a live problem, not a past; the hypothetical supplies the purchases premise, so nothing about Saltmarsh is assumed |
| A5 | "Design wants a bigger event than the calendar can hold, and community wants it sooner. How do you decide?" | CASE | [generic] | Clarify what each team is trying to achieve and what is fixed. Name the options, the criterion you would choose by, who makes the final call and who must hear it, and what you would write down. Propose principles for the seam rather than claiming to know the studio's. The guidance makes no claim about your past | The JD's four-team coordination line as a live problem (F2's requirement) |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | The highest-ROI rehearsal in this pack. Name one real limit, once, plainly, in your own words. Your message gives two, and the words are sourced: "I haven't worked on a game with in-app purchases." and "I haven't led a team." Choose the one you would genuinely say, without apology or padding. Then give what you would do about it as a plan, in the future tense: what you would ask to see first, whom you would ask, and what would show it was working; claim no learning, courses or exposure you have not stated. Rehearse the follow-ups until they are boring: first what you would do in your first month; then how anyone would know it was working; then what happens if it takes longer than you expect. Hold by returning to the plan, never by adding experience | The stated limits are the likeliest place a skeptic aims this stem; the prohibited list's first two entries carry their words. JD because it scores the whole list of requirements; most follow-up levels in the pack because it is the likeliest objection |
| B2 | "The JD asks for three or more years producing live-service games or apps. How does your experience match that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Say what your message states, at its scope: you spent 4 years as an associate producer at a puzzle-game studio, and you ran the weekly content-drop calendar for the main title for the last two years. Answer slot: expect a probe on how the four years divide. Say which years were which, in your own words; if the other two were different work, or the title was not run that way throughout, say so plainly and stay with the calendar years | F5 is the requirement and F6 its nearest evidence; the years line can be tested literally, which makes this the second-likeliest objection |
| B3 | "This role coordinates several teams on each update. Have you led a team?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Give the plain acknowledgment first: "I haven't led a team." Then hold at the JD's own verb, which is coordinate. Answer slot: if you coordinated work across teams on any drop, say what you did and which part was yours, in your own words; if you did not, or it was not yours to coordinate, say so plainly and return to the calendar you ran. Do not describe coordinating as managing or leading | F2's requirement against the stated limit; JD because the JD's verb is the defense |
| B4 | "You've run the calendar for your studio's main title. The JD has you planning for two titles at once. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Start with the quote at its scope: "I ran the weekly content-drop calendar for our main title for the last two years." Then reason forward as a plan, not a past: what you would ask first about the second title, what you would check for clashes between the two calendars, and how you would tell the teams. Answer slot: if there is anything about running the weekly calendar that you know would not carry across, say it in your own words; if you do not know, say so plainly and say what you would ask first | F1 is the nearest evidence for the calendar requirement; JD because it scores the calendar line and the two-title line together |
| B5 | "What's behind this move, and why Saltmarsh now?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | The reason is yours and the pack supplies none. Answer slot: give your actual reason for the move in your own words, and what in the JD's lines draws you; if you have no particular reason, say so plainly and name what in the JD's lines you would most like to do. Anything you say about this studio's games or plans must come from what you have read yourself, since the pack's research did not run | Motivation-consistency probe from the Skeptic's stems; EXP because it tests the story behind F5's years |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you presented in the quote's own terms: you presented the monthly retention numbers to the studio head. Answer slot: say how the numbers were counted, what they are most sensitive to, the assumption behind them you would defend least, and which part of producing them was yours, in your own words; if you do not know how a number was counted, say so plainly. If others produced the numbers, say so and stay with presenting them | The defend-the-number question for F7; EXP because it tests counting and attribution |
| C2 | "Which retention measures do you look at first, and what would make you stop trusting one?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you know which retention measures were in the numbers you presented, name them in your own words; if you do not know, say so plainly. For what would make you stop trusting a measure, name one condition you have actually seen; if none comes to mind, say so plainly and say how you would check a number before presenting it, as a plan | The retention requirement is a stated JD line; F7 is its evidence |
| C3 | "Which KPIs would you put in a post-event review, and why those?" | JD | [generic] | Choose two or three that follow from what the event was meant to move, and say what question each answers and what it cannot tell you. Say what you would leave out. Keep it a plan, not a record of what you have done | The post-event review and its KPIs are a stated JD line; F3 holds the nearest evidence and it is thin, so this is rehearsed as a design choice |

### Bank D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc whose beats are only what your message states: 4 years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for the main title for the last two years; the release checklist you wrote that QA still uses; the monthly retention numbers you presented to the studio head. Put them in whatever order is true. Answer slot: the last beat is why this role, and that reason is yours; if there is no particular reason, say so plainly and end on the calendar | The biography opener is the one question every conversation holds; EXP because it is scored on economy and accuracy against F5, F6, F4 and F7 |
| D2 | "Tell me about something you've written that a team relied on." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4's evidence: you wrote the release checklist, and your QA team still uses it, which are the beats the quote states; tell them in your own words. Answer slot: the written-communication line makes a probe on how you wrote it likely. If you know how your QA team's use of it changed, or why it still stands, say so; if you do not know, say so plainly and stay with the checklist you wrote | The written-communication line is a stated JD requirement; F8 holds its thin evidence, and the checklist is the one written piece the material carries |
| D3 | "What live-service games do you follow, and what do you notice about how they run?" | JD | [generic] | Name titles you actually play or follow and one thing you noticed, in your own words; if you do not follow any, say so plainly and name the nearest thing you do follow. Casual questions on the JD's own topic are scored | A conversational stem on the JD's live-service wording; the pack cannot supply your answer, and F5 shows the match is not established by the years alone |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." "Never led a team, and never worked on a game with in-app purchases." | Pause and restate the question. Hold to what your message states: you ran the weekly content-drop calendar for the main title for the last two years, you wrote the release checklist QA still uses, and you presented the monthly retention numbers to the studio head. Hold through two follow-ups by returning to these, never by adding to them. Concede one real limit specifically: "I haven't worked on a game with in-app purchases." Then stop | The pressure stem tests hold-then-concede; JD because it scores fit to the whole list (F1, F3, F4) |
| E2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: say what was yours and what was others', in your own words; the quote says ran and nothing about who set what. If part of it was set by others, say so plainly and stay with the part you ran. Hold the claim at ran through two follow-ups, and concede what you do not know, specifically | The attribution probe on F6; EXP because it tests what was yours |

### Bank F: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Where's the seam between live ops and design on an update, and what happens when you disagree?" | JD | [generic] | Propose principles rather than claiming to know the seam: who decides what, what each side needs from the other, and how a disagreement is settled before the drop date. Add what you bring to the design team, not only what you need. If a disagreement from your own work comes to mind, say what it was and what was yours; if none does, say so plainly and give how you would handle it | The collegial form of the coordination line (F2's requirement) |
| F2 | "You wrote the release checklist your QA team still uses. Walk me through how a release runs against it." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Start with the quote at its scope: "I wrote the release checklist our QA team still uses." Answer slot: the manage-with-QA line makes a probe on how the checklist worked in use likely. If you know how your QA team used it, say so in your own words; if you do not know, or it was not yours to see, say so plainly and stay with the checklist you wrote | F4 is the evidence for the checklist requirement and this is its only question |

### Bank G: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time you told someone senior something they did not want to hear; it needs a named stake, what you said, and what happened afterward. This pack's material does not show such a time. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Values persona's stem; generic because no published values are in hand |
| G2 | "Tell me about a time an update didn't go the way you planned." | VAL | [generic] | Pick a drop or release that changed after it was planned; it needs what changed, what was yours to do, and what you changed afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | An open prompt themed on the JD's per-update line (F2's requirement) |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1: live-events calendar for two mobile titles | B4, A2, A4 |
| F2: coordinate design, art, engineering and community teams on each update | B3, F1, A1, A5, G2 |
| F3: own the post-event review and the KPIs it reports | C3, A3 |
| F4: manage the release checklist with QA | F2 |
| F5: 3+ years producing live-service games or apps | B2, D3 |
| F6: experience running a content calendar | B4, A2, D1, E2 |
| F7: comfortable with player-retention metrics | C2, C1, A3 |
| F8: clear written communication | D2 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "Which two titles would this role cover, and what is each calendar trying to do for its title over the next quarter?" | It asks for the context a producer plans from, which your material cannot supply, and shows you plan from goals rather than dates |
| R2 | "What does a good post-event review look like here, and who reads it?" | It speaks to the review line in the JD and shows you how far the studio's practice sits from the numbers you have presented |
| R3 | "If any of the events are tied to in-app purchases, how does that change what the producer reports?" | It names your limit as a learning question, and turns B1 into a conversation without claiming anything |
| R4 | "How are updates coordinated across design, art, engineering and community today, and where does it tend to slip?" | It uses the JD's own four teams and asks where the producer's work is hardest |
| R5 | "How does QA work with the producer on the release checklist today, and what would you want changed?" | It ties to the JD's checklist line and to the checklist you wrote, and opens how it is used in practice |
| R6 | "What would you want me to have learned or changed by day 60?" | It makes the first weeks concrete and lets you test your day-one plan from B1 against their expectation |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| P1: Led a team | Negative the candidate stated, your message | The quote: "Never led a team, and never worked on a game with in-app purchases." Plain acknowledgment it gives: "I haven't led a team." No slot |
| P2: Worked on a game with in-app purchases, or on its purchase side | Negative the candidate stated, your message | The same quote. Plain acknowledgment it gives: "I haven't worked on a game with in-app purchases." No slot |
| P3: Planned and ran live events for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a weekly content-drop calendar for the main title, not live events and not two titles. B4's slot stays inside the calendar |
| P4: Owned the post-event review and the KPIs it reports | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says presenting monthly retention numbers, not owning a review or its KPIs. C1's slot asks only how the numbers were counted |
| P5: Managed releases with QA | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says writing the checklist, not managing releases against it. F2's slot stays inside the checklist |
| P6: Has 3+ years producing live-service games or apps | Inflated form of F5 | F5's quote and F6's quote at their own scopes. The limit is the pack's observation: the material gives 4 years as an associate producer at a puzzle-game studio and two years on the calendar, not 3+ years of live-service work. B2's slot asks only how the years divide |

## Sources

Provided documents: the JD text and your background lines, both pasted in your message. No CV and no tuesday-dossier.md were provided.

Searches sent, all refused, nothing returned:

- `Saltmarsh Games values`: refused
- `Saltmarsh Games interview process live operations producer`: refused
- `Saltmarsh Games strategy mobile games news`: refused
- `Tobias Wrenfield Saltmarsh Games`: refused

No fetches were sent.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | The call was refused. It would have moved the values cheat sheet and the VAL questions; G1 and G2 are generic as a result |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | The call was refused. It would have moved loop structure and persona weights, which rest on the hiring-manager prior and your one named session |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | The call was refused. It would have moved CO questions and the grounding brief; A1 to A5 are generic as a result |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | The call was refused. It would have moved the interviewer read, persona weights and a reverse question tied to his path |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV pasted in → the evidence cells quote the CV instead of your message summary, and F4, F6 and F7 can move on what it shows
- Which teams you worked with on a drop, and what you needed from each → F2 moves from none given to a mapped row, and A1, A5, B3 and F1 gain a story
- Which years of the four were on the weekly calendar, and whether the title ran as a live service → F5 and B2 move from slots to mapped answers
- How the monthly retention numbers were counted → C1 and C2 move from slots to mapped answers
- A look at your own artifacts, such as the release checklist, a calendar export or a retention deck → medium rows (F1, F3, F4, F6, F7) can move to high on inspection
- Search access for company research → Saltmarsh's published values, its documented interview loop and recent strategy replace the generic CASE and VAL rows; a deeper pass would add up to 6 more searches and 2 more fetches for a strategy brief, several more minutes, offered once
- Tobias's public footprint, via the same access → an interviewer read, tuned persona weights, and a reverse question tied to his path
- Whether Tobias is your future manager, and what the recruiter said about the 60 minutes → reweights every bank and adds a build section if a deliverable was announced
- How much prep time you have before Friday → a prioritized schedule, ending with what is insurance
- A tuesday-dossier.md from an earlier fit review → verified evidence and prohibited-claims guardrails would replace the ones built locally here
