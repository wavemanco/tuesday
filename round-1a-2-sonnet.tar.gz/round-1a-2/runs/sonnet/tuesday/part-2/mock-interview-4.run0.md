I'm building the prep pack now. The three web searches were refused, so I'm working from the dossier alone and marking the company-specific parts as generic.
Your prep pack is saved as Quartzline_product-manager-platform-apis_interview_pack.md. It has 22 questions, built for a single hiring-manager conversation from your dossier. The dossier is dated 2026-08-14, so it's worth confirming the posting hasn't changed.

The three web searches I tried (values, interview process, strategy) were refused. Anything about Quartzline itself is therefore generic, and the pack has no values cheat sheet. The pack says this in Sources and the upgrade menu.

Two things to know before you read it:
- **B1 is the question to rehearse most.** It's the objection your dossier named: no PM title, no roadmap ownership. The pack coaches a plain concession first. Then it gives the bridge from your integration work with its limit named, then a ramp plan. It does not coach a bridge for roadmap ownership, because your dossier marked that area `acknowledge_gap`.
- **R2 (shipped API or platform products) is a must-have the dossier gave no strategy.** I treated it as an open question you answer in your own words, either way. It's the likeliest miss after B1.

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a tuesday-dossier.md with the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

- Role: Product Manager, Platform APIs, Quartzline
- Round: a 45-minute conversation with the hiring manager, Thursday. Interviewer's name and profile: not provided
- Built on: your tuesday-dossier.md (version 1.1, dated 2026-08-14). The loop beyond this one conversation is not established, so persona weights rest on the hiring-manager relationship prior and a generic loop pattern

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: where a cell says "answer slot", the words have to be yours, from what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | The stated responsibilities and requirements, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, structure over the "right" answer |

Highest-ROI prep: question B1. Your underwriting dossier named it as the likeliest objection, so this pack gives it the deepest rehearsal.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile, R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [grounded] | transferability | The dossier's strategy is bridge: adjacent work, never PM experience. The words stay at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." The limit is named before it is asked for: the material shows integration leadership and no PM title or PM years. Plain acknowledgment, sourced from `prohibited_claims: "Having held a product manager title or role"`: "I haven't held a product manager title or role." |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile, responsibilities | none given | none | [grounded] | capability | The dossier's `uncertain_or_weak_areas` entry for roadmap ownership carries `acknowledge_gap`, so there is no bridge and no slot. Plain acknowledgment, sourced from `prohibited_claims: "Having owned a product roadmap"`: "I haven't owned a product roadmap." Then a plan, said as a plan and never as a past: learn how roadmap decisions are made here and which belong to the squad leads |
| F3 | "Shipped API or platform products" — dossier role_profile, R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | The dossier lists R2 as high priority but gives it no gap strategy, so this row is the pack's own call, derived from a quote that touches APIs without showing anything you launched to others. Answer slot: the must-have line makes a probe on what you shipped likely. If you shipped an API or platform product, say what and which part was yours, in your own words; if you never worked that way, say so plainly, return to the integrations at the quote's scope, and say what you would want to confirm about how they define shipped |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile, R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quotes show REST API work and a playbook, and do not show whether either involved API docs or schemas. Answer slot: if you read or wrote API docs, or worked with schemas, say which and for what; if you did not, say so plainly, return to the REST work at the quote's scope, and say what you would read first |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile, R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | Clients and product are in the quotes; engineering and sales are not. The sessions line is confirmed with limited inspectable proof, so volunteer the limit before a prober extracts it: "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot: if engineering or sales people were part of those integrations or sessions, say who and what you did together; if not, say so plainly and stay with clients and product |
| F6 | "Agile delivery experience" — dossier role_profile, R5, preferred | none given | none | [grounded] | discovery | The dossier's strategy is clarify. Answer slot: the requirement's own wording, agile delivery experience, is the interviewer's likely probe. If you have worked that way, say where and what your part was; if you have not, say so plainly and say what you would want to confirm about how they define it |
| F7 | "Run discovery with integration partners" — dossier role_profile, responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | Words stay at the quote: sessions, run by you, feeding client evidence to product. The material does not show what product did with it. Answer slot: the discovery line makes a probe on how the client evidence was gathered likely. If you gathered it, say how, in your own words; if it reached you another way, or there was no such step, say so plainly and stay with the sessions you ran |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile, responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [grounded] | transferability | The quote is delivery of client integrations, not squad delivery. The material does not show you directing an engineering squad's priorities and the pack does not coach it. Answer slot: if requirements you wrote were built from by engineers, say so and what your part was; if not, say so plainly and stay with the integrations |
| F9 | "Define and track adoption metrics" — dossier role_profile, responsibilities | none given | none | [grounded] | discovery | Answer slot: the adoption line makes a probe likely. If you defined or tracked any measure of whether partners used an API, say which and how it was counted; if none, say so plainly and say what you would measure first. The dossier also lists the current adoption baseline as unknown, which is a reverse question below |

No row is a gate: the dossier lists no hard gates and none of its requirements is a term the candidate meets or does not.

## Persona table

The relationship prior for a hiring manager is Case/Strategist plus Skeptic. No interviewer profile exists to adjust it, and no loop source establishes the loop, so the generic pattern applies with flat tilt beyond the prior. No values-style round is detected, which keeps the Values persona at the bottom.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems from the role: adoption, partner trade-offs, API change | High: hiring-manager prior; the role's JD lines on roadmap, adoption and squads give them material | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Skeptic | Probes the title and roadmap gap, the must-have R2, the thin spots | High: hiring-manager prior, plus the dossier named the objection | Rehearse the objection until it is boring; concede plainly where the material is silent; bridge only inside the named limit; ramp plan |
| C. Conversational | Opening biography, motivation, casual tooling talk | Medium: a 45-minute conversation will open this way and it is still scored | A 90-second arc built only from your own sentences; treat casual questions as scored |
| D. Data-Driven Prober | Reads the evidence line by line; asks how 30+ was counted | Medium: the headline figure is a standard target | Know what you can and cannot say about the count; name the weakest assumption first |
| E. Pressure | Time-boxes you; asks how much was actually you | Low to medium: the hiring manager is buying capability and derisking the gap | Pause, restate, anchor in what you said, hold through two follow-ups, concede specifically |
| F. Peer Evaluator | Seam with the two squad leads; credit across teams | Low to medium: the JD's squad structure invites the seam question | Propose seam principles rather than pretend to know the seam; reciprocity framing |
| G. Values/Behavioral | Scenario probes | Low: no values page was read and no values-style round is detected | Selection scaffolds with an honest branch |

## Question banks

Requirement coverage:

| Requirement | Questions |
|---|---|
| R1 3+ years product management experience | B1, B5, E2 |
| Own the roadmap (R1 sub-claim) | B1, B5, A2, F1 |
| R2 Shipped API or platform products | B2, A1 |
| R3 Technical fluency: API docs, schemas | A4, C3 |
| R4 Stakeholder management | B3, A2, F1, F2 |
| R5 Agile delivery experience | B4 |
| Run discovery with integration partners | A1, B3, C1 |
| Write specs and drive delivery with two squads | A2, A3, F1 |
| Define and track adoption metrics | A1, A5 |

### A. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Partner adoption of an API stalls after launch. What do you need to know first, and how do you diagnose it?" | CASE | [generic] | Clarify first: what adoption means here, how it is measured today, the current baseline. Then objective, segments of partners, hypotheses, the data you would pull, the risks. Challenge one premise respectfully. This question needs no claim about your past, so the guidance makes none | The JD's adoption and partner-discovery lines (F9, F7) make this a likely live problem; CASE because it scores structure |
| A2 | "Two squads and a partner each want something different next quarter and you can do only one. How do you decide, and who decides?" | CASE | [generic] | Say your criteria aloud: partner impact, cost to existing integrations, what each squad can absorb. Then say which parts of the call you would want the squad leads' view on, and that you would ask how decisions are split today instead of assuming. Do not present the call as yours alone | The decision-authority question is open in the dossier (F2, F8); CASE because it scores reasoning, and the answer must not outrun the material |
| A3 | "A partner asks for a breaking change to an endpoint other partners depend on. Walk me through it." | CASE | [generic] | Clarify who depends on it and what the change is for. Options: refuse, version, deprecate with notice, build alongside. Risks and a communication plan. Make no claim about having done this | The platform-API role makes change management a plausible live problem (F8); CASE |
| A4 | "The role asks for fluency with API docs and schemas. Where are you strongest, and where are you still building?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what you led, at the quote's scope. Answer slot: the JD's docs and schemas wording makes a probe on whether you read or wrote them likely. If you did, say which and for what; if you did not, say so plainly, return to the REST work, and say what you would read first. Then the building part is a plan, not a past | F4 is a discovery row, so the honest answer is ready before the probe; JD because it scores a stated requirement |
| A5 | "Which two adoption metrics go on the dashboard first, and why?" | CASE | [generic] | Ask how adoption is measured today and what the baseline is, then pick two measures tied to a partner outcome, and name the assumption behind each that you would defend least. Make no claim about metrics you have tracked | The JD names adoption metrics as a responsibility and the dossier lists the baseline as unknown (F9); CASE |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; the negatives are sourced from dossier `prohibited_claims` and `uncertain_or_weak_areas` | Named by your underwriting dossier as the likeliest objection, so this is the deepest rehearsal. Level 1, concede first and plainly: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Then the bridge with its limit: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Adjacent work, never PM experience, and say so. Then a plan: learn how roadmap decisions are made here and which belong to the squad leads. Level 2, "Why not hire someone who has done it?" Do not argue the title away; restate what the quote says and what you would have to learn. Level 3, "Which part would you be weakest at on day one?" The roadmap, said plainly. Do not call the integration work equivalent to a PM role, and keep the sessions line out of this answer: it is input to a roadmap, not ownership of one | F1 and F2 are the biggest gap and the one the interviewer is most likely to open with; JD because it scores the PM-experience requirement, with Skeptic delivery |
| B2 | "Shipped API or platform products is a must-have for us. What have you shipped?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: the must-have wording is the interviewer's probe. If you shipped an API or platform product, say what and which part was yours, in your own words; if you never worked that way, say so plainly and return to the integrations at the quote's scope. Add what you would want to confirm about how they define shipped | F3 is a must-have with no dossier strategy, so it is the likeliest miss after B1; JD |
| B3 | "Walk me through how the quarterly roadmap-input sessions worked." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Beats the quote states: quarterly, sessions, you ran them, client evidence fed to product. Tell them in your own words. Name the limit before it is extracted: this line is confirmed with limited inspectable proof. Answer slot: if you saw what product did with what the sessions fed it, say what you saw; if you did not see it, or nothing came of it, say so plainly and stay with the sessions you ran | F7 is the medium-confidence line a prober will test; EXP because it scores attribution |
| B4 | "Tell me about a time you worked inside an agile delivery process." | JD | [grounded] | Answer slot: the JD's agile delivery wording is the probe. If you have, say where and what your part was; if you have not, say so plainly and say what you would want to confirm about how they define it. Nothing about your past goes in beyond what you say here | F6 is a clarify area; JD because it scores a stated requirement |
| B5 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] dossier `prohibited_claims: "Having owned a product roadmap"` and `uncertain_or_weak_areas` | Name the roadmap, plainly: "I haven't owned a product roadmap." Then the plan as a plan: learn which decisions the squad leads own, and sit with partners before proposing anything. Do not soften it and do not volunteer a bridge here, because the dossier closed that door | F2 is an acknowledge_gap area; JD with Skeptic delivery |

### C. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey. How did you get from integrations to this role?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | A 90-second arc with only the beats the quotes state: you led 30+ client integrations, and you wrote the internal playbook your team uses. Answer slot: why product is yours to say, in your own words; no reason is supplied here | The opening question of a conversational round; F1 and F4 are what the arc stands on; EXP |
| C2 | "What drew you to Quartzline's partner API platform?" | CO | [generic] | A selection scaffold: pick one thing you actually read or used about Quartzline and say why it mattered to you. The pack holds no Quartzline facts because the research searches were refused. If nothing specific comes to mind, say so plainly and say what you would want to learn | The research was refused, so this is a generic scaffold rather than a story; CO |
| C3 | "What are you playing with in API tooling these days?" | JD | [generic] | A selection scaffold: name something you have actually used, what for, and what you learned. If nothing comes to mind, say so plainly and name what you would try first | The casual question that scores R3 (F4); JD |

### D. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the 30+ was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot, the four things a figure raises: say how it was counted, what the count is most sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words. If you do not know how it was counted, say so plainly. Never defend a method you cannot repeat under a second question | The headline figure of F1; EXP |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Name it before they do, in your own words. If you do not know of one, say so plainly. The pack does not supply the assumption | The weakest-assumption move converts a gotcha into credibility (F1); EXP |
| D3 | "What did you write in the integration playbook, and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Stay at the quote: you wrote it, it is internal, your team uses it. Tell it in your own words. Decide beforehand what of it you are allowed to share and say plainly if that is nothing | F4's second quote; EXP |

### E. Pressure (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That result — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause, restate the question, anchor in the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Hold that through two follow-ups. Then concede specifically. Answer slot: say which of the listed stages others did, in your own words; if all were yours, say so plainly. Never fold on the core claim to restore harmony | F1's attribution is the standard stress target; EXP |
| E2 | "Sixty seconds: what is your plan for the first ninety days in a role you have not done before?" | JD | [generic] | A plan, not a past: learn which decisions the squad leads own, listen to partners, find how adoption is measured and its baseline, and propose nothing before that. Time-box yourself. Make no promise of outcomes | The ramp plan the dossier's acknowledge_gap strategy needs (F2); JD with Pressure delivery |

### F. Peer Evaluator (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Where is the seam between you and the two squad leads, and what happens when you disagree?" | JD | [generic] | Propose seam principles instead of pretending to know the seam: who holds which kind of decision, how disagreements escalate, what each side needs from the other. Say you would ask how it works today. Do not claim authority over their priorities | The decision-authority unknown (F2, F8); JD |
| F2 | "How do you handle credit when work spans teams?" | EXP | [generic] | A selection scaffold: pick an example you actually have, "we" for context and "I" for your contribution. If none comes to mind, say so plainly and say how you would handle it | The credit probe scores the stakeholder requirement (F5); EXP |

### G. Values/Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | A selection scaffold: a named stake, the moment you said it, and a relationship that was intact after. Your material shows no such story, so if none comes to mind say so plainly, then give the nearest thing you actually have or how you would handle it | The persona stem for the values register; no published values were read, so VAL is generic |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | A selection scaffold: a real choice, what you gave up, what the customer got. If none comes to mind, say so plainly and say how you would weigh it | Persona stem; F5's customer side is the nearest row, but no quote carries this story |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | Which roadmap decisions does this PM make alone, and which belong to the squad leads? | The decision-authority split is named in the posting and not evidenced; the answer is something you need before accepting |
| 2 | How is partner API adoption measured today, and what is the current baseline? | The posting names adoption metrics and no baseline is stated; it reads as diligence |
| 3 | Can you describe the last time the PM and the two squad leads disagreed on scope, and how it resolved? | It asks for an instance instead of assuming a process, and shows how the seam works |
| 4 | What does a strong first quarter look like here, and what would you want me to learn first? | It invites the ramp plan from the person who will judge it |
| 5 | Which partners would I speak to in the first month, and how are those conversations run today? | It ties to the discovery responsibility and shows you intend to listen first |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | F1's quote at its own scope, with the limit named. Plain acknowledgment: "I haven't held a product manager title or role." |
| Having owned a product roadmap | Dossier `prohibited_claims` and the `acknowledge_gap` area | Plain acknowledgment: "I haven't owned a product roadmap." A plan, never a bridge or a slot |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | Plain acknowledgment: "I haven't set prioritization for an engineering squad." No slot |
| Shaped or influenced the roadmap | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation, not words for you: the material says sessions feeding client evidence to product, not what product did with it |

## Sources

Provided documents: tuesday-dossier.md, version 1.1, consumed. It supplied `role_profile` (the requirement and responsibility lines), `handoff_to_mock_interview` (verified evidence, weak areas and strategies, the objection, risks, employer questions, prohibited claims), and `decision` as context only.

Searches sent, all refused by the host, none returned anything:
- `Quartzline company values` — refused
- `Quartzline interview process product manager` — refused
- `Quartzline API platform strategy news` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Would have moved a values cheat sheet and the VAL bank; both are generic or dropped |
| 2. `Quartzline interview process product manager` | unavailable | Would have moved loop structure and persona weights; weights rest on the hiring-manager prior and a generic pattern |
| 3. `Quartzline strategy` / recent news | unavailable | Would have moved CO and CASE grounding; A1, A3, A5 and C2 are generic |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile fixes the requirement lines the fit snapshot and JD questions use |

## Upgrade menu

- The interviewer's name or profile → an interviewer read, persona weights tuned to their public footprint, and a reverse question tied to their own path
- The recruiter's prep notes (focus areas, any announced deliverable) → coverage that replaces the hiring-manager prior, and a build section for any deliverable
- Search access, or Quartzline's values page, loop description or strategy notes pasted in → a values cheat sheet if a values round is documented, and grounded CO and CASE questions in place of A1, A3, A5 and C2
- A deeper research pass (up to 6 further searches and 2 further fetches, several more minutes), offered once → a strategy brief and role-family loop reports
- The current job description text → a check that the dossier's role profile, dated 2026-08-14, still matches the posting
- Your own words on any answer slot, said outside a drill → F3, F4, F5, F6, F7, F8 and F9 regenerate with your quoted sentences
- An agenda or notes from one of the quarterly roadmap-input sessions → F5 and F7 could move from medium toward high
- How many hours you have before Thursday → a prep triage schedule sized to it
