Web search was refused, so I'm building the pack from what you've told me. I'll save it now.
Your prep pack for all three rounds is saved as `Larkfield-Systems_engineering-manager_interview_pack.md`. I built it as a loop pack. It has a shared fit snapshot, then a separate question set for each round: Tuesday's hiring manager, Thursday's panel and Monday's VP. Each round has its own persona weights and reverse questions, and the pack runs to about 30 questions.

Web search was refused, so the pack uses only what you told me. That has two effects:
- **Company details:** it contains nothing about Larkfield's values or strategy. The company-knowledge and live-problem questions are labeled generic, and there is no values cheat sheet for Monday.
- **Evidence:** I had only your message, not your CV, so only a few of your sentences carry a full story. The rest of the guidance is scaffolds.

The most important prep is A2, the hardware-roadmap objection for Tuesday. It is the gap you named against a line in the role, and the Director of Engineering is the person who would own that partnership.

Say the word and I'll play the Skeptic on A2 with live follow-ups. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions, or convert the pack to a Word document.

I have two questions:
1. Can you paste the full job description and your CV? Without the full JD I only have your one-paragraph description of the role, and I'll proceed with that if you'd rather not.
2. Has the recruiter given any focus areas for the panel or the VP round, or any exercise to prepare? This would reweight rounds 2 and 3.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield-Systems_engineering-manager_interview_pack.md -----
# Interview pack — Engineering Manager, Larkfield Systems (loop mode, three rounds)

**Candidate:** Yusuf. **Role:** Engineering Manager, two squads building device-management services, 11 engineers.

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering (name not given) | 45 min | Hiring manager, your would-be boss |
| 2 | The Thursday after | Two staff engineers and a product manager (names not given) | 60 min | Panel |
| 3 | The following Monday | VP Engineering (name not given) | 30 min | Skip-level, described by the recruiter as "values and leadership philosophy" |

## How to use this pack

Personas are how a question is asked; types are what is being scored. Guidance is scaffolding, not a script. Where guidance says "answer slot", it is an instruction for the interview: answer from your own experience, or say plainly the thing was not yours.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values and leadership, not generic virtue |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | The stated responsibilities, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, scored on structure |

The shared sections come first (triage, fit snapshot). Then one mini-pack per round, then the shared prohibited claims, sources and upgrade menu. Every question ID is unique across the pack, so the drill and your notes can point at it.

**Highest-ROI prep in the pack: A2.** The hiring manager is the person who owns the hardware partnership, and your own message names the gap. A2 gets the deepest rehearsal.

## Prep triage

You have two weeks and three rounds. Do these in order; everything else is insurance.

| When | Do | Tied to |
|---|---|---|
| Before Tuesday | Rehearse A2 aloud until it is boring, including both follow-ups and the concession wording | A2, F6 |
| Before Tuesday | Write your own 90-second arc from your own sentences, and settle your actual reason for this role | D1, A4 |
| Before Tuesday | Work out, in your own words, how the 60% and the 40 interviews were counted, and say plainly where you do not know | C1, C2 |
| Before Tuesday | Think one CASE through aloud, clarify first | B1 |
| Between Tuesday and Thursday | Rehearse the reliability quarter story with only the beats you can stand behind | E3, F1 |
| Between Tuesday and Thursday | Prepare your seam principles and your reciprocity answer | E1, E4 |
| Between Thursday and Monday | Draft two or three sentences on your leadership philosophy and the one decision that shows it | I1, I2 |
| Between Thursday and Monday | Rehearse the 60-second answer and the concession | K1, K2, I4 |
| Any day | Ask the recruiter for focus areas for rounds 2 and 3 | Upgrade menu |

Everything else in the pack is insurance.

## Fit snapshot (shared)

Requirements are the role description you gave me. Evidence is your own words from your message and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (scope strand) — role description in your message | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material says a team lead of 6, nothing inspected behind it, and the words stay there: "Of my 9 years in engineering, 3 were as a team lead of 6." The role's two squads and 11 engineers is a wider span than that quote carries, and your material does not show how it differs. Answer slot: the two-squads line makes a probe on the jump likely. Say what you expect to be different at that span, as a plan and not as a past |
| F2 | "Lead two squads building device-management services" (domain strand) — role description in your message | "currently at a payments company" — your message | low | [inferred] | discovery | The quote names your employer's sector, not any device or fleet work, so the material does not show whether this requirement is reached. Answer slot: the device-management line makes a probe on your domain likely. If any of your work touched devices, fleets or something close, say what, in your own words; if none did, say so plainly and stay with the payments context you stated |
| F3 | "own delivery, hiring and growth for 11 engineers" (delivery strand) — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | Words at the quote's scope: "I pushed a reliability quarter through against roadmap pressure, and my team's on-call burden dropped 60% after." The quote orders the two events and does not say the push caused the drop. Answer slot: the own-delivery line makes a probe on how the push happened likely. If the decisions and trade-offs were yours, say what you decided and did, in your own words; if others shared them, or there were none, say so plainly and stay with the quarter you pushed through |
| F4 | "own delivery, hiring and growth for 11 engineers" (hiring strand) — role description in your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe, and the figure raises the defend-the-number slots in C2. Lead with the loop in the quote's own terms: you run the hiring loop for backend roles, and the figure is about 40 interviews last year |
| F5 | "own delivery, hiring and growth for 11 engineers" (growth strand) — role description in your message | none given | none | [grounded] | discovery | Nothing in the material speaks to growing engineers. Answer slot: the growth line makes a probe likely. If you developed an engineer, say who and what you did, in your own words; if there was no such case, or it was not yours, say so plainly and return to the team of 6 you led |
| F6 | "partner with hardware and product on roadmap" (hardware strand) — role description in your message | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. The pack's observation: the role says partner and your quote speaks to owning, so what you have or have not done alongside hardware is not shown, and no wording here adds to the negative |
| F7 | "partner with hardware and product on roadmap" (product strand) — role description in your message | "roadmap pressure" — your message | low | [inferred] | discovery | The quote mentions roadmap pressure and not who applied it, so the material does not show whether it reaches product partnership. Answer slot: the product line makes a probe on how you work with product likely. If the pressure came from product, or you worked a roadmap with a product counterpart, say what happened and what part was yours, in your own words; if not, say so plainly and stay with the reliability quarter as quoted |

Coverage across rounds (every requirement and both headline figures):

| Requirement | Question IDs |
|---|---|
| F1 two squads, scope | A3, I4, K1 |
| F2 device-management domain | D2, H1, B3 |
| F3 delivery | B2, E3, I2, K2 |
| F4 hiring | C2, F2 |
| F5 growth | H2, I3 |
| F6 hardware partnership | A1, A2, B1, J1 |
| F7 product partnership | B2, G1 |
| The 60% figure | C1, F1, K2 |
| The 40 interviews figure | C2 |

---

# Round 1 — Tuesday, Director of Engineering (45 min)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the hardware gap, the span, and why this move | High. Hiring manager is the relationship prior for Skeptic and Case; F6 is a stated gap against a JD line | Rehearse the single most predictable objection until boring; calibrated candor over bluffing |
| Case/Strategist | Live problems from the actual role on hardware dependencies and prioritization | High. Same relationship prior; the role is delivery plus roadmap partnership | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober | Reads the figures line by line | Medium. You gave two figures, F3 and F4, so both are targets | Know how each figure was counted and say plainly where you do not know; name the weakest assumption first |
| Conversational | Opener and domain chat that is still scored | Medium-low. Opening arcs are asked in most manager rounds | Pre-script a 90-second arc from your own sentences; treat casual questions as scored |

Basis: the rounds come from your own words; no archetype fallback was used. The weights rest on relationship priors only, since no interviewer information exists.

## Question banks

### A. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | Name the hardware side in the quote's own terms: "I have never owned a hardware-adjacent roadmap." Then say, as a plan, who you would sit with first and what you would ask them, in your own words. Stop there; do not add strengths to cushion it | F6 is the stated gap and the honest answer to this stem; JD because it scores the listed job |
| A2 | "You haven't owned a hardware-adjacent roadmap. How would you handle the hardware side of this role?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | The highest-ROI rehearsal in this pack. Hold the position the quote carries: "I have never owned a hardware-adjacent roadmap." Follow-up 1, how do you know it is not a blocker: answer with your plan for the first weeks, not a past. Follow-up 2, what do you actually know about working with hardware: answer slot, the JD's partner-with-hardware line makes this probe likely; if you worked alongside hardware or firmware people, say how, in your own words; if you did not, or it was not yours, say so plainly and return to the plan. Concession, said specifically: "I haven't done it before, and here is how I would get up to speed." Never fold on the plan to restore harmony | F6 is where the role presses hardest and where your material is thinnest, so this objection arrives in some form; deepest means two follow-up levels, exact concession wording and the limit named before it is asked for |
| A3 | "The role covers two squads and 11 engineers. What changes for you at that span?" | JD | [grounded] "3 as a team lead of 6" | Start from the quote: "Of my 9 years in engineering, 3 were as a team lead of 6." What changes is yours to name as a plan: how you would divide your attention and what you would stop doing yourself. Answer slot: if any of your 6 worked across more than one group, say how; if not, say so plainly and stay with the team of 6 | F1 is the scope gap; the JD's own numbers make the probe near-certain |
| A4 | "Why this role, why now?" | JD | [generic] | Your actual reason, in your own words, in two parts: what draws you to this domain, and why now. The material gives no reason, so none is supplied here; a reason you do not hold is the one a follow-up breaks | Motivation consistency is what the Skeptic scores; no claim about your past is made, so the label stands alone |

### B. Case/Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A hardware release slips six weeks and your squads' device-management work is staged behind it. What do you need to know first, and what do you do?" | CASE | [generic] | Clarify first: what is blocked, what is not, how firm the new date is. Then objective, options (reorder, decouple, hold), who you inform and when, risks. Challenge one premise, such as whether the work was ever sequenced behind the release. No claim about your past is made | Live problem from the JD's hardware-partnership line (F6's requirement); generic because it is a pattern for the problem |
| B2 | "Product wants something new this quarter; one of your squads is midway through reliability work. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure it: what each side is protecting, what the cost of delay is for each, what evidence you would want, who decides. If you refer to your own story, only as quoted: you pushed a reliability quarter through against roadmap pressure. Answer slot: if the pressure came from a product counterpart and you made the case, say how, in your own words; if the call was not yours alone, or there was no such case, say so plainly and stay with the quote | F3 and F7 meet in this problem; CASE because the question asks about no past |
| B3 | "What would you measure in your first 90 days to know the two squads are healthy?" | CASE | [generic] | Three buckets work as a structure: delivery, reliability, people. Name what you would measure in each and what would make you act. State what you would need to ask first. No claim about your past is made | The device-management services in the JD are the object; F2 means this must be reasoned from first principles, not experience |

### C. Data-Driven Prober (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer slot: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words. If you do not know how it was counted, say so plainly. Hold only the quote's reading: the drop came after the push; do not say the push caused it unless you can back that | The headline metric is the first thing a prober checks; F3 |
| C2 | "About 40 interviews last year. What were they, and what part was yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Answer slot: how the 40 was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, in your own words. The figure counts interviews, not hires. If you do not know how it was counted, say so plainly | F4 carries a figure; defend-the-number applies |

### D. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | 90-second arc built from the quote's clauses: 9 years in engineering, 3 as a team lead of 6, now at a payments company. Add why you are here in your own words; no other beat is supplied | The opener is scored; F1 is the arc's spine |
| D2 | "What are you actually playing with in industrial IoT or device fleets these days?" | JD | [generic] | Answer slot: the device-management line makes this probe likely. If you have done anything with devices, fleets or similar, say what, in your own words; if not, say so plainly and say what you would read or try first, as a plan | F2 is discovery; a casual register on a hot JD topic is still scored |

## Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "What would you want the two squads' delivery to look like at six months for you to call this hire a success?" | Turns your day-one gap into a shared target you can be held to |
| R1.2 | "Where does hardware's planning most constrain the squads, and how do the two planning cycles meet today?" | Goes straight at F6 and signals you intend to learn it |
| R1.3 | "How are the 11 engineers split across the two squads, and are there leads inside them?" | Surfaces whether leading through leads is part of the job at all |
| R1.4 | "What is the on-call and reliability situation I would inherit, and how does the roadmap make room for it?" | Shows what you care about without claiming a past |
| R1.5 | "Is this seat new or a backfill, and what did the team learn from the previous arrangement?" | Gives you the context a first 90 days needs |

---

# Round 2 — The Thursday after, panel: two staff engineers and a product manager (60 min)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting, credit, "what would you need from us" | High. Assumed for the staff engineers: the role leads squads they sit in or beside, so the panel row blends Peer with the technical probers | Reciprocity framing; propose seam principles rather than pretend to know the seam |
| Data-Driven Prober | Staff engineers checking the figures and the hiring practice | Medium. Technical specialists lean to depth checks | Know how each figure was counted; name the weakest assumption first |
| Values/Behavioral | The product manager's scenario probes on working with product | Medium. Cross-functional relationship prior; the JD names product partnership | Map a story only where one of your quoted sentences carries it; otherwise a selection scaffold with the honest branch |
| Conversational | Chatty product-side questions | Low-medium. Cross-functional prior | Treat casual questions as scored |

Basis: the staff-engineer relationship is an assumption from the role description; if you know their actual relationship to the squads, tell me and the weights change.

## Question banks

### E. Peer Evaluator (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our squads sit alongside you. Where is the seam between what you decide and what staff engineers own technically, and what happens when we disagree?" | JD | [generic] | Propose principles rather than pretend to know the seam: who owns the what, who owns the how, how a disagreement is escalated and how it is recorded. Say what you would ask them first. No claim about your past is made | A peer stem; the role leads squads these engineers work in or beside |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams and credit mattered; it needs a named stake, a concrete thing you did, and a result that held. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Credit probes appear in peer rounds; nothing in the material carries this question |
| E3 | "You pushed a reliability quarter through against roadmap pressure. Walk us through how." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on F3, with only the beats the quote states: a reliability quarter, roadmap pressure, you pushed it through, and the on-call burden dropped 60% after. Answer slot: the own-delivery line makes a probe on how it got through likely. If you made the case to specific people, say how, in your own words; if the decision was not yours alone, or there was no such step, say so plainly and tell the quarter as quoted | Engineers care about reliability work; EXP because it tests what was actually yours |
| E4 | "What would you need from us in your first month, and what could you do for us?" | JD | [generic] | Reciprocity: give both halves. What you need is yours to name as a plan; what you offer should be a plan too, not a claim about your past. No claim about the staff engineers' work is made | The standard peer reciprocity probe |

### F. Data-Driven Prober (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "What was the 60% a drop in, and how was on-call burden measured?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer slot: what was measured, how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, in your own words. If you do not know the measure, say so plainly. Hold only the quote's reading: the drop came after the push | F3; the second interviewer to probe the same figure, so the answer must repeat |
| F2 | "How did you calibrate interviewers across the loop?" | EXP | [grounded] "I run our hiring loop for backend roles" | Answer slot: the JD's hiring line makes a probe on how the loop runs likely. If you did calibrate, say how, in your own words; if there was no such step, or it was not yours, say so plainly and describe how you run the loop | F4 is none-gap but the practice behind it is a likely probe |

### G. Values/Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you and a product counterpart wanted different things from the same quarter." | VAL | [inferred] "roadmap pressure" | Selection scaffold, theme from the JD's partner-with-product line: a named stake, a moment you did not fold, an intact relationship at the end. Answer slot: if the roadmap pressure in your reliability quarter came from a product counterpart, tell that story with only the beats the quote states; if not, pick another time, or say so plainly and give how you would handle it | F7 is discovery; the quote does not say who applied the pressure |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and a relationship that survived. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; a product manager scores whether you can hold a line with partners |

### H. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "What drew you to device management for industrial customers?" | JD | [generic] | Your actual reason, in your own words. The material gives none, so none is supplied. If part of the draw is new to you, say so plainly | F2; a casual domain question is scored |
| H2 | "If we asked your engineers what it is like to work for you, what would they say?" | VAL | [grounded] "3 as a team lead of 6" | Answer slot: say only what you have actually heard from them, in your own words; if you have not asked, say so plainly and say how you would find out. Stay inside the quote: you were a team lead of 6 | F5; growth probes arrive in this register |

## Reverse questions, round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "Where do the squads and staff engineers disagree most about priorities, and how does it get settled?" | Tests the seam you were asked about in E1 |
| R2.2 | "What would you want a new engineering manager to leave alone, and what to take off your plate?" | Reciprocity for the staff engineers |
| R2.3 | "How is the roadmap negotiated between product and hardware today, and where does it hurt?" | Targets F6 and F7 and puts the product manager in the conversation |
| R2.4 | "What does a good quarter look like for the squads from the product side?" | Tells you how the product manager scores delivery |
| R2.5 | "How are reliability and on-call work weighed against feature work in planning today?" | Connects to your own priorities without claiming a past |

---

# Round 3 — The following Monday, VP Engineering (30 min)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenarios on leadership and values | High. The recruiter's words, as you relayed them, name this round as values and leadership philosophy, so a values-style round is detected | Map a story only where one of your quoted sentences carries it; otherwise a selection scaffold with the honest branch |
| Case/Strategist | Altitude questions on priorities across hardware and software | Medium. Skip-level prior is strategy-heavy | Clarify, objective, approach, risks; think aloud |
| Pressure | Time-boxed challenge on why you and how much was you | Medium-low. Skip-level prior pairs Pressure with Strategist; 30 minutes favors short answers | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real |

Basis: your own words establish the round; the company's published values were not available, so the VAL questions are themed from the recruiter's description and not from named values.

## Question banks

### I. Values/Behavioral (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "What is your leadership philosophy?" | VAL | [generic] | Selection scaffold: a principle in a sentence, one decision it explains, and what it cost. The material gives no principle, so none is supplied. If your reliability quarter is where your principle shows, tell it with only the beats of your own sentence in I2's Provenance | Theme from the recruiter's description; nothing in the material states a principle |
| I2 | "Tell me about a time you put the team's health ahead of delivery pressure." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on F3, with only the beats the quote states: a reliability quarter, roadmap pressure, you pushed it through, on-call burden dropped 60% after. Answer slot: the JD's own-delivery line makes a probe on what the push involved likely. If something was delayed or dropped for it, say what; if nothing was, say so plainly and tell the quarter as quoted | The leadership theme from the recruiter's words; F3 is the one quoted sentence that carries a story |
| I3 | "What does growing an engineer mean to you?" | JD | [generic] | Answer slot: the JD's growth line makes a probe likely. If you developed an engineer, say who and what you did, in your own words; if there was no such case, or it was not yours, say so plainly, then say what you would do first as a plan | F5 is discovery with no evidence at all |
| I4 | "What is the step up from leading a team to leading two squads, in your own view?" | JD | [grounded] "I've never managed managers" and "3 as a team lead of 6" | If managing through leads is relevant, say plainly: "I've never managed managers." Anchor in the other quote: "Of my 9 years in engineering, 3 were as a team lead of 6." The step up is yours to name as a plan: what you would change in how you spend your time. Do not claim any experience beyond the two quotes | F1 and the stated negative; a VP tests whether you see the step honestly |

### J. Case/Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "A new device generation ships and your services must support old and new at once. How do you decide what the squads do first?" | CASE | [generic] | Clarify what constraint is real, set an objective, list options (support both, sunset one, stage), say who you consult, and name the risks. No claim about your past is made | F6's requirement; an altitude question on hardware and software timelines |
| J2 | "How would you decide how much of two squads' capacity goes to reliability versus new features?" | CASE | [generic] | Structure: what each protects, how you would measure the cost of delay, who decides, how you revisit it. No claim about your past is made | F3's requirement at VP altitude |
| J3 | "Why industrial IoT, and why Larkfield?" | CO | [generic] | Your actual reason, in your own words. Company specifics could not be researched, so none are supplied: do not recite anything about Larkfield that you have not read yourself this week | Honest cost of no research; the upgrade menu says what would change it |

### K. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year"; "I've never managed managers and never owned a hardware-adjacent roadmap" | Hold only the quotes: 9 years in engineering, 3 as a team lead of 6, you run the hiring loop for backend roles with about 40 interviews last year. Concede specifically and once: "I've never managed managers and I have never owned a hardware-adjacent roadmap." Hold through two follow-ups by returning to what you said, never by adding to it. Claim nothing about the internal candidate | Persona stem; the concession is a stated negative, so it has a source |
| K2 | "That reliability result — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold the position the quote carries: you pushed a reliability quarter through, and on-call burden dropped 60% after. Answer slot: if others carried parts of it, say which, in your own words; if it was yours throughout, say what you did, and only if true. Hold through two follow-ups by returning to the quote, then concede uncertainty specifically, such as how the 60% was counted if you do not know | Persona stem; F3 is the figure most likely to be attribution-tested |

## Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What does leadership look like when it is working here, in the managers you have seen thrive?" | Goes straight to the philosophy topic and gives you their definition |
| R3.2 | "What would you most want a new manager to have learned by the end of the first quarter?" | Gives you a target and shows you plan to be held to one |
| R3.3 | "Where is the sharpest tension between hardware and software timelines, and what do you expect of managers there?" | Shows altitude and addresses F6 openly |
| R3.4 | "How do you develop managers for the step from leading a team to leading squads?" | Addresses your stated gap without apologizing |
| R3.5 | "Which decisions do you want to make yourself, and which do you want managers to own?" | Learns the VP's operating style |

---

## Prohibited claims (shared)

Built before the banks. These are not coached anywhere in the pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads, or managed 11 engineers | Inflated form of F1 | F1's quote at its own scope: a team lead of 6. The limit is the pack's observation: the material says a team of 6, not two squads |
| Managed managers, or led leads | Negative you stated, F1's neighbour | The plain acknowledgment you gave: "I've never managed managers." No slot |
| Owned a hardware-adjacent roadmap | Negative you stated, F6 | The plain acknowledgment you gave: "never owned a hardware-adjacent roadmap", said as "I have never owned a hardware-adjacent roadmap." No slot |
| Cut on-call burden by 60%, or caused the drop | Inflated form of F3 | F3's quote at its own scope: the drop came after the push. The limit is the pack's observation: the quote orders the events and does not say the push caused it |
| Hired 40 engineers, or made the hiring decisions | Inflated form of F4 | F4's quote at its own scope: you run the loop and the figure counts interviews. The limit is the pack's observation: the quote says interviews, not hires |

## Sources

Provided documents: your message (the role description, the three rounds and their lengths, your background). No dossier was present.

Research was attempted and refused. Searches sent:

- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Search refused. Would have moved: a values cheat sheet for Monday's round (section dropped) and named-value VAL questions |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Search refused. Would have corroborated the loop; persona weights rest on your own description of the three rounds, which establishes the loop without it |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Search refused. Would have moved the CO and CASE banks off generic; J3 and the CASE questions are labeled generic |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names were given, so there was no query to form; no interviewer read, and the reverse questions are role-generic |
| 5. representative `Engineering Manager` JD | skipped | The role description you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full JD text → F1 to F7 currently rest on your one-paragraph role description; the full text would add requirements I have no question for and turn more rows `[grounded]`
- Your CV → more of your sentences to story-map; today only four sentences carry any question, so many guidance cells are scaffolds
- The artifact that would raise F3 and F4 from medium → the on-call or incident report behind the 60%, and the hiring loop's interview schedule or scorecard behind the 40
- Your answers to the answer slots on F2, F3, F5 and F7 → those rows and the questions drawing on them (D2, E3, H2, I3, G1) become story-mapped instead of scaffolds
- Interviewer names for all three rounds → an interviewer read, persona weights from public footprint, and a reverse question tied to each person's path
- The recruiter's focus areas for rounds 2 and 3, and any exercise the panel will set → coverage of a pre-declared deliverable, if there is one, and firmer persona weights
- Larkfield's published values page, pasted → a values cheat sheet for Monday
- A deeper research pass, if web search is permitted — up to 6 more searches and 2 more fetches, several more minutes → a strategy-grounded CO and CASE bank and a grounding brief
- A `tuesday-dossier.md` → verified evidence and a named highest-risk objection would replace the inference that A2 is the highest-ROI item
