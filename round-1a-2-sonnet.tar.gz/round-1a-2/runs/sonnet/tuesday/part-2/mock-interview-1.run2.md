I've read the playbook and loaded the search tool. Now I'm running three searches: Northwind Data's values, its interview process, and Dan's public footprint. Then I'll build the pack.
Priya's prep pack is saved as `Northwind-Data_senior-gtm-strategy-lead_interview_pack.md` in your working directory. It has 22 questions across seven personas, a fit snapshot, a prohibited-claims list and six reverse questions. I built it for a peer round, since Dan is a peer to the role, with Dan's "relentlessly data-driven" line and pricing background weighted in. Weights come from the peer prior plus that signal, so they are my judgment, not Northwind's documented loop.

Web research was refused, so I ran no searches. Company values, loop structure and anything on Dan's public footprint are not established. The values questions are generic, there's no values cheat sheet, and the interviewer read rests on your profile summary alone. The Sources section logs the three refused searches.

- **Highest-ROI prep:** question C1, "Which part of this JD would you be weakest at on day one?". The material states "No classic sales-ops or quota-setting experience." The pack coaches Priya to say that plainly, then lead with the adjacent evidence at its own scope. It keeps her annual volume targets from being relabeled as quotas.
- **Number to be ready for:** the ~$400M ARR figure gets four questions (A1, A2, A3, G2) because Dan will likely walk it to its assumptions. Where the pack doesn't have the specifics (how it was counted, what it's sensitive to, which part was hers), it leaves an answer slot for Priya to fill in her own words. It does not supply them.
- **Evidence quotes:** the fit snapshot quotes only your message, tagged as the coach's notes. Her CV text would let those quotes come from her own written sentences.

I'm offering these, none pushed:
- Run a live drill, as the Skeptic on C1 or as Dan on the ARR questions.
- Save a `tuesday-dossier.md` recording the gaps this prep exposed.
- Convert the pack to Word.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind-Data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy, a peer who reports to the same VP as the role
**Round:** one 60-minute conversation with Dan
**Built on this assumption:** the round is peer-led and conversational, with no pre-declared deliverable. The material is JD highlights, a summary of Priya's background, a profile summary of Dan, and your research note. Web research was refused, so company values and loop structure are not established (see Sources).

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Where a cell says "answer slot", it is an instruction for the interview, and Priya fills it from her own experience or says plainly that the practice was not hers. Question IDs skip the letter F so they never collide with fit-row IDs such as F1.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether claims about her experience survive scrutiny, including attribution |
| JD | Whether she can do the listed job, gaps included |
| CO | Company and strategy knowledge, and thinking at the company's altitude |
| CASE | Structure and reasoning on a live problem from the role |

## Fit snapshot

Evidence cells are verbatim from the coach's notes. Requirement quotes are verbatim from the JD highlights in your message. No gate (a term such as location, pay, travel or authorization) appears in the highlights, so there are no gate rows.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | The material says product strategy and ops, not go-to-market, and the words stay there: "I spent nine years in product strategy and ops at a large consumer-tech company." Answer slot: the JD's own-GTM line makes a probe on go-to-market work likely. If any of your work was go-to-market, say which and what part was yours, in your own words; if none was, or it was not yours, say so plainly and stay with product strategy and ops |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [inferred] | discovery | The quote touches growth from a product surface and does not show which lifecycle stage it served; reading it as relevant to whitespace is this pack's derivation. Answer slot: the JD's land/adopt/expand/renew line makes a probe on which stage the change served likely. If it served one, say which, in your own words; if it did not map to any stage, say so plainly and stay with the change you proposed |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | presentation | The quote names both tools and does not describe an analysis, so the words stay at the skill: "I'm skilled in SQL and Tableau." A skills line has nothing inspected behind it, so expect a probe on it |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The material says a model used in negotiations, not the design of a partner motion, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's partner-motion line makes a probe on the motion itself likely. If any part of how the partner relationship was structured was yours to design, say what, in your own words; if none was, or it was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you set annual volume targets, with cross-org consensus |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | The quote says use, and the words stay at use: "I use AI tools daily." Nothing in the material says she built an AI product or feature |
| F7 | Sales-operations or quota-setting fluency, the territory adjacent to a sales-strategy peer. Role-family expectation, not in the JD highlights | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and the coach's notes state it. Words: "I haven't had classic sales-ops or quota-setting experience." Then how she would learn it, said as a plan and never as a past. The pack observes that the annual volume targets in F5 are what the material shows, and the notes do not call them quota-setting, so the words stay at volume targets |

## Reading the interviewer

Source for every row below is the profile summary in your message. Nothing here comes from a search.

| Observation | Provenance | What it means for the conversation |
|---|---|---|
| Dan Kovac, Director of Sales Strategy, peer to the role under the same VP | [grounded] your message | Expect partnership-fit questions: the seam between his team and hers, and what she adds to his load |
| Self-describes as "relentlessly data-driven" | [grounded] your message | Every number she cites will be walked to its assumptions (bank A). Say plainly where she does not know how a figure was counted |
| Career spine is pricing and monetization roles | [grounded] your message | Case answers land best in pricing, packaging and unit-economics terms (D2, D3). Her partner-level revenue model in F4 is the nearest shared vocabulary |
| One early-stage-startup chapter | [grounded] your message | Builder stories tend to land with him. Expect a probe on large-company pace (C3). No shared jump with her path is established, so none is offered |

Mirror opportunity: Dan's public path runs through pricing and monetization, and F4's quote is "built a partner-level revenue model used in carrier negotiations". It is a shared professional vocabulary, not a shared jump. Raise it in her own words and only at that scope.

## Persona weights and table

Weights follow the peer-relationship prior (Peer Evaluator plus Data-Driven Prober). Dan's "relentlessly data-driven" self-description moves the Prober up, and his pricing spine tilts the case questions. The loop adds nothing: your note establishes one 60-minute conversation with Dan, so there is no loop beyond it. No values-style round is detected.

| Persona | How it shows up with Dan | Likelihood and reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|
| A: Data-Driven Prober (5 questions) | Walks each figure to its inputs and assumptions | Highest. Peer prior plus his own "relentlessly data-driven" line | Know what you can and cannot say about how each figure was counted, and say plainly what you do not know. Name the weakest assumption you know of before he does |
| B: Peer Evaluator (5) | Seam-splitting, "what would you need from me", credit-sharing | Highest. He is a peer pricing what the hire costs his own work | Reciprocity framing. Propose seam principles and ask where he sees the line |
| C: Skeptic (3) | Quiet probing of GTM, partner-motion and sales-ops gaps | Mid. Both gaps sit in or beside his remit | Rehearse the one predictable objection until it is boring. Calibrated candor over bluffing a competency he may own |
| D: Case/Strategist (3) | A live problem on the new lines, tilted to pricing and packaging | Mid. Pricing spine and a role that owns two launches | Clarify, objective, segmentation, approach, metrics, risks. Think aloud, challenge one premise |
| E: Conversational (2) | Friendly opener and a casual question about AI | Low-mid. Casual questions are still scored | A 90-second arc for the biography question. Treat the AI question as scored |
| G: Pressure (2) | Time-boxed "why you" and attribution challenges | Low. Peers rarely run it, but the gaps invite it | Pause, restate, hold a challenged position through two follow-ups, concede specifically |
| H: Values/Behavioral (2) | Scenario prompts from standard stems | Low. No values round is detected and no published values were read | Selection scaffolds ending in the honest branch |

## Question banks

### A: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say what the quote says, in your own words: you proposed the change, and the uplift was credited to it. Answer slots: how the figure was counted, who credited it, and what it is sensitive to. If you know, say so; if you do not, say plainly you do not know how it was counted, and what you would want to find out | F2 holds the only headline figure, so it is the likeliest target for a self-described data-driven peer. EXP because it tests how the number survives scrutiny |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The weakest-assumption move: name, in your own words, the assumption you know of that you would defend least, before he does. The pack does not name one for you. If none is known to you, say plainly that you do not know the assumptions behind the figure | F2's figure needs the weakest-assumption move. The name stays the candidate's, because a supplied assumption cannot be repeated under a second question |
| A3 | "What part of that change was actually yours?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The hold is the quote's own verb: "I proposed it." Answer slot: if any further step was yours, say which, in your own words; if none was, or it was not yours, say so plainly and return to the proposal | Attribution is where a big credited figure gets tested, and F2 is the only row that carries one. EXP because it scores precision about her own share |
| A4 | "Walk me through the partner-level revenue model you built." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats the quote states: you built it, it was partner-level, it was used in carrier negotiations. Tell them in your own words. Answer slot: expect a probe on how the model's inputs and outputs were checked. If checking was part of your work, say how; if there was no such step, or it was not yours, say so plainly and stay with the model | F4 is her one artifact an analytical peer can walk through line by line. EXP because the model's credibility is the question; JD secondarily because the requirement is partner-motion design |
| A5 | "Tell me about an analysis you ran yourself in SQL or Tableau." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold: pick an analysis where you wrote the query or built the view yourself, name the decision it fed, and be able to say what the data could not tell you. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "skilled in SQL/Tableau", or how you would approach a whitespace analysis in those tools. If you have one you can walk end to end, offer to | F3 is the JD's independent-analysis requirement, and a skills line draws a live probe. JD because the JD lists the tools, with a prober's delivery |

### B: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Offer seam principles in your own words (who owns the decision, who owns the input), then ask where he sees the line today. Do not pretend to know it. Anchor on the quote: you set annual volume targets, with cross-org consensus. Answer slot: if reaching consensus involved real disagreement, describe it and your part in it; if there was none, or it was not yours, say so plainly and stay with the targets | F5 is the cross-functional influence evidence, and a peer tests it as disagreement style. JD because the requirement is influence, with a peer's delivery |
| B2 | "What would you need from my team in your first ninety days?" | JD | [grounded] "set annual volume targets with cross-org consensus"; "built a partner-level revenue model used in carrier negotiations" | Reciprocity first: what you bring, in the quotes' terms, a partner-level revenue model and annual volume targets set with cross-org consensus. Then the needs, stated as needs and not as past: access to how his team defines and tracks stages, and the data behind them | Dan prices what the hire costs him, so the answer must show contribution as well as need. F4 and F5 supply the only quotable contributions. JD because it scores the role's cross-functional requirement |
| B3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Use the quote's own verb: you proposed the change, and the credit was for the change. Answer slot: if other teams built or shipped parts of it, name them; if the work did not span teams, say so plainly and answer in principle | The credit probe is the peer's version of the attribution check in A3. EXP because it tests candor about shared work |
| B4 | "Where does GTM strategy for new products end and sales strategy begin?" | JD | [grounded] "No classic sales-ops or quota-setting experience." | Open with the plain acknowledgment the notes support: "I haven't had classic sales-ops or quota-setting experience." Then ask where his team's process sits and offer a principle for the seam. The plan to learn it is stated as a plan: first weeks spent on how his team sets and reviews targets | F7 is the gap closest to his function, so the seam question carries it. JD because it scores whether she can partner with the function she has not worked in |
| B5 | "Tell me about a time a peer's data changed your mind on a plan." | VAL | [generic] | Selection scaffold: pick a time where the peer's data, not their seniority, moved you, you can say what changed in the plan, and the relationship was intact after. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | His data-driven self-description and the peer stem on disagreement raise it. VAL because it scores behavior toward an equal, and generic because no quote carries a story |

### C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus"; "built a partner-level revenue model used in carrier negotiations" | **Highest-ROI prep in this pack.** Say the plain acknowledgment first: "I haven't had classic sales-ops or quota-setting experience." Then the adjacent quotes at their own scope: you set annual volume targets with cross-org consensus, and built a partner-level revenue model used in carrier negotiations. Then a plan stated as a plan. Level 1 follow-up: "so you cannot do this job?" Hold by returning to the two quotes. Level 2: "volume targets are not quotas." Concede that plainly, since the notes say the same. The limit to name before it is asked: your material does not show quota-setting | F7 and F4 are the two largest gaps, and both sit in or beside his remit, so this objection arrives in some form. JD because it scores honest self-assessment against the listed job |
| C2 | "The JD calls partner-motion design experience required. What have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say what the quote says, in those words. Answer slot: if any part of how the partner relationship was structured was yours to design, say what; if none was, or it was not yours, say so plainly and stay with the model. Hold through two follow-ups by returning to the model, never by adding to it | F4 is the only evidence for a hard requirement, and the quote reaches it only partly. JD because the question is the listed requirement |
| C3 | "You spent nine years at a large consumer-tech company. Why leave, why a B2B data company, why now?" | EXP | [grounded] "then 9 at a large consumer-tech company in product strategy & ops" | The reason is yours alone: give your actual reason in your own words, and do not borrow Northwind's stated priorities as your reason unless they are. Expect a follow-up on large-company pace, so be ready with what you want from a smaller scale | Reason for leaving is a standard probe, and his one early-stage chapter makes the pace probe plausible. EXP because it tests the story's consistency |

### D: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Northwind is launching two new product lines. What do you need to know first before you sketch a GTM plan?" | JD | [grounded] "own GTM strategy for two new product lines" — JD highlights | Clarify before structuring: what each line is for, who buys it, where it sits against the existing base. Then objective, segmentation, approach, metrics, risks. Challenge one premise respectfully. The question asks about no past, so the guidance makes no claim | F1's requirement tested live. JD for the requirement, CASE for the delivery |
| D2 | "Larger platform vendors are bundling a competing capability into their suites. How does that change land and expand for a new line?" | CASE | [grounded] the research note: bundling by a much larger platform vendor is the main competitive threat | Structure it: where the bundle competes, which buyers it moves, what standalone value must survive. Use his native terms, price, packaging and unit economics, as questions to ask and not as claims about Northwind's pricing. State one premise you would test | The research note names the bundling threat, and his pricing spine makes packaging the natural angle. CASE because it is a live problem on the company's own strategy |
| D3 | "Compass is an AI copilot launching into your base. How would you size the whitespace for it?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" — JD highlights; the research note: an AI copilot launch ('Compass') | Clarify which base and which stage first: land, adopt, expand or renew. Then segment, size, name the data you would pull and the metric that tells you it is working. No claim about Northwind's numbers, and no past claim | F2's requirement tested live against a stated company priority. JD for the whitespace requirement, CASE for the delivery |

### E: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with the beats the quote states: two years of strategy consulting, then nine years in product strategy and ops at a large consumer-tech company. Close on why this role, in your own words. Add no beat the quote does not carry | The biography question is the most predictable casual opener and is scored. EXP because it tests whether the story holds together |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Name the tools and what you use them for, in your own words. Answer slot: if you have built something with them, say what; if it is use, not building, say so plainly and stay with use. Tie it to Compass only as curiosity | The JD flags AI as a plus, and casual questions about a JD plus are scored. F6 is the only row it draws on |

### G: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a candidate who has run sales ops?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus"; "No classic sales-ops or quota-setting experience." | Pause and restate. Lead with the two quotes at their scope, then concede plainly: "I haven't had classic sales-ops or quota-setting experience." Hold the position through two follow-ups by returning to the quotes, and never fold on them just to restore harmony | F7 against F4 and F5, delivered under time pressure. JD because it scores the stated fit |
| G2 | "That ARR number: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold on the quote's verb: you proposed the change. Concede specifically what you do not know about how the figure was counted, and never concede the proposal itself. Answer slot as in A3 | The same attribution check as A3, in a pressure register. EXP because it tests holding a true claim under challenge |

### H: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and a relationship still intact. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | Standard persona stem. No published values were read, so no value is named. VAL, generic because no quote carries a story |
| H2 | "When did you put a customer or partner ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the external party's interest cost an internal number, and you can say what the number was and what you chose. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | Standard persona stem, with a partner-heavy role in mind. VAL, generic because no quote carries a story |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| "own GTM strategy for two new product lines" | D1, D2 |
| "identify whitespace across land/adopt/expand/renew" | D3, A1 |
| "run independent analysis in SQL and Tableau" | A5 |
| "partner-motion design experience required" | C2, A4 |
| "strong cross-functional influence" | B1, B2, B4 |
| "AI experience a plus" | E2, D3 |
| Sales-operations or quota-setting fluency (F7, role-family) | C1, B4, G1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You have worked on pricing and monetization and had an early-stage chapter. How did that shape how you think about sales strategy for products that are new?" | Ties to his own path, so it turns an interview into a peer conversation and shows she researched him |
| R2 | "What could a new person on my side do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it shows she is thinking about his load |
| R3 | "Where is the line between GTM strategy for the new lines and sales strategy today, and where is it still unsettled?" | Puts the seam from B1 and B4 on the table in her words and invites him to define it |
| R4 | "Which of the two lines has the clearer path to land, and which is more of a whitespace question?" | Shows she has read the role as two distinct problems |
| R5 | "How is bundling by larger platform vendors showing up in the deals you see?" | Draws on the research note's competitive threat and asks a data-driven person for data |
| R6 | "What would success in this role look like at six months, in numbers you would look at?" | Matches his self-described style and gives her something concrete to ask later |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or led GTM strategy | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says product strategy and ops, not go-to-market. D1 asks no past, and F1's slot stays inside the quote |
| Designed partner motions or programs | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says a model used in negotiations, not the design of a motion. C2's slot stays inside the model |
| Has set sales quotas or has quota-setting experience | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I haven't had classic sales-ops or quota-setting experience." No slot. The annual volume targets are not relabeled as quotas |
| Drove, owned or delivered the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: she proposed the change, and the uplift was credited to it. A3 and G2 keep the hold on "proposed" |
| Built or shipped AI products | Inflated form of F6 | F6's quote at its own scope: "I use AI tools daily." E2's slot allows the honest branch that it is use |

## Sources

Provided documents: JD highlights, a background summary of Priya, a profile summary of Dan, and a research note listing Northwind Data's three priorities (enterprise expansion, the Compass AI copilot launch, reaching profitability) and its main competitive threat (bundling by a much larger platform vendor). All four came in your message. No dossier was present.

Searches sent, all refused:
- "Northwind Data B2B data infrastructure company values principles": refused
- "Northwind Data interview process strategy GTM role": refused
- "Dan Kovac Northwind Data Director of Sales Strategy": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The search was refused. It would have named the published values for VAL themes and a values cheat sheet, so bank H is generic |
| 2. `Northwind Data interview process GTM strategy` | unavailable | The search was refused. It would have checked the loop; persona weights rest on the peer prior and your note that this is one 60-minute conversation |
| 3. `Northwind Data strategy` / recent news | skipped | Could not have moved the CO and CASE banks: your research note already supplies the priorities and the competitive threat they use |
| 4. `Dan Kovac Northwind Data` | unavailable | The search was refused. It would have added public talks or writing to the interviewer read, which rests on your profile summary alone |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full JD text → the six quoted requirements become exact JD lines, any mid-list items missing from your highlights get questions, and any gate terms (location, travel, pay) appear as rows
- Priya's CV text → each fit-row quote can come from her own written sentences, and the defend-the-number rows can name what the CV actually says
- Priya's answers to the slots in F1, F2, F4, A1 and A3 → those rows move from slots to story-mapped guidance, with her words quoted in
- Permission to search the web → the published values, the loop structure and Dan's public talks or writing, and a values cheat sheet if a values round is documented
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, needs search permission) → a strategy brief to ground bank D in more than the research note
- The recruiter's guidance on focus areas or any pre-declared deliverable → coverage beyond the peer-round assumption
- Prep time available → a prioritized schedule sized to it
- A `tuesday-dossier.md` from an earlier role assessment → verified evidence, an underwriter-named top objection, and absolute prohibited claims in place of the locally built list
