Web search was refused, so I'm building the pack from what you've told me. Nothing in it will be Stripe-specific. Next I'm saving the pack file.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/tuesday/part-2/rooms/case-3-denied-62faec98/stripe_product-operations-manager_interview_pack.md`.

I built it for a final round with an unknown schedule and unknown interviewers, so the persona weights are a blended pattern, not Stripe's documented process. You gave me no job description or CV, so the fit snapshot is a worksheet and all 22 questions are labeled `[generic]`. All four of my web searches were refused. Nothing in the pack states a fact about Stripe's values, interview loop or strategy.

Say the word and I'll run a live drill as the Skeptic on B1, "Which part of a Product Operations Manager role would you be weakest at on day one?" It's the pack's highest-ROI question.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who is each session in your final round with (manager, peer, skip-level, cross-functional or recruiter), and did the recruiter name any focus areas, a deliverable, or interviewer names? The answer reweights every question bank.

Can you paste the job description and your CV, or say skip and I'll stay with the worksheet? With both, the fit snapshot holds your own quoted evidence.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

**Round:** final round. **Interviewer(s):** not given. **Relationship:** not given.

**Built on this assumption:** a final round of unknown schedule, with an unknown relationship to each interviewer, so persona weights are a blend of round-type patterns and not Stripe's documented process. No job description and no CV were supplied, so the fit snapshot is a worksheet and every question is `[generic]`. The searches this pack tried were refused (see Sources), so nothing here states a fact about Stripe's values, loop or strategy.

## How to use this pack

- **Personas** are how a question is asked: who is asking and in what style. **Types** are what is being scored.
- Type key: **VAL** is behavior against values, **EXP** is whether your experience survives scrutiny, **JD** is the role's stated work, **CO** is company and strategy homework, **CASE** is a live problem.
- Guidance is scaffolding, not a script. None of it says anything about your past, because no material about your past was given: where a question asks about your experience, the guidance helps you choose an instance from your own work and ends with an honest branch for when none comes to mind.
- Question IDs run by persona (A1, A2, B1 and so on) so you can ask for a drill on any of them.

## Fit snapshot

No JD was supplied, so the requirements are role-family patterns written as plain prose, not quotations. No evidence was supplied either, so each row is a worksheet row: the bridge column says what strong evidence looks like, then how to choose a story from your own work.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate launches or programs across product, engineering and go-to-market teams — role-family pattern, no JD | none given | none | [generic] | discovery | Strong evidence is one launch or program that needed several teams to move together, told in your own words with the part that was yours named. Selection scaffold: pick one instance from your own work with a named stake and a named contribution; if no such instance comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it |
| F2 | Design and run an operating cadence or process that teams actually use — role-family pattern, no JD | none given | none | [generic] | discovery | Strong evidence is a recurring process you set up or changed, and what changed for the people using it. Selection scaffold: pick one process from your own work and say what it was for and who used it; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would start |
| F3 | Measure and report product health so decisions improve — role-family pattern, no JD | none given | none | [generic] | discovery | Strong evidence is a figure you produced or tracked, with how it was counted and the assumption you would defend least. Selection scaffold: pick one figure from your own work; if none comes to mind, say so plainly, then say how you would decide what a product leader needs to see |
| F4 | Influence and resolve disagreement without formal authority — role-family pattern, no JD | none given | none | [generic] | discovery | Strong evidence is a disagreement with a peer or leader and how it ended, with your part separated from the team's. Selection scaffold: pick one instance with a named disagreement and a named outcome; if none comes to mind, say so plainly, then say how you would handle one |
| F5 | A clear, honest reason for choosing product operations over adjacent roles — role-family pattern, no JD | none given | none | [generic] | discovery | Strong evidence is your own reason, stated in a few sentences without disparaging a past role. Selection scaffold: say what you do day to day that you would choose again; if you can only say what you want to move away from, say that plainly and add what you want to move toward |

## Persona table

The weights rest on a pattern, not on Stripe's documented loop. They blend the round-type priors for a hiring manager, a peer, a skip-level or executive, and a cross-functional or values round, because a final round can contain any of them. This is noticeably weaker than a pack built on knowing who you meet; your answer to who each session is with reweights every bank.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist (5 questions) | Live problems from the role: plan this, diagnose that | High. It leads the hiring-manager and skip-level priors, two of the four blended rows | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Skeptic (4 questions) | Quiet probing of gaps and of why leave, why here, why now | High. It leads the hiring-manager prior and rides the recruiter prior | Rehearse the most predictable objection until it is boring; calibrated candor over bluffing |
| C. Peer Evaluator (3 questions) | Seam-splitting between teams, what you would need, credit | Medium. It leads the peer prior only | Reciprocity framing; propose seam principles, not a fake seam; show spine and tact together |
| D. Values/Behavioral (3 questions) | Scenario probes, STAR-shaped stories | Medium. It leads the cross-functional prior only. The company's published values were not in hand, so these are not tied to them | Choose stories where the hard truth landed; if your material shows none, say so rather than supplying the ending |
| E. Data-Driven Prober (3 questions) | Inputs, denominators, assumptions, two levels deep | Medium. It rides the peer prior and fits the role's reporting work | Know what you can and cannot say about how a number was counted; name the weakest assumption first |
| F. Pressure (2 questions) | Interruptions, time boxes, motives | Low. It rides the skip-level prior as the second persona | Pause, restate, hold through two follow-ups, concede specifically, never fold on the core |
| G. Conversational (2 questions) | Friendly, unstructured, still scored | Low. It rides the cross-functional prior as the second persona | A 90-second arc for the biography question; treat casual questions as scored |

## Question banks

Every guidance cell below makes no claim about your past. Where a question asks about your experience, the guidance is a selection scaffold ending in an honest branch.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two product teams are launching in the same quarter and both need the same launch-support resources. What do you need to know first, and how do you decide?" | CASE | [generic] | Clarify before structuring: what is fixed, what is actually constrained, who owns the call. Then criteria you would say aloud: customer commitments, readiness, dependencies, reversibility. Say whether you decide or recommend, and how each team hears the outcome. Challenge one premise politely, such as whether the constraint is real or a planning artifact | A live problem built from F1's requirement. CASE because it scores structure, not a remembered story |
| A2 | "A key product metric dropped twenty percent week over week. Diagnose it." | CASE | [generic] | Start with the definition and the instrumentation before any product cause. Then segment, line the drop up against releases and calendar effects, and say what you would check in what order. End with the decision the diagnosis feeds and the weakest assumption in your own approach | Built from F3's requirement and the Case persona's stock stem. CASE because the structure is scored, not the answer |
| A3 | "You're asked to set up how launches are tracked and reviewed across several teams from scratch. Sketch the first thirty days." | CASE | [generic] | Listen before designing: what is broken and who feels it. Pick one recent launch to learn from, propose the lightest cadence that would work, and say how you would know it is working and when you would drop it. Do not impose a process before you have heard the teams | Built from F2's requirement. CASE because it tests clarify-then-structure on an open build |
| A4 | "Why this role at this company, and what would you want to learn about its current priorities before you started?" | CO | [generic] | Say only what you have read yourself, naming where you read it, and do not recite it from memory. If you have not yet read their own material, say so plainly and say what you would look for first. The pack cannot tell you what is current, which is the honest cost of the research that did not run | The company-homework slot. It stays `[generic]` because no Stripe research ran; it becomes specific once you add Stripe's own pages |
| A5 | "In a product operations role, where do you draw the line between helping a team and doing its work for it?" | JD | [generic] | A principle you can defend: the team keeps the decision, operations owns the system around it. Offer a test, such as whether the team's outcome would suffer if you stopped. Concede that the line moves with a team's maturity. The question asks nothing about your past, so the guidance makes no claim | Built from F4's requirement. JD because it scores how the role's boundary is held |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of a Product Operations Manager role would you be weakest at on day one?" | JD | [generic] | Name it in your first sentence, then what you would do in your first ninety days to close it, with two concrete first actions. Expect two follow-ups, such as how you would know it is closing and what you would do if it took longer: hold the answer, concede the real limit, never swap in a weakness that is a strength in disguise. Choose it from rows F1 to F5, the one you honestly know is thinnest. If none comes to mind, say so plainly, then name what you would most want a colleague's help with in month one | The highest-ROI prep in this pack. The pack cannot find your likeliest objection without your background, so B1 stands in for it: every row of the snapshot is a discovery row, so this is the one answer only you can choose. JD because it scores honesty against the role's stated work |
| B2 | "Why are you looking to leave your current role, why this one, and why now?" | EXP | [generic] | Three short answers in your own words. Say what pulls you toward the role before what pushes you from the last one, and do not disparage anyone. If part of the reason is a push, say that plainly and keep it brief | Motivation consistency is what the Skeptic scores; F5's requirement. EXP because it tests whether your story holds under cross-examination |
| B3 | "Why product operations rather than product management or program management?" | JD | [generic] | Your own reason, built from the work you would choose to do again. Name what you would give up by not choosing the other roles. Do not claim a history of the work; if the clearest answer is about what you want to learn, say that | Built from F5's requirement. JD because it scores fit for the role as stated |
| B4 | "Suppose three months in you think the role is scoped differently than you expected. What do you do?" | JD | [generic] | A sequence you would follow: test whether the gap is real, raise it early with the person who set the scope, bring options and not only the problem, agree what changes. Concede that you may be the one who misread it. No claim about your past | A forward-looking probe from the Skeptic's why-here, why-now theme, F5. JD because it scores judgement about the role's scope |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where's the seam between us, and what happens when we disagree?" | JD | [generic] | Offer seam principles and not a fake seam: who owns the decision, who owns the system, what each team needs from the other. Ask what their team needs first. For disagreement, say how you would agree the decision and its owner, what would justify escalating, and what you would write down | F4's requirement. JD because it scores how the role meets its neighbours |
| C2 | "How do you handle credit when work spans teams?" | VAL | [generic] | A principle plus an honest instance: use we for context and I for your contribution. If an instance from your own material comes to mind, tell it in those terms; if none does, say so plainly, then say how you would handle it | The Peer Evaluator's stock probe on F4. VAL because it scores behavior toward colleagues, though no published value is in hand |
| C3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Answer both halves. What you need: context, access, and an honest picture of what is not working. What you give: a specific thing your team can use in the first month. No claim about your past | The reciprocity question the Peer Evaluator uses. JD because it scores partnership fit |

### D. Values/Behavioral

Stripe's published values were not in hand, so these are generic behavioral questions and not mapped to the company's principles.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick an instance with a named truth, a named audience and a named outcome; say what you said and how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Values persona's stock stem on F4. VAL because it scores behavior, not a recalled slogan |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick an instance with a named customer need, a named metric and what it cost. Use I for what you did and we for context. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide | The Values persona's second stock stem, on F3 and F4. VAL for the same reason |
| D3 | "When speed and thoroughness pull in different directions on a launch, how do you decide?" | VAL | [generic] | A decision rule you could state aloud: what is reversible, what is customer-facing, what the cost of being late is against the cost of being wrong. Concede where your rule would fail. No claim about your past | Built from F1's requirement. VAL because it scores judgement, though no published value is in hand |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick a number you would put on a resume for work you did. Walk me through how it was counted, and which assumption behind it you would defend least." | EXP | [generic] | Choose a figure that is yours. Four things to be ready to say in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part of it was yours. If you do not know how it was counted, say so plainly. The pack supplies no method, baseline or assumption | The Prober's stock stems, applied to F3. EXP because it tests attribution honesty |
| E2 | "You've introduced a new weekly launch review. After a quarter, how do you decide whether it was worth the teams' time?" | CASE | [generic] | Say what the review was for before you measure it. Mix a leading signal with what participants say, count the review's own cost, and say what result would make you stop it. Name the weakest assumption in your own measure | Built from F2 and F3. CASE because it scores how you measure a process |
| E3 | "A product leader asks you for a one-page weekly view of how their product is doing. What goes on it, and what stays off?" | CASE | [generic] | Ask what decision the page serves and who owns each definition. Keep to a few measures, say what staleness or gaps the page must show, and say what you would leave off and why. Name the weakest assumption in your choice | Built from F3. CASE because it scores structure and restraint |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause and restate the question. Name two things the role needs that your own material genuinely carries, in your own words. Hold through two follow-ups; when you concede, concede something specific, such as what an internal person would know that you do not yet. If your material carries nothing for the role's needs, say so plainly and say how you would build it | The Pressure persona's stock stem. JD because it scores fit under time pressure |
| F2 | "Tell me about a result you were part of. How much of it was actually you?" | EXP | [generic] | Use we for context and I for your contribution, in verbs you actually did. Concede specifically what others did, and do not fold on the core of what was yours. If no result comes to mind, say so plainly, then say how you would split credit on a shared one | The Pressure persona's stock stem on attribution, F4. EXP because it tests the hardest follow-up a CV line gets |

### G. Conversational/Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey. How did you get to where you are?" | EXP | [generic] | A 90-second arc in your real order: where you started, the turns and why you made them, and why this role next. The pack supplies no beats, because it holds none of your history. Rehearse it aloud until it fits | The biography opener the Conversational persona uses, F5. EXP because the arc is the first claim about your experience |
| G2 | "What are you actually exploring these days in how product teams work?" | JD | [generic] | A casual question that is still scored. Pick something you are really curious about right now and say what drew you to it. If nothing comes to mind, say what you have been reading or trying to learn. Never claim tool experience you do not have | The Conversational persona's stock casual probe. JD because it scores genuine interest in the role's field |

### Requirement coverage

| Requirement | Questions covering it |
|---|---|
| F1 Coordinate launches across teams | A1, D3 |
| F2 Design and run an operating cadence | A3, E2 |
| F3 Measure and report product health | A2, E1, E3, D2 |
| F4 Influence and resolve disagreement | A5, C1, C2, C3, D1, D2, F2 |
| F5 Reason for choosing product operations | B2, B3, B4, G1 |

## Reverse questions

| # | Question to ask them | Why it lands |
|---|---|---|
| R1 | "What does a good first ninety days look like for this role, and how would you tell I was on track?" | It asks for the success measure outright, and it lets you check your own B1 answer against theirs |
| R2 | "Which teams does this role work with most, and where is the working relationship strongest and weakest today?" | It shows you are thinking about the seams before you arrive, and the answer tells you where the work is |
| R3 | "What is the one process or cadence you would most like to be better a year from now?" | It points the conversation at a result you could own and gives you a live case to think about |
| R4 | "When product operations and a product team disagree, how does it usually get settled here?" | It is the peer-evaluator's seam question turned around, and the answer is real information about the role's authority |
| R5 | "What would you want a new person on your team to do in their first month that would genuinely help you?" | The reciprocity question for a peer: it signals you think about their load, not only your own start |
| R6 | "What part of this role has changed since it was first scoped?" | It tests whether the scope is stable, and it prepares you for B4 |

## Prohibited claims

Built locally from the fit snapshot. No CV or other material about your past was given, so no inflated form of one of your own sentences exists to list, and this pack coaches no claim about your past at all. The entries below are what the pack will not do.

| Not coached | Basis | Honest form |
|---|---|---|
| Any claim that you did, owned, decided or led something | No material about your past was supplied, so the pack has no sentence of yours to rest it on | Your own words from your own work, chosen through the selection scaffolds, each ending in its honest branch |
| Stating Stripe's values, loop structure or current strategy as fact | Every search for them was refused, and model memory is not a source for them | Say only what you have read on Stripe's own pages and name where you read it; say so plainly if you have not |

## Sources

Provided documents: none. A dossier was not present.

Searches tried, all refused (the host asked for a permission that was not granted):

- "Stripe operating principles values official": refused
- "Stripe interview process product operations manager final round": refused
- "Stripe strategy 2026 news stablecoins agentic commerce annual letter": refused
- "Stripe Product Operations Manager job posting responsibilities requirements": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have fed the values cheat sheet and the VAL bank's links to published values; D1 to D3 stay generic |
| 2. Stripe interview process, product operations | unavailable | Would have set the persona weights from documented rounds; they rest on a blended pattern instead |
| 3. Stripe strategy and recent news | unavailable | Would have grounded A4 and a grounding brief; A4 stays generic |
| 4. Interviewer name and Stripe | n/a | No name was given, so no query could be formed; the interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Would have replaced the five role-family rows with quoted requirements labelled `[inferred]` |

## Upgrade menu

- The job description text → the five `[generic]` rows become `[grounded]` rows quoted from the posting, JD-tagged questions are rewritten against its real list, and any location, work-authorization, schedule or pay term it states becomes a row checked against what you tell me
- Your CV or a few lines about your own work → the evidence column fills with your own quoted sentences, scaffolds become story-mapped guidance, and your real likeliest objection replaces the B1 stand-in
- Who each session is with, and any interviewer names → persona weights change from the blended pattern to your actual round, with a tailored reverse question and an interviewer read
- The final round's session schedule, if it is several sessions → per-session mini-packs, each with its own persona weights
- The recruiter's prep email → coverage of any pre-declared focus area or deliverable, such as a presentation or take-home, with a build section for it
- How much prep time you have → a prioritized schedule sized to it
- Permission to search the web, or Stripe's own values and interview pages pasted → Stripe-specific rows, grounded in its published words; a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief, interviewer talks, loop reports and recent organization context
- A `tuesday-dossier.md` from earlier work → verified evidence and your confirmed gaps carry in, so none of this is rebuilt
