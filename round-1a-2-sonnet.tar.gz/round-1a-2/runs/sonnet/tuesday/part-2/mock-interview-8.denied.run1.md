I'm running a quick format check on the saved pack (stray square brackets and table rows with the wrong number of columns), then I'll hand it over.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a2/runs/sonnet/tuesday/part-2/rooms/case-8-denied-d1e09d6c/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

It covers all three rounds on 29 November. I built it from your background paragraph alone, with no CV text and no interviewer names. I ran no searches, because the JD, values, recruiter email and strategy facts were all already in hand.

- **Most likely objection:** the contact-centre question. D1 is the pack's highest-ROI prep. B1 (recruiter) and K1 (panel, under pressure) are the same objection. You named this gap yourself (F2), so the pack gives you the plain wording for it rather than a bridge.
- **Values stories:** nothing in your paragraph carries a story for any of the four values. The Round 3 cheat sheet is four scaffolds, and finding one real example per value is the biggest job before the panel.
- **Wording to be careful with:** you wrote "spreadsheet", not Excel, and "formal complaints log", not regulated complaints. F7 and F9 hold answer slots for you to fill truthfully.
- **Presenting:** the pack makes no claim that you've presented at regional level, because your paragraph doesn't say you have.

Offers:
- I can play the Skeptic on D1 as a live drill.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- I can convert the pack to a Word document.

Can you paste your CV, or just its complaint-log, spreadsheet and training lines? Those would re-quote F1, F3, F4 and F6 and could close some answer slots.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Prepared:** 20 November 2026. **Mode:** loop, three rounds on 29 November 2026.

| Round | Who | Length | Shape, in the recruiter's words |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Not described further |
| 2 | The Head of Member Services, who would be your manager | 45 minutes | "mostly behavioural" |
| 3 | A panel of two branch managers | 60 minutes | "including a 20-minute case on a complaint escalation. The panel is also the values round — they score against the four values." |

No interviewer names are assigned yet, so there is no interviewer read. This pack was built on your background paragraph as you wrote it: no CV text, and no interviewer names.

## How to use this pack, and the type key

Personas describe how a question is asked. Types describe what is being scored. Every question carries one type tag:

| Tag | What it is really testing |
|---|---|
| VAL | Whether past behaviour shows the company's published values, not generic virtue |
| EXP | Whether the claims about your experience survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you know Ashgrove's strategy and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script. An **answer slot** is a place where only you can say what is true: it gives two honest branches and either is a good answer. The pack never fills a slot for you. A **selection scaffold** is used where none of your sentences carries a story: it tells you what a good story needs and ends with the honest branch if none comes to mind. Provenance labels: `[grounded]` is traceable to what you or Ashgrove supplied, `[inferred]` is derived and the derivation is named, and `[generic]` is a pattern for rehearsal with no claim about you or Ashgrove. All proposed wording in this pack is pending your approval: change anything you cannot stand behind.

## Prep triage

You have nine days (20 to 29 November) and all three rounds fall on one day. I don't know how many hours a day you have, so this is ordered by payoff, not sized to hours.

1. **20 to 21 November: write the true answers to the answer slots in F1, F3, F4, F5, F7 and F9.** Send them back and each becomes quoted material, so the rows and banks regenerate on facts instead of slots.
2. **22 to 24 November: rehearse D1 aloud until it is boring.** It is the highest-ROI prep in the pack, and B1 and K1 are the same objection asked by the recruiter and under pressure.
3. **25 to 27 November: find one real story for each of H1 to H4, or decide you have none and rehearse the honest branch.** The values cheat sheet has no mapped stories, and the panel scores on them.
4. **28 November: run I1, the 20-minute case, timed and aloud.** Take the drill offer for it.
5. **29 November, between rounds: rest.** Do the A1 arc once, lightly.

Everything else is insurance.

## Fit snapshot

Proposed wording below is pending your approval. The requirements are quoted from the job description you pasted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not a process across branches, and nothing is inspected behind it. The words stay at the log: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" makes a probe on what happened to a complaint beyond the log likely. If any step beyond the log was yours, say which and what you did, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then, as a plan and never as a past, what you would learn first and from whom, in your own words. Nothing added to make the gap feel smaller, and no claim to contact-centre work |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your material says you built a monthly spreadsheet your regional manager uses, with nothing inspected behind it; it does not say what the sheet counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: expect a probe on what the sheet counted and how. If you can say what it counted and how it was counted, say so in your own words; if you cannot, or it did not count what they ask about, say so plainly and stay with the sheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers and the escalation script, not supervisors. The words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on how you trained likely. Say how you went about it, in your own words; if part of it was not yours, or there was no particular way you went about it, say so plainly and stay with the tellers and the script |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this requirement. Answer slot: if any of your complaints work touched a digital channel or a digital team, say what, and which part was yours, in your own words; if none did, say so plainly, then say, as a plan, what you would ask a digital team first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap in length, but a line with nothing inspected behind it, so expect it to be checked. Say it in the quote's own terms: "6 years in retail banking, the last 3 as a branch supervisor." "Customer operations" is the employer's phrase; the words about your history stay yours |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | Inferred from the word "formal" sitting beside the JD's "regulated": that link is this pack's derivation, not your statement. Your material says a formal log; it does not say what governed how the log was kept. The words stay at the log: "I handled the branch's formal complaints log." Answer slot: expect a probe on what governed the log and what your part in it was. If you know, say what and what you did, in your own words; if you do not know, or nothing did, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have stated its scope. Words: "I've never presented to anyone above regional level." Then, as a plan and never as a past, how you would prepare a first monthly report for senior leaders and who you would ask to review it, in your own words. Your material does not say what you have presented below that level, so nothing here claims it |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | Inferred from "spreadsheet" beside the JD's "Excel": your material says spreadsheet and does not name the tool. The words stay there: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: expect a probe on the tool. Say what tool you built it in and what you did in it, in your own words; if you are unsure what to call it, say so plainly and stay with the sheet |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own the complaints process end to end across branches and the contact centre | B1, B2, D1, D2, I1, I3, K1 |
| Report monthly on complaint volumes and resolution times | E1, G1, G2, K2 |
| Coach branch supervisors on escalations | C3, J1 |
| Work with digital teams on self-service journeys | E2, I3 |
| 4+ years in financial-services customer operations | A1, K1 |
| Experience handling regulated complaints | B2, C4 |
| Confident presenting to senior leaders | C1, D3, B3 |
| Comfortable with Excel reporting | G1 |

## Grounding brief

The four strategy facts below are as you relayed them from the July 2026 brief the recruiter sent. I did not have the brief itself.

| Fact | Source | Provenance | Reading for your interviews, derived from the fact and the JD |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | 2026 strategy brief, as relayed | [grounded] | Digital self-service is the JD's fourth responsibility (F5), and E2 and I3 draw on it. Ashgrove published the brief, so other candidates can cite the same headline; E2 asks you to bring it once and then depart from it |
| Consolidate eight branches into five hubs over 2027 | 2026 strategy brief, as relayed | [grounded] | I2 draws on it. Two branch managers sit on the Round 3 panel; whether their branches are among those merging is unknown until names are assigned, so the pack assumes nothing about their stake |
| Launch a small-business lending product in Q1 2027 | 2026 strategy brief, as relayed | [grounded] | E3 draws on it: a new product is a possible source of complaint types the process has not seen, which is a question to ask, not a fact to assert |
| Main competitive pressure is app-only banks | 2026 strategy brief, as relayed | [grounded] | Sits behind the digital target; use it as context for E2, not as a claim about members |
| Member-owned, about 900 staff | The JD header you pasted | [grounded] | Context only |

---

## Round 1: the recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured opener and the practical questions: pay, notice, location, reason for the move | High. This pack's starting weight for a recruiter screen, not a fact about Ashgrove; the recruiter described it only as "30 minutes with me" | Have a 90-second arc ready; treat casual questions as scored; answer each logistics question with your own fact |
| Skeptic (light) | Quiet knockout checks on the gaps | Medium. The JD names the contact centre and senior-leader presenting, and you have named both as gaps yourself (F2, F8) | Say the plain acknowledgment first and one forward sentence; do not argue |
| Pressure, Values, Case, Prober, Peer | Not expected in a recruiter screen | Low. Values and cases are signposted for Rounds 2 and 3 | None needed here |

### Question bank

Proposed wording below is pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" "I built the monthly complaints spreadsheet our regional manager uses" "trained new tellers on our escalation script" | A 90-second arc built only from these four sentences, each beat a clause one of them states: six years in retail banking; the last three as a branch supervisor; the branch's formal complaints log; the monthly complaints spreadsheet your regional manager uses; training new tellers on the escalation script. Tell it in your own words and keep each at its own scope. Close with your own reason for wanting this role; the pack supplies none | A casual opener that is still scored. The arc carries the facts of F1, F3, F4 and F6 so none is said for the first time under pressure; EXP because it tests what was actually yours |
| A2 | "What do you know about us, and why Ashgrove?" | CO | [grounded] | Use what Ashgrove has published: the four value names, and the move of 40% of member service to digital by 2028. Bring that one headline to show you read it, then one point of your own, in your own words: which value draws you and why. Do not recite the brief; the pack supplies no reason of yours | CO because it tests homework depth; it asks for no claim about your past. Grounded in the values page and strategy facts you supplied |
| A3 | "What salary are you looking for?" | JD | [generic] | Logistics slot, yours alone: either give your own number as your figure, or ask for the role's band first and then answer. The pack gives no figure and wants no salary history | Recruiter screens ask pay; JD because it concerns the listed job's terms |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, and whether it can shorten if you know. If you are unsure of any of it, say so plainly and say you will confirm | Recruiter screens check notice; JD because it concerns the job's start |
| A5 | "Where are you based, and how would getting to the branches and the contact centre work for you?" | JD | [generic] | Logistics slot: give your actual location and the travel you can do. The JD names branches and the contact centre; if you do not know where the contact centre sits, ask | Location is a knockout check in a screen; JD because the JD's own wording spans sites |
| A6 | "What's prompting you to look at a move?" | EXP | [generic] | Logistics slot: your actual reason, in one or two plain sentences, pointed at what you want from this role rather than at anyone at your current employer. The pack supplies no reason; a short true sentence beats a polished one | Motivation consistency is scored in a screen; EXP because it tests whether your story holds across rounds |
| B1 | "The role covers branches and the contact centre. How do you see your fit with the contact centre side?" | JD | [grounded] "Never worked in a contact centre" | Say the plain acknowledgment first, before they find it: "I've never worked in a contact centre." Then one forward sentence, as a plan, in your own words: what you would learn first and from whom. Stop there; D1 rehearses the longer version | F2 is the stated gap and the JD names the contact centre, so a screen checks it early; JD because it scores a stated requirement |
| B2 | "Tell me about the formal complaints log you handled." | EXP | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1: the log, at its own scope, in your own words: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" makes a probe on what happened beyond the log likely. If any step beyond the log was yours, say which and what you did; if there was no such step, or it was not yours, say so plainly and describe the log you handled | F1 and F7 are the evidence for the complaints requirements and the likeliest first probe; EXP because it tests what was actually yours |
| B3 | "Which part of this job would you find hardest on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" | Pick the one you would honestly say and say it plainly. Your material shows two gaps you named, the contact centre (F2) and presenting above regional level (F8): "I've never worked in a contact centre" or "I've never presented to anyone above regional level." Then your plan for it, in your own words. If something else is honestly harder, say that instead | The Skeptic's standard question; F2 and F8 are where the material is thinnest, so the honest pick is already known |

### Reverse questions for Round 1

| Question | Why it lands |
|---|---|
| "Which parts of the role is the team most keen to see evidence of?" | It tells you which probes arrive in Rounds 2 and 3, and shows you are planning the loop |
| "How does the role divide between the branches and the contact centre: is it one process or two?" | It is exact about your biggest gap and gives you the vocabulary D1 needs |
| "Once the panel is assigned, can you tell me their roles or names?" | A normal practical ask, and the answer unlocks an interviewer read |
| "Is there anything I should know about the 20-minute case beforehand, such as whether it is live or written, and whether I can ask questions during it?" | The case is scored and its format changes how you rehearse |
| "Is there anything in my background you expect the Head of Member Services to probe?" | It surfaces the objection before Round 2 and shows you want it |

---

## Round 2: the Head of Member Services (45 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes, STAR-shaped stories | High. The recruiter calls the round "mostly behavioural" | Use "we" for context and "I" for contribution; where none of your sentences carries a story, use the scaffold's honest branch rather than supply one |
| Skeptic | Probes the gaps: contact centre, ownership, presenting | Medium. This pack's prior for a hiring manager, who is derisking gaps; F2, F8 and F1 are the thinnest rows | Rehearse the single most predictable objection until it is boring |
| Case / Strategist | Live problems from the role: reporting, digital, new product | Medium. The same hiring-manager prior; the JD's reporting and digital lines supply the problems | Clarify, then structure, then answer; think aloud; challenge one premise respectfully |
| Data-Driven Prober | Reads your spreadsheet line by line | Low. Nothing in your paragraph is a headline figure, but the spreadsheet is an artifact they can probe | Know what you can and cannot say about what the sheet counted; say plainly when you do not know |
| Conversational, Pressure, Peer | Opener only; not expected | Low. Nothing signposted | None needed |

### Question bank

Proposed wording below is pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold, since no quoted sentence of yours carries it: pick a time you told someone senior something they did not want to hear. It needs a named stake, what you actually said, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. "We" for context, "I" for what you said | A standard behavioural stem for the manager round the recruiter called "mostly behavioural"; VAL because it scores behaviour, and it is also where the senior-leader line (F8) gets tested |
| C2 | "Tell me about a time you put a member's interest ahead of an internal process or target." | VAL | [grounded] | Selection scaffold, no quoted sentence of yours carries it. The theme is Ashgrove's first value as you pasted it: "we decide from the member's side of the counter". Pick a time you decided from the customer's side and it cost you something with the process or the target: the stake, what you chose, how it ended. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Previews a Round 3 value while the stakes are lower; VAL because it scores a published value, not generic virtue |
| C3 | "Tell me about a time you helped a colleague through a difficult escalation." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: training new tellers on the escalation script is the beat the quote states; tell it in your own words at that scope: "I trained new tellers on our escalation script." Answer slot: if there was a particular escalation you helped someone through, say what happened and what your part was; if there was no such occasion, or it was not yours, say so plainly and stay with the training | The theme comes from the JD's coaching line; F4 is the only evidence near it; VAL because the story shows how you help others |
| C4 | "Tell me about a time a complaint had to be handled strictly by the book rather than by your own judgement." | JD | [grounded] "I handled the branch's formal complaints log" | Selection scaffold ending in the honest branch: pick a complaint where a rule that bound you left you no room; it needs the rule, what you did, and the member's outcome. If no such complaint comes to mind, say so plainly, then give the nearest thing your material does carry, which is the log: "I handled the branch's formal complaints log", or how you would handle it | The theme comes from the JD's regulated-complaints line; F7 is the thin row and a behavioural story is how a manager would probe it; JD because it scores that requirement |
| D1 | "You haven't worked in the contact centre, and this role owns the process across it. How would you handle that?" | JD | [grounded] "Never worked in a contact centre" | The highest-ROI prep in this pack, and the hold is only what the quote carries. Say it first, plainly: "I've never worked in a contact centre." Then the plan, in your own words: what you would learn first, from whom, and what you would leave alone until you had. Follow-up one, "how would you earn that team's trust?": answer with the plan, not with branch experience, which your material does not carry into the contact centre. Follow-up two, "what if you have misjudged how that team works?": say how you would find out and who you would ask. Concede only what you stated, and never claim equivalence between branch work and contact-centre work | F2 is the biggest stated gap and the JD names the contact centre, so this objection arrives in some form in every round; JD because it scores a stated requirement |
| D2 | "The role owns the complaints process end to end. What part of a complaint's journey have you owned yourself?" | JD | [grounded] "I handled the branch's formal complaints log" | The hold is only what the quote carries: "I handled the branch's formal complaints log." Answer slot: if any step beyond the log was yours to run, say which and how you decided; if none was, or it was not yours, say so plainly and describe the log you handled. The honest branch is a limit, not a confession | F1 is where the ownership requirement presses hardest; JD because it scores the stated requirement |
| D3 | "Tell me about a time you had to present something to people more senior than you." | JD | [grounded] "I've never presented to anyone above regional level" | Open prompt, theme from the JD's senior-leaders line. If a time comes to mind, tell it with the audience, what you presented and how it went, in your own words. If none does, say the plain acknowledgment, "I've never presented to anyone above regional level", then your plan for a first monthly report, in your own words: who you would ask to review it, and what you would want them to check | F8 is a stated gap and the manager would be the one you present to; JD because it scores the stated requirement |
| E1 | "Walk us through how you would set up the monthly complaints report for a leadership audience. What do you need to know first?" | CASE | [generic] | Structure it: clarify, objective, segmentation, approach, metrics, risks. Clarifying questions to ask: who reads it and what decision it should inform; what counts as a complaint and when it counts as resolved; where the clock starts and stops, since the JD asks for resolution times. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The JD's reporting line, which F3 maps, set as a live problem; CASE because it scores structure; generic because it is a pattern for the problem |
| E2 | "Ashgrove plans to move 40% of member service to digital channels by 2028. Where do complaints fit in that, and what would you want from the digital team?" | CO | [grounded] | Clarify first: what the 40% counts as member service, and whether complaints are inside it. Bring the headline once to show grounding, then one point of your own that departs from it, with its limit: for example, which kinds of complaint you would not push to self-service first, since part of this role is saying no. Defend only a view you hold, in your own words, and give one concession: digital may fix some things faster. The pack asserts nothing about what members prefer | The JD's digital line, which F5 maps, plus the strategy headline; CO because it tests whether you can think at Ashgrove's altitude |
| E3 | "A small-business lending product launches in Q1 2027. What would you want in place on complaints before it does?" | CO | [grounded] | Say what you would ask rather than assert what will happen: who the product is for, which teams will take its queries, whether it brings complaint types the process has not seen. Then objective, what you would check in the process, and what you would report early. Nothing is known about the product beyond its launch quarter, and the question asks for no claim about your past | Grounded in the strategy facts you supplied; CO because it tests strategy fluency |
| G1 | "Walk me through what that monthly spreadsheet counted, and how." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: expect probes on what it counted, how it was counted, what it was sensitive to, and the assumption behind it you would defend least; answer each in your own words and say plainly where you do not know how something was counted. Also say what tool you built it in and what you did in it; if you are unsure what to call it, say so and stay with the sheet | The JD's reporting and Excel lines meet here (F3, F9); EXP because probers go to the one artifact you built |
| G2 | "How did your regional manager use it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: if you know what your regional manager used it for, say so in your own words; if you do not, or it was not used that way, say so plainly and stay with the fact that you built it | F3 is the evidence and the question tests who the sheet served; EXP because it tests attribution |

### Reverse questions for Round 2

| Question | Why it lands |
|---|---|
| "What would a strong first 90 days in this role look like to you?" | A manager hears you planning the work, and the answer tells you what success is measured by |
| "Where does the complaints lead's remit end and a branch manager's begin?" | It is the seam question, and you hear the manager's answer before the branch managers give theirs in Round 3 |
| "How does this role work with the digital team today?" | F5 is the requirement your material does not show, and the answer gives you the vocabulary |
| "If you could change one thing about how complaints are handled today, what would it be?" | It points at a real problem you could be asked to pick up, which suits a role built around owning the process |
| "After today, what, if anything, would give you pause about me?" | It surfaces the objection live and shows a manager you can hear one calmly |

---

## Round 3: the panel of two branch managers (60 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes scored against each of the four values | High. The recruiter says "The panel is also the values round — they score against the four values." | Show each value through a real decision, not by naming it; where none of your sentences carries a story, use the scaffold's honest branch |
| Case / Strategist | The 20-minute escalation case | High. The recruiter says the round includes "a 20-minute case on a complaint escalation" | Clarify before structuring; think aloud; keep the member's problem held by one person throughout |
| Peer Evaluator | Seam questions: where you end and a branch manager begins | Medium. Derived from the JD's coaching line, which puts this role beside branch supervisors, so branch managers sit on the other side of that seam | Reciprocity first; propose seam principles rather than pretending to know the seam |
| Pressure | Time-boxed or devil's-advocate follow-ups, especially on the case | Low. Nothing signposted says the panel is adversarial; a time-boxed case can still bring interruptions | Pause, restate, hold through two follow-ups before conceding anything real |
| Conversational, Skeptic | Opening warm-up; the gaps arriving in pressure form (K1) | Low. The A1 arc covers the opener | None needed beyond A1 and K1 |

### Question bank

Proposed wording below is pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold, no quoted sentence of yours carries it. The theme is the first value as you pasted it: "Members First, Always". Pick a time you decided from the customer's side when the easier choice was the other side: the stake, what you chose, what it cost, how it ended. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The panel scores each value, so each gets a question; VAL because it scores a published value |
| H2 | "Tell me about a time you had to explain something twice, and what you changed so you did not have to." | VAL | [grounded] | Selection scaffold, no quoted sentence of yours carries it. The theme is the second value as you pasted it: "Plain Words". Pick a time something you said or wrote was not understood the first time and you changed the words: what it was, what you changed, what happened. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Second of four published values; VAL because it scores behaviour against the value |
| H3 | "Tell me about a time the numbers pointed one way and the people in front of you pointed the other." | VAL | [grounded] | Selection scaffold, no quoted sentence of yours carries it. The theme is the third value as you pasted it: "Neighbours, Not Numbers". Pick a time you weighed a figure against the people it affected: the figure, the people, what you decided, how it ended. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Third of four published values, and the one the branch consolidation in the strategy makes most live; VAL because it scores the value |
| H4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] | Selection scaffold, no quoted sentence of yours carries it. The theme is the fourth value as you pasted it: "Own the Fix". Pick a time you found a problem and stayed with it: what it was, what you did to keep hold of it, and how it ended. If you handed it on, say to whom. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Fourth of four published values, and close to the JD's "own the process"; VAL because it scores the value |
| I1 | "A member comes into a branch for the third time about the same unresolved complaint, and says they have been passed between the branch and head office. Walk us through what you would do, and what you would change afterwards." | CASE | [generic] | The declared 20-minute case will differ in detail; this is the shape to rehearse. Clarify first: what the member wants, what has been done, who holds it now, what is time-critical. Objective: the member's problem solved and one person holding it until it is. Approach: who owns it today, what you would say to the member and in what words, what you would hand on and how you would confirm it landed. Then what you would change and what you would report. Show the values inside the answer, not by naming them. Think aloud and challenge one premise respectfully. The question asks for no claim about your past, so the guidance makes none | The recruiter's "20-minute case on a complaint escalation"; CASE because it scores structure and reasoning. Generic because the real case is unseen |
| I2 | "Eight branches are due to consolidate into five hubs over 2027. A member from one of the branches that is merging comes to complain about the change. What do you do with that complaint?" | CASE | [grounded] | Clarify first: whether this is a complaint to resolve or feedback on a decision already taken, and ask what Ashgrove's process says rather than assume. Hear the member out; say plainly what can and cannot change, in plain words; decide where what they tell you goes, and who tells the branch manager. Nothing is asserted about how Ashgrove treats such complaints, and the question asks for no claim about your past | Grounded in the strategy facts you supplied; CASE because it tests reasoning on a live strategic problem, and it sits beside "Neighbours, Not Numbers" |
| I3 | "A member starts reporting a problem in the app, gives up, rings the contact centre, then comes into the branch. Who owns that member's problem, and what do you change?" | CASE | [generic] | Clarify first, then map the journey to find where it was lost, and say who holds the problem at each step. Name what you would ask the digital team and the contact-centre team; where your material is thin on either, say what you would ask and of whom rather than guess how they work. Then what you would measure. The question asks for no claim about your past | Joins the JD's digital and contact-centre lines (F5, F2) with the fourth value's idea of owning a fix; CASE because it scores structure; generic because it is a pattern for the problem |
| J1 | "A supervisor in one of our branches handled a complaint badly. Where is the line between you coaching them and me managing them, and what happens when we disagree?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Propose seam principles, not a pretend seam: ask where they would draw it, then offer how you would work: agree who talks to the supervisor and when, agree what you share back, and name who you would both go to if you disagree. Say the one fact in the quote's own words, the last 3 as a branch supervisor, and let them draw the inference | The JD's coaching line puts the role beside branch managers, so a seam question is likely; F4 is the thin row under it; JD because it scores the stated requirement |
| J2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold, no quoted sentence of yours carries it: pick a time work crossed teams; it needs who did what, how credit was shared, and what it did for the working relationship. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A Peer Evaluator stem; VAL because it scores collaboration behaviour |
| J3 | "What would you need from us in your first month, and what could we expect from you?" | JD | [generic] | Answer both halves in your own words and lead with what branches can expect. Offer principles, such as asking before changing anything and sharing what you learn, rather than pretending to know how their branches run | A reciprocity question from peers; JD because it scores how you would work with them in the role |
| K1 | "Sixty seconds: why you rather than someone who has worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" | Hold-then-concede. Pause and restate the question. Hold on what the quotes carry: "I've never worked in a contact centre. I have 6 years in retail banking, the last 3 as a branch supervisor, and I handled the branch's formal complaints log." Hold through two follow-ups by returning to those facts, never by adding to them. Concede plainly that the contact centre is a gap you would close by learning, and do not claim you are the better fit | F2 is the stated gap and a time-boxed challenge is how a pressure interviewer would press it; JD because it scores a stated requirement |
| K2 | "That monthly spreadsheet: how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Hold the quote: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if anyone else shaped it or set what it counted, say who and what; if no one did, say so plainly. Hold through two follow-ups by returning to the sheet; concede only what you do not know | F3 is the evidence and attribution is what this stem scores; EXP because it tests what was actually yours |

### Values and principles cheat sheet

Ashgrove's four values are as you pasted them from ashgrovecu.org/about/values on 20 November 2026; I did not fetch the page. The panel is the values round, so each value needs a story in your own words. None of your sentences carries a story for any of them, so every row below is a scaffold. Proposed wording is pending your approval.

| Value (official name) | Working meaning, paraphrased | Mapped story, or selection scaffold |
|---|---|---|
| Members First, Always | Decisions start from what the member needs, not from the institution's convenience | No quoted sentence carries a story. Scaffold: a time you decided from the customer's side and it cost something with the process or the target. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | Clarity is the organisation's job, so a member should not need a second explanation | No quoted sentence carries a story. Scaffold: a time something you said or wrote was not understood first time and you changed the words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Neighbours, Not Numbers | A branch is judged as part of its town, not by its figures alone | No quoted sentence carries a story. Scaffold: a time a figure and the people it affected pointed different ways, and what you decided. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds a problem stays with it until it is solved | No quoted sentence carries a story. Scaffold: a time you found a problem and stayed with it, and who you handed it to if you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

### Reverse questions for Round 3

| Question | Why it lands |
|---|---|
| "When branches consolidate into hubs, how would you want a complaint that starts in a merging branch to be handled?" | It ties to the strategy and to "Neighbours, Not Numbers" without presuming anything about their own branches |
| "What would you want a complaints lead to do in their first month that would genuinely help your branch?" | A reciprocity question: it shows you think about what you bring them, not only what you need |
| "Where does a complaint most often get stuck between a branch and the central process?" | It asks for the real friction and shows "Own the Fix" in practice |
| "What would make your supervisors want this role's coaching rather than see it as oversight?" | It names the seam you will work across and invites their honest view |
| "Which of the four values is hardest to live up to in a branch on a busy day?" | It shows you took the values seriously and invites a real story back |

---

## Prohibited claims

What this pack will not coach, and why. Each entry names its basis, and each honest form is the only form the pack uses.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says the branch's log, not a process across branches. B2's and D2's slots stay inside the log |
| Has contact-centre experience | Negative the candidate stated, F2 | The plain acknowledgment F2 gives: "I've never worked in a contact centre." No slot |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: the material says a formal log and does not say what governed it. C4's slot stays inside the log |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: new tellers and the script. The limit is the pack's observation: the material does not say supervisors. C3's slot stays inside the training you gave |
| Reported monthly on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says the sheet, not what it counted. G1's slot asks only what the sheet counted |
| Built the spreadsheet in Excel | Inflated form of F9 | F9's quote at its own scope, which says spreadsheet. G1's slot asks only what you built it in |
| Has presented to anyone above regional level | Negative the candidate stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot |

## Sources

Provided documents: the job description you pasted; Ashgrove's four values as you pasted them from ashgrovecu.org/about/values on 20 November 2026; the recruiter's email about the three rounds; the four strategy facts you relayed from the July 2026 strategy brief (the brief itself was not provided); your background paragraph, with no CV. No `tuesday-dossier.md` was present. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the values cheat sheet or the VAL questions: the pasted values page already supplies all four value names and their wording |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | Could not have moved the persona weights: the recruiter's email already names the three rounds, who runs each, and their length and shape |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | Could not have moved the CO and CASE questions: the four strategy facts from the July 2026 brief are in hand, under six months old on 20 November 2026 |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent and the upgrade menu says what names would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, or just its complaint-log, spreadsheet and training lines → F1, F3, F4 and F6 re-quoted from the CV, and several answer slots may close
- Your own true answers to the answer slots in F1, F3, F4, F5, F7 and F9 → each becomes quoted material, and the rows and the banks that draw on them regenerate on facts
- One real example, in your own words, for each of the four values → the cheat sheet's four scaffolds become mapped stories, and H1 to H4 get story-mapped guidance
- The interviewers' names (Head of Member Services and the two branch managers) → an interviewer read, persona weights tuned per panel member, and a reverse question tied to each one's own path
- The recruiter's detail on the 20-minute case: live or written, any material beforehand, and who sets it → I1 becomes specific, and a pre-declared deliverable would get its own build section
- Hours per day you can prep → the triage is resized to them
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → recent organisation context and interviewer footprint once names exist; it is offered once and runs only if you want it
- A `tuesday-dossier.md` from an earlier check on this role → verified evidence and a named top objection, replacing this pack's inferred ones
