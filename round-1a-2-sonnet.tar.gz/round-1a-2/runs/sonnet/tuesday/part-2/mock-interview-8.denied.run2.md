Your prep pack is built and saved. I'm now writing the message that presents it. I built it as a three-round loop from the recruiter's email. It has 32 questions in total: 8 for round 1, 12 for round 2 and 12 for round 3. I didn't run any searches, because your pasted JD, values, recruiter email and strategy points already cover everything a search would have fed.

The pack is at `/var/tmp/tuesday-measure/1a2/runs/sonnet/tuesday/part-2/rooms/case-8-denied-0326cbc7/ashgrove-credit-union_member-experience-lead_interview_pack.md`. It holds the shared fit snapshot, a persona-weight table, question bank and reverse questions for each round, and the values cheat sheet for the panel round. It also has a requirement-coverage table, a list of claims it won't coach, and the sources and upgrade menu.

Say the word and I'll play the Skeptic on B3, the question the pack names as its highest-ROI prep. It asks why you can own the process end to end across branches and the contact centre, when your material shows your branch's log and no contact-centre work.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Loop:** three rounds on 29 November 2026 — round 1, the recruiter (30 minutes); round 2, the Head of Member Services, who would be your manager (45 minutes, mostly behavioural); round 3, a panel of two branch managers (60 minutes, with a 20-minute case on a complaint escalation, also the values round). Interviewer names are not yet assigned, so there is no interviewer read.

This is a loop-mode pack: one shared fit snapshot, then a mini-pack per round with its own persona weights, question bank and reverse questions.

## How to use this pack

- Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words.
- Type key: VAL, behavioural or values alignment (past behaviour against Ashgrove's published values); EXP, a deep-dive on your own experience; JD, a stated requirement of the role; CO, company and strategy knowledge; CASE, a live problem set in the role.
- A Type cell holds one token. Where a question straddles two types, its rationale says so.
- An answer slot is an instruction for the interview, not a question for you now. Each has two honest branches; both are fine, and the pack never fills in the practice it names.
- Question IDs run by persona: A Conversational, B Skeptic, C Values/Behavioral, D Case/Strategist, E Data-Driven Prober, F Peer Evaluator.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the log, not the process, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on how far a complaint travelled through you likely. If you took any complaint from first contact to its final response, say how, in your own words; if you handled only part of it, or others did the rest, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote shows a monthly complaints sheet you built and does not show what it counted. Words stay at the quote: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: expect a probe on what the sheet counted. If it counted anything you can name, say what and how it was counted, in your own words; if it did not, or you do not know, say so plainly and stay with the sheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers, not supervisors. Words: "I trained new tellers on our escalation script." Answer slot: the JD's supervisor line makes a probe likely. If you have helped anyone beyond new tellers through an escalation, say who and how; if not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on digital work, which is silence and not an absence. Answer slot: if you have worked with a digital, product or online-banking team, say who and on what, in your own words; if you have not, say so plainly, and say what you would want to learn first as a plan |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | The quote already reaches the requirement in role-relevant terms, with nothing inspected behind it, so expect a probe. Say it as you said it: 6 years in retail banking, the last 3 as a branch supervisor. Do not restate your work in the JD's phrase |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | The quote shows formal complaints and does not show whether they sat under outside rules. Words stay at the quote: "I handled the branch's formal complaints log." Answer slot: if you can say what made those complaints formal — what rules or reporting they fell under — say it in your own words; if you do not know, or it was only your branch's own practice, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A stated absence. Words: "I haven't presented to anyone above regional level." Then how you would prepare for a first senior audience, as a plan. The quote does not say what you have presented, so nothing is added about it |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote shows a spreadsheet and does not show which tool. Words stay at the quote. Answer slot: if you built it in Excel, say so and say what you did in it, in your own words; if it was another tool, or Excel played a small part, say so plainly and stay with the sheet you built |

## Grounding brief

From the 2026 strategy brief the recruiter sent you, as you relayed it, and the JD.

| Fact | Source | Provenance | Where it is used |
|---|---|---|---|
| Member-owned, about 900 staff | JD header | [grounded] | A2 |
| Move 40% of member service to digital channels by 2028 | 2026 strategy brief, July 2026 | [grounded] | A2, D1 |
| Consolidate eight branches into five hubs over 2027 | 2026 strategy brief, July 2026 | [grounded] | D6, V10 |
| Launch a small-business lending product in Q1 2027 | 2026 strategy brief, July 2026 | [grounded] | A2 |
| Main competitive pressure is app-only banks | 2026 strategy brief, July 2026 | [grounded] | A2, D1 |

Ashgrove published the brief, so any prepared candidate can read it: do not recite it. Bring one item to show you have read it, then give a view of your own on what it means for complaints.

---

## Round 1 — Recruiter, 30 minutes

### Persona weights

| Persona | Weight | Reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | high | Recruiter-screen prior: friendly register, scored anyway, and the logistics questions arrive here | Pre-script a 60 to 90 second arc from your own quotes; treat casual questions as scored |
| Skeptic | low | Recruiter-screen prior includes light knockout checks, and F2 is a stated gap the JD names | Rehearse the contact-centre concession until it is plain and unhurried |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey. How did you get here?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F6, F1, F4 and F3: the six years and the last three as a branch supervisor, then the log, the tellers and the spreadsheet, each at the quote's own scope. About 90 seconds. Then say, in your own words, why this role; the pack does not write your reason | The opener is always scored in a screen. EXP because it tests whether the CV lines hold up said aloud |
| A2 | "What do you know about Ashgrove, and why a credit union?" | CO | [grounded] | Choose one or two items from the grounding brief, not all four, and say what you make of them for complaints. Why a credit union is your own reason, in your own words | The grounding brief is the pack's CO material; this is where it is first used. CO because it tests homework depth |
| A3 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first. Never a figure you cannot stand behind | The JD gives no pay terms, and a screen asks. JD because it is a term of the listed job |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | A standard screen item, and the only safe answer is your own |
| A5 | "Where would you work from, and can you get between sites?" | JD | [generic] | Logistics slot: say where you can work and how often, in your own words | The JD says the role runs across branches and the contact centre and states no location |
| A6 | "Why are you looking to move?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words. The pack supplies none | Motivation consistency is what a screen checks; EXP because it is about your own history |
| B1 | "I don't see contact-centre experience in your background. How would you handle that part of the role?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Concede it exactly: "I haven't worked in a contact centre." Then say what you do bring at its own scope: "I handled the branch's formal complaints log." Then a plan, said as a plan: what you would look at first and who you would sit with, in your own words | F2 is a stated gap and a JD-named scope, so a screen is where it is first tested. JD because it scores the stated scope |
| B2 | "Tell me about your experience with regulated complaints." | JD | [grounded] "I handled the branch's formal complaints log" | Say it at the quote's scope: "I handled the branch's formal complaints log." Answer slot: if you can say what made those complaints formal — what rules or reporting they fell under — say it in your own words; if you do not know, or it was only your branch's own practice, say so plainly and stay with the log | F7 is a headline requirement with thin evidence. JD because it scores the stated requirement |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| V1 | "Is there a salary band for the role, and is it based at one site or across branches?" | It settles the terms A3 and A5 leave open, with the person who holds them |
| V2 | "What does the contact centre look like today, and who does it report to?" | It meets the F2 gap head on and shows you are thinking about the half of the role you have not seen |
| V3 | "The case is 20 minutes on a complaint escalation. Is there a format or material I should expect?" | It is a direct ask for the one pre-declared piece of the loop |

---

## Round 2 — Head of Member Services (your would-be manager), 45 minutes, mostly behavioural

**The highest-ROI rehearsal in this pack is B3.** It is the objection this loop is most likely to raise in some form, and a calm, specific answer changes the interview.

### Persona weights

| Persona | Weight | Reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | high | The recruiter's email calls this round "mostly behavioural", which moves it above the manager prior | Map a story where one of your quotes carries one; "we" for context, "I" for contribution; where none does, say so |
| Skeptic | mid | Manager prior: buying capability and derisking gaps, and F1, F2 and F8 give it material | Rehearse the single most predictable objection until it is boring; calibrated candour over bluffing |
| Case/Strategist | mid | Manager prior; the JD names digital self-service and the brief names the 40% digital move | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| Data-Driven Prober | low | You built one artifact, the spreadsheet, so probes on it are likely, and low because the round is mostly behavioural | Know what you can and cannot say about what it counted, and say plainly when you do not know |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you kept hold of a member's problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | No quoted sentence carries a particular case, so this is a selection scaffold: pick one complaint from the log you handled, with a named problem as it arrived, a point where it could have been passed on, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I handled the branch's formal complaints log", or how you would handle it | The theme is the published value Own the Fix. VAL because it tests past behaviour against that value; F1 is the nearest evidence |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and a working relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem for a role that reports upward. VAL because it scores candour, not content |
| C3 | "Tell me about a time you coached someone through a difficult escalation." | EXP | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: you trained new tellers, on your escalation script, the beats the quote states, told in your own words. Answer slot: the JD's supervisor line makes a probe likely. If you have helped anyone beyond new tellers through an escalation, say who and how; if not, say so plainly and stay with the tellers | F4 is the evidence for the JD's coaching line. EXP because it tests what you actually did |
| C4 | "Tell me about a time you presented to senior people." | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Say it plainly: "I haven't presented to anyone above regional level." The nearest thing your material carries is the sheet your regional manager uses, at that scope only. Then a plan, said as a plan: who the audience would be and what you would ask them first | F8 is a stated gap and the JD asks for confidence presenting. JD because it scores the stated requirement |
| B3 | "You'd own the process across branches and the contact centre. You've handled your branch's formal complaints log, and you've never worked in a contact centre. Why should we believe you can take it end to end?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre" | The deepest rehearsal here. Hold only what the quotes carry: "I handled the branch's formal complaints log." Concede exactly: "I haven't worked in a contact centre." The limit, as the pack's own observation, is that your material says the log, not the process. Follow-up one, "What did you do for a complaint once it left the branch?": return to the log. Follow-up two, "What would you not know on day one?": repeat the concession and give your plan, in your own words. Answer slot: if you took any complaint from first contact to its final response, say how; if you handled only part of it, or others did the rest, say so plainly and return to the log | F1 and F2 together are where the role's scope presses hardest, so this objection arrives in some form. JD because it scores the stated scope, with a Skeptic's delivery |
| B4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Choose the one you can plan for honestly and say it in your words: "I haven't worked in a contact centre" or "I haven't presented to anyone above regional level". Then the plan. Your material also does not show digital work; if that is where you are weakest, say so plainly. Do not name a gap you do not have | A standard Skeptic stem with two stated gaps to choose from, F2 and F8. JD because it scores honest self-assessment against the listed job |
| B5 | "The role works with digital teams on self-service journeys. When have you worked with a digital team?" | JD | [grounded] | No quoted sentence carries this, so it is a selection scaffold: pick a time with a named team, a named journey, and what you contributed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would work with one | F5 is silence in your material, which is a discovery gap, and the JD raises it. JD because it scores the stated line |
| D1 | "Ashgrove wants 40% of member service on digital channels by 2028. How should a complaint work for a member who starts in the app?" | CASE | [grounded] | No claim about your past. Clarify first: what counts toward the 40%, which complaint types start in the app. Then objective, segments, approach, metrics, risks. Challenge one premise respectfully, for example whether the share of service moved is the only measure. Tie it to Plain Words: "if a member needs it explained twice, we wrote it wrong" | The CO and CASE item grounded in the brief; F5's requirement is its link to the JD. CASE because it is a live problem |
| D2 | "A member complains in a branch, then by phone, then in the app. Who keeps hold of it, and what does the member see?" | CASE | [grounded] | No claim about your past. Structure it: who the member talks to, who holds the record, what the member is told at each step, and how you would know it was solved. The published Own the Fix line, "whoever finds the problem keeps hold of it until it is solved", is the vocabulary to use | A live version of the role's ownership mandate in F1. CASE because it asks for structure, not a story |
| D3 | "What would you want to learn in your first 90 days?" | CASE | [generic] | No claim about your past. Structure it by what you would look at: members and complaint types, the handoffs between branches and the contact centre, the reporting, the supervisors. Say what you would ask for first | A manager's open question about readiness. CASE because it scores structure; `[generic]` because it is a pattern for the role |
| E1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F3: you built it, it is monthly, your regional manager uses it, the beats the quote states, in your own words. Answer slot: expect a probe on what it counted. If it counted anything you can name, say what and how; if it did not, or you do not know, say so plainly and stay with the sheet you built. Name, in your own words, the part you would defend least | F3 is the one artifact in your material, so it is the first place a prober goes. EXP because it tests what was actually yours |
| E2 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: if you built the sheet in Excel, say so and say what you did in it, in your own words; if it was another tool, or Excel played a small part, say so plainly and stay with the sheet you built | F9 is a requirement the quote touches without reaching. JD because it scores a listed skill |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| V4 | "What would you want the complaints process to look like twelve months from now?" | It asks for the outcome behind the JD's ownership line |
| V5 | "Where does a complaint most often get stuck today?" | It goes straight to the handoffs F1 and F2 turn on |
| V6 | "How do the digital teams hear about complaint themes today?" | It speaks to F5 and the self-service line without claiming experience |
| V7 | "Who would I present the monthly report to, and what do they do with it?" | It meets the F8 gap with a practical question about the audience |
| V8 | "What would a good first 90 days look like to you?" | It turns D3 into a shared plan and tells you how success is measured |

---

## Round 3 — Panel of two branch managers, 60 minutes, including a 20-minute escalation case

This is the values round: the recruiter says the panel scores against the four values.

### Persona weights

| Persona | Weight | Reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | high | The recruiter's email says "The panel is also the values round — they score against the four values" | One mapped story or scaffold per value; "we" for context, "I" for contribution |
| Case/Strategist | mid | The recruiter's email gives 20 of the 60 minutes to a case on a complaint escalation | Clarify before structuring; say your assumption aloud where you have no answer |
| Peer Evaluator | low | Branch managers sit on the seam with the role, and the JD's supervisor-coaching line makes the seam a likely topic; this weighting is the pack's inference | Reciprocity framing; propose seam principles, not a seam you do not know |
| Skeptic | low | F4 and F2 stay the thinnest rows in front of a panel that sits closer to branches | Calibrated candour over bluffing |
| Conversational | low | The panel's opener reuses A1's arc, so one question is enough | A 60-second version of A1; no new facts |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C5 | "Tell me about a time you decided from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a decision where the member's view and the institution's pulled apart, with who disagreed, what you decided and what happened to the member. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I handled the branch's formal complaints log", or how you would handle it | The theme is the published value Members First, Always. VAL because it tests past behaviour against that value |
| C6 | "Tell me about a time a member needed something explained twice." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold: pick a specific explanation that did not land, with what you said, what the member needed and what you changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "trained new tellers on our escalation script", at that scope only, or how you would explain it plainly | The theme is the published value Plain Words. VAL because it tests past behaviour against that value |
| C7 | "Tell me about a time you thought about what a branch means to its town." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Selection scaffold: pick a decision or conversation where the town, not only the branch's numbers, shaped what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "6 years in retail banking, the last 3 as a branch supervisor", or how you would approach it. The hub plan makes this a likely follow-up | The theme is the published value Neighbours, Not Numbers. VAL because it tests past behaviour against that value |
| C8 | "Tell me about a time you found a problem and stayed with it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | The same story map as C1, delivered to a different audience: reuse is fine, but keep the facts identical. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I handled the branch's formal complaints log", or how you would handle it | The published value Own the Fix is scored by this panel too. VAL because it tests past behaviour against that value |
| D4 | "A member's complaint has bounced between the contact centre and a branch, and they say they are leaving. You have 20 minutes. What do you do?" | CASE | [generic] "I handled the branch's formal complaints log" | The recruiter's note names a case on a complaint escalation; this is a pattern for it, not the actual case. Clarify first: what the member has been told, what is logged, who has touched it, what they want. Then objective, approach, who keeps hold of it, and what you would say to the member in plain words. Leave time to summarise. If asked whether you have handled one like it, answer only from "I handled the branch's formal complaints log" | The 20-minute case is the largest single block in the loop. CASE because it scores structure under time; `[generic]` because the case itself is unknown until the day |
| D5 | "A branch supervisor escalates every complaint to you. How do you coach them?" | CASE | [generic] | No claim about your past. Structure it: find out why they escalate, agree what they can resolve themselves, and set how you will check in. Reciprocity: what the branch gets back from you | The JD's supervisor-coaching line as a live problem, aimed at the people who manage those supervisors. CASE because it asks for an approach |
| D6 | "Eight branches become five hubs over 2027. What happens to complaints, and what would you watch?" | CO | [grounded] | No claim about your past. Clarify first: which complaint types, which towns. Then name two or three things you would track, using the JD's own reporting terms, and what you would ask the branches. Tie it to Neighbours, Not Numbers: "every branch is part of its town". Take a view of your own rather than reciting the brief | The branch-consolidation item from the brief, set where the branch managers will care. CO because it tests strategy fluency |
| F1 | "Where does your role stop and a branch manager's start when a complaint is open?" | CASE | [generic] | No claim about your past. Propose seam principles rather than claiming to know the seam: who the member speaks to, who holds the record, and what each side tells the other. Reciprocity: what the role gives the branch | The peer question a branch panel would ask of the role. CASE because it asks for a principle |
| F2 | "A branch fixes a problem you spotted. Who gets the credit in the monthly report this role writes?" | CASE | [generic] | No claim about your past. Say the branch is named, the fix is credited to the people who made it, and the report shows the pattern. Own the Fix: the one who found it keeps hold until solved, and does not keep the credit | A credit-sharing probe in collegial packaging. CASE because it is a hypothetical, not a story |
| A7 | "Tell us a little about yourself, and what drew you to Ashgrove." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log" | A 60-second version of A1's arc, from the same two quotes and no new facts. What drew you is your own reason, in your own words | A panel opener is scored. EXP because it tests whether the CV lines hold up said aloud |
| B6 | "You trained new tellers. Coaching supervisors is a different job. What changes?" | JD | [grounded] "trained new tellers on our escalation script" | Hold the quote: "I trained new tellers on our escalation script." Answer slot: if you have helped anyone beyond new tellers through an escalation, say who and how; if not, say so plainly and stay with the tellers. Then how you would adjust, as a plan | F4 is the thinnest of the coaching evidence. JD because it scores the stated line |
| B7 | "Which of our four values would be hardest for you to show?" | VAL | [grounded] | Choose the value your material carries least, and say so plainly. That is the pack's observation and not a verdict on you: C5 to C8 show where each value is carried and where it is thin. Then how you would show it, as a plan | The values wording is published, so a Skeptic can aim at it. VAL because it scores honest self-assessment against the four |

### Values and principles cheat sheet

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decisions start from the member's side of the counter | Scaffold, no quoted sentence carries it: pick a decision where the member's view and the institution's pulled apart. If none comes to mind, say so plainly, then give the nearest thing your material carries, F1, "I handled the branch's formal complaints log", or how you would handle it |
| Plain Words | If a member needs it explained twice, the writing was wrong | Scaffold: pick an explanation that did not land. If none comes to mind, say so plainly, then give the nearest thing your material carries, F4, "trained new tellers on our escalation script", or how you would explain it plainly |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold: pick a decision shaped by the town. If none comes to mind, say so plainly, then give the nearest thing your material carries, F6, "6 years in retail banking, the last 3 as a branch supervisor", or how you would approach it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1, "I handled the branch's formal complaints log". Answer slot: if you kept a particular complaint until it was solved, say which and what you did; if not, say so plainly and stay with the log |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| V9 | "When a complaint touches your branch, what do you most want from the person in this role?" | It turns the case into a partnership and asks what the branch needs from the role |
| V10 | "How will the move from eight branches to five hubs change what you need from complaints reporting?" | It speaks to the brief's hub plan from the branch's side |
| V11 | "What does Neighbours, Not Numbers look like in a complaints decision here?" | It uses a published value as the question |
| V12 | "What could a new person in this role do in the first month that would genuinely help your branch?" | The reciprocity question: it asks what you can give, not only what you need |

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | B1, B3, D2, D4, F1 |
| "report monthly on complaint volumes and resolution times" | E1, D6 |
| "coach branch supervisors on escalations" | C3, B6, D5 |
| "work with digital teams on self-service journeys" | B5, D1 |
| "4+ years in financial-services customer operations" | A1, A7 |
| "experience handling regulated complaints" | B2 |
| "confident presenting to senior leaders" | C4, B4 |
| "comfortable with Excel reporting" | E2, E1 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the log, not the process. B3's slot stays inside the log |
| Has contact-centre experience | Negative the candidate stated, F2 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Coached supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: new tellers. The slots in C3 and B6 stay with the tellers |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says the sheet, not what it counted. E1's slot asks only what it counted |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: your material says formal, not regulated. B2's slot stays inside the log |
| Has presented to senior leaders | Negative the candidate stated, F8 | The plain acknowledgment: "I haven't presented to anyone above regional level." No slot |

## Sources

Provided documents: the job description you pasted; the four published values you pasted, copied on 20 November 2026 from the values page; the recruiter's email about the process; the 2026 strategy brief of July 2026, as you relayed four points from it; your own background message. No dossier was present. No searches and no fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | skipped | Could not have moved the cheat sheet or the VAL bank: the values you pasted from the page this morning already supply all four names and wording |
| 2. `{company} interview process {role family}` | skipped | Could not have moved the persona weights: the recruiter's email fixes the three rounds, their length, who runs each and which is the values round |
| 3. `{company} strategy` / recent news | skipped | Could not have moved the CO bank: the July 2026 brief, under six months old, already supplies the priorities and the competitive frame, at the four points you relayed |
| 4. `{interviewer name} {company}` | n/a | No names were given, only roles, so there was no query to form; the interviewer read is absent |
| 5. representative `{role title}` JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions |

## Upgrade menu

- Interviewer names for all three rounds, once assigned → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to each one's own path
- The recruiter's detail on the case format → a tailored build for D4 in place of the pattern case
- The JD's pay band, location and working pattern → A3, A4 and A5's slots can be filled from the role's own terms; one email to the recruiter would do it
- Your answers to the slots in F1, F3, F4, F5, F7 and F9 → those rows move from thin evidence to quoted stories, and the banks that draw on them regenerate
- An anonymised copy of the monthly complaints spreadsheet, or the escalation script you trained on → F3, F4 and F9 can rise from medium to high on inspectable proof
- The full text of the July 2026 strategy brief → the grounding brief gains exact wording and numbers beyond the four points you relayed
- How much prep time you have before 29 November → a prioritised schedule, with everything else marked as insurance
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → role-family loop reports and recent organisational context for the CO bank
- A tuesday-dossier.md, if you have one from an earlier check → verified evidence and a prohibited-claims list that would replace this pack's locally built one
