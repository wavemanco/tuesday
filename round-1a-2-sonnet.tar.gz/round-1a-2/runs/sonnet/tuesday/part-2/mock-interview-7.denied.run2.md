Web search was refused for all four research queries, so I'm building the pack from your JD and background alone. I'll save it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/tuesday/part-2/rooms/case-7-denied-b3a4ec5a/saltmarsh-games_live-operations-producer_interview_pack.md`.

- **Round assumption:** I built it as a hiring-manager round, since you didn't say how Tobias relates to the role.
- **No research:** web search was refused on all four queries. Nothing about Saltmarsh Games or Tobias is in the pack, only your JD and background. The Sources section says what each query would have changed.
- **Highest-ROI prep:** B1, "Which part of this job would you be weakest at on day one?" It covers your two stated limits, never leading a team and never working on in-app purchases, plus the thin spot on owning the post-event review and KPIs.

Say the word and I'll run a live drill as the Skeptic on B1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias going to be your future manager, a skip-level, or a peer, and did the recruiter mention any focus areas or an exercise to prepare? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

- **Role:** Live Operations Producer, Saltmarsh Games (mobile game studio)
- **Interviewer:** Tobias Wrenfield, Head of Live Operations
- **Round:** 60 minutes, on Friday. Your relationship to Tobias was not stated, so this pack is built as a hiring-manager round. Persona weights below rest on that assumption and on no research about Saltmarsh Games.
- **Candidate:** Femi

## How to use this pack

Personas are how a question is asked. Types are what it is scored on. Guidance is scaffolding for a spoken answer, not a script: every claim about your past is a sentence you wrote, quoted next to the question, and where the material is silent the guidance is an answer slot for you to fill truthfully or decline.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows the company's published values (no VAL questions here: no published values were read) |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | The listed responsibilities and requirements, including their gaps |
| CO | Company and strategy knowledge (none here: no company research landed) |
| CASE | A live problem from the role, scored on structure and reasoning |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not a live-events calendar for two titles, and nothing inspected sits behind it. The words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-title line makes a probe on scale likely. Say, in your own words, how the weekly calendar was set and which of its decisions were yours; if some were set by others, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: the JD names four disciplines, so expect a probe on which of them you worked with. If you worked with any, say who and what part was yours, in your own words; if you did not work with some, or it was not yours, say so plainly and say how you would approach it |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [inferred] | discovery | Presenting numbers is adjacent to this requirement, and your material does not show what stood behind them. Answer slot: say what you presented, in those words; if you also prepared any of those numbers, say how, in your own words; if you did not, or they came from someone else, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and that your QA team still uses it, with nothing inspected behind it. Lead with that in its own terms: "I wrote the release checklist our QA team still uses." Answer slot: if you did anything beyond writing it, say what, in your own words; if you did not, say so plainly and stay with writing it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | The years are in your sentence; what the four years held is not. Answer slot: say what you worked on across them, in your own words; if some of it was other work, say so plainly and stay with the two years of the weekly calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | Your strongest row. Lead with it in its own terms: you ran it, weekly, for your main title, for two years. A CV line with nothing inspected behind it, so expect a probe on it |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | Lead with the quote in its own terms: you presented the retention numbers, monthly, to the studio head. Answer slot: expect a probe on which measures were in them and who prepared them. If you prepared or chose them, say how, in your own words; if someone else did, or there was no fixed set, say so plainly and stay with presenting them |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A written document others use touches this requirement, and your material does not show anything wider. Answer slot: if other writing of yours was relied on by others, say what, in your own words; if not, say so plainly and stay with the checklist |

Candidate-stated limits that are not JD rows but will matter: "Never led a team, and never worked on a game with in-app purchases." — your message. They are handled in the prohibited list and in B1, B3 and B4.

## Persona table

No loop source established Saltmarsh's process, so the Generic archetype applies and adds no tilt from the company's own loop. Weights come from the hiring-manager relationship prior alone.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the role: plan this, diagnose that | High. Hiring-manager prior; the JD's calendar, review and checklist duties turn directly into problems | Clarify, then objective, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of gaps and motivation | High. Hiring-manager prior; your own message states two limits | Rehearse the most predictable objection until it is boring; plain acknowledgment, then a plan said as a plan |
| Data-Driven Prober | Line-by-line on the numbers you mention | Medium. The JD names retention metrics and your material includes presenting them; no figures were given | Say plainly what you know of how things were counted and what you do not |
| Conversational | Friendly opener, still scored | Medium. A 60-minute conversation usually opens this way | A short arc built only from your sentences; treat casual questions as scored |
| Peer Evaluator | Seams between teams, credit | Low. Applies if Tobias is not your future manager | Reciprocity framing; propose seam principles rather than claiming to know the seam |
| Pressure | Time-boxed, "how much was you" | Low. Hiring-manager prior is secondary here | Hold the position through two follow-ups, concede specifically, never fold the core claim |
| Values/Behavioral | Scenarios against published values | Low, no bank. No values-style round was detected and no published values were read | Revisit once research or the values page is available |

## Question banks

**Highest-ROI prep in this pack: B1.** It will be asked in some form, it draws on the two limits you stated and on F3, the thinnest JD row, and a rehearsed, non-defensive answer changes the interview.

### A. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two events are due to start the same day on your two titles, and engineering says one will slip two days. Walk me through what you do." | CASE | [generic] | Structure aloud: clarify first (what slips, what depends on it, who decides, what is fixed on the other title), then the objective, the options and their costs, who you tell and when, and what you change in the calendar afterward. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The JD's two-title line is where F1's gap sits; a live problem tests it without a story. CASE because it is scored on structure |
| A2 | "An event just ended and the players who joined during it are retained worse than earlier cohorts. You own the review. How do you diagnose it?" | CASE | [generic] | Clarify before structuring: which cohorts, compared to what, over what window. Then segment, list what else changed that week, say what you would check first and what data you would ask for. Say plainly where you would need help. No claim about your past | F3 and F7 are the rows this probes. CASE because it asks for reasoning on a live problem |
| A3 | "Design, art, engineering and community each tell you their part of next month's update needs another week. What do you do?" | CASE | [generic] | Clarify what is fixed and what is movable, find which dependencies actually bind, decide who needs to hear what and when, and say what you would hold firm on. The question presupposes nothing about your past | F2 is the discovery row; this tests the same requirement as a decision rather than a record |
| A4 | "Sketch how you would plan a four-week events calendar for a title you have just joined. What do you need to know first?" | JD | [generic] | Start with the questions: goals, what players have seen recently, team capacity, fixed release dates, how results are reviewed. Then structure: objective, cadence, buffer, review points. No claim about your past | F6 is your strongest row, so this one is a chance to show structure; JD content, CASE delivery |
| A5 | "A release checklist item fails the morning an update is due to go live. QA says hold, the calendar says ship. What do you do?" | JD | [generic] | Clarify the item and its risk, who owns the call, what the options cost, who must be told, and what you would change in the checklist afterward. Say plainly what you would not decide alone. No claim about your past | F4 is a transferability row; a decision scenario tests the requirement without needing you to claim management of it; JD content, CASE delivery |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Choose one limit and say it in one plain sentence. Your own words carry two: "I haven't led a team" and "I haven't worked on a game with in-app purchases." Then give a plan as a plan: what you would ask to see first, who you would ask, what you would review in your first weeks, in your own words. Do not add experience that closes the gap. Hold through two follow-ups by repeating the limit and the plan; concede specifically what you do not yet know. If you would rather name the review and KPI row, use B5's slot | The most predictable objection; F3 is the thinnest JD row and the two limits are your own statements. JD because it scores the whole requirements list |
| B2 | "This role runs the calendar for two titles. When have you kept more than one stream of work moving at once?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pick a time with a named stake, how you decided what went first, and how it landed; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "For the last two years I ran the weekly content-drop calendar for our main title," or how you would handle it | F1 is the row this presses on; the question is an open prompt so it supplies no event; JD because it scores the listed two-title scope |
| B3 | "You haven't worked on a game with in-app purchases. What would you do about that in your first month?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Open with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then the plan, said as a plan: what you would ask to see first, who you would ask, what you would read, in your own words. No claim that your puzzle-game work covered it and no minimizing. Hold through two follow-ups by repeating the acknowledgment and the plan | Not a JD row; it comes from your own message and will matter if the interviewer notices the absence. EXP because it tests candor about what you have and have not done |
| B4 | "This role coordinates design, art, engineering and community on each update, and you haven't led a team. What do you bring?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Say the plain acknowledgment: "I haven't led a team." Answer slot: if any weekly drop needed you to get design, art, engineering or community to agree on timing, say how, in your own words; if you did not work with those teams, or it was not yours, say so plainly and say how you would approach it. Do not describe a team you did not lead | F2 is a discovery row and your stated limit sits next to it; JD because it scores the coordination line |
| B5 | "The role owns the post-event review and the KPIs it reports. What have you owned there?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you presented, in those words. Answer slot: if you also prepared any of those numbers, say how, in your own words; if you did not, or they came from someone else, say so plainly and stay with presenting them. Hold through two follow-ups by returning to what you presented, never by adding to it | F3 is where the JD's ownership wording presses hardest against the quote; JD because it scores the stated responsibility |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented monthly retention numbers to the studio head. Walk me through what you showed." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Story-mapped on F7: the numbers, the monthly cadence, the studio head, which are the beats the quote states; tell them in your own words. Answer slot: the JD's retention line makes a probe on which measures were in them and who prepared them likely. If you prepared or chose them, say how; if someone else did, or there was no fixed set, say so plainly and stay with presenting them | F7 is the evidence for the retention requirement. EXP because it tests what was actually yours. You gave no figures, so there is no defend-the-number question |
| C2 | "Which retention measures are you most comfortable reading, and which would you want help with?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Name the measures you have actually worked with, in your own words, and one you have not. If no such measures come to mind, say so plainly, then give the nearest thing your material carries, "I presented the monthly retention numbers to the studio head," or how you would learn | F7; JD because it scores the stated comfort requirement. An open prompt, so it supplies no event |
| C3 | "A post-event review says the event worked. What would make you doubt that?" | CASE | [generic] | Think aloud: worked compared to what, for which cohort, over what window, and what else changed that week. Name the assumption you would trust least before the interviewer does. Say what data you would want. No claim about your past | F3 and F7 tested as reasoning; CASE because it is scored on how you question a result |

### D. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc in this order, each beat at its own scope: four years as an associate producer at a puzzle-game studio; for the last two years, the weekly content-drop calendar for your main title; the release checklist your QA team still uses; the monthly retention numbers you presented to the studio head. Close with your own reason for this role | F5 to F8 are the sentences the arc stands on. EXP because it is the biography question, which is scored even when it sounds casual |
| D2 | "What draws you to live operations at a mobile studio, and why now?" | JD | [generic] | Give your real reason in two or three sentences and keep it consistent with D1. Make no claim about your past that D1's quotes do not carry. If your reason is partly that you want to learn something you have not done, say so plainly | Motivation consistency is scored in every register. JD because it concerns the listed role |
| D3 | "Tell me about something you wrote that other people relied on." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F8 and F4: the checklist, and that your QA team still uses it, which are the beats the quote states. Answer slot: the JD's written-communication line makes a probe on how you decided what went in likely. If you decided, say how, in your own words; if it was handed to you or built from a template, say so plainly and describe what you wrote | F8 and F4 together. JD because it scores the written-communication requirement; an open prompt so it supplies no event |

### E. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Live ops and engineering sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Offer seam principles instead of claiming to know this seam: what each side owns, what is shared, how a disagreement gets decided and by whom. Add what you would bring to the other team, not only what you would need. No claim about your past | F2's coordination line, asked collegially. Low weight because it applies if Tobias is not your future manager |
| E2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Pick an instance only if one comes to mind; name the stake, what you said and to whom. If no such instance comes to mind, say so plainly, then say how you would handle it. No claim about your past is made here | Collegial credit probe; EXP because it asks for behavior. Its guidance supplies no instance |

### F. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why should we choose you over someone who has run live events across two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head."; "Never led a team, and never worked on a game with in-app purchases." | Pause, restate the question, then say only what the quotes carry: you ran the weekly content-drop calendar for your main title for two years, you wrote the release checklist your QA team still uses, you presented the monthly retention numbers to the studio head. Hold through two follow-ups by returning to those. If pressed, concede specifically with your own words: "I haven't led a team" or "I haven't worked on a game with in-app purchases," and follow with the plan from B1. Never claim to be the stronger candidate | F1 to F8 as a whole; the comparison is a hypothetical, so it asks nothing about your past. JD because it presses the listed requirements |
| F2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the position the quote carries: "I ran the weekly content-drop calendar for our main title for the last two years." Hold through two follow-ups by returning to it. Answer slot: if some part of the calendar was set by someone else, say which part, and which were yours; if none was, say so plainly. Concede only what you can state specifically | F1 and F6; EXP because attribution probes exist to catch inflation |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A1, A4, B2 |
| Coordinate design, art, engineering and community teams on each update | A3, B4, E1 |
| Own the post-event review and the KPIs it reports | A2, B5, C3 |
| Manage the release checklist with QA | A5, D3 |
| 3+ years producing live-service games or apps | D1, F1 |
| Experience running a content calendar | A4, D1, F2 |
| Comfortable with player-retention metrics | C1, C2, C3 |
| Clear written communication | D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first 90 days look like in this role, and how would you tell at day 90?" | Shows you think about what the job is measured on, and the answer tells you what to prove first |
| R2 | "How do the two titles' calendars get planned today, and where do they collide?" | Moves the conversation to the two-title scope you have not run, with curiosity rather than defence |
| R3 | "Which KPIs does the post-event review report now, and who reads it?" | Points at the review and KPI ownership, the thinnest row in your material, and invites the real answer |
| R4 | "Where does an update most often get stuck between design, art, engineering and community?" | Shows you are asking about coordination as work, not as a title |
| R5 | "How much of this role's work touches how the titles earn money, and what would you want me to learn first there?" | Raises the in-app purchase gap on your terms, as a learning plan, before it is raised against you |
| R6 | "What do people in this role most often wish they had known in their first month?" | An open question that gets an experienced person's real advice |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative the candidate stated, "Never led a team, and never worked on a game with in-app purchases." — your message | The plain acknowledgment: "I haven't led a team." No answer slot |
| Worked on a game with in-app purchases, or on monetization | Negative the candidate stated, same sentence | The plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan said as a plan, never as a past |
| Ran a live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a weekly content-drop calendar for your main title. B2's guidance stays with that calendar |
| Owned the post-event review and the KPIs it reports | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says you presented the retention numbers. B5's slot stays inside presenting |
| Managed the release checklist with QA | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says you wrote it and QA still uses it |
| Three or more years of live-service production | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: the material says four years as an associate producer at a puzzle-game studio |

## Sources

**Provided documents:** the job description you pasted (Live Operations Producer, Saltmarsh Games) and the background in your message. No `tuesday-dossier.md` was present.

**Searches sent, all refused by the host (no results returned):**

- "Saltmarsh Games values": refused
- "Saltmarsh Games interview process live operations producer": refused
- "Saltmarsh Games strategy news mobile": refused
- "Tobias Wrenfield Saltmarsh Games": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Every call was refused. It would have moved the values cheat sheet and VAL questions; none are in this pack |
| 2. Saltmarsh Games interview process, live operations | unavailable | Every call was refused. It would have established the loop and moved persona weights; they rest on the hiring-manager prior and the Generic archetype instead |
| 3. Saltmarsh Games strategy and recent news | unavailable | Every call was refused. It would have moved CO and strategy-grounded CASE questions; the CASE questions here are generic |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Every call was refused. It would have moved the interviewer read and a reverse question tied to his path; both are absent |
| 5. representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission to run web search, or the company's values page and careers or interview page pasted in: values cheat sheet, company-grounded CO and CASE questions, and persona weights tied to Saltmarsh's actual loop
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), offered once: strategy brief, Tobias's public talks and writing, and loop reports, which would give the CASE bank company-specific problems and an interviewer read
- Whether Tobias is your future manager, a skip-level or a peer: reweights every bank and the reverse questions
- Anything the recruiter said about focus areas or a pre-declared exercise: coverage of any graded deliverable
- Your CV text: more rows quoted from it instead of your message, and any `none given` row that it covers upgrades
- Your answers to the slots on F1 to F5, F7 and F8: those rows move from slots to quoted stories
- Any retention figure you reported: adds a defend-the-number question to C1
- How much prep time you have: adds a prioritized prep schedule
- A `tuesday-dossier.md` from an earlier fit check, if you have one: verified evidence and allowed strategies per weak area
