Web research was denied, so I'm building the pack from what you gave me. I'm checking the dossier spec before I write it.
Your prep pack is at `/var/tmp/tuesday-measure/1a2/runs/sonnet/tuesday/part-2/rooms/case-2-denied-d4c6d279/atlas-freight_operations-manager_interview_pack.md`. It has 21 questions across seven interviewer styles, plus reverse questions and a claims-to-avoid list.

I built it with every interviewer style weighted equally, because I don't know who is interviewing you or what round it is. That makes it weaker than a pack built for a specific round.

The web searches on Atlas Freight were denied, so the pack has no company research. It has no values, no interview format and no strategy. The case and values questions are generic rehearsal and are labelled that way.

The one question I'd rehearse hardest is B2: "You lead 3 supervisors today and this role has 12 across 4 sites. Why would you be ready for that step?" The pack also says to be plain about Power BI. It says to say "I haven't used Power BI" and follow it with how you'd learn it. Every answer in the pack uses only what you told me, so you won't have to defend anything you didn't say.

Say the word and I'll play the Skeptic on B2.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who is interviewing you and in what round (hiring manager, peer, skip-level or recruiter), and has the recruiter mentioned any focus areas or a deliverable? Either answer reweights the whole pack.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not known. Round type and relationship: not known, so persona weights are flat (see the persona table). Built for one session, from the JD and background you pasted.

## How to use this, and the type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Scores |
|---|---|
| VAL | Whether past behavior shows the company's published values, not generic virtue |
| EXP | Whether the claims on your CV survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack: company research did not run, see Sources) |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage

A week is enough for the few things that matter, in this order. Everything else is insurance.

1. B2, the question this pack names as the highest-ROI prep: you lead 3 supervisors today, the role has 12 across 4 sites.
2. A1 and B1: the 40% mis-pick figure, defended to its assumptions and its attribution.
3. A3 and E1: saying plainly where you are on Power BI, with a ramp plan.
4. D1 to D3: say a case structure aloud twice. Delivery is the skill.
5. F1: the 90-second journey, built only from your own three sentences.

## Fit snapshot

No gate rows: nothing in the JD is a licence, location, schedule or pay term, and the 5+ years line is a length-of-experience requirement, graded like any other row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution work and a surge plan for the site, not terminal operations and not four sites, and the words stay at that scope: "I have 7 years in warehouse and distribution ops, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's 4-sites line makes a probe on running more than one site likely. If your work covered any site beyond your own, say which and how, in your own words; if it did not, say so plainly and stay with the surge plan you ran |
| R2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material says mis-pick rate, not on-time performance or cost-per-shipment, and nothing inspected sits behind the figure. The words: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD's two measures make a probe on what you have measured likely. Say what you counted in the mis-pick work, in your own words; if you have counted something else in your role, say what; if nothing else, say so plainly |
| R3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material shows 3 supervisors; the JD's team is 12. The words stay at 3: "Today I'm a senior shift manager over 3 supervisors." Answer slot: the JD's twelve makes a probe on how you lead supervisors likely. Say how you lead the three, in your own words; if any part of that was set by someone else, say so plainly |
| R4 | "build reporting in Excel/Power BI" — JD, the Excel half | "solid Excel" — your message | low | [inferred] | discovery | Solid Excel does not show that reporting was built, and the bridge should not be stretched. Answer slot: the JD's reporting line makes a probe on what you built likely. Say what you do in Excel, in your own words, and stop there; if the interviewer asks whether any of it was reporting, answer yes or no plainly |
| R5 | "build reporting in Excel/Power BI" — JD, the Power BI half | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past, in your own words. Nothing added to make the gap feel smaller |
| R6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | The quotes show seven years in operations and a current role over supervisors, and do not show how many of those years involved leading people. Answer slot: the JD states the requirement, so a probe on the count is likely. Say the number of years that included leading people only if you know it, with the role, in your own words; if you are unsure, say what you do know plainly |
| R7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms and the words stay on it: "I'm green belt certified." A certificate you can show would raise the band; today nothing inspected sits behind the line |

## Persona table

Round type and relationship are unknown, the loop is not established by any source, and the fallback archetype is Generic, so weights are flat. This is noticeably weaker than a pack built on the round: the one answer that would reweight it is in the closing question.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | Reads line by line, asks how numbers were counted | Equal weight: any round that read your background can do this, and the 40% figure invites it | Know what you can and cannot say about how the figure was counted, say plainly when you do not know, name your weakest assumption first |
| B. Pressure | Interrupts, time-boxes, tests composure on the 3-to-12 step | Equal weight: round unknown; the JD's scale jump gives this style a clear target | Pause, restate the question, hold your position through two follow-ups, concede one specific thing |
| C. Values / Behavioral | Scenario probes in a friendly register | Equal weight: no loop source names a values round, so it is not assumed, and it is not ruled out | Choose stories where the hard truth actually landed; where none comes to mind, say so |
| D. Case / Strategist | Live problems from the real job: on-time, cost, first 30 days | Equal weight: an operations role makes live cases likely in some round | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| E. Skeptic | Quiet probing of terminals, scale and Power BI | Equal weight: the gaps in R1, R3 and R5 are visible on the page | Rehearse the likeliest objection until it is boring; calibrated candor |
| F. Conversational | Chatty, feels safe, still scored | Equal weight: any first call or opener | A scripted 90-second arc; treat casual questions as scored |
| G. Peer Evaluator | Seams between the four sites, credit, disagreement | Equal weight: a peer at another site could sit on any panel | Reciprocity: what you bring their site, not only what you need |

## Question banks

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Story-mapped on R2: the redesign and the 40%, the beats the quote states, in your own words. Four slots, each answered in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how it was counted, say so plainly and say what you do know | R2 is the headline number on your background and the first place a prober goes; EXP because it tests counting and attribution |
| A2 | "The role is accountable for on-time performance and cost-per-shipment. What have you measured in your work?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say what you counted in the mis-pick work, in your own words. Answer slot: if you have counted something else in your role, say what and over what period; if nothing else, say so plainly and say what you would count first in this role. Do not describe a measure you did not track | R2 is the nearest evidence to the JD's two measures and stops short of them; JD because it scores the stated requirement |
| A3 | "The role builds reporting in Excel and Power BI. Tell me where you are with each." | JD | [grounded] "solid Excel, never used Power BI" | Power BI first, since the quote carries it: "I haven't used Power BI." Then your plan to learn it, said as a plan. For Excel, say what you do in Excel, in your own words, and stop there; if asked whether any of it was reporting, answer yes or no plainly | R4 and R5 are where the JD names a tool you have said you have not used; JD because it scores a listed tool |

### B. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "That 40% on the pick path: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold only what the quote carries: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: say which parts of the redesign and its result were yours and which were shared, in your own words; if it was a team effort, or others counted the result, say so plainly and return to the redesign. Hold through two follow-ups by returning to the quote, never adding to it; concede the one specific thing you do not know, in plain words | R2 is the figure attribution probes are built for; EXP because it scores what was yours |
| B2 | "You lead 3 supervisors today and this role has 12 across 4 sites. Why would you be ready for that step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack: this objection arrives in some form. Hold what the quote carries: "Today I'm a senior shift manager over 3 supervisors; the role's team is 12." Answer slot: say how you lead the three, in your own words, and which parts you expect to carry to a larger team and which you would need to learn; if you do not know, say so plainly. Do not offer the step as proof of readiness: describe what you do and let them draw the inference. Hold through two follow-ups by returning to that scope; concede in one plain sentence that the team and the sites are more, then give your first-weeks plan | R3 and R1 are where the JD presses hardest on your material; JD because it scores the stated requirement |
| B3 | "You have seven years in warehouse and distribution and lead 3 supervisors today. The JD asks for 5+ years of operations leadership. How many of those years involved leading people?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot: give the number of years that included leading people only if you know it, with the role and where, in your own words; if you are unsure, or the number is smaller than you would like, say what you know plainly and return to your current role. Never round up; a number you cannot repeat under a second question costs more than a smaller true one | R6 is a stated requirement the quotes do not settle; JD because it is the JD's own line |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, what you said, how it landed, and a working relationship intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Your pasted material does not show such a time, so the pack supplies none | A standard behavioral probe for a leader of supervisors; VAL because it scores behavior under pressure from above |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the customer and the number pulled apart, what you chose, what it cost, and what you would say about it now. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A freight business answers to shippers; VAL because it scores what you trade off, not what you profess |
| C3 | "Tell me about a time you coached a supervisor through a performance problem." | VAL | [grounded] "currently a senior shift manager over 3 supervisors" | Your quote carries only that you are over 3 supervisors, so any coaching story is yours to choose. Selection scaffold: a situation with a supervisor you can describe without naming them, what you said, what changed, and the relationship afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | R3's team-lead requirement is the JD's raising line; VAL because the question scores how you lead people |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "On-time performance at one of your four terminals has slipped for two weeks. What do you need to know first, and how do you diagnose it?" | CASE | [generic] | Structure aloud: clarify what on-time means here and what changed, state the objective, split the problem by lane, shift and handoff, choose an approach, name the metrics you would watch, name the risks. Challenge one premise politely. The question needs no claim about your past, so the guidance makes none | Live diagnosis from the JD's on-time line (R2's requirement); CASE because it scores structure |
| D2 | "Cost-per-shipment has to come down this year without hurting service. Where do you start, and what would you refuse to cut?" | CASE | [generic] | Clarify what sits in the cost and the count, state the objective, split the cost, pick where to look first, name the service measure you would protect and the metric you would track. Say the trade-off aloud | Live problem from the JD's cost line; CASE because the strong answer protects a limit as well as finding a saving |
| D3 | "You start Monday: four sites, twelve supervisors, and you know none of them. Walk me through your first thirty days." | CASE | [generic] | Structure: listen first, see each site, learn what each supervisor owns, find where the numbers already live, then choose two things to change. Say what you would not change yet. No claim about your past is needed | R1 and R3's requirements as a plan; CASE because it scores sequencing under uncertainty |

### E. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "solid Excel, never used Power BI" | Choose by your own honest read, not the pack's. If you choose Power BI, the quote carries the words: "I haven't used Power BI." Then the ramp plan, in your own words. Naming the weakness first is a credibility gain; a bluff is the thing this question exists to catch | R5 is the one gap you have stated yourself; JD because it scores honest self-assessment against the listed job |
| E2 | "You come from warehouse and distribution. What do you expect to be different about running a terminal?" | JD | [grounded] "7 years in warehouse and distribution ops" | Say what carries over in the quote's own terms. For what differs, say what you would ask in week one rather than assert terminal knowledge. Answer slot: if you have worked directly with terminals, say where and how, in your own words; if you have not, say so plainly and say what you would learn first | R1 is the biggest fit question between your material and the JD; JD because it scores the listed responsibility |
| E3 | "Why this role, why Atlas Freight, why now?" | JD | [generic] | A motivation answer has to be yours. Say only what you have read about Atlas Freight yourself: this pack holds no researched facts about the company. Do not use a reason you cannot defend through a second question | Motivation consistency is what a skeptic scores; JD because it tests fit with this specific role |

### F. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path" | A 90-second arc built from those three sentences only: the seven years, the current role over 3 supervisors, the redesign. The connective tissue and the order are yours. Add nothing no quote carries, and end on why this role, in your own words | The biography question opens most conversations and is scored; EXP because it tests whether your story matches your background |
| F2 | "Tell me about your green belt." | JD | [grounded] "green belt certified" | Say it in the quote's terms: "I'm green belt certified." Give the issuer and year in your own words if you know them. Answer slot: the JD's Lean/Six Sigma line makes a probe on application likely. If you applied it to a project, say which and what was yours; if you earned the certification and have not applied it at work, say so plainly | R7's requirement; JD because it scores a stated plus |
| F3 | "Walk me through the peak-season surge plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Story-mapped on R1: the plan, the site's, two years running, the beats the quote states, in your own words. Answer slot: the JD's own-daily-operations line makes a probe on which parts were yours to decide likely. If any part of the plan was yours to set, say which and how you decided; if it came from elsewhere or you carried it out, say so plainly and describe how you ran it. Give outcomes or numbers only if you have them | R1's best evidence, and the likeliest place to be asked what was yours; EXP because it tests attribution |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Two sites want the same dock capacity on the same morning and each calls it urgent. How do you settle it with them?" | CASE | [generic] | Structure: what you would ask each site first, what the shared priority is, how you decide and tell both, what you record afterward. Propose principles for the seam rather than pretending to know it. No claim about your past | R1's four-site requirement as a peer problem; CASE because it scores reasoning with equals |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a piece of work shared across teams, say what each side did, and how you described it afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Credit-sharing is a standard peer probe; VAL because it scores behavior with equals |
| G3 | "Tell me about a time you disagreed with someone at your level about how to run operations." | VAL | [generic] | Selection scaffold: a real disagreement, your position, theirs, how it was resolved, and the working relationship afterward. Show spine and tact together. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A peer is pricing what working beside you will be like; VAL because it scores disagreement style |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | B2, E2, F3, D1, D3, G1 |
| "drive on-time performance and cost-per-shipment down" | A2, D1, D2 |
| "lead a team of 12 supervisors" | B2, C3, D3 |
| "build reporting in Excel/Power BI" | A3, E1 |
| "5+ years operations leadership required" | B3 |
| "Lean/Six Sigma a plus" | F2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does on-time performance look like across the four sites today, and which site is furthest from where you want it?" | It uses the JD's own measure and shows you think in sites, not in one building |
| 2 | "What moves cost-per-shipment most here?" | It shows you ask what drives the number before proposing to change it |
| 3 | "What does the twelve-supervisor team look like today: where is it strongest, and where do you most need a new manager's hand?" | It turns the 3-to-12 question into a conversation you lead |
| 4 | "What reporting exists today, and where is the move to Power BI?" | It surfaces the tooling honestly and sets the learning curve in the open |
| 5 | "What would a good first ninety days look like to you?" | It gives you the interviewer's own scoring sheet for your first-weeks plan |
| 6 | "What surprises new managers most about running these terminals?" | It invites the candid answer a rapport-style interviewer remembers |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned terminal operations across multiple sites | Inflated form of R1 | R1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says warehouse and distribution work and a surge plan, not terminals or four sites. E2 and F3 stay inside the quotes |
| Led or managed a team of twelve supervisors, or a large team | Inflated form of R3 | R3's quote at its own scope: 3 supervisors. B2's slot asks only how you lead the three |
| Drove on-time performance or cost-per-shipment down | Inflated form of R2 | R2's quote at its own scope: the material says mis-pick rate. A2's slot asks only what you counted |
| Built reporting or dashboards in Excel | Inflated form of R4 | R4's quote at its own scope: "solid Excel". A3 asks for a plain yes or no if the interviewer asks |
| Used Power BI | Negative the candidate stated, R5 | The plain acknowledgment R5 gives: "I haven't used Power BI." Then a plan, never a past. No slot |
| Used Lean or Six Sigma methods to achieve the 40% mis-pick cut | Inflated form joining R2 and R7 | Each quote at its own scope, told separately. F2's slot asks only whether the belt was applied to any project |
| Has 5+ years of operations leadership | Inflated form of R6 | R6's quotes at their own scope: seven years in operations, a current role over 3 supervisors. B3's slot asks only for a count you know |

## Sources

Provided documents: the JD text and the background summary you pasted in your message. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Every search was sent and refused (no permission was granted), so nothing in this pack comes from outside research.

| Query sent | Outcome |
|---|---|
| Atlas Freight regional logistics company values | refused |
| Atlas Freight interview process operations manager | refused |
| Atlas Freight strategy recent news terminals | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Would have given published value names for VAL questions; no values cheat sheet is built, and C1 to C3 and G2 to G3 are generic |
| 2. Atlas Freight interview process, operations manager | unavailable | Would have named the loop's rounds and set persona weights; they are flat and the fallback archetype is Generic |
| 3. Atlas Freight strategy and recent news | unavailable | Would have grounded a CO question and the case problems in current priorities; D1 to D3 and G1 are generic and no CO question is included |
| 4. Interviewer name and Atlas Freight | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you are meeting and in what round (hiring manager, peer, skip-level, recruiter) → persona weights stop being flat and the banks reorder to match
- The recruiter's prep guidance, if any (focus areas, a deliverable, process details) → coverage built to the stated focus, and a build section for any deliverable
- The interviewer's name → an interviewer read and a reverse question tied to their own path
- Web search permission, or a pasted Atlas Freight values or careers page → published value names, the named loop, and a CO question grounded in current priorities; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief and the company's recent organisation news
- Your answers to the slots in R1, R2, R3, R4 and R6 → the `[inferred]` and `transferability` rows regenerate on your own words, and the bank guidance for A2, A3, B2, B3 and E2 tightens
- Your green belt certificate and any before-and-after record of the pick-path change → R7 and R2 can rise from medium to high
- Your full CV in place of the summary → every row's evidence cell draws on your CV's own lines
- A `tuesday-dossier.md` from an earlier review of this role → verified evidence and named objections, if you have one
