Femi, your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/tuesday/part-2/rooms/case-7-canned-79c9f8d9/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it for the Outage Hour, which Saltmarsh's careers page describes as "a live-incident tabletop on a simulated outage during a live event, then a values conversation." I assumed Tobias is the hiring manager running it.

The pack names C2 as the highest-ROI prep. That question is the in-app-purchase objection: the pack's research turned up a Saltmarsh announcement of a season-pass move for two of its titles, and you told me you haven't worked on a game with in-app purchases. C2 has three levels of follow-up and concession wording you can say truthfully.

The pack has 20 questions across six personas, a values sheet using Saltmarsh's three published values, six reverse questions, and a list of claims it won't coach. Several rows are answer slots, where you fill in what you actually did or say plainly that you didn't do it.

Say the word and I'll play the Skeptic on C2.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the hiring manager running your Outage Hour, and has the recruiter said anything about what the tabletop covers?
Do you want a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) on company strategy, Tobias's talks and recent org changes?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Session:** Friday, 60 minutes. Built as the Outage Hour, which Saltmarsh's interviewing page describes as "a single 60-minute interview with the hiring manager — a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home." The page does not say who the hiring manager is. This pack assumes Tobias is that person. If he is not, the persona weights change.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Each question carries one of five type tags:

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether the claims in your background survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company's strategy and can think at its level |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script. Anything marked as an answer slot is an instruction for the interview, and you fill it only from what you actually did. Wording marked as proposed is pending your approval. Change anything that is not how you would say it.

Question IDs run by persona weight. The sixth bank is G, because F is reserved for fit-snapshot rows.

## Fit snapshot

Proposed wording in this table, pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Proposed wording: "For the last two years I ran the weekly content-drop calendar for our main title." The pack's observation: your material names one title and weekly content drops, where the JD says two titles and a live-events calendar, and nothing is inspected behind it. Answer slot: the JD's wording makes a probe on how your weekly calendar compared likely. If events were part of what you scheduled, say how, in your own words; if they were not, or that part was not yours, say so plainly and stay with the weekly drops |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show this. Strong evidence would be one named update and which of the four groups you worked with. Answer slot: the JD names four groups, so a probe on which you worked with is likely. If you worked with any of them on a drop, say which and what you did, in your own words; if none, or someone else handled it, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Proposed wording: "I presented the monthly retention numbers to the studio head." The pack's observation: your material says presenting numbers, not what followed an event or who owned a KPI. Answer slot: the JD's line on a review after an event makes a probe on what the monthly numbers were used for likely. If any were looked at after a particular drop, say what you looked at and which part was yours; if they were not tied to drops, or the work was not yours, say so plainly and stay with the numbers you presented |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | Proposed wording: "I wrote the release checklist our QA team still uses." The pack's observation: your material says you wrote it and QA uses it, with nothing inspected behind it, and does not say who ran it at each release. Answer slot: if you also ran it release to release with QA, say how, in your own words; if you did not, or that was someone else's job, say so plainly and stay with the checklist you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Proposed wording: "Four years as an associate producer at a puzzle-game studio, the last two running the weekly content-drop calendar for our main title." The pack's observation: your material does not say what the first two of the four years held. Answer slot: expect a probe on which years were live-service. If the first two were, say what you produced; if they were not, say so plainly and stay with the two years of the weekly calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap in wording, but nothing is inspected behind it, so expect a probe. Lead with the quote's own terms: you ran it, weekly, for the main title, for two years. A named cadence beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in wording, but you gave no figure and nothing is inspected, so expect a defend-the-number probe (E1). Lead with the quote's own terms: you presented the monthly numbers to the studio head |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | The quote touches written work and does not show whether it was clear. The derivation is the pack's, from the checklist being in use. Answer slot: expect a request for an example of your writing. If you have a document of yours that others used, say which and how it was used; if the checklist is the only one, say so plainly and stay with it |

## Reading the interviewer

| # | What | Provenance | Source or derivation |
|---|---|---|---|
| I1 | "Patch Notes Are a Promise" is a GDC 2026 talk by Tobias Wrenfield, Head of Live Operations at Saltmarsh Games. Its argument, as the search snippet states it: "a live team is judged by how often its patch notes describe what actually shipped." | [grounded] | Search 4, snippet only; the page was not read |
| I2 | The same snippet says he was "previously a QA lead at a console studio." | [grounded] | Search 4, snippet only |
| I3 | Expect questions on what you announce versus what is built. His talk's theme sits close to Saltmarsh's second published value. Rehearse A2 and B2 | [inferred] | I1 with the values page, Sources row 1 |
| I4 | A QA background makes probes on the release checklist more likely. Rehearse A5 and B3 | [inferred] | I2 with the JD line "manage the release checklist with QA" |
| I5 | Shared vocabulary only: release checklists and patch notes. F4's quote, "Wrote the release checklist our QA team still uses", is yours to use in those terms. Do not build on shared background of any other kind | [inferred] | I2 with F4 |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | A simulated outage during a live event, then smaller live problems from the role | High. The loop page names "a live-incident tabletop on a simulated outage during a live event" as the first half of the session. The hiring-manager prior also puts Case first | Clarify, then objective, then approach, metrics and risks, thinking aloud. Challenge one premise respectfully per case. Banks A and D3 |
| B. Values / Behavioral | A scored conversation on Saltmarsh's three published values | High. The same page names "a values conversation" as the second half, and the published values are Players Before Plans, Ship the Patch Not the Promise and Leave the Build Greener | Map a story to a value only where your quoted sentences carry one. Elsewhere use the scaffold and its honest branch. Bank B and sheet below |
| C. Skeptic | Persistent probing of the gaps | Medium. The hiring-manager prior includes it, and your own stated limits give it material. It sits below A and B because the loop page gives the session two named halves, neither a skeptic's | Rehearse the single most predictable objection until it is boring: C2. Plain words for stated limits, adjacent evidence only at its own scope |
| D. Pressure | Interruptions and time limits during the tabletop | Medium. A live incident invites interruption, but the loop page does not say the interviewer presses | Pause, restate, hold the position the quotes carry through two follow-ups, concede specifically. Bank D |
| E. Data-Driven Prober | Line-by-line probing of the retention numbers | Medium. Retention is a stated requirement, and a metric in your background earns a defend-the-number question. Nothing public says Tobias probes data | Say how the numbers were counted if you know, and say plainly if you do not. Bank E |
| G. Conversational | A friendly opener such as "walk me through the journey" | Low. It will probably open the session and still be scored | A prepared 90-second arc from your quotes. Bank G |
| Peer Evaluator | Seam-splitting between adjacent teams | Low. No bank is built: nothing places a peer in this session. If your answer to the closing question says a peer joins, a bank is added | Not built |

## Question banks

Proposed wording in these tables, pending your approval. Each Provenance cell holds the label first, then every candidate sentence the guidance rests on.

### A. Case / Strategist (weight high, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It is the first hour of a weekend event and the event store will not load for half your players. The community channel is filling up. Walk me through your first thirty minutes." | CASE | [generic] | Structure it aloud. Ask what is affected, since when, and whether a rollback or a fix is possible. Set the objective as protecting players over keeping the schedule, which is the first published value. Name who you pull in from engineering, QA and community, and what you ask each for. Say what players hear and when. Say what you would record for the review afterwards. The question needs no claim about your past, so the guidance makes none | The loop page describes a tabletop on a simulated outage during a live event, so this is the likeliest shape of the first half. CASE because it is a live problem. Generic because it is a pattern, not Saltmarsh's scenario |
| A2 | "Engineering says the fix is two hours out and the event ends tonight. What do you recommend, and write me the two sentences that go to players." | CASE | [generic] | Clarify the cost of each option before choosing: extend, let it end, or make it up to players. Challenge one premise respectfully, such as whether tonight's end time is fixed. Give your recommendation first, then the reason. Then write the two sentences aloud: what is confirmed, what is not, and when the next update comes. Say only what is built, not what is hoped, which is the second published value. Plain beats reassuring | Tests the JD's written-communication line (F8) as a live task instead of a claim, and sits close to the interviewer's published theme (I1). CASE with written delivery |
| A3 | "Project Larkspur moves Tidepool Tactics and Lantern Row to a season pass and one shared events calendar from February 2027. What would you want to know before you drafted the first quarter?" | CO | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Clarify first: which events carry over, how season goals are set, who settles clashes between the two titles' calendars, what players are asked to buy and how that is measured. Then objective, approach, metrics and risks. If the pass's economy comes up, the sourced plain words are: "I haven't worked on a game with in-app purchases." Then say what you would ask or read first, as a plan. The JD does not name the two titles, so do not assume they are these | The announcement is the research's one current-strategy item (Sources, search 3), so this is the CO question. The limit it brushes is P2. CO because it scores company-level thinking, with CASE delivery |
| A4 | "You have one open slot next month and three event ideas, one each from design, art and community. How do you choose?" | CASE | [generic] | Clarify the goal for the slot and what each idea costs each team. State your criteria before choosing, such as player goal, effort, QA capacity and risk. Make the choice with a visible rule. Say what you tell the two teams whose idea waits. Say how the reason is recorded. No claim about your past | The JD's coordination line (F2) is where your material is silent, so it is posed as a decision. CASE because it is a live problem in the role |
| A5 | "Build me a release checklist for an event update. What goes on it, and what would make it fail?" | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Build it aloud in your own structure. If natural, say what the quote carries: you wrote the checklist and QA still uses it. Answer slot: the interviewer may ask what was on yours. If you can name items, do so in your own words; if you do not remember, or it has changed since, say so plainly and stay with the quote's words. The third published value, that every release leaves the checklist better than it found it, is why this question is likely | F4 is the evidence. CASE because it is asked as a build, not a history |

### B. Values / Behavioral (weight high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players pulled in different directions. What won?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold, because no quoted sentence carries this story. Pick a time a planned drop and what players needed pulled apart. It needs a named stake, what you chose, and what you told people. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the weekly content-drop calendar for our main title for the last two years", or how you would decide. Do not supply an ending | The first published value, Players Before Plans. Scaffold because no row's evidence carries a conflict story; F1 holds the nearest sentence |
| B2 | "Tell me about a time you had to say what was and was not ready to ship." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Selection scaffold. Pick a release where readiness was uncertain. It needs a named stake, what you said, and who heard it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "Wrote the release checklist our QA team still uses", or how you would say it | The second published value, Ship the Patch Not the Promise, and the interviewer's published theme (I1). Scaffold because no row's evidence carries a readiness story; F4 holds the nearest sentence |
| B3 | "Tell me about a time you left a checklist or process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F4. The beats the quote states are that you wrote the release checklist and that QA still uses it; tell those in your own words. Answer slot: the third value's wording makes a probe on what was there before and what changed likely. If an earlier version existed, say what you changed; if there was none, or the change was not yours, say so plainly and stay with the checklist you wrote | The third published value, Leave the Build Greener. F4 is the one row that carries a story for a value |
| B4 | "Tell me about a time you gave bad news about a plan, a date or a number to someone senior." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold. Pick a time with a named stake, what you said, and how it landed; the hard truth has to have actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "Presented the monthly retention numbers to the studio head", or how you would deliver it. Whether any number was unwelcome is yours to say, or to say none was | A values conversation commonly asks for an unpopular truth. No row's evidence carries a bad-news story; F7 holds the nearest sentence |

### C. Skeptic (weight medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Pick one requirement in the JD's own words and say what your material does and does not carry for it. Then say what you would do in the first month, as a plan. Two sourced plain acknowledgments are available: "I haven't led a team." and "I haven't worked on a game with in-app purchases." For a requirement where the pack's table shows silence, such as F2, the words are an answer slot: if you worked with any of the four groups, say which; if none, say so plainly. Naming the weakest part before they do is the move | A standard skeptic stem, and it scores the whole JD list. JD because it tests honest self-assessment against the requirements |
| C2 | "I don't see in-app purchases anywhere in your background. Both titles are moving to a season pass — how do you plan a calendar around something you haven't worked on?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Presented the monthly retention numbers to the studio head" | The highest-ROI rehearsal in this pack. Level one: say the limit first, in the sourced plain words, "I haven't worked on a game with in-app purchases." Then say only what your quotes carry, "I ran the weekly content-drop calendar for our main title for the last two years" and "Presented the monthly retention numbers to the studio head", at their own scope. Do not say what they prove about season passes; the interviewer draws that. Level two, "what would you do in your first thirty days": a plan, not a past. What you would ask first, such as what is sold, how it is measured and who decides tuning, and who you would sit with. Level three, "so is this too early for you": concede in your own words that it is a real gap, then stop. Hold the core claim by returning to the calendar you ran, never by adding to it | P2 is a negative you stated, and the announced season pass puts it at the centre of the company's direction, so this objection will arrive in some form. JD because it scores fit to the role's direction. It gets the most follow-up levels and a named limit before it is asked for |
| C3 | "Tell me about a time you got design, art, engineering and community onto the same update date." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses" | Selection scaffold, because no quoted sentence carries cross-team coordination (F2). Pick a named update, which of the four groups you worked with, and what you did yourself. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the weekly calendar you ran or the checklist QA uses, or how you would do it. Do not name a team you did not work with | The JD's coordination line is F2, where the material is silent. JD because it scores a stated responsibility |

### D. Pressure (weight medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a producer who has already run live events for two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses" | Restate the question and pause. Hold only what the quotes carry: "I ran the weekly content-drop calendar for our main title for the last two years" and "Wrote the release checklist our QA team still uses". Hold through two follow-ups by returning to those sentences, never adding to them. If pushed, the sourced concession is "I haven't worked on a game with in-app purchases." You have stated no other absence, so the pack supplies none. Answer slot: if you ran any drops as events, or worked on more than one title, say so; if not, say so plainly and stay with the weekly calendar | A pressure stem aimed at F1 and F4, where the material is narrower than the JD. JD because it scores the stated requirement |
| D2 | "That calendar — how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold the sentence you said: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's "plan and run" makes a probe on which part was yours likely. If you planned part of it, say which part, in your own words; if the plan was set by others and you ran it, say so plainly and stay with the weekly calendar. Hold through two follow-ups, then concede any uncertainty specifically, without folding on the core sentence | The standard attribution probe, aimed at F6 and F1. EXP because it tests what was actually yours |
| D3 | "Stop — ninety seconds. Mid-incident, what do you tell the players?" | CASE | [generic] | Pause, restate the question, and answer in order: what is confirmed, what is not known yet, and when you will update next. Say only what is built, not what is hoped. If interrupted again, return to the same three beats. Concede an unknown specifically rather than filling it. No claim about your past | The tabletop pressure case, tied to the second published value. Generic because it is a pattern for the problem |

### E. Data-Driven Prober (weight medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through how the monthly retention numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what the quote says: you presented the monthly retention numbers to the studio head. Answer slot: if you know how they were counted, say so in your own words, and name the assumption behind them you would defend least. If you do not know, or someone else produced them, say so plainly and stay with presenting them | F7 is the evidence, and you gave no figure, so the pack supplies no method. EXP because it tests whether you know your own numbers |
| E2 | "Tell me about a time a retention number changed what you did with the calendar." | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold, because no quoted sentence carries this story. Pick a time with the number, what you changed, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "Presented the monthly retention numbers to the studio head", or how you would use the number | The JD's retention line, F7, and its KPI line, F3. JD because it scores a stated requirement |
| E3 | "After a weekend event ends, what do you review, and what would you report as the KPIs?" | CASE | [generic] | Structure it aloud: the event's objective, the metrics chosen before launch, the baseline you compare to, what you would conclude, and what you would change next time. Say how you would write it up for people who were not in the room. No claim about your past | The JD's post-event review line, F3, as a live problem. Generic because it is a pattern for the problem |

### G. Conversational (weight low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc built from the beats the quotes state: four years as an associate producer at a puzzle-game studio, the last two running the weekly content-drop calendar for the main title, the release checklist QA still uses, and the monthly retention numbers presented to the studio head. Close with one published value or the announced move you genuinely reacted to, in your own words. The pack cannot supply your reason | The opener is scored. F5 and F6 are the evidence. EXP because it is the CV in sequence |
| G2 | "What are you actually playing with in live events these days?" | JD | [generic] | Name one live event you actually saw in a game you play, one thing it did well and one thing you would change. If you do not follow any, say so plainly and name how you would study them. No claim about your past | A casual question on a hot JD topic, and still scored. Generic because it asks for your own current observation |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 live-events calendar for two titles | A3, A4, D1, D2 |
| F2 coordinating design, art, engineering and community | A1, A4, C3 |
| F3 post-event review and KPIs | A1, E2, E3 |
| F4 release checklist with QA | A5, B2, B3 |
| F5 3+ years producing live-service | C1, D1, G1 |
| F6 running a content calendar | D2, G1 |
| F7 player-retention metrics | B4, E1, E2, E3 |
| F8 clear written communication | A2 |

## Values cheat sheet

Saltmarsh's interviewing page names a values conversation, so this sheet applies.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold, ending in its honest branch: pick a time a planned drop and what players needed pulled apart, with a named stake and what you chose. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, F1: "I ran the weekly content-drop calendar for our main title for the last two years", or how you would decide |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold, ending in its honest branch: pick a release where readiness was uncertain. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, F4: "Wrote the release checklist our QA team still uses", or how you would say it |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses". The beats the quote states are that you wrote it and QA still uses it; B3 holds the answer slot |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "Your GDC talk argued a live team is judged by how often its patch notes describe what actually shipped. What does the team check before a patch note goes out?" | Ties to his own published work (I1) and reads as diligence on the second value | [grounded] |
| R2 | "You came to live operations from QA. What did that change about how you run a release?" | Ties to his own path (I2) and invites the story he is likely to enjoy telling | [grounded] |
| R3 | "Are the two titles in this role the two in Project Larkspur?" | The JD does not name them, and the answer fixes the scope you would plan for | [grounded] |
| R4 | "I read that Project Larkspur moves to a single live-ops group. Where would this role sit in it, and who would I work with day to day?" | Shows you read the announcement and asks the question that decides the coordination load | [grounded] |
| R5 | "Who reads the post-event review, and what has it changed on a past event?" | Tests the KPI line of the JD and shows you think about what the review is for | [generic] |
| R6 | "What would you want a new producer to have learned in the first ninety days?" | Gives your ramp plan a target, which matters most where your background is thinnest (P2) | [generic] |

## Prohibited claims

Built before the banks. No answer slot, hold, bridge or rationale asserts, softens or implies these.

| # | Not coached | Basis | Honest form |
|---|---|---|---|
| P1 | Has led a team | Negative you stated: "Never led a team, and never worked on a game with in-app purchases" — your message | The plain acknowledgment: "I haven't led a team." No slot |
| P2 | Has worked on a game with in-app purchases, including a season pass | Negative you stated, same sentence | The plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, never a past. No slot |
| P3 | Ran live events for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says the weekly content-drop calendar for the main title. Slots D1 and D2 stay inside the calendar |
| P4 | Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The material says presenting the monthly numbers. E1 asks only how they were counted and which part was yours |
| P5 | Managed the release checklist release after release | Inflated form of F4 | F4's quote at its own scope. The material says you wrote it and QA still uses it. A5 and B3 stay with the checklist as written |
| P6 | Four years producing a live-service game | Inflated form of F5 | F5's two quotes at their own scope. The material says four years as an associate producer, and two of them on the weekly calendar |

## Sources

Provided: the JD as pasted in your message, and your background summary as written in your message. No tuesday-dossier.md was present.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | The values cheat sheet: three values by official name, and the VAL bank's themes |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop structure: one 60-minute session with a tabletop then a values conversation. Persona weights follow it, and no take-home means no deliverable section |
| 3. `Saltmarsh Games strategy / recent news` | yes | A3 and reverse questions R3 and R4. The result was a snippet and the page was not read, so every use stays at the snippet's words |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | The interviewer read and reverse questions R1 and R2. Snippet only, and the page was not read |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

| Call | Query or URL | What came back |
|---|---|---|
| Search 1 | `Saltmarsh Games values` | https://saltmarshgames.com/values |
| Search 2 | `Saltmarsh Games interview process live operations producer` | https://saltmarshgames.com/careers/interviewing |
| Search 3 | `Saltmarsh Games strategy news mobile` | https://saltmarshgames.com/news/project-larkspur. Snippet: September 2026, Project Larkspur moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027, and retires per-title event teams in favour of a single live-ops group |
| Search 4 | `Tobias Wrenfield Saltmarsh Games` | https://talks.gdconf.example/2026/patch-notes-are-a-promise. Snippet only |
| Fetch 1 | https://saltmarshgames.com/values | The three values and their one-line definitions |
| Fetch 2 | https://saltmarshgames.com/careers/interviewing | The loop description quoted at the top |

## Upgrade menu

- Whether Tobias is the hiring manager running your Outage Hour → confirms the persona weights, or moves them
- Anything the recruiter said about what the tabletop covers → coverage currently rests on the interviewing page alone
- Your prep time before the interview → a prioritized schedule, which this pack omits without it
- Your answers to the answer slots in F1, F2, F3, F4, F5 and F8 → those transferability and discovery rows regenerate with your own quoted words
- The release checklist itself, or a redacted page of a calendar or a retention report you presented → F4, F6 and F7 could rise from medium to high
- A tuesday-dossier.md from an earlier assessment of this role, if one exists → verified evidence and sourced limits would replace several inferences here
