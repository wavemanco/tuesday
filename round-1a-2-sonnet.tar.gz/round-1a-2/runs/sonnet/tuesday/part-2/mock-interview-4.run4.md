Search permission was denied, so I'm building the pack from your dossier alone and writing it to a file now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/tuesday/part-2/rooms/case-4-denied-8d30895d/quartzline_product-manager-platform-apis_interview_pack.md`. I built it for the 45-minute hiring-manager conversation you described, from your dossier alone.

It has 22 questions, six reverse questions, a table mapping each requirement to its questions, and a list of claims the pack won't coach.

My three web searches (Quartzline values, interview process, strategy) were refused. Nothing in the pack about Quartzline itself is researched, so the "what do you know about Quartzline" question (A5) is generic. Read Quartzline's public docs and changelog before Thursday so you can answer it with things you've actually read.

B1 is the most important thing to rehearse. It's the objection your underwriting named: no PM title, no roadmap, so why you over someone with three years in the job. P1 is the same question with a 60-second limit. The rehearsed shape is:
- Concede first, in your own words: you haven't held the PM title or owned a roadmap.
- Then state the 30+ integrations at the scope the dossier gives.
- Then give a ramp plan.

The pack coaches nothing from the dossier's `prohibited_claims` list (PM title, roadmap ownership, squad prioritization). Two bridges you might expect it to coach aren't there:
- **Roadmap ownership:** the roadmap-input sessions don't count as roadmap ownership, so there's no bridge for it.
- **R2, "Shipped API or platform products":** your dossier doesn't flag this one, but the evidence is client integrations of the vendor's APIs, not a shipped product. I graded it as a gap myself, so treat that as my call.

Say the word and I'll play the Skeptic on B1, or the time-boxed version on P1.
I can also save an updated `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: hiring-manager conversation, 45 minutes, Thursday (your message). Interviewer: hiring manager, name not given. Session mode, one conversation.

Built on your `tuesday-dossier.md` (conditional_go). The dossier's two conditions run through the whole pack: the bridge is positioned as adjacent and never as PM experience, and the squad-authority question gets asked live.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows good judgment under a values-style prompt |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you have done your homework on the company |
| CASE | Structure and reasoning on a live problem from the role |

The highest-ROI rehearsal in this pack is B1. The underwriter named that objection, and P1 is its time-boxed twin. Rehearse those two until they are boring.

## Fit snapshot

Requirement text comes from the dossier's `role_profile`. Evidence is quoted from the dossier's `handoff_to_mock_interview.verified_candidate_evidence`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff | low | [inferred] | transferability | Positioned as adjacent, never as PM experience, as the underwriter framed it. The words stay at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." The limit is the plain acknowledgment, sourced from `prohibited_claims`: "Having held a product manager title or role", so the words are "I haven't held a product manager title or role." Let the interviewer draw any inference about transfer; do not assert one |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibility; the handoff files this as the R1 sub-claim | none given | none | [grounded] | capability | The underwriter's `acknowledge_gap` area is "Owning a roadmap and prioritization authority (R1 sub-claim)", with no evidence found. The strategy is a plain acknowledgment plus a ramp plan, never a bridge. Words: "I haven't owned a product roadmap." (`prohibited_claims`: "Having owned a product roadmap"). The ramp plan is a plan, not a past: what you would learn first and whom you would ask, in your own words. No answer slot |
| F3 | "Shipped API or platform products" — dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff | low | [inferred] | transferability | Your material says client integrations of the vendor's REST APIs, not an API or platform product. The underwriter's weak-area list does not include R2, so this grading is the pack's own call from the quote. Words stay at the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: the requirement makes a probe on your decisions inside those integrations likely. If you set any of scoping, requirements, architecture, UAT or go-live, say which and how you decided, in your own words; if none was yours to set, say so plainly and describe how you led them |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff; "Wrote the internal integration playbook her team uses" — dossier handoff | low | [inferred] | discovery | The quotes touch technical work without showing whether API docs or schemas were part of it. Answer slot: if you worked from API docs or schemas in those integrations, say how, in your own words; if you did not, say so plainly and say what you would read first in Quartzline's own docs. The playbook is the one inspectable artifact the dossier marks, so be ready to say what is in it |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier handoff | medium | [inferred] | discovery | The sessions are confirmed with limited inspectable proof, so expect a probe and volunteer the limit before it is extracted. Words at the quote's scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot: the requirement names engineering, sales and customers, so expect a probe on each. For any you worked with in those integrations or sessions, say how, in your own words; for any you did not, say so plainly and stay with the integrations and sessions as quoted |
| F6 | "Agile delivery experience" — dossier role_profile R5, preferred | none given | low | [grounded] | discovery | The underwriter's strategy for "Agile delivery inside a product org (R5)" is `clarify`, and no verified entry speaks to it, so nothing about your past goes in the answer unless you say it. Answer slot: expect the probe in the requirement's own wording, "Agile delivery experience". If you have worked that way, say how you define it and what your part was, in your own words; if you have not, say so plainly, and say what you would want to confirm about how Quartzline's squads define it |

## Persona table

The round is a hiring-manager conversation (your message), so relationship priors set the weights. No interviewer profile and no loop source beyond your own words exist, so nothing adjusts them. Depth follows weight: 5, 3 or 2 questions.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (B) | Quiet probing of the no-PM-title, no-roadmap gap | High: the hiring-manager prior, plus the underwriter's named objection (F1, F2) | Rehearse B1 until it is boring; name the limit before it is asked for |
| Case/Strategist (A) | Live problems from the actual role | High: the hiring-manager prior; the role covers roadmap, partner discovery, two squads and adoption metrics | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise; answer roadmap cases in the conditional ("I would"), never in the past tense |
| Data-Driven Prober (C) | Reads the integration claim line by line | Medium: the one headline figure is the 30+ in F1 | Know how it was counted; name the assumption you would defend least; say plainly what you do not know |
| Conversational (D) | Friendly opener about the journey; casual questions are still scored | Medium: a 45-minute conversation usually opens this way | A 90-second arc built only from your quoted sentences (D1) |
| Peer Evaluator (E) | Seam between PM and squad leads; credit | Low: the interviewer is a manager, but the squad-lead seam is an open risk in the dossier | Offer seam principles, not a claim to know the seam; say plainly what you did and what others did |
| Pressure (P) | Time-boxed, devil's advocate | Low: no signal either way; included because B1 will likely arrive time-boxed | Pause, restate, hold two follow-ups, concede only specifically |
| Values/Behavioral (V) | Scenario probes | Low: no published values were read and no values-style round is documented | Selection scaffolds with the honest branch |

## Question banks

### A. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Partners tell us onboarding to the API takes too long. How would you find out why, and what would you do?" | CASE | [generic] | Clarify first: what "too long" is measured from and to, and for which partners. Then state the objective, segment before you diagnose, list hypotheses, say how you would test each, name the metric you would watch, and name one risk. Challenge one premise respectfully, for example whether onboarding time is the right problem. The question needs no claim about your past, so the guidance makes none | A live problem from the partner-facing scope and the partner-discovery responsibility; CASE because it scores structure; high weight from the hiring-manager prior |
| A2 | "Partners are asking for more than the two squads can build next quarter. How do you decide what goes on the roadmap?" | CASE | [generic] | Open with decision rights: ask who decides what between the PM and the squad leads, since the dossier lists that as unevidenced. Then criteria, the evidence you would use, how you would take the trade-off to partners and squads, and what you would say no to. Speak in the conditional: "I would". Your material shows no roadmap ownership (F2), so a past-tense answer here would imply a claim section 13 lists | Targets the roadmap and two-squad responsibilities, the area where the underwriter found nothing to bridge; CASE because the prompt is hypothetical |
| A3 | "Adoption of the API drops 20 percent quarter over quarter. Walk me through your diagnosis." | CASE | [generic] | State what "adopted" means before you diagnose; the dossier lists how adoption is measured today as unknown, so asking is part of the answer. Then separate a real drop from a measurement change, segment before you explain, and say what you would check first and why. Name your own metrics; this pack does not supply them | The adoption-metrics responsibility has no baseline in the dossier; CASE because it scores structured diagnosis |
| A4 | "Running discovery with integration partners is part of the job. How would you start in your first sixty days?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | A plan, not a past: who you would talk to, what you would want to learn first, and how you would turn it into evidence for decisions that are not only yours. The one past fact is the quote, at its scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." The dossier marks it confirmed with limited inspectable proof, so say what the sessions were before you are asked for proof. Do not call it discovery ownership | R4's only medium-confidence evidence (F5) is relevant here and is where a prober will press; JD because it scores a stated responsibility, CASE delivery |
| A5 | "What do you know about Quartzline's platform today, and where would you push it?" | CO | [generic] | This pack could not research Quartzline (see Sources), so every platform fact has to come from your own reading of Quartzline's public docs and changelog before Thursday. Bring two things you actually read, say where you are inferring, and end on a question rather than a bold claim. No claim about your past | The CO slot, left generic because research was refused; it becomes grounded if you add Quartzline material (upgrade menu) |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; `prohibited_claims`: "Having held a product manager title or role"; `prohibited_claims`: "Having owned a product roadmap"; `acknowledge_gap` area: "Owning a roadmap and prioritization authority (R1 sub-claim)" | The underwriter named this objection, so it is the highest-ROI prep in the pack. Steps: (1) Pause and restate the question in your own words. (2) Concede first and specifically: "I haven't held a product manager title or role, and I haven't owned a product roadmap." (3) Say what you have, at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Stop there and let the interviewer draw the inference; do not tell them it proves you can do the job. (4) Give the ramp plan as a plan: "In the first weeks I would learn which decisions are the PM's and which sit with the squad leads, and how adoption is measured today." Follow-ups to rehearse; hold through two before conceding anything beyond the sourced items. Follow-up one, "What did you actually decide in those integrations?": answer slot: if you set any of scoping, requirements, architecture, UAT or go-live, say which and how you decided; if none was yours to set, say so plainly and describe how you led them. Follow-up two, "Why not the PM with three years?": do not compare yourself; return to the quote and the ramp plan. Follow-up three, "What would you get wrong first?": answer slot: name it in your own words from what you know you have not done; the sourced gap is roadmap ownership and prioritization authority | The dossier's named objection, asked as written because each negative in it has a sourced field; JD because it scores R1, with EXP overtones. Deepest bank item: most follow-up levels, exact concession wording, limit named before it is requested |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] `acknowledge_gap` area: "Owning a roadmap and prioritization authority (R1 sub-claim)" | Name it plainly and early: "The part I haven't done is owning a roadmap and prioritization authority." Then the ramp plan, in your own words, as a plan. Do not volunteer agile delivery as a weakness unless you know it is one: the dossier marks it as unestablished (F6), and your honest answer there may be a question about how the squads work | The persona stem for the Skeptic; candid self-assessment is what is scored, and F2 is the underwriter's named gap |
| B3 | "Tell me about an API or platform product you shipped." | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Start from what the quote carries and no more: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Your material says client integrations of the vendor's REST APIs, not an API or platform product, so do not describe them as one. Answer slot: the requirement makes a probe on your decisions inside them likely. If you set any of those stages, say which and how you decided; if none was yours to set, say so plainly and describe how you led them | R2 is a must-have (F3) and the likeliest second probe after B1; JD because it scores a stated requirement |
| B4 | "Tell me about a time you had to align engineering, sales and a customer who wanted different things." | JD | [inferred] "Ran quarterly roadmap-input sessions feeding client evidence to product" | An open prompt, so choose an instance. Selection criteria: named parties on each side, a decision, whether the decision was yours, and an intact relationship at the end. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I ran quarterly roadmap-input sessions feeding client evidence to product", with its limited-proof caveat named, or say how you would handle it | R4 names three stakeholder groups (F5); JD because it scores the requirement, behavioral in shape |
| B5 | "How do you define agile delivery, and when have you worked that way?" | JD | [grounded] | The dossier carries no verified entry for this requirement, so nothing about your past goes in the answer unless you say it. Answer slot: the probe arrives in the requirement's own wording, "Agile delivery experience". If you have worked that way, say how you define it and what your part was, in your own words; if you have not, say so plainly, and say what you would want to confirm about how Quartzline's squads define it | The underwriter's `clarify` area (F6); JD because it scores a preferred requirement. The question asks for your definition first, so it is safe to answer honestly either way |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say 30+ client integrations — how was that counted, and which part of each was yours?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on F1: the beats are the ones the quote states, led, end to end, scoping, requirements, architecture, UAT, go-live; tell them in your own words. The figure raises four slots, each in your own words: how an integration was counted, what the 30+ is sensitive to, the assumption you would defend least (name it before they do), and which part was yours. If you do not know how it was counted, say so plainly | The 30+ is the one headline figure, so it gets the defend-the-number question; the dossier grades the claim high and inspectable (F1) |
| C2 | "Walk me through the integration playbook you wrote." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Story-mapped on F4: you wrote it and the team uses it, so "I wrote the internal integration playbook my team uses." Answer slot: expect a probe on what is in it and how the team uses it. If you know, say so in your own words; if you do not, or it is not tracked, say so plainly and stay with the fact that you wrote it. It is graded high and inspectable, so be ready to say what is in it | The playbook is the inspectable artifact behind the integration claim; EXP because it tests what was actually yours |
| C3 | "When you look at an API's docs and schema, what tells you a partner could integrate without hand-holding?" | JD | [generic] | Give your own criteria, in your own words; the pack supplies none. Answer slot: if you worked from API docs or schemas in your integrations, say how; if you did not, say so plainly and say what you would read first in Quartzline's own docs | R3 is important and needs a rehearsed answer (F4); JD because it scores a stated requirement |

### D. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey. How did you end up here?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, each only as quoted: you led the integrations; you wrote the playbook your team uses; you ran the quarterly roadmap-input sessions, with the limited-proof caveat named. State the limit in one clause: "I haven't held a product manager title or role" (`prohibited_claims`: "Having held a product manager title or role"). Answer slot: why this role and why now, in your own words; the pack supplies no reason | Persona stem for the opener; casual questions are scored, and F1, F4 and F5 hold the only quotes the arc may use |
| D2 | "What have you been reading or trying in the API world lately?" | JD | [generic] | Pick something you actually read or tried, such as a spec, a doc set or a changelog; name it and give one opinion. If nothing comes to mind, say so plainly and say what you would look at first | The casual form of the technical-fluency check (F4); a rapport-style question that is still scored |
| D3 | "What has pulled you toward owning a product rather than working on integrations?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Give your own reason; the pack supplies none and will not write one. Anchor with the quote at its scope, then your reason, then stop. Do not describe your integration work as product ownership | Motivation consistency, the question the dossier's objection invites in softer form |

### E. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our squad leads and the PM share this roadmap. Where is the seam, and what happens when you disagree?" | JD | [inferred] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Offer seam principles, not a claim to know the seam: decision rights written down, who owns the what and the how, how a disagreement is escalated. Then ask the dossier's own question: which roadmap decisions this PM makes alone and which belong to the squad leads. For what you bring the squads, the only quote is "I ran quarterly roadmap-input sessions feeding client evidence to product", with its caveat. If a disagreement with an engineering lead comes to mind, tell it with what you wanted, what they wanted and what happened; if none does, say so plainly and say how you would handle it. Never imply prioritization authority | The dossier's open risk about squad-lead authority (F2); JD because it scores the two-squad delivery responsibility |
| E2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | "We" for context, "I" for contribution: "I wrote the internal integration playbook my team uses." Say who else contributed, in your own words, if anyone did; if nobody did, say so plainly. Do not enlarge your share | Persona stem; the playbook is the one sentence that names a team |

### P. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; `prohibited_claims`: "Having held a product manager title or role"; `prohibited_claims`: "Having owned a product roadmap" | The time-boxed form of B1. Pause, restate, then in order: the concession, "I haven't held a product manager title or role, and I haven't owned a product roadmap"; the quote, "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; the ramp plan as a plan. Hold through two follow-ups by returning to the quote, never by adding to it. Concede only the sourced items | B1 will likely arrive in this register, so rehearse the same content against a clock |
| P2 | "That 30+ — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the position the quote carries: "I led them." Hold through two follow-ups. Answer slot: if some stages in the quote were the team's rather than yours, say which, plainly and specifically, and return to the ones that were yours; if all were yours, say so and describe how you led them. Never fold on the quote just to restore harmony, and never add to it | Persona stem for attribution probes; EXP because it tests what was actually yours (F1) |

### V. Values/Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: a named stake, the truth you told, who it was unwelcome to, and an intact relationship at the end. Choose a story in which the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or say how you would handle it | Persona stem; low weight because no values source was read and no values-style round is documented |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: the metric, what it cost to set it aside, what the customer got, and whether you were right. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or say how you would handle it | Persona stem; customer-facing integration work makes it plausible even without a values source |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1 "3+ years product management experience" | B1, B2, P1, D1, D3 |
| R1 sub-claim: own the roadmap | A2, B1, B2, E1 |
| R2 "Shipped API or platform products" | B3, C1, P2 |
| R3 "Technical fluency: API docs, schemas" | C3, D2, C2 |
| R4 "Stakeholder management across engineering, sales, customers" | B4, A4, E1, E2 |
| R5 "Agile delivery experience" | B5 |
| Responsibility: define and track adoption metrics | A3 |
| Responsibility: run discovery with integration partners | A4 |
| Responsibility: write specs and drive delivery with two engineering squads | A2, E1 for the delivery side; spec-writing is none, because no quoted sentence speaks to it and it is a responsibility line rather than a requirement |

## Reverse questions

| # | Question | Why it lands | Source |
|---|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Answers the dossier's open risk that decision authority versus the two squad leads is asserted but not evidenced; it reads as diligence and tells you what you would be accepting | Dossier `questions_for_employer` |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | Answers the dossier's open risk that adoption metrics are a named responsibility with no stated baseline; a baseline is what you would be judged against | Dossier `questions_for_employer` |
| 3 | "How do the two squads work day to day, and what does agile delivery mean here?" | Turns the `clarify` area (F6) into diligence and lets you answer the preferred requirement against their definition, not yours | Pack, from F6 |
| 4 | "How do partners' needs reach the roadmap today, and where does that path break down?" | Shows you think about discovery as a pipeline; the answer shows where your integration-side experience would be most useful | Pack, from A4 |
| 5 | "What would a strong first quarter look like for this PM?" | Makes the manager state the success criteria you will be held to, and gives your ramp plan something to attach to | Pack |
| 6 | "What would make you hesitate about hiring someone from outside a PM title, and what would close that for you?" | Names the B1 objection yourself and lets you answer it against the manager's own criteria, instead of your guess | Pack, from the dossier's named objection |

## Prohibited claims

Not coached anywhere in this pack: no guidance, slot, hold, bridge or reverse question asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | The F1 quote at its own scope, plus the plain acknowledgment: "I haven't held a product manager title or role." No slot |
| Having owned a product roadmap | Dossier `prohibited_claims` and the `acknowledge_gap` area "Owning a roadmap and prioritization authority (R1 sub-claim)" | The plain acknowledgment: "I haven't owned a product roadmap." Then a ramp plan as a plan. No bridge and no slot |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | The plain acknowledgment: "I haven't set prioritization for an engineering squad." No bridge and no slot |
| Shaping or influencing the roadmap through the roadmap-input sessions | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation, not words for you: the material says sessions feeding client evidence to product, not what product did with it |
| Having shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says client integrations of the vendor's REST APIs. B3's slot stays inside the integrations' stages |

## Sources

Provided documents: `tuesday-dossier.md`, dossier_version 1.1, generated by job-underwriter on 2026-08-14. Consumed: `role_profile` (requirement and responsibility text as the JD's lines), `handoff_to_mock_interview` (all fields: verified evidence, weak areas with strategies, the named objection, risks, employer questions, prohibited claims), `decision` (context only). Not present in the dossier: `evidence_map`, `risk_register`, `evidence_state`, so the fit snapshot's grading comes from the handoff, and where the pack graded a row itself (F3 to F5) it says so. Round type and length: your message.

Searches sent, each refused (search permission was not granted):

- `Quartzline company values` — refused
- `Quartzline interview process product manager` — refused
- `Quartzline API platform strategy news` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Every call was refused. It would have supplied official value names for VAL themes and a values cheat sheet (only if a values-style round were also documented) |
| 2. `Quartzline interview process product manager` | unavailable | Every call was refused. It would have fixed the loop structure and persona weights; weights rest on the hiring-manager prior and your own words |
| 3. `Quartzline strategy` / recent news | unavailable | Every call was refused. It would have grounded A5 and the CO and CASE questions in current priorities; they are labeled generic |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` supplies the requirements and responsibilities that fix the fit snapshot and JD-tagged questions |

## Upgrade menu

- Interviewer's name and public profile → an interviewer read, persona weights tuned to their footprint, and a reverse question tied to their own path
- Recruiter or HR guidance on focus areas or any pre-declared deliverable → coverage of that deliverable and sharper persona weights
- Quartzline's values page, loop description or a strategy brief pasted in, or search permission granted → A5 and the CO and CASE rows become grounded, and a values cheat sheet appears if a values round is documented
- Deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, covering a strategy brief, the interviewer's talks and writing, role-family loop reports and recent org context
- Your own words on the answer slots in F3 to F6 → those rows and the questions built on them (A4, B3, B4, B5, C2, C3, E1, P2) become story-mapped instead of slotted
- An artifact behind the roadmap-input sessions, such as an agenda or the written output that went to product → raises F5 from medium toward high and gives B4 and A4 something inspectable
- The raw CV behind the confirmed claims → checks the quotes against your own wording and may add rows
- Prep time available → a prioritized prep schedule sized to it
