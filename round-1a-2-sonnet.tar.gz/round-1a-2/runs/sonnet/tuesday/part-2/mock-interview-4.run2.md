Web search was refused, so I'm building the pack from your dossier alone. I'll say so in the pack's Sources section. Writing the pack file now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/tuesday/part-2/rooms/case-4-denied-b49ad98f/quartzline_product-manager-platform-apis_interview_pack.md`. I built it for a hiring-manager round, as you described, with 23 questions across seven personas. Skeptic and Case/Strategist carry the most weight.

- **No company research:** web search was refused, so all three Quartzline searches failed. The pack rests on your dossier alone. Values, loop structure and company strategy are not covered, and the Case questions are generic.
- **Top rehearsal:** A1 is the question the underwriter named, your lack of the PM title and a roadmap. The pack has you concede both limits first, bridge only to what the dossier verified, and then give a ramp plan.
- **R2 gap:** "Shipped API or platform products" is a must-have, but the dossier's weak-areas list doesn't cover it. I graded it myself as adjacent only (F3, A4). Expect it as the second probe after A1.
- **Seven years:** that figure appears only in the dossier's decision summary, not in any verified entry. The pack leaves tenure for you to state in your own words.

Say the word and I'll play the Skeptic on A1 as a live drill.
I can also save an updated `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview pack: Product Manager, Platform APIs at Quartzline

- Role: Product Manager, Platform APIs, Quartzline
- Round: one 45-minute conversation with the hiring manager (name not given)
- Highest-ROI prep: A1. The underwriter named this objection in your dossier, so it gets the deepest rehearsal in the pack.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your experience claims survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now. You answer it in your own words from your own experience. Either branch is a good answer, including "that was not mine" or "that never existed".

## Fit snapshot

F1, F2 and F6 carry the underwriter's grading from the dossier's weak-areas list. The dossier does not grade R2, R3 or R4, so F3, F4 and F5 are graded here.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified evidence 2 | low | [inferred] | transferability | Confidence is the underwriter's grade for R1. The bridge is adjacent work, positioned as adjacent and never as product management experience, at the quotes' own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs" and "I wrote the internal integration playbook my team uses". The pack's observation: your material shows integration leadership and a playbook, not the role the years line asks for. Plain acknowledgment, sourced to prohibited_claims "Having held a product manager title or role": "I haven't held a product manager title or role." |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities, the R1 sub-claim | none given | none | [grounded] | capability | The dossier records this as an acknowledge_gap area, so no bridge is coached. Words, sourced to prohibited_claims "Having owned a product roadmap" and prohibited_claims "Having set prioritization for an engineering squad": "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then how you would learn it, said as a plan and never as a past. No answer slot |
| F3 | "Shipped API or platform products" — dossier R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | low | [inferred] | transferability | Your material says client integrations of the vendor's APIs, not a product shipped, and the words stay at the integrations: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: the JD's second must-have makes a probe on your side of the APIs likely. If any stage of those integrations was yours to set, say which and how you decided; if there was no such step, or the APIs themselves were someone else's work, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified evidence 2 | low | [inferred] | discovery | The quotes touch technical work on REST APIs and do not show whether it reached API docs or schemas. Answer slot: the JD's wording makes a probe on which docs or schemas you worked from likely. If any were yours to read or write, say which and what you did with them, in your own words; if none were, say so plainly and stay with the architecture stage the quote names |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence 3 | medium | [grounded] | transferability | Medium because the roadmap-input sessions are confirmed with limited inspectable proof, so expect a probe and volunteer the limit first. The words stay at the quotes: client integrations and sessions that fed client evidence to product. The pack's observation: the quotes carry the client side and the feed to product, not engineering and sales as the JD names them. Answer slot: if you worked with engineering or sales on these integrations, say how, in your own words; if not, say so plainly and stay with the client side |
| F6 | "Agile delivery experience" — dossier R5, preferred | none given | low | [grounded] | discovery | The dossier marks this area clarify, and no verified entry speaks to it. Answer slot: the JD's wording makes a probe on how you have worked in agile delivery likely. If you have, say where and what your part was; if you never worked that way, say so plainly and say what you would want to confirm about how this team defines it |

## Persona table

Weights start from the hiring-manager prior: Case/Strategist and Skeptic dominate, because a hiring manager is buying capability and checking gaps. No interviewer profile exists, so no signal adjusts them. Your own words establish one session with one interviewer, so no loop rounds adjust them either. Depth follows weight: top personas get five questions, middle three, low two.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Skeptic | Quiet, persistent probing of the PM-title and roadmap gap, and of why you want this move now | High. The hiring-manager prior, plus the underwriter's named objection (F1, F2) | Rehearse A1 until it is boring: concede the two limits first, then the bridge at the quotes' scope, then the ramp plan | A |
| Case/Strategist | Live problems from the role: roadmap trade-offs, adoption diagnosis, partner discovery | High. The hiring-manager prior, and the JD's own responsibilities are case material | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully | B |
| Data-Driven Prober | Reads your claims line by line, asks how the 30+ was counted and what the playbook holds | Medium. The headline number and the medium-confidence sessions invite it | Know what you can and cannot say about how each claim was counted; say plainly when you do not know | C |
| Conversational | Opens with the biography question, then casual questions on JD topics | Medium. Most hiring-manager conversations open this way and it is still scored | A 90-second arc built only from your confirmed sentences | D |
| Peer Evaluator | The squad leads' seam, framed as a collaboration scenario | Medium. The JD's two squads and the unresolved authority question put the seam in play, though the interviewer is not a peer | Propose seam principles rather than pretending to know the seam; say what you bring the squads | E |
| Pressure | Time-boxes you on the objection, asks how much of a result was you | Low. Possible on A1 and the 30+ claim, but not a hiring-manager default | Hold the bridge through two follow-ups, concede specifically, never fold on what the quote states | G |
| Values/Behavioral | Behavioral prompts such as unpopular truths and customer-over-metric | Low. No source names a values round, so these are generic rehearsal | Choose stories where the hard truth landed; where none comes to mind, say so | H |

Bank letters skip F so they never collide with fit-snapshot rows.

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses". The Question's two negatives rest on prohibited_claims "Having held a product manager title or role" and prohibited_claims "Having owned a product roadmap" | The underwriter named this objection, so it gets the most follow-up levels. Four beats. One, concede first: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Two, bridge at the quotes' scope: "What I have done is lead 30+ end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live, and write the integration playbook my team uses." Three, name the limit before it is asked for: "That is adjacent work, not product management, and I'm not presenting it as the same thing." Four, a ramp as a plan and never a past: "In the first weeks I'd want to learn which roadmap decisions are mine and which belong to the squad leads, and I'd ask that directly." Follow-ups: asked why not the PM with three years, return to beat two and say what the adjacent work covers and no more. Asked for your weakest area, repeat beat one without softening. Pressed a third time for a roadmap track record, hold beat one. Do not offer anything else in its place | F1 and F2 are where the role's seat presses hardest, so this objection arrives in some form. JD because it scores the stated years requirement; the Skeptic delivery is why it is phrased as a challenge |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] uncertain_or_weak_areas (acknowledge_gap) "Owning a roadmap and prioritization authority (R1 sub-claim)"; prohibited_claims "Having owned a product roadmap"; prohibited_claims "Having set prioritization for an engineering squad" | Answer the question asked, plainly and first: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then the ramp, as a plan: how you would find out where the decision lines sit, and what you would do in your first thirty days to learn the roadmap, in your own words. Do not pivot to adjacent work in this answer: the underwriter found nothing to bridge with, and a bridge improvised live is the one that gets pulled apart | F2 is the acknowledge_gap row, so the honest answer is the acknowledgment plus a plan. JD because it asks about the listed responsibilities |
| A3 | "Tell me about a time you worked inside an agile delivery process." | JD | [grounded] the JD line "Agile delivery experience" (dossier role_profile R5) | No quoted sentence speaks to this requirement, so there is no story to map. Answer slot: the JD's "Agile delivery experience" line makes a probe on how you have worked likely. If you have worked in an agile delivery process, say where and what your part was, in your own words; if you have not worked that way, or it was not yours, say so plainly. Either branch can end with the clarifying question, in your own words: what the team means by agile delivery across its two squads, and what cadence you would be joining | F6 is the clarify row. JD because it scores a stated preferred requirement |
| A4 | "What part of shipping an API product have you owned yourself?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The hold is only what the quote carries: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live." Answer slot: the JD's second must-have makes a probe on your side of the APIs likely. If any stage of those integrations was yours to set, say which and how you decided, in your own words; if there was no such step, or the APIs themselves were someone else's work, say so plainly and describe what you led. Hold through two follow-ups by returning to the integrations, never by adding to them; the honest branch is a limit, not a confession | F3 covers a must-have the dossier does not grade, and it is a likely second probe after A1. JD because it scores the stated requirement |
| A5 | "Why move into product management now?" | JD | [generic] | The material states no reason for the move, so the pack supplies none. Answer slot: give your actual reason, in your own words, in two or three sentences. If part of it is about what this role offers, name that part of the JD as the JD words it. Keep it consistent with your A1 answer, because this question is where a story is cross-examined | Motivation consistency is what the Skeptic scores, and F1 makes the question unavoidable. JD because it is about this role; generic because it carries no entity-specific claim |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch the plan for the partner-facing API platform's first two quarters — what do you need to know first?" | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Clarify first: who the partners are, how adoption is measured today and what the baseline is, and which roadmap decisions sit with the PM and which with the squad leads. Then objective, segmentation, approach, metrics, risks, thinking aloud. State your assumptions as assumptions | The JD's roadmap responsibility is the case material, and the dossier's two unknowns are the right clarifying questions. CASE because it is a live problem; generic because no company research ran |
| B2 | "Partner API adoption has been flat for two quarters — diagnose it." | CASE | [generic] | No claim about your past. Open by asking how adoption is measured and what the baseline is, since the dossier flags both as unknown. Then segment the funnel from partner sign-up to production use, form two or three hypotheses, say which data would separate them, and name the one you would test first | The JD names adoption metrics as a responsibility and the dossier notes no baseline is stated. CASE because it is a diagnosis problem |
| B3 | "Two squads each want the same quarter for different partner asks, and the squad leads disagree with you. How do you decide?" | CASE | [generic] | A method question, answered as method: say how you would decide, in the first person conditional. Ask first where the decision authority sits. Then principles: partner impact, cost and dependency, and what you would put in writing so the disagreement is on the record. Do not answer with a story from your past; the first-person future keeps the answer inside what you can stand behind | F2 is where prioritization authority is the gap, and a hypothetical is how a hiring manager tests it safely. CASE because it asks about no past |
| B4 | "How would you run discovery with integration partners to decide what the platform builds next?" | CASE | [generic] | No claim about your past. Structure: whom you would talk to and why, what you would ask, how you would separate recurring needs from one-off ones, and how the evidence would reach the roadmap discussion. Say where you would want help from the squads | The JD names discovery with integration partners as a responsibility. CASE because it is a method problem; C3 is where your own sessions are probed |
| B5 | "A partner's integration fails in UAT because a response schema changed without notice. Walk me through what you would do and what you would change so it does not recur." | CASE | [generic] | A live problem, so no claim about your past is needed. Structure: contain the failure with the partner, find the cause, then the change that stops a recurrence, such as how schema changes are announced and versioned. Answer slot: if a UAT failure like this occurred on one of the integrations you led, say what happened and what your part was, in your own words; if none did, say so and stay with the method | F4 is the technical-fluency row, and a schema scenario tests it without asking for a past. CASE because it is a live problem |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say 30+ client integrations — walk me through how that number was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what the quote says: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Four answer slots, each in your own words and each allowed the honest branch "I don't know": how the 30+ was counted; what it is sensitive to; the assumption behind it you would defend least, named before the interviewer does; and which part of each integration was yours, where the quote gives scoping, requirements, architecture, UAT and go-live. If the count is not something you can reconstruct, say that plainly rather than defend a method | The only headline number in the material. F1 and F3 both rest on it, so it is a magnet target. EXP because it tests attribution |
| C2 | "Tell me about the integration playbook — what is in it, and how does your team use it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Story-mapped on the beats the quote states: you wrote it, it is internal, it is about integrations, and your team uses it. Tell them in your own words. The underwriter had the playbook available to inspect, so you can offer to walk through it end to end. Answer slot: if any part of it was your own decision, say which and why; if parts came from others or from the vendor, say so plainly and describe the parts you wrote | F1 and F4 both lean on the playbook, so a prober checks it. EXP because it tests what you actually produced |
| C3 | "Walk me through one of your quarterly roadmap-input sessions — who was in the room, and what happened to the evidence afterwards?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-mapped on the beats the quote states: you ran them, quarterly, as roadmap-input sessions, feeding client evidence to product. This is a medium-confidence claim, confirmed with limited inspectable proof, so volunteer the limit before it is extracted. Answer slot: if you know what product did with the evidence, say what and what part was yours; if you passed it along and do not know what came of it, say so plainly. Say the limit in the underwriter's terms, sourced to prohibited_claims "Having owned a product roadmap": "I haven't owned a product roadmap" | F5 and the dossier's medium-confidence note say to expect a probe here. EXP because it tests what was actually yours |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with only the beats your sentences state: the 30+ integrations you led, the playbook you wrote, the roadmap-input sessions you ran feeding client evidence to product. Say your own tenure in your own words; the verified entries carry no figure, so the pack supplies none. Close with your reason for the move, in your own words, matching A5. Volunteer the sessions' limit as in C3: medium confidence, limited inspectable proof | The biography question opens most conversations and sets the story every later question tests. EXP because it is about your history |
| D2 | "What are you actually playing with in API docs and schemas these days?" | JD | [generic] | Treat the casual register as scored. Choose something real you have used recently with API docs or schemas. Answer slot: say what it was and what you did with it, in your own words; if nothing comes to mind, say so plainly and say what you would look at first in this platform's docs | F4 is the technical-fluency row, asked casually. JD because it targets the listed requirement |
| D3 | "Tell me about a time you had to bring engineering and sales onto the same page." | JD | [generic] | Selection scaffold, since no sentence of yours carries this. Pick an occasion with a named stake, a point where the two sides disagreed, and a result you can describe. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5's engineering and sales gap is the reason for the question. JD because it targets the stakeholder requirement |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You'll sit next to two squad leads — where is the seam between what you decide and what they decide, and what happens when you disagree?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Propose seam principles rather than pretending to know the seam: which calls the PM makes, which the squads make, how a disagreement is escalated and recorded. Ask where the line sits today; the dossier flags the authority question as asserted in the JD and not evidenced. Reciprocity, at the quote's scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Volunteer the medium-confidence limit as in C3 | The dossier's authority risk makes this the likeliest seam question. JD because it scores the role's authority |
| E2 | "A squad lead tells you the spec is not buildable in the quarter. What do you do?" | CASE | [generic] | A hypothetical, so no claim about your past. Ask what exactly is not buildable, split the scope into what can ship and what cannot, say what you would trade and what you would not, and say where you would escalate and when | The JD's responsibility to write specs and drive delivery with two squads makes this a natural scenario. CASE because it is a live problem |
| E3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold. Pick an occasion where credit was shared across teams, with a named moment where you chose to give it away or share it, and an intact relationship afterwards. If none comes to mind, say so plainly, then say how you would handle it | The Peer Evaluator's credit-sharing probe. VAL because it scores collaborative behavior rather than skill |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a PM who has done this job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live". The concession rests on prohibited_claims "Having owned a product roadmap" | Pause, restate the question, then answer in A1's order, compressed: concede in one clause, bridge in one sentence at the quote's scope, name the limit in one clause. Hold the bridge through two follow-ups by returning to the quoted work. If pressed, concede the specific point, "I haven't owned a product roadmap", and never fold on what the quote states | A1 delivered under time pressure. JD because it scores the same requirement |
| G2 | "That 30+ result — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Anchor in what the quote says: "I led them." Answer slot: which stages were yours, where the quote lists scoping, requirements, architecture, UAT and go-live; if any stage was someone else's, say which, plainly, without apologizing. Hold the position that you led through two follow-ups, and concede only the specific stage that was not yours | The standard attribution probe on the one number in the material. EXP because it tests attribution honesty |

### H. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold. Pick a time with a named stake, a moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | No values source was available, so this is a persona-stem prompt rehearsed generically. VAL because it scores behavior |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold. Pick a specific decision where the two conflicted, say which you chose and why, and what it cost. If none comes to mind, say so plainly, then say how you would weigh the two | Persona-stem prompt, same reasoning as H1. VAL because it scores behavior |

## Requirement coverage

| Requirement | Questions |
|---|---|
| R1: 3+ years product management experience (must_have) | A1, A2, A5, G1, E1 |
| R1 sub-claim: owning the roadmap (dossier acknowledge_gap) | A2, B1, B3 |
| R2: Shipped API or platform products (must_have) | A4, C1, G2 |
| R3: Technical fluency: API docs, schemas (important) | B5, D2, C2 |
| R4: Stakeholder management across engineering, sales, customers (important) | C3, D3, E1, E2, E3 |
| R5: Agile delivery experience (preferred) | A3 |
| Responsibility: run discovery with integration partners | B4 |
| Responsibility: write specs and drive delivery with two squads | E2 |
| Responsibility: define and track adoption metrics | B2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's unresolved risk is that decision authority is asserted in the JD and not evidenced; the answer also settles what you would be signing up for |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier's second risk is that adoption metrics are a named responsibility with no baseline stated; asking reads as diligence and answers something you need to know |
| 3 | "Where does partner feedback reach the roadmap today, and who runs those conversations?" | The JD names discovery with partners as a responsibility; the answer shows which part of discovery would be yours and which exists already |
| 4 | "How do the two squads divide the platform today, and how do they take on new partner asks?" | It tests the seam in E1 from your side and shows whether the squad leads' authority is documented anywhere |
| 5 | "What would you want a new PM to have learned by the end of the first quarter?" | It invites the interviewer to define success in their terms, which gives your ramp plan from A1 something concrete to meet |
| 6 | "What support does a new PM get in the first weeks, and from whom?" | It follows from the ramp plan in A1 and tells you what the onboarding actually is, since the material says nothing about it |

## Prohibited claims

Built from the dossier's `prohibited_claims`, which bind every guidance cell, plus entries built locally from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | F1's quotes at their own scope. Plain acknowledgment, sourced to prohibited_claims "Having held a product manager title or role": "I haven't held a product manager title or role." The bridge stays adjacent, as the dossier's condition requires |
| Having owned a product roadmap | Dossier prohibited_claims, and the acknowledge_gap area on the R1 sub-claim | Plain acknowledgment: "I haven't owned a product roadmap." No bridge and no slot on F2; B3 is answered as method |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | Plain acknowledgment: "I haven't set prioritization for an engineering squad." No slot |
| Shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: the material says client integrations of the vendor's APIs, not a product shipped. A4's slot stays inside the integrations |
| Drove or shaped the product roadmap | Inflated form of F5's sessions quote | F5's quote at its own scope. The limit is the pack's observation: the material says sessions that fed client evidence to product, not decisions about what was built. C3's slot asks only what came of the evidence |

## Sources

Provided documents: the pasted tuesday-dossier.md, dossier_version 1.1. It supplied role_profile, which stands as the JD tier, and handoff_to_mock_interview in full, which stands as the CV tier. The decision section was read as context only. The carried file has no evidence_map, evidence_state, risk_register or candidate_constraints section, so fit grading rests on the handoff alone.

Searches sent, all refused because web search was not granted in this session:

- `Quartzline company values` — refused
- `Quartzline interview process product manager` — refused
- `Quartzline API platform strategy news 2026` — refused

Loop and persona basis: no loop source exists beyond your own words, which establish one 45-minute hiring-manager conversation. Persona weights rest on the hiring-manager prior. No source documents a values round, so none is detected and there is no values cheat sheet.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Search refused. It would have named published values to theme the H bank; no values cheat sheet appears either way because no values round is detected |
| 2. `Quartzline interview process product manager` | unavailable | Search refused. It would have documented loop structure; your own words already fix the session, so persona weights are unchanged in structure |
| 3. `Quartzline strategy` / recent news | unavailable | Search refused. It would have grounded CO and CASE questions in current strategy; the B bank is generic and the pack has no CO question |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web search enabled for this session → Quartzline's published values, documented loop and current strategy: the B bank and H bank become grounded, and CO questions can be written
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, needs search enabled → a strategy brief, recent org context and interviewer footprint
- The interviewer's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- The recruiter's prep email → any stated focus areas or pre-declared deliverable such as a case or presentation
- Your own answers to the slots in A3, A4 and B5, said outside a rehearsal → F6, F3 and F4 regenerate from your words instead of from answer slots
- An inspectable artifact for the roadmap-input sessions, such as a deck, notes or an attendee list from one session → the medium-confidence claim behind C3, D1 and E1 can rise to high
- The dossier's evidence_map and evidence_state sections, absent from the carried file → F3, F4 and F5 take the underwriter's own grading in place of the one derived here
