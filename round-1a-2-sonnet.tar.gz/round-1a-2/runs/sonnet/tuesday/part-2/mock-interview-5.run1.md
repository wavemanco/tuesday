Web search was refused, so I'm building the pack from your message and the recruiter's words alone. I'm writing it to a file now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/tuesday/part-2/rooms/case-5-denied-68930398/kelverton-rail_senior-partnerships-manager_interview_pack.md`. I built it for a two-person panel with a 15-minute POV and Q&A, as the recruiter described. Web search was refused in this session, so it has no Kelverton facts. It rests on the recruiter's words and your background, and many cells are labeled `[generic]` or `[inferred]`. The market report wasn't pasted, so nothing in the pack comes from it.

Start with section 5, the POV build. It has three thesis options, each with a concession, and I recommend presenting the first and third. The highest-ROI rehearsal is B1, the "no rail sales in your background" question. The prep triage splits your four hours into five blocks.

I can play the Skeptic on B1 live, or the Prober on C1 for Ross's commercial push. Say which.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Can you paste the job description and your CV? If you can't, say skip and I'll keep going on what's here.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, panel, 60 minutes. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). The first 15 minutes are your POV, with no slides. The rest is Q&A, and the recruiter says Ross will push on commercials.

**Built on:** the recruiter's email as you quoted it, and your background statement. Web research was refused, and no job description or CV was supplied. Company facts are therefore absent and many rows are labeled `[generic]` or `[inferred]`. The upgrade menu says what would change that.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and use only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values (none in this pack, see Sources) |
| EXP | Whether your claims survive scrutiny, and what was actually you |
| JD | The stated role and its gaps |
| CO | Company and strategy knowledge |
| CASE | A live problem, structure and reasoning |

## Prep triage (four hours)

| Block | Time | Do this | Tied to |
|---|---|---|---|
| 1 | 75 min | Build the POV: choose two moves, write each one's concession, write the operator close and the anti-pick | Section 5, A1 to A5 |
| 2 | 45 min | Say the answer to the highest-ROI question (B1) out loud until it is boring, then the hold-then-concede answers | B1, D1, D3 |
| 3 | 40 min | Write, in your own words, how each of your two headline figures was counted, what it is sensitive to, the assumption you would defend least, and what was yours | C1, C2, C3, D2 |
| 4 | 40 min | Deliver the full 15-minute POV aloud twice, timed, no slides | Section 5, E1 |
| 5 | 40 min | Pick three reverse questions, prepare how you differentiate from the market report, rehearse the biography arc | Section 11, E2, E1 |

Everything else in this pack is insurance.

## Fit snapshot

The requirements come from the recruiter's words. There is no job description, so no requirement is JD-quoted. Evidence cells hold only your own sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your material shows a channel in payments, not operator partnerships in rail, and nothing inspected sits behind the figures. The words stay at the quote: "For the last four years I ran the ISV channel at a payments company, and took it from 6 partners to 40." Answer slot: the brief makes a probe on whether that channel carries over to operators likely. If any part of it does, say which part and how you know, in your own words. If none does, or you do not know yet, say so plainly and stay with the ISV channel |
| F2 | "land on what it means for the operators themselves" — recruiter email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning in consulting. It does not say which operators, or which side of the table you stood on. The words stay at the quote: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: expect a probe on "the other side". If any of that work was done for or with an operator, say which kind and what part was yours. If none was, or it was not yours, say so plainly and stay with the network planning |
| F3 | "Ross will push on commercials" — recruiter email | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I never carried a direct quota, only influenced revenue." Then how you would approach owning a number here, said as a plan and never as a past |
| F4 | Credibility with train operating companies, the customers your message names for Kelverton (unquoted prose, from your message) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | Words: "I've never sold into rail specifically." Then a ramp plan said as a plan and never as a past. F2 is adjacent work only, and its limit goes with it every time it is used |

## 5. Graded deliverable: the 15-minute POV

The recruiter announced it, so it is graded.

**Material you can speak from.** Each item is a row of the fit snapshot and a sentence quoted from its evidence cell.

| Row | Quote |
|---|---|
| F1 | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." |
| F2 | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." |

**Three theses.** Each has a mandatory concession, and each is a hypothesis to test, not a finding about Kelverton.

| Thesis | What it could mean for the operators themselves (hypothesis to test) | Mandatory concession | Provenance |
|---|---|---|---|
| T1: go deeper with fewer operators before broadening | Each operator gets a partnership shaped around one outcome it cares about, instead of a standard offer. Test it by asking operators which outcome | You do not yet know how current operator partnerships are split, so this is a first-90-days hypothesis. Depth costs breadth | [generic] |
| T2: widen the partner ecosystem around operators so change is not limited by Kelverton's own capacity | Operators wait less on Kelverton's own team | Whether rail operators adopt through partners is something you cannot know from outside. The ISV channel in F1 is adjacent, not proof | [generic] |
| T3: tie partnership terms to operator outcomes that are measured first | Operators can see what changed for them, not only what they paid | F3 applies: you never carried a direct quota, so the commercial terms are where you lean on Ross and Deepa. You propose, they own | [generic] |

**Recommendation.** Present T1 and T3, and hold T2 for Q&A. This follows the recruiter's two stated asks, operators and commercials.

**Shape, timed to 15 minutes, no slides.**

| Minutes | Content |
|---|---|
| 1 | What you will cover, and that you are reasoning from outside |
| 2 | The assumptions you are making and the two or three facts that would change the plan |
| 7 | Two moves, each with its concession said aloud |
| 3 | The requested close: for each move, one sentence on what changes for an operator, and how you would check that with operators |
| 1 | What you would not do (the anti-pick), then invite pushback |
| 1 | Buffer |

**Differentiate from the market report, never recite it.** I have not seen its contents. Its strategy team wrote it and both panelists know it, so reciting it scores as homework. Name one item from it to show grounding, then give one thesis of your own that departs from it with reasons, then the anti-pick. Candidate anti-pick: not making operator count the headline measure in year one. Your own quoted figure counts partners, so be ready for "but you measured that way" and answer from your own words about why this role differs.

## 8. Persona table

The session is established by the recruiter's words: one panel of Deepa and Ross, 60 minutes, 15 on the POV and the rest Q&A. Weights rest on that and on relationship priors, not on a fallback archetype. No interviewer profiles exist, so no interviewer signals are applied.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | Follow-ups on the POV: what you would need to know, what you would not do | Co-top. Deepa is "your future manager", the hiring-manager prior is Case plus Skeptic, and the POV is the announced deliverable | Clarify first, then structure, then answer. Challenge one premise respectfully. Think aloud |
| Skeptic (B) | Quiet probing of the rail gap and the motivation | Co-top. Same prior, and F3 and F4 are stated gaps | Rehearse B1 until boring. Bridge only from F2 with its limit named, plus a ramp plan |
| Data-Driven Prober (C) | Your two figures, walked to their assumptions | Mid. The recruiter says Ross "will push on commercials". No public profile exists, so this rests on that line alone | Know how each figure was counted, and say plainly where you do not know |
| Pressure (D) | Time-boxed challenges on why you, and how much was you | Mid. The executive prior for a Commercial Director is Case plus Pressure | Pause, restate, hold two follow-ups, then concede specifically |
| Conversational (E) | The opener and the market-report question | Low weight but scored. Casual questions still count | A prepared 90-second arc, and a prepared answer to the report question |

Not included: Values/Behavioral, because no values-style round is documented by any source here. Peer Evaluator, because neither interviewer is a peer role.

## 9. Question banks

**Requirement coverage.** There is no job description, so this maps the recruiter's stated asks and the F4 requirement to question IDs. It cannot be checked against a posting's own list.

| Requirement | Questions |
|---|---|
| "present a short POV on where you'd take our operator partnerships over the next 18 months" | A1, A2, A3, A5, B5, and the section 5 build |
| "land on what it means for the operators themselves" | A4, A5, and the section 5 close |
| "Ross will push on commercials" | C1, C2, C3, D2, D3 |
| Credibility with train operating companies | B1, B2, B4, D1 |
| The market report the recruiter attached (not a requirement) | E2 |

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have fifteen minutes: where would you take our operator partnerships over the next 18 months?" | JD | [grounded] | The announced POV. Build it from section 5, not here. Assumptions first, two moves each with its concession, then land on the operators | The recruiter's email announces it, so it is the opener. JD because it scores the stated deliverable, with CASE delivery |
| A2 | "What would you need to know about our operators before you committed to that plan?" | CASE | [generic] | Clarify before committing: name the two or three facts that would change your plan and who you would ask. Say plainly that you are reasoning from outside, and state no facts about their operators | Case interviewers score clarify-before-structure. The question needs no claim about your past |
| A3 | "What are you choosing not to do, and why?" | CASE | [generic] | The anti-pick from section 5. Say it as a decision with its cost, not as a criticism of the current approach | The role includes saying no. A thesis with no anti-pick reads as a wish list |
| A4 | "A year in, how would you tell whether the operators themselves are better off?" | CASE | [generic] | Pick one or two operator-side signals and say you would test the choice with operators first. Then say how a signal connects to Kelverton's commercial result. Claim no knowledge of operators' current measures | The recruiter asked you to land on operators, so this is the same ask as a probe |
| A5 | "Where does a partner-led approach go wrong?" | CASE | [generic] | Name one or two failure patterns as patterns, not as experiences, and say how you would spot each early | Tests whether T2 survives a skeptical follow-up. It asks about no past |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see rail sales in your background. How would you handle that in this role?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | The highest-ROI rehearsal in this pack. Say it plainly: "I've never sold into rail specifically." Then the adjacent work at its own scope: "I spent five years in transport consulting, in bus and light rail network planning." State its limit yourself, in the pack's observation that your material says bus and light rail, not train operating companies. Then a ramp plan said as a plan: who you would learn from, what you would learn, by when, in your own words. Do not claim the other side of the table | F4 is where the panel presses hardest, so this arrives in some form. JD because it tests the listed job's gap |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pick the weakest part truthfully before they do. If it is the number, say: "I never carried a direct quota, only influenced revenue." Then what you would do about it as a plan | Honest self-assessment is what a Skeptic scores. F3 is the likeliest answer |
| B3 | "Why leave payments for rail-tech, and why now?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Give your own reason in your own words; this pack supplies none. If it connects to your transport consulting years, say how. If it does not, say so and give the reason it does have | Motivation consistency is scored. The reason is the only part nobody else can write |
| B4 | "You said you know the operator world from the other side. What do you mean by that?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Answer slot: if any of that work was for or with train operators, say which and what part was yours, in your own words. If none was, say so plainly and stay with the bus and light rail network planning. Do not turn "the other side" into a claim about who your client was | F2 holds the phrase, and a relationship claim is the one that collapses on the first follow-up |
| B5 | "Which part of the plan you have just described are you least sure of, and what would change your mind?" | CASE | [generic] | Name one part and one concrete thing you would learn that would change it. Calibrated candor beats defending everything | Follows the POV directly. Tests whether the plan survives self-examination |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the roughly £4M of influenced revenue was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot, in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Supply no method you cannot repeat under a second question | F1 holds the figure, and commercial probers go to the number first |
| C2 | "How did you get from 6 partners to 40?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot, in your own words: what counted as a partner, and which part of the growth was yours. If the growth was shared or inherited in part, say so. If you do not know a detail, say so plainly | F1 holds the count, and the count is the second figure a prober checks |
| C3 | "What does influenced revenue mean in your numbers, and how is it different from revenue you closed?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Plain words first: "I never carried a direct quota, only influenced revenue." Answer slot, in your own words: how that influence was counted. If you do not know, say so plainly. Never describe it as closed revenue | F3 is the direct commercial challenge, and Ross is the likeliest to ask it |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has sold into rail?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Hold only what the quotes carry: "For the last four years I ran the ISV channel at a payments company, and took it from 6 partners to 40." Concede, specifically: "I've never sold into rail specifically." Hold through two follow-ups by returning to the quotes, never by adding to them | F1, F2 and F4 are the full set of what you can say, so the hold is only those |
| D2 | "That result — how much of it was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot, in your own words: which part was yours and which was the team's. If you ran it alone, say so. If a good part was shared, say that plainly. Precise attribution is the point | Attribution probes exist to catch inflation, and F1's figures are exactly where that happens |
| D3 | "You have never carried a quota. Why should we trust you with a commercial number?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Plain words: "I never carried a direct quota, only influenced revenue." Then a proposal: how you would want to be measured here, or, if you have not formed a view, what you would agree with Deepa first. Hold the position without becoming defensive | F3 is a stated gap, so a time-boxed version of it is likely |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | A 90-second arc with three beats: five years in transport consulting, in bus and light rail network planning; then the last four years running the ISV channel at a payments company; then your own reason for this role, in your own words | Casual openers are scored for economy. F2 and F1 are the only beats the quotes carry |
| E2 | "What did you make of the market report our strategy team circulated?" | CO | [inferred] | Never recite it. Bring one consensus item to show you read it, then one thesis of your own that departs from it with reasons, then the anti-pick. I have not seen the report, so name the items yourself | Inferred from the recruiter attaching it to her email. CO because it tests homework depth |

## 11. Reverse questions

| Question | Why it lands |
|---|---|
| "What would make the first 18 months a clear success for operator partnerships, and how would you and Ross each know?" | It shows you think about measurement across both the partnership and commercial sides |
| "How is this role's number set: influenced revenue, direct revenue, or a mix?" | It puts the commercial structure on the table before Ross does, and you need the answer to accept the role |
| "Where do operators push back hardest on working with Kelverton today?" | It keeps the conversation on the operators themselves, which the recruiter asked you to land on |
| "What did the market report underweight, if anything?" | It invites their own view and continues the differentiation you started in the POV |
| "What would you want someone new to have learned by day 90?" | It signals you plan to learn rail first, which answers the B1 objection indirectly |
| "What is the one thing about this role you would change if you could?" | It gives them room to be candid, which people remember |

## 13. Prohibited claims

Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a quota or owned a revenue number | Negative you stated, F3 | The plain acknowledgment F3 gives: "I never carried a direct quota, only influenced revenue." No slot |
| Has sold into rail | Negative you stated, F4 | "I've never sold into rail specifically." No slot |
| Knows train operating companies from the inside, or was the operator's customer or colleague | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says bus and light rail network planning in consulting, not train operating companies. B4's slot stays inside the planning work |
| Closed, booked or sold the £4M, or personally originated the partners | Inflated form of F1 | F1's quote at its own scope: you ran the channel and took it from 6 partners to 40, and the revenue is influenced. The limit is the pack's observation. C1 and D2 slots ask only how it was counted and which part was yours |

## 14. Sources

**Provided.** The recruiter's email as quoted in your message. Your background statement. The market report was attached to the recruiter's email, but its contents were not shared with this pack, so nothing in the pack is drawn from it. No job description or CV was supplied. No dossier was present.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

Every call was refused by the host, so nothing came back from any of them.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Would have fed a values cheat sheet. As it stands, none exists and no VAL questions are included |
| 2. `Kelverton Rail interview process partnerships manager` | unavailable | Would have documented loop structure. The recruiter's own words establish this session instead |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Would have grounded CO and CASE questions in current strategy. They are labeled generic or inferred |
| 4. `{interviewer name} Kelverton Rail` (two names) | unavailable | Would have supported an interviewer read, interviewer-signal persona adjustments, and a reverse question tied to their paths. The read is absent |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Would have supplied inferred JD-tagged requirements. The fit snapshot uses the recruiter's words instead |

Queries sent, all refused: "Kelverton Rail values"; "Kelverton Rail interview process partnerships manager"; "Kelverton Rail strategy scheduling software train operating companies"; "Deepa VP Partnerships Kelverton Rail"; "Ross Commercial Director Kelverton Rail"; "Senior Partnerships Manager rail technology job description train operating companies".

## 15. Upgrade menu

- The job description text → the recruiter-word requirements become JD-quoted rows, JD-tagged questions become grounded, and the requirement-coverage check runs against the posting's own list
- The market report text, or its key pages → a grounding brief, a concrete consensus item and divergence for the POV, and E2 and the CO questions become grounded
- Your CV → fit snapshot evidence quotes the CV as well as your message, and more guidance cells become story-mapped instead of scaffolded
- Your own answers to the slots in F1, F2, C1, C2, C3 and B4 (how the figures were counted, whether any consulting work was for train operators) → those rows are regenerated on your quoted words
- Search access, and a deeper pass of up to 6 more searches and 2 more fetches taking several more minutes → company values, strategy, a loop source, and Deepa's and Ross's public professional footprints, giving an interviewer read, tuned persona weights, and reverse questions tied to their paths
- A tuesday-dossier.md from a prior underwriting of this role → verified evidence per requirement, a named top objection, and a prohibited-claims list you did not have to infer
