Your prep pack for all three rounds is saved as `ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as three round-by-round question sets, because your recruiter's email gives all three rounds. I ran no searches, since the values, process and strategy you pasted already covered them.

The pack names one top prep item: the contact-centre objection, rehearsed in R2-A1. The JD puts the contact centre inside the role, and your would-be manager is the person most likely to press it.

Your own words give you a plain acknowledgment for each of the two gaps you stated: the contact centre and presenting above regional level. The pack coaches you to say those and add a plan, nothing more. Answer slots in the pack mark where your quoted material stops short of what the JD asks. Send me your answers to them and I'll update the pack.

Say the word and I'll play the Head of Member Services on R2-A1, with live follow-ups and feedback.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Prepared for Dara. Loop mode: three scheduled rounds on 29 November 2026.

| Round | Who | Length | Relationship |
|---|---|---|---|
| 1 | The recruiter (name not given) | 30 minutes | Recruiter screen |
| 2 | The Head of Member Services (name not given) | 45 minutes | Your would-be manager; the recruiter calls it mostly behavioural |
| 3 | A panel of two branch managers (names not given) | 60 minutes | Includes a 20-minute case on a complaint escalation; the panel is also the values round and scores against the four published values |

The highest-ROI prep in this pack is R2-A1, the contact-centre objection. It is the one stated gap the JD puts inside the role, and the person who would be your manager is the one most likely to press it.

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values |
| EXP | Whether what you have told us survives scrutiny, and what was actually yours |
| JD | A stated requirement of the role, including its gaps |
| CO | Knowledge of Ashgrove's strategy, competition and recent moves |
| CASE | A live problem from the role, answered aloud |

Question IDs read round, then persona letter, then number: R2-A3 is round 2, persona A, question 3. Answer slots are instructions for the interview, not questions for me; send me what you would say to any of them and I will update the pack.

## Prep triage

You have nine days, from 20 to 29 November. In this order:

1. Say the two plain acknowledgments aloud until they are boring, with the plan you add to each: R2-A1 for the contact centre, R2-A4 for presenting above regional level.
2. Write your own answer to each answer slot in the fit snapshot (F2, F3, F5, F6, F7, F9). Each is either a fact you can state or a plain "that was not mine"; both are strong.
3. Time the 20-minute case aloud with R3-B1, structure first, then R3-B2.
4. Pick one story per published value, or take the honest branch: R3-A1 to R3-A4 and the values cheat sheet.
5. Settle your own answers to pay, notice, location and the reason for moving before the recruiter call: R1-A3 to R1-A6.

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is your own words from your message and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap in the years, but a line from your message with nothing inspected behind it, so expect a probe on what the six years held. Say it in the quote's own terms: six years in retail banking, the last three as a branch supervisor |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your material says a formal log and does not show what rules governed it, so the words stay at "I handled the branch's formal complaints log." Answer slot: the JD's line on this makes a probe on the log likely. Say what the log covered and which part of handling it was yours; if you know what rules or reporting duties applied to it, say what you knew; if you do not, or none applied, say so plainly and stay with the log |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material carries one branch's formal log, which stops short of the whole process and of other branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what sat beyond the log likely. If any step beyond the log was yours to handle, say which and how, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log |
| F4 | "end to end across branches and the contact centre" — JD, the contact-centre half | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then what you would do to learn how the contact centre handles complaints, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says a monthly complaints spreadsheet your regional manager uses, not what it counted, and the words stay there: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's monthly-reporting line makes a probe on what the spreadsheet counted likely. Say what it counted and how each count was made, in your own words; if you do not know how something in it was counted, or it counted something different, say so plainly and stay with the spreadsheet |
| F6 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Training new tellers on a script is adjacent to coaching supervisors, and the words stay at "trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on supervisors likely. If you have guided other supervisors on escalations, say how, in your own words; if you have not, say so plainly and stay with the tellers |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this, which is not an absence. Answer slot: the JD's digital line and the strategy brief's aim of moving 40% of member service to digital channels by 2028 make a probe likely. If you have worked with a digital or app team on anything members do for themselves, say what and which part was yours, in your own words; if you have not, say so plainly and say what you would want to learn first |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then what you would do to prepare for your first presentation, said as a plan and never as a past. The JD does not say who counts as senior, which the recruiter can say. Never a claim to senior presentations, and nothing added to make the gap feel smaller |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says spreadsheet, not which tool, so the words stay at "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names Excel, so expect a probe on the spreadsheet. If it was in Excel, say so and say what you built in it, in your own words; if it was in another tool, or Excel did little of the work, say so plainly and stay with the spreadsheet |

## Grounding brief

From the 2026 strategy brief the recruiter sent you, as summarised in your message. It was published in July 2026, about four months before today.

| # | Item | Provenance | Content |
|---|---|---|---|
| G1 | Digital shift | [grounded] | The brief aims to move 40% of member service to digital channels by 2028 |
| G2 | Branch hubs | [grounded] | The brief consolidates eight branches into five hubs over 2027 |
| G3 | Business lending | [grounded] | The brief launches a small-business lending product in Q1 2027 |
| G4 | Competition | [grounded] | The brief names app-only banks as the main competitive pressure |
| G5 | Source limit | [grounded] | You gave me the four points above, not the full document; anything the full brief says beyond them is not in this pack |
| G6 | Reading: complaints and digital | [inferred] | Derived from G1 and the JD's digital-teams line: more service moving to self-service may change where complaints start and which ones reach a person, which would explain why the JD pairs complaints with self-service journeys |
| G7 | Reading: hubs and round 3 | [inferred] | Derived from G2 and the panel being branch managers: branch structure is a live 2027 topic, so a question on hubs is plausible; the brief as you gave it does not say what changes for branch staff |

Sound current: use their own words, members, hubs and self-service, rather than generic banking vocabulary.

## Round 1: recruiter screen (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly biography and motivation questions, plus the logistics | High: the relationship prior for a recruiter screen is Conversational plus a light Skeptic, and nothing about this recruiter shifts it | A 90-second arc built only from your quoted sentences; treat every casual question as scored |
| Skeptic | A knockout-style check on the JD's items | Medium: F4 is the one stated gap a screen is likely to surface | Say the acknowledgment once, plainly, and add nothing to it |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "So, walk me through your time in retail banking." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F1, F2 and F5: the six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log; you trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Those are the beats the quotes state; tell them in your own words in about 90 seconds and add no beat the quotes do not carry | F1 is the years evidence, and an opening biography question is near-certain in a screen. JD because it scores the stated years requirement, with EXP delivery since it walks the CV |
| R1-A2 | "What attracted you to Ashgrove?" | CO | [grounded] | Build it from the published material and your own reasons: pick one value and one strategy move that genuinely matter to you and say why. The material gives you "Members First, Always — we decide from the member's side of the counter", the aim of moving 40% of member service to digital channels by 2028, and eight branches consolidating into five hubs over 2027. Answer slot: say the reason that is actually yours; if you have not yet formed one, say so plainly and do not borrow this pack's | G1, G2 and the values page give a recruiter the motivation-consistency check something to test. CO because it tests homework depth, with VAL content |
| R1-A3 | "What are you looking for, salary-wise?" | JD | [generic] | A logistics slot, and no figure is supplied here: give your own number, or ask for the role's band first. The JD you pasted states no salary, so asking is a fair first move. Whichever you choose, it must be a number you have decided on or a question you actually want answered | Recruiter screens carry the pay question, and the only safe answer is the candidate's own. JD because it concerns the job's terms |
| R1-A4 | "What's your notice period?" | JD | [generic] | A logistics slot: give your actual notice period in your own words, and any flexibility only if it is real | Notice is a standard screen item and a fact only you hold. JD because it concerns the job's terms |
| R1-A5 | "Where are you based, and is there anything about where or how often you can work that we should know?" | JD | [generic] | A logistics slot: state your own location and any constraint in your own words. The JD you pasted names no location or office pattern, so ask the recruiter what the role's is before committing to an answer about it | Location is a standard screen item. The JD's "across branches and the contact centre" implies more than one site, which makes the pattern worth asking about. JD because it concerns the job's terms |
| R1-A6 | "What's prompting a move now?" | EXP | [generic] | A logistics slot: give your actual reason in your own words. Say what you are moving toward only if it is true, and do not supply a reason this pack has not heard from you | The reason for leaving is asked in every screen and is where motivation stories drift. EXP because it tests the candidate's own account |
| R1-B1 | "This role covers the contact centre, and you haven't worked in one. How do you see that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say the plain acknowledgment first, in these words: "I've never worked in a contact centre." Then stop adding, and say as a plan what you would do first to learn how the contact centre handles complaints; the plan is yours to state. If asked what you do have, the quotes carry one fact: you handled the branch's formal complaints log. Claim no phone, queue or contact-centre work | F4 is the clearest stated gap, and a screen is where it first appears as a check. The fuller rehearsal is R2-A1. JD because it scores the stated requirement |
| R1-B2 | "Tell me about the complaints work you've done." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F2 and F5: you handled the branch's formal complaints log; you trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Those are the beats. Answer slot: expect a probe on what the log covered and what rules governed it; say what you know, in your own words; if you do not know, say so plainly and stay with the log | F2 and F5 are the evidence for the complaints requirement and the likeliest place to be probed. JD because it scores the stated requirement, with EXP delivery |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1-V1 | "How does the work split between branches and the contact centre today?" | It tests the contact-centre gap honestly and shows you are asking to learn it, which fits the plan R1-B1 asks you to state |
| R1-V2 | "What would you most want the Head of Member Services conversation to cover?" | Recruiters can often say what the next round will press, and it costs one question |
| R1-V3 | "What does the panel score the 20-minute case on, and is anything sent in advance?" | The format is un-researchable and shapes how you rehearse R3-B1 |
| R1-V4 | "How does the digital target show up in this role in its first year?" | It signals you read the strategy and ties to F7 |
| R1-V5 | "Who does the monthly reporting go to, and who counts as senior leadership for this role?" | It closes the gap in the JD that F8 leaves open |

## Round 2: Head of Member Services (45 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the gaps | High: the hiring-manager prior is Case/Strategist plus Skeptic, and this is the person who would carry the risk of the hire; F4, F6, F7 and F8 are the thin rows | Hold-then-concede on R2-A1 until it is boring |
| Values / Behavioral | Scenario and "tell me about a time" probes | Medium: the recruiter calls this round mostly behavioural, which lifts it above the hiring-manager prior; the scored values round is the panel, so this round is not yet scored against the four values | A story only where a quoted sentence carries it; the scaffold's honest branch otherwise |
| Case / Strategist | Live problems from the strategy and the role | Medium: the hiring-manager prior, lowered by the recruiter's "mostly behavioural" | Clarify, objective, approach, metrics, risks, thinking aloud |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-A1 | "You'd own this process across branches and the contact centre, and you haven't worked in a contact centre. How would you earn that team's confidence?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The highest-ROI rehearsal in this pack. Concede first, in these words: "I've never worked in a contact centre." Then hold what the quotes carry and add nothing: you handled the branch's formal complaints log and trained new tellers on the escalation script. Name the limit before it is asked for: how the contact centre works is what you would need to learn. Then three follow-ups. One, "What would you do in your first month?": a plan in your own words for learning how the contact centre handles complaints, said as a plan and never as past work. Two, "That isn't the same as having done it": agree it is not, repeat the acknowledgment, return to the log and the script. Three, "What would you need from that team?": your own questions, asked as questions. Never describe how a contact centre runs as though you had seen it | F4 is a stated gap and the JD puts the contact centre inside the role, so this objection will arrive in some form from the person buying capability. JD because it scores the stated requirement, with Skeptic delivery |
| R2-A2 | "The role asks you to coach branch supervisors on escalations. What have you done in that line?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what the quote carries: you trained new tellers on the escalation script. Answer slot: if you have guided other supervisors on escalations, say how, in your own words; if you have not, say so plainly and stay with the tellers. Do not call the training coaching of supervisors | F6 carries adjacent work and the JD names supervisors, so the line between tellers and supervisors will be tested. JD because it scores the stated requirement |
| R2-A3 | "Pick one complaint you handled and walk me through it from when it came in to where your part ended." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A selection scaffold: pick a case from the log you handled that you can tell without adding a detail you cannot stand behind; it needs the member's position, what you did, where it went and how it ended. If no case comes to mind that you can tell that way, say so plainly, then give the nearest thing your material carries, that you handled the branch's formal complaints log, or how you would handle one. Never add a stage, a person or an outcome you cannot stand behind | F3 is the evidence for the end-to-end requirement and stops at one branch's log, so the interviewer will look for where your part ended. JD because it scores the stated requirement, with EXP delivery |
| R2-A4 | "The role needs you to present to senior leaders. Have you done that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say the plain acknowledgment and stop: "I've never presented to anyone above regional level." Then a plan, in your own words, for how you would prepare for your first presentation, said as a plan and never as past work. If it helps, ask who counts as senior here, because the JD does not say and your answer depends on it. Never claim a presentation you have not given | F8 is a stated gap and your manager is the person who would ask. JD because it scores the stated requirement |
| R2-A5 | "Walk me through the monthly complaints spreadsheet you built." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F5 and F9: you built the monthly complaints spreadsheet, and your regional manager uses it; those are the beats, in your own words. Answer slot on what it counted: expect a probe on what the spreadsheet counted and how each count was made; say what, and if you do not know how something in it was counted, say so plainly. Answer slot on the tool: the JD names Excel; if the spreadsheet was in Excel, say so, and if it was in another tool, say which. Add no formula, chart or distribution you have not named yourself | F5 and F9 draw on one sentence, and a prober reads a spreadsheet line by line. JD because it scores the reporting and Excel requirements, with EXP delivery |
| R2-B1 | "Tell me about a time you had to tell a member something they did not want to hear." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A selection scaffold: pick a time from your own work; it needs the member's situation, what they wanted, what you told them and how, and where it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, that you handled the branch's formal complaints log, or how you would handle it | The theme comes from "Plain Words" and "Members First, Always" on the values page, and complaints work makes it likely. VAL because it asks for behaviour, not a figure |
| R2-B2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | A selection scaffold: pick a time you held a position under pressure from someone senior; it needs a named stake, a moment you did not fold, and a relationship that was intact at the end. Choose a case where the hard truth actually landed; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem for a manager's round, with the hard-truth test the stem exists for. VAL because it asks for behaviour |
| R2-B3 | "When did you put a member ahead of an internal target?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A selection scaffold: pick a time the member's side and the target pulled apart; it needs what pulled each way, what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, that you handled the branch's formal complaints log, or how you would handle it | The theme comes from "Members First, Always" on the values page, which also appears in round 3. VAL because it asks for behaviour |
| R2-C1 | "The role works with the digital teams on self-service journeys, and our strategy aims to move 40% of member service to digital channels by 2028. Where would you start?" | JD | [grounded] | Clarify first, and ask rather than guess: what counts in the 40%, which journeys go first, where complaints start today. Then objective, how you would segment the journeys, approach, one metric and one risk, thinking aloud, challenging one premise respectfully. Answer slot: expect a follow-up on whether you have worked with a digital team. If you have, on anything members do for themselves, say what and which part was yours; if you have not, say so plainly and say what you would want to learn first | F7 is silent in your material and G1 gives the JD's digital line a number. JD because it scores the stated requirement, with CASE delivery |
| R2-C2 | "A small-business lending product launches in Q1 2027. How would you set up complaints handling for it?" | CASE | [grounded] | Clarify first: who owns the product, which complaint rules apply to it, where complaints would arrive. Then objective, who a complaint goes to from a branch, the contact centre and the digital channels, what the first monthly report should show, risks. Think aloud and challenge one premise. This question needs no claim about your past, so the guidance makes none | G3 is a dated launch that the brief names, and a new product is where a complaints lead is built first. CASE because it is a live problem; CO because it uses the brief |
| R2-C3 | "Eight branches become five hubs over 2027. What does that change for how you'd coach branch supervisors on escalations?" | CASE | [grounded] | Clarify first: what changes for supervisors, who handles an escalation in a hub, what members will be told. Then objective, approach, a metric and a risk, thinking aloud. Do not guess the hub plan; say what you would need to know. This question needs no claim about your past, so the guidance makes none | G2 is a live 2027 change and the role's coaching line meets it directly. CASE because it is a live problem; JD because it applies the coaching requirement |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2-V1 | "What would make the first six months a success, and how would you want to see it?" | It asks the manager to define the bar, which an interviewer who will manage you weighs heavily |
| R2-V2 | "How do branches and the contact centre hand a complaint to each other today?" | It tests the contact-centre gap by asking to learn it |
| R2-V3 | "Who would I be presenting the monthly report to, and what do they decide from it?" | It addresses F8 directly and shows you are planning the work |
| R2-V4 | "How would you want me to learn the contact-centre side in the first month?" | It shows the stance R2-A1 asks you to rehearse: a candid gap with a plan |
| R2-V5 | "How will self-service journeys and complaints data feed each other with the digital teams?" | It ties F7 and G1 together and signals you read the strategy |

## Round 3: panel of two branch managers (60 minutes)

The recruiter describes the 20-minute case as part of the panel, not a prepared piece, so it is rehearsed through R3-B1 and R3-B2 rather than a build section. A values-style round is detected here, from the recruiter's own words that the panel scores against the four values.

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes mapped to the four published values | High: the recruiter says the panel scores against them | A story for each value where a quoted sentence carries one; the scaffold's honest branch where none does |
| Case / Strategist | The 20-minute complaint-escalation case | High: 20 of the 60 minutes are the case | Structure before answer, aloud, with one premise challenged |
| Peer Evaluator | Where your job meets a branch manager's | Medium: the panel is branch managers and the role coaches branch supervisors; the panel row of the persona model blends each member's top two relationship personas, and with no names I cannot assign them per member | Seam principles, not a pretended seam; what the role gives them |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-A1 | "Tell me about a time you decided from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A selection scaffold: pick a time the decision that was right for the member differed from the easier one; it needs the member's position, what pulled the other way, what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, that you handled the branch's formal complaints log, or how you would handle it | "Members First, Always" is the first published value, and the panel scores against it. VAL because it asks for behaviour |
| R3-A2 | "Tell me about a time you made something clearer for a member." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A selection scaffold: pick a time a member needed more than one explanation or a clearer one; it needs what was unclear, what you changed and how you knew it worked. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, that you trained new tellers on the escalation script, at that scope and without saying you wrote the script, or how you would handle it | "Plain Words" is a published value: "if a member needs it explained twice, we wrote it wrong". VAL because it asks for behaviour |
| R3-A3 | "Every branch is part of its town. Tell me about a decision where you weighed the town, not only the numbers." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | A selection scaffold: pick a decision where the branch's place in its town mattered; it needs what the town needed, what the numbers said and what you decided. If no such decision comes to mind, say so plainly, then give the nearest thing your material does carry, that you spent the last three years as a branch supervisor, or how you would handle it | "Neighbours, Not Numbers" is a published value and, read with G2, is where hub consolidation will press. VAL because it asks for behaviour |
| R3-A4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F3: the only beat the quote states is that you handled the branch's formal complaints log; tell that in your own words. Answer slot: the value says whoever finds the problem keeps hold of it until it is solved, so expect a probe on a problem you stayed with. If there was one in the log you handled, say what it was, what you did and where it ended; if there was none, or part of it was not yours, say so plainly and stay with the log | "Own the Fix" is a published value and the nearest to the JD's ownership line. VAL because it asks for behaviour |
| R3-A5 | "Which of our four values would be hardest for you to live up to in this role?" | VAL | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose one in your own reasoning and say why, from what is new to you in the role. If the honest answer is a limit you have stated, say it in your own words: "I've never worked in a contact centre." Do not choose a strength dressed up as a weakness | A panel scoring values often asks where the candidate expects to strain, and F4 is a stated limit. VAL because it tests self-assessment against the published values |
| R3-B1 | "A member has complained about the same fee at a branch twice, and the branch has closed both complaints. They have now phoned the contact centre and say they will move to an app-only bank. You have twenty minutes: what do you do, and in what order?" | CASE | [generic] | Structure it aloud. Clarify: what the fee is, what each closure said, whether the complaint has reached a formal stage and what time limits apply; ask, do not assume the rules. Objective: decide from the member's side, with one person holding the case until it is solved. Approach: read both earlier closures before calling, tell the member in plain words what happens next and by when, find out why the fee was charged and whether it was right, agree with the branch and the contact centre who holds it. Metrics: whether the issue is solved, repeat complaints on the same fee, time taken. Risks: closing it again without fixing it, the branch and contact centre telling different stories, a promise you cannot keep. Afterwards: what the supervisor learns. Challenge one premise: whether the earlier closures were correct, not only whether they were closed. This question needs no claim about your past, so the guidance makes none | The recruiter says the panel includes a case on a complaint escalation; this is a rehearsal case, not their case, and it is built so the three values it touches show up in the structure. CASE because it is a live problem; [generic] because the scenario is invented |
| R3-B2 | "A branch supervisor escalates every difficult complaint straight to you. How do you change that without leaving members waiting?" | CASE | [generic] | Structure it: clarify why they escalate (confidence, uncertainty about the rules, caution); objective; approach, agreeing what stays at the branch and what escalates, coaching on live cases, reviewing together; a metric and a risk, especially members waiting while coaching happens; keep the case held until it is solved. This question needs no claim about your past, so the guidance makes none | The JD's coaching line applied as a live problem, and the second likely case shape. CASE because it is a live problem; JD because it applies the coaching requirement |
| R3-B3 | "A long-standing member of a branch that is consolidating into a hub says the credit union no longer cares about their town. How do you respond, and what do you tell the supervisor?" | CASE | [grounded] | Structure it: clarify what the member has been told and what the hub plan commits to, and do not guess it; objective, apply "Neighbours, Not Numbers" and "Plain Words" in how you answer; approach for the member and for the supervisor; a metric and a risk, especially promising what the plan does not say. This question needs no claim about your past, so the guidance makes none | G2 and the Neighbours value meet here, and a branch-manager panel is the likeliest to ask. CASE because it is a live problem; VAL because it applies a published value |
| R3-B4 | "What is the main competitive pressure on Ashgrove, and what does it mean for complaints?" | CO | [grounded] | Differentiate from the shared source: any candidate with the brief says app-only banks, so say that once to show grounding, then give one view of your own with its concession. A thesis to consider, yours to hold only if you believe it: a human who resolves a complaint well is something an app-only bank may find harder to match; concede what app-only banks do better, and say that not every complaint belongs in self-service. This question needs no claim about your past, so the guidance makes none | G4 is the consensus answer anyone with the brief assembles; differentiating from it scores as judgement. CO because it tests strategy fluency |
| R3-C1 | "You'd coach our supervisors on escalations. Where's the line between your job and mine as a branch manager?" | JD | [grounded] | Propose seam principles and do not pretend to know the seam: agree before a case arises who decides what; keep the supervisor's manager informed; ask how they want it to work. Reciprocity: say what the role's monthly report on complaint volumes and resolution times could show them about their own branch. This question needs no claim about your past, so the guidance makes none | F6's JD line puts the role beside branch managers, and the question is the peer's seam probe. JD because it applies the coaching requirement |
| R3-C2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | A selection scaffold with reciprocity: pick a time work crossed teams; it needs who else was involved, how you shared the credit and what the other side gained. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, that you built the monthly complaints spreadsheet your regional manager uses, at that scope, or how you would handle it | A standard peer-evaluator stem about partnership. VAL because it asks for behaviour |
| R3-C3 | "Where's the seam between branches and the contact centre, and what happens when we disagree?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say the acknowledgment before the panel finds the gap: "I've never worked in a contact centre." Then offer seam principles as questions you would ask, not a seam you claim to know: who holds a complaint when it crosses, who decides when the branch and the contact centre differ, how you would hear from both. Disagreement is a conversation about the member's outcome | F4 meets the peer probe on the line between branches and the contact centre, which the panel sits on one side of. JD because it scores the stated requirement |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3-V1 | "What does a good escalation look like to you as a branch manager, and what does a bad one look like?" | It asks for the peer's own standard before you offer yours |
| R3-V2 | "How do the hubs change which complaints land with branch supervisors?" | It ties the brief to the panel's own work and shows you read it |
| R3-V3 | "What would you want from this role in its first 90 days that would make your branch's life easier?" | The reciprocity question for a peer: it asks what you can bring them, not only what you need |
| R3-V4 | "When a complaint is about something a branch cannot fix, who holds it?" | It tests "Own the Fix" in practice and invites a real answer |
| R3-V5 | "How do you hear what members in your town are saying outside the formal log?" | It applies "Neighbours, Not Numbers" to the complaints process |

## Values cheat sheet

Round 3 is the values round. Names are as published on the values page you pasted on 20 November 2026.

| Value | Working meaning | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold at R3-A1, ending in its honest branch: if no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it |
| Plain Words | If a member needs it explained twice, the wording was wrong | Scaffold at R3-A2, ending in its honest branch. F6 is the nearest row: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Keep it at the training; do not say you wrote the script |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold at R3-A3, ending in its honest branch. F1 is the nearest row: "6 years in retail banking, the last 3 as a branch supervisor." |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F3: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Story beat is the log only; R3-A4's answer slot covers any problem you stayed with |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| 4+ years in financial-services customer operations | R1-A1 |
| experience handling regulated complaints | R1-B2, R3-B1 |
| Own the member complaints process end to end across branches and the contact centre | R2-A3 for end to end; R1-B1, R2-A1, R3-C3 for the contact centre |
| report monthly on complaint volumes and resolution times | R2-A5, R2-C2 |
| coach branch supervisors on escalations | R2-A2, R2-C3, R3-B2, R3-C1 |
| work with digital teams on self-service journeys | R2-C1 |
| confident presenting to senior leaders | R2-A4 |
| comfortable with Excel reporting | R2-A5 |
| The four published values | R3-A1 to R3-A4, and R3-A5 |
| Strategy: digital shift, hubs, business lending, app-only banks | R2-C1, R2-C2, R2-C3, R3-B3, R3-B4 |

## Prohibited claims

What this pack will not coach, built from the fit snapshot before the question banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked in a contact centre | Negative you stated, F4 | The plain acknowledgment F4 gives: "I've never worked in a contact centre." No slot |
| Has presented above regional level | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot |
| Owned the complaints process end to end | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: the material says one branch's log, not the whole process or other branches |
| Coached branch supervisors | Inflated form of F6 | F6's quote at its own scope: you trained new tellers on the escalation script. The limit is the pack's observation: the material says tellers, not supervisors |
| Reported complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope: you built the monthly complaints spreadsheet your regional manager uses. The limit is the pack's observation: the material does not say what it counted |
| Handled complaints under a regulator's rules | Inflated form of F2 | F2's quote at its own scope: you handled the branch's formal complaints log. The limit is the pack's observation: the material says a formal log, not what governed it |
| Built the monthly report in Excel | Inflated form of F9 | F9's quote at its own scope: you built the monthly complaints spreadsheet your regional manager uses. The limit is the pack's observation: the material says spreadsheet, not the tool |

## Sources

Provided documents: the JD, the four published values, the recruiter's email on the process, the 2026 strategy brief as summarised, and your background, all as pasted in your message on 20 November 2026. No `tuesday-dossier.md` was present.

No searches or fetches were sent. The values page was pasted, not linked, so it was not fetched.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values text you pasted fixes the four names and their wording for the cheat sheet and the VAL questions |
| 2. Ashgrove interview process, member-services roles | skipped | The recruiter's email fixes the three rounds, who runs each, their lengths and the panel's scoring against the values; persona weights follow it |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 brief you pasted, about four months old, fixes the CO and CASE questions and the grounding brief |
| 4. Interviewer names at Ashgrove | n/a | No names have been assigned, so there is no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, or a fuller account of your complaints work → F2, F3, F5, F6 and F9 quote only your message; each sentence you add becomes new evidence and may close a slot
- Your answers to the slots in F2, F3, F5, F6, F7 and F9 → each becomes a quoted fact in the snapshot and regenerates the rows and questions that draw on it
- The interviewers' names and public profiles, once assigned → a reading of each, persona weights per panel member, and a reverse question tied to each one's own path
- The recruiter's view of the 20-minute case: its format, any advance material, who scores it → the case rehearsal in R3-B1 fitted to the real shape
- Who the JD means by senior leaders → whether F8's stated limit sits above or at the level the role presents to
- A deeper research pass, offered once → up to 6 more searches and 2 more fetches, several more minutes, covering recent organisation context and loop reports for this kind of role
- A `tuesday-dossier.md` from an earlier fit analysis of this role → verified evidence and a ranked objection to rehearse against, never a precondition for this pack
