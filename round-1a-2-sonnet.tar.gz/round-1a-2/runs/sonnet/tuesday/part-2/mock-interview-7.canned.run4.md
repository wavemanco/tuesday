Quick status: I've run four searches (values, interview loop, strategy, interviewer) and found Saltmarsh's own pages. I'm fetching two of them now, then I'll build the pack.
Femi, your prep pack is saved as `saltmarsh-games_live-operations-producer_interview_pack.md`. I built it as a hiring-manager round with Tobias, and I haven't confirmed that he's the person you'd report to.

It has 20 questions across six personas. The pack names C2 as the highest-ROI prep: "You haven't worked on a game with in-app purchases. How would you get up to speed?" It sits next to Saltmarsh's own season-pass announcement.

Say the word and I'll play the Skeptic on C2 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, and did the recruiter say anything about the interview's format or what to prepare? The answer reweights the persona table and the question banks.
Can you paste your CV, or say skip and I'll stay with the five sentences from your message? A CV swaps those sentences for your exact CV wording in the fit snapshot.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Prepared for Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Session: one 60-minute interview. Relationship: built as a hiring-manager round, assumed and not confirmed; the persona table shows what moves if that is wrong.

## How to use this pack

Personas are how a question arrives (who is asking, in what style). Types are what the question is scoring. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you know the company's strategy and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you here: it gives two honest branches, and either one is a good answer.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one title, and does not show events or a second title; nothing is inspected behind it. The words stay at the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's live-events and two-titles wording makes a probe on both likely. If any of those drops were timed events, or you ran a calendar for more than one title, say which, in your own words; if not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: the JD names four disciplines on each update, so expect a probe on who you worked with. If you worked with any of them on a drop, say which and how, in your own words; if none, or if the work ran another way, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the monthly numbers, and shows no event review or ownership of KPIs behind them; nothing is inspected. The words stay at the quote: "Presented the monthly retention numbers to the studio head." Answer slot: the JD's post-event review line makes a probe on whether those numbers followed a review of a specific event likely. If a review of one drop or event came before the numbers, say how it ran and which part was yours; if there was no such review, or it was not yours, say so plainly and stay with presenting the monthly numbers |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote it and your QA team still uses it, not that you ran it release by release; nothing is inspected. The words stay at the quote: "Wrote the release checklist our QA team still uses." Answer slot: the JD's manage-with-QA wording makes a probe on running it likely. If you ran it on releases, say how and with whom in QA, in your own words; if you did not, or it was QA's to run, say so plainly and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [grounded] | discovery | Your material gives four years as an associate producer and does not say whether the title you produced was a live-service game. Answer slot: the JD's 3+ years line makes a probe on which years were live-service likely. If the main title was a live-service game, say for how many of the four years you produced it, in your own words; if it was not, or you cannot say it was, say so plainly and stay with the calendar you ran |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a line in your message with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: weekly, one main title, two years, because a count beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but the quote shows you presented the numbers, not how they were counted, so expect the probe to go there. Lead with it in the quote's own terms: monthly, retention numbers, the studio head |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | Derived from the quote: a written checklist is writing, and the quote does not say how it read to the people using it. Answer slot: the JD's clear-writing line makes a probe on a piece of your writing likely. If you can say how you know it reads clearly to the people using it, say so, in your own words; if you do not know, or never checked, say so plainly and stay with the fact that QA still uses it |
| F9 | In-app-purchase experience (not a JD line; you raised it) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F10 | Having led a team (not a JD line; you raised it) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you said so. Words: "I haven't led a team." Then how you would work with people you do not manage, said as a plan and never as a past. F2 holds the coordination question, which your material leaves open |

## Reading the interviewer

Public professional footprint only: one talk listing.

| Item | What it says, and what it means for you | Provenance |
|---|---|---|
| Talk | GDC 2026, "Patch Notes Are a Promise" by Tobias Wrenfield, Head of Live Operations at Saltmarsh Games: a live team is judged by how often its patch notes describe what actually shipped | [grounded] |
| Reading of the talk | Expect attention to what shipped versus what was announced. A2 and B2 rehearse it. Derived from the talk's argument and the published value "Ship the Patch Not the Promise" | [inferred] |
| Career path | Previously a QA lead at a console studio | [grounded] |
| Reading of the path | A former QA lead is likely to read a release checklist closely; expect a probe on F4's wording and on how the checklist runs. Derived from the path above | [inferred] |
| Mirror opportunity | Shared vocabulary, not a shared past: his path includes QA release work, and F4's evidence reads "Wrote the release checklist our QA team still uses." Use it in the quote's own words. Your material does not say you worked in QA, so do not suggest it | [inferred] |

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy | Provenance |
|---|---|---|---|---|
| Case/Strategist (bank A) | A live incident tabletop on a simulated outage during a live event | High. The careers page describes the interview as a live-incident tabletop, then a values conversation, and the hiring-manager prior also puts Case/Strategist first. Top weight: 5 questions | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully | [grounded] |
| Values/Behavioral (bank B) | The values conversation in the same hour, on Saltmarsh's three published values | High. The same page documents a values conversation, so this persona is guaranteed in this session. Top weight: 5 questions | Choose a story per value only where your material carries one; otherwise use the scaffold and its honest branch; "we" for context, "I" for what you did | [grounded] |
| Skeptic (bank C) | Quiet probing of the gaps you named: in-app purchases, never led a team, live-service years | Mid. Hiring-manager prior, plus F5, F9 and F10. Weight: 3 questions | Rehearse the C2 objection until it is boring; plain acknowledgment, then a plan | [inferred] |
| Data-Driven Prober (bank D) | Line-by-line questions on the calendar and the retention numbers | Mid. The JD names retention metrics and you named retention numbers; no interviewer signal tilts it further. Weight: 3 questions | Know what you can and cannot say about how each number was counted; say plainly when you do not know | [inferred] |
| Pressure (bank E) | Time-boxed or devil's-advocate challenges, possibly inside the tabletop | Low. No source describes a stress style; the tabletop may borrow the time pressure. Weight: 2 questions | Pause, restate, hold through two follow-ups, then concede specifically | [inferred] |
| Conversational (bank F) | A friendly opener and a motivation question | Low. Openers like this arrive in most interviews, and they are still scored. Weight: 2 questions | A 90-second arc built only from your sentences | [generic] |
| Peer Evaluator | Not built | A hiring-manager round does not call for it. If Tobias turns out to be a peer rather than your manager, add this bank | None | [inferred] |

## Question banks

### Bank A: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Mid-event, a reward stops landing for part of your player base and support messages are climbing. Walk me through your first fifteen minutes." | CASE | [generic] | Structure it aloud: what is broken and for whom, who can stop the event, what players are told and when, and what gets recorded for the post-event review. The question needs no claim about your past, so the guidance makes none | The simulated-outage tabletop is the core of this loop (Sources, row 2). CASE because it scores structure under pressure; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| A2 | "The fix will take three hours. What do you tell players, and what do you not say yet?" | CASE | [inferred] | Separate what is built and confirmed from what is hoped, say only the first, and name when the next update comes. If pushed for a firm time, hold the line on what you know and concede the rest plainly. No claim about your past | Derived from the published value "Ship the Patch Not the Promise" and the interviewer's talk theme (reading the interviewer). CASE delivery, with VAL content |
| A3 | "QA has not signed off the build an event depends on, and the event starts in six hours. What do you do?" | CASE | [generic] | Structure it: what QA flagged and how serious it is, the options (ship, delay, cut scope, ship with the known issue named), who decides, what players are told, and what the checklist should change afterward. No claim about your past | The JD's release-checklist-with-QA line (F4's requirement), asked as a decision rather than a record. JD content, CASE delivery |
| A4 | "Tidepool Tactics and Lantern Row are moving to one shared events calendar from February 2027. Sketch how you would plan it. What do you need to know first?" | CO | [grounded] | Clarify first (what the shared calendar must serve, what each title's players expect), then objective, segmentation, approach, metrics, risks. Challenge one premise respectfully, and use the company's own words: season pass, shared calendar. The question needs no claim about your past, so the guidance makes none | Grounded in Project Larkspur (Sources, row 3). The JD's two-titles line does not name its titles, so the pack does not assume these are the two. F1 is thin, so rehearsing the planning itself matters; CO primary, CASE delivery |
| A5 | "Retention dropped 20% after the last event. Diagnose it." | CASE | [generic] | Clarify which retention measure, which players, against what baseline, and what else changed. Then segment, offer hypotheses, say what data you would pull, and name the assumption in your diagnosis you would defend least. No claim about your past | The JD's retention-metrics line (F7's requirement) as a live problem. JD content, CASE delivery |

### Bank B: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the plan and the players pointed in different directions." | VAL | [grounded] | Selection scaffold: pick an occasion with a named plan, a signal from players, a decision you made and a cost you can name. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Theme from the published value "Players Before Plans" (Sources, row 1). Your material shows no such occasion, so this is a scaffold, not a story map |
| B2 | "When have you held back an announcement until the thing was actually built?" | VAL | [grounded] | Selection scaffold: pick an occasion where something was promised or expected and you waited for it to be real; name what was at stake and what people heard from you. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Theme from the published value "Ship the Patch Not the Promise". No sentence of yours carries a story here, so this is a scaffold |
| B3 | "When have you left a process or a checklist better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote the release checklist, and your QA team still uses it; those are the beats the quote states, told in your own words. Answer slot: the value's line on leaving the checklist better makes a probe on changes after releases likely. If you changed it after a release, say what changed and why; if you did not, or it was not yours to change, say so plainly and stay with having written it | Theme from the published value "Leave the Build Greener"; F4 is the only evidence that fits |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick an occasion where the news was unwelcome, you said it anyway, and the relationship was intact afterward. Your material shows no unwelcome news, so if no such time comes to mind, say so plainly, then give the nearest thing it does carry: you presented the monthly retention numbers to the studio head, or how you would handle it | A standard values stem for this persona. F3 is the nearest evidence and does not show a hard truth landing, so the scaffold does not supply one |
| B5 | "Tell me about a piece of your writing that other people had to act on." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F8: you wrote the release checklist, and your QA team still uses it; the beats the quote states, in your own words. Answer slot: the JD's clear-writing line makes a probe on how you know it reads clearly likely. If you can say how you know, say so; if you do not know, or never checked, say so plainly and stay with the fact that QA still uses it | The JD's clear-written-communication line (F8's requirement). Asked as a behavioral prompt, scored as JD |

### Bank C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The posting asks for 3+ years producing live-service games or apps. Where does that show up in your four years?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Say the years and the role in those words, then the calendar: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if the main title was a live-service game, say for how many of the four years you produced it; if it was not, or you cannot say it was, say so plainly and stay with the calendar you ran. Hold the quoted facts through a follow-up; concede only what the slot's second branch says | The JD's years requirement, aimed where F5 is thin. JD because it scores a stated requirement |
| C2 | "Saltmarsh is moving to a season-pass model. You haven't worked on a game with in-app purchases. How would you get up to speed?" | CO | [grounded] "Never led a team, and never worked on a game with in-app purchases." | The highest-ROI rehearsal in this pack. Level 1: volunteer the limit in your first sentence: "I haven't worked on a game with in-app purchases." Level 2: give a plan in your own words, naming the first things you would learn and who you would ask, by role. Level 3, if pushed on what you would get wrong first: name one thing you would expect to misjudge. Level 4, if pressed to prove readiness: concede plainly that you would be learning it, not applying it, and do not name a monetization method or metric you have not worked with. Do not offer another kind of game experience as a substitute | F9 is the stated gap, and the Larkspur announcement (Sources, row 3) puts a season pass on the table, so this objection arrives in some form. CO primary, because the question is aimed at the company's direction |
| C3 | "You haven't led a team, and the JD has you coordinating design, art, engineering and community on each update. Engineering tells you a date can't hold. What do you do?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Open with the plain acknowledgment, "I haven't led a team." Then structure the decision: what changed and what is firm, the options (move the date, cut scope, split the update), who has to agree, and what each other discipline hears and when. Answer slot: if you have worked with any of the four disciplines on a drop, say which, in your own words; if none, or if the work ran another way, say so plainly and stay with the calendar you ran | F10 is the stated gap, and F2's requirement is the JD line the question stands on. JD because it scores the coordination line |

### Bank D: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the weekly content-drop calendar you ran." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F6: a weekly calendar, for your main title, over two years; the beats the quote states, in your own words. Answer slot: the JD's plan-and-run wording makes a probe on how drops were chosen and sequenced likely. If you decided what went into each drop and in what order, say how; if that was set elsewhere, or there was no set order, say so plainly and describe how you ran the calendar | F6 is the evidence for the content-calendar requirement and the likeliest place to be probed; EXP because it tests what was yours |
| D2 | "Walk me through the monthly retention numbers you presented to your studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Story-mapped on F7: monthly, retention numbers, the studio head; the beats the quote states, in your own words. Answer slot: expect probes on how each number was counted, what it was most sensitive to, the assumption you would defend least, and which part was yours; answer each in your own words, and if you do not know how one was counted, say so plainly | F7 is where a prober goes first; EXP because the rehearsal is precise attribution of what the numbers were and what was yours |
| D3 | "Tell me about a time you reviewed how a content drop performed." | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a drop where you can say what was looked at and what followed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: you presented the monthly retention numbers to the studio head, or how you would run one. Answer slot: the JD's post-event review line makes a probe on who ran the review likely. If a review was yours, say how it ran; if it was not, or there was none, say so plainly and stay with presenting the monthly numbers | The JD's post-event-review line (F3's requirement), aimed where F3 is thin. JD because it scores a stated responsibility |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause and restate the question. Hold the quoted sentence through two follow-ups by returning to it, never by adding to it. Answer slot: if any part of the calendar was set by someone else, say which part and who; if all of it was yours, say that and stay with the quote. Concede specifics plainly and never fold on the core claim | F1 and F6 both rest on this sentence, so attribution is where pressure lands; EXP because it tests honesty about your share |
| E2 | "Sixty seconds: why you over an internal candidate?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Never led a team, and never worked on a game with in-app purchases." | Say the two things you did, the calendar and the checklist, in those words, and let the interviewer draw the inference; make no claim about the other candidate. If challenged, hold on those two sentences and concede the named gap in the quote's own words: "I haven't worked on a game with in-app purchases." | A standard pressure stem; F4, F6 and F9 are the facts it draws on |

### Bank F: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc built only from your four sentences, each at its own scope, in order: the four years as an associate producer at a puzzle-game studio, the calendar, the checklist, the retention numbers. Answer slot: why this role and why now is not in your material; give your own reason, in your own words | Casual openers are scored; F5, F6, F4 and F7 supply the facts |
| F2 | "What drew you to Saltmarsh?" | CO | [grounded] | Pick one of the three published values that you actually connect with and say why, in your own words; do not recite all three. If none is yours, say so plainly and name what you do connect with. No claim about your past beyond what you choose to say | Motivation consistency is the scoring; the published values (Sources, row 1) are the only attributable material the pack has on what Saltmarsh says about itself |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A4, D1, E1 |
| "coordinate design, art, engineering and community teams on each update" | C3 |
| "own the post-event review and the KPIs it reports" | D3, A1 |
| "manage the release checklist with QA" | A3, B3 |
| "3+ years producing live-service games or apps" | C1 |
| "experience running a content calendar" | D1, E1 |
| "comfortable with player-retention metrics" | A5, D2 |
| "clear written communication" | B5 |

## Values cheat sheet

A values-style round is documented: Saltmarsh's careers page describes a values conversation within the interview. Official names are from the fetched values page.

| Value (official name) | Working meaning (paraphrased) | Your mapped story | Provenance |
|---|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | None carried by your material. Scaffold: pick an occasion where a plan and a player signal pulled apart, with a decision and a cost you can name; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it (B1) | [grounded] |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | None carried by your material. Scaffold: pick an occasion where you waited until something was real before saying it; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it (B2, A2) | [grounded] |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." Beats are the quote's only; the slot in B3 covers any later changes | [grounded] |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| G1 | "Your GDC talk argued that a live team is judged by how often its patch notes describe what actually shipped. How does this team measure that today?" | Tied to his own published argument; it shows you researched him, not only the company | [grounded] |
| G2 | "You were a QA lead before live operations. What did that change about how you run a release checklist?" | Tied to his own career path; it turns the checklist into a peer conversation on shared vocabulary (F4) | [grounded] |
| G3 | "Project Larkspur retires per-title event teams for a single live-ops group. What does a producer own differently in that model?" | Shows you read the strategy and asks what you need to know before accepting | [grounded] |
| G4 | "What would my first post-event review be judged on?" | Turns the JD's review-and-KPIs line into a concrete expectation | [grounded] |
| G5 | "Players Before Plans: has the calendar ever given way to players here, and what did it cost?" | Asks for a real example of a published value in use rather than the slogan | [grounded] |
| G6 | "How do in-app purchases and the season pass shape what the events calendar can promise?" | Turns your stated gap (F9) into diligence about the job you would be doing | [grounded] |

## Prohibited claims

What this pack will not coach, built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked on a game with in-app purchases | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot |
| Has led a team | Negative you stated, F10 | The plain acknowledgment F10 gives: "I haven't led a team." No slot |
| Ran a live-events calendar, or a calendar for two titles | Inflated form of F1 | F1's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The limit is the pack's observation: the material says content drops for one title. C1's and E1's slots stay inside the quote |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope: "Presented the monthly retention numbers to the studio head." The material says you presented numbers, not that you owned a review. D3's slot stays inside that |
| Managed the release checklist on each release | Inflated form of F4 | F4's quote at its own scope: "Wrote the release checklist our QA team still uses." The material says you wrote it, not that you ran it. B3's slot stays inside that |
| Has three or more years of live-service production | Inflated form of F5 | F5's quote at its own scope: "4 years as an associate producer at a puzzle-game studio." The material does not say which years were live-service. C1's slot asks only that |

## Sources

Provided: the job description you pasted; your message (the source of every quoted sentence about you). No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Query or fetch | What came back |
|---|---|
| Search: Saltmarsh Games values | https://saltmarshgames.com/values |
| Search: Saltmarsh Games interview process live operations producer | https://saltmarshgames.com/careers/interviewing (read from the search result; not fetched) |
| Search: Saltmarsh Games strategy news mobile | https://saltmarshgames.com/news/project-larkspur |
| Search: Tobias Wrenfield Saltmarsh Games | https://talks.gdconf.example/2026/patch-notes-are-a-promise (read from the search result; not fetched) |
| Fetch: https://saltmarshgames.com/values | The three published values and their one-line definitions |
| Fetch: https://saltmarshgames.com/news/project-larkspur | September 2026: Tidepool Tactics and Lantern Row move to a season-pass model with one shared events calendar from February 2027, and per-title event teams are retired in favour of a single live-ops group |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet and bank B, with the official value names from the fetched page |
| 2. `Saltmarsh Games interview process live operations producer` | yes | The loop: one 60-minute interview with the hiring manager, a live-incident tabletop then a values conversation, no take-home. It sets persona weights and bank A; no graded-deliverable section follows because none is announced |
| 3. `Saltmarsh Games strategy news` | yes | A4, C2's rationale and G3; the grounding-brief section is not built because no L2 pass ran |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | The interviewer read, A2, G1 and G2 |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Whether Tobias is your future manager, and anything the recruiter said about the interview's format → persona weights confirmed or reweighted, and any announced format added
- Your CV → the quoted sentences in the fit snapshot become your exact CV wording, and F2, F5 and F8 may find lines this message did not carry
- Your answers to the slots in F1, F2, F3, F4 and F5 → those rows upgrade from open slots to quoted evidence, and the banks that draw on them regenerate
- The time you have before the interview → a prep triage schedule sized to it
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on Larkspur and the live-ops reorganization, the interviewer's other talks and writing, and reports on this company's tabletop format. This is the one offer of it
- A tuesday-dossier.md from an earlier role check → evidence-graded gaps and a named top objection to replace the ones this pack inferred
