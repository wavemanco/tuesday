Status: the pack file is written. I'm fixing one formatting slip, a Provenance cell with three labels where the rules allow one. Then I'll present it.
Dara, your prep pack is saved at `/var/tmp/tuesday-measure/1a2/runs/sonnet/tuesday/part-2/rooms/case-8-canned-0357f6c5/Ashgrove_Credit_Union_member-experience-lead_interview_pack.md`.

I built it as three mini-packs, one per round on 29 November. Each has its own persona weights, 10 to 11 questions and reverse questions. The panel round also has a values cheat sheet for the four Ashgrove values. Everything came from what you pasted, so I ran no searches.

The highest-ROI prep is question 2B1 in round 2: "You've never worked in a contact centre, and this role owns the process there too. How will you do that?" The pack rehearses it with three follow-ups. Say the limit first, then stay with what you actually did, then give a plan for learning the contact centre. Presenting above regional level is the second gap, covered in 2B3.

Where your four background sentences don't show something the interviewers will probe, the pack gives you an answer slot instead of a story. Examples are what the complaints log was kept for, what your spreadsheet counted and which tool it was built in, and whether you've worked with a digital team. Answer from your own experience, or say plainly it wasn't yours. Your CV and your answers to those slots would let me turn them into proper stories.

Say the word and I'll play the Skeptic on 2B1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions, or convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove_Credit_Union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Prepared for Dara. Loop mode: three scheduled rounds on 29 November 2026.

| Round | Who | Length | What the recruiter's email says |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Not described beyond the slot |
| 2 | Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | Panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation. The panel is also the values round and scores against the four values |

Interviewer names are not assigned yet, so there is no interviewer read. The upgrade menu says what names would add.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Question IDs read as round, persona letter, number. 2B1 is round 2, persona B, question 1.
- The five type tags:
  - VAL: whether your past behaviour shows Ashgrove's published values.
  - EXP: whether the claims in your own account of your background hold up, and what was actually yours.
  - JD: whether you can do the listed job, gaps included.
  - CO: whether you know Ashgrove's strategy and can think at its level.
  - CASE: a live problem from the role, scored on structure and reasoning.
- Provenance labels: `[grounded]` traces to something you or Ashgrove supplied. `[inferred]` is this pack's derivation, with the derivation named. `[generic]` is a pattern with no claim about Ashgrove or you.
- Answer guidance is scaffolding, not a script. Where a row says "answer slot", it is an instruction for the interview: answer from your own experience in your own words, or say plainly that the practice was not yours.
- The only things this pack knows about your past are the four sentences you wrote in your message. Everything it says about you quotes them.

## Fit snapshot (shared across all three rounds)

Requirements are quoted from the JD you supplied. Evidence is your own words from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's log and the training on the escalation script, not the process end to end, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what sits around the log likely. If you had a hand in other stages of a complaint, say which and what you did, in your own words; if the log was the part you handled, or the other stages were not yours, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. The material also shows the branch's log and no work across branches, which is the pack's observation, not words for you. Nothing is added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says you built a monthly complaints spreadsheet that your regional manager uses. It does not say what the spreadsheet counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's reporting line makes a probe on what the spreadsheet tracked likely. Say what it tracked and how each figure was counted, in your own words; if you do not know how something was counted, or part of it was not yours, say so plainly and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your sentence says new tellers and the escalation script, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on who the training was for and what it covered likely. Say who and what, in your own words; if it was new tellers and the script, say so plainly and stay there |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Nothing in your material speaks to this. Answer slot: the JD's digital line makes a probe on your experience likely. If you have worked with a digital team or on a self-service channel, say what and which part was yours, in your own words; if not, say so plainly, then say what you would want to learn from the digital team first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on what the six years held. Lead in the quote's own terms: six years in retail banking, the last three as a branch supervisor |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your sentence says a formal complaints log and does not say what governed it. Words: "I handled the branch's formal complaints log." Answer slot: the JD's wording on this requirement makes a probe on what the log was kept for likely. Say what it was kept for and who it went to, in your own words; if you do not know what governed it, or it was not tied to an outside rule, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare for it, said as a plan and never as a past. The material does not show whom Ashgrove counts as senior leaders, which is the pack's observation, not words for you |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says spreadsheet and does not name the tool. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names a tool, so a probe on which one you used and what you did in it is likely. Say which tool and what you did in it, in your own words; if it was a different tool, say so plainly and stay with the spreadsheet you built |

## Grounding brief: Ashgrove's July 2026 strategy

This is the brief the recruiter sent you, as you summarised it. It is Ashgrove's own document, so every prepared candidate has it. Bring one item from it to show you have read it, then bring your own view with its reasons.

| Item | What it says | How to use it | Provenance |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | Raises the self-service line of the JD (F5). Used in 1A7, 2C2, 3B4 | [grounded] |
| Hubs | "consolidate eight branches into five hubs over 2027" | Complaints will move with the branches. Used in 2C2, 3B4 and the Neighbours, Not Numbers row of the values sheet | [grounded] |
| Small-business lending | "launch a small-business lending product in Q1 2027" | A new product is a new place for member complaints to arise. This is a reading of the brief, not something the brief says | [inferred] |
| Competition | "the main competitive pressure is app-only banks" | Frames why a complaint handled badly matters: a member can leave through an app | [inferred] |
| Date | Published July 2026; today is 20 November 2026 | Treat its dates as plans, not outcomes. Do not correct an interviewer who describes them differently | [grounded] |

---

# Round 1: recruiter screen (30 minutes)

## Persona weights

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational | Friendly, unstructured. Logistics asked casually | Dominant. The recruiter-screen prior is Conversational plus a light Skeptic, and the risk is treating it as unscored | Prepare a 90-second arc for the background question. Treat every casual question as scored. Know your own pay, notice, location and reason for leaving before you dial in |
| B. Skeptic (light) | A knockout check on the JD's must-haves | Medium. A recruiter checks the requirements the hiring manager will check, and your own message names two gaps | Say the plain acknowledgment once, calmly, then move to what your material does carry |
| C. Data-Driven Prober (light) | One CV line probed for detail | Low. A 30-minute screen has room for one | Know what the spreadsheet counted, or say you do not know |

## Question bank

### A. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "Walk me through your six years in retail banking." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Story-mapped on F6: the six years in retail banking and the last three as a branch supervisor are the beats the quote states. Tell them in your own words in about 90 seconds and end on why this role. Add what you did in those years only where it is true and yours; the quote carries no more | The opener sets the frame for the whole screen. EXP because it tests whether the account matches the CV-style claim in F6 |
| 1A2 | "Why Ashgrove, and why now?" | CO | [grounded] | The question needs no claim about your past, so the guidance makes none. Choose from what Ashgrove has published: the four values, or a priority in the July strategy brief. Say which is true for you and why, in your own words. The pack does not supply your reason | Recruiters check motivation against what the organisation says about itself. CO because the answer shows homework, and the sources are the values page and the brief you supplied |
| 1A3 | "What salary are you looking for?" | JD | [generic] | Logistics slot, on the job's terms. Give your own figure, or ask for the role's band first. The pack supplies no figure | Pay is a standard recruiter-screen question. JD because the answer is about the listed job's terms |
| 1A4 | "What's your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period, in your own words, and say whether it can be shortened only if it can | A standard screen question on the job's terms. JD for the same reason as 1A3 |
| 1A5 | "Where would you be based, and what travel between sites would work for you?" | JD | [generic] | Logistics slot. Say where you can work and how often you could travel between sites, as it really is for you. The JD places the role across branches and the contact centre, so a straight answer is more useful than a flexible-sounding one | Location is a logistics check, and the role spans several sites. JD because the JD's scope raises it |
| 1A6 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot on your reason for leaving. Give one honest sentence of your own. Say what you are moving toward only if it is true, and say about your current employer only what you would say in front of them | The reason for leaving is checked for consistency with the "why Ashgrove" answer in 1A2. EXP because it tests whether the story holds together |
| 1A7 | "How do you feel about more member service moving to digital?" | CO | [grounded] | Give your honest view. Answer slot: the JD's digital line (F5) makes a probe on your experience likely. If you have worked with a digital team or on a self-service channel, say what and which part was yours; if not, say so plainly and say what you would want to learn from the digital team first | The brief's 40% digital target and the JD's self-service line both raise this. CO because it tests whether you can think at Ashgrove's altitude |

### B. Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose the part you honestly think is weakest. Your own sentence names two. If it is the contact centre, the words are "I haven't worked in a contact centre." Then a plan: what you would do first to learn it. If it is presenting, the words are "I haven't presented to anyone above regional level." Say it once and keep moving. Never reach for a claim to cover either | F2 and F8 are the gaps you stated, so this is the likeliest form the objection takes in a short screen. JD because it scores the listed requirements |
| 1B2 | "Walk me through the formal complaints log you handled, and what it was kept for." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F7: the formal complaints log, handled by you, is the beat the quote states. Answer slot: the JD's wording on this requirement makes a probe on what governed the log likely. Say what it was kept for and who it went to, in your own words; if you do not know what governed it, or it was not tied to an outside rule, say so plainly and stay with the log | The JD's complaints requirement is a likely screen item, and F7 is where your material is silent on what governed the log. JD because it scores a stated requirement |

### C. Data-Driven Prober (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1C1 | "Tell me about the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F3 and F9: you built it, it was monthly, and your regional manager uses it. Those are the beats the quote states, in your own words. Answer slot: expect a probe on what the spreadsheet tracked, how each figure was counted, and which tool it was built in. Say what it tracked, how each figure was counted and the tool, in your own words; where you do not know how something was counted, or part of it was not yours, say so plainly and stay with what you built | It is the one line in your material that matches the JD's reporting and spreadsheet requirements, so it is the line most likely to be probed. EXP because it tests what was actually yours |

## Reverse questions

| # | Question to ask the recruiter | Why it lands |
|---|---|---|
| R1 | "What would a strong first six months look like in this role?" | It shows you think in outcomes, and a recruiter can relay what the hiring team told them |
| R2 | "Are complaints in the branches and the contact centre handled as one process today, or two?" | It takes the contact centre seriously, and the answer tells you how big the gap in F2 really is |
| R3 | "Is there anything to prepare or bring for the 20-minute case in round three?" | Pre-declared deliverables are graded, and one email can settle whether there is one |
| R4 | "Who will be on the round-three panel, and what does each of them lead?" | Names and roles let you tune the pack, and recruiters can often share them before the day |
| R5 | "What is the timeline for a decision after the 29th?" | It is practical, closes the call cleanly and avoids the weak "no questions" answer |

---

# Round 2: Head of Member Services, your would-be manager (45 minutes)

## Persona weights

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| A. Values/Behavioral | "Tell me about a time…" scenarios | High. The recruiter says this round is mostly behavioural, and the values are published | Use "I" for what you did and "we" for context. Choose stories where the hard truth actually landed. Where your material carries no story, say so plainly and give the nearest thing it does carry |
| B. Skeptic | Quiet, persistent probing of the gaps | High. The hiring-manager prior is Case plus Skeptic, and a future manager is buying capability and derisking gaps. Your message names two gaps | Rehearse 2B1 until it is boring. Use only adjacent material you actually stated, and say the limit before it is asked for |
| C. Case/Strategist | A live problem from the role's roadmap | Medium. The hiring-manager prior includes it, but the recruiter calls the round mostly behavioural | Clarify, then structure, then answer. Challenge one premise respectfully |
| D. Data-Driven Prober | Line-by-line probing of the reporting claim | Medium-low. Reporting is a core duty and your spreadsheet is your main reporting evidence | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know |

## Question bank

### A. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2A1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you gave someone senior news they did not want. It needs a named stake, a moment you did not soften it, and a relationship that was intact afterwards. Choose one where the truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's senior-leader line (F8) and the monthly reporting duty make news that is hard to hear likely. VAL because it tests behaviour, not knowledge. The pack has no sentence of yours that carries such a story, so it supplies none |
| 2A2 | "When did you put a member ahead of an internal target?" | VAL | [grounded] | Selection scaffold for Members First, Always: pick a time a member's need and a rule or a target pulled in different directions. It needs a named stake, what you decided and how the member and your colleagues were left. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First, Always is Ashgrove's first published value, and round 3 will score against it. VAL because it tests behaviour against the value by name |
| 2A3 | "Tell me about a time you coached someone through a hard escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4: you trained new tellers on the escalation script, which is the beat the quote states. Answer slot: the JD's coaching line makes a probe on a live case likely. If you stood beside someone during one, say what happened and which part was yours, in your own words; if your training was the script and there was no live case, say so plainly and stay with the training | The JD's escalation-coaching duty raises this, and F4 shows where your material stops. JD because it scores a stated duty |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2B1 | "You've never worked in a contact centre, and this role owns the process there too. How will you do that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | **The highest-ROI prep in this pack.** Say the limit first, before it is asked for: "I haven't worked in a contact centre." Then what your material carries, at its own scope: "I handled the branch's formal complaints log." "I trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." Do not say or imply that any of these was contact-centre work. Then a plan, said as a plan: you would learn how the contact centre works from the people there before you changed anything, only if that is true of you. Follow-up 1, "What would you do in week one?": stay with the plan. Follow-up 2, "Why take the risk on you over someone who has run a contact centre?": hold the same quotes, and concede plainly that you cannot match their time in the seat, without folding on what the quotes carry. Follow-up 3, "What if the contact centre team does not accept someone from the branch side?": answer as a plan, starting with asking them what working in that process is like | F2 is a gap you stated, and the contact centre is half the role's scope in the JD, so some form of this question will arrive in round 2 or round 3. JD because it scores the stated scope. It is the deepest rehearsal because it is the likeliest objection and the one where the material is thinnest |
| 2B2 | "What's your experience of working with digital teams?" | JD | [grounded] | The question needs no claim about your past, so the guidance makes none. Answer slot: the JD's digital line (F5) makes your experience the subject. If you have worked with a digital team or on a self-service channel, say what and which part was yours, in your own words; if not, say so plainly, then say what you would want to learn from the digital team first and what a member who needs help would need from a self-service journey | F5 is silent in your material, and the brief's digital target raises its weight. JD because it scores a stated duty |
| 2B3 | "You'd report monthly to senior leaders. Have you presented to leaders at that level before?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say the limit plainly: "I haven't presented to anyone above regional level." Then a plan, said as a plan: how you would prepare for your first leadership report, for instance asking your manager what senior leaders want to see, only if you would really do that. Do not reach for an experience your sentence does not carry | F8 is a gap you stated, and a would-be manager decides how much support the ramp needs. JD because it scores the stated requirement |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2C1 | "Sketch the plan for owning complaints across branches and the contact centre. What do you need to know first?" | CASE | [grounded] | The question asks about no past, so the guidance makes no claim about yours. Clarify first: where complaints arrive and in which channels, who holds each step today, what members say about it. Then objective, segmentation, approach, metrics and risks, thinking aloud. Challenge one premise respectfully, for example whether one owner per complaint is the right test. Use Ashgrove's own words where they fit: "keeps hold of it until it is solved", and "Plain Words" | The JD's first duty is exactly this problem. CASE because it scores structure, and the vocabulary comes from the JD and the values you supplied |
| 2C2 | "We're consolidating eight branches into five hubs over 2027. What does that change for how complaints are handled?" | CO | [inferred] derived from the brief's consolidation and the Neighbours, Not Numbers value | The question asks about no past. Bring one point from the brief to show you have read it: the eight-to-five consolidation. Then your own view, with its reasons and its concession. One example you could take or leave: watch complaints from the affected towns first, and concede that you have not seen Ashgrove's data, so it is a hypothesis. The brief is Ashgrove's own, so reciting it scores as homework and departing from it with reasons scores as judgement | The brief is the strategy source you hold, and it is public. CO because it tests whether you can think at the credit union's altitude |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2D1 | "Which two or three numbers would you put at the top of the monthly complaints report, and why?" | JD | [inferred] derived from the JD's reporting line and the Own the Fix value | The question asks about no past. For each number say what it tells a leader and what it could hide. Name the weakest assumption behind each before you are asked. One example: a fast resolution time can hide a complaint closed without the member agreeing it was solved. Say plainly if you would want to see Ashgrove's data before choosing | The JD names monthly reporting as a duty, and the Own the Fix value makes the cost of a misleading number concrete. JD because it scores a stated duty |
| 2D2 | "Walk me through the spreadsheet you built. What did it show, and who used it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F3 and F9: you built it, it was monthly, and your regional manager uses it, in your own words. Answer slot: expect follow-ups on how each figure was counted and which figure you would trust least. Say what it tracked and how each figure was counted, naming the assumption you would defend least; where you do not know how something was counted, or part of it was not yours, say so plainly and stay with what you built | It is your only reporting evidence, so a manager who owns the monthly report will go deepest here. EXP because it tests attribution |

## Reverse questions

| # | Question to ask the Head of Member Services | Why it lands |
|---|---|---|
| R1 | "What does a good monthly complaints report look like here, and who reads it?" | It ties to the reporting duty and shows you care about the reader, not only the numbers |
| R2 | "Where is complaints handling weakest today, across the branches and the contact centre?" | It invites your would-be manager to name the real problem, which is Own the Fix in practice |
| R3 | "How will the move to hubs change the work of the supervisors I would coach?" | It uses the brief and links to the coaching duty |
| R4 | "Who in the digital team would I work with first, and what is their roadmap for complaints?" | It answers the F5 gap with curiosity and shows you take the self-service line seriously |
| R5 | "What is the best way for someone coming from the branch side to learn the contact centre quickly here?" | It turns the stated gap into a joint plan and gives the manager a role in the ramp |

---

# Round 3: panel of two branch managers, the values round (60 minutes)

## Persona weights

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| A. Values/Behavioral | Scenario probes mapped to the four published values | Dominant. The recruiter says the panel is the values round and scores against the four values | One story per value where your material carries one, and a scaffold ending in the honest branch where it does not |
| B. Case/Strategist | The 20-minute escalation case | High. The recruiter names it, and 20 of 60 minutes is a third of the round | Clarify, structure, answer. Keep the member first and name who holds the complaint |
| C. Peer Evaluator | "What do I get from you" and where the seam is | Medium. A panel blends the top two personas of each member's relationship, and branch managers run the supervisors this role coaches | Reciprocity framing. Propose seam principles instead of pretending to know where the seam is |
| D. Skeptic | A quiet probe at the weakest value | Low. The panel's job is to score values more than to derisk gaps | Pick the honest answer, not the safest one |

## Question bank

### A. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3A1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold for Members First, Always: pick a time a member's need and a rule or target pulled in different directions. It needs a named stake, what you decided and how the member was left. Choose one where the hard truth landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first value, and the panel scores against it by name. VAL because it tests behaviour against the value. No sentence of yours carries such a story, so the pack supplies none |
| 3A2 | "When have you had to explain a difficult decision to a member in plain words?" | VAL | [grounded] | Selection scaffold for Plain Words: pick a time a member needed something hard explained. It needs the decision, what made it hard to say, and how you knew the member understood. Where the value says a member who needs it explained twice means "we wrote it wrong", be ready to say what you would change in the wording. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The second value. VAL because it scores clarity of explanation in behaviour, not in slogans |
| 3A3 | "You built the monthly complaints spreadsheet your regional manager uses. What can a spreadsheet like that miss about a branch's town?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F3: you built it, it is monthly, and your regional manager uses it. Those are the beats the quote states. Then your view of what numbers can miss. Answer slot: the Neighbours, Not Numbers value makes a probe on something you saw at the counter that the spreadsheet did not show likely. If there was one, say what it was and what you did, in your own words; if there was not, say so plainly and answer as how you would look for it | The third value sits against a role that reports in numbers. F3 is your one reporting sentence, so the panel can test it against the value. VAL because it scores whether you hold both at once |
| 3A4 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F1: the formal complaints log, handled by you, is the beat the quote states. Answer slot: the Own the Fix value makes a probe on one complaint you stayed with likely. If there was one, say what it was, what you did and which part was yours, in your own words; if the log's entries passed to others, or you cannot name one such case, say so plainly and stay with the log you handled | The fourth value and the one closest to your material. VAL because it tests whether past behaviour shows the value rather than whether you know it |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3B1 | "A member comes into a branch angry. They have complained twice before and say nobody has called back. The supervisor escalates it to you. What do you do, and in what order?" | CASE | [generic] | The question asks about no past, so the guidance makes none. Clarify first: what has been recorded, what was promised, whether there is a deadline we owe the member, and whether anything suggests the member needs extra care. Objective: the member leaves knowing who holds it and by when. Approach: one owner until it is solved, said in plain words, recorded, and then look for why it happened twice. Challenge one premise: is this one complaint or a pattern | The recruiter names a 20-minute escalation case. The scenario is this pack's own and a pattern for the problem, not what Ashgrove will ask. CASE because it scores structure |
| 3B2 | "The contact centre says the branch should have fixed it. The branch says it is the contact centre's. The member is stuck in the middle. What do you do?" | CASE | [generic] | The question asks about no past. Member first: name one owner today and settle who was right later. Then fix the seam. Propose principles, such as whoever finds the problem keeps hold of it, rather than pretending to know how the two teams work. Say plainly where you would want to ask both teams before deciding | The role owns the process across both channels. CASE because it scores reasoning under a live conflict. It is a pattern, so `[generic]` |
| 3B3 | "A supervisor in one of our branches keeps escalating late. How would you coach them?" | CASE | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Clarify before coaching: is it timing, confidence, or a script that is unclear? Listen first, show the escalation path in plain words, agree a small next step and follow up. If your material is called on, say it at its scope: "I trained new tellers on our escalation script." Do not describe coaching supervisors, which the sentence does not say | The JD's coaching duty is aimed at exactly this audience, and the panel manages those supervisors. CASE because it is a live problem from the role; F4 is the only evidence |
| 3B4 | "Eight branches become five hubs and 40% of member service moves to digital. How do you make sure members still feel looked after at the counter?" | CO | [inferred] derived from the brief's two targets and the Members First and Neighbours, Not Numbers values | The question asks about no past. Bring one consensus point from the brief to show grounding. Then one view of your own, with reasons and a concession: for example, which member conversations you would not move to digital first, conceding that you have not seen Ashgrove's data. The brief is public, so departing from it with reasons scores as judgement | The panel runs branches, so the hub change touches them directly. CO because it scores strategy fluency, and the brief is the source |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3C1 | "As a branch manager, what do I get from you, and where is the line between you and me when a supervisor escalates something?" | JD | [grounded] | The question asks about no past. Reciprocity first: what the branch gets, said as what you would do, not what you have done. Then seam principles rather than a claimed map: the supervisor keeps the member relationship, the complaint has one owner until it is solved, and the branch manager is in the loop. Say plainly where you would ask the branch managers what works for them | The coaching duty puts the role between the panel and their supervisors. JD because it scores that duty, and F4 is the evidence that bounds what you can say |
| 3C2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a time work spanned two teams. It needs what each team did, how credit was shared and what you did when it was uneven. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Complaints cross the branch and the contact centre, so credit is a real peer issue. EXP because it tests attribution. No sentence of yours carries such a story |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3D1 | "Which of our four values would you find hardest to live up to, and why?" | VAL | [grounded] | The question needs no story. Pick the value you honestly find hardest, say why, and say what you would do about it. The pack cannot choose for you, and the safest pick is the one a panel hears most | It tests honest self-assessment against the published values by name. VAL because the four values are the scoring sheet |

## Values cheat sheet

The values are quoted from the page you pasted from ashgrovecu.org/about/values on 20 November 2026.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold, used in 2A2 and 3A1: pick a time a member's need and a rule or target pulled in different directions, with a named stake and a decision. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs it explained twice, the wording is the problem | Selection scaffold, used in 3A2 and 3B1: pick a time you explained something hard in plain words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Neighbours, Not Numbers | Every branch is part of its town, so numbers alone are not the picture | F3: "I built the monthly complaints spreadsheet our regional manager uses." The beat is that you built the numbers side. Answer slot in 3A3: if you saw something at the counter that it did not show, say what; if not, say so plainly |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The beat is the log you handled. Answer slot in 3A4: if there was a complaint you stayed with until it was solved, say what; if not, say so plainly and stay with the log |

## Reverse questions

| # | Question to ask the panel | Why it lands |
|---|---|---|
| R1 | "What do your supervisors find hardest about escalating today?" | It puts the coaching duty in their words and shows you start from their problem |
| R2 | "What could a new complaints lead do in their first month that would genuinely help your branch?" | The reciprocity question for a peer panel, and it shifts the talk from what you need to what you give |
| R3 | "How are members in your town reacting to the plan for hubs, and what are they asking you?" | It speaks to Neighbours, Not Numbers and shows you listen to the branches |
| R4 | "When has a complaint at your branch gone well, and what made it go well?" | It invites the panel to describe what they score, in their own words |
| R5 | "Which of the four values is most tested in a hard week at your branch?" | It treats the values as practice, not slogans, in the round that scores them |

---

## Requirement coverage

| Requirement | Row | Questions that cover it |
|---|---|---|
| Own the process end to end | F1 | 1B2, 2C1, 3A4, 3B1 |
| Across branches and the contact centre | F2 | 1B1, 2B1, 2C1, 3B2 |
| Report monthly on volumes and resolution times | F3 | 1C1, 2D1, 2D2, 3A3 |
| Coach branch supervisors on escalations | F4 | 2A3, 3B3, 3C1 |
| Work with digital teams on self-service journeys | F5 | 1A7, 2B2, 3B4 |
| 4+ years in financial-services customer operations | F6 | 1A1 |
| Experience handling regulated complaints | F7 | 1B2 |
| Confident presenting to senior leaders | F8 | 1B1, 2A1, 2B3 |
| Comfortable with Excel reporting | F9 | 1C1, 2D2 |

## Prohibited claims

What this pack will not coach, and why. The pack built this list from the fit snapshot before writing any question.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material says the log and the script training, not the process end to end. The slots stay inside the log |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment, from your message ("Never worked in a contact centre"): "I haven't worked in a contact centre." No slot |
| Has presented above regional level | Negative you stated, F8 | The plain acknowledgment, from your message ("I've never presented to anyone above regional level"): "I haven't presented to anyone above regional level." No slot |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: "I trained new tellers on our escalation script." The limit is the pack's observation: the material says new tellers, not supervisors. The slot asks only who the training was for and what it covered |
| Reported complaint volumes and resolution times each month | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The limit is the pack's observation: the material does not say what it counted. The slots stay inside the spreadsheet |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material says a formal log, not what governed it. The slot asks only what the log was kept for |

## Sources

Provided documents:

- The JD you pasted.
- The values page you pasted, copied on 20 November 2026 from ashgrovecu.org/about/values. It was not fetched.
- The recruiter's email on the process. It establishes the loop: three rounds on 29 November, who runs each, and that round three is the values round.
- Ashgrove's 2026 strategy brief, published in July 2026, as summarised in your message.
- Your background, in your message.
- No `tuesday-dossier.md` was present.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values page you pasted already supplies all four values by name, so it fixes the values cheat sheet and the VAL questions |
| 2. `Ashgrove Credit Union interview process member services` | skipped | The recruiter's email already fixes the rounds, who runs each and that round three is the values round, so it fixes the persona weights per round |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief you supplied already fixes the CO and CASE grounding, and it is under six months old |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer names are assigned yet, so there was no query to form. The interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewers' names once assigned → an interviewer read for each round, persona weights adjusted from their public roles and writing, and a reverse question tied to each one's own path
- The recruiter's note on what the round-three case covers, and whether anything is expected beforehand → the case rows 3B1 to 3B3 become `[grounded]` instead of `[generic]`, and a build section if a deliverable is declared
- Your CV → more evidence cells than the four sentences in your message, so F3, F5, F7 and F9 may move from `discovery` to a firmer gap type
- Your own answers to the answer slots (what the log was kept for, what the spreadsheet tracked and which tool built it, whether you have worked with a digital team, who the escalation training was for) → F1, F3, F4, F5, F7 and F9 evidence rows upgrade, and the slot guidance becomes story maps
- A deeper research pass, offered once → up to 6 more searches and 2 more fetches, several more minutes, covering Ashgrove's recent news since the July brief, interviewers' public footprint once named, and reported loop formats for this role family
- How many hours you have before the 29th → a prep triage sized to that time
- A `tuesday-dossier.md` → verified evidence and absolute prohibited claims carried in from an earlier pass, so the highest-ROI objection is evidence-derived instead of inferred
