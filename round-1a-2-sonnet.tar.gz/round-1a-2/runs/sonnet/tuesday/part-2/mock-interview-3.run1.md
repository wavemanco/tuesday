I'm running the research for your Stripe prep pack now. It covers Stripe's published values, how its interviews work, its recent strategy, and a typical Product Operations Manager posting.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/tuesday/part-2/rooms/case-3-denied-a5f571c5/stripe_product-operations-manager_interview_pack.md`. I built it for a final round with unknown interviewers, using blended persona weights. Web search was refused in this session, so none of it is researched. It has no Stripe values, no real interview loop and no strategy content. All 21 questions are labeled generic, and the fit snapshot is a worksheet because I had no CV or job description. The question I'd rehearse first is B1: "Which part of this role would you be weakest at on day one?"

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting in the final, and how many sessions is it? The answer reweights every question bank.
Can you paste the job description and a few lines on your background, or tell me to go on without them? With them, the generic rows become rows built on your actual words.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe (final round)

Interviewer: not known. Relationship to you: not known. Number and format of sessions in the final: not known. Built on those unknowns with blended persona weights; nothing in this pack asserts how Stripe runs its final.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether your past behavior shows the values a company publishes, not generic virtue |
| EXP | Whether claims about your work survive scrutiny, including what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

Three things shape every cell below. You gave no CV and no job description, so no row quotes you and every question carries the label generic. Web search was refused in this session, so nothing here is researched, and nothing about Stripe's values, interview loop or strategy appears. Where a guidance cell would normally map one of your stories, it gives selection criteria that end in an honest branch instead.

## Fit snapshot (worksheet variant)

With no CV and no JD, this is a worksheet. Requirements are role-family patterns written as plain prose, not quotes from a posting. Every evidence cell reads none given.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate launches or work across product, engineering and go-to-market teams (role-family pattern, no posting supplied) | none given | none | [generic] | discovery | Strong evidence here is a named piece of cross-team work, your part in it stated precisely, and something a colleague could confirm. Selection scaffold: pick one piece of cross-team work where your part is clear to you; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Define and track operating metrics (role-family pattern, no posting supplied) | none given | none | [generic] | discovery | Strong evidence is a metric you can explain end to end: how it was counted, what moves it, which assumption you would defend least. Selection scaffold: pick a figure you have reported that you can explain from the raw counting up; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Prioritize and improve internal processes (role-family pattern, no posting supplied) | none given | none | [generic] | discovery | Strong evidence is a process that changed, the reason it was chosen over alternatives, and what happened afterward, all in your words. Selection scaffold: pick a process change where you can state both the choice and the result; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Influence stakeholders and leadership without direct authority (role-family pattern, no posting supplied) | none given | none | [generic] | discovery | Strong evidence is a moment where you had no formal say and the outcome moved, with the other party's position stated fairly. Selection scaffold: pick a time you held a view against someone with more authority; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Customer orientation in operational decisions (role-family pattern, no posting supplied) | none given | none | [generic] | discovery | Strong evidence is a decision where a customer's need and an internal measure pointed different ways, and which way you went. Selection scaffold: pick such a decision only if one is genuinely yours; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Persona table

Loop source: none read, so no loop is established. Fallback archetype: Generic, flat weights, said plainly. Because a final round often mixes a manager-style conversation with peer-style ones, the weights blend the hiring-manager prior (Case, Skeptic) with the peer prior (Peer, Prober). That is a judgment you can override if you know who you are meeting.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy (rehearsal method) |
|---|---|---|---|
| Case / Strategist (A) | A live operational problem: plan this, diagnose that | Top tier. The hiring-manager prior, and operations roles are commonly assessed on live reasoning | Clarify first, then objective, segments, approach, metrics, risks. Think aloud and challenge one premise politely |
| Skeptic (B) | Quiet probing of gaps, motivation, why this role, why now | Top tier. Hiring-manager prior, and a final round is where remaining doubts get tested | Rehearse the single most predictable objection until it is boring. Use only evidence you actually have, and name limits plainly |
| Values / Behavioral (C) | Past-behavior prompts, often from someone outside the function | Mid tier. No published values were available, so these follow generic behavioral themes | Pick a story where the hard truth actually landed. Say we for context and I for what you did |
| Peer Evaluator (D) | Seam-splitting, collaboration, credit-sharing | Mid tier. A final often includes a peer-style conversation, but this is not known | Offer principles for the seam, not a pretended map of it. Bring what you give their team, not only what you need |
| Data-Driven Prober (E) | Walks through how your numbers were counted | Mid tier. Operations work is measured work, and metrics invite this | Know what you can and cannot say about how each figure was counted. Say plainly when you do not know |
| Pressure (G) | Time-boxes, interrupts, plays devil's advocate | Low tier. Possible in a final, but nothing here says this loop uses it | Pause, restate, hold a challenged position through two follow-ups before conceding anything real |
| Conversational (H) | Friendly, loose openers that are still scored | Low tier, but every interview opens this way | Have a 90-second arc for the biography prompt, and treat casual questions as scored |

Highest-ROI prep in this pack: B1, the Skeptic's day-one-weakness question. It targets wherever your material is thinnest, and a rehearsed, honest, non-defensive answer is the one most worth having ready.

## Question banks

Letter F is skipped for personas so question IDs do not clash with fit-snapshot rows F1 to F5. Every row below makes no claim about your past: open prompts supply no event, and case questions assume nothing.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch the plan for getting a cross-team product launch coordinated. What do you need to know first?" | CASE | [generic] | Clarify before structuring: what counts as launched, who must sign off, what is fixed and what can move. Then objective, who is involved, approach, how you would know it worked, risks. Challenge one premise politely. No claim about your past is needed | F1's territory, asked as a live problem so it presupposes nothing. CASE because it scores structure |
| A2 | "An internal process that teams were meant to adopt shows adoption down 20 percent in a month. Diagnose it." | CASE | [generic] | Ask what changed and when, who dropped off, and how adoption is measured before proposing causes. Split into causes you can test quickly, say which you would check first and why, and say what would change your mind | Covers F2 and F3 as a diagnosis problem. CASE because the answer is reasoning, not experience |
| A3 | "You are asked for ten operational improvements and have capacity for three. How do you choose?" | CASE | [generic] | State your criteria aloud before ranking anything, say who you would consult, and name what you would say to the seven that wait. Offer the criteria as a hypothesis you would test, not a fixed formula | F3 as a prioritization problem. Interviewers watch for explicit criteria and for how the losing requests are handled |
| A4 | "Launch is two weeks out. Engineering says it is not ready and go-to-market has promised customers a date. What do you do in the first hour?" | CASE | [generic] | First hour: establish the facts of readiness, the real cost of each option, and who owns the decision. Say what you would not do, such as pick a side before hearing both. Close with what you would tell each team | F1 and F4 under tension. A case, so no past is claimed |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Rehearse until boring. Name one honest gap in your own words, say what you would do in the first weeks about it, and stop. If you cannot name one, say so plainly, then name the area you expect to learn fastest and how. Do not pick a fake weakness and do not claim you have none | The most predictable objection to any finalist, and the highest-ROI prep here. JD because it scores the role's own demands; the pack cannot name your weak area without your material |
| B2 | "Why Stripe, why this role, why now?" | CO | [generic] | Three short parts, each in your own reasons: the company, the function, the timing. Use only what you have actually read or experienced about the company. This pack could not research it, so do not borrow a talking point from here | Motivation consistency is the Skeptic's core test. CO because it checks homework; generic because no research ran |
| B3 | "Product operations means different things at different companies. What does it mean to you, and where does it stop?" | JD | [generic] | Give your own definition in two sentences and one boundary, such as what the function should not own. Say how you would check the interviewer's version of the role in your first week | Role-definition mismatch is a common source of doubt. JD because it scores whether you understand the job |
| B4 | "What is prompting this move now?" | EXP | [generic] | One true reason, stated without criticizing a past employer, then what you are moving toward. Your actual reason, in your own words; do not tidy it into something you did not feel | Reason for leaving is always asked. EXP because it tests whether your account of your own history is consistent |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: a named stake, a moment you did not soften it, and an intact relationship afterward. Context as we, contribution as I. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard values probe and relevant to F4. Published Stripe values were not available, so it is not tied to any |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: the metric and the customer need must both be nameable, and the choice must be yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5 as a behavioral prompt. VAL because it scores behavior, not belief |
| C3 | "Tell me about a time you held a position under pressure from someone senior." | VAL | [generic] | Selection criteria: the stake, the moment you did not fold, and how it ended with the relationship intact. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 again, from the pressure angle. VAL because it scores composure demonstrated in the past |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Offer principles for a seam rather than a map you cannot know: who owns the decision, who is consulted, how a disagreement is escalated. Ask which seams are currently unclear. Reciprocity: say what your side would bring them | F1's cross-team territory. JD because it tests whether you understand the role's boundaries |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection criteria: an actual case where credit was shared or contested, your behavior stated plainly. If no such case comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Credit-sharing is a standard peer probe. VAL because it scores behavior |
| D3 | "What would you need from me in your first month?" | JD | [generic] | Ask for context and access, not for answers: what the team is already working on, where help is wanted, how to reach decisions quickly. Add one thing you would offer in return, in your own words | A peer is pricing the hire's cost to their load. Reciprocity framing answers it |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick a metric you have reported to leadership and walk me through how it was counted." | EXP | [generic] | Selection criteria: choose a figure you can explain from the raw counting up. State what you know and what you do not. If no such figure comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F2 as a probe. Prober asks for the denominator, so choosing the figure well is the whole preparation |
| E2 | "Think of a figure you have presented. Which assumption behind it would you defend least?" | EXP | [generic] | Name the assumption in your own words before they do. If you do not know how it was counted, say so plainly. A figure you cannot explain is the wrong one to choose | The weakest-assumption move turns a gotcha into credibility. F2 again |
| E3 | "Of the work you have described today, how much was actually you versus the team?" | EXP | [generic] | Say plainly which parts were yours, which were shared and which were someone else's. Precise attribution beats a big share. If a part was not yours, say so | Attribution honesty is the Prober's real test. EXP because it checks what was actually done |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause and restate. Give two reasons in your own terms, both things you can support, and no comparison claims about the other person. If challenged, hold through two follow-ups, then concede one specific uncertainty without folding the core point | Composure test. JD because the content is why you fit the role |
| G2 | "I am not convinced an operations function adds value here. Convince me in a minute." | JD | [generic] | Do not argue defensively. Restate the concern, grant what is fair in it, then make one point about what the function does, in plain words. Hold through two follow-ups | Devil's advocacy on the role itself. Tests holding a position without ego |

### H. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc in three beats: where you started, the turn that led to operations, why this role. Keep to facts you would say the same way twice; no new detail here that you would not repeat under a second question | The standard opener, scored even though it feels casual |
| H2 | "What have you been trying lately that changed how you or your team work?" | EXP | [generic] | Pick one real thing and say what you tried and what you concluded, including if it did not work. If nothing comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Rapport interviewers use this to gauge genuine curiosity. F3's territory |

## Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| F1 Coordinate work across teams | A1, A4, D1, D3 |
| F2 Define and track operating metrics | A2, E1, E2, E3 |
| F3 Prioritize and improve processes | A2, A3, B3, H2 |
| F4 Influence without direct authority | A4, C1, C3, D2, G2 |
| F5 Customer orientation | C2 |
| Motivation and fit, no requirement row | B1, B2, B4, G1, H1 |

## Reverse questions

Each is role-generic because no interviewer profile or research was available.

| # | Question | Why it lands |
|---|---|---|
| R1 | "How would you describe what success looks like for this role at six months and at twelve?" | Shows you think in outcomes, and gets the interviewer's own definition on record |
| R2 | "Which cross-team handoffs today are most in need of attention?" | Tells you where the role's real work is and shows interest in the seams |
| R3 | "What is something a person in this role has done that you wish more people did?" | Surfaces unwritten expectations and invites a story instead of a policy |
| R4 | "How are product operations priorities set, and who can change them?" | Shows you want to know how decisions get made before you try to influence them |
| R5 | "What would make you hesitate about a candidate for this role, and is there anything I can address now?" | Gives you a chance to answer a doubt live instead of after you leave |
| R6 | "What are you working on that you would most like help with?" | Reciprocity question; useful if the interviewer turns out to be a peer |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| No entries | No sentence of yours was supplied, so no inflated form of one exists and no negative or dossier item exists to list | This pack makes no claim about your past. Anything you later say about it enters the fit snapshot as your own quoted sentence, and entries are added where a requirement would stretch it |

## Sources

Provided documents: none. Your message gave the company, the role and the stage, which is all this pack rests on.

Searches sent, all refused:

- `Stripe operating principles values`: refused
- `Stripe interview process product operations final round`: refused
- `Stripe strategy news 2026`: refused
- `Stripe Product Operations Manager job description`: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Would have supplied the published value names for a values cheat sheet and VAL mapping. Without them there is no section 10, and VAL questions use generic behavioral themes |
| 2. `Stripe interview process product operations` | unavailable | Would have named the real rounds and set persona weights. Weights fall back to Generic and flat, as said above |
| 3. `Stripe strategy` and recent news | unavailable | Would have grounded at least one CO or CASE question and a grounding brief. B2 and the case questions are generic instead |
| 4. `{interviewer name} Stripe` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative Product Operations Manager JD | unavailable | Would have turned the five generic requirement rows into inferred rows with quoted source lines. They stay generic role-family patterns |

## Upgrade menu

- The job description text (paste it): the five generic requirement rows become grounded, and JD-tagged questions are rewritten against its exact lines
- Your CV or a few lines on your background: the fit snapshot gets verbatim evidence, selection scaffolds become story maps, and defend-the-number questions are built on your real figures
- Who you are meeting and how many sessions the final has (if your final is several sessions, send the schedule): persona weights and per-session mini-packs can replace the blended weights
- Any email or notes from the recruiter about focus areas or a pre-set exercise: coverage can be aimed at what will actually be scored, and a build section added for any exercise
- Search access, or pasted Stripe values and interview material: the four refused targets above could run, giving a values cheat sheet, a grounding brief and the real loop. A deeper pass, up to 6 more searches and 2 more fetches taking several more minutes, would add a strategy brief and loop reports
- A tuesday-dossier.md from an earlier session, if you have one: verified evidence and the objection worth deepest rehearsal would arrive ready to use, and nothing here depends on it
