# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. One 60-minute session.
**Built on this assumption:** a hiring-manager round, since your note did not say how Tobias relates to the role. If he is a panel member or a peer, the persona weights change.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values. No VAL questions here: no values-style round is documented in your material, and the company's values page could not be fetched |
| EXP | Whether your background survives scrutiny, and what was actually you |
| JD | A stated responsibility or requirement in the posting |
| CO | Company and strategy knowledge. No CO questions here: company research was unavailable, so strategy cannot be grounded |
| CASE | A live problem set in the role, answered by structuring it aloud |

Provenance labels: `[grounded]` rests on a document you gave me. `[inferred]` is derived from adjacent material, with the derivation named. `[generic]` is a role-family pattern with no claim about Saltmarsh or about you.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not live events and not two titles, and the words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on running more than one calendar likely. If you ever had more than one title or calendar to sequence, say how, in your own words; if not, say so plainly and stay with the calendar you ran |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you ran the weekly content-drop calendar for your main title, for two years |
| F3 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which teams fed your drops, and the words are an answer slot: if you coordinated with design, art, engineering or community on any drop, say which and what part was yours, in your own words; if you did not, or it was not yours, say so plainly and answer as a plan |
| F4 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the monthly retention numbers, not that you owned a review or its KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's ownership line makes a probe on any review you ran likely. If you ran a review after any drop, say what it covered and what was yours; if there was none, or it was not yours, say so plainly and stay with the monthly presentation |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The quote already carries the checklist and QA in other terms, and the words keep its verb: "I wrote the release checklist our QA team still uses." The material says wrote, not managed, so keep wrote. Expect a probe on how it is used |
| F6 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message, "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer and two years of weekly drops, and does not say in so many words whether the title was live-service. Answer slot: if anything in the four years beyond the weekly calendar involved ongoing content work, say what and what was yours; if not, say so plainly and stay with the two years of weekly drops |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | The quote already shows regular contact with retention numbers in other terms: "I presented the monthly retention numbers to the studio head." Nothing in your material says how they were defined or counted, so expect a probe there |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The quote shows a written document other people use, in other terms: "I wrote the release checklist our QA team still uses." It is the only written work your material names |
| F9 | Awareness of how in-app purchases shape mobile live-event KPIs; the JD does not state this, so it is role-family prose | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [generic] | capability | A gap you stated yourself, so the words are yours: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. The same sentence says you have not led a team; the JD asks you to coordinate teams, not lead one |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet, persistent probing of the stated gaps: in-app purchases, no team led, one calendar against two titles | High. A hiring manager is buying capability and derisking gaps, and F9 is a gap you stated | Rehearse the in-app-purchases objection until it is boring; acknowledge plainly, give a learning plan as a plan, hold what your quotes carry |
| Case / Strategist (B) | Live problems from the role: plan an event, make a release call, diagnose a retention drop | High. The same hiring-manager prior, and the JD is built around the calendar, the review and the release checklist | Clarify, then objective, segments, approach, metrics, risks; think aloud; challenge one premise respectfully per case |
| Data-Driven Prober (C) | Line-by-line questions on the retention numbers you presented | Medium. The JD names player-retention metrics and the KPIs the review reports, and F7 is your retention evidence | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| Conversational / Rapport Builder (D) | Open biography, motivation and writing questions that feel casual | Medium. A 60-minute conversation usually opens this way, and casual questions are still scored | Prepare a 90-second arc from your own sentences; treat the casual questions as scored |
| Pressure (E) | Time-boxed challenges on why you and how much was you | Low. Nothing in your material signals this style, but a head of function may test composure | Pause, restate, hold the position your quotes carry through two follow-ups, concede specifically |
| Values / Behavioral | No bank | No values-style round is documented in your material, and the values page could not be fetched | Not applicable until a values round is documented |
| Peer Evaluator | No bank | Tobias is the head of the function, not a peer | Not applicable |

## Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pick the one gap you can speak to without padding. One honest option your material gives is the plain form: "I haven't worked on a game with in-app purchases." Then say what you would do in your first weeks to learn it, as a plan and never as a past: what you would ask for and from whom. Do not add a second weakness to look balanced. Answer slot: if another part of the JD is truly your weakest, name it in your own words | F9 is the gap you stated, so it is the likeliest answer to a question built to surface one. JD because it scores the stated requirements |
| A2 | "I don't see in-app purchase experience in your background. How would you handle that in this role?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack. Name the limit before it is asked for: your material has no purchase-side experience, so offer no example and do not reach for one. Say the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then the plan, as a plan: what you would ask Tobias in your first week, who you would sit with, what you would want explained about how the review's numbers are counted. Offer the adjacent fact at its own scope only: "I presented the monthly retention numbers to the studio head." Follow-up one, how long until you are useful: give your own honest estimate and do not borrow one. Follow-up two, what if purchases are most of what the KPIs track: concede specifically that it would then be the first thing you learn and that you would ask what good looks like, and do not fold on what your quotes carry | F9 is the one gap you stated, and a skeptical hiring manager will reach it in some form. EXP because it tests how your story holds under cross-examination |
| A3 | "The role coordinates design, art, engineering and community on each update, and you haven't led a team. How would you work with four disciplines you don't manage?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Start with the plain acknowledgment: "I haven't led a team." Answer slot: the JD's coordination line makes a probe on how your drops reached those disciplines likely. If you coordinated with any of them on a drop, say which and what part was yours, in your own words; if you did not, or it was not yours, say so plainly and answer as a plan: how you would learn each discipline's lead times and agree dates with them. Never present the plan as something you did | F3 has no evidence in your material and F9 carries your stated limit. JD because coordination is a stated responsibility |
| A4 | "The posting asks for three years producing live-service games or apps. What did your four years as an associate producer hold?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." | Beats your quotes state: four years as an associate producer at a puzzle-game studio, and the last two running the weekly content-drop calendar for your main title. Tell them in your own words. Answer slot: expect a probe on anything in the four years beyond the weekly calendar. If it involved ongoing content work, say what and what part was yours; if not, say so plainly and stay with the two years of weekly drops | F6 is the thinnest of the JD's headline requirements, so it is where the years are probed. JD because it scores the stated requirement |
| A5 | "The role plans events for two titles at once. What would change from running the calendar for your main title?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | The hold is what the quote carries: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if you ever had more than one title or calendar to sequence, say how you decided what went first; if not, say so plainly and describe how you ran the one calendar. Then say what you would ask Tobias about how the two titles' calendars fit together. Hold through follow-ups by returning to the calendar, never by adding to it | F1 and F2 are where the two-titles line presses hardest. JD because it scores the stated responsibility |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch the plan for a two-week live event on one of our titles. What do you need to know first?" | CASE | [generic] | Ask before you structure: what the event is for and which KPI would show it worked, what is already on the calendar, which of design, art, engineering, community and QA have work in it and their lead times. Then objective, who it is for, approach, how you would measure it, risks. Challenge one premise respectfully, such as whether two weeks is the right length. The question needs no claim about your past, so the guidance makes none | Live problems from the role's own calendar are the Case persona's core move. CASE because it scores structure; `[generic]` because it is a pattern, not a fact about Saltmarsh |
| B2 | "An update is due Thursday and QA has an open blocker on Tuesday night. Walk me through your call." | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Structure it: what the blocker breaks and for whom, the options (ship, ship without the affected part, slip), who owns the call, and what you would tell design, art, engineering and community, and when. The one beat your material carries is "I wrote the release checklist our QA team still uses." Say that and no more about how it is used. Answer slot: if you have handled a release with an open QA issue, say what happened and what part was yours; if not, or it was not yours, say so plainly and answer as the call you would make | F5 is the release-checklist evidence. CASE because the delivery is a live decision, JD because it scores the stated checklist responsibility |
| B3 | "Day-7 retention drops 20% after an event. Diagnose it." | CASE | [grounded] "Presented the monthly retention numbers to the studio head." | Clarify first: how retention is defined, which players, compared with what, and what else shipped. Then segment, line the drop up against the event and update timeline, shortlist hypotheses, and say what you would check first and who you would ask. Say what you would not conclude from one number. The beat from your material is "I presented the monthly retention numbers to the studio head," at that scope | F7 is the retention evidence, and the JD names retention metrics. CASE because it is a live diagnosis, JD because it scores the stated requirement |
| B4 | "One title's event and the other title's event both want the same weekend and the same art team. How do you sequence them?" | CASE | [generic] | Ask what each event is for, which dates are movable, the art team's capacity and what each slip costs. Lay out the options, who makes the call, and who needs to hear it and when. Challenge one premise, such as whether the same art team must do both. The question needs no claim about your past, so the guidance makes none | F1's two-titles line makes collisions between calendars the role's central problem. CASE because it scores trade-off reasoning; `[generic]` because it is a pattern |
| B5 | "What should a post-event review contain, and who should read it?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Design it aloud as a proposal: what the event set out to do, what moved and what did not, what you would change next time, who owns each follow-up, who needs to read it. The beat from your material is "I presented the monthly retention numbers to the studio head." Answer slot: the JD says you would own the review and the KPIs it reports. If you ran a review after any drop, say what it covered and what was yours; if there was none, or it was not yours, say so plainly and describe the review you would run, as a proposal | F4 is where the ownership line presses. JD because it scores the stated responsibility |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you presented, in the quote's words. Answer slot: if you know how the numbers were counted and what they were sensitive to, say it in your own words; if you do not, or someone else produced them, say so plainly and say what you would ask. Never explain a method you cannot repeat under a second question | F7 is the only place your material touches numbers, and probers go to how a figure was counted. EXP because it tests what was actually yours |
| C2 | "Which assumption behind those numbers would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Name it in your own words before the interviewer does, which turns a gotcha into a credibility gain. Answer slot: if you know of a weak assumption, say what it is; if you do not know how the figures were counted, say so plainly and say what you would check first | F7 again, asked as the weakest-assumption move. EXP because it tests honest self-assessment |
| C3 | "Which player-retention metrics are you comfortable with, and which would you want to learn?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Open with what you have: "I presented the monthly retention numbers to the studio head." Answer slot: name the specific metrics you have worked with, in your own words; if the monthly numbers are the extent, say so plainly. Then name what you would want to learn, as a plan | F7 is the retention requirement, asked as a calibration. JD because it scores the stated requirement |

### D. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | A 90-second arc built only from those four sentences: four years as an associate producer at a puzzle-game studio; for the last two you ran the weekly content-drop calendar for your main title; you wrote the release checklist your QA team still uses; you presented the monthly retention numbers to the studio head. Add no specifics those sentences do not carry. Answer slot: close with why this role, in your own words | F2, F5, F6 and F7 all sit in this one arc, so it is the cheapest place to land them. EXP because it tests whether the story hangs together |
| D2 | "Why live ops, why here, and why now?" | EXP | [generic] | Give your real reasons in your own words, each one true and repeatable under a follow-up. The why-here part needs something specific you read about Saltmarsh yourself, because this pack could not research the company. Do not use a reason you cannot back | Motivation consistency is the Skeptic's stem delivered in a friendly register. EXP because it tests honest self-account; `[generic]` because the question carries no claim about your past |
| D3 | "Part of the role is clear written communication. Tell me about something you've written that other people relied on." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F8: you wrote it, and your QA team still uses it, which are the beats the quote states. Answer slot: the JD's written-communication line makes a probe on how it was written likely. If you can say how you decided what went into it or who reviewed it, say so in your own words; if it drew on an existing list, or someone else shaped it, say so plainly and stay with the fact that QA still uses it | F8 is the only written work your material names. JD because it scores the stated requirement |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, over a candidate who has run live events on a game with in-app purchases?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." and "Never led a team, and never worked on a game with in-app purchases." | Pause and restate the question. Hold what your quote carries: "I ran the weekly content-drop calendar for our main title for the last two years." Concede specifically: "I haven't worked on a game with in-app purchases." Hold through two follow-ups by returning to the calendar and never by adding to it, and do not fold on it to restore harmony. Do not describe the other candidate | F2 is the evidence to hold and F9 the limit to concede. EXP because it tests composure about what you actually did |
| E2 | "That calendar — how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: say in your own words which parts you ran and which others owned. "Ran" is what you said, so keep it. If parts were shared, say what and with whom; if all of it was yours, say so and describe how you ran it. Concede uncertainty explicitly where a part was not yours, and hold the core claim | F1 and F2 rest on this one sentence, so attribution is the likeliest pressure point. EXP because it tests attribution honesty |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 live-events calendar for two titles | A5, B4, E2 |
| F2 content calendar | A5, D1, E1, E2 |
| F3 coordinate design, art, engineering and community | A3, B1 |
| F4 post-event review and KPIs | B3, B5 |
| F5 release checklist with QA | B2 |
| F6 3+ years live-service | A4, D1 |
| F7 retention metrics | B3, C1, C2, C3 |
| F8 clear written communication | D3 |
| F9 in-app purchases (role-family, stated gap) | A1, A2, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How do the two titles' calendars differ in rhythm, and where do they collide?" | It shows you grasp that the job is two calendars at once, and the answer tells you what to sequence first |
| R2 | "What does the post-event review look like today, and which KPIs does it report?" | The JD says you would own it, so asking how it runs shows you are already planning to |
| R3 | "How much of an event's success is measured in retention against revenue here, and what would you want me to learn first?" | It raises your in-app-purchases gap openly, on your terms, and turns it into a ramp plan |
| R4 | "How does the release checklist run with QA today, and where would you want it to change?" | It connects the checklist you wrote to the JD's checklist line without claiming you ran it |
| R5 | "Where do design, art, engineering and community disagree most on an update, and who decides?" | It shows you expect to coordinate disciplines you do not manage |
| R6 | "What would make you say in six months that this hire worked?" | It asks for the success measure directly, and the answer tells you what to rehearse for later rounds |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | A negative you stated, F9 | The plain acknowledgment: "I haven't led a team." Your sentence is "Never led a team, and never worked on a game with in-app purchases." No slot |
| Worked on a game with in-app purchases | A negative you stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Owned the post-event review and its KPIs | Inflated form of F4 | F4's quote at its own scope: "Presented the monthly retention numbers to the studio head." The limit is the pack's observation: the material says presenting, not owning. B5's slot stays inside the monthly presentation |
| Managed the release checklist with QA | Inflated form of F5 | F5's quote at its own scope: "Wrote the release checklist our QA team still uses." The material says wrote, not managed |
| Ran live events for two titles | Inflated form of F1 | F1's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The material says one main title's content-drop calendar |
| Four years producing live-service games | Inflated form of F6 | F6's quotes at their own scope: "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." A4's slot stays inside those years |

## Sources

Provided documents: the job description you pasted, and your background message. No `tuesday-dossier.md` was present. No links were given.

Searches sent, all refused because the host had not granted web search:

| Query | Outcome |
|---|---|
| Saltmarsh Games values | refused |
| Saltmarsh Games interview process live operations producer | refused |
| Saltmarsh Games strategy mobile titles news | refused |
| Tobias Wrenfield Saltmarsh Games Head of Live Operations | refused |

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Would have fed a values cheat sheet and VAL questions if a values round is documented. Neither is in this pack |
| 2. Saltmarsh Games interview process, live operations producer | unavailable | Would have named the loop's rounds. Persona weights rest on your own words, a single 60-minute session with Tobias, and the hiring-manager prior |
| 3. Saltmarsh Games strategy and recent news | unavailable | Would have grounded a CO or CASE question in current priorities. B1 and B4 are `[generic]` for that reason |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Would have produced an interviewer read, reweighted personas and a reverse question tied to his path. The reverse questions are role-generic |
| 5. representative Live Operations Producer JD | skipped | The JD you pasted fixes the fit snapshot and every JD-tagged question |

## Upgrade menu

- Web search access, or pasted pages: Saltmarsh's values page, careers or interviewing page and a recent strategy source → a values cheat sheet if a values round is documented, CO questions grounded in current priorities, and persona weights read from the real loop
- Tobias's public profile or talks, pasted or searchable → an interviewer read, personas reweighted to his signals, and a reverse question tied to his own career path
- A deeper research pass, offered once, if search becomes available: up to 6 more searches and 2 more fetches, several more minutes → a strategy brief for the Grounding brief section and sharper CASE questions
- Your answers to the answer slots in F1, F3, F4 and F6 → those rows move from slots to quoted evidence, and the matching banks regenerate
- A published calendar, an event post-mortem or the retention deck itself → raises F2, F4 and F7 above medium, because those are the inspectable artifacts live-ops work leaves behind
- The recruiter's prep email → stated focus areas and any pre-declared deliverable, which would add a build section
- How many hours you have before Friday → a prep triage ordered to that time
- A `tuesday-dossier.md` → verified evidence and a named top objection in place of the ones this pack infers; the pack never needed it
