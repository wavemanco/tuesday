# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, one 60-minute panel on Tuesday. **Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). **Shape, in the recruiter's words:** a 15-minute POV on where you'd take operator partnerships over the next 18 months, then Q&A where "Ross will push on commercials."

**Built on:** your message only. No JD text, no CV beyond the background you gave, no company research (every search was refused), and the market report was not pasted, so nothing here draws on it.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values (no values round detected, so none are banked) |
| EXP | Whether your claims survive scrutiny: what was actually you |
| JD | The role's stated responsibilities, including gaps |
| CO | Company and strategy knowledge, at the company's altitude |
| CASE | A live problem from the role, reasoned aloud |

An answer slot is an instruction for the interview, not a question for you now. Answer it from your own experience, in either of its two branches.

## Prep triage (four hours)

| Order | Time | Do this | Tied to |
|---|---|---|---|
| 1 | 60 min | Pick one thesis and write the five-beat spine of the POV | Graded deliverable, T1 to T3 |
| 2 | 45 min | Re-read the market report: mark one consensus item, one point you would diverge on, one thing you would decline | Graded deliverable, A4, C4, E2 |
| 3 | 60 min | Say B3 aloud five times, then B1, B2, D1, D2; record yourself and check every claim against your own three sentences | B3 (highest-ROI), B1, B2, D1, D2 |
| 4 | 45 min | Deliver the full 15 minutes aloud twice, timed; aim for 12 to 13 minutes | Graded deliverable run of show |
| 5 | 30 min | C1, C2 and E1 once each; choose your three reverse questions | C1, C2, E1, Reverse questions |

Everything else in the pack is insurance.

## Fit snapshot

The recruiter's words stand in for the JD, so every requirement below comes from her email as you quoted it, and nothing here is JD-derived. Evidence cells hold only your own sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your sentence carries a payments ISV channel, not an operator partnership programme, and the words stay at that scope: "For the last four years I ran the ISV channel at a payments company, and took it from 6 partners to 40." Answer slot: the POV asks where you would take operator partnerships, so expect a probe on what from the channel's growth carries over. If you can say what drove that growth, say it in your own words; if you cannot, or it was not yours to drive, say so plainly and stay with the figures you gave |
| F2 | "Please land on what it means for the operators themselves." — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Your sentence says bus and light rail network planning and describes the operator world as known from the other side; it does not say whose operators or what they asked of suppliers. Words: "Before partnerships I spent five years in transport consulting, on bus and light rail network planning." Answer slot: if that planning work showed you what operators need from the companies that supply them, say what, in your own words; if it did not, or it was not rail, say so plainly and stay with the network planning |
| F3 | "Ross will push on commercials." — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message; "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | medium | [grounded] | transferability | The figure is influenced revenue and you have said it is the only kind you hold, so the words are those: "I haven't carried a direct quota; what I had was influenced revenue." Nothing in the material shows how the figure was counted. Answer slot, the four a figure raises: how the £4M was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how part of it was counted, say that plainly |

No gate row exists: nothing in your material states a term such as location, schedule, pay or travel as a requirement, so no gate question is asked.

## Graded deliverable: the 15-minute POV

The recruiter announced it, so it is graded. Her stated close: "Please land on what it means for the operators themselves."

**Grounded facts to build on (yours, at their own scope)**

| Fact | Row | Quote |
|---|---|---|
| What you have run | F1 | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." |
| Where your operator knowledge comes from | F2 | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." |
| The limit Ross will test | F3 | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." |

**Three thesis options.** Pick one, not all three. Each carries a concession you say aloud, because a thesis with no stated cost reads as a pitch.

| Thesis | Shape of the argument | Mandatory concession | Provenance |
|---|---|---|---|
| T1 Fewer operators, deeper | Spend the 18 months on a small set of operator partnerships run against outcomes the operator itself would name, and say no to the rest | F1's figures describe growth in partner numbers (6 to 40), which cuts the other way; say so, and say the first 18 months would show fewer partners | [generic] |
| T2 An ecosystem around the operator | Grow the set of partners who make the scheduling product more useful to operators, with operator need deciding who gets in | F1 is a payments channel, and you have said you have not sold into rail specifically; the concession is that what carries across is yours to test, not yours to assert | [generic] |
| T3 Measure partnerships by operator outcomes | Agree a short scorecard with each operator and with Ross's team, so partnership value is counted the same way commercially and for the operator | F3: you have not carried a direct quota, so you cannot claim to have owned a number, and you would ask how the scorecard should be counted before proposing one | [generic] |

**Differentiation against the consensus answer.** The market report was circulated inside Kelverton, so Deepa and Ross have read it, and likely so has every prepared candidate. Recite nothing from it. Bring one consensus item to show you read it, then one thesis-driven divergence with your reasons.

- Consensus item: one point from the report you agree with. Choose it from the report; this pack has not seen it.
- Divergence: one point you would weight differently, and why.
- Anti-pick: the role includes saying no, so name one operator request or partnership type you would decline in the first 18 months, and what it protects.

**Run of show (12 to 13 minutes of talking, 15 available)**

| Minutes | Beat |
|---|---|
| 0 to 1 | Frame: the question you are answering and the one assumption you are making |
| 1 to 3 | The consensus item, then the one you would question |
| 3 to 9 | Your thesis, two supporting moves, and its concession |
| 9 to 12 | What changes for operators at month 6, month 12 and month 18 |
| 12 to 13 | What you would decline |
| 13 to 15 | What you would need to learn first, then stop |

For the operator close, name each month's change in operator terms (what an operator would notice or be able to do), and name a metric only if you actually know one. Do not invent figures.

**Proposed lines, pending your approval**

- Concession line, T2 or T3: "I haven't sold into rail specifically, so I'd treat what carried across from my channel as something to test with operators in the first ninety days." 
- Limit line, before Ross asks: "My number is influenced revenue, not a direct quota." 

## Persona table

The loop is established by the recruiter's own words: one session, two named people, a POV and then Q&A. No archetype fallback is used. Weights follow Deepa as future manager and Ross as Commercial Director, then the recruiter's remark about commercials.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The POV itself, then follow-ups on operators and prioritisation (Deepa and Ross) | Highest: 15 of the 60 minutes are a strategy talk, and a future manager buys capability | Clarify, then structure, then answer; challenge one premise respectfully (A1 to A5) |
| Pressure | Ross, time-boxed and challenging on the number | High: the recruiter wrote "Ross will push on commercials" | Pause, restate, hold the position through two follow-ups, concede specifically (B1 to B4) |
| Skeptic | Probing the gap between payments and rail (Deepa) | High: you have said you have never sold into rail, and a future manager is derisking | Rehearse the one predictable objection until it is boring (C1 to C4) |
| Data-Driven Prober | The £4M and the 6 to 40 | Medium: a Commercial Director will test a figure, and yours is influenced revenue | Know what you can and cannot say about how each figure was counted (D1 to D3) |
| Conversational | The opener, "walk me through your journey" | Medium: every panel opens somewhere, and it is still scored | A 90-second arc built on your own three sentences (E1 to E3) |
| Peer Evaluator | Not banked | Low: no peer is on the panel the recruiter named | None needed |
| Values/Behavioral | Not banked | Low: no values-style round is detected, because the recruiter's words describe a POV and Q&A | None needed |

## Question banks

### A. Case/Strategist (weight 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Before you give us your view, which operator partnership would you want to look at first, and what would you want to know about it?" | CASE | [generic] | Clarify before you structure: what the partnership is meant to achieve for the operator, how it is measured today, who at the operator owns it, and what the commercial arrangement is. Ask these as questions, and assert nothing about Kelverton you have not read | Opens the POV as a live problem on the recruiter's own topic; CASE because it scores clarification before structure |
| A2 | "In three sentences, where would you take our operator partnerships over the next 18 months?" | JD | [generic] | The POV compressed: thesis, one move, one cost. Use your chosen thesis from the graded deliverable and its concession. The question needs no claim about your past, so the guidance makes none | F1's requirement arrives in miniature; JD because it scores the recruiter's stated deliverable, delivered under time pressure |
| A3 | "Our operators won't all want the same thing. How would you decide where your time goes first?" | CASE | [generic] | Offer selection criteria and say they are criteria to test, not findings: what the operator is trying to achieve, how reachable the benefit is, what it costs Kelverton to serve, and what it teaches you for the next one. Name the weakest criterion and why | The prioritisation follow-up a strategy talk draws; CASE because it scores structure under constraint |
| A4 | "What would an operator notice is different about working with us at month six?" | JD | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Land it in operator terms, since the recruiter asked for exactly that. The beat your sentence carries is five years of transport consulting on bus and light rail network planning, told in your own words. Answer slot: if that planning work showed you what operators need from their suppliers, say what; if it did not, or it was not rail, say so plainly and describe how you would find out. Name a metric only if you know one | F2 is the evidence for the operator close and the likeliest place to be probed; JD because it scores the recruiter's stated close |
| A5 | "You've run a channel at a payments company. What from that would you bring here, and what wouldn't carry across?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | The beats your sentence states are the payments company, running the ISV channel, 6 partners to 40, and roughly £4M of influenced revenue. Answer slot: if you can name what you would bring and what would not carry across, say each in your own words; if you do not yet know what would not carry, say so plainly and stay with what the channel was. Do not claim a method of how it grew unless you can repeat it under a second question | F1 is the adjacent evidence for the POV; EXP because it tests what was actually yours, and CASE-like because it asks for judgment |

### B. Pressure (Ross, weight 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: your £4M was influenced rather than direct revenue. Why should a Commercial Director trust that number?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." and "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Hold only what the sentences carry: "roughly £4M of influenced revenue", and never call it sales or bookings. Answer slot, the four a figure raises: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how part of it was counted, say that plainly. Name your weakest assumption before he does | F3 is where the commercial push lands; EXP because it tests whether the figure survives, with the metric type's weakest-assumption move |
| B2 | "That result: how much of it was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | The quote carries one claim about you: you ran the ISV channel in the last four years. Anything wider is a slot. Answer slot: if there were parts of the channel's results that were yours, a team's or a partner's, say which and how you know; if you cannot separate them, say so plainly and return to running the channel. Hold through two follow-ups by returning to the sentence, never by adding to it | F1 is the attribution target a pressure interviewer chooses; EXP because it is the classic attribution probe |
| B3 | "You've never carried a quota. Why would we give you a number?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | The highest-ROI rehearsal in this pack. Hold, then concede, in that order. Plain acknowledgment: "I haven't carried a direct quota; what I had was influenced revenue." Then speak to the future, never to a past you did not state: how you would want to be accountable here, in your own words. Follow-up 1, "What would you commit to by month twelve?": say what you would need to see before committing to anything. Follow-up 2, "Anyone can claim they influenced a deal; how would I tell?": answer from how your figure was counted, using the four slots in B1, or say plainly that you do not know how part of it was counted. Follow-up 3, "Would you take a role where your pay depended on a number?": answer from your own situation. Do not promise a figure you cannot defend | F3 is the single most likely objection to this candidate, aimed at the stated negative; JD because it scores the commercial accountability the recruiter flagged |
| B4 | "How would you think about the commercial terms between us, an operator and a partner?" | CASE | [generic] | Structure it as questions before terms: what each party gets, who pays whom for what, what the current arrangement is, and what Ross's team needs to see. Say that you cannot price without Kelverton's own data, and name the first data point you would ask for. The question needs no claim about your past, so the guidance makes none | F3 says the commercials will be pushed; CASE because it is a live problem, asked as a decision rather than a record |

### C. Skeptic (Deepa, weight 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Calibrated candor beats a bluff. Plain acknowledgment: "I haven't sold into rail specifically." Say it once, name the part of the role it touches, and then give your plan to close it, said as a plan and never as a past. Do not pad it with a second weakness to look balanced | F3 holds the stated negatives; JD because it scores honest self-assessment against the role |
| C2 | "Bus and light rail planning isn't running a train operating company. What don't you know yet?" | JD | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | The sentence carries bus and light rail network planning and a view of the operator world. Answer slot: if any of it touched train operators, say which and what your part was; if none did, say so plainly and describe how you would learn the heavy-rail side. Never stretch the sentence to cover heavy rail operations | F2 is where the domain probe lands; JD because it scores whether the candidate's domain claim survives |
| C3 | "Why leave payments, and why now?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Your material says transport consulting came before your partnerships career; it does not say why you are moving now. Answer slot: give your actual reason, in your own words. If part of your reason is not something you would say to this panel, leave it out; do not invent one that sounds better | F2 shows the path; EXP because motivation consistency is checked against the CV's story |
| C4 | "Where would you disagree with how we run operator partnerships today?" | CO | [generic] | You have read the market report, and the panel has too. Answer slot: if there is a point in it you would weight differently, name it and give your reason; if there is none, say what you would ask first before disagreeing with anything. Challenge one premise respectfully and never claim to know how Kelverton runs partnerships today | The differentiation question that separates a candidate who read the report from one who recited it; CO because it scores company-level judgment |

### D. Data-Driven Prober (Ross, weight 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | The sentence holds the figure and its word, influenced. The method is yours to state. Answer slot: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, each in your own words; if you do not know how part of it was counted, say that plainly. Never supply a baseline or attribution model you cannot repeat | F3 is the figure's home; EXP because a headline metric earns a defend-the-number question |
| D2 | "What is the 40 counting?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | The sentence says 6 partners to 40. Answer slot: what counted as a partner, and how the six and the forty were each counted, in your own words; if you cannot say, say so plainly. Do not add a definition after the fact | F1 holds the second headline number; EXP because both numbers get tested |
| D3 | "With the same resources here, what would you expect to influence by month eighteen?" | CASE | [generic] | The figure in your sentence is not a forecast and should not be offered as one. Say what you would need to know first (the operator base, the current partner set, what counts as influenced here) and give a range only if you can defend how you reached it. Say plainly that you do not yet have those inputs | F3's figure invites extrapolation; CASE because it is a sizing problem under uncertainty |

### E. Conversational (opening, weight 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through your journey." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." and "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | A 90-second arc with the beats the sentences state: five years in transport consulting on bus and light rail network planning, then nine years in partnerships, the last four at a payments company running the ISV channel. Answer slot: why you made each move, in your own words; if a move was circumstance rather than choice, say so | F1 and F2 give the arc; EXP because it is the biography question and it is scored |
| E2 | "What did you take from the market report?" | CO | [generic] | The panel's own strategy team wrote it, so recite nothing. Answer slot: the one point you agree with and the one you would weight differently, in your own words; if you did not form a view on a point, say so plainly. This is the same pair as the POV's first two beats | The report is shared with the panel, so this is the differentiation question; CO because it scores homework depth |
| E3 | "What would your first ninety days look like?" | JD | [generic] | A plan, said as a plan: who you would hear from first, what you would read, and what you would hold off deciding until you had. Do not describe a past you have not stated | The role's ramp, and the natural way to cover the rail gap constructively; JD because it scores the listed job's start |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 the POV on operator partnerships over 18 months | A1, A2, A3, A5, C4, E1, and the graded deliverable |
| F2 land on what it means for operators | A4, C2, C3, and the graded deliverable's close |
| F3 commercials | B1, B2, B3, B4, C1, D1, D2, D3 |
| The JD's own requirement list | none, and why: no JD was supplied, so there is no list to check against |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "When an operator partnership goes well, what does the operator say has changed, and who at Kelverton hears it first?" | Keeps the conversation on operator outcomes, which is where the recruiter asked you to land |
| R2 | "How would you want this role's contribution counted: direct, influenced, or both?" | Turns the quota gap into a design conversation instead of a defence |
| R3 | "Which operator partnership are you proudest of, and which would you most like to change?" | Invites the panel's own view and shows you can hold both |
| R4 | "What did the market report get most right, and what do you think it missed?" | Shows you read it and treats the panel as the experts on it |
| R5 | "What would make this hire a clear success at eighteen months?" | Gets the real scoring sheet in the panel's own words |
| R6 | "Where does the partnerships team's work stop and the commercial team's start?" | The seam question; it shows you are thinking about how the two panel members' work meets |

## Prohibited claims

Built from the fit snapshot before the banks. None of these is a finding that you lack the thing; each is wording this pack will not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a number or a direct quota | Negative you stated, F3 | Plain acknowledgment: "I haven't carried a direct quota; what I had was influenced revenue." No slot |
| Sold into rail | Negative you stated, F3 | Plain acknowledgment: "I haven't sold into rail specifically." No slot |
| Booked or closed £4M | Inflated form of F1 and F3 | The quote at its own scope: "roughly £4M of influenced revenue" |
| Built or designed the channel from scratch | Inflated form of F1 | The quote at its own scope: running the ISV channel, 6 partners to 40. The limit is the pack's observation: your material says running and the growth, not who designed the programme or recruited the partners |
| Rail operations expertise | Inflated form of F2 | The quote at its own scope: bus and light rail network planning. The limit is the pack's observation: your material does not say whether any of it touched train operators |

## Sources

Provided: your message, including the recruiter's email as you quoted it. The market report was attached to her email and read by you; its contents were not provided here. No `tuesday-dossier.md` was present.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

Queries sent, all refused (the host did not grant search permission):

- "Kelverton Rail values" — refused
- "Kelverton Rail interview process partnerships" — refused
- "Kelverton Rail strategy news train operating companies scheduling software" — refused
- "Deepa VP Partnerships Kelverton Rail" — refused
- "Ross Commercial Director Kelverton Rail" — refused
- "Senior Partnerships Manager rail technology job description train operating companies" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Would have fed a values cheat sheet; none is built, and no values round is detected from the recruiter's words |
| 2. Kelverton Rail interview process | unavailable | Would have added loop detail; the recruiter's own words already fix this session (one panel, two named people, a POV, then Q&A), so persona weights are unchanged |
| 3. Kelverton Rail strategy and recent news | unavailable | Would have grounded the CO and CASE questions; they are labelled generic, and the market report you hold is the better source |
| 4. Interviewer footprint, Deepa and Ross | unavailable | Would have fed a reading of the interviewer and a path-tied reverse question; both are absent |
| 5. Representative Senior Partnerships Manager JD | unavailable | Would have given JD-derived rows; the fit snapshot rests on the recruiter's words instead |

## Upgrade menu

- The job description text → the three recruiter-worded rows become JD-sourced, each stated requirement gets a JD question, and any gate (location, travel, schedule) can be checked
- Your full CV → more of your own sentences in the evidence column, more story-mapped answers and fewer selection scaffolds, and more defend-the-number questions
- The market report's headline findings, pasted → the consensus item and the divergence in the graded deliverable and C4, E2, R4 become grounded rather than generic, and a grounding brief becomes possible
- Search permission for company research → Kelverton's published values, loop and strategy, so the CO bank can be grounded; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) can be run on your say-so
- Deepa's and Ross's full names or profiles → a reading of each interviewer and one reverse question tied to a path
- One email to the recruiter asking whether Ross's commercial push has a named focus (pricing, partner revenue, or the partner model) → B3, B4 and D3 aimed at the real topic
- A `tuesday-dossier.md` from an earlier opportunity check → the objection worth the deepest rehearsal arrives evidence-derived, and weak areas carry the allowed strategy
