# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, one 60-minute panel. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: your talk with no slides. Rest: Q&A, where Ross will push on commercials.
**Built on:** the recruiter's email and your own background paragraph. No JD, no market report text and no web research were available, so the labels below say how much each part rests on.
**Highest-ROI prep in this pack:** B1, the objection that you have never sold into rail and never carried a direct quota. It will be asked in some form.

## 2. How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values. No question carries this tag here: no values-style round is named in the recruiter's email |
| EXP | Whether your claims survive scrutiny and how much was actually you |
| JD | The role as described, including its gaps |
| CO | Knowledge of the company and its strategy |
| CASE | A live problem set in the role |

An answer slot is an instruction for the interview, not a question for you now. Where one says "if you did this, say how", the second branch always lets the answer be "I didn't, or it wasn't mine". Lines marked as proposed language are pending your approval, and nothing in them is applied to anything you will send.

## 3. Prep triage (4 hours)

| Order | Time | Do | Tied to |
|---|---|---|---|
| 1 | 60 min | Build the 15-minute talk: pick one thesis, write its beats in your own words, include the concession and the close on operators | Section 5, A1 to A4 |
| 2 | 45 min | Say it aloud twice against a timer, recording once; cut to 15 minutes | Section 5 timing frame |
| 3 | 45 min | Rehearse the objection until it is boring: B1 and its three follow-ups, hold then concede | B1, D1 |
| 4 | 40 min | Write your own answers to the number slots for the 6-to-40 count and the £4M | C1, C2, D2 |
| 5 | 30 min | Choose three reverse questions and your 90-second opening arc | R1 to R6, E1 |
| 6 | 20 min | One full run: the talk, then B1, C1 and D2 back to back | Whole pack |

Suggested split: items 1 and 2 in the first session, 3 and 4 in the second, 5 and 6 in the last. Everything else is insurance.

## 4. Fit snapshot

The recruiter's email supplied no JD, so the requirements are her own words, quoted. Evidence cells hold only your sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your material carries an ISV channel at a payments company, adjacent to operator partnerships but a different kind of partner, with nothing inspected behind it. Use the sentence at its own scope: you ran the ISV channel for the last 4 years and took it from 6 partners to 40. The step to operators is what the talk argues for, not something your past already shows. The defend-the-number slots for the 6 and the £4M sit at C1 and C2 |
| F2 | "Please land on what it means for the operators themselves." — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning and says nothing about train operating companies. Words: "I spent 5 years in transport consulting, on bus and light rail network planning." Answer slot: "the other side" invites the probe "which side?". Say which side you stood on and what you saw from there, in your own words; if the work was not for or with operators directly, say so plainly and stay with the bus and light rail network planning |
| F3 | "Ross will push on commercials." — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | The email does not say what "commercials" covers. Your material gives the figure at its own scope, "roughly £4M of influenced revenue", which is influenced and not a direct number. Hold it there. Expect a probe on how it was counted: slots at C1 and D2 |
| F4 | "Ross will push on commercials." — recruiter's email | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't sold into rail specifically, and I haven't carried a direct quota." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | Running a partner programme at senior level — role-family requirement, no source supplied | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [generic] | none | No gap on the partner side, but a line with nothing inspected behind it, so expect a probe. Lead with the channel in the sentence's own terms, because a named channel beats an adjective, and say influenced where the revenue comes up |

*Proposed language in the bridge column, pending your approval.*

## 5. Graded deliverable: the 15-minute talk

**What the recruiter asked for, in her words:** "present a short POV on where you'd take our operator partnerships over the next 18 months", "no slides needed, just talk us through it", and "Please land on what it means for the operators themselves."

**Grounded facts about you to build on** (each from its fit-snapshot row, quoted exactly):

| Fact | Row | Quoted from the row's evidence cell |
|---|---|---|
| The ISV channel and its growth | F1 | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." |
| The consulting background | F2 | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." |
| The stated limits | F4 | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." |

**Theses.** Pick one, and use it only if you believe it. These are options to argue from, not claims about Kelverton, and the market report may support or undercut each. I have not seen it.

| # | Thesis | Mandatory concession | Anti-pick it implies | Provenance |
|---|---|---|---|---|
| T1 | Go deep before wide: choose a small set of operators and make each partnership a working relationship before adding more | Depth leaves most operators untouched for 18 months and concentrates risk in a few relationships | A partner-count target. F1's quote is a count of partners, and this thesis argues against leading with one | [generic] |
| T2 | Anchor each partnership on an outcome the operator can see on their own side, agreed with them at the start, rather than on Kelverton's pipeline | Operator outcomes are harder to attribute to a partnership than pipeline, so the reporting will be slower and less tidy than a commercial director may want | Influenced revenue as the headline measure, which is the only revenue measure F4's quote gives you | [generic] |
| T3 | Make partnership the formal route by which operators shape what Kelverton builds, as co-design, not as feedback | Co-design gives operators influence over scope, which may pull against what Kelverton wants to standardise and sell more widely | An advisory forum that meets and changes nothing | [generic] |

**Differentiation against the report.** The report came from their own strategy team, so Deepa and Ross know it. Reciting it scores as homework. Open with one point from it to show you read it, then diverge with one thesis above and one thing you would decline. I cannot build the consensus point or the divergence until I see its recommendations; see the upgrade menu.

**The requested close.** Finish on one sentence that starts with what an operator can do, or stops having to do, once the partnership is working. Take it from your thesis, state it in the operators' own terms, and say how you would know. The recruiter asked for exactly this, so give it the last two minutes rather than a recap.

**Timing frame.** A proposed structure, pending your approval.

| Minutes | Beat |
|---|---|
| 0 to 2 | State what you assumed and the one question you would ask first |
| 2 to 6 | The thesis and why |
| 6 to 10 | How it unfolds: first six months, then to month 18 |
| 10 to 12 | The concession, and what you would decline |
| 12 to 15 | The close on operators, then stop and hand over |

## 8. Persona table

Both panellists are known by title only. No row of the persona priors fits a commercial director exactly, so Ross is weighted from the recruiter's word "push".

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | Deepa follows up on your talk: what first, what you would not do, how you would know | Highest. The email sets a 15-minute plan and Deepa is the future manager, whose prior is Case plus Skeptic | Clarify, then structure, then answer; challenge one premise respectfully |
| Skeptic (B) | The gaps: no rail sales, no direct quota, bus and light rail not train operators | High. Your own message states the first two, and a hiring manager prices exactly these | Rehearse B1 until it is boring; concede the limit plainly, then show the ramp |
| Data-Driven Prober (C) | Ross on the £4M and the 6-to-40 count | High. The email says he will push on commercials, and your two figures are the material he has | Know how each figure was counted and say plainly when you do not |
| Pressure (D) | Time-boxed, "sixty seconds", "how much was you" | Medium. "Push" suggests it, though the email does not describe style | Hold the position through two follow-ups, then concede specifically |
| Conversational (E) | The opening "walk me through your journey" and a casual closing question | Lower. A 15-minute talk leaves less room for chat, but an opener is likely | A 90-second arc; treat casual questions as scored |

## 9. Question banks

Eighteen questions: A has 5, B 4, C 4, D 3, E 2. Where a guidance cell quotes you, the quote is in the Provenance column and the cell says nothing it does not.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Take us through where you would take our operator partnerships over the next 18 months." | CASE | [grounded] | Build it from section 5, in your own words: one thesis, how it unfolds, the concession, what you would decline, the close on operators. Hold to 15 minutes and stop. It needs no claim about your past, so none is made here | The recruiter's own wording, and the likeliest source of every follow-up in banks A to D. CASE because it is a live plan |
| A2 | "Before you commit to that plan, what would you want to know about our operators?" | CASE | [generic] | Clarify before structuring. Ask two or three: which operators and what the relationship is today, what each gets from Kelverton and gives back, what the strategy report treats as success. Then say which answer would change your thesis. No claim about your past | Hiring managers score whether you clarify before you structure. CASE; [generic] because it is a pattern, not a fact about this employer |
| A3 | "What would you choose not to do in the next 18 months, and why?" | CASE | [generic] | Name one thing you would decline and give the operator-side reason, tied to the anti-pick in section 5. Say what evidence would change your mind. No claim about your past | A role that has to say no to some partners makes this a judgement test. CASE |
| A4 | "Picture an operator that is content with the product and sees no reason to change how it works with us. What does a partnership offer them?" | CASE | [grounded] | Start from the operator's problem, not Kelverton's. Say what they would do differently, what it would cost them, and what they lose by not taking part. Concede what you do not know about their economics. One sentence at the end, in their terms. No claim about your past | Tests the recruiter's own close, "what it means for the operators themselves", under live pressure. CASE |
| A5 | "How would we know in 18 months that it worked? What would you measure?" | CASE | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Choose one measure an operator would recognise on their side and one Kelverton cares about commercially, and say how they connect. If you reach for revenue, keep your own scope: "I haven't carried a direct quota, only influenced revenue." Answer slot: if any measure you used before was agreed with the partners and not set for them, say how; if not, say so plainly and say what you would agree first | F3 and F4 are why a measure question lands on revenue. CASE because it is a live design problem |

*Proposed language in this bank, pending your approval.*

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail and you've never carried a direct quota. Why should we trust you with operator commercials?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | The highest-ROI rehearsal. Beat 1, the acknowledgment first and plainly: "I haven't sold into rail specifically, and I haven't carried a direct quota." Beat 2, hold only what the quotes carry: 9 years in partnerships, the last 4 running the ISV channel, 6 partners to 40, and that the figure is influenced revenue. Beat 3, the ramp as a plan: what you would do in your first weeks to learn rail commercials and what you would ask Ross to teach you, in your own words. Follow-up 1, "influenced isn't revenue you were accountable for": concede, do not defend, and return to beat 1. Follow-up 2, "rail is unlike payments, what makes you think any of it carries?": say what you would test first and that you do not yet know what carries. Follow-up 3, "what do you bring that someone who has sold into rail doesn't?": answer only within the quoted scope. Answer slot: if one thing in those quotes answers it, name it; if none does, say so plainly. Never hold that you know how rail commercials work | F4 is the pack's biggest gap and the question is aimed at it. JD because it scores the stated commercial push; the deepest rehearsal because it will be asked |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Say the true one first. The sentence you gave points to selling into rail and carrying a number; if something else is truer, say that instead. Then the ramp as a plan. Never name a weakness chosen to sound harmless | A persona stem that returns the same gap in a gentler register. JD |
| B3 | "Your consulting work was bus and light rail network planning. How much of that applies to train operating companies?" | JD | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Say what it was, at its own scope: 5 years in transport consulting, on bus and light rail network planning. Answer slot: the probe will be "which side?". If any of that work was for or with operators directly, say who and what was yours; if none was, say so plainly and stay with the network planning. Do not claim knowledge of train operating companies' own planning | F2 is where "the other side" will be tested. JD |
| B4 | "Why this role at a rail-tech vendor, and why now?" | JD | [generic] | Give a reason you can stand behind that does not rest on flattering Kelverton. If a thread runs through your earlier roles, name it in your own words; if none does, say so plainly and give the nearest honest reason | The standard motivation probe for a career move into a new sector. JD; [generic] because it needs no claim here |

*Proposed language in this bank, pending your approval.*

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Four slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Keep "roughly" and "influenced". If you do not know how it was counted, say so plainly; do not supply a method you cannot repeat under a second question | F3 is the figure Ross can push on. EXP because it tests attribution |
| C2 | "Take me from 6 partners to 40: what counted as a partner, and which part was you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | The same four slots for the count: what counted as a partner, what the count is sensitive to, the assumption you would defend least, and which part was yours. Say "took it from 6 partners to 40" and nothing larger; do not say you built it | F1's other headline figure. EXP |
| C3 | "Influenced revenue isn't revenue you closed. How would you feel being held to a direct number here?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Hold, then concede. Concede the fact: "I haven't carried a direct quota, only influenced revenue." Then say plainly how you feel about it, in your own words. Answer slot: if anything in your partnership work had a number attached for which you were answerable, say what it was and how it was set; if nothing did, say so plainly and stay with influenced revenue | The email says Ross pushes on commercials and F4's quote is the opening. JD |
| C4 | "How would you think about the commercial terms of an operator partnership? What would you want to know before proposing any?" | JD | [generic] | Structure it: who pays whom, what the operator gets, what Kelverton gets, how it is measured, what could go wrong. Say what you would ask Ross before proposing anything. Answer slot: if you have set partner terms before, say which and what part was yours; if others set them, or none were set, say so plainly. No claim about your past beyond what you say there | A commercial director tests structure first and experience second. JD with CASE delivery; [generic] because no JD or strategy source was available |

*Proposed language in this bank, pending your approval.*

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has sold into rail?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pause, restate the question, then hold what the quotes carry: 9 years in partnerships, the last 4 running the ISV channel, 6 partners to 40. Hold it through two follow-ups. Concede the limit specifically: "I haven't sold into rail specifically." Do not argue you are better; argue what you would bring and what you would learn | A persona stem aimed at F4. JD |
| D2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Do not fold and do not inflate. State the figure at its own scope: roughly £4M of influenced revenue. Answer slot: say which part was yours, in your own words; if you cannot separate your part from the channel's, say so plainly. Concede that it is influenced revenue, not a number you carried | F3's figure under the "how much was you" stem. EXP |
| D3 | "An operator's commercial team will ask what this partnership costs them and what they get. Give me that in sixty seconds." | CASE | [generic] | Hold one position from your section 5 thesis through two follow-ups. Say what it costs the operator, what they get, and what you do not yet know about their economics. Concede that last point specifically; do not invent a number. No claim about your past | Tests the recruiter's close, "what it means for the operators themselves", in commercial terms. CASE |

*Proposed language in this bank, pending your approval.*

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | A 90-second arc of the roles as you gave them: 9 years in partnerships, the last 4 running the ISV channel, and 5 years in transport consulting on bus and light rail network planning. Answer slot: your material does not show how the 5 consulting years sit against the 9 partnership years, so say the order of the roles plainly, in your own words. Give your own reason for each move; if there was no single reason, say so | The biography question sets the frame for everything after it. EXP |
| E2 | "What have you been following lately about how operators plan and run their services?" | CO | [generic] | Choose one thing you have genuinely followed and can discuss for 60 seconds; if nothing comes to mind, say so plainly and say how you would find out. If you have read the report, one point you would challenge, with your reason, is stronger than one you agree with. No claim about your past | A casual question on the role's central topic is still scored. CO; [generic] because no strategy source was available |

*Proposed language in this bank, pending your approval.*

### Requirement coverage

| Requirement | Questions |
|---|---|
| "present a short POV on where you'd take our operator partnerships over the next 18 months" | A1, A2, A3, A4, A5, D3 |
| "Please land on what it means for the operators themselves." | A1, A4, B3, D3 |
| "Ross will push on commercials." | A5, B1, B2, C1, C2, C3, C4, D1, D2 |
| Limits you stated: no rail sales, no direct quota | B1, B2, C3, D1 |
| JD requirements | none, and why: no JD was supplied |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would you want to be true about operator partnerships six months after I start?" | Turns the 18-month talk into Deepa's own yardstick |
| R2 | "Which operator relationship do you think has the most untapped potential, and what is stopping it?" | Invites the real constraint and keeps the conversation on operators |
| R3 | "In the strategy report your team circulated, which conclusion are you least sure about?" | Shows you read it and treat it as live thinking. Ask only if you have read it, and not to correct her |
| R4 | "Does this role carry a number, and if so, is it direct or influenced?" | After B1 the gap is on the table, and this gets the fact you most need while showing you take commercials seriously |
| R5 | "Where do partnership commercials and direct sales overlap, and who owns the boundary?" | Turns Ross's push into a scoping conversation |
| R6 | "If I asked three of your operators what a partnership with Kelverton is worth to them, what would they say?" | Operator-first, as the brief asked, and surfaces ground truth |

## 13. Prohibited claims

Built locally from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't sold into rail specifically." No slot |
| Has carried a quota or hit a number | Negative you stated, F4 | "I haven't carried a direct quota." Your quote adds "only influenced revenue". No slot |
| Generated, closed or owned £4M | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue". The limit is the pack's observation: your material says influenced, not closed or owned. C1 and D2 stay inside the figure's own slots |
| Built the ISV channel | Inflated form of F1 | F1's quote at its own scope: running the ISV channel and taking it from 6 partners to 40. The limit is the pack's observation: your material says running and growing it, not building it |
| Knows train operating companies' planning and scheduling | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning. The limit is the pack's observation: your material names no work for train operating companies. B3's slot stays inside the network planning |

## 14. Sources

**Provided documents:** the recruiter's email as you quoted it, which establishes the loop (one 60-minute panel, a 15-minute talk, then Q&A) and so the persona weights above; your background paragraph. The market report was attached by the recruiter but its text was not available to me, so nothing here is drawn from it. No dossier was present.

**Searches sent, all refused (permission not granted):**

- `Kelverton Rail values`: refused
- `Kelverton Rail interview process partnerships`: refused
- `Kelverton Rail strategy news train operating companies scheduling software`: refused
- `Deepa VP Partnerships Kelverton Rail`: refused
- `Ross Commercial Director Kelverton Rail`: refused
- `Senior Partnerships Manager job description rail technology UK train operating companies`: refused

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Published values could have themed VAL questions and a values sheet; no values-style round is named, so the cost is small |
| 2. `Kelverton Rail interview process partnerships` | unavailable | Documented loop structure beyond the recruiter's email, and persona weights keyed to it |
| 3. `Kelverton Rail strategy` / recent news | unavailable | CO and CASE questions grounded in current strategy, and a grounding brief. The report's text, which would fix this, is not in hand |
| 4. `{interviewer name} Kelverton Rail` | unavailable | An interviewer read for Deepa and Ross and a reverse question tied to their paths. Two calls were sent, one per first name with title and company |
| 5. representative `Senior Partnerships Manager` JD | unavailable | JD-tagged questions and requirement rows in place of the recruiter-words-only snapshot |

## 15. Upgrade menu

- The market report's recommendations and conclusions → section 5's theses are rebuilt against it with a consensus point and a divergence, and A2, A3 and E2 become `[grounded]`, with a grounding brief added
- The JD text → the coverage table gets real requirements and JD-tagged questions in place of the recruiter's words
- Search permission → published values, loop structure, strategy news, Deepa's and Ross's public footprint, and a representative JD, which sharpen the persona weights and the reverse questions
- One line to the recruiter asking what "commercials" covers for Ross, such as pricing, deal structure or accountability for numbers → C and D are reweighted to match
- Your own answers to the slots in C1, C2, B3, C3 and E1 → those rows become story-mapped and the evidence column gains the new quotes
- The attribution report or partner-programme dashboard behind the £4M and the 6-to-40 count → F1 and F3 move from `medium` toward `high`
- Dates for the 5 consulting years and the 9 partnership years → E1's timeline slot closes
- A tuesday-dossier.md, if you have one → verified evidence and any recorded objections would sharpen B1 and the prohibited list
