# Interview pack: Senior Partnerships Manager, Kelverton Rail

- **Round:** second round, Tuesday. A panel of two, 60 minutes: a 15-minute POV talk with no slides, then Q&A (recruiter's email, as you quoted it).
- **Panel:** Deepa, VP Partnerships, your future manager. Ross, Commercial Director, who "will push on commercials" (recruiter's email).
- **Built on:** your message and the recruiter's email only. No JD was supplied, the market report did not reach me, and the web research I tried was refused (see Sources).
- **Prep time:** about four hours across the weekend.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Wherever it says "answer slot", the content is yours, in your own words, and "I don't know" or "that was not mine" is an honest answer.

Question IDs run A to E and then G. F is skipped because F1 to F7 are fit-snapshot rows.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behaviour shows the company's published values. No bank here: no values round is documented. |
| EXP | Whether your CV claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage (about 4 hours)

1. **60 min: the POV.** Build it from the graded-deliverable section below. Do two timed runs aloud, aiming for 11 to 12 minutes. Stop early rather than run over.
2. **45 min: C1 until it is boring.** This is the highest-ROI prep in the pack. Add D2 (the 60-second version) and C2.
3. **45 min: your two numbers.** Do B1, B2 and D1. Before you rehearse, write down for yourself what you know and don't know about how each figure was counted.
4. **40 min: Ross's commercial push.** Do B3, B4, D3 and G2, and pick your reverse questions.
5. **20 min: the market report.** Choose one consensus point to cite, one place you diverge, and one thing you would say no to.
6. **30 min: one live drill** on C1, or on whichever answer still feels shaky.

Everything else (E1, E2, G1, A3, A4) is insurance.

## Fit snapshot

No JD was supplied. Requirements are the recruiter's own words where she gave them, and plain role-family prose labelled generic where she did not. Requirement text without quotation marks is not a quote from anything.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message | medium | [grounded] | transferability | Your quote is channel work at a payments company, not operator partnerships, and nothing inspected sits behind it. Keep your words at that scope: "For the last four years I was running the ISV channel at a payments company." Answer slot: the brief is about operator partnerships, so expect a probe on how channel work carries over. If any part of it resembled operator work, say how in your own words; if none did, say so plainly and stay with the channel |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your quote says bus and light rail network planning. Your message describes Kelverton's customers as train operating companies, and the quote does not say you worked with one. Words: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: "the other side" is yours to define. Say which side you were on and for whom you worked; if you never worked directly with a train operating company, say so plainly and stay with the quote |
| F3 | "Ross will push on commercials" — recruiter's email | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material says influenced revenue, not revenue you carried, with nothing inspected behind it. Keep the figure at its own scope: roughly £4M, influenced. The probes on this figure are in B1, B2 and D1 |
| F4 | Carrying a revenue number directly (generic, role-family) | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A limit you stated. Words: "I have never carried a direct quota." Then how you would learn what carrying one involves, said as a plan and never as a past. Nothing is added to make the gap feel smaller |
| F5 | Selling into rail (generic, role-family) | "Never sold into rail specifically" — your message | none | [grounded] | capability | A limit you stated. Words: "I have never sold into rail specifically." Then a plan in your own words for the first weeks. Do not offer adjacent work as if it closed the gap |
| F6 | Growing a partner programme from a small base (generic, role-family) | "took it from 6 partners to 40" — your message | medium | [grounded] | none | No gap, but a figure with nothing inspected behind it, so expect it to be probed. Lead with it in your own terms: 6 to 40. A number beats an adjective |
| F7 | Understanding the operator problem the product addresses (generic, role-family) | none given | none | [generic] | discovery | Your material does not show this either way. Selection scaffold: pick an operator problem you can describe from first-hand experience, with a named stake and what you saw. If no such problem comes to mind, say so plainly, then give the nearest thing your material carries (the F2 quote, at its scope), or say how you would find out |

No gate rows appear because there is no JD. Location, travel, pay and start-date terms would be gates, and your material says nothing about them.

## Graded deliverable: the 15-minute POV

The brief: "where you'd take our operator partnerships over the next 18 months", landing on "what it means for the operators themselves". It is graded, so it gets its own build.

**Facts you may build on.** Each is quoted from a fit-snapshot row's evidence cell, and the row's limit travels with it.

| Fact (row) | Quote | Use it as | Limit to state |
|---|---|---|---|
| F6 | "took it from 6 partners to 40" | The scale of channel you have grown | You have not said who recruited the partners or how they were counted. Do not add either |
| F2 | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The close, where you speak from the operators' seat | Bus and light rail, not train operating companies |
| F5 | "Never sold into rail specifically" | The limit you volunteer in the first minute | None. This is your own statement |

**The consensus problem.** The strategy team that wrote the market report is the audience, and the report was circulated to you, so rivals may hold it too. Reciting its shortlist scores as homework at best. Bring one consensus point to show you read it. Then give one thesis-driven divergence with your reasons. Then give the anti-pick, the one thing you would say no to.

**Thesis options.** Choose one as the spine and mention the others only as things you would test. Each carries a mandatory concession, said aloud.

| Thesis | Operators' side | Mandatory concession | Provenance |
|---|---|---|---|
| T1: judge every operator partnership by a result an operator would notice, not by a Kelverton-side count | The operator sees the partnership change something in their own work | It is slower to prove and harder to count, which makes it a harder case to make to the Commercial Director. Say so | [generic] |
| T2: go deeper with fewer operators before going wider | Fewer vendors' attention, more of it each | Breadth and the topline arrive later. You have not carried a quota, so name the trade-off as a question for Ross rather than assert its size | [generic] |
| T3: build a small partner ecosystem around operators' needs, so Kelverton need not build everything itself | Operators get more than the core product without a new procurement each time | Your ISV channel partners were not operators, and an operator may not want another vendor to manage (A4). Say that this is adjacent experience, used as a method to test | [inferred] from F1 and F6: channel work is the closest thing your material carries |

**Anti-pick (one row, required).**

| Anti-pick | How to say it | Provenance |
|---|---|---|
| One kind of operator request or partnership you would decline in 18 months | The request, what saying yes would cost the operator and Kelverton, and what you would offer instead. Choose it from the report's own content, not from memory | [generic] |

**Requested close: what it means for the operators.** Finish the talk here and not on Kelverton's revenue. In your own words, state four things from the operator's seat: what changes for them at month 6, what changes at month 18, what you would ask them to give, and how they would tell it was working. Supply no outcome or figure you have not read in the report or been given.

**Shape of the talk.**

| Minutes | Beat | Provenance |
|---|---|---|
| 0:00 to 1:00 | Frame it: the question, two or three assumptions you are making about operators, and the limit you volunteer, "I have never sold into rail specifically" | [generic] |
| 1:00 to 3:00 | The consensus point, then where you diverge | [generic] |
| 3:00 to 8:00 | The spine thesis, and how the 18 months run in three phases. The content of each phase is yours | [generic] |
| 8:00 to 10:00 | The anti-pick, and the concession | [generic] |
| 10:00 to 12:00 | The close on operators | [generic] |
| 12:00 to 15:00 | Buffer. Stop early and invite challenge | [generic] |

## Persona table

No interviewer public footprint was researched. The weights rest on the recruiter's words and on the relationship priors.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Challenges to the POV: what it assumes, what you'd say no to, how you would measure it | high. Deepa is your future manager, a hiring-manager prior of Case plus Skeptic. The first 15 minutes are a graded POV, so every follow-up is a case | Clarify, then structure, then answer. Name your assumptions aloud and challenge one premise respectfully |
| Data-Driven Prober | Every number on your account, taken two levels down | high. The recruiter said "Ross will push on commercials", and your two figures are the only commercial evidence you have given | Know what you can and cannot say about how each figure was counted. Name the weakest assumption before they do |
| Skeptic | The rail gap: "never sold into rail" | high. You have stated the gap yourself, and a hiring manager's job includes derisking it | Rehearse the one predictable objection until it is boring. Bridge only from what you stated, and name the limit first |
| Pressure | Interruptions, "how much of that was you", 60-second forcing | medium. Ross is a senior commercial exec, which is the skip-level and executive prior, and the commercial push suggests it | Pause, restate, hold the quoted position through two follow-ups, concede specifically |
| Conversational | The opening, "walk me through the journey" | low. A panel of two senior people after a prepared talk makes a chatty register less likely | A 90-second arc built only from your quotes. Treat casual questions as scored |
| Peer Evaluator | The seam between partnerships and commercial | low. Ross is not a peer, but a Commercial Director sits next to a partnerships function | Propose seam principles, not Kelverton's real seam. Say what you bring his team |
| Values / Behavioral | Scenario probes against published values | low. The recruiter described no values round, and no published values were retrieved. No bank is written | If a values round turns up, the research section says what to add |

## Question banks

### A. Case / Strategist (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Where would you take our operator partnerships over the next 18 months, and what does it mean for the operators themselves?" | JD | [grounded] | This is the assignment. Build it from the section above. It makes no claim about your past beyond the rows that section quotes | The recruiter set this question as the 15-minute deliverable (F1, F2). JD, because it scores the stated brief |
| A2 | "What did you have to assume about our operators to build that view?" | CASE | [generic] | Open the talk by naming two or three assumptions aloud and inviting correction. That turns the gaps in F2 and F5 into a method. Present assumptions as assumptions, and state nothing about Kelverton's operators that you have not been given or read. The assumptions are yours to choose. The pack names none | A Strategist scores whether you clarify before you structure. The rail gap makes this the safest way to show it |
| A3 | "Which operator request would you say no to over the next 18 months, and why?" | CASE | [generic] | Structure: the request, what saying yes would cost the operator and Kelverton, what you would offer instead. Use the anti-pick from the build section. Choose it from the report's own content | A role that includes saying no gets tested on it. Rehearsed here so you are not inventing the principle live |
| A4 | "An operator tells you the scheduling software works but it does not want another vendor relationship to manage. What do you do?" | CASE | [generic] | Clarify first: what sits behind the objection, what it costs them, who decides. Then objective, options, risks and what you would measure. Say what you would need to know before choosing. The question needs no claim about your past, so the guidance makes none | It tests the T3 ecosystem thesis at its weakest point (F1, F2). It is a live problem from the role, not a question about your history |
| A5 | "How would you know in six months that the plan is working, from the operators' side and not ours?" | CASE | [generic] | Structure: the result an operator would notice, a leading indicator, and who tells you. Name no figure and no benchmark you have not been given. If you know the report's own measures, use them as it states them | It forces the close of the POV (F2) to be measurable, which is where a Commercial Director will press |

### B. Data-Driven Prober (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You took the ISV channel from 6 partners to 40. How were those partners counted?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Story-mapped on F6: the channel went from 6 partners to 40. Those are the beats the quote states, so tell them in those words. Answer slots, each in your own words: how the 6 and the 40 were counted, what that count is sensitive to, the assumption behind it you would defend least, and which part was yours. If you know, say it; if you do not know how it was counted, say so plainly and return to the quote. Name the weakest assumption yourself before they do | F6 is a headline figure. Defend-the-number is EXP because it tests attribution and counting, not the result |
| B2 | "Roughly £4M of influenced revenue: what does influenced cover, and what is that number most sensitive to?" | EXP | [grounded] "roughly £4M of influenced revenue", "only influenced revenue" | Say it at the quote's own scope: roughly £4M, influenced, and not a quota you carried. Answer slots, each in your own words: what influenced covered, what the figure is most sensitive to, and the assumption you would defend least. If you do not know how it was built, say so plainly and return to the quote. Say "only influenced revenue" as you said it. Do not soften it or widen it | F3 is the only commercial evidence in the material, and Ross will push on commercials, so the figure is the target |
| B3 | "If we asked you to carry a number here, what would you want to know before taking it on?" | JD | [grounded] "never carried a direct quota" | Start from the plain acknowledgment your message states: "I have never carried a direct quota." Then ask your own questions: what the number would be measured on, over what period, and what you would need from others to hit it. They are questions, so they claim nothing about your past. Close with how you would learn the answer in the first weeks, said as a plan | F4 is a stated gap. The honest form is a plain acknowledgment plus diligence, which reads as seriousness with a senior commercial interviewer |
| B4 | "Tell me about a commercial decision you made in your channel work." | EXP | [generic] | Selection scaffold: pick a decision where terms or money were at stake and you took a position. It needs a named stake, what you chose and what followed. If no such decision comes to mind, say so plainly, then give the nearest thing your material carries (F6, at its scope), or say how you would approach one. Your material carries no commercial decision, so none is supplied | The recruiter's "commercials" raises the theme. No quote carries a story for it (F3, F4), so this is a scaffold |

### C. Skeptic (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have never sold into rail. Why should operators take you seriously?" | JD | [grounded] "Never sold into rail specifically", "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)", "9 years in partnerships, last 4 at a payments company running the ISV channel" | **The highest-ROI prep in this pack.** Level 1, exact wording, concession first: "I have never sold into rail specifically. I spent five years in transport consulting, in bus and light rail network planning, and for the last four years I was running the ISV channel at a payments company." Stop there. Let them draw the inference, because an inference you assert on your own behalf is the one that gets tested. Level 2, "bus and light rail is not a train operating company, so what is different?" Answer slot: say in your own words what you know to be different; if you do not know, say so plainly and stay with the quote. Level 3, "so what don't you know?" Answer with the questions you would ask in the first weeks. Claim nothing about your past. Volunteer the limit in the first minute of the POV, so it is yours and not extracted | F5 is the gap you stated, and a hiring manager's job includes derisking it. Skeptic and JD: the probe scores a stated gap against the listed job |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never carried a direct quota, only influenced revenue", "Never sold into rail specifically" | Choose one of the two limits your own message states and say it first: "I have never sold into rail specifically" or "I have never carried a direct quota." Then the ramp, as a plan in future tense and in your own words: what you would do first and who you would ask. The pack does not choose between them | Both limits are yours (F4, F5). A gap you name before you are asked scores as self-assessment, not a dodge |
| C3 | "You say you know the operator world from the other side. Which side was that?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Answer slot: say plainly which side you were on and for whom you worked, in your own words. If you did not work directly with a train operating company, say so and stay with the quote: five years in transport consulting, in bus and light rail network planning. Do not turn "the other side" into a relationship the quote does not state | The phrase is a claim about which side of the table you stood on (F2). A relationship inversion collapses on the first follow-up |
| C4 | "Why leave payments for rail-tech, and why now?" | EXP | [generic] | Give your actual reason in your own words, in two sentences. The pack supplies none. Keep it forward-looking and make it the same reason you gave the recruiter | Motivation consistency is scored. The material states no reason, so this is a slot and not a script |

### D. Pressure (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That result: how much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue", "never carried a direct quota, only influenced revenue" | Pause and restate the question. Hold through two follow-ups by returning to the quote: roughly £4M, influenced. Concede specifically, from your message: "I have never carried a direct quota." Never fold on the figure to restore harmony and never add to it. Answer slot: say which part of the figure was yours in your own words; if you cannot separate your part, say so plainly and return to the quote | F3. Attribution is the pressure test aimed at an influenced figure |
| D2 | "Sixty seconds: why you over a candidate who has sold into rail?" | JD | [grounded] "Never sold into rail specifically", "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)", "9 years in partnerships, last 4 at a payments company running the ISV channel" | Concede first, in one sentence: "I have never sold into rail specifically." Then two quoted facts, each at its scope: five years in transport consulting, in bus and light rail network planning, and four years running the ISV channel at a payments company. Stop. No claim about what those years prove | F5 under time pressure. The hold is only what the quotes carry |
| D3 | "Skip to the point. What does this plan cost us, and what do we get back?" | CASE | [generic] | Pause, restate, then give the shape: what you would need from Kelverton's numbers, the categories a cost and a return would fall into, and what would change your answer. Say plainly that you would not give a figure without the data. Invent no figure and no benchmark | A time-boxed cut-in on the POV from the commercial interviewer. It rehearses composure and honest uncertainty (F3, F4) |

### E. Conversational (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)", "9 years in partnerships, last 4 at a payments company running the ISV channel" | Story-mapped on F2 and F1, in 90 seconds and in order, with only the beats those quotes state: five years in transport consulting, in bus and light rail network planning; nine years in partnerships, the last four at a payments company running the ISV channel. Why here: give your actual reason in your own words, because the pack supplies none | A casual opener is still scored. A scripted arc keeps it from drifting (F1, F2) |
| E2 | "What are you most curious about in our operators' world?" | CO | [generic] | Pick the assumption from A2 you most want corrected, and say why in one sentence. State no fact about Kelverton's operators that you have not read or been given | Curiosity is scored, and this ties the Q&A back to the POV's stated assumptions |

### G. Peer Evaluator (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Where is the seam between partnerships and the commercial team on a new operator deal, and what happens when we disagree?" | JD | [generic] | Offer principles, not Kelverton's real seam: who owns the operator relationship, who owns the terms, how a disagreement gets escalated. Say they are proposals to test with Ross. Selection scaffold for the disagreement half: pick a time you disagreed with an equal. It needs a named stake, what you held, and the relationship intact afterwards. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Ross is the commercial voice, and partnerships sit beside commercial (F3). The material carries no disagreement story, so this is a scaffold |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick an occasion where credit spanned teams. It needs a named stake, how credit was shared, and what you would do differently. If none comes to mind, say so plainly, then say how you would handle it. Claim no credit rule you did not use | Your own phrase "only influenced revenue" invites this question (F3, F4). Shared credit is exactly where an influenced figure gets probed |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1: the 18-month POV | A1, A2, A3, A4, A5 |
| F2: land on the operators | A1, A5, C3, D2, E1, E2 |
| F3: commercials | B1, B2, B4, D1, D3, G2 |
| F4: carrying a number | B3, C2, D1 |
| F5: selling into rail | C1, C2, D2 |
| F6: growing a partner programme | B1, E1 |
| F7: the operator's problem | A2, A4, E2 |
| Questions covering no listed requirement | C4 (motivation) and G1 (the seam). Both are included because of who is on the panel |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which operator relationship is this role meant to deepen, and what would it look like in 18 months?" | It ties to your POV and tests the assumptions you stated at the start |
| 2 | "What do your operators say they most want from Kelverton that the software alone doesn't give them?" | It invites correction of A2's assumptions in the operators' own terms, and it is what you most need to know |
| 3 | "In this role, how is the line drawn between a number I would carry and revenue I would influence?" | You have been plain that you have not carried a quota (F4). Asking it first reads as diligence, and the answer decides the job |
| 4 | "How do partnerships and the commercial team share credit on an operator deal?" | It anticipates the G1 and G2 seam before Ross raises it |
| 5 | "What would have to be true at month six for you to feel this hire was working?" | It makes the success measure explicit and invites a candid answer about the rail gap |
| 6 | "Which claim in the strategy team's report do you expect operators to push back on?" | It shows you read it, and it points you toward the divergence in your POV |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Negative you stated, F5 | The plain acknowledgment: "I have never sold into rail specifically." No slot |
| Has carried a quota or owned revenue | Negative you stated, F4 | The plain acknowledgment: "I have never carried a direct quota." No slot |
| Worked with train operating companies | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation, not words for you: the material says bus and light rail network planning, not train operating companies. C3's slot stays inside the quote |
| Owned or closed £4M of revenue | Inflated form of F3 | F3's quote at its own scope: roughly £4M, influenced. The limit is the pack's observation: the material says influenced, not carried |
| Recruited the 34 further partners or built the programme from scratch | Inflated form of F6 | F6's quote at its own scope: the channel went from 6 partners to 40. The material does not say who recruited them or how, and B1's slot asks only how they were counted |

## Sources

- **Provided:** your message, including the recruiter's email as you quoted it.
- **Not in hand:** the market report. The attachment did not reach me, so nothing in this pack is drawn from it. The differentiation advice is method only.
- **No dossier** was present.
- **Searches sent** (all refused, so none returned a result):
  - "Kelverton Rail values": refused
  - "Kelverton Rail interview process partnerships": refused
  - "Kelverton Rail strategy scheduling software train operating companies news": refused
  - "Deepa VP Partnerships Kelverton Rail": refused
  - "Ross Commercial Director Kelverton Rail": refused
  - "Senior Partnerships Manager Kelverton Rail job description": refused

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Would have fed a values cheat sheet (section 10) only if a loop source documented a values round. It moves nothing now, and no VAL bank is written |
| 2. `Kelverton Rail interview process partnerships` | unavailable | Would have checked the loop against published process. Persona weights rest on the recruiter's description of the session |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Would have fed a grounding brief (section 6) and sharpened the CO and CASE banks, which are generic here |
| 4. `Deepa` and `Ross` at Kelverton Rail | unavailable | Would have fed the interviewer read (section 7), per-member persona weights and a reverse question tied to an interviewer's own path |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Would have replaced the role-family prose in F4, F5 and F7 with quoted lines labelled inferred, and could have surfaced gate rows |

## Upgrade menu

- The JD text → the generic requirement rows (F4, F5, F6, F7) become quoted and grounded, and gate rows for location, travel and pay terms join the snapshot
- The market report's headline claims, pasted → a grounding brief, and differentiation built against its actual consensus items instead of method
- Search access allowed → the values, loop, strategy and interviewer targets run, which adds the interviewer read and sharpens the CO and CASE banks
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), once search is allowed → a company strategy brief, interviewer talks and writing, and role-family loop reports
- Interviewers' full names or public profiles → per-member persona weights and a reverse question tied to an interviewer's own path
- Your own answers to the slots in B1, B2, C3 and D1 (how the 6 and 40 were counted, what influenced covered, which side of the operator world, which part was yours) → those rows move from slots to story-mapped, grounded answers
- A `tuesday-dossier.md` from an earlier role assessment → verified evidence, an underwriter-named objection and prohibited claims
