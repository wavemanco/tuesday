# Interview prep pack — Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy — a peer: both of you would report to the same VP. **Format:** one 60-minute conversation.
**Highest-ROI prep in this pack:** D1, the question about having no classic sales-ops or quota-setting experience, sitting next to a Director of Sales Strategy.

## 1. How to use this pack and the type key

Personas describe how a question arrives. Types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script: where it says answer slot, the answer has to come from what you actually did, in your own words, and either branch of the slot is a good answer.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the company's published values. No question carries this tag here: no published values were in hand and no values round is documented |
| EXP | Work-experience deep-dive | Whether the CV claims survive scrutiny and whether attribution is honest |
| JD | Role / JD-driven | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge | Whether you can think at Northwind's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the actual role |

A question that mixes two types carries its primary type in the Type column and the other is named in the rationale.

## 4. Fit snapshot

The requirements are the six JD highlights you supplied, not the full JD text. F7 is the peer seat rather than a JD line. The candidate evidence is your summary of Priya's background, not her CV.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Your material says you proposed a change and that it was credited with an uplift. It does not say who credited it, how the figure was counted, or that the change was go-to-market for a product line, and the words stay at the quote: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: the JD's own-GTM-strategy line makes a probe on how far the work reached likely. If any of what followed the proposal was yours, say which part and how you decided, in your own words; if the proposal was the extent of it, or the credit was shared, say so plainly and stay with the proposal |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | low | [inferred] | discovery | Inferred from the JD's four-stage line: a partner-level revenue model touches opportunity sizing, and nothing in the material shows analysis across customer or partner lifecycle stages, so no claim spans it. Answer slot: if any analysis of yours looked across stages of a relationship, say which stages and what you found, in your own words; if none did, or none was yours, say so plainly and say how you would size the first stage you would look at |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | The tools are named in the quote's own terms, so lead with them as stated: "I'm skilled in SQL/Tableau." It is a skill claim with nothing inspected behind it, so expect a probe, and the quote says skilled, not that analyses were run independently, which B4's slot handles |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The material says a model and the negotiations it was used in, not the design of a partner motion, and the words stay there: "I built a partner-level revenue model used in carrier negotiations." "Required" makes this the row most likely probed. Answer slot: if any part of how a partner went to market with the company was yours to design, say which part and how you decided; if the model informed negotiations and you designed no part of the motion, or no such design existed, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote reaches the requirement in other terms, so the bridge only rewords it: "I set annual volume targets with cross-org consensus." Which orgs, how consensus was reached and whether anyone disagreed are not in the material, so nothing is added; A4 carries the slot |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | none | The quote reaches the line as written: "I use AI tools daily." It says use, not building or launching, and the words stay at use. Which tools and for what is the candidate's to say; E2 carries the slot |
| F7 | "Director of Sales Strategy" — the peer seat (Dan's title), the coach's notes, not a JD line | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and the notes state it. Words: "I haven't had classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past: what you would ask the peer to walk you through first. The adjacent quote "set annual volume targets with cross-org consensus" stays at its own scope and is never offered as quota-setting |

## 7. Reading the interviewer

Everything here comes from your profile summary of Dan. The searches for his public footprint were refused, so no talks or writing were checked.

| Item | Detail |
|---|---|
| Career pattern | Pricing and monetization roles, with one early-stage-startup chapter |
| Self-described style | "relentlessly data-driven" |
| Implication 1 | Expect every number you give to be walked back to its assumptions: B1, B2 and B3 rehearse that |
| Implication 2 | Pricing and packaging is his native ground, so the cases (C1, C2) tilt there. Reason about it in your own words without claiming pricing experience |
| Implication 3 | As a peer, he is pricing what you cost his work and what you add to it: A1, A3 and A5 rehearse reciprocity and disagreement |
| Implication 4 | One startup chapter is a mild signal: expect a scrappiness or pace probe at most, and do not over-index on it |
| Mirror opportunity | Shared vocabulary only, not a shared path: his monetization spine and your quote "built a partner-level revenue model used in carrier negotiations" (F4) both sit near revenue. No row carries a startup chapter on your side, so none is offered. Shared background is never a strategy |

## 8. Persona table

| Persona | How it shows up with Dan | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting between his team and yours, "what would you need from me", credit across teams | High. Relationship prior for a peer. Depth 5 | Reciprocity first; offer seam principles instead of pretending to know the seam; a disagreement story that shows spine and tact |
| Data-Driven Prober | Walks the numbers to their inputs and assumptions, two levels deep | High. Peer prior, raised by "relentlessly data-driven". Depth 5 | Know what you can and cannot say about how each number was counted, say plainly when you do not know, and name the weakest assumption you know of before he does |
| Case / Strategist | A live problem set in pricing, packaging or the product's go-to-market | Medium. His pricing and monetization spine tilts toward pricing and unit-economics cases. Depth 3 | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of the sales-ops and quota gap and of the move to this role | Medium. F7 is a stated gap and he sits in the adjacent seat. Depth 3 | Rehearse the one predictable objection until it is boring; calibrated candor over bluffing a competency he may own |
| Conversational / Rapport Builder | Opening biography and a casual question about AI | Low. Likely only as an opener. Depth 2 | A 90-second arc; treat casual questions about the JD's plus-skill as scored |
| Pressure / Stress | Time-boxed challenge on attribution or on why you | Low. Not a peer prior; present as a short stress test. Depth 2 | Pause, restate, anchor in what you stated, hold through two follow-ups, concede specifically |
| Values / Behavioral | No bank | Low. Your word is one 60-minute conversation with Dan; no loop source documents a values round, and no archetype fallback is used because the loop is established | Behavioral probes arrive through the Peer bank (A2, A5) instead |

## 9. Question banks

Provenance comes before the guidance and carries every candidate sentence the guidance rests on. Where the guidance claims nothing about your past, the cell holds its label alone.

### A. Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side — where is the seam between what you would own and what sits with sales strategy, and what happens when we disagree?" | JD | [generic] | Make no claim about your past. Say first that you do not yet know where the seam sits here, then offer principles: one named owner per decision, shared definitions for numbers both teams use, and a way to surface a disagreement before it reaches your shared VP. Close on reciprocity: what you would ask Dan for and what you would put on the table for his team. Never describe the seam as if you knew it | The JD's own-GTM-strategy line (F1) puts you next to his team, and a peer opens with the seam. JD because it scores the role's scope; a pattern for the problem, so generic |
| A2 | "How do you handle credit when work spans teams?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Open prompt. First say in your own words how you actually handle it. If a story fits, the only beats your material states are these: annual volume targets, set with consensus across orgs; tell it in those words. Answer slot: if credit or ownership of those targets was ever divided between orgs, say how it was handled; if it was not an issue, or not yours to handle, say so plainly and stay with the targets | A peer-evaluator stem, matched to the influence requirement in F5. JD because it scores "strong cross-functional influence"; the quote sets the only beats allowed |
| A3 | "Say we are both live next quarter. What would you need from me in your first month, and what would my team get from you?" | JD | [grounded] "skilled in SQL/Tableau" | Reciprocity first: lead with what you offer, then what you need. What your material carries is skill in SQL/Tableau, so offering to share analysis openly is a statement about the future, not a claim about a past project. Your needs are asks, not facts: the planning calendar, where the numbers live, and how the team defines each lifecycle stage. Do not pretend to know how the team runs today | The peer is pricing what the hire adds to his work; F3 is the capability you can offer. JD because it tests the JD's analysis line applied to the seam |
| A4 | "Walk me through how you reached cross-org consensus on those annual volume targets." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: you set annual volume targets, and consensus spanned orgs; tell those beats in your own words. Answer slot: a peer will probe the seam, so if orgs disagreed, say which positions and what moved them; if there was no disagreement, or the consensus was reached without a process you ran, or it was not yours to resolve, say so plainly and stay with the targets. Do not call them quotas | F5 is the evidence for the influence requirement and the likeliest place to be probed. EXP because it tests what was actually yours; JD content, EXP delivery |
| A5 | "If your read of a whitespace number and mine disagree, how do we settle it?" | CASE | [generic] | Structure it: first agree definitions and data source, compare inputs before conclusions, name which assumption moves the gap, agree what evidence would change either view, and only then take the documented difference to your shared VP instead of lobbying. Make no claim about your past | A live disagreement that merges the peer persona with a data-driven interviewer. CASE because it is a problem about the future with no premise about your history; it scores F2's whitespace line and F5 |

### B. Data-Driven Prober (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Defend-the-number, in your own words, on four slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Where the quote supplies none, it is an answer slot: if you know how it was counted, say how; if you do not, say plainly "I don't know how it was counted" and return to the quote's own verbs, proposed and credited. Never supply a method for it | F1 is the headline metric, and quantified claims are what probers go to first. EXP because it tests attribution and counting |
| B2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Name, before he does, the assumption you know of that you would defend least. Answer slot: if you know of one, say it in your own words; if you do not, say plainly that you do not know of one or do not know how it was counted. Never offer an assumption on the quote's behalf | The weakest-assumption move converts a gotcha into credibility; F1 is where it applies. EXP as a second level of B1 |
| B3 | "Walk me through the revenue model you built for carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4, with only the beats the quote states: you built it, it was partner-level, it was used in carrier negotiations. Answer slot: "relentlessly data-driven" and the JD's analysis line make a probe on what the model was built from and how it was checked likely, and the JD's partner-motion line makes a probe on whether any of it shaped how a partner went to market likely. If you did those things, say how; if there was no such step, or it was not yours, or it never existed, say so plainly and stay with the model | F4 is the evidence for partner-motion design and its likeliest probe. EXP because it tests what was actually yours; JD content, EXP delivery |
| B4 | "Tell me about an analysis you ran yourself in SQL or Tableau, start to finish." | JD | [grounded] "skilled in SQL/Tableau" | Open prompt matched to the JD's independent-analysis line (F3). Pick one where you can name the question you asked, the data you used, the choice you made in cutting it, and what it changed, and where you did the work yourself rather than directing it. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries, skill in SQL/Tableau, or how you would approach one | F3 is a skill claim with nothing inspected; a data-driven interviewer is likely to test it. JD because it scores the stated requirement |
| B5 | "For a new product with no history, what would you need to see before you trusted a whitespace number?" | JD | [generic] | JD content, CASE delivery. Clarify what whitespace means for the product (new accounts, adoption, expansion, renewal), then the data you would want, the definitions and denominators you would check, what is missing with no history and how you would label a stand-in assumption, the decision the number feeds, and what would change your mind. Name your weakest assumption aloud. Make no claim about your past | The JD's whitespace line (F2) is a core responsibility and the most likely place a data-driven peer tests reasoning. A pattern for the problem, so generic |

### C. Case / Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is an AI copilot launching into enterprise expansion. If it were an add-on to an existing contract rather than a separate product, how would you think about packaging and pricing it?" | CASE | [grounded] | Premise from your research note: enterprise expansion and the Compass launch are stated priorities, and profitability is the third. Clarify what decision this feeds and who buys. Segment existing customers by adoption. Offer two or three packaging options and the trade between them. Metrics: attach, expansion revenue, margin. Risks: cannibalization, and bundling by a much larger platform vendor. Make no claim about your past and none about Northwind's actual packaging | His pricing and monetization spine pulls cases toward packaging; the stated priorities supply a live problem. CASE with CO content; grounded in the research note, whose age is unknown and which was not re-verified |
| C2 | "A much larger platform vendor starts bundling a competing capability at no extra charge. Where do you look first, and what changes in the plan?" | CO | [grounded] | Premise from your research note: bundling by a much larger platform vendor is the main stated competitive threat. Diagnose before prescribing: where do the products overlap most, at which stage of land, adopt, expand or renew does it bite, and what leading indicators would show it. Then options: differentiate on what a bundle cannot do, change packaging, protect renewals. Say what you would need from his team. Make no claim about your past | Strategy fluency at Northwind's own altitude. CO because it tests homework depth; CASE delivery |
| C3 | "A new product line needs a partner route to market alongside direct sales. How would you design the motion, and how would you know it is working?" | JD | [generic] | JD content, CASE delivery on F4's required line. Clarify the product, who the partners would be and what each side wants; define the partner's role in land, adopt, expand and renew; choose what the motion must be measured on; name the main risk and a premise you would challenge. Make no claim about having designed one | "Partner-motion design experience required" has no direct question unless this one exists. A pattern for the problem, so generic |

### D. Skeptic (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "We would report to the same VP. I do not see classic sales-ops or quota-setting experience in your background — how would you handle that side of working with my team?" | JD | [inferred] "No classic sales-ops or quota-setting experience." "set annual volume targets with cross-org consensus" "built a partner-level revenue model used in carrier negotiations" | The highest-ROI rehearsal in this pack. Level 1, the plain acknowledgment: "I haven't had classic sales-ops or quota-setting experience." Name the limit before he asks for it: that is not an area to bluff. Bridge only from stated adjacent work at its own scope, never as quota-setting: "I set annual volume targets with cross-org consensus" and "I built a partner-level revenue model used in carrier negotiations". Then a ramp plan: what you would ask him to walk you through first. Level 2, "what would you get wrong in month one": answer slot: name in your own words where you expect to be slowest; if you cannot name one, say so plainly. Level 3, "why not someone who has done it": hold by describing what the role asks and what you did, and let him draw the inference; concede that you would be learning his side from him. Hold through two follow-ups, then concede specifically, never on the core | F7 is the stated gap, and he sits in the adjacent seat. JD because it scores whether you can do the job beside his team, a gap-probe more than a stated line; the likelihood is inferred from his title and F7, hence the label |
| D2 | "Most of your background is consumer tech. Land, adopt, expand and renew is an enterprise motion — what makes you think it transfers?" | JD | [inferred] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" "built a partner-level revenue model used in carrier negotiations" | State the background in those words and no more; your material has no stated absence of enterprise work, so do not say there was none. Answer slot: if any of your work touched enterprise or partner-level counterparties, say which and how they compared; if not, say so plainly and stay with what you did. Then how you would learn the motion: what you would ask his team about stage conversion. Do not claim the carrier negotiations were enterprise sales | The JD's land/adopt/expand/renew line (F2) is an enterprise motion and the background is consumer tech; F1 and F4 are the nearest evidence. Likelihood inferred, hence the label |
| D3 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] | Pick the JD line your material speaks to least; the pack's own observation is that F2, F4 and F7 are the thinnest. Say it plainly, give the nearest thing your material carries at its own scope, and a first-month plan. If none comes to mind, say so plainly. Never bluff a competency he may own | A skeptic stem every candidate meets. JD because it scores the JD's own list against your honest self-assessment |

### E. Conversational / Rapport Builder (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc whose beats are the quote's own: two years of strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops. Pick two things you did, at the verbs your material uses (built, set, proposed). Answer slot: give your actual reason for the move into this role, in your own words; no reason is supplied here. End by pointing at the role | A casual biography question is still scored; F1 to F5 supply the verbs. EXP because it checks the CV's shape |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say it first: "I use AI tools daily." Answer slot: name the tools and what you use them for, in your own words; if the use is not for analyses or work like this role's, say so plainly. A launch of Northwind's AI copilot, per your research note, is why this is asked casually and scored. Do not claim building or launching AI | The JD's plus-skill (F6) asked in a casual register |

### F. Pressure / Stress (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That ~$400M result — how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, restate. Hold-then-concede on the quote's own attribution: you proposed it, and it was credited with the uplift. Hold through two follow-ups by returning to those verbs. Answer slot: if you know which parts of the result were others', say so specifically; if you do not know, say plainly that you do not. Never fold on the core claim to restore harmony and never add to it | Pressure stems are built on attribution; F1 is the most exposed claim in the pack |
| F2 | "Sixty seconds: why you over someone who has actually run a quota and a forecast?" | JD | [inferred] "No classic sales-ops or quota-setting experience." "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, restate. Plain acknowledgment first: "I haven't had classic sales-ops or quota-setting experience." Then describe, in the quote's own words and without concluding, what you did, and let him draw the inference. Hold through two follow-ups; concede that the other candidate has what you do not. Never disparage him or them | The same gap as D1, delivered as a time-boxed challenge. Likelihood inferred from F7, hence the label |

### Requirement coverage

| JD requirement | Question IDs | Note |
|---|---|---|
| "own GTM strategy for two new product lines" | A1, A3, C1 | B1 carries the headline metric |
| "identify whitespace across land/adopt/expand/renew" | B5, D2 | |
| "run independent analysis in SQL and Tableau" | B4, A3 | |
| "partner-motion design experience required" | C3, B3 | |
| "strong cross-functional influence" | A2, A4, A5 | |
| "AI experience a plus" | E2, C1 | |
| The peer seat (F7, not a JD line) | D1, F2 | |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You have worked in pricing and monetization roles and spent a chapter at an early-stage startup — what from that chapter do you still use here?" | Tied to his own path, which turns an interrogation into a peer conversation and shows you read about him |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer; it shows you are pricing what you add |
| R3 | "Where do you expect the seam between your team and the GTM lead for the two new product lines to be, and what should we agree up front for when we disagree?" | Shows you plan to design the seam with him rather than assume it |
| R4 | "Enterprise expansion, Compass and profitability are the stated priorities — how does the sequencing show up in how your team plans the year?" | Shows homework without asserting what you cannot know |
| R5 | "How is the bundling threat showing up in what you see, and what is the first analysis you would want from me on it?" | Moves the conversation into data, his stated style, and into your first deliverable |
| R6 | "From your seat, what would make this hire a clear success six months in?" | A rapport-weighted slot a candidate must not leave generic |

## 13. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or led go-to-market for a product line, or sole credit for the ~$400M uplift | Inflated form of F1 | F1's quote at its own scope: proposed, credited. The limit is the pack's observation: the material says a proposal, not go-to-market ownership. B1 and F1's slots stay inside the proposal |
| Designed partner motions or programs | Inflated form of F4 | F4's quote at its own scope: a model used in carrier negotiations. B3's slot stays inside the model |
| Ran land, adopt, expand or renew analysis | Inflated form of F2 | F2's quote at its own scope. The slot asks only whether any analysis looked across stages |
| Presented the revenue model as pricing or monetization experience, to mirror Dan's career | Inflated form of F4 | F4's quote at its own scope: a revenue model, not a pricing model |
| Built or launched an AI product | Inflated form of F6 | F6's quote at its own scope: uses AI tools daily |
| Quota-setting or sales-ops experience, including presenting the annual volume targets as quota-setting | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I haven't had classic sales-ops or quota-setting experience." No slot |

## 14. Sources

**Provided documents:** your message: the six JD highlights, the summary of Priya's background, the profile summary of Dan, and your research note on Northwind's priorities and competitive threat. The research note's age is unknown and it was not re-verified. No dossier was present.

**Searches sent:**
- `Northwind Data company values` — refused
- `Dan Kovac Northwind Data Director of Sales Strategy` — refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The search was refused. It would have supplied published value names for VAL-themed questions; no values cheat sheet is built, since no values-style round is detected |
| 2. `Northwind Data interview process, strategy and GTM roles` | skipped | Your words establish the loop: one 60-minute conversation with Dan, a peer. That fixes the persona weights, so no archetype fallback is used |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note already supplies the three priorities and the bundling threat, which feed C1, C2 and R4 |
| 4. `Dan Kovac Northwind Data` | unavailable | The search was refused. The interviewer read rests on your profile summary only; talks and writing were not checked |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## 15. Upgrade menu

- Full JD text → every requirement beyond the six highlights gets a quoted row and a question, and any location, schedule or pay term becomes a gate row
- Priya's CV lines, verbatim → the evidence column becomes quote-level, and any further metric gets its own defend-the-number question
- Her own answers to the slots in F1, F2, F4 and F5 → those rows can move from slot to story, and the matching bank rows regenerate
- Recruiter or HR guidance (focus areas, announced deliverables, who else joins) → coverage tuned to the stated focus, and a build section for any announced deliverable
- Northwind's published values page → VAL-themed questions, and a cheat sheet if a values round is documented
- Prep time available → a prioritized prep triage sized to it
- Search permission → the interviewer's public footprint, loop reports and values; a deeper research pass would add up to 6 more searches and 2 more fetches and take several more minutes
- A `tuesday-dossier.md` from an earlier fit review → verified evidence and a ranked list of objections, though none is needed for this pack
