# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not known. Relationship assumed: hiring-manager round, because nothing says otherwise. Round type and relationship are the biggest unknown here; if either changes, the persona weights and banks below get redone.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: every claim about your past rests on a sentence you wrote, quoted in the Provenance column. Where the pack cannot know what you did, the guidance is an answer slot: answer it from your own experience, or say plainly it was not yours or never happened. Both are good answers.

Type key:

| Tag | Name | What it is scoring |
|---|---|---|
| VAL | Behavioral / values | Whether past behavior shows the values an employer publishes (none are researched here, so VAL questions are generic) |
| EXP | Work-experience deep-dive | Whether your CV claims survive scrutiny and you can say what was actually yours |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth (no CO bank in this pack, see the upgrade menu) |
| CASE | Live problem | Structure and reasoning on a problem from the role |

Question IDs run by persona. There is no bank F, because F1 to F6 are the fit rows.

## Prep triage

You have about a week. In order, each tied to an ID:

1. Rehearse B1 and B3 until they are boring. B1 is the highest-ROI prep in this pack.
2. Rehearse C1 and D2 on the 40% figure, out loud, including what you do not know about how it was counted.
3. Talk through A1 to A5 aloud once each, structure first, without notes.
4. Time your E1 arc to 90 seconds.
5. Everything else is insurance.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is your own words from your message. I did not have your CV, only your summary.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "ran the site's peak-season surge plan two years running" — your message; "7 years in warehouse and distribution ops" — your message | medium | [grounded] | transferability | Your material says a site's surge plan and warehouse and distribution ops, not terminals and not four sites, with nothing inspected behind it, so the words stay there: "ran the site's peak-season surge plan two years running". Answer slot: the JD's 4-sites line makes a probe on scope likely. If any part of the surge plan was yours to set, say which and how you decided, in your own words; if there was no such part, or it was not yours, say so plainly and describe how you ran the plan |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | A mis-pick rate is not on-time performance or cost-per-shipment, and the bridge should not be stretched; the words stay at "cut mis-pick rate 40% by redesigning the pick path". Answer slot: the JD's on-time and cost line makes a probe on your numbers likely. Say what the 40% was measured against and which part of the redesign was yours, in your own words; if you do not know how it was counted, say so plainly |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material shows three supervisors, not twelve, and not across sites, with nothing inspected behind it; the words stay at "currently a senior shift manager over 3 supervisors". Answer slot: the JD's twelve makes a probe on span likely. Say how you lead the supervisors you have, in your own words; if the probe is about a larger team, say plainly the size you have led |
| F4a | "build reporting in Excel/Power BI" — JD (the Excel half) | "solid Excel, never used Power BI" — your message | low | [inferred] | discovery | "Solid" says a skill level, not that you built reporting, so this row is thin. Answer slot: say what you do in Excel and for whom, in your own words, and where you would need help; if reporting was not part of it, say so plainly and say what you would build first |
| F4b | "build reporting in Excel/Power BI" — JD (the Power BI half) | "solid Excel, never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never used Power BI." Then how you would learn it, said as a plan and never as a past. The JD's slash does not say whether Power BI is required or an alternative to Excel; reverse question 3 asks. Nothing added to make the gap feel smaller |
| F5 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Seven years in ops is not seven years of leadership, and your material does not show when you first led people. The reading that claims less is the one to hold: "7 years in warehouse and distribution ops". Answer slot: say when you first led a team of any size and for how long, in your own words; if the leadership years are fewer than the ops years, give the number that is true and let the interviewer weigh it |
| F6 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap in role-relevant terms: lead with "green belt certified". The quote names a certification, not who issued it or a project, so expect a probe. Answer slot: if a project was run under the certification, say what it was and your part in it; if none was, say so plainly and stay with the certification |

## Persona table

No source here documents Atlas's loop, so the weights rest on the hiring-manager prior and a generic archetype (screen, then hiring manager, then panel), not on this company's process. Change the relationship and the weights move.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live ops problems: diagnose a slipping site, plan a surge, build a scorecard | High. A hiring manager is buying capability, and the JD is built on daily operations, on-time, cost and reporting; F1 and F2 are where a live problem has the most to test | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully per case |
| B. Skeptic | Quiet probing of the jump from three supervisors to twelve, the leadership years, Power BI | High. The hiring-manager prior is Skeptic, and F3, F4b and F5 are the biggest gaps in the snapshot | Rehearse the most predictable objection until it is boring; stay inside what your quotes carry; give a concrete ramp plan as a plan |
| C. Data-Driven Prober | Reads the numbers line by line | Medium. The 40% figure on its own invites it, and the JD names two metrics | Know what you can and cannot say about how the figure was counted; say plainly when you do not know; name the weakest assumption before they do |
| D. Pressure | Time-boxed, devil's advocate | Low to medium. More likely in a skip-level round, but the 7 versus 5+ years and 3 versus 12 gaps give it material | Pause, restate, anchor in what you said, hold through two follow-ups before conceding anything real |
| E. Conversational | Friendly biography and tools questions that are still scored | Low. Common at the start of any round, and the JD flags a plus that can arrive casually | A 90-second arc built from your own sentences; treat casual questions about Lean or Six Sigma as scored |
| G. Values / Behavioral | Scenario probes | Low. No loop or values source was available, so a dedicated values round is not assumed | Stories with a named stake and an intact relationship; where none comes to mind, say so plainly |
| H. Peer Evaluator | Seams between sites, disagreement, credit | Low. Relevant if a site lead or peer sits in the loop | Reciprocity framing; propose seam principles rather than pretending to know the seam |

## Question banks

### A. Case / Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On-time performance is slipping at one of your four terminals and holding at the other three. How do you diagnose it?" | CASE | [generic] | Clarify first: how on-time is defined and measured, since when, and what changed. Then split the problem (inbound, dock, loading, linehaul, customers), choose the few numbers that would separate the causes, and say what you would do in week one versus later. The question needs no claim about your past, so the guidance makes none | Live problem from the JD's on-time line (F2's requirement). CASE because it scores structure, not recall; generic because it is a pattern for the problem, not a fact about Atlas |
| A2 | "Leadership wants cost-per-shipment down across the four terminals without hurting on-time. Where do you start?" | CASE | [generic] | Clarify what is in the cost, the baseline and the time frame; list the levers you would test (labour, handling, dock time, damage, rework) and which could hurt on-time; name the measure that would tell you a saving was real. Say your assumptions aloud and challenge one premise respectfully | Drawn from the JD's cost-per-shipment line (F2's requirement); the trade-off with on-time is where a strategist is scored |
| A3 | "Volume jumps with two weeks' notice at one terminal while the other three are flat. How do you decide what to do?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure first: what you need to know, the options (move labour, add shifts, overtime, push back with customers), and what each risks. If you draw on your own experience, the words stay at "ran the site's peak-season surge plan two years running". Answer slot: if any part of that plan was yours to set, say which and how you decided, in your own words; if there was no such part, or it was not yours, say so plainly and show how you would test the approach across several sites | F1 holds your nearest evidence to daily operations; CASE because the interviewer wants the reasoning across four sites more than the story |
| A4 | "You start Monday with twelve supervisors you have not met across four sites. What do your first thirty days look like?" | CASE | [generic] | Say your order of operations as a plan: listen and walk the floor, learn the numbers and how each site reports them, meet each supervisor, agree what you will change and what you will leave alone. Do not promise results in thirty days. The question needs no claim about your past, so the guidance makes none | Targets the JD's team-of-12 line (F3's requirement) as a plan rather than a record, so it is a safe place to show structure |
| A5 | "What goes on the one-page daily scorecard for four terminals?" | JD | [grounded] "solid Excel, never used Power BI" | Choose few measures, tie each to on-time or cost-per-shipment, say who reads it and what decision it drives, and say how often it refreshes. On tools, the words stay at "solid Excel, never used Power BI": a first version in Excel is a plan you can state, and a plain "I have never used Power BI" is the sourced acknowledgment, followed by how you would learn it. Answer slot: if you have made reports others used, say what and for whom; if not, say so plainly | F4a and F4b. JD because it scores the reporting requirement; CASE delivery because the answer is a design, not a story |

### B. Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You manage three supervisors today and this role has twelve across four sites. What would you be weakest at on day one?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack: this question will come in some form, and a calm answer changes the interview. Hold only what the quote carries: "currently a senior shift manager over 3 supervisors". Answer slot: say how you lead the supervisors you have, in your own words; if the probe is about a larger team, say plainly the size you have led. Then give your ramp as a plan: the first two things you would do in your first month, in your own words. Hold through two follow-ups by returning to the quote, never by adding to it | F3 is the biggest scale gap in the snapshot, and F1 compounds it; JD because it scores the stated requirement |
| B2 | "The role asks for 5+ years of operations leadership. How many of your seven years in warehouse and distribution ops were spent leading people?" | JD | [grounded] "7 years in warehouse and distribution ops" | Answer with the true number. Answer slot: say when you first led a team of any size and for how long, in your own words; if the leadership years are fewer than the ops years, give the number that is true, then return to "7 years in warehouse and distribution ops" and what that ops depth lets you do. Never let the seven years stand in for leadership years | F5 is the requirement a screener can check literally, and the material does not settle it; JD because it scores the headline requirement |
| B3 | "You have never used Power BI, and this job builds reporting in it. How do you close that?" | JD | [grounded] "solid Excel, never used Power BI" | Acknowledge, then plan. The sourced words: "I have never used Power BI." Then, in your own words, what you would do first to learn it and how you would keep reporting running in Excel meanwhile. The quote says "solid Excel" and nothing else about it, so say no more than that. If it helps, ask whether Power BI is needed on day one (reverse question 3) | F4b is a gap you have stated, so the honest, rehearsed answer is the strongest one available; F4a supplies the Excel half |
| B4 | "Why leave a senior shift manager role for this one, and why now?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors" | The reason is yours and the pack supplies none: give your actual reason in your own words, in two or three sentences, forward-looking and consistent with what you tell the recruiter. Keep the role description at "currently a senior shift manager over 3 supervisors" | A motivation probe is standard for the Skeptic; EXP because it tests the consistency of your own story (F3 is the role you are leaving) |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the result in the quote's own words: "cut mis-pick rate 40% by redesigning the pick path". Answer slot: say how the 40% was counted, what it is sensitive to, which assumption behind it you would defend least, and what part of the pick-path redesign was yours, each in your own words; where you do not know how it was counted, say so plainly. Name the weakest assumption before they do | F2 holds your only headline metric, so a defend-the-number question is the one a prober will certainly ask; EXP because it tests attribution |
| C2 | "Tell me about a time you changed a process on the floor and the supervisors had to work differently afterwards." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Story-mapped on F2 with only the beats the quote states: the redesign and the 40%. Answer slot: the JD's supervisor line makes a probe on adoption likely. If supervisors had to change how they worked, say what you did and how it went, in your own words; if they did not, or it was not yours to lead, say so plainly and stay with the redesign | The prompt's theme comes from the JD's supervisor line (F3's requirement); the quote carries no adoption story, so the rest is a slot |
| C3 | "The JD talks about on-time performance and cost-per-shipment. Which numbers do you work with day to day?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: say which numbers you work with at your site and what you do with them, in your own words; if neither of those two is among them, say so plainly, then return to "cut mis-pick rate 40% by redesigning the pick path" and say what you would add to your own scorecard | F2: the JD's two measures are not in your quotes, so this is a discovery probe; JD because it scores the headline requirement |

### D. Pressure (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who already runs several terminals?" | JD | [grounded] "7 years in warehouse and distribution ops"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause, restate the question, then hold on what the quotes carry: "7 years in warehouse and distribution ops", "ran the site's peak-season surge plan two years running", "green belt certified". Hold through two follow-ups. Concede explicitly and specifically what you have not run, in your own words; the pack supplies no wording for it. Never fold on the core claim just to restore harmony | F1 and F3 are the likeliest places a stress interviewer leans; JD because it scores the stated requirement under time pressure |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Anchor in the quote: "cut mis-pick rate 40% by redesigning the pick path". Answer slot: say which part of the redesign was yours and who else took part, in your own words; if it was shared, say so plainly and stay with your part. Hold through two follow-ups by returning to the quote; never widen it and never shrink it below what is true | F2's one metric is the natural target for an attribution probe; EXP because it scores honesty about contribution |

### E. Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | A 90-second arc with three beats: "7 years in warehouse and distribution ops", then "currently a senior shift manager over 3 supervisors", then why this role, which is your own reason in your own words. Keep each beat at the quote's scope | F5 and F3 are the facts an opener sets up; EXP because it is the biography question, however casually asked |
| E2 | "What are you actually playing with in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Start from "green belt certified". Answer slot: if you are using the method now, say how, in your own words; if not, say so plainly and stay with the certification. Treat it as scored, because the JD names it as a plus | F6; JD because the JD lists the requirement, asked in a casual register |

### G. Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and an intact relationship afterwards, where the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; generic because no values page was available, so no company value is being mapped |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with the customer named by type, the metric you set aside, and what it cost; with "we" for context and "I" for your own contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem that fits an on-time role; generic for the same reason as G1 |

### H. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "If two terminals both need the same resource on the same day, how do we settle it?" | CASE | [generic] | Propose principles rather than pretending to know the seam: what is on the line at each site, who decides, what gets recorded, how the loser is told why. Reciprocity: say what you would bring the other sites. The question needs no claim about your past, so the guidance makes none | A live seam problem from the JD's four-site line (F1's requirement); CASE because it asks for reasoning, not recall |
| H2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Scaffold: "we" for context, "I" for contribution, and name what the other team did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; generic because your quotes carry no cross-team story |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A3, A4, B1, D1, H1 |
| "drive on-time performance and cost-per-shipment down" | A1, A2, C3 |
| "lead a team of 12 supervisors" | A4, B1, C2 |
| "build reporting in Excel/Power BI" | A5, B3 |
| "5+ years operations leadership required" | B2, E1 |
| "Lean/Six Sigma a plus" | E2, D1 |
| "regional logistics, 800 employees" (context, not a requirement) | — none, and why: it states the employer, not a requirement to answer |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How does the company define on-time performance, measured at which point and for which customers, and where is it versus where leadership wants it?" | Shows you would define the target before fixing it, and it tells you what the job is really scored on |
| 2 | "Of the four sites, which would you want me to understand first, and why?" | Shows a plan to learn before acting, and surfaces the hardest site early |
| 3 | "How do the sites report today, and is Power BI expected on day one or is it something the role builds toward?" | Turns your one stated gap into a plan conversation instead of waiting for the probe |
| 4 | "How are the twelve supervisors spread across the four sites, and what is the biggest difference between the strongest and weakest team?" | Moves the span-of-control concern into their reality and shows you think about people first |
| 5 | "What has already been tried on cost-per-shipment, and what did you learn from it?" | Signals you will build on prior work rather than restart it |
| 6 | "What would make you say, at ninety days, that this hire went well, and what would make you say it went wrong?" | Gets the real scorecard, and rapport-style interviewers weigh this slot as a preparation signal |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned daily terminal operations across several sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says a site's surge plan, not terminals or four sites. A3's slot stays inside the surge plan |
| Drove on-time performance or cost-per-shipment down | Inflated form of F2 | F2's quote at its own scope. The material says the mis-pick rate, not on-time or cost. C1 and D2 stay inside the redesign |
| Led twelve supervisors, or a team of that size | Inflated form of F3 | F3's quote at its own scope. The material says three supervisors. B1's slot asks only for the size you have led |
| Built reporting in Excel | Inflated form of F4a | "solid Excel" at its own scope; the material does not say reporting was built. A5's slot asks only what you do in Excel |
| Has used Power BI | Negative you stated, F4b | The plain acknowledgment F4b gives: "I have never used Power BI." No slot |
| Has 5+ years of operations leadership | Inflated form of F5 | F5's quote at its own scope. The material says seven years in ops, not seven years of leadership. B2's slot asks only when you first led a team |

## Sources

Provided documents: the JD text and your background summary, both from your message. No tuesday-dossier.md was present.

Searches sent, all refused for lack of search permission, so nothing about Atlas Freight was read or used:

- `Atlas Freight regional logistics company values` — refused
- `Atlas Freight interview process operations manager` — refused
- `Atlas Freight regional logistics strategy news 2026` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Search was refused. It would have fed a values cheat sheet and mapped VAL stories; G1 and G2 are generic instead |
| 2. `Atlas Freight interview process operations manager` | unavailable | Search was refused. It would have named the loop's rounds; persona weights rest on the hiring-manager prior and a generic archetype instead |
| 3. `Atlas Freight strategy` / recent news | unavailable | Search was refused. It would have fed a CO bank grounded in current priorities; the pack has no CO questions |
| 4. `interviewer name Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and the interviewer's name and title → persona weights re-set from their role and public footprint, plus a reverse question tied to their own path
- Search permission, or Atlas's values page, interview process and a recent strategy note pasted in → a values cheat sheet, loop-based persona weights and a CO question; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief and recent organisation context, offered once
- Your answers to the answer slots on F1, F2, F3, F4a, F5 and F6 → those rows become grounded stories, with real beats in place of slots
- Your CV → the fit snapshot's evidence cells quote it directly, and any line your summary left out becomes usable
- The recruiter's guidance (focus areas, any presentation or take-home) → coverage for pre-declared deliverables; usually one email to the recruiter
- A tuesday-dossier.md from an earlier check on this role → verified evidence, a named highest-ROI objection and a prohibited-claims list in place of the ones built here
