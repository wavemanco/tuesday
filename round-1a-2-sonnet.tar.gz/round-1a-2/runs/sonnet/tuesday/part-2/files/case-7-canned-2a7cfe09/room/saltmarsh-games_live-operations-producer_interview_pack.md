# Interview pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship: hiring manager, assumed from the loop Saltmarsh publishes (Sources, query 2). Candidate: Femi. Format: one 60-minute session.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Every question carries one persona (its bank), one type, a Provenance cell and answer guidance.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your CV claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you know the company and its current moves |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script. An answer slot is an instruction for the interview, not a question for you: answer whichever branch is true, in your own words. The one thing to rehearse first is B1.

## Fit snapshot

Requirements are the JD's own lines. F8 is not a JD line: it is context from Saltmarsh's own news. Your evidence is quoted from your message and nothing else is used about your past.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one title, with nothing inspected behind it, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's live-events line makes a probe on what a drop held likely. If a drop was built around something time-limited, say what it was and what you did; if none were, say so plainly and stay with the weekly drops |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | none | [grounded] | discovery | Your material does not show which of these four teams you worked with. Answer slot: the JD names all four, so expect a probe on each. Say which you worked with and what you did with each, in your own words; if you did not work with one, say so plainly and stay with the ones you did |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says monthly retention numbers presented upward, not a review of an event. The words: "I presented the monthly retention numbers to the studio head." Answer slot: if those numbers were part of looking back on content drops, say how; if they were not, say so plainly and stay with presenting them |
| F4 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you presented the monthly retention numbers to the studio head, because a named audience beats an adjective |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | Your material says you wrote it and QA still uses it, not that you ran releases through it. The words: "I wrote the release checklist our QA team still uses." Answer slot: if you also kept it current or worked each release through it with QA, say how, in your own words; if you did not, say so plainly and stay with the checklist you wrote |
| F6 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | Your material gives the years and the title, and does not say how the studio's updates were run. Answer slot: the JD says live-service, so expect a probe on what your four years covered. Say what the updates looked like, in your own words; if the title was not run as a live service, say so plainly and stay with the calendar you ran |
| F7 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [grounded] | discovery | A written document exists, and the material does not show how clear it was to its readers. Answer slot: expect a request to write something live. If other writing of yours was relied on, name it, in your own words; if the checklist is the writing you can point to, say so plainly |
| F8 | "season-pass model" — Saltmarsh news, September 2026, search result | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then what you would learn first, said as a plan and never as a past. Never a claim to monetisation work, and nothing added to make the gap feel smaller |

## Persona table

The loop is documented (Sources, query 2): one session with the hiring manager, a live-incident tabletop, then a values conversation. Weights start from the hiring-manager prior, then follow the documented loop.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | The tabletop outage, then calendar and metric problems | Highest. Hiring-manager prior, and the published loop names a tabletop | Clarify, objective, segmentation, approach, metrics, risks. Think aloud, in the conditional, because a case asks about no past |
| Skeptic (bank B) | Probing the gaps: the season pass, never having led, the post-event review | High. Hiring-manager prior, and F8, F2 and F3 are the thinnest rows | Rehearse B1 until it is boring. Bridge only from your own quotes and say the limit plainly |
| Values / Behavioral (bank C) | The values conversation, one value at a time | Medium, and certain to happen somewhere in this session because the loop documents it. Three questions, one per published value | Map a story to a value where a quoted sentence carries one; otherwise use the scaffold and its honest branch |
| Data-Driven Prober (bank D) | Retention numbers probed to their assumptions | Low to medium. Nothing public about the interviewer says data-driven | Know what you can and cannot say about how the numbers were counted, and say plainly when you do not know |
| Pressure (bank E) | Sixty-second challenges and attribution | Low to medium. No source describes a stress style, so two questions | Pause, restate, anchor in what you stated, hold through two follow-ups, then concede specifically |
| Conversational (bank G) | The opener and the motivation question | Low, but the opener is always scored | Script the 90-second arc from your own sentences |
| Peer Evaluator | Not used | Dropped: the interviewer is the hiring manager, not a peer | Not applicable |

## Reading the interviewer

Public professional footprint only. Both facts below come from one search result, not an opened page.

| Fact or implication | Provenance |
|---|---|
| Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio | [grounded] GDC 2026 talk listing, Sources query 4 |
| His GDC 2026 talk was "Patch Notes Are a Promise": a live team is judged by how often its patch notes describe what actually shipped | [grounded] same listing |
| Implication: how you word an announcement may be scored as closely as what you decide. Say what is built and known, and leave out hoped-for dates (A1, A5, C2) | [inferred] from the talk's stated argument |
| Implication: the release checklist is ground a former QA lead knows well, so expect follow-ups on it (A2, E2) | [inferred] from his QA background |
| Mirror opportunity, professional path only: his QA years and F5's sentence, "Wrote the release checklist our QA team still uses". Offer the sentence as what you did, and ask how his QA years shaped his view of a checklist (R1). Do not claim a shared experience | [inferred] pairing of his public path with F5 |

## Question banks

### Bank A: Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Mid-event, players report the event rewards are not showing and community is already fielding tickets. You are the producer on call. What do you do in the first fifteen minutes?" | CASE | [grounded] | Clarify first: what is broken, who is affected, since when, how much of the event is left. Name what you would ask of each of design, art, engineering, community and QA. Decide what players are told: only what is known, never a hoped-for fix time. Name what you would watch afterwards. Speak in the conditional; the question asks for no past, so the guidance makes none | The documented tabletop is a live outage during an event, so this is its most direct rehearsal. It carries Saltmarsh's published value that announcements state what is built (Sources, query 1); CASE because it scores structure, not history |
| A2 | "Engineering has a hotfix. QA says the release checklist cannot finish before the event ends. Who decides what happens, and how?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Clarify which checklist steps protect players and which are about completeness, and who holds the call. Lay out the options and name the owner of the risk each one carries. If you refer to your own checklist, keep to the quote: "I wrote the release checklist our QA team still uses." Beyond that, speak in the conditional | F5's requirement set as a live problem. JD content, CASE delivery, because it scores the checklist-with-QA line |
| A3 | "From February 2027 two titles will share one events calendar. Sketch how you would build it. What do you need to know first?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Clarify what is shared (dates, rewards, comms), who resolves a clash, how much the two audiences overlap, and where a season pass sits. Challenge one premise respectfully, such as whether both titles want one cadence. Anchor on what you ran in the quote's own terms: "For the last two years I ran the weekly content-drop calendar for our main title." Name the step up to two titles as the first thing you would clarify, not as something you have done | F1 is the requirement and the step up from it is the limit. JD content, CASE delivery, with strategy grounding from Saltmarsh's published plan (Sources, query 3) |
| A4 | "Day-three retention dropped 20% after an event. Diagnose it." | CASE | [generic] | Clarify which players, which platform and compared to what. Segment: new against returning, event participants against non-participants, by build. Order your hypotheses by how cheap each is to check, say what you would check first, and say which assumption you would defend least. The question asks for no past, so the guidance makes none | F3 and F4 as a live problem, in the persona's standard diagnosis shape. CASE because it scores reasoning, not recall |
| A5 | "An event is delayed by a build fault. Write the two sentences players will read, then tell me what you left out and why." | JD | [grounded] | Lead with the fact. Say what is known and what you are doing. Promise a next update only if you can commit to its time. Leave out guesses and blame, and say that is why. Saltmarsh's published wording is that it announces what is built, not what is hoped (Sources, query 1). Say the sentences aloud; no past is claimed | F7's requirement as a live task. JD content, CASE delivery, because written clarity is easiest to score by asking for writing |

### Bank B: Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Saltmarsh is moving its two titles to a season pass, and you have never worked on a game with in-app purchases. How do you handle that?" | CO | [grounded] "never worked on a game with in-app purchases"; "Presented the monthly retention numbers to the studio head" | The highest-ROI rehearsal in this pack. Name the limit before it is asked for: "I haven't worked on a game with in-app purchases." Then say only what your quote carries: "I presented the monthly retention numbers to the studio head." Follow-up one, "that is a big gap": hold by returning to those two sentences and concede nothing further. Follow-up two, "retention is not the whole picture, why trust you": concede the specific limit, the in-app purchases, and return to the quote. Follow-up three, "what do you do in your first month": give a plan, never a past. Name two or three concrete things you would ask or read, and who you would sit with, in your own words. If you do not know how a season pass works in practice, say that and say what you would ask | F8 is the biggest gap and the question is born from Saltmarsh's own news, so it will arrive in some form. CO because it tests knowledge of the company's current move, Skeptic in delivery |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] | Selection scaffold: choose the requirement where your own material is thinnest. The pack observes that F2, F3 and F7 have the least behind them. Say which you would pick and what you would do about it in your first weeks, as a plan. If none comes to mind, say so plainly, then name the one you would most want a colleague's help on | The persona's standard probe, and F2, F3 and F7 are where an honest answer lands. JD because it scores the listed requirements |
| B3 | "You have never led a team, and this role coordinates design, art, engineering and community on every update. What makes you the right person to run that?" | JD | [grounded] "Never led a team"; "I ran the weekly content-drop calendar for our main title for the last two years" | Name the limit plainly: "I haven't led a team." Then stay with the quote: "For the last two years I ran the weekly content-drop calendar for our main title." The JD's word is coordinate. Answer slot: the JD names four teams, so expect a probe on which you worked with on the drops. Say which and what you did with each, in your own words; if you did not work with one, or the calendar ran without them, say so plainly and stay with the calendar you ran | F2's thin row against the JD's four named teams, so the premise is the JD's and your own stated limit. JD because it scores the coordination line |
| B4 | "Walk me through how you review an event after it ends, and which KPIs you report." | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Start from the quote: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's post-event review line makes a probe on whether you wrote reviews likely. If those monthly numbers were part of looking back on content drops, say how, in your own words; if they were not, say so plainly and stay with presenting them to the studio head | F3's requirement is the JD's, and the quote is adjacent to it. JD because it scores the review-and-KPIs line |

### Bank C: Values / Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the calendar and the players disagreed. Which won?" | VAL | [grounded] | Selection scaffold, for Players Before Plans: the story needs a named date or promise, a moment someone had to choose, and how the players were told. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide | Theme taken from the published value (Sources, query 1). No quoted sentence carries a story here, so it is a scaffold, as the values sheet shows |
| C2 | "Tell me about a time you held back or corrected what players were told." | VAL | [grounded] | Selection scaffold, for Ship the Patch Not the Promise: name what was announced, what was known when it was, who decided, and what players saw afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Theme taken from the published value, and the interviewer's public talk argues the same point (Section: Reading the interviewer). A scaffold because no quote carries a story |
| C3 | "Tell me about a time a release taught you something that changed how the team works." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F5, for Leave the Build Greener: you wrote the checklist, and QA still uses it, which are the beats the quote states. Tell them in your own words. Answer slot: the value's wording about leaving the checklist better makes a probe on what changed it likely. If a release problem prompted a change to it, say what and what changed; if the checklist was written for another reason, or no release prompted a change, say so plainly and stay with the checklist as you wrote it | F5 is the one row that a quoted sentence ties to a published value. VAL because it scores the demonstrated value, not the answer's polish |

### Bank D: Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about the monthly retention numbers you presented. What was in them?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Story-mapped on F4: the numbers were monthly and went to the studio head, which are the beats the quote states. Answer slot: the JD's retention line makes a probe on how the numbers were counted likely. Say which retention measures were in them and how each was counted, in your own words, if you know. If you do not know how one was counted, or someone else counted them, say so plainly and stay with presenting them to the studio head | F4 is the requirement and the likeliest place to be probed on assumptions. JD because it scores comfort with retention metrics |
| D2 | "Which retention measure would you trust least when judging an event, and why?" | JD | [generic] | The weakest-assumption move. Name, in your own words, the measure or assumption you would defend least, before the interviewer does. If you do not know how a measure is counted, say so plainly. The question asks for an opinion, so the guidance supplies none | F3 and F4 together, in the persona's standard assumption probe. JD because it scores the retention line and the review line |

### Bank E: Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already run a monetised live-ops calendar?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head"; "never worked on a game with in-app purchases" | Pause, restate, then hold only what the quotes carry: "For the last two years I ran the weekly content-drop calendar for our main title. I wrote the release checklist our QA team still uses. I presented the monthly retention numbers to the studio head." Hold through two follow-ups by returning to those sentences. Then concede the one specific limit: "I haven't worked on a game with in-app purchases." Do not add a strength your quotes do not carry | F1, F4, F5, F6 and F8 in sixty seconds, which is where this persona presses. JD because it scores fit against the listed job |
| E2 | "The release checklist your QA team still uses: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold on the quote: "I wrote the release checklist our QA team still uses." Hold through two follow-ups by returning to it, never by adding to it. Answer slot: if others shaped it, say who and what they added, in your own words; if you wrote it alone, say so plainly | F5 is where an attribution probe lands hardest, and the interviewer's public QA background makes it likelier. EXP because it scores what was actually the candidate's |

### Bank G: Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc in this order, each beat a clause one of the quotes states: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for the main title, for the last two years; the release checklist QA still uses; the monthly retention numbers presented to the studio head. Then why this role: say your actual reason, in your own words; if it is not tied to this posting, say so plainly and tie it only to what is true | F6 and the strongest quotes from F1, F4 and F5 are the whole arc. EXP because it is the CV told aloud |
| G2 | "Why Saltmarsh, and why now?" | CO | [grounded] | Selection scaffold: Saltmarsh publishes three values and a plan for one live-ops group (Sources, queries 1 and 3). Use only what is true for you. If a value genuinely lands, name it and say why, in your own words; if none does, say so plainly and give your actual reason | The persona's motivation probe. CO because it scores homework, built only from what Saltmarsh published |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A3, B2, E1 |
| "coordinate design, art, engineering and community teams on each update" | A1, B2, B3 |
| "own the post-event review and the KPIs it reports" | A4, B4, D2 |
| "manage the release checklist with QA" | A2, C3, E2 |
| "3+ years producing live-service games or apps" | B2, E1, G1 |
| "comfortable with player-retention metrics" | A4, D1, D2 |
| "clear written communication" | A5 |
| Context, not a JD line: the season pass | A3, B1, G2 |

## Values cheat sheet

Detected because the published loop names a values conversation (Sources, query 2). Names are Saltmarsh's own, from its values page.

| Value (official name) | Working meaning, paraphrased | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold (C1): a named date or promise, a moment someone chose, how players were told. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold (C2): what was announced, what was known, who decided, what players saw. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F5: "Wrote the release checklist our QA team still uses". The answer slot in C3 holds the rest |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came to live operations from a QA lead role. What did QA teach you about running a live calendar that you would want a producer here to already have?" | Ties to his own public path, and it opens the checklist ground F5 touches |
| R2 | "Your GDC talk argued a live team is judged by whether patch notes describe what shipped. How does the team check that today?" | Shows you read his talk, and asks about the standard he set |
| R3 | "Project Larkspur retires per-title event teams for one live-ops group. Where does this role sit in it, and who decides when two titles want the same weekend?" | Shows you read the plan, and surfaces the calendar-ownership question you will actually face |
| R4 | "The season pass arrives in February 2027. What would the producer own: the calendar around it, the numbers on it, or both?" | Turns F8's gap into a scoping question you genuinely need answered |
| R5 | "Which of design, art, engineering and community would I work with most on a typical update, and where do they disagree most?" | Takes the JD's four named teams (F2) and asks for the real friction |
| R6 | "What would you want to have seen from this role after its first ninety days?" | Gives you a concrete bar to measure the offer against |

## Prohibited claims

Built before the banks. None of these is coached, in any answer, slot, hold or bridge.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated, F2 | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases | Negative you stated, F8 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Ran a live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a weekly content-drop calendar for one title. B1 stays inside the quote |
| Owned post-event reviews and the KPIs they report | Inflated form of F3 | F3's quote at its own scope. The material says monthly retention numbers presented to the studio head. B4's slot stays inside that |
| Managed the release process with QA | Inflated form of F5 | F5's quote at its own scope. The material says you wrote the checklist and QA still uses it. E2 and C3 stay inside that |

## Sources

Provided documents: the JD text and your background summary, both in your message. No tuesday-dossier.md was present.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Query or fetch | What came back |
|---|---|
| Search: Saltmarsh Games values | https://saltmarshgames.com/values |
| Search: Saltmarsh Games interview process live operations producer | https://saltmarshgames.com/careers/interviewing |
| Search: Saltmarsh Games strategy mobile titles news | https://saltmarshgames.com/news/project-larkspur (search snippet only, page not opened) |
| Search: Tobias Wrenfield Saltmarsh Games | https://talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet only, page not opened) |
| Fetch: https://saltmarshgames.com/values | Page text: the three values and their one-line definitions |
| Fetch: https://saltmarshgames.com/careers/interviewing | Page text: the loop is a recruiter call, then one 60-minute interview with the hiring manager, a live-incident tabletop and then a values conversation, with no take-home |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | The values cheat sheet, the C bank and G2 |
| 2. Saltmarsh Games interview process, live-ops producer | yes | Loop structure: persona weights, the A and C banks, the values sheet and the assumption that Tobias is the hiring manager |
| 3. Saltmarsh Games strategy and recent news | yes | A3, B1, G2, R3 and R4, and the F8 context row |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | The interviewer read, R1 and R2, and the implications for A1, A2, A5, C2 and E2 |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- A recruiter note on anything announced about the session, or confirmation that Tobias is the person you would report to → persona weights and the interviewer read firm up from assumed to confirmed
- Your own answers to the answer slots in F1, F2, F3, F5, F6, F7, B3, B4, C3, D1 and E2 → those rows become story-mapped, `[grounded]` stories instead of slots
- A CV or the original wording of your lines → more quotable sentences, and a possible lift in confidence for rows resting on one line
- Opening the Project Larkspur and GDC talk pages, plus a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on the season pass and the shared calendar, and the talk's recurring themes as likely questions; this is the one offer of that pass
- A tuesday-dossier.md from earlier work on this role → a named top objection and a ready-made prohibited-claims list; never needed
- How much time you have to prep → a prioritized schedule of the few things to do first
