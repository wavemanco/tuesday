# Interview pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Built as a hiring-manager round, on one assumption: that Tobias is the hiring manager. Saltmarsh's careers page describes every loop as a recruiter call, then a single 60-minute interview with the hiring manager, which matches your Friday slot. If he is not your hiring manager, the persona weights change.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say only what you actually did, in your own words. An answer slot is an instruction for the interview, not a question for you now. The outage scenarios in bank A are my practice wording, not Saltmarsh's.

| Tag | Name | What it tests |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows Saltmarsh's published values |
| EXP | Work-experience deep-dive | Whether your CV claims survive scrutiny and attribution |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Whether you can think at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a live problem from the role |

## Fit snapshot

No JD requirement is a term you either meet or do not (authorization, location, pay), so there is no gate row. Rows F9 and F10 are limits you raised yourself, not JD requirements.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your sentence says a weekly content-drop calendar for your main title, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." The JD says live-events and two titles; your sentence says content-drop and one title, so the terms are not swapped. Answer slot: the JD's two-title line makes a probe likely on running more than one title's calendar. If you ever did, say how, in your own words; if not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: if coordinating any of those disciplines was part of running the weekly drops, say which and what you did, in your own words; if it was not, or it was someone else's, say so plainly and say how you would start with each |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your sentence says you presented the monthly retention numbers to the studio head, and the words stay there: "I presented the monthly retention numbers to the studio head." It does not say who produced the numbers or that they were tied to events. Answer slot: the JD's post-event review line makes a probe on that likely. If you also produced them or tied them to specific drops, say how; if you presented numbers others produced, or none were tied to drops, say so plainly and stay with the presenting |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap on the checklist itself, but a line with nothing inspected behind it, so expect a probe. Lead with it in the sentence's own terms: "I wrote the release checklist our QA team still uses." The JD's verb is manage and yours is wrote, so keep yours |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | presentation | Say each at its own scope: "I spent 4 years as an associate producer at a puzzle-game studio, and for the last two I ran the weekly content-drop calendar for our main title." Your material sets two years on the calendar against the JD's 3+, so expect that comparison to be tested |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap: you ran it. Lead with the sentence in its own terms |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | Say it as it stands: "I presented the monthly retention numbers to the studio head." Your sentence does not show how the numbers were counted, and "comfortable" is the JD's word, so let question D1 test it rather than claiming it |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A written checklist touches this without showing it; derived from the checklist being written. Answer slot: if there is another written piece you produced that others relied on, say what it was; if there is none beyond the checklist, say so plainly |
| F9 | Work on a game with in-app purchases (not in the JD; raised by you) — your message | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past |
| F10 | Leading a team (not in the JD; raised by you) — your message | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't led a team." The JD's verb is "coordinate", which is a line to quote, not a way around this |

## Persona table

Weights follow three passes: the hiring-manager prior (Case/Strategist and Skeptic), then the loop (the careers page names one session, a live-incident tabletop then a values conversation), then interviewer signals (none verified, so none applied).

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The outage tabletop and the shared-calendar problem | High: the careers page puts a tabletop first in the one session | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Values/Behavioral | The conversation after the tabletop, on the three published values | High: the careers page says the session ends in a values conversation | Where a quoted sentence carries a story, map it; where none does, use the scaffold and its honest branch |
| Skeptic | The in-app purchases and team-leading gaps; one title versus two | Medium: hiring-manager prior, and you named both gaps yourself (F9, F10) | Rehearse C1 until it is boring: plain acknowledgment, a plan, back to what you did |
| Data-Driven Prober | Retention numbers and the post-event review | Medium: the JD asks for retention comfort and KPI ownership; nothing verified says Tobias is data-driven | Say what you know of how each number was counted, and say plainly what you do not |
| Pressure | Time-boxed or interrupting follow-ups inside the tabletop | Low: the careers page does not document it; the live-incident format makes some of it plausible | Pause, restate, hold through two follow-ups, concede only specifics |
| Conversational | The opener, and the reverse-question slot | Low: an opener is likely in any round, but it is not weighted by this loop | A 90-second arc from your own sentences; never answer "I think you've covered everything" |
| Peer Evaluator | Not banked | Low: the one session is with the hiring manager, not a peer; this changes if peers join | Add a bank if you learn peers are in the room |

## Question banks

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We're mid-event and the game is down for players. Tell me what you do in the first fifteen minutes." | CASE | [grounded] | Clarify before acting: what is down, who is affected, since when, what is known versus guessed. Say the objective aloud: players first; Saltmarsh's published line is "when the calendar and the players disagree, the players win". Name which of the JD's four teams (design, art, engineering, community) you would pull in and what you would ask each, who tells players what and when, and keep a running log for the review afterward. Challenge one premise respectfully, such as whether the event should keep running. The question needs no claim about your past, so the guidance makes none | The careers page puts a simulated outage during a live event first in the session, and F2 is the requirement it presses on. CASE because it is a live problem |
| A2 | "The fix is in, but the event lost six hours. Engineering wants to extend it, the calendar has a drop in two days, and community says players are angry. What do you decide?" | CASE | [grounded] | Ask what players lost and what is already promised. Say the principle first: the published value is that the players win when they disagree with the calendar. Lay out the options you see, the trade-off of each, the one you pick and what would change your mind, and who must agree before anything is announced. No claim about your past | A calendar-versus-players conflict is the first published value in a tabletop form, and F1 is the calendar requirement. CASE delivery of VAL content |
| A3 | "Write me the first player-facing message about this. What does it say, and what does it leave out?" | CASE | [grounded] | Say what is known and built now; leave out fixes and dates that are not built, using the published line "we announce what is built, not what is hoped". Keep it short and plain. Say when you will tell players more only if that is in your control. No claim about your past | F8 is the written-communication requirement, tested live; the second published value supplies the bar. CASE with a JD target |
| A4 | "From February 2027 two of our titles share one events calendar. How would you start building it?" | CO | [grounded] | Clarify first: which two titles (the Project Larkspur post names Tidepool Tactics and Lantern Row, so confirm they are the JD's two), which events are already committed, who approves what in a single live-ops group, and what each audience needs. Then objective, which events are shared and which stay per-title, approach, metrics, risks such as collisions between titles. Challenge one premise respectfully: whether one calendar fits both audiences. No claim about your past | Current strategy from a post under six months old, read as a search snippet only, so the details are worth confirming with the recruiter. F1 and F6 are the calendar requirements it presses on |
| A5 | "QA says the fix isn't ready. What has to be true before it ships, and who signs off?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Ask what QA found and how severe it is, what the options are, who owns the call, and what must be checked before shipping. You can point to one real thing: "I wrote the release checklist our QA team still uses." Answer slot: the JD's release-checklist line makes a probe on how you work it with QA likely. If you ran releases against it with QA, say how, in your own words; if you wrote it and others ran it, or it was used differently, say so plainly and stay with the checklist you wrote | F4 is the evidence for the checklist requirement. CASE delivery of JD content |

### B. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and what players needed pulled in different directions." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: pick an occasion when a drop's date and what players needed disagreed; it needs a named stake, what you actually decided, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the weekly content-drop calendar for our main title for the last two years", or how you would handle it, starting from the published line that the players win | First published value, Players Before Plans. F1 is the nearest evidence, and it carries a calendar, not a conflict |
| B2 | "Tell me about a time you told someone something was not ready." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Selection scaffold: pick a time you said no or not yet; it needs the thing that was not ready, who you told, and what happened to the relationship. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I wrote the release checklist our QA team still uses", or how you would handle it, starting from the published line "we announce what is built, not what is hoped" | Second published value, Ship the Patch Not the Promise. F4 is the nearest evidence, and it carries a checklist, not a refusal |
| B3 | "Tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: the checklist you wrote and that QA still uses, which are the beats the sentence states; tell them in your own words. Answer slot: the published value names the checklist, so a probe on whether it improved over releases is likely. If you changed it after a release, say what prompted that and what part was yours; if it was not revised, or the revisions were not yours, say so plainly and stay with the checklist you wrote | Third published value, Leave the Build Greener. F4 is the only row that carries a story for it |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't worked on a game with in-app purchases. How do you expect that to show up in this job?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "I ran the weekly content-drop calendar for our main title for the last two years." | The highest-ROI rehearsal in this pack, with the limit named before it is asked for: no sentence of yours reaches purchases, so none is borrowed. Say plainly: "I haven't worked on a game with in-app purchases." Then give a plan, never a past. Answer slot: say in your own words what you would learn first and who you would ask; the pack supplies neither. First follow-up: return to the plain sentence and your plan. Second follow-up: concede exactly what you do not yet know, without widening or shrinking it. Then return to what you did: "I ran the weekly content-drop calendar for our main title for the last two years." Never stand retention or checklist work in for purchases | F9 is the largest gap you stated yourself, so this objection arrives in some form. JD because it scores fit for the listed job |
| C2 | "You haven't led a team, and this role needs you to coordinate design, art, engineering and community teams on each update. What will be hardest?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Say plainly: "I haven't led a team." The JD's own verb is "coordinate". Answer slot: if coordinating any of those disciplines was part of running the weekly drops, say which and what you did, in your own words; if it was not, or it was someone else's, say so plainly and say how you would start with each. Hold through two follow-ups by returning to what you said | F10 and F2 meet here: the stated gap and the requirement that tests it |
| C3 | "You ran your main title's calendar. We'll have two titles on one shared calendar. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F1: "I ran the weekly content-drop calendar for our main title for the last two years", which are the beats the sentence states. Answer slot: the JD's two-title line makes a probe on a second title likely. If you ever fit another title's content around the first, say how; if not, say so plainly and say what you would ask first | F1's limit, rehearsed so the honest answer is ready. JD because it scores the stated requirement, with CO context from the shared-calendar news |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented: how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you know of how the numbers were counted, what they were sensitive to, which assumption behind them you would defend least, and which part of the work was yours, each in your own words. Name the weakest assumption you know of before the interviewer does. If you do not know how they were counted, say so plainly. Never name a method you cannot repeat under a second question | F7 is the retention evidence, and the number is the likeliest thing to be probed. EXP because it tests attribution |
| D2 | "Did those retention numbers ever change what you scheduled?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." and "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if they did, give one case and say which part was yours; if they did not, or you only presented them, say so plainly and say how you would link them to the calendar | F3 and F7 together: whether the reporting touched the calendar. EXP because it tests what you actually did |
| D3 | "After an event ends, how would you structure the review, and which KPIs would it report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Structure it: what the event was for, what would count as success before it ran, what you would compare against, what you would report and who acts on it. Retention is the one metric the JD names. Anchor in the reporting you did, in those words, not the review itself: "I presented the monthly retention numbers to the studio head." | F3 is the post-event review requirement. JD content with CASE delivery |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should I trust you with two titles after one calendar?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." and "4 years as an associate producer at a puzzle-game studio." and "Never led a team, and never worked on a game with in-app purchases." | Pause and restate the question. Hold on what the quotes carry: "I ran the weekly content-drop calendar for our main title for the last two years" and "4 years as an associate producer at a puzzle-game studio." Hold through two follow-ups by returning to those sentences. When pushed, concede specifics plainly: "I haven't led a team" and "I haven't worked on a game with in-app purchases", then go back to the calendar. Never fold on the core claim to restore harmony | F1 and F5 are the claim under pressure, and F9 and F10 are what pressure reaches for. JD because it scores the requirement |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold on the sentence: "I wrote the release checklist our QA team still uses." Answer slot: if anyone else shaped it, say who and what; if it was yours alone, say so; if you cannot say, say so plainly. Hold through two follow-ups by returning to what you wrote, and concede explicitly any part that was not yours | F4 is the attribution target. EXP because the stem exists to catch inflation |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | A 90-second arc from those four sentences in that order, each at its own scope. Close with an answer slot: say in your own words why this role and why now; if you have not settled it, say what draws you to it and do not borrow a reason from the posting | F5 is the spine of the arc. EXP because it is a CV walk-through in a casual register, which is still scored |
| F2 | "What are you actually looking at in player retention these days?" | JD | [grounded] | Casual, but scored: pick one thing you have really looked at, such as a game's event, a number or a talk, and say what you took from it. If nothing recent comes to mind, say so plainly and say what you would look at first. If you have played either title named in the Project Larkspur post, say what you noticed; if not, do not claim to | F7's requirement asked casually. JD because retention comfort is a stated requirement |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A2, A4, C3 |
| coordinate design, art, engineering and community teams on each update | A1, C2 |
| own the post-event review and the KPIs it reports | D2, D3 |
| manage the release checklist with QA | A5, B3, E2 |
| 3+ years producing live-service games or apps | E1, F1 |
| experience running a content calendar | B1, C3, F1 |
| comfortable with player-retention metrics | D1, D2, D3, F2 |
| clear written communication | A3 |

## Values cheat sheet

A values-style round is detected: the careers page says the session ends in a values conversation. Value names are from saltmarshgames.com/values.

| Value | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the schedule and players' needs collide, players decide | No quoted sentence carries a conflict, so the B1 scaffold applies, ending in its honest branch; nearest row is F1 |
| Ship the Patch Not the Promise | Announce what exists, not what is hoped for | No quoted sentence carries a refusal, so the B2 scaffold applies, ending in its honest branch; nearest row is F4 |
| Leave the Build Greener | Each release should leave the codebase and the checklist better | F4: "Wrote the release checklist our QA team still uses." Beats are what the sentence states; B3 holds the answer slot |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "When the shared calendar starts in February 2027, how does this role fit into the single live-ops group?" | Draws on the Project Larkspur post and asks about the role's real shape, not its title |
| R2 | "In the Outage Hour, what separates a strong tabletop answer from an adequate one?" | Asks for the scoring bar directly, which reads as preparation |
| R3 | "Can you give me an example where the calendar gave way to the players, and who made the call?" | Tests the first published value in practice and shows you took it seriously |
| R4 | "What should a post-event review change about the next event?" | Moves from reporting to decisions, which is the JD's ownership line |
| R5 | "Where does the release checklist work well with QA today, and where does it strain?" | Invites a candid answer on a line the JD names |
| R6 | "What would you want to see from me in the first 90 days?" | A standing closer that keeps the last slot from going to waste |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative the candidate stated, F10 | The plain acknowledgment F10 gives: "I haven't led a team." No slot |
| Has worked on a game with in-app purchases | Negative the candidate stated, F9 | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." Then a plan, never a past |
| Ran live events, as the JD words it | Inflated form of F1 | F1's quote at its own scope: a weekly content-drop calendar. The limit is the pack's observation: your sentence says content-drop, not live-events |
| Ran calendars for more than one title | Inflated form of F1 | F1's quote at its own scope: "our main title". C3's slot stays inside the calendar you ran |
| Owned the post-event review or its KPIs | Inflated form of F3 | F3's quote at its own scope: you presented the monthly retention numbers. The limit is the pack's observation: your sentence says presenting, not owning |
| Produced or analysed the retention numbers | Inflated form of F3 and F7 | The quote at its own scope: "Presented the monthly retention numbers to the studio head." D1's slot asks only how they were counted |
| Managed releases with QA | Inflated form of F4 | F4's quote at its own scope: you wrote the checklist QA still uses. The limit is the pack's observation: your sentence says wrote, not managed |
| 4 years producing live-service games | Inflated form of F5 | F5's quotes at their own scope: 4 years as an associate producer, and two years on the calendar. The limit is the pack's observation: the two are not the same span |

## Sources

Provided documents: the JD and your background, both in your message. No `tuesday-dossier.md` was present.

Searches sent:
- `Saltmarsh Games values` returned https://saltmarshgames.com/values
- `Saltmarsh Games interview process live operations producer` returned https://saltmarshgames.com/careers/interviewing
- `Saltmarsh Games mobile studio strategy news` returned https://saltmarshgames.com/news/project-larkspur (search snippet only; the fetch cap went on the two pages above)
- `Tobias Wrenfield Saltmarsh Games Head of Live Operations` returned https://talks.gdconf.example/2026/patch-notes-are-a-promise (not used: it sits on a reserved example domain, so I could not verify it)

Fetches: https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | The values cheat sheet and bank B, with the three value names from the official page |
| 2. `{company} interview process {role family}` | yes | The loop: one 60-minute session with the hiring manager, a tabletop then a values conversation; persona weights follow it |
| 3. `{company} strategy` / recent news | yes | A4, C3 and R1 draw on the Project Larkspur snippet; the page itself was not read |
| 4. `{interviewer name} {company}` | yes | Not established: the only result was unverifiable, so nothing from it is used and there is no interviewer read |
| 5. representative `{role title}` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV's exact wording for the calendar, checklist and retention lines → the snapshot's evidence cells are your message's sentences today, so a CV could regrade F1 to F8 and add defend-the-number rows if it holds figures
- The release checklist, an export of the content-drop calendar, or one retention deck, if you can share them → F1, F3, F4, F6 and F7 could move from medium toward high
- Your own answers to the slots in F1, F2 and F3 (more than one title, coordinating teams, who produced the retention numbers) → rows A4, C2, C3, D2 and D3 upgrade from slots to story-mapped answers
- Whether Tobias is your hiring manager, and whether anyone else joins → reweights every bank, and adds a Peer Evaluator bank if peers are in the room
- A confirmed profile or talk link for Tobias → an interviewer read, a reverse question tied to his path, and persona adjustments
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → the Project Larkspur page read in full, a grounding brief, and role-family loop reports
- The recruiter's prep email → any stated focus areas for the Outage Hour; the careers page says there is no take-home
- Hours of prep time before Friday → a prioritized prep schedule
- A `tuesday-dossier.md` from an earlier session, if you have one → verified evidence and a sourced prohibited-claims list in place of the one built here
