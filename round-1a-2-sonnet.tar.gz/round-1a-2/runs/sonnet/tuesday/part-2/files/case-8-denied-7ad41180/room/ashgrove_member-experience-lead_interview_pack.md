# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode: three rounds, all on 29 November 2026, in this order.

| Round | Who | Length | What the recruiter said it holds |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Not described beyond the length |
| 2 | The Head of Member Services, who would be your manager | 45 minutes | "mostly behavioural" |
| 3 | A panel of two branch managers | 60 minutes | A 20-minute case on a complaint escalation; the panel "is also the values round" and scores against the four values |

Interviewers beyond their roles are not yet assigned, so there is no interviewer read in this pack. Round IDs below read round, then persona letter, then number: 2B1 is round 2, persona B, question 1.

## How to use this pack

- Personas are how a question arrives; types are what it scores. Type tags: VAL (does past behaviour show the published values), EXP (does a claim on your background survive scrutiny), JD (can you do the listed job, gaps included), CO (do you know the company's strategy and competition), CASE (a live problem, structure over the "right" answer).
- Guidance is scaffolding for a spoken answer, not a script. Every sentence about your past comes from something you wrote to me, quoted next to it. Where your material is silent, the guidance is an answer slot: an instruction for the interview, with an honest branch if the practice was not yours or never existed.
- Highest-ROI prep in the pack: 2B1, the contact-centre objection. It is the one gap you stated yourself and the JD names in its first line, so it will be asked in some form, and 1B2 and 3D1 are its shorter versions.
- All three rounds are on one day, so keep the wording of your concessions identical across them.
- Proposed wording in the tables below is pending your approval, and none of it should be said unless it is true for you.

## Prep triage

Nine days from 20 November (a Friday) to 29 November. Hours per day are not known, so this is ordered rather than timed.

1. Confirm the date with the recruiter first: 29 November 2026 is a Sunday, which is unusual for three rounds with branch managers. Ask for the times, format and location at the same time.
2. Say the concessions in 2B1 and 2B2 aloud until they are boring, a few minutes a day. These are the highest-ROI items.
3. Run the 20-minute case 3B1 aloud with a timer, twice, on different days.
4. Pick real stories for the scaffolds in 3A1 to 3A4, and for 2A1 to 2A4. Where nothing comes to mind, the honest branch in each cell is the answer.
5. Settle your own answers to pay, notice and location (1A3 to 1A5) before the recruiter call.
6. Prepare your walk-through of the spreadsheet (2C1) and what you know about how it was put together.

Everything else is insurance.

## Fit snapshot

Shared by all three rounds.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD (the branch half) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process across branches, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on the stages around the log likely. If any of those stages were yours, say which and what you did, in your own words; if the log was where your part began and ended, or it was not yours, say so plainly and stay with the log |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD (the contact-centre half) | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says you built a monthly complaints spreadsheet that your regional manager uses, and the words stay there. Answer slot: the JD's monthly-reporting line makes a probe on what the sheet held likely. If you know what it held and how it was put together, say so in your own words; if you do not know how something in it was counted, or a step was not yours, say so plainly and stay with the spreadsheet you built |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | You wrote "spreadsheet", and the JD says Excel, so the pack does not borrow the JD's word for your history. Answer slot: if the spreadsheet was in Excel, say so and say what you did in it, in your own words; if it was another tool, say which, plainly |
| F5 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says you trained new tellers on the escalation script, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on who you have guided likely. If you have guided anyone beyond new tellers on escalations, say who and how, in your own words; if not, or it was not yours, say so plainly and stay with the tellers |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: if you have worked with a digital team on anything, say what and which part was yours, in your own words; if you have not, say so plainly and say what you would ask a digital team first |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in your own terms: six years in retail banking, the last three as a branch supervisor |
| F8 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your word is "formal", and the JD's is "regulated", so the pack does not swap one for the other. Words: "I handled the branch's formal complaints log." Answer slot: the JD's line on regulation makes a probe on which rules governed the log likely. If you know which rules applied and what they required of you, say so in your own words; if the log ran on internal policy only, or you do not know, say so plainly and stay with the log |
| F9 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare for it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

Requirement-coverage line:

| Requirement | Question IDs | Note |
|---|---|---|
| F1 own the process, branch half | 1A1, 2A1, 3A4, 3B1 | |
| F2 the contact centre | 1B2, 2B1, 3D1, 3B1 | 2B1 is the deepest rehearsal |
| F3 monthly reporting | 1A1, 2C1, 2C2, 2D1, 3A3, 3C2 | |
| F4 Excel | 2C1 | Asked inside the walk-through of the spreadsheet |
| F5 coaching supervisors | 2A3, 3B2, 3C1 | |
| F6 digital teams | 2B3, 2D2 | |
| F7 four years | 1A1 | |
| F8 regulated complaints | 1B3, 3B1 | |
| F9 senior leaders | 2A4, 2B2, 2D1 | |
| Each of the four values | 3A1, 3A2, 3A3, 3A4 | One question per value |

## Grounding brief

From the 2026 strategy brief the recruiter sent, as you summarised it. I do not have the brief itself, only your four lines, and it was published in July 2026.

| Fact, in your words | Source | Provenance | Where it is used |
|---|---|---|---|
| "move 40% of member service to digital channels by 2028" | Strategy brief, via your message | [grounded] | 1B1, 2D2 |
| "consolidate eight branches into five hubs over 2027" | Strategy brief, via your message | [grounded] | 3B3, R3 reverse question 4 |
| "launch a small-business lending product in Q1 2027" | Strategy brief, via your message | [grounded] | R2 reverse question 5 |
| "the main competitive pressure is app-only banks" | Strategy brief, via your message | [grounded] | 1B1, 2D2 |

The brief is equally available to any prepared candidate, so reciting it only proves you read it. Bring one item from it to show grounding, then a view of your own with a concession, as 2D2 and 3B3 set out.

---

# Round 1: the recruiter (30 minutes)

## Persona table, round 1

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly walk-through of your background, then pay, notice, location and why you are leaving | High. The recruiter-screen prior is Conversational plus a light Skeptic, and the recruiter's own description is a 30-minute conversation | Prepare a 90-second arc for the biography question and treat the logistics as scored |
| Skeptic (light) | Knockout checks on the JD's requirements, and why Ashgrove and why now | Medium. The prior says light, and the gaps you stated (F2, F9) are the likeliest knockouts | Concede what you have said plainly, once, and move to the plan |
| Values / Behavioral | Not expected here | Low. The values round is documented for round 3, not this one | None drilled |
| Case / Strategist | Not expected here | Low. The only case documented is in round 3 | None drilled |

## Question bank, round 1

Proposed wording, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc in three beats the quotes state, told in your own words and at their scope: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Answer slot: close on why you want this role, in your own words, and if your honest reason is smaller or messier than that, say it plainly rather than dressing it up | F7 is the spine of the arc and F1 and F3 are the two lines it leads into. EXP because it tests what was actually yours, and the biography question sets the register for the call |
| 1A2 | "What's making you want to move on from your current role?" | EXP | [generic] | Logistics slot. Give your own actual reason in your own words and tie it to something this role really does. If part of it concerns your current employer, say so without criticising them. Never offer a reason you did not give | A recruiter asks for the reason for leaving in every screen, and consistency of motivation is what it scores. No F row speaks to it |
| 1A3 | "What salary are you looking for?" | JD | [generic] | Logistics slot. Give your own number, or ask for the role's band first. Which of those two you do is your own call, and either is a legitimate answer | Pay is a standard recruiter-screen item, and the role's terms are the JD's. No F row speaks to it |
| 1A4 | "What's your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period in your own words. Mention flexibility only if there really is some | Notice is a standard recruiter-screen item. No F row speaks to it |
| 1A5 | "Where, and how often, can you work?" | JD | [generic] | Logistics slot. State the locations and working pattern you can actually do. If you do not know where the role is based, or whether it involves moving between branches, ask rather than guess | Location is a standard recruiter-screen item. The JD names branches and a contact centre without saying where the role sits |
| 1B1 | "Why Ashgrove, and why now?" | CO | [grounded] strategy brief and values page, both provided | Pick one item from the strategy brief that touches complaints, either the move of service to digital or the hub consolidation, and say in your own words why it makes this role matter. Then name one of the four values you can honestly say you care about. Do not say you have lived a value unless you can name the time, because that is the round 3 bank | The why-here probe is the Skeptic's stem, and CO because it scores homework from the brief. No F row speaks to it |
| 1B2 | "The role covers the contact centre, and you haven't worked in one. How do you see that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | The short form of 2B1. Say the plain acknowledgment: "I haven't worked in a contact centre." Then one sentence of plan in your own words, and stop. Do not offer a parallel from the branch | F2 is the gap you stated and the likeliest knockout in a screen. JD because it scores the stated requirement |
| 1B3 | "What experience do you have with regulated complaints?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what you handled, at its scope: "I handled the branch's formal complaints log." Answer slot: expect a probe on which rules governed the log. If you know which rules applied and what they required of you, say so in your own words; if the log ran on internal policy only, or you do not know, say so plainly and stay with the log | F8 is the one row for this requirement, and the gap between formal and regulated is where a probe lands. JD because it scores a stated requirement |

## Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| 1 | "Is there anything about the 20-minute case in round 3 you can tell me, such as its format or whether there is anything to prepare?" | It asks for the one thing in the process that has no description, and a recruiter can often answer it |
| 2 | "Who would the contact-centre team and the branch supervisors report to in this role?" | It shows you are thinking about how the process runs across both, which is the JD's first line |
| 3 | "Does the role involve moving between branches or the contact centre, and where would it be based?" | It settles location and pattern with the person who knows, and it supports your own answer to 1A5 |
| 4 | "What does the Head of Member Services most want to see from someone in the first months?" | It collects what the next round is likely to probe, from the person who briefed them |
| 5 | "What happens after the panel, and who makes the decision?" | It shows you are thinking past the day, and it fixes the timeline |

---

# Round 2: the Head of Member Services (45 minutes, mostly behavioural)

## Persona table, round 2

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time" probes on escalations, coaching and putting members first | Highest. The recruiter described this round as mostly behavioural | Use a real story where one comes to mind and the honest branch where none does; "we" for context, "I" for what was yours |
| Skeptic | Quiet probing of the gaps: the contact centre, senior leaders, digital | High. The hiring-manager prior is Case plus Skeptic, and this person would be your manager, so the gaps you stated (F2, F9) and the silence on F6 are what they would derisk | Rehearse the single most predictable objection until it is boring: 2B1 |
| Data-Driven Prober | Reads your line on the spreadsheet closely | Medium. F3 and F4 rest on one sentence, and a manager who owns monthly reporting is likely to open it | Know what you can and cannot say about how it was put together, and say plainly what you do not know |
| Case / Strategist | A live problem from the role, and the strategy | Medium. The prior is Case plus Skeptic, but the recruiter said mostly behavioural, so fewer questions | Clarify, then structure, then answer; challenge one premise respectfully |
| Pressure | Not expected | Low. Nothing in the loop suggests it | None drilled |

## Question bank, round 2

Proposed wording, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2A1 | "Tell me about a time an escalation did not go the way it should have. What did you do?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick an escalation you were part of that went wrong. It needs the member's problem, what went wrong, your own part in it (name only what was yours), and how it ended. The nearest thing your material carries is "I handled the branch's formal complaints log and trained new tellers on our escalation script," so say that at its scope. If no such escalation comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle one | F1 and F5 are the nearest rows, and escalation is a JD pillar. EXP because it tests what was actually yours |
| 2A2 | "When did you put a member ahead of an internal target or process?" | VAL | [generic] | Selection scaffold: pick a time you decided something from the member's side when it cost you something, whether time, a rule or a target. It needs a named situation, a decision that was yours, and an honest account of what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide | The Values persona's stem, mapped to Members First, Always. No F row carries a story for it |
| 2A3 | "Tell me about a time you had to coach a colleague who had handled something badly." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a time you corrected or coached someone who had got something wrong. It needs what they did, what you said, and how it was left. The nearest thing your material carries is "I trained new tellers on our escalation script," which is training, so do not present it as coaching someone who erred. If no such time comes to mind, say so plainly and stay with the tellers | F5 is the JD's coaching row and the quote carries training, not coaching. EXP because it tests the verb |
| 2A4 | "Tell me about a time you had to tell someone more senior something they did not want to hear." | VAL | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Selection scaffold: pick someone at the level you have actually worked with, and keep the level honest, since you have said you have not presented above regional level. It needs what you said, how they took it, and whether the relationship held. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would go about it | The Values persona's stem, aimed at F9 because the role reports to senior people. VAL because the hard truth has to have landed in a real story |
| 2B1 | "Half of this process runs through a contact centre you have never worked in. How do you own something you have not done?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't worked in a contact centre." Then what you have, at its scope: "I handled the branch's formal complaints log." Then a plan in your own words and as a plan, never a past. Hold through three follow-ups. If asked "so you cannot do the job yet", repeat the limit and the plan and add no claim. If asked who in the contact centre you would lean on, do not name anyone or anything you do not know, and say what you would ask. If asked what worries you most, name the weakest assumption in your plan, which is that nothing from the branch carries over until you have tested it. Concede that it is a real gap, specifically, and do not fold on the plan | F2 is the gap you stated and the JD names it first. JD because it scores the stated requirement, and it is the question most likely asked in some form by this person |
| 2B2 | "This role presents monthly to senior leaders, and you have not presented above regional level. What makes you confident?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say the plain acknowledgment first: "I haven't presented to anyone above regional level." Then a plan in your own words: how you would find out what leaders need from the monthly report, and how you would prepare. Answer slot: if you have presented anything that senior people have read or heard, say what and to whom, in your own words; if you have not, say so plainly and stay with the plan | F9 is the stated gap. JD because it scores a stated requirement |
| 2B3 | "You would work with our digital teams on self-service journeys. What have you done with digital teams?" | JD | [grounded] | Answer slot: expect a probe on any work with a digital or app team. If you have worked with a digital team on anything, say what and which part was yours, in your own words; if you have not, or it was not yours, say so plainly and say what you would ask the digital team first about a self-service journey | F6 is silent in your material, so this is the question that opens it. JD because the requirement is stated |
| 2C1 | "Walk me through the spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The beats the quote states: you built it, it was monthly, it was about complaints, and your regional manager uses it. Answer slot: expect a probe on what the sheet held, how it was put together, and what tool it was built in, since the JD names Excel. If you know, say it in your own words; if you do not know how something was counted, or a step was not yours, say so plainly and return to "I built the monthly complaints spreadsheet our regional manager uses." Name the assumption in it you would defend least, in your own words, before they ask | F3 and F4 both rest on this one sentence, so it is the likeliest probe target. EXP because it tests what was actually yours |
| 2C2 | "Knowing what you know now, what would you change about that spreadsheet?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if there is something you would change, say what and why, in your own words; if there is nothing, say so plainly. Do not invent a flaw to look self-aware | F3 again, and the weakest-assumption move put as a hindsight question. EXP because it tests candour about your own work |
| 2D1 | "You have two minutes with senior leaders on this month's complaints. What do you put in front of them?" | CASE | [generic] | Structure: what decision they need to make, one headline, the exception that needs them, then the ask, and stop. Say which of these you would agree with the Head of Member Services before the first report. The question needs no claim about your past, so the guidance makes none | F9 and F3 meet here: a monthly report put to people above the level you have presented at. CASE because it is a live problem from the role, and `[generic]` because it is a pattern |
| 2D2 | "The strategy moves 40% of member service to digital by 2028. Which complaints would you keep with a person, and why?" | CO | [grounded] strategy brief, provided | One item from the brief to show grounding: the 40% move, or the pressure from app-only banks. Then a position of your own, with a concession. Options, for you to accept or replace: start self-service where members already struggle, and keep any complaint that is already escalated with a person. Concede that both depend on data you have not seen. Anti-pick: do not move the complaint itself to self-service first. The guidance makes no claim about your past | The CO question from the brief, built to differ from the shared reading of it. F6 is the row it presses on |

## Reverse questions, round 2

| # | Question | Why it lands |
|---|---|---|
| 1 | "Where do complaints stall today between branch and contact centre?" | It goes straight at the process the role owns, and it is the question your gap in F2 most needs answered |
| 2 | "What does the monthly report look like today, and who reads it?" | It asks about the work you will actually do, and signals you think about the audience |
| 3 | "What has been tried on self-service complaint journeys so far?" | It asks for history instead of assuming a blank page |
| 4 | "Given I have not worked in your contact centre, how would you want me to spend the first 30 days?" | It names the gap yourself, as a plan, and invites the manager to shape it |
| 5 | "How does the Q1 2027 small-business lending launch change what complaints handling needs to cover?" | It ties the role to a named move in the brief and shows you read past the headline |

---

# Round 3: the panel of two branch managers (60 minutes, including a 20-minute case; also the values round)

## Persona table, round 3

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes mapped to the four published values | Highest. The recruiter said the panel scores against the four values | One question per value in 3A; a story where one of your sentences carries one, the honest branch where none does |
| Case / Strategist | The 20-minute complaint-escalation case, and the strategy | High. The case is documented | Clarify, structure, answer, and challenge one premise respectfully |
| Peer Evaluator | Where your job ends and a branch's begins, and how disagreements go | Medium. Branch managers are the people whose supervisors the role coaches, which is an inference from the JD and the recruiter's description | Propose seam principles rather than pretend to know their seam; say what you bring them as well as what you need |
| Skeptic | The contact centre and which value you would find hardest | Medium-low. A panel's top two personas per member lean on Values, and the gaps are covered in round 2 | Use the same concession wording as 2B1 |
| Pressure | Not expected | Low. Nothing in the loop suggests it | None drilled |

## Values / principles cheat sheet

Detected: the recruiter's email says the panel is the values round and scores against the four values. The values are from the page you copied this morning from ashgrovecu.org/about/values.

| Value (official name) | Working meaning, paraphrased | Mapped story, or scaffold |
|---|---|---|
| Members First, Always | Decisions are made from the member's side of the counter | No row carries a story. Scaffold in 3A1, ending in its honest branch |
| Plain Words | If a member needs it explained twice, the wording was wrong | No row carries a story. Scaffold in 3A2, with F5's "I trained new tellers on our escalation script." as the nearest thing at its own scope |
| Neighbours, Not Numbers | Every branch is part of its town | F3: "I built the monthly complaints spreadsheet our regional manager uses." The role reports numbers, so the tension to rehearse is in 3A3 |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Scaffold in 3A4, with the quote as the nearest thing, not as a finished story |

## Question bank, round 3

Proposed wording, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3A1 | "Tell me about a time you decided something from the member's side of the counter when it was the harder thing to do." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a time a member's situation pulled against a rule, a target or the easy option, and you decided for the member. It needs a named situation, a decision that was yours, what it cost, and how it ended. The nearest thing your material carries is "I handled the branch's formal complaints log," which is not a decision, so do not stretch it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide | Members First, Always, from the published page. F1 is the nearest row and carries no decision story |
| 3A2 | "Tell me about a time you had to explain something to a member or colleague who needed it explained twice. What did you change?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a time your first explanation failed. It needs what you said, why it did not land, and the wording you used the second time, in your own words. The nearest thing your material carries is "I trained new tellers on our escalation script," which does not say you wrote it or changed it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Plain Words, from the published page. F5 is the nearest row and carries training only |
| 3A3 | "You would report monthly on complaint volumes and resolution times. How do you stop the numbers hiding the neighbour?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what you have at its scope: "I built the monthly complaints spreadsheet our regional manager uses." Then a plan in your own words, as a plan: how a member's own story stays visible next to the totals. Answer slot: if your spreadsheet gave any view of individual members' complaints, say what; if it did not, say so plainly and stay with the plan | Neighbours, Not Numbers set against the JD's reporting line. F3 is the row, and the tension is the one this role carries |
| 3A4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a problem you found that was not obviously yours and stayed with. It needs what it was, what you personally did, who you handed to or did not, and how it ended. The nearest thing your material carries is "I handled the branch's formal complaints log." If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would keep hold of one | Own the Fix, from the published page, and it echoes the JD's first line. F1 is the nearest row |
| 3B1 | "A member has complained three times about the same card payment problem. The branch says it is the contact centre's, and the contact centre says it is the branch's. The member says they will leave and tell the local paper. Walk us through what you do." | CASE | [generic] | An invented practice case, not Ashgrove's. Structure: ask what has been said to the member and by whom, which complaint rules and timeframes apply, and what the member wants; set the objective; name who keeps hold of it, as Own the Fix says; give the member a plain-words update today; close the branch and contact-centre handover gap; record it for the monthly report. Where it reaches the contact centre, say what you would ask rather than pretend to know. The case needs no claim about your past, so the guidance makes none | The recruiter named a 20-minute complaint-escalation case without describing it, so this rehearses the pattern. F1, F2 and F8 are the rows it presses on |
| 3B2 | "In that case, the supervisor involved handled the member badly. How do you coach them?" | CASE | [generic] | Structure: separate the member's fix from the coaching; ask the supervisor what they saw before saying what you saw; agree one thing to do differently; check back. Say what you would do, never what you have done. The question needs no claim about your past, so the guidance makes none | The follow-on a panel can add to any escalation case, and F5 is the JD row it presses on |
| 3B3 | "Eight branches become five hubs over 2027. What happens to complaints, and to Neighbours, Not Numbers, through that change?" | CO | [grounded] strategy brief and values page, both provided | One item from the brief to show grounding: the consolidation itself. Then a position of your own, with a concession. Options, for you to accept or replace: watch complaints from the affected towns as an early signal, and report them by town so numbers do not hide places. Concede that you do not know which branches are affected. Do not guess which branches, and do not assume how the panel's own branches are affected. The guidance makes no claim about your past | The CO question from the brief's second move, and the one a branch-manager panel can answer from the inside. It rests on the brief and the values page, not on F rows |
| 3C1 | "You would coach our supervisors on escalations. Where does your job end and ours begin when a complaint lands on a branch manager's desk?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Do not pretend to know their seam. Propose a principle in your own words: who keeps hold of a complaint, and when it moves. Reciprocity: say what you can give a branch manager as well as what you need. The only experience nearby is "I trained new tellers on our escalation script," so keep any past claim to that | The Peer persona's seam stem. F5 is the row, and the quote carries tellers, not supervisors |
| 3C2 | "Complaint numbers will sometimes make a branch look bad. How do you handle that with the branch manager before it reaches senior leaders?" | JD | [generic] | A principle to propose, in your own words and as a principle, not a practice you claim: the branch manager sees a branch's figures first, with the context, before anyone senior does. Add one concession: that you have not presented above regional level and would agree the practice with your manager. The guidance makes no claim about your past | The Peer persona's credit and disagreement stem, aimed at the JD's monthly reporting. F3 and F9 are the rows it touches |
| 3D1 | "You have never worked in a contact centre. Why should two branch managers trust you with it?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Use the same wording as 2B1: "I haven't worked in a contact centre." Then the plan, in one or two sentences, and then what you can offer a branch manager, which is the branch's view only to the extent your own sentence states it. Do not widen it | F2 again, in a panel's packaging. JD because it scores the stated requirement |
| 3D2 | "Which of our four values would you find hardest to live up to in this job?" | VAL | [generic] | Pick one, name why in your own words, and say what you would do about it. The question needs no claim about your past, so the guidance makes none. Choose the one you can discuss honestly, and do not pick the easy one to look safe | A Skeptic probe aimed at honest self-assessment, and the panel scores against the values, so this reads candour. No F row speaks to it |

## Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| 1 | "What do your supervisors find hardest about escalations today?" | It asks the people the role coaches for the problem the coaching is meant to solve |
| 2 | "What would help your branch most from this role in its first month?" | A reciprocity question that moves you from candidate to colleague |
| 3 | "How would you want to hear about a complaint trend in your branch: before it goes up, or at the same time?" | It tests the principle in 3C2 against the panel's own view |
| 4 | "How will complaint handling and your relationships in the towns be kept through the hub changes?" | It ties the role to the brief's consolidation and to Neighbours, Not Numbers |
| 5 | "Where have you seen Own the Fix work well in a branch, and where has it been hard?" | It asks for a real story from them, and gives you material for your own |

---

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material says the branch's log, not the process across branches |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F9 | The plain acknowledgment: "I haven't presented to anyone above regional level." No slot |
| Coached branch supervisors on escalations | Inflated form of F5 | F5's quote at its own scope: "I trained new tellers on our escalation script." The limit is the pack's observation: the material says new tellers, not supervisors |
| Reported on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The limit is the pack's observation: the material says a monthly complaints spreadsheet, not what it held |
| Handled regulated complaints | Inflated form of F8 | F8's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material says formal, not regulated |

## Sources

Provided documents: the JD, the values page text you copied this morning from ashgrovecu.org/about/values, the recruiter's email on the process, your summary of the July 2026 strategy brief, and your background as you gave it. No dossier was present.

No search or fetch was sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values page you pasted fixes the cheat sheet and the four VAL questions, so a fetch could not have moved either |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email establishes three sessions, who runs each and what each holds, which fixes the loop and the persona weights |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | Your summary of the July 2026 brief supplies the priorities that feed the CO questions and the grounding brief |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer has been named, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names and roles for any of the three rounds → an interviewer read, persona weights from their public footprint, and a reverse question tied to each one's path
- The strategy brief itself, not only your four-line summary → CO questions grounded in more than four facts, and a fuller grounding brief
- Your own answers to the answer slots in F1, F3, F4, F5, F6 and F8 (what the stages around the log were, what the spreadsheet held and what tool it was in, whom you have guided, any digital work, which rules governed the log) → those rows move from discovery toward grounded, and the guidance in 1B3, 2A3, 2B3 and 2C1 becomes story-mapped
- A CV, not only your summary → more of your own sentences to quote, and fewer rows resting on one sentence
- The recruiter's answer on what the 20-minute case holds and whether there is anything to prepare → 3B1 and 3B2 tuned to its format, and a build section if it turns out to be a deliverable
- Your honest reasons and numbers for 1A2 to 1A5 → they are yours to give, so nothing is asked here, but writing them down before the call is the whole prep
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes, covering a refreshed strategy picture, interviewer footprints once names exist, reports on this role family's loops, and recent organisation context → a fuller grounding brief and sharper CO questions
- A tuesday-dossier.md from an earlier assessment of this role → verified evidence and prohibited claims arriving ready-made, in place of the ones built here
