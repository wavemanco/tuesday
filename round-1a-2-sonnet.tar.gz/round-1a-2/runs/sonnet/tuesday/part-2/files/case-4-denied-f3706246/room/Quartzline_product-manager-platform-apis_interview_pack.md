# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes, Thursday. Interviewer name not given. Session mode.
**Built on:** your `tuesday-dossier.md` (conditional_go) plus the pack's own derivations. Persona weights rest on the hiring-manager relationship prior and the generic loop fallback, not on a documented Quartzline process (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment against published values (none detected in this pack) |
| EXP | Work-experience deep-dive: do your claims survive scrutiny, and what was actually you |
| JD | Role and JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack, see Sources) |
| CASE | A live problem set in the role |

Guidance is scaffolding, not a script. Where a cell quotes you, say it in your own words and no wider than the quote. Where a cell is an answer slot, answer from what is true: either branch is a good answer.

**Highest-ROI rehearsal: B1.** The underwriter named that objection in your dossier, so it is theirs and not inferred. Rehearse it until it is boring.

## 4. Fit snapshot

Requirement text is the dossier's `role_profile` requirement lines, standing as the JD. Evidence cells hold only your confirmed sentences from the dossier's `verified_candidate_evidence`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [grounded] | transferability | The underwriter's strategy is bridge, with the limit named: this is adjacent integration leadership, never PM experience. The words stay at the quotes' scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, and I wrote the internal integration playbook my team uses." The limit, in sourced words: "I haven't held a product manager title or role" (prohibited_claims: "Having held a product manager title or role"). Say the limit first, before it is asked for |
| F2 | "Owning a roadmap and prioritization authority" — dossier handoff, R1 sub-claim | none given | none | [grounded] | capability | The underwriter recorded this as acknowledge_gap, so no bridge is coached. Words, sourced to `uncertain_or_weak_areas` (acknowledge_gap) and `prohibited_claims: "Having owned a product roadmap"` and `prohibited_claims: "Having set prioritization for an engineering squad"`: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan said as a plan and never as a past: what you would learn first (A5) |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | The pack's observation: your material says integrations of the vendor's APIs, not an API or platform product, and the dossier's weak-area list does not classify this must-have, so it is unresolved. Answer slot: R2 makes a probe on products you shipped likely. If you shipped an API or platform product, say what it was and what part was yours, in your own words; if you did not, or the product was the vendor's and you integrated it, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quote touches the requirement without showing whether it reaches docs or schemas. Answer slot: if you worked from API docs or schemas in those integrations, say which and how, in your own words; if not, say so plainly and stay with the stages the quote states and the playbook you wrote |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | The second quote is confirmed with limited inspectable proof, so expect a probe on it: say plainly what you can show and what you can only describe. It is input to a roadmap, not ownership of one, and it is not used to answer F2. Words stay at the quotes: "I led 30+ end-to-end client integrations of the vendor's REST APIs" and "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot: R4 names sales and engineering and the quotes carry neither. If you worked with either, say how and what part was yours; if not, say so plainly and stay with the clients and product |
| F6 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [inferred] | discovery | The underwriter's strategy is clarify and no verified entry speaks to this requirement, so nothing about your past goes in an answer. Answer slot: R5 makes a probe on the cadence you have worked inside likely. If you have worked in sprints or a similar cadence, say which and what part was yours; if you never worked that way, say so plainly, and say what you would want to confirm about how the two squads define it |

No row is a hard gate: the dossier records `hard_gates: []` and no requirement is a term such as location, pay or authorization.

## 8. Persona table

Weighting is shown so you can recalibrate if you know something this pack does not.

| Persona | How it shows up | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist (A) | Live problems on the partner API platform: diagnose adoption, prioritize between squads, outline a spec | highest, 5 questions | Hiring-manager round prior is Case/Strategist plus Skeptic; the JD responsibilities (roadmap, specs with two squads, adoption metrics) are all case-shaped | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B) | Quiet, persistent probing of the title and roadmap gap, then must-have R2 | highest, 5 questions | Same prior, raised by the dossier's named objection and by the gap rows F1, F2, F3 | Rehearse the objection until boring; bridge only from adjacent quotes with the limit named; concede the roadmap gap plainly |
| Data-Driven Prober (C) | Reads the 30+ figure and the playbook line by line | mid, 3 questions | The CV-style claim carries a headline number, and the JD names adoption metrics | Know what you can and cannot say about how the 30+ was counted; name the weakest assumption first; offer to walk the playbook end to end |
| Conversational (E) | The "walk me through the journey" opener and casual questions on JD topics | mid, 3 questions | Almost every first conversation opens this way; casual questions are still scored | A 90-second arc built only from your three sentences; treat casual JD-topic questions as scored |
| Peer Evaluator (F) | Collegial versions of the authority question: the seam with the squad leads | low, 2 questions | The JD names two squads and the dossier lists authority versus the squad leads as unresolved | Offer seam principles, not a pretended seam; reciprocity |
| Pressure (D) | Time-boxed "why you over them" and "how much was you" | low, 2 questions | Lower prior for this round type; the stems are the likeliest way the objection returns under time pressure | Pause, restate, hold through two follow-ups, concede specifically |

No values-style round is detected, so no VAL questions or values cheat sheet are included.

## 9. Question banks

### A. Case / Strategist (highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Adoption of a partner API platform looks flat. What do you need to know first, and how would you diagnose it?" | CASE | [inferred] | Think aloud: clarify first, then objective, segmentation, approach, metrics, risks, and challenge one premise respectfully. Your first clarifying questions can be the live unknowns for this role: how adoption is measured today and what the baseline is. The question needs no claim about your past, so the guidance makes none | Derived from the JD responsibility to define and track adoption metrics and the dossier unknown on how adoption is measured; Case/Strategist prior for a hiring-manager round. CASE because it asks for structure on a problem, not a past |
| A2 | "Two squads each want the same quarter: one for a partner-requested endpoint, one for platform hardening. How do you decide, and what happens when a squad lead disagrees?" | CASE | [inferred] | State your criteria aloud, say how you would bring both squad leads into the call, and say which decision rights you would want clarified first, since who decides is the open question. No claim about your past | Lets you show prioritization judgment without a past claim, which F2 does not support. Derived from the JD line on two engineering squads. CASE because it is a live decision |
| A3 | "Outline the spec for a new partner-facing endpoint. What has to be in it before a squad starts?" | CASE | [inferred] | Walk the order you would use: the partner problem and the evidence for it, the contract and schema, versioning and docs, acceptance, rollout, the adoption measure, and what you would ask the squad lead to own. No claim about your past | Derived from the JD responsibility to write specs and drive delivery, and R3's docs and schemas. CASE because it asks for structure on a task from the role |
| A4 | "Pick three adoption metrics for the partner API platform and tell me what decision each would change." | CASE | [inferred] | Name three, tie each to a decision, and say you would need the baseline before trusting any. Name the assumption behind each you would defend least. No claim about your past | Derived from the adoption-metrics responsibility; the baseline is an open item in the dossier. CASE because it scores reasoning and vocabulary, not a past |
| A5 | "Walk me through your first thirty days." | CASE | [generic] | A plan, not a past: who you would meet first (both squad leads, partners), what you would map (decision rights, the current roadmap, the adoption baseline), and what you would not commit to until you had. This is also the ramp plan for F2 | Doubles as the ramp plan an acknowledge_gap area needs; its unknowns are the reverse questions in section 11. CASE because it is a forward plan |

### B. Skeptic (highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap"; prohibited_claims: "Having set prioritization for an engineering squad" | The deepest rehearsal in the pack. Open by conceding, before they press: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Then the bridge, with its limit: "I led 30+ end-to-end client integrations of the vendor's REST APIs, and I wrote the internal integration playbook my team uses" — adjacent work, not PM work, and say so. The playbook can be shown, so offer to walk it end to end. Follow-up one, "so you've never prioritized for a squad?": hold by returning to those two sentences and concede in sourced words, "I haven't set prioritization for an engineering squad." Follow-up two, "then what makes you ready?": the ramp plan from A5, and your question on decision rights. Never add a PM-flavored claim to win the exchange | Named by the underwriter as the likeliest objection, so it comes from your confirmed evidence, not from a cold read. Rows F1 and F2. JD because it scores the stated 3+ years requirement |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] prohibited_claims: "Having owned a product roadmap" | Name it before they do: "I haven't owned a product roadmap." Then the plan, said as a plan: learn the squad leads' current plan, the decision rights and the adoption baseline before proposing anything. Calibrated candor beats bluffing a competency the interviewer personally owns | Stock Skeptic stem; F2 is the largest gap in the material, so it is the honest answer. JD because it scores the listed job including its gaps |
| B3 | "Tell me about a time you shipped an API or platform product." | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Selection scaffold: pick the product, say what it was and exactly what part was yours; say what it did for adoption only if you know. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is "I led 30+ end-to-end client integrations of the vendor's REST APIs," at that scope, or say how you would approach shipping one | R2 is a must-have and F3 is unresolved, so this is where the Skeptic goes after the bridge. JD because it scores a stated requirement |
| B4 | "What does agile delivery look like in your experience?" | JD | [inferred] | Nothing in your verified evidence speaks to this requirement, so no story is coached. Answer slot: the JD's agile delivery line makes a probe on the cadence you have worked inside likely. If you have worked in sprints or a similar cadence, say which and what part was yours, in your own words; if you never worked that way, say so plainly, and say what you would want to confirm about how the two squads define it | F6, clarify strategy. JD because it scores a listed preferred requirement, asked as an open question |
| B5 | "Why this move, and why now?" | JD | [generic] | Selection scaffold: one sentence of your own reason, one on why a platform-owner role, one on why now, in your own words. If you cannot yet name a reason, say so plainly rather than adopting one that sounds right | Motivation consistency is what the Skeptic scores for a candidate changing seats. Nothing in the material states a motive, so none is supplied. JD because it concerns this role |

### C. Data-Driven Prober (mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ integrations were counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend the number in your own words. Answer slot: what made something count as one integration, what the figure is sensitive to, the assumption behind it you would defend least (name it before they ask), and which part was yours, where the quote says "Led". If you do not know how it was counted, say so plainly | F1 and F5 draw on this headline number, so it is the likeliest to be probed to its assumptions. EXP because it tests attribution |
| C2 | "Pick one of those integrations and walk me through it from scoping to go-live." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on the five stages the quote states, in your own words, at its "Led" attribution: scoping, requirements, architecture, UAT, go-live. Answer slot: R3 makes a probe on API docs and schemas likely. If you worked from either in that integration, say which and how; if not, say so plainly and stay with the stages | F4's requirement gives this a technical probe. EXP because it checks the claim end to end |
| C3 | "Tell me about the integration playbook." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Two beats, both from the quote: you wrote it, and your team uses it. It is the one artifact you can show, so offer to walk it end to end and describe it from what it says. Claim no effect it had unless you can state it in your own words | Counter-strategy for the Prober: offer to walk through work you did yourself. F1 carries the quote. EXP because it tests what you actually did |

### D. Pressure (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a PM who has done this for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; prohibited_claims: "Having held a product manager title or role" | Pause and restate the question. Hold: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Concede specifically: "I haven't held a product manager title or role." Hold through two follow-ups by returning to the integrations, never by adding PM work | The objection in B1 arriving time-boxed. F1. JD because it scores the 3+ years requirement |
| D2 | "That result — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold at "Led". Answer slot: say which parts were yours alone and which were shared with your team, in your own words; if "led" meant coordinating others' work, say so plainly. Concede that specific part, never the core claim, and never widen it to restore harmony | Stock Pressure stem aimed at the one headline claim. F1 and F5 |

### E. Conversational (mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc of three sentences, each at its own scope: you led 30+ client integrations of the vendor's REST APIs; you wrote the internal integration playbook your team uses; you ran quarterly roadmap-input sessions feeding client evidence to product. The third is confirmed with limited inspectable proof, so say plainly what you can show and what you can only describe. Close with your own reason for this move (B5) | The opener is scored even when it feels casual. F1, F5. EXP because it presents the history the later questions probe |
| E2 | "Tell me about something recent in API design or documentation that caught your attention." | JD | [generic] | Selection scaffold: pick something real you have read or used and say what you took from it. If nothing comes to mind, say so plainly, then say how you keep current | Casual question on a JD topic (R3), scored all the same. JD because it probes technical fluency |
| E3 | "Tell me about working across engineering, sales and customers." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-mapped on the two quotes at their own scope, naming the second's limited proof. Answer slot: the JD names sales and engineering and the quotes carry neither. If you worked with either, say how and what part was yours; if not, say so plainly and stay with the clients and product | R4 is an important requirement; F5. JD because it scores the stated stakeholder line |

### F. Peer Evaluator (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Where does the seam sit between a PM and a squad lead, and what do you do when you disagree?" | JD | [generic] | Offer principles, not a pretended seam: who owns the problem and who owns the build, and say you would want to hear how this team draws it (reverse question 1). For the disagreement part, selection scaffold: pick a time you disagreed with an engineer or peer, name the stake and what changed, keep the relationship intact. If no such time comes to mind, say so plainly, then say how you would handle it | The dossier lists authority versus the squad leads as unresolved, so the question returns collegially. JD because it scores the role's cross-squad work |
| F2 | "How do you handle credit when work spans teams?" | EXP | [generic] | "We" for context, "I" for contribution. Selection scaffold: pick a time work spanned teams, say what was yours, and keep it precise. If no such time comes to mind, say so plainly, then say how you would handle it | Stock Peer stem; it tests the same attribution honesty as D2 in a friendlier register |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| R1 3+ years product management experience | B1, B2, D1, E1 |
| R1 sub-claim: roadmap and prioritization authority | A2, A5, B1, B2, D1 |
| R2 Shipped API or platform products | B3, C2 |
| R3 Technical fluency: API docs, schemas | A3, C2, E2 |
| R4 Stakeholder management across engineering, sales, customers | E3, F1, F2 |
| R5 Agile delivery experience | B4 |
| Responsibility: discovery with integration partners | A1 |
| Responsibility: specs and delivery with two squads | A2, A3 |
| Responsibility: adoption metrics | A1, A4 |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's open risk: authority versus the two squad leads is asserted in the JD but not evidenced. The answer tells you what you would own before you accept, and it reads as diligence |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier's second open risk: adoption metrics are a named responsibility with no stated baseline. It is the same unknown A1 asks you to clarify first |
| 3 | "How do the two squads divide the platform today, and where does work cross between them?" | Maps the seam F1 asks about, from the JD's two-squad line, so your seam principles meet the real one |
| 4 | "Who talks to integration partners today, and how does what they say reach the roadmap?" | The JD names discovery with partners; it shows you are thinking about the work and surfaces who owns partner input now |
| 5 | "What would success look like at ninety days, and how would you and the squad leads know?" | Turns A5 into a shared definition and invites the manager to state expectations early |
| 6 | "What would you want to see in a first quarter from someone coming from the integration side rather than a PM seat?" | Invites the manager to name their real concern about the gap, which is better heard in the room than guessed afterward |

## 13. Prohibited claims

Built before the banks, and binding on every cell above.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | prohibited_claims from the dossier | "I haven't held a product manager title or role." Limited by F1's quotes at their own scope |
| Having owned a product roadmap | prohibited_claims from the dossier; acknowledge_gap area | "I haven't owned a product roadmap." Then the A5 ramp plan, no bridge |
| Having set prioritization for an engineering squad | prohibited_claims from the dossier | "I haven't set prioritization for an engineering squad." No slot |
| Shipped an API or platform product | Inflated form of F1 and F3 | F1's quote at its own scope; the limit is the pack's observation, not words for you: the material says integrations of the vendor's APIs, not a product. B3 and F3 stay inside that scope |
| Shaped the roadmap through the roadmap-input sessions | Inflated form of F5 | F5's quote at its own scope; the limit is the pack's observation: the material says the sessions fed client evidence to product, not that any decision followed |

## 14. Sources

**Provided:** `tuesday-dossier.md`, dossier_version 1.1, generated 2026-08-14 by job-underwriter. Consumed: `handoff_to_mock_interview` (all fields), `role_profile` (requirement text stands as the JD's lines; responsibilities and unknowns are context), `decision` (context only). The dossier carries no `evidence_map` or `evidence_state`, so evidence cells quote `verified_candidate_evidence` and name it as their origin.

**Searches sent (all refused, nothing returned):**
- `Quartzline company values` — refused
- `Quartzline interview process product manager` — refused
- `Quartzline strategy API platform news` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The search was refused. It would have supplied published value names for VAL themes; with no loop source, no values-style round is detected, so the cheat sheet would not appear either way |
| 2. `Quartzline interview process product manager` | unavailable | The search was refused. It would have established the loop and moved persona weights, which now rest on the hiring-manager prior and the generic archetype fallback |
| 3. `Quartzline strategy / recent news` | unavailable | The search was refused. It would have grounded CO questions; with none, the pack holds no CO question and its CASE questions are `[inferred]` or `[generic]` |
| 4. `{interviewer name} Quartzline` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. representative PM JD | skipped | The dossier's `role_profile` requirement lines fix the fit snapshot and the JD-tagged questions |

Nothing in this pack states a fact about Quartzline beyond what the dossier carries.

## 15. Upgrade menu

- The interviewer's name and role → an interviewer read, persona weights tuned to their public footprint, and a reverse question tied to their path
- How much prep time you have → a prioritized prep triage
- The recruiter's note on the loop and focus areas → persona weights based on this loop instead of a relationship prior
- Search access, or Quartzline's careers, values and process pages pasted → the three refused targets rerun, grounded CO questions and, if a values round is documented, a values cheat sheet; a deeper research pass (up to 6 further searches and 2 further fetches, several more minutes) is available once if search is permitted
- Your own words on shipped products (F3), API docs and schemas (F4), sales and engineering work (F5) and agile cadence (F6) → those rows' answer slots become quoted stories
- An agenda or write-up from one roadmap-input session → raises F5's second quote from medium toward high
- The raw CV behind the confirmed claims → more quotable sentences for the story-mapped cells
