# Member Experience Lead, Ashgrove Credit Union: interview pack (loop mode)

Prepared 20 November 2026 for Dara. Three rounds on 29 November 2026.

| Round | Length | Who | Relationship | Source |
|---|---|---|---|---|
| 1 | 30 minutes | The recruiter | Recruiter screen | Recruiter's email |
| 2 | 45 minutes | The Head of Member Services | Would be your manager; mostly behavioural | Recruiter's email |
| 3 | 60 minutes | A panel of two branch managers | Panel; includes a 20-minute case on a complaint escalation; also the values round, scored against the four values | Recruiter's email |

No interviewer names are assigned yet, so there is no interviewer read. The highest-ROI rehearsal in this pack is R2A1.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values |
| EXP | Whether what you said about your own work survives follow-up |
| JD | The listed responsibilities and requirements, including where you are thin |
| CO | Knowledge of Ashgrove's strategy and competition |
| CASE | A live problem from the role, structured aloud |

- Provenance labels: `[grounded]` traces to something you or the employer supplied, `[inferred]` is derived and the derivation is named, `[generic]` is a pattern with no claim about you or Ashgrove.
- An answer slot is an instruction for the interview, not a question for you now. Each has two honest branches: say how you did it in your own words, or say plainly it did not happen or was not yours.
- Everything said about your past in this pack rests on a sentence you wrote, quoted next to it.

## Grounding brief

| # | Item | Source | Provenance | Where it surfaces |
|---|---|---|---|---|
| G1 | Move 40% of member service to digital channels by 2028 | July 2026 strategy brief, as you summarised it | [grounded] | R1A7, R2C1, R3B3 |
| G2 | Consolidate eight branches into five hubs over 2027 | July 2026 strategy brief, as you summarised it | [grounded] | R1A5, R2C2 |
| G3 | Launch a small-business lending product in Q1 2027 | July 2026 strategy brief, as you summarised it | [grounded] | Not used in a bank, because the JD does not touch it; held for a reverse question |
| G4 | The main competitive pressure is app-only banks | July 2026 strategy brief, as you summarised it | [grounded] | R2C1 |
| G5 | Ashgrove writes "member", not "customer"; use the same word | JD and the values page | [grounded] | Every answer |

The brief is under six months old on the interview date. This grounding rests on your four-point summary, not the brief itself.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap on length, but a line with nothing inspected behind it, so expect a probe on what the years were. Say it in your own terms, retail banking and the last three as a branch supervisor, and add nothing |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your material says a formal complaints log and does not show which rules it was kept under. Words stay at the quote: "I handled the branch's formal complaints log." Answer slot: the JD's regulated line makes a probe on the rules behind the log likely. If it was kept to external rules, say which and what they meant for how you handled a complaint, in your own words; if it was an internal log, or the rules sat with someone else, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (branch half) — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on which stages were yours to set likely. If any were, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log you handled |
| F4 | "Own the member complaints process end to end across branches and the contact centre" (contact-centre half) — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote says a monthly complaints spreadsheet your regional manager uses and does not show what it counted. Words stay at it: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet showed. If it counted either, say how, in your own words; if it tracked something else, or someone else set the measures, say so plainly and stay with the spreadsheet you built |
| F6 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers and an escalation script, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on supervisors likely. If you have guided other supervisors on an escalation, say who and how, in your own words; if not, say so plainly and stay with the tellers you trained |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show work with a digital team. Answer slot: the JD names digital teams and self-service journeys, so expect a probe. If you have worked with one, say on what and what your part was, in your own words; if you have not, say so plainly and say how you would start |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said it. Words: "I've never presented to anyone above regional level." Then how you would prepare, as a plan. Your material does not show who the JD's senior leaders are or whether any sit at regional level, which is a question for the recruiter |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote says spreadsheet, not Excel, and the words stay at it: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names Excel, so expect the tool to be named. If it was Excel, say so and what the sheet did, in your own words; if it was another tool, say that plainly |

No row is a gate: the JD sets no term such as a licence, location or pay, and its experience requirement is graded like any other row.

## Requirement coverage

| Requirement | Question IDs | Note |
|---|---|---|
| 4+ years in financial-services customer operations (F1) | R1A1, R1A2 | R1A2 is the JD-tagged one |
| Regulated complaints (F2) | R2A2 | |
| Own the process end to end, branches and contact centre (F3, F4) | R1B1, R2A1, R2A2, R3D1 | R2A1 is the deepest rehearsal |
| Monthly reporting on volumes and resolution times (F5) | R2A4, R2D1 | |
| Coach branch supervisors on escalations (F6) | R2A3, R3C1, R3B2, R3D2 | |
| Digital teams and self-service journeys (F7) | R2C1, R3B3 | CASE-tagged, because there is no past to premise |
| Confident presenting to senior leaders (F8) | R1B2, R2A4 | |
| Excel reporting (F9) | R2D2 | |
| Members First, Always | R2B3, R3A1 | |
| Plain Words | R2B2, R3A2 | |
| Neighbours, Not Numbers | R2B3, R3A3 | |
| Own the Fix | R2B1, R3A4, R3C3 | |

No requirement is left without a question. No row asks you to defend a number, because you gave no figures; the upgrade menu says what would add them.

---

## Round 1: recruiter screen (30 minutes)

### Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly opener, then pay, notice, location and why you are moving | High. The relationship prior for a recruiter screen is Conversational plus a light Skeptic, and nothing about this recruiter moves it | A 90-second arc built only from your quoted sentences (R1A1); treat casual questions as scored; never answer "I think you've covered everything" to the questions slot |
| Skeptic (light) | Knockout checks on the two gaps you named | Low. It is the second half of the same prior; the gaps are F4 and F8 | Say the plain acknowledgment first, then a plan, in your own words |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc made of your own sentences, in this order: the six years in retail banking and the last three as a branch supervisor; handling the branch's formal complaints log and training new tellers on the escalation script; building the monthly complaints spreadsheet your regional manager uses. Tell each at that scope and stop; the pack adds no reason or outcome to any step, so any you give are yours. Finish on why this role, in your own words | The biography question opens most screens; F1, F2, F5 and F6 are the rows an arc can carry honestly |
| R1A2 | "The role asks for four-plus years in financial-services customer operations. How does your background line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Lead with the quote in your own terms: six years in retail banking, the last three as a branch supervisor. Add nothing to it; expect a follow-up on what the years held, which only you can answer, at the scope of what you did | The first requirement on the JD's list, and F1 is its row; JD because it scores the stated requirement |
| R1A3 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own figure, or ask for the role's band first. The pack supplies no figure | Recruiters ask pay at the screen, and the only safe answer is your own; no claim about your history is made |
| R1A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period | A knockout-style logistics check; the answer is yours alone |
| R1A5 | "Where are you based, and is getting to our sites workable?" | JD | [generic] | Logistics slot: say where you are based and what commute or working pattern you can do, in your own words. If the role's base site is not stated, ask which site it is, since eight branches are due to become five hubs over 2027 (G2) | Location is a logistics slot at a screen; the hub consolidation is why the base site may matter |
| R1A6 | "What's behind looking for a move now?" | EXP | [generic] | Logistics slot: give your own reason in a sentence. The pack supplies none, and any reason you rehearse must be one you can stand behind under a second question | The reason for leaving is a logistics slot at every recruiter screen; EXP because it tests consistency with the rest of your story |
| R1A7 | "What do you know about Ashgrove, and what drew you to it?" | CO | [grounded] | Name one of the four values by its published name, for example "Plain Words" or "Own the Fix", and one line from the July 2026 brief, for example the 40% of member service moving to digital channels by 2028 (G1). What drew you is your own reason and is not supplied here | The screen is where preparation shows first; the values and the brief are provided documents, so both are grounded |
| R1B1 | "The role covers the contact centre, and you haven't worked in one. How do you see that part of it?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say the plain version first: "I haven't worked in a contact centre." Then a plan, never a past: what you would want to learn first about how complaints move through the contact centre, and who you would ask, in your own words. Stop there. Round 2 has the deeper version (R2A1) | The negative is one you stated, so it can be asked straight; F4 is the row. JD because it scores the contact-centre half of the duty |
| R1B2 | "The role presents to senior leaders. What's your experience at that level?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say it plainly: "I've never presented to anyone above regional level." Then say how you would prepare, as a plan: what you would ask about the audience and the format first. Do not fill the gap with a presentation your material does not show. Round 2 has the build (R2A4) | F8 is a stated gap; a rehearsed plain acknowledgment beats a surprise at the panel. JD because it scores the stated requirement |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1V1 | "Who sits on the final panel, and which branches do they run?" | It signals you have noticed the panel is also the values round |
| R1V2 | "Is the case handed over on the day or shared beforehand, and is there anything I should bring?" | It gets the case format, which the email does not give, and shows you are preparing for it |
| R1V3 | "Who are the senior leaders the monthly report goes to?" | It settles what the JD's phrase means for F8 before you prepare for the wrong audience |
| R1V4 | "Which site would the role be based at once the hubs are in place?" | It ties your logistics answer to the brief (G2) |
| R1V5 | "What would the Head of Member Services most want changed in this process by the end of the first year?" | It gets the manager's priority before round 2 and shows you are thinking at the role's altitude |

---

## Round 2: Head of Member Services, your future manager (45 minutes, mostly behavioural)

### Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes tied to the published values, STAR-shaped | High. The recruiter calls the round mostly behavioural; the themes come from the pasted values page | Map a story where one of your quoted sentences carries one; where none does, use the selection scaffold and its honest branch |
| Skeptic | Quiet probing of the gaps in F3, F4, F6 and F8 | High. A hiring-manager prior is Case plus Skeptic; this manager is buying capability and weighing gaps | Rehearse R2A1 until it is boring; hold, then concede exactly |
| Case / Strategist | A live problem from the role or the brief | Low-medium. The prior is high, pulled down because the round is mostly behavioural | Clarify, objective, segmentation, approach, metrics, risks; challenge one premise respectfully |
| Data-Driven Prober | Line-by-line questions on the spreadsheet | Low. Your material has two reporting sentences and no figures, so there is little to probe | Say what the quote says, and say plainly what you do not know about how anything was counted |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2A1 | "You handled your branch's formal complaints log, and you haven't worked in a contact centre. This role owns the process across branches and the contact centre. Which part would you be weakest at on day one?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | The highest-ROI rehearsal in this pack. Name the limit before it is asked: your material shows a branch's log and no contact-centre work, and neither is stretched. Hold: "I handled the branch's formal complaints log." Concede exactly: "I haven't worked in a contact centre." Then a plan, never a past: what you would learn first, from whom, and what you would not change until you had. Expect three follow-ups: how you would earn the contact-centre team's trust; whether you would be learning on members; what you would not touch in the first month. Hold through the first two by returning to the log, never by adding to it. Answer slot: the JD's end-to-end line makes a probe on stages beyond the log likely. If any stage was yours to set, say which and how you decided; if there was no such step, or it was not yours, say so plainly and return to the log you handled | F3 and F4 are the widest gaps against the role's central duty, so this objection arrives in some form; the deepest rehearsal means three follow-up levels and the concession worded in advance. JD because it scores the stated duty, delivered as a Skeptic probe |
| R2A2 | "The role needs experience handling regulated complaints. What did handling your branch's formal complaints log involve?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what the quote says: "I handled the branch's formal complaints log." Answer slot: if the log was kept to external rules, say which and what they meant for how you handled a complaint, in your own words; if it was an internal log, or the rules sat with someone else, say so plainly and stay with the log you handled. Hold through two follow-ups by returning to the log | F2 is where the JD's regulated line presses; the question premises only what the quote carries, and the slot lets the premise be false. JD because it scores the stated requirement |
| R2A3 | "You trained new tellers on your escalation script. The role is coaching branch supervisors on escalations. What would be different?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what the quote says: "I trained new tellers on our escalation script." What would differ is a plan, in your own words, not something you have done. Answer slot: if you have guided other supervisors on an escalation, say who and how; if not, say so plainly and stay with the tellers you trained | F6 is adjacent work, not the duty itself; a collegial Skeptic probe tests whether the candidate knows the difference. JD because it scores the coaching line |
| R2A4 | "Imagine the monthly complaints report goes to our senior leaders for the first time. How would you present it?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Start with the plain version: "I've never presented to anyone above regional level." Then build the answer as a plan in your own words: what the leaders need to decide, the JD's two measures first, volumes and resolution times, said in plain words, and what you would ask the Head about the format before you build anything | F8 and the reporting duty meet here (F5); the premise is a hypothetical, so nothing about your past is assumed. JD because it scores the stated requirement, with CASE delivery |
| R2B1 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick one problem you stayed with from the moment you found it to its close. It needs a named stake, what you did yourself, and where it closed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I handled the branch's formal complaints log", or how you would handle it | Own the Fix is a published value and the role's core duty; no sentence of yours carries a story for it, so this is a scaffold |
| R2B2 | "Tell me about a time something needed explaining more than once." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a time you explained something to a member or a colleague and had to put it differently the second time. It needs what was unclear, what you changed, and what they then understood. If none comes to mind, say so plainly, then give the nearest thing your material carries, "trained new tellers on our escalation script", or how you would handle it | Plain Words is a published value and its own wording is about explaining twice; F6 is the nearest row and carries no such story |
| R2B3 | "When did you put a member ahead of an internal number?" | VAL | [grounded] | Selection scaffold: pick a decision where the member's interest and a target or a rule pulled apart. It needs the decision you made, what it cost, and what happened. If none comes to mind, say so plainly, then say how you would handle it | Members First and Neighbours, Not Numbers both point here; the stem is a standard Behavioral probe. No claim about your past is made |
| R2B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs what the truth was, how you said it in plain words, and what happened to the relationship afterwards. If no such time comes to mind, say so plainly, then say how you would handle it. Choose a story where the truth landed; do not supply an ending your memory does not hold | A standard Behavioral probe the manager may use to test composure with seniors; it connects to F8's stated limit, so the honest branch matters |
| R2C1 | "Ashgrove wants 40% of member service on digital channels by 2028. If members could raise and track a complaint in the app, what would you want to know before designing it, and what would you keep with a person?" | CASE | [grounded] | Think aloud: clarify what the 40% counts and what the digital team already has; objective, members can raise and track while someone still keeps hold of the fix; segment complaint types by how hard they are to describe in a form; approach; metrics, the JD's volumes and resolution times plus a plain-words check on every message; risks, with app-only banks as the competitive frame (G4). Bring the 40% to show grounding, then one divergence of your own with a concession. Challenge one premise respectfully | The JD names digital teams and self-service journeys (F7), and the brief is the live material; the brief is shared with rival candidates, so differentiate rather than recite. CASE because it is a live problem, JD because it scores F7 |
| R2C2 | "Eight branches are consolidating into five hubs over 2027. What happens to complaints that are open when a branch closes?" | CASE | [grounded] | Think aloud: clarify who holds each open complaint and what the member has been told; objective, the member never has to explain twice and the person who found the problem keeps hold until it is solved; approach for the handover; what you would record; the risk of a complaint falling between two sites. No claim about your past is needed | G2 is the consolidation fact, and Own the Fix and Plain Words are the values it tests; CASE because it is a live problem |
| R2D1 | "Walk me through what your monthly complaints spreadsheet showed." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what the quote says: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times. If it counted either, say how, in your own words; if it tracked something else, or someone else set the measures, say so plainly and stay with the spreadsheet you built | F5 is the row a reporting-minded manager probes first; EXP because it tests what was yours |
| R2D2 | "The role says Excel reporting. Which tool was it, and what did the sheet do?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Name the tool plainly. Answer slot: if it was Excel, say so and describe what the sheet did, in your own words; if it was another tool, say that plainly and stay with the sheet you built | F9: the quote says spreadsheet, not Excel, so the tool will be asked. JD because it scores the stated requirement |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2V1 | "Where does the complaints process hurt most today between the branches and the contact centre?" | It tests the end-to-end duty without presuming an answer |
| R2V2 | "Which digital self-service journeys touch complaints first?" | It ties directly to F7 and G1 |
| R2V3 | "What would you want to see from me by the end of my first ninety days?" | It invites the manager to state the bar and lets you ask about the ramp |
| R2V4 | "How are monthly volumes and resolution times reported today, and to whom?" | It maps the reporting duty (F5, F8) before you are asked to own it |
| R2V5 | "How will the move to five hubs change who coaches whom on escalations?" | It joins the coaching duty (F6) to the brief (G2) |

---

## Round 3: panel of two branch managers, including the values round (60 minutes)

The panel scores against the four values. Twenty of the sixty minutes are a case on a complaint escalation.

### Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes against the four values, STAR-shaped | High. The recruiter says the panel is also the values round | One story attempt per value (cheat sheet below); "we" for context, "I" for contribution |
| Case / Strategist | The 20-minute escalation case | Medium-high. A third of the session is the case, so it outweighs a normal mid-weight | Clarify before structuring; think aloud; challenge one premise respectfully |
| Peer Evaluator | Seam-splitting, "what would you need from us" | Medium. Inferred from the JD's coaching line: the panel's branches are where the role's coaching lands | Reciprocity first; propose seam principles, not a seam you cannot know |
| Skeptic | The gaps returning in collegial packaging | Low. The panel is values- and case-led, but F4 and F6 still return | The same hold and concession as R2A1 |

Interviewer names are not assigned, so personas are not yet split per member.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3A1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold: pick a decision made at the counter where the easy answer was not the member's. It needs the decision, what it cost, and what the member saw. If none comes to mind, say so plainly, then say how you would handle it | Members First, Always is a published value, quoted from the pasted page; no sentence of yours carries a story for it |
| R3A2 | "Tell me about a time you made something clearer for a member." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a time you changed how something was said or written because it needed explaining twice. It needs what was unclear and what changed. If none comes to mind, say so plainly, then give the nearest thing your material carries, "trained new tellers on our escalation script", or how you would handle it | Plain Words says if a member needs it explained twice, it was written wrong; F6 is the nearest row and carries no such story |
| R3A3 | "Tell me about a time local knowledge of a branch or its town changed what you did." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Selection scaffold: pick a case where what you knew about the town or its members changed a decision. It needs the decision and what it changed. If none comes to mind, say so plainly, then give the nearest thing your material carries, "the last 3 as a branch supervisor", or how you would handle it | Neighbours, Not Numbers is a published value; F1 is the nearest row. Eight branches becoming five hubs (G2) may make this live for a branch manager |
| R3A4 | "Tell me about a time you kept hold of a problem you found, until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a problem you found and stayed on. It needs a named stake, what you did yourself, and where it closed. If none comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", or how you would handle it | Own the Fix is a published value and the role's core duty; it repeats R2B1 on purpose, because the panel scores it |
| R3B1 | "A member has complained three times about a charge they say was wrongly taken. The branch says it's resolved; the contact centre's note says it isn't. The supervisor wants to close it. Walk us through your next hour." | CASE | [generic] | Think aloud. Clarify: what the member is asking for in their own words, what each side has told them, and which rules and time limits apply, which you would check rather than assume. Objective: the member hears one voice and one answer. Who keeps hold: the person who found it, until it is solved. Challenge one premise: resolved is not closed. A plain-words reply to the member; what you would record; the coaching for the supervisor afterwards | The announced case is on a complaint escalation across branch and contact centre; a pattern for the problem, not a fact about Ashgrove. No claim about your past is made |
| R3B2 | "A branch supervisor escalated a complaint late and says the escalation script was unclear. How do you handle the supervisor, and the script?" | CASE | [generic] | Think aloud. Clarify what was unclear, what the script says at that point, and whether anyone else was caught by it. Objective: the supervisor can escalate on time and the script is fixed if it is wrong. Approach: coach and fix are two jobs, so say which comes first and why. Metrics: how you would know it worked. No claim about your past is needed | The JD's coaching line (F6) as a live problem; Plain Words applies to a script as much as to a letter |
| R3B3 | "Which complaints would you keep out of digital self-service, and why?" | CASE | [grounded] | Bring the brief's 40% to show grounding (G1), then one divergence of your own with a concession, and the anti-pick: name one complaint type you would not move yet and the reason, in your own judgement. Clarify what self-service would cover before you answer | The role's job includes saying no, and the brief is shared with rival candidates, so a defended divergence beats a recitation. CASE because it is a live problem, CO because it uses the strategy |
| R3C1 | "You'd coach our branch supervisors on escalations. Where's the seam between your coaching and our management, and what happens when we disagree?" | JD | [generic] | Propose principles, not a seam you cannot know: the branch manager stays the supervisor's manager; you own the process and the coaching on it; say what you would ask the panel about how they work today. For disagreement, pick a time you disagreed with a peer or a manager and kept the relationship; it needs the disagreement, what you did, and what it cost. If no such time comes to mind, say so plainly, then say how you would handle it | The Peer Evaluator probe on the seam, and the JD's coaching line (F6); the panel manages the people you would coach |
| R3C2 | "What would you need from us in your first month, and what would you give us?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Lead with what you bring: say the fact, "6 years in retail banking, the last 3 as a branch supervisor", and let the panel draw the inference. Then what you need from them, in your own words | Reciprocity framing for peers; F1 is the only sentence of yours that carries the branch side |
| R3C3 | "How do you handle credit and blame when a complaint spans a branch and the contact centre?" | VAL | [generic] | Say how you would work, in your own words, using the published value as the frame: whoever finds the problem keeps hold of it until it is solved, so credit and blame follow the fix rather than the team. If you have a time it happened, say so; if not, say so plainly and stay with how you would handle it | The standard credit-sharing probe, joined to Own the Fix |
| R3D1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | The same hold and concession as R2A1: "I handled the branch's formal complaints log." and "I haven't worked in a contact centre." Keep the plan about what you would learn and what you would ask the panel's branches, in your own words | F3 and F4 return in collegial packaging; this is the same objection, rehearsed in R2A1 |
| R3D2 | "What makes you credible with branch supervisors?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say the facts and let the panel draw the inference: "6 years in retail banking, the last 3 as a branch supervisor" and "trained new tellers on our escalation script". Do not tell them what those facts prove. Answer slot: if you have guided other supervisors on an escalation, say who and how; if not, say so plainly and stay with the tellers you trained | F6 shows tellers, not supervisors, and F1 shows the branch side; JD because it scores the coaching line |

### Values cheat sheet

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No row's evidence carries a story. Selection scaffold: pick a decision where the easy answer was not the member's; it needs the decision, what it cost, and what the member saw. If none comes to mind, say so plainly, then say how you would handle it |
| Plain Words | If a member needs it explained twice, the words were wrong | No row's evidence carries a story. F6: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Selection scaffold: pick a time you changed how something was said because it needed explaining twice. If none comes to mind, say so plainly, then give the nearest thing the quote carries, or how you would handle it |
| Neighbours, Not Numbers | Each branch is part of its own town | No row's evidence carries a story. F1: "6 years in retail banking, the last 3 as a branch supervisor." Selection scaffold: pick a case where local knowledge changed a decision. If none comes to mind, say so plainly, then give the nearest thing the quote carries, or how you would handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | No row's evidence carries a story. F3: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Selection scaffold: pick a problem you found and stayed on; it needs a named stake, what you did, and where it closed. If none comes to mind, say so plainly, then give the nearest thing the quote carries, or how you would handle it |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3V1 | "What could a new person in this role do in their first month that would genuinely help your branch?" | The reciprocity question for peers; it turns the panel from judges into customers of the role |
| R3V2 | "Which escalations reach you most often, and what do you most want to hear back?" | It shows you think of branch managers as the people the process serves |
| R3V3 | "Where does the escalation script get in the way for your supervisors?" | It goes straight at Plain Words and the coaching duty |
| R3V4 | "What does your branch's place in its town ask of how complaints are handled?" | It answers Neighbours, Not Numbers from their side of the counter |
| R3V5 | "Which of the four values is hardest to hold in a branch on a busy day?" | It shows you read the values and invites a real story you can respond to |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: the material says the branch's log, not the process across branches. R2A1's slot stays inside the log |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope. The material says a formal complaints log, not which rules it was kept under. R2A2's slot asks only about the log |
| Has contact-centre experience | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot |
| Coached branch supervisors on escalations | Inflated form of F6 | F6's quote at its own scope: "I trained new tellers on our escalation script." The slots in R2A3 and R3D2 stay with the tellers |
| Reported on complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope: a monthly complaints spreadsheet your regional manager uses. R2D1's slot asks only what it showed |
| Built the complaints reporting in Excel | Inflated form of F9 | F9's quote at its own scope. The material says spreadsheet, not Excel. R2D2's slot lets either answer stand |

---

## Sources

Provided documents:

- The job description, pasted
- Ashgrove's four values, copied on 20 November 2026 from ashgrovecu.org/about/values and pasted; not fetched
- The recruiter's email on the three rounds, pasted
- The July 2026 strategy brief, as you summarised it in four points; the brief itself was not supplied to me
- Your background, in your message
- No tuesday-dossier.md was present

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values page fixes the four value names, the cheat sheet and the VAL themes |
| 2. `Ashgrove Credit Union interview process member services` | skipped | The recruiter's email fixes the loop: three sessions and who runs each; persona weights follow it |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief you summarised supplies the CO and CASE material and is under six months old |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer names are assigned, so there is no query to form; the interviewer read is absent and the upgrade menu says what names would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Interviewer names for rounds 2 and 3 → an interviewer read, persona weights per panel member, and a reverse question tied to their own path
- The recruiter's answers on the case format, who the senior leaders are, and the panel's branches → the R1 reverse questions answered, and a build for the case if it is handed over beforehand
- The rules your complaints log was kept under, in your own words → F2 and R2A2 move from an answer slot to a story-mapped answer
- What your monthly spreadsheet counted and which tool it was built in → F5 and F9 upgrade, and R2D1 and R2D2 become story-mapped
- Any figures you can state about it, such as complaints per month or time to resolve → defend-the-number rows, which are not built today because you gave no figures
- Any occasion you guided a supervisor on an escalation → F6 and R2A3, R3C1, R3D2 become story-mapped
- Any work with a digital team, even small → F7 and R2C1
- Any story for each of the four values, said in your own words → the values cheat sheet and R2B1 to R2B3, R3A1 to R3A4 become story-mapped
- The strategy brief's full text → the grounding brief rests on four points today
- Your prep time → a prioritised schedule
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → role-family loop reports, org context, and interviewer footprints once names exist
- A tuesday-dossier.md from an earlier role check → verified evidence and gap strategies sharpen the pack; this pack does not need one
