# Interview pack: Product Manager, Platform APIs at Quartzline

- **Role:** Product Manager, Platform APIs, Quartzline
- **Round:** one 45-minute conversation with the hiring manager (session mode). Interviewer name not given, so there is no interviewer read.
- **Built on:** your note on the round, plus `tuesday-dossier.md` (job-underwriter, dossier_version 1.1, dated 2026-08-14). No web research ran in this build, so nothing here is about Quartzline's values, loop or strategy.

## How to use this pack

Personas are how a question arrives. Types are what it is scored on. Guidance is scaffolding for a spoken answer, not a script: every claim about your past comes from a sentence quoted in that row, and anything the material does not carry is an answer slot you fill from what actually happened, in your own words.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behavior shows the company's published values (not used here, see the persona table) |
| EXP | Whether your claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (not used here, no research ran) |
| CASE | Structure and reasoning on a live problem from the role |

## Fit snapshot

The dossier carries no evidence map, only `handoff_to_mock_interview` and `role_profile`. F1, F5 and F6 take their confidence and gap type from the dossier's `uncertain_or_weak_areas`. F2, F3 and F4 are not in that list, so their grades are this pack's own calls.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD, via dossier R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [grounded] | transferability | Bridge, with its limit named: the underwriter positions this as adjacent, never as product management experience. The words stay at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." The limit is the pack's observation: your material shows integration delivery and no product management title. The plain acknowledgment is sourced by the dossier field prohibited_claims: "Having held a product manager title or role", so the words are "I haven't held a product manager title or role." |
| F2 | "Shipped API or platform products" — JD, via dossier R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quote touches the requirement without showing whether it reaches it, and the bridge should not be stretched: say the quote at its own scope. Answer slot: the JD's R2 line makes a probe on what you shipped likely. If you shipped anything beyond those integrations, say what it was and what part was yours, in your own words; if you did not, or it was not yours, say so plainly and stay with the integrations you led |
| F3 | "Technical fluency: API docs, schemas" — JD, via dossier R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | medium | [inferred] | discovery | The dossier grades both claims high and inspectable, but it does not grade them against R3, so this row is the pack's own call. Say both at their own scope: "I wrote the internal integration playbook my team uses." Answer slot: R3 names API docs and schemas, so expect a probe on your own hands-on work with them. If you wrote or reviewed any, say which and what your part was; if not, say so plainly and stay with the integrations and the playbook |
| F4 | "Stakeholder management across engineering, sales, customers" — JD, via dossier R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | discovery | Clients and product are what the quotes carry; engineering and sales are not shown. The dossier grades the sessions claim medium: confirmed, limited inspectable proof, so expect a probe, and volunteer that limit in your own words before it is extracted. Answer slot: if engineering or sales were part of those integrations or sessions, say how you worked with them; if they were not, say so plainly and stay with the clients and product |
| F5 | "Agile delivery experience" — JD, via dossier R5, preferred | none given | low | [grounded] | discovery | No verified entry speaks to this requirement itself, so there is no quote to bridge from. Answer slot: the JD's R5 line makes "how do you define agile delivery here" the likely probe. If you worked in an agile cycle, say how, in your own words; if you never worked that way, say so plainly and say what you would want to confirm about how the interviewer defines it |
| F6 | "Owning a roadmap and prioritization authority (R1 sub-claim)" — dossier uncertain_or_weak_areas | none given | none | [grounded] | capability | The underwriter found nothing here and marked it acknowledge_gap, so no bridge. The plain acknowledgment is sourced by the dossier fields prohibited_claims: "Having owned a product roadmap" and prohibited_claims: "Having set prioritization for an engineering squad", so the words are "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan said as a plan, never as a past |

## Persona table

The round is the hiring-manager round you described. The weights are the hiring-manager relationship priors (Case/Strategist plus Skeptic), adjusted by the dossier's own objection and open questions. No company loop source was read, so the weights rest on that pattern and not on Quartzline's documented process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Case / Strategist | Live problems on the role: adoption, two squads, first 90 days | High. Hiring-manager prior, and the role's responsibilities are about roadmap, squads and adoption | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully | A1 to A5 |
| Skeptic | Quiet, persistent probing of the title and roadmap gap | High. Hiring-manager prior, and the underwriter named this objection (B1) | Rehearse B1 until it is boring; bridge only from what the quotes carry, with the limit said first | B1 to B5 |
| Data-Driven Prober | Line-by-line on the CV: the 30+ figure, the sessions, technical depth | Medium. There is one headline figure and one medium-confidence claim to probe | Know what you can and cannot say about how the 30+ was counted; say plainly when you do not know | C1 to C3 |
| Peer Evaluator | Where you sit relative to the two squad leads, and how you disagree | Medium. The dossier flags squad authority as unresolved, so the manager may test it | Propose seam principles instead of pretending to know the seam; reciprocity framing | D1 to D3 |
| Conversational | "Walk me through the journey" | Low. An opener, but still scored | A 90-second arc built only from the quotes | E1 to E2 |
| Pressure | Time-boxed "why you" and attribution challenges | Low. Less typical of a manager round, but B1 can arrive in this register | Pause, restate, hold two follow-ups, concede only what is true | F1 to F2 |
| Values / Behavioral | Not banked | No values-style round is detected: your note names one conversation with the manager, and no published values were read | Not applicable | none |

## Question banks

The hardest preparation is B1: it is the objection the underwriter named, it will arrive in some form, and it gets the deepest rehearsal here.

### A. Case / Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Suppose partner adoption of the platform's APIs has stalled. What do you need to know first, and how would you diagnose it?" | CASE | [generic] | Clarify before structuring: ask what adoption means here and what the current baseline is, as questions to put to the interviewer. Then objective, segmentation (which partners, which APIs), competing hypotheses (docs, onboarding, product gaps, partner priorities), what data would separate them, risks. Think aloud and challenge one premise respectfully. The question asks nothing about your past, so the guidance makes none | The role names adoption metrics as a responsibility and the dossier says no baseline is stated, so a live adoption problem is likely. CASE because the hiring-manager round tilts to live problems; `[generic]` because it is a pattern for the problem, not a fact about Quartzline |
| A2 | "Two squad leads disagree about what to build next: one wants new endpoints, the other wants to fix partner onboarding. How do you decide?" | CASE | [generic] | Structure the decision: what evidence each lead is relying on, what partners are actually blocked on, what each option costs and unlocks, how you would reach a decision with both leads. Say aloud that who holds the final call is the thing you would confirm first, which is also reverse question RQ1. Hold this as a proposal of how you would work, not a claim about decisions you have made | The dossier flags decision authority versus the two squad leads as unevidenced, so a manager may test it with a scenario. CASE; the guidance deliberately makes no claim about past prioritization (F6) |
| A3 | "What would your first 90 days look like, and what do you need to learn before you commit to a roadmap?" | CASE | [generic] | This is where the F6 ramp plan lives, said as a future plan only. Name what you would establish first, in your own words: which roadmap decisions belong to the PM and which to the squad leads, how adoption is measured today, and what the partners say are their biggest blockers. Do not describe any of it as something you have done | F6 is a capability gap with no bridge, and the honest answer is a ramp plan. CASE for the delivery, JD for the content |
| A4 | "A partner tells you your API is hard to integrate. How do you find out whether the problem is the docs, the schema design or the onboarding?" | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Structure the investigation: what you would ask the partner, what you would look at, how you would separate the three causes, who you would involve. You may open with exactly what the quote carries and no more: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Then reason the case in your own words | Tests F3 (technical fluency) through a live problem. The quote is the only claim about your past in the answer and it stays at its own scope |
| A5 | "You will own adoption metrics for the platform. What would you put on the first dashboard, and what would it hide?" | CASE | [generic] | Name the one or two metrics you would pick and why, then what each hides (for example, volume without depth), then what you would add next. If you need a baseline to choose, say so and ask what exists. No claim about metrics you have defined before | The adoption responsibility and the open baseline question make this likely; CASE with a data-driven flavour |

### B. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap" | The underwriter named this objection, so it gets the deepest rehearsal. Three beats. Limit first, in the sourced plain words: "I haven't held a product manager title or role, and I haven't owned a product roadmap." The adjacent case, at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live," and "I ran quarterly roadmap-input sessions feeding client evidence to product." Volunteer the sessions' limit in your own words: say what you can and cannot show from them. Then the ramp plan, as a plan: what you would establish first about decision rights and the adoption baseline. Hold through two follow-ups by returning to the integrations and the sessions, never by adding to them. If asked what product did with the evidence, answer only from what you know, and say plainly if you do not know. Never call this product management experience | The dossier's own objection (F1 and F6). JD because it scores the must-have R1. The negatives in the Question are sourced by the dossier fields prohibited_claims and acknowledge_gap, so it is asked as written |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] prohibited_claims: "Having owned a product roadmap"; prohibited_claims: "Having set prioritization for an engineering squad" | Name it yourself before they do. Your material shows no evidence for roadmap ownership or squad prioritization, and the sourced plain words are "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Follow with the ramp plan from A3, in your own words. No bridge on this one: the dossier marks it acknowledge_gap, and a bridge improvised live is how a candidate gets caught. Hold the answer through two follow-ups without softening it | F6 is the clearest gap and this stem asks for it directly. JD; Skeptic's standard stem |
| B3 | "Tell me about a time you delivered work in an agile cycle." | JD | [grounded] | The dossier marks this clarify, and no verified entry speaks to agile delivery, so there is no quote to build on. Answer slot: the JD's R5 line makes a probe on how you define it likely. If you worked in an agile cycle, say how, in your own words; if you never worked that way, say so plainly and say what you would want to confirm about how the interviewer defines agile delivery here | F5. It is a preferred requirement, so the stakes are lower; JD |
| B4 | "When have you shipped an API or platform product?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The nearest quote is the integrations, and it is nearby evidence, not shipping a product. Say it at its own scope and do not call it shipping the platform. Answer slot: if you shipped anything beyond those integrations, say what it was and what part was yours, in your own words; if you did not, or it was not yours, say so plainly and stay with the integrations you led | R2 is a must-have and the quote only touches it (F2). JD |
| B5 | "Why are you looking to move from integration delivery into product management?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The pack holds no reason from you, so the answer is yours. It needs a real reason in your own words, a concrete thing the role lets you do, and nothing that sounds like a complaint about your current work. If no single reason comes to mind, say so plainly, then give the nearest thing that is true | Motivation consistency is what the Skeptic scores. JD because it tests whether the move to this role is reasoned |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the 30+ integrations. What counted as one?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend the number. The 30+ attaches to client integrations and nothing else. Answer slots, each in your own words: how it was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how a figure was counted, say so plainly. The dossier grades this claim high and inspectable (the integration playbook), so you can offer to point to it | Every headline figure gets a defend-the-number question. F1's evidence is built on it |
| C2 | "Walk me through how one of your quarterly roadmap-input sessions ran, and what you fed to product." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Tell it with only the beats the quote states: you ran them, they were quarterly, they fed client evidence to product. The dossier grades this medium: confirmed, limited inspectable proof, so expect a probe, and say the limit yourself in your own words. Your material says the evidence went to product, not what product did with it, so do not describe outcomes you did not state | The weakest-proof claim in the dossier and the one a prober will test (F4). EXP |
| C3 | "Walk me through what happens at go-live on one of the integrations you led." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Stay with the stages the quote names: scoping, requirements, architecture, UAT, go-live. Answer slot: R3 names API docs and schemas, so expect a probe on your hands-on work with them. If you wrote or reviewed any, say which and what your part was; if not, say so plainly and stay with the stages and the playbook you wrote | Tests F3 for depth. EXP because it tests what you did, JD because R3 is the stated requirement |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You and the two squad leads will overlap on what gets built. Where is the seam, and what happens when you disagree?" | CASE | [generic] | Propose seam principles, not facts: who owns the why and the what, who owns the how, how a disagreement gets decided and recorded. Say that where the final call sits is what you would confirm, which is RQ1. Offer reciprocity: what you would bring the squads (a partner's view, a clear decision record), not only what you need from them. No claim about past decisions | The dossier flags squad authority as unevidenced. CASE for delivery; guidance makes no claim about your past (F6) |
| D2 | "Tell me about a time you disagreed with an engineer or a product colleague, and how it resolved." | EXP | [generic] | No quote carries a disagreement, so this is a selection scaffold. Pick a real instance with a named stake, a moment you held your view, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer evaluators ask about disagreement with equals. EXP because it tests what you did |
| D3 | "Tell me about a time engineering, sales and a customer wanted different things from the same piece of work." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | The quotes carry clients and product, not engineering or sales. Answer slot: R4 names all three groups, so expect a probe on the other two. If engineering or sales were part of an instance, say how you worked with them and what part was yours; if they were not, say so plainly and use the instance your quotes carry. If no instance comes to mind, say so plainly | F4. JD because R4 is the stated requirement |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, each at its quote's scope: you led the integrations, you wrote the playbook your team uses, you ran the roadmap-input sessions that fed client evidence to product. Then one sentence on why this role, in your own words. The pack holds no durations, so add none | An opener, but scored for economy. EXP; the arc rests only on quotes (F1, F3, F4) |
| E2 | "What do you want to be doing in this role a year from now?" | JD | [generic] | A selection scaffold: pick something concrete about the platform or its partners that you would want to have changed, and say why it matters to you. If you do not yet know enough about the platform to say, say so plainly and say what you would want to find out first | A casual question that is still scored. JD because it tests whether you understand the job |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a candidate who has held the PM title?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; prohibited_claims: "Having held a product manager title or role" | Pause, restate the question, answer in order: the plain words "I haven't held a product manager title or role," then "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Hold through two follow-ups by returning to that sentence. Concede what is true and never add to the claim to restore harmony | B1 in a time-boxed register. JD because it scores R1 |
| F2 | "That playbook — how much of it was actually you?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Hold at the quote: "I wrote the internal integration playbook my team uses." If others contributed, say so plainly and say what was yours, in your own words. Do not add anything to the claim, and do not shrink it below what the quote says. The dossier grades this high and inspectable, so you can offer to show it | An attribution probe on the most inspectable claim (F3). EXP |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1: "3+ years product management experience" | B1, B2, F1 |
| R2: "Shipped API or platform products" | B4 |
| R3: "Technical fluency: API docs, schemas" | A4, C3 |
| R4: "Stakeholder management across engineering, sales, customers" | D3, A2, D1 |
| R5: "Agile delivery experience" | B3 |
| R1 sub-claim: roadmap and prioritization authority | B1, B2, A3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier records decision authority versus the two squad leads as asserted in the JD but not evidenced. It reads as diligence, and the answer is something you need before accepting |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier records adoption metrics as a named responsibility with no baseline stated. It shows you think in metrics, and the answer tells you what success is measured against |
| RQ3 | "What would a strong first quarter look like here, and what would tell you it was going badly?" | It asks the manager to define the bar in their own terms, and gives you the chance to address any concern about the title gap directly |
| RQ4 | "How do the two squads take partner feedback into their plans today, and where does that get stuck?" | It follows from the discovery responsibility and surfaces how much of the PM's job is building a process versus using one |
| RQ5 | "What would you want to see from someone coming from an integration background to feel confident in the hire?" | It converts the objection in B1 into a conversation, and the answer tells you what the manager is actually weighing |
| RQ6 | "How do planning and review work between the PM and the two squads in practice?" | A concrete follow-on to RQ1 that tests whether your agile-delivery answer (B3) matches how they actually work |

## Prohibited claims

Built from the dossier's `prohibited_claims`, plus inflated forms of your quoted sentences found while writing the banks.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | F1's quote at its own scope. The plain acknowledgment: "I haven't held a product manager title or role." |
| Having owned a product roadmap | Dossier prohibited_claims, and the F6 acknowledge_gap area | The plain acknowledgment: "I haven't owned a product roadmap." No bridge, no slot |
| Having set prioritization for an engineering squad | Dossier prohibited_claims, and the F6 acknowledge_gap area | The plain acknowledgment: "I haven't set prioritization for an engineering squad." No bridge, no slot |
| Influenced or shaped the product roadmap | Inflated form of F4's sessions quote | The quote at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product." The limit is the pack's observation: the material says the evidence went to product, not what product did with it |
| Ran product discovery with partners | Inflated form of F1's "scoping, requirements" | F1's quote at its own scope. The limit is the pack's observation: the material says client integrations, not product discovery |

## Sources

- **Provided:** `tuesday-dossier.md`, pasted by you, dossier_version 1.1, generated 2026-08-14. Consumed: `handoff_to_mock_interview` (verified evidence, weak areas and strategies, the objection, risks, employer questions, prohibited claims) and `role_profile` (requirement text and priorities). `decision` was read as context only.
- **A note on the dossier:** its decision text mentions "seven years of integration leadership", but no verified entry states a duration, so no cell here uses it.
- **Searches sent, all refused (permission not granted):**
  - `Quartzline company values` — refused
  - `Quartzline interview process product manager` — refused
  - `Quartzline API platform strategy news` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Search refused. It would have fed a values cheat sheet and VAL questions; the pack has none |
| 2. `Quartzline interview process product manager` | unavailable | Search refused. It would have confirmed the loop; persona weights rest on the hiring-manager priors and your note instead |
| 3. `Quartzline strategy` / recent news | unavailable | Search refused. It would have grounded a CO or CASE question in current strategy; A1 to A5 are `[generic]` for that reason |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` requirement text already fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web search permission → a values check, the documented loop and a strategy sweep; CASE questions tied to Quartzline's current priorities. A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) can follow once search is allowed
- The interviewer's name → an interviewer read, persona weights read from their public footprint, and a reverse question tied to their own path
- Your answers to the slots in F2 to F5 → those rows are regenerated from your own words, and B3, B4, C3 and D3 move from slots to story-mapped guidance
- A session agenda or write-up from the roadmap-input sessions → F4's medium confidence can rise, and C2 gets firmer ground
- Your actual tenure in integration work, in your own words → E1 and F1 can carry a duration; none is used now
- The recruiter's prep email → any stated focus areas or pre-declared deliverable, which the pack would then cover in its own section
- Prep time available → an ordered prep schedule sized to it, instead of the full pack
- The current posting, if it has changed since the dossier's 2026-08-14 date → F1 to F5 and the coverage table are checked against it
