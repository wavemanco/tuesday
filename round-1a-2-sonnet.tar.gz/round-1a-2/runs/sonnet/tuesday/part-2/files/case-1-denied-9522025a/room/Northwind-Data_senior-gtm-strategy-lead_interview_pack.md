# Interview prep pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, a peer (both report to the same VP). **Round:** one 60-minute conversation with Dan.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did. An answer slot is an instruction for the interview, not a question for this conversation.

| Type tag | Meaning |
|---|---|
| VAL | Behavioral and values alignment: whether past behavior shows how you work with others |
| EXP | Work-experience deep-dive: whether the CV claims survive scrutiny and attribution is honest |
| JD | Role and JD-driven: can you do the listed job, including its gaps |
| CO | Company and strategy knowledge: can you think at Northwind's altitude |
| CASE | Hypothetical or live problem: structure and reasoning on a problem from the role |

**Highest-ROI prep in this pack: C1**, the question about no classic sales-ops or quota-setting experience. It will arrive in some form, from a peer whose function that is.

## Fit snapshot

Requirements are the JD highlights as supplied in the coach's notes, quoted as supplied; the full JD was not available. F7 is not a JD line: it is the gap the notes state, set against the interviewer's own function. No gate rows: the highlights name no term such as location, pay or travel, so the material cannot show any gate either way.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | The material says consulting, then product strategy and ops, with nothing inspected behind it and nothing about owning a go-to-market. The words stay at the quote: two years in strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops. Answer slot: the JD's own-GTM line makes a probe on launches likely. If any of that work took something new to market, say what and which part was yours; if none did, or it was not yours, say so plainly and say how you would start |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The quote says a proposal, credited with an uplift. It does not say which lifecycle stage the change acted on, how the figure was counted or how much was yours, and a probe on all four is likely. Words at scope: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slots are in A1, A5 and F2 |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | low | [inferred] | discovery | Naming two tools does not show what was done in them, and the bridge should not be stretched. Answer slot: say which of the two tools you actually use and for what, in your own words; if that is narrower than a probe assumes, or the work was someone else's, say so plainly, and say what you would build first |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a model used in negotiations, with nothing inspected behind it, and the words stay there: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you shaped how the model was used in the carrier negotiations beyond building it, say how, in your own words; if you built it and others used it, or none of that was yours to shape, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap in terms, but a line with nothing inspected behind it, so expect a probe on how the consensus was reached. Lead in the quote's own terms: you set annual volume targets, with cross-org consensus. Keep "targets" and "cross-org" as written |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Reworded, and nothing added: "I use AI tools every day." Detail is left to E2's slot |
| F7 | Sales-ops and quota-setting fluency, the function of the interviewer (Director of Sales Strategy per the notes); not a JD line | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and the notes state it. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Grounding brief

From your research note, undated. Search access was refused, so its currency was not checked; confirm it is current before relying on it.

| Item | Content | Provenance |
|---|---|---|
| Stated priorities | Enterprise expansion; an AI copilot launch called Compass; reaching profitability | [grounded] |
| Main competitive threat | Bundling by a much larger platform vendor | [grounded] |
| Vocabulary from the JD | Land, adopt, expand, renew | [grounded] |

## Reading the interviewer

Source for every row is the profile as described in the coach's notes. His talks and writing were not read (search refused), so nothing below goes beyond what the profile says.

| Signal | What the notes say | Practical implication |
|---|---|---|
| Self-description | "relentlessly data-driven" | Every number you give will be taken to its assumptions. Know what you can and cannot say about how each figure was counted, and say plainly when you do not know |
| Career spine | Pricing and monetization roles | His native language is packaging, pricing and unit economics. Expect case questions to tilt there (D2, D3) and state a packaging hypothesis early |
| One early-stage startup chapter | One chapter, early-stage | A mild chance of a scrappiness probe about working without a playbook. C4 carries the scaffold |
| Relationship | Peer, same VP | He is pricing what you cost and contribute to his work. Reciprocity beats self-promotion (B4) |

Mirror opportunity, shared vocabulary only: his pricing and monetization path alongside F4's evidence, "built a partner-level revenue model used in carrier negotiations". The quote says a revenue model used in negotiations; it does not say prices were set. Do not stretch it into pricing ownership, and do not build on any shared identity or background.

## Persona table

The loop is established by your own words: one 60-minute conversation with Dan. No loop source documents a values-style round, so none is assumed and there is no values cheat sheet.

| Persona | How it shows up with Dan | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | Reads your lines closely, asks how numbers were counted, goes two levels deeper | Highest. Peer prior, plus the "relentlessly data-driven" self-description, plus a headline figure and a model on your line | Know how each figure was counted and what you cannot say; name the weakest assumption yourself before he does; say plainly when you do not know |
| B. Peer Evaluator | Seam-splitting, what you would need from him, credit across teams | High. The relationship prior for a peer, and he shares a VP with you | Reciprocity framing; propose seam principles, not a pretended seam; disagreement with spine and tact |
| C. Skeptic | Quiet, persistent probing of the gaps and of why leave, why here, why now | High. F7 and F4 are the biggest gaps, the move is consumer to B2B, and his function is where F7 sits | Rehearse the most predictable objection until it is boring; bridges only from adjacent evidence you stated; a concrete ramp plan |
| D. Case/Strategist | Live "how would you think about" problems on Northwind's own priorities | Medium. A peer rarely runs a long case, but his pricing spine tilts any case toward packaging and unit economics | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| E. Conversational | Friendly opener, a casual question on a hot JD topic | Low to medium. An opener is near-certain, but it is two questions deep | Prepare the 90-second arc; treat casual questions on AI as scored |
| F. Pressure | Time-boxes, devil's advocate | Low. A peer round, but a data-driven style can press on attribution | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real |
| Values/Behavioral | Scenario probes against published values | Low. No values-style round is documented; one VAL question sits in bank B | Selection scaffold, with the honest branch |

## Question banks

Total 20 questions, weighted by persona. All Provenance quotes are the coach's notes.

### A. Data-Driven Prober (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You proposed a store-surface change that was credited with about $400M of ARR uplift. Walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open with the sentence the quote carries and keep its verbs, proposed and credited, with no stronger ones. Answer slots, each in your own words: how the figure was counted; what it is most sensitive to; the assumption behind it you would defend least, named before he asks; which part was yours. If you do not know how it was counted, say so plainly. Add no baseline, timeline or method the quote does not state | F2 holds the one headline metric, and a data-driven peer goes to it first. EXP because it tests whether the figure survives scrutiny |
| A2 | "Walk me through the partner-level revenue model you built for the carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4, with the beats the quote states: you built the model, it was partner-level, it was used in carrier negotiations. Tell them in your own words. Answer slot: the JD's independent-analysis line makes a probe on how it was built likely. If you built it yourself, say how; if parts came from others or from a shared source, or you built only part of it, say so plainly and stay with the part you built. If there is an assumption in it you would defend least, name it before he asks; if you do not know, say so | F4 is the evidence for the partner requirement and the second line a prober reads closely. EXP because it tests what was actually yours |
| A3 | "Tell me about an analysis you ran yourself in SQL or Tableau, from the question to the answer." | JD | [inferred] "skilled in SQL/Tableau" | No quoted sentence carries a story, so this is a selection scaffold: choose an analysis you can walk through completely, with the question it answered, what you queried or charted yourself, and what changed because of it. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it. Answer slot: say which of the two tools you actually use and for what, in your own words; if that is narrower than the question assumes, say so plainly | F3 is thin, so this is a scaffold. JD because the JD names the tools; the evidence is inferred from a one-line quote, not from a story |
| A4 | "You set annual volume targets with cross-org consensus. Walk me through that." | EXP | [grounded] "set annual volume targets with cross-org consensus" | The beats the quote states and no more: you set the targets, they were annual, and the consensus was cross-org. Tell them in your own words and keep the quote's word, targets, throughout. Where a follow-up reaches past those beats, say plainly what you did and what you did not, and return to the targets | F5 is the evidence for influence, and F7 is why he will test its scope. EXP because it defends a CV line |
| A5 | "Where in land, adopt, expand and renew did that store-surface change act?" | JD | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Answer slot: the JD's land, adopt, expand and renew line makes this probe likely. If you know which stage the change acted on, say which and how you know, in your own words; if it did not map to those stages, or you did not frame it that way, say so plainly and stay with the change you proposed. Do not place it on a stage you cannot defend | F2 is the only evidence near the whitespace requirement and it names no stage. JD because the question scores the lifecycle requirement directly |

### B. Peer Evaluator (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side — where's the seam between sales strategy and what you'd own, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam: ask what he owns today before saying what you would take on; agree who decides which kinds of calls; work from one shared set of numbers; when you disagree, put both views in writing and take it to whoever you both answer to. The question needs no claim about your past, so the guidance makes none | The peer prior and the shared-VP relationship make seam-splitting near-certain; F5's requirement is the JD side. JD because it scores the stated influence requirement as a live seam |
| B2 | "Tell me about a time you got several groups with competing priorities to agree on something." | JD | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5, with the beats the quote states: you set annual volume targets, with cross-org consensus. Say "we" for context and "I" only for what the quote lets you claim. Answer slot: the JD's influence line makes a probe on who disagreed likely. If there was disagreement, say who and how it was resolved, and what part was yours; if there was none, or the consensus came without any particular step of yours, say so plainly and stay with the targets | F5 is the one influence sentence. JD content with behavioral delivery, because the JD names the influence requirement |
| B3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick an occasion where credit was shared across teams, name who got what and how you handled it; "we" for context, "I" for your contribution. Choose a story where the awkward point actually landed; if your own recollection has none, say so rather than supplying an ending. If no such time comes to mind, say so plainly, then say how you would handle it | A peer scoring partnership fit asks this, and F2 makes it likelier. VAL, with no published Northwind values in hand, so it rests on the persona stem and is generic |
| B4 | "What would you need from me and my team in your first 90 days?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | Reciprocity: say what you bring before what you need, in these words and no more: "I built a partner-level revenue model used in carrier negotiations" and "I set annual volume targets with cross-org consensus". Then the honest ask: "I don't have classic sales-ops or quota-setting experience", so in the first month you would ask to learn how his team works and for access to the data you would work from. That is a plan, not a past | F4, F5 and F7 meet here. JD because it scores whether the hire reduces or adds to the peer's load |

### C. Skeptic (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see classic sales-ops or quota-setting in your background — how would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus" | The deepest rehearsal. Pause, restate it, then say the limit before he asks for it, in the stated words: "I don't have classic sales-ops or quota-setting experience." Only if it helps, the nearest work at its own scope: "I set annual volume targets with cross-org consensus", with no stretch. Then the ramp as a plan, in your own words: what you would ask to learn, and from whom, in the first month. Follow-up one, "Is that enough for a role this close to sales?": hold by restating what your evidence carries and repeating the acknowledgment in the same words. Follow-up two, "What would you get wrong first?" Answer slot: name the thing you expect to get wrong first, in your own words; if you cannot name one, say so plainly rather than inventing one. Concession wording: "That is a real gap, and the plan I gave is how I would close it." Never answer by listing strengths | F7 is the biggest gap and sits in his own function, so this arrives in some form. JD because it scores the role's adjacent competency; it is the pack's highest-ROI prep |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "No classic sales-ops or quota-setting experience" | Choose the weakest part honestly and say it first. F4 and F7 are the two gaps the material shows; pick the one you believe, or a different one if it is truer. If it is the stated absence: "I don't have classic sales-ops or quota-setting experience." Then a concrete ramp plan, in your own words: who you would ask, what you would read, by when. Do not name a weakness you do not have in order to sound modest | A near-universal Skeptic stem, and F4 and F7 are where the material is thin. JD because it scores honest self-assessment against the role |
| C3 | "Partner-motion design is required here. What have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | The hold is only what the quote carries: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you shaped how the model was used in the carrier negotiations beyond building it, say how and why, in your own words; if you built it and others used it, or none of that was yours to shape, say so plainly and stay with the model. Hold through two follow-ups by returning to the model, never by adding to it; concede plainly that your evidence here is the model and say what you would learn first | F4 is the only evidence for a requirement the JD calls required, so this is a hard-requirement JD question. JD because it scores the stated requirement |
| C4 | "Why leave nine years at a large consumer-tech company for a B2B data-infrastructure company of about 3,000 people?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Give your actual reasons in your own words: why leave, why here, why now. The pack supplies none. Keep the history to the quote's beats. Answer slot: if the move to B2B is part of your reason, say so; if it is not, say so and give what is. If he follows with how you work where there is little precedent, use a selection scaffold: pick an occasion where you started without a template, name the stake and what you did; if none comes to mind, say so plainly, then say how you would approach it | F1 is the history he will cross-examine, and his startup chapter makes a scrappiness probe possible. EXP because it tests the CV narrative and motivation consistency |

### D. Case/Strategist (weight: medium, 3 questions, pricing-tilted)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A new data-infrastructure product line is two quarters from launch. Sketch the GTM plan — what do you need to know first?" | CASE | [generic] | Clarify first: what the product is, who buys it, what success is. Then objective, segmentation, approach, metrics, risks. Build the plan across land, adopt, expand and renew, with a metric per stage, and treat a partner route as one lever to test rather than assume. State a packaging and pricing hypothesis early, since pricing is his language. Challenge one premise respectfully, and name the assumption you would defend least. The question needs no claim about your past, so the guidance makes none | The JD's first two lines are this problem, and F1, F2 and F4 are thin on it, so it is the live test of the gap. CASE because it is a live problem; generic because it is a pattern, not a Northwind fact |
| D2 | "Bundling by a much larger platform vendor is our main competitive threat. How would you package and price Compass against it?" | CO | [grounded] | Clarify what Compass is sold as, who the buyer is and what the bundle would include; these are questions to ask, not facts to assume. Then structure: a value metric, packaging, a price floor set by unit economics, and what differentiates against a bundle. Tie it to the profitability priority and say what you would not discount. State a hypothesis early and name its weakest assumption. The question needs no claim about your past, so the guidance makes none | The threat and the product come from your research note, and his pricing spine makes this the likeliest case. CO because it scores strategy fluency; CASE delivery |
| D3 | "Our priorities are enterprise expansion, Compass and profitability. If the two new lines pull against those, how do you decide where GTM effort goes?" | CO | [grounded] | Ask whether the three priorities rank before answering. Then criteria for deciding, segmentation, the metrics you would compare, and the trade-off you would accept; commit to a recommendation and say what would change your mind. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | Tests altitude against the stated priorities, which is the differentiator most candidates cannot touch. CO because it scores company-strategy fluency |

### E. Conversational (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc built only from the quote's beats: two years of strategy consulting at a top firm, then nine years at a large consumer-tech company in product strategy and ops. Answer slot: why each move, in your own words; the pack supplies no reasons. Close by pointing at this role, in your own words, without a claim the quote lacks. A casual register is still scored | F1 is the biography he will open with. EXP because it is the CV in story form |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say it in the quote's terms: "I use AI tools every day." Answer slot: name the tools and what you use them for, in your own words; if your use is narrower than the question assumes, say so plainly and stay with what you do. You can turn it into a question back about how the team thinks about Compass, which is curiosity, not a claim | F6 is the evidence for the plus-skill and Compass makes the probe likely. JD because the JD names AI |

### F. Pressure (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a candidate who has carried quota and run sales-ops?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | Pause, restate, answer inside the time. Hold what the quotes carry, in their words: the model and the targets. Concede explicitly: "I don't have classic sales-ops or quota-setting experience." Then stop; let him draw the inference. If he presses twice, return to the same two sentences and the same concession; do not add strengths and do not fold | F7 makes a time-boxed comparison likely from a data-driven peer. JD because it scores the role's adjacent competency under composure |
| F2 | "That result — how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold at the quote's verbs: "I proposed it, and it was credited with the uplift." Answer slot: say what part of the work after the proposal was yours, in your own words; if the credit was shared, or assigned by others, or you do not know how it was assigned, say so plainly and return to the proposal. Concede specifically, naming what you cannot attribute to yourself, and never fold on the proposal itself | F2 invites exactly this attribution probe. EXP because it tests attribution honesty |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | D1, D2, D3 |
| identify whitespace across land/adopt/expand/renew | A5, D1 |
| run independent analysis in SQL and Tableau | A3, A2 |
| partner-motion design experience required | C3, C2, D1 |
| strong cross-functional influence | B1, B2, B3, B4, A4 |
| AI experience a plus | E2, D2 |
| Not a JD line: sales-ops and quota-setting fluency (F7) | C1, C2, F1, B4 |
| Headline metric on the CV (F2) | A1, F2 |

## Reverse questions

Ask at least three. The reciprocity question matters most with a peer.

| # | Question | Why it lands |
|---|---|---|
| R1 | "You've spent your career in pricing and monetization. How does that shape the way you see GTM for a new product line before its pricing is settled?" | Tied to his own path as the notes describe it, and it turns an interrogation into a peer conversation |
| R2 | "What could a new person in this seat do in the first month that would genuinely help your team?" | The reciprocity question for a peer; it shows you are pricing his load |
| R3 | "Where does your team's remit end and this role's begin on the two new lines, and who decides when we disagree?" | Shows you want the seam principles before you need them |
| R4 | "Which of the two new lines, if either, is Compass, and where is each today across land, adopt, expand and renew?" | Shows you read the priorities and the JD's lifecycle language; the answer reweights D1 and D2 |
| R5 | "How is bundling by the larger platform vendor showing up in the deals and renewals you see?" | Uses his vantage point on the one competitive threat in your note |
| R6 | "What did you take from the early-stage chapter that you still use at this scale?" | Tied to his startup chapter as the notes describe it; ask only if you are genuinely curious |

## Prohibited claims

Built before the banks. Each entry is a claim this pack will not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| Led, drove or owned the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: you proposed the change, and it was credited with the uplift. The limit is the pack's observation: the material says proposed and credited, not owned or delivered |
| Has set sales quotas or run sales-ops | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| Presented the annual volume targets as quota-setting | Inflated form of F5, and contradicted by F7 | F5's quote at its own scope. The limit is the pack's observation: the material says volume targets with cross-org consensus, not quotas |
| Designed or ran a partner motion | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says a model used in negotiations, not a motion. C3's slot stays inside the model |
| Owned go-to-market for a new product line | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says product strategy and ops, not a go-to-market |
| Built, launched or led AI products | Inflated form of F6 | F6's quote at its own scope: you use AI tools every day. E2's slot stays inside the tools you use |
| Ran independent end-to-end analyses in SQL and Tableau | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material names the tools, not the work. A3's slot asks only which tool and for what |

## Sources

Provided documents: the coach's notes in the request: JD highlights, the candidate summary, the interviewer profile as described, and the research note. No dossier was present in context.

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Query | Outcome |
|---|---|
| `Northwind Data values principles` | refused |
| `Northwind Data interview process strategy GTM` | refused |
| `Northwind Data Compass AI copilot launch strategy 2026` | refused |
| `Dan Kovac Northwind Data Director Sales Strategy` | refused |
| `Senior GTM Strategy Lead Emerging Products job description B2B data infrastructure` | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Would have moved a values cheat sheet if a values round exists; nothing in the pack uses published values |
| 2. `Northwind Data interview process GTM` | unavailable | Would have shown whether other rounds exist; weights do not depend on it, since your own words establish the one session |
| 3. `Northwind Data strategy` / recent news | unavailable | The query checked whether your pasted note is current; it moved nothing, so the Grounding brief is flagged undated |
| 4. `Dan Kovac Northwind Data` | unavailable | Would have added his talks and writing to the interviewer read; it rests on the profile as described |
| 5. representative `Senior GTM Strategy Lead` JD | unavailable | Would have added inferred rows and any gate term; the fit snapshot rests on the highlights alone |

## Upgrade menu

- The full JD text → the six highlight rows are quoted against the JD's own words, mid-list items get questions, and any gate term (location, pay, travel) would show up
- Priya's CV → the evidence cells quote the CV rather than the coach's notes; to raise a medium row to high, the artifact is the model file or deck behind F4's model, the readout that credited F2's figure, or a Tableau workbook or query set for F3
- Answers to the answer slots in A1, A2, A3, A5, C3 and E2 → those rows regenerate on what you actually did
- Recruiter or Dan's team guidance on focus areas or a pre-declared deliverable → coverage of any graded deliverable; usually one email
- Search permission → Northwind's published values and loop, a currency check on your research note, and Dan's public talks and writing; a deeper pass would be up to 6 more searches and 2 more fetches, several more minutes
- If the loop has other sessions, send the schedule → per-round mini-packs
- A `tuesday-dossier.md` → verified evidence, a named highest-ROI objection and absolute prohibited claims, in place of the ones this pack inferred
