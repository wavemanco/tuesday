# Interview prep pack: Product Operations Manager, Stripe

Round: final round. Interviewer name and relationship: not given. Built as a session-mode pack with blended persona weights. No JD, CV, or web research was available, so this is a worksheet-style pack: every row below is a structure to fill from your own material, not a claim about you or about Stripe.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say only what you actually did, in your own words.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the values asked about |
| EXP | Work-experience deep-dive: do your claims survive scrutiny, and what was actually you |
| JD | Role-driven: can you do the listed job, including its gaps |
| CO | Company and strategy knowledge: homework depth. Generic in this pack, because no research ran |
| CASE | Live problem from the role: structure and reasoning, delivered out loud |

## Fit snapshot

No JD, recruiter words, or CV were provided, and no representative JD could be fetched. The requirements below are role-family prose written without a source, so they carry `[generic]`. They are not quotes from a Stripe posting. Evidence cells are empty because you have not shared any yet. No requirement here is a gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate launches or programs across product, engineering and go-to-market teams (role-family, no source) | none given | none | [generic] | discovery | Strong evidence here is a named launch or program, your specific part in it, and who depended on you. Selection scaffold: pick one cross-team effort where your own part is clear, say what you did and what others did, and name what changed because of it. If no such effort comes to mind, say so plainly, then give the nearest work your material does carry, or how you would approach it |
| F2 | Design and run an operating cadence or process for a team (role-family, no source) | none given | none | [generic] | discovery | Strong evidence is a process you set up or changed, why, and what happened to it. Selection scaffold: pick a process where you can say whether it was yours to design, inherited, or adjusted. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would build one |
| F3 | Use metrics and data to inform product decisions (role-family, no source) | none given | none | [generic] | discovery | Strong evidence is a figure you can explain end to end: how it was counted, what it is sensitive to, and which part was yours. Selection scaffold: pick one number you have reported. If you do not know how it was counted, say so plainly, then give the nearest analysis your material does carry, or how you would check it |
| F4 | Communicate and influence without direct authority (role-family, no source) | none given | none | [generic] | discovery | Strong evidence is a moment where you moved a decision without the power to order it, and the relationship stayed intact. Selection scaffold: pick a disagreement with a peer or senior person where you can say what you proposed and what happened. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Prioritize and make progress under ambiguity (role-family, no source) | none given | none | [generic] | discovery | Strong evidence is a situation with unclear ownership or goals, the trade-off you named, and the outcome. Selection scaffold: pick one such situation and say how you decided what to leave out. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it |
| F6 | Clear, specific motivation for this role and this company (role-family, no source) | none given | none | [generic] | discovery | Strong evidence is reasons you can state in your own words that survive a follow-up. Selection scaffold: write the three reasons you would give, then cut any you could not defend under a second question. If you cannot name a reason beyond the title, say so plainly and decide whether this is the role you want |

## Persona table

No loop source was readable, so the loop is not established: no source says how many sessions the final round holds or who runs each. The archetype fallback is Generic (screen, hiring manager, panel), which gives flat weights. The pack says so plainly: these weights rest on a pattern, not on Stripe's documented process. If your final is several back-to-back sessions, the schedule would let this pack split into per-session mini-packs.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | A live problem set in a product operations role: plan this launch, diagnose this metric | Equal weight. A final round for a role built on process and decisions plausibly includes a live problem, but no source confirms it | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud, and challenge one premise respectfully |
| B. Skeptic | Quiet probing of gaps, motivation, and role fit | Equal weight. Any final round weighs motivation and day-one weakness, and the pack holds no CV to find a specific gap in | Rehearse the most predictable objection until it is boring. Bridge only from work you actually did. Offer a concrete ramp plan |
| C. Data-Driven Prober | Asks how a number was counted, two levels deep | Equal weight. Product operations work leans on metrics, so a figure you cite will likely be tested | Know how each figure was counted. Name the assumption you would defend least before they do. Say plainly when you do not know |
| D. Peer Evaluator | Seam-splitting between teams, credit, collaboration | Equal weight. A final round may include a future peer, but the relationship is unknown | Frame what you bring them, not only what you need. Propose seam principles instead of pretending to know the seam |
| E. Values / Behavioral | Scenario probes keyed to published values | Held to two questions. No published values were read, so this bank cannot be keyed to Stripe's own names | Choose stories where the hard truth actually landed. If your material shows none, say so rather than supplying an ending |
| F. Pressure | Interrupts, time-boxes, plays devil's advocate | Equal weight. Common in later rounds, but unconfirmed here | Pause, restate, hold a challenged position through two follow-ups, then concede specifically |
| G. Conversational | Friendly, unstructured; casual questions still scored | Equal weight. Often the opener, and the reverse-question slot lives here | Script a 90-second arc. Treat casual questions on hot topics as scored |

**Highest-ROI prep: B1, "Which part of this role would you be weakest at on day one?"** It is the most predictable objection for any candidate in any final round. With no CV or JD, the pack cannot name a specific gap, so this pick comes from the Skeptic's stock stem and not from your material. Sharing your CV and the JD would replace it with your actual biggest gap.

## Question banks

Every row is `[generic]`: none of the guidance rests on a sentence you wrote, so none makes a claim about your past. Where a question asks about your past, the guidance is a selection scaffold ending in an honest branch. Where no past is asked about, it makes no claim about you.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product launch is two weeks out and engineering, sales and support each say they are not ready. What do you need to know first, and how would you structure the next two weeks?" | CASE | [generic] | Clarify before structuring: what is launching, who decides it can slip, what each team means by not ready. Then objective, who owns each readiness criterion, the decision points, and what you would escalate. Name one premise you would challenge. The question needs no claim about your past, so the guidance makes none | Live problem in the role's own territory, covering F1 and F5. CASE because it scores structure over the right answer |
| A2 | "A metric the product team relies on dropped 20% week over week. Diagnose it." | CASE | [generic] | Ask first: is the drop real, which segments, what changed upstream. Then rule out measurement before behavior, rank hypotheses, and say what you would check first and why. Think aloud, and say plainly what you would not conclude yet. No claim about your past | Metric-diagnosis stem for F3. CASE because it scores clarify, structure, then answer |
| A3 | "Design the operating rhythm for a product organization that ships often and has no shared cadence. What would you keep out?" | CASE | [generic] | Start from what decisions need to be made and by whom, then the minimum meetings and documents that serve them. The keep-out half is the part to rehearse: name what you would refuse to add and the cost of adding it. No claim about your past | Covers F2 and tests judgment about what not to build. CASE because it is a design problem with a stated constraint |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal in the pack. Choose the real answer from your own material, state it plainly in one sentence without apologizing, give a concrete first-month ramp, and stop. Hold through two follow-ups by returning to the plan, not by adding experience. If nothing comes to mind quickly, that is itself the gap to work on before the interview | Predictable in some form in any final round (F1 to F6). JD because it scores honest self-assessment against the role |
| B2 | "Why this role, why Stripe, why now?" | CO | [generic] | Give three reasons in your own words, each one you could defend under a second question. Do not use claims about Stripe you cannot source; with no research in this pack, any Stripe-specific reason is yours to bring and verify. If a reason is only the title or the brand, cut it | Motivation consistency, F6. CO because it tests homework depth, and this pack could not supply any, so it is generic by necessity |
| B3 | "How would you tell a coordination role from one that changes decisions, and where do you want this role to sit?" | JD | [generic] | Say what you would want the role to be accountable for, and how you would know it had changed a decision rather than only reported on one. Name one risk of each end. No claim about your past | Probes F1, F4 and F5 from the role's side. JD because it scores whether you understand what the job is for |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Think of a number you have reported to a team. Walk me through how it was counted." | EXP | [generic] | Selection scaffold: pick one figure you can explain. Say how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly, then give the nearest figure you do understand | Defend-the-number rehearsal for F3. EXP because it tests whether a claim survives scrutiny |
| C2 | "Tell me about a time data changed a decision you were part of. What was your part?" | EXP | [generic] | Selection scaffold: pick a decision where you can separate what the data showed, what you did, and what others did. Use we for context and I only for your contribution. If no such time comes to mind, say so plainly, then describe the nearest thing your material does carry, or how you would handle it | Attribution probe for F3 and F4. EXP because the second half asks what was actually you |
| C3 | "How would you decide which three metrics a product operations team reports to leadership every month, and which you would refuse to report?" | CASE | [generic] | Start from the decisions leadership makes, then metrics that move them, then the refuse list and why. Name how you would keep a metric from being gamed. No claim about your past | Covers F3 as a design question. CASE because it asks about no past |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | CASE | [generic] | Propose seam principles instead of claiming to know the seam: who decides, who informs, how a disagreement escalates. Lead with what you would bring their team, not only what you need. No claim about your past | Seam-splitting for F1 and F4. CASE because it is a live collaboration scenario |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a cross-team effort where credit was shared. Say how you described your part and others' parts at the time. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Credit probe, F4. VAL because it scores behavior, not a published value |
| D3 | "What would you need from me in your first month, and what could you give my team?" | JD | [generic] | Name two specific needs and one thing you would offer in return. Keep the offer inside what you could credibly deliver in a month. No claim about your past | Reciprocity framing, F1 and F4. JD because it tests how you would start the role |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship that survived. If the hard truth did not land, say so. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona-stem question for F4. VAL because it scores behavior under pressure |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a specific decision and the trade-off it cost you. Say what you chose, what it cost, and what you would do differently. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona-stem question, F5. VAL because it asks for a decision, not a slogan |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, then give two reasons you can defend from your own material. Hold the position through two follow-ups; concede one specific limit without folding on the core. No claim about your past | Motive and composure probe, F6. JD because it scores role fit under time pressure |
| F2 | "Pick a result you are proud of. How much of it was actually you?" | EXP | [generic] | Selection scaffold: pick a result where you can separate your part from the team's. Say your part in one sentence, then what others did. If you are not sure how much was you, say so plainly | Attribution pressure, F3 and F4. EXP because it tests what was the candidate's |
| F3 | "I am not convinced by that answer. Defend it." | EXP | [generic] | Hold-then-concede: restate your position in one sentence, give the single strongest reason, then concede a specific uncertainty without taking back the core. Practice on any answer in this pack. No claim about your past | Rehearses the method, covers F5. EXP because it tests holding a position |

### G. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | Script a 90-second arc once you have written your CV in. Selection scaffold now: three beats from your own history, each tied to why the next move followed. Cut anything you cannot say plainly. Once you share your CV, this becomes a story-mapped answer | Biographical opener, F6. EXP because it scores communication economy |
| G2 | "What are you reading or trying out these days that bears on this kind of work?" | JD | [generic] | Name one specific thing you are actually doing, and what you took from it. If nothing comes to mind, say so plainly rather than inventing something | Casual register, still scored, F6. JD because it tests live interest in the field |
| G3 | "What questions do you have for me?" | JD | [generic] | Use the reverse questions below. Never answer that you think they have covered everything | The reverse-question slot rapport interviewers weight heavily, F6 |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Cross-team launch or program coordination | A1, D1, D3 |
| F2 Operating cadence or process design | A3 |
| F3 Metrics and data for product decisions | A2, C1, C2, C3, F2 |
| F4 Communicate and influence without authority | B3, D1, D2, E1 |
| F5 Prioritize under ambiguity | A1, B3, E2, F3 |
| F6 Motivation for this role and company | B1, B2, F1, G1, G2, G3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would make this role clearly successful at six months, and how would you know?" | Shows you think in outcomes and gives you something to measure yourself against |
| R2 | "Where does product operations sit relative to product management and to go-to-market teams, and where does that cause friction?" | Asks about the seam directly and signals you thought about turf |
| R3 | "What is the decision this team most wishes it made faster?" | Invites a real example of the problem the role exists to solve |
| R4 | "What did the last person in a similar position do that you want more of, or less of?" | Surfaces what the interviewer actually values, in their own words |
| R5 | "What is something about how this team works that I would only learn after joining?" | Collegial, and often draws out candid detail |
| R6 | "If you are a peer on the team: what could a new person do in the first month that would genuinely help yours?" | Reciprocity question for a peer interviewer; skip it if your interviewer is your future manager |

## Prohibited claims

This pack was built with no candidate material: no CV, no quotes, no stated negatives, no dossier. There is nothing to inflate and nothing to contradict, so no entries are listed. That is not a finding that nothing could be inflated. It means the pack was given nothing to inflate. Once you share your material, this section will list the stretched wordings of your own sentences that the pack will not coach.

## Sources

Provided documents: your message only (company, role title, final round).

Research tier: L1 — searches 4 of 6, fetches 0 of 2

All four searches the pack sent were refused by the host and returned nothing.

Queries sent, each refused: Stripe operating principles values; Stripe interview process Product Operations Manager final round; Stripe strategy news 2026; Stripe Product Operations Manager job description responsibilities.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have supplied the published value names and a values cheat sheet; E bank is generic instead |
| 2. Stripe interview process, product operations | unavailable | Would have established the loop and set persona weights; fell back to the Generic archetype, flat weights |
| 3. Stripe strategy or recent news | unavailable | Would have grounded a CO or CASE question in current strategy; B2 is generic instead |
| 4. Interviewer name and Stripe | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Would have made the fit snapshot rows quotable and JD-tagged questions `[inferred]` instead of `[generic]` |

## Upgrade menu

- Permission to run web research → published Stripe values, documented loop structure and current strategy, which would add a values cheat sheet, loop-based persona weights and a strategy-grounded CO question
- The job description text → the six role-family rows become quoted requirements and the JD-tagged questions become `[grounded]`
- Your CV → fit snapshot evidence cells filled with your own sentences, story-mapped guidance in place of selection scaffolds, defend-the-number questions on your actual figures, and a specific biggest-gap objection in place of the stock one
- Your round type and who you are meeting → persona weights recomputed and banks reordered
- The interviewer's name → a tailored reverse question and persona weights read from their public footprint
- The recruiter's prep email, if any → coverage of any pre-declared deliverable or focus areas
- If your final is several sessions, the schedule → per-session mini-packs
- A `tuesday-dossier.md` from an earlier session → verified evidence and a named top objection in place of an inferred one
