# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode: three sessions on 29 November 2026, nine days from today (20 November). Interviewers: none named yet. Roles per the recruiter's email: the recruiter (30 minutes); the Head of Member Services, your future manager (45 minutes, mostly behavioural); a panel of two branch managers (60 minutes, including a 20-minute case on a complaint escalation, also the values round).

## How to use this pack

Personas describe how a question is asked. Types describe what it scores.

| Type | Meaning |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's published values |
| EXP | Whether what you have said about your experience survives follow-ups |
| JD | A stated responsibility or requirement of the posting, including your gaps |
| CO | Whether you can think at Ashgrove's altitude: strategy, competition, recent moves |
| CASE | A live problem set in the role; it asks about no past |

Guidance is scaffolding, not a script. An answer slot is an instruction for the interview, in your own words: say the true branch, including "that was not mine" or "there was no such step". A logistics slot works the same way: the answer is yours, and the pack supplies none.

## Prep triage (nine days)

| Order | Do | Where |
|---|---|---|
| 1 | Settle your contact-centre answer: the plain acknowledgment, then the plan said as a plan. Rehearse it aloud with the three follow-ups | 2B1, 1B1, 1B2 |
| 2 | Write your own one-line answers for pay, notice, location and reason for leaving | 1A2 to 1A5 |
| 3 | Pick one real story per value, or decide you have none and rehearse the honest branch | 3A1 to 3A4, 2A1 to 2A3 |
| 4 | Answer the slots about your own experience (rules, spreadsheet, supervisors, digital) before anyone asks | F2, F3, F5, F6, F7, F8 |
| 5 | Run the case structure aloud twice, timed to 20 minutes | 3B1, 2C1 |

Everything else is insurance.

## Fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: "I've spent six years in retail banking, the last three as a branch supervisor." |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your material says a formal complaints log, and does not show which rules the complaints ran under. Words: "I handled the branch's formal complaints log." Answer slot: the JD says regulated, so expect a probe on what rules those complaints ran under. If any applied, say which and what was yours to do under them, in your own words; if none applied, or it was not yours, say so plainly and stay with the log |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD, branch side | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's log, not the process end to end across branches. Words stay at that scope: "I handled the branch's formal complaints log." Answer slot: expect a probe on what happened to a complaint before it reached the log and after. If any of that was yours, say which; if the log was the whole of your part, say so plainly and stay with the log |
| F4 | "Own the member complaints process end to end across branches and the contact centre" — JD, contact-centre side | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says a monthly complaints spreadsheet, and does not show what it counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what yours counted. If it counted either, say which and how it was counted; if it counted neither, say so plainly and stay with what it did hold |
| F6 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says tellers and a script, not supervisors. Words stay at that scope: "I trained new tellers on our escalation script." Answer slot: expect a probe on the difference. If you have ever guided another supervisor through an escalation, say what and what was yours; if not, say so plainly and stay with the tellers |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent, so this is a question and not a gap you stated. Answer slot: if you have worked with a digital or app team on anything members used themselves, say what and what part was yours; if not, say so plainly and say what you would ask a digital team first |
| F8 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | The sentence says spreadsheet, not Excel, and the pack takes the reading that claims less. Words stay: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it was Excel, say so and what you can do in it; if it was another tool, or Excel only in part, say so plainly |
| F9 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You have stated the limit. Words: "I haven't presented to anyone above regional level." Then how you would prepare your first one, said as a plan and never as a past |

None of the nine rows is a gate (a term met or not): the four-years line is graded like any other requirement, and your six years clear it on your own words.

## Grounding brief: what Ashgrove has said it will do

| Fact | Source | Provenance |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | Ashgrove's 2026 strategy brief, July 2026, as you relayed it | [grounded] |
| Consolidate eight branches into five hubs over 2027 | same | [grounded] |
| Launch a small-business lending product in Q1 2027 | same | [grounded] |
| Main competitive pressure: app-only banks | same | [grounded] |

The brief is four months old, inside the six-month freshness window. This pack holds your four points, not the brief itself.

## Sources

Provided: the job description; the values text you copied from ashgrovecu.org/about/values on 20 November 2026; the recruiter's email on the process; the four strategy points you relayed from the July 2026 brief; your background message. No search or fetch was sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the values cheat sheet or the VAL banks: the values text you pasted fixes both |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | Could not have moved the persona weights: the recruiter's email fixes the three sessions, who runs each, and the panel's values scoring |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | Could not have moved the CO and CASE questions: the four points you relayed from the July 2026 brief fix them |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No name was given, only roles, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

# Round 1: recruiter screen (30 minutes)

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured: the journey, pay, notice, why you are moving | High: the recruiter-screen prior is Conversational plus a light Skeptic, and the recruiter described only a 30-minute conversation | A 90-second arc; treat every casual question as scored |
| Skeptic (light) | Knockout checks on the two things the posting names that your message does not cover | Medium: the posting names the contact centre and senior leaders, and your message shows neither | Say the limit once, plainly, then the plan |

## Questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F1, F2, F5: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log; training new tellers on the escalation script; the monthly complaints spreadsheet your regional manager uses. Tell those beats in your own words in about 90 seconds. Answer slot: close on why this role, in your own words; if the honest reason is mixed, say so plainly | The opening question frames every later probe; the beats are exactly what F1, F2 and F5 carry |
| 1A2 | "What are your pay expectations for this role?" | JD | [generic] | Logistics slot: give your own figure, or ask for the role's band first. The posting states no pay, and the pack supplies no figure or salary history | Logistics a recruiter screen covers; JD because it concerns the listed job's terms |
| 1A3 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period in your own words; the pack supplies none | Same logic as 1A2 |
| 1A4 | "Where are you able to work, and how often?" | JD | [generic] | Logistics slot: say where and how often, in your own words. The posting you shared names no location, so if you are unsure where the role sits, ask the recruiter before you answer | Same logic as 1A2 |
| 1A5 | "What's prompting you to look at a move?" | EXP | [generic] | Logistics slot: give your own reason in one or two plain sentences; the pack supplies none. Say what is true, and do not criticise an employer | The reason for leaving is a standard screen item; EXP because it tests consistency with your story in 1A1 |
| 1B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose from your own words, first person: "I haven't worked in a contact centre." Then the plan, said as a plan: who you would sit with in your first weeks and what you would ask first. No past tense in the plan | F4 and F9 are the two stated limits; the contact-centre one is the more likely to be named first because the posting names it in its first line |
| 1B2 | "The role covers the contact centre as well as the branches. What's your experience there?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | The plain acknowledgment: "I haven't worked in a contact centre." Then stop and let them respond. Answer slot: if you have worked alongside contact-centre colleagues, or handled a complaint that began there, say what; if not, say so plainly | F4; asked here so the first rehearsal of the gap is with the friendliest listener |
| 1B3 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | The brief is the one every prepared candidate holds, so bring one point from it to show you have read it, not the list: the 40% digital target by 2028 is the one closest to the posting's self-service line. Then one view put as a question, a hypothesis and not a fact about Ashgrove: as more member service moves to digital channels, which complaints still need a person, and what has already happened to them when they arrive. Answer slot: if you have a view of your own on what the brief means for complaints, say it in your own words; if not, say so and ask the question | Grounded in the strategy points you relayed; differentiating from a shared source is the CO rule |
| 1B4 | "Tell me about the reporting you've done." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F5 and F8: you built it, it was monthly, it was about complaints, your regional manager used it. Answer slot: the JD names complaint volumes, resolution times and Excel, so expect probes on each. If it counted either figure, say which and how it was counted; if it ran in Excel, say so; if it did not, say what it ran in; if it counted neither, say so plainly and stay with what it held | F5 and F8 are the rows where the JD's words go past the sentence; a recruiter checks them as a knockout |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Where does this role sit, and how often would it be in branches compared with the contact centre?" | Shows you have read the scope; settles your answer to 1A4 |
| R1.2 | "What does the panel's 20-minute case use: a written scenario, a past complaint, or something handed over on the day? Is there anything I should read first?" | Only the recruiter can say; it turns a surprise into preparation |
| R1.3 | "Can you tell me who the two branch managers on the panel are?" | Names unlock an interviewer read for round 3 |
| R1.4 | "Is the contact-centre side the part you most need to see evidence on?" | Calibrated candour: it surfaces the likeliest objection while you are among friends |

# Round 2: Head of Member Services, your future manager (45 minutes)

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Open prompts: a time you did something | High: the recruiter called this round mostly behavioural | Pick instances you can tell fully; where none exists, say so and give the nearest real thing |
| Skeptic | Quiet probing of the contact-centre gap, end-to-end ownership, and senior presenting | High: the hiring-manager prior includes the Skeptic, and a manager is buying capability and weighing gaps | Rehearse the single predictable objection until it is boring |
| Case/Strategist | One or two live problems from the role's own roadmap | Medium: the hiring-manager prior, lowered because the round is mostly behavioural | Clarify, objective, segmentation, approach, metrics, risks; challenge one premise respectfully |

## Questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2A1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, what you actually said, and how the relationship stood afterwards; choose one where the hard truth landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem for a manager's behavioural round; no quoted sentence carries a story for it |
| 2A2 | "Tell me about a time a complaint needed escalating. What did you do, and what happened?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The quote carries the log and the script and no particular escalation, so the instance is yours to choose: one you can tell fully, with what the member asked for, what you did and what happened. If no escalation comes to mind that you can tell in full, say so plainly and describe how the escalation script worked | JD escalations and F2, F6 meet here; EXP because it tests what was actually yours |
| 2A3 | "When did you put a member ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time the member's need and a target pulled apart. It needs the choice you made, what it cost, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; this and Round 3's Members First question can share one story, told the same way both times |
| 2A4 | "Tell me about a time you taught someone to handle something difficult." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F6: new tellers, the escalation script, training. Answer slot: the JD asks you to coach, so expect a probe on what changed afterwards. If you saw a change in how a teller handled an escalation, say what; if not, say so plainly and stay with the training | F6 is the nearest evidence for the coaching line; JD because it scores a stated responsibility |
| 2B1 | "I don't see contact centre experience in your background. How would you handle that part of the role?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | The highest-ROI rehearsal in this pack. Level 1: "I haven't worked in a contact centre." Then the plan as a plan: what you would learn first, from whom, in what order. Follow-up 1, "What makes you think you can own it then": hold to what you have said and add nothing, and do not describe contact-centre work as yours. Follow-up 2, "Would that team trust a lead who hasn't done their job": concede specifically that you would not know their constraints on day one, and say how you would find out. Follow-up 3, "Isn't someone from a contact centre a better fit": do not fold; say what you would need to learn, and keep the concession exact. The limit, named before it is asked for: this gap is real and no wording closes it. Answer slot: if you have worked alongside contact-centre staff, or handled a complaint that began there, say what; if not, say so plainly | F4 is the largest stated gap against the posting's first line, so this objection arrives in some form; JD because it scores a stated requirement |
| 2B2 | "What part of a complaints process have you owned yourself?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The hold is only what the quote carries: "I handled the branch's formal complaints log." Answer slot: expect a probe on what happened to a complaint before it reached the log and after. If any of it was yours, say which; if the log was the whole of your part, say so plainly and describe how you kept the log. Hold through two follow-ups by returning to the log, never by adding to it | F3 is where the posting's end-to-end line presses hardest; JD because it scores the stated requirement |
| 2B3 | "The role presents to senior leaders, and you've not presented above regional level. How would you handle the first time?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | The acknowledgment: "I haven't presented to anyone above regional level." Then the plan as a plan: what you would lead with, and who you would rehearse in front of. Answer slot: if you have ever taken the spreadsheet's results to your regional manager or anyone else, say how it went; if you only handed it over, say so plainly | F9 and the posting's senior-leaders line; the spreadsheet is F5's evidence and is the likeliest thing you would be presenting from |
| 2C1 | "Sketch how you would start owning the complaints process across branches and the contact centre. What do you need to know first?" | CASE | [generic] | Clarify first: who holds a complaint now at each step, what rules govern it, and what the current reporting shows. Objective, then a split between branches and the contact centre, then an approach and the measures. Name one premise to challenge respectfully. This question asks about no past, so the guidance makes no claim about yours | The persona stem for a hiring-manager round, set on the posting's first line |
| 2C2 | "A branch supervisor escalates a complaint and says the policy will not let them put it right. How do you coach them?" | CASE | [generic] | Ask first what the member asked for and what policy actually says. Separate what the supervisor can decide from what must go up. Coach the supervisor to keep hold of it and tell the member plainly what will happen next. Close by asking what you would change in the policy or the script if this keeps arising | The posting's coaching line as a live problem; asks about no past |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What would a good first ninety days look like for whoever holds this role, and what would you want changed by the end?" | A manager hears you planning from their goal, not yours |
| R2.2 | "When a complaint moves between a branch and the contact centre today, who holds it?" | Own the Fix as a question; shows end-to-end thinking without assuming the answer |
| R2.3 | "The strategy says 40% of service moves to digital by 2028. What should a self-service complaint journey achieve?" | Ties the posting's digital line to the brief without claiming experience |
| R2.4 | "Which part of this role do you expect to be hardest for someone coming from a branch?" | Invites them to name the contact-centre gap on their terms |
| R2.5 | "How should the monthly report reach senior leaders, and who presents it?" | Addresses F9 directly and shows you are planning for it |

# Round 3: panel of two branch managers (60 minutes, including a 20-minute case)

The recruiter says this panel scores against the four values, so a values-style round is detected. The roles' relationship to you is unclear: they are branch managers, and the role coaches branch supervisors.

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | One scored scenario per published value | High: the recruiter said the panel scores against the four values | One story per value, or the honest branch; "we" for context, "I" for contribution |
| Case/Strategist | The 20-minute complaint escalation case, plus strategy-linked problems | High: stated in the recruiter's email; it is a third of the round | Clarify before structuring; use Ashgrove's own words |
| Peer Evaluator | Where the seam sits between this role and a branch, and what happens in a disagreement | Medium: the role coaches branch supervisors, whose managers these are, which is the pack's inference and not a stated fact | Reciprocity: what you bring a branch, not only what you need |

A Conversational register is also plausible in the values conversation; treat it as scored. It gets no separate bank because 3A covers it.

## Values and principles cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence carries a story. Selection scaffold: pick a time you decided from the member's side and say what it cost; if none comes to mind, say so plainly and give the nearest real thing |
| Plain Words | If a member needs it explained twice, the wording was wrong | F2 and F6 hold the nearest sentence: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The script is wording, but the sentence does not say you wrote or changed it. Scaffold: pick a time wording had to change; if none, say so plainly |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted sentence carries a story. Scaffold: pick a decision you made with your branch's town in mind; if none, say so plainly. Have one sentence ready on how reporting numbers can serve a member |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | F2 and F3 hold the nearest sentence: "I handled the branch's formal complaints log and trained new tellers on our escalation script." It says you handled the log, not that you carried a problem to its end. Scaffold: pick a problem you kept hold of to the end; if none, say so plainly |

## Questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3A1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [generic] | Selection scaffold: a named member situation, the choice you made, what it cost, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The published value Members First, Always, as an open prompt; no quoted sentence carries a story |
| 3A2 | "Tell me about a time something you wrote or said to a member had to be said twice. What did you change?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The quote carries the log and the script and nothing about wording. Answer slot: if you wrote or changed any wording of the script, say what and why, in your own words; if you did not, say so plainly and use a different instance or say what you would change | The published value Plain Words; F2 and F6 are the nearest evidence |
| 3A3 | "Tell me about a time you made a decision with your branch's town in mind." | VAL | [generic] | Selection scaffold: a named decision, who in the town it affected, and what it cost the branch or the numbers. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The published value Neighbours, Not Numbers; the role's reporting sits beside it, which is F5's row |
| 3A4 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The quote carries handling the log, which is not the same as carrying a problem to its end. Selection scaffold: pick a problem that stayed with you to the end, with how you knew it was solved. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The published value Own the Fix; F3 is the nearest evidence |
| 3B1 | "Here's a complaint that has been passed between teams and the member has now complained again. Walk us through what you do." | CASE | [inferred] the case method read through the four published values and the recruiter's note that the panel scores them | Clarify first: what the member asked for, what they have been told so far, who holds it now, and which rules apply and by when. Then objective, then name one owner until it is solved (Own the Fix), then tell the member plainly what happens next (Plain Words), then what you would record and what you would pass on as coaching. Challenge one premise respectfully. The case itself is unknown, so use this as a frame and not a script; the question asks about no past | The 20-minute case the recruiter named; the pattern and the values are known, the scenario is not |
| 3B2 | "A member tries to raise a complaint in the app. What should that journey do, and where does it hand over to a person?" | CASE | [grounded] the 40% digital target in the strategy points you relayed | Clarify who the member is and what they are trying to do, then what makes a complaint different from a query. Put the hand-over where the member would otherwise have to say it twice. Answer slot: if you have worked with a digital team, say what and what part was yours; if not, say so plainly and say what you would ask them first | F7; CASE because it is set in the role |
| 3B3 | "Ashgrove plans to consolidate eight branches into five hubs over 2027. What does that mean for complaints?" | CO | [grounded] the consolidation point in the strategy points you relayed | Think aloud. Ask what happens to a complaint raised in a branch that becomes part of a hub. Name what members could lose and gain without taking sides, and say you do not yet know the plan's detail. Tie it to Neighbours, Not Numbers only if it fits the answer | The brief's consolidation line touches branches and the panel are branch managers; whether their own branches are affected is unknown |
| 3B4 | "What would you report each month to tell us complaints handling is getting better?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The JD names complaint volumes and resolution times; start from those and say what you would add. Answer slot: if your spreadsheet counted either, say how it was counted and the assumption you would defend least; if it counted neither, say so plainly | F5 and F8; the weakest-assumption move applies to any figure you offer |
| 3C1 | "You'll coach our supervisors on escalations. Where's the seam between you and me, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam and do not pretend to know where it sits now. Ask what a supervisor does today when they are unsure. Selection scaffold for the disagreement: a named disagreement with an equal, what you each held, and how it ended. If no such time comes to mind, say so plainly | A peer stem set on the posting's coaching line; asks for no claim about your past |
| 3C2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Reciprocity framing: who did what, named plainly. Selection scaffold: a time work spanned teams, what you did and what others did, and how credit was shared. If none comes to mind, say so plainly | A persona stem; no quoted sentence carries it |
| 3C3 | "Your monthly report shows my branch with the slowest resolution times. What happens next?" | CASE | [generic] | Check the figure before sharing it: how it was counted, and what it is sensitive to. Talk to the branch manager first, find the cause together, and say what you would offer. Concede what you cannot know until you have looked | The posting's reporting and coaching lines meeting a peer; asks about no past |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What could someone new in this role do in their first month that would help your branch?" | Reciprocity: the peer-evaluator slot, and it shows you are thinking about what you bring |
| R3.2 | "When a supervisor in your branch is unsure about an escalation, who do they go to today?" | Shows you are building on what exists and not replacing it |
| R3.3 | "Once branches become hubs, how will a member raise a complaint in person?" | Neighbours, Not Numbers as a practical question, tied to the brief |
| R3.4 | "Can you tell me about a time one of the four values was tested in your branch?" | Hears what the panel scores for, in their own words |
| R3.5 | "What would tell you, six months in, that this role is working for your branches?" | Lets them define success in their own terms |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "4+ years in financial-services customer operations" | 1A1 |
| "experience handling regulated complaints" | 2A2, 2B2, 3B1 |
| "Own the member complaints process end to end across branches and the contact centre" | 1B1, 1B2, 2B1, 2B2, 2C1, 3B1 |
| "report monthly on complaint volumes and resolution times" | 1B4, 3B4, 3C3 |
| "coach branch supervisors on escalations" | 2A4, 2C2, 3C1 |
| "work with digital teams on self-service journeys" | 1B3, 3B2 |
| "comfortable with Excel reporting" | 1B4, 3B4 |
| "confident presenting to senior leaders" | 1B1, 2B3 |
| Four published values | 3A1 to 3A4 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says the branch's log, not the process end to end |
| Handled regulated complaints under named rules | Inflated form of F2 | F2's quote at its own scope: your material says a formal complaints log and does not show which rules applied |
| Reported complaint volumes and resolution times each month | Inflated form of F5 | F5's quote at its own scope: a monthly complaints spreadsheet, with what it counted unshown |
| Coached branch supervisors on escalations | Inflated form of F6 | F6's quote at its own scope: new tellers and the escalation script |
| Advanced Excel skills | Inflated form of F8 | F8's quote at its own scope: the sentence says spreadsheet, not Excel |
| Has contact-centre experience | Negative you stated, F4 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F9 | The plain acknowledgment: "I haven't presented to anyone above regional level." No slot |

## Upgrade menu

- Your answers to the slots in F2, F3, F5, F6, F7 and F8: what rules the complaints ran under, what your spreadsheet counted and whether it was Excel, whether you have guided another supervisor, whether you have worked with a digital team. Each answer you give changes that row and the questions built on it
- A copy of one monthly report with member details removed: the one artifact that would move F5 from medium towards high
- The two branch managers' names, once assigned: an interviewer read, persona weights read from their public footprint, and a tailored reverse question
- The recruiter's answer on what the 20-minute case uses: a build for the case instead of a general frame
- The strategy brief itself: the pack holds four points you relayed, and the brief would add current numbers and context for CO and CASE questions
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, covering Ashgrove's recent organisation changes and reports of how this kind of loop is run. Say so if you want it
- A `tuesday-dossier.md` from an earlier pass: verified evidence and a prohibited-claims list that would replace the ones this pack built locally
