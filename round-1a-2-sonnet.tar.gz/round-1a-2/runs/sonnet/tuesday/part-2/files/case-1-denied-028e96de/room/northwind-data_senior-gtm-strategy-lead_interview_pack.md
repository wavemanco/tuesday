# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya. **Round:** one 60-minute conversation with Dan Kovac, Director of Sales Strategy, who would be Priya's peer under the same VP. **Pack mode:** session. **Research:** search permission was denied in this session, so the pack rests on what you supplied (Sources and the target accounting say exactly what that cost).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Every question carries one of each, a Provenance cell that shows which of Priya's own sentences the guidance rests on, answer guidance, and a rationale. Guidance is scaffolding, not a script: say only what Priya actually did, in her own words.

| Type | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the values a company publishes, not generic virtue |
| EXP | Work-experience deep-dive | Whether the CV's claims survive scrutiny and attribution is honest |
| JD | Role / JD-driven | Whether she can do the listed job, gaps included |
| CO | Company and strategy knowledge | Whether she can think at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the actual role |

An answer slot is an instruction for the interview, not a question for you. It has two honest branches, and either one meets it.

## Fit snapshot

Requirements are quoted from the JD highlights in your message. Evidence is quoted from your description of Priya, nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message; "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | transferability | Words stay at the quotes' scope: product strategy and ops work, and a change she proposed. Your material does not show a go-to-market for a new product line, and the JD's two-new-product-lines wording makes a probe likely. Answer slot: if any of the product strategy work was a launch or go-to-market for a new product, say what it was and which part was yours, in your own words; if none was, or it was not yours, say so plainly and stay with the product strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | none given | none | [grounded] | discovery | Your material does not show lifecycle-stage analysis, so the evidence may exist and is not shown. Answer slot: the JD's land/adopt/expand/renew wording makes a probe on lifecycle analysis likely. If you have analysed how customers or partners move between stages, say what the analysis covered; if you have not, say so plainly and say how you would begin |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — your message | medium | [grounded] | none | The quote reaches the tooling in the JD's terms: "I'm skilled in SQL and Tableau." The quote does not say "independent", so nothing about solo or end-to-end work is added, and nothing is inspected behind it. Answer slot: if there is an analysis you ran start to finish in them, name it; if the tools were part of a team's work or someone else ran the analysis, say so plainly and stay with the skill as stated |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | The quote is a revenue model used in negotiations, which is adjacent to a partner motion and does not reach designing one. Words stay: "I built a partner-level revenue model used in carrier negotiations." Answer slot: the JD marks this required, so expect a probe on motion design. If any part of how a partner relationship worked was yours to design, say which part and how you decided; if no part was, or it was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms: "I set annual volume targets with cross-org consensus." Keep "cross-org" and "consensus" exactly as stated. It adds no account of how consensus was reached, and a probe on that is likely |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — your message | medium | [grounded] | presentation | The quote reaches the requirement as use: "I use AI tools daily." It is use, not building or shipping, and the words stay there. Answer slot: if asked which tools and for what, name them and the tasks, in your own words; if the use is narrower than the question assumes, say so |
| F7 | "Director of Sales Strategy" — the interviewer's title, your message | "No classic sales-ops or quota-setting experience" — your message | none | [grounded] | capability | A gap you stated, so the words come from your statement: "I haven't had classic sales-ops or quota-setting experience." Then a plan, said as a plan and never as a past. F5's quote stays at its own scope (volume targets with consensus) and is never described as quota-setting |

No gate row appears: the JD highlights you gave name no authorization, location, schedule, pay, travel or credential term. The full JD may; see the upgrade menu.

## Reading the interviewer

Everything here comes from how your message describes Dan; no public footprint could be searched.

| Signal | Source | Practical implication | Mirror opportunity |
|---|---|---|---|
| Self-described "relentlessly data-driven" | Your message, describing his profile | Expect every number to be taken down to how it was counted, and expect questions about the weakest assumption. Offer assumptions before he asks | The "~$400M ARR" figure in F1 is the natural place he goes first |
| Career spine of pricing and monetization roles | Your message | Native vocabulary: packaging, price realization, attach, unit economics. Frame GTM cases in those terms | Pair his monetization spine with the F4 quote "built a partner-level revenue model used in carrier negotiations" — your message, said as stated |
| One early-stage-startup chapter | Your message | Builder stories may land well, and a big-company-pace probe is plausible. Describe how work got done with limited process, only where a real example exists | None offered: no fit-snapshot row's evidence carries a startup move on Priya's side |
| Peer under the same VP | Your message | He is weighing what a hire costs and contributes to his own work. Lead with what Priya's work gives his team, then what she needs | The seam between sales strategy and emerging-products GTM: propose principles, not a seam you cannot know |

## Persona table

Weights rest on three things, shown so you can recalibrate: the peer-round prior, Dan's signals above, and the loop. The loop is one 60-minute conversation by your account, so no archetype fallback is used. No loop source beyond your words was read, so no values-style round is detected; Values questions stay light.

| Persona | How it shows up with Dan | Weight and reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|
| A. Peer Evaluator | Seam-splitting between his team and the role, what you need from him, credit across teams | Top weight, 4 questions. Prior for a peer round, and both of you report to the same VP | Reciprocity first; propose seam principles; a disagreement story only if a quoted sentence carries one |
| B. Data-Driven Prober | Line-by-line probing of the revenue model, the ARR figure and the SQL/Tableau claim | Top weight, 4 questions. Prior for a peer round, raised by his "relentlessly data-driven" line | Know what you can and cannot say about how each number was counted; name the weakest assumption first; say plainly when you do not know |
| C. Case / Strategist | GTM cases set in pricing, packaging and bundling terms, using Northwind's three priorities from your note | Raised to 4 questions. His pricing and monetization spine tilts cases to his native ground | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| D. Skeptic | The sales-ops and quota gap, the partner-motion requirement, why leave and why now | 4 questions, above its usual weight. The fit snapshot's gaps (F1, F2, F4, F7) concentrate here, and the single highest-ROI objection lives here | Rehearse the predictable objection until it is boring; bridge only from stated adjacent evidence; candor over bluffing a competency his seat owns |
| E. Pressure | Interruptions, "how much of that was you", a sixty-second time box | Low weight, 2 questions. Little in a peer round or in your account points to a stress style | Pause, restate, anchor in what you stated; hold through two follow-ups, then concede specifically |
| F. Conversational | Friendly opener, then casual probes on AI and hot topics | Low weight, 2 questions. Still scored, and the biography question is near-certain | A scripted 90-second arc; treat casual AI questions as scored |
| G. Values / Behavioral | Scenario prompts on unpopular truths and partner-versus-metric trade-offs | Low weight, 2 questions. No values page could be read and no values round is detected | Use a selection scaffold; if no real story comes to mind, say so and give the nearest real thing |

## Question banks

Highest-ROI prep: **D1**. It is the objection this candidate meets in some form, and it sits exactly where the material is thin. **B1** is second.

### A. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam between sales strategy and an emerging-products GTM lead, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Propose seam principles rather than pretending to know the seam: one owner per number, shared definitions of land, adopt, expand and renew, and a standing place to settle differences. The one thing you say about your past stays at the quote: "I set annual volume targets with cross-org consensus." Answer slot: the JD's cross-functional-influence wording makes a probe on how consensus was reached likely. If you can say how, in your own words, do; if there was no such step, or it was not yours, say so plainly and stay with the targets set with cross-org consensus | F5 is the evidence for the influence requirement. JD because it scores a stated requirement; the seam framing is the Peer persona's native ground |
| A2 | "What would you need from me and my team in your first 90 days, and what would you give us?" | JD | [grounded] "skilled in SQL/Tableau" | Reciprocity framing: give before you ask. What you offer is future, not past: analysis on the two new lines' land, adopt, expand and renew picture, drawing on "I'm skilled in SQL and Tableau" as stated. Then two or three concrete asks: how the current motion is structured, which data you can query, and who the key stakeholders are | F3 supports the offer. JD because it tests cross-functional fit; the question asks for a plan, so it needs no claim about the past beyond the quote |
| A3 | "How do you handle credit when work spans teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open prompt, so pick a real instance. Selection criteria: a named stake, work that actually crossed teams, and a clear account of who did what. If you use the store-surface story, "proposed" is your verb and "credited" is as stated; say who did the rest only if you know it, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F1 carries the only story with visible credit attached. VAL because it scores partnership behavior, and the Peer persona asks it in collegial packaging |
| A4 | "Say sales strategy sets a target for one of your product lines that you think is wrong. How do you take it up with me?" | CASE | [grounded] "No classic sales-ops or quota-setting experience" | Frame it as how you would approach it, never how you did: first ask how the target was derived, bring your own analysis, propose a test or a range, agree what evidence would change either view, then escalate by agreement. Your material states no classic quota-setting experience, so claim none; the plain words are "I haven't had classic sales-ops or quota-setting experience, so I'd start by learning how yours is derived" | F7 is the gap this case brushes against. CASE because it is a live disagreement with a peer, asking nothing about the past |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Keep the quote's scope: you proposed the change and it was credited with the uplift. Four slots, each in your own words. How it was counted: if you know, say so; if you do not, say plainly you do not know how it was counted. What it is sensitive to: say what you know, or say you do not know. The assumption you would defend least: name it before he does, or say you do not know which. Which part was yours: say exactly what you proposed and what others did. Never supply a method, baseline or attribution you cannot repeat under a second question | F1's headline figure is the likeliest first target. EXP because it tests attribution and the figure's survival |
| B2 | "Walk me through the partner-level revenue model you built for carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-map only what the quote states: you built the model and it was used in carrier negotiations. Answer slot: the JD's partner-motion and SQL/Tableau wording makes probes on how the partnership worked and how the model was built likely. If any part of the partnership's structure was yours, or the model was built in those tools, say so in your own words; if not, or not yours, say so plainly and stay with the model you built | F4 is the evidence for the partner requirement. EXP because it tests what was actually built; JD is secondary because the probe is aimed at the required partner line |
| B3 | "What have you personally run in SQL or Tableau, start to finish?" | JD | [grounded] "skilled in SQL/Tableau" | Name one analysis you actually ran: the question it answered, what you pulled, what you concluded, in your own words. If your use was partial, or the analysis was a team's, say so plainly and stay with the skill as stated. If you have an analysis you can walk through end to end, offer to do so; a prober rewards that offer | F3 is `none` as a gap but has nothing inspected behind it, so expect the probe. JD because it scores the "independent analysis" requirement |
| B4 | "How would you size whitespace across land, adopt, expand and renew for a new product line? What data do you pull first?" | JD | [generic] | Structure it aloud. Clarify: the definition of each stage per product, the unit of analysis, what data exists for a line with little history. Then segmentation, the first queries, a small-sample plan for new lines, how you would validate it with sales strategy, and what would change your mind. This is an approach, not a past claim | F2 is a discovery gap, so this question is rehearsed as an approach. JD because it scores the whitespace requirement; CASE is the delivery |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Northwind's priorities are enterprise expansion, the Compass launch and reaching profitability. Which does an emerging-products GTM lead most help, and which does it strain?" | CO | [grounded] | Pick one of each and say why. Tie the choice to a trade-off you would manage, such as growth spend against the profitability goal. Do not state facts about Northwind beyond your note's three priorities; where you want more, say what you would ask | The three priorities come from your research note, whose date and source I could not check. CO because it tests company-altitude thinking |
| C2 | "The role owns GTM for two new product lines. Sketch your plan. What do you need to know first?" | JD | [grounded] | Clarify first (customers, price points, stage of each line, success measures), then objective, segmentation, approach, metrics, risks. Use his language: packaging, price realization, attach. Challenge one premise respectfully, for example whether both lines need the same motion. No claim about your past | The JD's responsibility line is the raising source. JD because it scores a stated responsibility; CASE is the delivery |
| C3 | "A much larger platform vendor bundles a competing capability into its suite. How does your GTM respond?" | CASE | [grounded] | Clarify what is bundled and for whom. Then structure: where standalone value holds, which segments the bundle does not reach, packaging and pricing responses, whether a partner motion helps, and the metrics you would watch. Name a risk of your own answer | Bundling is the competitive threat in your note. CASE because it is a live strategic problem in his pricing territory |
| C4 | "Where would a partner motion help a B2B data-infrastructure product at this stage, and where would it hurt?" | CASE | [generic] | Criteria, not claims: who owns the customer relationship, margin share, enablement cost, conflict with direct sales, and how you would test it. Note the conflict with direct sales is the seam in A1 | F4's requirement is partner-motion design. CASE because it is a live design question that asks nothing about your past |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't done classic sales ops or quota setting. This role works next to sales strategy. How do you earn credibility in the first 90 days?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus" | The highest-ROI rehearsal. Level 1, the concession, stated plainly: "I haven't had classic sales-ops or quota-setting experience." Level 2, only the quote at its own scope: "I set annual volume targets with cross-org consensus." Never call these quotas. Likely follow-up on how the two differ: answer slot, if you can say how a volume target differs from a quota in practice, do; if you cannot, say so plainly and stay with what you set. Level 3, the plan, said as a plan: in week one you would ask how targets and capacity are built and what the data shows. Hold the concession without apologising and without adding to the quote | F7 is the stated gap and the objection Dan's seat makes most natural. JD because it scores fit for the role next to sales strategy; the Skeptic persona asks it quietly and persists |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" | Calibrated candor. Name the one your material states: sales-ops and quota-setting. Say it plainly, then the plan. Answer slot: if there is another requirement you would be weakest at, say which; if there is not, do not invent one. Do not volunteer a weakness you cannot back | F7 again, from the persona stem. JD because it asks about the listed job's gaps |
| D3 | "You've spent nine years at a large consumer-tech company. Why leave, why a B2B data-infrastructure company, and why now?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Biography at the quote's scope. Answer slot: the reason for leaving is yours, so give your actual reason in your own words. For why here, name the one of the three priorities in your note that genuinely pulls you, and why. Expect a probe on big-company pace; answer with a real example of how work moved, if one exists | F1's biography is the background gap this question presses. EXP because it tests motivation consistency; the Skeptic persona asks it |
| D4 | "Partner-motion design is listed as required. What do you bring, and where is the edge of it?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Lead with the quote as stated: "I built a partner-level revenue model used in carrier negotiations." Name the edge plainly: the quote is a model, not a designed motion, as the pack's own observation. Answer slot: if any part of a partner relationship's structure was yours, say which; if none was, or it was not yours, say so plainly and stay with the model. Then how you would test a motion on a new line | F4 is a transferability gap on a requirement the JD marks required. JD because it scores that line; the Skeptic persona asks for the edge |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That ~$400M ARR. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, restate, then hold: "I proposed the change; it was credited with the uplift." Hold through two follow-ups by returning to that sentence, never adding to it. Concede specifically: say plainly what you do not know about how it was counted or who built it. Never fold on the core sentence to restore harmony | F1's figure under pressure. EXP because it tests attribution; the Pressure persona asks it as a stress test |
| E2 | "Sixty seconds: why you over someone who has run sales strategy for years?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "skilled in SQL/Tableau"; "No classic sales-ops or quota-setting experience" | Three beats in sixty seconds, each at its quote: what you built, what you are skilled in, and the plain concession of the sales-ops gap. Do not disparage the other candidate. Hold the position through two follow-ups, then concede only what is true | F4, F3 and F7 together. JD because it scores fit; the Pressure persona time-boxes it |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus"; "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc made of the quotes' own beats: consulting, then the consumer-tech years, three proof points each at its own scope, then why this role. Answer slot: why this role is in your own words, from your real motivation | The biography question is near-certain and is a scored opener. EXP because it tests whether the CV story is coherent |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | A casual question about a JD plus, and it is scored. Answer slot: name the tools and the tasks you actually use them for, in your own words; if the use is narrower than the question assumes, say so. Do not imply building or shipping AI products. For Compass, ask what Dan is seeing rather than claiming knowledge | F6 is the evidence. JD because it scores the "AI experience a plus" line; the Conversational persona asks it casually |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship intact afterwards. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | No quoted sentence carries this story, so it is a scaffold. VAL from the Values persona stem; kept light because no values round is detected |
| G2 | "When did you put a partner or customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a real trade-off, a metric that visibly took the hit, and an outcome you can state without embellishing. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The partner theme comes from the JD's partner-motion line, but no quote carries the story. VAL because it tests behavior against a trade-off |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| own GTM strategy for two new product lines | C2, C1, C3 |
| identify whitespace across land/adopt/expand/renew | B4 |
| run independent analysis in SQL and Tableau | B3, B2, A2 |
| partner-motion design experience required | D4, B2, C4 |
| strong cross-functional influence | A1, A2, A3, A4 |
| AI experience a plus | F2 |
| the candidate's stated gap (sales-ops and quota-setting) | D1, D2, E2, A4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You've spent most of your career in pricing and monetization. How does that shape how you want sales strategy and emerging products to divide the work?" | Ties to his own path and invites a peer conversation about the seam |
| R2 | "What could a new person on my side do in their first month that would genuinely help your team?" | Reciprocity question for a peer; signals you are thinking about his load |
| R3 | "You had an early-stage chapter. What did it change about how you test a new motion before committing to it?" | Ties to his own path; surfaces how he trades rigor against speed |
| R4 | "Of enterprise expansion, Compass and profitability, which will pull hardest on this role's time and data first?" | Uses your research note's priorities and shows you are planning against them |
| R5 | "When a larger vendor bundles against us, which number would you trust first as a leading indicator?" | Speaks his data-driven language and tests how he thinks about the threat |
| R6 | "What would a strong first 90 days look like, in terms you would measure?" | Pins down the scoring sheet while he is still evaluating you |

## Prohibited claims

Built before the banks, from the fit snapshot. None of these is coached anywhere in the pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran go-to-market for a new product line | Inflated form of F1 | F1's quotes at their own scope; the limit is the pack's observation: the material says product strategy and ops, not a launch |
| Set sales quotas, or had sales-ops experience | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I haven't had classic sales-ops or quota-setting experience." No slot |
| Described the volume targets as quotas | Inflated form of F5 | F5's quote at its own scope: "I set annual volume targets with cross-org consensus." The limit is the pack's observation |
| Designed a partner motion | Inflated form of F4 | F4's quote at its own scope; D4's slot stays inside the model |
| Generated or drove the ~$400M ARR uplift | Inflated form of F1 | F1's quote at its own scope: "proposed", and "credited with" |
| Built or shipped AI features or products | Inflated form of F6 | F6's quote at its own scope: "I use AI tools daily" |

## Sources

**Provided documents:** your message — the JD highlights, the description of Priya, the description of Dan's profile and the research note on Northwind's priorities. No dossier was present, so none was consumed. No loop source beyond your own words was read.

**Searches sent (all refused, so nothing came back):**

- "Northwind Data company values B2B data infrastructure" — refused
- "Northwind Data interview process strategy GTM role" — refused
- "Northwind Data Compass AI copilot launch enterprise expansion bundling" — refused
- "Dan Kovac Director of Sales Strategy Northwind Data" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Would have moved a values cheat sheet and VAL questions themed on published value names; the Values bank is a scaffold bank instead |
| 2. `Northwind Data interview process GTM` | unavailable | Would have moved loop structure and persona weights; they rest on your account of one conversation and on relationship priors |
| 3. `Northwind Data strategy` / recent news | unavailable | Would have moved the CO and CASE rows (C1 to C3) and a grounding brief; those rest on your note, whose date and accuracy I could not check |
| 4. `Dan Kovac Northwind Data` | unavailable | Would have moved the interviewer read beyond your description (talks, writing) and R1 and R3 |
| 5. representative JD | skipped | The JD highlights you supplied fix the requirement rows and the JD-tagged questions |

## Upgrade menu

- Full JD text → F1 to F6's requirement cells would be the JD's own sentences instead of your highlights; it may also surface gate terms (location, travel, pay) I could not check and mid-list requirements I have no questions for
- Priya's CV text or her own sentences → a larger quote pool, so some scaffold and slot rows can become story-mapped
- Priya's answers to the answer slots in F1, F2, F3, F4 and B1 → those rows upgrade from slots to story maps
- Search permission → the four refused targets run, and a deeper pass is available (up to 6 further searches and 2 further fetches, several more minutes)
- The source and date of your research note → C1 to C3 and R4 can be checked against it
- The recruiter's guidance on focus areas or a pre-declared deliverable → coverage and any graded-deliverable section, usually one email
- Prep time available → a prioritized prep schedule
- A `tuesday-dossier.md` from an earlier stage → verified-evidence grading and an underwriter-named top objection; the pack does not need one
