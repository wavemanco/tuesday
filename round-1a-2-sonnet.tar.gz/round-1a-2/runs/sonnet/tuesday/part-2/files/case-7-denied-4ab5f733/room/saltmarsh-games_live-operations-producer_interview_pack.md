# Interview prep pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Format: 60 minutes, one session. Built as a hiring-manager round, because the relationship was not stated: the persona weights rest on that assumption and on a role-family pattern, not on Saltmarsh's documented process.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values (no published values were in hand, so this pack has no VAL bank) |
| EXP | Whether your background survives scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (generic here, because research did not run) |
| CASE | A live problem from the role, scored on structure and reasoning |

Highest-ROI prep: B1, the in-app-purchase question. It is the gap you named yourself, and it will be asked in some form. Rehearse it until it is boring.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not live events and not two titles, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's live-events wording makes a probe on whether the drops included time-limited events likely. If they did, say what, in your own words; if the drops were not events, or there was no such thing, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | low | [inferred] | discovery | Running a calendar does not show which teams worked to it, and the quote says nothing of design, art, engineering or community. Answer slot: if any of those teams worked to your calendar, say which and how, in your own words; if none did, or you did not work with them, say so plainly and stay with the calendar |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | The quote says you presented the numbers, not that you owned them or ran a post-event review, so the words stay at presented: "I presented the monthly retention numbers to the studio head." Answer slot: if any review followed an event or a drop, say what it looked at and what part was yours; if there was no such review, or the numbers were not yours, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap in the wording. Lead with it in the quote's terms: you wrote the checklist and your QA team still uses it. The quote says wrote, not managed, so the words stay at wrote; expect a probe on how it is used day to day |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | presentation | Use the quotes' own words: four years as an associate producer at a puzzle-game studio, and for the last two years the weekly content-drop calendar for your main title. Neither sentence says live-service, so the pack does not say it for you; the interviewer weighs how far associate-level years reach 3+ |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap in the wording: "I ran the weekly content-drop calendar for our main title for the last two years." Expect a probe on how the calendar worked day to day; tell it only as you ran it |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in the wording: "I presented the monthly retention numbers to the studio head." The quote says presented, not which measures or who produced them; C1 rehearses that |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [inferred] | discovery | A checklist is written work, but the quote does not show it read clearly to anyone beyond the people using it. Answer slot: the interviewer may ask for an example of your writing. If you have a piece other teams relied on, say which and what it did; if the checklist is the main example, say so plainly and stay with it |

No JD requirement here is a gate: the experience requirement is graded like any other row. Separately, you told me "Never led a team, and never worked on a game with in-app purchases". The JD names neither, so they are not fit rows; they are on the prohibited list and in B1 and B2.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from the role: plan this calendar, diagnose that drop | High. A hiring manager buys capability and tests it on the real job; the title suggests a senior owner of the calendar. 5 questions | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of the gaps | High. You named two gaps yourself, and a hiring manager derisks them. 5 questions | Rehearse the in-app-purchase objection until it is boring; plain acknowledgment, then a ramp plan |
| Data-Driven Prober | Reads your background line by line; asks how numbers were counted | Medium. The JD names retention metrics and you present them monthly. 3 questions | Know how the retention numbers were counted and say plainly when you do not know; name the assumption you would defend least |
| Conversational | Friendly opener, "walk me through the journey" | Medium. Almost every first ten minutes opens this way, and casual questions are still scored. 3 questions | A 90-second arc made only of your own sentences; use the reverse-question slot |
| Pressure | Time-boxed challenges, "how much was actually you" | Low to medium. A hiring-manager round usually carries a little of it; more if Tobias turns out to be a skip-level. 2 questions | Pause, restate, hold the position through two follow-ups, then concede specifically |
| Peer Evaluator | Seam-splitting between teams | Low. The role coordinates four disciplines, so a collegial version of the objection may appear. 2 questions | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Values / Behavioral | Scenario probes against published values | Not planned. No published values were in hand and no loop source documents a values-style round, so none is detected | Revisit if the recruiter names a values round |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Both titles want a big event in the same fortnight and they share one art team. How do you decide, and what do you need to know first?" | CASE | [generic] | Clarify before you structure: what each event is meant to move, what the shared team can actually deliver, what is fixed and what can slide. Then objective, options, a recommendation with the metric you would watch and the risk you accept. Challenge one premise, for instance whether both really need that fortnight. The question asks about no past, so the guidance makes no claim about yours | JD line on coordinating design, art, engineering and community (F2's requirement), asked as a decision; CASE because it is scored live |
| A2 | "Retention for the cohort that joined during last week's event is 20% below plan. Diagnose it." | CASE | [generic] | Clarify first: how plan was set, how the cohort is defined, whether the drop is in one platform or one source. Then segment, form two or three hypotheses, say what data would split them, and what you would do this week. Say the structure aloud. No claim about your past is needed | Retention is both a JD line (F7's requirement) and the stem a case interviewer reaches for; CASE because the answer is the reasoning |
| A3 | "Sketch a post-event review for an event that ran two weeks. What goes in it, and what happens to it afterwards?" | CASE | [generic] | Structure it: the goal the event was set against, what moved and what did not, what you would change next time, who receives it and who acts. Stay at the level of structure; name no metric you did not track | The JD makes the post-event review and its KPIs a headline duty (F3's requirement), and your material is thinnest there, so the interviewer will test it live |
| A4 | "Plan the release checklist for an update that touches both titles. Who signs off on what?" | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Structure first: scope, owners, gates, what blocks a release, what happens when something fails late. Then one optional sentence, in the quote's words: "I wrote the release checklist our QA team still uses." Answer slot: the JD says manage the checklist with QA, so a probe on sign-off is likely. If sign-off steps were yours to set, say which, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the checklist you wrote | F4 is your strongest direct row; CASE because the live version asks you to build one, not recite one |
| A5 | "We run two titles. What would you want to know about each before you plan their first calendar?" | CASE | [generic] | A clarify-led answer: audience and cadence of each title, what events have done before, what the teams can sustain, what is already committed. Offer a first-month plan only after the questions. No claim about your past is needed | F1's requirement, asked as the opening move of a plan; the quality of your questions is what is scored |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see in-app purchases anywhere in your background. How would you handle that on day one?" | JD | [grounded] "never worked on a game with in-app purchases" — your message; "Presented the monthly retention numbers to the studio head" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment, which you stated: "I haven't worked on a game with in-app purchases." Then a plan, never a past: name who you would learn from, what you would read first, and what you would ask in week one, in your own words. One adjacent fact, kept at its scope: "I presented the monthly retention numbers to the studio head." Follow-up one: how would you tell whether an event paid off. Hold the acknowledgment, say what you would look at first and who you would ask, and do not describe how it works in practice. Follow-up two: what would you do in your first month. Give the plan again, shorter. Concede the limit before you are asked for it. Never imply purchase, revenue or monetization experience | Your own stated gap, and the one a hiring manager who owns the role's commercial results will press. JD because it scores readiness for the job; the wording is the interviewer's premise and the guidance does not adopt it |
| B2 | "I see you haven't led a team. Where does that matter in this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" — your message | Plain acknowledgment: "I haven't led a team." Then separate the two ideas: the JD asks you to coordinate teams on each update, which is not the same as leading them, and you should not blur them. Answer slot: if design, art, engineering or community teams worked to your calendar, say how you worked with them, in your own words; if none did, or you did not, say so plainly and say how you would build those working relationships. No claim of authority over anyone | The JD never lists people management, so this is a probe on whether you will overreach in either direction; JD because it scores a stated requirement (F2) |
| B3 | "You ran the content calendar for your main title. This role has two titles. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Story beats are only what the quote states: a weekly calendar, your main title, two years. Say them in your words. Then say what you would expect to change with two titles: contention for shared teams, two audiences, one person's attention. Answer slot: if your calendar ever touched a second title, say how; if it did not, say so plainly and stay with the main title. Do not say you have run two | F1 is a transferability row; this is the question that tests the distance between one title and two |
| B4 | "The role asks for 3+ years producing live-service games or apps. Walk me through how your years map to that." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Say it in the quotes' words: four years as an associate producer at a puzzle-game studio, and for the last two the weekly content-drop calendar for your main title. Answer slot: if the main title was a live game with updates reaching players on an ongoing basis, say how that ran, in your own words; if it was not, say so plainly and stay with the weekly drops. Do not call the years live-service unless that is how you would describe them | F5 is the literal years requirement; interviewers often screen it directly, so it arrives as a plain question |
| B5 | "Why this role, and why now?" | JD | [generic] | A selection scaffold: name the real reason in one sentence, the one thing in this role you could not get where you are, and one thing you have already done to move toward it. If no reason comes to mind that you would say to a friend, say so plainly and give the nearest true one. Nothing here is supplied by the pack: your motive is yours | The Skeptic's motivation probe; you gave no reason, so the pack cannot map one |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what you presented in the quote's words. Answer slot, in your own words: how the figures were counted, what they are most sensitive to, the assumption you would defend least, and which part of the work was yours. If you do not know how a figure was counted, say so plainly; if you did not produce them, say who did and what you did with them | F7's evidence is a single sentence, so a prober goes straight to it; EXP because it tests attribution |
| C2 | "Which retention measures are you most comfortable with, and which would you want to learn?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | An honest inventory: name the measures you have actually presented or used, and say plainly which you have not. Name one you would learn first and why. Do not list measures to sound complete | The JD says comfortable with player-retention metrics (F7); the question separates comfort from familiarity |
| C3 | "What did the studio head do with those numbers?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: if a decision followed from a presentation, say what and which part of it was yours; if none did, or you do not know, say so plainly and return to presenting the numbers each month. Do not supply a decision or an outcome | Probers ask what changed because of a number; EXP because it tests whether the work had effect or only existed |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc of four beats, each a clause the quotes state: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for your main title, two years; the release checklist you wrote, which your QA team still uses; the monthly retention numbers you presented. Close with one sentence on why this role, in your own words | The opener most interviewers use, and a casual question that is scored for economy |
| D2 | "What live-event calendars do you follow in other mobile games?" | CO | [generic] | A selection scaffold: pick one or two mobile games whose events you actually follow, and say what you notice about how their calendar is paced. If you do not follow any closely, say so plainly and name how you would study two before starting | Generic because no company research ran; it tests genuine interest, which the JD's plus-skills usually draw out casually |
| D3 | "Tell me about a piece of writing of yours that other teams relied on." | JD | [grounded] "Wrote the release checklist our QA team still uses" | Story beats from the quote: you wrote it; your QA team still uses it. Tell it in your words. Answer slot: if you can say what made it clear to people who were not you, say it; if you cannot, say so plainly and stay with the fact that the team still uses it. Offer to show it only if you can | F8's requirement; the checklist is the one written artifact the material carries |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a producer who has run live events with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head"; "never worked on a game with in-app purchases" — your message | Pause and restate the question. Hold on exactly what the quotes carry: the weekly calendar you ran, the checklist your QA team still uses, the retention numbers you presented. Hold through two follow-ups by returning to those, not by adding. Concede specifically: "I haven't worked on a game with in-app purchases." Never fold on the core claim just to settle the room | The stem a stress interviewer uses on the biggest gap; JD because it scores the whole fit |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold the quote: "I wrote the release checklist our QA team still uses." Answer slot: if anyone else shaped it, say who and how; if it was yours alone, say so plainly. Hold through two follow-ups by returning to what you wrote; concede any part that was not yours by name. Never widen the claim from wrote to ran or managed | Attribution probes exist to catch inflation; EXP because it tests precise credit on F4 |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our design, art, engineering and community teams all want a say in the same update. Where's the seam, and what happens when we disagree?" | JD | [generic] | Offer seam principles, not a map you cannot know: who owns the date, who owns the content, who can say no and on what ground. Say what you would bring those teams as well as what you need from them. For the disagreement part, a selection scaffold: pick a time two teams wanted different things in an update; if none comes to mind, say so plainly, then say how you would handle it | The role coordinates four disciplines (F2's requirement), and a peer-style version of that objection can arrive collegially |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] | A selection scaffold: pick a time a result was shared across teams and say how you named each contribution. Use "we" for context and "I" for what was yours. If no such time comes to mind, say so plainly, then say how you would do it | Credit probes test partnership fit; the pack has no quote about shared work, so this stays a scaffold |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 live-events calendar, two titles | A1, A5, B3 |
| F2 coordinate design, art, engineering, community | A1, B2, G1 |
| F3 post-event review and KPIs | A2, A3, C3 |
| F4 release checklist with QA | A4, E2 |
| F5 3+ years live-service | B4, D1, E1 |
| F6 running a content calendar | B3, D1 |
| F7 player-retention metrics | A2, C1, C2 |
| F8 clear written communication | D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is the calendar for the two titles set today, and who has the last word when they collide?" | Shows you think about the calendar as a decision, not a list |
| R2 | "Which KPIs does the post-event review report now, and which one gets argued about?" | Goes to the duty the JD makes yours and invites a real answer |
| R3 | "How do producers here get up to speed on how events perform commercially?" | Raises the ramp you will need without claiming anything you have not done |
| R4 | "How do design, art, engineering and community each find out an update is changing?" | Shows you are thinking about coordination in the team's own terms |
| R5 | "At what point in an update does QA come in, and where does the release checklist sit?" | Ties to the checklist you wrote without overstating it |
| R6 | "What does the team do after an event that missed? What is the review actually for?" | Signals you see the review as something to act on, not only to file |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated: "Never led a team" — your message | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases, or has monetization experience | Negative you stated: "never worked on a game with in-app purchases" — your message | The plain acknowledgment: "I haven't worked on a game with in-app purchases." The ramp is said as a plan, never as a past |
| Ran live events for two titles | Inflated form of F1 | F1's quote at its own scope. The pack's observation: the material says a weekly content-drop calendar for the main title, not events and not two titles. B3's slot stays inside the calendar |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The pack's observation: the material says presented, not owned or defined. A3 and C3 stay at presenting |
| Managed the release process with QA | Inflated form of F4 | F4's quote at its own scope. The pack's observation: the material says wrote the checklist, not managed the release. E2 stays at wrote |

## Sources

Provided documents: the job description you pasted, and your background summary (your message). No dossier was present.

Searches sent, all refused by the host (nothing returned):
- "Saltmarsh Games values" — refused
- "Saltmarsh Games interview process live operations producer" — refused
- "Saltmarsh Games strategy mobile titles news" — refused
- "Tobias Wrenfield Saltmarsh Games" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Would have moved a VAL bank and a values cheat sheet if a values round exists; with none read, both are absent |
| 2. Saltmarsh Games interview process, live operations | unavailable | Would have moved persona weights from the named rounds; the pack uses a hiring-manager prior and says so |
| 3. Saltmarsh Games strategy or recent news | unavailable | Would have moved the CO and CASE banks to Saltmarsh's actual titles; they are generic here |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Would have moved the interviewer read, persona adjustments and one reverse question tied to his path; all absent |
| 5. representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Whether Tobias is your future manager, a skip-level or a peer-level lead → reweights every bank; the pack assumes hiring manager
- The recruiter's prep email, or any stated focus areas or take-home → coverage of a pre-declared deliverable, and the loop confirmed instead of assumed
- Saltmarsh's careers or values page, pasted → a values cheat sheet if a values round exists, and VAL questions
- Tobias's public profile or talks, pasted → an interviewer read, tuned persona weights and a reverse question tied to his own path
- A recent Saltmarsh strategy note or news item, pasted → B-bank and A-bank CO and CASE questions grounded in their actual titles
- Your full CV → F-row evidence beyond your summary, possibly turning F2, F3 and F8 from questions into quotes
- Whether the weekly drops included time-limited events, and which teams worked to your calendar → upgrades F1 and F2
- A writing sample you could show, such as the checklist → upgrades F8 and D3
- A `tuesday-dossier.md` from an earlier run, if you have one → verified evidence and standing prohibited claims; the pack stands without it
