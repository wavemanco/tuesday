# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Prepared 20 November 2026 for three rounds on 29 November 2026, built in loop mode: one shared fit snapshot, then a mini-pack per round.

| Round | Who | Length | Relationship | Format |
|---|---|---|---|---|
| 1 | The recruiter | 30 minutes | Recruiter screen | Conversation |
| 2 | Head of Member Services, who would be your manager | 45 minutes | Hiring manager | Mostly behavioural, per the recruiter |
| 3 | Panel of two branch managers | 60 minutes | Panel, relationship to the role assumed (see Round 3) | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four values |

No interviewer names are assigned yet, so there is no interviewer read in this pack.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values, not generic virtue |
| EXP | Whether the claims in your background survive questioning, and what was actually yours |
| JD | The stated responsibilities and requirements, gaps included |
| CO | Whether you know the company's strategy and can think at its altitude |
| CASE | A live problem set in the role, scored on structure and reasoning |

Question IDs read round, then persona letter, then number: R2-B1 is Round 2, Skeptic, first question. Persona letters: A Conversational, B Skeptic, C Values/Behavioral, D Case/Strategist, E Data-Driven Prober, F Pressure, G Peer Evaluator.

An answer slot is an instruction for the interview, not a question for you now. Where a slot says to say something plainly, that branch is as good as the other.

## Prep triage

Nine days, 20 to 29 November. Do these in order; each is tied to a section or question.

| Order | When | Do | Tied to |
|---|---|---|---|
| 1 | Fri 20 to Sat 21 Nov | Write your own answer to each answer slot in the fit snapshot, honest branch included, and decide your pay approach, notice period, location constraints and reason for leaving | F1, F3, F4, F5, F7, F9; R1-A3 to R1-A6 |
| 2 | Fri 20 to Sat 21 Nov | Confirm the day and start times of all three rounds with the recruiter: 29 November 2026 falls on a Sunday, and nothing you sent says otherwise | R1 reverse questions |
| 3 | Sun 22 to Mon 23 Nov | Say the two concession sentences aloud until they are boring, then run the contact-centre objection through all four follow-up levels | R2-B1, R3-F1, R1-B1, R1-B2 |
| 4 | Tue 24 Nov | Walk through the complaints log and the monthly spreadsheet aloud, ending with the part you would trust least | R1-B4, R2-E1, R2-E2 |
| 5 | Wed 25 to Thu 26 Nov | Pick one story per value, four in all, and write only the beats you can stand behind; Round 2's behavioural questions reuse them | R3-C1 to R3-C4, R2-C1 to R2-C3 |
| 6 | Fri 27 Nov | Run the escalation case aloud against a twenty-minute timer, then the disagreement twist | R3-D1, R3-D3, R2-D1 |
| 7 | Sat 28 Nov | Strategy questions once, reverse questions once, then stop | R2-D2, R3-D2, reverse questions |

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process across branches, and the words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on anything beyond your branch likely. If any complaint work reached past your own branch, say what and which part was yours, in your own words; if none did, say so plainly and stay with the log you handled |
| F2 | "and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says the sheet was monthly, about complaints, and used by your regional manager; it does not say what it counted. Answer slot: the JD's reporting line makes a probe on what the sheet counted likely. If you can say what it counted and how, say so in your own words; if you do not know how some of it was counted, say so plainly and stay with the sheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your sentence carries new tellers and the escalation script, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's supervisor line makes a probe on who else you have taken through escalations likely. If anyone beyond the new tellers had the script or escalations explained to them by you, say who and which part was yours; if not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show work with a digital team. Answer slot: the JD's self-service line makes a probe likely. If you worked with any digital or online team on something members used, say what it was and which part was yours; if not, say so plainly and say how you would approach it |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Your sentence reaches the requirement in other terms: retail banking, not customer operations. Lead with your own terms and let the interviewer map them: "I worked in retail banking for six years, the last three as a branch supervisor." A line with nothing inspected behind it, so expect a probe |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your sentence says formal complaints, in a log you handled; it does not say how each complaint was governed. Answer slot: the JD's requirement makes a probe on that likely. If the log came with set steps for how each complaint was handled, say which and which were yours to follow or set; if it was the branch's own record with no such steps, or the steps were set elsewhere, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented above regional level." Then how you would prepare for it, said as a plan and never as a past. The sentence does not say what you presented at regional level, so the pack describes none of it |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says spreadsheet, and the words stay there: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names a specific tool, so expect a probe on yours. Name the tool you used, whatever it was, and say what you built in it; if it was not the tool the JD names, say so plainly and stay with the sheet you built |

No requirement in the JD is a gate in the sense of a term you either meet or do not; the years requirement is graded as experience (F6).

## Grounding brief

Built from the four-point summary you gave of Ashgrove's 2026 strategy brief, published July 2026 and sent by the recruiter, not from the full brief. The brief is public to every prepared candidate, so use it to show you have read it, then add a thesis of your own.

| Item | What the brief says, as you summarised it | Provenance | Where it comes up |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | [grounded] | R1-B3, R2-D2 |
| Branch consolidation | Consolidate eight branches into five hubs over 2027 | [grounded] | R3-D2, R3-C3 |
| New product | Launch a small-business lending product in Q1 2027 | [grounded] | R1-A3 |
| Competitive pressure | The main competitive pressure is app-only banks | [grounded] | R1-A3, R2-D2 |
| Date | Published July 2026; the 2027 timings are as of then | [grounded] | R1 reverse question 1 |

## Round 1: the recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Conversational | Friendly, unstructured; logistics asked casually | High: recruiter-screen prior; the pack counts six questions here because pay, notice, location and the reason for leaving each get a row | Treat every casual question as scored; a short arc for the biography question |
| B Skeptic | Quiet knockout checks on the gaps | Medium: the recruiter-screen prior is light Skeptic, and your message states two limits (F2, F8) that a screen would check | Say each limit plainly first, then your plan as a plan; R1-B1 and R1-B2 |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc with only the beats those sentences state: six years in retail banking, the last three as a branch supervisor; handling the branch's formal complaints log; training new tellers on the escalation script; building the monthly complaints spreadsheet. Tell them in your own words at those scopes. Answer slot: the closing beat, why this role now, is yours alone; say it in your own words and keep it consistent with R1-A3 and R2-B4 | The opener every screen has, and where the rest of the loop first hears your story; F6, F1 and F3 supply its beats. EXP because it tests what was actually yours |
| R1-A2 | "What drew you to Ashgrove?" | CO | [grounded] | Pick one thing you can speak to honestly from what Ashgrove published: one of the four values by its exact name, or one point from the strategy brief. Say why it matters to you in your own words. Answer slot: if what drew you is something else, say that plainly; do not borrow a value you do not hold | A motivation probe that also scores homework; the values and brief are in hand. CO because it tests company knowledge |
| R1-A3 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot: give your actual reason in one or two sentences, in your own words, about what you are moving toward; if part of it concerns your current employer, say it without blame. Keep it consistent with R1-A1 and R2-B4 | The recruiter row of the persona priors carries this question every time. EXP because it tests consistency of your own account |
| R1-A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words. The pack has no figure for you and supplies none | A term of the listed job that a recruiter must have. JD because it scores the job's terms |
| R1-A5 | "What are your salary expectations?" | JD | [generic] | Logistics slot: choose between giving your own number and asking for the role's band first; either is yours to choose, and the pack supplies no figure | The one question most likely to be mishandled by guessing. JD because it scores the job's terms |
| R1-A6 | "Where and how often can you work?" | JD | [generic] | Logistics slot: say plainly where you can work and how often, as your own constraints; the posting you sent does not state a location, so this is yours to establish with the recruiter | Location is a term of the job, and your material says nothing on it. JD because it scores the job's terms |
| R1-B1 | "I don't see contact-centre experience in your background, and the role covers the contact centre. How would you handle that side of it?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say the limit first, in your own words: "I haven't worked in a contact centre." Then a plan, said as a plan and never as a past. Answer slot: name what you would learn first and who you would ask, in your own words; the pack knows nothing of this employer's contact centre and supplies none of it. If asked what you do bring, return only to what your sentences carry: you handled the branch's formal complaints log | F2 is the stated gap and the recruiter's most likely knockout check; R2-B1 rehearses the same objection at full depth. JD because it scores the stated requirement |
| R1-B2 | "The role asks for confidence presenting to senior leaders. What's your experience of that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say the limit first, in your own words: "I haven't presented above regional level." The sentence does not say what you presented at regional level, so describe none of it. Then your plan for a first senior presentation, as a plan. Answer slot: if you want to mention work at regional level, say only what happened, in your own words; if nothing was presented, say so plainly | F8 is the second stated gap. JD because it scores the stated requirement |
| R1-B3 | "Tell me about a time you worked with a digital or online team on something members used." | JD | [grounded] | Selection scaffold: pick a time you took a member-facing problem to a team that builds or runs an online or app journey; it needs the member's problem, what you brought the team, and what changed or did not. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would approach it | F5 has no evidence either way, and the brief's 40% digital aim makes it live. JD because it scores the self-service requirement; open prompt, so no premise |
| R1-B4 | "Walk me through how you handled the branch's formal complaints log." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F7: the log, and that it held the branch's formal complaints, which are the beats the quote states; tell them in your own words. Answer slot: if the log came with set steps for how each complaint was handled, say which and which were yours to follow or set; if it was the branch's own record with no such steps, or the steps were set elsewhere, say so plainly and describe how you kept the log | F1 and F7 are the evidence for the JD's complaints requirements and the likeliest place to be probed. EXP because it tests what was actually yours |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "The strategy brief is dated July. Have the 2027 timings for the hubs or the small-business launch moved since?" | Shows you read it, and checks the one source the pack's strategy rows rest on |
| 2 | "Can you tell me what the panel's 20-minute case will look like, and whether I should prepare anything in advance?" | The case is the loop's biggest unknown; a recruiter can usually say whether it is written or spoken and whether materials come first |
| 3 | "Can you share the panel's names once they are assigned?" | Unlocks the interviewer read and reweighting in this pack |
| 4 | "Who does this role work with on the contact-centre side today?" | Turns your biggest gap into ownership of a first question |
| 5 | "Is there an existing monthly complaints report, and who reads it?" | Ties to the reporting requirement and tells you what you would inherit |

## Round 2: the Head of Member Services (45 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| B Skeptic | Probes the two stated gaps and the move from supervisor to lead | High: the hiring-manager prior is Case plus Skeptic, because this person is buying capability and derisking gaps, and F2 and F8 are stated limits | R2-B1 at full depth; calibrated candour, never bluffing a competency |
| C Values/Behavioral | Scenario probes tied to the published values | High: the recruiter says this round is mostly behavioural, which lifts it above the prior | Story picks in advance; we for context, I for contribution |
| D Case/Strategist | A live problem or a strategy question | Medium: the hiring-manager prior; the brief supplies the roadmap | Clarify, objective, segmentation, approach, metrics, risks, aloud |
| E Data-Driven Prober | Goes line by line on the one artifact in your background | Low to medium, and an inference: the spreadsheet is the one inspectable thing in your message | Say what you can and cannot say about how it was counted |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-B1 | "I don't see contact-centre experience in your background, and this role owns the process across the contact centre as well as branches. How would you do that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The highest-ROI rehearsal in this pack. Open with the limit, in your own words: "I haven't worked in a contact centre." Then a plan, said as a plan. Expect four levels of follow-up and rehearse each until it is boring: what would you want to learn in your first weeks; who would you ask and what would you ask them; what if people there doubt a branch person should own it; what would you not claim yet. Hold through all four by returning to what your sentences carry, that you handled the branch's formal complaints log, and never by adding to it. Answer slot: each of the four answers is a plan in your own words; the pack knows nothing of this employer's contact centre and supplies no name, system or practice. Say the limit before you are asked for it | F2 is the stated gap and the one objection that arrives in some form in all three rounds; a rehearsed, non-defensive answer changes the interview. JD because it scores the stated requirement |
| R2-B2 | "Your complaints experience is one branch's log. How does that get you to owning the process end to end across all of our branches?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold on what the sentence carries: "I handled the branch's formal complaints log." Answer slot: if any complaint work reached past your own branch, say what and which part was yours; if none did, say so plainly and stay with the log you handled and what you would want to learn about the other branches. Hold through two follow-ups by returning to the log, never by widening it | F1 is where the end-to-end mandate presses hardest. JD because it scores the stated requirement; the premise is the quote's own, since the log is the branch's |
| R2-B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose honestly. Your message names two limits, the contact centre and presenting above regional level; say the one you would rank first, plainly, then your plan for it as a plan. Answer slot: if a different part of the JD worries you more, say that one; the pack does not know which | The stock Skeptic stem, and the quickest test of honest self-assessment. JD because it scores the whole requirements list; F2 and F8 are the evidence |
| R2-B4 | "Your last three years were as a branch supervisor. Why move to a complaints lead role, and why here?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Start from the quote's own terms: the last three years as a branch supervisor. Then your reason, in your own words: what you want to do that the supervisor role did not let you. Answer slot: the reason is yours alone; keep it consistent with R1-A3 and R1-A1, and if part of it is practical, say so plainly | Motivation consistency across rounds is what a manager checks. EXP because it tests whether your account holds; F6 is the evidence |
| R2-C1 | "Tell me about a time you put a member ahead of an internal metric or process." | VAL | [grounded] | Selection scaffold: pick a time where what was easiest for the branch and what was right for the member pulled apart and you chose the member; it needs the member's situation, the decision that was yours, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would decide. Reuse the story you pick for R3-C1 | Members First, Always is published, and this is the persona stem for it. VAL because it scores behaviour against that value; open prompt, so no premise |
| R2-C2 | "Tell me about a time you had to give someone senior an unwelcome message." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear and it was heard; it needs what the message was, how you put it, and what happened. We for context, I for what you said. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would do it | A standard behavioural stem that also probes F8 sideways. VAL because it scores behaviour; open prompt, so no premise |
| R2-C3 | "Tell me about a time something you wrote or said to a member had to be reworded so they understood it." | VAL | [grounded] | Selection scaffold: pick a time wording failed and you changed it; it needs what was unclear, what you changed, and how you knew it worked. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would test wording. Reuse the story you pick for R3-C2 | Plain Words is published in terms of explaining twice. VAL because it scores behaviour against that value; open prompt, so no premise |
| R2-D1 | "A member has raised the same complaint three times, and each branch or team they contact says someone else owns it. Where do you start?" | CASE | [grounded] | Clarify aloud first: what the member has been told, by whom, what they now want, what the records show. State the objective, say who owns it today, then what the member hears first and what you fix after; add how you would know it is fixed and the risk of acting too fast. The published value Own the Fix supplies a principle you can name: whoever finds the problem keeps hold of it until it is solved. Challenge one premise respectfully, for example whether it is one complaint or three. No claim about your past is needed | A live problem from the role's ownership line, and the scenario is the pack's own pattern; grounded in the published value only. CASE because it scores structure |
| R2-D2 | "Ashgrove aims to have 40% of member service on digital channels by 2028. What should happen to a complaint that starts in the app?" | CO | [grounded] | Structure it aloud: what you would need to know first and would ask, not assume, then the objective, then which kinds of complaint suit self-service and which stay with a person: choose your own and say what would change your mind. The brief is public to every prepared candidate, so bring one point from it, then one thesis of your own with a concession, and say where you would say no. No claim about your past is needed | The differentiator question most candidates cannot touch; the strategy summary is in hand. CO because it tests altitude; CASE in delivery |
| R2-E1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F3 and F9: that you built it, that it was monthly and about complaints, and that your regional manager used it; tell them in your own words. Answer slot: if you can say what it counted and how, say so; if you do not know how some of it was counted, say so plainly and stay with what you built. If asked which tool, name the tool you used, whatever it was | The one inspectable line in your background, and the likeliest place to be probed. EXP because it tests what was actually yours |
| R2-E2 | "Which part of that spreadsheet would you trust least?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The weakest-assumption move: say, in your own words, the part you would defend least before the interviewer finds it. Answer slot: if you cannot say how part of it was counted, say that plainly; the pack names no assumption because your sentence names none | Converts a gotcha into a credibility gain. EXP because it tests attribution honesty; F3 and F9 are the rows |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How do you expect the move from eight branches to five hubs to change where complaints come in?" | Uses the brief and shows you are thinking at the role's altitude |
| 2 | "What would you want to be different about the complaints process twelve months from now?" | Gets the manager's own success definition |
| 3 | "Where does the 40% digital aim leave complaints, and which would you want kept with a person?" | Invites the manager to think aloud on the brief's biggest number |
| 4 | "How do you see supervisor coaching working here: one to one, in groups, or from the data?" | Shows you are thinking about F4 and learns the manager's style |
| 5 | "Given that I haven't worked in a contact centre, what would you want to see from me in the first three months?" | Says the limit first and turns it into a working question |

## Round 3: the panel of two branch managers (60 minutes, including a 20-minute case)

Built on the recruiter's words that the panel also scores against the four values. Assumption: the two branch managers sit beside the process this role owns, because the role coaches branch supervisors; if you learn their relationship differs, say so and the weights change.

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| C Values/Behavioral | One scenario probe per published value, STAR-shaped | Highest: the recruiter says the panel scores against the four values, so a values-style round is documented | One story per value, picked in advance; we for context, I for contribution |
| D Case/Strategist | The 20-minute complaint-escalation case, plus a strategy probe | High: the recruiter names the case; the brief gives the hub plan | Clarify, objective, ownership, approach, metrics, risks; say the framework aloud |
| G Peer Evaluator | Seam and coaching questions between branches and your team | Medium, and an inference: the role coaches branch supervisors, so the managers' interest is in what it does to their load | Reciprocity: what you bring them, not only what you need |
| F Pressure | A time-boxed challenge on the two limits | Low: a panel prior blends each member's top two personas, and neither member is known | Pause, restate, concede specifically, hold on what you did |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-C1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a decision where the easy route and the member's side pulled apart and you chose the member's; it needs the member's situation, the decision that was yours, and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, that you handled the branch's formal complaints log, or how you would decide | Members First, Always is published and scored here. VAL because it scores behaviour against the value; the cheat sheet maps it. F1 holds the nearest thing |
| R3-C2 | "Tell me about a time something had to be explained to a member twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a time the first explanation failed and what you changed; it needs what was unclear, what you did, and how you knew it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, that you trained new tellers on the escalation script, or how you would find out | Plain Words is published in exactly these terms. VAL because it scores behaviour against the value; open prompt. F4 holds the nearest thing |
| R3-C3 | "Tell me about a time what a branch meant to its town pulled against what the numbers said." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Selection scaffold: pick a time a local consideration and a figure pointed different ways and you had a part in the outcome; it needs both sides, your part, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the last three years as a branch supervisor, or how you would weigh it | Neighbours, Not Numbers is published, and the brief's hub plan makes it live. VAL because it scores behaviour against the value; open prompt. F6 holds the nearest thing |
| R3-C4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a problem you found and stayed on until it was fixed; it needs what you found, what you did yourself, who you had to chase, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, that you handled the branch's formal complaints log, or how you would keep hold of one | Own the Fix is published, and the role is defined by it. VAL because it scores behaviour against the value; open prompt. F1 holds the nearest thing |
| R3-D1 | "Here is a case. A member's complaint has gone from the contact centre to a branch and back. The supervisor says it is not theirs and the member is angry. You have twenty minutes. How do you handle it?" | CASE | [generic] | Say your framework aloud before using it. Roughly: clarify first (what the member has been told, what they want, what the records show, what is already in motion); state the objective; say who owns it from now; what the member hears first, in plain words; what you fix after; why it bounced and what would stop it bouncing again; how you would coach the supervisor without blame; how you would know it is fixed; the risks. Challenge one premise respectfully. You have not worked in a contact centre, so ask how its handoffs work rather than assume. No claim about your past is needed | The panel's real case is unknown, so this is the pack's pattern for the recruiter's escalation case, not a prediction of it; generic by design. CASE because it scores structure |
| R3-D2 | "Eight branches become five hubs over 2027. As complaints lead, what would you do about complaints during that change?" | CO | [grounded] | Structure aloud: what you would need to know first (which branches, when, what members are told), who is affected, then your approach, with a thesis of your own and its concession; the brief is public to every prepared candidate, so bring one point from it then diverge, and say where you would say no. Neighbours, Not Numbers is the published value that bears on it. No claim about your past is needed | The brief's hub plan touches branches, and the panel are branch managers, so this question is plausible: that is the pack's inference. CO because it tests altitude; CASE in delivery |
| R3-D3 | "The supervisor involved disagrees with you in front of us and says your approach is wrong. What do you do?" | CASE | [generic] | The composure test inside the case. Pause and restate their point; ask what they would do differently; separate what the member needs from the disagreement; concede what is fair and say specifically what; hold where the position protects the member. Then how you would follow up with them afterwards, as a plan. No claim about your past is needed | The twist most likely to follow a 20-minute case; scores how you hold a position in front of the people being coached. CASE because it scores reasoning under challenge |
| R3-G1 | "How would you coach a supervisor who escalates complaints they could have resolved themselves?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4 only as far as the sentence goes: you trained new tellers on the escalation script. Answer slot: if anyone beyond the new tellers had the script or escalations explained to them by you, say who and which part was yours; if not, say so plainly and stay with the tellers. Then your approach as a plan: what you would ask first and what you would offer, in your own words | F4 is the evidence for the coaching requirement and the point where the JD's wording presses. JD because it scores the stated requirement |
| R3-G2 | "Our branches and your team sit side by side. Where is the seam, and what happens when we disagree about a complaint?" | VAL | [grounded] | Propose seam principles rather than pretending to know the seam. The published value Own the Fix gives one you can name: whoever finds the problem keeps hold of it until it is solved. Then how a disagreement gets settled and what the member hears meanwhile. A disagreement story, if you have one, is a selection scaffold: pick a time you disagreed with an equal and the relationship survived; if no such time comes to mind, say so plainly and say how you would handle it | The peer stem; the published value gives you a principle that is Ashgrove's own words. VAL because it scores ownership behaviour against the value |
| R3-G3 | "What would you need from branch managers in your first ninety days, and what would you bring us?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Reciprocity first: what you bring, only at the scope your sentences carry, that you handled the branch's formal complaints log, trained new tellers on the escalation script, and built a monthly complaints spreadsheet. Then what you need, in your own words. Answer slot: your needs are yours; the pack names none | A reciprocal question branch managers weight heavily. JD because it scores the role's working relationships; F1, F3 and F4 are the evidence |
| R3-F1 | "Sixty seconds: you've never worked in a contact centre and you've never presented above regional level. Why you?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Pause and restate the question. Concede both limits first, plainly: "I haven't worked in a contact centre. I haven't presented above regional level." Hold on what you did: you handled the branch's formal complaints log, trained new tellers on the escalation script, built the monthly complaints spreadsheet. Hold through two follow-ups by returning to those, never by adding to them. Answer slot: why you for this role is yours alone; say it in your own words | The Pressure stem built from F2 and F8. JD because it scores the whole requirements list |

### Values and principles cheat sheet

A values-style round is documented: the recruiter says the panel scores against these four. Names are as you copied them from Ashgrove's values page this morning. One story per value; R2-C1 to R2-C3 reuse these.

| Value | Working meaning, paraphrased | Mapped story |
|---|---|---|
| Members First, Always | Decisions are made from the member's side of the counter | Selection scaffold (R3-C1): pick a decision where the easy route and the member's side pulled apart and you chose the member's; if none comes to mind, say so plainly, then give the nearest thing F1 carries, "I handled the branch's formal complaints log and trained new tellers on our escalation script.", or how you would decide |
| Plain Words | If a member needs it explained twice, the wording was wrong | Selection scaffold (R3-C2): pick a time the first explanation failed and what you changed; if none comes to mind, say so plainly, then give the nearest thing F4 carries, "I handled the branch's formal complaints log and trained new tellers on our escalation script.", or how you would find out |
| Neighbours, Not Numbers | Every branch counts as part of its own town | Selection scaffold (R3-C3): pick a time a local consideration and a figure pointed different ways and you had a part in the outcome; if none comes to mind, say so plainly, then give the nearest thing F6 carries, "6 years in retail banking, the last 3 as a branch supervisor.", or how you would weigh it |
| Own the Fix | Whoever finds a problem stays responsible until it is solved | Selection scaffold (R3-C4): pick a problem you found and stayed on until it was fixed, with who you chased and how it ended; if none comes to mind, say so plainly, then give the nearest thing F1 carries, "I handled the branch's formal complaints log and trained new tellers on our escalation script.", or how you would keep hold of one |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What do you most want a complaints lead to change about how escalations reach your branch?" | Puts their pain first and shows you are listening for their view of the role |
| 2 | "When does the escalation route work well for your supervisors, and when does it not?" | Invites their own examples and tells you what the case may be modelled on |
| 3 | "What could a new person do in their first month that would genuinely help your branch?" | The reciprocity question; branch managers weight the offer of help |
| 4 | "What do members' complaints look like in the weeks around a branch change, in your experience?" | Connects the hub plan to their daily work, in Neighbours, Not Numbers terms |
| 5 | "Which of the four values is hardest to hold in a branch day to day?" | Invites a real story from them and shows you read the values as practice, not slogans |

## Requirement coverage

| JD requirement | Questions | Note |
|---|---|---|
| Own the complaints process end to end across branches | R2-B2, R1-B4, R3-D1 | |
| Across the contact centre | R1-B1, R2-B1, R3-F1, R3-D1 | |
| Report monthly on complaint volumes and resolution times | R2-E1, R2-E2 | |
| Coach branch supervisors on escalations | R3-G1, R3-D3, R3-G3 | |
| Work with digital teams on self-service journeys | R1-B3, R2-D2 | |
| 4+ years in financial-services customer operations | R1-A1, R2-B4 | |
| Experience handling regulated complaints | R1-B4, R3-D1 | |
| Confident presenting to senior leaders | R1-B2, R2-C2, R3-F1 | |
| Comfortable with Excel reporting | R2-E1, R2-E2 | |

## Prohibited claims

Built locally from the fit snapshot; no dossier was present. Nothing in this pack coaches these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation, not words for you: the material says the branch's log, not the process across branches. R2-B2's slot stays inside the log |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: "I handled the branch's formal complaints log." The material says formal complaints, in a log; that is the pack's observation. R1-B4's slot asks only about the steps the log came with |
| Reported monthly on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." R2-E1's slot asks only what the sheet counted |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: "trained new tellers on our escalation script". R3-G1's slot asks only whether anyone beyond the tellers was taken through the script |
| Built the reporting in Excel | Inflated form of F9 | F9's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." R2-E1's slot asks you to name the tool you used |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders or above regional level | Negative you stated, F8 | The plain acknowledgment: "I haven't presented above regional level." No slot |

## Sources

Provided documents: the job description as pasted; the four values as pasted, which you said were copied on 20 November 2026 from ashgrovecu.org/about/values; the recruiter's email about the three rounds; your four-point summary of the 2026 strategy brief published July 2026; your background paragraph in your message. No dossier was present. No search or fetch was sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the values cheat sheet and every VAL question; nothing a search could return would change either |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email establishes the loop: three rounds, who runs each, and the case in Round 3; it fixes every persona weight |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | Your four-point summary of the July 2026 brief supplies the current priorities that the CO rows and the grounding brief draw on; a fuller brief is an upgrade-menu item |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer has been assigned a name, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you pasted fixes the fit snapshot and every JD question |

## Upgrade menu

- Your written answers to the answer slots → F1, F3, F4, F5, F7 and F9 become quoted evidence, and R1-B4, R2-B2, R2-E1, R2-E2 and R3-G1 regenerate as story maps instead of slots
- The monthly complaints spreadsheet with member details removed, and the escalation script, only what you are free to share → F3, F9 and F4 can move from medium toward high
- Your CV → any line it holds that your message does not becomes quoted evidence and may close or shrink a gap
- The panel's names, once assigned → an interviewer read from public professional footprint, reweighted personas, and a reverse question tied to their path
- The recruiter's answer on the case format → R3-D1 reshaped to the real format, and a build section if anything must be prepared in advance
- The full July 2026 strategy brief → the CO and CASE rows now built on your four-point summary gain the brief's own wording and figures
- Prep hours per day → the triage sized to your actual time
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes, covering recent organisational context and role-family loop reports (forum claims labelled `[inferred]`), plus the interviewers' public footprint once named → say the word and I'll run it
- A `tuesday-dossier.md` from an earlier fit check → verified evidence and prohibited claims would replace the ones this pack built locally; the pack stands without it
