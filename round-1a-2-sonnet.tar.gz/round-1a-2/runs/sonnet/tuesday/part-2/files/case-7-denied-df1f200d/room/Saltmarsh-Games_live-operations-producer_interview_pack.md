# Interview prep pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Session: one 60-minute interview. Relationship assumed to be hiring manager; your note did not confirm it, and a different answer would reweight the banks.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script: where a cell says answer slot, the words are yours, from what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: whether past behavior shows the company's published values |
| EXP | Work-experience deep-dive: whether your claims survive scrutiny, and what was actually you |
| JD | Role and JD-driven: the stated responsibilities and qualifications, gaps included |
| CO | Company and strategy knowledge: homework depth |
| CASE | Hypothetical or live problem: structure and reasoning on a problem from the role |

Provenance labels: `[grounded]` traces to what you or the JD said; `[inferred]` is derived from a named source; `[generic]` is a role-family pattern with no claim about you or Saltmarsh.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | presentation | Your sentence says a weekly content-drop calendar, not a live-events calendar, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Nothing is inspected behind it, so expect a probe |
| F2 | "for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your sentence carries one calendar, for your main title, and the words stay at that scope. Answer slot: the JD says two titles, so a probe on what two calendars at once adds is likely. If you have worked on a calendar that covered more than one title, say how, in your own words; if not, say so plainly and stay with the calendar you ran |
| F3 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show how updates were coordinated across those teams. Answer slot: expect a probe on how you have worked with them. If you worked with any of them on updates, say which and what you did, in your own words; if you did not, or it was not yours, say so plainly and return to the calendar you ran |
| F4 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your sentence is presenting numbers, not owning a review or its KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD names a post-event review, so expect a probe on whether one existed where you worked. If you wrote or ran one, say what it covered; if there was none, or it was not yours, say so plainly and stay with presenting the monthly numbers |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Lead in the sentence's own terms: "I wrote the release checklist our QA team still uses." Your material says wrote and still used, not how releases were managed with QA, and nothing is inspected behind it |
| F6 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material does not show which of the four years were on a live title, or whether the title is one the JD would call live-service. Answer slot: expect a probe on both. Say how the title ran, in your own words; if it did not run as a live-service game, say so plainly and stay with the calendar you ran |
| F7 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead in the quote's terms: you ran it, weekly, for the main title, for the last two years |
| F8 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap on the wording, and no figure was given, so no number is defended here. If asked how a number was counted, say how if you know, and say plainly if you do not. Lead in the quote's terms: monthly, retention numbers, the studio head |
| F9 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [grounded] | discovery | A written document others rely on touches the requirement without showing how clear it was. Answer slot: if another document you wrote was worked from by others, say which and who used it; if the checklist is the main one, say so and stay there |
| F10 | Familiarity with in-app purchases: plain prose, generic, not a line of this JD | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F11 | Leading a team: plain prose, generic, not a line of this JD, which asks you to coordinate teams | "Never led a team" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't led a team." Coordinating is a separate row (F3) and is not converted into leading |

## Persona table

Relationship prior: hiring manager (assumed). Interviewer signals: none established, because the interviewer searches were refused, so nothing adjusts the prior. Loop: your words give one 60-minute session with Tobias Wrenfield, so no archetype fallback applies, and no values-style round is detected; there is no Values persona bank for that reason.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A, 5 questions) | Live problems from the role: plan this, diagnose that | High. Hiring-manager prior; the JD's calendar, review and retention lines convert directly into problems | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (bank B, 5 questions) | Quiet, persistent probing of gaps and motive | High. Hiring-manager prior; F10 and F11 are gaps you stated yourself, and F2 to F4 are thin | Rehearse the single most predictable objection (B1) until it is boring; bridges only from adjacent evidence you stated; a concrete ramp plan |
| Data-Driven Prober (bank C, 3 questions) | Reads your lines closely; asks how numbers were counted | Medium. Not a hiring-manager default; raised because F4 and F8 are the metric lines a close reader tests | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| Conversational / Rapport Builder (bank D, 3 questions) | Friendly opener, casual questions that are still scored | Medium. Every pack prepares the biography arc and the casual register, so neither is met for the first time live | A 90-second arc built only from your own sentences; treat casual questions as scored |
| Pressure (bank E, 2 questions) | Time-boxed answers, challenges on motive and attribution | Low. Hiring-manager prior puts it behind the Skeptic; included so the style is not new | Pause, restate, anchor in what you stated; hold through two follow-ups before conceding anything real |
| Peer Evaluator (bank P, 2 questions) | Seam-splitting between teams, credit and disagreement | Low. The JD's coordination line makes collegial versions of the Skeptic's questions plausible | Reciprocity framing; propose seam principles rather than pretending to know the seam |

## Question banks

### Bank A: Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two events are due the same weekend across the two titles, and engineering says only one can ship safely. How do you decide, and who do you talk to first?" | CASE | [generic] | Clarify first: what is fixed and what can move, what slipping costs each title, what has already been promised to players. Then state the objective and the options (ship one, stagger, cut scope on one), what you would compare them on, and the risks of each. Say your hypothesis early and challenge one premise respectfully. Close with who you would bring the trade-off to across design, art, engineering and community. The question needs no claim about your past, so the guidance makes none | F2's requirement tested as a decision rather than a record. CASE because it is a live problem; `[generic]` because it is a pattern for the problem, not a fact about Saltmarsh |
| A2 | "Retention for new players dipped during an event compared with the one before. Walk me through how you would diagnose it." | CASE | [generic] | Clarify: which new-player cohort, measured over which days, against which earlier event, and what else changed at the same time. Segment before concluding, rank hypotheses by how cheaply each can be checked, say what you would pull first, and what you would decide if the cause were the event itself versus something around it. No claim about analysis you did; none is carried here | F8's requirement in live form. CASE because it is a diagnosis delivered live |
| A3 | "Sketch the plan for a four-week run of live events for one title. What do you need to know first?" | CASE | [generic] | Clarify before structuring: the goal for the four weeks, how far ahead each team needs to be told, what dates are fixed. Then shape the weeks (a lead event, a lighter week, a buffer), set a checkpoint with design, art, engineering and community, and say what you would review after each event. Name how a slipped date would be handled. No claim about your past | F1 and F7's requirement as a planning problem. CASE delivery, with JD content |
| A4 | "Art tells you on Tuesday that an event's key assets will land two days after the date community has already announced. What do you do?" | CASE | [generic] | Clarify the size of the slip: what exactly is late and whether a reduced version exists. Then the options (ship reduced, move the date with a clear note to players, ship on the date with a placeholder), who decides and who must hear first, and what the post-event review should record. No claim about your past | F3's requirement as a pressure scenario across teams |
| A5 | "How would you set up a post-event review so it changes what the next event does? Which numbers would it report?" | JD | [generic] | Ask what the studio already reports. State the event's goal before the event, pick a few numbers tied to that goal (the JD names retention as one area), say which baseline you would compare against and what would make you distrust the comparison, and end every review with named decisions and owners. No claim about reviews you have run | F4's requirement. JD because it scores the stated responsibility; the question is about how you would work, not what you did |

### Bank B: Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see in-app purchases anywhere in your background. How would you get up to speed on them?" | JD | [grounded] "never worked on a game with in-app purchases" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment, in these words and no others: "I haven't worked on a game with in-app purchases." Then give the plan, as a plan: what you would ask to be walked through first, which past event reviews you would ask to read if any exist, who you would sit with, and by when you expect to follow a purchase-related discussion. Name the limit before it is asked for: you would be learning this, not bringing it. Follow-up 1, "What would you do in your first month?": answer with the plan's first concrete step. Follow-up 2, "What if an event decision hinged on pricing in week six?": say who you would ask and what you would want to see; offer no view you do not hold. Hold the acknowledgment through both; concede only what you have said | F10 is the gap you stated yourself, so this is the one objection the pack can rehearse in full. JD because it scores whether you can ramp on a listed-job gap; it is the closest of the five types |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [generic] | Pick one honestly from the rows where the pack found your material thinnest (F2, F3, F4), say it in one plain sentence, then the first thing you would do about it in week one. Do not answer with a strength dressed as a weakness | The standard Skeptic opener for a hiring manager; the thin rows decide what a real answer is. JD because it scores the listed job including its gaps |
| B3 | "You ran the content-drop calendar for your studio's main title. This job covers two titles. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F2: the weekly content-drop calendar, for the main title, for the last two years are the beats the sentence states; tell them in your own words. Answer slot: the JD says two titles, so expect a probe on what two calendars at once adds. If you have worked on a calendar that covered more than one title, say how, in your own words; if not, say so plainly, say what you would ask first about how the second title's calendar differs, and return to the calendar you ran | F2 is the row where the JD's scale is larger than the quoted sentence. JD because it scores the stated requirement |
| B4 | "You haven't led a team, and this job coordinates design, art, engineering and community on each update. How would you make that work?" | JD | [grounded] "Never led a team" | Plain acknowledgment first: "I haven't led a team." Do not turn coordination into leading. Answer slot: the JD asks for coordination across those four teams on each update, so expect a probe on what working across them looked like for you. If you worked with any of them on updates, say which and what you did, in your own words; if you did not, or it was not yours, say so plainly. Then what you would do before the first update, as a plan: ask each team what it needs from you and by when | F11 and F3. JD because the question scores the listed responsibility against a gap you stated |
| B5 | "Why Saltmarsh Games, and why now?" | CO | [generic] | A selection scaffold. Pick the one or two real reasons: what you actually know about the studio and its titles from sources you have read yourself, and a real reason for the move now, in your own words. The pack established nothing about Saltmarsh beyond your message, so it supplies no facts about the studio and no reason for you. If you know little about the titles, say that plainly and say what you would want to learn | Motivation consistency is the Skeptic's scoring target. CO because "why here" tests homework depth; `[generic]` because the research that would ground it did not run |

### Bank C: Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the retention numbers you presented each month." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Story-mapped on F4 and F8: retention numbers, monthly, presented to the studio head are the beats the sentence states; tell them in your own words. Answer slot: the JD names player-retention metrics, so expect a probe on how those numbers were counted. If you know, say how, in your own words; if you do not, say so plainly. Also expect which part of the numbers was yours: if someone else prepared them, say so plainly and stay with presenting them | F4 and F8 are the lines a close reader tests. EXP because it checks attribution |
| C2 | "Tell me about a time a retention number changed what you did with the calendar." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." "I ran the weekly content-drop calendar for our main title for the last two years." | A selection scaffold. Pick a moment where a retention figure led to a decision about what shipped or when. It needs the decision and what you would do differently, and a figure only if you remember it. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: you ran the weekly content-drop calendar for the main title and presented the monthly retention numbers to the studio head, or say how you would connect the two | An open prompt on the JD's retention and calendar lines (F7, F8). EXP because it checks whether the two skills ever met |
| C3 | "How do you judge whether a live event worked?" | JD | [generic] | Start from the goal set before the event, pick the number that answers that goal, and say which baseline you would compare against. Name the assumption in that comparison you would trust least, before the interviewer does. Say which numbers move for reasons unrelated to the event, and end with the decision the number should drive. No claim about your past | F8 and F4's requirements, asked as a judgment about method. JD because it scores the stated responsibility |

### Bank D: Conversational / Rapport Builder (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc built only from those four sentences: four years as an associate producer at a puzzle-game studio; for the last two years you ran the weekly content-drop calendar for the main title; you wrote the release checklist the QA team still uses; you presented the monthly retention numbers to the studio head. Answer slot: the JD says live-service games or apps, so expect a probe on whether the title ran as one; say how it ran, in your own words, and if it did not, say so plainly. End on your actual reason for wanting this role, in your own words; none is supplied here | The biography question is scored even in a casual register (F6, F7). EXP because it checks what you say you did |
| D2 | "Tell me about the release checklist you wrote." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F5: that you wrote it and that your QA team still uses it are the two beats the sentence states; tell them in your own words. Answer slot: the JD says to manage the release checklist with QA, so expect a probe on how you and QA used it at release. If you worked with QA on it, say how; if QA used it without you in the loop, or there was no such step, say so plainly and stay with having written it | F5's requirement in a friendly register. JD because it scores a stated responsibility |
| D3 | "What's the clearest document you've written for other people to work from?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | An open prompt on the JD's written-communication line. The nearest thing your material carries is the checklist: you wrote it and the QA team still uses it. If another document comes to mind, pick it only if you can say who worked from it, and say in your own words what made it clear. If none comes to mind, say so plainly and use the checklist | F9 is the row with no inspected proof. JD because it scores the stated requirement |

### Bank E: Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, when you haven't worked on in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases" "I ran the weekly content-drop calendar for our main title for the last two years." | Hold, then concede. Pause and restate the question. Hold on what your sentence carries: "For the last two years I ran the weekly content-drop calendar for our main title." Concede, specifically and once: "I haven't worked on a game with in-app purchases." Hold through two follow-ups by returning to the calendar and adding nothing to it; do not fold on the calendar to restore harmony | F10 under the Pressure style. JD because it scores the gap against the listed job |
| E2 | "That retention reporting — how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold: "I presented the monthly retention numbers to the studio head." Answer slot: expect which part of the numbers was yours. Say, in your own words, which part you prepared; if someone else prepared them, say so plainly and stay with presenting them. Hold through two follow-ups, concede exactly the part that was not yours, and do not fold on having presented them | F4 under the Pressure style. EXP because it is an attribution probe |

### Bank P: Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Engineering and design sit next to you on every update. Where's the seam between producer and them, and what happens when you disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam: ask where each team's decisions end and what you need to know to plan, agree in advance who breaks ties and how the outcome is recorded, and on a disagreement put the trade-off, the date and the cost in writing before asking who decides. Reciprocity: what the calendar gives them to plan against. No claim about your past | F3's requirement in collegial packaging. JD because it scores the stated coordination line |
| P2 | "When work spans design, art, engineering and community, how do you handle credit?" | JD | [generic] | A selection scaffold. "We" for context, "I" for your contribution. Pick a story only if you can say what each team did and what you did; if none comes to mind, say so plainly, then say what you would do: name each team's part and the owner of each decision in the review. No claim about your past | The standard Peer credit probe applied to the JD's four teams (F3). JD because the coordination line is the stated responsibility |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A3, B3 |
| "coordinate design, art, engineering and community teams on each update" | A4, B4, P1, P2 |
| "own the post-event review and the KPIs it reports" | A5, C3 |
| "manage the release checklist with QA" | D2 |
| "3+ years producing live-service games or apps" | D1 |
| "experience running a content calendar" | A3, B3, C2 |
| "comfortable with player-retention metrics" | A2, C1, C2, C3, E2 |
| "clear written communication" | D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first 90 days look like for the person in this role?" | Ties your first months to what the JD says the job owns, and gives you the standard you will be measured against |
| R2 | "How do the two titles' calendars differ, if at all, in cadence and in what players expect?" | Answers the two-title point (F2) from their side instead of leaving it as your gap |
| R3 | "What does the post-event review look like today, and who reads it?" | Uses the JD's own words (post-event review, KPIs it reports) and shows you treat the review as owned work |
| R4 | "Where do the release checklist and QA's own process meet today, and what would you want to change first?" | Opens the QA relationship the JD names (F5) as a working conversation |
| R5 | "Which number from the review does the team look at first after an event, and what has it driven?" | Shows retention and KPI fluency (F8) without claiming a method you have not used |
| R6 | "If the titles sell in-app items, who owns that side of an event, and how would you want me to learn it?" | Turns the stated gap (F10) into a ramp plan the interviewer can respond to; conditional, so it assumes nothing about their titles |

## Prohibited claims

Built before the banks. Each entry is a claim this pack will not coach, with its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran a live-events calendar | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a content-drop calendar, not a live-events calendar |
| Managed releases with QA | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: the material says wrote the checklist and QA still uses it, not that releases were managed |
| Owned the post-event review or its KPIs | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says presenting monthly retention numbers, not owning a review |
| Worked on a game with in-app purchases | Negative you stated, F10 | The plain acknowledgment F10 gives: "I haven't worked on a game with in-app purchases." No slot |
| Led a team | Negative you stated, F11 | The plain acknowledgment F11 gives: "I haven't led a team." No slot |

## Sources

Provided documents: your message (the JD as pasted, and your background). No dossier was present. Nothing about Saltmarsh Games or Tobias Wrenfield was established; all four searches were refused.

Searches sent, by query:

- "Saltmarsh Games values": refused
- "Saltmarsh Games interview process live operations producer": refused
- "Saltmarsh Games mobile studio news strategy": refused
- "Tobias Wrenfield Saltmarsh Games": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have decided whether published value names exist to map; with none, no values cheat sheet is built |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have named the loop's rounds; your own words fix this one session, so persona weights rest on the hiring-manager prior |
| 3. `Saltmarsh Games strategy / recent news` | unavailable | Would have fed CO and CASE questions on current priorities; those banks are `[generic]` |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have fed an interviewer read and a reverse question tied to his path; both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Whether Tobias is the person you would report to → reweights every bank; a peer or skip-level changes the persona weights and adds a reciprocity question
- The recruiter's note on focus areas or any task to prepare → replaces the assumed coverage, and adds a build section for any announced deliverable
- Search access for a research pass, then optionally a deeper one (up to 6 further searches and 2 further fetches, several more minutes) → published values, loop structure and current strategy; real CO questions in place of the `[generic]` ones; an interviewer read and a reverse question tied to his public path
- Your answers to the answer slots on F2, F3, F4, F6 and F9 → those rows get your own quoted sentences, and the guidance on A-bank, B3, B4, C1, D1 and D3 becomes story-mapped instead of slotted
- A sample of the release checklist, a calendar export or a slide from the monthly retention presentation → F1, F5, F7 and F8 move from `medium` toward `high`, since those are the artifacts a producer's work leaves behind
- How much prep time you have before Friday → a prioritized rehearsal schedule sized to it
- A `tuesday-dossier.md` from an earlier session, if you have one → verified evidence and any prohibited claims carried in; never required
