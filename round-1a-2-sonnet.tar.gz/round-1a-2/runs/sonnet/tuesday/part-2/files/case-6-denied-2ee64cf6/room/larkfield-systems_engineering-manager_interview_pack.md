# Interview pack: Engineering Manager, Larkfield Systems (loop of three rounds)

- Candidate: Yusuf
- Role: Engineering Manager, Larkfield Systems, industrial IoT, about 600 people
- Mode: loop. Round 1 is a 45-minute hiring-manager conversation with a Director of Engineering (your would-be boss). Round 2 is a 60-minute panel with two staff engineers and a product manager, two days later. Round 3 is a 30-minute conversation with the VP Engineering, the following Monday
- Names are not known for any interviewer, so there is no interviewer read

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: every sentence you say aloud about your own past must be one you can repeat under a second question.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values and leadership, not generic virtue |
| EXP | Whether your own claims survive scrutiny and attribution is exact |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack: no research ran, see Sources) |
| CASE | Structure and reasoning on a live problem from the role |

Answer slots in the guidance are instructions for the interview. They have two honest branches, and either one meets the slot.

## Prep triage

Sized to the three rounds over about two weeks. Do these few things well, in this order.

1. Before round 1: B2, the objection this pack names as your highest-ROI prep, then B1 and B3 (the 60% figure), then A2.
2. Between rounds 1 and 2: E1 and E3 (defending your two figures in front of engineers), then D4 and F3 (the product partnership), then D1.
3. Before round 3: G1 and G2, then I1, then H2.

Everything else is insurance.

## Fit snapshot (shared by all three rounds)

Requirements are from the role description you gave me. Your CV was not provided, so every evidence cell draws on your message alone.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description, your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says one team of six at a payments company, not two squads and not device-management work. The words stay at your scope: "Nine years in engineering, three as a team lead of six." Answer slot: the two-squads line makes a probe on scale likely. If any of your current work touches services that manage devices, say what, in your own words; if none does, or it was not yours, say so plainly and stay with the team you lead |
| F2 | "own delivery, hiring and growth for 11 engineers" (delivery) — role description, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Your material says the reliability quarter and the on-call figure, with "after" and not "because", and the words stay at that quote. It does not show delivery commitments across a team. Answer slot: the JD's delivery line makes a probe on how delivery was tracked likely. If you set or tracked commitments for your team, say how, in your own words; if you did not, say so plainly and stay with the reliability quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" (hiring) — role description, your message | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | transferability | Your material says you run the loop for backend roles, with a count of interviews, and nothing about what falls outside the loop. The words stay at the loop: "I run our hiring loop for backend roles." Answer slot: the JD's hiring line makes a probe beyond the loop likely. If any part beyond the loop was yours, say which and how, in your own words; if not, or if there was no such step, say so plainly and stay with the loop you run |
| F4 | "own delivery, hiring and growth for 11 engineers" (growth) — role description, your message | none given | none | [grounded] | discovery | Your material does not show anything on this, and no absence was stated. Answer slot: the JD's growth line makes a probe likely. If you have helped an engineer develop, say who, what you did and how it turned out, in your own words; if you have not, or it was not yours, say so plainly and say what you would do first |
| F5 | "partner with hardware and product on roadmap" (product) — role description, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Your material says roadmap pressure and a reliability quarter you pushed through, not who the pressure came from or how it was settled. The words stay at the quote. Answer slot: the JD's product line makes a probe on how it was settled likely. If you can say who pressed and how the quarter was agreed, say so in your own words; if the decision was made elsewhere, or it was not as the question assumes, say so plainly and stay with the quote |
| F6 | "partner with hardware and product on roadmap" (hardware) — role description, your message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Never a claim to hardware roadmap work, and nothing added to make the gap feel smaller |

Requirement-coverage line:

| Requirement | Questions that cover it |
|---|---|
| F1 two squads, device-management services | A1, A3, B4, C1, C2, H1 |
| F2 delivery | A2, A3, B3, D4, E1, E2, H2 |
| F3 hiring | E3, G3, H3 |
| F4 growth | F2 |
| F5 product roadmap partnership | A2, D4, F3, H2 |
| F6 hardware roadmap partnership | A1, A4, B1, B2, H1, I1 |

## Round 1: Director of Engineering (hiring manager), 45 minutes

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems on the squads' real situation | High. The hiring-manager row of the priors leads with it: they are buying capability on their own roadmap | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet, persistent probing of the gaps | High. The same row pairs it with Case, and F6 and F1 are the visible gaps | Rehearse the single most predictable objection until it is boring; say the limit before it is asked for |
| Conversational | Friendly biography and interest questions | Low. A 45-minute boss conversation usually opens with one; it is still scored | A 90-second arc built only from your quoted sentences; treat casual questions as scored |

Depth follows weight: 4, 4, 2.

### Bank A: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A firmware release from the hardware team slips six weeks, and both squads have work waiting on it. Sketch how you would re-plan. What do you need to know first?" | CASE | [generic] "I've never managed managers and never owned a hardware-adjacent roadmap." | Clarify first: what exactly slipped, what each squad can still do without it, who decides the new date. Then objective, options for the two squads, metrics, risks. Challenge one premise, for example whether six weeks is firm. The question needs no claim about your past. If asked whether you have done this, the words are "I haven't owned a hardware-adjacent roadmap," then your plan | Live problem from the JD's hardware line (F6), the HM's native ground; CASE because it scores structure, JD because the requirement comes from the posting |
| A2 | "Product wants a new feature in the device-management service next quarter, and the squads are carrying a heavy on-call load. How do you decide, and how do you take it to product?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure the decision: what each choice costs, what evidence you would bring product, what you would offer in exchange. Where you refer to your past, stay at the quote: you pushed a reliability quarter through against roadmap pressure, and on-call burden dropped 60% after. Answer slot: the JD's product line makes a probe on how that was settled likely. If you can say who pressed and how the quarter was agreed, say so in your own words; if the decision was made elsewhere, or it was not as the question assumes, say so plainly and return to the quote | F2 and F5 are the evidence for delivery and product partnership; the reliability story is where both are tested at once |
| A3 | "You would own delivery for eleven engineers across two squads. How do you find out in your first thirty days what they deliver and where they are stuck?" | CASE | [generic] | A listening plan, not a claim: who you would talk to and in what order, what you would ask each, what you would look at before forming a view, and what you would hold back from changing. If device-management work is new to you, say so plainly as the starting point of the plan; your material does not state either way, so say only what is true | Covers the two-squads and delivery lines (F1, F2) as a live problem; CASE because the delivery is hypothetical and asks about no past |
| A4 | "What would you want from the hardware team before committing a quarter's roadmap?" | CASE | [generic] "I've never managed managers and never owned a hardware-adjacent roadmap." | Questions, not claims: what is firm and what is a forecast, what the dependencies are, who can say no, how change gets signalled. Say the limit in one sentence, "I haven't owned a hardware-adjacent roadmap," then show how you would find out. Do not describe a past hardware planning step | Rehearses the F6 gap as a collaborative question; CASE for the delivery, JD for the requirement |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Name it first, in your own words and at its scope: "I haven't owned a hardware-adjacent roadmap." Then the plan, said as a plan: whom you would ask, what you would read, what you would not decide alone. Calibrated candor beats bluffing a competency the interviewer owns | F6 is the widest gap against the posting and the opening question for it; JD because it scores honest self-assessment against the requirements |
| B2 | "I don't see hardware roadmap ownership in your background. How would you handle that part of this role?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Highest-ROI rehearsal in this pack. Hold only what the quote carries and say the limit before it is pulled out of you: "I haven't owned a hardware-adjacent roadmap." Follow-up one, the first sixty days: describe the plan as a plan, never as something done. Follow-up two, what if the hardware team's dates are unreliable: say how you would find out and who you would involve. Follow-up three, why not hire someone who has done it: return to what your quotes carry, concede the limit plainly, and do not add experience. Hold through two follow-ups by returning to the quote, never by adding to it | F6 is where the posting presses hardest and where the material is thinnest, so this objection arrives in some form; JD because it scores a stated requirement |
| B3 | "Walk me through how the 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say what you know about how the figure was counted and what it is sensitive to, in your own words. Name the assumption behind it you would defend least before they do. Say which part was yours, at the quote's scope: you pushed the reliability quarter through, and the burden dropped after. If you do not know how it was counted, say so plainly. Never explain the figure with a method you cannot repeat under a second question | Headline metric on your profile, so a defend-the-number question; F2 holds the quote, and "after" is not "because" |
| B4 | "Two squads and eleven engineers. Which part of that scope is new to you?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Say the scope you hold in the quote's terms: nine years in engineering, three as a team lead of six, at a payments company. The scope here is larger than that quote; say that as your own observation. If the question reaches layers of management, the words are "I've never managed managers," and then how you would work with whoever leads under you. Answer slot: if you have run work across more than one team, say what and how, in your own words; if not, say so plainly and stay with the team of six | F1 is the evidence for the scale requirement; EXP because it tests how much of the stated scope is yours |

### Bank C: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc whose beats are the sentence's: nine years in engineering, three as a team lead of six, now at a payments company. Why this role, why industrial IoT and why now are yours to say in your own words; the material does not state them. Leave the interviewer a hook rather than an inventory | Opening question of almost every hiring-manager conversation; F1 holds the quote |
| C2 | "What are you actually playing with in industrial IoT these days?" | JD | [generic] | Selection scaffold: pick something you have actually read, run or built that touches devices, fleets or industrial systems, name what it was and what you took from it. If nothing comes to mind, say so plainly, then give the nearest thing your material carries or how you would start learning | A casual question on the company's domain; scored on genuine interest. Generic because it depends on what you have done in this area |

### Reverse questions for round 1

| Question | Why it lands |
|---|---|
| "What does good look like for these two squads at six and twelve months, and who judges it?" | Shows you think in outcomes and want the scoring rule from the person who sets it |
| "Where do the hardware roadmap and the squads' roadmaps meet today, and where does it hurt?" | Goes straight to the part of the role you will need most from them and signals that you want the real picture |
| "How does the squads' on-call load look now, and who decides how much roadmap time goes to reliability?" | Connects your reliability interest to their decision process without a claim about what you did |
| "How do you want to hear that delivery is at risk, and how early?" | Asks how to work with them as a boss: their preference, not yours |
| "Which hardware counterparts should I spend my first weeks with, and what do they care most about?" | A practical onboarding question that treats the hardware partnership as the work it is |

## Round 2: panel of two staff engineers and a product manager, 60 minutes

### Persona weights

I assumed the staff engineers are technical peers of the role and the product manager is cross-functional; if either is wrong, tell me and the weights change.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting, "what would you need from us", credit and disagreement | High. Both staff engineers and the product manager price what you add to their work; the panel row blends the top two personas of each member | Reciprocity: what you bring them; propose seam principles, not a map you do not have; a disagreement story that shows spine and tact |
| Data-Driven Prober | Your two figures, probed to their assumptions | Medium. Engineers who read a profile closely will go to the 60% and the 40 interviews | Know what you can and cannot say about how each was counted; name the weakest assumption first |
| Values/Behavioral | Behavioral prompts from the product manager | Medium. A cross-functional interviewer leans here and the JD raises hiring, growth and product partnership | A story only where one of your quoted sentences carries it; where none does, a selection scaffold ending in the honest branch |

Depth follows weight: 4, 3, 3.

### Bank D: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Where is the seam between you and the staff engineers on technical decisions, and what happens when we disagree?" | JD | [generic] | Propose principles, not a map you do not have: who owns direction, who owns delivery and people, how a disagreement gets escalated and how it gets closed. Answer slot: if you have a disagreement with a senior engineer you can tell, say what it was about and how it resolved, in your own words; if you have none, say so plainly and say how you would handle one | A seam question is the staple of a peer; JD because it scores the role's own mandate (delivery, hiring and growth) |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Reciprocity framing: what credit practice you would set, and what you would give the other team first. Answer slot: if you have shared credit across teams and can tell it, say what happened, in your own words; if not, say so plainly and describe how you would do it | Stock peer probe that returns in collegial packaging; generic because it asks for a practice, not a fact |
| D3 | "What would you need from the staff engineers in your first month, and what would we get from you?" | JD | [generic] | Lead with what they get: a clear owner for delivery and people decisions, quick answers on priorities, a manager who asks before deciding on technical direction. Then your needs, limited to learning the domain and the codebase | A reciprocity question when the interviewer is a peer; generic because it describes a plan, not a past |
| D4 | "Product and engineering disagree on next quarter, reliability or features. Walk us through how you would settle it with the product manager." | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure it: the decision, what evidence product needs to see, what you offer in return, how it gets recorded. If you refer to your own past, stay at the quote: you pushed a reliability quarter through against roadmap pressure and on-call burden dropped 60% after. Answer slot: the JD's product line makes a probe on how that was settled likely. If you can say who pressed and how it was agreed, say so in your own words; if the decision was made elsewhere, or it was not as the question assumes, say so plainly and return to the quote | F2 and F5; the product manager will be listening to how you treat them as a partner |

### Bank E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which assumption behind that 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Name the assumption you would defend least, in your own words, before they do; if you do not know how the figure was counted, say so plainly. Say what the figure is sensitive to, if you know. The quote says "after", not "because", so keep to it | The persona's own stem on a headline number; F2 holds the quote |
| E2 | "That result: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold the quote's scope: you pushed a reliability quarter through against roadmap pressure, and the team's on-call burden dropped 60% after. Say which parts of the work were yours and which were the team's, in your own words. Hold through two follow-ups by returning to the quote; concede plainly what you do not know about what drove the drop; never claim the drop alone | Attribution probe; the staff engineers will check the first-person claims against what a team does |
| E3 | "Walk me through the hiring loop you run." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | The beats the sentence states: you run the loop for backend roles, and about 40 interviews last year. Say how that figure was counted and what it is sensitive to, in your own words, and which part was yours; if you do not know, say so plainly. Answer slot: the JD's hiring line makes a probe beyond the loop likely. If any part beyond the loop was yours, say which and how; if there was no such step, or it was not yours, say so plainly and describe the loop you run | F3 holds the quote; the second figure on your profile gets the same defend-the-number treatment |

### Bank F: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a named customer-side stake, a metric you left worse for it, and an intact working relationship after. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | Stock values stem; the product manager is the likely asker. Generic because no quoted sentence carries a customer story |
| F2 | "Tell me about a time you helped someone on your team grow." | VAL | [generic] | Selection scaffold: pick one person, what you saw in their work, what you did that was yours to do, and what changed for them. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would approach it | The JD's growth line (F4) raises this; generic because your material shows nothing on it |
| F3 | "Tell me about a time you worked with product on what the roadmap should contain." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on F5 with only the beats the quote states: a reliability quarter, roadmap pressure, you pushed it through, on-call burden dropped 60% after. Answer slot: if you can say who pressed and how the quarter was agreed, say so in your own words; if the pressure was not from product, or the decision was made elsewhere, say so plainly and stay with the quote | The JD's product line (F5) raises this; the product manager scores how you treat a partner under tension |

### Reverse questions for round 2

| Question | Why it lands |
|---|---|
| To the staff engineers: "Which technical decisions do you want the engineering manager to stay out of, and which to be in the room for?" | Defines the seam from their side and signals that you will respect it |
| "What does the on-call load look like for each squad now?" | A concrete question about the work they live in |
| "How are hardware-dependent releases coordinated between the squads and firmware today?" | Shows you are listening for the hardware seam without claiming knowledge of it |
| To the product manager: "How does the roadmap get set between product, hardware and engineering, and where does it break?" | Goes to the real process and invites a candid answer |
| Reciprocity: "What could a new manager do in the first month that would genuinely help your work?" | Treats the panel as colleagues you would serve |

## Round 3: VP Engineering, 30 minutes, "values and leadership philosophy"

### Persona weights

The recruiter's own words, "values and leadership philosophy", name this round's focus, so a values-style round is detected here. The company's published values are not in hand (see Sources), so the questions follow the recruiter's wording and the persona stems, not value names.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Leadership philosophy and behavioral prompts | High. The recruiter's own description; the skip-level row adds altitude | Map a story only where a quoted sentence carries one; "we" for context, "I" for contribution; where none does, a scaffold with its honest branch |
| Case/Strategist | Role-level problems at altitude | Medium. The skip-level and executive row leads with it; 30 minutes limits how many | Say the framework aloud, state a hypothesis early, keep it short |
| Pressure | Time-boxed challenges to your claims | Low. The executive row pairs it with Case; composure under a short clock is what is scored | Pause, restate, anchor in what you said, hold through two follow-ups before conceding anything real |

Depth follows weight: 4, 3, 2. In 30 minutes you will not be asked all nine; G1 and G2 are the most likely.

### Bank G: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "What is your leadership philosophy?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." and "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say in your own words what you do first when a team is under pressure, and anchor it in two things your material carries: you run the hiring loop for backend roles, and you pushed a reliability quarter through against roadmap pressure. Describe what you did and let the interviewer draw the inference; do not tell them what your work proves. Philosophy beyond those two quotes is yours to say, and the pack supplies none | The recruiter's own words raise this question; F2 and F3 hold the quotes |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped only as far as the quote: a reliability quarter, roadmap pressure, you pushed it through, on-call burden dropped 60% after. The material does not show who the pressure came from or whether the truth landed. Answer slot: if it was leadership you told, and it landed, say so and say what you said; if the pressure came from elsewhere, or it did not land that way, say so plainly and pick the nearest thing you did tell leadership | The persona's own stem, and it fits a VP's altitude; F2 holds the quote |
| G3 | "Tell me about a time a hiring decision was hard." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | The quote supplies the loop and the count, not an event, so this is a selection scaffold: pick one decision where the evidence was mixed, say what you weighed and what you decided, and what it taught you. If no such time comes to mind, say so plainly, then describe how you run the loop | The JD's hiring line (F3) raises it; the quote gives you a loop, not a story |
| G4 | "Tell me about feedback that changed how you lead." | VAL | [generic] | Selection scaffold: one piece of feedback, who gave it, what you changed, how you could tell it worked. If none comes to mind, say so plainly, then give the nearest thing your material carries or how you seek feedback | Follows the recruiter's "leadership philosophy"; generic because no quoted sentence carries it |

### Bank H: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "You inherit eleven engineers on two squads and depend on a hardware roadmap you do not control. What are your first three priorities?" | CASE | [generic] "I've never managed managers and never owned a hardware-adjacent roadmap." | State a hypothesis early and keep it short: learn the work and the people, find the hardware dependencies and who owns them, agree what good looks like with your boss. If it comes up, say the limit once, "I haven't owned a hardware-adjacent roadmap," and show how you would close it | Altitude question on F1 and F6 from the VP; CASE because it is a live problem |
| H2 | "How would you decide between investing in reliability and shipping new device features across two squads?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure the decision: what each choice costs, how you would bring evidence, how you would take it to product. If you refer to your past, stay at the quote: you pushed a reliability quarter through against roadmap pressure and on-call burden dropped 60% after. Do not say it proves your judgment | F2 and F5 at VP altitude; the same quote as G2, here asked as a decision to structure rather than a story to tell |
| H3 | "How would you build a one-year hiring plan for a team of eleven?" | CASE | [generic] "I run our hiring loop for backend roles — about 40 interviews last year." | Clarify first: current gaps, attrition, budget, what the squads will need next. Then roles, sequence, loop design, how you would keep the bar. Your material says you run the loop for backend roles and nothing beyond it, so keep claims at the loop | The JD's hiring line (F3) as a live problem |

### Bank I: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "Sixty seconds: why you for this role rather than someone who has owned a hardware-adjacent roadmap?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." and "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." and "I've never managed managers and never owned a hardware-adjacent roadmap." | Pause and restate. Hold only what the quotes carry: you run the hiring loop for backend roles, and you pushed a reliability quarter through against roadmap pressure. Concede the limit plainly, in one sentence: "I haven't owned a hardware-adjacent roadmap." Hold through two follow-ups by returning to the quotes, never by adding to them, and do not argue you are the better choice | The persona's own stem, aimed at F6; the concession is the one your material gives |
| I2 | "In your first month an engineer disagrees with you in front of the team. What do you do?" | CASE | [generic] | Pause, restate the situation, then what you would do in the moment, what you would do afterwards, and what you would not do. Hold your position on the process, concede that you may be wrong on the substance, and do not fold to restore harmony. The question needs no claim about your past | Composure under a short clock; generic because it describes a plan |

### Reverse questions for round 3

| Question | Why it lands |
|---|---|
| "Which behaviors have mattered most in the engineering managers who have done well here?" | Asks the VP to define the values in practice, which is the point of the round |
| "Where does engineering want to grow over the next two years, and what does that ask of this role?" | Altitude question that shows you think about the role's future, not just its first quarter |
| "How do you want engineering managers to handle tension between hardware timelines and software delivery?" | Goes to the hardest seam in the role, and to their philosophy on it |
| "What do you do when a manager's team and the roadmap disagree?" | Asks for their leadership practice, which is what the round is about |
| "What would make you say in a year that this hire was the right one?" | Lets them state the scoring rule |

## Prohibited claims

Built before the banks and binding on every cell.

| Not coached | Basis | Honest form |
|---|---|---|
| Owns delivery across two squads | Inflated form of F1 and F2 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a team of six, not two squads |
| Managed a team of six | Inflated form of F1 | "Three as a team lead of six," as the quote has it |
| Owned or decided hiring for a team | Inflated form of F3 | F3's quote at its own scope: you run the loop for backend roles. The pack's observation: the material says the loop, not what lies outside it |
| Cut on-call burden by 60% | Inflated form of F2 | The quote's own order: the burden dropped 60% after you pushed a reliability quarter through. The material says "after", not "because" |
| Has hardware-adjacent roadmap experience | Negative you stated, F6 | The plain acknowledgment you gave: "I haven't owned a hardware-adjacent roadmap." No slot |
| Has managed managers | Negative you stated, F6 | The plain acknowledgment you gave: "I've never managed managers." No slot |

## Sources

Provided: your message (the role description, the three round descriptions, and your background). No CV, full JD, values page or recruiter email was provided.

Searches sent, all refused because the host did not grant search permission:

- "Larkfield Systems industrial IoT company values": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems industrial IoT device management strategy news": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Would have fed the values cheat sheet and VAL questions themed on named values; the round 3 bank follows the recruiter's wording instead |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Would have checked the loop beyond your own account; the loop here rests on your and the recruiter's words, which establish all three sessions, so no archetype fallback applies |
| 3. Larkfield Systems strategy and recent news | unavailable | Would have fed CO questions; the pack has none |
| 4. Interviewer name and company | n/a | No interviewer was named, so there was no query to form; the interviewer read is absent |
| 5. Representative Engineering Manager JD | skipped | The role description you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full job description text → the six requirement rows quote the posting's own wording, and any mid-list requirement the summary omitted gets a question
- Your CV → every evidence cell can quote more than your message, F4 may move from none given to a quote, and more of the banks become story-mapped
- Your account of how the 60% was counted and who pressed on the roadmap, and of any part of hiring beyond the loop → rows F2, F3 and F5 and questions A2, B3, D4, E1, E3 and G2 get upgraded
- The company's published values page, pasted → the values cheat sheet for round 3 and VAL questions themed on named values
- Search permission granted → the L1 targets for values, loop structure and strategy run, and CO questions become possible
- Interviewer names and roles → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to each person's own path
- The recruiter's prep email for the panel and VP rounds → coverage of any announced deliverable or focus area
- A `tuesday-dossier.md` from an earlier session → verified evidence and a named objection would replace the inferred ones here
