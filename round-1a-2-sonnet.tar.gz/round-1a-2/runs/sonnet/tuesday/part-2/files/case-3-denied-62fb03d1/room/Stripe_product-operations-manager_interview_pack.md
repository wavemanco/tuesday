# Stripe — Product Operations Manager — final-round prep pack

Interviewer(s) and relationship: not given. Built for a final round of unknown format, with blended persona weights. This is a first version: no JD, no CV and no research were available, so most of it is generic scaffolding, labeled as such.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only say what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge, thought at the company's altitude |
| CASE | Structure and reasoning on a live problem from the role |

Every quoted evidence cell below reads `none given` because no CV or background was supplied. Wherever guidance would normally map one of your stories, it gives selection criteria that end in an honest branch instead.

## Fit snapshot (worksheet variant)

No JD was supplied and no search could run, so the requirements are role-family prose, not quotes from a posting.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Launch and change management across several teams (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a launch or rollout you coordinated, named by what the change was and who had to adopt it. Selection scaffold: pick one rollout where several teams had to change how they worked; it needs a named change, a named group affected and a result you can state. If no such rollout comes to mind, say so plainly, then give the nearest coordination work your material does carry, or how you would run one |
| F2 | Process and operating-rhythm design (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a recurring process or meeting cadence you designed or reshaped, and what changed afterwards. Selection scaffold: pick one process you built or changed, name who used it and one thing that differed afterwards. If none comes to mind, say so plainly and describe how you would design one |
| F3 | Metrics, data and decision support (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a metric you defined, tracked or analyzed, with how it was counted and the assumption you trust least. Selection scaffold: pick one number you relied on, and be ready to say how it was counted and which part was yours. If none comes to mind, say so plainly and say how you would define the first metric |
| F4 | Influence without authority across product, engineering, and go-to-market (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a case where you moved a group you did not manage, and what you did when someone disagreed. Selection scaffold: pick one disagreement with an equal or a senior person where the relationship held afterwards. If none comes to mind, say so plainly and describe the approach you would take |
| F5 | Customer and field feedback loops into product decisions (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a feedback channel you set up or used, and a decision it changed. Selection scaffold: pick one piece of customer or field input and the decision it touched, naming only what you saw. If none comes to mind, say so plainly and say how you would build the loop |
| F6 | Prioritizing and operating through ambiguity (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a time you were handed an unclear problem and chose what to do first, and why. Selection scaffold: pick one unclear brief, the options you weighed and the one you chose. If none comes to mind, say so plainly and walk through how you would choose |

## Persona table

The loop is unknown. The pack falls back to the Generic archetype (screen, hiring manager, panel) with flat priors, stated plainly: these weights rest on a pattern, not on Stripe's documented process. A final round is likely several sessions, so the weights are blended and per-session mini-packs are offered in the upgrade menu.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | Live problem set in the role: launch, diagnose, prioritize | Highest — a hiring manager is the likeliest interviewer in a final round and this role is judged on structure | Clarify, set the objective, segment, approach, metrics, risks; think aloud; challenge one premise politely |
| Skeptic (B) | Quiet probing of day-one gaps and motivation | High — a final round derisks gaps, and with no CV the specific gap is unknown | Rehearse the single most predictable objection until it is boring |
| Data-Driven Prober (D) | Asks how numbers were counted | Medium — this is an operations-and-metrics role | Know how each figure you cite was counted; name its weakest assumption first |
| Conversational (F) | Friendly, loose, still scored | Medium — a cross-functional or leadership chat is plausible | A short arc for the biography question; treat casual questions as scored |
| Values / Behavioral (C) | Scenario probes | Lower — no values round is documented here, so none is assumed | One honest story per theme, or the honest branch |
| Peer Evaluator (G) | Seam-splitting with product and engineering peers | Lower — depends on who the panel is | Offer seam principles, not a pretended seam |
| Pressure (E) | Time-boxed, devil's advocate | Lowest — plausible from a senior interviewer | Pause, restate, hold through two follow-ups, then concede specifically |

## Question banks

Highest-ROI prep: B1, the day-one weakness question. It will arrive in some form, and the pack cannot yet tell you the specific objection because it has no CV.

### A — Case / Strategist (weight highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product change ships in three weeks, and two teams disagree on whether customers are ready. How would you run it — what do you need to know first?" | CASE | [generic] | Clarify what is changing and for whom, the objective, who decides readiness, and what would move the date. Then structure: stakeholders, readiness criteria, comms, rollback, and metrics. Challenge one premise, such as whether readiness is one question or several. No claim about your past is needed | Tests F1 and F4 as a live problem; CASE because it scores structure, not history |
| A2 | "Adoption of a recently launched feature is flat. Diagnose it." | CASE | [generic] | Clarify what flat is measured against and over what period. Segment: awareness, access, activation, repeat use. Name the first two data cuts you would ask for and what each would rule out. State your weakest assumption aloud | Tests F3; a diagnosis case is a standard probe of metric reasoning |
| A3 | "Internal teams ask you for more process help than you can give. How do you decide what to take?" | CASE | [generic] | State the criteria you would use, such as impact, urgency and reuse, say what you would decline and how you would say no. Offer the criteria as a proposal to test with stakeholders | Tests F6 and F4; the role is a service role with finite capacity |
| A4 | "Design an operating rhythm for a group of product teams that currently share information ad hoc." | CASE | [generic] | Clarify the decisions the rhythm must serve, then propose the smallest set of recurring forums and artifacts, an owner for each and a way to retire what does not earn its place | Tests F2; asks about design, not your past |
| A5 | "Pick one area where you think the company's products could be easier for customers to adopt. How would you size it and what would you need to learn?" | CO | [generic] | Use only what you have verified yourself from public material you have read; say so when you are reasoning from a general pattern instead. Structure: who the customer is, where friction could sit, how you would size it, what you would test first | Coverage gap: no research could run, so this CO question is generic and the pack makes no claim about the company's current strategy |

### B — Skeptic (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Choose a real area from your own honest self-assessment. State it plainly in one sentence, then a concrete ramp plan told as a plan, not a past: what you would learn, from whom, in the first weeks. Hold through two follow-ups and concede specifically. If no weakness comes to mind, say so plainly and name the area you have had least exposure to | The most predictable objection; JD because it scores the listed job, gaps included |
| B2 | "Why product operations, rather than product management or program management?" | JD | [generic] | Say what draws you to the work, in your own words, and what you would be giving up. Keep it about the job's nature, not a ranking of the other roles. If your reasons are mixed, say so plainly | Motivation consistency; skeptics test whether the move is chosen or drifted into |
| B3 | "Why this company, and why now?" | CO | [generic] | Give reasons you can state from public material you have read yourself, and reasons about your own direction. Do not recite facts you have not verified | CO because it scores homework; generic here because no research ran |
| B4 | "What would make you leave this role within a year?" | JD | [generic] | A candid, specific answer about the conditions you need to do good work, without a complaint about a past employer. If you do not know yet, say so and say what you would watch for | Tests honest self-assessment and fit expectations |

### C — Values / Behavioral (weight lower)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: a named stake, a moment you did not soften it, and the relationship intact afterwards. Use we for context and I for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for the Values interviewer; no published values were read, so it is not tied to any |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: the metric, the customer need, what you chose, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; customer focus is a common theme in product roles |

### D — Data-Driven Prober (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a metric you relied on to make a decision. How was it counted, and which assumption behind it would you defend least?" | EXP | [generic] | Choose one number you can speak to. Say how it was counted, what it is sensitive to, the weakest assumption in your own words, and which part was yours. If you do not know how it was counted, say so plainly | The defend-the-number rehearsal, built as an open prompt because no CV figure exists yet |
| D2 | "How would you know a process change you introduced had actually worked?" | JD | [generic] | Name the outcome you would expect, one leading and one lagging signal, a baseline you would establish first and what would make you call it a failure | Tests F2 and F3 together |
| D3 | "Size the cost of a recurring manual process that spans several teams. What would you need to know, and which assumption would you defend least?" | CASE | [generic] | Clarify the process and its frequency, then structure by people, time and error cost. Show the arithmetic aloud and name the weakest input | A sizing case with the weakest-assumption move built in |

### E — Pressure (weight lowest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, over a candidate who has done this exact role before?" | JD | [generic] | Pause, restate, then give two reasons you can back with your own experience and one honest limit. Do not claim experience you lack. If a reason does not come to mind, say so and say what you would bring | Pressure stem; tests composure and honest self-assessment |
| E2 | "Whichever example you just gave, how much of it was actually you?" | EXP | [generic] | Say plainly which parts you did, which were shared and who did them. Hold your account through two follow-ups, then concede any limit specifically. Never add detail to sound bigger | Pressure stem; attribution honesty |

### F — Conversational (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | Prepare a 90-second arc in your own words: where you started, the two or three turns, and why this role is next. Every turn should be one you can speak about if asked | Persona stem; the opener that sets the tone for the rest |
| F2 | "What are you working on or reading these days that bears on this role?" | JD | [generic] | Pick something real and be ready for a follow-up. If nothing comes to mind, say so plainly and name what you would want to learn first | Casual register, still scored for genuine interest |
| F3 | "What do you hope your next role gives you that your current one does not?" | EXP | [generic] | Say it constructively and specifically, about what you want to build, not what you are leaving. If you are unsure, say so | Motivation consistency |

### G — Peer Evaluator (weight lower)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | JD | [generic] | Offer principles for a seam, such as who owns the decision and who owns the how, without pretending to know this team's seam. Describe how you would handle a disagreement as an approach | Tests F4 without presupposing a past |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say what you do as a matter of practice and why. If a real example comes to mind, keep to what was yours | Peer stem; credit-sharing probe |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Launch and change management | A1, A5 |
| F2 Process and operating-rhythm design | A4, D2, G1 |
| F3 Metrics, data and decision support | A2, D1, D2, D3 |
| F4 Influence without authority | A1, A3, G1, G2, C1 |
| F5 Customer and field feedback loops | A5, C2 |
| F6 Prioritizing through ambiguity | A3, B1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would make the first 90 days in this role a clear success from your side?" | It shows you are thinking about outcomes and gives you the interviewer's own bar |
| R2 | "Which decisions does product operations own here, and which does it advise on?" | It surfaces the seam and shows you care about scope |
| R3 | "What is the one process you most wish ran better today?" | It invites a real problem you can respond to in the room |
| R4 | "How do product, engineering and go-to-market teams here feel about operations support, and what has earned trust?" | It shows you expect a service role to be judged by its users |
| R5 | "What is the hardest tradeoff the team has had to make recently, and how was it settled?" | It reveals how decisions are made, not just what was decided |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | A reciprocity question for the case where the interviewer is a peer |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None listed yet | No candidate sentences were supplied, so there is no quoted wording to inflate and no stated negative to protect | Once you send your CV or background, this list is built from it. Until then, every answer slot above asks you to say plainly when a practice was not yours |

## Sources

Provided documents: none. A dossier was not present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | The search call was refused. It would have moved the values cheat sheet (omitted) and the names the VAL bank could use |
| 2. `Stripe interview process product operations` | unavailable | The search call was refused. It would have moved persona weights and the loop archetype, now the Generic fallback |
| 3. `Stripe strategy` / recent news | unavailable | The search call was refused. It would have moved the CO bank, now generic |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so no query could be formed |
| 5. representative `Product Operations Manager` JD | unavailable | The search call was refused. It would have turned the six role-family rows `[inferred]` or `[grounded]` |

Queries sent: "Stripe operating principles values" (refused); "Stripe interview process Product Operations Manager" (refused); "Stripe strategy 2026 news stablecoins agentic commerce annual letter" (refused); "Stripe "Product Operations" Manager job description responsibilities qualifications" (refused).

## Upgrade menu

- The posting's text → the six role-family rows become `[grounded]` and the JD-tagged questions are rebuilt on its own lines, including any location, work-authorization or schedule terms
- Your CV or a few sentences on your background → the fit snapshot gets real quoted evidence, the guidance maps your stories instead of scaffolds, and the prohibited list gets built
- Who you are meeting and in what format (manager, peer, skip-level, panel; one session or several) → persona weights are reset from a blended guess, and per-session mini-packs become possible; if your final is several sessions, send the schedule
- The recruiter's prep email → any declared deliverable gets its own build section
- Search access, or Stripe's values page and your recruiter's description of the loop pasted in → the values cheat sheet, the loop-based persona weights and strategy-grounded CO questions
- An interviewer's name → an interviewer read and a reverse question tied to their path
- A `tuesday-dossier.md` → verified evidence, per-gap strategy and the objection worth the deepest rehearsal, so the Skeptic bank stops being a guess
