I'm writing the pack now. Web search was denied, so it rests on what you gave me. I'll record the three refused searches in the Sources section.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/tuesday/part-2/rooms/case-1-denied-b348741b/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. It has 23 questions across seven personas, built for a peer conversation with Dan.

Web search was denied, so all three searches (Northwind's values, its interview process, Dan's public footprint) came back refused. The pack rests only on what you gave me. That means no values cheat sheet and no verified loop structure. The interviewer read uses your description of Dan, not his public footprint. The Sources section records this.

- **Highest-ROI prep is D1.** The question is that Priya has no classic sales-ops or quota-setting experience, asked by the peer who owns that territory. The pack has her say the limit first, then her quoted target-setting work, then a plan. It includes three follow-ups to rehearse.
- **Persona weights:** Peer Evaluator and Data-Driven Prober come first (5 questions each), then Case, Skeptic, Conversational, Pressure and Values.
- **Open slots:** Where your notes don't say how something was done, the guidance is a slot for Priya to fill from what she actually did. This applies to how the ~$400M was counted, how the revenue model was built, and whether she designed any partner motion.
- **What the pack won't coach:** It lists claims Priya shouldn't make, such as "owned GTM", "drove the $400M" or "led carrier negotiations".

Say the word and I'll play Dan on D1, the pack's highest-ROI question.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Has the recruiter said what Dan will focus on or asked for a prepared deliverable? A named focus or deliverable would reweight the banks or add a build section.
Can you paste the full JD or Priya's CV text? Either would replace the rows I built from your summary, or say skip and I'll leave it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy — a peer, both reporting to the same VP. **Format:** one 60-minute conversation. **Candidate:** Priya. First version of this pack.

## How to use this pack

- **Personas describe how a question is asked; types describe what it is scored on.** Rehearse both: the same fit question can arrive collegially, as a data probe, or as a challenge.
- **Type key:**

| Tag | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the behavior asked about |
| EXP | Work-experience deep-dive: do the claims survive scrutiny, and what was actually yours |
| JD | Role or JD-driven: can you do the listed job, including its gaps |
| CO | Company and strategy knowledge: can you think at Northwind's altitude |
| CASE | Live problem set in the role, scored on structure and reasoning |

- **Guidance is scaffolding, not a script.** In guidance cells, "you" means Priya. Every claim about her past rests on a sentence quoted in the row's Provenance column. Where a quote does not carry a beat, the cell holds an answer slot: an instruction for the interview, with one branch for "I did this" and one for "that did not happen, or was not mine".
- **Provenance labels:** `[grounded]` traces to what you gave me; `[inferred]` is a derivation from it; `[generic]` is a role-family pattern with no claim about Northwind or Priya.
- **Highest-ROI prep in this pack: D1** (the sales-ops and quota-setting gap, asked by the peer who owns that territory). Rehearse it until it is boring.

## Fit snapshot

Requirements are the JD highlights from your message. Evidence is quoted from your message, which is the only source on Priya's background so far. There are no gate rows: the highlights name no term such as location, schedule, pay or travel, and the full JD may.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Words stay at the quotes' scope: "I spent nine years in product strategy and ops at a large consumer-tech company, and I proposed a store-surface change that was credited with a ~$400M ARR uplift." Your material says strategy and a proposal, not go-to-market ownership of a product line. Answer slot: the JD's two-product-lines line makes a probe on who made launch decisions likely. If any go-to-market decision was yours to make, say which, in your own words; if there was no such decision, or it was not yours, say so plainly and stay with the strategy work and the proposal |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | none given | none | [grounded] | discovery | The material does not show work across these stages, and nothing says there was none. Answer slot: the JD's lifecycle line makes a probe on where you have found unused growth likely. If any of your work looked across stages of a customer relationship, say what it was and what part was yours, in your own words; if none did, say so plainly and say where you would look first |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | discovery | The quote names the tools, not independent analysis. Words: "I'm skilled in SQL and Tableau." Answer slot: expect a "show me" probe from a data-driven peer. If you ran an analysis yourself, pick one and say the question, the method and what you found; if you did not run one yourself, say so plainly and stay with the tools |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a model used in negotiations, not the design of a partner motion, and the words stay there: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if any part of how a partner relationship was structured, run or measured was yours to set, say which and how you decided; if there was no such step, or it was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on how consensus was reached. Lead with the quote in its own terms: you set the targets, with cross-org consensus |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the plus in terms of use. Words: "I use AI tools daily." Nothing is added to it, and it stays use, not building or launching |
| F7 | Sales-strategy fluency (quota, capacity and territory planning) that a Director of Sales Strategy may test; not named in the JD highlights | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and it has been stated. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. F5's quote says you set volume targets with consensus; your material does not show whether that method resembled quota-setting, so no bridge claims it |

## Reading the interviewer

Public footprint could not be searched (see Sources). This read rests only on how you described Dan.

| Signal (source: your description of his profile) | What it implies for the conversation | Where it shows up |
|---|---|---|
| Self-describes as "relentlessly data-driven" | Every number is probed to its assumptions; "I don't know how it was counted" is better than a guessed method | B1, B2, B3, B4 |
| Career spine in pricing and monetization | Case questions tilt to pricing, packaging and unit economics; this is his native language | C2, C3, B2 |
| One early-stage startup chapter | Expect a probe on pace and scrappiness at a large-company background; 0→1 framing is relevant to emerging products | D2, G1, R1 |
| Peer reporting to the same VP | He is pricing what you cost and add to his own work: seams, disagreement style, credit | A1 to A5, R2 |

**Mirror opportunities.** Shared vocabulary: monetization and revenue, against F4's quote, "built a partner-level revenue model used in carrier negotiations". No shared career jump is offered: nothing in the material carries Priya's side of an early-stage jump.

## Persona table

Weights rest on your stated relationship (peer, one 60-minute session with Dan) and on his profile as described. No Northwind loop or values-style round is documented, so no values round is assumed.

| Persona | How it shows up with Dan | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting between sales strategy and emerging-products GTM; what you need from his team; credit; disagreement | Highest. Peer is this persona's relationship prior, and he is weighing what the hire does to his own load | Reciprocity framing: what you bring his team, not only what you need. Propose seam principles rather than pretending to know the seam. Show spine and tact together |
| Data-Driven Prober | CV numbers and any analysis probed to inputs, denominators and assumptions | Highest. Peer prior, raised again by "relentlessly data-driven" | Know what you can and cannot say about how each number was counted. Name your own weakest assumption before he does. Offer to walk an analysis end to end if you have one |
| Case/Strategist | Live problems on whitespace, bundling, profitability, partner design, in pricing and packaging terms | Medium-high. A peer is not the manager who sets cases, but his pricing spine tilts toward them | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Skeptic | Quiet probing of the sales-ops gap and the consumer-to-enterprise move | Medium. Peers voice it collegially, and F7 is a stated gap in his own territory | Rehearse D1 until boring. Bridge only from what is quoted, and name the limit before he asks |
| Conversational / Rapport | Opener and casual AI question | Low-medium. The opener nearly always arrives; casual questions are still scored | Pre-script a 90-second arc. Treat the AI question as scored |
| Pressure | A collegial "how much was actually you" on the headline number | Low. Not a peer prior, so it arrives as a challenge inside other questions | Pause, restate, hold through two follow-ups, concede specifically |
| Values / Behavioral | One or two story prompts inside the peer conversation | Low. No values-style round is detected and no Northwind values were read | Where a quoted sentence carries a story, use it; otherwise follow the selection scaffold to its honest branch |

## Question banks

Ordered by weight. 23 questions: 5, 5, 4, 3, 2, 2, 2.

### A. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where is the seam between sales strategy and emerging-products GTM, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Do not pretend to know the seam. Ask Dan how it works today, then offer principles: shared definitions for the numbers both teams use, anything touching his plans reviewed with him before it reaches the VP, disagreements settled on the data before escalation. The only quoted fact for a disagreement story is "I set annual volume targets with cross-org consensus." Answer slot: expect a probe on what the orgs disagreed about and what part of reaching consensus was yours. If there was disagreement, say what it was and what you did, in your own words; if consensus came without disagreement, or the part was not yours, say so plainly and stay with the targets | F5 is the evidence for the cross-functional requirement. JD content, with the peer-seam delivery this persona uses |
| A2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Describe only what the quote states: you proposed the change, and the uplift was credited to it. Lead with the principle you actually follow, then the quoted sentence. Answer slot: if other teams' work fed into the change, say whose and how credit was shared; if the change was yours alone, or credit was never a question, say so plainly and stay with the proposal | Peer Evaluator's own stem for credit-sharing. EXP because the answer tests attribution on the F1 evidence. It would be VAL only if Northwind publishes a collaboration value, which is not in hand |
| A3 | "What would you need from me and my team in your first ninety days?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "skilled in SQL/Tableau" | Reciprocity first. Ask for how his team defines and tracks the lifecycle stages and an hour on how sales plans are built. Then what you bring his work, in the quotes' terms: "I built a partner-level revenue model used in carrier negotiations" and "I'm skilled in SQL and Tableau." Offer him a first read of whitespace before it goes further. That is a plan, not a past | The reciprocity move the peer persona rewards. F4 and F3 are the only candidate evidence offered, at their own scope. JD because it scores how the hire fits the role's seams |
| A4 | "We each own a forecast and the two disagree widely ahead of a VP review. What do you do?" | CASE | [generic] | Structure it: reconcile definitions and scope first, trace the gap to inputs, talk to Dan before the VP, present both numbers with the difference explained, agree what evidence would move each. The question needs no claim about your past, so the guidance makes none | A disagreement-with-an-equal problem for a data-driven peer. `[generic]` because it is a pattern, not a fact about Northwind. CASE because it asks about no past |
| A5 | "Tell me about a time a colleague's data showed you were wrong." | VAL | [generic] | Selection scaffold: pick a time numbers, not seniority, changed your position. It needs your original view, the data, what you changed, and an intact relationship. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The theme comes from his self-description as "relentlessly data-driven". VAL because it scores behavior toward a data-driven peer, not a published value |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The ~$400M ARR uplift: walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Keep the quote's own hedges: "proposed", "credited with", "~". Say the sentence, then the four slots a figure raises, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least (name it before he does), and which part was yours. If you do not know how it was counted, say so plainly. Do not supply a method here; an explanation you cannot repeat under a second question is worse than none | The headline metric on the profile is the first target for a prober. F1 carries it. EXP because it tests whether the figure survives scrutiny |
| B2 | "Walk me through the partner-level revenue model you built." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say the sentence, then take the probes. Answer slot: expect questions on inputs and the assumption you would defend least; if you know them, say them in your own words; if you do not know, or the inputs were not yours, say so plainly and stay with what you built. Expect him to probe in his native territory of pricing and monetization; stay with the model, not with practices the quote does not state | F4 is the model evidence and the peer-level test of whether its owner knows its assumptions. EXP because the premise is the quote's own |
| B3 | "How were the annual volume targets set: what went in, and who had to agree?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Say the sentence, then answer slots in your own words: the inputs, what the targets were sensitive to, the assumption you would defend least. Answer slot: if consensus was hard in some place, say where and what you did; if it came easily, or the method was set by others, say so plainly and stay with the targets. Do not describe the method as quota-setting; the material does not show that | The nearest thing to his own territory, so this is where he compares it with quota-setting. F5 is the evidence and F7 is the limit. EXP because it tests what was actually yours |
| B4 | "Pick an analysis you are proud of in SQL or Tableau and walk me through it end to end." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold: choose one where you can state the question, where the data came from, one thing you would redo, and what you found. If no such analysis comes to mind that you ran yourself, say so plainly, then give the nearest thing your material does carry (you are skilled in SQL and Tableau) or how you would approach one. Offering a full walkthrough is itself the strongest signal for this persona | The JD's independent-analysis line (F3) is where a data-driven peer will test for evidence. The quote names tools, not an analysis, so the guidance is a scaffold |
| B5 | "How would you tell whether adoption inside an account is real, rather than a few power users?" | CASE | [generic] | Clarify what adoption means for the product and who the users are. Then segment by account type and look at breadth versus depth of use, active versus purchased seats, and the trend after onboarding. Separate leading from lagging measures. Say what would change your mind, and ask what Northwind measures today | The JD's adopt stage, tested as a measurement problem he will care about. `[generic]` because the metrics are a pattern. CASE because it asks about no past |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "We have two new lines early in market. Sketch how you would find whitespace across land, adopt, expand and renew. What do you need to know first?" | CASE | [grounded] | Clarify first: each line's stage, who the customers are so far, which data exists. State a hypothesis early. Segment by lifecycle stage and customer type, and for each stage ask where drop-off or unused demand would show. Tie it to enterprise expansion, one of the three priorities in your research note. Size and prioritise, name risks, think aloud, and challenge one premise respectfully, such as whether four stages deserve equal weight for a line this young | The JD's whitespace line (F2) set as the live problem. Uses Northwind's stated enterprise-expansion priority from your research note. CASE because it asks about no past |
| C2 | "A much larger platform vendor starts bundling something that competes with one of our lines. What does the GTM response look like?" | CO | [grounded] | Clarify which line, which buyer, and how the bundle is priced and packaged. Then where a bundle is strongest and weakest by segment, and the options: positioning, packaging, pricing, partner angles. Protect renewals first. Name the tension with profitability if the response is discounting. Expect depth on packaging and discounting from him; reason from the problem, not from claimed experience | Bundling by a much larger platform vendor is the main competitive threat in your research note. His pricing spine makes this his native question. CO content, CASE delivery |
| C3 | "Profitability is a priority alongside Compass and enterprise expansion. How does that change how you would run GTM for a new line?" | CO | [grounded] | Name the tension openly: new lines need investment while profitability is a stated priority. Then choose where to be selective: segments, lower cost-to-serve motions, partner leverage. Define the milestones that tell you to double down or stop, and ask what profitability means at line level here. Keep to reasoning, not to claimed experience | Three stated priorities from your research note, set against each other. CO because it tests altitude. Mid-weight because a peer in sales strategy lives this trade-off daily |
| C4 | "You are asked to design a partner motion for one of the new lines. What do you need to know first?" | CASE | [grounded] | Clarify the objective (reach, fit, margin), who the partners are and what they bring, and what the line needs from partners to be sold. Then the economics for both sides, the partner's roles over the relationship, how conflict with direct sales is handled (this is where his team's seam shows up), and how it is measured. The question asks about no past, so the guidance claims none | The JD's required partner-motion line (F4), set as the live problem that tests design thinking. CASE because it presupposes nothing about the candidate |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your background does not include classic sales-ops or quota-setting. This role has to work through the sales org to land and expand. How do you handle that?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus" | **The deepest rehearsal in the pack.** Say the limit first, before it is asked for: "I don't have classic sales-ops or quota-setting experience." Then what your material carries at its own scope: "I set annual volume targets with cross-org consensus." Do not call it quota-setting. Then the plan: ask Dan to walk you through how his team sets and tracks targets, and what he would not want touched. Follow-ups to rehearse: (1) "So what is the difference?" (2) "What would you get wrong first?" (3) "Why should I trust you with my numbers?" Hold through the first two by returning to the quoted sentence. Concede specifically: his team's planning mechanics are what you would learn from him, while you bring the analysis and the cross-org work you have said. Answer slot: if the way those targets were set resembled how a sales org allocates them, say how; if it did not, or you do not know, say so plainly and stay with the targets | F7 is the stated gap in the territory he runs, and F5 is the nearest quoted evidence. This objection will arrive in some form. JD because it scores the requirement to work with the sales org, in a Skeptic's quiet register |
| D2 | "Your last nine years were at a large consumer-tech company. Why enterprise B2B data infrastructure, and why now?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Motivation is yours to give: state why this role and why now, in your own words; this pack supplies no reason. Then the transfer, only at the quote's scope. Answer slot: if any of your work touched enterprise or B2B customers, say what it was and what part was yours; if it did not, say so plainly and say what you would learn first. Keep the story consistent with E1 | The predictable background-mismatch probe (F1). His startup chapter makes a pace-and-fit version of it likely. JD because it tests whether the candidate can do this job from this background |
| D3 | "The JD says partner-motion design is required. What have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold: "I built a partner-level revenue model used in carrier negotiations." The limit is the pack's observation, not your words: the material says a model, not a motion. Answer slot: if any part of how a partner relationship was structured, run or measured was yours to set, say which and how you decided; if none was, say so plainly and say that the model is what you built. Hold through two follow-ups by returning to the model, never by adding to it. Then concede the gap specifically and offer the C4 structure as how you would design one | F4 is the JD's required line and the thinnest of the headline requirements. JD because it scores a stated requirement directly |

### E. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations" | A 90-second arc with three beats the quotes state: two years in strategy consulting at a top firm; then nine years in product strategy and ops at a large consumer-tech company; the partner-level revenue model used in carrier negotiations as the one anchor. Close on why this role, in your own words; this pack supplies no reason. Do not narrate what the work proves; let him draw the inference | The opener nearly always arrives and is scored on economy. EXP because it sets up every follow-up that reads the profile |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say the sentence, then: "I use AI tools daily." Answer slot: name which tools and for what tasks, in your own words; if your use is mostly drafting or analysis help, say so; if a use Dan asks about is not one of yours, say so plainly. Do not describe building or launching an AI product, which the material does not show. You know Compass by name from the research note; if you give a view on it, give it as a view | The JD's AI plus (F6), asked casually and still scored. JD because it scores a stated qualification |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you, rather than someone who has run enterprise sales strategy?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus"; "No classic sales-ops or quota-setting experience" | Pause and restate. Three beats from the quotes: the model, the targets set with cross-org consensus, your skill in SQL and Tableau. Concede the gap in one clause: "I don't have classic sales-ops or quota-setting experience." Do not argue you are better; say what you bring and what you would learn. Hold through two follow-ups by returning to those sentences | A time-boxed challenge on the F7 gap against the F4 and F5 evidence. JD because the content is the requirement; Pressure because the delivery is composure |
| F2 | "That ~$400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The honest hold is the sentence: you proposed the change, and the uplift was credited to it. Anything more (what others did, how the credit was assigned) is an answer slot: if you know how the credit was assigned, say so; if you do not, or it was not yours to know, say so plainly. Hold through two follow-ups by returning to the sentence. Concede specifically what you do not know, never the core claim | The attribution probe exists to catch inflation. F1's headline number is the target. EXP because it scores what the candidate actually did |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time the hard truth actually landed. It needs the truth, the stakes, how you framed it with evidence, and an intact relationship afterward. Use "we" for context and "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for this style. No Northwind values were read, so it is `[generic]`. VAL because it scores behavior, not a published value |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the customer's interest and the metric pulled apart. It needs the metric, what the customer needed, what you did, and what it cost. Say plainly what counts as the customer in your work. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem again, and a likely gap for a consumer-tech background moving to enterprise. VAL, `[generic]`, low weight |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "own GTM strategy for two new product lines" | C1, C2, C3, C4, D2, F1 |
| "identify whitespace across land/adopt/expand/renew" | C1, B5 |
| "run independent analysis in SQL and Tableau" | B4, B5, A3 |
| "partner-motion design experience required" | D3, C4, B2 |
| "strong cross-functional influence" | A1, A2, A3, A4, B3 |
| "AI experience a plus" | E2 |
| Sales-strategy fluency (F7, not in the JD highlights) | D1, F1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You have spent your career in pricing and monetization, with one early-stage chapter. How has that chapter shaped how you work now?" | Ties to his own path and turns the hardest motivation probe into a peer conversation |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it shows you are thinking about his load |
| R3 | "Is Compass one of the two lines this role covers, or does it sit with another team?" | Shows you read the stated priorities, and surfaces the seam directly |
| R4 | "Does the bundling pressure show up in your data yet, and where?" | Speaks to his data-driven side and tests whether you can think at the company's altitude |
| R5 | "How are the handoffs between land, adopt, expand and renew measured today, and which metric do you trust least?" | A data-driven peer will enjoy the honest answer, and it maps the work you would inherit |
| R6 | "What would make this hire an obvious success to you and the VP at six months?" | Aligns on the bar the peer and the shared VP will use |

## Prohibited claims

These are claims this pack will not coach, with the basis and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or led go-to-market for a product line | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: the material says product strategy and a proposal, not GTM ownership. C1 and D2 slots stay inside that |
| Drove, delivered or generated the ~$400M ARR uplift | Inflated form of F1 | "I proposed a store-surface change credited with a ~$400M ARR uplift." B1 and F2 slots ask only how it was counted and which part was yours |
| Led or ran carrier negotiations | Inflated form of F4 | "I built a partner-level revenue model used in carrier negotiations." The material says a model used in negotiations |
| Designed a partner motion or program | Inflated form of F4 | F4's quote at its own scope. D3's slot stays inside the model |
| Has classic sales-ops or quota-setting experience, or called her target-setting quota-setting | Negative stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| Built, launched or led an AI product | Inflated form of F6 | "I use AI tools daily." E2's slot asks only which tools and for what |

## Sources

**Provided documents:** your message: JD highlights, Priya's background in your notes, your description of Dan's profile, and your research note on Northwind's three priorities and its main competitive threat. No tuesday-dossier.md was present.

**Searches sent (all refused, none returned results):**

- "Northwind Data company values operating principles" — refused
- "Northwind Data interview process strategy GTM role" — refused
- "Dan Kovac Director of Sales Strategy Northwind Data" — refused

**Loop:** your words establish one 60-minute conversation run by Dan. No documented Northwind loop exists in hand, so no values-style round is detected and no fallback archetype is used.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Search refused. It would have supplied published values by name for VAL themes and, if a values-style round were documented, a cheat sheet. G1 and G2 are `[generic]` as a result |
| 2. Northwind Data interview process for this role family | unavailable | Search refused. It would have documented loop structure; persona weights rest on your stated relationship instead |
| 3. Northwind Data strategy and recent news | skipped | Your research note already supplies the three priorities and the main competitive threat that feed C2 and C3 |
| 4. Dan Kovac, Northwind Data | unavailable | Search refused. It would have added public talks and writing to the interviewer read, which rests only on your description |
| 5. Representative JD for the title | skipped | The JD highlights you supplied fix the fit snapshot rows and the JD-tagged questions as far as they go; the full JD is in the upgrade menu |

## Upgrade menu

- Full JD text → any term-type requirement (location, schedule, travel, pay) becomes its own gate row, and mid-list requirements beyond the highlights get questions and coverage-table rows
- Priya's CV text → the rows built from your summary notes (F1 to F7) get her own verbatim sentences, and the Provenance quotes in every bank tighten
- Priya's own answers to the answer slots, stated outside a drill (how the ~$400M was counted, how the targets and the revenue model were built, whether any partner relationship was hers to structure) → rows F1 to F4 gain evidence, and B1 to B3, D1, D3 and F2 become story-mapped instead of slots
- The recruiter's guidance on what Dan will cover or any prepared deliverable → coverage reweighted, and a build section for any announced deliverable
- Which product lines the role covers, and whether Compass is one → C1 to C4 become grounded in the real lines instead of generic cases
- Web search permission → the default research pass (values, loop, strategy sweep, Dan's public footprint), plus an offer, made once, of a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) for a strategy brief and Dan's talks and writing
- Prep time available → a prioritized prep schedule sized to it
- A tuesday-dossier.md, if one exists → verified evidence, allowed strategies per weak area and prohibited claims arrive pre-graded, and the highest-ROI objection is read from it rather than inferred
