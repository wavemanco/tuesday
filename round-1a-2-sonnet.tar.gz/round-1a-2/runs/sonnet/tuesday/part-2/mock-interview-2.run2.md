Web search was refused, so no company research ran. I'm building the pack from your JD and your own summary, labeling anything that isn't traceable to those as generic or inferred, and saving it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/tuesday/part-2/rooms/case-2-denied-9c87266e/atlas-freight_operations-manager_interview_pack.md`. It has 21 questions across seven interviewer styles. I built it for an unknown round with flat weights, since you don't know who you're meeting.

The web searches were refused in this session, so nothing in the pack comes from research on Atlas Freight. It rests on your JD and your own summary, and the Sources section lists the refused calls. The pack names A2 as the highest-ROI rehearsal: you're over 3 supervisors today, and the role asks you to lead 12. F6, never having used Power BI, is the one gap that wording can't close, so the pack coaches a calm concession and a plan.

Say the word and I'll play the Skeptic on A2 as a live drill.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Has the recruiter or the invite said what kind of round this is, or asked you to bring anything?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer and relationship:** not known
**Round type:** not stated, so this is a full-loop pack with flat persona weights, which is noticeably weaker than a pack built on a known round
**Built from:** the JD as you pasted it and your own summary of your background. No research on Atlas Freight is in it (see Sources).

## How to use this pack

Personas are how a question is asked; types are what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows how you work, not generic virtue |
| EXP | Whether your claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you did your homework on the company |
| CASE | Structure and reasoning on a live problem from the role |

Labels: `[grounded]` is traceable to your message, the JD or a cited source; `[inferred]` is derived from them, with the derivation named; `[generic]` is a pattern for the role family with no claim about you or Atlas Freight.

An answer slot is an instruction for the interview, not a question for me: it tells you where an honest answer goes, and it always allows that the practice was not yours or never existed.

## Prep triage

The only time stated is next week, with no hours, so this is ordered rather than scheduled. Do each until it is boring.

1. A2, the highest-ROI rehearsal in the pack.
2. A4 and B1, then B2: the years, and the 40%.
3. D3 with the F6 line, said aloud.
4. C1 to C3, structured aloud.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says a senior shift manager over 3 supervisors and the site's surge plan, not terminal operations and not four sites, and the words stay at that scope: "I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's four-site line makes a probe on the span of your work likely. Say what the shift and the surge plan covered, in your own words; if part of it was not yours, say so plainly and stay with what was |
| F2 | "drive on-time performance" — JD | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | The surge-plan quote touches the service requirement without showing a measure behind it. Answer slot: the JD's on-time performance line makes a probe on how the plan's results were judged likely. If a measure was kept, say what it was and which part of it was yours; if none was, or it was not yours, say so plainly and describe how you ran the plan |
| F3 | "cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material says mis-pick rate, not cost-per-shipment, and the words stay there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD's cost line makes a probe on what else the redesign changed likely. If anything beyond the mis-pick rate was counted, say what and which part was yours; if nothing else was counted, say so plainly and stay with the mis-pick rate |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says 3 supervisors and the JD says 12; the number stays with its noun: "I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's team-lead line makes a probe on how you lead likely. Say how you lead those 3, in your own words; if you have not led a bigger team, say so plainly and say, as a plan and never as a past, what you would want to see first with each team |
| F5 | "build reporting in Excel" — JD | "solid Excel" — your message | low | [inferred] | discovery | The quote names a tool, not reports built with it. Answer slot: the JD's reporting line makes a probe on what you built likely. If you built reports in Excel, say what they showed and who used them, in your own words; if you did not, or it was not you, say so plainly and say what Excel work you can describe |
| F6 | "Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI work, and nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | The seven years are in ops, and the quotes do not show how many of them were spent leading people, so the number stays at its own scope: "I have 7 years in warehouse and distribution ops, and I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's 5+ years line makes a probe on how the years divide likely. Say how they divide between roles, in your own words; if you cannot separate them, say so plainly and stay with the years as stated |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | presentation | The quote already reaches the Lean/Six Sigma line in other terms; reword it only as stated: "I'm green belt certified." The pack's observation: your material gives the belt, not the framework, the issuing body or a project behind it, so the match to the JD's wording is the interviewer's to probe, and D2 and F3 rehearse it |

## Persona table

Round type and interviewer are unknown, so the relationship priors cannot be applied, and no loop source was read, so these weights rest on a fallback pattern, the Generic archetype (screen, hiring manager, panel) at flat weights, and not on Atlas Freight's documented process. Flat means three questions each, one extra in the Skeptic bank because the deepest rehearsal goes there, and two for the Peer, who is plausible only if a panel is on the loop.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the gaps: scale, background, tools | Flat weight, 4 questions. The thinnest rows of the fit snapshot, F1, F4 and F6, are what this persona asks about, which earns the extra question | Rehearse A2 until it is boring: the quote at its own scope, the limit named by you before they do, then the plan, never an addition |
| Data-Driven Prober | Reads your lines one by one and asks how each number was counted | Flat weight, 3 questions. F3 holds the only figure in your material, and a prober goes to the figure first | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know (B1) |
| Case / Strategist | Live problems from the job: diagnose, plan, size | Flat weight, 3 questions. The JD's on-time and cost lines are natural case material | Clarify, objective, segmentation, approach, metrics, risks; think aloud and challenge one premise (C1 to C3) |
| Pressure / Stress | Interrupts, time-boxes, tests composure | Flat weight, 3 questions. F3, F6 and F8 each hand a pressure interviewer something specific to press | Pause, restate, anchor in what you stated, hold through two follow-ups, then concede specifically (D1 to D3) |
| Values / Behavioral | Scenario probes, often STAR-shaped | Flat weight, 3 questions. No values-style round is detected and no published values were read, so these are generic behavioral questions, not mapped to named values | A selection scaffold with its honest branch where no sentence of yours carries the story (E1 to E3) |
| Conversational / Rapport | Friendly and unstructured; casual questions are still scored | Flat weight, 3 questions | A 90-second arc for the biography question, and treat casual questions on JD topics as scored (F1 to F3) |
| Peer Evaluator | Seam-splitting between adjacent teams, credit-sharing | Lighter, 2 questions, because a peer is only plausible in a panel | Reciprocity framing, and seam principles rather than pretending to know the seam (G1, G2) |

## Question banks

### A. The Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] | Choose the requirement where you judge your own material thinnest and name it first, before they do, with what you would do about it in week one, said as a plan. The fit snapshot's F1, F4 and F6 rows are where the material is thinnest, but the choice is yours. If none comes to mind, say so plainly and name the nearest requirement that does | The standard Skeptic opener, and its answer is the cheapest credibility you can earn. JD because it scores the stated requirements, gaps included |
| A2 | "The JD asks you to lead a team of 12 supervisors, and you're currently over 3. What makes you think you can step up to that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. The hold is only what the quote carries: "I'm currently a senior shift manager over 3 supervisors." Say that number yourself before they do. Answer slot: if any part of how you lead those 3 would carry to a bigger team, say what it is in your own words; if you have not led a bigger team, say so plainly, return to the 3, and say as a plan what you would want to see first with each team. Hold through two follow-ups by returning to the 3, never by adding to it, and concede the difference in size specifically rather than fold on what you do lead | F4 is where the role's scale presses hardest, so this objection arrives in some form, and it is the single most predictable one for this candidate. JD because it scores the stated requirement; a Skeptic tone because it probes the gap |
| A3 | "Your background is warehouse and distribution. How does that map to terminal operations across four sites?" | JD | [grounded] "7 years in warehouse and distribution ops"; "ran the site's peak-season surge plan two years running" | Hold only the quotes: "I have 7 years in warehouse and distribution ops" and "I ran the site's peak-season surge plan two years running." Say, as an expectation and not a past, what you expect to be the same and what you expect to differ in a terminal. Answer slot: the JD's four-site line makes a probe on the span of your work likely. Say what the shift and the surge plan covered, in your own words; if part of it was not yours, say so plainly and stay with what was | F1 is the evidence for the daily-operations requirement and the likeliest place to be pressed on scope. JD because it scores the stated requirement |
| A4 | "The role asks for 5+ years of operations leadership. Walk me through your 7 years in warehouse and distribution ops, role by role." | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Story-mapped only on the beats the quotes state: the 7 years in warehouse and distribution ops, and the current senior shift manager role over 3 supervisors. Answer slot: the JD's 5+ years line makes a probe on how the years divide likely. Say, role by role, what each role was, in your own words; if you cannot separate them, say so plainly and stay with the years as you stated them | F7 is the row where a numeric requirement meets a number of a different kind, and an interviewer can check it against dates. JD because it scores the stated requirement |

### B. The Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that 40% mis-pick figure was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the sentence as stated: "I cut mis-pick rate 40% by redesigning the pick path." Then the four slots, each in your own words and each with an honest branch: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. The pack supplies no baseline, period or method | F3 holds the only figure in the material, and figures draw probes. EXP because it tests counting and attribution |
| B2 | "How did you judge whether the surge plan was working?" | JD | [inferred] "ran the site's peak-season surge plan two years running" | Start from the sentence: "I ran the site's peak-season surge plan two years running." Answer slot: the JD's on-time performance line makes this probe likely. If a measure was kept, say what it was and which part of it was yours, in your own words; if none was, or it was not yours, say so plainly and describe how you ran the plan. Two years running makes a comparison between the years a likely follow-up; answer it only from what you remember doing | F2 is thin, so the probe is likely to land here. JD because it scores the stated on-time line; [inferred] because the link from the plan to that line is this pack's derivation |
| B3 | "What reporting have you built in Excel, and who used it?" | JD | [inferred] "solid Excel" | Answer slot: the JD's reporting line makes this probe likely. If you built reports in Excel, say what they showed, who used them and how often, in your own words; if you did not, or it was not you, say so plainly and say what Excel work you can describe. Never name a report, dashboard or audience you did not give | F5 is the Excel half of the reporting requirement, and "solid" is an adjective an interviewer will test with a concrete ask. JD because it scores the stated requirement |

### C. The Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "One of your four sites has slipped on on-time performance this month. What do you need to know first, and what do you do in the first week?" | JD | [generic] | Clarify before you structure: what "late" means here, since when, and where it shows up. Then the objective, the cuts you would make, your approach, the metric you would watch and the main risk. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | F2 is the thinnest evidence row for a stated requirement, so a live problem lets you show reasoning without a claim. JD content, CASE delivery |
| C2 | "Cost-per-shipment at one site is running above the others. How would you work out why?" | JD | [generic] | Ask what is in the number before anything else: what is counted, per what, over what period. Then break it into parts, compare against the other sites, name the first thing you would test and what would change your mind. A plan, not a past: no figure and no past project goes in | F3 stops at mis-pick rate, so this is where the cost requirement gets rehearsed without a claim. JD content, CASE delivery |
| C3 | "It's your first 30 days across the four sites. How do you spend them?" | CASE | [generic] | Structure it as a sequence: who you meet, what you want to see in person, what you decide to hold back from changing, and what you would have decided by day 30. A plan stated as intent, never as something you have done | F1 and F4 are scale gaps, and a first-30-days plan is the honest way to rehearse them. CASE because it is a live problem set in the role |

### D. The Pressure / Stress Interviewer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause, restate the question, then hold the sentence as stated: "I cut mis-pick rate 40% by redesigning the pick path." Hold it through two follow-ups by returning to the sentence, never by adding to it. Then concede specifically. Answer slot: if others carried part of it, say which part and whose, in your own words; if you cannot separate it, say so plainly and return to the sentence | F3's figure is the likeliest target for an attribution probe. EXP because it tests what was actually yours |
| D2 | "You're green belt certified. What have you done differently because of it?" | JD | [grounded] "green belt certified" | Hold the sentence as stated: "I'm green belt certified." Answer slot: the JD's Lean/Six Sigma line makes this probe likely. If you have used the method in your work, say where and which part was yours, in your own words; if you have not, or it was not yours, say so plainly and say what the belt covered. Do not link it to any project you have not tied to it yourself | F8 is a credential with nothing behind it in your material, so pressure lands on the use, not the belt. JD because it scores the stated plus |
| D3 | "The JD lists Power BI, and you've said you've never used it. Why isn't that a dealbreaker?" | JD | [grounded] "never used Power BI" | Pause and do not defend. Concede first, in the quote's own words: "I've never used Power BI." Then hold the only position the material carries, which is a plan: say as intent what you would build first and for whom, and how you would learn it, all as future, never as done. Hold that through two follow-ups; the concession is the limit, so add nothing to it | F6 is the one gap wording cannot close, so the rehearsal is a calm concession and a plan. JD because it scores the stated requirement |

### E. The Values / Behavioral Interviewer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | No sentence of yours carries this one, so this is a selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, a moment you did not soften it, and the relationship intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral probe with no published values read, so it is generic. VAL because it scores behavior, not a named value |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | A selection scaffold: pick a time the customer's need and a number you were measured on pointed different ways. It needs a named choice and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's on-time and cost lines set service against cost, which is where this question lives. VAL because it scores behavior |
| E3 | "Tell me about a time you changed how a team worked." | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Story-mapped only on the beats the sentence states: the mis-pick rate cut 40%, by redesigning the pick path. Answer slot: the JD's team-lead line makes a probe on how others took the change likely. If the redesign changed how others worked, say what changed and how they took it, in your own words; if it did not touch others' work, or you choose a different time, say so plainly. If no time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F3 is the only change-making sentence in the material, and the JD's team-lead line makes it a likely theme. VAL because it scores behavior |

### F. The Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | A 90-second arc with only the beats the sentences state: 7 years in warehouse and distribution ops, and now a senior shift manager over 3 supervisors. The through-line between them, and why this role next, are yours to add in your own words; the pack has neither. End on this role, not on the present job | F7 and F4 carry the biography, and this is the question that sets the frame for everything after. EXP because it checks the story against the record |
| F2 | "What drew you to Atlas Freight?" | CO | [generic] | Anchor in the posting's own words, "regional logistics, 800 employees", and in what you read on the company's own pages before the interview; this pack holds no research on Atlas Freight, so nothing here is a fact about the company. Give a reason that is yours. If none comes to mind yet, read those pages and choose one then | Homework depth is scored even in a friendly register. CO because it tests what you know of the company, and [generic] because no research ran |
| F3 | "What are you actually playing with in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Answer slot: the JD's Lean/Six Sigma line makes this casual probe likely. If you are using any of it now, say what and where, in your own words; if you are not, say so plainly and say what the belt covered: "I'm green belt certified." Treat the casual register as scored | F8 is the plus the JD names, and rapport interviewers ask about plus-skills casually. JD because it scores the stated plus |

### G. The Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Two sites hand work to each other and each says the other is the delay. What do you do?" | CASE | [generic] | Reciprocity first: what each side needs from the other and what you would offer. Then a principle for the seam rather than a verdict, such as who sees which data and who decides when they cannot agree, and how you would tell both. A plan, with no claim about your past | The JD's four sites make a seam likely in any panel with a peer. CASE because it is a live problem |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | A selection scaffold: pick a time work spanned teams. It needs a named handoff, a moment credit was at stake, and both sides still working with you; use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A peer's stock probe, with no sentence of yours that carries it. VAL because it scores behavior |

### Requirement coverage

| JD requirement | Questions | Note |
|---|---|---|
| "Own daily terminal operations across 4 sites" | A3, C1, C3, G1 | |
| "drive on-time performance" | B2, C1 | |
| "cost-per-shipment down" | C2 | |
| "lead a team of 12 supervisors" | A2, E3 | |
| "build reporting in Excel/Power BI" | B3, D3 | |
| "5+ years operations leadership required" | A4 | |
| "Lean/Six Sigma a plus" | D2, F3 | |

## Reverse questions

Role-generic, because no interviewer profile exists; a name would let one of these tie to their own path.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does on-time performance look like across the four sites today, and which one is hardest?" | It asks for the interviewer's own scoring sheet on a stated requirement, and shows you think in service measures |
| R2 | "How is cost-per-shipment calculated here, and who owns its inputs?" | It is the counting question you rehearsed in B1, turned around, and it shows you ask what is in a number first |
| R3 | "What does reporting look like today, and what would you expect me to build versus maintain in the first quarter?" | It brings the Power BI gap up on your terms, as a plan, before an interviewer does |
| R4 | "How do the supervisors work with this role day to day, and where does it help most?" | It shows you are thinking about leading at scale, which is where F4 is thin |
| R5 | "What would a good first 90 days look like for this role?" | It pins down what the role is scored on, and you can restate it in your close |
| R6 | "What differs most between the sites?" | It signals you will not assume your own site's pattern carries over |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned terminal operations across four sites | Inflated form of F1 | F1's quotes at their own scope: "currently a senior shift manager over 3 supervisors" and "ran the site's peak-season surge plan two years running". The limit is the pack's observation: the material says the site's plan and 3 supervisors, not terminals or four sites. A3's slot stays inside what you ran |
| Led 12 supervisors | Inflated form of F4 | F4's quote at its own scope: "currently a senior shift manager over 3 supervisors". The limit is the pack's observation: the number stays with its noun. A2's slot stays with how you lead those 3 |
| Cut cost per shipment | Inflated form of F3 | F3's quote at its own scope: "cut mis-pick rate 40% by redesigning the pick path". The limit is the pack's observation: the material says mis-pick rate. B1's and F3's slots stay inside that figure |
| Seven years of operations leadership | Inflated form of F7 | F7's quotes at their own scope: "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors". The limit is the pack's observation: the material gives the years in ops, not how they divide. A4's slot asks only how they divide |
| Has Power BI experience | Negative the candidate stated, F6 | The plain acknowledgment F6 gives: "I've never used Power BI." Then a plan, never a past. No slot |

## Sources

**Provided documents:** the JD as quoted in your message; your background as stated in your message. No dossier was present.

**Searches sent, and what came back:**

| Query | Outcome |
|---|---|
| Atlas Freight regional logistics company values | refused |
| Atlas Freight interview process operations manager | refused |
| Atlas Freight regional logistics terminals news strategy | refused |

No fetches were sent.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | All calls were refused. It would have moved the values cheat sheet and mapped the VAL bank to named values; the upgrade menu offers it |
| 2. `Atlas Freight interview process operations manager` | unavailable | All calls were refused. It would have moved the persona weights, which follow the loop's named rounds, and the loop structure |
| 3. `Atlas Freight strategy` / recent news | unavailable | All calls were refused. It would have moved the CO bank, which stays generic without it |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent and the upgrade menu says what a name would unlock |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who you are meeting → persona weights stop being flat, the banks reorder, and the reverse questions retune
- The recruiter's email or process notes, including focus areas and any pre-declared deliverable → coverage assumed from round-type priors becomes coverage built on what they said
- Your CV, with dates and titles → F7 and F4 quote dated entries in place of your summary, and the years in A4 can be checked against them
- A line on whether any of your past work covered more than one site, and the most supervisors you have led at once → F1 and F4 regenerate with your own words quoted, and A2 and A3 gain a story-mapped beat
- Your green belt certificate and a before-and-after report on the pick-path change → F8 and F3 can move from medium toward high, and B1's counting slots can be answered from the document
- Search access, or the company's values page and any interview guide pasted in (this run's three searches were refused; a deeper pass later would be up to 6 further searches and 2 further fetches, several more minutes) → a values cheat sheet, persona weights from a documented loop, and CO and CASE questions grounded in current strategy
- The interviewer's name → an interviewer read, persona weights adjusted from their public professional footprint, and a reverse question tied to their own path
- A tuesday-dossier.md, if you already have one → the objection inferred in A2 would come from verified evidence instead, and claims you have already ruled out would bind every cell
