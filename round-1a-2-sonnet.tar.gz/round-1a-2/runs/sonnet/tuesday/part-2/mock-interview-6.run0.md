Web search was refused, so the pack will rest only on what you've told me. I'm building it now in loop mode, with one mini-pack for each of your three rounds.
Your prep pack for all three rounds is saved as `larkfield-systems_engineering-manager_interview_pack.md` in the working directory. It's in loop mode, with one shared fit snapshot and a mini-pack per round (29 questions in all). Each mini-pack has its own persona weights and reverse questions.

Web search was refused, so the pack has no Larkfield values, loop details or strategy. The Sources section lists all three searches as refused. Your three rounds and the recruiter's "values and leadership philosophy" line for the VP are the only loop information it uses. The role comes from your one-paragraph description, not a full posting, and there's no CV, so every claim about you quotes your own message.

The most useful rehearsal is the pair A1 and H1. Your stated limits, "never managed managers" and "never owned a hardware-adjacent roadmap", are what the hiring manager and the VP will each press. A4, E1 and H2 cover the 60% on-call figure, which comes back in all three rounds.

Say the word and I'll play the Skeptic on A1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. I can convert the pack to Word if you want it.

Can you paste the full job description and your CV, or say skip and I'll keep working from what you've told me? Did the recruiter say what the panel will focus on, or ask you to bring anything?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack (loop mode): Engineering Manager, Larkfield Systems

For Yusuf. Three scheduled rounds: Tuesday, 45 min with the hiring manager (a Director of Engineering, your would-be boss); the Thursday after, 60 min panel (two staff engineers and a product manager); the following Monday, 30 min with the VP Engineering (the recruiter's words: "values and leadership philosophy"). No interviewer names were given, so there is no interviewer read.

## How to use this pack, and the type key

Personas describe how a question arrives (who is asking, in what style). Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: where it says "answer slot", that is an instruction for the interview, and the honest answer is either branch, in your own words.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows values, not generic virtue |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny; what was actually you |
| JD | Role / JD-driven | Can you do the listed job, including its gaps |
| CO | Company and strategy knowledge | Homework depth (none in this pack: see Sources) |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the actual role |

Question IDs run across the pack: A to C are Round 1, D to F are Round 2, G to I are Round 3.

## Prep triage

The few things done well, in order:

1. Before Tuesday: rehearse A1 and A2 aloud until the limits in your own material sound ordinary; then A4 (the 60% figure). Both come back in Rounds 2 and 3 (E1, H1, H2).
2. Before Tuesday: B1 aloud once, thinking out loud.
3. Between Tuesday and Thursday: E1 and E2 (defend both numbers), then D1 and D4.
4. Between Thursday and Monday: H1 and H2 with a timer; G1 in your own words.
5. Everything else is insurance.

## Fit snapshot (shared by all three rounds)

Requirements are quoted from the role description you gave (a one-paragraph summary, not a full posting). Evidence is your own sentences from your message. No CV was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | medium | [grounded] | transferability | Your material says a team lead of six, and the words stay there: "I was a team lead of six for three years." It does not show a second group, other leads or device-management work. Answer slot: the two-squads line makes a probe on leading across groups likely. If you have led more than one group or worked through other leads, say how, in your own words; if you have not, say so plainly and stay with the team of six |
| F2 | "own delivery, hiring and growth for 11 engineers" — role description, the delivery part | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The quote is about a reliability quarter and on-call burden, not about delivery commitments, and the words stay at that scope. Answer slot: the delivery line makes a probe on commitments likely. If delivery commitments were yours to make or defend, say which and how, in your own words; if there were none, or they were not yours, say so plainly and stay with the reliability quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" — role description, the hiring part | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap in kind, but a self-reported line with nothing inspected behind it, so expect a probe on the 40. Lead in the quote's own terms: you run the loop for backend roles, about 40 interviews last year. The pack's observation: the material does not say how many of those you conducted or who made offer decisions, so the words stay with the loop |
| F4 | "own delivery, hiring and growth for 11 engineers" — role description, the growth part | none given | none | [grounded] | discovery | Nothing in the material touches developing engineers. Answer slot: the growth line makes a probe likely. If you have coached, developed or promoted anyone, say what you did, in your own words; if not, or it was not yours, say so plainly and say how you would approach it |
| F5 | "partner with hardware and product on roadmap" — role description, the hardware part | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. The pack's observation: the material does not say whether you have worked alongside hardware teams in another way, and the upgrade menu asks |
| F6 | "partner with hardware and product on roadmap" — role description, the product part | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Adjacent only: the quote says roadmap pressure, not who applied it or that it was product. The words stay there: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if the pressure came from product or hardware, say what you said and what happened, in your own words; if it came from elsewhere, or you cannot recall, say so plainly and stay with the quote |

### Requirement coverage

| Requirement | Question IDs | Note |
|---|---|---|
| F1 two squads | A2, B2, H1, I1 | |
| F2 delivery | B2, B3, B4, E3, I2 | |
| F3 hiring | E2, G3 | |
| F4 growth | G4 | Also reverse question 1.5 |
| F5 hardware | A1, B1 | |
| F6 product | B1, B3, F1, F3 | |
| Headline figures | 60%: A4, E1, H2. About 40 interviews: E2 | |

## Round 1: Hiring manager, Tuesday, 45 min

Assumption: a Director of Engineering who would be your manager; the format is a conversation with live problems.

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the gaps: scale, hardware, why this move | High. Hiring manager row of the priors: they are derisking gaps, and F1 and F5 are the widest | Rehearse the single most predictable objection until it is boring; calibrated candor, no bluffing a competency they own |
| Case / Strategist | Live problems on their actual roadmap | High. Same row: they buy capability and expect problems from the role itself | Clarify, objective, options, criteria, risks; think aloud; challenge one premise respectfully |
| Conversational | Friendly opener, biography question | Medium. A 45-minute first conversation opens this way, and casual questions are still scored | A pre-scripted 90-second arc from your own sentence |

### Question bank

**A. Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | The highest-ROI rehearsal in this pack. Say the limit in your own words: "I've never owned a hardware-adjacent roadmap." Then give a plan for learning it, as a plan and never as a past, with the first steps in your own words; the pack supplies none. Do not volunteer experience this quote does not state. Rehearse it until it sounds boring | F5 is the widest gap against a stated requirement and will be asked in some form. JD because it scores the stated requirement; the Skeptic delivers it |
| A2 | "I see a team of six in your background, and this role is two squads and eleven engineers. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Start with the quote at its scope: "I was a team lead of six for three years." Answer slot: the two-squads line makes a probe on leading across groups likely. If you have led more than one group or worked through other leads, say how, in your own words; if you have not, say so plainly, then say what you would want to learn first as a plan | F1 is the transferability gap the panel will price. The question's premise is F1's quote plus the role description |
| A3 | "Why leave a payments company for industrial IoT, and why now?" | EXP | [generic] | Give your own reason, in your own words. None of your material states one, so the pack supplies none. Keep it to what draws you to this role and say it in under a minute | The Skeptic's motivation probe is predictable for a domain switch. EXP because it tests whether your story holds together |
| A4 | "That 60% drop in on-call burden — how was it measured, and how much was you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say the quote at its scope: the burden dropped after you pushed the quarter through. Answer slot: how the 60% was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words; if you do not know how it was counted, say so plainly. Name your weakest assumption before they do. Do not turn "after" into "because" | F2 carries the one headline figure on your side and is the magnet for a prober. EXP because it tests attribution |

**B. Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Hardware and product both want your two squads' next quarter, and there is room for one. How do you decide?" | CASE | [generic] | A live problem that needs no claim about your past. Clarify first: what each needs, the dates, the cost of waiting. Then the objective, the options, your decision criteria, who you talk to first, and how you tell the one that loses. Challenge one premise respectfully, for instance whether it really is one or the other | The role description puts hardware and product on your roadmap (F5, F6). CASE because the hiring manager tests structure |
| B2 | "You take over two squads and delivery is slipping. What do you look at first?" | CASE | [generic] | Think aloud: what you need to know before you form a view, what you would look at in the first weeks, and what you would not change yet. Frame it as your approach, not as a record | F1 and F2 meet here. CASE because it tests clarify-then-structure |
| B3 | "When would you give a squad a reliability quarter against the roadmap?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say the quote at its scope, then give your decision criteria as a view. Answer slot: if you can say where the roadmap pressure came from and how you answered it, do so in your own words; if you cannot, or it was not framed that way, say so plainly and stay with the quote. Do not describe how it was won | F2 and F6 are the evidence closest to the question. CASE delivery with an EXP root |
| B4 | "What does it mean to own delivery across two squads? What would you track?" | JD | [generic] | Give your own definition and the few signals you would trust, in your own words; the pack supplies no metrics. Say what you would want to learn from the squads before fixing any measure | The role description's delivery line (F2). JD because it scores that line |

**C. Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | A 90-second arc with only the beats the quote states: nine years in engineering, three as a team lead of six, currently at a payments company. End on why this role, in your own words | F1. A rapport opener is scored, and the arc should add nothing the quote does not say |
| C2 | "What are you actually playing with in device management or IoT these days?" | JD | [generic] | Answer truthfully. Your material shows no IoT work, so if you have any, say it in your own words; if you do not, say so plainly and say what you would read or try first | The role description's device-management line (F1). JD because it scores the domain, asked casually |

### Reverse questions for Round 1

| # | Question | Why it lands |
|---|---|---|
| 1.1 | "Do the two squads have their own leads, or would I manage all eleven engineers directly?" | It settles the one structural question your own material flags, and it reads as diligence |
| 1.2 | "What would you want to be true about delivery in these squads six months after I join?" | It turns a vague expectation into a measure you can work toward |
| 1.3 | "Where do hardware and software roadmaps collide today, and who arbitrates?" | It shows you are already thinking about the hardware partnership (F5) |
| 1.4 | "What is the reliability and on-call situation for the device-management services?" | It connects to the one story you can tell about reliability (F2) |
| 1.5 | "How does the team handle growth, and what does a promotion conversation look like here?" | It covers the growth line (F4), where your material is silent |

## Round 2: Panel, Thursday, 60 min (two staff engineers, one product manager)

Assumption: no names, so personas are blended by role: the staff engineers read as peers and technical specialists, the product manager as cross-functional.

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting between a manager and staff engineers; what do you need from us | High. Panel row blends each member's top personas, and staff engineers price what the hire costs their work | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Data-Driven Prober | Probing your numbers to their assumptions | Medium. Technical specialists verify depth, and you have two figures on the table (F2, F3) | Know how each number was counted and say plainly when you do not |
| Values / Behavioral | Scenario probes on working with product | Medium. The cross-functional row, and the role description's partner-with-product line | Stories with "we" for context and "I" for contribution, where your sentences carry one |

### Question bank

**D. Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Where is the line between you deciding and the staff engineers deciding on technical direction?" | JD | [generic] | Offer principles for the seam rather than claiming to know theirs: what you would want to decide, what you would leave to them, how you would settle a disagreement. Say it as your view and ask where it differs today | F1 and F2 reach into technical direction. JD because it scores the role's remit |
| D2 | "When have you disagreed with a senior engineer about priorities?" | VAL | [generic] | Selection scaffold: pick a time with a named stake, a position you held, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Peer persona's disagreement stem. The pack has no sentence of yours for this, so it is a scaffold |
| D3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work crossed teams, say who did what, and how credit was shared. If no such time comes to mind, say so plainly, then say how you would handle it | The Peer persona's credit stem. Scaffold for the same reason as D2 |
| D4 | "What would you need from us in your first month?" | JD | [generic] | A reciprocity answer: what you would ask of them, and what you would offer back. Both in your own words; the pack supplies neither | The Peer persona prices what the hire adds to or removes from their load |

**E. Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through how that 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say the quote at its scope. Answer slot: how the figure was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, each in your own words; if you do not know how it was counted, say so plainly. Offer to talk the numbers through end to end only if you have done that analysis yourself | F2's headline figure, asked a second time by a different persona |
| E2 | "About 40 interviews last year — how were those counted, and how many were yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say the quote at its scope: you run the loop for backend roles, about 40 interviews last year. Answer slot: what the 40 counts, what it is sensitive to, the assumption you would defend least, and how many were yours, in your own words; if the loop was shared, say so plainly. Do not add who decided offers unless you say so yourself | F3's figure, the second magnet for a prober |
| E3 | "Which delivery signals do you trust, and which would you distrust?" | JD | [generic] | A view in your own words: a few signals and why. Mention one you would distrust and why. The pack supplies no metrics and makes no claim about your past | The role description's delivery line (F2), from a technical audience |

**F. Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you pushed back on a product request." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on the quote's beats only: a reliability quarter, pushed through, against roadmap pressure. Answer slot: if the pressure came from product, say what you said and how the person responded, in your own words; if it came from elsewhere, or there was no pushback of this kind, say so plainly and stay with the quote or choose another instance | F6 is the only adjacent evidence for the product partnership. The theme comes from the role description's partner-with-product line |
| F2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a truth that landed, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Values persona's stem. Your material has no sentence for it, so it is a scaffold |
| F3 | "How do you work with a product manager when you disagree on scope?" | JD | [generic] | A view in your own words: how you would find out what the manager needs, where you would give, where you would hold. Do not describe a past case unless you can name one in your own words | The role description's partner-with-product line (F6). The product manager is the audience |

### Reverse questions for Round 2

| # | Question | Why it lands |
|---|---|---|
| 2.1 | "What is the hardest technical trade-off in device management right now?" (staff engineers) | It invites them to teach you, and it is something you cannot get from a posting |
| 2.2 | "How do technical decisions get split today between managers and staff engineers?" | It answers D1 from their side and shows you will not guess the seam |
| 2.3 | "How are hardware timelines and product asks traded off today?" (product manager) | It tests F5 and F6 against how the company actually runs |
| 2.4 | "What is one thing about how these squads work with product that you would change?" | It surfaces a live problem you may be hired to help with |
| 2.5 | "What would make you say this hire was working after ninety days?" | It reciprocates: it asks what the panel needs, not what you do |

## Round 3: VP Engineering, Monday, 30 min

Assumption: a skip-level conversation on "values and leadership philosophy" (the recruiter's words). The recruiter's words are the only loop source, so this round is treated as a values round; Larkfield's published values were not retrieved.

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes on how you lead | High. The recruiter described the round as values and leadership philosophy | Own words for philosophy; stories with "we" for context and "I" for contribution, from your quoted sentences |
| Pressure / Stress | Time-boxed answers; why you | Medium. Skip-level and executive row, and 30 minutes forces compression | Pause, restate, hold a position through two follow-ups, concede specifically |
| Case / Strategist | Altitude questions about the first ninety days | Low. 30 minutes leaves room for one or two | Clarify, structure, say what you would need to know first |

### Question bank

**G. Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "What is your leadership philosophy, in a couple of sentences?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." and "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | State your philosophy in your own words; the pack supplies none. Point at the two quoted lines only at their scope. Answer slot: if a belief of yours explains why you ran the loop or pushed the reliability quarter, say so; if you did not act on a stated philosophy, say so plainly and describe what you did | The recruiter's own words name leadership philosophy. F2 and F3 are the only past sentences it can lean on |
| G2 | "Tell me about a time your values were tested at work." | VAL | [generic] | Selection scaffold: a named stake, a choice you made, and what it cost or protected. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The recruiter's own words name values. Scaffold because no sentence of yours carries it |
| G3 | "How do you hire, and what do you look for?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say the quote at its scope, then say what you look for, in your own words; the pack supplies no criteria. Do not claim decisions on offers unless you can say so yourself | F3, the hiring half of the role. A VP will test whether the hiring is a philosophy or a process |
| G4 | "How do you want to grow the people on your team?" | JD | [generic] | Answer slot: if you have coached, developed or promoted anyone, say what you did, in your own words; if not, or it was not yours, say so plainly and say how you would approach it | F4, where your material is silent. The role description's growth line makes this likely |

**H. Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you, with a team of six behind you and eleven engineers ahead?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." and "I've never managed managers and never owned a hardware-adjacent roadmap." | Pause and restate. Hold the position the quote carries: "I was a team lead of six for three years." Hold it through two follow-ups by returning to that, never by adding to it. Concede specifically and only what you said: "I've never managed managers" and "I've never owned a hardware-adjacent roadmap", each followed by how you would learn it as a plan | The highest-ROI rehearsal for the VP round, and a repeat of A1 at altitude. F1 and F5 are the gaps a skip-level will price |
| H2 | "That result — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold what the quote carries: you pushed the quarter through, and the burden dropped after. Answer slot: who else did what, in your own words; if the team did the work, say so plainly. Concede what you cannot attribute, specifically, and never fold on the core claim just to restore harmony | F2. The attribution probe is the Pressure persona's stem |
| H3 | "You pushed back on roadmap pressure once. What if I asked you to cut reliability for a hardware date?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say the quote at its scope, then answer as a view: what you would ask first, what you would hold, what you would trade. Do not describe how the earlier push was won. Hold your position through two follow-ups, then concede what you would genuinely reconsider | F2 and F5 combined, put as a live problem |

**I. Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "What would you want to change in your first ninety days across two squads?" | CASE | [generic] | Say what you would need to know first and from whom, then at most two changes and what would make you wait. The pack supplies no content for them | F1. A VP tests altitude and humility together |
| I2 | "How would you decide what the squads stop doing?" | CASE | [generic] | Criteria in your own words, who you would consult, and how you would tell the people affected | F2, delivery at the VP's altitude |

### Reverse questions for Round 3

| # | Question | Why it lands |
|---|---|---|
| 3.1 | "What do you look for in the managers you hire?" | It answers G1 from the VP's side |
| 3.2 | "What is a decision from the last year that reflects the company's values for you?" | It moves a values conversation onto a real decision |
| 3.3 | "What does a manager new to this scope most often get wrong?" | It signals self-awareness about the F1 gap |
| 3.4 | "Where does device management sit in engineering's priorities this year?" | It tests your grasp of the company without claiming one you do not have |
| 3.5 | "How do you want your managers to disagree with you?" | It rehearses the hold-then-concede line from H1 and H2 as a partnership |

## Prohibited claims (shared)

Not coached anywhere in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F5 | The plain acknowledgment: "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F5 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then a learning plan, never a past |
| Cut on-call burden by 60% | Inflated form of F2 | F2's quote at its own scope: the burden dropped after you pushed the quarter through. The pack's observation: the material says "after", not what produced the drop |
| Owned delivery across two squads | Inflated form of F1 | F1's quote at its own scope. The pack's observation: the material says a team of six, not two squads |
| Decided who got hired | Inflated form of F3 | F3's quote at its own scope: you run the loop. The pack's observation: the material does not say who decided offers |

## Sources

Provided documents: the role description and your message (your own sentences, the schedule and the recruiter's one-line description of Round 3).

Queries sent:

- `Larkfield Systems industrial IoT values` — refused
- `Larkfield Systems interview process engineering manager` — refused
- `Larkfield Systems industrial IoT device management strategy news` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The search was refused. It would have moved the values cheat sheet (omitted) and VAL themes for Round 3 |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The search was refused. It would have moved persona weights for the three rounds; they rest on the relationship priors and on your own account of each round |
| 3. `Larkfield Systems strategy` / recent news | unavailable | The search was refused. It would have moved a company-strategy CO question; none is written, and the CASE questions are `[generic]` |
| 4. `interviewer name Larkfield Systems` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative Engineering Manager JD | skipped | The role description you supplied fixes the requirement quotes in F1 to F6 |

Larkfield-specific facts are nowhere in this pack: no values, loop details or strategy. The role description's company details ("industrial IoT, ~600 people") are yours.

## Upgrade menu

- The full job description text → F1 to F6 quote the real posting instead of a one-paragraph summary, and the JD-tagged questions are re-checked against its mid-list items
- Your CV → evidence cells quote it directly, and more rows leave the answer-slot form
- Larkfield's published values and the loop as the recruiter describes it (one email) → a values cheat sheet for Round 3 and VAL questions on named values
- What the recruiter said about the panel's focus, and any announced deliverable → coverage of a graded deliverable, or sharper persona weights for Round 2
- Each interviewer's name and role → an interviewer read, tuned persona weights and a reverse question tied to their path
- Your answers to the slots in F1, F2, F4, F6 and the slots in A2, A4, E1, E2, F1, G1 and G4 → those rows become story-mapped on your own words
- Whether you have worked alongside hardware teams in any capacity → F5 and A1 move from a plain limit to a bridge
- Your reason for the move → A3 and C1 move from a scaffold to your own arc
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes; needs search permission, which was refused) → a company strategy brief for the CO and CASE questions
- A `tuesday-dossier.md` from a prior session → verified evidence and constraints already graded, if you have one
