Your prep pack is saved as `larkfield-systems_engineering-manager_interview_pack.md`. It covers all three rounds. I built it from your role summary and the four sentences you gave about yourself. Web search was refused in this session, so nothing about Larkfield's values or strategy is researched. The company-level questions (M1–M3) are labelled generic, and there is no values cheat sheet for Monday.

The pack has one shared fit snapshot, then a mini-pack per round with its own persona weights, question bank and reverse questions. The highest-ROI prep is **B1**, the hardware-roadmap objection. Your own sentence supplies the plain acknowledgment ("I haven't owned a hardware-adjacent roadmap"), and the guidance pairs it with a ramp plan. Rounds 2 and 3 come back to it in other packaging (E1, L1).

Say the word and I'll play the Skeptic on B1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste the full JD and your CV, or just its key bullets? I'll proceed without them, but they would move several `[generic]` and `[inferred]` rows to `[grounded]`.
2. Has the recruiter said anything about focus areas or a pre-declared deliverable for any round? A deliverable would get its own build section.
3. On Thursday's panel, would either staff engineer work directly alongside the squads you'd lead? The answer reweights Round 2.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems

**Candidate:** Yusuf
**Mode:** loop, three scheduled rounds sharing one fit snapshot, with a mini-pack per round
**Rounds:**

| Round | When | Who (your words) | Relationship |
|---|---|---|---|
| 1 | Tuesday, 45 min | Director of Engineering, the hiring manager | Would-be boss |
| 2 | The Thursday after, 60 min | Two staff engineers and a product manager | Panel |
| 3 | The following Monday, 30 min | VP Engineering, described by the recruiter as "values and leadership philosophy" | Skip-level or executive |

Interviewer names: none given. This pack was built from your role summary and four sentences about yourself. It has no JD text, no CV and no web research.

## How to use this pack

- **Personas** describe how a question arrives: who is asking and in what style. **Types** describe what is being scored.
- Type key: **VAL** is behavioral or values alignment. **EXP** is a work-experience deep-dive. **JD** is a role-driven question. **CO** is company and strategy knowledge. **CASE** is a live problem.
- Guidance is scaffolding, not a script. An **answer slot** is an instruction for the interview, not a question for you now. It has two honest branches, and either one meets it.
- Provenance labels: `[grounded]` means traceable to what you gave me, and the quote sits beside it. `[inferred]` means derived, with the derivation named. `[generic]` means a role-family pattern with no claim about you or Larkfield. Where the guidance rests on your words, the quote is in the Provenance cell.
- The highest-ROI prep across all three rounds is **B1**, the hardware-roadmap objection. It will be asked in some form, and Rounds 2 and 3 return to it in collegial and pressured packaging (E1, L1).

## Fit snapshot (shared by all three rounds)

Requirements are quoted from the role description you gave me, so they are your summary and not the posting. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description you gave | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says a team lead of six, at a payments company. It does not show two squads or device-management work, and the words stay at that scope: "For three of my nine years in engineering I've been a team lead of six." Answer slot: a probe on what changes between one team and two is likely. If you have seen what changes, say what, in your own words. If you have not, or the question does not match your experience, say so plainly and stay with the team of six |
| F2 | "own delivery, hiring and growth for 11 engineers" (the delivery part) — role description you gave | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The sentence carries a reliability quarter you pushed through and an on-call drop after it, at the scope of your team. It does not show owning delivery for eleven people. Words: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Answer slot: the delivery line makes a probe on what the roadmap pressure was and what was traded off likely. If you traded something off, say what, in your own words. If nothing was, or it was not yours to trade, say so plainly and stay with the reliability quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" (the hiring part) — role description you gave | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | transferability | The sentence says you run the loop and gives a count. It does not show who made hire decisions, and it does not say whether the 40 are interviews you gave or interviews the loop held. Words: "I run our hiring loop for backend roles — about 40 interviews last year." Answer slot: if you designed the loop or made the hire call, say which and how you decided. If you ran interviews inside a loop someone else designed, or the call was shared or not yours, say so plainly and stay with the loop you run |
| F4 | "own delivery, hiring and growth for 11 engineers" (the growth part) — role description you gave | none given | none | [grounded] | discovery | Your material says nothing about developing engineers, so there are no words for you yet. Answer slot: a probe on how you have grown an engineer is likely. If you have, say in outline what you did and what changed, in your own words, with no name needed. If you have not, or it was not yours, say so plainly and say how you would start with eleven engineers |
| F5 | "partner with hardware and product on roadmap" (the hardware part) — role description you gave | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | discovery | Your sentence is a stated negative about owning, and the role says partner. Words you may say, from your own sentence: "I haven't owned a hardware-adjacent roadmap." The material does not show whether you have worked alongside a hardware team in any other way. Answer slot: if you have worked with a hardware team on timing or dependencies, say how and what part was yours, in your own words. If you have not, or it was not yours, say so plainly and say how you would learn it |
| F6 | "partner with hardware and product on roadmap" (the product part) — role description you gave | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | Derived from the phrase "roadmap pressure", which does not say who it came from, so this is a lead and not a story. Answer slot: if the pressure came from product and you worked it through with them, say how, in your own words. If it did not, or someone else handled it, say so plainly and stay with the quarter |

No row is a gate: nothing you gave me states a location, travel, pay or schedule term.

### Requirement coverage

| Requirement | Fit row | Covered by |
|---|---|---|
| Lead two squads building device-management services | F1 | A2, A4, B3, M2 |
| Own delivery | F2 | A1, C1, C2, G2, G3, K2, L2 |
| Own hiring | F3 | E3, G1 |
| Own growth | F4 | K1, X5 |
| Partner with hardware on the roadmap | F5 | A3, B1, B2, E1, L1 |
| Partner with product on the roadmap | F6 | A1, H2, J2 |
| Context: industrial IoT, about 600 people | none | D2, M1, M3 |

---

# Round 1: Tuesday, hiring manager (Director of Engineering, 45 min)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems from the real roadmap: two squads, device services, hardware dates | high. The hiring-manager prior is Case/Strategist plus Skeptic. This person is your would-be boss, so they are pricing how you think on their roadmap | Clarify, objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| B. Skeptic | Quiet, persistent probing of the gaps and the why-now | high. Same prior. F5 and the scale jump from F1 are where it will aim | Rehearse the one predictable objection until it is boring. State the limit first, then a ramp plan said as a plan and never as a past |
| C. Data-Driven Prober | Line-by-line reading of the quantified claims | medium. My judgment, not a prior: two of your sentences carry figures | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know |
| D. Conversational | Chatty opener, casual questions that are still scored | low. Every interview opens this way, but this round is not a rapport round | A 90-second arc for the biography question. Treat casual questions as scored |

### Bank A: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Product and hardware both want the next quarter of your squads' capacity, for different things. What do you need to know first, and how do you decide?" | CASE | [generic] | Clarify before you structure: what each request is for, what slips if it waits, and who can say. Then objective, how you split the options, approach, how you tell each side, the metric you watch, the risk. Think aloud and challenge one premise respectfully, such as whether it is a choice between the two at all. The question asks about no past of yours, so the guidance makes none | F2 and F6 are the requirements this tests live. CASE because the hiring-manager row expects live problems on the actual roadmap. `[generic]` because it is a pattern for the problem, not a fact about this employer |
| A2 | "A set of devices in the field stops checking in after an update, and your squads own the service they report to. What do you do in the first hour, and what do you change afterwards?" | CASE | [generic] | Clarify first: how many devices, since when, what changed, what is known and what is not. Then contain, tell hardware and product, find the cause, and say what you would change afterwards so it does not recur. Name one premise you would challenge, such as whether the service or the update is at fault. No claim about your past is needed | F1's device-management requirement as a live problem. CASE because the interviewer is scoring structure, not the right answer |
| A3 | "Hardware's release dates are fixed and your services have to be ready for them. Where is the seam between you and hardware, and what happens when you disagree?" | JD | [generic] | Offer seam principles rather than a map you have not seen: what each side commits to, how dates and dependencies are shared, who decides when they conflict and how that is recorded. Ask what hardware needs from you first, and say what you would offer in return. Your own experience with hardware is B1's slot, not this one's | F5 is the requirement under test. JD content with CASE delivery, so it is tagged JD |
| A4 | "What would your first ninety days look like with two squads and eleven engineers?" | JD | [generic] | A plan in the future tense: who you meet and what you ask first, what you read and measure before changing anything, how you get to know each engineer and the hardware and product partners, and what you commit to by day ninety. Keep every clause one you would actually do. The guidance makes no claim about your past | F1 and F4 are what a manager of two squads is expected to have a plan for. A plan is a legitimate answer where the material shows no experience |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't owned a hardware-adjacent roadmap, and this role partners with hardware on the roadmap. What worries you about that on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | **The highest-ROI rehearsal in this pack.** State the limit first, in words your own sentence supports: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past: whom you sit with first and what you ask. Hold through two follow-ups by returning to the limit and the plan, never by adding experience. Answer slot: if you have worked with a hardware team on timing or dependencies, say how and what part was yours, in your own words. If you have not, or it was not yours, say so plainly and stay with the plan. The honest branch is a limit, not a confession | F5 is the stated gap the role presses on hardest, so this objection will arrive in some form. JD because it scores a stated requirement, Skeptic because of the delivery |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers and never owned a hardware-adjacent roadmap" | Pick one gap and say it in a sentence, keeping to what your own sentences state: you have not owned a hardware-adjacent roadmap, and your team was six where the role has eleven. Then say what you would do in the first month. Naming the one the role presses on hardest is the answer, and a list of three reads as a hedge | F1 and F5 are the two gaps the material shows. The Skeptic stem asks for the candidate's own honest self-assessment |
| B3 | "You've led a team of six. Why are you ready for two squads and eleven engineers?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Story-mapped on F1. The beats the sentence states are nine years in engineering, three of them as a team lead, a team of six. Tell them in your own words and do not enlarge them. Answer slot: the jump is in size and in shape, so a probe on what changes is likely. If you have seen what changes between a team of six and a larger group, say what, in your own words. If you have not, say so plainly and say what you would watch for in the first month. Hold the number at six | F1 is the evidence for the scale requirement and the likeliest place to be pressed. EXP because it tests what you actually did |
| B4 | "Why leave a payments company for industrial IoT, and why now?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Give your actual reasons in your own words. This pack has none from you and supplies none. If you have one reason for leaving and a different one for choosing this company, say each. If one is thin, say so and do not pad it. Answer slot: if the move toward devices and hardware is part of the draw, say so in your own words. If it is not, do not add it | F1 gives only the current employer. The Skeptic stem is why leave, why here, why now. EXP because it tests motive consistency |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your team's on-call burden dropped 60%. Walk me through how that number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Start from the sentence exactly: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Answer slots, each in your own words: how the 60% was counted, what it is sensitive to, the assumption behind it you would defend least, and which part of it was yours. If you do not know how it was counted, say so plainly. Name the weakest assumption before they do | F2's headline figure, and quantified claims are what probers go to first |
| C2 | "How much of the reliability quarter was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold the sentence's verb: you pushed the quarter through against roadmap pressure. Answer slot: if you also did hands-on work in the quarter, say which, in your own words. If others did it, say whose and keep your part to the push. If the decision was shared, say that plainly. Do not upgrade "pushed through" into a bigger verb | F2 is where attribution gets probed. EXP because it tests what was yours |

### Bank D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc from the sentence: nine years in engineering, three of them as a team lead of six, now at a payments company. The sentence stops there, so add earlier roles and choices only where you can speak to them. Answer slot: end with why this role, in your own words. If the why is not clear yet, say what you are curious about and do not invent one | F1 is all the biography the material carries. The chat is scored even when it feels casual |
| D2 | "What are you actually playing with in device management these days?" | JD | [generic] | Answer slot: if you have done anything in this space, such as reading, a side project or a conversation with someone who works on it, say what, in your own words. If you have not, say so plainly and say what you would start with. Treat the casual register as scored and do not claim familiarity you lack | F1's device-management requirement in casual form. This is the Conversational stem applied to the role's core domain |

### Reverse questions for Round 1

| # | Question | Why it lands |
|---|---|---|
| X1 | "What does success look like for the two squads at ninety days and at twelve months, and where would you expect me to need the most help?" | It shows you plan and concedes where you will lean on them, which answers the day-one probe before it is asked |
| X2 | "How do hardware and software commitments get reconciled today, and where does it break?" | It turns your biggest gap into curiosity about the real mechanism |
| X3 | "What is the biggest delivery risk across the squads right now?" | It signals you are thinking about owning delivery from the first day |
| X4 | "What do you want from the managers who report to you that you rarely get?" | It is a partnership question to your would-be boss and turns an interrogation into a working conversation |
| X5 | "How are growth and promotion handled for these engineers today, and where do you want it to be?" | It covers F4, where your material is silent, by asking rather than claiming |

---

# Round 2: Thursday, panel (two staff engineers and a product manager, 60 min)

### Persona table

The persona weights blend each member's relationship prior. I assumed the staff engineers read as peer-like and technical, and the product manager as cross-functional. If the staff engineers would sit on your squads, tell me and I will reweight.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| E. Peer Evaluator | Seam-splitting, "what would you need from me", credit and disagreement scenarios | high. Staff engineers fall under the peer row, and they are pricing whether you reduce or add to their load | Reciprocity: what you bring them, not only what you need. Propose seam principles and do not pretend to know the seam |
| G. Data-Driven Prober | Technical depth, figures, how things were counted | high. The peer row pairs the Peer Evaluator with the Prober, and your sentences carry two figures | Know what you can and cannot say about how each figure was counted. Name the weakest assumption before they do |
| H. Values/Behavioral | Scenario probes, story-shaped answers | medium. The product manager sits on the cross-functional row, and the recruiter calls Monday the values round, so this is a warm-up for it | "We" for context, "I" for contribution. Use one story where your quoted material carries one, and a scaffold ending in its honest branch where none does |
| J. Conversational | Opening biography and warm, loosely framed questions | medium. A panel usually opens with introductions, and this is the cross-functional row's second persona | Trim the Round 1 arc to about 60 seconds. Treat the casual questions as scored |

### Bank E: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where is the seam between a manager and the staff engineers on a squad, and what happens when we disagree?" | JD | [generic] | Offer seam principles and not a map you have not seen: who decides technical direction, who decides priorities, how a disagreement gets surfaced and settled. Say what you would ask them first, and what you would take off their plate and what you would need from them. A past disagreement story is not needed here and the guidance claims none | F5's partnership requirement in collegial packaging, and F1's two-squad shape. JD content, Peer delivery |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams and credit had to be shared. It needs who else was involved, what part was yours, and how credit was named. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Peer stem on credit-sharing. VAL because it scores behavior. `[generic]` because nothing in your material carries this story |
| E3 | "You would be interviewing alongside us. How do you run a loop, and what happens when you and a staff engineer disagree on a candidate?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Story-mapped on F3. The beats the sentence states are that you run the hiring loop for backend roles and that it came to about 40 interviews last year. Tell them as the sentence tells them. Answer slot: the role's hiring line makes a probe on who decides likely. If you designed the loop or made the hire call, say which and how you decided, in your own words. If you ran interviews inside a loop someone else designed, or the call was shared or not yours, say so plainly and stay with the loop you run. On the disagreement: say how you would handle it as a principle. If a real disagreement with an interviewer comes to mind, say what it was and how it ended. If none does, say so | F3 is your strongest row for hiring and the one the staff engineers share. JD because it scores the hiring requirement |

### Bank G: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "You mention about 40 interviews last year. How was that number counted?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Start from the sentence: "I run our hiring loop for backend roles — about 40 interviews last year." Answer slots, each in your own words: how the 40 was counted, whether it is interviews you gave or interviews the loop held, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know, say so plainly | F3's headline figure. A defend-the-number question for every quantified claim |
| G2 | "A team lead tells you their service is flaky and asks for a quarter to fix it that nobody asked for. Do you back it, and how do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure: what evidence they have, the cost of not doing it, the smallest scope that tests the claim, who must agree and what you would trade. Hold your position through two pushbacks and concede what you do not know. If you use your own story, tell it only at the sentence's scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Answer slot: the delivery line makes a probe on what was traded off likely. If you traded something off, say what, in your own words. If nothing was, or it was not yours to trade, say so plainly | F2 as a live problem. CASE because it asks for a decision, with your story available as an optional anchor |
| G3 | "How would you tell whether two squads are delivering well, without turning it into counting tickets?" | JD | [generic] | A principled answer: what outcomes you would want to see, how you would read them with the squads and not only about them, what would make you intervene. Present it as how you would approach it, not as something you have done. Ask what the squads already track before proposing anything new | F2's delivery requirement. The Prober asks for the measure behind the claim |

### Bank H: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on F2. The beats the sentence states are a reliability quarter, roadmap pressure, you pushing it through, and the on-call burden dropping 60% after. Tell those in your own words. Answer slot: an interviewer will ask who the pressure came from and what you said. If you made the case to someone, say who and what you said. If the push was made another way, or was not a conversation with leadership, say so plainly and tell the story as the sentence tells it | The Values stem on unpopular truths. F2 is the only quoted pushback story, so this and K2 share it |
| H2 | "Product asks you to commit to a date your squads do not believe. What do you do?" | CASE | [generic] | Clarify what is driving the date and what is known. Offer options on scope, sequence or confidence ranges. Say who needs to hear what and when, and what you would refuse to promise. Add what you would ask product to do in return. No claim about your past is made | F6's product partnership as a live problem. The product manager is the likeliest to ask it |

### Bank J: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Tell us a bit about yourself and what drew you to this team." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Use D1's arc trimmed to 60 seconds: nine years in engineering, three of them as a team lead of six, now at a payments company. Answer slot: end on what drew you to this team, in your own words. If the draw is not yet clear, say what you are curious about | F1 again, for three listeners. Panels usually open with introductions, and this one is scored |
| J2 | "How would you want to work with product on the roadmap?" | JD | [generic] | Offer working principles and reciprocity: what you would bring product, and what you would ask from them. Answer slot: the role's product-partnership line makes a probe on how you have done this likely. If you have worked with product on a roadmap, say how and what part was yours, in your own words. If you have not, or it was not yours, say so plainly and say how you would start | F6 in a friendly register. The Conversational stem applied to a JD line |

### Reverse questions for Round 2

| # | Question | Why it lands |
|---|---|---|
| Y1 | "What could a new manager do in their first month that would genuinely help you?" | It is the reciprocity question for the staff engineers and shows you are thinking about their load |
| Y2 | "Which part of the device-management stack would you most like better partnership on?" | It invites a concrete answer and shows you want the seam before you are in it |
| Y3 | "Where do engineering and product disagree most, and how has it been resolved?" | It is for the product manager and probes the same seam from the other side |
| Y4 | "What do you want from a manager that you have not had?" | It makes the staff engineers describe your job in their own words |
| Y5 | "How does a hiring decision get made here, and where would you want more say?" | It ties to F3 and tests whether your loop experience maps to theirs |

---

# Round 3: Monday, VP Engineering (30 min)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| K. Values/Behavioral | Scenario probes and a leadership-philosophy question | high. The recruiter's own words raise it: "values and leadership philosophy" | Map a story to each point where your quoted material carries one, and give a scaffold ending in the honest branch where it does not. "We" for context, "I" for contribution |
| L. Pressure | Time-boxed answers, devil's advocate, challenge to motive and attribution | medium. The skip-level row prior pairs Case/Strategist with Pressure. Thirty minutes forces time-boxing | Pause, restate the question, anchor on what you actually said, hold through two follow-ups before conceding anything real |
| M. Case/Strategist | Altitude questions about the business and the strategy | medium. The same prior. The strategy content in this bank is generic, because research did not run | Clarify, structure, think aloud. Ask good questions where you cannot recite strategy |

Thirty minutes covers perhaps five or six of these. Rehearse K and L first.

### Bank K: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "What is your philosophy for growing engineers?" | JD | [generic] | Selection scaffold: pick an engineer whose growth you can tell, in outline. It needs where they started, what you did that was yours, and where they ended. If no such person comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it | F4, where the material is silent. The role's growth line raises it, and the recruiter's "leadership philosophy" suggests the VP will go here |
| K2 | "What do you do when the roadmap and the team's health pull in different directions?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on F2, with the emphasis changed from H1: the quarter you pushed through, the pressure you pushed against, the on-call drop that followed. Say what you did in the sentence's verb and let the VP draw the inference. Answer slot: if you gave something up or traded something for the quarter, say what, in your own words. If nothing was traded, say so plainly. One quoted story carries both H1 and K2, so rehearse two cuts of it | The leadership-philosophy question asked as a dilemma. More stories would let this stand apart from H1 |
| K3 | "How would you describe your leadership philosophy in a couple of sentences?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer slot: state your own principle in your own words, then test each clause: can you name one instance behind it that you could tell. Keep the clauses you can attach to your material, which are the team of six, the hiring loop and the reliability quarter, and drop the rest. Do not use values language you cannot back with an instance | The recruiter's words raise this directly. It is where a polished line gets tested by the next follow-up |
| K4 | "Why management, and why now?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Answer slot: give your actual reasons in your own words. This pack has none from you and supplies none. The beats the sentence carries are three of nine years as a team lead of six. If you have a reason you could not say aloud with a straight face, leave it out | F1 and the motive-consistency probe, asked at VP altitude |

### Bank L: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Sixty seconds: why you over someone who has already owned a hardware-adjacent roadmap?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year"; "I've never managed managers and never owned a hardware-adjacent roadmap"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold, then concede. Pause, restate the question, and hold what your own sentences carry: three of nine years as a team lead of six, running the hiring loop for backend roles, and the reliability quarter you pushed through against roadmap pressure. Hold through two follow-ups. Then concede specifically: "I haven't owned a hardware-adjacent roadmap." Do not fold on the three held items to restore harmony, and do not add to them. Answer slot: if there is another strength you can back with something you did, say it in your own words. If there is not, stop at the three | F5 under pressure, which is B1's objection in its sharpest packaging |
| L2 | "That 60%. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold the sentence's verb: you pushed the quarter through. Concede specifically and only what is true: if others did the work, say whose, and if you do not know how the number was counted, say so. Do not fold on the push itself to restore harmony. Answer slot: which part was yours, in your own words | The Pressure stem on attribution. It is C2 with the composure test added |
| L3 | "You haven't managed managers. Is that a limit for this role?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | A plain acknowledgment from your own sentence: "I haven't managed managers." Your material does not say whether the role involves managing managers, so assume neither way. Answer slot: if you know the role's reporting shape, say how you would work within it. If you do not, say so plainly and say what you would ask. Hold the limit and do not pad it | The negative is yours and sourced, so it can be asked as stated. The role description gives no manager layer, so the honest answer is a question |

### Bank M: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M1 | "We are about 600 people building industrial IoT. What would make a device-management platform win or lose with industrial customers?" | CO | [generic] | Clarify first: which customers, what scale of fleet, who buys and who operates. Then structure what you would look at and why. Larkfield-specific strategy is not in this pack, so keep to structure and questions and do not recite company facts you have not read. Challenge one premise respectfully | The role description gives the context. CO because it scores altitude. `[generic]` because research did not run, which is the honest cost |
| M2 | "Both your squads are late and one customer launch cannot move. How do you allocate your attention?" | CASE | [generic] | Clarify what is late and why, what the launch actually needs, and who is waiting on what. Then say where you would put your attention first and what you would tell each squad and the customer. Add what you would stop doing. No claim about your past is made | F1's two-squad shape at executive altitude |
| M3 | "What would you want to know about our strategy before deciding whether you can help?" | CO | [generic] | Ask rather than recite. Prepare four or five questions on what the company is trying to win, where hardware dates constrain software, and what the engineering organisation is being asked to deliver this year. If you have found something real before the call, say what you read. If you have not, say so plainly | The honest form of a CO question when research did not run. It converts a gap into a signal |

### Reverse questions for Round 3

| # | Question | Why it lands |
|---|---|---|
| Z1 | "What are you most worried about for engineering in the next year that I could help with?" | It talks to the VP's agenda and shows you are thinking about their problem, not yours |
| Z2 | "How do you think about the balance between hardware-driven dates and software quality?" | It reaches your F5 gap by asking the person who owns the trade-off |
| Z3 | "What is a leadership behaviour you have seen here that you would want more of?" | It makes the VP point at their own culture, which a values round wants |
| Z4 | "Which of the company's values show up in decisions, not only on the wall?" | It treats values as practice, which suits a values and leadership round |
| Z5 | "What would you want me to have learned by day ninety?" | It makes the VP set the bar you will then prepare against |

---

## Prohibited claims

What this pack will not coach, with the basis and the honest form. Built from the snapshot before the banks.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative the candidate stated, F5 | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message. The plain acknowledgment: "I haven't managed managers." L3 uses it |
| Has owned a hardware-adjacent roadmap | Negative the candidate stated, F5 | The same sentence. The plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." B1 and L1 use it, and B1's slot asks only about working with hardware, not owning |
| Led or managed two squads or eleven engineers | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a team lead of six |
| Owned delivery for a group | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material shows a reliability quarter on your team |
| Owned hiring for the team or made the hire decisions | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says the loop and an interview count |
| Cut on-call burden by 60%, or the reliability quarter caused the drop | Inflated form of F2 | F2's quote at its own scope: the burden dropped after the quarter. The limit is the pack's observation: your material gives the sequence and not the cause. C1's slots ask only how it was counted |
| Line-managed six engineers, with reviews, promotions or pay | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says team lead and not reporting line |

---

## Sources

**Provided documents:** your message, which gave the role summary, the three-round schedule and four sentences about yourself. No dossier, JD text, CV or interviewer profile was present.

**Searches sent (each returned nothing, because the host refused them):**

- `Larkfield Systems industrial IoT company values` — refused
- `Larkfield Systems industrial IoT device management strategy news` — refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Both calls were refused. It would have fed a values cheat sheet for Round 3 and tied the K bank to published value names |
| 2. `Larkfield Systems interview process engineering manager` | skipped | Your schedule names three sessions, who runs each and what each holds, which fixes the loop and the persona weights |
| 3. `Larkfield Systems strategy` / recent news | unavailable | The call was refused. It would have grounded M1 to M3 and added current-strategy material to Round 1's cases |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer names were given, so no query could be formed. The interviewer read is absent |
| 5. representative `Engineering Manager` JD | skipped | The role description you gave fixes the fit snapshot rows and the JD-tagged questions |

A values-style round is detected from the recruiter's own words for Monday. Published values are not in hand, so the values cheat sheet is not in this pack.

## Upgrade menu

- Full JD text → the requirement rows quote the posting instead of your summary, mid-list requirements your summary may have dropped get rows and questions, and the coverage table is rechecked
- CV text or its bullets → more quoted evidence, so F1 to F4 and F6 can move toward presentation or none, and Round 2 and 3 get more than the one pushback story that H1 and K2 share
- Your own answers to the answer slots in F1 to F6, written outside a drill → those rows and the questions that draw on them regenerate from your words
- Larkfield's published values page, pasted → a values cheat sheet for Monday with each value mapped to a story or a scaffold, and the K bank tied to the values by name
- A pasted strategy brief or permission to search → M1 to M3 and Round 1's cases become grounded, and a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a grounding brief
- Interviewer names for any round → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- The recruiter's guidance for each round, including any pre-declared deliverable → the persona weights are rebased, and any assignment gets its own build section
- Whether either staff engineer would sit on or work directly alongside your squads → Round 2's persona weights are recomputed
- The role's terms: location, travel, pay and schedule → gate rows in the fit snapshot
- Your prep time → a prioritized schedule across the three rounds
- A `tuesday-dossier.md` from an earlier fit review → verified evidence and prohibited-claims constraints, which this pack stands without
