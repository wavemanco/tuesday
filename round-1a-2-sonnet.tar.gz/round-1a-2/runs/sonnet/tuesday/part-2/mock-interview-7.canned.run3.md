Running the L1 research now: four searches on Saltmarsh Games (values, interview process, strategy, Tobias Wrenfield). Then I'll build the pack.
Your prep pack is saved as /var/tmp/tuesday-measure/1a2/runs/sonnet/tuesday/part-2/rooms/case-7-canned-752064e6/saltmarsh-games_live-operations-producer_interview_pack.md. I built it for Saltmarsh's "Outage Hour", which its careers page describes as one 60-minute hiring-manager interview. That interview is a live-incident tabletop followed by a values conversation, and it matches the format you described. The Project Larkspur news item and Tobias's GDC talk were read from search summaries only, not the full pages.

Say the word and I'll play the Skeptic on C1, the question the pack names as your highest-ROI prep (no in-app purchases, no team led).
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations (hiring manager). Candidate: Femi. Session mode, one 60-minute conversation, built as the Saltmarsh "Outage Hour" (a tabletop on a simulated live-event outage, then a values conversation) because the careers page describes a single 60-minute hiring-manager interview in that shape.

## How to use this pack

Personas describe how a question arrives (who is asking, in what style). Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

An answer slot is an instruction for the interview. It names what an interviewer is likely to probe, then gives two honest branches: if you did it, say how; if you did not, or it was not yours, say so plainly and return to what your material does carry. Either branch is a good answer. Neither needs a reply to me.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows Saltmarsh's published values, not generic virtue |
| EXP | Work-experience deep-dive | Whether your résumé claims survive scrutiny, and what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth and thinking at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a live problem from the role |

## Fit snapshot

Your evidence column holds your own words only. The JD is the interviewer's scoring sheet; the bridge column says what you can safely say and where an answer slot sits.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, with nothing inspected behind it, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-titles line makes a probe on running more than one calendar likely. If you ever ran or shared a calendar across more than one title, say how and which part was yours, in your own words; if not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which teams you worked with on a drop. Answer slot: expect a probe on each of the four disciplines. If you coordinated any of them on a drop, name which and what you did, in your own words; if you did not, or it was not yours, say so plainly |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | low | [inferred] | discovery | Presenting monthly retention numbers is not owning a post-event review, and the bridge should not be stretched. Answer slot: if any of those presentations looked back at a specific release or event, say what was reviewed and who read it; if none did, or the numbers were prepared by someone else, say so plainly, then say what you would review first after an event, as a plan and never as a past |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap in terms, but a résumé-style line with nothing inspected behind it, so expect a probe on it. Lead in the quote's own terms: you wrote it, and your QA team still uses it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | The years and the title are stated: four years, associate producer. Your material does not say whether the title was live-service or for how long. Answer slot: expect a probe on the live-service part. If the game was live-service, say what made it so, in your own words; if it was not, say so plainly and stay with the years and the role you stated |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap in terms, but nothing inspected behind it. Lead in the quote's own terms: weekly cadence, your main title, the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms: you presented the monthly retention numbers to the studio head. Say it that way, with the audience and the cadence, and add nothing about how the numbers were produced |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms: a written document your QA team still uses. Say that, in those words. Your material shows no other writing, which is the pack's observation and not words for you |

## Reading the interviewer

Public professional footprint only. The talk and its summary were read from a search result, not the full page.

| Observation | Source | What it means for you |
|---|---|---|
| Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio | GDC 2026 talk listing, search result | A release checklist and QA partnership will be familiar ground for him; expect F4 to be probed closely |
| Talk titled "Patch Notes Are a Promise"; his argument is that a live team is judged by how often its patch notes describe what actually shipped | GDC 2026 talk listing, search result | Expect attention to whether what you say matches what happened. Keep every claim at the scope of your own sentences |
| His argument sits beside the published value "Ship the Patch Not the Promise" | Talk listing and the values page | The values conversation will likely press on announcing only what is built. Do not recite the value; show it by being exact about what you did |
| Mirror opportunity: shared vocabulary on release checklists. His public path runs through QA; your side is "Wrote the release checklist our QA team still uses" (F4) | Talk listing; F4 | Name the checklist plainly when QA comes up. Nothing about shared identity or background is a strategy here, and none is offered |

## Persona weights

Three passes, shown so you can recalibrate. Relationship prior: a hiring manager brings Case/Strategist and Skeptic. The loop: the careers page names one 60-minute hiring-manager interview, a live-incident tabletop and then a values conversation, so Case rises and Values/Behavioral is guaranteed in this session. Interviewer signals: a QA-lead path and a talk about shipped versus promised raise precision probes, so the Prober is kept at mid weight.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | The tabletop on a simulated outage during a live event; plan-this and diagnose-that problems | Highest. The careers page makes the tabletop the first half of the hour; hiring-manager prior agrees. Five questions | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Values/Behavioral | The second half of the hour, mapped to the three published values | High. A values conversation is documented in the loop. Three questions, one per value | Map a story where one of your quoted sentences carries one; where none does, pick by criteria and keep the honest branch |
| C. Skeptic | Persistent probing of the gaps: no team led, no in-app purchases, one calendar against two titles | Mid-high. Hiring-manager prior, and you stated two of the gaps yourself. Three questions | Rehearse the single most predictable objection until it is boring; plain acknowledgment plus a ramp plan |
| D. Data-Driven Prober | Line-by-line questions on the retention numbers and the checklist | Mid. The JD names retention metrics and the checklist, and his public argument is about claims matching what shipped. Three questions | Know what you can and cannot say about how each number was counted; say plainly when you do not know |
| E. Pressure | Time-boxed challenges inside the tabletop; attribution probes | Low-mid. Incident simulations commonly add time pressure, a pattern and not a Saltmarsh fact. Two questions | Pause, restate, hold through two follow-ups, concede specifically |
| F. Conversational | The opening biography and a casual question about live-ops | Low-mid. Typical opener, and still scored. Two questions | A 90-second arc built only from your quoted sentences |
| Peer Evaluator | Not used | No peer interviewer is named, and the loop is hiring-manager only. No questions | Not applicable |

## Question banks

Highest-ROI prep in this pack: **C1**, the objection about no in-app purchases and no team led. It will be asked in some form. Rehearse it until the plain acknowledgments feel boring.

### A. Case/Strategist (five questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event is two days in and the reward isn't granting for a subset of players. You have ten minutes. What do you do?" | CASE, JD | [inferred] | Clarify first: who is affected, since when, what is confirmed and what is not. Then the objective for the next ten minutes, who you pull in from the four disciplines the JD lists, what players are told and when, what you would record for the post-event review. Think aloud and challenge one premise. Answer slot: the JD's coordinate-four-teams line makes a probe on your own coordination likely. If you coordinated any of those teams on a drop, say which and what you did, in your own words; if you did not, or it was not yours, say so plainly | The careers page makes a live-incident tabletop the first half of the hour; the scenario is a typical shape, derived and not Saltmarsh's own. CASE for structure; JD because F2 is the row it presses |
| A2 | "Engineering says the cause isn't confirmed. Community wants a statement now. What goes out?" | CASE, VAL | [grounded] | The published value says: we announce what is built, not what is hoped. Structure it: what is known, what is not, when the next update comes, and nothing promised that is not built. Say the wording aloud in a short form. No claim about your past is needed | The values page raises it directly; the written wording is also a test of the JD's written-communication line, F8. CASE delivery, VAL content |
| A3 | "Saltmarsh is moving Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027. What do you need to know before you plan the first season's calendar?" | CO, CASE | [grounded] | Clarify before structuring: what the season pass changes for existing events, who owns the calendar across titles, what the two titles' players each expect. Then objective, segments per title, approach, metrics, risks. Challenge one premise respectfully, for example that two titles share one cadence. No claim about your past | A September 2026 news item on the Saltmarsh site; read as a search summary only, so keep your wording to what you can verify. CO because it tests current strategy, CASE for delivery |
| A4 | "Two events collide on the same weekend, one per title, and engineering can support only one. How do you decide?" | CASE, JD | [generic] | Clarify what each event depends on and what players were told. State your criteria aloud before choosing, name the choice, say how the other team hears it and what gets recorded. The value that applies: when the calendar and the players disagree, the players win. No claim about your past | The JD's two-titles line raises it; F1 is the row it presses. Generic because it is a pattern for the problem, not a fact about Saltmarsh |
| A5 | "An event ended last night and retention is down against the previous event. Show me how you'd structure the review." | CASE, JD | [generic] | Clarify what the retention figure is measuring, over what window, against which comparison. Then objective, segments, approach, what you would report and to whom. Name the assumption you would defend least before he does | The JD's post-event review line raises it; F3 and F7 are the rows. Generic because the structure is a pattern, and it makes no claim about your past |

### B. Values/Behavioral (three questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. What won?" | VAL | [grounded] | Selection scaffold: pick a time where players, through a signal and not a hunch, pointed away from a scheduled plan. It needs a named stake, what changed, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The published value Players Before Plans is the raising source. VAL because it scores past behavior against a named value |
| B2 | "Tell me about a time you told people less than they hoped." | VAL | [grounded] | Selection scaffold: pick a time you held back an announcement until the thing was built, or corrected an expectation. It needs the wording you used, the reaction, and the relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The published value Ship the Patch Not the Promise is the raising source. VAL because it scores behavior against that value |
| B3 | "Tell me about a time you improved a process others depend on." | VAL, EXP | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F4: you wrote the checklist, and your QA team still uses it. Tell those two beats in your own words. Answer slot: the published value says every release leaves the checklist better than it found it, so expect a probe on whether the checklist changed after releases. If you revised it, say what and why; if it stayed as first written, or the revisions were not yours, say so plainly and stay with the checklist QA still uses | The published value Leave the Build Greener is the raising source. F4 is the evidence; VAL for the value, EXP because it tests what was actually yours |

### C. Skeptic (three questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see in-app purchases in your background, and you haven't led a team. The group is moving to a season pass. How would you handle that in this role?" | JD, EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "Presented the monthly retention numbers to the studio head" | Say the two acknowledgments first, each in one breath: "I haven't led a team." "I haven't worked on a game with in-app purchases." Then a ramp plan, said as a plan: what you would learn first about how the season pass is planned and reported, and who you would sit with. Then the nearest thing your material carries, at its own scope: "I presented the monthly retention numbers to the studio head." Stop there; do not say it covers revenue. Follow-up one is who you would ask first. Follow-up two is what happens if that team disagrees with your plan; answer with the plan again, not with a past. Never fold, never add | The objection this pack expects most: the two negatives are yours, and the season pass makes the monetization gap live (Sources). F7 holds the one adjacent sentence. JD because it presses a requirement-shaped gap; EXP because it tests what you did |
| C2 | "The JD says two titles. What part of running calendars for more than one title have you done yourself?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | The hold is only what the quote carries: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you ever ran or shared a calendar beyond your main title, say how and which part was yours; if not, say so plainly and describe how you ran the weekly calendar. Hold through two follow-ups by returning to the calendar, never by adding to it | F1 is where the two-titles line presses hardest. JD because it scores the stated requirement |
| C3 | "Why this role, why Saltmarsh, why now?" | CO, JD | [grounded] | Answer slot: give your actual reason, in your own words; there is no stand-in reason here. If you have read or watched Tobias's talk, say what you took from it; if you have not, leave it out. The published values are public, and naming the one that matters most to you is allowed only if it is true | Motivation consistency is the Skeptic's score. The talk and values are public (Sources), and the pack supplies no reason for you. CO for company homework, JD for role fit |

### D. Data-Driven Prober (three questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented to the studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | The beats are the ones the quote states: monthly, retention numbers, the studio head. Tell them in your own words. Answer slot: if you know how those numbers were counted and which assumption behind them you would defend least, say so; if you do not know how they were counted, say so plainly and say what you would check first | F7 is the evidence; the JD's retention line raises the probe. EXP because it tests what was actually yours |
| D2 | "When you look at an event's results, what do you look at first, and why?" | CASE, JD | [generic] | Structure it aloud: what the event was meant to change in player behavior, what you compare against and why, what you would distrust in the first read. Name the weakest assumption in your own approach before he does. No claim about your past | F3 and F7 are the rows. Generic because it asks for a method, not a fact about you |
| D3 | "You wrote the release checklist your QA team uses. Walk me through what's on it." | EXP, JD | [grounded] "Wrote the release checklist our QA team still uses" | The beats are the ones the quote states: you wrote it, and your QA team still uses it. Describe the items in your own words, not mine. Answer slot: the JD's manage-with-QA line makes a probe on how it is used at each release likely. If you ran it with QA at releases, say how; if QA ran it, or you handed it over, say so plainly and stay with having written it | F4 is the evidence, and the QA-lead path of the interviewer makes this a close read. EXP and JD, because it tests what was yours and the stated line |

### E. Pressure (two questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already worked on a game with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Never led a team, and never worked on a game with in-app purchases" | Pause, restate the question. Hold on what the quotes carry: "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." Then concede the gap specifically: "I haven't worked on a game with in-app purchases." Do not argue that you are better; say what you have, say what you lack, and stop | A time-boxed version of C1. JD because it presses a stated gap against a rival. F1 and F4 hold the quotes |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | The hold is only the quote: "I wrote the release checklist our QA team still uses." Answer slot: if others contributed, say who and what; if it was yours alone, say so plainly. Hold through two follow-ups by returning to the quote, and concede specifically anything others did | Attribution is the stem a pressure interviewer uses; F4 is the evidence. EXP because it tests what was actually yours |

### F. Conversational (two questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey. How did you end up in producing?" | EXP, JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc with four beats, each a clause your quotes state: four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for your main title for two years, the release checklist your QA team still uses, the monthly retention numbers to the studio head. Answer slot: why live operations is yours to say, in your own words; there is no reason supplied here | The opener is scored; F5, F6, F4 and F7 supply the beats. EXP because it tells your history; JD because it states the years |
| F2 | "Which live-service games' event calendars do you follow, and what do you notice?" | JD | [generic] | Selection scaffold: name one or two games you actually follow and one thing you have seen in how they run events. If you do not follow any, say so plainly and say what you would study first. No claim about your past work | A casual question on the hot JD topic, still scored. Generic because it asks for your own observation and the pack supplies none |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A3, A4, C2 |
| Coordinate design, art, engineering and community on each update | A1, A2, A4 |
| Own the post-event review and the KPIs it reports | A5, D2, D1 |
| Manage the release checklist with QA | D3, E2, B3 |
| 3+ years producing live-service games or apps | F1, C1 |
| Experience running a content calendar | C2, B1 |
| Comfortable with player-retention metrics | D1, D2, A5 |
| Clear written communication | A2, D3 |

## Values cheat sheet

Saltmarsh's three published values, from its values page. The Outage Hour's second half is a values conversation.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | None of your quoted sentences carries this one. Selection scaffold: pick a time players pointed away from a scheduled plan, with a named stake, what changed and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it (B1) |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | None of your quoted sentences carries this one. Selection scaffold: pick a time you told people less than they hoped, with the wording and the reaction. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it (B2) |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses". Tell the two beats the sentence states. Whether the checklist changed after releases is an answer slot (B3) |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "In your GDC talk you argued a live team is judged by how often its patch notes describe what actually shipped. How does the team check that before a release goes out?" | Ties to his own public path from QA. Use it only if you have read or watched the talk; the pack has only its summary line |
| R2 | "With the move to one shared events calendar from February 2027, what does the first season's calendar need to get right?" | Shows you read the company's own announcement and asks him for the priority, not for the plan |
| R3 | "When the calendar and the players disagree, who makes the call, and how does the team hear about it?" | Takes the published value Players Before Plans from a slogan to a decision, and shows you took the values page as a working rule |
| R4 | "What does the post-event review report today, and what would you want it to report that it doesn't?" | The JD gives the role the review and its KPIs, so this asks where the work starts |
| R5 | "How will the work split between the single live-ops group and the individual titles once per-title event teams retire?" | Follows the announcement's own wording and asks where the role sits, a question a prepared candidate raises |
| R6 | "What does a strong first ninety days look like for the person in this role?" | A standard question, kept because rapport-style interviewers weight the closing slot; it signals you are thinking about the work and not the interview |

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative you stated: "Never led a team, and never worked on a game with in-app purchases" | The plain acknowledgment: "I haven't led a team." Then a plan for coordinating the four disciplines, said as a plan and never as a past |
| Has worked on a game with in-app purchases | Negative you stated, same sentence | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Ran a live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one main title and content drops. C2's slot stays inside the calendar you ran |
| Four years producing live-service games | Inflated form of F5 | F5's quote at its own scope: four years as an associate producer at a puzzle-game studio. The limit is the pack's observation: your material does not say live-service. The Skeptic and Conversational answers stay at that scope |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says presenting the monthly retention numbers, not owning a review |

## Sources

Provided documents: the job description and your message.

| Query or fetch | Returned |
|---|---|
| Search: Saltmarsh Games values | https://saltmarshgames.com/values |
| Search: Saltmarsh Games interview process live operations producer | https://saltmarshgames.com/careers/interviewing, which also says there is no take-home, so no build section is in this pack |
| Search: Saltmarsh Games strategy mobile games news | https://saltmarshgames.com/news/project-larkspur (September 2026), read as a search summary only |
| Search: Tobias Wrenfield Saltmarsh Games Head of Live Operations | https://talks.gdconf.example/2026/patch-notes-are-a-promise, read as a search summary only |
| Fetch: https://saltmarshgames.com/values | Three values, names and one-line definitions |
| Fetch: https://saltmarshgames.com/careers/interviewing | The recruiter call and the Outage Hour, as described above |

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet; the VAL bank (B1 to B3) and A2 |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop structure; persona weights follow the tabletop and values conversation; no graded-deliverable section |
| 3. `Saltmarsh Games strategy` / recent news | yes | A3, R2 and R5; the monetization point in C1's rationale |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Reading the interviewer; R1 |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- A deeper research pass (strategy brief, the talk and his writing, loop reports, recent org context; up to 6 more searches and 2 more fetches, several more minutes) → A3 and R1 to R5 sharpened from full pages instead of search summaries
- Answers to the answer slots on F1, F2, F3 and F5 → those rows move from `discovery` or `transferability` toward `[grounded]` evidence, and the C-bank and A1 slots become stories
- The release checklist itself, or a screenshot of the weekly calendar, with names removed → F4, F6 and F1 can rise from `medium` toward `high`
- The retention deck or one slide of it → F7 and D1, and what the numbers actually counted
- The recruiter's prep email → what the tabletop is likely to cover, which retunes the A bank
- How many hours you have before the interview → a prioritized prep schedule
- A `tuesday-dossier.md`, if you already have one → verified evidence and objections carried in, instead of inferred from this message
