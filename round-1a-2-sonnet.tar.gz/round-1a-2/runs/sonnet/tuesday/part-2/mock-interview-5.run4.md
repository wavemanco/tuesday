Research was refused, so I'm building the pack from your message and the recruiter's email, then saving it.
Your prep pack is saved as `kelverton-rail_senior-partnerships-manager_interview_pack.md` in the working folder. Two gaps limit it:

- **No web research.** All six searches were refused, so nothing in it is verified about Kelverton, Deepa or Ross. Questions that would normally rest on their strategy are generic.
- **No market report.** The attachment wasn't in this conversation, so nothing in the pack draws on it. The POV build tells you where to bring in your own reading of it.

I built the pack on the recruiter's description of the panel. I treated Ross as a commercial counterpart who will press on the numbers, since her email doesn't say where he sits relative to Deepa.

Your two biggest prep priorities, in order:
- **The POV (about two hours).** The pack offers three thesis options, each with a concession to say aloud. It also gives a 15-minute shape that ends on what changes for the operators.
- **The rail objection (question B1).** Concede "I haven't sold into rail specifically" first, then use only what you've told me: the ISV channel and the bus and light rail planning.

Offers:
- Say the word and I'll play Ross on C1, the £4M question.
- I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
- If you'd like the pack as a Word document, say so and I'll convert it.

Questions, each of which would restructure the pack:
1. Is Ross senior to Deepa, a peer, or in a separate reporting line? The answer reweights the Peer and Pressure banks.
2. Do you have the posting text? Paste it, or say skip, and I'll leave the requirement rows as they are.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

Panel round, Tuesday, 60 minutes. Panel: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). Format from the recruiter: a 15-minute POV from you, then Q&A. Built from your message and the recruiter's email only: no web research ran and no job description was supplied.

The recruiter's email says who runs this session and what it holds, so persona weights rest on that, not on a guessed loop archetype. Nothing is assumed about any other round.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values. No question carries this type: no values-style round is detected and no published values were read |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | The role as stated, including its gaps |
| CO | Knowledge of the company and its strategy |
| CASE | A live problem, scored on structure and reasoning |

Guidance is scaffolding, not a script. Where a cell says "answer slot", it is an instruction for the interview: answer from your own experience, or say plainly that the practice was not yours or never existed.

## Prep triage (four hours, over the weekend)

| Block | Time | Do this | Where |
|---|---|---|---|
| 1 | 60 min | Build the 15-minute POV on paper: one thesis, its concession, one point of agreement with the report, one anti-pick, the operator close | Graded deliverables section |
| 2 | 45 min | Say the POV aloud twice against a timer, cutting to 15 minutes | Graded deliverables section |
| 3 | 60 min | Rehearse Ross's numbers and commercials aloud, until you can say what you do not know without flinching | C1, C2, C4, D2, D3 |
| 4 | 45 min | Rehearse the rail objection until it is boring | B1, B2, D1 |
| 5 | 30 min | Choose which reverse questions you will actually ask, and decide who gets each | Reverse questions |

Everything else is insurance.

## Fit snapshot

No job description was supplied, so the requirements are the recruiter's own words and your description of the company. No row is a gate: nothing in the material states a location, right-to-work, travel or similar term.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — the recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company, not operator partnerships, with nothing inspected behind it, and the words stay there: "I ran the ISV channel at a payments company and took it from 6 partners to 40." Answer slot: the POV is about operators, so a probe on what carries across is likely. If something from the ISV channel carries across, say what and why in your own words; if nothing does, or it was not yours, say so plainly and stay with the channel |
| F2 | "Please land on what it means for the operators themselves." — the recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, not heavy rail and not train operating companies, and the words stay there: "I spent 5 years in transport consulting, in bus and light rail network planning." Answer slot: the close about operators makes a probe on what you saw of operators' problems likely. If any of that work put you in contact with those problems, say which, in your own words; if it did not, say so plainly and stay with the planning work |
| F3 | "Ross will push on commercials." — the recruiter's email | "roughly £4M of influenced revenue" — your message; "never carried a direct quota, only influenced revenue" — your message | medium | [grounded] | transferability | Your material gives an influenced figure and no commercial terms, and the words stay there: "I haven't carried a direct quota; the figure I can speak to is roughly £4M of influenced revenue." Answer slot: a figure invites four probes. Say how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words; where you do not know one, say so plainly |
| F4 | "they sell scheduling software to train operating companies" — your message | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't sold into rail specifically." Then how you would learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller |

## Graded deliverable: the 15-minute POV

The recruiter's words: "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it" and "Please land on what it means for the operators themselves." This is graded, so it gets its own build.

Facts you may build on, each exactly as your evidence cell holds it:

- F1: "took it from 6 partners to 40, roughly £4M of influenced revenue"
- F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"
- F4, as the limit to name rather than hide: "Never sold into rail specifically"

Three thesis options. Pick one; the concession is mandatory.

| Thesis | What you would say | Concession to say aloud | Provenance |
|---|---|---|---|
| T1 Depth before breadth | Build a small number of operator partnerships to a measurable operator outcome first, then widen | It shows coverage more slowly. The pack's observation: your quoted record in F1 is a partner count, not depth with any one partner, so present depth as a hypothesis you would test, not an experience | [generic] |
| T2 A repeatable programme | Make operator partnerships repeatable, so each added operator is easier to bring in than the last | A programme shaped for a wider partner base may fit operators less well. Say that is untested and say how you would test it. The pack's observation: F1's quote is an ISV channel | [generic] |
| T3 Operator outcome first | Start each partnership from an outcome the operator would recognise, then work back to what Kelverton delivers | The outcomes have to come from operators. The pack's observation: F4 says you have not sold into rail specifically, so state them as hypotheses to check in your first weeks | [generic] |

Differentiation. You have read the same report your panel's own strategy team wrote, so reciting its shortlist scores as homework, not judgment. Bring one item you agree with, in your own words, to show you did the reading. Then diverge: your chosen thesis, with reasons. Then give an anti-pick: one thing you would deliberately not do in the 18 months, and what that costs. This pack has not seen the report, so it names no item for you. If the report has its own segmentation language, use its words.

Suggested 15-minute shape:

| Minutes | Content |
|---|---|
| 0 to 2 | Where you would start, and the one question you would want answered first |
| 2 to 5 | The point of agreement with the report |
| 5 to 10 | Your thesis and its concession |
| 10 to 12 | The anti-pick |
| 12 to 15 | The close: what an operator would see change around months 3, 12 and 18, each said as a hypothesis, ending on the first thing you would ask operators |

## Persona table

| Persona | How it shows up | Weight, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Deepa's live problems on the operator partnerships; the POV itself | Highest, 5 questions. The hiring-manager prior is Case / Strategist plus Skeptic, and the email announces a POV on "where you'd take our operator partnerships" | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | The rail gap and the quota gap | High, 4 questions. The hiring-manager prior includes it, and F3 and F4 are negatives you stated | Rehearse the single most predictable objection (B1) until it is boring; build bridges only from the quotes in F1 and F2 |
| Data-Driven Prober | Ross on the two figures and on commercials | High, 4 questions. The email says "Ross will push on commercials", and F1 and F3 hold two figures | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know |
| Pressure | Time-boxed or interrupting pushback on commercial answers | Medium, 3 questions. "Push" in the email may mean challenge, not stress, so it sits below the Prober | Pause, restate, anchor in your quotes, hold through two follow-ups before conceding anything real |
| Peer Evaluator | Ross as the commercial counterpart to partnerships | Low, 2 questions. Reporting lines are not in the email, so this rests on the Step 1 question about Ross | Reciprocity: what you bring his team; propose seam principles, not a seam you cannot know |
| Conversational | The opener and a casual sector question | Low, 2 questions. The email puts the POV first, but a casual question is still scored | A 90-second arc built only from your quoted sentences |

## Question banks

### A. Case / Strategist (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Before you tell us where you'd take it, what would you want to know about our operator partnerships, and why?" | CASE | [grounded] the recruiter's "where you'd take our operator partnerships over the next 18 months" | Clarify before structuring. Name two or three things you would ask, and for each say how the answer would change your recommendation. The question needs no claim about your past, so the guidance makes none | Asked because a POV invites a clarifying challenge before it starts. F1's requirement is the source; CASE because it scores structure |
| A2 | "Talk us through where you would take our operator partnerships over the next 18 months." | CASE | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | This is the deliverable: build it as the section above sets out. If you refer to your own record, do it once, in the quote's words: you ran the ISV channel at a payments company and took it from 6 partners to 40. Answer slot: a probe on what carries across from an ISV channel to operators is likely. If something does, say what, in your own words; if nothing does, say so plainly and stay with the channel | F1 is the requirement. CASE because it is a live recommendation, and the likeliest place for the panel to test whether your thesis is yours |
| A3 | "What does that mean for the operators themselves, at month three, month twelve and month eighteen?" | CASE | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Say each consequence as a hypothesis to test with operators. Hold what you know to the quote: bus and light rail network planning. Answer slot: if any of that planning work involved hearing what operators struggled with, say what you heard; if not, say so plainly and stay with the planning work | F2 is the requirement and the recruiter's named close. CASE because it scores whether the recommendation lands on the operator |
| A4 | "Which operators or segments would you not prioritise in the first six months, and why?" | CASE | [generic] | Give your criteria before any names: what makes a partner worth early effort, and what makes one wait. Choose one thing you would decline and say what declining it costs. The question needs no claim about your past, so the guidance makes none | The anti-pick from the differentiation strategy, asked directly. `[generic]` because it is a prioritisation pattern, not a fact about this employer |
| A5 | "How would you tell, in eighteen months, whether the partnerships were working, for us and for the operator?" | CASE | [generic] | Give one lens for Kelverton and one for the operator, and separate early signs from late results. Name the measure yourself where you have one; the pack names none. The question needs no claim about your past, so the guidance makes none | F2's requirement asks for the operator's view, so the metric needs both lenses. CASE because it scores reasoning about success |

### B. Skeptic (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail specifically. Why should we believe you can build partnerships with operators?" | JD | [grounded] "Never sold into rail specifically"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "took it from 6 partners to 40, roughly £4M of influenced revenue"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | The highest-ROI rehearsal in this pack. Concede first, in your own words: "I haven't sold into rail specifically." Then give only what the quotes carry: you spent 5 years in transport consulting, in bus and light rail network planning, and you ran the ISV channel and took it from 6 partners to 40. Then a ramp plan, said as a plan: name the first two things you would learn, and from whom. Answer slot: if a follow-up lands on "the other side", say in your own words which side you meant; if you are unsure, say so plainly and return to the planning work. Hold through two follow-ups by returning to the quotes, never by adding to them | F4 is the biggest gap and F1 and F2 are the only adjacent evidence, so this objection will arrive in some form. JD because it scores the role as stated; the Skeptic is the persona |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically"; "never carried a direct quota, only influenced revenue" | Choose the one you believe, not the safest. Your own message names two candidates, rail and a direct quota, and the pack will not pick for you. Say it plainly, then say how you would close it, as a plan. Answer slot: if neither is your weakest, say what is, in your own words | F3 and F4 are the two stated negatives. JD because it scores honest self-assessment against the role |
| B3 | "What draws you to rail-tech partnerships, and why now?" | JD | [generic] | Answer slot: give your actual reasons, in your own words; the pack does not know them. If the pull is the sector more than the move, or the reverse, say so plainly. Rehearse it to 45 seconds | Motivation consistency is what the Skeptic scores, and the material does not state your reasons. JD because it tests fit with the role |
| B4 | "You ran an ISV channel. What carries over to operator partnerships, and what doesn't?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | Start from the quote: you ran the ISV channel at a payments company. Split your answer in two: what you would carry, and what you would test before assuming it carries. Answer slot: if you built a specific practice with ISV partners that you expect to carry across, say what it was, in your own words; if you did not, say so plainly and answer from how you would approach the question | F1 is the bridge the panel will test. JD because it scores the transfer the role depends on |

### C. Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the £4M: how was it counted?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue"; "never carried a direct quota, only influenced revenue" | Keep the quote's words: roughly, and influenced. Answer slot: say how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words. If you do not know how it was counted, say so plainly. Name the weakest assumption before he does | F3 is the headline figure, and a commercial director probes headline figures. EXP because it scores attribution |
| C2 | "On the 6 to 40: how was a partner counted, and which part of that growth was yours?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Same four slots as C1: how a partner was counted, what the count is sensitive to, the assumption you would defend least, and your share. Each in your own words; where you do not know one, say so plainly | The second figure on your material gets the same probe. EXP because it scores what was actually yours |
| C3 | "How would you think about commercial terms with operators?" | CASE | [generic] | Structure it. What the partnership is for, who carries the risk, how value is measured, what each side gets. Say plainly that you would want Ross's view on today's terms before committing to a model. The question needs no claim about your past, so the guidance makes none | The email says commercials will be pushed. CASE because it is a live problem; `[generic]` because it is a pattern, not a fact about this employer |
| C4 | "You've never carried a direct quota. How would you hold a number here?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Plain acknowledgment: "I haven't carried a direct quota." Then the figure the quote carries, said as it stands: influenced revenue. Answer slot: if any number was reviewed against your name in your ISV role, say what and by whom; if none was, say so plainly, then say how you would want a target set | F3 states the absence, so the question is lawful and predictable. JD because it scores the role's commercial accountability |

### D. Pressure (Ross, Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically"; "took it from 6 partners to 40, roughly £4M of influenced revenue"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Pause, restate, then hold only the quotes: you ran the ISV channel and took it from 6 partners to 40, and you spent 5 years in bus and light rail network planning. Concede explicitly, in your own words: "I haven't sold into rail specifically." Do not claim to be better. Hold through two follow-ups, never by adding to the quotes | F4 is the stem's target. JD because it scores the role; Pressure because it is time-boxed |
| D2 | "That £4M: how much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue"; "never carried a direct quota, only influenced revenue" | Hold the word influenced; do not upgrade it to a stronger verb. Answer slot: say which part was yours, in your own words; if you do not know how much was, say so plainly and return to the quote. Concede that influenced is different from a quota, and stop there | F3's figure under attribution pressure. EXP because it scores precise attribution |
| D3 | "An operator partner asks for a concession on terms you don't have authority to approve. What do you say?" | CASE | [generic] | Pause. Ask what is wanted and what it is worth, say who would need to approve it, and do not agree on the spot. Say you would take it to Ross rather than guess. Hold that through a push, concede that you do not yet know Kelverton's terms. The question needs no claim about your past, so the guidance makes none | F3's commercial push, as a live problem. CASE because it scores composure and structure |

### E. Peer Evaluator (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Partnerships and commercial sit close together. Where's the seam, and what happens when we disagree?" | JD | [inferred] derived from the panel's makeup in the recruiter's email: a VP Partnerships and a Commercial Director | Propose principles for the seam, not a seam you cannot know: who owns the operator relationship, who owns the terms, how a disagreement gets decided. Say what you would bring his team, not only what you would need. Say you would want his view on how it works today. The question needs no claim about your past, so the guidance makes none | The reporting lines are not in the email, so the seam is a likely probe, not a certain one. JD because it scores how you work with the commercial function |
| E2 | "How do you handle credit when a partner deal spans partnerships and sales?" | EXP | [generic] | Selection scaffold. Pick a time credit for revenue was shared with another team: it needs who held the customer relationship, how credit was split, and how the relationship ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is the influenced figure as it stands, or how you would handle it | The stem scores credit-sharing, and your figure is influenced, not direct. EXP because it probes attribution |

### F. Conversational (both)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | A 90-second arc with only the beats the quotes state: 5 years in transport consulting, in bus and light rail network planning; 9 years in partnerships; the last 4 running the ISV channel at a payments company. Answer slot: the link between the consulting years and the partnerships years is not in your material; say why you moved, in your own words. End pointing at operators | The one unscripted slot before the POV. EXP because it tests whether your story holds together |
| F2 | "What are you actually thinking about in rail scheduling these days?" | CO | [grounded] "which I've read" | Answer slot: you have read the report; say one thing from it that changed or sharpened your view, in your own words. If you have not followed scheduling closely beyond the report, say so plainly and say what you would learn first. The pack has not seen the report and offers nothing from it | A casual question about the company's field is still scored. CO because it scores sector knowledge; with no research, it is `[grounded]` only on your reading of the report |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1: the 18-month POV on operator partnerships | A1, A2, A4, A5, B4, F1 |
| F2: land on what it means for the operators | A3, A5, F1 |
| F3: Ross will push on commercials | C1, C2, C3, C4, D2, D3, E2 |
| F4: selling scheduling software to train operating companies | B1, B2, B3, D1, F2 |
| Working with the commercial function: no stated requirement, a persona probe from the panel's makeup | E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | To Deepa: "What would a good 18 months look like for operator partnerships from your seat, and what would tell you it hadn't worked?" | It gives you the measure your POV is scored against, and invites her to correct it |
| R2 | To Deepa: "Which parts of today's operator partnerships would you most like to change?" | It shows where your thesis meets her priorities, and signals you are thinking about a role you would hold |
| R3 | To Ross: "How do commercial terms with operators get decided today, and where would you want partnerships to have a voice?" | It turns his commercial push into a conversation about the seam |
| R4 | To Ross, the reciprocity question: "What could a new partnerships person do in their first month that would genuinely help your team?" | It shows you are thinking about what you bring him, not only what you need |
| R5 | To both: "What would you want me to have learned about operators by day 90?" | It shows you have a ramp plan, which answers B1 and B2 before they are asked |
| R6 | To both: "Which part of last quarter's market report is shaping how you think about partnerships now?" | It shows you read it, and lets the panel say what they took from it, instead of you reciting it |

## Prohibited claims

Built before the banks. These are claims this pack will not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail, or has rail commercial experience | Negative the candidate stated, F4 | The plain acknowledgment F4 gives: "I haven't sold into rail specifically." No slot |
| Has carried a quota or owned a revenue target | Negative the candidate stated, F3 | The plain acknowledgment F3 gives: "I haven't carried a direct quota." No slot beyond C4's |
| Generated, sourced or closed £4M | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue". The limit is the pack's observation: your material says influenced, not sourced or closed |
| Built or ran operator partnerships | Inflated form of F1 | F1's quote at its own scope: an ISV channel at a payments company. The limit is the pack's observation: your material says ISVs, not operators |
| Has first-hand knowledge of train operators' problems | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning. The limit is the pack's observation: your material says network planning, not heavy rail operations |

## Sources

Provided: the recruiter's email, as quoted in your message; your own description of your background. The market report the recruiter attached was not in this conversation and the working folder held no file, so nothing in this pack comes from it. No dossier was present.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Search refused. Would have fed a values cheat sheet; none is built, and no values-style round is detected in any case |
| 2. Kelverton Rail interview process, partnerships | unavailable | Search refused. The recruiter's email establishes this session, so persona weights rest on it; nothing is assumed about other rounds |
| 3. Kelverton Rail strategy and recent news | unavailable | Search refused. Would have grounded the CO and CASE questions in current strategy; they stay generic or rest on your report |
| 4. Deepa and Ross at Kelverton Rail | unavailable | Both searches refused. Would have fed an interviewer read and a reverse question tied to their paths; both are absent |
| 5. Representative Senior Partnerships Manager JD | unavailable | Search refused. Would have supplied quoted requirements; the snapshot uses the recruiter's words instead |

Queries sent, all refused:

- "Kelverton Rail values": refused
- "Kelverton Rail interview process partnerships": refused
- "Kelverton Rail strategy news train operating companies scheduling software": refused
- "Deepa VP Partnerships Kelverton Rail": refused
- "Ross Commercial Director Kelverton Rail": refused
- "Senior Partnerships Manager job rail technology software train operating companies UK": refused

## Upgrade menu

- The market report's headline findings, pasted: thesis options built against its own shortlist, and a grounding brief of current vocabulary; F2 and the CO questions become grounded
- The job description: requirement rows become quoted, JD-tagged questions become grounded, and any location, right-to-work or travel term shows up as a row
- Search permission: a rerun of the five targets above, which would add values, loop, strategy, interviewer footprint and a representative JD
- A deeper research pass, offered once: up to 6 further searches and 2 further fetches, several more minutes, needing the same search permission; adds a strategy brief and interviewers' published talks
- Interviewers' public profiles, pasted: an interviewer read and reverse questions tied to their career paths
- Your own answers on how the £4M and the 6 to 40 were counted, and whether any consulting work put you in contact with operators' problems: F1, F2 and F3 move from transferability toward grounded stories, and A2, A3, C1, C2 sharpen
- A `tuesday-dossier.md`, if you have one: verified evidence and prohibited claims arrive pre-built; the pack stands without it
