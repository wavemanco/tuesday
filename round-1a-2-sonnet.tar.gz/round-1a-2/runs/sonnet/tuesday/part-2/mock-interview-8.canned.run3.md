Pack written. I'm running a quick format check for stray brackets and pipes, then I'll send the summary.
Your prep pack is saved as ashgrove-credit-union_member-experience-lead_interview_pack.md. It covers all three rounds on 29 November and has 31 questions. I wrote it as three round-by-round sections because the recruiter's email fixes who runs each round. Persona weights rest on the interviewers' roles alone, since none have been assigned yet.

The date needs checking: 29 November 2026 is a Sunday. Confirm the day and the three start times with the recruiter.

- **Biggest objection:** your contact centre gap is the one to rehearse most. D1 to D3 take it through three follow-ups, with the wording for conceding the gap plainly and a plan for your first 30 days. Your presenting gap is covered the same way in B2 and J1.
- **Round 3:** G1 to G4 give one question per value, in their published names. H1 to H3 are practice for the complaint-escalation case, and H3 covers the eight-into-five hubs. I invented the H1 scenario for rehearsal, so it is not Ashgrove's actual case.
- **Not added to your story:** the pack keeps your own sentences at their own scope. It doesn't coach "owned the process end to end", "reported on volumes and resolution times", "coached supervisors" or "handled regulated complaints", and nothing about contact centre work or presenting above regional level. Where the interviewer is likely to probe past what you said, the pack gives you an instruction to answer in your own words. For example, say what your monthly spreadsheet counted, or say plainly if you don't know.
- **Research and gaps:** I ran no searches. Your pasted values, the recruiter's email and your summary of the strategy brief already covered what the questions needed. The pack's upgrade menu lists what would sharpen it, including the brief itself, the interviewers' names and the case format.

Say the word and I'll play the Skeptic on D1, the pack's highest-ROI question.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode: three rounds on 29 November 2026, built from the recruiter's email.

| Round | Who | Length | Shape |
|---|---|---|---|
| 1 | The recruiter | 30 min | Screen |
| 2 | Head of Member Services, who would be your manager | 45 min | Mostly behavioural |
| 3 | Panel of two branch managers | 60 min | Includes a 20-minute complaint-escalation case; also the values round, scored against the four values |

Interviewer names have not been assigned, so the pack has no interviewer read and persona weights rest on each round's role alone.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored. Every question carries one of each.
- Types: VAL (behaviour that shows Ashgrove's published values), EXP (whether your own experience survives scrutiny), JD (a stated requirement of the role, including its gaps), CO (company and strategy knowledge), CASE (a live problem set in the role).
- Guidance is scaffolding, not a script. All proposed wording in this pack is pending your approval: change it into your own words, and drop any line you could not say about yourself under a second question.
- An answer slot is an instruction for the interview, not a question for you now. Meet it with whichever branch is true.
- Question IDs run A to K across the whole pack, so the drill and any follow-up can point at one.

## Fit snapshot (shared by all three rounds)

Proposed wording below is pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's complaints log and a teller training script, not a process across branches, and nothing inspected sits behind it. The words stay at that scope: "I handled my branch's formal complaints log and trained new tellers on our escalation script." Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint after it left your branch likely. If any part of that was yours to follow, say which part, in your own words; if a complaint left your branch and you had no further hand in it, say so plainly and stay with the log you handled |
| F2 | "the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past: "In my first weeks I would ask to sit with the contact centre team and follow complaints from their desk back to a branch." Never a claim to contact centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says a monthly complaints spreadsheet your regional manager uses; it does not say what the spreadsheet counted. The words stay there: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: expect a probe on what it counted. Say what it counted and how, in your own words; if you did not track a figure the interviewer names, say so plainly and describe what it did show |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your sentence says spreadsheet, not Excel, so the words stay at spreadsheet. Answer slot: if you built it in Excel, say so and what you built into it, in your own terms; if it was another tool, name it plainly |
| F5 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says you trained new tellers on the escalation script, not that you coached supervisors, and nothing says what followed the training. Words at that scope: "I trained new tellers on our escalation script." Answer slot: expect a probe on how you went about it. Say how, in your own words; if you had no method, or it was not yours to set, say so plainly and describe what you did with the tellers |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Nothing in your material shows this yet. Strong evidence would be one named member journey, what members struggled with, and what changed. Answer slot: if you have had any contact with a digital or IT team about something members use, say what it was and what part was yours, in your own words; if you have not, say so plainly and say what you would ask a digital team first |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap in the years: the quote says six in retail banking. Lead with it in its own terms, "6 years in retail banking, the last 3 as a branch supervisor", and stay at retail banking when asked what it covered. Expect a probe, since nothing inspected sits behind the line |
| F8 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | The quote says a formal complaints log; whether those complaints fell under any rules is not shown. Answer slot: expect a probe on what made those complaints formal. Say what made them formal and what you did with them, in your own words; if you do not know what rules applied, or there were none, say so plainly and stay with the log |
| F9 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then a plan, not a past: "For the first monthly report I would keep it to one page, lead with what changed, and say what decision I am asking for." Never a claim to have presented to senior leaders |

Requirement coverage, JD line by JD line:

| JD requirement | Covered by | Note |
|---|---|---|
| Own the complaints process end to end, branches and contact centre | B1, D1, D2, D3, H1, H3, J1 | Deepest rehearsal is the D chain |
| Report monthly on complaint volumes and resolution times | E2, F1 | |
| Coach branch supervisors on escalations | C3, H2, I1 | |
| Work with digital teams on self-service journeys | C4, E1 | |
| 4+ years in financial-services customer operations | A1, A8 | |
| Experience handling regulated complaints | F2 | |
| Confident presenting to senior leaders | B2, J1 | |
| Comfortable with Excel reporting | A7, F1 | |
| Members First, Always | G1 | |
| Plain Words | G2 | |
| Neighbours, Not Numbers | G3 | |
| Own the Fix | G4 | |

## Prohibited claims (shared)

Built from the snapshot before any bank was written. Nothing in this pack coaches these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says one branch's log and a teller script, not a process across branches. D1 to D3 and H1 stay inside the log |
| Has contact centre experience | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F9 | The plain acknowledgment F9 gives: "I've never presented to anyone above regional level." No slot |
| Reported on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says a monthly spreadsheet, not what it counted. F1's slot asks only what the spreadsheet counted |
| Coached branch supervisors | Inflated form of F5 | F5's quote at its own scope. The material says new tellers. C3 and I1 stay with the tellers |
| Handled regulated complaints | Inflated form of F8 | F8's quote at its own scope. The material says a formal complaints log. F2's slot asks only what made those complaints formal |

## Round 1: the recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured, logistics and motivation | Highest. A recruiter screen sits here by relationship prior, and the recruiter's email gives this round 30 minutes with no stated focus. [grounded] recruiter's email | Treat casual questions as scored. Have a 90-second arc ready and never close the reverse-question slot with "I think you've covered everything" |
| Skeptic, light | Quiet knockout checks on gaps | Lower. The recruiter row adds a light Skeptic by relationship prior; the JD's contact centre and senior-leader lines are where it lands. [inferred] JD requirements against F2 and F9 | Name the gap in your own plain words, then give the plan. Do not stretch adjacent work to cover it |

Proposed guidance below is pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your journey so far, and how it led you to this role." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F7, F1 and F3, using only the beats the quotes state: six years in retail banking, the last three as a branch supervisor; the complaints log you handled; training new tellers on the escalation script; the monthly spreadsheet your regional manager uses. Tell them in your own words. Answer slot: the why-this-role beat is yours; say what draws you to complaints work and to Ashgrove, in your own words, and if the move has a different reason, say that plainly | The biography question opens most screens, and F7 is the headline requirement a recruiter checks first; EXP because it tests whether your telling matches your material |
| A2 | "What do you know about where Ashgrove is heading?" | CO | [grounded] "move 40% of member service to digital channels by 2028; consolidate eight branches into five hubs over 2027; launch a small-business lending product in Q1 2027; the main competitive pressure is app-only banks" — your message, from the July 2026 strategy brief | Use the four points in the brief's own terms and pick the two that touch this role: the 40% digital target by 2028 links to the JD's self-service line, and the eight-into-five hub plan links to the JD's across-branches line. Say what you would want to understand about each rather than what you predict. Your material holds only these four points from the brief, so read the brief itself before the call | Recruiters test homework depth early, and this is the one question that needs no experience claim; CO because it scores company knowledge, with a JD link as the proof you read the role |
| A3 | "What are your salary expectations for this role?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first. Give no figure you have not decided and no past pay figure unless you choose to | The recruiter row of the persona priors always includes pay; JD because pay is a term of the listed job |
| A4 | "What is your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | The recruiter row always includes notice; JD because it is a term of the listed job |
| A5 | "How would working across branches and the contact centre fit with where you are based?" | JD | [generic] | Logistics slot: give your own location and any constraint on travelling between sites, in your own words, or say you have none | The JD's across-branches and contact centre line makes location a live check; JD because it scores a term of the listed job |
| A6 | "What is prompting a move now?" | EXP | [generic] | Logistics slot: give your own reason, in your own words. Keep it about what you are moving toward, and keep every word true | The reason for leaving is asked at every screen and the only safe answer is your own; EXP because it tests consistency with your story |
| A7 | "The role needs Excel reporting. How comfortable are you with Excel?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F4, at the quote's own words: the monthly complaints spreadsheet you built and your regional manager uses. Answer slot: if you built it in Excel, say so and what you built into it, in your own terms; if it was another tool, name it plainly | A comfort check is the cheapest knockout in a screen, and F4's evidence stops at spreadsheet; JD because it scores a stated requirement |
| A8 | "Can you confirm your years in financial services?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say it in the quote's own terms: six years in retail banking, the last three as a branch supervisor. Stay at retail banking if asked what it covered | The years requirement is a quick yes or no in a screen, and F7 meets it; JD because it scores the first stated requirement |
| B1 | "Which part of this job description would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick the gap you have stated and say it plainly: "I haven't worked in a contact centre." Then the plan from F2, as a plan: sit with the team and follow complaints from their desk back to a branch. Do not offer branch work as contact centre experience | The JD's first line puts the contact centre in the job, which makes this the likeliest Skeptic opening; JD because it scores a stated requirement and its gap |
| B2 | "This role presents to senior leaders. How do you feel about that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say it plainly: "I've never presented to anyone above regional level." Then the plan from F9, as a plan: a one-page monthly report, what changed first, and the decision you are asking for. Do not describe confidence you have not been able to test | The JD names confident presenting, and a recruiter screens for it by asking about feelings first; JD because it scores a stated requirement |

### Reverse questions for the recruiter

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "Can you tell me anything about the 20-minute case: its format, whether there are materials, and whether I get time to prepare?" | Recruiters can often share format in one email, and asking shows you prepared a specific round |
| R1-2 | "How does the role split between branches and the contact centre day to day?" | It opens the contact centre topic on your terms instead of theirs |
| R1-3 | "Where does the role sit relative to the digital team working on the move to digital channels?" | It ties the JD's self-service line to the brief's digital target |
| R1-4 | "Has this role existed before, or is it new?" | It shows you are thinking about handover and mandate, and the answer shapes everything you ask in round 2 |
| R1-5 | "What is the timeline for decisions after the three rounds?" | A plain logistics close that signals interest without a generic compliment |

## Round 2: Head of Member Services, your would-be manager (45 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes, story-shaped answers | Highest. The recruiter's email says this round is mostly behavioural. [grounded] recruiter's email | Where a quoted sentence carries a story, tell it at its own scope; where none does, use the scaffold and its honest branch. Use "we" for context and "I" for what was yours |
| Skeptic | Probing the gaps, then returning to them | High. A hiring manager buys capability and derisks gaps by relationship prior; F2 is the biggest gap in the snapshot. [inferred] the relationship prior with F2 | Rehearse the contact centre objection until it is boring. D1 to D3 are the highest-ROI preparation in this pack |
| Case / Strategist | Live problems from the role's own agenda | Mid. A manager's relationship prior is Case and Strategist, tilted down here because the email says mostly behavioural. [inferred] relationship prior adjusted by the recruiter's email | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Data-Driven Prober | Reading the claim line by line | Lower. The only built artifact in your material is the monthly spreadsheet (F3). [inferred] F3 | Know what you can and cannot say about what it counted, and say plainly where you do not know |

Proposed guidance below is pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to someone more senior." | VAL | [generic] | Selection scaffold, since no quoted sentence carries this story. Pick a time with a named stake, a moment you held your position, and a relationship that was intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or say how you would handle it | The behavioural round is where the persona stem about unpopular truths lands, and the JD's senior-leader line makes the theme live; VAL because it scores behaviour, not a stated requirement |
| C2 | "When did you put a member ahead of an internal metric?" | VAL | [generic] | Selection scaffold, since no quoted sentence carries this story. Pick a specific member, the easier answer, what you did instead and what it cost you. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or say how you would handle it | The first value is Members First, Always, so a manager running a behavioural round will probe this stem; VAL because it scores values-aligned behaviour |
| C3 | "Tell me about a time you helped a colleague handle a difficult escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F5, at the quote's own beats: new tellers, the escalation script, your training of them. Answer slot: the JD's coaching of supervisors makes a probe on how you taught the tellers likely. Say how you went about it, in your own words; if you had no method, or it was not yours to set, say so plainly and describe what you did with the tellers | The JD says coach branch supervisors on escalations, and F5's evidence is the nearest thing in the material; JD because it scores the stated requirement, with a behavioural delivery |
| C4 | "Tell me about a time you worked with a team outside your own to fix something members used." | JD | [generic] | Answer slot: the JD's digital-teams line makes this likely. If you have worked with a digital or IT team on something members use, say what it was and what part was yours, in your own words; if you have not, say so plainly and say what you would ask a digital team first | F6 has no evidence, so this question has no story to map and the slot is the honest form; JD because it scores the self-service line |
| D1 | "I don't see contact centre experience in your background. How would you own a complaints process that runs through one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | The highest-ROI rehearsal in this pack. Level one: say it plainly, "I haven't worked in a contact centre", then the plan from F2: sit with the team and follow complaints from their desk back to a branch. Hold only what the quote carries and stay with the branch log if pressed. Do not describe how a contact centre runs | This is the single most predictable objection; it arrives in some form in at least two rounds because the JD names the contact centre in its first line; JD because it scores a stated requirement and its gap |
| D2 | "I am not sure a branch background carries across. What would change my mind?" | CASE | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Level two, hold then concede. Hold: the log and the escalation script are what you have done. Concede specifically: the contact centre side is something you have not done, and the plan is to learn it before changing anything. Name the limit before it is asked for: your material does not show contact centre work. Do not add a second claim to cover the gap | A follow-up that tests whether you fold or stretch; CASE delivery because it asks you to reason about evidence, though the content is the same objection as D1 |
| D3 | "What would your first 30 days on the contact centre side look like?" | CASE | [generic] | Level three, a plan and never a past. Offer two or three moves you would choose from, such as sitting with the team, reading how complaints reach them and what leaves them, and agreeing with them what you would not change yet. Pick the ones you would actually do, and drop any you would not | Hiring managers ask for a plan once a gap is conceded; CASE because it is a live problem about the role |
| E1 | "Ashgrove wants to move 40% of member service to digital channels by 2028. For complaints, what do you need to know first before deciding what moves to self-service?" | CASE | [grounded] "move 40% of member service to digital channels by 2028" — your message, from the July 2026 strategy brief | Clarify first: what the complaints data shows by type and by channel, which complaints members will want a person for, who owns the journeys today. Then objective, approach, and how you would measure it. Use the Plain Words value as a test of any journey: if a member needs it explained twice, the journey is wrong. The question asks about no past, so the guidance makes no claim about yours | The strategy brief's digital target is the clearest bridge to the JD's self-service line; CASE because it is a live problem in the manager's own agenda |
| E2 | "If you were designing the monthly complaints report for the leadership team, what would be on the first page?" | CASE | [generic] | Clarify the audience and the decision first. Then lead with the two measures the JD itself names, volumes and resolution times, and say how you would show change rather than a snapshot. End with the decision you would ask for. The question asks about no past, so the guidance makes no claim about yours | The JD makes monthly reporting a core duty; CASE because it tests structure before answer, and F3 and F9 sit behind it |
| F1 | "Walk me through what your monthly complaints spreadsheet showed and how your regional manager used it." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what it was, in the quote's terms: a monthly complaints spreadsheet you built that your regional manager uses. Answer slot: expect probes on what it counted, how, what it is sensitive to, and which parts were yours. Say each in your own words; if you do not know how a figure in it was counted, say so plainly. Name the part you would defend least before they do | This is the nearest thing to a reporting artifact in your material (F3), so it is the magnet for a probe; EXP because it tests attribution |
| F2 | "The role handles regulated complaints. Tell me about the formal complaints log you handled." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F8, at the quote's own beat: the formal complaints log you handled. Answer slot: expect a probe on what made those complaints formal. Say what made them formal and what you did with them, in your own words; if you do not know what rules applied, or there were none, say so plainly and stay with the log | F8's evidence is the log and nothing shows whether it was regulated; EXP because it tests what was actually yours |

### Reverse questions for the Head of Member Services

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "What would a good first six months look like in this role?" | It asks them to set the scoring sheet you will be measured on |
| R2-2 | "What does the complaints picture look like today across branches and the contact centre, and what would you most want fixed?" | It invites their view of the real problem before you offer yours |
| R2-3 | "Who sees the monthly complaints report today, and what decision should it drive?" | It ties to the JD's monthly reporting line and to the senior-leader audience |
| R2-4 | "How do member services and the digital teams work together on self-service journeys now?" | It tests the JD's digital-teams line from their side |
| R2-5 | "My background is in branches. What support would I have on the contact centre side?" | It turns the biggest objection into a planning conversation with your future manager |

## Round 3: panel of two branch managers (60 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Stories scored against the four published values | Highest. The recruiter's email says the panel is also the values round and scores against the four values. [grounded] recruiter's email | One story or scaffold per value, G1 to G4. Choose stories where the hard truth landed; where your material shows none, say so rather than supplying an ending |
| Case / Strategist | The 20-minute complaint-escalation case | High. The recruiter's email names a 20-minute case on a complaint escalation. [grounded] recruiter's email | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud, and say the values only where they truly describe how you would decide |
| Peer Evaluator | Where the seam is, what happens in a disagreement | Mid. The role coaches branch supervisors, so branch managers have a stake in how it is done. [inferred] JD line on coaching supervisors, with the panel's make-up from the recruiter's email | Offer seam principles rather than pretending to know the seam; bring a reciprocity framing |
| Skeptic | Probing the gaps once more | Lower. The gaps will already have been probed in round 2. [inferred] round 2 persona weights | Plain acknowledgment and the plan, as before |
| Pressure | Time-boxed, challenging | Lowest. Plausible inside the case rather than as its own style. [inferred] the case format | Pause, restate the question, anchor in what you stated, hold through two follow-ups before conceding anything real |

Proposed guidance below is pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided from the member's side of the counter." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Selection scaffold, since no quoted sentence carries a member-side decision. Pick a specific member, what the easy answer was, what you did instead and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or say how you would decide | This is the first published value, Members First, Always, and a values panel scores each by name; VAL because it scores the published value, not generic virtue |
| G2 | "Tell me about a time something had to be explained to a member more than once. What did you change?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F5 at the quote's own beat: the escalation script you trained new tellers on. Answer slot: the Plain Words value says that if a member needs it explained twice, we wrote it wrong. If you saw tellers or members need the script or a letter explained twice, say what you did about it and whose wording it was, in your own words; if you did not, or it was not yours to change, say so plainly and stay with the training | The second published value, Plain Words, is about wording, and the script is the only wording your material touches; VAL because it scores the value |
| G3 | "Tell me about a time a number and the people in front of you pulled in different directions." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Selection scaffold, since no quoted sentence carries this story. Pick one specific moment, the number, the person, what you did and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or say how you would weigh it. Neighbours, Not Numbers says every branch is part of its town, so a branch-manager panel will hear it personally | The third published value, Neighbours, Not Numbers, will matter most to branch managers; VAL because it scores the value. The brief's hub plan makes it pointed, see H3 |
| G4 | "Tell me about a complaint you found and kept hold of until it was fixed." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F1 at the quote's own beat: the formal complaints log you handled. Answer slot: Own the Fix says whoever finds the problem keeps hold of it until it is solved. Pick one complaint from the log, say what was wrong, what you did and how it ended, in your own words; if none stayed with you until solved, say so plainly, then give the log as it stands, or how you would hold one in this role | The fourth published value, Own the Fix, is also the natural frame for the whole case; VAL because it scores the value |
| H1 | "A member has complained three times about the same charge. The branch says it is resolved; the contact centre's notes say it is not. A branch manager wants it closed today. Walk us through what you do." | CASE | [generic] | Clarify first: what the member was told, what each record actually shows, what deadline or clock applies. State the objective, then who keeps hold of it, how the member hears back in words that need no second explanation, and what you record. Challenge one premise respectfully, such as closing today. The question asks about no past, so the guidance makes no claim about yours | The recruiter's email names a 20-minute case on a complaint escalation; CASE because it scores structure on a live problem. The scenario is invented for rehearsal, not Ashgrove's case |
| H2 | "The supervisor involved says they followed the script. How do you coach them without it becoming a blame conversation?" | CASE | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Structure it: what you would ask first, what you would listen for, what you agree together, how you follow up. Where you reach for your own experience, stay at the quote: new tellers, the escalation script. Do not describe coaching supervisors as something you have done | The JD's coaching line is the likeliest follow-up inside the case, and F5 is its evidence; CASE because it is a live problem, with a JD requirement behind it |
| H3 | "Eight branches become five hubs over 2027. How should complaints handling change when a branch closes or merges?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" — your message, from the July 2026 strategy brief | Clarify first: which towns lose a counter, what members there do now, how complaints reach each hub. Do not assume whose branch is affected. Keep the Neighbours, Not Numbers value in view: ask what would keep a closed branch part of its town. Your material holds only this one line of the plan, so say what you would need to know, not what you predict | The brief's hub plan bears directly on a branch-manager panel; CO because it scores strategy fluency at their altitude |
| I1 | "You would be coaching our supervisors on escalations. Where is the seam between your role and a branch manager's, and what happens when we disagree?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Propose seam principles rather than pretending to know the seam: who keeps hold of the complaint, who decides, who tells the member. Offer what you would bring them, in the JD's own terms: the escalation coaching and the monthly report. Answer slot: if you have a disagreement story with an equal, say what it was and how it ended; if you do not, say so plainly and describe how you would handle one | The panel members are the people whose supervisors you would coach, so the seam question is likely; JD because it scores the coaching line, with a peer delivery |
| I2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold, since no quoted sentence carries this story. Pick one occasion with named teams and a named outcome; say plainly which part was yours and which was others'. If no such occasion comes to mind, say so plainly, then give the nearest thing your material carries, or say how you would handle it | A cross-team credit probe tests whether you share credit with branches that keep your fix alive; VAL because it scores behaviour toward colleagues |
| J1 | "You have not worked in the contact centre or presented above regional level. Which worries you more?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick the one that is true for you and say it plainly, then give its plan: F2's for the contact centre, F9's for presenting. Do not call either a strength. Say the limit before it is asked for | By round 3 the panel has probably heard both gaps, and this is the cross-examination form; JD because it scores two stated requirements and their gaps |
| K1 | "Sixty seconds: why you, and not an internal candidate?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold: the complaints log you handled and the script you trained tellers on. Concede specifically: no contact centre, and nothing above regional level. Hold through two follow-ups by returning to the quote, never by adding to it. Do not claim to know their internal candidates | Time-boxed pressure is plausible inside the case; VAL because it tests composure and honest self-assessment rather than a stated requirement |

### Reverse questions for the panel

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "How do your supervisors handle escalations today, and where do they get stuck?" | It shows you will coach from their reality and not a template |
| R3-2 | "What could a new Member Experience Lead do in the first month that would genuinely help your branch?" | The reciprocity question for people who will be your stakeholders |
| R3-3 | "How do you expect the move from eight branches to five hubs to change what branch teams need from complaints support?" | It engages the strategy at their level and lets them say what worries them |
| R3-4 | "Which of the four values is most tested in your branch day to day?" | It lets them score you against the one they care about most |
| R3-5 | "When a complaint is escalated from your branch, what do you want to be told, and when?" | It makes the seam concrete in the panel's own terms |

## Values / principles cheat sheet (round 3)

A values-style round is detected because the recruiter's email says the panel scores against the four values. Names are exact as published; working meanings are paraphrased.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold: a specific member, the easy answer, what you did instead and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or say how you would decide. Used in G1 |
| Plain Words | If a member needs it explained twice, the wording was wrong | F5: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Tell it at that scope; the answer slot in G2 covers anything beyond the training |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold: one moment a number and the people in front of you pulled apart, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or say how you would weigh it. Used in G3 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Tell it at that scope; the answer slot in G4 covers how any one complaint ended |

## Sources

Provided documents: the job description you pasted; the values page text you pasted, copied on 20 November 2026 from ashgrovecu.org/about/values; the recruiter's email about the three rounds; your summary of the July 2026 strategy brief, four points, the brief itself not provided; and your background as written in your message. No dossier was present.

No searches or fetches were sent. The values URL is where your pasted text came from, not a link read for this pack.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the cheat sheet or the VAL questions: the pasted values page fixes all four names and their wording |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | Could not have moved the persona weights: the recruiter's email fixes three rounds, who runs each and what each holds |
| 3. `Ashgrove Credit Union strategy` | skipped | Could not have moved the CO questions: the July 2026 brief, under six months old, supplies the four points A2, E1 and H3 use |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names were given, only roles, so there was no query to form; the interviewer read is absent and the upgrade menu says what names would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The strategy brief itself → a grounding brief section and sharper CO and CASE questions; A2, E1 and H3 are built on four points from your message
- The interviewers' names, when assigned → an interviewer read, persona weights per interviewer, and a reverse question tied to each one's path
- The recruiter's detail on the 20-minute case: format, any materials, whether you get time to prepare → H1 and H2 re-fitted to the real format
- Your own answers to the answer slots, in your own words: what the monthly spreadsheet counted and what tool it was in (F3, F4), what made the complaints formal (F8), any contact with a digital team (F6) → those rows are regenerated from your words and their banks sharpen
- An anonymised page of the monthly spreadsheet, or a sample of the report → F3 and F4 can rise from medium and low, since a complaints report is the inspectable artifact in this field
- How many hours you can give to prep → a prep triage section in priority order
- The date: 29 November 2026 is a Sunday → worth confirming the day and the three start times with the recruiter
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → adds loop reports for this role family and recent organisation context; say "go deeper" and I will run it
- A tuesday-dossier.md, if you have one from earlier work → verified evidence and a named top objection instead of the ones inferred here
