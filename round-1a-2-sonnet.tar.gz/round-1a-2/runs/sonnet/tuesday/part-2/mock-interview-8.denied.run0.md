Your prep pack is saved as `ashgrove-credit-union_member-experience-lead_interview_pack.md` in your working folder. I built it as three mini-packs, one per round on 29 November, sharing one fit snapshot. It includes a values cheat sheet for the panel round. No interviewer names exist yet, so it has no interviewer read, and I didn't know your prep hours, so the triage assumes the nine days left.

- **Biggest exposure:** The pack names D1 as its highest-ROI prep. It asks how you get from one branch's complaints log to owning the process across every branch and the contact centre. It comes back in rounds 1 to 3, so rehearse it first.
- **Honest limits:** Your gaps are the contact centre and presenting above regional level. The pack coaches plain acknowledgments for both, with a plan. It never coaches claims of end-to-end ownership or coaching supervisors, because your material doesn't say either.
- **Slots to fill:** Several rows ask you to answer in your own words. They cover what governed your complaints log, what your spreadsheet tracked and whether it was Excel, who you've coached, and any work with digital teams.
- **Date check:** 29 November 2026 is a Sunday, so it's worth confirming the date with the recruiter. That's reverse question R1.5.
- **Research:** I ran no searches. Your pasted values, the recruiter's email, your strategy-brief points and the JD already covered every target.

Say the word and I'll play the Head of Member Services on D1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Loop (from the recruiter's email):** three rounds on 29 November, in this order: round 1, 30 minutes with the recruiter; round 2, 45 minutes with the Head of Member Services, who would be Dara's manager, mostly behavioural; round 3, 60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation, which is also the values round. Interviewers beyond their roles are not yet assigned, so there is no interviewer read. Built in loop mode: one shared fit snapshot, then a mini-pack per round. Question IDs run on across rounds so each is unique.

## How to use this pack

Personas describe how a question is asked. Types describe what is scored.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values, not generic virtue |
| EXP | Whether the claims in your own account survive scrutiny, and what was actually you |
| JD | A requirement stated in the job description, gaps included |
| CO | Whether you can think at Ashgrove's altitude: strategy, competitors, recent moves |
| CASE | Structure and reasoning on a live problem set in the role |

Guidance is scaffolding for a spoken answer, not a script. Where a cell says answer slot, it is an instruction for the interview: answer in your own words from what really happened, and the second branch is always allowed.

## Prep triage

No prep hours were stated, so this is sized to the nine days between 20 November and 29 November.

| Order | Do this | Tied to |
|---|---|---|
| 1 | Rehearse the scope-jump question aloud until the plain acknowledgment and the limit come out without flinching | D1, F3, F4, J1 |
| 2 | Write out your own answers to the answer slots on F2, F3, F5, F6 and F9; each takes one honest paragraph | Fit snapshot |
| 3 | Pick one real story per Ashgrove value, or decide plainly that none comes to mind, using the scaffolds | C1 to C4, G1 to G4, values cheat sheet |
| 4 | Practise the case structure aloud once on H1 and once on H4 | H1, H4 |
| 5 | Fix your real answers on pay, notice, location and reason for leaving | A3 to A6 |

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap, but a line from your message with nothing inspected behind it, so expect a probe on it. Lead with it in its own terms: six years in retail banking, the last three as a branch supervisor. Customer operations is the JD's phrase and stays out of your sentence |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [inferred] | discovery | Your material says a formal complaints log you handled, not what governed it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's wording makes a probe on what governed the log likely. If any rules or time limits applied to it, say which and how you worked to them, in your own words; if none did, or you did not know them, say so plainly and describe the log as you handled it |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | This row is the branch half; the contact centre half is F4. Your material says one branch's log, not the process across branches, and the words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end, across-branches wording makes a probe on what came before and after the log likely. If any intake, resolution or closing step was yours, say which, in your own words; if the log was the part you held, or there was no such step, say so plainly and stay with the log |
| F4 | "the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | Your material says a monthly complaints spreadsheet you built that your regional manager uses; it does not say what it tracked. The words stay at: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's monthly-reporting line makes a probe on what the sheet tracked likely. Say what it tracked, in your own words; if it did not track what the JD names, or you cannot say, say so plainly and stay with the sheet you built |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your sentence says spreadsheet, not which tool, and Excel stays out of your words until you say it. Answer slot: if the sheet was in Excel, say so and what you did in it, in your own words; if it was another tool, say which; if what you did there was limited, say so plainly |
| F7 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan. The pack's observation: your material does not say who counts as senior leaders here, which is a question for the recruiter (round 1 reverse questions) |
| F8 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says training new tellers on the escalation script, not coaching supervisors, and the words stay at that scope: "trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on who you have coached likely. If you have coached supervisors or peers on escalations, say who and how, in your own words; if you have not, say so plainly and stay with the new tellers and the script |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not mention digital teams or self-service. Answer slot: the JD's digital line makes a probe likely. If you have worked with a digital team or on an online or app journey, say what and which part was yours, in your own words; if you have not, say so plainly, then say how you would start, as a plan |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| experience handling regulated complaints | D2 |
| Own the member complaints process end to end across branches | D1, H1, J1 |
| the contact centre | B1, D1, C3, J1 |
| report monthly on complaint volumes and resolution times | E1 |
| coach branch supervisors on escalations | D4, H4 |
| work with digital teams on self-service journeys | F2 |
| confident presenting to senior leaders | D3 |
| comfortable with Excel reporting | E2 |

## Round 1: recruiter, 30 minutes

### Persona table

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through, then logistics: pay, notice, location, reason for leaving | High. A recruiter screen's prior is Conversational plus a light Skeptic, and the recruiter's own words give the round no other shape | A 90-second arc told from your own sentences; treat the casual questions as scored |
| Skeptic | Quiet knockout-style checks on the JD's gaps | Low. Light by prior, but your two stated negatives are exactly where a screen probes | Say the negative plainly, then give the plan |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Tell it in the order your sentences give: six years in retail banking, the last three as a branch supervisor; the formal complaints log you handled; the new tellers you trained on the escalation script; the monthly spreadsheet you built for the regional manager. Use these words, no further beats. Under 90 seconds | F1, F2, F5 and F8 are the evidence a recruiter has heard; EXP because it tests that your account matches what you will say again in rounds 2 and 3 |
| A2 | "What draws you to Ashgrove?" | CO | [grounded] | Choose the one of the four published values you actually recognise, name it as Ashgrove writes it, and say what it means to you in your own words. Add one line on the 2026 strategy brief only if it genuinely matters to you. The question needs no claim about your past, so the guidance makes none | Motivation consistency is scored in a screen; CO because it tests whether the homework is genuine rather than recited |
| A3 | "What are you looking for on salary?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first. The JD you supplied states no pay. Do not guess a figure you have not decided | The recruiter row's logistics question; JD because it is the listed job's terms |
| A4 | "What is your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | The recruiter row's logistics question; JD because it is the listed job's terms |
| A5 | "Where and how often can you work?" | JD | [generic] | Logistics slot: give your own constraints on where and how often you can work. Round 1's reverse questions include which site the role sits at | The recruiter row's logistics question; JD because it is the listed job's terms |
| A6 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot: give your actual reason in your own words, short and true. No reason is in your material, so the pack supplies none | The recruiter row's reason-for-leaving question; EXP because it tests consistency with your account |
| B1 | "The role covers the contact centre as well as branches. How do you see that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say it plainly: "I haven't worked in a contact centre." Then a plan, in your own words: what you would ask to see first and who you would want to learn from. Do not describe contact-centre work as something you have done | F4 is the gap; JD because the line is in the posting, and the stated negative is the only honest start |
| B2 | "Which part of this job would be hardest on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick from the two negatives you have actually stated, say it plainly, then give the plan. Do not name a weakness you have not stated and do not pick a safe one to dodge the real ones | F4 and F7 are where a screen probes first; JD because it scores the stated requirements |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Are complaints in the contact centre and in branches handled as one process today, or two?" | The JD asks for end to end across both, so this shows you read the scope |
| R1.2 | "Who will be on the panel in the third round, and could you share their names?" | Interviewers are unassigned, and names unlock an interviewer read |
| R1.3 | "Is the 20-minute case live, or is there material to read first, and what should I bring?" | Practical, and it tells you whether a prepared deliverable section is needed |
| R1.4 | "Who counts as senior leaders for the monthly reporting?" | F7 is a stated gap, and the answer sizes it |
| R1.5 | "Could you confirm the date and times for all three rounds? 29 November 2026 falls on a Sunday." | The date is derived from the calendar, and an error at this stage costs you the round |

## Round 2: Head of Member Services, 45 minutes

### Persona table

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Open "tell me about a time" prompts, STAR-shaped | High. The recruiter calls the round mostly behavioural, which lifts it above the hiring-manager prior | Story-map only where a sentence of yours carries one; otherwise pick a real instance, or say none comes to mind |
| Skeptic | Quiet probing of scope and the two stated negatives | High. A manager is derisking gaps, and yours are on the record: F3, F4, F7 | Rehearse the scope-jump answer until it is boring; bridges only from adjacent evidence; plain acknowledgments plus a plan |
| Data-Driven Prober | Reads the CV line by line, asks what the spreadsheet tracked | Medium. The spreadsheet is the one reporting artifact in your material | Know what you can and cannot say about what it tracked, and say plainly where you do not know |
| Case/Strategist | A live problem from the role's roadmap | Low. A hiring manager's prior would raise it, but the recruiter places the case in round 3 | Clarify, objective, segmentation, approach, metrics, risks; think aloud |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear, with a named stake, a moment you did not soften it, and the working relationship intact afterwards; if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A persona stem for values rounds; VAL because it tests behaviour, and a scaffold because none of your sentences carries this story |
| C2 | "Tell me about a time a problem landed on you that was not yours to fix, and what you did." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The one sentence you can stand on is the log: "I handled the branch's formal complaints log." Answer slot: Ashgrove's Own the Fix line makes a probe on whether you kept a problem until it was solved likely. If you followed a complaint through to the end, say which and what you did, in your own words; if the log was the part you held, say so plainly and stay with the log | Own the Fix is a published value; VAL because it tests that behaviour. F3 is the evidence, and the story stays at the log's scope |
| C3 | "Tell me about a time you had to learn how an unfamiliar team or channel really works." | VAL | [generic] | Selection scaffold: pick a time you had to get up to speed on something outside your usual patch, with what you did first, who you learned from, and what you got wrong; if no such time comes to mind, say so plainly, then give how you would learn the contact centre, as a plan | The JD's contact centre scope is a gap (F4); VAL because the stem tests how you ramp |
| C4 | "When did you put a member ahead of an internal metric or process?" | VAL | [generic] | Selection scaffold: pick a decision made from the member's side of the counter, with the easier route named, what you gave up, and what the member got; if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Members First, Always is a published value; the stem is a standard values question; scaffold because no sentence of yours carries it |
| D1 | "The role covers every branch and the contact centre. You have handled one branch's complaints log. How do you get from there to owning it across the organisation?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | The highest-ROI rehearsal in this pack. Three levels. First: the hold is only what the quote carries: "I handled the branch's formal complaints log." Answer slot: if any intake, resolution or closing step was yours, say which; if the log was the part you held, or there was no such step, say so plainly. Second follow-up, on the contact centre: "I haven't worked in a contact centre," then a plan in your own words. Third, on whether that is enough: concede the limit by name, and return to the log without adding to it | F3 and F4 are where the owning-end-to-end line presses hardest, so this objection arrives in some form in every round; JD because it scores the stated scope. The limit is named before it is asked for |
| D2 | "The JD asks for experience handling regulated complaints. What did the log you handled have to comply with?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what you handled first: "I handled the branch's formal complaints log." Answer slot: if any rules or time limits applied to it, say which and how you worked to them, in your own words; if none did, or you did not know them, say so plainly and describe the log as you handled it. Never name a regime you cannot speak to | F2 is the evidence and the JD's wording is stronger than the quote, so it is probed; JD because it scores a stated requirement |
| D3 | "How confident are you presenting to senior leaders?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I've never presented to anyone above regional level." Then a plan, in your own words, for how you would prepare a first presentation to senior leaders. Do not claim confidence you have not tested | F7 is a stated gap; JD because the requirement is in the posting |
| D4 | "Tell me about a time you helped a colleague handle an escalation better." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Beats the sentence states: you trained new tellers, on the escalation script. Say that in your own words. Answer slot: the JD's coaching line makes a probe on who else you have coached likely. If you coached supervisors or peers, say who and how; if you have not, say so plainly and stay with the new tellers and the script | F8 is the evidence and is adjacent, not equal, to coaching supervisors; EXP because it tests what was actually yours |
| E1 | "Walk me through what your monthly complaints spreadsheet tracked." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start with the sentence: you built it, monthly, and your regional manager uses it. Answer slot: say what it tracked, in your own words; if you cannot say, or it did not track what the JD names, say so plainly and stay with the sheet you built. The pack names no field or count for you | F5 is the evidence; EXP because the prober's question is what was counted and what was yours |
| E2 | "Which tools do you build reports in, and where are your limits?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if the sheet was in Excel, say so and what you did in it; if another tool, say which; say your limits plainly, in your own words. A named limit scores better than a claim of comfort | F6 is the evidence and the JD says Excel, which your sentence does not; JD because it scores a stated requirement |
| F1 | "Sketch how you would find out what is really happening to complaints across the branches and the contact centre in your first month. What do you need to know first?" | CASE | [generic] | Clarify first: what counts as a complaint, where each is logged, who holds each stage. Then objective, segmentation (branch, channel, complaint type), approach, what you would measure, risks. Think aloud and challenge one premise politely. No claim about your past is needed | A persona stem for strategist rounds; CASE because it is a live problem from the JD's own scope |
| F2 | "Ashgrove wants 40% of member service on digital channels by 2028. Which complaints should never be self-service?" | CO | [grounded] | The brief is public, so every prepared candidate has the 40% figure: say it once, to show grounding. Then your own divergence, with reasons: name the complaint types you would keep with a person, and the test you would use. Where the JD's digital line touches you, F9 is an answer slot, not a story | The 2026 strategy brief makes this a likely CO question and the JD asks for work with digital teams; CO because it tests the company's altitude |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What would a good six months look like for this role, and what would you want to see in the first monthly report?" | Ties the role's reporting duty to your manager's own measure of success |
| R2.2 | "Who owns complaints in the contact centre today, and how would we work together?" | Names your biggest gap and asks for the way in |
| R2.3 | "As more service moves to digital channels, which complaints do you expect to stay with people?" | Shows you read the strategy and invites their view rather than reciting yours |
| R2.4 | "Who receives the monthly report, and what do they ask for?" | Sizes F7 and prepares your first presentation |
| R2.5 | "What would you want me to learn first in my first month?" | Turns the gap into a joint plan |

## Round 3: panel of two branch managers, 60 minutes, including a 20-minute case

### Persona table

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenarios mapped to the four published values | Top. The recruiter says the panel is also the values round and scores against the four values | A mapped story where a sentence of yours carries one, a selection scaffold otherwise; "we" for context, "I" for what you did |
| Case/Strategist | The 20-minute escalation case, plus strategy questions | High. The recruiter names the case, and the strategy brief gives the panel material | Clarify, objective, segmentation, approach, metrics, risks; say the structure aloud |
| Peer Evaluator | Seam questions: where your team meets their branches | Medium. The role coaches supervisors in branches, so the seam between your team and theirs is their natural question; recalibrate if you learn otherwise | Reciprocity first: what you bring their branch; propose seam principles |
| Skeptic | The scope objection returns in a branch manager's voice | Low. Reasoned, not signalled: the same objection from rounds 1 and 2 | The same hold and plain acknowledgments as D1 |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell us about a decision you made from the member's side of the counter that was not the easy one." | VAL | [generic] | Selection scaffold: pick a decision where the member's interest and the easier route pointed apart, with what the easier route was, what you decided, and what the member got; if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Members First, Always is a published value and is scored; scaffold because no sentence of yours carries it |
| G2 | "Tell us about a time you explained something to a member or colleague more than once, and what you changed." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The sentence supports training new tellers on the script: "trained new tellers on our escalation script." Answer slot: Plain Words says needing it explained twice means the wording failed. If any wording of the script was yours to change, say what and why; if you taught it as written, say so plainly and stay with the training | Plain Words is a published value; F8 is the only evidence in reach and is about training |
| G3 | "Tell us how you have kept a branch's own town in mind when a decision was made elsewhere." | VAL | [generic] | Selection scaffold: pick a time a decision from head office or the region affected your branch's community, with what you did, who you spoke to, and what changed; if no such time comes to mind, say so plainly, then give how you would handle it | Neighbours, Not Numbers is a published value, and the 2027 hub changes make it live; scaffold because no sentence of yours carries it |
| G4 | "Tell us about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The sentence supports the log: "I handled the branch's formal complaints log." Answer slot: Own the Fix says whoever finds the problem keeps it until it is solved. If you followed any complaint through to the end, say which and what you did; if others solved them and you held the log, say so plainly and stay with the log | Own the Fix is a published value; F3 is the evidence and holds only at the log's scope |
| H1 | "A member has raised the same complaint about a fee at their branch, then with the contact centre, and was told something different each time. The supervisor escalates it to you late on a Friday. Walk us through the next hour, and the next month." | CASE | [generic] | Clarify first: what the member was told each time and by whom, what has been logged, any time limit running. Then the objective, the member first, then segment the fix: this member now, this pattern in both channels, the supervisor's escalation. Metrics and risks last. Say it in plain words, since Plain Words is scored. No claim about your past is needed | The 20-minute escalation case is named by the recruiter; CASE because it is a live problem in the role; generic because the case content is not yet known |
| H2 | "Over 2027, eight branches become five hubs. How do you make sure a member of a branch that merges still gets heard, and still feels their branch counted?" | CO | [grounded] | Ground in the brief's own point, then give your approach: how complaints from a merging branch stay visible through the change, and how a member can tell someone is holding theirs. No claim about your past is needed | The brief's consolidation plan meets Neighbours, Not Numbers, and the panel are branch managers; whether their own branches merge is not known |
| H3 | "App-only banks are Ashgrove's main competitive pressure. What does a complaint handled well do for a member that an app cannot?" | CO | [grounded] | The brief is public, so name the competitive point once, then your own thesis with a concession: where an app is faster, and where a person is the point. Keep it in plain words | The brief names app-only banks as the main pressure; CO because it tests whether you can think at the company's altitude |
| H4 | "A branch supervisor tells you she escalates as little as she can because it makes her branch look bad. What do you do?" | CASE | [generic] | Clarify what she means and what she has seen happen. Then objective, the member first; what you would say to her; what you would change in how branches are seen when they escalate. Think aloud; challenge one premise respectfully. Guidance makes no claim about your past | The JD's coaching line, set as a live problem; CASE because it tests structure, and the panel are branch managers who know the pressure |
| I1 | "Our branches and your team sit side by side. Where is the seam, and what happens when we disagree about an escalation?" | CASE | [generic] | Reciprocity first: what you bring a branch, not only what you need from it. Then two or three principles for the seam rather than a claimed map of it, and how you would handle disagreement: say what you think, hear theirs, agree who decides | A peer evaluator's stem; CASE because it is a live scenario about the working seam |
| I2 | "Tell us about a time work spanned teams and you had to share credit or blame." | EXP | [generic] | Selection scaffold: pick a time work crossed teams, with who did what, how credit or blame was shared, and the relationship afterwards; if no such time comes to mind, say so plainly, then give how you would handle it | A peer evaluator's stem on credit; the scaffold because no sentence of yours carries it |
| J1 | "Branches are the heart of Ashgrove. What makes you think someone who has handled one branch's log, and has not worked in the contact centre, can hold all of them?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold what the quote carries: "I handled the branch's formal complaints log." Plain acknowledgment: "I haven't worked in a contact centre." Then the plan, in your own words. Hold through two follow-ups by returning to the log, never by adding to it; concede the limit by name | The D1 objection in a branch manager's voice; JD because it scores the stated scope. F3 and F4 are the evidence |

### Values cheat sheet

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decisions are made from the member's side of the counter | Selection scaffold, G1 and C4: pick a decision made from the member's side when the easier route lay elsewhere, with a named stake; if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it |
| Plain Words | If a member needs something explained twice, the wording was at fault | F8: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Beat: you trained new tellers on the script. Answer slot: if any wording of the script was yours to change, say what and why; if you taught it as written, say so plainly and stay with the training |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold, G3: pick a time a decision made elsewhere touched your branch's community, with what you did and who you spoke to; if no such time comes to mind, say so plainly, then give how you would handle it |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | F3: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Beat: you handled the log. Answer slot: if you followed any complaint through to the end, say which and what you did; if the log was the part you held, say so plainly and stay with the log |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "How does a complaint from your branch reach the centre today, and where does it get stuck?" | Asks for their seat's view of the process the role would own |
| R3.2 | "How will complaints be tracked through the branch changes in 2027?" | Shows you read the consolidation plan without assuming anything about their branches |
| R3.3 | "What could a new person in this role do in their first month that would genuinely help your branch?" | Reciprocity: makes you a colleague, not a supplicant |
| R3.4 | "Which of the four values is hardest to live by on a busy day in your branch?" | Invites a real answer and tells you what the panel will test |
| R3.5 | "What would make you say, from a branch manager's seat, that the complaints process is working?" | Turns their scoring criterion into your plan |

## Grounding brief

The July 2026 strategy brief, as you summarised it, in four points. This is what your message supplied, not the full document.

| Brief item | Pack questions that use it | Provenance |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | F2 | [grounded] |
| "consolidate eight branches into five hubs over 2027" | H2, R3.2 | [grounded] |
| "launch a small-business lending product in Q1 2027" | none yet; ask the recruiter (R2.1 can carry it) | [grounded] |
| "the main competitive pressure is app-only banks" | H3 | [grounded] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F3 | F3's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says one branch's log, not the process across branches |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says a formal log, not what governed it. D2's slot stays inside the log |
| Coached branch supervisors on escalations | Inflated form of F8 | F8's quote at its own scope: "trained new tellers on our escalation script." |
| Reported complaint volumes and resolution times each month | Inflated form of F5 | F5's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." E1's slot asks only what it tracked |
| Has worked in a contact centre | Negative the candidate stated, F4 | The plain acknowledgment F4 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I've never presented to anyone above regional level." No slot |

## Sources

Provided documents: the job description pasted in your message; the four Ashgrove values pasted in your message, copied by you from ashgrovecu.org/about/values on 20 November 2026; the recruiter's email on the three rounds; your summary of Ashgrove's July 2026 strategy brief; your own account of your background. No `tuesday-dossier.md` was present. No search or fetch was sent, and no link was read.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the values cheat sheet: the pasted page supplies all four values by name |
| 2. `Ashgrove Credit Union interview process member services` | skipped | Could not have moved the persona weights or round structure: the recruiter's email names the rounds, who runs each, and the case |
| 3. `Ashgrove Credit Union strategy` | skipped | Could not have moved the CO bank: the four brief points you supplied, from July 2026, already supply current priorities |
| 4. `interviewer name Ashgrove Credit Union` | n/a | No names were given, so there was no query to form; the interviewer read is absent, and the upgrade menu says what names would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names, once assigned → an interviewer read per round, persona weights read from their public footprint, and a reverse question tied to their own path
- The full text of the July 2026 strategy brief → the grounding brief gains its headline figures and wording, and the small-business lending point gets a question
- Your CV → the fit rows resting only on four sentences from your message gain CV lines, and more of the CO and EXP rows become story-mapped
- Your own answers to the slots on F2, F3, F5, F6, F8 and F9, written outside a drill → each row regenerates with your words quoted in, and its bridge firms up
- The recruiter's answer on whether the case is live or has a pre-read → if a deliverable is announced, a build section is added
- Hours you can give to prep each day → the triage is resized to your time
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, covering a fuller strategy read, recent organisation context and reports of this loop → CO and CASE rows lose their generic labels where sources support them
- A `tuesday-dossier.md` → verified evidence and the objections prep exposed, carried into later sessions without being re-asked
