Your prep pack is saved as `stripe_product-operations-manager_interview_pack.md`. I built it for a final round with no known schedule, flat persona weights, and no CV or job description. My web searches were refused, so the pack has no Stripe-specific facts, values or strategy, and nothing in it comes from memory. It holds 19 questions across seven interviewer styles, plus reverse questions, a requirement-coverage table and an upgrade menu.

Say the word and I'll play the Skeptic on B1, "Why this role, why Stripe, why now?", which the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting in the final round, and is it one session or several back to back? The answer reweights every bank.
Can you paste your CV and the job description, or tell me to proceed without them? With them, the generic scaffolds become answers built from your own sentences.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

**Round:** final round. Interviewer names, relationship to you and the number of sessions are not known, so persona weights are flat (section 3).
**Built on:** no CV, no job description, and no web research (all four searches were refused). Everything below is labeled `[generic]` because it is a pattern for the role, not a fact about Stripe or about you.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Answer guidance is scaffolding, not a script: where it asks for a story, the story has to be one you actually lived, in your own words.

| Type | What it tests |
|---|---|
| VAL | Whether past behavior shows the company's published values, not generic virtue |
| EXP | Whether claims about your work survive scrutiny, and what was actually yours |
| JD | The responsibilities of the role, including where you are thinnest |
| CO | Company and strategy knowledge, and whether you think at the company's altitude |
| CASE | A live problem from the role, scored on structure more than on the answer |

## 2. Fit snapshot (worksheet variant)

No CV was given, so every evidence cell reads `none given`. The requirements are role-family patterns for product operations written as plain prose, not quotes from a posting. Each bridge says what strong evidence would look like, then gives a selection scaffold. When you paste your CV, these rows become quotes from it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run launches or operating processes across product, engineering and go-to-market teams (role-family pattern, no posting supplied) | none given | none | [generic] | discovery | Strong evidence is one sentence of yours naming what you ran, with whom, and what happened. Pick one launch or process you were close to; it needs a named stake and an outcome you can explain. If no such instance comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Define and track product or operations metrics and act on them (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a figure you can explain from numerator to denominator. Pick one metric you tracked and know how it was counted. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Build or improve a repeatable process or tool that other teams used (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a process you built or changed, who used it, and what you know about whether it stuck. If no instance comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Communicate status, risks and decisions to senior leaders (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a moment you told a senior audience something they did not want to hear, and what followed. If no such moment comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Influence teams you do not manage (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a disagreement with an equal that ended with the relationship intact. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Prioritize competing requests with limited capacity (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a time you said no or not yet, how you decided, and how it landed. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## 3. Persona table

Weights are flat, and the reasoning is shown so you can correct it if you know more. No row of the relationship priors applies, because the relationship is unknown. There is no interviewer profile to adjust the weights. No loop source was read, since research was refused and "final round" alone establishes no sessions. The fallback archetype is Generic (screen, hiring manager, panel), which tilts nothing. A final round is likely to put several of these styles in front of you, so every style gets a bank. Ties are ordered by how often a hiring-manager or panel round leans on them.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|
| A. Case / Strategist | Live problems: plan this, diagnose that | Medium-high; a role about running processes invites live problems, but the format is unconfirmed | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise politely |
| B. Skeptic | Quiet probing of motive and weakest areas | Medium-high; final rounds usually test why this role and why now | Rehearse the motivation answer until it is boring; build bridges only from things you did |
| C. Values / Behavioral | Scenario probes, STAR stories | Medium; guaranteed somewhere only if a loop source documents a values round, and none was read | One true story per theme; "we" for context, "I" for your contribution |
| D. Peer Evaluator | Seam-splitting, credit, collaboration | Medium; the role works across teams, so a cross-team interviewer is plausible | Offer principles for the seam, not a pretended knowledge of it; show what you bring them |
| E. Data-Driven Prober | Numbers probed to their assumptions | Medium; product ops is metric-heavy | Know how each figure was counted and say plainly when you do not |
| F. Pressure | Interruptions, time-boxes, devil's advocate | Lower; tests composure | Pause, restate, hold a position through two follow-ups, concede only what is real |
| G. Conversational | Friendly, unstructured, still scored | Lower; casual openers recur in any round | A 90-second arc for "walk me through the journey"; never "I think you've covered everything" |

## 4. Question banks

All rows are `[generic]`: none rests on a sentence of yours, because none was given. Every guidance cell is a method. Where a story would go, it is a selection scaffold ending in the honest branch.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A feature launches in two weeks and three teams say they were never consulted. What do you do first?" | CASE | [generic] | Ask before acting: who owns the launch, what each team needs, what is actually at risk. State the objective, sort the three teams by impact, propose a first conversation and a way to prevent a repeat. Challenge one premise, such as whether the complaint is about the launch or about the process. The question asks about no past of yours, so the guidance makes no claim | Live cross-team problem typical of the role family (F1, F5); CASE because it scores structure, not a recalled story |
| A2 | "Adoption of a feature that shipped last quarter is 20% below plan. Diagnose it." | CASE | [generic] | Clarify what plan, what adoption and over what window. Split into reach, activation and retention. List two or three hypotheses you could test fastest and the data each needs. Say what you would not conclude yet | Metric-diagnosis case, a standard persona stem; supports F2 |
| A3 | "Sketch the operating rhythm for a product org that has none: what reviews, what escalation, what do you need to know first?" | CASE | [generic] | Begin with questions: team size, launch cadence, current pain. Then purpose before mechanism: what decisions the rhythm must speed up. Propose the lightest version that serves them and how you would judge whether it earned its cost | Process-design case (F1, F3); tests whether you ask before you build |
| A4 | "Five teams each want your help this quarter and you can serve two. How do you choose?" | CASE | [generic] | Name criteria before ranking: impact, urgency, who else could do it, cost of delay. Say how you would communicate the three declined requests. Show the trade-off, not a formula | Prioritization case (F6); the communication part tests influence without authority |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why this role, why Stripe, why now?" | CO | [generic] | The highest-ROI rehearsal in this pack (see section 5). Three parts, each in your own words: what draws you to product operations as work, what draws you to this company (from official sources you read yourself; I could not supply any), and why now. If one part has no honest answer yet, say so plainly and give the parts that are true. Hold it through two follow-ups by returning to what you actually said | A final round tests motive consistency; CO because company knowledge is half of it. I could not infer the single objection specific to you without your CV, so this is the most universal one |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one real gap in a sentence, then a concrete ramp plan: what you would read, who you would ask, what you would do in the first weeks. Candor beats bluffing a skill the interviewer may own. If you cannot name a gap, say what you have not yet had the chance to do | Persona stem; aims at the thin rows of the snapshot (F1 to F6) |
| B3 | "What do you do in your first 90 days?" | CASE | [generic] | Learn, then map, then one early win. Say what you would ask each stakeholder, what you would hold back from changing, and how you would know you were on track. A plan, not a past | Common final-round question that scores judgment about sequencing |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and a relationship still intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Use "we" for context, "I" for what you did | Persona stem supporting F4; no published Stripe values were read, so I cannot map it to one |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: the choice, what the metric cost, who noticed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; customer-first themes recur, but I could not confirm Stripe's own wording |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Offer principles, not a pretended map: who owns the decision, who owns the outcome, when to escalate. Say how you would raise a disagreement early and privately. Do not claim to know their seam | Persona stem; F5 |
| D2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: one piece of shared work where you can say who did what. If no instance comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; attribution honesty (F5) |
| D3 | "What would you need from me in your first month?" | JD | [generic] | Reciprocity: name two things you would ask for, then what you could take off their plate. Keep it to what you could honestly deliver | Persona stem; tests whether you add or add load |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Choose a number from your work that you would stand behind. Walk me through how it was counted." | EXP | [generic] | Slots a figure raises: how it was counted, what it is sensitive to, which part was yours. Say each in your own words. If you do not know how it was counted, say so plainly. If no figure comes to mind, say so and describe what you tracked instead | Persona stem; F2. I cannot see your figures, so the pack names none |
| E2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name the assumption yourself before they do, in your own words. If you do not know of one, say so plainly | Converts a gotcha into a credibility gain |
| E3 | "Pick three metrics to judge whether launches are going well. What would each one miss?" | CASE | [generic] | Say what decision each metric serves, then the blind spot of each, then how a fourth would compensate. A framework, not a claim about your past | Metric-design case (F2); no past presupposed |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you for this role?" | JD | [generic] | Pause, restate the question, then three beats of your own: what you did, what you can do here, what you are still learning. Hold your position through two follow-ups and concede only what is real | Persona stem; time-boxed version of B1 |
| F2 | "Pick a result you would claim. How much of it was actually you?" | EXP | [generic] | Hold, then concede: say exactly what was yours, stay there through two follow-ups, concede what was not. If you cannot separate your part, say so plainly. Never fold on what you did just to restore harmony | Persona stem; attribution probe (F1, F2) |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc made only of things you did: where you started, the turns, why this role next. I cannot map beats without your CV; build it from your own résumé lines, and cut any beat you could not defend if asked | Persona stem; casual-register questions are still scored |
| G2 | "What has caught your attention recently about the company?" | CO | [generic] | Answer from your own reading of official sources; I could not supply any, and a borrowed fact is what a follow-up exposes. If nothing comes to mind, say so plainly and do the reading first | Rapport-style CO probe; tests genuine interest |

## 5. Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Run launches or operating processes | A1, A3 |
| F2 Define and track metrics | A2, E1, E2, E3 |
| F3 Build repeatable process or tool | A3, B3 |
| F4 Communicate to senior leaders | C1 |
| F5 Influence without authority | A1, D1, D2, D3 |
| F6 Prioritize competing requests | A4 |

The highest-ROI prep is B1, "Why this role, why Stripe, why now?" Without your CV or a posting, I could not derive the objection specific to you, so this is the most universal one, not a finding about your candidacy.

## 6. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would make someone in this role clearly successful six months in?" | Shows you think in outcomes, and tells you what is actually scored |
| R2 | "Where does product operations stop and the product team start here, and where is that line contested?" | Raises the seam before it surfaces, and signals you plan to work across it |
| R3 | "What is the hardest cross-team problem this role would inherit?" | Invites a real answer and shows readiness for the unglamorous part |
| R4 | "How do you decide which launches get operational support and which do not?" | Shows you see prioritization as the core of the job |
| R5 | "What have you changed your mind about in the last year about how teams here work?" | Turns an interrogation into a peer conversation |
| R6 | "What would you want a new person to do in the first month that would help your team?" | Reciprocity question, strongest if the interviewer is a peer |

## 7. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Nothing listed | No candidate material was given, so there is no sentence of yours to inflate | Rehearse only what you actually did. When you share your CV, this section is built from it |

## 8. Sources

Provided documents: none.

Searches sent (all refused, nothing returned):

- `Stripe operating principles values`: refused
- `Stripe interview process product operations manager`: refused
- `Stripe strategy news 2026`: refused
- `Stripe Product Operations Manager job description`: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Search refused. Would have supplied official value names for a values cheat sheet; none is written, and nothing is taken from memory |
| 2. `{company} interview process {role family}` | unavailable | Search refused. Would have shown the loop's rounds; weights fall back to the Generic archetype |
| 3. `{company} strategy` / recent news | unavailable | Search refused. Would have grounded the CO bank; CO rows are generic |
| 4. `{interviewer name} {company}` | n/a | No name was given |
| 5. representative `{role title}` JD | unavailable | Search refused. Would have turned the role-family rows into quoted requirements |

## 9. Upgrade menu

- Search access → official values, documented loop structure and current strategy; CO rows become grounded and a values cheat sheet appears if a source documents a values round
- Your CV → fit rows hold your own quoted sentences, selection scaffolds become story-mapped answers, and every figure gets a defend-the-number row
- The job description → requirement rows become quotes, the coverage table follows its own list, and JD rows become grounded
- Interviewer names, relationships and the schedule of your final round → per-person persona weights and a reverse question tied to each interviewer's path; if your final is several sessions, send the schedule and I'll build a mini-pack per session
- The recruiter's guidance on focus areas or any pre-declared deliverable → coverage of that exact content, usually one email
- Time available before the interview → a prioritized prep schedule
- A `tuesday-dossier.md` from earlier work → verified evidence, prohibited claims, and an evidence-derived top objection in place of the guessed one
