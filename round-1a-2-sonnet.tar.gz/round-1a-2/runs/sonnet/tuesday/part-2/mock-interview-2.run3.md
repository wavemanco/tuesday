I'm building your prep pack. The company searches were refused, so it's built only from what you pasted.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/tuesday/part-2/rooms/case-2-denied-5f4206b7/atlas-freight_operations-manager_interview_pack.md`.

I built it as a full-loop pack with flat persona weights, because your note didn't say which round this is or who you're meeting. The three company searches (values, interview process, strategy) were refused. So nothing in the pack is researched, and the company and strategy questions (F3, D1 to D3) are generic. They are labeled that way.

The pack has 22 questions across seven interviewer styles, and every JD requirement is covered. It also has a fit snapshot, a list of claims it won't coach you to make, and a table of what each missing input would unlock.

The one to rehearse first is E2: "You have three supervisors today and this role has twelve across four sites. What makes you think you can run that?" The gap between 3 and 12, and between one site and four, is the most predictable objection. Power BI is the clearest stated gap, and the pack has you say so plainly rather than work around it.

Say the word and I'll play the Skeptic on E2 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is this a recruiter screen, a hiring-manager round or a panel, and do you know whether the person is your future manager or a peer? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack — Operations Manager, Atlas Freight

- Role: Operations Manager, Atlas Freight (JD: "regional logistics, 800 employees")
- Interviewer: not known. Round type and relationship: not known.
- Built on one assumption: with no round type and no interviewer, every persona gets a bank and the weights are flat. That is a noticeably weaker pack than one for a known round, and the round question in the chat message would restructure it.

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Guidance is scaffolding, not a script. An answer slot is an instruction for the interview, not a question for me: answer it truthfully from your own experience, in your own words, and either branch is a good answer.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether the experience on your CV survives scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage

You said the interview is next week. Do these in order and stop when time runs out.

1. E2, aloud, until it is boring. It is the highest-ROI prep in this pack. Include its follow-ups.
2. A1 and B2: write your own answers to the four slots on the 40% figure.
3. E3, E4 and B3: say each honest-limit answer out loud once.
4. D1 to D3: one aloud pass each, using the structure in the guidance.
5. F1 (your 90-second arc), F3 (company homework) and the reverse questions.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "ran the site's peak-season surge plan two years running" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says the site's surge plan and a shift role. It does not show four sites or terminal operations, and the words stay at that scope: "I ran the site's peak-season surge plan two years running." Answer slot: the JD's four-site line makes a probe on your reach likely. If you have worked across more than one site or beyond your own shift, say how, in your own words; if not, say so plainly and stay with the site you ran the plan for |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material says the mis-pick rate, not on-time performance or cost per shipment, and the words stay there: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: the JD's two measures make a probe on what you tracked likely. If you tracked either at your site, say which and what you tracked, in your own words; if you tracked neither, say so plainly and stay with the mis-pick rate. The 40% raises its own four slots in A1 |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says 3 supervisors and the JD says 12, and the words stay at 3: "I'm currently a senior shift manager over 3 supervisors." The JD's twelve makes a probe on span likely (E2). Answer slot: if you have covered or overseen more supervisors than your own 3, say so, in your own words; if not, say so plainly and stay with the 3 |
| F4 | "build reporting in Excel/Power BI" — JD (Excel part) | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" touches the requirement but does not show what it was used for, and the bridge should not be stretched. Answer slot: the JD's reporting line makes a probe on what you have done in Excel likely. If you can say what you used it for, say so in your own words and at that scope; if there is nothing specific to say, say so plainly and stay with "solid Excel" |
| F5 | "build reporting in Excel/Power BI" — JD (Power BI part) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [inferred] | discovery | Your material says seven years in operations and a current role over 3 supervisors; it does not show how many of the seven years had you responsible for others. A titled-years line is likely screened literally, a reading from the posting's wording. Answer slot: if you can say how many years you held supervisor or manager responsibility, give the number as it is, in your own words; if that is fewer than the posting's five, say so plainly and stay with the seven years and your current role |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a certification with nothing inspected behind it, so expect a probe on it. Lead with it in the quote's own terms: "I'm green belt certified." Answer slot: if you used any Lean or Six Sigma tools on the pick-path redesign, say which, in your own words; if you used none, or the two were unrelated, say so plainly and stay with the certification |

## Persona table

Weights are flat. Reasoning: no round type, no interviewer and no loop source (the company searches were refused), so this pack falls back to the generic archetype, screen then hiring manager then panel, with flat weights. If you learn the round, the weights change.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | Reads the CV line by line; asks how each number was counted | flat — round unknown; the 40% figure (F2) is the obvious target for this style | Know what you can and cannot say about how the figure was counted; name the assumption you would defend least before they do (A1, A2, A3) |
| B. Pressure / Stress | Interrupts, time-boxes, tests composure | flat — round unknown | Pause, restate the question, hold the position your own words carry through two follow-ups, concede specifically (B1, B2, B3) |
| C. Values / Behavioral | Scenario prompts; wants a specific story | flat — round unknown; no published values were found, so these banks are generic | Choose stories where the hard truth landed; "we" for context, "I" for contribution (C1, C2, C3) |
| D. Case / Strategist | Live problems from the role | flat — round unknown; the JD's four sites and two measures give the problem material | Clarify, objective, segmentation, approach, metrics, risks; think aloud (D1, D2, D3) |
| E. Skeptic | Quiet, persistent probing of the gaps | flat — round unknown; F3, F5 and F6 are where this style would press | Rehearse the predictable objection until it is boring; calibrated candor over bluffing (E1, E2, E3, E4) |
| F. Conversational / Rapport | Friendly, chatty; still scored | flat — round unknown | A scripted 90-second arc; treat casual questions on JD topics as scored (F1, F2, F3) |
| G. Peer Evaluator | Seam-splitting, collaboration, credit | flat — round unknown | Reciprocity framing; seam principles, not a pretended knowledge of the seam (G1, G2, G3) |

## Question banks

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say it at the quote's scope: "I cut the mis-pick rate 40% by redesigning the pick path." Then the four slots a figure raises, each in your own words. How it was counted: say what you know; if you do not know, say that plainly. What it is sensitive to: say what you know, or say you do not. The assumption you would defend least: name it before they ask, if you know one. Which part was yours: say so exactly. Add no method, baseline or period you could not repeat under a second question | F2 holds your one quantified claim, so it is a magnet for this style. EXP because it tests whether the number survives and what was yours |
| A2 | "On-time performance and cost-per-shipment are the two measures this role drives down. What have you tracked at your site?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you tracked either one, say which and what you tracked, in your own words; if you tracked neither, say so plainly and stay with the mis-pick rate: "I cut the mis-pick rate 40% by redesigning the pick path." Put no number on either measure that you cannot source | F2 is the distance between the JD's two measures and your evidence. JD because it scores the posting's headline line |
| A3 | "What do you actually use Excel for day to day?" | JD | [grounded] "solid Excel" | Say what the quote says: "solid Excel". Answer slot: if you can say what you used it for, say so in your own words and at that scope; if there is nothing specific to say, say so plainly and stay with "solid Excel". Name only what you actually did | F4 is thin evidence against a duty the JD names. JD because it scores a stated requirement |

### B. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "7 years in warehouse and distribution ops"; "ran the site's peak-season surge plan two years running"; "green belt certified"; "never used Power BI" | Pause, restate the question, then hold the position the quotes carry: "I have 7 years in warehouse and distribution ops, I ran the site's peak-season surge plan two years running, and I'm green belt certified." Hold it through two follow-ups by returning to those facts, never by adding to them. If pressed on tools, concede plainly: "I've never used Power BI." Do not claim to know their operation better than the people who run it | This style tests composure under a comparison. F6, F1 and F7 carry the facts and F5 the concession. JD because it scores fit to the posting |
| B2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold what the quote carries: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: say which part of the redesign was yours and who else was involved, in your own words; if it was shared, or you do not know how the credit divides, say so plainly and describe only what you did. Hold through two follow-ups by returning to your own part; concede exactly the part that was not yours and keep the rest | F2's number asked as an attribution test. EXP because attribution is what is scored |
| B3 | "Reporting here is built in Power BI. What's your experience with it?" | JD | [grounded] "never used Power BI"; "solid Excel" | Say it plainly and early: "I've never used Power BI." Then, in your own words, how you would learn it, as a plan and never as a past; a step you take before the interview becomes a fact only once you have done it. Stay with "solid Excel" at its scope rather than comparing the two tools | F5 is a stated gap and the JD names the tool. JD because it scores a stated requirement; the guidance is a concession, not a defence |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and a relationship still intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The pack supplies no beats because it does not know your story | A common behavioral probe for any manager role. VAL because it tests behavior; generic because no published values were found |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision with a named customer, a named metric you let slip, and a result you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A common behavioral probe for a service operation. VAL because it tests behavior; generic for the same reason as C1 |
| C3 | "Walk me through how you ran the site's peak-season surge plan." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Story-mapped on F1: the surge plan and the two years running, which are the beats the quote states; tell them in your own words. Answer slot: a probe on which calls in the plan were yours is likely. If any were yours to make, say which and how you made them; if the plan was set by others, or there was no such decision, say so plainly and describe how you ran it. Add no volumes, dates or headcount you did not give | F1 is your strongest evidence for operating at scale, so expect it to be opened up. EXP because it tests what was actually yours |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You take over four terminals and on-time performance is slipping at one. Where do you start, and what do you need to know first?" | CASE | [generic] | Clarify first: what late means here and how it is measured, which shipments, since when. Then objective, segmentation (by lane, shift, customer, cause), approach, the metrics you would watch, and risks. Think aloud and challenge one premise respectfully. The question asks about no past, so the guidance makes none | A live problem built from the JD's four sites and on-time line (F1, F2). CASE because it scores structure |
| D2 | "Cost-per-shipment is up on last quarter. Diagnose it." | CASE | [generic] | Clarify what is in the measure and what changed. Split cost from volume and mix, then by site, shift and cost line; say which cut you would run first and why. State what would change your mind. No claim about your past | A live problem from the JD's cost line (F2). CASE because it scores reasoning, not the right answer |
| D3 | "You have twelve supervisors, four sites and a volume surge six weeks out. How do you decide where each supervisor goes?" | CASE | [generic] | Clarify the forecast and what is fixed. State your principles for allocation, how you would check the plan against each site's constraints, and what you would revisit weekly. The question needs no claim about your past, so the guidance makes none | Combines the JD's twelve supervisors and four sites (F1, F3) with a surge, as a decision. CASE because it is a live allocation problem |

### E. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI"; "currently a senior shift manager over 3 supervisors" | Name one weakness plainly before they do, then a ramp plan in future tense, in your own words. Your material gives two you can state from your own words: the tool ("I've never used Power BI") and the team size ("I'm currently a senior shift manager over 3 supervisors", against the JD's 12). Choose the one you would stand behind. Do not offer a weakness you do not have, or a strength dressed as one | F5 and F3 are the two gaps the material states. JD because it scores the posting's requirements, delivered skeptically |
| E2 | "You have three supervisors today and this role has twelve across four sites. What makes you think you can run that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | The highest-ROI rehearsal in this pack. Name the limit before they ask: "Today it's three supervisors; the role is twelve." Hold only what the quotes carry: "I'm currently a senior shift manager over 3 supervisors, and I ran the site's peak-season surge plan two years running." Follow-up one, "that's one site": answer slot: if you have worked across more than one site or beyond your own shift, say how, in your own words; if not, say so plainly and say how you would learn the other three sites, as a plan. Follow-up two, "what would you want from the twelve in the first month": a plan in your own words, no past. Hold through both by returning to the quotes, never by adding to them | F3 and F1 are where the posting presses hardest, so this objection arrives in some form. JD because it scores the stated requirement |
| E3 | "This role runs terminals. Your background is warehouse and distribution. Where does that carry over, and where doesn't it?" | JD | [grounded] "7 years in warehouse and distribution ops" | Say what the quote says: "I have 7 years in warehouse and distribution ops." Answer slot: the JD's terminal-operations line makes a probe on what a terminal asks of you that your background has not likely. If you have worked in or alongside terminal operations, say how, in your own words; if not, say so plainly and say what you would ask on the first day. Do not assert differences between the two settings that you have not seen | F1 shows warehouse and distribution work and not terminal operations. JD because it scores fit to the stated role |
| E4 | "Five-plus years of operations leadership is required here. How many of your seven years had you responsible for other people's work?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot: give the number of years you held supervisor or manager responsibility, as it is, in your own words; if that is fewer than five, say so plainly and stay with the seven years and your current role: "I'm currently a senior shift manager over 3 supervisors." Do not round up | F6 is a discovery gap and a titled-years line is likely read literally. JD because it scores a stated requirement |

### F. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | A 90-second arc built only from what the quotes state: seven years in warehouse and distribution ops, now a senior shift manager over 3 supervisors, and the two pieces of work you lean on, the pick-path redesign and the surge plan. Answer slot: if there were turning points between the early years and your current role, say which, in your own words; if there were none worth naming, say so and move on. Finish with your own reason for wanting a role this size, in your own words | Opening question in friendly rounds; scored for economy. F1, F2 and F3 supply the arc. EXP because it tests the CV story |
| F2 | "What are you actually playing with in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified"; "cut mis-pick rate 40% by redesigning the pick path" | Start with the quote: "I'm green belt certified." Answer slot: if you are applying any of it to something now, say what, in your own words; if you are not currently using it, say so plainly and stay with the certification. If asked whether the pick-path redesign used it, say which tools it used if it did; if it did not, say so plainly | A casual question on a JD plus-skill is still scored. F7 carries the certification. JD because it scores the stated plus |
| F3 | "What do you know about Atlas Freight?" | CO | [generic] | The pack could not research the company, so it supplies no facts about Atlas. The JD itself gives you: regional logistics, 800 employees, 4 sites. Before the interview, read Atlas's own published pages and pick three things you can say plainly and one question you would ask. If little is public, say what you found and ask what you should know | CO is the type this pack cannot ground, because the searches were refused. Generic because no research ran |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side — where's the seam, and what happens when we disagree?" | CASE | [generic] | Propose seam principles rather than pretending to know the seam: who owns the decision, how a disagreement is raised, how it is settled and recorded. Frame what you would bring to their team, not only what you need. The question asks about no past, so the guidance makes none | Likely only if a peer is in the loop. CASE because it is a live collaboration problem |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams, with a named contribution of yours and a named contribution of theirs. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard peer probe. VAL because it tests behavior; generic because no stored story supports it |
| G3 | "What would you need from me in your first month?" | JD | [generic] | Use reciprocity: what you would ask for, such as their priorities and where their pain is, and what you would offer back, as a principle and not a claim about your past. The question needs no claim about your past, so the guidance makes none | A collaboration probe likely from a peer. JD because it tests how you would ramp into the role |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| "Own daily terminal operations across 4 sites" | C3, D1, D3, E2, E3 |
| "drive on-time performance and cost-per-shipment down" | A2, D1, D2 |
| "lead a team of 12 supervisors" | D3, E1, E2 |
| "build reporting in Excel/Power BI" | A3, B3 |
| "5+ years operations leadership required" | B1, E4 |
| "Lean/Six Sigma a plus" | F2 |
| The 40% mis-pick figure, your one headline metric | A1, B2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first ninety days look like for the person in this seat across the four sites?" | Their answer tells you what the job measures first, and it lets you test your plan against it |
| R2 | "Which of the four sites is hardest to run right now, and what makes it hard?" | It points the conversation at the live problem the JD's four-site line implies, and turns D1 into a real discussion |
| R3 | "How are on-time performance and cost-per-shipment reported today, and who reads the reports?" | It shows how much Excel and Power BI work is waiting, so you can size the tool gap honestly |
| R4 | "What does the supervisor team look like today, and where does it need support?" | It moves the twelve-supervisor probe from a test to a working conversation |
| R5 | "How does the operation handle peak season, and what has gone well or badly lately?" | It shows what the surge side of the role needs and gives you something real to respond to |
| R6 | "Is there anything in my background you'd want me to say more about?" | It surfaces a concern while you can still answer it, which is the point of rehearsing E2 and E4 |
| R7 | "If we worked side by side, what would help your team most from me in month one?" | Reciprocity question for a peer interviewer; use only if one is in the room |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned operations across four sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says the site's surge plan and a shift role. E2 and E3 stay inside that scope |
| Led twelve supervisors | Inflated form of F3 | F3's quote at its own scope. The material says 3 supervisors, not 12 |
| Moved on-time performance or cost-per-shipment | Inflated form of F2 | F2's quote at its own scope: the mis-pick rate. A2's slot asks only what you tracked |
| Built operational reporting in Excel | Inflated form of F4 | F4's quote at its own scope: "solid Excel". A3's slot asks only what you used it for |
| Has used Power BI | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." No slot |

## Sources

Provided documents: the job description as pasted in your message; your background summary in your message. No tuesday-dossier.md was present.

Searches sent, each refused:

- `Atlas Freight regional logistics company values` — refused
- `Atlas Freight interview process operations manager` — refused
- `Atlas Freight regional logistics strategy news` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. It would have supplied the company's published values for a values cheat sheet and grounded VAL questions; C1, C2, G2 are generic instead |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. It would have named the real rounds and set persona weights; the weights are flat and the archetype fallback is generic |
| 3. `Atlas Freight strategy` / recent news | unavailable | Every call was refused. It would have grounded CO and CASE questions in current strategy; F3 and D1 to D3 are generic |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who the interview is with (recruiter, future manager, peer, panel) → persona weights and bank depth reweighted
- The interviewer's name, if the invite gives one → an interviewer read and a reverse question tied to their path
- Search access for company research (values, loop structure, current strategy; a deeper pass would add up to 6 more searches and 2 more fetches, several more minutes) → F3 and the CO and CASE banks become grounded, and a values cheat sheet if a values round turns up
- Your CV text → more of your own sentences in the evidence column, which can upgrade F1, F3 and F6
- How many of your seven years had you responsible for others → F6 and E4 move from discovery
- What the 40% was counted against and what part was yours, in your own words → A1 and B2 become story-mapped
- Whether you track on-time performance or cost-per-shipment at your site → F2 and A2
- What you use Excel for, and any reporting tool you have used besides it → F4, A3 and B3
- Whether you have worked across more than one site or beyond your own shift → F1 and E2
- The green belt issuer and the certificate → F7 moves from medium toward high
- The recruiter's prep email (focus areas, any announced deliverable) → coverage assumed from round-type priors becomes real, and a deliverable would get its own section
- A `tuesday-dossier.md` from an earlier run → verified evidence and sourced prohibited claims would sharpen the banks; the pack does not need one
