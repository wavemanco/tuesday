Web search was refused in this session, so the pack will carry no company research. I'm building it from what you told me and writing it to a file now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/tuesday/part-2/rooms/case-6-denied-aa091ff5/Larkfield-Systems_engineering-manager_interview_pack.md`.

I built it in loop mode: one shared fit snapshot, then a mini-pack for each of the three rounds, with 10 questions each and 5 reverse questions each. The sections are persona weights, question banks, reverse questions, requirement coverage, prohibited claims, sources and an upgrade menu.

Web search was refused in this session, so there is no research on Larkfield:
- **Company facts:** Nothing in the pack comes from the web, and the strategy questions are labeled `[generic]`.
- **Values cheat sheet:** I dropped it because I have no published values to map your stories to.
- **Persona weights:** They rest on your description of the three rounds.

Your own words are the only evidence in the pack. Your reliability-quarter sentence carries most of the story-mapped answers, so a second and third story would strengthen it. The highest-ROI rehearsal is Tue-A2, the hardware-roadmap objection from the Director. Mon-A6, the "never managed managers" question from the VP, comes second.

Say the word and I'll run a drill, playing the Skeptic Director on Tue-A2. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste the full job posting and your CV, or should I proceed without them? Either would turn several rows from your summary into quoted evidence.
2. Did the recruiter give any focus areas for each round, or announce a deliverable such as a case or presentation for the panel?
3. Do you want a deeper research pass, with up to 6 more searches and 2 more fetches and several more minutes, if search access is granted?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield-Systems_engineering-manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems (loop mode, three rounds)

Candidate: Yusuf. Rounds: Tuesday, Director of Engineering (hiring manager, would-be boss), 45 min. Thursday, panel of two staff engineers and a product manager, 60 min. Following Monday, VP Engineering, 30 min, described by the recruiter as "values and leadership philosophy". No interviewer names or profiles were given. No company research ran (see Sources).

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: where a cell quotes your own sentence, tell it in your own words and at the quote's own scope. Answer slots are instructions for the interview, not questions for you here.

| Tag | Name | What it is scoring |
|---|---|---|
| VAL | Behavioral / values | Whether past behavior shows the values or leadership philosophy being probed |
| EXP | Work-experience deep-dive | Whether your stated claims survive scrutiny and attribution |
| JD | Role / JD-driven | The stated responsibilities, including the gaps |
| CO | Company and strategy knowledge | Homework depth (none banked here: no research ran, so no honest CO question exists) |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem set in the role |

Persona letters are fixed across rounds: A Skeptic, B Case/Strategist, C Data-Driven Prober, D Conversational, E Peer Evaluator, G Values/Behavioral, H Pressure. Question IDs carry the round: Tue, Thu, Mon.

## The fit snapshot (shared across all three rounds)

Requirements are quoted from the role description in your message. Evidence is your own sentences only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says a team lead of 6, with nothing inspected behind it, and the words stay there: "I've been a team lead of 6 for 3 years." Answer slot: the role's two-squad scope makes a probe on how that compares likely. If your lead role reached beyond that team, say how in your own words; if it did not, say so plainly and stay with the team of 6 |
| F2 | "own delivery, hiring and growth for 11 engineers" (delivery) — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote carries a reliability quarter and an on-call figure, not ownership of delivery for 11 engineers, and nothing is inspected behind it. Words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: the role's delivery line makes a probe on what went into that quarter and who decided likely. If any of that was yours to decide, say what and how, in your own words; if there was no such step, or it was not yours, say so plainly and stay with pushing the quarter through |
| F3 | "own delivery, hiring and growth for 11 engineers" (hiring) — role description | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | transferability | The quote carries running a loop for backend roles, not owning a team's hiring decisions or headcount. Words: "I run our hiring loop for backend roles." Answer slot: the role's hiring line makes a probe on who decided offers likely. If decisions were yours, say which and how, in your own words; if there was no such decision, or it was not yours, say so plainly and stay with the loop |
| F4 | "own delivery, hiring and growth for 11 engineers" (growth) — role description | none given | none | [grounded] | discovery | Your material does not show work on developing engineers. Answer slot: the role's growth line makes a probe on how you develop people likely. If you have done this, say what, in your own words; if you have not, say so plainly and say what you would do first |
| F5 | "partner with hardware and product on roadmap" (hardware) — role description | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | discovery | Your stated limit is owning such a roadmap, and the plain words are: "I've never owned a hardware-adjacent roadmap." Partnering is not owning, and your material does not say either way. Answer slot: if you have worked alongside hardware people on a roadmap, say how, in your own words; if you have not, say so plainly and say how you would start |
| F6 | "partner with hardware and product on roadmap" (product) — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | Roadmap pressure appears, but not who it came from or how it was settled, and the bridge does not fill that. Answer slot: if there was a working arrangement with a product partner, say how, in your own words; if there was none, say so plainly and stay with the reliability quarter |
| F7 | "Lead two squads building device-management services" (domain) — role description | none given | none | [grounded] | discovery | Your material names a payments company and does not show device or fleet work. Answer slot: if any service you built or ran handled devices or fleets, say what, in your own words; if none did, say so plainly and say what you would read or ask first |

Status: pending your approval.

## Round 1: Tuesday, Director of Engineering (hiring manager), 45 min

Persona weights, with the reasoning shown. The loop rests on your own account of the three rounds; Larkfield's own process is not documented here.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| A Skeptic | Quiet probing of the gaps: hardware roadmap, scale, why here | High: hiring-manager prior is Case/Strategist plus Skeptic, and your own message names two limits | Rehearse the single most predictable objection until it is boring; bridge only from what your quotes carry; give a ramp plan as a plan |
| B Case/Strategist | Live problems from the role: late dependency, reliability against roadmap, first 30 days | High: same prior; this person is buying capability on a real roadmap | Clarify, objective, options, risks, what you would record; think aloud; challenge one premise politely |
| C Prober | Line-by-line on the reliability quarter | Mid: your two figures are the likeliest thing read closely | Say how each figure was counted, or say plainly you do not know; name the assumption you would defend least |
| D Conversational | "Walk me through the journey" opener | Low: one opener, but it is scored | A 90-second arc built only from your sentence |
| G, H, E | Not banked this round | Pressure and Values carry to Monday; Peer to Thursday | none |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Tue-A1 | "Which part of leading two squads would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Name the gap you would honestly rank first. Two are in your own words: "I've never managed managers" and "I've never owned a hardware-adjacent roadmap". If your weakest is something else, such as the device-management domain, say that in your own words. Then a ramp plan said as a plan, never a past: two or three concrete first-month steps you would actually take | F5 and F7 are the thinnest rows, so this arrives early. JD because it scores the role's own list |
| Tue-A2 | "You haven't owned a hardware-adjacent roadmap. Why should I believe you can partner with hardware on ours?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | The highest-ROI rehearsal in this pack. Plain words: "I've never owned a hardware-adjacent roadmap." Name the limit before it is asked for: what you cannot claim is owning one. Then the plan: who you would ask, what you would read, what you would ask of the Director. Answer slot: if you have worked alongside hardware people on a roadmap, say how, in your own words; if you have not, say so plainly and stay with the plan. Hold through two follow-ups by returning to the limit and the plan, never by adding experience | F5 is where the role presses hardest against your stated limit, so some form of this will be asked; a rehearsed non-defensive answer changes the round |
| Tue-A3 | "This role owns delivery for 11 engineers across two squads. How does that compare with the team you've led?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Story-mapped on F1: the beats the quote states are 3 years as a team lead of 6; tell them in your own words. Answer slot: if you already do something differently as a group grows, say what; if you have not led beyond that team, say so plainly and say what you would want to learn first | F1 and F2 are the scale rows; JD because it scores the stated team size |
| Tue-A4 | "Why this role, and why now?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Give your actual reasons in your own words; the pack holds none, so none are supplied. Answer slot: if the move is toward more scope, say it as that; if it is the domain, say what drew you; if your current role is part of it, say it without blame | A motivation probe is near-certain; the persona stem is "why here, why now" |
| Tue-B1 | "Hardware tells you a dependency your squads need will arrive late, and product has already given customers a date. Walk me through the next week." | CASE | [generic] | Structure: what exactly is late and by how much, what is fixed and what can move, options such as re-scoping or re-sequencing, who needs to hear what and when, what you would record. The question needs no claim about your past, so the guidance makes none | A live problem from the role's hardware-and-product line (F5, F6); generic because it is a pattern, not a fact about Larkfield |
| Tue-B2 | "Reliability work is crowding the roadmap in one of your squads. How do you decide what gives?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure the decision: what the pain costs, what the roadmap item buys, what could be traded. If you reach for your own example, tell it at its scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure", and add nothing | F2's evidence is the one story you have that fits; CASE because it is asked as a decision |
| Tue-B3 | "You inherit 11 engineers across two squads you haven't met. What do you do in your first 30 days?" | CASE | [generic] | Structure: listen first, map commitments and risks, then pick what to change and what to leave alone, and say how you would check you were right. No claim about your past | F1 and F4 in plan form; generic because it asks for a method |
| Tue-C1 | "Walk me through how the 60% on-call number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Four slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. The pack supplies no method or baseline | Headline metric, so a defend-the-number row; EXP because it tests attribution |
| Tue-C2 | "What did you personally do in that reliability quarter?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped: the beats the sentence states are a reliability quarter, pushed through, against roadmap pressure, on-call burden down 60%. Tell them in your own words. Answer slot: the role's delivery line makes a probe on what went into the quarter and where the pressure came from likely. If you decided the contents or the pressure came from a person or team, say so and how it resolved; if it was set by someone else or there was no such step, say so plainly and stay with pushing it through | F2 and F6 both rest on this sentence, so it gets read hardest |
| Tue-D1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc with only the beats the sentence states: 9 years in engineering, 3 as a team lead of 6, now at a payments company. Answer slot: say in your own words what pulled you toward this role; the pack holds no reason and supplies none | Casual openers are scored; F1 supplies the beats |

Status: pending your approval.

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would make the next two quarters a success for these squads, from your seat?" | Turns the delivery line into a measurable and shows you are thinking about the first results |
| 2 | "Where do hardware and product roadmaps pull against each other most today, and who settles it?" | Asks for the seam rather than assuming one, which is honest given the limit you stated |
| 3 | "Who on the hardware side would I work with most closely in my first quarter?" | Makes the ramp concrete and signals you plan to start learning on day one |
| 4 | "How is growth handled for the 11 engineers today, and what is working or not?" | Echoes the role's own growth line and gets you the real state before you commit to an approach |
| 5 | "When you and I disagree about delivery versus reliability, how do you want us to settle it?" | Tests the working relationship with the person who would be your manager |

Status: pending your approval.

## Round 2: Thursday, panel (two staff engineers, one product manager), 60 min

Panel rule: blend the top two personas of each member's relationship. No names were given, so assignment is by seat, not by person.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| E Peer Evaluator | Seam-splitting between squads, staff engineers and product; credit and disagreement | High: staff engineers and the product manager would work beside you, which is the Peer prior | Reciprocity framing: what you bring them, not only what you need; offer seam principles rather than pretending to know the seam |
| C Prober | Depth on the hiring loop and your figure; domain depth on device work | High: the staff-engineer seats take the Prober prior; F3 and F7 are open | State what you can and cannot say about each figure; say plainly where the domain is new |
| G Values/Behavioral | Scenario prompts from the product seat | Mid: cross-functional prior, and the PM is outside engineering | Tell stories your quotes carry; where none does, say so and give the nearest |
| A Skeptic | One gap probe from an engineer | Low: the Director carries most of it, but the hardware limit travels | The plain acknowledgment from F5, then a plan |
| D Conversational | Not banked | Carried from Tuesday's opener | none |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Thu-E1 | "Our teams sit side by side with yours. Where is the seam between engineering, hardware and product on the roadmap, and what happens when we disagree?" | JD | [generic] | Offer seam principles, not a map you have not seen: who decides what, how a disagreement is raised and by when, what you would ask of them first. No claim about your past, so none is made | F5 and F6 in panel form; JD because it scores the partnership line |
| Thu-E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work crossed teams, with a named stake, what you did about credit, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for the Peer; generic because no sentence of yours carries it |
| Thu-E3 | "Tell me about a time you disagreed with a senior engineer on a technical call. How did it end?" | VAL | [generic] | Selection scaffold: a real disagreement with a named stake, where you held a view with tact and the outcome is known. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Peer stem is "what happens when we disagree"; generic because your quotes hold no such story |
| Thu-E4 | "A staff engineer wants to rewrite a service and the roadmap has no room. What do you say?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure: what the rewrite fixes, what it costs, what could move, how you would test the claim before committing. If you reach for your own example, use that sentence at its scope and add nothing | Staff engineers raise technical debt against the roadmap; F2's evidence is your only quoted story on that tension |
| Thu-C3 | "Walk me through how you run the hiring loop." | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Story-mapped on F3: the beats the quote states are a hiring loop, for backend roles. Tell them in your own words. Answer slot: the role's hiring line makes a probe on who decided offers likely. If decisions were yours, say which and how; if there was no such decision or it was not yours, say so plainly and describe how you run the loop | F3; JD because the role owns hiring for 11 engineers |
| Thu-C4 | "How was the figure of about 40 interviews counted?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Four slots, each in your own words: how the 40 was counted, what it is sensitive to, the assumption behind it you would defend least, and which of those interviews you ran yourself. If you do not know how it was counted, say so plainly. Read the 40 at the smaller reading: it is about interviews in the loop, not necessarily ones you conducted | Headline metric, so a defend-the-number row |
| Thu-C5 | "Tell me about a system you've been close to that had to keep running at scale." | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Selection scaffold: pick a system with a named reliability stake and your part in it. Answer slot: the role is device-management services, so expect a probe on whether anything touched devices or fleets. If it did, say what; if none did, say so plainly, then give the nearest thing your material carries, which is 9 years of engineering at a payments company, or how you would learn the domain | F7 is the open domain row; open prompt, so it supplies no event |
| Thu-G1 | "Tell me about a time you told a product partner something they didn't want to hear." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The only quoted story that comes near is that sentence, and it does not say the pressure came from a product partner or what you said. Tell its beats at its scope. Answer slot: if the pressure came from a product partner, say what you told them and how it landed; if it did not, or you did not tell them, say so plainly and give the nearest thing your material carries | F6, with the Values stem about an unpopular truth |
| Thu-G2 | "Tell me about a time you worked with another team to land something neither team could land alone." | VAL | [generic] | Selection scaffold: a real cross-team effort with a named stake, your own part, and a result you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5 and F6; no sentence of yours carries a cross-team story, so none is supplied |
| Thu-A5 | "How would you earn the trust of a squad that knows this domain well?" | JD | [generic] | Say what you would ask of them before what you would bring: what they would want you to learn first, which decisions you would leave to them, when you would step in. These are intentions, not past practice, and no claim about your past is made | Domain-gap probe in collegial form (F7) |

Status: pending your approval.

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What could a new manager do in the first month that would genuinely help your team?" | The reciprocity question for peers: it asks what you can add to their load, not only what you need |
| 2 | "Where do the squads and staff engineers disagree most today?" | Surfaces the seam from people who live in it |
| 3 | "What would you fix first in this platform if you had a free quarter?" | Engineers weight this slot as a preparation signal and it shows whether technical debt is on your radar |
| 4 | "How does product hear about hardware constraints today, and when does it hurt?" | Directly relevant to the product seat and to the roadmap-partnership line |
| 5 | "How are priorities set between the two squads when they collide?" | Tests what the role really owns and how much of the arbitration is yours |

Status: pending your approval.

## Round 3: Monday, VP Engineering, 30 min ("values and leadership philosophy")

A values-style round is detected from the recruiter's own words as you relayed them. Larkfield's published values are not in hand, so the VAL questions are themed on leadership philosophy and the values cheat sheet is dropped.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| G Values/Behavioral | Scenario prompts on leadership and values | High: the recruiter's description makes it guaranteed | Map a story where one of your quoted sentences carries one; use a selection scaffold with its honest branch where none does |
| A Skeptic | Probing the manager-of-managers limit and the move up | Mid: your own message names "never managed managers" | Plain acknowledgment, then how you would grow into it as a plan |
| H Pressure | Time-boxed, composure-testing, motive questions | Mid: skip-level and executive prior, and only 30 minutes | Pause, restate, hold the position through two follow-ups, concede specifically |
| B Case/Strategist | One or two altitude questions about the two squads | Mid: executive prior; kept short because the recruiter's brief is values | Clarify first, state a hypothesis early |
| D, E | Not banked | Covered in rounds 1 and 2 | none |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Mon-G3 | "How would you describe your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | None of your sentences states a philosophy, so this is a selection scaffold: choose two or three principles you actually act on, each with one time it showed. Where a principle matches that sentence, tell it at its scope. If no such principle comes to mind, say so plainly, then give the nearest thing your material does carry | The recruiter's own words raise it, and it is the likeliest opener |
| Mon-G4 | "Tell me about a time you made an unpopular call and stood behind it." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped: the beats the sentence states are a reliability quarter, pushed through, against roadmap pressure, on-call burden down 60%. Answer slot: if someone disagreed, say who and what you said, in your own words; if nobody did, or it was not yours to call, say so plainly and stay with the quarter | The persona stem is the unpopular truth; this is your one quoted story, so have a second ready |
| Mon-G5 | "Tell me about a time you helped an engineer grow." | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Selection scaffold: one person, what they needed, what you did, what changed for them. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is 3 years as a team lead of 6, or how you would handle it | F4 has no evidence; JD because the role owns growth, VAL because the VP will hear it as philosophy |
| Mon-G6 | "Tell me about a time something you decided as a lead turned out to be wrong." | VAL | [generic] | Selection scaffold: a real decision, what you learned, what you changed after. If no such time comes to mind, say so plainly, then give how you would handle it | The recruiter's leadership theme; nothing in your quotes carries it |
| Mon-A6 | "You've said you haven't managed managers. Does that matter for this role?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Plain words: "I've never managed managers." Answer slot: say in your own words whether it matters for the two squads and 11 engineers; the pack does not tell you whether it does. Then how you would grow into it, as a plan | The question your own message flags; the role description does not say whether it asks for it |
| Mon-A7 | "What would worry you if you were hiring for this role?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Name your honest top concern in your own words; the two in your message are "I've never managed managers" and "I've never owned a hardware-adjacent roadmap". Then the plan that answers it | Skeptic stem about day-one weakness, asked at VP altitude |
| Mon-H1 | "Sixty seconds: why you over a manager who has done this before?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold on what the quotes carry: 9 years in engineering, 3 as a team lead of 6, and a reliability quarter pushed through. Make no comparison you cannot back. Concede specifically if pressed: "I've never managed managers". Hold through two follow-ups by returning to the quotes | Pressure stem; JD because it tests the fit story |
| Mon-H2 | "That 60%, how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold the sentence at its scope: it says "my team's" burden and "I pushed" the quarter. Answer slot: say which part of the drop was yours, in your own words; if you do not know, say so plainly. Concede the unknown specifically; never fold on the quarter itself | Pressure stem on the headline figure |
| Mon-B4 | "How should an engineering team balance new device features against fleet reliability?" | CASE | [generic] | Structure: what each failure costs the customer, how you would decide which gives, how you would check the balance was right. No claim about your past, so none is made | Executive altitude on the role's delivery tension (F2); generic because no company strategy was researched |
| Mon-B5 | "How would you tell whether the two squads are healthy six months in?" | CASE | [generic] | Structure: signals across delivery, quality and people, how you would collect them, what would make you act. No claim about your past | F1 and F2 at altitude |

Status: pending your approval.

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a great first year look like in this role, in your words?" | Gets the VP's own bar and shows you aim at it |
| 2 | "How do you think about the balance between shipping and reliability across engineering?" | Connects your one quoted story to the VP's altitude |
| 3 | "What have you changed in how engineering is led here, and why?" | Asks the leadership philosophy question back, which suits a values round |
| 4 | "What do you wish managers at my level did more of?" | Surfaces the VP's expectations of the level you would join |
| 5 | "How do you develop the people who lead the squads?" | Shows interest in growth in both directions, given your stated limit on managing managers |

Status: pending your approval.

## Requirement coverage

| Requirement | Covered by | JD-tagged question |
|---|---|---|
| F1 two squads | Tue-A1, Tue-A3, Tue-B3, Tue-D1, Mon-B5 | Tue-A1, Tue-A3 |
| F2 delivery | Tue-A3, Tue-B2, Tue-C2, Thu-E4, Mon-G4, Mon-B4 | Tue-A3 |
| F3 hiring | Thu-C3, Thu-C4 | Thu-C3 |
| F4 growth | Mon-G5, Tue reverse 4 | Mon-G5 |
| F5 hardware partnership | Tue-A1, Tue-A2, Tue-B1, Thu-E1, Mon-A7 | Tue-A2, Thu-E1 |
| F6 product partnership | Tue-B1, Thu-E1, Thu-G1 | Thu-E1 |
| F7 device-management domain | Tue-A1, Thu-C5, Thu-A5 | Thu-C5 |

Headline metrics: the 60% is covered by Tue-C1 and Mon-H2; the 40 interviews by Thu-C4. The highest-ROI prep in this pack is Tue-A2, with Mon-A6 second.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative the candidate stated | "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative the candidate stated | "I've never owned a hardware-adjacent roadmap." Any partnership slot stays on working alongside, never owning |
| Led two squads or 11 engineers | Inflated form of F1 | F1's quote at its own scope: the material says a team lead of 6, not two squads |
| Owned hiring for a team, or made the hiring decisions | Inflated form of F3 | F3's quote at its own scope: the material says running the loop for backend roles, not owning the decisions |
| Cut on-call by 60% through your own work alone | Inflated form of F2 | F2's quote at its own scope: the material says your team's burden dropped and you pushed the quarter; which part was yours is an answer slot |

## Sources

Provided: your message only, covering the role description, the three rounds as you described them, the recruiter's description of Monday as "values and leadership philosophy", and your own sentences. No full job description, CV, interviewer profile or published values page was supplied.

Searches sent, all refused, nothing returned:
- "Larkfield Systems industrial IoT company values": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems industrial IoT device management strategy news": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The search was refused. It would have fed the values cheat sheet for Monday and themed the VAL bank on named values; the cheat sheet is dropped |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The search was refused. It would have checked the loop against a documented one; persona weights rest on your account of the rounds |
| 3. `Larkfield Systems strategy` / recent news | unavailable | The search was refused. It would have grounded CO and CASE questions in current priorities; those are generic |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Engineering Manager` JD | skipped | The role description you gave fixes the fit snapshot and the JD-tagged questions; a full posting would add more requirements |

## Upgrade menu

- The full job posting text → more requirements as quoted rows, and any term-type requirements such as location or onsite pattern that the role summary does not show
- Your CV → more of your own sentences to quote; right now one sentence carries most of the story-mapped answers (F2, F6, Tue-C1, Tue-C2, Thu-G1, Mon-G4), so a second and third story told outside a drill would upgrade those rows
- Answers to the answer slots, especially growth, hardware and product partnership, and the domain → F4, F5, F6 and F7 and the questions built on them
- Larkfield's published values page, pasted → the values cheat sheet for Monday and VAL questions themed on named values
- Panel members' names and roles, and the Director's → an interviewer read, retuned persona weights and a reverse question tied to their own path
- The recruiter's focus areas for each round, or any announced deliverable → coverage beyond the round-type priors
- A strategy brief or recent news about Larkfield, pasted → CO and CASE questions grounded in Larkfield's actual priorities, now generic
- A tuesday-dossier.md from an earlier fit assessment → verified evidence, stronger limits on what you can claim, and the objection to rehearse most
