Searches weren't permitted here, so this runs on your text alone.

## Decision snapshots

**First: Operations Analyst, Duinvaart Cold Chain. Yes, worth your time. Status: `conditional_go`.**

**Fit ledger.**
- `hard_gate`: unclear: R1 (Hybrid, three days in Rotterdam)
- `must_have`: direct: R2, R3, R4, R5a · unclear: R5b (Temperature compliance)
- `important`: adjacent: R6 (Route changes with depot managers)
- `preferred`: adjacent: R7 (Dutch a plus)

R5b: temperature work not yet shown; R6: a credible bridge, its limit named.

**Opportunity ledger.** The posting is specific about duties (RR2). The employer could not be checked from here (RR1), and pay is not stated (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, three days in Rotterdam office); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 turns out workable for you; (2) R5b: you have some temperature or condition-sensitive tracking to show, or can name it honestly as a gap; (3) the employer verifies (RR1).

**Second: Supply Planner, Kroonhaven Foods. No, not worth your time. Status: `no_go`.**

**Fit ledger.**
- `hard_gate`: unclear: S1 (On-site in Utrecht)
- `must_have`: adjacent: S2 (Fluent Dutch), S5 (Run weekly S&OP meeting) · unclear: S6 (Advanced Excel) · absent: S3 (3+ years FMCG planning), S4 (Own 13-week supply plan), S7 (SAP IBP or similar)

S3, S4, S7: no planning evidence, and you said you have none; S2: your Dutch is the limit.

**Opportunity ledger.** The mandate is clearly defined (SR3). The employer could not be checked from here (SR1), and pay is not stated (SR2).

- **Hard gates:** none failed; unconfirmed: S1 (On-site in Utrecht); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would change this:** S3, S4 and S7 would need real planning-system and FMCG planning evidence, and S2 would need Dutch at professional fluency. None of that can be fixed by rewording your resume.

---

## First: Duinvaart Cold Chain

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Mandate | Track on-time delivery and temperature compliance for a refrigerated fleet, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Scope read | An analyst role that reports and recommends. The posting names no decision rights over routes | `[inferred]` from "work with depot managers" |
| Market calibration | Not run: the role-family search was refused | none |
| Unknowns | Salary, team size, who the role reports to, how temperature data is captured | `[grounded]` posting silent |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | none | hard_gate | You work in Amsterdam. You have not said whether you would commute to Rotterdam or move, so the gate is not settled | `[grounded]` posting and your stated employer location | Question 1 below |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier. This is your own account, not yet checked against anything | `[grounded]` your background | none |
| R3 | Strong SQL | must_have | direct | medium | none | You use SQL daily. Your own account, no artifact seen | `[grounded]` your background | none |
| R4 | Power BI or Tableau | must_have | direct | medium | none | You use Power BI daily and built the on-time dashboard your depot managers use. A sanitized screenshot would raise this to `high` | `[grounded]` your background | Offer: dashboard screenshot |
| R5a | Track on-time delivery | must_have | direct | medium | none | Your depot-manager dashboard is on-time delivery | `[grounded]` your background | none |
| R5b | Track temperature compliance on a refrigerated fleet | must_have | unclear | low | discovery | Nothing in what you gave me mentions temperature or cold-chain work. Low rather than none because a parcel carrier may have had some condition-sensitive handling | `[grounded]` silence in your background | Question 2 |
| R6 | Work with depot managers on route changes | important | adjacent | medium | discovery | You ran the weekly route-performance review and your dashboard serves depot managers. The limit: reviewing route performance is not the same as agreeing route changes, and I do not know whether yours led to any | `[grounded]` your background | Question 3 |
| R7 | Dutch a plus | preferred | adjacent | medium | none | Conversational Dutch counts toward a "plus" but is not fluency | `[grounded]` your background | none |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R5b, must_have) | discovery | No temperature or cold-chain work mentioned | It is half of the role's headline duty, and the answer decides whether the application leads with a strength or a gap | Chilled or frozen parcels, pharma or food shipments, any delivery-condition exceptions you reported, sensor or telematics data | A dashboard screenshot or a report excerpt | `[grounded]` silence in your background; `[generic]` that employers read a core-duty gap more harshly than a plus |
| G2 | Route changes with depot managers (R6, important) | discovery | The review is confirmed, but whether it produced route changes is not | A concrete route change you drove turns an adjacent row into a direct one | A review that ended in a re-sequenced route, a depot schedule change, or a recommendation a manager acted on | Sanitized review notes or a summary slide | `[grounded]` your background |
| G3 | Rotterdam office days (R1, hard_gate) | hard_gate | Location and willingness unknown | A gate that does not settle cannot be written around | Not applicable | Not applicable | `[grounded]` your stated Amsterdam employer |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The search was refused, so I have not checked that the company or posting exists as described. Many small firms also just have thin footprints | `[generic]` pattern, not a claim about this company | Can you point me to this role on your careers site, and say who I would be interviewing with? | unresolved |
| RR2 | Duties and requirements are specific | positive_signal | — | "Track on-time delivery and temperature compliance … build weekly dashboards in Power BI" | The scope reads as concrete | `[grounded]` posting | Which reports does this role own in its first 90 days? | noted |
| RR3 | Pay not stated | unknown | — | the posting as pasted has no salary | May be withheld or omitted from the paste | `[grounded]` posting as pasted | What is the budgeted salary range for this post? | unresolved |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with the on-time delivery dashboard and the weekly route-performance review, in your own existing wording and with no new claims | See R4, R5a, R6 | `[grounded]` your background | pending your approval |
| E2 | Ask the RR1 and RR3 questions of the recruiter before investing in the loop | See RR1, RR3 | `[grounded]` register | pending your approval |

---

## Second: Kroonhaven Foods

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Mandate | Own the 13-week supply plan for chilled ready-meals, balance capacity against forecast, run the weekly S&OP meeting | `[grounded]` posting |
| Working pattern | On-site in Utrecht | `[grounded]` posting |
| Scope read | An owner-level planning role, not an entry point into planning | `[inferred]` from "own" and the 3+ years in FMCG planning requirement |
| Market calibration | Not run: the role-family search was refused | none |
| Unknowns | Salary, team size, planning-system licence status | `[grounded]` posting silent |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| S1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Your location and willingness are not stated. It does not change the decision | `[grounded]` posting | none while `no_go` |
| S2 | Fluent Dutch | must_have | adjacent | medium | transferability | You have conversational Dutch. The limit: the posting says fluent, and the role runs a meeting. I read that as needing professional fluency | `[grounded]` your background; `[inferred]` from "run the weekly S&OP meeting" | none |
| S3 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You told me you have never worked in planning, and a parcel carrier is not FMCG | `[grounded]` your own statement | none |
| S4 | Own the 13-week supply plan, capacity against forecast | must_have | absent | none | capability | No planning ownership in your background | `[grounded]` your own statement | none |
| S5 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly route-performance review. The limit: that review was not a cross-functional demand and supply meeting | `[grounded]` your background | none |
| S6 | Advanced Excel | must_have | unclear | low | discovery | Your background names SQL and Power BI and is silent on Excel | `[grounded]` silence | none while `no_go` |
| S7 | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning system appears in your background | `[grounded]` your own statement | none |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| H1 | Planning ownership, FMCG experience, planning system (S3, S4, S7, must_have) | capability | No credible direct or adjacent evidence | These are the role's core and are three separate must-haves | A planning-analyst or demand-analyst role in FMCG, or planning-tool training | A course certificate or a planning-tool project | `[grounded]` your own statement; `[generic]` that closing this takes a role or a long project, not a rewrite |
| H2 | Professional Dutch (S2, must_have) | transferability | Conversational, not fluent | A Dutch-run weekly meeting needs more | Work meetings or written work done in Dutch | A language-level certificate | `[grounded]` your background |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| SR1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The search was refused, so I have not checked that the company or posting exists as described | `[generic]` pattern, not a claim about this company | Can you point me to this role on your careers site, and say who I would be interviewing with? | unresolved |
| SR2 | Pay not stated | unknown | — | the posting as pasted has no salary | May be withheld or omitted from the paste | `[grounded]` posting as pasted | What is the budgeted salary range for this post? | unresolved |
| SR3 | Mandate is clearly defined | positive_signal | — | "Own the 13-week supply plan" | The role's scope is concrete | `[grounded]` posting | What does the first quarter's plan cover? | noted |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| F1 | Skip this posting and look for demand-analyst or planning-analyst roles at the analyst level, where your SQL and dashboard work counts | See S3, S4, S7 | `[generic]` role-family pattern | pending your approval |

---

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for Duinvaart Cold Chain and for Kroonhaven Foods were refused. They would have checked each employer and posting, feeding RR1 and SR1 |
| 2. Role-family sweep | unavailable | Searches for analyst and planner pay and scope were refused. They would have fed market calibration and the pay entries RR3 and SR2 |
| 3. Hiring manager's public footprint | n/a | No hiring manager was named |

---

I can write both assessments into a `tuesday-dossier.md` if you want a file to keep or reuse.

**Upgrade menu**
- Permission to search → RR1 and SR1 (employer checks) and the market calibration lines.
- A sanitized screenshot of your depot-manager dashboard → R4 to `high`.
- Your answer on temperature work → R5b and G1 close.
- Your answer on commuting → R1 settles.

**Questions**

1. G3 — Where do you live now, and would you do three days a week in Rotterdam by commuting or by moving?
2. G1 — Have you tracked or reported on anything temperature-sensitive or condition-sensitive at the carrier? What did you own, and is there a report or screenshot you could share?
3. G2 — Did your weekly route-performance review ever lead to a route change? What did you recommend and who acted on it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.