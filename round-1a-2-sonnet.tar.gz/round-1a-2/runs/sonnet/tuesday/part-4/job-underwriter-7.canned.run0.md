I've run four searches and I'm now checking whether the role is live on Calderbrook's own careers page.
Aoife, yes, this one is worth applying for, on the conditions below.

## Decision snapshot

**Yes, worth applying for, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R4 (Clear, timely written records)
- `important` — direct: R5, R7, R9 · adjacent: R6 (leg-ulcer care), R12 (care in patients' own homes), R13 (small caseload of your own) · unclear: R8 (continence care), R10 (end-of-life visits), R11 (care planning)
- `preferred` — absent: R14 (Doppler assessment)

R4 — a must-have waiting on your answer; R6, R12, R13 — credible bridges, limits named; R14 — a stated gap on a desirable item, with a closure path to ask about.

**Opportunity ledger.** The post is supported and transparent. The pay range is stated (RR3), and a supported caseload and pool cars are positive signals (RR2). The live posting is unconfirmed on Calderbrook's own site (RR1), and the training period (RR4) and working pattern (RR5) are unstated.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post confirmed open on Calderbrook's own careers page — RR1; (2) your record-keeping experience confirmed — R4; (3) the leg-ulcer, home-visiting and caseload bridges framed as adjacent, never as direct experience — R6, R12, R13.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff across four locality hubs | `[grounded]` "About Calderbrook Community Health" (calderbrookhealth.example/about) |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin and care planning, on an electronic patient record | `[grounded]` JD |
| Support model | A small caseload of your own, supported by a senior community nurse | `[grounded]` JD |
| Team lead | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse; at the 2025 community nursing forum, spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` "Rhiannon Mabbott — Community Nursing Team Lead" (communitynursingforum.example/speakers/rhiannon-mabbott), search result text |
| Pay | £31,050–£37,800 plus mileage | `[grounded]` JD |
| Market calibration | One 2026 survey of community staff nurses at Band 5 in England (n=1,240) gives median basic pay £34,300 and interquartile range £32,400–£36,600, with 61% paid mileage and 24% on a pool or lease car. The posting's range encloses that interquartile range. This is the band to expect, never this employer's offer | `[generic]` role-family sweep, one survey (wardround.example/2026-uk-community-nursing-pay-guide); `[grounded]` JD for the range |
| First-90-days outcomes | Not stated | `[grounded]` JD silent |
| Unknowns | Closing date and hub base; training and supervised period; hours, rota and weekend pattern | — |
| Contradictions | None found between the JD and the about page. The careers page could not be fetched, so the live posting is not cross-checked (RR1) | `[grounded]` about page fetched; careers page returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | Your CV states Registered Nurse (Adult), registration active, revalidation due March 2028. That is a specific statement I have not inspected, and the register entry is the artifact. I did not look it up; checking it is yours | `[grounded]` CV | none |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | CV states a full UK licence, category B. The JD provides pool cars, so no own vehicle is needed | `[grounded]` CV and JD | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. This is a length-of-experience requirement, not a gate, and the CV comfortably meets it | `[grounded]` CV | none |
| R4 | Clear, timely written records (electronic patient record in use) | must_have | unclear | low | discovery | The CV is silent on record-keeping and on any electronic system. Ward work involves notes, but this CV does not show it, so this is a discovery gap, not an absence | `[grounded]` CV silence; `[generic]` that acute ward nursing involves routine documentation | G1 question below |
| R5 | Wound care | important | direct | medium | none | CV states wound care including pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R6 | Leg-ulcer care | important | adjacent | medium | transferability | Pressure-ulcer and surgical-wound care carries over. Limit: the CV does not mention leg ulcers, compression therapy or vascular assessment, so the bridge stops short of leg-ulcer care itself | `[grounded]` CV wound-care claim; `[generic]` that leg-ulcer care involves assessment and compression methods beyond other wound care | G3 question below |
| R7 | Catheter care | important | direct | medium | none | CV states catheter care. Continence care is the wider half of the JD phrase and is carried separately in R8 | `[grounded]` CV | none |
| R8 | Continence care | important | unclear | low | discovery | CV mentions catheter care only; wider continence work is not stated | `[grounded]` CV silence | G4 in the queue; not asked this turn |
| R9 | Insulin administration | important | direct | medium | none | CV states insulin administration. Care planning is carried separately in R11 | `[grounded]` CV | none |
| R10 | End-of-life visits at home | important | unclear | low | discovery | CV is silent on end-of-life care, on the ward or on home visits | `[grounded]` CV silence | G2 question below |
| R11 | Care planning | important | unclear | low | discovery | CV is silent on care planning. The discharge-to-assess secondment may involve it, but nothing stated says so | `[grounded]` CV silence | G4 in the queue; not asked this turn |
| R12 | Delivering care in patients' own homes | important | adjacent | medium | transferability | 18 months seconded to discharge-to-assess, visiting patients at home in their first week after discharge. Limit: first-week post-discharge visits are not ongoing care of housebound adults, and the CV does not say whether hands-on care was given. The reading resolves downward until you say | `[grounded]` CV | G5 in the queue |
| R13 | A small caseload of your own, supported by a senior nurse | important | adjacent | medium | transferability | You confirm you have never held your own caseload. The nearest evidence is the home-visiting secondment. Limit: visiting after discharge is not owning a continuing caseload. The post is built with senior support, which the JD states | `[grounded]` your statement and CV; `[grounded]` JD support model | G5 in the queue |
| R14 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You confirm you have never done a Doppler assessment. It is desirable, not essential. Closure path: ask whether the employer trains staff, since the team lead has spoken publicly on Doppler training for staff new to community work | `[grounded]` your statement; `[grounded]` forum speaker page | Ask the training question (RR4) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records on an electronic system (R4, must_have) | discovery | The CV says nothing on record-keeping or on any electronic system | R4 is the `must_have` row still unclear, and the JD names the electronic patient record | Same-day visit notes in discharge-to-assess; ward nursing documentation; anyone's feedback on your notes | A documentation audit result, the name of the system you used | `[grounded]` CV silence; `[inferred]` that confirming this moves R4 to `direct` |
| G2 | End-of-life care at home (R10, important) | discovery | The CV is silent on end-of-life care | The JD lists end-of-life visits as part of the daily work | Caring for dying patients on the ward; arranging a discharge home for end-of-life care; working with palliative or community teams | A reflective account, a training record, a thank-you letter | `[grounded]` CV silence; `[generic]` that this is core district-nursing work |
| G3 | Leg-ulcer care (R6, important) | transferability | Pressure-ulcer and surgical-wound care, nothing on leg ulcers | The team lead has spoken publicly on leg-ulcer clinics, and Doppler (R14) sits next to this skill | Dressing venous or mixed ulcers; applying or observing compression bandaging; shadowing a leg-ulcer clinic | A competency sign-off, a training certificate | `[grounded]` CV and speaker page; `[inferred]` that a stronger bridge here helps R14 |
| G4 | Continence care and care planning (R8, R11, important) | discovery | Catheter care is stated; wider continence work and care planning are not | Both are in the JD's duty list | Bladder or bowel management plans; writing or reviewing patient care plans on the ward or in discharge-to-assess | A care-plan template you used, a competency record | `[grounded]` CV silence |
| G5 | Home care and caseload ownership (R12, R13, important) | transferability | Home visits after discharge; no held caseload | The role's central expectation, softened by the stated senior support | The number of patients you visited, whether you planned and delivered care yourself, any repeat visits to the same patients | A secondment description, a handover template | `[grounded]` CV and your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Live posting not confirmed on the employer's own careers page | unknown | — | "Current vacancies are listed on our careers page." (about page) | The posting may be live and simply unreachable from here; the careers page address I tried returned no page | `[grounded]` fetch returned no page; `[inferred]` the cause is open | "Is this post currently open, and where is it listed on your careers page?" | unresolved |
| RR2 | Supported caseload and provided pool cars | positive_signal | — | "supported by a senior community nurse"; "pool cars are provided" | The role is built for a nurse developing a caseload, with no personal vehicle cost | `[grounded]` JD; `[generic]` only about one in four survey respondents had a pool or lease car | "How is the senior nurse's support structured: shared visits, supervision, caseload review?" | noted |
| RR3 | Pay stated as a range | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Stated pay reads as in line with the survey band in role reality | `[grounded]` JD range; `[generic]` single survey band | "Where in the range would someone with this experience start?" | noted |
| RR4 | Training and supervised period unstated | unknown | — | "supported by a senior community nurse" | The posting does not say how long supervision lasts before a solo caseload, or whether Doppler training is offered | `[inferred]` from the JD's silence | "What training and supervised period come before I hold my own caseload, and is Doppler training provided?" | unresolved |
| RR5 | Hours, rota and weekend pattern unstated | unknown | — | "end-of-life visits" | The posting does not say whether visits fall in evenings or weekends | `[inferred]` from the JD's silence | "What is the working pattern: shift times, evening and weekend rota, any on-call?" | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take up the informal chat with Rhiannon Mabbott before applying, and ask RR1, RR4 and RR5 verbatim | The JD invites it, and the answers move the conditions | `[grounded]` JD; `[grounded]` speaker page | pending your approval |
| E1 | Lead the experience section with your own sentence: "seconded 18 months to its discharge-to-assess team, visiting patients at home in their first week after discharge" | Home visiting is the closest evidence for R12 and R13 and is currently the last item in your history | `[grounded]` CV, traced clause by clause; nothing added | pending your approval |
| A2 | Ask whether Doppler training is provided (RR4) and do not claim Doppler experience | R14 is desirable and absent, and the question is the honest closure path | `[grounded]` your statement; `[grounded]` JD | pending your approval |

Everything in this plan, and the advice in it, is a proposal and not applied until you approve. If you decide to apply, mock-interview can prepare you for the interview itself.

## Evidence status

Verified: none yet.

Your National Insurance number isn't needed for this assessment. I haven't used or repeated it, and it only belongs on paperwork after an employer asks at onboarding.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Community Staff Nurse Band 5 district nursing Calderbrook Community Health CIC vacancy"; fetched "About Calderbrook Community Health" (calderbrookhealth.example/about); the fetch of calderbrookhealth.example/careers returned no page. Role reality's organization row, and RR1 as the live posting is not cross-checked |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing requirements Doppler training experience Agenda for Change pay 2026", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide), result text only. Market calibration `[generic]` and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott), result text only; public professional footprint only. Role reality's team lead row, A1 and A2 |

I can save this as `tuesday-dossier.md` if you'd like it for later.

**Upgrade menu**

- An answer to G1 (and the name of your electronic system) → R4 to `direct`, the one condition that rests on you.
- Answers to G2, G3 and G4 → R10, R6, R8 and R11 firm up from `unclear` and `adjacent`.
- A competency sign-off or training certificate for leg-ulcer care → R6 stronger, and a better footing for R14.
- The live posting link on Calderbrook's own careers page → RR1 closes.
- Rhiannon's answers on training, hours and support → RR2, RR4 and RR5 close.
- A deeper research pass on Calderbrook (leadership and staffing changes, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G1 — What records did you keep on the ward and in discharge-to-assess, on which system, and has anyone audited or commented on them?

G2 — Have you cared for patients at the end of life, on the ward or in a home visit; what was your part, and who else was involved?

G3 — Have you dressed or assessed leg ulcers, including compression bandaging, and were you signed off as competent in it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.