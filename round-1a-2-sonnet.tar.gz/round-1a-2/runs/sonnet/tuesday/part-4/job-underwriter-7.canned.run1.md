I've confirmed the employer exists and have a pay benchmark. Next I'm checking whether this posting is live on their careers page.
**Yes, Aoife, this one is worth applying for, as long as the posting checks out (RR2) and R4 closes. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R6, R7, R8 · adjacent: R5 (Care for adults at home) · unclear: R4 (Clear, timely written records)
- `important` — adjacent: R9 (Leg-ulcer care), R13 (Own small caseload) · unclear: R10 (Continence care), R11 (End-of-life visits), R12 (Care planning)
- `preferred` — absent: R14 (Doppler assessment)

R13 — a credible bridge, its limit named; R4 (`low`) — the CV is silent, and one answer could close it; R14 — absent, preferred tier.

**Opportunity ledger.** The employer is established (RR1). Pay sits inside the market band (RR3) and the post is supported (RR4). Two unknowns remain: I couldn't find the posting live on their site (RR2), and the hours and rota aren't stated (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live (RR2); (2) your record-keeping is evidenced (R4, G1); (3) the caseload and leg-ulcer bridges are framed as adjacent, never as direct experience (R9, R13).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` "About Calderbrook Community Health" (calderbrookhealth.example/about) |
| Mandate | District nursing for housebound adults at home: wounds and leg ulcers, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record | `[grounded]` posting |
| Scope read | A first-caseload post: a small caseload, with a senior community nurse behind it | `[inferred]` from "small caseload of your own, supported by a senior community nurse" |
| Market calibration | £31,050–£37,800 brackets a survey median of £34,300 and interquartile range of £32,400–£36,600 for Band 5 community staff nurses in England (n=1,240). 61% of respondents were paid mileage and 24% had a pool or lease car. This is the market band, never this employer's offer. | `[generic]` Wardround 2026 UK Community Nursing Pay Guide; `[grounded]` posting for its own range |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. In 2025 she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work. | `[grounded]` Community Nursing Forum speaker page (communitynursingforum.example/speakers/rhiannon-mabbott) |
| Unknowns | Hours and rota; whether Doppler training is offered here; whether mileage is paid when using a pool car | — |
| Contradictions | None found between the posting and the about page. The posting itself was not located on their site. | `[grounded]` searches and one fetch, see evidence status |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state Adult registration, active, revalidation due March 2028. Nothing has been inspected, so `medium`; checking the register is yours to do | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full UK licence, category B. Pool cars are provided, so no vehicle is needed | `[grounded]` CV and posting | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. A length-of-experience requirement is not a gate | `[grounded]` CV | none |
| R4 | Clear, timely written records on the electronic patient record | must_have | unclear | low | discovery | The CV says nothing about records or record systems. I won't infer practice from ward years | `[grounded]` CV silence | G1 |
| R5 | Caring for adults in their own homes | must_have | adjacent | medium | transferability | 18 months visiting patients at home in their first week after discharge. Limit: that was short post-discharge follow-up, not an ongoing housebound caseload | `[grounded]` CV; `[inferred]` that the limit applies | Name the limit when you apply (A2) |
| R6 | Wound care (pressure ulcers, surgical wounds) | must_have | direct | medium | none | Stated on your CV with both wound types named | `[grounded]` CV | none |
| R7 | Catheter care | must_have | direct | medium | none | Stated on your CV | `[grounded]` CV | none |
| R8 | Insulin administration | must_have | direct | medium | none | Stated on your CV | `[grounded]` CV | none |
| R9 | Leg-ulcer care | important | adjacent | medium | transferability | Your pressure-ulcer and surgical wound work is close. Limit: your CV doesn't mention leg-ulcer assessment or compression | `[grounded]` CV; `[inferred]` adjacency | G3 |
| R10 | Continence care (beyond catheters) | important | unclear | low | discovery | The CV names catheters, not wider continence care | `[grounded]` CV silence | G4 |
| R11 | End-of-life visits | important | unclear | low | discovery | The CV is silent. Acute ward work often includes end-of-life care, but I won't assert that of you | `[grounded]` CV silence; `[generic]` ward pattern | G2 |
| R12 | Care planning | important | unclear | low | discovery | The CV is silent on care planning | `[grounded]` CV silence | G4 |
| R13 | A small caseload of your own, with senior support | important | adjacent | medium | transferability | You've said you have never held your own caseload, so this is not direct. Adjacent: home visits on the discharge-to-assess secondment. The post is built around senior support | `[grounded]` your statement and posting; `[inferred]` adjacency | Name the limit when you apply (A2) |
| R14 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You've said you have never done one. It is desirable, not essential. Closure path: ask whether training is offered | `[grounded]` your statement and posting | Ask in the informal chat (A1) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records (R4, must_have) | discovery | The CV doesn't say what you recorded, where, or how promptly | It is an essential criterion, and it is the one `must_have` row still `unclear` | Documenting discharge-to-assess visits; electronic charting on the ward; handover notes; incident or audit entries | A record-keeping audit result, or a line from a reference or appraisal | `[grounded]` CV silence; `[inferred]` that closing it moves `conditional_go` toward `go` |
| G2 | End-of-life care (R11, important) | discovery | The CV doesn't mention it | It is a named duty of the post | Caring for dying patients on the ward; symptom control; supporting families; end-of-life care plans | A training certificate or a reference line | `[grounded]` CV silence; `[generic]` that ward nurses often meet this |
| G3 | Leg-ulcer care (R9, important) | transferability | Pressure-ulcer and surgical wound care, with no leg ulcers or compression | Leg-ulcer care leads the posting's duties, and Doppler is the desirable skill | Applying compression bandaging, even supervised; leg-ulcer dressings on the ward | A competency sign-off or a training record | `[grounded]` CV; `[inferred]` adjacency |
| G4 | Continence care and care planning (R10, R12, important) | discovery | The CV names catheters only | Both are named duties of the post | Bladder or bowel care plans; writing or updating care plans on the ward or home visits | A care-plan sample, sanitised | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer exists as described | positive_signal | — | "Calderbrook Community Health CIC, Halifax" | The posting's description matches a real organization running NHS-contracted community nursing in Calderdale | `[grounded]` about page | Which hub would I be based at? | noted |
| RR2 | Posting not located on their site | unknown | — | "Community Staff Nurse, Band 5" | The vacancy may be listed elsewhere, or the careers page may sit at another address | `[inferred]` from one failed fetch and one search that didn't return a vacancy | Can you confirm the post is open and the closing date? | unresolved |
| RR3 | Pay inside the market band | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The stated range brackets the survey's median and interquartile range | `[grounded]` posting; `[generic]` survey band | Where in the range do new-to-community nurses usually start? | noted |
| RR4 | Senior support and a pool car | positive_signal | — | "supported by a senior community nurse… pool cars are provided" | A first caseload with backup, and a vehicle provided. The team lead has spoken on Doppler training for newcomers | `[grounded]` posting and speaker page; `[inferred]` that the training applies here | Is Doppler training offered, and how soon after starting? | noted |
| RR5 | Hours and rota unstated | unknown | — | "end-of-life visits" | Community nursing can involve weekend or evening work, and the posting doesn't say | `[generic]` role-family pattern | What are the working hours, and is there a weekend or on-call rota? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV: lead with the discharge-to-assess secondment, "visiting patients at home in their first week after discharge", with wound, catheter and insulin work beside it | see R5–R8 | `[grounded]` CV | pending your approval |
| A1 | Take the informal chat with Rhiannon Mabbott before applying. Ask RR2, RR5 and the Doppler training question | The posting invites it, and it resolves two unknowns | `[grounded]` posting | pending your approval |
| A2 | Supporting statement, one line: "In my discharge-to-assess secondment I visited patients at home in their first week after discharge. I haven't yet held my own caseload, and I'm looking to build that with senior support." | Names the limit and traces to your own sentences. It claims no leg-ulcer, Doppler, records or end-of-life experience | `[grounded]` CV and your statement | pending your approval |

Each row above, and the A2 sentence, is proposed only and pending your approval.

## Evidence status

Verified: none yet. The National Insurance number you included isn't needed for this and I haven't used or repeated it. Your NMC registration number isn't repeated either, and checking the register is yours.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health careers Community Staff Nurse Band 5 district nursing"; both returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers: no page at that address. Moved RR1 (employer established) and RR2 (posting not located) |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary Calderdale Halifax", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook Community Health", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved the hiring contact row, RR4 and plan rows A1 and A2 |

I can save this as `tuesday-dossier.md` if you'd like to keep it.

**Upgrade menu**

- A line or example of your record-keeping (a sanitised audit result, an appraisal line) → R4 can move from `unclear`.
- Answers on end-of-life, leg-ulcer, continence and care-planning work → R11, R9, R10 and R12 firm up.
- A link to the vacancy on their own site, or Rhiannon Mabbott's confirmation → RR2 closes.
- The hours and rota from the informal chat → RR5 closes.
- Your pay floor, travel limits and any non-negotiables → the hard-gate checks against them can run. Right now they are unknown.
- A deeper research pass on Calderbrook (staff reports, past hiring, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G1 — In your ward and discharge-to-assess work, what did you record, in which system, and how soon after a shift or visit was it completed?

G2 — Have you cared for patients at the end of life, on the ward or on home visits? What was your part: symptom control, family conversations, care plans?

G3 — Have you dressed leg ulcers or applied compression bandaging, even once or under supervision? What did you personally do?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.