Still working on the assessment. I've read the playbook and most of its rules, and I'm now checking the evidence-map, gap and output rules. After that I'll run the employer research.
# Job Underwriting — Community Staff Nurse, Band 5, Calderbrook Community Health CIC (Halifax)

## Decision snapshot

**Yes, it's worth applying for, on a couple of light conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R4 (Clear, timely written records)
- `important` — direct: R7a, R8 · adjacent: R5 (Housebound adults in their own homes), R6 (Wound and leg-ulcer care) · unclear: R7b (Continence care), R10 (End-of-life visits), R11 (Care planning) · absent: R9 (Own caseload)
- `preferred` — absent: R12 (Doppler assessment)

R4 (`low`) — your CV is silent on records; R6 — a credible bridge, its limit named; R9 and R12 — you've told me you have neither, and the advert describes support for the first and lists the second as only desirable.

**Opportunity ledger.** A transparent post: pay, pool cars and senior support are all stated (RR3, RR4). Still open are whether the post is live, the rota, and whether Doppler training is offered (RR1, RR2, RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The post is confirmed live on the employer's own careers page (RR1).
  2. Your ward and discharge-team record-keeping is confirmed as evidence (R4, G4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | A community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` About Calderbrook Community Health page |
| Role | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record | `[grounded]` advert |
| Support and scope | A small caseload of your own, with a senior community nurse supporting | `[grounded]` advert |
| Pay and car | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` advert |
| Market calibration | Community staff nurse at this banding: median basic pay £34,300, interquartile range £32,400–£36,600, so the advertised range brackets the survey's middle half. Mileage was paid to 61% of respondents and a pool or lease car to 24%, so a pool car is the less common offer. The band describes England, not this employer. | `[generic]` Wardround 2026 pay guide, one salary search; `[grounded]` advert for the figures |
| Contact's footprint | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. At the 2025 community nursing forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work. | `[grounded]` forum speaker page |
| Unknowns | Whether the post is still live and its closing date; rota, weekends and any out-of-hours; whether Doppler training is provided; the name of the patient record system | — |
| Contradictions | None between the advert and the About page. The careers page could not be opened, so the posting is not confirmed live. | `[grounded]` About page; careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state registered nurse (adult), registration active, revalidation due March 2028. Nothing inspected here; checking the register is yours to do | `[grounded]` CV | You check your own register entry before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Stated: full UK licence, category B. Pool cars are provided, so no own vehicle is asked for | `[grounded]` CV, advert | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as an acute medical ward staff nurse. This is an experience length, so it is graded as a requirement, not a gate | `[grounded]` CV | none |
| R4 | Clear, timely written records (electronic patient record) | must_have | unclear | low | discovery | The CV says nothing about records or the system used, so I cannot tell what you have | `[grounded]` CV silence | Q1 below |
| R5 | Caring for housebound adults in their own homes | important | adjacent | medium | transferability | Eighteen months visiting patients at home in their first week after discharge is real home visiting. It is a post-discharge group, not long-term housebound patients, and that limit goes wherever the bridge is used | `[grounded]` CV | Frame as home visiting in discharge-to-assess, not as district nursing |
| R6 | Wound and leg-ulcer care | important | adjacent | medium | transferability | You have wound care including pressure ulcers and surgical wounds; leg ulcers are not mentioned. Leg-ulcer care is usually a distinct skill set from pressure-ulcer care | `[grounded]` CV; `[generic]` on how the skills differ | G3, Q3 |
| R7a | Catheter care | important | direct | medium | none | Stated on the CV | `[grounded]` CV | none |
| R7b | Continence care | important | unclear | low | discovery | CV mentions catheter care only | `[grounded]` CV silence | G5, Q2 |
| R8 | Insulin administration | important | direct | medium | none | Stated on the CV; no artifact | `[grounded]` CV | none |
| R9 | Holding a small caseload of your own | important | absent | none | capability | You have never held one. The advert says a senior community nurse supports the post | `[grounded]` your statement; advert | Carry as a stated risk; ask how support is structured (RR3) |
| R10 | End-of-life visits | important | unclear | low | discovery | The CV is silent, so I will not assume you did this | `[grounded]` CV silence | G5, Q2 |
| R11 | Care planning | important | unclear | low | discovery | The CV is silent | `[grounded]` CV silence | G5, Q2 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have not done one. The advert lists it as desirable, and the named contact has spoken publicly on Doppler training for staff new to community work | `[grounded]` your statement; advert; forum page | Ask whether training is provided (RR5) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own caseload (R9, important) | capability | Never held; discharge-to-assess visiting is the nearest thing | The advert names it as part of the role, so expect it in interview | Planning your own visits or reviewing your own patients on the discharge team, if that was part of it | A short account of how your discharge-team visits were allocated | `[grounded]` your statement |
| G2 | Doppler assessment (R12, preferred) | capability | None | Marked desirable, not essential | Observing or assisting at a leg-ulcer clinic, any compression training | A training record if one exists | `[grounded]` advert |
| G3 | Leg-ulcer care (R6, important) | transferability | Pressure ulcers and surgical wounds | The advert names leg-ulcer care and the contact has spoken on the topic | Compression bandaging, venous ulcer dressings on the ward | A sanitised dressing record or competency sign-off | `[inferred]` from the advert and the forum page |
| G4 | Records and the patient record system (R4, must_have) | discovery | CV silent | A must-have row at `unclear`; the one I most want evidence for | Ward and discharge-team documentation, any electronic record system | The system's name and any training or audit feedback | `[grounded]` CV silence |
| G5 | Continence, end-of-life and care planning (R7b, R10, R11; all important) | discovery | CV silent on all three | Each is a named duty in the advert | Continence assessments, end-of-life care on the ward, care plans you wrote or contributed to | A sanitised care plan or ward competency record | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | unknown | — | "Current vacancies are listed on our careers page." (About page) | The careers page I tried could not be opened, so the post may be listed elsewhere or have closed | `[inferred]` from the failed careers fetch | Is this post still open, and what is the closing date? | unresolved |
| RR2 | Working pattern unstated | unknown | — | "end-of-life visits" | Community nursing posts may include weekends or evenings; the advert does not say | `[generic]` pattern for community nursing posts | What is the working pattern, including weekends and any out-of-hours? | unresolved |
| RR3 | Senior support stated against a first caseload | positive_signal | — | "supported by a senior community nurse" | The post is built for someone new to holding a caseload | `[grounded]` advert | How is that support structured in the first months? | noted |
| RR4 | Pay and pool car stated | positive_signal | — | "£31,050–£37,800 a year plus mileage"; "pool cars are provided" | Transparent terms; the range sits within the survey's spread | `[grounded]` advert; `[generic]` survey band | Where in the range would someone with my experience start? | noted |
| RR5 | Doppler training not mentioned | unknown | — | "Desirable: Doppler assessment for leg ulcers" | The team may train new starters, as the lead's 2025 talk suggests, but the advert does not promise it | `[grounded]` forum page; `[inferred]` for this post | Is Doppler training provided to new starters, and how soon? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with: "Five years as a staff nurse on an acute medical ward, the last 18 months seconded to its discharge-to-assess team, visiting patients at home in their first week after discharge." Keep wound care, catheter care and insulin administration as you wrote them | Every clause is from your CV; it puts the home visiting first without calling it district nursing | `[grounded]` CV | pending your approval |
| A1 | Take up the informal chat with Rhiannon Mabbott and ask the RR1, RR2, RR3 and RR5 questions verbatim | The register doubles as interview preparation; the advert invites the call | `[grounded]` advert, register | pending your approval |
| A2 | Say plainly in your application that you have not held a caseload or done Doppler assessment, and that you want to | Both are visible gaps, and the advert has support and a desirable-not-essential Doppler in it | `[grounded]` your statements; advert | pending your approval |
| A3 | Confirm the post on the employer's own careers page before drafting anything long | See RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet. I haven't used your National Insurance number and don't need it for any of this; keep it off the application until an employer asks for it after an offer.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax community staff nurse" and got "About Calderbrook Community Health" (calderbrookhealth.example/about); the entity exists as described. The fetch of calderbrookhealth.example/careers returned no page, so the posting is not confirmed live (RR1). Moved: role reality's organization and contradictions rows |
| 2. Role-family sweep | yes | Searched "Community Staff Nurse Band 5 district nursing salary Agenda for Change pay scale" and got "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: market calibration and RR4 |
| 3. Contact's public professional footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead" and got "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: role reality's contact row, RR5 and the plan |

If you'd like this kept for later, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- The role's link on Calderbrook's own careers page → RR1 closes, and the decision likely simplifies to `go`.
- The name of the patient record system you've used, and anything showing training or audit feedback → R4 moves from `unclear`.
- A sanitised competency record or care plan → R6, R7b, R10 and R11 can move up.
- A pay floor or shift constraints you can't move on → hard-gate checks against them can run.
- A deeper pass on Calderbrook (recent news, inspection reports, staff reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

1. **G4 (R4):** Which electronic patient record system(s) have you documented in, on the ward and on the discharge team? Did anyone review your notes?
2. **G5 (R7b, R10, R11):** Have you done continence assessments, looked after patients at the end of life, or written or contributed to care plans? A line or two on each is enough.
3. **G3 (R6):** Have you applied compression bandaging or dressed venous leg ulcers, and were you signed off for it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.