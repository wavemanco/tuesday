Web search wasn't permitted in this session, so this runs only on what you pasted. Everything about Fernquay beyond your two texts is unverified.

## Decision snapshot

**Yes, the role is worth taking the call for, and on legitimacy I can't establish Fernquay from here. Nothing you pasted asks for money, ID or bank details (RR2). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R8 · unclear: R7 (Salary €52,000–€60,000)
- `must_have` — direct: R1, R2, R3, R4 · adjacent: R5 (Own the booking flow end to end)
- `important` — unclear: R6 (First designer, no design lead)

R5 (`medium`) — checkout is one part of a booking flow, and that limit is named; R6 — the one thing you haven't done, and it is waiting on your answer.

**Opportunity ledger.** Scope, pay range and reporting line are stated openly (RR5), but the employer is unverified from here (RR1). The WhatsApp channel is an open question and not a red flag (RR2). The equity terms are blank (RR3), and being the only designer is a real adjustment for you (RR4).

- **Hard gates:** none failed (R8 `direct`); unconfirmed: R7 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies as real and the role is live on their own site, see RR1; (2) the equity terms are written down, see RR3; (3) you are comfortable being the only designer, see R6 and RR4.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting as you pasted it |
| Mandate | First designer; own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Reports to or works with | Co-founder Ronan Kehoe; the call also includes Saoirse, the CTO | `[grounded]` posting and WhatsApp message |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting |
| Compensation | €52,000–€60,000 plus 0.5–1% equity; vesting, share class and strike terms not stated | `[grounded]` posting |
| Market calibration | Not calibrated. No search ran, so I give no market band and don't claim the range is fair or unfair | `[grounded]` no research ran |
| Scope read | A coherent first-designer scope: one flow, one customer type, two engineers. The cost is no design peer or lead | `[inferred]` from "first designer" against the team size |
| Unknowns | Equity terms; funding and runway; whether the role is on Fernquay's own site; the sender domain of the invite | — |
| Contradictions | None between the posting and the message: both name Ronan, and the message cites your checkout case study. This is consistency, not proof of identity | `[grounded]` your two pasted texts |

## Evidence map

Your background is prose, so everything is capped at `medium`. I haven't seen your portfolio.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company is over the posting's figure. Prose only, no artifact inspected | `[grounded]` your background | Share portfolio or case study link to raise to `high` |
| R2 | Strong Figma | must_have | direct | medium | none | You use Figma daily. Skill level isn't inspectable until a file is seen | `[grounded]` your background | Portfolio files would raise it |
| R3 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Limit: these were usability sessions, and the posting's calls with school owners may be more exploratory | `[grounded]` your background; `[inferred]` that owner calls are more exploratory | Be ready to say which sessions you planned and ran yourself |
| R4 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R5 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow, which is part of a booking journey. Limit: you haven't said you owned the whole journey, such as search, availability and confirmation | `[grounded]` checkout redesign; `[inferred]` that the whole flow is wider | See G1 |
| R6 | First designer, no design lead | important | unclear | low | discovery | You've never been the only designer. Whether you set design direction without a lead isn't established | `[grounded]` your statement | See G2 |
| R7 | Pay €52,000–€60,000 plus equity | hard_gate | unclear | low | hard_gate | The posting states the range. You haven't given a floor, so I can't say whether it meets your terms | `[grounded]` posting; no constraint stated | Tell me your floor and what you'd want on equity |
| R8 | Hybrid, two days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway last year. You haven't stated this as a constraint, so I rest it on where you live | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Whole booking flow (R5, must_have) | transferability | A checkout redesign, but not the steps before it | R5 is the headline responsibility, and checkout is the most likely stretch to be probed | Work on availability, search, basket or confirmation emails; a flow audit; cross-team ownership of a journey | The checkout case study, plus anything covering earlier steps | `[grounded]` checkout redesign; `[generic]` that interviewers probe the edges of ownership |
| G2 | Working without a design lead (R6, important) | discovery | "Never the only designer" says nothing about autonomy | It decides whether the first-designer remit is a stretch or a leap | Setting design standards, running critiques yourself, choosing research priorities, making calls without sign-off | A story or artifact where you made a design call without a lead | `[grounded]` your statement; `[inferred]` that autonomy may exist without the title |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who else will be on the call? | unresolved |
| RR2 | Contact on WhatsApp, invite sent by email | unknown | — | "I have emailed you a calendar invite with the video link" | Small teams often schedule by chat. The open question is whether the invite came from a Fernquay address | `[generic]` small-team scheduling habits | Can you confirm the invite was sent from your company email address? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The percentage may come without vesting, share class or dilution details | `[inferred]` from the posting giving a percentage and nothing else | What are the vesting schedule, share class and strike terms, and when would they be put in writing? | unresolved |
| RR4 | Only designer, no design lead | risk_signal | low | "You would be our first designer" | You may get no design critique or mentorship, and the role may be broader than your experience | `[inferred]` from "first designer" against your history | Who reviews your design work, and what does support look like in your first 90 days? | unresolved |
| RR5 | Pay, scope and reporting line stated openly | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | A posting that names pay, scope and who you work with is easier to check, and the message cites your own case study | `[grounded]` posting and your message | Which outcomes would define a good first year? | noted |

I'm judging only from the two texts you pasted, so please confirm the invite's sender address yourself before the call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check that the invite came from a Fernquay address and that the role is on their own site; if it isn't, ask them to point you to it | see RR1, RR2 | `[grounded]` register | pending your approval |
| A2 | Ask the verification questions from RR1–RR5 on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Lead with the checkout redesign and the monthly usability sessions in your own words ("I redesigned our checkout flow", "I ran monthly usability sessions with customers"). Say plainly that you haven't owned a whole booking journey | see R3, R5 | `[grounded]` your sentences | pending your approval |
| A4 | Bring one honest real project, messy included, since the posting says they prefer that. Say what was yours and what the squad's | The posting's own stated preference | `[grounded]` posting | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Fernquay booking software sea kayak surf schools Galway" and "Fernquay Product Designer Galway careers") were refused. They would have settled RR1 and role reality's contradictions row |
| 2. Role-family sweep | unavailable | One search (Irish product designer salary) was refused. It would have supplied the market calibration and a check on whether the pay band fits the seniority |
| 3. Hiring manager's public footprint | unavailable | One search on Ronan Kehoe was refused. It would have informed which of your stories to lead with. Public professional footprint only |

## Dossier offer

I can save this as `tuesday-dossier.md` whenever you like; there's no pressure.

## Upgrade menu

- Permission for web search → RR1 and the contradictions row could close, and the pay band could be calibrated.
- A deeper research pass (up to 5 more searches and 2 more fetches) on Fernquay's funding, news and hiring pattern → fills RR1 further. Say the word and it runs, once permission is granted.
- Your portfolio or checkout case study link → R1, R2, R3 and R5 can reach `high`.
- Your pay floor and equity expectations → R7 can resolve as met or failed.
- Interview prep for the call with Ronan and Saoirse is a separate job, mock-interview's, if you want it.

## Questions

G2 — Have you ever made a design call on your own, such as setting standards, choosing research priorities or running critiques, with no design lead signing off? What was it, and what happened?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G1 — Beyond checkout, did you work on any earlier steps of the booking journey (search, availability, confirmation)? What was yours?

R7 — What's your pay floor, and is equity a bonus or something you'd weigh seriously?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.