Search permission was refused, so everything below rests on the two postings and your background only. Where I describe the employers or the market, I say so.

# Decision snapshots

**Your question, answered per posting:** Duinvaart is worth your time. Kroonhaven is not, as posted.

## Duinvaart Cold Chain: Operations Analyst

**Yes, worth applying to. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: D1 (Hybrid, three days Rotterdam office)
- `must_have` — direct: D2, D3, D4
- `important` — direct: D5a · adjacent: D6 (Working with depot managers on route changes) · unclear: D5b (Temperature compliance, refrigerated fleet)
- `preferred` — adjacent: D7 (Dutch a plus)

D5b — new territory, not yet probed; D6 (`medium`) — dashboard and review confirmed, route changes not stated.

**Opportunity ledger.** The posting is concrete about outputs (DX4). The employer is unverified from here (DX1) and the pay is not stated (DX2). The office-days term is unresolved against your situation (DX3).

- **Hard gates:** none failed; unconfirmed: D1 (Hybrid, three days a week in Rotterdam); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the three Rotterdam days work from where you live (D1, DX3); (2) the employer and live posting verify (DX1); (3) temperature compliance is framed as new to you, never as experience you have (D5b).

## Kroonhaven Foods: Supply Planner

**No, not as posted. K2, K4 and K6 are must-haves with no matching work you've stated. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: K1 (On-site in Utrecht)
- `must_have` — adjacent: K5 (Fluent Dutch) · unclear: K3 (Advanced Excel) · absent: K2 (3+ years supply or demand planning in FMCG), K4 (SAP IBP or similar planning system), K6 (Own the 13-week supply plan)
- `important` — adjacent: K7 (Run the weekly S&OP meeting)

K2, K4, K6 — the planning core, which you told me you haven't done; K5 — conversational Dutch against a fluent bar.

**Opportunity ledger.** The posting is coherent: its mandate and requirements match each other (KX3). The employer is unverified from here (KX1) and the pay is not stated (KX2).

- **Hard gates:** none failed; unconfirmed: K1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** planning work you haven't mentioned (forecasting or capacity balancing that fed a plan), plus Dutch at working-fluent level.

# Duinvaart: detail

## Role reality (Duinvaart)

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; refrigerated fleet | `[grounded]` JD header |
| Employer check | Not established: no search result is available | `[grounded]` research refused, see tier line |
| Mandate | Track on-time delivery and temperature compliance; weekly Power BI dashboards; work with depot managers on route changes | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Scope read | An analyst post that reports and advises. The posting names no team, budget or decision rights | `[inferred]` from the JD's verbs against its silence on authority |
| Market calibration | Not given. The salary sweep did not run, and I won't quote a band from memory | `[grounded]` research refused |
| Unknowns | Pay; fleet size; who the depot managers report to; how route changes get decided | `[grounded]` JD silence |
| Contradictions | None inside the posting text; not checked against a careers page | `[grounded]` JD only |

## Evidence map (Duinvaart)

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | You have given no constraint on commute or office days, so there is no claim to grade. Whether the term fits your situation is unsettled | `[grounded]` JD term; no candidate statement | Closing question D1 |
| D2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | You describe 4 years as an operations analyst at a parcel carrier. Self-reported, nothing inspected yet, so `medium` | `[grounded]` your background message | none |
| D3 | Strong SQL | must_have | direct | medium | none | "SQL daily" is specific and plausible. "Strong" is a level nobody has inspected | `[grounded]` your background message | none |
| D4 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use, and you built the on-time delivery dashboard your depot managers use. No artifact inspected | `[grounded]` your background message | A sanitized screenshot would raise it to `high` |
| D5a | Track on-time delivery | important | direct | medium | none | The dashboard you built is on-time delivery for a parcel carrier. The metric transfers; this fleet is refrigerated | `[grounded]` your background message | none |
| D5b | Track temperature compliance on a refrigerated fleet | important | unclear | none | discovery | Nothing in what you gave me touches temperature or cold-chain monitoring. That is silence, not proof of absence. Teams that track compliance often reuse threshold-and-exception reporting, but that pattern is not evidence about you | `[grounded]` background silence; `[generic]` on reporting patterns | Closing question D5b |
| D6 | Work with depot managers on route changes | important | adjacent | medium | discovery | You ran the weekly route-performance review and depot managers use your dashboard. Whether those reviews led to route changes is not stated, so route changes stay unclaimed | `[grounded]` your background message | Closing question D5b's sibling in the upgrade menu |
| D7 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch is real but below fluent. The posting calls Dutch a plus, not a requirement | `[grounded]` your background message and JD | State "conversational", never "fluent" |

## Gap recovery queue (Duinvaart)

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GD1 | Office days and commute (D1, hard_gate) | hard_gate | The JD fixes three Rotterdam days; I don't know your base or limits | A term you can't meet ends the application however strong the fit | A commute you already do; a move planned; days at a site | A link to the live posting, to check the terms | `[grounded]` JD term; `[inferred]` that your base matters, since your last job was in Amsterdam |
| GD2 | Temperature compliance (D5b, important) | discovery | No cold-chain or compliance monitoring in what I have | The role's second headline metric. Resolving it moves the interview story | Reporting on delivery exceptions or SLA breaches; time-critical or sensitive parcels; any threshold-alert reporting | A dashboard view showing exception tracking | `[grounded]` background silence; `[generic]` that interviewers probe the domain gap |
| GD3 | Route changes (D6, important) | discovery | Reviews and a dashboard confirmed; outcomes not stated | The difference between reporting on routes and influencing them | A review that ended in a depot changing a route or schedule | A review agenda or action log, sanitized | `[grounded]` your background message |

## Opportunity risk register (Duinvaart)

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| DX1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| DX2 | Pay not stated | unknown | — | The posting as provided has no pay line | The figure may be market-normal or the employer may simply not publish it | `[inferred]` from the posting's silence; no band available | What salary range is budgeted for this post? | unresolved |
| DX3 | Office-day term against your situation (D1) | unknown | — | "Hybrid, three days a week in our Rotterdam office" | The three days may be fixed or flexible | `[inferred]` from the JD stating it without detail | Are the three office days fixed, and can they be set to suit travel? | unresolved |
| DX4 | Outputs and collaborators are named | positive_signal | — | "build weekly dashboards in Power BI, and work with depot managers on route changes" | The mandate is defined enough that success is observable | `[inferred]` from named deliverables in the JD | Which decisions do the weekly dashboards feed today? | noted |

## Application plan (Duinvaart)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| PD1 | Lead the application with the on-time delivery dashboard your depot managers use and the weekly route-performance review you ran. Say nothing about temperature compliance as experience | See D4, D5a, D6; D5b has no evidence | `[grounded]` your own sentences | pending your approval |
| PD2 | Describe Dutch as "conversational" | See D7 | `[grounded]` your own words | pending your approval |
| PD3 | Check the live posting and company site before sending anything | See DX1 | `[grounded]` register | pending your approval |
| PD4 | Ask DX2 and DX3 early, before investing in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| PD5 | Tailoring your CV to this posting is a job for resume-tailor, which I haven't run | You asked about worth, not CV edits | `[grounded]` your question | pending your approval |

# Kroonhaven: detail

## Role reality (Kroonhaven)

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; chilled ready-meals range | `[grounded]` JD header |
| Employer check | Not established: no search result is available | `[grounded]` research refused, see tier line |
| Mandate | Own the 13-week supply plan; balance capacity against the forecast; run the weekly S&OP meeting | `[grounded]` JD |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Scope read | A planning role with full ownership, aimed at someone who already does planning | `[inferred]` from "Own" and "3+ years of supply or demand planning" together |
| Market calibration | Not given. The salary sweep did not run, and I won't quote a band from memory | `[grounded]` research refused |
| Unknowns | Pay; planning system in use; who attends S&OP | `[grounded]` JD silence |
| Contradictions | None inside the posting text | `[grounded]` JD only |

## Evidence map (Kroonhaven)

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No stated constraint from you on location, so there is no claim to grade. Whether the term fits is unsettled | `[grounded]` JD term; no candidate statement | none unless you pursue the role |
| K2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You told me you have never worked in planning. The posting ties the requirement to years of experience, which makes it a requirement and not a gate | `[grounded]` your statement | closure path in GK1 |
| K3 | Advanced Excel | must_have | unclear | none | discovery | Excel does not appear in your background. That is silence, not proof of absence | `[grounded]` background silence | none unless you pursue the role |
| K4 | SAP IBP or a similar planning system | must_have | absent | none | capability | A planning system presumes planning work, and you've said you haven't done any. This is my inference from your statement, not something you said about tools | `[inferred]` from your statement | closure path in GK1 |
| K5 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational Dutch is real and below the stated fluent bar | `[grounded]` your background message | none unless you pursue the role |
| K6 | Own the 13-week supply plan, balancing capacity against forecast | must_have | absent | none | capability | The core of the job, and the work you say you haven't done | `[grounded]` your statement | closure path in GK1 |
| K7 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review, a different kind of meeting. S&OP means reconciling demand, supply and finance, which that review did not | `[grounded]` your background message | none unless you pursue the role |

## Gap recovery queue (Kroonhaven)

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GK1 | Planning core (K2, K4, K6, must_have) | capability | No planning work stated. You've said so directly | Three must-haves, and the role is the planning function | Forecasting or capacity-balancing work you did as an analyst and have not mentioned | A forecast model or capacity report you built | `[grounded]` your statement; `[generic]` that the realistic route is a role mixing analysis with planning, not one owning the plan outright |
| GK2 | Fluent Dutch (K5, must_have) | transferability | Conversational, below the bar | A language bar is screened early | Work conducted in Dutch; a recognised language assessment | A certificate or level assessment | `[grounded]` your background message |
| GK3 | Advanced Excel (K3, must_have) | discovery | Not in your background | A must-have with no evidence either way | Models or planning workbooks you built | A sanitized workbook | `[grounded]` background silence |
| GK4 | On-site Utrecht (K1, hard_gate) | hard_gate | Term fixed; your base unknown | Moot unless the fit changes | — | — | `[grounded]` JD term |

## Opportunity risk register (Kroonhaven)

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| KX1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| KX2 | Pay not stated | unknown | — | The posting as provided has no pay line | The figure may be market-normal or the employer may not publish it | `[inferred]` from the posting's silence; no band available | What salary range is budgeted for this post? | unresolved |
| KX3 | Mandate and requirements are consistent | positive_signal | — | "Own the 13-week supply plan … 3+ years of supply or demand planning in FMCG" | The role is priced and scoped for an experienced planner, not a bundled junior post | `[inferred]` from the match between ownership and years asked | Which decisions on the plan does the planner make without sign-off? | noted |

## Application plan (Kroonhaven)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| PK1 | Don't spend application effort on this posting as written | See K2, K4, K6 | `[grounded]` map rows | pending your approval |
| PK2 | If planning interests you long-term, look for postings that ask for analysis with some planning exposure, and check each against your background before applying | The gap is closed by a stepping-stone role, not by wording | `[generic]` role-family pattern | pending your approval |

# Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page (Duinvaart) | unavailable | Searched "Duinvaart Cold Chain Rotterdam refrigerated transport"; refused. Would have moved DX1 and the contradictions row |
| 1. Official site and careers page (Kroonhaven) | unavailable | Searched "Kroonhaven Foods Utrecht chilled ready meals"; refused. Would have moved KX1 and the contradictions row |
| 2. Role-family sweep (Duinvaart) | unavailable | Searched "operations analyst logistics salary Rotterdam Netherlands"; refused. Would have moved market calibration and DX2 |
| 2. Role-family sweep (Kroonhaven) | unavailable | Searched "supply planner FMCG salary Netherlands Utrecht"; refused. Would have moved market calibration and KX2 |
| 3. Hiring manager's public footprint (both) | n/a | No name was given for either posting, so there was no query to form |

I can offer the dossier as a file: say so and I'll write it up as `tuesday-dossier.md`, covering both postings.

**Upgrade menu**

- Search access, if you allow it, would check that both employers exist and the postings are live. That would move DX1 and KX1, and calibrate pay for DX2 and KX2. A deeper pass beyond that is up to 5 more searches and 2 more fetches; say the word.
- A link to each live posting or careers page resolves DX1 and KX1.
- The pay range, from the employer, closes DX2 and KX2.
- Your base and what commute you'll accept settles D1 and K1.
- A sanitized screenshot of your on-time delivery dashboard raises D4 to `high`.
- A review agenda or action log showing a route change that came out of it settles D6.
- A language level or certificate settles D7 and K5.
- An Excel model or forecast workbook you built would settle K3 and could reopen GK1.
- The hiring manager's name, for either posting, feeds the scope read and which story you lead with.

**Questions**

- D1 — Where would you be commuting from, and are three days a week in Rotterdam workable for you? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- D5b — In your parcel work, did you ever track or report on temperature-sensitive, time-critical or exception-flagged shipments, and what was yours to do? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.