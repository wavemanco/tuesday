Web search was declined, so I'm working from the text you pasted only. Here's the assessment.

## Decision snapshot

**Worth taking the call, with checks first. Status: `conditional_go`.** I can't confirm Fernquay exists as described, because my searches were refused (RR1). Nothing in the posting or the WhatsApp message asks you for money, ID or bank details (RR2).

**Fit ledger.**

- `hard_gate` — unclear: R8 (Two office days a week in Galway), R9 (Salary €52,000–€60,000)
- `must_have` — direct: R1, R2, R3, R4 · adjacent: R5 (Own the booking flow end to end)
- `important` — adjacent: R6 (Research calls with school owners) · absent: R7 (Work as the only designer)

R5 — a credible bridge, its limit named; R7 — the stretch you named yourself; R2 (`medium`) — the Figma claim is waiting on a portfolio.

**Opportunity ledger.** The employer can't be established from here (RR1). The WhatsApp contact is unexplained but carries no request that harms you (RR2). Success measures and support for a first designer are unstated (RR3), and the equity terms are unspecified (RR4). The posting is transparent about pay and scope (RR5).

- **Hard gates:** none failed; unconfirmed: R8 (Two office days a week in Galway), R9 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay checks out: a website, a live posting, and an invite from a company address (RR1, RR2); (2) pay and equity terms meet your floor (R9, RR4); (3) what "first designer" means in practice is concrete: support, success measures, decision rights (R7, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, booking software for sea-kayak and surf schools. This is the posting's own description and is not verified | `[grounded]` posting |
| Mandate | First designer. Own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Reports to / works with | Closest to co-founder Ronan Kehoe. The CTO, Saoirse, is on the call | `[grounded]` posting and message |
| Terms | €52,000–€60,000 plus 0.5–1% equity. Hybrid, two days a week in the Galway office | `[grounded]` posting |
| Scope read | A single-product mandate that is broad for one person: design, research and shipping with no peer designer | `[inferred]` from "first designer" against the three duties listed |
| Market calibration | Not run, because the role-family search was refused. I won't give a market figure from memory | — |
| Unknowns | Success measures; support for a first designer; equity terms; funding and runway; customer base | — |
| Contradictions | None between the posting and the message | `[grounded]` the two texts compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product design | must_have | direct | medium | none | You state 4 years as a product designer at a Dublin travel-booking company. That is confirmed and specific, with no inspectable artifact in hand | `[grounded]` your background | none |
| R2 | Strong Figma | must_have | direct | medium | none | You use Figma daily. Their message says they liked your checkout case study, but I haven't seen it | `[grounded]` your background | none |
| R3 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Limit: usability sessions are one kind of research | `[grounded]` your background | none |
| R4 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R5 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned a travel-booking company's checkout flow. Limit: checkout is one stage of a booking flow, and you haven't said whether you owned the earlier stages | `[grounded]` your checkout redesign; `[inferred]` that checkout is one part of a booking flow | G2 |
| R6 | Run research calls with school owners | important | adjacent | medium | transferability | Your sessions were with customers. Owner interviews are a different relationship and topic, and nothing says you've done those | `[grounded]` your sessions; `[inferred]` that owner calls differ from customer usability sessions | G4 |
| R7 | Work as the only designer (the posting says "first designer") | important | absent | none | capability | You've never been the only designer. Nearest evidence is your checkout ownership inside a squad | `[grounded]` your statement; `[inferred]` that "first designer" means no design peers | G1 |
| R8 | Two days a week at the Galway office | hard_gate | unclear | low | hard_gate | You live in Galway, which makes this plausible. You haven't stated how you feel about fixed office days | `[grounded]` your move back to Galway; posting terms | Confirm on the call |
| R9 | Salary €52,000–€60,000 against your floor | hard_gate | unclear | none | hard_gate | The posting states the pay. Your floor wasn't given, so I can't check it | `[grounded]` posting; no stated floor | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Sole designer (R7, important) | capability | You've always had design peers or a squad around you | They say you'd be first; how you'd set your own process is the likely probe | Setting up a research cadence, a component library or a design process yourself; the sole design voice on a feature | A case study of a messy real project, which the posting says they prefer | `[grounded]` your statement; `[generic]` that first-designer hires get probed on self-direction |
| G2 | End-to-end booking flow (R5, must_have) | transferability | Checkout is covered; earlier stages (availability, selection, confirmation, changes) aren't | Closing it turns R5 from adjacent to direct | Designing the search or availability step, handling cancellations or rebooking, owning the flow beyond payment | Flow diagrams or screens from the checkout case study | `[grounded]` the checkout claim; `[inferred]` that earlier stages are unstated |
| G3 | Pay floor (R9, hard_gate) | hard_gate | Pay is stated; your floor isn't | A gate I can't check | — | — | `[grounded]` posting; no floor given |
| G4 | Owner research (R6, important) | transferability | Customer usability sessions only | The posting names research calls with school owners | Interviews with small-business owners or B2B customers; stakeholder discovery calls | A research-plan or findings summary | `[grounded]` your sessions |
| G5 | Office days (R8, hard_gate) | hard_gate | You live in Galway; fixed days unconfirmed | Cheap to settle | — | — | `[grounded]` your location |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to the role on your own careers page, and to your company website? | unresolved |
| RR2 | First contact by WhatsApp, with an invite by email | unknown | — | "I have emailed you a calendar invite with the video link" | It may just be quick scheduling. Neither message asks for money, ID or bank details, and the interview is on video | `[generic]` startups often schedule over chat; `[grounded]` the message's text | Could the invite come from your company email address, and who else will be on the call? | unresolved |
| RR3 | No stated success measures or support for a first designer | unknown | — | "You would be our first designer: own the booking flow end to end" | Accountability may come without defined outcomes or design support | `[inferred]` from the posting's silence | What would a successful first six months look like, and who reviews design work today? | unresolved |
| RR4 | Equity terms unspecified | unknown | — | "0.5–1% equity" | Vesting, strike price, share class and dilution aren't stated | `[inferred]` from the posting's silence | What are the vesting and strike terms, and how is the company funded? | unresolved |
| RR5 | Transparent pay, named co-founder, concrete scope and hybrid terms | positive_signal | — | "Salary €52,000–€60,000 … two days a week at our Galway office" | Terms are stated openly rather than withheld | `[grounded]` posting | Who owns the booking flow's metrics today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check the invite's sender address against the company's own website. Find the company on Ireland's Companies Registration Office (CRO) search. Share nothing beyond your professional materials until there's a written offer | RR1, RR2 | `[generic]` standard pre-interview checks | pending your approval |
| A2 | Ask the verification questions from RR1, RR3 and RR4 on the call, word for word | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Say plainly that you haven't been the only designer. Pair it with what you owned: the checkout redesign and the monthly usability sessions | R7; every clause traces to your own sentences | `[grounded]` your background | pending your approval |
| A4 | Bring the checkout case study, with its rough edges visible | The posting says they'd rather see "one messy real project" | `[grounded]` posting | pending your approval |

If you take the call, interview rehearsal is a separate job that mock-interview covers.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Fernquay booking software sea kayak surf schools Galway"; the call was refused. It would have confirmed the company exists and the posting is live, feeding role reality and RR1 |
| 2. Role-family sweep | unavailable | Searched "product designer salary Ireland Galway 2026 startup"; the call was refused. It would have given the market band for role reality and R9 |
| 3. Hiring manager's public footprint | unavailable | Searched "Ronan Kehoe Fernquay co-founder"; the call was refused. It would have fed the scope read and the plan's positioning |

## Upgrade menu

- Permission to search the web → rows 1–3 above rerun: the company and its careers page, the market pay band, and Ronan Kehoe's public professional footprint. Any of these could close RR1 or move R9.
- Your minimum salary → R9 resolves, and the pay gate closes or fails.
- A link to the checkout case study → R2 and R5 can rise to `high`, and G2 narrows.
- A link to Fernquay's careers page or website → RR1 resolves.

I can write this up as `tuesday-dossier.md` if you want it kept.

Questions:

- G3 — What's the lowest salary you'd accept for this role, and does €52,000 clear it?
- G1 — Have you ever defined a process or shaped a feature where you were the only design voice? What was it, and what did you own?
- G2 — Which parts of the travel-booking flow beyond payment did you design, and how did you know the redesign worked?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.