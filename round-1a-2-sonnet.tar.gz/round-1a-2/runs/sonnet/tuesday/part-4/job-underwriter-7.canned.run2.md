I'm running the company and role-family searches the playbook calls for. They use only the employer, role and manager named in the advert, and none of your personal details.
## Decision snapshot

**Yes, this one is worth applying for. Status: `conditional_go`.** R1 and R2 are both hard gates and both `direct`, and R3 is `direct`. R4, the "clear, timely written records" requirement, is `unclear`, so it needs one answer from you.

**Fit ledger**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R4 (Clear, timely written records)
- `important` — direct: R5a, R6a, R7 · adjacent: R10 (Home care of housebound adults), R11 (Small caseload of your own) · unclear: R5b (Leg-ulcer care), R6b (Continence care), R8 (Care planning), R9 (End-of-life visits)
- `preferred` — absent: R12 (Doppler assessment)

R11 — a credible bridge, its limit named; R4 (`low`) — one answer would move it.

**Opportunity ledger.** The employer is established and the terms look sound: pay sits around the market band (RR2), senior support and pool cars are stated (RR3). Two things are unconfirmed, whether the posting is live on the employer's own site (RR1) and the rota and caseload size (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your answer on written records and the electronic patient record confirms R4 (see G1); (2) the vacancy is confirmed live on the employer's own careers page (see RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; 410 staff, four locality hubs | `[grounded]` About page, found by search |
| Mandate | Own a small caseload of housebound adults at home: wounds and leg ulcers, catheters and continence, end-of-life visits, insulin and care planning, on an electronic patient record | `[grounded]` advert |
| Support | Senior community nurse supports the caseload; pool cars provided | `[grounded]` advert |
| Team lead | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. At a 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page, fetched |
| Scope read | The mix of tasks is a normal district-nursing Band 5 remit | `[generic]` role-family pattern |
| Market calibration | A 2026 pay guide for England puts community Band 5 median basic pay at £34,300, interquartile range £32,400–£36,600. The advert's £31,050–£37,800 brackets that band. This is a survey snippet, not this employer's offer | `[generic]` survey; `[grounded]` advert figures |
| Unknowns | Caseload size, rota and weekend or on-call work, whether Doppler training is provided, whether the posting is live on the careers page | — |
| Contradictions | None found between the advert and the About page | `[grounded]` About page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult Nurse | hard_gate | direct | medium | none | CV states Adult registration, active, revalidation due March 2028. Stated by you; not yet inspected | `[grounded]` CV | You can screenshot your own NMC register entry; checking it is yours |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states a full UK licence, category B. Pool cars are provided | `[grounded]` CV and advert | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. A length-of-experience requirement, so not a gate | `[grounded]` CV | none |
| R4 | Clear, timely written records (electronic patient record) | must_have | unclear | low | discovery | CV is silent on record-keeping and on any electronic record system. A ward nurse records care, but you have not stated it, so it is not asserted | `[grounded]` CV silence | G1 |
| R5a | Wound care | important | direct | medium | none | Pressure ulcers and surgical wounds are stated | `[grounded]` CV | none |
| R5b | Leg-ulcer care | important | unclear | low | discovery | The CV does not mention leg ulcers. Pressure ulcers are a different wound type | `[grounded]` CV silence | G2 |
| R6a | Catheter care | important | direct | medium | none | Stated on the CV | `[grounded]` CV | none |
| R6b | Continence care | important | unclear | low | discovery | The CV names catheter care only | `[grounded]` CV silence | G2 |
| R7 | Insulin administration | important | direct | medium | none | Stated on the CV | `[grounded]` CV | none |
| R8 | Care planning | important | unclear | low | discovery | The CV does not mention care planning | `[grounded]` CV silence | G3 |
| R9 | End-of-life visits | important | unclear | low | discovery | The CV does not mention end-of-life care. Its absence from the CV does not show it was never done | `[grounded]` CV silence | G2 |
| R10 | Caring for housebound adults in their own homes | important | adjacent | medium | transferability | Eighteen months on a discharge-to-assess team visiting patients at home in their first week after discharge. Limit: short post-discharge episodes, not an ongoing housebound caseload | `[grounded]` CV | Frame as adjacent, never as district-nursing experience |
| R11 | Hold a small caseload of your own | important | adjacent | medium | transferability | You state you have never held your own caseload. The home visiting is adjacent evidence. Limit: ownership of a caseload is not shown. The advert says a senior nurse supports it | `[grounded]` your statement and CV; `[grounded]` advert | G3 |
| R12 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You state you have never done one. The team lead has spoken on Doppler training for staff new to community work. Whether this employer trains new starters is not established | `[grounded]` your statement; `[inferred]` that training may be offered | Ask in the informal chat whether training is provided |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records and electronic patient record (R4, must_have) | discovery | The CV says nothing about records or systems | The one essential requirement not yet evidenced, so it holds the status at `conditional_go` | Using an electronic patient record on the ward, discharge documentation for the assessment team, record-keeping audits | A reference line from a ward manager, or an audit result | `[grounded]` CV silence; `[inferred]` that one answer could move the status |
| G2 | Leg-ulcer, continence and end-of-life work (R5b, R6b, R9, important) | discovery | The CV names pressure ulcers, surgical wounds and catheters only | These are named duties of the post, and the CV does not yet show whether you have done them | Compression bandaging on the ward, bladder or bowel care beyond catheters, caring for dying patients on a medical ward | A competency record or training certificate | `[grounded]` CV silence; `[generic]` that wards and community teams treat these as routine |
| G3 | Working alone, care planning and caseload (R8, R11, important) | transferability | Home visiting is stated; whether you visited alone, set plans and made decisions is not | Decides how honestly the caseload bridge can be framed | Visiting alone, deciding who needed a return visit, writing or updating care plans, escalating to the GP | A discharge-to-assess service description | `[grounded]` CV; `[inferred]` limit |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's careers page | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | My one guessed careers address returned no page. That shows nothing about the vacancy: it may sit at another address | `[grounded]` fetch returned no page; `[generic]` that vacancies often sit at other addresses | Can you confirm this vacancy is open and point me to it on your careers page? | unresolved |
| RR2 | Stated pay against the survey band | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range brackets the survey median and interquartile range, so pay is not a below-market sign | `[grounded]` advert figures; `[generic]` England-wide survey snippet | Where in the range would a nurse with five years' acute experience start? | noted |
| RR3 | Senior support and pool cars stated | positive_signal | — | "supported by a senior community nurse"; "pool cars are provided" | Lowers the risk of an unsupported caseload and of car costs. In the survey only a quarter had a pool or lease car | `[grounded]` advert; `[generic]` survey | How is the senior nurse's support structured, for example joint visits and supervision? | noted |
| RR4 | Rota and caseload size unstated | unknown | — | "hold a small caseload of your own" | The advert gives no hours, weekend or on-call pattern, or caseload size | `[inferred]` from the advert's silence | What are the working hours and rota, including weekends, and how many patients is a typical caseload? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the vacancy is live on the employer's own site before investing effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Call Rhiannon Mabbott for the informal chat and ask the RR3 and RR4 questions, plus whether Doppler training is provided | see R12, RR4 | `[grounded]` advert's invitation | pending your approval |
| E1 | CV: lead with the discharge-to-assess home visits, in your own words ("visiting patients at home in their first week after discharge"), then wound, catheter and insulin work | see R5a, R6a, R7, R10 | `[grounded]` CV | pending your approval |
| E2 | CV: add a record-keeping line only after you answer G1. Nothing is written until then | see R4 | `[grounded]` R4 row | pending your approval |

## Evidence status

Verified: none yet. Your National Insurance number isn't needed for this. I haven't used it and haven't repeated it, and it belongs only in an employer's own portal after a written offer. Your NMC PIN is not needed either. Your registration is taken as kind, class, status and expiry, and checking it is yours.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and a careers-focused query. Both returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, which returned no page. Moved: the employer exists as described, which is why there is no standing employer entry. It also produced RR1 |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing role expectations caseload Doppler training salary 2026", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: market calibration and RR2, RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead" and fetched "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: R12's reasoning and plan row A2 |

## Dossier and upgrade menu

I can save this as `tuesday-dossier.md` if you'd like to keep or reuse it.

- Your pay floor and any non-negotiables (hours, weekends, travel) → the hard-gates line moves from "not given" to checked.
- A record-keeping reference or audit result → R4 from `low` towards `medium`.
- Your own NMC register entry, seen by you → R1 towards `high`.
- A competency record for compression, continence or end-of-life care → G2 closes the rows it covers.
- The live vacancy link on the employer's site → RR1 closes.
- A deeper research pass on Calderbrook (leadership changes, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

G1 — On your ward, did you record care on an electronic patient record, and how was your record-keeping checked or audited?
G2 — Have you done leg-ulcer or compression care, continence care beyond catheters, or end-of-life care for dying patients, and roughly how often?
G3 — On the discharge-to-assess visits, did you visit alone, and did you decide the plan or the next visit yourself, or was that set by someone else?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.