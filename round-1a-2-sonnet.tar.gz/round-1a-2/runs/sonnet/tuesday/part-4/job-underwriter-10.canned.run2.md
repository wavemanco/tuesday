Checking whether Fernquay exists as described, then I'll write up the assessment.
Fernquay looks real. I checked what I could, and the WhatsApp message on its own isn't a warning sign.

## Decision snapshot

**Yes, worth taking the call, and the employer checks out on what I could reach. Status: `conditional_go`.** The conditions are below.

**Fit ledger.**

- `hard_gate` — direct: R7 · unclear: R8 (Pay €52,000–€60,000 against your floor)
- `must_have` — direct: R1, R2, R3, R4
- `important` — adjacent: R5 (Own the booking flow end to end), R6 (First designer, no design peers)

R5, R6 — credible bridges, limits named; R3 (`medium`) — usability sessions confirmed, discovery-style calls with school owners not yet evidenced.

**Opportunity ledger.** The employer matches its own posting (RR1). The WhatsApp contact is unusual but explained, pending one check (RR2). Equity terms (RR3), design decision rights (RR4) and the firm's runway (RR5) are unknown. The stated pay is clear (RR6).

- **Hard gates:** none failed (R7 `direct`); unconfirmed: R8 (Pay €52,000–€60,000 against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the invite and any later messages come from Fernquay's own domain, see RR2; (2) the pay clears your floor, see R8; (3) the equity terms turn out to be concrete, see RR3; (4) the sole-designer reality is acceptable to you, see R6 and RR4.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people, Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, "funded by its customers" | `[grounded]` fernquay.example/about |
| Posting live and consistent | The careers page matches your posting: first design hire, hybrid, two days a week in Galway, €52,000–€60,000 plus equity, apply with one real project | `[grounded]` careers page fetched |
| Hiring manager | Ronan Kehoe is listed as co-founder and CEO, and before Fernquay was product lead at a Galway travel-software company for five years. That is close to your travel-booking background | `[grounded]` search result, LinkedIn-style profile page |
| Your CTO contact | Saoirse is named on the About page as co-founder. The page does not give her title as CTO | `[grounded]` About page; `[inferred]` the title is simply not on that page |
| Scope read | One designer owning a booking flow, with research and shipping alongside two engineers. Ordinary for a first design hire at a six-person company, though no design peer means no critique | `[inferred]` from the posting's own scope against its team size |
| Market calibration | Irish product designers with 3 to 5 years: median €57,000, interquartile range €51,500 to €62,000. The posted range sits inside that, a stated figure and not an estimate | `[generic]` 2026 Tillerby Ireland report, n=520; `[grounded]` posting's range |
| Thin footprint | Four searches found their own pages and one founder profile, and no independent coverage or customer reviews. That is not proof either way, and I searched only a handful of times | `[grounded]` searches run; `[generic]` that a 2023 customer-funded six-person firm often has little press |
| Unknowns | Equity terms; design decision rights; runway; how the WhatsApp number was obtained | `[grounded]` posting and message are silent |
| Contradictions | None between the posting, the careers page, the About page and the message's names | `[grounded]` pages compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company. Self-reported, with no document inspected yet | `[grounded]` your background statement | none |
| R2 | Strong Figma | must_have | direct | medium | none | "Figma daily" is confirmed. Nothing inspectable has been shared; a portfolio file is the artifact designers keep | `[grounded]` your statement | bring a Figma file of the real project |
| R3 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. The posting also wants calls with school owners, which are interview-style, so the limit is named: usability testing is one kind of research | `[grounded]` your statement; `[inferred]` the posting's research calls are discovery-style | be ready to say what you ran yourself |
| R4 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your statement | none |
| R5 | Own the booking flow end to end | important | adjacent | medium | transferability | You redesigned a checkout flow, which is one stage of a booking flow. Limit: whether you owned research-to-ship, and the stages before and after checkout, is not yet stated | `[grounded]` your statement; `[inferred]` the posting's scope | see G2 |
| R6 | Be the first designer (an implied requirement: working without a design peer) | important | adjacent | low | transferability | The posting says "our first designer", which implies self-direction without a lead. You have never been the only designer, and you worked in a squad. Limit: no evidence yet of setting design direction with no design lead above you | `[grounded]` posting and your statement; `[inferred]` the implied requirement | see G2 |
| R7 | Hybrid, two days a week in Galway | hard_gate | direct | high | none | You live in Galway, and the posting's two office days are met by that. Confidence grades your own statement of where you live | `[grounded]` your statement and posting | none |
| R8 | Pay €52,000–€60,000 plus 0.5–1% equity against your floor (your constraint, not yet given) | hard_gate | unclear | none | hard_gate | The posting states the pay. Your floor has not been stated, so I can't say whether it clears it | `[grounded]` posting; your floor not given | ask your floor (G1) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R8, hard_gate) | hard_gate | The posting gives €52,000–€60,000 plus equity; your minimum is not stated | A gate not established stays visible and caps the decision | A minimum base salary; whether you would trade pay for equity | Your own number | `[grounded]` posting and absence of your floor |
| G2 | Own the booking flow, and work without a design peer (R5, R6) | transferability | The checkout redesign and monthly usability sessions are confirmed. Which parts you owned, and whether you ever set design direction yourself, are not | These are the two rows the interview is likeliest to probe | Choosing what to research and what to ship; defining the checkout's components or patterns; making calls when engineers and product disagreed | Your checkout case study, plus a line on what you owned versus the squad | `[grounded]` your statement; `[generic]` that a first-designer interview probes ownership |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer matches the posting | positive_signal | — | "Six people, based in Galway" | The firm exists as described and the role is live. This rests on their own pages, not independent corroboration | `[grounded]` About and careers pages | Who else has worked with your team, and could I speak to one current team member? | noted |
| RR2 | First contact by WhatsApp, interview invite by email | unknown | — | "I have emailed you a calendar invite with the video link" | Scheduling by chat for a video call held elsewhere, with the invite emailed, is ordinary at a small firm. The Ronan and Saoirse named match the About page. Open check: whether the invite comes from Fernquay's own domain and how the number was obtained | `[grounded]` message and About page; `[generic]` that small firms often use chat to schedule | Can you confirm the invite will come from your Fernquay address, and that the call is on a link you will share by email? | unresolved |
| RR3 | Equity terms not stated | unknown | — | "0.5–1% equity" | The grant could be options or shares, with vesting and a strike price. A customer-funded firm's equity may be worth little until it has a valuation | `[inferred]` from the posting giving a percentage and no terms; `[generic]` on equity at small firms | Are these options or shares, over what vesting period, at what strike price, and what is the total share count? | unresolved |
| RR4 | Design decision rights not stated | unknown | — | "own the booking flow end to end" | You may own the flow in name while product decisions sit with the co-founder | `[inferred]` from the posting's scope against its silence on decision rights | Which product decisions would I make alone, and which would go to you? | unresolved |
| RR5 | Runway not stated | unknown | — | "funded by its customers" | Customer-funded means no investor cushion, and its stability depends on revenue I can't see | `[grounded]` About page; `[inferred]` stability is unknown | How many schools pay today, and is revenue growing? | unresolved |
| RR6 | Pay stated and within market | positive_signal | — | "€52,000–€60,000" | A clear range, inside the typical band for the experience level | `[grounded]` posting; `[generic]` Tillerby band | What is the progression for the first designer? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check that the invite arrives from a Fernquay address, and that the number was one you gave in your application. Use the careers page's jobs address, not WhatsApp, to confirm if in doubt | see RR2 | `[grounded]` careers page | pending your approval |
| A2 | Take the call. Bring one real project, the checkout redesign, and tell it as what you personally owned versus what the squad did | The posting says it would rather see one messy real project than a polished deck | `[grounded]` posting | pending your approval |
| A3 | Ask RR3, RR4 and RR5 questions verbatim on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | Ask Ronan how he would support a designer with no design peer | see R6 | `[inferred]` from R6 | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay Product Designer Galway careers"; found "About Fernquay" (fernquay.example/about) and fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Role reality: organization, posting live, contradictions; register: RR1 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland first designer startup Galway", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Market calibration and RR6 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Role reality: hiring manager row; plan A2 |

## Dossier offer

If useful, I can save this as `tuesday-dossier.md` so a later step can pick it up.

## Upgrade menu

- Your minimum salary and non-negotiables → R8 closes, and the decision simplifies to `go` or `no_go`.
- The checkout case study or a Figma file → R2 and R3 can rise toward `high`, and R5's bridge firms up.
- Where the invite comes from, and how Fernquay got your number → RR2 closes.
- Equity terms from Ronan → RR3 closes.
- A deeper pass on Fernquay (customer reviews, any news; up to 5 more searches and 2 more fetches) → says more about RR5. Say the word and it runs.
- The mock-interview module can prep you for the 45-minute call with Ronan and Saoirse.

## Questions

G1 — What is the minimum base salary you would accept, and is there anything else you won't trade (days in the office, equity in place of pay)?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — In your checkout redesign, which parts did you personally decide and own, and have you ever set design direction without a design lead above you?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

RR2 — Did your application go to jobs@fernquay.example, and did it include the checkout case study and your WhatsApp number?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.