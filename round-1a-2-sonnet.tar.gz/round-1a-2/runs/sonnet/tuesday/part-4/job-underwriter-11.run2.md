Search permission was denied, so I'm underwriting both roles from your posts and background alone. Every outside claim is labelled and the research gaps are shown.

# Duinvaart Cold Chain: Operations Analyst (Rotterdam)

## Decision snapshot

**Yes, this one is worth your time. R2, R3 and R4 (the must-haves) are all `direct` from your background. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Hybrid, three days in Rotterdam)
- `must_have` — direct: R2, R3, R4
- `important` — direct: R5 · adjacent: R7 (Working with depot managers on route changes) · unclear: R6 (Temperature compliance)
- `preferred` — adjacent: R8 (Dutch a plus)

R6 — cold-chain-specific, nothing on your background yet; R7 (`medium`) — a bridge, its limit named.

**Opportunity ledger.** The scope is concrete (RR3), but the employer was not checked (RR1) and the pay is withheld (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, three days a week in Rotterdam); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 is workable for you; (2) the employer and live posting verify (RR1); (3) you can show cold-chain-adjacent evidence for R6, or accept it as a learning gap.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, a refrigerated-fleet operator in Rotterdam | `[grounded]` posting header; existence not checked |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` posting |
| Working pattern | Hybrid, three office days a week | `[grounded]` posting |
| Scope read | A mid-level analyst role. The listed tools and deliverables are ones you already use | `[inferred]` from the posting's requirements against your stated work |
| Market calibration | Not run. The search was refused, and the posting states no pay | `[grounded]` posting silent on pay |
| Unknowns | Salary; team size; who owns the temperature data; whether Dutch is used day to day | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | You have given no constraint, and your home base is not stated. Your last employer was in Amsterdam | `[grounded]` posting; your constraints not given | G3 |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | 4 years as an operations analyst at a parcel carrier. Self-reported, nothing inspectable yet | `[grounded]` your background | none |
| R3 | Strong SQL | must_have | direct | medium | none | Your own words: daily use. Depth is untested until a probe or a technical screen | `[grounded]` your background | none |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use, including the on-time dashboard your depot managers use | `[grounded]` your background | none |
| R5 | Track on-time delivery and build weekly dashboards | important | direct | medium | none | The dashboard you built for depot managers is the same work | `[grounded]` your background | none |
| R6 | Temperature compliance across a refrigerated fleet | important | unclear | low | discovery | Nothing in your background mentions temperature or cold-chain data. Parcel on-time work does not show it | `[grounded]` silence in your background | G1 |
| R7 | Work with depot managers on route changes | important | adjacent | medium | transferability | You ran a weekly route-performance review and depot managers use your dashboard. Limit: nothing says you proposed or decided route changes | `[grounded]` your background; limit `[inferred]` from silence | G2 |
| R8 | Dutch a plus | preferred | adjacent | medium | none | Conversational, not fluent. The posting counts it as a plus only | `[grounded]` your statement and the posting | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R6, important) | discovery | Nothing on temperature or cold-chain data | It is the one part of the posting specific to this employer's trade | Delivery exception reports for time-sensitive or perishable parcels; any SLA or compliance dashboard; breach or excursion tracking | A dashboard screenshot with figures removed, or an exception-report definition | `[grounded]` background silence; `[generic]` that employers in this field screen for it |
| G2 | Route changes (R7, important) | transferability | A route review, but not who decided changes | An interviewer will ask what changed because of your analysis | A route or depot change your review prompted; a recommendation a depot manager acted on | A review pack or meeting notes with figures removed | `[grounded]` your background; `[generic]` that interviewers probe the analysis-to-decision link |
| G3 | Office days and location (R1, hard gate) | hard_gate | Constraint unknown | An unworkable commute ends the application whatever the fit | Not applicable | Not applicable | `[grounded]` your constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not checked | unknown | — | "Duinvaart Cold Chain, Rotterdam" | Search was refused, so existence and a live posting are unconfirmed. This may just be a smaller firm | `[generic]` pattern for unchecked postings, not a claim about this firm | Can I see this role on your own careers page, and who would I report to? | unresolved |
| RR2 | Pay withheld | unknown | — | no figure given | Pay may be below or at the market band for this seniority | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Concrete scope and named tools | positive_signal | — | "build weekly dashboards in Power BI" | The role is well defined and matches your daily tools | `[grounded]` posting | Which depot or fleet metrics would I own from week one? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the depot-manager on-time dashboard and the weekly route-performance review | see R4, R5, R7 | `[grounded]` your background | resume_edits_pending_approval |
| A1 | Check the posting on Duinvaart's own careers page before applying | see RR1 | `[grounded]` register | pending your approval |
| Q1 | Ask RR1, RR2 and RR3's questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

# Kroonhaven Foods: Supply Planner (Utrecht)

## Decision snapshot

**No, I'd skip this one. R11, R13 and R14 (must-haves) are absent: this is planning work and you haven't worked in planning. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R9 (On-site in Utrecht)
- `must_have` — adjacent: R10 (Fluent Dutch) · unclear: R12 (Advanced Excel) · absent: R11 (3+ years planning in FMCG), R13 (SAP IBP or similar), R14 (Own the 13-week supply plan)
- `important` — adjacent: R15 (Run the weekly S&OP meeting)

R15 — a facilitation bridge, its limit named; R10 — conversational, not fluent.

**Opportunity ledger.** The role itself reads as coherent (RR5). The employer was not checked (RR4).

- **Hard gates:** none failed; unconfirmed: R9 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** for a `conditional_go`, planning experience (R11, R14) and a planning-system skill (R13) would have to exist. That takes a move into planning first, not better wording.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, a chilled ready-meals producer in Utrecht | `[grounded]` posting header; existence not checked |
| Mandate | Own the 13-week supply plan, balance capacity against forecast, run the weekly S&OP | `[grounded]` posting |
| Working pattern | On-site in Utrecht | `[grounded]` posting |
| Scope read | A role that expects planning experience from day one. Nothing in it is entry-level | `[inferred]` from the 3+ years and named-system requirements |
| Market calibration | Not run. The search was refused, and the posting states no pay | `[grounded]` posting silent on pay |
| Unknowns | Salary; team size; whether S&OP meetings run in Dutch | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R9 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | You have given no constraint, and your home base is not stated | `[grounded]` posting; your constraints not given | Only worth asking if you'd pursue the role |
| R10 | Fluent Dutch | must_have | adjacent | medium | transferability | You say conversational, not fluent. Limit: the posting says fluent, and chairing a meeting is a heavier use than conversation | `[grounded]` your statement and the posting | none |
| R11 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You said you've never worked in planning. Parcel operations analysis is adjacent work, not planning | `[grounded]` your statement | G4 |
| R12 | Advanced Excel | must_have | unclear | low | discovery | Your background names SQL and Power BI, not Excel | `[grounded]` background silence | none: it can't move the decision |
| R13 | SAP IBP or a similar planning system | must_have | absent | none | capability | SQL and Power BI are reporting tools, not planning systems | `[grounded]` your background | G4 |
| R14 | Own the 13-week supply plan | must_have | absent | none | capability | No planning ownership in your background | `[grounded]` your statement | G4 |
| R15 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review. Limit: nothing says it balanced demand and supply across functions | `[grounded]` your background; limit `[inferred]` from silence | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G4 | Planning experience and system (R11, R13, R14, all must_have) | capability | No planning role, no planning system | Three absent must-haves decide this one | Not applicable: no question, since you've said you haven't done it | A planning-system certification or a junior planner role would be the closure path | `[grounded]` your statement; `[generic]` that closing this takes months to years |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR4 | Employer not checked | unknown | — | "Kroonhaven Foods, Utrecht" | Search was refused, so existence and a live posting are unconfirmed | `[generic]` pattern for unchecked postings, not a claim about this firm | Can I see this role on your own careers page, and who would I report to? | unresolved |
| RR5 | Clear, coherent scope | positive_signal | — | "Own the 13-week supply plan" | The mandate and requirements agree with each other | `[grounded]` posting | Which planning system is in use today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| none | No action proposed while the status is `no_go` | see R11, R13, R14 | `[grounded]` map | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam refrigerated transport careers Operations Analyst" and "Kroonhaven Foods Utrecht chilled ready-meals careers Supply Planner"; both refused. Would have confirmed each employer exists and the posting is live (RR1, RR4) |
| 2. Role-family sweep | unavailable | Searched "operations analyst logistics salary Rotterdam Netherlands" and "supply planner FMCG salary Netherlands Utrecht"; both refused. Would have set market calibration and RR2 |
| 3. Hiring manager's public footprint | n/a | No names were given, so there was no query to form |

The dossier is available as `tuesday-dossier.md` if you want it, and I'd only write it on your say-so.

Upgrade menu:
- Search access → both employers confirmed live (RR1, RR4) and pay bands for R1 and RR2.
- A dashboard screenshot or review pack with figures removed → R4, R5 and R7 move toward `high`.
- Your home base and commute limit → R1 and R9 resolve.
- A hiring manager's name → the scope read and which story to lead with.
- Once you decide to apply to Duinvaart, resume-tailor can rework your CV for it.
- A deeper research pass on both employers (up to 5 more searches and 2 more fetches) — say the word and it runs.

Questions:

G1 — Have you tracked anything time- or temperature-sensitive at the parcel carrier, such as perishables, SLA breaches or exception reports? What did you own, and what happened?
G2 — Did your weekly route review ever lead to a route or depot change? Who made the call, and what was your part?
G3 — Is three office days a week in Rotterdam workable for you?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.