Running the job-underwriter on your offer. Web searches were declined, so I couldn't check Marrowgate Housing online and I'm going only on what you've pasted.

## Decision snapshot

**Yes, it's normal for an employer to ask for bank details, PPS number and a passport scan after a written offer like this one. Accept, but enter them only in the employer's own portal. Status: `conditional_go`.**

You were right to be wary of handing these over before an offer. This request comes after one, so it isn't a red flag in itself (RR3).

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Hybrid, two days Limerick office), R3 (Pay €38,000–€42,000)
- `must_have` — direct: R4, R6 · adjacent: R7 (Monthly payroll for 240 staff) · unclear: R5 (Irish PAYE, PRSI and USC)
- `important` — direct: R8, R9 · absent: R10 (Pension changes)

R5 — your Irish tax experience isn't stated in what you've told me; R7 — scale and pay cycle differ from your hotel group work; R10 — a gap you've named yourself, learnable on the job.

**Opportunity ledger.** The offer looks credible on its face: it is specific and inside the posted pay band (RR2). But I can't confirm the employer from here (RR1), and the onboarding request is routine only once the portal's address checks out (RR3).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Hybrid, two days Limerick office), R3 (Pay €38,000–€42,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the portal address checks out as the employer's own — RR1, RR3; (2) two Limerick days and €40,000 meet your own limits — R2, R3; (3) pension-change duties are raised with Declan Garvagh before you start — R10.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick. Its existence is not established from here | `[grounded]` posting and offer email; existence not checked (search refused) |
| Mandate | Monthly payroll for 240 staff; starters, leavers and pension changes; monthly payroll-to-ledger reconciliation; staff payroll queries | `[grounded]` posting |
| Terms offered | Permanent, €40,000, hybrid with two days a week in the Limerick office, reporting to Declan Garvagh (Finance Manager); start after your notice period; reply within five working days | `[grounded]` offer email |
| Scope read | One function, ordinary for a payroll post. Whether anyone else does payroll or pensions is not stated | `[inferred]` from the posting's single-function duties |
| Market calibration | Not run, because the role-family search was refused. The offer sits inside the posted band | `[grounded]` posting band and offer figure compared |
| Unknowns | Whether the portal is on the employer's own domain; who handles pension changes today; payroll software used | — |
| Contradictions | None between the posting and the offer on role, hybrid pattern or pay | `[grounded]` the two texts compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | A payroll qualification or working towards one | hard_gate | direct | medium | none | You hold a Payroll Technician certificate (2024). It is a stated claim with no document inspected | `[grounded]` your stated background | A copy of the certificate would raise this to high |
| R2 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | You haven't stated your commute or location limits, so this gate is unsettled | `[grounded]` no constraint given | Answer the closing question on your limits |
| R3 | Salary €38,000–€42,000 (offer: €40,000) | hard_gate | unclear | none | hard_gate | The offer is inside the band, but your own pay floor isn't stated | `[grounded]` offer and posting figures; your floor not given | Answer the closing question on your limits |
| R4 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff, self-reported with nothing inspected | `[grounded]` your stated background | none |
| R5 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your background doesn't say the hotel group's payroll ran under Irish rules. Irish employers normally expect this to be hands-on | `[grounded]` your background is silent; `[generic]` the normal expectation | See G1 |
| R6 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP, self-reported | `[grounded]` your stated background | none |
| R7 | Run the monthly payroll for 240 staff | must_have | adjacent | medium | transferability | Fortnightly payroll for 90 staff carries over. The limit is that you haven't run a monthly cycle or this headcount | `[grounded]` your stated background; `[inferred]` the limit from the scale difference | See G3 |
| R8 | Process starters and leavers | important | direct | medium | none | Stated directly in your background | `[grounded]` your stated background | none |
| R9 | Monthly payroll-to-general-ledger reconciliation | important | direct | medium | none | Stated directly in your background | `[grounded]` your stated background | none |
| R10 | Process pension changes | important | absent | none | capability | You've never done these; your manager handled them. No adjacent work is stated | `[grounded]` your own statement | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI, USC (R5, must_have) | discovery | Payroll experience is stated, but not which jurisdiction's tax rules it ran under | A must-have that is currently unclear. You've already been offered the job, so it matters for how ready you are, not whether you get in | Revenue payroll submissions, handling tax credit and RPN changes, year-end returns | A redacted payslip layout, a Revenue return you prepared, or a course module | `[grounded]` background silent on jurisdiction; `[generic]` that these are the usual evidence in Irish payroll |
| G2 | Pension changes (R10, important) | capability | No direct or adjacent work stated | A named duty of the post and one your manager held at the hotel group | Sitting in on pension changes, preparing the payroll side of auto-enrolment starters | A short pension or payroll-pensions course certificate | `[grounded]` your statement; `[inferred]` that it is learnable on the job |
| G3 | Monthly cycle at 240 staff (R7, must_have) | transferability | Fortnightly payroll for 90 staff, with monthly reconciliation | The scale and cycle are the stated limit of the bridge. Say "adjacent" about this honestly | Month-end close work, a larger pay run during a peak season | A description of your busiest pay run | `[grounded]` your background; `[inferred]` the limit |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | I couldn't check the employer because searches were refused. This is not a sign of a problem. Two in-person interviews at their office weigh against one | `[generic]` pattern: an unchecked employer, not a claim about this one | Can you confirm the web address of the onboarding portal, and that your own website links to it? | unresolved |
| RR2 | Offer is specific and inside the posted band | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh, Finance Manager" | Role, pay, reporting line and work pattern are concrete and match the posting | `[grounded]` offer and posting texts compared | Who handles pension changes today, and is there a handover? | noted |
| RR3 | Bank, PPS and passport requested after acceptance | unknown | — | "you add your bank details for salary payments, your PPS number for Revenue, and a scan of your passport for our right-to-work check" | Post-offer payroll and right-to-work checks of this kind are routine onboarding. The one check that matters is where you enter them | `[generic]` how Irish onboarding commonly works | Is the portal reached from your own website, and may I show the original passport on day one if a scan upload doesn't work? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Reply to accept in writing and attach no personal details | The offer sends the portal link only after you accept | `[grounded]` offer text | pending your approval |
| A2 | Before entering anything, check the portal's address is on marrowgatehousing.ie or linked from the employer's own website. If unsure, phone the office using a number from that site, or ask Declan, whom you've met | See RR1, RR3 | `[generic]` standard verification practice | pending your approval |
| A3 | Enter the three items only in that portal. Don't email a passport scan or reply with numbers in the message body | The portal is the route the offer names | `[grounded]` offer text | pending your approval |
| A4 | Raise pension-change handover with Declan before your start date | See R10, RR2 | `[grounded]` your stated gap | pending your approval |
| A5 | Bring the original passport on day one, as the offer asks | See RR3 | `[grounded]` offer text | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were sent for Marrowgate Housing and its payroll post; both were refused. It would have settled RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | One search, for payroll administrator pay in Limerick, was refused. It would have filled the market calibration line |
| 3. Hiring manager's public footprint | unavailable | You named Declan Garvagh with his title and company, but research was declined, so none was sent. It would have informed the scope read |

## Dossier offer

If you want, I can save all of this as `tuesday-dossier.md`.

## Upgrade menu

- The portal link or its web address, once they send it → RR1 and RR3 can close against the employer's own site.
- Permission to run the web checks → RR1 closes if the employer is found, and market calibration fills in. A deeper pass (up to 5 more searches and 2 more fetches) is available once, if you want it.
- Your commute and pay limits → R2 and R3 resolve to met or failed.
- A redacted payslip or a Revenue return you prepared → R5 firms up.
- A copy of the certificate → R1 to `high`.

**R2, R3** — Are two days a week in Limerick, and €40,000, within your own limits?

**G1** — Was the hotel group's payroll run under Irish PAYE, PRSI and USC, and what did you do with them yourself (Revenue submissions, credit changes, year-end)?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.