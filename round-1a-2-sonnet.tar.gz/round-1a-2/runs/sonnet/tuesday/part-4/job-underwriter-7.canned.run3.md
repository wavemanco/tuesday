I've run three searches. Next I'm fetching the employer's careers page to check the posting is live.
# Job Underwriting Assessment: Community Staff Nurse, Band 5, Calderbrook Community Health CIC, Halifax

## Decision snapshot

**Yes, it's worth applying for, on the conditions below. Status: `conditional_go`.** No hard gate fails (R1, R2 and R3 are met; R4 is unconfirmed). The gaps are experience-shaped, not eligibility-shaped.

**Fit ledger.**

- `hard_gate` — direct: R1, R2, R3 · unclear: R4 (Pay £31,050–£37,800)
- `must_have` — direct: R5, R7a, R9 · adjacent: R7b (Leg-ulcer care), R8 (Catheter and continence care) · unclear: R6 (Clear, timely written records), R10 (End-of-life visits)
- `important` — adjacent: R11 (Small caseload of your own), R13 (Caring for housebound adults in their homes) · unclear: R12 (Care planning on the electronic patient record)
- `preferred` — absent: R14 (Doppler assessment)

R7b — wound care bridges, leg-ulcer technique not shown; R11 — home visiting in discharge-to-assess bridges, no caseload of your own; R14 — absent, with a training route to check (RR3).

**Opportunity ledger.** Sound on what the advert states. A supported small caseload (RR4) and a stated salary (RR5) count in its favour. The posting being live (RR1), the hours (RR2) and Doppler training (RR3) are unknowns.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); unconfirmed: R4 (Pay £31,050–£37,800); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post is confirmed open, RR1; (2) the starting salary suits you, R4 and RR5; (3) your end-of-life, records and care-planning experience is confirmed, R10, R6 and R12; (4) Doppler training is offered after starting, R14 and RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. Founded 2015; 410 staff in four locality hubs | `[grounded]` the company's About page (calderbrookhealth.example/about) |
| Mandate | A Band 5 post in the district nursing team: housebound adults at home, with a small caseload of your own and a senior community nurse supporting | `[grounded]` advert |
| Team lead | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. She spoke at the 2025 community nursing forum on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page |
| Scope read | The Doppler training talk and the "desirable, not essential" wording suggest the team expects to train new starters in it | `[inferred]` from the speaker page against the advert's wording |
| Pay | £31,050–£37,800 plus mileage, with pool cars provided | `[grounded]` advert |
| Market calibration | Survey of community staff nurses at Band 5 in England (n=1,240): median £34,300, interquartile range £32,400–£36,600; 61% were paid mileage and 24% had a pool or lease car. The advert's range brackets that interquartile range. The survey band is not this employer's offer | `[generic]` Wardround 2026 pay guide, one search; `[grounded]` advert for the range |
| Unknowns | Hours and any weekend or on-call rota; whether Doppler training is provided; which patient record system is used; whether the post is currently open | — |
| Contradictions | None between the advert and the About page. The careers-page address I tried returned no page, so I could not confirm the posting there (RR1) | `[grounded]` About page; fetch result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | Your CV states active registration as a Registered Nurse (Adult), revalidation due March 2028. CV-only, so `medium`. The NMC register is public and checking it is yours | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states a full UK licence, category B. Pool cars are provided | `[grounded]` CV, advert | none |
| R3 | Based in Halifax | hard_gate | direct | medium | none | The advert places the post in Halifax and you state you live there | `[grounded]` advert, CV | none |
| R4 | Pay £31,050–£37,800 | hard_gate | unclear | none | hard_gate | You have given no pay floor, so whether this meets it is not established | `[grounded]` advert; no candidate constraint given | Pay-floor question, closing block |
| R5 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. This is a length-of-experience requirement, not a gate | `[grounded]` CV | none |
| R6 | Clear, timely written records | must_have | unclear | none | discovery | The CV is silent on recording standards or audits | `[grounded]` CV silence | G2 |
| R7a | Wound care | must_have | direct | medium | none | CV states wound care including pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R7b | Leg-ulcer care | must_have | adjacent | medium | transferability | Wound care carries over. Limit: the CV does not show leg-ulcer assessment or compression therapy | `[grounded]` CV; `[inferred]` bridge derived from the stated wound care | G4 |
| R8 | Catheter and continence care | must_have | adjacent | medium | discovery | Catheter care is stated. Continence care is not mentioned | `[grounded]` CV | Covered by the CV edit in E2, only if you confirm it |
| R9 | Insulin administration | must_have | direct | medium | none | CV states insulin administration. The role adds care planning around it, which is R12 | `[grounded]` CV | none |
| R10 | End-of-life visits | must_have | unclear | none | discovery | The CV is silent on end-of-life care | `[grounded]` CV silence | G1 |
| R11 | A small caseload of your own, with senior support | important | adjacent | medium | transferability | You state you have never held your own caseload. The nearest evidence is 18 months on the discharge-to-assess team visiting patients at home | `[grounded]` your statement, CV | G5 |
| R12 | Care planning on the electronic patient record | important | unclear | none | discovery | The CV names no record system and says nothing about care planning | `[grounded]` CV silence | G2 |
| R13 | Caring for housebound adults in their own homes | important | adjacent | medium | transferability | Home visiting is evidenced. Limit: your visits were in the first week after discharge, not long-term housebound care | `[grounded]` CV | Plan row E1 |
| R14 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You confirm you have never done one. It is desirable, not essential | `[grounded]` your statement | G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-of-life visits (R10, must_have) | discovery | The CV neither shows nor rules out end-of-life care | A must-have in a district nursing advert, and the likeliest thing to move the decision from conditions to `go` | Caring for dying patients on the ward; symptom-control or anticipatory-medication work; supporting a family at the end of life; a discharge for a dying patient to die at home | A reflective note, a training certificate or a service thank-you (anonymised) | `[grounded]` CV silence; `[generic]` that end-of-life work is a routine part of district nursing |
| G2 | Records and care planning on an EPR (R6, must_have) | discovery | The CV names no record system and says nothing about care planning or records | The advert names clear, timely records as essential and says everything is recorded electronically | Care plans you wrote for discharge; record audits; the system you used on the ward and in discharge-to-assess | An audit result, a training record or an anonymised care-plan example | `[grounded]` CV silence and advert wording |
| G3 | Continence care (R8, must_have) | discovery | Catheter care is stated; continence is not | Half of one must-have row is unconfirmed | Continence assessments, bladder or bowel care plans, catheter trials without catheter | A competency record | `[grounded]` CV |
| G4 | Leg-ulcer care (R7b, must_have) | transferability | Wound care is evidenced; leg-ulcer care is not | The bridge has a stated limit: leg-ulcer technique | Applying compression bandaging; leg-ulcer assessment; wound care for venous or mixed ulcers | A competency record or a wound-care course certificate | `[inferred]` bridge from the stated wound care; `[generic]` that leg-ulcer care is core district nursing work |
| G5 | Own caseload (R11, important) | transferability | Home visiting in discharge-to-assess; no caseload of your own | The advert gives a small caseload of your own as part of the role; the supported start is an asset | Planning your own day of visits; prioritising a list of patients; reviewing a patient across several visits | A description of how visits were assigned and reviewed | `[grounded]` your statement, CV; `[inferred]` that discharge-to-assess visiting resembles it in part |
| G6 | Doppler (R14, preferred) | capability | You have never done one | Preferred, so a smaller risk. The team lead has spoken about Doppler training for staff new to community work | None to claim. The honest route is to say so and ask about training | None | `[grounded]` your statement, speaker page; `[inferred]` that training may be offered |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | unknown | — | "Join our district nursing team" | The careers-page address I tried returned no page. The post may be listed elsewhere, or may have closed | `[grounded]` the fetch result | Is this post currently open, and where is it listed on your careers page? | unresolved |
| RR2 | Hours and rota unstated | unknown | — | The advert gives no hours | District nursing posts often involve weekend or evening visits, but this advert does not say | `[generic]` role-family pattern, not a claim about this employer | What are the working hours, and is there a weekend or on-call rota? | unresolved |
| RR3 | Doppler training not stated | unknown | — | "Desirable: Doppler assessment for leg ulcers" | The team lead has spoken on Doppler training for new community staff, so training may be offered | `[inferred]` from the speaker page | Is Doppler training provided after starting, and how is competence signed off? | unresolved |
| RR4 | Supported start | positive_signal | — | "supported by a senior community nurse" | A supervised start suits someone with no caseload of their own yet | `[inferred]` from the advert's wording | How is the caseload built up, and how long is the supervised period? | noted |
| RR5 | Salary stated and in line | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range brackets the survey's interquartile range, so it looks ordinary for the grade | `[grounded]` advert against the `[generic]` survey band | Where in the range would I start, given my experience? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | `resume_edits_pending_approval`: move the seconded discharge-to-assess role to the top of Experience and open it with "Seconded for 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge" | See R13, R11 | `[grounded]` your own sentence | pending your approval |
| E2 | `resume_edits_pending_approval`: add continence care, end-of-life care, records and care planning to the CV only after you confirm them in G1, G2 and G3 | See R6, R8, R10, R12 | `[grounded]` the gap rows | pending your approval |
| A1 | Ring Rhiannon Mabbott for the informal chat the advert offers, and ask the RR1, RR2, RR3 and RR4 questions | The register doubles as your question list | `[grounded]` advert, register | pending your approval |
| A2 | In that chat, say plainly that you have not held your own caseload or done a Doppler assessment, and ask what the supported start looks like | Truthful and checkable | `[grounded]` your statements | pending your approval |

Tailoring the CV itself is resume-tailor's job; the rows above only propose edits.

## Evidence status

Verified: none yet. Your National Insurance number isn't needed for this assessment, so I haven't used or repeated it.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax community staff nurse district nursing", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, which returned no page. Role reality's organization row is confirmed. The posting being live is not, which is RR1 |
| 2. Role-family sweep | yes | Searched "community staff nurse district nursing Band 5 role requirements experience Doppler leg ulcer salary Agenda for Change", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration row and RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved the scope read, RR3 and plan row A1 |

I can save this as a `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- Your answer on end-of-life care (G1) → R10 resolves, and the decision likely moves to `go`.
- Your records and care-planning experience (G2) → R6 and R12 resolve.
- Your pay floor → R4 resolves.
- A competency record for leg-ulcer or compression work (G4) → R7b strengthens.
- The recruiter's answer on the live posting (RR1) and the hours (RR2) → both close.
- A deeper research pass on Calderbrook Community Health (leadership changes, regulator reports, staff accounts; up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — Have you cared for a patient at the end of life, on the ward or at discharge? What did you personally do, and what happened?
G2 — What record system did you use on the ward and in discharge-to-assess, and have you written care plans or taken part in record audits?
R4 — What is the lowest salary you would accept, and are there any hours or rota patterns you can't work?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.