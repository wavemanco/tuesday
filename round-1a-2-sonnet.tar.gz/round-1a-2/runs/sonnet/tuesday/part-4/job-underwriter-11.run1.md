Femi, I'm sorry about the layoff. Short answer: apply to the first role, skip the second. I tried four searches on the two employers and on salary bands, but search permission wasn't granted, so this rests on your background and the two postings only.

# Role 1: Operations Analyst, Duinvaart Cold Chain (Rotterdam)

## Decision snapshot

**Yes, this one is worth your time. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Hybrid, three days in Rotterdam)
- `must_have` — direct: R2, R3, R4
- `important` — direct: R5a, R6 · unclear: R5b (Temperature compliance)
- `preferred` — adjacent: R7 (Dutch a plus)

R5b — the one piece of cold-chain work your background doesn't show; R7 — Dutch is a plus and yours is conversational.

**Opportunity ledger.** The role is concretely scoped (RR3), but the employer is unverified (RR1) and the pay is not stated (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, three days in Rotterdam); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, per RR1; (2) the three-day Rotterdam office schedule works for you, per R1; (3) you can show some temperature or compliance-type tracking, per R5b, or accept that it is the thing you'll be probed on.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, a refrigerated-fleet operator based in Rotterdam. I could not confirm it exists as described. | `[grounded]` posting text; existence not established |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Scope read | An analyst post that matches your daily work: a recurring dashboard plus a stakeholder loop with depot managers | `[inferred]` from the posting's duties against your stated background |
| Market calibration | Not run. The salary search was refused, and the posting withholds pay | `[grounded]` posting silent on pay |
| Unknowns | Salary, team size, who the analyst reports to, which TMS or telematics feeds the data | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | You gave no location constraint. You work in Amsterdam now; whether Rotterdam three days a week works is yours to say | `[grounded]` posting; no constraint stated | Ask: is this schedule workable? |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier. Self-reported, nothing inspected yet, so `medium` | `[grounded]` your background, self-reported | none |
| R3 | Strong SQL | must_have | direct | medium | none | Daily use, stated. Self-reported, so expect a technical screen | `[grounded]` your background | none |
| R4 | Power BI or Tableau | must_have | direct | medium | presentation | You built the on-time delivery dashboard that depot managers use. This is your strongest match, and the CV should lead with it | `[grounded]` your background | Edit E1, pending your approval |
| R5a | Track on-time delivery | important | direct | medium | none | The dashboard you built is the same metric, in parcels rather than refrigerated freight | `[grounded]` your background | none |
| R5b | Track temperature compliance | important | unclear | low | discovery | Nothing in your background mentions temperature or compliance data. Whether you handled anything similar is unknown | `[grounded]` silence in your background | Ask G1 |
| R6 | Work with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review, and depot managers use your dashboard | `[grounded]` your background | none |
| R7 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch is credible and not fluent. The posting calls it a plus, so it is not a requirement | `[grounded]` your statement, and the posting's wording | Say it plainly, as "conversational" |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R5b, important) | discovery | Nothing in your background about temperature, compliance or exception tracking | This is the one area where the posting is specific to cold chain and you show nothing yet | Tracking service-level breaches, damage or claims, or delivery exceptions; any compliance or audit reporting; sensitive-parcel handling | A dashboard screenshot (sanitized), an exceptions report, a KPI definition | `[grounded]` silence in your background; `[generic]` that cold-chain postings usually probe this first |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The research did not run, so this says nothing about the company. It may be a real firm I couldn't check, a stale or aggregated posting, or not a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers page, and tell me who I'd interview with? | unresolved |
| RR2 | Salary not stated | unknown | — | (posting gives no figure) | The pay may be below or within the usual band; the posting is silent | `[grounded]` posting silent | What salary range is budgeted for this role? | unresolved |
| RR3 | Concrete duties and a named stakeholder loop | positive_signal | — | "work with depot managers on route changes" | The scope is defined enough to judge success | `[grounded]` posting | What would a good first quarter look like? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your CV with the on-time delivery dashboard depot managers use, and the weekly route-performance review you ran, in your own wording | See R4, R6 | `[grounded]` your background | pending your approval |
| A1 | Check the posting on the company's own site, and the recruiter's email domain, before investing effort | See RR1 | `[grounded]` register | pending your approval |
| Q1 | Ask the RR1 to RR3 questions verbatim in the first conversation | The register doubles as interview prep | `[grounded]` register | pending your approval |

# Role 2: Supply Planner, Kroonhaven Foods (Utrecht)

## Decision snapshot

**No, this one is not worth your time as a direct application. Status: `no_go`, on R2, R5 and R6, which are `must_have` rows with no evidence and no quick closure path.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (On-site in Utrecht)
- `must_have` — adjacent: R3 (Fluent Dutch) · unclear: R4 (Advanced Excel) · absent: R2 (3+ years planning in FMCG), R5 (SAP IBP or similar), R6 (Own the 13-week supply plan)
- `important` — adjacent: R7 (Run the weekly S&OP meeting)

R2, R5, R6 — three planning-specific must-haves with nothing behind them; R7 (`medium`) — your weekly route-performance review is a credible bridge, its limit named.

**Opportunity ledger.** The employer is unverified (RR1) and the pay is not stated (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the three planning must-haves would have to be different. The posting would need to accept analytics experience in place of planning experience, or you would need real planning work I haven't seen.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, a chilled ready-meals maker in Utrecht. I could not confirm it exists as described | `[grounded]` posting text; existence not established |
| Mandate | Own the 13-week supply plan, balance capacity against the forecast, run the weekly S&OP meeting | `[grounded]` posting |
| Working pattern | On-site in Utrecht | `[grounded]` posting |
| Scope read | A core planning-function seat, with ownership of the plan and of the cross-functional meeting | `[inferred]` from the posting's "own" and "run" |
| Market calibration | Not run; search refused, and no pay stated | `[grounded]` posting silent on pay |
| Unknowns | Salary, team size, planning system in use, who attends the S&OP meeting | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No location constraint given; you work in Amsterdam now | `[grounded]` posting; no constraint stated | none; the decision doesn't turn on it |
| R2 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You said you've never worked in planning. This is an experience requirement, not a gate, but your four analyst years don't count toward it | `[grounded]` your statement | closure path named below |
| R3 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational is credible and not fluent. The limit is real because you'd run a meeting and work with plant teams in Dutch | `[grounded]` your statement | none |
| R4 | Advanced Excel | must_have | unclear | low | discovery | You didn't mention Excel. Your SQL and Power BI suggest comfort, but they're different tools | `[grounded]` silence in your background | none; the decision doesn't turn on it |
| R5 | SAP IBP or a similar planning system | must_have | absent | none | capability | SQL and Power BI are reporting tools, not planning systems | `[grounded]` your background | closure path named below |
| R6 | Own the 13-week supply plan; balance capacity against forecast | must_have | absent | none | capability | You have no planning work, and capacity-versus-forecast balancing is the core of the job | `[grounded]` your statement | closure path named below |
| R7 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review: the same chairing rhythm and cross-team accountability. The limit is that you didn't negotiate supply against demand in it | `[grounded]` your background | name the limit plainly if you ever interview |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G2 | Planning system and planning method (R2, R5, R6) | capability | No planning work and no planning-system use | Three must-haves, all absent, sit in this one gap | A short planning-tool course or a certification; a self-built capacity-versus-forecast model for a public dataset | A certificate or a small portfolio project | `[grounded]` your statement; `[generic]` that this closes slowly, over months, not before this posting closes |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The research did not run, so this says nothing about the company. It may be a real firm I couldn't check, a stale or aggregated posting, or not a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers page, and tell me who I'd interview with? | unresolved |
| RR2 | Salary not stated | unknown | — | (posting gives no figure) | The pay may be within or outside the usual band; the posting is silent | `[grounded]` posting silent | What salary range is budgeted for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A2 | Don't spend tailoring effort here. If you want to apply anyway, treat it as a long shot and say plainly that you have no planning experience | See R2, R5, R6 | `[grounded]` map | pending your approval |
| A3 | Look at planning-adjacent analyst roles (for example, demand or supply analytics, where reporting is the core) as a bridge into planning | Planning teams often hire analysts, a route in that needs no planning years | `[generic]` role-family pattern, not a claim about any employer | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht" were refused. It would have settled RR1 for both employers and whether each posting is live |
| 2. Role-family sweep | unavailable | Searches for operations analyst and supply planner pay in the Netherlands were refused. They would have filled the market calibration rows and RR2's comparison |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you want a saved record of both assessments, I can write them to a `tuesday-dossier.md`.

## Upgrade menu

- Search permission for the two employers' own sites → closes RR1 for each, and tells you whether the postings are live. A deeper pass (up to 5 more searches and 2 more fetches) is available if you say the word.
- A sanitized dashboard or exceptions report → R5b moves from `unclear` toward `direct`.
- Your location constraints and pay floor → R1 and RR2 in both roles can be checked against them.
- Recruiter's salary range for either role → RR2 closes.

## Questions

G1 — In your parcel work, did you ever track or report anything like a temperature, damage, or service-level breach, or run exceptions or compliance reporting? What did you own, and what happened?
R1 — Is three days a week in Rotterdam workable for you, and is there a minimum pay or a commute limit I should hold the role against?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.