Web searches weren't permitted, so I'm working only from what you pasted.

## Decision snapshot

**Yes, asking for bank details, your PPS number and a passport scan after you accept a written offer is routine onboarding, not a warning sign in itself (RR2). Status: `conditional_go`.** It stays conditional because I couldn't check from here that Marrowgate or the sender's address is who they say (RR1).

**Fit ledger.**

- `hard_gate` — unclear: R1 (Right to work in Ireland), R2 (Two office days in Limerick), R3 (Pay €38,000–€42,000, offer €40,000)
- `must_have` — direct: R4, R6, R7, R9, R10 · adjacent: R8 (Monthly payroll for 240 staff) · unclear: R5 (Irish PAYE, PRSI, USC) · absent: R11 (Pension changes)
- `important` — unclear: R12 (Answering staff payroll queries)

R8 — scale and pay frequency differ from your hotel payroll, limit named; R11 — you've not done these yourself, closure path named; R5 — Irish tax knowledge isn't stated in your background.

**Opportunity ledger.** The offer is specific and matches the ad (RR3). Two things are unverified: the employer from here (RR1) and where the portal link will lead (RR2). You haven't seen written terms yet (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Right to work in Ireland), R2 (Two office days in Limerick), R3 (Pay €38,000–€42,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 clears, as in the application plan; (2) the portal address checks out, and you enter details nowhere else (RR2); (3) the pension-changes gap is raised honestly with Declan (R11).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick. Existence and domain not checked from here | `[grounded]` ad and offer text; no verification completed |
| Mandate | Monthly payroll for 240 staff, starters, leavers, pension changes, monthly ledger reconciliation, staff queries | `[grounded]` ad |
| Ad against offer | Title, hybrid pattern, two Limerick office days and a reporting line agree. €40,000 sits inside the ad's band | `[grounded]` ad and offer |
| Requested items | Bank details for salary, PPS number for Revenue, passport scan for right to work, original passport on day one. Employers normally need all of these to pay and register a new hire, and they ask after the offer is accepted | `[generic]` onboarding pattern |
| Your rule against handing these over | Sensible before any offer or with an unknown party, which is where it protects you. After a credible written offer it gives way to one check: the portal address | `[generic]` |
| Market calibration | Not run, since search was declined. €38–42k is unchecked against role-family norms | `[grounded]` no sweep completed |
| Unknowns | Portal address, written contract terms, pension scheme details, start date | `[grounded]` offer is silent on each |
| Contradictions | None between ad and offer | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Right to work in Ireland (passport check) | hard_gate | unclear | none | hard_gate | You haven't stated your status. The offer's passport check implies it matters | `[grounded]` offer text; status not given | Confirm it's met; no workaround needed |
| R2 | Hybrid, two days a week in Limerick | hard_gate | unclear | none | hard_gate | Terms are clear. Your own constraints aren't given | `[grounded]` ad and offer | Confirm two Limerick days work for you |
| R3 | Pay €38,000–€42,000; offered €40,000 | hard_gate | unclear | none | hard_gate | The offer is inside the band. Your floor isn't given | `[grounded]` ad and offer | Confirm against your floor |
| R4 | 2+ years running payroll | must_have | direct | medium | none | 3 years of fortnightly payroll for 90 staff, confirmed, with no document inspected yet | `[grounded]` your background | none |
| R5 | Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your background doesn't say which tax regime the hotel payroll ran under | `[grounded]` silence in background | Question G1 |
| R6 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP, self-reported | `[grounded]` your background | none |
| R7 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024, self-reported | `[grounded]` your background | A copy of the certificate would raise it to `high` |
| R8 | Run the monthly payroll for 240 staff | must_have | adjacent | medium | transferability | Credible bridge: 90 staff fortnightly. Limit: about 2.7 times the headcount, monthly cycle not exercised. The ratio is arithmetic on your figures | `[grounded]` background; `[inferred]` limit from the headcount ratio | Frame as adjacent, never as 240-staff experience |
| R9 | Monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | Stated directly in your background | `[grounded]` background | none |
| R10 | Process starters and leavers | must_have | direct | medium | none | Stated directly in your background | `[grounded]` background | none |
| R11 | Process pension changes | must_have | absent | none | capability | You said your manager handled these. Exposure isn't ownership, so none is claimed | `[grounded]` your statement | Name a closure path (G2) |
| R12 | Answer staff payroll queries | important | unclear | low | discovery | Not stated either way. Fortnightly payroll for 90 staff usually brings such queries | `[grounded]` silence; `[generic]` pattern | Fold into your next answer if useful |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI, USC (R5, must_have) | discovery | Payroll duties are clear, but not which tax system they ran under | A must-have at `unclear`; confirming it removes the largest open fit question | Filing Irish payroll submissions; applying USC and PRSI classes to starters; handling Revenue notifications | A payslip template, a payroll report or a Revenue submission screenshot, with names removed | `[grounded]` background silence |
| G2 | Pension changes (R11, must_have) | capability | You watched your manager handle these and haven't done them | The only must-have with no evidence of doing; Declan will likely ask in week one | Preparing scheme deductions or joiner and leaver forms while the manager reviewed them | The training notes or procedure you'd follow | `[grounded]` your statement; `[inferred]` that the manager's review might have included preparing forms |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The entity may be too new or small to have a footprint, the offer may not come from who it names, or something else. Two in-person interviews at their office count in its favour if the address matches their own site | `[generic]` pattern for organizations of this size, not a claim about this one | Could you give me the web address your People Team emails and onboarding portal use, so I can check it against your website? | unresolved |
| RR2 | Onboarding request for bank, PPS and passport details | unknown | — | "we will send you a link to our onboarding portal, where you add your bank details for salary payments, your PPS number for Revenue, and a scan of your passport" | A written offer naming role and pay, which comes before this request, is the usual order. The open point is whether the link goes to Marrowgate's own portal | `[generic]` onboarding pattern; `[grounded]` the quote and its order | What web address will the portal be on? | unresolved |
| RR3 | Specific offer, matching ad | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh, Finance Manager" | Role, pay, reporting line and hybrid terms are named and consistent with the ad | `[grounded]` ad against offer | Is this post replacing a leaver or newly created? | noted |
| RR4 | Written terms not yet seen | unknown | — | "starting on a date we agree once your notice period ends" | Probation, hours, pension scheme and notice terms aren't in the email, and you're asked to accept within five working days | `[grounded]` offer is silent on them | Can I see the full contract, including probation, notice and pension terms, before the deadline? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find Marrowgate's own website yourself, check the office address you attended and the People Team's email domain against it, and confirm the offer through a contact listed there | RR1 | `[grounded]` register | pending your approval |
| A2 | Don't send passport, PPS or bank details by email reply. Enter them only in the portal, once its address matches the one on Marrowgate's own site | RR2 | `[grounded]` register | pending your approval |
| A3 | Ask for the written contract before replying to accept | RR4 | `[grounded]` register | pending your approval |
| A4 | Raise pension changes with Declan as new to you, and ask what training or handover is planned. This is stated as what you have not done, not as experience | R11 | `[grounded]` R11 | pending your approval |

## Evidence status

Verified: none yet. Your background is prose self-report, so every claim is a lead and not proof.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused, with permission not granted, so nothing was found. It would have settled RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | One search was refused. It would have given the market calibration line for €40,000 |
| 3. Hiring manager's public footprint | unavailable | Declan Garvagh's name was given, but no search was sent because research wasn't permitted. It would have informed the scope read and which story to lead with |

## Upgrade menu

- A search permission, or the address of Marrowgate's own website → RR1 closes, plus market calibration for the pay.
- An answer to G1, or a payslip or report with names removed → R5 moves toward `direct`.
- The written contract → RR4 closes and R3 can be checked against your floor.
- Your pay floor, office-day limits and right-to-work status → R1, R2 and R3 move from `unclear`.
- A deeper research pass on Marrowgate Housing (leadership and news; up to 5 more searches and 2 more fetches) — say the word and it runs.

I can also save this as `tuesday-dossier.md` if you'd like to keep it.

Questions:

- RR1 — Was the office you attended at the address on Marrowgate's own website, and did you meet Declan Garvagh there in person?
- G1 — Did your hotel payroll run Irish PAYE, PRSI and USC, and which submissions to Revenue did you handle yourself?
- G2 — When your manager handled pension changes, which parts did you see or prepare, such as scheme deductions or joiner and leaver forms?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.