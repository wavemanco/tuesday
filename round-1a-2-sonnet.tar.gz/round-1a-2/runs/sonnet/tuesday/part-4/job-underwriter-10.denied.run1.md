**Worth applying to? Yes, on conditions. Legit? I can't say yet. The message asks only for a 45-minute video call, but I couldn't check the company from here. Status: `conditional_go`**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R7 · adjacent: R6 (Own the booking flow end to end)
- `important` — adjacent: R8 (Research calls with school owners), R9 (First designer, no design peer)

R6 — checkout is a credible bridge, its limit named; R9 — real squad experience, never as the only designer.

**Opportunity ledger.** Plausible small-startup posting that states pay, equity and scope (RR3), but the employer is unverified (RR1), the invite sender and channel are unchecked (RR2), and equity terms and runway are unstated (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies as a real employer with this role live on its own site — RR1; (2) the pay range meets your floor — R2; (3) the calendar invite comes from the company's own domain — RR2; (4) equity terms are explained in the call — RR4.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools. This is the posting's description of itself, not independently checked | `[grounded]` JD |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers, work most closely with co-founder Ronan Kehoe | `[grounded]` JD |
| Working pattern | Hybrid, two days a week at the Galway office | `[grounded]` JD |
| Compensation | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` JD |
| Scope read | One product surface and a small team make this a coherent first-designer remit, not an obviously bundled one | `[inferred]` from the JD's stated responsibilities |
| Market calibration | Not run. Search was refused, so there is no band, and I won't give one from memory | `[grounded]` search refused |
| First-year outcomes | Not stated in the JD | `[grounded]` JD silent |
| Unknowns | Equity type, vesting and strike; funding and runway; who reviews design work; how many schools use the product | `[grounded]` JD silent on each |
| Contradictions | None between the posting and your message: Ronan, Saoirse and the case study all fit the posting and your application. Consistency does not verify the company (RR2) | `[grounded]` posting and your message |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You live in Galway, so the location term is met. You haven't said whether two office days suit you, and you gave no stated constraint | `[grounded]` your background note | Confirm two days suits you |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | The posting states the range. You gave no floor or current pay, so nothing settles whether it meets your terms. Confidence grades your statement of a floor, and none was given | `[grounded]` JD figure; no floor stated | G1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company. Prose self-report, so `medium` | `[grounded]` your background note | Share your CV or portfolio to raise to high |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is confirmed but nothing inspectable has been read. Fernquay has already seen your checkout case study, which I have not | `[grounded]` your background note | A Figma file or the case study link would raise to high |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers. Whether you planned, recruited and synthesised them is unstated, so I take the narrower reading | `[grounded]` your background note | Say what you personally owned in those sessions |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow. Limit: checkout is one stage, and nothing yet shows you owned search, availability, changes or cancellations | `[grounded]` your background note; limit derived from its silence | G2 |
| R7 | Ship alongside two engineers | must_have | direct | medium | none | Four years' work in a squad with four engineers | `[grounded]` your background note | none |
| R8 | Research calls with school owners | important | adjacent | medium | transferability | Usability sessions with customers of a consumer travel-booking company are research, but not interviews with owner-operators of small businesses, a different kind of conversation | `[inferred]` from the difference in participants | G3 |
| R9 | First designer: no design peer or lead (implied) | important | adjacent | medium | transferability | You have never been the only designer, and you owned checkout work within a squad. Limit: no evidence yet of setting design direction or standards alone. A first design hire usually has no senior peer for critique | `[grounded]` your note; `[generic]` first-hire pattern | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay against your floor (R2, hard_gate) | hard_gate | The posting states €52,000–€60,000; your floor and current pay are unknown | A pay term is a gate, so it decides whether this is worth the effort | Your floor, and whether equity changes it for you | None needed; it's your own constraint | `[grounded]` JD figure; no floor in your message |
| G2 | Scope beyond checkout (R6, must_have) | transferability | One confirmed redesign, the checkout flow; nothing on the stages around it | "End to end" is the JD's first responsibility, so the checkout bridge needs its limit stated | Date or availability selection, confirmation and reminder emails, changes and cancellations, mobile booking, a funnel review beyond checkout | A flow map or Figma file, the checkout case study with its before and after | `[grounded]` note silent beyond checkout; `[generic]` that "end to end" is probed on stages |
| G3 | Owner-operator research (R8, important) | transferability | Customer usability sessions; no interviews with business owners stated | The JD names school-owner calls as a core activity | Calls with merchants or suppliers, partner or B2B feedback sessions, discovery interviews | A research plan or synthesis deck, sanitised | `[inferred]` from the participant difference |
| G4 | Working without a design peer (R9, important) | transferability | Squad work only; no stated solo ownership | A first designer sets the standards, so how you handle that matters | A feature you took from research to ship alone, a component library you started, running critique yourself | A component or style library file, a design-decision doc | `[grounded]` note; `[generic]` that first hires carry this load |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | Your own searches turned up little, and I couldn't search. The company may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and tell me who else I would meet in the process? | unresolved |
| RR2 | Contact on WhatsApp; invite sender not yet checked | unknown | — | "Hi Maeve, Ronan from Fernquay here … I have emailed you a calendar invite with the video link." | The message asks only for a 45-minute call, and scheduling by chat for a call held elsewhere is not a warning sign. Whether the invite came from the company's own domain, and how Ronan got your number, are not yet known. Small teams often use WhatsApp for scheduling | `[grounded]` the message's content; `[generic]` small-team pattern | Could you resend the invite from your company address, so I can match it to your website? | unresolved |
| RR3 | Pay range, equity and scope stated openly | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | Terms are transparent. Pay is not buried or deferred | `[grounded]` JD | What is the budget behind the top of the range, and when is pay reviewed? | noted |
| RR4 | Equity terms and runway unstated | unknown | — | "plus 0.5–1% equity" | The percentage may be worth little without type, vesting, strike price, dilution history and funding runway | `[inferred]` from the JD's silence on each | Are these options or shares, what is the vesting schedule, and how many months of runway does the company have? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, find Fernquay yourself: its own website, any social presence and the Irish company registry (cro.ie), and confirm this role is on its own careers page | RR1; do not rely on links sent in the chat | `[generic]` standard due-diligence route | pending your approval |
| A2 | Check that the calendar invite and video link come from an address on the same domain as the company's website; if not, ask Ronan to resend it from the company address | RR2 | `[inferred]` from your message | pending your approval |
| A3 | Lead with your own words: "I redesigned our checkout flow and ran monthly usability sessions with customers." Say plainly that this was within a squad and that checkout was your scope, not the whole booking flow | R5, R6, R9; keeps the bridge honest about its limit | `[grounded]` your background note | pending your approval |
| A4 | In the call, ask the verification questions from RR1, RR2, RR3 and RR4 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Preparing for the call with Ronan and Saoirse is mock-interview's job; ask when you want it | You have an interview coming | `[grounded]` your message | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for "Fernquay booking software sea kayak surf schools Galway" and "Fernquay product designer job Galway careers" were refused. They would have moved RR1, the contradictions row and whether the posting is live |
| 2. Role-family sweep | unavailable | The search for first-designer salary and equity in Ireland was refused. It would have moved the market calibration row and a pay comparison for R2 and RR3 |
| 3. Hiring manager's public footprint | unavailable | The search "Ronan Kehoe Fernquay co-founder" was refused. It would have moved the scope read and the positioning in A3 |

If you'd like to keep this assessment, I can write it up as `tuesday-dossier.md`; it's your call.

**Upgrade menu**
- Search permission, or the text of Fernquay's own careers or about page → RR1 and the contradictions row can close, and the market calibration for R2 can run.
- Your pay floor → R2 resolves, and the decision can move to `go` or `no_go` on pay.
- The invite's sender address → RR2 closes.
- A Figma file or the checkout case study → R4 can reach `high`, and G2 narrows.
- A sanitised research plan or synthesis → R5 and G3 strengthen.

**Questions**

G1 — Is €52,000–€60,000 at or above your pay floor?

G2 — Which parts of the booking journey beyond checkout did you personally design, such as date selection, confirmations, changes or cancellations, and what did you own?

G4 — Have you taken a feature from research to ship, or set up a component library, without a design lead? What was it and what was yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.