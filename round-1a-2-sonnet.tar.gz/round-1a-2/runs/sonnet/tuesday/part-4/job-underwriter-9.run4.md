I'm reading the job-underwriter playbook's remaining reference files. After that I'll check whether Marrowgate Housing is a real, verifiable employer, then write up the assessment.
**Yes, this is routine, and your old rule still holds. The rule is for requests that come before an offer. This request comes after a written offer that names the role and pay, and it arrives only once you accept. Enter the details only in Marrowgate's own onboarding portal, at an address you find on their own website and not from the email link. Status: `conditional_go`.**

I couldn't check Marrowgate Housing online because the search permission was refused. The `conditional_go` rests on that gap and on the conditions below.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Hybrid, two days Limerick office), R2 (Right-to-work check), R3 (Salary €38,000–€42,000)
- `must_have` — direct: R4, R6, R7 · adjacent: R8 (Monthly payroll for 240 staff) · unclear: R5 (Irish PAYE, PRSI and USC)
- `important` — direct: R9, R11 · unclear: R12 (Staff payroll queries) · absent: R10 (Pension changes)

R8 — a credible bridge, its limits named; R10 — a gap you confirmed, in the role's own duty list; R5 — waiting on your answer.

**Opportunity ledger.** The offer looks credible: it is in writing and within the advertised pay range, it follows two in-person interviews, and the portal link comes only after acceptance (RR3, RR2). Not yet checked: that Marrowgate and its portal address are what they say, from here (RR1), and the contract terms the offer leaves out (RR5, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days Limerick office), R2 (Right-to-work check), R3 (Salary €38,000–€42,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Marrowgate and its onboarding portal check out against the company's own website (RR1, RR2); (2) you have the written contract terms before you give notice (RR5); (3) a plan for the pension-change duty is agreed with Declan Garvagh (RR4, R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` ad and offer text; not independently checked |
| Mandate | Monthly payroll for 240 staff, starters, leavers and pension changes, monthly payroll-to-ledger reconciliation, staff payroll queries | `[grounded]` ad |
| Pay | Ad €38,000–€42,000; offer €40,000, inside the band | `[grounded]` ad against offer |
| Working pattern | Hybrid, two days a week in the Limerick office | `[grounded]` ad and offer agree |
| Reporting line | Declan Garvagh, Finance Manager | `[grounded]` offer |
| Scope read | The ad lists the whole payroll cycle under one title and names no team or backup | `[inferred]` from the duty list against the ad's silence on other payroll staff |
| Market calibration | Not calibrated: the salary search was refused, so no band is quoted | none: no source |
| Unknowns | Probation, notice and leave terms, pension scheme, payroll software, backup cover, onboarding portal address | `[grounded]` absent from the ad and offer |
| Contradictions | None between ad and offer on title, hybrid pattern or pay | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | low | hard_gate | You attended two interviews at the office, but you have not stated whether the two-day pattern suits you | `[grounded]` your message; no stated constraint | Confirm it works for you before accepting |
| R2 | Right-to-work check (passport scan, original on day one) | hard_gate | unclear | none | hard_gate | Nothing in what you shared states your eligibility; the offer makes the check a condition of onboarding | `[grounded]` offer text | Only you can confirm; no question needed from me |
| R3 | Salary €38,000–€42,000 | hard_gate | unclear | low | hard_gate | The €40,000 offer sits inside the advertised band; no pay floor of yours was stated | `[grounded]` ad and offer | Check against your own floor |
| R4 | 2+ years running payroll | must_have | direct | medium | none | 3 years of fortnightly payroll for 90 staff, self-reported with no inspectable artifact, so the intake ceiling applies | `[grounded]` your background | none |
| R5 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | You didn't say the hotel payroll was Irish, or which statutory deductions you ran | `[grounded]` silence in your background | See G1 |
| R6 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP, self-reported | `[grounded]` your background | none |
| R7 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024; no certificate copy seen | `[grounded]` your background | Keep the certificate to hand |
| R8 | Run monthly payroll for 240 staff | must_have | adjacent | medium | transferability | Carries over: full payroll cycles. Limits: your cycle was fortnightly and for 90 staff, not monthly for 240. Strengthener: be exact about those figures when asked | `[grounded]` your figures against the ad | See G2 |
| R9 | Process starters and leavers | important | direct | medium | none | Starters and leavers are in your hotel role | `[grounded]` your background | none |
| R10 | Process pension changes | important | absent | medium | capability | You said you have not done these yourself and your manager handled them | `[grounded]` your own statement | See G3 and RR4 |
| R11 | Reconcile payroll to the general ledger monthly | important | direct | medium | none | You did the monthly payroll-to-ledger reconciliation | `[grounded]` your background | none |
| R12 | Answer staff payroll queries | important | unclear | low | discovery | Your background doesn't mention handling staff queries | `[grounded]` silence in your background | Optional, see G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish statutory deductions (R5, must_have) | discovery | Hotel payroll described without jurisdiction or deductions | R5 is a must-have; confirming it would move it to direct | Running PAYE, PRSI and USC through payroll, filing returns, handling Revenue notices | A redacted payslip layout or a payroll-software report | `[grounded]` silence in your background |
| G2 | Monthly payroll for 240 staff (R8, must_have) | transferability | Fortnightly for 90 staff | Scale and frequency are the likeliest objection to your fit | Month-end closes, a larger headcount covered at any time, running two payroll cycles in one month | A sanitized cycle calendar or close checklist | `[inferred]` bridge from your figures |
| G3 | Pension changes (R10, important) | capability | No direct experience, stated by you | The ad lists it as a duty | None to claim; closure is training on the job | A pension-scheme guide or a short course | `[grounded]` your statement |
| G4 | Staff payroll queries (R12, important) | discovery | Not mentioned | The ad lists it as a duty | Fielding payslip questions, correcting errors, explaining deductions | A sanitized query log | `[grounded]` silence in your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and sender not independently checked | unknown | — | "from people@marrowgatehousing.ie" | The email domain may or may not match the housing association's own website; most small offers do match, but I couldn't check this one | `[generic]` pattern; `[grounded]` that no check ran | "Can you confirm the address of the onboarding portal and that it's linked from your website?" Ask through the People Team contact details on Marrowgate's own site, not the offer email. | unresolved |
| RR2 | Request for bank, PPS and passport details | unknown | — | "you add your bank details for salary payments, your PPS number for Revenue, and a scan of your passport" | These are normal payroll and right-to-work steps after a written offer naming role and pay; the one risk is a look-alike link | `[generic]` onboarding pattern; `[grounded]` offer text | "Is the portal address the one on your website, and who do I contact if the link doesn't open?" | unresolved |
| RR3 | Credible offer | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh, Finance Manager" | The offer names the role, the pay (inside the ad's band) and the manager, and followed two in-person interviews | `[grounded]` offer, ad and your account | "What does a typical first month look like?" | noted |
| RR4 | Pension-change duty against no direct experience | unknown | — | "process starters, leavers and pension changes" | Pension changes may be covered by training or a colleague at the start | `[inferred]` from the duty list against your statement | "Who covers pension changes in my first months, and is there training?" | unresolved |
| RR5 | Contract terms not stated | unknown | — | "permanent post ... starting on a date we agree" | The offer doesn't mention probation, notice, leave or pension scheme | `[grounded]` offer text | "Could you send the written contract, including probation, notice, leave and pension terms?" | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Type Marrowgate's address into your browser yourself, and check its Limerick contact details and People Team email against the offer | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Accept in writing only once you have asked for the full contract terms; don't give notice before you have them | RR5 | `[generic]` usual practice | pending your approval |
| A3 | After accepting, open the portal from the address on their website, or phone the People Team on the number published there to confirm the link. Enter details only in the portal, never by email, text or chat | RR2 | `[grounded]` RR2 | pending your approval |
| A4 | Bring the original passport on day one, as the offer asks | R2 | `[grounded]` offer text | pending your approval |
| A5 | Ask Declan Garvagh the pension-change question in your first week | RR4, R10 | `[grounded]` RR4 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused: "Marrowgate Housing Limerick housing association" and "Marrowgate Housing careers Payroll Administrator Limerick". It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | One search was refused: "Payroll Administrator salary Ireland Limerick 2026". It would have moved the market calibration row and R3 |
| 3. Hiring manager's public footprint | unavailable | You gave a name, but the search permission was refused, so none was sent. It would have moved the scope read and the plan's emphasis |

## Dossier offer and upgrade menu

I can save this as a `tuesday-dossier.md` if you'd like one.

- Search permission → RR1 and the role-reality organization row close, or become a standing risk entry.
- The salary search → market calibration and R3.
- A redacted payslip layout or a payroll-software report → R5 to `direct`.
- A cycle calendar or close checklist → R8's bridge narrows.
- The written contract → RR5 closes and R1 and R3 can be confirmed.
- A deeper research pass on Marrowgate (up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

1. Research consent — may I retry the employer check on Marrowgate's own pages?
2. R1, R3 — do you have non-negotiables, such as a pay floor, a limit on office days or a notice-period constraint?
3. G1 — was your hotel payroll run under Irish PAYE, PRSI and USC, and which of those did you process yourself?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.