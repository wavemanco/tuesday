Web checks on both employers were refused, so this assessment rests on your two postings and your background only. Everything unchecked is marked.

## Decision snapshot

### Duinvaart Cold Chain, Operations Analyst

**Yes, worth your time, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: RA1 (Hybrid, three days a week in Rotterdam)
- `must_have`: direct: RA2, RA3, RA4, RA5a
- `important`: adjacent: RA6 (Work with depot managers on route changes) · unclear: RA5b (Temperature compliance tracking)
- `preferred`: adjacent: RA7 (Dutch a plus)

RA6: your review reads performance, and nothing you've said covers changing routes; RA5b: nothing in your background on temperature data; RA1: waiting on your location.

**Opportunity ledger.** The posting is concrete about outputs (RRA3). The employer is unchecked (RRA1) and pay is withheld (RRA2).

- **Hard gates:** none failed; unconfirmed: RA1 (Hybrid, three days a week in Rotterdam); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) three days a week in Rotterdam works for you (RA1); (2) the employer verifies as real and the posting is live (RRA1); (3) you can speak honestly to temperature or compliance data (RA5b).

### Kroonhaven Foods, Supply Planner

**No, not as posted: RB2, RB4 and RB6 are absent must-haves. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: RB1 (On-site in Utrecht)
- `must_have`: adjacent: RB5 (Fluent Dutch), RB7 (Run the weekly S&OP meeting) · unclear: RB3 (Advanced Excel) · absent: RB2 (3+ years FMCG planning), RB4 (SAP IBP or similar), RB6 (Own the 13-week supply plan)

RB2, RB4, RB6: no planning work, by your own account; RB5: conversational against fluent; RB3: Excel isn't in your background.

**Opportunity ledger.** The scope is clear (RRB3). The employer is unchecked (RRB1) and pay is withheld (RRB2).

- **Hard gates:** none failed; unconfirmed: RB1 (On-site in Utrecht); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would change this:** planning work in a planning system that you haven't mentioned (RB2, RB4, RB6), or the employer treating those three as flexible.

## Role reality

| Element | Duinvaart | Kroonhaven | Provenance |
|---|---|---|---|
| Organization | Refrigerated fleet operator, Rotterdam | Chilled ready-meals producer, Utrecht | `[grounded]` postings; existence unchecked |
| Mandate | Track on-time delivery and temperature compliance, weekly Power BI dashboards, route changes with depot managers | Own the 13-week supply plan, balance capacity against forecast, run weekly S&OP | `[grounded]` postings |
| Working pattern | Hybrid, three days in Rotterdam | On-site Utrecht | `[grounded]` postings |
| Scope read | Reporting plus stakeholder work, close to what you do now | A planning-owner role, not an analyst role | `[inferred]` from each posting's responsibilities against your background |
| Market calibration | Not available: the sweep was blocked, so no band | Not available: same | — |
| Unknowns | Salary; whether the post is a backfill or new; who the manager is | Salary; whether Dutch is tested in the interview; tooling beyond SAP IBP | `[grounded]` postings are silent |
| Contradictions | None between posting and your background | None between posting and your background | `[grounded]` postings and your message; not cross-checked against careers pages |

## Evidence map

Your background is self-reported at this stage, so confidence tops out at `medium`.

**Duinvaart**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| RA1 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | You haven't stated where you live or your constraints, so the term is unsettled | `[grounded]` posting; your location not given | Ask whether this commute works (question below) |
| RA2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as operations analyst at a parcel carrier, confirmed in your message with no inspectable proof yet. A years requirement is graded on fit, not as a gate | `[grounded]` your background | none |
| RA3 | Strong SQL | must_have | direct | medium | none | "SQL daily" over four years; no sample inspected | `[grounded]` your background | A sanitized query would raise it to `high` |
| RA4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including the on-time delivery dashboard depot managers use | `[grounded]` your background | A dashboard screenshot would raise it to `high` |
| RA5a | Track on-time delivery | must_have | direct | medium | none | That dashboard is on-time delivery reporting, as you describe it | `[grounded]` your background | none |
| RA5b | Track temperature compliance | important | unclear | none | discovery | You haven't mentioned temperature or compliance metrics. The requirements list asks for logistics analysis generally, not cold-chain experience | `[grounded]` background silent; `[inferred]` the posting's requirements list doesn't ask for cold-chain experience | Question GA1 |
| RA6 | Work with depot managers on route changes | important | adjacent | medium | discovery | You ran the weekly route-performance review and built the dashboard depot managers use. Whether it led to route changes, and what you owned in them, is unstated, so the lower reading holds | `[grounded]` your background | Question GA2 |
| RA7 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch against an advantage that the posting doesn't define. State it as conversational, never fluent | `[grounded]` your background | none |

**Kroonhaven**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| RB1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Your location and constraints are not given | `[grounded]` posting; location not given | Moot unless you pursue the role |
| RB2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You've said you have never worked in planning, so discovery is done. Nothing adjacent is stated in FMCG | `[grounded]` your statement | Closure path in G-B1 |
| RB3 | Advanced Excel | must_have | unclear | none | discovery | Your tools are SQL and Power BI. Excel isn't mentioned | `[grounded]` background silent | Ask only if you pursue |
| RB4 | SAP IBP or similar planning system | must_have | absent | none | capability | BI tools are not planning systems, and none is stated | `[grounded]` your background | Closure path in G-B1 |
| RB5 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational against fluent. The limit is running a meeting in Dutch | `[grounded]` your statement | none |
| RB6 | Own the 13-week supply plan | must_have | absent | none | capability | No planning ownership stated | `[grounded]` your statement | Closure path in G-B1 |
| RB7 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly route-performance review, so you've facilitated a recurring ops meeting. The limit is that nothing stated shows it set a plan across functions; S&OP meetings usually do that | `[grounded]` your background; `[generic]` what S&OP meetings usually do | Strengthener: agenda or outcomes of your review |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GA1 | Temperature compliance (RA5b, important) | discovery | No cold-chain or compliance-metric work stated | It's the one responsibility with no evidence behind it | Delivery-failure or breach rates; SLA monitoring; chilled or time-critical parcel lanes; exception reporting | A dashboard view or a KPI definition sheet | `[grounded]` background silent; `[generic]` that such metrics are a normal parcel-analytics adjacency |
| GA2 | Route changes (RA6, important) | discovery | Review ownership is clear; the link to actual route changes is not | Separates "reported on routes" from "changed routes with managers" | A review that triggered a route or depot change; recommendations managers adopted | A review deck or a before-and-after metric | `[grounded]` your background |
| G-B1 | Planning must-haves (RB2, RB4, RB6) | capability | No planning evidence | Three must-haves with no closure inside this posting | Closure path: a planning-analyst or demand-planner-level role, or an SAP IBP course plus a forecasting portfolio piece | Not applicable now | `[grounded]` your statement; `[generic]` that adjacent analyst-to-planner moves exist |
| G-B2 | S&OP bridge (RB7, must_have) | transferability | Weekly review facilitation | The one must-have where your evidence carries over | Reviews where several depots agreed a change | A review agenda | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RRA1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The check was blocked, so this is a pending check; no finding about the company | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RRA2 | Salary not stated | unknown | — | "Operations Analyst — Duinvaart Cold Chain" (no pay figure) | The pay may sit outside your target, or the firm may simply not publish it | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |
| RRA3 | Concrete outputs | positive_signal | — | "build weekly dashboards in Power BI" | Success is measurable and matches work you already do | `[grounded]` posting | Who consumes the weekly dashboard today? | noted |
| RRB1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Same as RRA1 | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RRB2 | Salary not stated | unknown | — | "Supply Planner — Kroonhaven Foods" (no pay figure) | Same as RRA2 | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |
| RRB3 | Concrete mandate | positive_signal | — | "Own the 13-week supply plan" | Scope and ownership are explicit | `[grounded]` posting | Where is the plan produced today, and with what tool? | noted |

## Application plan

Duinvaart only is worth pursuing. If you go ahead, resume-tailor can fit your CV to it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Apply to Duinvaart once RA1 and RRA1 clear, leading with the on-time delivery dashboard and the weekly route-performance review, in your own terms | RA4, RA5a, RA6 | `[grounded]` your background | pending your approval |
| A2 | Say your Dutch is conversational, not fluent | RA7 | `[grounded]` your statement | pending your approval |
| A3 | Ask RRA1, RRA2 and RRA3's questions verbatim in a first call | Register doubles as interview prep | `[grounded]` register | pending your approval |
| B1 | Skip Kroonhaven as posted; look for roles between analysis and planning, such as a planning-analyst role | RB2, RB4, RB6 | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht chilled ready meals" were refused. They would have moved RRA1, RRB1 and the contradictions row |
| 2. Role-family sweep | unavailable | Searches "operations analyst logistics Rotterdam salary Power BI SQL" and "supply planner FMCG Netherlands salary SAP IBP Dutch required" were refused. They would have moved market calibration and RRA2, RRB2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

I can write all of this up as `tuesday-dossier.md` for later steps if you'd like.

**Upgrade menu**

- Permission for web search, so I can verify both employers and pull salary bands. That closes RRA1, RRB1, RRA2 and RRB2.
- Your location: settles RA1 and RB1.
- A dashboard screenshot or sanitized SQL sample: RA3 and RA4 to `high`.
- A hiring manager's name: sharpens how to lead the Duinvaart application.

**Questions**

- RA1: Where do you live, and is three days a week in Rotterdam workable?
- GA1: Have you worked with temperature, breach, SLA or other compliance-style metrics, even on chilled or time-critical parcels?
- GA2: Did your weekly route-performance review lead to actual route changes, and what part was yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.