Web search wasn't permitted in this session, so this runs on what you pasted and I couldn't check the company from outside.

## Decision snapshot

**Yes, worth taking the call. Nothing you've shared asks you for money, ID or bank details, but I couldn't confirm the firm exists from here. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R8 (First designer, no design peer)

R7 — a credible bridge, its limit named; R8 — adjacent, limit stated by you.

**Opportunity ledger.** The posting is specific and its details agree with the WhatsApp message, which counts in its favour (RR4). The employer is not yet established (RR1), the invite's sender is unchecked (RR2), and the equity terms and the company's funding position are unknown (RR3, RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** (1) the company verifies from independent sources, and the calendar invite comes from its own domain (RR1, RR2); (2) the pay clears your floor (R2); (3) you frame R7 and R8 honestly as adjacent.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting only; not checked externally |
| Mandate | First designer: owns the booking flow, runs research calls with school owners, ships with two engineers, works most closely with co-founder Ronan Kehoe | `[grounded]` posting |
| Working pattern | Hybrid, two days a week at the Galway office | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity; vesting, strike price and share class unstated | `[grounded]` posting |
| Scope read | Real ownership of one narrow product surface, with no design peer for review or mentoring | `[inferred]` from "first designer" and a six-person team |
| Market calibration | Not done: the search was refused, so I state no band | — |
| Unknowns | Funding and runway; equity terms; who decides product direction; how the school-owner research calls get arranged | — |
| Contradictions | None between the posting and the message: Ronan is the named co-founder in both, and the call matches the role's own description | `[grounded]` the two texts you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two office days a week in Galway | hard_gate | direct | medium | none | You live in Galway, so the location is met. You haven't said whether two fixed office days suit you | `[grounded]` your move back to Galway | Confirm the days suit you |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | You gave no pay floor, so I can't say whether the band clears it | `[grounded]` posting figure; no candidate constraint given | Question G3 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company, stated in prose, not yet probed | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is confirmed but nothing inspectable was read. The checkout case study they praised is the artifact, and I haven't seen it | `[grounded]` your background | Have the case study ready |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers. Limit: usability testing is not the same as discovery calls with school owners | `[grounded]` your background | Be ready to say which sessions were interviews and which were usability tests |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout, which is one stage of a booking flow. Limit: what you owned before and after checkout is unstated | `[grounded]` checkout redesign; `[inferred]` that "end to end" is broader | Question G1 |
| R8 | Work as the first designer, with no design peer | important | adjacent | low | transferability | You've never been the only designer. Your squad and checkout ownership are indirect evidence of working independently | `[grounded]` your statement; requirement `[inferred]` from "first designer" | Question G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking flow beyond checkout (R7, must_have) | transferability | Checkout redesign confirmed; search, availability, pricing and confirmation emails are not mentioned | The posting says "end to end", so this is the likeliest probe | Changes upstream of checkout that you proposed or shipped; post-booking screens; handoffs you drove to engineers | The checkout case study; before-and-after flows | `[inferred]` bridge from checkout to the full flow; `[generic]` that "end to end" gets probed |
| G2 | Operating without a design peer (R8, important) | transferability | No evidence of setting your own process, standards or priorities | You would be the only designer and the only person who can review design work | A component set you maintained; deciding what to research next; design decisions you defended to engineers or product | A design-system page; a research plan; a decision log | `[grounded]` your statement that you've never been the only designer; `[generic]` that first-designer roles lean on this |
| G3 | Pay against your floor (R2, hard_gate) | hard_gate | The band is stated, but no floor from you | A failed pay gate caps the decision however good the fit | Your current salary band and any minimum you'd accept, equity aside | Nothing to attach | `[grounded]` posting band, no candidate figure |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small for a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers page, and show me who else I'd be interviewing with? | unresolved |
| RR2 | Sender and invite domain unchecked | unknown | — | "I have emailed you a calendar invite with the video link" | The invite may come from Fernquay's own domain, or it may not. WhatsApp scheduling is not a signal on its own, and no request for money, ID or bank details appears | `[generic]` small teams often schedule by chat | Can you confirm the invite comes from your company email, and which video platform you'll use? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | The grant may be options with vesting and a strike price, or something else, and the percentage's value depends on that | `[inferred]` from the posting's silence on structure | What is the equity form, vesting schedule and strike price, and how many shares are outstanding? | unresolved |
| RR4 | Posting is specific and consistent with the message | positive_signal | — | "you will work most closely with our co-founder, Ronan Kehoe" | The mandate, pay, team size and the named people are stated and match | `[grounded]` the posting and the message you pasted | Who owns design priorities today, you or Ronan? | noted |
| RR5 | Company funding and runway unknown | unknown | — | "We are six people" | A six-person company's payroll depends on its funding, and the posting says nothing about it | `[generic]` early-stage payroll depends on funding | How long is the current runway, and what is the funding plan? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check that the company website and careers page exist and name Ronan and the role. Check that the invite's sender domain matches the site. Optionally look the company up on Ireland's public company register | See RR1, RR2 | `[generic]` standard verification steps | pending your approval |
| A2 | Open with what you actually did: "I redesigned our checkout flow and ran monthly usability sessions with customers." Say plainly that you've never been the only designer, and let them ask about the rest | See R5, R7, R8; each clause traces to your own sentences | `[grounded]` your background | pending your approval |
| A3 | Ask RR1, RR3 and RR5's questions in the call, and ask RR4's one too | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | Pay, equity and funding details go through the company's own channels only. If anyone asks you for money, a cheque deposit or ID details before an offer, stop and tell me | See R2 | `[generic]` standard hiring-process hygiene | pending your approval |

If you'd like to rehearse the call itself, mock-interview does that.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused: "Fernquay booking software sea kayak surf schools Galway" and "Fernquay product designer Galway careers". They would have settled the existence row in role reality and RR1 |
| 2. Role-family sweep | unavailable | One search was refused: "product designer salary Ireland startup first designer equity". It would have fed the market calibration row and R2 |
| 3. Hiring manager's public footprint | unavailable | One search was refused: "Ronan Kehoe Fernquay co-founder". It would have fed the scope read and the positioning in A2 |

## Dossier offer

If you'd like, I can write this up as `tuesday-dossier.md` to carry into later steps.

## Upgrade menu

- The company's website text, careers page or a LinkedIn page, pasted in → RR1 and the existence row can close.
- The sender address and domain of the invite → RR2 closes.
- Your pay floor → R2 moves to `direct` or `hard_gate_fail`, and the decision firms up.
- The checkout case study or a Figma link → R4 and R7 can reach `high`.
- Web search permission → the three declined targets can run, which would settle the market calibration and Ronan's footprint.

## Questions

G3 — What is the lowest base salary you'd accept, and does the equity matter to you at all?
G2 — Where have you set your own process or standards without a design peer, for example a component set, a research plan or a prioritisation call?
G1 — Did your checkout redesign touch stages before or after checkout, and what did you own there?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.