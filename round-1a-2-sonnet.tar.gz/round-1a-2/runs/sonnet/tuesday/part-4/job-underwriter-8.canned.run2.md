I'm still loading the job-underwriter's format rules, and I have three files left to read. The verdict is already clear: this has the pattern of a scam. I'll put the full write-up together next.
**No, don't go ahead. RR1, RR2 and RR3 are confirmed severe red flags, so the status is `no_go`. This job is very likely a scam.** The posting and the Telegram messages ask you to pay for equipment, deposit a cheque and hand over ID before any offer you can verify. Please don't paste your IBAN anywhere. I haven't used it, your PPS number or your passport, and none of them is needed for this assessment.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (at least €30,000 a year)
- `must_have` — direct: R3, R4 · adjacent: R2 (strong attention to detail)
- `important` — adjacent: R6 (order and parcel operations) · unclear: R5 (a quiet place to work)

R1 — the pay turns on a rate and hours the posting leaves open; R3 (`medium`) — your Excel tracker maps straight on.

**Opportunity ledger.** Poor. RR1, RR2 and RR3 are demands made of you; RR4 is a hiring process run wholly on Telegram; RR5 and RR6 are further signs. RR7 is the one favourable signal, and it is only the stated pay rate.

- **Hard gates:** none failed; unconfirmed: R1 (Earn at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** the demands would have to be absent. The employer would have to be confirmed through its own channels, and the process would need real interviews and a written offer that names the role and its pay. Even then R1 would need a rate and hours that reach €30,000.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics", named in the posting. No site or careers page was found, so the employer is not established | `[grounded]` posting; search returned nothing |
| Mandate | Remote order processing, 15–30 hours a week, "set your own hours" | `[grounded]` posting |
| Pay | "Up to €26 an hour plus commission." Against your €30,000 floor, that is about €19.23 an hour at 30 hours a week, the most the posting offers. At 15 hours, even €26 an hour is about €20,280 | `[inferred]` arithmetic on the posting's own figures |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median €31,200, interquartile range €28,400 to €34,100. The guide excludes freelance and commission-only work, so this is a pattern and not this employer's offer | `[generic]` Pennoral 2026 Ireland pay guide |
| Process | Hiring only on Telegram, "no calls or video interviews" | `[grounded]` posting |
| Unknowns | Who the employer is, the actual hourly rate and hours, the contract type | — |
| Contradictions | The posting says it needs no experience and offers "training", yet the messages jump to payment and ID within minutes of an application | `[grounded]` posting and messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | You need at least €30,000 a year | hard_gate | unclear | high | hard_gate | The constraint is your own. The posting gives only "up to €26", with hours from 15 to 30, so €30,000 is reachable only at the top rate and top hours | `[grounded]` your stated floor; `[inferred]` arithmetic | Ask for the confirmed rate and hours, in writing, through the employer's own channel |
| R2 | Strong attention to detail | must_have | adjacent | medium | transferability | About 60 tickets a day in Zendesk is a credible bridge. The limit is that ticket volume doesn't directly show order accuracy | `[grounded]` your account; `[inferred]` bridge | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep a weekly team tracker in Excel. Self-reported, with no artifact inspected | `[grounded]` your account | none |
| R4 | Good written English | must_have | direct | medium | none | Three years of written customer tickets and training two starters | `[grounded]` your account | none |
| R5 | A quiet place to work | important | unclear | low | discovery | You haven't said | `[grounded]` posting silent on your setup | none |
| R6 | Order and parcel operations, with training promised | important | adjacent | medium | transferability | Courier customer service sits next to order processing. The posting offers training | `[inferred]` from your courier role | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay against floor (R1) | hard_gate | "Up to €26" with 15–30 hours, and no contract or written rate | A €30,000 floor can't be confirmed from "up to" | A written offer from a verified employer stating rate, hours and contract | A signed contract from an employer whose own site you found yourself | `[grounded]` posting; `[inferred]` gap |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment demanded for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages" | This request is very likely a scam. Real employers don't normally charge new staff for equipment before pay begins | `[generic]` pattern for pay-to-work requests | Does your company ask new starters to pay for equipment before their first pay? Put this to the employer through contact details you find on its own site, never through the Telegram chat or the email address in these messages | confirmed |
| RR2 | Cheque deposit with onward transfer | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner" | Cheques of this kind often fail days after the deposit. The money sent on is then lost and the bank can claim back the deposit. Don't deposit it | `[generic]` pattern for cheque-and-transfer requests | See RR1 | confirmed |
| RR3 | Bank and ID details requested before any offer | red_flag | high | "Please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | These details were asked for after a Telegram "screening" and before a written offer. That is the stage at which this request is a sign of identity or payment-detail harvesting | `[generic]` pattern | See RR1 | confirmed |
| RR4 | Hiring run wholly on Telegram | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | The interview, offer and onboarding all happened in chat, so there is no way yet to tell who is on the other end. This sign takes no verdict by itself | `[generic]` pattern for chat-only hiring | See RR1 | confirmed |
| RR5 | Contact off any verifiable employer domain | risk_signal | medium | "Any problems, email velloway.hr@postmail.example" | The address is on a mail service, not on an employer's own domain. The message may not come from who it names | `[inferred]` from the address against no employer domain found | Which email domain does your own company use for HR? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The search returned nothing. The entity may be very small or new, or the posting may not represent a real hiring employer | `[generic]` pattern for companies without a footprint | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR7 | Stated hourly rate | positive_signal | — | "Earn up to €26 an hour" | The rate sits near the market median when read as full-time, though it is a ceiling and not a commitment | `[inferred]` against the `[generic]` band in role reality | What is the guaranteed hourly rate, before commission? | noted |

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. Until you have, hold the €349 payment, the cheque and your details.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing further: no IBAN, no PPS number, no passport photo | See RR3 | `[grounded]` register | pending your approval |
| A2 | Don't pay the €349, and don't lodge the cheque or send on any part of it | See RR1, RR2 | `[grounded]` register | pending your approval |
| A3 | Look for the company's own site yourself, not through any link in the chat, and ask them about this role | See RR1, RR6 | `[grounded]` register | pending your approval |
| A4 | If you have already shared your passport or PPS number, tell your bank and ask about identity-fraud steps. Report the posting to the jobs site | Limits misuse of anything already shared | `[generic]` common response to leaked identity details | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics careers remote order processing coordinator"; no results, so the employer is not established. This produced RR6 and the role-reality organization row |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary hourly rate Ireland", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). This gave the market calibration and the R1 comparison |
| 3. Hiring manager's public footprint | n/a | No name was given |

If you want more on this, I can run a deeper check on the company name and on public reports of this wording (up to 5 more searches and 2 more fetches). Say the word and it runs.

I can save this as `tuesday-dossier.md` if you'd like a copy.

- A link to the live posting, and the jobs site it's on, would let me check the posting against the site's own listing.
- The employer's own site or careers page, once you've found it, would settle RR6 either way.
- A written rate and hours from a verified employer would settle R1.

- RR6 and R1: have you found a website or careers page for this company yourself, and is the role listed there?
- R5: do you have a quiet place to work from home?

Answer briefly, or say "skip" to any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.