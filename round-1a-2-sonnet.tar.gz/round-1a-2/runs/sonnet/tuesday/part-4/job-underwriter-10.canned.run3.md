Running the first research searches now: does Fernquay exist as described, and is the role posted on its own site.
Short answer: **yes, apply and take the call**, and Fernquay checks out as real. The one thing I couldn't confirm is that the WhatsApp message actually came from Ronan. Check the sender address on the emailed invite before the call (RR2).

**Decision snapshot**

**Yes, worth applying to and taking the call. Fernquay's own careers page lists the same role, pay and hybrid terms (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Pay €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R8 (First designer)
- `preferred` — direct: R9

R7 — the checkout redesign is a credible bridge, its limit named; R8 — adjacent, no solo-designer history; R2 — waiting on your pay floor.

**Opportunity ledger.** The employer and the posted pay hold up against its own pages and a salary survey (RR1, RR3). The WhatsApp contact asks for nothing but a call, and its one open check is the invite's sender address (RR2). What is still unverified is the equity terms, the support a first designer gets, and how the company is funded (RR4, RR5, RR6).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52,000–€60,000 against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the pay clears your own floor, which only you can say — R2; (2) the emailed invite comes from a Fernquay address — RR2; (3) you get a clear answer on who supports and reviews a first designer's work — RR5.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers. Makes booking software for sea-kayak, surf and sailing schools in Ireland and Scotland | `[grounded]` About page (search result) |
| Role as published | "Product Designer, our first design hire. Hybrid, two days a week in Galway. €52,000–€60,000 plus equity." Applications go to a jobs address on the company's domain | `[grounded]` careers page fetched |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship alongside two engineers, working most closely with Ronan | `[grounded]` your pasted posting |
| Process so far | A WhatsApp message asking for a 45-minute video call with Ronan and Saoirse, plus an emailed calendar invite. It asks for no money, bank details or ID | `[grounded]` your pasted message |
| Scope read | A broad first-design-hire remit (flow ownership, research and delivery) for a small team | `[inferred]` from the posting's scope against its team size |
| Market calibration | Product designers with 3 to 5 years in Ireland: median base €57,000, interquartile range €51,500 to €62,000. The posted €52,000–€60,000 sits inside that range. This is a survey band, never Fernquay's offer, and it does not value the equity | `[generic]` Tillerby 2026 survey (n=520); `[grounded]` careers page for the posted range |
| People | Ronan Kehoe is listed as co-founder and CEO, previously product lead at a Galway travel-software company for five years | `[grounded]` professional profile (search result) |
| Unknowns | Equity terms; who reviews design work; revenue and runway; Saoirse's CTO title, which I did not see on the pages I read | `[grounded]` absent from the pages read |
| Contradictions | None between your pasted posting and the careers page (pay, hybrid, first design hire, apply with a real project) | `[grounded]` careers page fetched |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days are workable. The band grades your own statement, which is specific but not documented | `[grounded]` your message | none |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | You have not told me a pay floor, so I can't say whether the range meets it. The posted range is on the careers page | `[grounded]` careers page; no constraint stated | Ask for your floor (question G3) |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company. Self-reported, nothing inspected yet | `[grounded]` your background | A link to the work raises it |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is self-reported. The inspectable artifact in design is a portfolio with the Figma files | `[grounded]` your background | A portfolio link raises it |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers. The role also asks for research calls with school owners, which are interviews rather than usability tests. The limit is that interviewing owners is not shown | `[grounded]` your background; `[inferred]` that usability sessions differ from owner interviews | Prepare to say which you ran |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned your company's checkout flow, which is part of a booking flow. Limits: checkout is not the whole flow, and your ownership level is not stated | `[grounded]` your background; `[inferred]` the limit | G1 |
| R8 | Be the first designer, with no design peers (inferred from "our first designer") | important | adjacent | medium | transferability | Credible adjacent work (research, a redesign delivered with engineers), but you have always had other designers around | `[inferred]` from the posting's "first designer"; `[grounded]` your message | G2 and RR5's question |
| R9 | Booking-software domain (inferred from the product description) | preferred | direct | medium | none | Four years in travel booking. Owners of small outdoor schools are a different customer from consumer travellers, so the overlap has limits | `[grounded]` your background; `[inferred]` the difference in customer | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking flow ownership (R7, must_have) | transferability | A checkout redesign, but not what you owned or how far it reached beyond checkout | R7 is a `must_have` row at `adjacent`; it is the headline of the role | Choosing the scope of the redesign; deciding what shipped; touching search, selection or confirmation steps alongside checkout | The checkout case study they said they liked, with before and after screens | `[grounded]` your background is silent on scope; `[generic]` that this is the likeliest probe |
| G2 | Working as the first designer (R8, important) | transferability | Always in a team with other designers or a design lead | Decides whether you'd carry design direction alone | Setting up a design file system, documenting patterns, deciding between competing asks without a design lead | A style guide, component library or process doc you started | `[inferred]` from your "never the only designer" |
| G3 | Pay floor (R2, hard_gate) | hard_gate | The posted range, but no floor from you | A gate not yet checked against you | A figure you would not go below, and how you value equity | none needed | `[grounded]` no constraint stated |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting verified | positive_signal | — | "Open now: Product Designer, our first design hire. Hybrid, two days a week in Galway. €52,000–€60,000 plus equity." | Company and role are as posted | `[grounded]` careers page fetched; About page matches your posting | Which of the six people would I work with day to day? | noted |
| RR2 | WhatsApp contact plus emailed invite | unknown | — | "I have emailed you a calendar invite with the video link." | Chat is being used to schedule a call held elsewhere, which is not a sign of a problem by itself. I can't confirm the WhatsApp sender is Ronan, or that the email invite comes from a Fernquay address. The message asks for a call and nothing else: no money, bank details or ID | `[generic]` scheduling by chat on small teams; `[grounded]` the message's content | Could you send the invite from your Fernquay email address, and tell me who will be on the call? | unresolved |
| RR3 | Posted pay sits within the surveyed band | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | Pay is realistic for 3–5 years of experience | `[grounded]` careers page; `[generic]` survey band | Is the range fixed or does it move with experience? | noted |
| RR4 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The value depends on the type of equity, the vesting schedule and the share base, none of which the posting states | `[inferred]` from the posting's silence | Is the 0.5–1% options or shares, over what vesting, and as a share of what fully diluted base? | unresolved |
| RR5 | First designer with a wide remit | risk_signal | low | "own the booking flow end to end, run research calls with school owners, and ship alongside our two engineers" | You may carry design direction, research and delivery without a design peer to review your work | `[inferred]` from the posting's scope against your stated history | Who reviews design decisions, and how are research calls with school owners arranged? | unresolved |
| RR6 | Customer-funded, runway unstated | unknown | — | "funded by its customers" | Salary depends on revenue; how much runway the revenue gives is not stated | `[grounded]` About page; `[inferred]` on runway | How many schools pay today, and is this role funded from current revenue? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Before the call, check the emailed invite's sender address matches Fernquay's own domain, and don't share anything beyond what the call needs | see RR2 | `[grounded]` RR2 | pending your approval |
| P2 | Lead with the checkout redesign and the monthly usability sessions, in your own words and your own scope. Say plainly you have not been the only designer, and ask how the role is supported | see R7, R8, RR5 | `[grounded]` your background; `[inferred]` that this reads well to the hiring team | pending your approval |
| P3 | Ask the RR4, RR5 and RR6 questions verbatim on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P4 | Decide your pay floor and your view of the equity before the call | see R2, RR4 | `[grounded]` R2 | pending your approval |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about), and "Fernquay Product Designer careers Galway"; fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland first designer startup Galway", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe), as a search result only, not fetched. Moved role reality's people row; his stated role is the only part used |

If you'd like, I can save this as `tuesday-dossier.md` so a later step can pick it up.

**Upgrade menu**

- Your pay floor → R2 closes and the decision firms up.
- The invite's sender address → RR2 closes.
- The checkout case study they liked, with the Figma files → R3, R4, R5 and R7 can reach `high`.
- Equity terms from Ronan → RR4 closes.
- Interview prep for the call with Ronan and Saoirse is a separate job (a prep pack and a mock round); say so if you want it.
- A deeper diligence pass on Fernquay (funding history, customer and employee reports, recent news; up to 5 more searches and 2 more fetches) → RR6 and the risk register. Say the word and it runs.

**Questions**

G3 — What is the lowest salary you'd accept, and how much do you value the equity?

G1 — On the checkout redesign, what did you personally decide, and did your work reach beyond checkout into search, selection or confirmation?

G2 — Have you ever set up design practice from scratch (a pattern library, a research routine, a review habit), even informally?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.