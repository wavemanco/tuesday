I'm checking that Marrowgate Housing exists as described and that the €40,000 is in line with market pay, before I write up the assessment.
Web search wasn't permitted, so the employer, salary-band and manager checks didn't run, and I've marked that below. Here is the full assessment.

## Decision snapshot

**Yes, it's normal for an employer to ask for bank details, a PPS number and passport after a written offer that names the role and pay. Enter them only in the employer's own portal. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R9 (Two days a week in Limerick office), R10 (Pay €38,000–€42,000)
- `must_have` — direct: R1, R3, R4 · unclear: R2 (Irish PAYE, PRSI and USC)
- `important` — direct: R5, R6 · unclear: R8 (Answer staff payroll queries) · absent: R7 (Pension changes)

R2 — your background doesn't state the tax jurisdiction; R7 — you've not done pension changes yourself; R8 — query handling isn't mentioned; R9, R10 — your own limits weren't given.

**Opportunity ledger.** The offer is specific and matches the ad on title, pay band, reporting line and working pattern (RR3). Three things are unverified from here: the onboarding portal (RR1), the employer's own pages (RR2) and the written contract terms (RR4).

- **Hard gates:** none failed; unconfirmed: R9 (Two days a week in Limerick office), R10 (Pay €38,000–€42,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the portal address and the offer confirmed through contact details you find yourself on the employer's own website, not the email — RR1, RR2; (2) contract terms in writing before you hand in notice — RR4; (3) the pension-changes gap raised openly in your reply or first conversation — R7.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` ad and offer email; its own website was not checked |
| Role | Payroll for 240 staff: starters, leavers, pension changes, monthly ledger reconciliation, staff queries | `[grounded]` ad |
| Offer | Permanent, €40,000, reporting to Declan Garvagh (Finance Manager), hybrid two office days, five working days to accept | `[grounded]` offer email |
| Pay position | €40,000 is the midpoint of the advertised €38,000–€42,000 | `[grounded]` ad and offer email |
| Process before the offer | Two in-person interviews at their office | `[grounded]` your account |
| Onboarding request | Bank details, PPS number and a passport scan are asked for only after you accept, through a portal link sent then; the original passport is to be shown on day one | `[grounded]` offer email |
| Why it's routine | Bank details for salary, a PPS number for Revenue and an identity check are ordinary new-employee items | `[generic]` general onboarding pattern, not a claim about this employer |
| Market calibration | Not available: the salary search did not run, so I give no market band for this title | — |
| Unknowns | Contract terms, probation, pension scheme details, start date | `[grounded]` the offer email is silent on them |
| Contradictions | None between ad and offer on title, hours, pay band or hybrid pattern | `[grounded]` both documents |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years running payroll | must_have | direct | medium | none | You describe 3 years of fortnightly payroll for 90 staff. The ad sets no headcount or frequency. Your background is self-report with nothing inspected | `[grounded]` your background | none |
| R2 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | none | discovery | Your background doesn't say which tax system the hotel payroll ran under or whether you applied these yourself | `[grounded]` your background is silent | G1 |
| R3 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP, stated by you and not inspected | `[grounded]` your background | none |
| R4 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024, stated by you; the certificate itself isn't inspected | `[grounded]` your background | none |
| R5 | Monthly payroll-to-ledger reconciliation | important | direct | medium | none | You describe doing it monthly at the hotel group | `[grounded]` your background | none |
| R6 | Process starters and leavers | important | direct | medium | none | You describe starters and leavers at the hotel group | `[grounded]` your background | none |
| R7 | Process pension changes | important | absent | none | capability | You've never done them yourself; your manager handled them. The offer was made knowing your interview answers, which I haven't seen | `[grounded]` your statement | G2; say it plainly and ask about training |
| R8 | Answer staff payroll queries | important | unclear | none | discovery | Not mentioned in your background | `[grounded]` your background is silent | G3 closes it if you wish |
| R9 | Two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | Your commute and schedule limits weren't given. You attended two in-person interviews there | `[grounded]` ad; limits not stated | Question 3 |
| R10 | Pay €38,000–€42,000 | hard_gate | unclear | none | hard_gate | Your pay floor wasn't given; the offer is €40,000 | `[grounded]` ad and offer; floor not stated | Question 3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI and USC (R2, must_have) | discovery | Payroll experience, but no stated tax jurisdiction | A must-have the ad names directly; confirming it makes it direct | Applying tax and social-insurance rules yourself; handling year-end or Revenue-related returns; fixing a deduction error | Payslip layout (anonymised), a payroll-software screenshot with names removed, your certificate's syllabus | `[grounded]` background silent on jurisdiction |
| G2 | Pension changes (R7, important) | capability | You've not processed them; your manager did | The ad lists it as a duty, so you'd start with a task you haven't done | Pension deductions appearing on payrolls you ran; seeing a pension change processed even without doing it | Any record of a pension change you assisted with | `[grounded]` your statement; `[generic]` that a new starter can usually be trained on a task like this |
| G3 | Staff payroll queries (R8, important) | discovery | Not mentioned | An important duty; likely you did some | Answering payslip or deduction questions from staff | An example query and how you resolved it | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Portal link not yet seen; can't be checked from here | unknown | — | "we will send you a link to our onboarding portal" | A link arriving by email can't be told from the employer's own system without checking its address | `[generic]` a link's origin can't be judged from its appearance | Can you confirm the portal address, and that it is the one listed on your own website or HR system? | unresolved |
| RR2 | Employer not established from attributable sources | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The searches didn't run. Two in-person interviews at their office weigh strongly the other way, so this stays medium | `[generic]` pattern for any employer not yet checked, not a claim about this one | Can you point me at this role on your own careers site, and confirm who signed off the offer? | unresolved |
| RR3 | Offer names role, pay, reporting line, working pattern; follows two in-person interviews; sent from an address carrying the employer's name | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh, Finance Manager" | The role is concrete and consistent with the ad | `[grounded]` offer email and ad; the domain is not checked against the employer's website | Will a written contract carry these same terms? | noted |
| RR4 | Contract, probation, pension scheme and start date not in writing | unknown | — | "starting on a date we agree once your notice period ends" | Terms may exist but aren't yet visible | `[grounded]` the offer email is silent | Can I see the written contract, including probation and pension terms, before I give notice? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the company's own website yourself, not through the email, and phone or email the People Team using the contact details there to confirm the offer and the portal address | RR1, RR2 | `[grounded]` register | pending your approval |
| A2 | Enter bank, PPS and passport details only in the portal at the address confirmed in A1. Never send them as an email reply or attachment | RR1 | `[grounded]` register | pending your approval |
| A3 | Before giving notice, ask for the written contract (RR4) | RR4 | `[grounded]` register | pending your approval |
| A4 | Tell them about pension changes in your reply. Suggested wording: "I haven't processed pension changes myself; my manager handled those. Could you tell me how they're handled here and what training there is?" Each clause traces to your own sentence | R7 | `[grounded]` your statement | pending your approval |
| A5 | Bring the original passport on day one, as the offer asks | Offer email | `[grounded]` offer email | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Marrowgate Housing Limerick housing association"; the call was refused (permission not granted). It would have confirmed the employer and the live role, and moved RR2 and the domain check in RR3 |
| 2. Role-family sweep | unavailable | Searched "payroll administrator salary Ireland 2026 housing association Limerick"; refused. It would have set a market band in role reality and checked R10 |
| 3. Hiring manager's public footprint | unavailable | Searched "Declan Garvagh Finance Manager Marrowgate Housing"; refused. It would have confirmed he holds the role named in the offer |

I can save this as `tuesday-dossier.md` if you'd like a copy to keep.

## Upgrade menu

- Permission to run the three searches above → RR2 and RR3's domain check resolve, R10 gets a market band, and the manager's role is confirmed. A deeper pass would be up to 5 more searches and 2 more fetches.
- Your answers on tax jurisdiction → R2 moves toward `direct`.
- Your pay floor and commute limit → R9 and R10 resolve.
- The written contract → RR4 closes.

**Questions**

- G1 — Which tax system was the hotel group's payroll run under, and did you apply PAYE, PRSI and USC yourself, or did the software or your manager?
- G2 — Did pension deductions run through the payrolls you processed, and did you ever see a pension change go through, even without making it?
- R9, R10 — Are two office days a week in Limerick and €40,000 both acceptable to you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.