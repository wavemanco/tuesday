I'm checking the research rules in the playbook, then I'll run a few searches on Velloway Logistics. After that I'll give you the verdict.
**No. Don't go ahead, and don't send your IBAN, PPS number, passport photo or any money.** Of the six items checked below, RR1–RR4 are the serious ones. I couldn't find the firm anywhere, so I can't establish who is behind these messages.

## Decision snapshot

**No — RR1, RR2, RR3 and RR4 are confirmed severe red flags, so this is not worth pursuing. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Earn at least €30,000 a year)
- `must_have` — direct: R2, R3, R4
- `important` — adjacent: R5 (Order processing experience)

R1 — only an hourly ceiling is stated, so your floor is unconfirmed; R5 — a credible bridge, its limit named.

**Opportunity ledger.** The requests in RR1, RR2 and RR3 are very likely a scam, so pay nothing, deposit nothing and send nothing. RR4 adds a process that exists only in chat, and RR5 and RR6 leave the sender's identity unresolved.

- **Hard gates:** none failed; unconfirmed: R1 (Earn at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** the employer would have to be confirmed through its own website, and the payment, cheque and ID requests would have to be withdrawn. Even then, R1 would still need a written salary figure.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics", with no address, registration or website in the posting | `[grounded]` posting header |
| Mandate | Remote order processing, "no experience needed, full training provided" | `[grounded]` posting |
| Pay | "Up to €26 an hour plus commission", 15–30 hours a week. At the top rate that is about €20,280 a year at 15 hours and about €40,560 at 30. Your €30,000 floor needs roughly 22 hours a week at €26 all year, and "up to" means the real rate may be lower | `[inferred]` arithmetic from the posting's figures; commission is undefined |
| Hiring process | Wholly on Telegram, no calls or video interviews | `[grounded]` posting and messages |
| Posting vs messages | The posting mentions no equipment cost. The sender later asked you to pay for equipment and to deposit a cheque | `[grounded]` posting set against the messages |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland have a median base of about €31,200, with an interquartile range of €28,400 to €34,100. That guide covers salaried roles only, so it is a rough guide to what to expect, never this employer's offer | `[generic]` Pennoral 2026 pay guide, one search |
| Unknowns | Registered employer, base salary, commission terms, contract type | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Earn at least €30,000 a year (your hard constraint; posting says "up to €26 an hour plus commission") | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is `unclear` because no salary is stated, and the floor is reachable only at the top rate and at least roughly 22 hours a week | `[grounded]` your statement and the posting | Get a written base salary from the employer's own site |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 tickets a day in Zendesk is relevant, but it is self-reported and has no inspectable artifact | `[grounded]` your background as typed | none needed |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep a weekly team tracker in Excel; the claim is self-reported | `[grounded]` your background as typed | none needed |
| R4 | Good written English | must_have | direct | medium | none | Written ticket handling is relevant but not inspected | `[grounded]` your background as typed | none needed |
| R5 | Order-processing experience (implied by the title) | important | adjacent | medium | transferability | Parcel-courier ticket work is close. Limit: you haven't described order entry or fulfilment itself | `[inferred]` from the title against your courier work | none needed |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Earn at least €30,000 a year (R1, hard_gate) | hard_gate | Hourly ceiling and undefined commission; no base figure | Your floor can't be checked against "up to" pay | Not applicable; only the employer's written terms settle it | A written offer naming base pay, from a verified employer | `[grounded]` posting wording; `[generic]` that "up to" is a ceiling, not a rate |
| G2 | Order-processing experience (R5, important) | transferability | Courier ticket handling, nothing on order entry | Matters only if a real employer is found | Handling returns, redelivery or order-status changes for customers | A Zendesk macro or process note you wrote | `[inferred]` from your described work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | This request is very likely a scam. The sender's identity is unresolved, so the hold stands | `[generic]` requests to pay for the job or equipment are a known scam pattern | Which registered company is the employer, and can this role be confirmed through contact details on its own website, not through this chat or address? | confirmed |
| RR2 | Cheque deposit, then forwarding money | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest" | This request is very likely a scam. A cheque can be credited and later returned unpaid, leaving you to repay the money you forwarded | `[generic]` known cheque-overpayment pattern | Same question as RR1, asked only through independently found contact details | confirmed |
| RR3 | Bank, tax and ID details before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport" | This request is very likely a scam. It came after a chat screening and before any written offer from an employer you could verify | `[generic]` the same details can be used to open accounts or take credit in your name | Same question as RR1; the employer's own portal is the only place to enter such details | confirmed |
| RR4 | Hiring process wholly on chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | The sign shows no live check of who is hiring; it does not say who is behind it | `[grounded]` the posting's own words | Can I speak with a named hiring contact on a number published on your own website? | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Remote Order Processing Coordinator — Velloway Logistics" | The firm may be too new or small to have a footprint, the posting may be stale or aggregated, or the messages may not come from who they name; none is ranked as likely | `[generic]` possibilities for any employer with no findable footprint | Can you point me at this role on your own careers site? | unresolved |
| RR6 | Contact off the employer's domain | risk_signal | medium | "Any problems, email velloway.hr@postmail.example" | A free-mail style address is not an employer domain, so the sender may not be who they name | `[inferred]` from the address against an employer-owned domain | Is there an email address on your own company domain? | unresolved |

**Hold:** pay nothing, lodge nothing, and share no IBAN, PPS number or passport photo while you check. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send and pay nothing; if a cheque arrives, don't lodge it | see RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | Look for the firm on its own website or in the Irish company register, and contact it only through details found there | see RR1, RR5 | `[generic]` how to verify an employer | pending your approval |
| A3 | Report the posting to the jobs site where you found it | see RR4, RR5 | `[generic]` jobs sites usually accept such reports | pending your approval |
| A4 | If you've already shared anything beyond what you told me, contact your bank | see RR3 | `[generic]` banks handle suspected misuse of details | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics careers order processing coordinator remote"; both returned no results, so the firm is not established. This feeds RR5 and role reality's organization row |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator hourly pay Ireland", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). This set the market calibration row and the context for R1 |
| 3. Hiring manager's public footprint | n/a | No person's name was given, only a Telegram handle, so there was no query to form |

Tuesday can save this assessment as a `tuesday-dossier.md` if you want to keep it.

**Upgrade menu**
- The link to the live posting, or the name of the jobs site → RR5 can be checked against the posting itself.
- The company's own website or registration details, if it has any → RR5 and RR6 could close.
- A written base salary from a verified employer → R1 closes.
- A deeper research pass (up to 5 more searches and 2 more fetches) → fills out RR5 with any public reports. Say the word and it runs.

RR5 — Can you give me the link to the posting, or name the jobs site? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.