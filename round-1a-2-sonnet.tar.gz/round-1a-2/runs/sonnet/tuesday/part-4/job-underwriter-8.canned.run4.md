Nothing in the posting or the messages checks out, and the whole thing follows a pattern I'd stop on. I searched the company name and the pay level, and the answer is below.

## Decision snapshot

**No, don't go ahead. Status: `no_go`.** RR1, RR2, RR3 and RR4 are confirmed severe red flags, each a demand made of you. This job is very likely a scam. I can't establish the firm from here (RR5), so I'm judging the requests, not accusing anyone.

**Fit ledger.**

- `hard_gate` — unclear: R1 (€30,000 a year minimum)
- `must_have` — direct: R2 · adjacent: R3 (Strong attention to detail), R4 (Good written English)

R1 — the posting gives a ceiling, not a rate; R2 (`medium`) — Excel tracker, self-reported.

**Opportunity ledger.** RR1, RR2, RR3 and RR4 ask for your bank, tax and passport details, a €349 payment, a cheque deposit with onward transfer, and a hiring process held only in chat. Beneath them the employer is not established (RR5), and the pay claims need a written rate (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (€30,000 a year minimum)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`)
- **What would change this:** the employer established independently on its own careers page, a written offer at a stated rate with no payment, deposit or ID demanded beforehand, and a real interview outside chat.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics": a search of the name returned no results. That means nothing attributable turned up, not that no such firm exists | `[grounded]` search returned nothing |
| Mandate | Remote order processing, with commission on each order | `[grounded]` posting |
| Pay and hours | "Up to €26 an hour plus commission", 15–30 hours a week | `[grounded]` posting |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews"; an offer followed a chat Q&A | `[grounded]` posting and your messages |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median base €31,200, interquartile range €28,400 to €34,100, from a survey that leaves out commission-only and freelance work. At 30 hours for 52 weeks, €26 an hour is €40,560, above that band. The posting's rate is a ceiling and the survey is salaried-only, so this is a rough comparison, never this employer's offer | `[generic]` Pennoral 2026 pay guide; `[grounded]` posting figure and arithmetic |
| Unknowns | Who the employer is; the actual hourly and commission rates; employed or self-employed; who the "equipment partner" is | — |
| Contradictions | The posting mentions no equipment cost, but the messages add a €349 purchase and a cheque. The posting promises training, but the "interview" was a chat Q&A | `[grounded]` posting against your messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | €30,000 a year minimum (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your stated floor. Fit is unclear because "up to €26 an hour" is a ceiling. At that top rate, €30,000 needs about 22 hours a week, and 15 hours would give €20,280 | `[grounded]` posting figures and your constraint | Rate and guaranteed hours in writing from an independently verified employer |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel; self-reported, no artifact | `[grounded]` your message | none |
| R3 | Strong attention to detail | must_have | adjacent | medium | transferability | About 60 Zendesk tickets a day and training two starters are indirect evidence. Limit: neither shows error rates or checking | `[inferred]` from the ticket and training work you described | see G1 |
| R4 | Good written English | must_have | adjacent | medium | transferability | Ticket replies imply written work, but no samples were inspected | `[inferred]` from Zendesk ticket work | see G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Attention to detail (R3, must_have) | transferability | Volume and trainer work, no accuracy evidence | Would matter only for a real role that tests it | Catching wrong details in tickets; checking the tracker's figures; fixing errors in starters' work | A QA score or a team accuracy report | `[grounded]` your description; `[generic]` that such roles screen for it |
| G2 | Written English (R4, must_have) | transferability | Zendesk replies, no samples | Same | Reply templates or macros you wrote; guides for the starters you trained | A sanitized reply or guide | `[grounded]` your description; `[generic]` as above |

R1 is the one gap that could matter, and it can't be closed from here. The posting has to state the rate, from an employer you've verified.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bank, tax and passport details requested before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | These details can be misused to act in your name. Who sent the messages, and whether the employer in the posting is involved, is unresolved | `[grounded]` the message asks before any offer; `[generic]` on how such details can be misused | Through contact details you find yourself on the employer's own site or careers page, never this chat or address: did your organization ask me for bank, tax and passport details before an offer? | confirmed |
| RR2 | Payment demanded for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages" | Paying to start work is the request, and a promised refund from wages doesn't change that | `[grounded]` the message; `[generic]` on the pattern | As RR1 | confirmed |
| RR3 | Cheque to deposit, with the balance sent on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner" | A cheque can be credited and later returned, leaving the money you sent on as your loss | `[grounded]` the message; `[generic]` on how cheques clear | As RR1 | confirmed |
| RR4 | Hiring and offer run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | The offer followed a chat Q&A with no interview you can place. The sign shows only that the process can't be checked independently | `[grounded]` posting and messages | As RR1 | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Remote Order Processing Coordinator — Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. The reply address's domain is not tied to any employer site I could find | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` the name search returned nothing | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Pay claims need a written rate | risk_signal | low | "Earn up to €26 an hour plus commission on every order you process. No experience needed" | The top rate runs above the salaried band, and a ceiling says nothing of the rate you'd get. I took the lower severity because the survey covers salaried roles only | `[grounded]` posting; `[generic]` band | What is the guaranteed hourly rate, and the commission rate, in the written contract? | unresolved |

Hold everything: send nothing, pay nothing and lodge nothing while you check. Check with the employer named in the posting, using contact details you find yourself on its own website, not this chat or this email address. If you can't identify an employer independently, the sender's identity stays unresolved and the hold stays.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

You pasted your IBAN. I haven't repeated it, and nothing here needs it, your PPS number or your passport photo.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't send the IBAN, PPS number or passport photo | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Don't pay the €349 and don't lodge the cheque if it arrives | see RR2, RR3 | `[grounded]` RR2, RR3 | pending your approval |
| A3 | Stop replying in the chat; report the posting to the jobs site | Posting a risky advert is something the site can act on | `[generic]` common practice on jobs sites | pending your approval |
| A4 | Look for salaried order-processing or customer-operations roles where the employer's own careers page states the pay; your Zendesk and Excel work fits (R2) | Salaried roles in the survey's band could meet your €30,000 floor (R1) | `[generic]` pay guide; `[grounded]` your background | pending your approval |

I've proposed no CV edits, since there's nothing here to apply to.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics"; no results, so not established. Moved RR5 and the organization row |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland per hour", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). Moved the market calibration row and RR6 |
| 3. Hiring manager's public footprint | n/a | No person's name was given, only a chat handle, so there was no query to form |

If it would help, I can save this as `tuesday-dossier.md`, so a later check of a real posting starts from it.

**Upgrade menu**
- The posting's link or the jobs site's name → confirms the posting is live and consistent, and feeds RR5.
- The employer's own careers page or company registration details → closes RR5.
- A written offer stating the hourly rate and hours, from an independently verified employer → settles R1 and RR6.
- Your CV as a document → lifts R2, R3 and R4 from self-reported toward inspectable, for a real role.
- A deeper research pass (public reports of this pattern, recent news; up to 5 more searches and 2 more fetches) → say the word and it runs.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.