I couldn't run the web searches, so this assessment rests only on what you pasted.

## Decision snapshot

**Yes, taking the call looks worthwhile, but I can't establish Fernquay from here. Neither the posting nor the WhatsApp message asks you for money, documents or bank details. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important`: adjacent: R8 (Research calls with school owners), R9 (First designer on the team)

R7 — checkout is one stage of a booking flow, wider ownership unconfirmed; R9 — the sole-designer gap is real and named; R2 (`none`) — you gave no pay floor.

**Opportunity ledger.** The posting is specific and states its pay and equity, and it asks nothing of you (RR5). The company could not be checked (RR1), and the equity terms (RR3), the decision rights of a first designer (RR2) and the invite's sender (RR4) are open.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies from its own website and a live posting, and the invite comes from its own domain, per RR1 and RR4; (2) the range clears your own floor, per R2; (3) the first-designer remit has clear decision rights, per R9 and RR2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Six people in Galway making booking software for sea-kayak and surf schools"; this is the company's own description, not independently confirmed | `[grounded]` posting |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Working relationship | Closest to co-founder Ronan Kehoe; the call is with him and Saoirse, the CTO | `[grounded]` posting and WhatsApp message |
| Pay and equity | €52,000–€60,000 plus 0.5–1% equity; vesting, cliff and share structure are not stated | `[grounded]` posting figures; `[inferred]` from the posting's silence on terms |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting |
| Scope read | A founding-designer generalist remit (product ownership, research and delivery) rather than a pure craft seat | `[inferred]` from "first designer" against a six-person team |
| Market calibration | Not done: no research ran, and I won't use memory for pay or title norms | — research unavailable |
| Unknowns | Equity terms, funding and revenue, customer count, design decision rights, where your phone number came from | `[grounded]` posting and message silence |
| Contradictions | None between the posting and the message: the same co-founder, the CTO named by role, and your checkout case study | `[grounded]` both texts |

## Evidence map

I treated your typed background as CV-equivalent, and I haven't seen a CV or portfolio.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Galway office | hard_gate | direct | medium | none | You live in Galway. Confidence grades your statement of residence; whether you accept two fixed office days isn't stated | `[grounded]` your message | none |
| R2 | Pay €52,000–€60,000 | hard_gate | unclear | none | hard_gate | You gave no floor, so whether the range meets your terms is unsettled | `[grounded]` no constraint stated | G2: state your floor |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company; self-reported, no artifact inspected | `[grounded]` your background | case study link would raise it |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily"; the proof in design is a portfolio, not yet inspected | `[grounded]` your background | link the case study |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Whether you designed the studies as well as moderating them is unstated, so I took the narrower reading | `[grounded]` your background | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout at a travel-booking company, which is part of a booking flow. The limit: other stages and end-to-end ownership are unconfirmed | `[grounded]` your background; `[inferred]` that checkout is one stage of several | G1 |
| R8 | Run research calls with school owners | important | adjacent | medium | transferability | Your customer sessions carry over as method. The limit: whether those customers were small business owners, and whether the sessions were exploratory or evaluative, is unknown | `[grounded]` your background; `[inferred]` the method carries over | prepare an account of how you recruited and ran sessions |
| R9 | First designer, with no design peers | important | adjacent | low | transferability | You have owned a redesign and run sessions yourself, but have never been the only designer. Stated as a limit, not hidden | `[grounded]` your message; `[inferred]` requirement from "first designer" | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking flow ownership (R7, must_have) | transferability | A checkout redesign; no mention of search, availability, payment, confirmation or changes and cancellations | A must-have at `adjacent`; the posting asks for the whole flow | Owning availability or search screens, a changes-and-refunds flow, or confirmation emails | The case study, before/after screens, a flow map | `[grounded]` your background; `[generic]` that booking flows span several stages |
| G2 | Pay floor (R2, hard_gate) | hard_gate | A stated range, and no floor from you | A pay term is a gate, and it decides whether the call is worth your time | Your current salary band and what you would trade for equity | Your own figure; nothing to attach | `[grounded]` no floor stated |
| G3 | Working without design peers (R9, important) | transferability | Four years in a squad; no solo-design stretch mentioned | The posting makes you the first designer | Starting a design system, setting up research practice, a freelance or side project owned alone | A project link or short write-up | `[grounded]` your message; `[inferred]` what would count |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small to have a footprint, or the posting may be stale. No check ran, so this is about unverified status, not a finding | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who else I'd be interviewing with? | unresolved |
| RR2 | Responsibility without stated authority | unknown | — | "own the booking flow end to end" | Decision rights over what ships, and any research budget, are not stated | `[inferred]` from the posting's silence on authority | When design and engineering disagree on the booking flow, who decides, and what budget exists for research? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | Vesting, cliff, share class and dilution may differ from what the percentage implies | `[inferred]` from the posting giving a percentage without terms | What's the vesting schedule and cliff, and what share structure does 0.5–1% sit on? | unresolved |
| RR4 | Contact started on WhatsApp; invite sender not yet seen | unknown | — | "I have emailed you a calendar invite with the video link" | A chat message to schedule a video call is not by itself a sign of a problem. Open: the sender address of the emailed invite, and whether your number came from your application | `[generic]` pattern; the invite itself is not in hand | Could you confirm the invite is from your company address and that it's the same domain as your careers page? | unresolved |
| RR5 | Specific, transparent posting; nothing asked of you | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | Pay and equity are stated, the product is concrete, and the process is a video call with two named roles | `[grounded]` posting and message | Who will I work with most closely day to day beyond Ronan? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, open Fernquay's website yourself, not via any link in a message, and find this posting there. Check the invite came from an address on that same domain. | RR1, RR4 | `[grounded]` register | pending your approval |
| A2 | Settle your pay floor and whether equity moves it | R2, G2 | `[grounded]` R2 row | pending your approval |
| P1 | Lead with the checkout redesign and the monthly usability sessions. Name the limit: checkout is one stage of the flow. Say plainly you haven't been the only designer. | R5, R7, R9 | `[grounded]` your own statements | pending your approval |
| Q1 | Ask RR1, RR2 and RR3's questions verbatim on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none from prior context.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Fernquay and its posting were refused. They would have settled RR1 and whether the posting is live |
| 2. Role-family sweep | unavailable | One search on first-designer pay and scope was refused. It would have filled market calibration and checked R2 |
| 3. Hiring manager's public footprint | unavailable | One search on Ronan Kehoe's public professional background was refused. It would have fed the scope read and which story P1 leads with |

## Closing

I can save this as a `tuesday-dossier.md` for you to bring back later, if you'd like.

**Upgrade menu**
- Search access → RR1 gets a real answer, market calibration fills in, and Ronan's public professional background informs P1.
- The invite's sender domain (the part after the @) and the careers-page link → RR1 and RR4 close.
- A link to the checkout case study the founders saw → R3, R4, R5 and R7 can move toward `high`.
- Your pay floor → R2 and the hard-gates line resolve.
- Rehearsing the call with Ronan and Saoirse is the mock-interview module's job.

**Questions**
- G1 — Beyond checkout, which other stages of a booking journey did you personally own, and what happened as a result?
- G2 — What is the lowest base salary you would accept, and does €52,000–€60,000 clear it?
- G3 — Have you ever made design calls with no other designer to review them, for example a side project, freelance work or a system you set up alone?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.