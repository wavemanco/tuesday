Researching Fernquay's public footprint now, then I'll write up the assessment.
**Yes, it's worth taking the call. The employer checks out on its own pages (RR1), and the WhatsApp message asks only for a scheduled call (RR5). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Pay €52–60k plus equity)
- `must_have`: direct: R3, R4, R5, R7 · adjacent: R6 (Own the booking flow end to end)
- `important`: adjacent: R8 (First and only designer)

R6: checkout is a credible bridge to the whole flow, its limit named; R8 (`medium`): squad work, never solo.

**Opportunity ledger.** The employer and posting verify (RR1) and the stated pay sits inside the survey band (RR3). The open points are the unstated success measures (RR2), the equity terms and runway of a customer-funded company (RR4), and a chat-first contact route that so far asks nothing of you (RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52–60k plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the pay clears your own floor, which I don't have (R2); (2) the equity terms turn out to be real and explained (RR4); (3) you're comfortable being the only designer (R8, RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people, Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, "funded by its customers" | `[grounded]` About Fernquay page |
| Posting is live | The careers page lists "Product Designer, our first design hire", hybrid, two days a week in Galway, €52,000–€60,000 plus equity, applying with "one real project" | `[grounded]` careers page fetched |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship alongside two engineers, work closest with the co-founder | `[grounded]` posting |
| Hiring manager | Ronan Kehoe is listed as co-founder and CEO, previously product lead at a Galway travel-software company for five years | `[grounded]` search result, LinkedIn snippet, page not opened |
| Scope read | A normal remit for a product designer: one product surface, one research stream, one engineering pair. It isn't several roles folded into one title | `[inferred]` from four stated responsibilities against a six-person company |
| Market calibration | For 3–5 years' experience the survey gives a median base of €57,000 and an interquartile range of €51,500–€62,000. The posted range sits inside it, and the survey doesn't price equity | `[generic]` Tillerby 2026 Ireland Design Salary Report, n=520, snippet only |
| Unknowns | Success measures for the first year; equity terms (vesting, price, class); runway; who has the final say on design; your pay floor | `[grounded]` absent from posting and careers page |
| Contradictions | None between the posting and the careers page: same pay, same hybrid pattern, same "first design hire" | `[grounded]` both read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You said you moved back to Galway last year, so the pattern is workable. Stated in conversation, nothing inspectable | `[grounded]` your message | none |
| R2 | Pay €52–60k plus 0.5–1% equity (your floor unknown) | hard_gate | unclear | none | hard_gate | The range is stated but I have no floor from you, so I can't say whether the gate is met. The equity terms are also unstated | `[grounded]` posting and careers page agree on the range; `[generic]` survey band | Ask G3: whether the range clears your floor |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company, self-reported. Confirmed and specific, no inspectable proof yet | `[grounded]` your background | Your portfolio would raise this |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" across four years in a squad. Self-reported, and a file or prototype is the inspectable artifact in design | `[grounded]` your background | Link a Figma file or prototype from the case study |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Limit: these were usability sessions, not interviews with business owners, which is what the posting's "research calls with school owners" describes | `[grounded]` your background | Discovery-style interviews aren't confirmed; mention only if you have done them |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow of a booking product, which is a core part of a booking flow. Limit: nothing confirmed about the steps before or after checkout, or about owning the whole flow | `[grounded]` checkout redesign; `[inferred]` that "end to end" reaches beyond checkout | See G1 |
| R7 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers. Confirmed and specific | `[grounded]` your background | none |
| R8 | First and only designer: no design peer or reviewer | important | adjacent | medium | transferability | You've never been the only designer. Squad work and owning a flow with engineers carry over; setting up design practice alone, without anyone to review your work, hasn't been tested. That's a stated reading of "our first designer" | `[inferred]` from the posting's "first designer"; `[grounded]` your statement | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Whole booking flow, not only checkout (R6, must_have) | transferability | Checkout redesign confirmed; nothing on the steps around it | The posting leads with this responsibility, and R6 is a `must_have` row at `adjacent` | Choosing a date or slot, availability and group-size selection, add-ons, confirmation and reminder emails, cancellations and rebooking, mobile layout | A flow map, before-and-after screens, or conversion figures from the case study | `[grounded]` the posting's wording and your checkout work; `[inferred]` what "end to end" covers |
| G2 | Working with no design peer (R8, important) | transferability | Squad work confirmed; no solo-designer context | A first hire has no design lead to review work or share the load, so which parts you've already done alone sets how steep the ramp is | Setting up or maintaining a shared component library; running research without a research team; making a design trade-off with no design reviewer; writing up findings for engineers | A component library, a research summary, or a decision note | `[inferred]` that this is the likeliest adjustment; `[generic]` what solo roles usually involve |
| G3 | Pay and equity against your floor (R2, hard_gate) | hard_gate | Posted range and "plus equity" known; your minimum and your Dublin salary unknown | A gate nobody has checked. It decides whether the loop is worth your time | Your current pay, your minimum, and whether equity counts toward it or is a bonus | None needed; this is your own number | `[grounded]` posting range; `[generic]` survey band |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting verify | positive_signal | — | "We are six people in Galway making booking software for sea-kayak and surf schools" | The company exists as described and the role is live on its own careers page | `[grounded]` About page and careers page both read, matching the posting | Which two engineers would you work with day to day, and who has the final say on design? | noted |
| RR2 | Success measures and design support unstated | unknown | — | "own the booking flow end to end" | Accountability without a stated definition of success is a pattern to check, and a first design hire has no design reviewer | `[inferred]` from the posting's silence on outcomes; `[generic]` pattern for first-hire roles | What would a good first six months look like for this role, and who reviews design work? | unresolved |
| RR3 | Stated pay sits inside the market band | positive_signal | — | "€52,000–€60,000" | The range is in line with the survey band for this seniority | `[grounded]` posting; `[generic]` survey band | How is the range set, and what moves someone within it? | noted |
| RR4 | Equity terms and runway unstated | unknown | — | "0.5–1% equity"; "funded by its customers" | Equity in a customer-funded company has no outside round to price it, and its value depends on terms and revenue | `[grounded]` posting and About page; `[inferred]` what that means for value | What vesting schedule and share type apply, and what does the revenue runway look like? | unresolved |
| RR5 | First contact by WhatsApp, invite by email | unknown | — | "I have emailed you a calendar invite with the video link. Just shout here if the time does not suit" | The message asks only for a 45-minute video call. It asks for no payment, no bank or ID details, and no interview held in chat | `[grounded]` the message's content; `[generic]` small teams often schedule by chat | Can you confirm this invite is from your Fernquay address? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Open the emailed invite and check the sender address uses the same domain as the careers page, `fernquay.example`. I haven't seen the invite, so this check is yours | see RR5 | `[grounded]` careers page address | pending your approval |
| A2 | Work out your pay floor before the call | see R2, G3 | `[grounded]` R2 row | pending your approval |
| A3 | On the call, ask the RR2, RR4 and RR5 questions as written | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | Describe the checkout redesign as exactly that, and say plainly you've never been the only designer | see R6, R8 | `[grounded]` your own statements | pending your approval |
| A5 | If asked for the case study again, send the one they already liked, with a flow map if you have one | The message says they liked it; Ronan's background is product work in travel software | `[inferred]` from the message and his listed background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay product designer job Galway"; fetched "About Fernquay" (fernquay.example/about) and "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Role reality, contradictions row, RR1 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup first designer equity 2026", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report), snippet only. Market calibration, RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe), snippet only. Role reality's hiring-manager row and A5 |

The search results can't tell me whether the WhatsApp number is Ronan's. That's why A1 and RR5 are your checks to make.

I can write this up as `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- The checkout case study they liked, or any Figma file: R3, R4, R5 and R6 move toward `high`.
- Your pay floor: R2 resolves and the decision simplifies to `go` or `no_go`.
- Answers to G1 and G2: the R6 and R8 bridges strengthen or their limits get sharper.
- The call with Ronan and Saoirse: the mock-interview module can prep you for it.
- A deeper research pass on Fernquay (leadership history, customer and employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

G1 — In your checkout redesign, which steps of the booking flow did you personally own, and did you touch anything before or after checkout?
G2 — Have you ever made design decisions or set up shared design assets without another designer reviewing them? What happened?
G3 — What's your minimum salary for this move, and would you count the 0.5–1% equity toward it or treat it as a bonus?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.