Web search wasn't permitted, so this uses only what you pasted.

## Decision snapshot

**Yes, after a written offer like this, a request for bank details, PPS number and a passport scan is routine onboarding. Enter them only in the employer's own portal, at the address its own website gives. Status: `conditional_go`.**

Your "never hand those over" rule is a good one. It applies to an unverified sender, or to anyone who asks before a real offer exists. Here the request comes after a written offer that names the role, pay and manager, following two interviews you attended at their office. I couldn't verify the firm from here (see RR2).

**Fit ledger.**

- `hard_gate`: unclear: R1 (Hybrid, two days in Limerick), R2 (Salary €38,000–€42,000)
- `must_have`: direct: R3, R5, R6 · unclear: R4 (Irish PAYE, PRSI and USC)
- `important`: direct: R8, R10 · adjacent: R7 (Monthly payroll for 240 staff) · unclear: R11 (Staff payroll queries) · absent: R9 (Pension changes)

R4 (`low`) — unsettled by what you gave me; R9 — confirmed never done directly; R7 — the same work at a different scale and cadence.

**Opportunity ledger.** The offer's terms are specific and match the ad (RR3). Whether the portal link you'll receive leads to the employer's own portal is unchecked (RR1), as is the employer itself (RR2). Contract, probation and pension terms aren't in the email (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days in Limerick), R2 (Salary €38,000–€42,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the portal address matches the employer's own website or is confirmed by phone, using contact details you find yourself (RR1, RR2); (2) you see the contract, probation and pension terms before you give notice (RR4); (3) you confirm what training or cover exists for pension changes (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick. Its existence is not checked from here | `[grounded]` the pasted ad and offer |
| Mandate | Run monthly payroll for 240 staff; starters, leavers and pension changes; monthly payroll-to-ledger reconciliation; staff payroll queries | `[grounded]` JD |
| Working pattern and reporting | Permanent, hybrid, two office days in Limerick; reports to Declan Garvagh, Finance Manager | `[grounded]` JD and offer agree |
| Pay | Ad says €38,000–€42,000; offer is €40,000, inside the range | `[grounded]` JD and offer |
| Process | Two in-person interviews at their office; offer from people@marrowgatehousing.ie | `[grounded]` your account and the offer's sender line |
| Market calibration | Not run, because search was not permitted. No market band is claimed | none |
| Contradictions | None between ad and offer (title, pay range, hybrid pattern all agree) | `[grounded]` comparing the two texts |
| Unknowns | Whether the portal is the employer's own; contract, probation and pension scheme; who handles pension changes today | none |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | The term is stated in both documents. You gave no constraint on location or days, so I can't mark it met | `[grounded]` JD and offer; your constraint not given | Question 3 |
| R2 | Salary €38,000–€42,000 (offer: €40,000) | hard_gate | unclear | none | hard_gate | The offer is inside the ad's range. You gave no pay floor, so I can't mark it met | `[grounded]` JD and offer; your constraint not given | Question 3 |
| R3 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff at a hotel group. Self-reported with no artifact yet, so expect a probe | `[grounded]` your background as typed | none |
| R4 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | You didn't say the hotel group's payroll was Irish or that you ran these taxes yourself. They may well exist and the certificate may cover them | `[grounded]` silence in your background; `[inferred]` that the certificate may cover them, unchecked | Question 1 |
| R5 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP, confirmed and specific. No artifact inspected | `[grounded]` your background as typed | none |
| R6 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024. The certificate itself would be the inspectable artifact | `[grounded]` your background as typed | none |
| R7 | Run monthly payroll for 240 staff | important | adjacent | medium | transferability | The same work, fortnightly for 90 staff. The limit is that monthly cadence and 240 headcount are unexercised | `[grounded]` your background as typed | See G3 |
| R8 | Process starters and leavers | important | direct | medium | none | Stated directly, no artifact | `[grounded]` your background as typed | none |
| R9 | Process pension changes | important | absent | none | capability | You said you never did these and your manager handled them. This is a real gap, and the closure path is training | `[grounded]` your own statement | See G2 |
| R10 | Reconcile payroll to the general ledger monthly | important | direct | medium | none | Stated directly, no artifact | `[grounded]` your background as typed | none |
| R11 | Answer staff payroll queries | important | unclear | low | discovery | Not mentioned in what you gave me | `[grounded]` silence in your background | Low priority; not asked |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI, USC (R4, must_have) | discovery | Payroll years and a certificate, but nothing stating Irish tax work | The one must-have row left unsettled, and the job's core | Running Irish payroll at the hotel group; year-end or Revenue filings; the certificate's modules | Certificate syllabus, a reference letter | `[grounded]` background silent; `[generic]` that a role like this centres on these taxes |
| G2 | Pension changes (R9, important) | capability | You've never done them. The offer came anyway | You'd start with a task you haven't done | Any pension opt-in, contribution change or provider submission you saw done or helped with | A pension module on your certificate | `[grounded]` your statement; `[inferred]` that employers usually train for this |
| G3 | Scale of 240 monthly (R7, important) | transferability | Fortnightly payroll for 90 staff | Same skills, larger and different rhythm | A month-end close you handled, or any payroll with 200+ staff | Payroll calendar, reconciliation workbook (sanitized) | `[grounded]` your background; limit named above |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bank, PPS and passport requested after acceptance, via a link not yet sent | unknown | — | "Once you accept, we will send you a link to our onboarding portal, where you add your bank details for salary payments, your PPS number for Revenue, and a scan of your passport for our right-to-work check." | The request follows a written offer naming role and pay, from the employer's domain, after two in-person interviews, which fits ordinary onboarding. What is unchecked is where the link will lead | `[grounded]` the offer text and your account; `[generic]` that collecting these after an offer is ordinary onboarding | "Can you confirm the portal's web address, so I can match it to your website before I enter anything?" Use contact details you find yourself on their own site | unresolved |
| RR2 | Employer not established from attributable sources | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. Your two in-person interviews count against this, but I can't verify them | `[generic]` pattern for organizations of this kind, not a claim about this one | "Can you point me at the role on your own careers site, and who would I be working with?" | unresolved |
| RR3 | Offer terms specific and consistent with the ad | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh, Finance Manager" | Role, pay, manager and hybrid pattern are named and match the posting | `[grounded]` comparing the two texts | "Who else sits in the payroll and finance team?" | noted |
| RR4 | Contract, probation and pension terms absent | unknown | — | "starting on a date we agree once your notice period ends" | The email doesn't mention a contract document, probation or the pension scheme, which may follow separately | `[inferred]` from the email's silence | "Will I receive the written contract, including probation and pension terms, before I give notice?" | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Type the company's web address yourself, find its careers or contact page, and note a phone number from there | RR1, RR2 | `[grounded]` register | pending your approval |
| A2 | When the portal link arrives, don't use it until the People Team confirms the address through contact details from A1 | RR1 | `[grounded]` register | pending your approval |
| A3 | Ask for the written contract, probation and pension terms before giving notice | RR4 | `[grounded]` register | pending your approval |
| A4 | Ask what training or cover exists for pension changes, framed as a start-up question | R9, G2 | `[grounded]` R9 row | pending your approval |
| A5 | Bring the original passport on day one, as the offer asks | RR1 | `[grounded]` offer text | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Marrowgate Housing Limerick housing association"; the call was refused (permission not granted). It would have moved RR2 and the contradictions row |
| 2. Role-family sweep | unavailable | Searched "payroll administrator Ireland salary housing association Limerick"; refused likewise. It would have moved the market calibration row and the check on €40,000 |
| 3. Hiring manager's public footprint | unavailable | No search was sent for Declan Garvagh because search was not permitted. It would have moved the application plan's positioning |

If you'd like to keep this analysis, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- The company's own careers page link, or a phone number you've found yourself → RR2 and RR1 can close.
- An answer to G1 → R4 settles and the `must_have` tier is clear.
- Your pay floor and office-day limits → R1 and R2 become met or failed instead of unclear.
- The written contract and pension terms → RR4 closes.
- Search permission → L1 research runs (up to 5 searches and 2 fetches) and fills the three target rows above.

## Questions

1. G1 — Was the hotel group's payroll Irish, and did you personally run PAYE, PRSI and USC? Did the certificate cover them? 
2. G2 — Did the interviews cover that you haven't done pension changes, and what did they say about training?
3. R1 and R2 — Is €40,000 and two Limerick office days acceptable, or do you have a floor or a limit on either?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.