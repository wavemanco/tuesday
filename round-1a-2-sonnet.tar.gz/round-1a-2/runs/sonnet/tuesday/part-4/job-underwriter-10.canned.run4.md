Checking whether Fernquay exists and the role is live, then I'll write the assessment.
**Decision snapshot**

**Yes, worth continuing, and the employer checks out on what I could find (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R6
- `important`: adjacent: R7 (Own booking flow end to end), R8 (First designer, no design peer)

R7 – your checkout redesign is a credible bridge, its limit named; R8 – the real stretch, since you have never been the only designer.

**Opportunity ledger.** The company and the posting match across independent results (RR1). The WhatsApp route is an unknown that the invite email can settle (RR2). The job is a stretch scope for a first designer (RR3). The equity terms are unstated (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the calendar invite arrives from a Fernquay address (RR2); (2) the salary band clears your floor (R2); (3) the equity terms are explained (RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people, Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` About page, search result |
| Role | First design hire, owning the booking flow, running research calls with school owners, shipping with two engineers | `[grounded]` your posting; the careers page listing matches |
| Working pattern and pay | Hybrid, two days a week in Galway, €52,000–€60,000 plus 0.5–1% equity, same on the careers page | `[grounded]` posting and careers page |
| Who you'd work with | Ronan Kehoe is listed as co-founder and CEO, and was previously a product lead at a Galway travel-software company for five years. Saoirse is called CTO in the message. I could not confirm that title | `[grounded]` LinkedIn-style result for Ronan; `[inferred]` for Saoirse's title |
| Scope read | One designer covering flow ownership, research and delivery with no design peer is normal for a six-person company | `[generic]` pattern for companies of this size |
| Market calibration | For 3–5 years' experience in Ireland the survey shows a median base of €57,000 (interquartile range €51,500–€62,000). The posted band sits inside it. This is the market band, not this employer's offer | `[generic]` Tillerby 2026 salary report, from a search snippet |
| Unknowns | Equity terms; your pay floor against the band; the invite sender | – |
| Contradictions | None between the posting, the careers page and the About page | `[grounded]` search results |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days look workable. You have not stated a constraint, so the band is `medium` | `[grounded]` your message | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | You have not given a pay floor, so I cannot say whether the band meets it | `[grounded]` your message is silent on pay | G3 question |
| R3 | 3+ years of product design | must_have | direct | medium | none | 4 years as a product designer at a Dublin travel-booking company, self-reported with no document seen | `[grounded]` your message | none |
| R4 | Strong Figma | must_have | direct | medium | none | Figma daily, self-reported. Expect them to look at real files | `[grounded]` your message | bring a real project (A2) |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers. The limit: this role calls for research calls with school owners, so B2B owner interviews may differ from the customer sessions you ran | `[grounded]` your message; `[inferred]` on the B2B difference | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | Four engineers in your squad against two here | `[grounded]` your message | none |
| R7 | Own the booking flow end to end | important | adjacent | medium | transferability | You redesigned a checkout flow. The limit: checkout is one stage, and end-to-end could also cover search, availability, pricing and post-booking | `[grounded]` your message; `[inferred]` on how far end-to-end reaches | G1 |
| R8 | First designer, no design peer (inferred from "our first designer") | important | adjacent | medium | transferability | You have worked daily with engineers and owned a flow. The limit: you have never been the only designer, so setting up research and design practice alone is unexercised. The posting says what they want to see is "one messy real project", which counts in your favour | `[inferred]` from the posting's "first designer"; `[grounded]` your message | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking flow beyond checkout (R7, important) | transferability | A checkout redesign. No view of how much of the surrounding flow you owned | End-to-end ownership is the headline of the job | Work on availability, basket or multi-person bookings, confirmation and post-booking emails, or changes to search | The checkout case study they already liked, plus any before/after | `[grounded]` your message; `[generic]` that end-to-end flows usually span more than checkout |
| G2 | Working as the only designer (R8, important) | transferability | Squad work with engineers, no solo design role | They are hiring their first designer, so the gap is the heart of the job | Setting up a Figma library alone, starting a research routine, or making design calls with no peer review | A project you drove without design review, or a library you built | `[inferred]` from the posting's "first designer"; `[generic]` that a solo hire carries this weight |
| G3 | Pay floor against the band (R2, hard_gate) | hard_gate | Band stated, floor unknown | A gate not yet established | – | – | `[grounded]` posting; your message is silent on your floor |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting attributable | positive_signal | – | "six people in Galway making booking software for sea-kayak and surf schools" | The company exists as described and the role is live with the same pay band | `[grounded]` About page, careers page, and the result for Ronan, all consistent with the posting | Beyond you and Saoirse, who would I meet, and when would I meet the two engineers? | noted |
| RR2 | First contact by WhatsApp, with the invite sent by email | unknown | – | "I have emailed you a calendar invite with the video link. Just shout here if the time does not suit." | Small teams often schedule by chat. The message asks for no money, no ID and no bank details, and the interview is on a video call rather than in chat. I cannot verify the number from here | `[generic]` pattern for small teams; `[grounded]` the message's content | Could you confirm the invite came from your Fernquay address, and which platform the call will use? | unresolved |
| RR3 | Stretch scope for a first designer | risk_signal | low | "own the booking flow end to end, run research calls … and ship alongside our two engineers" | One person carries flow, research and delivery with no design mentor. Severity stays `low` because the posting says the mess is welcome | `[inferred]` from the posting's scope against "first designer" | What would success look like for the designer after six months, and who reviews design work? | unresolved |
| RR4 | Equity terms unstated | unknown | – | "0.5–1% equity" | Vesting, cliff, share class and current valuation are not given, so the percentage cannot be priced. The company is funded by its customers, so there is no outside round to anchor on | `[grounded]` posting is silent on terms; `[generic]` that equity needs those terms to be valued | What is the vesting schedule, and what is the current share count or valuation? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check that the calendar invite arrives from the same domain as the careers page address before you accept or click the video link | RR2 | `[grounded]` careers page address | pending your approval |
| A2 | Bring one real project they can see in Figma, messy included, in line with the posting's own ask. The checkout case study they praised is the natural lead | R4, R7 | `[grounded]` posting and message | pending your approval |
| A3 | Say plainly that you have always worked inside a design team, then describe how you would set up practice alone | R8 | `[inferred]` from the gap, not a claim about the company | pending your approval |
| A4 | Ask the four register questions, RR1 to RR4, on the call | the register is also your interview prep | `[grounded]` register | pending your approval |

You have a video call coming, so the interview-prep module can build a pack and run drills on request.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about), and "Fernquay product designer Galway careers", which returned "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). I read snippets, not full pages. Moved RR1 and the contradictions row |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup first designer equity", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration line. It did not speak to equity norms |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Moved the "who you'd work with" row |

I can offer one extension beyond this: a deeper diligence pass. Say the word and I'll run up to 5 more searches and 2 more fetches on company funding, customer reports and recent news.

I can also save this as `tuesday-dossier.md` if you'd like to keep it.

**Upgrade menu**
- The invite email's sender address would close RR2.
- Your pay floor would settle R2, which carries the one unconfirmed gate.
- The checkout case study, or any link or file from a real project, would raise R4, R5 and R7 toward `high`. For a designer the inspectable artifact is a portfolio piece or a Figma file.
- Their answers on vesting, cliff and valuation would close RR4.

G3 — Is there a salary below which you wouldn't take this role, and does €52,000–€60,000 clear it?
G2 — Have you ever made design decisions with no other designer reviewing them? What did you own, and what happened?
G1 — Which parts of the booking journey beyond checkout did you personally change?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.