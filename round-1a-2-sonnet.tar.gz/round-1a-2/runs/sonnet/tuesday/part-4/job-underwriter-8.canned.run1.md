I've read the playbook and run two searches, which found nothing on the firm. I'm now running one pay-benchmark search for this role type, and then I'll write the full assessment.
# Job Underwriting Assessment: Remote Order Processing Coordinator

## Decision snapshot

**Is it legit, and should you go ahead? No, don't go ahead. This job is very likely a scam. RR1, RR2, RR3 and RR4, each `severity: high`, are requests the sender has made of you. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Pay at least €30,000 a year)
- `must_have` — direct: R3, R4 · adjacent: R2 (Strong attention to detail)

R1 — "up to" pay and 15–30 hours leave your floor unsettled; R3 (`medium`) — Excel tracker, self-reported.

**Opportunity ledger.** The messages ask you to pay, to deposit a cheque and forward money, and to hand over bank, tax and passport details before any offer (RR1, RR2, RR3), and the whole process is chat-only (RR4). I can't establish the firm from here (RR5), and the pay terms are loose (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Pay at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** the employer would have to be established through its own website, and a written offer would have to come from its own domain. The payment, cheque and pre-offer ID requests would have to be withdrawn, and a guaranteed rate and hours would have to meet your floor (R1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics", named in the posting; not established | `[grounded]` posting; `[grounded]` a careers search returned no results |
| Mandate | Remote order processing, 15–30 hours a week, "up to €26 an hour plus commission on every order" | `[grounded]` posting |
| Hiring process | Telegram only, "no calls or video interviews" | `[grounded]` posting |
| Pay against your floor | €26 an hour is €390 a week at 15 hours and €780 at 30. Reaching €30,000 a year at the top rate needs about 22 hours a week, all year | `[inferred]` arithmetic on the posting's own figures |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median €31,200, interquartile range €28,400 to €34,100. The guide excludes commission-only and freelance work, so it is a loose comparison for hourly part-time | `[grounded]` Pennoral 2026 pay guide snippet |
| Unknowns | Guaranteed hourly rate, commission scale, guaranteed hours, employment basis, who the employer is | `[grounded]` posting silent |
| Contradictions | The posting mentions no equipment purchase. The messages add a €349 payment and a cheque to forward | `[grounded]` posting against the messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your hard constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is `unclear` because "up to €26" with 15–30 hours settles no minimum | `[grounded]` your statement; posting figures | Moot unless the employer verifies. Then ask RR6's question |
| R2 | "Strong attention to detail" | must_have | adjacent | medium | transferability | Volume ticket work and training two starters are adjacent. Accuracy rates aren't stated, which is the limit | `[grounded]` your background in prose | none needed given the status |
| R3 | "Confident with spreadsheets" | must_have | direct | medium | none | You keep your team's weekly Excel tracker. It is self-reported, with no artifact inspected | `[grounded]` your background in prose | none |
| R4 | "Good written English" | must_have | direct | medium | none | Zendesk ticket work is written, and ticket text is the evidence a sample would show. The level isn't tested here | `[inferred]` from your Zendesk work | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Guaranteed pay against the €30,000 floor (R1, hard_gate) | hard_gate | Only a ceiling rate and a variable 15–30 hours | Until a floor rate and guaranteed hours exist, R1 stays `unclear` | Not applicable; this is a term of the job | A written offer from the employer's own domain stating rate, hours and commission | `[grounded]` posting terms |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment for equipment asked of you | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | This request is very likely a scam. Don't pay. | `[grounded]` the message asks it; `[generic]` up-front payment for work equipment is a known scam pattern | To the employer, using contact details you find yourself on its own site, never the chat or email you were given: "Do new hires pay for equipment by transfer to a third party, and did you send this message?" | confirmed |
| RR2 | Cheque to deposit, with money forwarded onward | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | This request is very likely a scam. Don't deposit the cheque. A cheque can be credited and later returned unpaid, leaving the transfer you made on your own account | `[grounded]` the message asks it; `[generic]` how a returned cheque leaves the transfer on your account | As RR1, through the same independent route: "Does payroll send new starters a cheque to forward to a supplier?" | confirmed |
| RR3 | Bank, tax and ID details requested before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up." | This request is very likely a scam. It came before any offer | `[grounded]` the message asks it; `[generic]` these details are what identity misuse needs | As RR1: "Do you collect IBAN, PPS number and passport before an offer, and through which portal?" | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | The interview and the offer happened only in chat, so nothing in the process reaches a person or place you can check. The message may not come from who it names | `[grounded]` the posting and the messages | As RR1: "Can I speak to a named person at your company by phone or video before I accept?" | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Pay stated as a ceiling with no floor or commission scale | risk_signal | low | "Earn up to €26 an hour plus commission on every order you process." | €26 is a ceiling. The pay guide's median converts to roughly €15 an hour at 40 hours a week, which is my assumption, and the guide excludes part-time and commission work, so the gap is loose evidence | `[grounded]` posting and guide figures; `[inferred]` the hourly conversion | What is the guaranteed hourly rate, how is commission calculated, and how many hours a week are guaranteed? | unresolved |

Please don't pay, deposit the cheque or send your IBAN, PPS number or passport photo until you have confirmed who is behind this through contact details you find yourself on the employer's own website, not through the Telegram handle or the email address you were given. Your IBAN, PPS number and passport aren't needed for this assessment, and I haven't repeated or used them. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Hold the €349 payment, the cheque and your IBAN, PPS number and passport photo | see RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | Find the company's own website yourself and ask RR1's question through contact details found there | see RR1, RR5 | `[grounded]` register | pending your approval |
| A3 | If a cheque arrives anyway, don't lodge it; ask your bank how to handle it | see RR2 | `[generic]` common bank guidance | pending your approval |
| A4 | If you want a genuine version of this kind of work, look at salaried coordinator roles. Your Zendesk and Excel tracker experience (R3, R4) fits them, and the pay band's median clears your floor | see R1, RR6 | `[inferred]` from the pay guide against your background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics careers Ireland"; no results, so the employer is not established. It feeds role reality's Organization row and keeps RR5 open |
| 2. Role-family sweep | yes | Searched "order processing coordinator remote part-time hourly pay Ireland"; it returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). It set role reality's market calibration and RR6 |
| 3. Hiring manager's public footprint | n/a | No name was given, only a Telegram handle |
| Outside the declared targets | yes | Searched "remote order processing coordinator Telegram interview cheque equipment fee job scam Ireland"; no results, so it moved nothing |

I can offer to save this as `tuesday-dossier.md`, if you want a record to keep.

## Upgrade menu

- The name of the jobs site and the link to the posting → I can check whether its employer listing leads to a site you can verify, which would settle RR5.
- The company's own website or Irish company registration details, found independently → RR5 closes one way or the other.
- A written offer from the employer's own domain stating rate, hours and commission → R1 and RR6 close.
- A deeper research pass (funding and leadership, public candidate reports, recent news; up to 5 more searches and 2 more fetches) → say the word and it runs.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.