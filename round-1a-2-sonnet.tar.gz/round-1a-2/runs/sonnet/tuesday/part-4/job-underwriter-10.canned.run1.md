I've run four searches and they all line up with the posting. Next I'm fetching Fernquay's own careers and about pages to check the posting is live and consistent.
**Worth taking the call — and Fernquay checks out against its own pages (RR3). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R8 (Research calls with school owners) · absent: R9 (First designer, no design peer)

R7 — a credible bridge from checkout to the whole flow, its limit named; R8 — usability sessions, not owner calls; R9 — the real stretch, since you have never been the only designer.

**Opportunity ledger.** The employer is established and the posting is live and consistent with it (RR3), and the stated pay sits inside the market band (RR5). The WhatsApp contact is unconfirmed as to sender only (RR4), and the sole-designer scope (RR1) and the equity terms (RR2) are unknowns.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for `go`:** (1) R2 — your pay floor sits at or below the posted range; (2) RR2 — equity terms confirmed in writing; (3) RR1 — what design support exists, given R9; (4) RR4 — the invite comes from a Fernquay address.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` About page, fetched |
| Posting | The careers page lists the same role, the same hybrid pattern (two days a week in Galway) and the same €52,000–€60,000. It says "plus equity" with no percentage; the 0.5–1% appears only in the text you pasted | `[grounded]` careers page, fetched |
| Mandate | First design hire. Own the booking flow, run research calls with school owners, ship with two engineers, work most closely with a co-founder | `[grounded]` posting |
| Scope read | A broad solo-designer remit with direct access to a founder and no stated design leader | `[inferred]` from "first designer" against the silence on design support |
| Market calibration | Product designers with 3 to 5 years in Ireland: median base €57,000, interquartile range €51,500 to €62,000. The posted range sits inside it. The band is what to expect, never Fernquay's offer, and it excludes equity | `[generic]` Tillerby 2026 Ireland Design Salary Report (n=520), read from the search snippet; `[grounded]` posting for the range |
| Ronan Kehoe | Co-founder and CEO at Fernquay, previously a product lead at a Galway travel-software company for five years | `[grounded]` public profile, search snippet only (page not fetched) |
| Saoirse | Your message calls her CTO. The About page names Saoirse Doyle as co-founder and gives no title | `[grounded]` About page; `[inferred]` that it is the same person |
| Unknowns | Equity mechanics; who reviews design work; whether the WhatsApp number is Ronan's | — |
| Contradictions | None between the posting and the careers page. The WhatsApp number appears on neither page I read | `[grounded]` both pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You say you moved back to Galway last year, and you stated no limit on office days. Confidence grades your own statement, which is specific but unprobed | `[grounded]` your message | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | The posting states the range, but you have not told me your floor, so I cannot say whether it is met. The range sits inside the market band | `[grounded]` posting; `[generic]` band | G3 question |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company, self-reported and unprobed | `[grounded]` your message | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is specific but nothing was inspected | `[grounded]` your message | Your Figma file or the checkout case study would raise it to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers, which you ran. Scope is usability sessions only | `[grounded]` your message | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your message | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow. The limit is that checkout is one stage of a booking flow, and "redesigned" does not say you owned the whole flow | `[grounded]` your message; the "end to end" reading is `[inferred]` from the posting's wording | G1 question |
| R8 | Run research calls with school owners | important | adjacent | medium | transferability | Usability sessions with customers carry over. Limit: you have not said you ran discovery calls with business owners | `[grounded]` your message; requirement from the posting's responsibilities | G2 question |
| R9 | Work as the first and only designer | important | absent | none | capability | You said you have never been the only designer. Requirement inferred from "our first designer". Squad work is not the same, so this stays a stated stretch, not a blocker | `[inferred]` from the posting's "first designer"; `[grounded]` your statement | Closure path in G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Whole-flow ownership (R7, must_have) | transferability | A checkout redesign in travel booking, with no stated ownership of the stages before it | R7 is a `must_have` row at `adjacent`, and "end to end" is the role's headline | Search or availability screens, basket or add-ons, confirmation emails, changes and cancellations, even where a squad owned the rest | The checkout case study (they have seen it), a flow map, a Figma file | `[grounded]` your message is silent on other stages; `[generic]` that "end to end" invites a scope probe |
| G2 | Research with business owners (R8, important) | transferability | Monthly usability sessions with customers, with no stated discovery or owner-side interviews | The role runs owner calls, and testing a design differs from learning how a school operates | Calls with partners or suppliers, sales or support calls you sat in on, interviews before a design existed | A research plan, a call guide, a synthesis note | `[grounded]` your message; `[generic]` that testing and discovery are different skills |
| G3 | Pay floor (R2, hard_gate) | hard_gate | The range is posted and your floor is unknown | A gate the inputs do not settle is carried until you answer | Your minimum base, with equity counted or not | None needed | `[grounded]` posting and your message |
| G4 | Solo-designer work (R9, important) | capability | No sole-designer experience; squad work only | A stated stretch the founders should hear from you | Setting your own priorities, running design crits with non-designers, establishing a component library | Not closable by evidence. The posting prefers "one messy real project", and a small project of your own could stand in | `[grounded]` your statement; `[grounded]` posting's wording on projects |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | First design hire, no design peer stated | unknown | — | "You would be our first designer" | Design decisions may have no senior reviewer, with a founder as the only sounding board | `[inferred]` from "first designer" and "work most closely with … Ronan Kehoe" | Who gives design feedback today, and what would good look like at month six? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "0.5–1% equity" | The percentage may be subject to vesting, dilution or a strike price that changes its worth | `[generic]` how equity offers commonly work, not a claim about Fernquay | Is it options or shares, what is the vesting schedule, and what is the strike price? | unresolved |
| RR3 | Employer and posting match | positive_signal | — | "booking software for sea-kayak and surf schools" | The employer exists as described and the role is live on its own site | `[grounded]` About and careers pages fetched, both agreeing with the posting | What does the rest of the interview process look like? | noted |
| RR4 | WhatsApp sender unconfirmed | unknown | — | "I have emailed you a calendar invite with the video link" | The message only schedules a video call and asks for no money, bank or ID details. The number is on neither page I read, so who sent it is unconfirmed from here | `[grounded]` pages fetched and your message quoted; `[generic]` that small teams often schedule over messaging apps | Could you send the invite from your Fernquay address? | unresolved |
| RR5 | Stated pay inside the market band | positive_signal | — | "€52,000–€60,000" | The range is neither low nor inflated for 3 to 5 years | `[grounded]` posting; `[generic]` Tillerby band | Is the range flexible within it by experience? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check that the calendar invite's sender is on fernquay.example, the domain both pages use, before joining the link | see RR4 | `[grounded]` fetched pages | pending your approval |
| A2 | On the call, say in your own words which parts of the checkout redesign were yours and which the squad's | see R7, G1 | `[grounded]` your message | pending your approval |
| A3 | Describe your research as monthly usability sessions with customers, and say plainly you have not been the only designer | see R5, R8, R9 | `[grounded]` your own statements | pending your approval |
| A4 | Lead with the checkout redesign: his public profile shows five years as a product lead in travel software, so the booking domain is shared ground | see R7 | `[grounded]` profile snippet | pending your approval |
| A5 | Ask the RR1, RR2 and RR4 questions verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software kayak surf schools Galway" and "Fernquay product designer job Galway". Fetched "About Fernquay" (fernquay.example/about) and "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Role reality's organization and contradictions rows, and RR3 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup first designer equity", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report), snippet only. Market calibration, RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe), snippet only. Role reality's contact row and A4 |

I can offer a fuller picture if you share the dossier: I can write `tuesday-dossier.md` for you to keep, with this assessment and its evidence, if you'd like it.

**Upgrade menu**

- Your pay floor and any other non-negotiables (office days, start date) → R2 closes, and the hard-gates line stops flagging unknown constraints.
- Your Figma file or the checkout case study → R4 and R7 can rise toward `high`.
- Answers to G1 and G2 → the bridges for R7 and R8 strengthen or narrow.
- The invite's sender address as your email shows it → RR4 closes.
- Equity terms in writing → RR2 closes.
- A deeper research pass on Fernquay (leadership, customer reviews, news; up to 5 more searches and 2 more fetches) — say the word and it runs.
- You have a 45-minute call coming; that is mock-interview's job, and I can switch to it if you want practice.

**Questions**

G3 — Is there a minimum base salary, or any other hard limit, such as office days or a start date, that would rule this role out?

G1 — Which stages of the booking journey before checkout, if any, did you personally design or influence, and what did the squad own?

G2 — Have you ever talked to customers or partners before a design existed, to learn how they work, and what did you do with it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.