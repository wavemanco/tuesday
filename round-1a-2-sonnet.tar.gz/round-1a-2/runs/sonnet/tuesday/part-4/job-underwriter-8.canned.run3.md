I'm partway through the playbook. I still need the decision-snapshot rules, and I'll then check whether Velloway exists.
**No, don't go ahead. As you've described it, this isn't a legitimate job. Status: `no_go`.**

I haven't used or repeated your passport, PPS number or IBAN. I don't need them, and the sender shouldn't have them. Please don't paste the IBAN anywhere in that chat.

**Fit ledger.**

- `hard_gate` — unclear: R1 (pay of at least €30,000 a year)
- `must_have` — direct: R2, R3
- `important` — adjacent: R5 (order or logistics experience); unclear: R4 (a quiet place to work)

Your fit is fine. The opportunity is the problem, and the two ledgers stay separate.

**Opportunity ledger.** Three confirmed demands for money or identity data before any contract: RR1, RR2 and RR3. The employer could not be found (RR5), and the hiring process avoids any live contact (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (pay of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`).
- **What would have to be different:** the employer verifiable on its own website, a live call or video interview, a written contract, no payment asked of you, and no identity documents requested before a signed contract.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics", with no website, registration or address given in the posting | `[grounded]` posting |
| Employer check | A search for the name returned nothing, so existence is not established | `[grounded]` search, see Evidence status |
| Pay | "Up to €26 an hour plus commission", 15–30 hours a week. At the top rate that is about €20,300 to €40,600 a year. Reaching €30,000 at €26 needs about 22 hours a week every week, and "up to" means the real rate may be lower. Commission is unquantified. | `[grounded]` posting; `[inferred]` arithmetic |
| Contract basis | Not stated. No employer, contract or payroll terms appear anywhere. | `[grounded]` posting silence |
| Hiring process | Telegram only, "no calls or video interviews" | `[grounded]` posting |
| Market calibration | Not run, because the decision does not depend on it (see Evidence status) | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your stated constraint. Fit is unclear because the pay is "up to" and the hours are a range. It is moot while the employer is unverified. | `[grounded]` your constraint; posting | none, moot |
| R2 | Attention to detail and spreadsheets | must_have | direct | medium | none | You keep a weekly team tracker in Excel and handle about 60 Zendesk tickets a day. It is self-reported, with no artifact inspected. | `[grounded]` your description | none |
| R3 | Good written English | must_have | direct | medium | none | Written ticket handling is your daily work. It is self-reported. | `[grounded]` your description | none |
| R4 | A quiet place to work | important | unclear | low | discovery | You haven't said. It is a trivial requirement. | `[grounded]` your messages are silent | none |
| R5 | Order or logistics processing | important | adjacent | medium | transferability | Parcel-courier customer service is adjacent to order processing. The limit is that you haven't described processing orders yourself. | `[inferred]` from your courier role | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay at or above €30,000 (R1) | hard_gate | Hours and rate are not firm enough to settle it | It matters only if the employer proves real | Not applicable | A written contract stating pay and hours | `[grounded]` posting |
| G2 | Quiet workspace (R4) | discovery | Not stated | Minor | Not applicable | None needed | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Upfront payment demanded | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | A legitimate employer supplies equipment at its own cost. The "refund with first wages" promise is the standard advance-fee hook. | `[grounded]` message; `[generic]` known pattern | Where on the company's own website is this equipment policy? | confirmed |
| RR2 | Cheque, keep a cut, forward the rest | red_flag | high | "Lodge it… keep €350… transfer the rest to our equipment partner" | A cheque can bounce days or weeks after the bank shows the funds. You would then owe the bank the full amount, having already sent your own money onward. | `[grounded]` message; `[generic]` known pattern | Why would an employer send more than the pay owed and ask for the balance back? | confirmed |
| RR3 | IBAN, PPS number and passport photo requested before any contract | red_flag | high | "send your IBAN, your PPS number and a clear photo of your passport" | Those items together are enough for identity theft or account misuse. Payroll normally collects them after a signed contract. | `[grounded]` message; `[generic]` hiring norms | Will the company issue a written contract and collect these on its own HR system? | confirmed |
| RR4 | Telegram-only hiring, no live contact, "passed" after a chat | risk_signal | medium | "no calls or video interviews" | Hiring someone with no live contact lets a sender stay anonymous. It is a pattern, not proof by itself. | `[inferred]` from the posting and messages | Can I have a video call with a named manager? | unresolved |
| RR5 | Employer not established; contact is a generic mail address | risk_signal | medium | "velloway.hr@postmail.example" | The email is not on a company domain, and a search for the name found nothing. This could also be a very small firm, but that does not explain RR1 to RR3. | `[grounded]` search and message | What is the company's registration number and website? | unresolved |
| RR6 | Vague pay, "up to" plus commission | unknown | — | "Earn up to €26 an hour plus commission" | The real rate may be well below the headline. | `[inferred]` from the wording | What is the guaranteed hourly rate? | unresolved |

I'm going only on what you've shared, and I can get this wrong. Before you reply, pay or send anything, please confirm who this is through contact details you find yourself, not through the chat or the email they gave you. If the company can't be independently found, treat the money and ID requests as a hold. The decision is yours.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing: no IBAN, no passport, no PPS number, no €349 | See RR1 and RR3 | `[grounded]` register | pending your approval |
| A2 | Don't lodge the cheque or transfer any of it | See RR2 | `[grounded]` register | pending your approval |
| A3 | Stop replying, then report the account to the jobs site and to Telegram. If you ever sent money or documents, contact your bank straight away and An Garda Síochána. | Reporting protects other applicants, and speed matters if money has moved | `[generic]` standard practice | pending your approval |
| A4 | Look for a real role that fits your Zendesk and Excel experience at €30,000 or more. A resume-tailor pass can sharpen your CV for a specific posting once you have one. | Your background is a genuine asset | `[inferred]` from your description | pending your approval |

## Evidence status

Verified: none yet. Your claims are self-reported. Unverified leads: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics". No results, so employer existence is not established. It fed RR5. |
| 2. Role-family sweep | skipped | The three confirmed demands (RR1 to RR3) already fix the decision as `no_go`, so a pay or scope benchmark could not change it. |
| 3. Hiring manager's footprint | n/a | No name was given. |
| Outside declared targets | yes | Searched "remote order processing coordinator job Telegram cheque overpayment equipment fee scam". No results, and it moved nothing. |

## Closing

I can write all this up as a `tuesday-dossier.md` file if you'd like to keep it.

- A deeper research pass (up to 5 more searches and 2 more fetches) is available, though it probably won't change the answer.
- A link to the original posting and the jobs site's name would let me check that it's still live.
- A registration number or a website for "Velloway Logistics", if you can find one independently, would settle RR5.

Questions:
1. (RR3) Besides the application chat, have you given them anything else, such as a phone number, address or date of birth, or have you sent any money or documents?
2. (RR5) Which jobs site was the posting on, and is it still listed?
3. (R1) Do you want me to look at what kinds of roles fit your background at €30,000 or more? You can answer in text, paste a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.