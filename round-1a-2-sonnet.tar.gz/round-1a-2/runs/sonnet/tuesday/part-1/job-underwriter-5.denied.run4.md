Reading the last section of the worked report, which shows the evidence-status table. Then I'll run one check that the posting and company are live.
## Decision snapshot

**Yes, this looks worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (dbt-modelled warehouse in BigQuery); unclear: R9 (Ingestion from app and CRM), R10 (Data contracts analysts depend on)

R8 (`medium`) — Snowflake-to-BigQuery bridge, limit named; R9 (`low`) — ingestion sources unconfirmed; R10 (`none`) — nothing in your background yet; R1, R2 — waiting on your constraints.

**Opportunity ledger.** The pay range is published and sits inside the market report's band (RR4). The team, reporting line and equity terms are unknown (RR1, RR2), and the employer has not been independently checked (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Your location, US work eligibility and pay floor meet R1 and R2.
  2. The employer and live posting verify (RR3).
  3. The BigQuery gap is framed as adjacent, never as BigQuery experience (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the About text you pasted (not independently checked) |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Seniority | "Senior", 5+ years data engineering | `[grounded]` JD |
| Scope read | Reads as end-to-end ownership of one reporting domain, with no direct reports mentioned. Team size is not stated | `[inferred]` from the JD's mandate against its silence on team |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Market calibration | Report median base is $151,000 and the interquartile range is $139,000–$163,500. The posted $148,000–$166,000 starts $3,000 under the median and ends $2,500 above the range's upper edge. The report's usual scope for the title is one domain's pipelines with no reports, which matches the scope read. This is the market band, never this employer's offer | `[generic]` Datawright 2026 report (Series B–D, US, n=2,310, from your recruiter, not independently checked); `[grounded]` JD figure |
| Unknowns | Hiring manager (the posting names none); team size; equity type and amount; whether BigQuery experience is expected on day one | — |
| Contradictions | None between the JD and the About text as pasted | `[grounded]` both documents |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You have not stated your location or US work eligibility, so the term is not settled either way | `[grounded]` JD; no candidate statement yet | Question in closing block, tagged R1/R2 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor given. Equity terms are not stated in the posting | `[grounded]` JD; no candidate statement yet | Question in closing block, tagged R1/R2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. That is intake prose with no inspectable artifact, so `medium` and expect a probe | `[grounded]` your message | Offer a CV or LinkedIn to raise the band |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use stated; no artifact inspected | `[grounded]` your message | Offer a code sample or repo link |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | A dbt project of about 180 models on Snowflake meets both halves. Limit: the model count is your figure, not inspected | `[grounded]` your message | Offer a sanitized lineage graph or docs export |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow stated. Scope of your own part (authored vs maintained) is not stated | `[grounded]` your message | Offer a sanitized DAG screenshot |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, which is a stated ownership claim. No artifact inspected | `[grounded]` your message | Offer a suite config or test-coverage summary |
| R8 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Carries over: the dbt modelling work on Snowflake. Limit: you have never used BigQuery, so nothing here shows its own cost or table-design habits, which differ from other warehouses | `[grounded]` your message; `[generic]` that warehouses differ in cost and table design | See G1 |
| R9 | Ingestion from the app and the CRM | important | unclear | low | discovery | You describe orchestrated pipelines, but not which sources fed them or whether any were app-event or CRM data | `[grounded]` your message is silent on sources | See G2 |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Nothing in your background mentions contracts, schema agreements or analyst-facing guarantees. Your Great Expectations work may be adjacent, but that is not yet a claim | `[grounded]` silence in your message | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Carries over: dbt modelling on Snowflake. Limit: no BigQuery use. Strengthener: a small hands-on piece | The posting names BigQuery in its mandate, so it is the likeliest probe | A personal or sandbox dbt project on BigQuery; a migration or evaluation you contributed to | A small public repo or a short write-up | `[inferred]` bridge from your Snowflake work; `[generic]` that the named warehouse is the usual probe |
| G2 | App and CRM ingestion (R9, important) | discovery | Pipelines in Airflow are stated; the sources are not | The mandate opens with ingestion, so this row could move fit to `direct` | Event or product-usage data landed from an application; syncing a CRM or billing system; API or file-based extracts; handling late or changed records | A sanitized DAG, a source-to-model diagram | `[grounded]` source silence; `[inferred]` that it moves the row |
| G3 | Data contracts (R10, important) | discovery | No mention of contracts or analyst-facing guarantees | The posting names contracts as a core deliverable | Agreeing schemas or freshness expectations with analysts; versioned models or documented column meanings; tests that gate a downstream dashboard | A contract doc, schema-change process, or model docs page | `[grounded]` silence; `[generic]` that tests can stand in for a contract |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team, reporting line and ownership unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You may be the sole owner of the whole reporting stack, or one of a team. The posting names no hiring manager | `[inferred]` from the mandate's breadth against the posting's silence | Who would I report to, and who else works on the pipelines and warehouse today? | unresolved |
| RR2 | Equity unspecified | unknown | — | "plus equity" | Type, amount and vesting may be undefined or negotiated late | `[inferred]` from the posting giving no terms | What is the equity grant for this level, and what are its type and vesting terms? | unresolved |
| RR3 | Employer not established from attributable sources | risk_signal | medium | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. My one check was refused, so nothing came back either way | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR4 | Pay range published and within market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range sits at and just above the report's median and upper quartile, with no sign of a seniority-pay gap | `[grounded]` JD figure; `[generic]` Datawright band | How are offers placed within this range? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check your location, US work eligibility and pay floor against R1 and R2 before spending application time | Both gates are unconfirmed | `[grounded]` R1, R2 rows | pending your approval |
| A2 | Lead with the dbt project, the Airflow orchestration and the Great Expectations suite, stated as you described them | R5, R6, R7 are your strongest rows, at `medium`: expect a probe on what was personally yours | `[grounded]` R5, R6, R7 rows | pending your approval |
| A3 | Present BigQuery as adjacent: dbt on Snowflake, no BigQuery use claimed | See R8; the limit stays visible | `[grounded]` R8 row | pending your approval |
| W1 | Optional work sample: a small dbt project on a BigQuery sandbox | Narrows the R8 limit | `[inferred]` strengthener for G1 | pending your approval |
| Q1 | Ask the verification questions of RR1, RR2, RR3 and RR4 verbatim in the process | The register doubles as interview preparation | `[grounded]` register | pending your approval |

If you decide to apply, resume-tailor can tailor your resume to this posting.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Pellucid Learning Denver online tutoring K-12 Series C Senior Data Engineer" was refused, so no attributable result came back. It would have confirmed the employer and the live posting. It moved RR3, which stays unresolved and caps the decision at `conditional_go` |
| 2. Role-family sweep | skipped | The pasted Datawright report fixes the market calibration line and the pay comparison, so a search would change neither |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

I'll offer the dossier file if you want it, as one `tuesday-dossier.md` to carry this assessment forward.

## Upgrade menu

- Your CV, or sanitized artifacts such as a dbt lineage graph, a DAG screenshot, or the Great Expectations suite config. These can raise R3, R4, R5, R6 and R7 from `medium` toward `high`.
- Your location, work eligibility and pay floor. This settles R1 and R2, and the decision becomes `go` or `no_go` on those terms.
- The live careers-page link, or permission to search. This could clear RR3.
- The hiring manager's name once known. This would add a scope read and shape which story you lead with.
- An answer on G1, G2 or G3. This could move R8, R9 or R10.

## Questions

1. R1/R2 — Are you in the US with the right to work there, can you do remote or Denver, and what is your minimum base salary? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. G2 — Did any of your pipelines pull data from a product or application, or from a CRM or billing system? What did you personally build and own, and what happened when the source changed? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. G3 — Did you ever agree schemas, freshness or column meanings with the analysts who used your models, and how was that written down or enforced? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.