Reading the playbook is done, so next I'm running the three research searches: Quillfield itself, the pay band for this role, and Tamsin Achebe's public profile.
# Job Underwriting Assessment: Revenue Operations Lead at Quillfield

## Decision snapshot

**Yes, it's worth applying, on conditions. Status: `conditional_go`.** R6 (owning a forecast) is a stretch you can bridge, and R7a (billing data) is a real gap, but neither is disqualifying. The two hard gates, R1 and R2, are unchecked because I don't have your constraints.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, two office days), R2 (Salary £61,500–£67,000)
- `must_have`: direct: R3, R4 · adjacent: R5 (SQL and spreadsheet modelling), R6 (Owning a forecast) · unclear: R7b (Working with finance on revenue data) · absent: R7a (Billing data)
- `important`: direct: R8

R6 is a credible bridge via your monthly pipeline review, its limit named; R7a is no billing-data work, a closure path and not a bridge; R3 (`medium`) has matching years, but whether a payments company counts as "B2B software" is unconfirmed.

**Opportunity ledger.** Pay is a positive (RR2). Open items are whether the posting is live on Quillfield's own site (RR1), who owns the forecast (RR3), the share-option terms (RR4) and the success measures (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, two office days), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol with two office days and the £61,500–£67,000 band both work for you (R1, R2); (2) you frame forecast experience as adjacent, never as ownership, and the interview shows what the role owns versus Tamsin and the CFO (R6, RR3); (3) you accept billing data as a ramp-up risk and your answer on finance work holds up (R7a, R7b).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` "About Quillfield" page |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol, hybrid, two office days; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments for four years | `[grounded]` recruiter via you; `[grounded]` her public profile |
| Scope read | The title "Lead" sits beside a "Head of Revenue Operations", so the role probably reports into her. Whether the forecast is this role's number or hers is not stated | `[inferred]` from the titles against the posting's silence on reporting line |
| First-year outcomes | None stated | `[grounded]` posting |
| Market calibration | Posted midpoint is £64,250. Pay guide for UK B2B software revenue operations leads: median £64,200, interquartile range £57,800–£70,400, n=438. The band is UK-wide, not Bristol-specific, and is a pattern, never Quillfield's offer | `[generic]` Ledgerline 2026 pay guide; `[grounded]` posting figures |
| Unknowns | Team size, who owns the forecast, billing system, option terms, success measures | — |
| Contradictions | None found. The posting appears only on Tallyboard in my searches; none of my three searches returned a Quillfield careers page | `[grounded]` search results |

## Evidence map

Your background was typed in, so it counts as self-report with the same standing as a CV, which caps it at `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | You haven't stated a location or schedule limit, so the gate is not settled either way | `[grounded]` posting; no candidate statement | Question G1 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No pay floor stated, so the gate is not settled | `[grounded]` posting; no candidate statement | Question G1 |
| R3 | 4+ years in revenue operations, sales operations or similar analytics at a B2B software company | must_have | direct | medium | none | Five years in sales operations, the last two running revenue operations for the UK team, covers the years. Limit: the employer is a B2B payments company, and whether that counts as software is not established | `[grounded]` your account | Share a CV with titles and dates |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified and you rebuilt the dashboards. The certificate itself has not been inspected | `[grounded]` your account | Link the certification record to raise to `high` |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | SQL weekly and Excel daily show use, not modelling. Limit: you haven't described building a model | `[grounded]` your account | Gap G5 |
| R6 | Experience owning a forecast (quarterly, with the CFO) | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, and finance owned the company forecast. Limit: you have not owned a forecast or presented one to a finance lead | `[grounded]` your account | Question G2 |
| R7a | Billing data experience ("own our CRM and billing data") | must_have | absent | none | capability | You say you have never worked on billing data | `[grounded]` your statement | Closure path in G3 |
| R7b | Working with finance on revenue data | must_have | unclear | low | discovery | Renewal dashboards imply revenue data, and finance owned the forecast, but how you worked with them is not stated | `[inferred]` from the renewal dashboards | Question G4 |
| R8 | Build pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt the pipeline and renewal dashboards. Whether finance used them is not stated | `[grounded]` your account | Screenshot or description of a dashboard would raise to `high` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Whether the location and pay terms work for you (R1, R2; hard_gate) | hard_gate | No location, schedule or pay floor from you | A gate you fail makes the status `no_go` whatever else fits | Not applicable; the gate is met or it is not | Your stated limits | `[grounded]` no constraints given |
| G2 | Forecast ownership (R6; must_have) | transferability | Monthly pipeline review with your sales director; finance owned the company forecast | The posting names forecasting with the CFO as a core duty, so this is the gap most likely to be probed | Rolling up pipeline into a commit or best-case number; comparing forecast with actuals; supplying a number finance used | A review deck, a forecast-versus-actual sheet, a roll-up template | `[grounded]` your account; `[generic]` that forecasting is probed hardest for this title |
| G3 | Billing data (R7a; must_have) | capability | No billing-data work | A must-have with nothing direct or adjacent to build on | Nothing in your account counts yet. Closure path: study how invoices, credit notes and recurring billing records map to CRM accounts, and rehearse a reconciliation exercise, as ramp-up preparation and never as a claim | None yet | `[grounded]` your statement; `[generic]` that billing-to-CRM reconciliation is the usual skill here |
| G4 | Working with finance on revenue data (R7b; must_have) | discovery | Renewal dashboards, finance owning the forecast, nothing on how you worked together | Could turn a must-have from `unclear` to `adjacent` | Reconciling renewal figures with finance; agreeing how a renewal counts; a recurring finance sync you joined | A renewal-definition note, a dashboard with finance sign-off | `[inferred]` from the renewal dashboards |
| G5 | SQL and spreadsheet modelling depth (R5; must_have) | discovery | Frequency stated, no model described | Lower impact than the gaps above | A pipeline or renewal model with assumptions; a SQL view feeding a dashboard | A model screenshot, a sanitized query | `[grounded]` your account |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not seen on Quillfield's own site | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | The role may be live and just not indexed, or the board copy may be stale | `[generic]` pattern for job-board postings | Is this role currently open, and where is it listed on your careers page? | unresolved |
| RR2 | Pay inside the market band | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The posted midpoint is close to the band's median, so the offer looks market-rate | `[grounded]` posting figures; `[generic]` Ledgerline band | Does the band flex with experience, given forecast ownership would be new to me? | noted |
| RR3 | Forecast ownership and reporting line unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may carry the forecast while a Head of Revenue Operations owns the number | `[inferred]` from the posting's silence on reporting line | Who owns the forecast number today, and what does this role own versus Tamsin and the CFO? | unresolved |
| RR4 | Share-option terms unstated | unknown | — | "plus share options" | Value depends on grant size, vesting and strike price, none given | `[generic]` pattern for Series A options | What are the grant size, vesting schedule and strike price? | unresolved |
| RR5 | No success measures for a demanding mandate | unknown | — | CRM, billing data, reporting and forecast in one role, with no outcomes stated | Four duties may be bundled with no definition of success | `[inferred]` from the posting's duty list against its silence on outcomes | What would a successful first six months look like, and what would I own by then? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the rebuilt pipeline and renewal dashboards and the monthly pipeline review you run with your sales director, in your own words | See R8, R6 | `[grounded]` your account | pending your approval |
| A2 | Say plainly that finance owned the company forecast and that you have not worked on billing data, then say how you would close it | See R6, R7a; avoids a claim an interviewer can test | `[grounded]` your statements | pending your approval |
| A3 | With Tamsin, common ground is a payments-company sales operations background, hers at Corvane Payments and yours at a B2B payments company. Don't assume it resonates | See hiring manager row in role reality | `[grounded]` her public profile; `[inferred]` that it helps | pending your approval |
| A4 | Ask RR1 to RR5's questions verbatim, starting with RR3 | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Confirm Bristol, two office days and the pay band with the recruiter before investing in the loop | See R1, R2 | `[grounded]` posting | pending your approval |

## Evidence status

Verified: none yet. Stage assumed: evaluating.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol careers", which returned "About Quillfield" (quillfield.co.uk/about). It confirmed the employer exists as described and fed role reality's organization row. No careers page came back, so RR1 stays open |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol B2B software UK", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). It fed the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). It fed the scope read and A3 |

## Dossier offer

I can save all of this as a `tuesday-dossier.md` so you can pick it up later, if you want it.

## Upgrade menu

- Your CV with titles and dates: confirms R3, including whether your employer counts as B2B software.
- A link to your Salesforce certification: R4 to `high`.
- A dashboard screenshot or description with finance as a user: R8 to `high` and a better read on R7b.
- A forecast, review deck or roll-up template: R6 gets stronger evidence.
- Your location, office-day limits and pay floor: R1 and R2 resolve, which settles the hard gates.
- A deeper research pass on Quillfield (funding history, leadership changes, staff reports; up to 5 more searches and 2 more fetches): say the word and it runs.

## Questions

G1 — Can you work from Bristol two days a week, and what is your minimum acceptable pay?

G2 — Have you ever turned pipeline into a number that someone else used as a forecast, such as a commit roll-up or a forecast-versus-actual review? What did you own?

G4 — When you built the renewal dashboards, did you reconcile any figures with finance, and what did they own versus you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.