# Job Underwriting — Revenue Operations Lead at Quillfield

## Decision snapshot

**Should you go for it? Yes, apply, with R1 and R2 confirmed first and the R6 and R7b gaps stated openly. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, two office days), R2 (£61,500–£67,000 pay)
- `must_have`: direct: R3, R4 · adjacent: R5 (strong SQL, spreadsheet modelling), R6 (owning a forecast) · unclear: R7a (working with finance on revenue data) · absent: R7b (owning billing data)
- `important`: direct: R8

R6 is a credible bridge, its limit named; R7b is a real gap, its closure path named; R5 (`low`) is stated frequency with depth unconfirmed.

**Opportunity ledger.** The role looks sound but under-specified. Pay is stated (RR1). The reporting line and forecast ownership are not stated (RR2). I have not seen the posting on Quillfield's own site (RR3). No first-year outcomes are given (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, two office days), R2 (£61,500–£67,000 pay); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol with two office days (R1) and the salary band (R2) both work for you. If either does not, this becomes `no_go`. (2) The forecast scope is pinned down in conversation (R6, RR2). (3) The billing-data gap (R7b) is carried as a stated gap with a closure path, never glossed.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` "About Quillfield", quillfield.co.uk/about (search result) |
| Mandate | Own CRM and billing data; build the pipeline and renewal reporting sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. The recruiter named her as hiring manager | `[grounded]` your recruiter's statement; profile "Tamsin Achebe — Head of Revenue Operations, Quillfield" (search result) |
| Scope read | A hands-on mix of data ownership, reporting and forecasting. The posting names no team and no first-year outcomes, even though the title says "Lead" | `[inferred]` from the posting's wording and its silence on reports and outcomes |
| Market calibration | The posted range sits inside the middle band of one UK survey for this title (median base £64,200, interquartile range £57,800–£70,400, n=438). The survey is UK-wide, not Bristol-specific, and is a pattern, not this employer's offer | `[generic]` Ledgerline 2026 pay guide; `[grounded]` posting's figure |
| Stage | Evaluating | `[inferred]` from your asking whether to go for it |
| Unknowns | Reporting line and team; who owns the forecast today (Tamsin or the CFO); first-year outcomes; share-option terms; whether the posting is on Quillfield's own site | — |
| Contradictions | None between the posting and Quillfield's About page on location and product | `[grounded]` posting against About page |

## Evidence map

Your background comes from your message, which counts as CV-equivalent self-report. That caps most bands at `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days | hard_gate | unclear | none | hard_gate | You have not stated a location constraint, so nothing grades the gate. Your "UK team" does not say where you are based | `[grounded]` posting; your message silent | Ask whether it works (closing question) |
| R2 | Pay £61,500–£67,000 plus options | hard_gate | unclear | none | hard_gate | No pay floor stated, so the posted band cannot be checked against one | `[grounded]` posting; your message silent | Ask whether it works (closing question) |
| R3 | 4+ years in revenue ops, sales ops or similar analytics at a B2B software company | must_have | direct | medium | none | 5 years in sales operations, the last 2 running revenue operations for the UK team, is specific and plausible but uninspected. The employer is a B2B payments company, not labelled "software", so describe it plainly and let them judge. This is a years requirement, not a gate | `[grounded]` your background | none |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified is specific, but no certification record has been inspected | `[grounded]` your background | A certification record would raise to `high` |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | low | discovery | "SQL weekly, Excel daily" states frequency, not strength or modelling work. Taking the lower band | `[grounded]` your frequencies; the depth is not stated | Offer: a sanitized query or workbook would show depth |
| R6 | Experience owning a forecast; running the quarterly forecast with the CFO | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director and have never owned the company forecast, which finance did. Limit: the review exercises pipeline inspection, not committing to a revenue number. `[generic]` a pipeline review inspects open deals, while owning a forecast means committing to a number | `[grounded]` your statements; `[generic]` on the difference | See G1 |
| R7a | Working with finance on billing or revenue data | must_have | unclear | low | discovery | Your renewal dashboards touch revenue, but working with finance on revenue data is not stated | `[grounded]` your renewal dashboards; finance collaboration not stated | See G3 |
| R7b | Owning billing data ("own our CRM and billing data") | must_have | absent | none | capability | You have never worked on billing data. The CRM half of the sentence is carried by R4 | `[grounded]` your statement | See G2 |
| R8 | Build pipeline and renewal reporting that sales and finance run on | important | direct | medium | none | "Rebuilt our pipeline and renewal dashboards" matches. Whether finance used them is not stated, and that goes to G3 | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6, must_have) | transferability | Monthly pipeline review with your sales director; the company forecast sat with finance | The posting has you run the quarterly forecast with the CFO, so this decides how stretched the move is | Supplying pipeline or commit numbers that fed finance's forecast; keeping close-date and stage hygiene that the forecast relied on; explaining pipeline movement against plan in the monthly review | A sanitized pipeline-review deck, a dashboard screenshot, a review agenda | `[grounded]` your statements; `[inferred]` that these examples fit your history |
| G2 | Billing data (R7b, must_have) | capability | No billing-data work, confirmed by you | The posting leads with owning billing data, so it carries as a material risk. A realistic closure path: a small worked example reconciling closed-won CRM deals to invoice records in SQL, on synthetic data, so the claim is shown and not asserted | None identified; adjacent exposure from payments-company work is not claimed | The worked example itself (pending your approval, see W1) | `[grounded]` your statement; `[inferred]` that the example closes part of the gap |
| G3 | Working with finance on revenue data (R7a, must_have) | discovery | Renewal dashboards exist; finance's role in them is unstated | A resolved R7a would move this row from `unclear` toward `adjacent` or `direct` | Reconciling renewal figures with finance; agreeing a bookings or renewal-rate definition with them; finance relying on your renewal dashboard | A metric-definition note, a sanitized email thread, a dashboard screenshot | `[grounded]` the renewal dashboards; finance's involvement not stated |
| G4 | SQL and spreadsheet depth (R5, must_have) | discovery | Frequency only | Lower priority than G1 to G3, so no question this turn | Queries behind your dashboards; a model finance or sales used | A sanitized query or workbook | `[grounded]` your frequencies |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated, with share options | positive_signal | — | "Salary £61,500–£67,000 plus share options" | Pay is transparent and sits within the surveyed middle band. The option terms are unknown | `[grounded]` posting; `[generic]` survey band | How are the options structured: vesting, strike price, and size of the grant? | noted |
| RR2 | Reporting line and forecast ownership unstated | unknown | — | "run the quarterly revenue forecast with the CFO" | A Head of Revenue Operations already exists, so the split between her and this role on the forecast, and whether "Lead" carries reports, is open | `[inferred]` from the posting's silence against the hiring manager's title; `[grounded]` her title | Who owns the forecast today, and what would pass to this role? Does it have direct reports? | unresolved |
| RR3 | Posting not seen on the employer's own site | unknown | — | "Revenue Operations Lead, Quillfield" (job-board listing) | The role is probably live, but I only saw it on Tallyboard. The one Quillfield careers address I tried returned no page, and that was a guessed address | `[grounded]` fetch returned no page; `[inferred]` that this is weak evidence | Can you point me to this role on your own careers page? | unresolved |
| RR4 | No first-year outcomes stated for a demanding mandate | unknown | — | "own our CRM and billing data, build the pipeline and renewal reporting… run the quarterly revenue forecast" | Success is undefined, so you cannot tell what you would be judged on | `[inferred]` from the posting's silence on outcomes | What should this role have delivered by the end of its first two quarters? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with your rebuild of the pipeline and renewal dashboards and the monthly pipeline review you run with your sales director | These are your closest verified evidence (R6, R8). The hiring manager's listed background is sales operations at a payments company, the same field as yours | `[grounded]` your statements; her profile | pending your approval |
| A2 | State the gaps plainly. Draft line: "I run our monthly pipeline review with the sales director; the company forecast sat with finance and I haven't worked on billing data." | Honest, and it traces to your own sentences (R6, R7b) | `[grounded]` your statements | pending your approval |
| W1 | A small worked example on synthetic data that reconciles CRM closed-won deals to invoice records in SQL | The one concrete closure path for G2 | `[inferred]` from G2 | pending your approval |
| Q1 | Ask RR1, RR2 and RR4's questions verbatim in the process | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Ask the recruiter for the role on Quillfield's own careers page, and check the recruiter's email domain against quillfield.co.uk | See RR3 | `[grounded]` RR3 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers", which returned "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers, which returned no page. Moved: role reality's organization row (the company exists as described) and RR3 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved: market calibration and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved: the hiring-manager row, RR2 and A1 |

If you'd like, I can save all of this as `tuesday-dossier.md` so it carries forward.

## Upgrade menu

- Your location and pay floor → R1 and R2 resolve, and the hard-gates line closes.
- An answer to G1 or a sanitized pipeline-review deck → R6's bridge strengthens or resolves.
- An answer to G3 → R7a moves off `unclear`.
- A record of your Salesforce certification → R4 to `high`.
- A sanitized query or workbook → R5 can rise from `low`.
- Your CV → I can check presentation gaps and move rows past the intake ceiling.
- The recruiter's answer on the posting and email domain → RR3 closes.
- Tamsin's answers on reporting line, forecast ownership and first-year outcomes → RR2 and RR4 close.
- Share-option terms → RR1 closes.
- A deeper research pass on Quillfield (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

R1 and R2 — Are Bristol with two office days a week and a £61,500–£67,000 salary workable for you?

G1 — Have you ever supplied pipeline numbers or commit calls that fed finance's forecast, or explained pipeline movement against plan? What exactly did you own?

G3 — Have you worked with finance on revenue or renewal numbers, for example agreeing a definition or reconciling figures? What was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.