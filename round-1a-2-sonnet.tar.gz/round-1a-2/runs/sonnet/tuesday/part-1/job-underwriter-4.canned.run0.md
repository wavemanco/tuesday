Searches are back, and the company's careers page says something different from your JD on location. I'm fetching that page to confirm before I write the assessment.
# Job Underwriting — Senior Pricing Analyst, Brindlemoor

## Decision snapshot

**Yes on fit, but not until you know where the job is based: R1 (the working pattern) is unconfirmed. Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5a, R6, R7 · unclear: R5b (Monitor rating models)
- `important` — adjacent: R9 (Pet-insurance product knowledge)
- `preferred` — direct: R8

R1 — the JD and the careers page disagree; R5b (`low`) — one word, "maintained", to firm up; R9 — a credible bridge from motor, its limit named.

**Opportunity ledger.** The role itself looks coherent: single product, reporting to the Director of Pricing, and a manager whose public work is on rating-model monitoring (RR3). Two things are open: the working pattern conflicts between sources (RR1) and the salary is not stated (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would change this:** the awaited answers are your own on R1 (can you work four days a week in Leeds, or is fully remote essential?) and Brindlemoor's confirmation of which pattern is real (RR1). If R1 is met, I'd move this to `go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; the role is listed as accepting applications | `[grounded]` JD header; careers page fetched |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | Director of Pricing (Odile Varga) | `[grounded]` JD; careers page |
| Working pattern | JD says fully remote (UK); the careers page says Leeds office four days a week. This is a contradiction between sources, not resolved here | `[grounded]` both sources, quoted |
| People management | The JD lists no management requirement, so having never managed anyone is not a stated gap | `[grounded]` JD silent; your statement that you haven't managed anyone |
| Salary | Not stated in the JD or on the careers page | `[grounded]` JD and careers page fetched |
| Market calibration | A 2026 UK survey of senior pricing analysts at insurers and insurtechs (n=612) gives a median base of £58,400 and an interquartile range of £52,100 to £64,900. This is a band to expect, not Brindlemoor's offer. I saw the figures in a search snippet and did not fetch the survey page | `[generic]` role-family sweep; `[grounded]` search result |
| Scope read | One product, with pricing analytics owned directly under a director, reads as a normally scoped senior post | `[inferred]` from the JD's mandate and reporting line |
| Hiring manager | Odile Varga spoke at the 2025 Insurance Pricing Forum on monitoring rating models in small books, and was previously head of pricing analytics at Calloway Re for six years. Her talk topic matches the "monitor" half of the mandate, so expect that to be probed. I saw this in a search snippet only | `[grounded]` search result; `[inferred]` that monitoring will be probed |
| Unknowns | Salary; which working pattern is real; team size; the pet data and systems you would inherit | — |
| Contradictions | JD against careers page on working pattern (R1, RR1) | `[grounded]` both sources |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) working pattern | hard_gate | unclear | none | hard_gate | The JD says fully remote and the careers page says Leeds four days a week. You haven't said whether Leeds works for you, so there is no constraint of yours to grade. Fit stays `unclear` until both sides are known | `[grounded]` JD and careers page | Ask you the R1 question; ask Brindlemoor (RR1) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Confirmed in prose, no inspectable artifact yet, so `medium`: expect a probe | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. No artifact seen | `[grounded]` your background | A sanitized query or notebook would raise to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for your young-driver book. No artifact seen | `[grounded]` your background | A sanitized model spec or documentation page would raise to `high` |
| R5a | Build rating models | must_have | direct | medium | none | Same evidence as R4: you built the young-driver GLM | `[grounded]` your background | as R4 |
| R5b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" may or may not include performance monitoring such as actual-versus-expected tracking, drift checks or refit triggers. I resolve it downward until you say. It matters more here because the hiring manager's public talk is on exactly this | `[grounded]` your sentence; `[inferred]` that monitoring will be probed | Question G1 |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. The 14 counts tests, not products or segments | `[grounded]` your background | A sanitized test readout would raise to `high` |
| R7 | Present results to underwriting or actuarial leads, with recommendations | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. That is underwriting, not actuarial; the JD accepts either | `[grounded]` your background; JD wording | A sanitized review deck would raise to `high` |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer. Not pet, but the JD asks for insurance experience, not pet | `[grounded]` your background; JD wording | none |
| R9 | Pet-insurance product knowledge (inferred from "our pet-insurance product"; the JD does not list it) | important | adjacent | medium | transferability | Your GLM rating, price testing and underwriting work all carry over. The limit is that none of it touched a pet product. Pet risk factors differ from motor driver factors, so expect questions on that | `[grounded]` your motor work; `[generic]` that pet rating factors differ from motor | See G2; do not claim pet experience |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R5b, must_have) | discovery | You maintained the young-driver GLM; the posted evidence doesn't say how performance was tracked | The role's mandate is "build and monitor", so this is the one must-have row still below `direct` | Actual-versus-expected tracking by segment; drift or stability checks; a loss-ratio dashboard; a trigger for refitting; a model-performance report to underwriting | A sanitized monitoring pack, a dashboard screenshot, or a refit memo | `[grounded]` the CV-style description says "maintained" only; `[generic]` that monitoring is a standard part of the work |
| G2 | Pet-insurance knowledge (R9, important) | transferability | Strong motor pricing evidence; no pet product exposure | The likeliest objection. The bridge is a credible one, but its limit has to be said plainly | Any work on multi-factor risk rating for an unfamiliar product; reading a pet claims dataset or public pet-insurance material before the interview | A short written note on how you'd adapt your motor approach to a new product | `[inferred]` bridge from your stated motor work; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern differs between sources | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The JD you hold may be older than the live posting, or the role may be hybrid with the JD wording loose | `[inferred]` from two sources disagreeing | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Salary not stated | unknown | — | No figure in the JD or on the careers page | Brindlemoor may not publish pay, or the figure may sit away from the survey band in role reality | `[inferred]` from the withheld figure against the `[generic]` band | What salary range is budgeted for this post? | unresolved |
| RR3 | Hiring manager's background matches the mandate | positive_signal | — | Careers page: "reports to the Director of Pricing"; her public talk: "Small Books, Loud Errors" | A manager from a pricing-analytics background is likely to read the work technically | `[inferred]` from her stated career and talk topic | Which rating models and price tests would I inherit, and how is their performance monitored today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern with the recruiter or Odile Varga's team before investing in the application | see R1, RR1 | `[grounded]` R1 and RR1 rows | pending your approval |
| E1 | Put the GLM young-driver model and the 14 price tests at the top of the CV, in your own existing wording. No bullet is drafted until G1 is answered | see R4, R6 | `[grounded]` your background | resume_edits_pending_approval |
| P1 | If asked about pet insurance, say it plainly: "I haven't priced pet insurance; my pricing work has been in motor, where I built and maintained the GLM rating model for the young-driver book and ran 14 price tests with underwriting last year." Every clause comes from your own sentences | see R9 | `[grounded]` your background | pending your approval |
| Q1 | Ask RR1, RR2 and RR3's questions verbatim during the process | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). The role is live and attributable to Brindlemoor, so the employer is established for this posting. It moved role reality's working-pattern and contradictions rows and produced RR1. The page is thin: company stage and size were not established |
| 2. Role-family sweep | yes | Searched "Senior pricing analyst insurance UK salary remote pet insurance", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), read as a snippet only. It moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), read as a snippet only. It moved role reality's hiring-manager row, RR3 and R5b's reasoning |

## Dossier offer

If you want a saved record of this assessment to carry into later steps, I can write it up as `tuesday-dossier.md`; no pressure either way.

## Upgrade menu

- Your answer on Leeds versus remote → R1 resolves and the decision moves off `hold_pending_answers`.
- An answer to G1 → R5b moves toward `direct`, and E1 can be drafted.
- A sanitized model spec, monitoring pack, price-test readout or review deck → R3, R4, R5a, R6 or R7 toward `high`.
- Brindlemoor's answer on salary → RR2 closes against the survey band.
- A deeper research pass on Brindlemoor (funding, leadership changes, staff reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

R1 — Can you work four days a week in the Leeds office, or is fully remote essential for you? A flat "I can't do Leeds" is a complete answer.
G1 — After your young-driver GLM went live, how did you track whether it was performing (for example actual-versus-expected by segment, drift, a trigger to refit)? What did you own, and what did it change?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.