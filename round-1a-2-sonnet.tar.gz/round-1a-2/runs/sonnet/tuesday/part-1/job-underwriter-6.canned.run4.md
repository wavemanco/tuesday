**Yes, go for it, as a stretch rather than a clean fit. Status: `conditional_go`.** The real gaps are R6 (`adjacent`, owning a forecast) and R8b (`absent`, owning billing data). Whether the role is open and what the location and pay terms are for you still need confirming (R1, R2).

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000)
- `must_have` — direct: R3, R4, R5a · adjacent: R6 (Experience owning a forecast) · unclear: R5b (Spreadsheet modelling), R7 (Working with finance on billing or revenue data)
- `important` — direct: R8a, R9 · absent: R8b (Owning billing data)

R6 — a bridge from your pipeline review, with the limit that finance owned the forecast; R8b — a confirmed gap with a closure path named; R7 and R5b — recoverable with an answer from you.

**Opportunity ledger.** Pay sits inside the market band (RR3). The open items are whether the role is listed on Quillfield's own site (RR1), whether a team and authority come with the Lead title (RR2), the share option terms (RR4) and what success looks like (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol with two office days and the pay range work for you — R1, R2; (2) the interviews show forecasting and billing data are learnable in the role, with you saying plainly you haven't done either — R6, R8b, RR2, RR5; (3) the role is confirmed open — RR1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. It was founded in 2018 in Bristol, has 96 employees, and closed a £11M Series A in April 2025 | `[grounded]` "About Quillfield" (quillfield.co.uk/about) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting that sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| First-year outcomes | None stated. The first quarterly forecast cycle with the CFO and taking over billing data are the likely early tests | `[grounded]` posting silence; `[inferred]` from its stated duties |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield. Previously sales operations manager at Corvane Payments for four years. This matches what your recruiter told you; I saw a search snippet only, not the full profile | `[grounded]` search result (linkedin.example/in/tamsin-achebe) |
| Market calibration | Ledgerline's 2026 UK pay guide for revenue operations leads in B2B software (n=438) gives a median base of £64,200 and an interquartile range of £57,800–£70,400. The posted range falls inside that range. It is a UK-wide pattern, not a Bristol figure, and the posted range is the employer's actual one | `[generic]` Ledgerline guide, from a search snippet; `[grounded]` posting for the range |
| Unknowns | Whether the role is open on Quillfield's own site; team size; option terms; success measures; which billing system is in use | `[grounded]` posting silence |
| Contradictions | None found between the posting and Quillfield's About page. Its careers page returned nothing, so I can't tell whether the role is listed there | `[grounded]` fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid: two days a week in the office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or what office days you'll accept, so the gate isn't established. There is no stated constraint to grade | `[grounded]` posting terms; your constraints not given | Question tagged R1, R2 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | Your pay floor isn't stated, so I can't say whether the range clears it | `[grounded]` posting; floor not given | Question tagged R1, R2 |
| R3 | 4+ years in revenue operations, sales operations or a similar analytics role at a B2B software company | must_have | direct | medium | none | You stated 5 years in sales operations, the last 2 running revenue operations for the UK team, at a B2B payments company. The years and function match. "B2B software" versus "B2B payments" is a wording gap I can't settle from your prose. Confirmed by you, nothing inspected | `[grounded]` your background statement | State in a phrase what your employer's product was |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | You are Salesforce admin certified and rebuilt the pipeline and renewal dashboards. The certification is inspectable but I haven't seen it, so `medium` | `[grounded]` your statement | Share the credential record to raise this to high |
| R5a | Strong SQL | must_have | direct | medium | none | You use SQL weekly. Frequency is stated and depth isn't, so I take the lower band. Expect a probe on depth in an interview | `[grounded]` your statement; `[generic]` that depth gets probed | Offer a sanitized query or a description of a hard one |
| R5b | Spreadsheet modelling | must_have | unclear | low | discovery | You use Excel daily. That doesn't say whether you built models (coverage, quota, renewal forecast) or worked in reports | `[grounded]` your statement | See G5 |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director and rebuilt the pipeline dashboards. You have not owned the company forecast; finance did. Pipeline work is adjacent to forecasting but doesn't show you owned a forecast number. The bridge and its limit both stay in any wording | `[grounded]` your statement, limit included | See G2 |
| R7 | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | The posting says "billing or revenue", so revenue-data work with finance could count even without billing. You've said you haven't worked on billing data. Whether your renewal dashboards involved finance isn't stated | `[grounded]` posting wording and your statement | See G3 |
| R8a | Own CRM data | important | direct | medium | none | Salesforce admin certification and the dashboard rebuilds support this. Confirmed by you, nothing inspected | `[grounded]` your statement | none |
| R8b | Own billing data | important | absent | none | capability | You confirmed you haven't worked on billing data. The requirements list only asks for "billing or revenue", but "you will own" billing data is a stated duty, so it is an important row | `[grounded]` your statement and posting | See G4 |
| R9 | Build pipeline and renewal reporting that sales and finance run on | important | direct | medium | none | You rebuilt pipeline and renewal dashboards. Whether finance used them isn't stated, so I took the lower band | `[grounded]` your statement | Dashboard screenshot would raise this to high |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms (R1, R2, hard_gate) | hard_gate | Neither your location nor your pay floor is stated | Either could fail the role outright whatever the fit elsewhere | Your base location, the office days you'd accept, a pay floor | Your own statement is the evidence | `[grounded]` constraints not given |
| G2 | Forecast ownership (R6, must_have) | transferability | You run the pipeline review and built the dashboards; finance owned the forecast | Forecasting with the CFO is the posting's headline duty, so this is the likeliest sticking point | Supplying pipeline coverage or commit numbers that finance or the sales director used; a forecast-versus-actual review; a weighted pipeline model with stated assumptions | A sanitized forecast-versus-actual sheet, a pipeline coverage model, a review deck | `[grounded]` your statement; `[generic]` that forecasting is the likeliest sticking point for candidates without forecast ownership |
| G3 | Finance collaboration (R7, must_have) | discovery | Renewal dashboards exist; a finance counterpart isn't mentioned | The "or" in the requirement means revenue-data work with finance could close this row without any billing experience | Agreeing a renewal or ARR definition with finance; reconciling your dashboard to finance's numbers; supplying data for a quarter-end review | A definitions doc, a dashboard screenshot, a reconciliation sheet | `[grounded]` your statement and the posting's "or" |
| G4 | Billing data (R8b, important) | capability | You haven't worked on billing data | It is a stated duty, and you'd be learning it on the job | Not applicable: no adjacent evidence stated. Closure path: a short self-built sample (sample invoice and subscription tables reconciled to renewal figures in SQL) so you can show how you'd approach it, with the plain statement that you haven't owned billing data | The sample itself, if you choose to build one | `[grounded]` your statement; `[inferred]` that a sample would narrow the objection |
| G5 | Spreadsheet modelling (R5b, must_have) | discovery | Daily Excel use stated; no model described | Lower impact than G2 and G3 | A pipeline coverage model, a quota or commission model, a renewal forecast sheet | A sanitized workbook | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | The role wasn't found on Quillfield's own careers page | unknown | — | Posting on Tallyboard Jobs; the careers page fetch returned no page | The role may be listed elsewhere, newly posted, or advertised through an aggregator | `[grounded]` the fetch result; `[generic]` that companies often list roles in several places | Is this role currently open, and where is it listed on your own site? | unresolved |
| RR2 | A "Lead" title with no team or authority stated | risk_signal | low | "Revenue Operations Lead… You will own our CRM and billing data… and run the quarterly revenue forecast with the CFO" | You may be a sole practitioner holding bundled duties. Tamsin Achebe's title as Head of Revenue Operations suggests a function already exists, which lowers the concern | `[inferred]` from the posting's scope against its silence on team; `[grounded]` her title from a search snippet | Who is on the team today, and who currently owns CRM, billing data and the forecast? | unresolved |
| RR3 | Pay stated and inside the market band | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The employer is transparent on base pay and the figure is in line with the role family | `[grounded]` posting; `[generic]` Ledgerline band | Is the range base salary only? | noted |
| RR4 | Share option terms unstated | unknown | — | "plus share options" | The options may be meaningful or token; the posting doesn't say | `[grounded]` posting silence | What is the grant size and vesting schedule, and what is the current valuation basis? | unresolved |
| RR5 | No success measures for a demanding mandate | unknown | — | The posting lists duties but no outcomes | The first-year expectations may be unwritten | `[grounded]` posting silence; `[generic]` pattern of mandates without stated targets | What would a good first six and twelve months look like? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter to confirm the role is open, where it's listed on Quillfield's site, and the option terms | see RR1, RR4 | `[grounded]` register | pending your approval |
| A2 | Lead with "2 years running revenue operations for the UK team", the pipeline and renewal dashboard rebuild, and the Salesforce admin certification | see R3, R4, R9; each phrase traces to your own words | `[grounded]` your statements | pending your approval |
| A3 | Say it before they ask: "I've run the pipeline review with the sales director; finance owned the company forecast, and I haven't worked on billing data" | see R6, R8b; it states what you told me, including its limits | `[grounded]` your statements | pending your approval |
| A4 | For the hiring manager, lead with your sales-operations-into-revenue-operations progression, which echoes her public path from sales operations manager to Head of Revenue Operations. This is a reading of her footprint, not a claim about what she values | see R3 | `[inferred]` from her career pattern in a search snippet | pending your approval |
| A5 | Ask the verification questions from RR2, RR4 and RR5 verbatim in the interviews | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A6 | Optional: build the small invoice-to-renewal reconciliation sample from G4 | see R8b | `[inferred]` that a sample would help | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers", which returned "About Quillfield" (quillfield.co.uk/about); fetched quillfield.co.uk/careers, which returned no page. Role reality's organization and contradictions rows, and RR1 |
| 2. Role-family sweep | yes | Searched "revenue operations lead Bristol salary B2B software UK", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Market calibration and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), snippet only. Role reality's hiring-manager row, RR2 and A4 |

I can write this up as `tuesday-dossier.md` if you want to keep it or build on it later. Just say so.

**Upgrade menu**

- Your location and pay floor → R1 and R2 resolve, and the decision firms up or drops.
- An answer on forecasting, or a sanitized forecast-versus-actual or pipeline coverage sheet → R6 strengthens.
- An answer on finance collaboration, or a definitions doc or reconciled dashboard → R7 can close.
- The Salesforce credential record → R4 to `high`; a dashboard screenshot → R9 to `high`.
- A sanitized workbook → R5b.
- Your CV (I worked from your description) → lets me check presentation gaps and propose edits as `resume_edits_pending_approval`.
- The recruiter's confirmation of the listing and option terms → RR1 and RR4 close.
- A deeper research pass on Quillfield (funding and leadership changes, recent news, public employee reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

- R1, R2 — Does a Bristol-based role with two office days a week and £61,500–£67,000 work for you, or are your location or pay floor different?
- G2 — Have you ever produced or checked a pipeline-based number (coverage, commit, stage conversion) that finance or your sales director used in a forecast, and which part was yours?
- G3 — Have you worked with finance on renewal or revenue numbers, such as agreeing a definition or reconciling a dashboard to their figures, and what was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.