I've read the underwriting playbook. Next I'm checking that the posting and the company page are live and match what you pasted, then I'll write the assessment.
The posting and company page are live and match what you pasted word for word, so the assessment below runs on them.

## Decision snapshot

**Yes, worth applying to, provided R1 and R2 check out. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or our Denver office), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5a, R5b, R6, R7
- `important` — adjacent: R8 (BigQuery warehouse); unclear: R9 (ingestion from app and CRM), R10 (data contracts)

R8 — a credible bridge, its limit named; R9, R10 — CV silent on both, one question would settle R9.

**Opportunity ledger.** Sound on the posted terms: pay is stated and sits inside the market range (RR3). The manager, team and first-year outcomes are not stated (RR1, RR2), and the equity terms are not stated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you are US-based or can work from Denver — R1; (2) the stated range clears your base-pay floor — R2; (3) BigQuery is presented as the gap it is, never as experience — R8.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026). These are the company's own statements | `[grounded]` About page fetched, matches your paste |
| Mandate | Build and run the reporting pipelines: ingestion from app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts analysts depend on | `[grounded]` posting fetched |
| Working pattern | Remote (US) or Denver office | `[grounded]` posting |
| Seniority | The posting asks for 5+ years. Datawright calls 5–8 years typical for "Senior", so your six years sits inside that range | `[grounded]` posting and the pay report you supplied; `[inferred]` the comparison |
| Scope read | Three named areas (ingestion, warehouse, contracts) with no reports or team size mentioned. Datawright's typical scope is one domain's pipelines with no direct reports, which this resembles | `[inferred]` posting against the report's description |
| Market calibration | Posted $148,000–$166,000 against a Series B–D base median of $151,000 and interquartile range $139,000–$163,500 (n=2,310). The low end is $3,000 under the median and the top is $2,500 above the 75th percentile. I read "salary" as base pay, and equity is separate and unquantified (RR4) | `[grounded]` posting and recruiter's Datawright report; `[inferred]` that "salary" means base |
| Unknowns | Hiring manager and team size; first-year outcomes; equity terms; whether the "Remote (US)" option has any state restrictions | — |
| Contradictions | None between your pasted text and the live pages | `[grounded]` both pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you are based, so nothing settles this. The confidence band grades your statement of the constraint, and there isn't one yet | `[grounded]` posting; your location not given | Question R1 below |
| R2 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | The posting states the pay, but your floor is unknown, so fit can't be called | `[grounded]` posting; your floor not given | Question R2 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Your six years at a B2B payroll company exceed the minimum. It is self-reported with no resume or other artifact inspected, so `medium` | `[grounded]` your intake message | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is confirmed in your words, but "strong" is untested and nothing inspectable has been seen. Expect a technical screen to probe it | `[grounded]` your intake message; `[generic]` that screens for this title usually test SQL and Python directly | none |
| R5a | dbt | must_have | direct | medium | none | You built your company's dbt project, about 180 models. Specific, but there is no inspectable artifact yet | `[grounded]` your intake message | Offer: a sanitized lineage-graph screenshot or model-count listing would raise this to `high` |
| R5b | A cloud warehouse | must_have | direct | medium | none | You ran dbt on Snowflake, which is a cloud warehouse. The requirements line says "a cloud warehouse", not BigQuery by name (BigQuery is covered in R8) | `[grounded]` your intake message and the posting's requirements line | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named in the requirement and you used it for orchestration. Your exact ownership of the DAGs isn't stated, so I assert only "used Airflow" | `[grounded]` your intake message | A sanitized DAG listing would raise this to `high` |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite, which is specific and is your own claim of origination. No artifact inspected | `[grounded]` your intake message | A sanitized suite config or a validation report would raise this to `high` |
| R8 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | The posting's requirements list asks only for "a cloud warehouse", so this tier is my reading of the role description. dbt and Snowflake carry over. The limit is that you have never used BigQuery. BigQuery bills mainly by data scanned and rewards partitioning and clustering, which differs from Snowflake's compute model | `[inferred]` tier from the mandate sentence; `[grounded]` your "never used BigQuery"; `[generic]` the cost-model difference | A small dbt-on-BigQuery project would narrow the limit (offered under Application plan, W1) |
| R9 | Ingestion from the app and CRM | important | unclear | low | discovery | Your pipelines surely loaded data from somewhere, but you haven't said from what. Low, not none, because Airflow work is indirect context | `[inferred]` from your Airflow use; `[grounded]` that your message is silent on sources | Question R9 below |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | The CV-level material is silent. Your tests may amount to contracts, but nothing says analysts were promised anything | `[grounded]` your message is silent | Gap G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location (R1, hard_gate) | hard_gate | No location stated | Remote is US-only and the other option is Denver, so this decides eligibility | Your current city and state, and whether you'd work from Denver | None needed | `[grounded]` posting terms; your location not given |
| G2 | Pay floor (R2, hard_gate) | hard_gate | No floor stated | The range straddles the market median, so whether it clears your floor decides the status | A base figure you would accept | None needed | `[grounded]` posting range; `[inferred]` that your floor matters here because I don't have it |
| G3 | BigQuery (R8, important) | transferability | Strong dbt-on-Snowflake evidence, no BigQuery | The posting makes BigQuery the warehouse, so the bridge and its limit are the likeliest objection | A personal dbt-bigquery project, a migration you took part in, BigQuery used outside your day job | A public or sanitized repo | `[inferred]` bridge from your dbt and Snowflake work; `[generic]` that this is the likeliest objection |
| G4 | Data contracts (R10, important) | discovery | Great Expectations suite exists, but no agreement with analysts is described | The posting names contracts as a core duty | Source freshness checks or column tests analysts relied on; a documented SLA or schema agreement; dbt model contracts | A sanitized schema agreement, a test config, an analyst-facing doc | `[grounded]` silence in your message |
| G5 | Ingestion (R9, important) | discovery | Sources unstated | Half the mandate is ingestion from app and CRM data | Loads from an application database; CRM, billing or HRIS connectors; incremental or change-data-capture loads | A sanitized DAG listing, an ingestion diagram | `[inferred]` Airflow work implies loads; `[grounded]` sources not stated |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Manager and team not named | unknown | — | "The posting names no hiring manager" (your note) | Role may report into engineering, analytics or a single lead; team size unknown | `[inferred]` from the posting's silence | Who does this role report to, and how many engineers and analysts does it work with? | unresolved |
| RR2 | No first-year outcomes stated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | Success may be defined only once you start; scope across ingestion, warehouse and contracts could be wide for one hire | `[inferred]` from the posting's silence on outcomes against its three-part mandate | What should be true of the warehouse and data contracts twelve months in? | unresolved |
| RR3 | Pay stated and in the market range | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Posted terms are transparent and priced near the Series B–D band | `[grounded]` posting and recruiter's Datawright report | Is the range base pay, and does it apply to Remote (US) the same as Denver? | noted |
| RR4 | Equity unquantified | unknown | — | "plus equity" | Amount, vesting and strike terms may only come at offer | `[inferred]` from the posting naming equity without terms | What equity is typical at this level, and how is it structured? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the dbt project (about 180 models, Snowflake) and the Great Expectations suite you set up, then Airflow and daily SQL and Python | R5a, R7, R6, R4 are the `must_have` rows you meet | `[grounded]` your intake message | pending your approval |
| A2 | Name BigQuery yourself, in your own words: "I've built dbt on Snowflake and haven't used BigQuery." Don't present it as experience | R8; the plain statement is what you said | `[grounded]` your intake message | pending your approval |
| W1 | Build a small dbt-on-BigQuery project as a sample, if you have time before applying | R8 | `[inferred]` it narrows the limit named in R8 | pending your approval |
| Q1 | Ask RR1, RR2 and RR4's questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer) and "About Pellucid Learning" (pellucidlearning.com/about) to check your pasted text. Both match word for word, and the posting shows as accepting applications. It moved the contradictions row, and no employer-not-established entry was needed. Funding and headcount are the company's own statements, not independently confirmed |
| 2. Role-family sweep | skipped | The Datawright report you pasted fixes the market calibration line and RR3, so a search could change nothing |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'd offer a profile of the hiring manager once you have a name, and a deeper search into funding and leadership changes (up to 5 more searches and 2 more fetches) if you want one.

If you want this kept, I can save it as `tuesday-dossier.md`.

## Upgrade menu

- Your location and pay floor → R1 and R2 resolve, and the decision becomes `go` or `no_go`.
- Your resume → I could check whether it buries any `must_have` evidence, and set presentation gaps.
- A sanitized dbt lineage screenshot, DAG listing or Great Expectations config (payroll data stays out) → R5a, R6 and R7 can go to `high`.
- The hiring manager's name → role reality's scope read, and which story to lead with for that reader.
- A deeper company check (leadership changes, funding news; up to 5 more searches and 2 more fetches) → say the word and it runs.

R1 — Are you based in the US, or able to work from Denver?
R2 — Does $148,000–$166,000 base clear your floor?
R9 — Did you build ingestion from an application database or a CRM or billing source, and what part was yours?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.