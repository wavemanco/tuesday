I've read the underwriting playbook and I'm now running the default research pass: the company, UK salary norms for the role, and the hiring manager's public profile.
**Yes, apply, once the employer and posting verify (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5a, R6, R7 · unclear: R5b (Monitor rating models)
- `important`: unclear: R8 (recommendations for product)
- `preferred`: direct: R9 · adjacent: R10 (pet-insurance domain)

R5b: "maintained" may cover monitoring, unconfirmed; R8: the product audience is unevidenced; R10 (`medium`): a credible bridge from motor, its limit named.

**Opportunity ledger.** The employer could not be established from search (RR1), pay is unstated (RR2), and the team around the role is unspecified (RR3). The posting's concrete duties and the manager's public talk on monitoring rating models run the other way (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and the live posting verify (RR1); (2) UK location and right to work confirmed (R1); (3) pay checked against your floor (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header |
| Employer check | A search for Brindlemoor returned nothing, so the employer is not established from here | `[grounded]` search returned no results |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, give recommendations to underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Reports to | Odile Varga, Director of Pricing | `[grounded]` your message |
| Manager footprint | A profile page names her as Director of Pricing at Brindlemoor, speaker at the 2025 Insurance Pricing Forum ("Small Books, Loud Errors", on monitoring rating models in small books), and previously head of pricing analytics at Calloway Re for six years. A third-party page naming the company does not establish it | `[grounded]` profile page snippet |
| People management | The JD lists no line-management requirement, so having never managed anyone creates no row | `[grounded]` JD silence |
| Scope read | Looks like an individual-contributor owner role; no reports are stated | `[inferred]` from the JD's "own" wording against its silence on a team |
| Market calibration | A 2026 survey puts senior pricing analysts at UK insurers and insurtechs at a median base of £58,400, interquartile range £52,100 to £64,900. The posting states no pay, so this is a band to expect, never Brindlemoor's offer (RR2) | `[generic]` survey snippet, one search; `[grounded]` JD for the missing figure |
| Unknowns | Pay; team size and tooling; how monitoring is done today; whether the product audience is a real stakeholder | — |
| Contradictions | None found, but there was no company page to compare the JD against | `[grounded]` no careers page reached |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | Your location and right to work are not stated. Working at a UK insurer suggests a UK base, but that is not confirmation | `[inferred]` from the UK employer; no constraint stated | Confirm in Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years' pricing analytics at a UK motor insurer, stated in prose. It is self-report with nothing inspected yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Both used daily, per you; no artifact inspected | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book; no artifact inspected | `[grounded]` your background | none |
| R5a | Build rating models | must_have | direct | medium | none | The same GLM build covers this | `[grounded]` your background | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" may include monitoring, but you haven't said so. I took the reading that claims less | `[grounded]` your wording; `[inferred]` that maintenance may include monitoring | Ask G1 |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with underwriting. Which parts you designed and which you read out is unconfirmed, so expect a probe | `[grounded]` your background | none |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R8 | Recommendations for product, beyond underwriting | important | unclear | low | discovery | Your evidence is underwriting-facing; nothing mentions product teams | `[grounded]` background silent on product | Ask G2 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance domain (implied by the product, not stated as a requirement) | preferred | adjacent | medium | transferability | The model-building and test work carries over. You have not priced pet insurance, and that limit stays named. Pet pricing's rating factors differ from motor's | `[inferred]` from the JD's product against your motor-only history; `[generic]` that rating factors differ | Bridge case G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R5b, must_have) | discovery | You built and maintained the model, but nothing says how you tracked its performance | Monitoring is half of the JD's first duty, and the hiring manager has spoken publicly on monitoring in small books | Tracking actual-versus-expected by segment; drift or lift checks; a refit trigger you set; a dashboard others read | A monitoring pack, a dashboard screenshot, a refit note | `[grounded]` background silent; `[inferred]` that this resolves a must-have row |
| G2 | Recommendations for product (R8, important) | discovery | Your recommendations went to underwriting; no product-facing work appears | The JD names product as an audience | Price-test readouts that changed a product feature, a tier or a discount; work with a product or proposition team | A readout deck or a test summary, sanitised | `[grounded]` background silent on product |
| G3 | UK location and right to work (R1, hard_gate) | hard_gate | Stated by neither the JD side nor you | A term you either meet or don't, and it can't be worked around | A term, not experience | None needed | `[inferred]` UK base from the employer |
| G4 | Pet-insurance domain (R10, preferred) | transferability | Motor GLM and test work; no pet exposure | It is the likeliest objection in a screen | Adjacent: the rating-model build and the tests. Limit: no pet-specific rating factors or claims patterns. Strengthener: a short note on how you would approach a small-book pet model | A one-page approach note | `[inferred]` bridge from your motor work; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | "Fully remote (UK)" is the only term the posting gives; no figure appears | The figure may sit below the survey band, or it may simply not be published | `[inferred]` from the JD's silence against the `[generic]` band | What base salary is budgeted for this post? | unresolved |
| RR3 | Scope of "own" with team and resources unspecified | unknown | — | "Own pricing analytics for our pet-insurance product" | You may be the only analyst, with limited data or tooling | `[inferred]` from "own" against the JD's silence on a team | Who else sits in pricing, and what data and tooling would I own? | unresolved |
| RR4 | Concrete duties; manager's public monitoring focus | positive_signal | — | "build and monitor rating models, design and read price tests" | The duties are specific, and the manager's talk topic matches the monitoring duty | `[grounded]` JD; `[grounded]` profile page snippet, whose link to Brindlemoor is unverified | How is model monitoring done today, and what would you want in my first six months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter for the careers-site link and confirm the sender's email domain before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead with your own line: "Built and maintained the GLM rating model for the young-driver book" at a UK motor insurer, moved to the top | R4, R5a | `[grounded]` your wording, unchanged | `resume_edits_pending_approval` |
| E2 | Keep the tests line as you stated it: ran 14 price tests with the underwriting team last year, with no added verbs such as "designed" until you confirm | R6 | `[grounded]` your wording | `resume_edits_pending_approval` |
| E3 | State the quarterly pricing review you present to the head of underwriting as its own line | R7 | `[grounded]` your wording | `resume_edits_pending_approval` |
| P1 | Say plainly that you haven't priced pet insurance and that the model build and testing work is what carries over | R10 | `[grounded]` your statement; `[generic]` that candour reads well in screens | pending your approval |
| Q1 | Put RR1 to RR4's verification questions to the hiring manager verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" and got no results, so the employer is not established. This moved the standing RR1 entry and capped the decision at `conditional_go` |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), read as a snippet. This moved market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), read as a snippet. This moved role reality's manager footprint row and RR4 |

If you'd like, I can save this as `tuesday-dossier.md` so later steps can read it.

**Upgrade menu**

- The careers-site link or the recruiter's email domain → RR1 closes, and the decision likely moves to `go`.
- Your constraints (UK location, right to work, pay floor) → R1 settles and RR2 gets a floor to check against.
- A monitoring pack or dashboard screenshot → R5b rises from `low`.
- A sanitised test readout → R8 and R6 firm up.
- A deeper research pass (up to 5 more searches and 2 more fetches on funding, leadership and recent news) → RR1 and the opportunity ledger. Say the word and it runs.

**Questions**

- Q1 (R1): Do you have terms this role must meet, such as UK location and right to work, a pay floor, or a working pattern? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- Q2 (G1): Did you track the young-driver model's performance after launch, and if so, how and how often, and what did you do when it drifted? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- Q3 (G2): Did any of your 14 price tests lead to a change a product or proposition team owned, and what was your part? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.