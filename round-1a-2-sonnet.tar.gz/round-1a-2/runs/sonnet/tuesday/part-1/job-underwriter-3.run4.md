Here's where it stands. The two web searches I tried were refused, so this rests on your message and the posting alone. It is not worth pursuing as written, and your instinct was right. The match on paper is real, but two of your own terms conflict with the posting's.

## Decision snapshot

**No, not worth pursuing as posted: R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site Austin office 5 days), R2 (Base $70–85k)
- `must_have` — direct: R3, R4, R5, R6
- `important` — unclear: R7 (SEO/content), R8 (Brand, PR, partnerships), R9 (Sales ops), R10 (Team of one)

R1 — location conflicts with your remote-only constraint; R2 — pay conflicts with your $150k base floor; R6 (`medium`) — scaled revenue with a budget, personal share still to be probed.

**Opportunity ledger.** The role conflicts with your terms (RR1, RR2). It is also thin on its own account: the posting packs seven functions into one seat (RR3), states no budget or authority (RR4), expects after-hours work (RR5), leaves success undefined (RR6), and doesn't quantify the equity (RR7). The employer's own claims are unverified (RR8). Direct reporting to the CEO is the favorable signal (RR9).

- **Hard gates:** failed: R1 (On-site Austin office 5 days a week, no exceptions), R2 (Base $70–85k).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** R1 would have to allow Portland-based remote work, and R2 would have to reach $150k base or more. The posting rules out the first in its own words ("no exceptions"), so that would be a different role, not this one.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement startup, Series A, "profitable since day one"; none of this is verified (RR8) | `[grounded]` posting header |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Team | "A team of one to start" | `[grounded]` posting |
| Reporting | CEO, dotted line to the board | `[grounded]` posting |
| Working pattern | On-site Austin, 5 days a week; "evenings and weekends when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside", with no equity terms given | `[grounded]` posting |
| Success metrics | Undefined: "will evolve as we learn" | `[grounded]` posting |
| Scope read | A department-sized mandate placed in a solo seat | `[inferred]` from the function list against "team of one" |
| Market calibration | Not established. The role-family search was refused, so no market band is stated. Read from the posting alone, the top of the range sits $65k below your floor | `[grounded]` posting figures and your stated floor |
| Unknowns | Budget, spend authority, equity terms, whether hires follow "to start", the 12-month success measure | — |
| Contradictions | "Head of" title, board access and "all revenue growth" sit beside a one-person team and a $70–85k base | `[inferred]` from the posting's own terms |

## Evidence map

I worked from your account in this message. No CV was provided, so every candidate claim is self-report and capped at `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site Austin office 5 days a week, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your statement of the limit (remote-only, Portland, not relocating), which is your own, specific and confirmed. The fit fails because the posting rules out any exception | `[grounded]` posting quote and your stated constraint | Surface only; the employer changing terms is the one resolution |
| R2 | Base pay $70–85k | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your $150k base floor, which is your own and confirmed. The range tops out $65k below it, and equity does not count toward a base floor | `[grounded]` posting figure and your stated floor | Surface only; the employer changing terms is the one resolution |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, Growth lead then Head of Growth, self-reported with no inspectable artifact yet | `[grounded]` your account | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid at both companies; self-reported | `[grounded]` your account | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze; self-reported | `[grounded]` your account | none |
| R6 | Owning revenue growth with a budget | must_have | direct | medium | none | $8M to $40M ARR over three years with a budget you controlled. Medium, with the caveat named: expect a probe on how much of that was personally yours | `[grounded]` your account | An ARR-bridge or channel P&L would raise it to high |
| R7 | SEO/content | important | unclear | none | discovery | You named none; silence is not absence | `[grounded]` your account is silent | See G1 |
| R8 | Brand, PR, partnerships | important | unclear | none | discovery | You named none | `[grounded]` your account is silent | See G2 |
| R9 | Sales ops | important | unclear | none | discovery | You named none | `[grounded]` your account is silent | See G3 |
| R10 | Working as a team of one | important | unclear | low | discovery | You built and managed teams of 3–7; no solo-execution evidence either way | `[inferred]` from team-building history, an indirect link | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R7, important) | discovery | Paid, lifecycle and experimentation are named; organic is not | Moot while R1 and R2 stand | Owning a content calendar or an SEO agency relationship; organic revenue you reported on | A traffic-to-revenue report | `[grounded]` your account is silent; `[inferred]` moot given the gates |
| G2 | Brand, PR, partnerships (R8, important) | discovery | Nothing stated | Moot while R1 and R2 stand | Affiliate or co-marketing deals; a launch with a press push | A partner list or a deal summary | `[grounded]` your account is silent |
| G3 | Sales ops (R9, important) | discovery | Nothing stated | Moot while R1 and R2 stand | Lead routing, CRM hygiene, handoff to sales on a subscription funnel | A funnel definition or a routing doc | `[grounded]` your account is silent |
| G4 | Solo execution (R10, important) | discovery | Teams of 3–7 managed; no stretch as the only operator | Moot while R1 and R2 stand | An early period before the team formed; a function you ran by hand | An org history or a roadmap from that stretch | `[inferred]` from team-building history |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Five-day on-site conflicts with your remote-only constraint (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | The role is incompatible with your stated Portland, remote-only constraint, with no flex indicated | `[grounded]` posting quote and your stated constraint | Is the Austin on-site requirement fixed for this role, or is any remote arrangement possible? | confirmed |
| RR2 | Base range sits far below your floor (see R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The top of the range sits $65k under your $150k base floor, and equity does not close a base gap | `[grounded]` posting figure and your stated floor | Is the base range fixed, or is it negotiable above $85k? | confirmed |
| RR3 | Bundled specializations plus a seniority-pay mismatch | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" | Several full functions in one seat, with 8+ years' leadership asked at this base range. A market search that would confirm the pay gap did not run | `[inferred]` from the function list and pay against the one-person seat | Which of these functions will have budget or headcount behind them in year one, and how was this base range set against the scope? | unresolved |
| RR4 | Responsibility without stated authority or resources | unknown | — | "Own all revenue growth end to end" | Budget and spend authority are unstated | `[inferred]` from the posting's silence | What budget does this role control, and who approves spend? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work may be routine rather than exceptional | `[inferred]` from the wording | How often did the last person in this seat, or the team, work evenings and weekends in a typical quarter? | unresolved |
| RR6 | Success undefined against a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You may be accountable for revenue with no agreed definition of success | `[inferred]` from the posting's own wording | What would you expect to see in the first 90 days, and at 12 months, to call this a success? | unresolved |
| RR7 | Equity unquantified | unknown | — | "meaningful equity upside" | Grant size, vesting and strike price are unstated | `[inferred]` from the posting's silence | What percentage and vesting terms come with the equity, and what is the current preference stack? | unresolved |
| RR8 | Employer claims not verified: no research ran | unknown | — | "Series A, profitable since day one" | Stage, profitability and the live posting could not be confirmed from here | `[generic]` pattern: a posting's own claims are unchecked until sourced elsewhere | Can you point me at this role on your careers site, and who would I interview with? | unresolved |
| RR9 | Direct reporting line to the CEO | positive_signal | — | "Report to the CEO with a dotted line to the board" | Senior access and visibility | `[grounded]` posting | Who does the CEO expect to own the growth number day to day? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't spend application effort on this posting as written | See R1, R2, RR1, RR2 | `[grounded]` map and register | pending your approval |
| A2 | If you want to test the terms, ask the recruiter one question: are the on-site and pay terms fixed? Expect a yes, since the posting says "no exceptions" | See RR1, RR2 | `[inferred]` from the posting's wording | pending your approval |
| A3 | If you proceed anyway, ask RR3 to RR8's questions verbatim before any interview time is spent | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | Aim the search at remote-eligible growth leadership roles with a stated base of $150k or more. Your paid, lifecycle and experimentation story is the one to lead with, at `medium` until you have artifacts | See R4, R5, R6 | `[generic]` role-family direction; `[grounded]` your stated account | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin careers Head of Growth"; the call was refused. It would have moved role reality's organization and contradictions rows and RR8 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth startup salary range base compensation Series A"; the call was refused. It would have moved the market calibration row and the pay read in RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'm offering one x item, not including it: a one-page channel-by-channel summary of which of the seven functions your history covers. It would earn its place only if you pursue this or a similar role.

I can save this as `tuesday-dossier.md` if you want it to carry forward.

## Upgrade menu

- Your CV or an inspectable artifact (an ARR bridge, a channel P&L, an experiment log, a Braze journey map) → R3 to R6 can move to `high`.
- A written answer from the recruiter on whether on-site and base are fixed → R1, R2, RR1 and RR2 close. The decision changes only if both terms move.
- A link to the role on Novaline's own careers page → RR8 closes.
- Search permission → targets 1 and 2 run, and the market calibration and employer checks fill in. A deeper pass (up to 5 more searches and 2 more fetches) is available once search works.
- Evidence for SEO, brand/PR/partnerships or sales ops → R7 to R9 firm up, though this matters only if the terms change.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.