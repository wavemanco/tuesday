I'm checking that the Pellucid posting is still live and matches what you pasted. After that I'll write up the assessment.
**Yes, it's worth applying — `conditional_go`.** Your fit is strong on the must-haves (R3, R4, R5, R7, R8 are all `direct`). The two conditions are that you confirm R1 (location) and R2 (pay), because I don't have your location or pay floor.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R7, R8
- `important` — adjacent: R6 (BigQuery warehouse) · unclear: R9 (Ingestion from app and CRM), R10 (Data contracts for analysts)

R6 (`medium`) — a credible bridge, its limit named; R9, R10 — the background you gave is silent on them.

**Opportunity ledger.** Sound on what can be checked: the posting is live and matches the company's own pages (RR1), and the pay is posted and in the market range (RR2). Open items are the missing hiring manager and team shape (RR3), equity terms (RR4) and a possibly broad remit (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm you can work from the US or Denver — R1; (2) the posted range meets your floor — R2; (3) the BigQuery bridge is framed honestly as adjacent, never as BigQuery experience — R6.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016 in Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company About page, fetched |
| Mandate | Build and run the reporting pipelines: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` posting, fetched |
| Requirements stated | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` posting |
| Pay and location | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` posting |
| Hiring manager | Not named | `[grounded]` posting names none |
| Scope read | Three areas (ingestion, warehouse, contracts) under one title; the report's typical scope is one domain's pipelines with no direct reports, so this may run broader than typical | `[inferred]` from the posting's three areas against the report's scope description |
| Market calibration | The posted range spans the report's median of $151,000: its low end is $3,000 under the median and its top is $2,500 over the interquartile range's upper end of $163,500. Pellucid's Series C stage sits inside the report's Series B–D cohort, and its 5+ years sits inside the typical 5–8 | `[grounded]` Datawright 2026 report figures, from your recruiter; `[inferred]` the arithmetic and the cohort match |
| Unknowns | Hiring manager and team size; equity terms; source systems behind "app and CRM"; whether analysts already have contracts | — |
| Contradictions | None between the pasted posting and the live careers page, or between the pasted About text and the live About page | `[grounded]` both pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You gave no location, so the posting's terms can't be matched to you. Confidence is `none` because there is no statement to grade | `[grounded]` posting; no constraint stated | Question R1 below |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You gave no pay floor, so I can't say whether the range meets it. Equity terms are not stated | `[grounded]` posting; no constraint stated | Question R2 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | 6 years of data engineering at a B2B payroll company, self-reported with no artifact yet. The report calls 5–8 years the usual meaning of "Senior" | `[grounded]` your background; `[grounded]` report for the 5–8 | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily; the evidence is self-report, so expect a probe | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models. A project repo or model docs would raise this to `high` | `[grounded]` your background | Offer: sanitized model lineage or docs to reach `high` |
| R6 | BigQuery warehouse (named in the mandate, not the requirements list) | important | adjacent | medium | transferability | Snowflake and dbt work carries over. Limit: you have never used BigQuery, so its cost model, partitioning and clustering are untested by you | `[grounded]` your background; `[inferred]` that the mandate's naming of BigQuery makes it matter | See G1 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration; scope and scale weren't stated | `[grounded]` your background | none |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. Coverage and what it caught weren't stated | `[grounded]` your background | none |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | The payroll-company work may include comparable ingestion, but your background doesn't say what the sources were | `[grounded]` your background is silent on sources | See G2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Great Expectations and dbt tests are adjacent to contracts, but you haven't said whether any agreements with analysts existed | `[grounded]` your background is silent on contracts | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6, important) | transferability | Snowflake and dbt carry over; BigQuery use is none | The posting names BigQuery in the mandate, so an interviewer may probe it first | Cost and partitioning decisions on Snowflake; a dbt adapter swap; any BigQuery exposure in side projects | A small public BigQuery and dbt project, or a written Snowflake-to-BigQuery comparison | `[grounded]` you have never used BigQuery; `[generic]` that adjacent-warehouse candidates are usually probed on it |
| G2 | App and CRM ingestion (R9, important) | discovery | Source systems unstated | It's the first named responsibility | Pulling from a product database, event stream or SaaS API such as a CRM; managing incremental loads or schema drift | A pipeline diagram or DAG screenshot | `[grounded]` background silent on sources |
| G3 | Data contracts (R10, important) | discovery | No mention of agreements with downstream users | The posting says analysts depend on them | Schema-change reviews with analysts; tests that gate releases; documented column definitions | A contract doc, a test config or a changelog | `[grounded]` background silent on contracts |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting consistent with the company's own pages | positive_signal | — | "Accepting applications." | The posting is live and the employer matches its description | `[grounded]` both pages fetched; the funding figure is the company's own statement and not independently checked | Who would I interview with, and what's the process? | noted |
| RR2 | Pay posted and in market range | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is transparent and not below the report's interquartile range | `[grounded]` posting and report figures | Is the range negotiable within the band? | noted |
| RR3 | No hiring manager or team named | unknown | — | "The posting names no hiring manager" | Unknown reporting line, team size and who owns analytics engineering | `[grounded]` posting names none | Who does this role report to, and how many data engineers are there? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | Grant size, vesting and strike may materially change the offer's value | `[grounded]` posting gives no terms | What is the equity grant range, vesting schedule and strike price? | unresolved |
| RR5 | Three areas under one title | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | The remit may cover several specialisms, broader than the report's typical one-domain scope | `[inferred]` from the posting's three areas against the report's scope description | Which of these areas are you hiring me to own, and which are shared? | unresolved |

## Application plan

Every row is proposed and awaits your approval; E1 carries `resume_edits_pending_approval`.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your resume with the dbt project on Snowflake (about 180 models), Airflow orchestration and the Great Expectations suite, using your own wording and figures | See R3, R5, R7, R8 | `[grounded]` your background | pending your approval (`resume_edits_pending_approval`) |
| W1 | A small public dbt-on-BigQuery project, described as learning work and never as BigQuery experience | See R6, G1 | `[grounded]` R6 row | pending your approval |
| Q1 | Ask RR3, RR4 and RR5's questions verbatim once you're in conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Confirm location and pay (R1, R2) before investing in the loop | See the hard-gates line | `[grounded]` map | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer) and "About Pellucid Learning" (pellucidlearning.com/about). Both checked your pasted copies: the posting is live and the text is identical. It fed the contradictions row and RR1 |
| 2. Role-family sweep | skipped | The Datawright report in hand fixes market calibration and RR2, so a search could not change them |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Say the word and I'll write `tuesday-dossier.md` from this assessment.

## Upgrade menu

- A project repo, model docs or lineage for your dbt work → R5 to `high`.
- A DAG screenshot or pipeline diagram → G2 and R7 firm up.
- Any test or contract artifact → G3 and R8 firm up.
- A BigQuery side project → G1's limit narrows.
- The hiring manager's name → role reality's scope read and which story to lead with.
- A deeper research pass on Pellucid (funding and leadership changes, hiring patterns, employee reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

R1 — Are you US-based, or near Denver? If you're elsewhere, say where.
R2 — Is $148,000–$166,000 at or above your pay floor, and does equity matter to you?
G2, G3 — Have you ingested from a product database, event stream or CRM-type API, and did you ever agree schema or column definitions with analysts?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.