**Yes, it's worth applying to, with conditions. Status: `conditional_go`.** R1 and R2 (the location and pay gates) are unconfirmed against you, and I couldn't verify the employer (RR1).

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (BigQuery warehouse) · unclear: R9 (Ingestion from app and CRM), R10 (Data contracts)

R8 is a credible bridge with its limit named. R9 and R10 are rows your background is silent on. R5 (`medium`) is stated in prose with no artifact yet.

**Opportunity ledger.** The posted pay sits at the market reference you supplied (RR2). The open items are the equity terms (RR3), the team and scope (RR4), and the employer facts, which I couldn't verify (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Your location and pay floor are confirmed against R1 and R2.
  2. The employer and live posting verify (RR1).
  3. BigQuery is presented as adjacent, never as experience (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026). I could not check this against the live site. | `[grounded]` the About text you pasted |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Requirements stated | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| First-year outcomes | None stated. The JD gives no definition of success. | `[grounded]` JD silence |
| Scope read | Reads as one domain (reporting) spanning several layers. Whether you would own all of it or share it is unknown (RR4). | `[inferred]` from the JD's three named areas against its silence on team size |
| Market calibration | Posted $148,000–$166,000 against the Datawright report's base median of $151,000 and interquartile range of $139,000–$163,500. The low end sits just under the median and the high end just above the top of the range. | `[grounded]` the recruiter's report, n=2,310, not independently checked; `[inferred]` that the posted salary is base |
| Scope norm | The report says Senior typically means 5–8 years and ownership of one domain's pipelines with no direct reports. Your 6 years and this posting both fit that. | `[grounded]` report as supplied; `[inferred]` for the posting match |
| Stage fit | Series C falls inside the report's Series B–D cohort. | `[grounded]` report cohort and About text |
| Unknowns | Equity terms, team size and reporting line, who owns data contracts today, hiring manager (none named) | `[grounded]` JD and posting silence |
| Contradictions | None between the JD and the About text as pasted. Neither was checked live. | `[grounded]` the two pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you are or what working arrangement you need, so the term can't be checked. Confidence grades your statement of the constraint, and none was given. | `[grounded]` JD; no candidate constraint provided | Closing question R1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The range is posted, but your pay floor wasn't given, so the gate can't be met or failed yet. | `[grounded]` JD; no candidate constraint provided | Closing question R2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. That is a typed background with no artifact yet, so it stays at `medium`. | `[grounded]` your background message | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. "Strong" is the JD's word, and depth isn't evidenced beyond that statement. | `[grounded]` your background message | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake. Snowflake is a cloud warehouse, so the requirement as written is met. BigQuery is carried separately in R8. | `[grounded]` your background message | A sanitized lineage graph or repo excerpt would raise this to `high` |
| R6 | Airflow or similar orchestration | must_have | direct | medium | none | You state "Airflow for orchestration". Whether you authored the DAGs or ran them isn't stated, so I read it as used, not built. | `[grounded]` your background message | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite, which is specific and owned. There is no artifact yet. | `[grounded]` your background message | A sanitized suite config would raise this to `high` |
| R8 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | The dbt modelling and SQL carry over from your Snowflake work. The limit is that you have never used BigQuery, so its platform-specific tuning and cost behavior are unexercised. | `[inferred]` adjacency from your stated Snowflake and dbt work; `[generic]` that warehouse-specific tuning differs by platform | Gap queue G1 |
| R9 | Ingestion from the app and CRM | important | unclear | none | discovery | Your background doesn't mention ingestion. Airflow is a thread but not evidence, so I take the lower band. | `[grounded]` silence in your message | Closing question G2 |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Your background doesn't mention contracts. The Great Expectations suite is adjacent work, but a test suite is not a contract. | `[grounded]` silence in your message | Not asked this turn; see the upgrade menu |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Six years of dbt on Snowflake. BigQuery was never used. | It is the one named platform in the mandate, so it is the likeliest objection. | A personal or sandbox dbt project on BigQuery; any BigQuery exposure through analysts or other teams | A small public repo with dbt models on a public BigQuery dataset | `[inferred]` bridge from your stated work; `[generic]` that a named platform you haven't used is a likely objection |
| G2 | Ingestion from app and CRM (R9, important) | discovery | The message doesn't say what fed your pipelines. | It is the first item in the mandate, and an answer could move R9 to `adjacent` or `direct`. | Loading application database exports or CRM data (Salesforce, HubSpot) into the warehouse; owning a connector or an incremental-load pattern | A pipeline diagram or DAG screenshot, sanitized | `[grounded]` your message's silence; `[inferred]` that an answer could move the row |
| G3 | Data contracts (R10, important) | discovery | The message doesn't mention contracts. | The JD names them as something analysts depend on. | Agreeing schemas or freshness expectations with analysts; failing a pipeline on a contract breach; documenting model guarantees | A schema or contract doc, dbt `contract` configs, or a Great Expectations suite tied to a consumer | `[grounded]` your message's silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | I could not run the search that would have checked this, so it is unverified, not contradicted. Unverified employers may be too small or new to have a footprint, the posting may be stale, or it may not represent a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay sits at market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range straddles the report's median and ends just above its interquartile top, so there is no seniority-pay mismatch. | `[grounded]` JD and the report you supplied; `[inferred]` that the posted salary is base | Where in the range would someone with six years of experience be placed? | noted |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | The type, size, vesting and strike price are all unstated, so the equity can't be valued. | `[inferred]` from the posting's silence | What are the equity type, size, vesting schedule and strike price? | unresolved |
| RR4 | Team, reporting line and ownership unknown | unknown | — | The posting names no hiring manager (your note); the JD gives no team size or first-year outcomes. | You may be the only data engineer or one of a team. The report's norm is one domain with no direct reports, so a wider scope would be worth a conversation. | `[inferred]` from the JD's silence against `[grounded]` report scope | Who would I report to, how many data engineers are on the team, and which of ingestion, warehouse and contracts would I own on day one? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on Pellucid's own careers page before spending effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with the dbt project (about 180 models on Snowflake) and the Great Expectations suite you set up. State BigQuery as new to you, with the Snowflake and dbt work as the bridge. | see R5, R7, R8 | `[grounded]` your stated work | pending your approval |
| A3 | Optionally build a small dbt-on-BigQuery project on a public dataset | see G1 | `[inferred]` from the gap | pending your approval |
| A4 | Ask the RR1, RR3 and RR4 questions verbatim in the loop, and ask where in the range you'd sit (RR2) | The register doubles as interview preparation. | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches (the company's Denver careers page for this role, and its Series C announcement) were refused because web search permission wasn't granted. They would have checked that the company exists as described and that the posting is live. This is why RR1 stands. |
| 2. Role-family sweep | skipped | The Datawright report you supplied is in hand and fixes the market calibration, the scope norm and RR2. |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there is no query to form. |

I'll offer the quickest next step: if you grant web search, I can rerun target 1 and clear or confirm RR1. That would be the single most useful check, since the rest of the case is sound on what you gave me.

I can also write this up as `tuesday-dossier.md` if you'd like to carry it to later steps.

## Upgrade menu

- Web search permission → RR1 closes or firms up, and the decision may move from `conditional_go` to `go`. A deeper pass (funding and leadership churn, recent news; up to 5 more searches and 2 more fetches) is available too, and I'd run it only if you say so.
- Your location and pay floor → R1 and R2 close, and the decision becomes `go` or `no_go` on those gates.
- An answer to G2, or an example for G3 → R9 and R10 move off `unclear`.
- A sanitized lineage graph, repo link or Great Expectations config → R5 and R7 can reach `high`.
- A small BigQuery project → R8's bridge narrows.
- The hiring manager's name → role reality's scope read and the plan's lead story sharpen.
- Equity details → RR3 closes.

R1 — Where are you based, and do remote (US) or the Denver office both work for you?

R2 — What base salary is your floor, and does $148,000 clear it?

G2 — For the pipelines you ran, which source systems fed them (app databases, CRM, other), and which parts of ingestion did you personally own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.