Checking the posting and company page are live, then I'll write the assessment.
# Job Underwriting Assessment: Senior Data Engineer at Pellucid Learning

## Decision snapshot

**Is it worth it? Yes, apply. R1 and R2, both hard gates, still need confirming. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery); unclear: R10 (ingestion from app and CRM), R11 (data contracts)

R9 (`medium`) — Snowflake and dbt carry over, the BigQuery limit named; R10 — what fed your pipelines is not yet described; R11 — contracts not mentioned.

**Opportunity ledger.** Sound on what is stated: the posted band sits at or above the market median you supplied (RR1). Equity terms (RR2), team shape (RR3), the funding figure's source (RR4) and on-call expectations (RR5) are unanswered.

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 confirmed met against your own location and pay floor; (2) the BigQuery gap is framed honestly as adjacent, never as BigQuery experience (R9); (3) team shape and ownership verify in the loop (RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company About page, fetched via search result |
| Mandate | Build and run reporting pipelines: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` posting, fetched live |
| Compensation | $148,000–$166,000 plus equity; equity terms not stated | `[grounded]` posting |
| Location | Remote (US) or Denver office | `[grounded]` posting |
| Scope read | One domain of pipelines (reporting), no direct reports mentioned; a single owner of the platform's reporting data is plausible | `[inferred]` from the posting's "build and run" wording and its silence on reports or team |
| Market calibration | The posted band's low end sits just below the report's Series B–D senior base median of $151,000, and its top sits above the interquartile range's upper end of $163,500. The report puts "Senior" at 5–8 years, and your 6 sits inside that. The report's typical scope is one domain's pipelines with no direct reports, which matches the posting's wording. This is the market's band, never this employer's offer | `[grounded]` Datawright 2026 report (n=2,310, supplied by your recruiter, not independently checked) and posting; `[inferred]` that the posting's "salary" means base |
| Unknowns | Hiring manager and team size; equity terms; on-call duty; whether you would be the first data engineer | — |
| Contradictions | None between what you pasted and the live pages | `[grounded]` careers page shows "Accepting applications" with the same text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | The posting states the term. Your location and work constraints have not been given, so nothing settles it | `[grounded]` posting; your constraints not given | Question R1 below |
| R2 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | The band is stated. Your pay floor has not been given | `[grounded]` posting; your floor not given | Question R2 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. It is a stated claim with no inspectable artifact, so `medium`; expect a probe on scope | `[grounded]` your message | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. "Strong" is the posting's word, and daily use is what you evidenced; a code sample or repo would raise the band | `[grounded]` your message | Offer a sanitized sample (upgrade menu) |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models. Specific, with no artifact inspected yet | `[grounded]` your message | Sanitized lineage graph or project docs would raise to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. The posting asks for "a cloud warehouse", and the BigQuery-specific ask is carried separately in R9 | `[grounded]` your message and posting | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow for orchestration; the posting names Airflow | `[grounded]` your message and posting | none |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. The posting names no tool, so the tool difference is immaterial | `[grounded]` your message | A sanitized expectation suite would raise to `high` |
| R9 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | The posting names BigQuery in the role description, not in its requirements list. Your dbt and Snowflake work carries over. Limit: you have not used BigQuery, so its cost model, partitioning and clustering choices, and access setup are unexercised | `[grounded]` your message, no BigQuery use; `[generic]` that warehouses differ in these respects | See G1 |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | You describe orchestration and testing, not which source systems fed your pipelines | `[grounded]` your message is silent on sources | See G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Contracts are not mentioned. Your Great Expectations suite is related work, but tests are not contracts, so it is a lead and not a claim | `[grounded]` your message is silent; `[inferred]` the GE suite as a lead | Question G3 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Strong dbt and Snowflake, with no BigQuery use | It is the one named platform difference, so it is the likeliest probe | A personal or side project on BigQuery; a warehouse migration you contributed to; Snowflake cost or performance tuning that maps onto BigQuery's choices | A small dbt project run against a BigQuery project of your own | `[grounded]` no BigQuery use stated; `[generic]` that hands-on work narrows the stated limit |
| G2 | App and CRM ingestion (R10, important) | discovery | Pipelines and orchestration are described, but not their sources | The posting lists ingestion first among its responsibilities | Product event data loaded to the warehouse; a CRM or billing-system sync; a third-party API extract | A pipeline diagram or DAG screenshot, sanitized | `[grounded]` your message silent on sources |
| G3 | Data contracts (R11, important) | discovery | Nothing stated about agreements with data consumers | The posting names contracts as something analysts depend on | Agreed schemas or SLAs with downstream teams; schema-change notices; tests that blocked a breaking change | A contract doc, a schema-change policy, or a test that enforced one | `[grounded]` your message silent; `[inferred]` the GE suite as a possible thread |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posted pay against market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The stated band is concrete and sits at or above the supplied market median | `[grounded]` posting against the Datawright report | Is the range base salary, and is there flexibility within it? | noted |
| RR2 | Equity terms unstated | unknown | — | "plus equity" | The grant size, vesting and strike terms may be material to total pay | `[inferred]` from the posting naming equity with no terms | What is the equity grant range and vesting schedule for this level? | unresolved |
| RR3 | Team shape and ownership unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You may be the sole data engineer, or one of several; the posting does not say | `[inferred]` from "build and run" with no team described | Who does this role report to, and how many data engineers are on the team? | unresolved |
| RR4 | Funding figure from the company's own page only | unknown | — | "Series C ($52M, February 2026)" | The stated round is plausible for the headcount, but my one search returned only the company's own page, so it is unconfirmed independently | `[grounded]` search result was the company's About page only | How much runway does the Series C give, and what is the hiring plan for the data team? | unresolved |
| RR5 | On-call expectations unstated | unknown | — | "Build and run" | "Run" may include supporting pipelines out of hours | `[inferred]` from the word "run" against the posting's silence on on-call | Is there an on-call rotation for pipelines, and how often are incidents out of hours? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume's top section with three items in your own words: dbt project on Snowflake, about 180 models; Airflow orchestration; the Great Expectations suite you set up | R5, R7, R8 | `[grounded]` your message | `resume_edits_pending_approval` |
| E2 | Name Snowflake as the warehouse you used, and do not list BigQuery as a skill | R9 | `[grounded]` your message | `resume_edits_pending_approval` |
| W1 | Optional: a small dbt project run against a BigQuery project of your own, so you can speak to the differences first-hand | G1 | `[generic]` hands-on work narrows the stated limit | pending your approval |
| Q1 | Ask RR2, RR3, RR4 and RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Ask the recruiter about team shape (RR3) before investing in the loop | R1, R2 and RR3 are cheap to settle early | `[grounded]` RR3 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer): live, "Accepting applications", same text as you pasted. Searched "Pellucid Learning Denver tutoring Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about), matching your paste. Moved: the contradictions row (none) and RR4 (funding rests on the company's own page) |
| 2. Role-family sweep | skipped | Your Datawright report is in hand and fixes the market calibration line and the pay comparison in RR1 |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no query to form |

One-sentence dossier offer: I can save this as `tuesday-dossier.md` so later sessions start from it, whenever you want it.

## Upgrade menu

- Your base-pay floor and where you are based → R1 and R2 close, and the decision likely simplifies to `go` or `no_go`.
- A sanitized dbt lineage graph or project docs, a Great Expectations suite, or a repo with Python and SQL → R4, R5 and R8 can move to `high`.
- An answer on what fed your pipelines (G2) → R10 resolves.
- The recruiter's answer on team shape, equity and on-call → RR2, RR3 and RR5 close.
- The hiring manager's name → role reality's scope read, and which verified story the plan leads with for that reader.
- A deeper research pass on Pellucid Learning (independent confirmation of funding, leadership changes, public employee reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

R1 — Are you based in the US, and would you work remote, or from Denver if needed?
R2 — Does $148,000 base clear your pay floor, and what is the floor?
G3 — Have you agreed schemas, SLAs or change notices with the people consuming your data, and what did you own versus the team?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.