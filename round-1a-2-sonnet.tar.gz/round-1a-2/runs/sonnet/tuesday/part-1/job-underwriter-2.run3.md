Search permission was declined, so this runs on your resume and the JD alone.

# Underwriting: Product Manager, Platform APIs at Quartzline

## Decision snapshot

**No, you're not wasting your time on the pivot, but this posting is a stretch. R1a, a `must_have`, has no titled evidence, and R3 and R4a are your strongest rows. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1b (PM-type work without the title), R2 (shipped API or platform product), R6 (own the roadmap) · unclear: R4b (Sales and support stakeholders) · absent: R1a (3+ years PM experience, titled)
- `important` — adjacent: R8 (Launches with sales and support) · unclear: R5 (Agile delivery), R7 (Adoption metrics)

R1a — no titled PM years; R1b, R2, R6 — credible bridges, limits named; R4b, R5, R7 — the resume is silent, and an answer could move them.

**Opportunity ledger.** The role reads as defined in scope (RR4). The employer is unverified because no search ran (RR1), and compensation, location and roadmap authority are unstated (RR2, RR3). Whether adjacent experience can stand in for the experience requirement is unknown (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Quartzline confirms it will weigh adjacent product work against R1a (RR5); (2) your confirmed work on R2, R6 and R7 turns out to be specific, for instance the triage tool in question 1; (3) the employer verifies as described (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B, as the posting describes itself | `[grounded]` JD header; not independently verified |
| Mandate | Own the roadmap of a partner-facing API platform; discovery with integration partners; specs; delivery with two engineering squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| Scope read | One product surface with two squads, which reads as a single-product IC role and not a group lead | `[inferred]` from the squad count and the absence of any direct-report language |
| First 90 days / first year | Not stated | `[grounded]` JD silent |
| Market calibration | Not run: the role-family search was refused, so no band is offered and nothing is claimed about pay or title norms | — |
| Unknowns | Location and work arrangement, compensation, roadmap authority versus sales and leadership, whether "3+ years" is flexible | `[grounded]` JD silent on each |
| Contradictions | None found between the JD and your resume | `[grounded]` both read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience (titled) | must_have | absent | none | capability | You have never held a PM title, so there is no titled evidence. A length-of-experience requirement is not a gate and is graded on fit, and the work near it sits in R1b. Postings that mark this must-have are often read literally at the first screen | `[grounded]` your statement; `[generic]` on literal reading | Ask whether adjacent work counts (RR5). No wording can create titled years |
| R1b | Discovery with integration partners; writing specs | must_have | adjacent | medium | transferability | Scoping workshops, requirements documents and quarterly roadmap-input sessions with clients are close to discovery. Limit: the documents scoped client implementations, and no evidence shows specs for engineering squads building the product | `[grounded]` resume; `[inferred]` on the limit, from the resume's silence | Lead with these bullets in your own words (E1); see G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your vendor's REST APIs, so you shipped integrations, not the API product itself. Limit: you worked from the consuming side of the API | `[grounded]` resume; `[inferred]` on the limit | Question 1 (triage tool, unconfirmed lead); see G2 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI reading, plus integration architecture work, are specific and plausible. Limit: no inspectable artifact yet, so expect a probe | `[grounded]` resume | none |
| R4a | Stakeholder management with engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and PMs, and ran client workshops through go-live. Limit: no outcome artifact | `[grounded]` resume | none |
| R4b | Stakeholder management with sales and support | must_have | unclear | none | discovery | The resume is silent on sales and support | `[grounded]` resume silence | Queue G3; not asked this turn |
| R5 | Agile delivery | important | unclear | none | discovery | UAT and go-live are delivery work, but nothing states a sprint or squad process | `[grounded]` resume silence on method | Queue G4; not asked this turn |
| R6 | Own the roadmap | must_have | adjacent | medium | transferability | You collected client input for product, which is input, not prioritization. Limit: no evidence of deciding what got built | `[grounded]` resume | Question 2; see G5 |
| R7 | Define and track adoption metrics | important | unclear | none | discovery | No metric work is stated | `[grounded]` resume silence | Question 2; see G6 |
| R8 | Launches with sales and support | important | adjacent | low | transferability | Client go-lives are launches of a kind. Limit: no stated sales or support partner. Low, not medium, because the link is indirect | `[inferred]` from go-live work | Queue G7 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | PM work without the title (R1a, R1b) | capability | No titled years; adjacent work present | R1a is a `must_have` and decides whether this role is reachable | Product decisions you drove outside a PM title; a backlog you ranked; a feature you specified for your own engineers | A spec, a roadmap-input summary, a feature request you carried to ship | `[grounded]` resume; `[generic]` that titled years are read literally |
| G2 | Shipped API or platform product (R2) | transferability | Integrations shipped, product not | A `must_have`; the limit is which side of the API you stood on | An internal tool others used; your integration playbook's adoption; a client-facing tool you specified | The triage tool, if confirmed, or playbook usage notes | `[grounded]` resume; `[inferred]` bridge |
| G3 | Sales and support stakeholders (R4b) | discovery | Resume silent | A `must_have` half left unevidenced | Joint client calls with sales; support escalations you resolved with product | A launch note, an escalation log excerpt | `[grounded]` resume silence |
| G4 | Agile delivery (R5) | discovery | Resume silent on method | An `important` row cheap to close if true | Sprint reviews with client engineers; backlog grooming on custom builds | A sprint board screenshot, a ticket export | `[grounded]` resume silence |
| G5 | Roadmap ownership (R6) | transferability | Input collected, ownership not shown | A `must_have`; the bridge needs its limit stated | Choosing which client requests went to product; shaping a quarter's priorities | A summary of the roadmap-input sessions | `[grounded]` resume; `[inferred]` bridge |
| G6 | Adoption metrics (R7) | discovery | No metric work stated | The role is measured on adoption | Tracking playbook usage; integration time-to-go-live; request volumes | A dashboard, a SQL query you wrote for this | `[grounded]` resume silence |
| G7 | Launch coordination with sales and support (R8) | transferability | Go-lives, no sales or support partner stated | An `important` row sitting at `low` | Go-live plans that involved sales or support | A go-live checklist | `[inferred]` from go-live work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. No search ran, so this is unverified, not failed | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who I would be interviewing with? | unresolved |
| RR2 | Compensation, location and work arrangement unstated | unknown | — | JD gives none | They may sit outside your floor or constraints, which are not yet given | `[inferred]` from the JD's silence | What is the budgeted salary range, and where is the role based or expected to work? | unresolved |
| RR3 | Roadmap authority unstated | unknown | — | "Own the roadmap" | Ownership may stop at recommending, with priorities set by sales or leadership | `[inferred]` from the JD's silence on decision rights | Which roadmap decisions does this role make alone, and which go to leadership? | unresolved |
| RR4 | Scope and delivery shape stated | positive_signal | — | "run discovery … drive delivery with two engineering squads; define and track adoption metrics" | The mandate looks concrete: one platform, two squads, a named metric type | `[grounded]` JD | Who owns the adoption metrics today? | noted |
| RR5 | Flexibility on the experience requirement unknown | unknown | — | "3+ years product management experience (must-have)" | The bar may bend for adjacent experience, or may be screened literally | `[inferred]` from the JD's wording; `[generic]` that practice varies | Would you consider someone with extensive product-adjacent work, such as roadmap input and API integration leadership, in place of titled PM years? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move three existing bullets to the top, wording unchanged: "Led 30+ client integrations of our REST APIs end to end"; "Ran quarterly roadmap-input sessions collecting client feedback for product"; "Wrote the internal integration playbook the whole team uses". Do not retitle yourself or add product-ownership language | R1b, R2, R6; each clause traces to your own sentence | `[grounded]` resume | resume_edits_pending_approval |
| Q1 | Put the RR5 question to the recruiter before investing in the full process | R1a; it decides whether the application is worth the effort | `[grounded]` R1a | pending your approval |
| A1 | Ask a Quartzline product contact for an introduction before applying cold | Referrals are a common route past a literal screen, a pattern and not a fact about this employer | `[generic]` role-family pattern | pending your approval |
| A2 | Also consider roles titled for technical or platform product work, or a move inside your current vendor | Roles that explicitly want your integration background may weigh R1a less; this is a pattern, not a finding about any employer | `[generic]` pattern | pending your approval |

## Evidence status

Verified: none yet. Unverified lead: agent memory suggests you once built an internal request-triage tool that support agents adopted. It is unconfirmed, so it prompts a question and is not counted as evidence. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused. It would have confirmed whether Quartzline exists as described and the posting is live; RR1 stands as unverified |
| 2. Role-family sweep | unavailable | The search was refused. It would have fed the market calibration row and the pay check in RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

If you'd like, I can write all of this up as `tuesday-dossier.md` so it carries into later steps, and nothing is saved unless you say so.

## Upgrade menu

- Search permission, then the first two targets run → RR1 verifies or fails and the market calibration row appears.
- A confirmed answer on the triage tool → R2 and R1b firm up.
- Your salary floor, location, and any other non-negotiables → hard-gate checks become real.
- A spec, a roadmap-input summary, or a playbook usage count → R1b, R6 or R7 rises toward `high`.
- A hiring manager's name → the application plan's positioning for that reader.

**Questions**

1. G2 — Agent memory suggests you built a request-triage tool that support agents adopted. Is that right? If so, what did you own, who used it, and how did you know it worked?
2. G5, G6 — Have you ever decided which client requests went to product, or tracked a number that showed whether something was adopted, such as playbook use or time to go-live? What was it?
3. RR2 — Do you have a salary floor, a location or remote requirement, or authorization limits that this role has to meet?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.