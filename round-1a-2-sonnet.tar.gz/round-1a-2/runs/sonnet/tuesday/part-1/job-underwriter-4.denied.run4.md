## Decision snapshot

**Yes, apply, once Brindlemoor checks out as a real, live employer. Status: `conditional_go`.** The pet-insurance and no-management gaps you flagged don't stop you. The JD asks for neither as a requirement (R9 is `preferred` and `adjacent`; see Role reality for direct reports).

**Fit ledger.**

- `hard_gate`: unclear: R10 (Fully remote (UK))
- `must_have`: direct: R1, R2, R5, R6, R7 · adjacent: R3 (Design and read price tests), R4a (Recommendations to underwriting) · unclear: R4b (Recommendations to product)
- `preferred`: direct: R8 · adjacent: R9 (Pet-insurance domain)

R3 and R4a: your wording says "ran" and "presented", the JD says "design" and "recommend"; R4b: no product-side evidence yet; R9: a credible bridge, its limit named.

**Opportunity ledger.** Sound on its face but unverified from here: the employer is not established (RR1), pay is unstated (RR2), team and tooling are unstated (RR3), and direct reports are unstated (RR4). One entry runs the other way: the scope is concretely stated (RR5).

- **Hard gates:** none failed; unconfirmed: R10 (Fully remote (UK)); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and the posting verify (RR1); (2) the remote-UK term works for you (R10); (3) the product-side recommendation gap is closed with evidence or carried as a minor risk (R4b).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; not verified (see Evidence status) | `[grounded]` JD header |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | Odile Varga, Director of Pricing | `[grounded]` your message |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | A single-product analytics seat that closes the loop from model to test to recommendation | `[inferred]` from the JD's three stated duties |
| Market calibration | Not done: the searches were refused, so no pay band or title norm is given | `[grounded]` search refused this session |
| Unknowns | Salary; team size and tooling; whether the post has direct reports (the JD lists none, so people management is not a stated requirement) | `[grounded]` JD silence on all three |
| Contradictions | None visible inside the JD; no careers page was compared | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Stated 5 years of pricing analytics at a UK motor insurer, 2 as senior; no document inspected | `[grounded]` your background | none |
| R2 | Build and monitor rating models | must_have | direct | medium | none | Stated: built and maintained the GLM rating model for the young-driver book. Carried as "maintained", not more | `[grounded]` your background | none |
| R3 | Design and read price tests | must_have | adjacent | medium | discovery | Stated: ran 14 price tests last year with underwriting. "Ran" does not show you designed them, so the lower reading is taken | `[grounded]` your background | G1 |
| R4a | Recommendations for underwriting | must_have | adjacent | medium | discovery | You work with underwriting and present the quarterly review to its head; neither says you made recommendations | `[grounded]` your background | G1 |
| R4b | Recommendations for product | must_have | unclear | low | discovery | Nothing stated touches a product team | `[grounded]` silence in your background | G2 |
| R5 | Strong SQL and Python | must_have | direct | medium | none | Stated: both daily | `[grounded]` your background | none; a repo or sanitised script would raise it to high |
| R6 | GLM experience | must_have | direct | medium | none | Same GLM build as R2 | `[grounded]` your background | none |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Stated: you present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background | none |
| R9 | Pet-insurance knowledge (implied by the product you would own, not stated) | preferred | adjacent | low | transferability | Bridge: the same GLM rating and testing work, in a different line. Limit: you have not worked on pet rating factors or pet claims. Pet-specific factors usually differ from motor, so expect a probe | `[inferred]` from the JD naming the product; `[generic]` that factors differ | Name the bridge and its limit in the application |
| R10 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You have not stated your location or right to work, so the gate is not established | `[grounded]` JD; your constraints not given | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Designing tests and making recommendations (R3, R4a, must_have) | discovery | 14 tests run with underwriting and a quarterly review presented; design ownership and the recommendation step are not stated | Two must-haves sit at `adjacent`; confirming them moves both toward `direct` | Writing the test hypothesis or segmentation; setting sample size or duration; defining the success metric; a write-up that changed a rate or rule | A test-design doc, a results deck, a sanitised summary | `[grounded]` your wording ("ran", "present"); `[generic]` that interviews for this kind of role probe design ownership |
| G2 | Recommendations to product (R4b, must_have) | discovery | Nothing in your background touches a product team | The JD names product as a second audience; an unevidenced must-have could hold the decision at `conditional_go` | Pricing input to new cover, optional extras, or a rating-structure change; work with a commercial or product owner on a rate change | A product paper, a rate-change proposal, a deck | `[grounded]` silence in your background |
| G3 | Remote UK eligibility (R10, hard_gate) | hard_gate | The JD's term is clear; your location and right to work are not stated | A gate that is not established is not met | Not applicable; this is a yes-or-no fact | None needed | `[grounded]` JD term; your constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small for a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay unstated | unknown | — | none: the JD as pasted has no pay figure | The figure may be withheld or simply not in what you pasted | `[inferred]` from the pasted JD's silence | What salary band is budgeted for this post? | unresolved |
| RR3 | Team, data and tooling unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Own" may mean sole analyst, without data-engineering or tooling support | `[inferred]` from "own" set against the JD's silence on support | Who else sits in pricing, and what data and modelling tooling does the role have? | unresolved |
| RR4 | Direct reports unstated | unknown | — | "Senior Pricing Analyst" | The post may or may not carry people management now or as a path | `[inferred]` from the JD listing no reports | Does this role have, or expect to grow, direct reports? | unresolved |
| RR5 | Scope concretely stated | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations for underwriting and product" | The job has a defined loop from model to test to recommendation | `[grounded]` JD | What would success in this role look like at twelve months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify Brindlemoor: find its careers page yourself, and check that the recruiter's email domain matches the company's site | RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead the CV with the GLM rating model, the 14 price tests and the quarterly review, in your own wording ("ran", "presented") until G1 confirms more | R2, R3, R6, R7 | `[grounded]` your background | pending your approval |
| E2 | Name the pet bridge honestly as adjacent: motor GLM work, no pet-specific rating factors yet | R9 | `[inferred]` bridge from R2 and R6 | pending your approval |
| Q1 | Ask RR2, RR3 and RR4 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched for Brindlemoor's careers listing; the search was refused. It would have confirmed the employer and the live posting, moving role reality's organization row and RR1 |
| 2. Role-family sweep | unavailable | Searched for senior pricing analyst pet-insurance salary; the search was refused. It would have given the market calibration and a pay band for RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched for Odile Varga's public professional footprint; the search was refused. It would have informed the scope read and which story the plan leads with |

I'm offering one next step: say the word and I'll draft `tuesday-dossier.md` from this assessment.

## Upgrade menu

- Search permission, so the three research targets can run → RR1 may clear or confirm, a pay band for RR2, and a positioning read for Odile Varga.
- An answer to G1, plus a test-design doc or results deck → R3 and R4a toward `direct`.
- An answer to G2 → R4b closes or is carried as a minor risk.
- Your location and right to work (G3) → R10 closes. A pay floor or other non-negotiables → the pay and schedule gates get checked.
- A sanitised SQL or Python sample → R5 toward `high`.

**Questions**

G1 — Across your 14 price tests, which did you personally design (hypothesis, segmentation, sample size, success metric), and did any write-up of yours change what underwriting did?

G2 — Have you ever taken pricing results to a product or commercial team, for example for a rate change, new cover or a rating-structure change? What did you own?

G3 — Are you based in the UK with the right to work there, and do you have any non-negotiables (pay floor, hours, travel) I should check this role against?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.