I've finished reading the job-underwriter playbook and its reference files. Next I'm loading the search tool to check that Quartzline exists as described, then I'll write the assessment.
**Nadia, this is not a waste of your time, but this posting is a stretch with one real obstacle.** R3 is `direct`. R1b, R2, R4, R6, R7 and R9 are `adjacent`. R1a, the literal "3+ years as a PM", is `absent` because you've never held the title. Status: `conditional_go`, meaning apply on the conditions below, with bounded effort.

Two things limit this assessment:
- Web search was not permitted, so nothing about Quartzline is verified. Everything below rests on the posting and resume summary you pasted.
- Your resume is a pasted summary, so every claim from it is capped at `medium`.

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R3 · adjacent: R1b (PM-adjacent work toward the 3+ years), R2 (shipped API or platform products), R4 (stakeholder management) · unclear: R5 (agile delivery) · absent: R1a (3+ years as a PM)
- `important` — adjacent: R6 (discovery with integration partners), R7 (specs and delivery with two squads), R9 (own the roadmap) · unclear: R8 (adoption metrics)

R1a — no PM title held, per your own statement; R1b, R2 and R9 — credible bridges, limits named in the map; R3 (`medium`) — tools stated, no artifact yet; R5 and R8 — the resume is silent.

**Opportunity ledger.** The scope is concrete (RR4), but the employer is unverified (RR1) and pay is unstated (RR3). How strictly the three years are applied (RR2) and who else sits in product (RR5) are unknowns.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Quartzline and the live posting verify (RR1).
  2. The recruiter confirms that equivalent product work counts toward the three years, before you invest in a full application (R1a, R1b, RR2).
  3. Your bridge is framed as adjacent work, never as PM ownership (R1b, R2, R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B. Not checked against any outside source | `[grounded]` JD header as pasted |
| Mandate | Own the roadmap of a partner-facing API platform; run partner discovery; write specs; drive two engineering squads; define adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| First-year outcomes | Not stated; the JD lists duties, not outcomes | `[grounded]` JD silent |
| Seniority read | "3+ years" as a must-have points to a mid-level post rather than an entry-level one | `[inferred]` from the stated years against two squads of scope |
| Pivot path | Moving from solutions or implementation work into API product management is a commonly travelled route, because the role leans on integration and customer knowledge | `[generic]` role-family pattern, not a claim about this employer |
| Market calibration | Not run: the role-family sweep was refused | — |
| Unknowns | Salary, reporting line, decision rights over the roadmap, how the metrics are defined | `[grounded]` JD silent |
| Contradictions | None inside the JD; no outside check ran | `[grounded]` JD as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years of PM experience, read as time in a PM role | must_have | absent | none | capability | You've never held a PM title. The JD doesn't say the years must be titled, so this is the literal reading and R1b is the work-equivalent one. A posting that tiers years as a must-have is often screened on title | `[grounded]` your statement; `[generic]` on screening practice | Closure path: ask whether equivalent work counts (RR2); no question to you |
| R1b | PM-adjacent work within those years: requirements, roadmap input, cross-functional coordination | must_have | adjacent | medium | transferability | You wrote requirements documents, ran quarterly roadmap-input sessions "collecting client feedback for product", and coordinated engineers and PMs. Limit: you supplied input to product, and nothing stated shows you made prioritisation calls | `[grounded]` resume summary | G3 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ end-to-end integrations of your employer's REST APIs and wrote the integration playbook. Limit: you integrated and delivered someone else's API; nothing stated shows you owned an API product | `[grounded]` resume summary | G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI specs, plus 30+ REST integrations. Confirmed and specific, but no inspectable artifact yet, so expect a probe | `[grounded]` resume summary | none |
| R4 | Stakeholder management across engineering, sales and customers | must_have | adjacent | medium | discovery | Engineers, client engineers and PMs are shown, and so are clients. Sales and support are not mentioned | `[grounded]` resume summary, silent on sales and support | Fold into G3's answer if sales or support appear |
| R5 | Agile delivery | must_have | unclear | low | discovery | You ran UAT and go-live, which is delivery, but the resume says nothing on sprints or squads | `[grounded]` resume silent | G2 |
| R6 | Run discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops with clients on integrations. Limit: that was discovery for implementations, not for a product roadmap | `[grounded]` resume summary | none |
| R7 | Write specs and drive delivery with two engineering squads | important | adjacent | medium | transferability | Requirements documents, integration architecture and UAT. Limit: no stated sprint-level work with squads | `[grounded]` resume summary | W1 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | The resume is silent. A prior-conversation memory about a support-agent tool is unconfirmed and prompts a question only | `[grounded]` resume silent; memory lead unconfirmed | G1 |
| R9 | Own the roadmap for the API platform | important | adjacent | medium | transferability | Roadmap-input sessions are shown. Limit: collecting input is not setting priorities, and nothing stated shows you set any | `[grounded]` resume summary | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owned product, with adoption (R2, R8) | discovery | The resume is silent. A prior conversation suggested you built an internal request-triage tool that support agents adopted; that is unconfirmed | It could be your one example of building something others used, and of tracking whether they did | A triage tool, dashboard or script that a team adopted; usage counts or before/after numbers; deciding what it did and did not do | A screenshot, a usage figure, an announcement note | `[grounded]` resume silent; `[inferred]` that this could lift R2 and R8 |
| G2 | Agile delivery (R5, must_have) | discovery | UAT and go-live shown; no sprint or squad work stated | A must-have at `unclear` is cheap to close if the experience exists | Sprint planning or standups with client or internal engineers on custom builds; backlog grooming; release trains | A sprint board or release note, sanitised | `[grounded]` resume silent |
| G3 | Prioritisation ownership (R1b, R9, R4) | discovery | Input sessions are shown; no decisions are stated | This is the hinge between "gathered feedback" and "owned a roadmap" | Deciding which client request went into a build; saying no to a custom request; ranking asks across clients; sales or support involvement in launches | A readout from a roadmap-input session showing what changed | `[grounded]` resume summary; `[generic]` that roadmap ownership is the role's core |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small for a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Strictness of the 3+ years unknown | unknown | — | "3+ years product management experience (must-have)" | It may be screened on title, or it may accept equivalent product work | `[generic]` screening pattern for titled-years requirements | Would several years of product-facing work in a solutions or implementation role count toward the three years? | unresolved |
| RR3 | Salary unstated | unknown | — | Silent: no compensation in the posting as pasted | The pasted text may omit a band the full posting states | `[grounded]` JD as pasted | What salary is budgeted for this role? | unresolved |
| RR4 | Scope and delivery partners stated concretely | positive_signal | — | "drive delivery with two engineering squads" | Duties are specific rather than vague | `[grounded]` JD | Which outcomes is this role measured on in its first year? | noted |
| RR5 | Reporting line and product peers unknown | unknown | — | "Own the roadmap for our partner-facing API platform" | A company this size may have a small product team, so mentorship for a first PM role is an open question | `[generic]` pattern for companies of this size | Who does this role report to, and who else in product would I work with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | `resume_edits_pending_approval`: move "Ran quarterly roadmap-input sessions collecting client feedback for product" and "Wrote the internal integration playbook the whole team uses" into the top third of your resume, in your own wording. No PM title or ownership language is added | See R1b, R7, R9 | `[grounded]` your resume lines | pending your approval |
| W1 | A one-page sanitised spec for a change you would make to a partner API, as a work sample. State plainly that it is a sample | See R7, R9 | `[inferred]` from the adjacent limit on R7 | pending your approval |
| Q1 | Ask RR2's question of the recruiter before building a full application | See R1a, RR2 | `[grounded]` register | pending your approval |
| A1 | Seek an introduction through someone at Quartzline or an integration partner before applying cold | Referral routes often get a human reading before a title screen | `[generic]` pattern | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Quartzline logistics technology company careers Product Manager Platform APIs" was refused. It would have moved RR1 and role reality's contradictions row |
| 2. Role-family sweep | unavailable | The search "platform API product manager salary range B2B SaaS Series B requirements" was refused. It would have moved market calibration and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer, upgrade menu and questions

I can also save this as a `tuesday-dossier.md` if you'd like to reuse it later.

**Upgrade menu**
- Allowing search would let me check Quartzline's site and careers page (RR1) and run the role-family sweep for market calibration and a salary band. A deeper pass, covering funding, leadership churn and recent news, would add up to 5 more searches and 2 more fetches.
- A sanitised excerpt of your integration playbook or a requirements document would lift R2 and R7.
- A usage figure for the triage tool, if it was yours, would lift R8.
- A roadmap-input readout showing what changed in product would lift R9.
- The hiring manager's name would let me read their public footprint for the application plan.
- Your non-negotiables (pay floor, location, work authorisation) would turn the hard-gates line from unknown into checked.

**Questions**
- G1 — Did you build the request-triage tool that support agents adopted? If so, what did you own, who used it, and how did you know they used it?
- G3 — Have you ever decided which client request made it into a product or custom build, or said no to one? What did you decide, and who else weighed in?
- Constraints — What is your pay floor, and are there location or schedule limits? PM pay and location terms can differ from a solutions-engineer role.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.