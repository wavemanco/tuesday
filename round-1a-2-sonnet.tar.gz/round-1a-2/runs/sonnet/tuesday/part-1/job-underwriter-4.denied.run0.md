# Job Underwriting — Senior Pricing Analyst, Brindlemoor

## Decision snapshot

**Yes, go for it, on conditions. R2, R3, R4, R5 and R6 (the `must_have` rows) all land `direct`, and the conditions are R1 and RR1. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK-based)
- `must_have` — direct: R2, R3, R4, R5, R6
- `important` — adjacent: R8 (Owning pricing analytics for a whole product) · unclear: R7 (Recommendations to product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance domain knowledge)

R10 — GLM carries across, pet rating factors untested; R7 — product audience not evidenced; R8 — a book-level model, not a whole product.

**Opportunity ledger.** The role is concrete about its deliverables (RR5). The employer is unverified (RR1), and the JD is silent on salary (RR4), team size (RR2) and people management (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK-based); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the live posting verify, see RR1; (2) UK location and right to work confirmed, see R1; (3) the real scope of "own" and the product audience are clarified in interviews, see R7, R8, RR2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech with a pet-insurance product | `[grounded]` JD header |
| Mandate | Build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | "Own pricing analytics for our pet-insurance product" at a Senior title suggests a broad remit, possibly with a small team around it | `[inferred]` from the JD's "own" against its silence on team size |
| Market calibration | Not run. Research was not permitted, so I offer no salary band | — |
| Unknowns | Salary, team size, reports, decision rights over rating changes | `[grounded]` JD silent on each |
| Contradictions | None between the JD and your background. The JD was not checked against a careers page | `[grounded]` the two inputs |

## Evidence map

Your background was typed in, so it is self-report at intake. That caps every row at `medium` until an artifact is inspected.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based | hard_gate | unclear | low | hard_gate | You stated no location or right-to-work constraint. A UK motor insurer employer suggests UK but does not establish it | `[inferred]` from your UK employer | Answer G1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years of pricing analytics stated against four asked. A length-of-experience requirement, so graded on fit, not a gate. No artifact inspected | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated. "Strong" is a grade the evidence can only partly carry | `[grounded]` your background | A sanitized query set or notebook would raise to high |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. Limit: motor, not pet | `[grounded]` your background | A sanitized model spec or validation summary would raise to high |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting. The JD says "underwriting or actuarial", so one audience suffices | `[grounded]` your background | A sanitized review deck would raise to high |
| R6 | Designing and reading price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team. "Ran" does not say who designed and who read them, so it resolves to the lower reading until you say | `[grounded]` your background | Be ready to split design from read per test; one test write-up would raise to high |
| R7 | Recommendations for underwriting and product | important | unclear | low | discovery | The underwriting audience is evidenced (R5, R6). A product audience is not mentioned | `[grounded]` your background silent on product | Answer G2 |
| R8 | Owning pricing analytics for a whole product | important | adjacent | medium | transferability | You owned the GLM for one book, not stated as a whole product line. Limit: end-to-end scope is unevidenced | `[inferred]` from "own" in the JD against your book-level work | Answer G3 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance domain knowledge | preferred | adjacent | medium | transferability | The JD does not ask for pet experience, only "insurance a plus". This row exists because the product is pet. Your GLM and price-test method carry across. Limit: a pet factor set differs from motor, and none of it was exercised | `[grounded]` your background; `[generic]` that pet and motor rating factors differ | State the limit plainly; see plan A1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK location and right to work (R1, hard_gate) | hard_gate | Nothing states residence or work authorization | A gate the inputs do not settle stays open. It can only be answered, not worded around | n/a | n/a | `[grounded]` your background silent |
| G2 | Product-facing recommendations (R7, important) | discovery | Underwriting audience shown, no product audience | The JD names product as the second audience for results | Presenting test results to a product or commercial team; a pricing change proposal that product owned the customer side of; a conversion or retention readout | A one-page test readout or recommendation memo | `[grounded]` background silent on product; `[generic]` that pricing roles at insurers often serve a product audience |
| G3 | Whole-product ownership (R8, important) | transferability | One book's GLM, owned end to end | "Own pricing analytics for our product" may mean sole accountability for model, monitoring and tests | Owning model refreshes, monitoring and test calendar for the young-driver book; being the single point of contact for one product line | A monitoring pack or a model-governance note | `[inferred]` from the JD's "own" |
| G4 | Pet domain (R10, preferred) | transferability | Motor GLM and tests, no pet work. The bridge is the method; the limit is every pet-specific rating factor | Likely the first thing an interviewer probes | Any exposure to claims-cost or vet-cost data, or to an animal or health-adjacent book; otherwise none, and that is fine | A short note on how you would approach pet rating factors, as a work sample | `[grounded]` background; `[generic]` that this role family probes domain gaps |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Scope of "own" and team size unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may be sole accountability for the product's pricing analytics, with no stated team or decision rights | `[inferred]` from the JD's "own" against its silence on team | Who else works on pricing for this product, and which rating changes does this role decide versus recommend? | unresolved |
| RR3 | People management unstated | unknown | — | No reports or line-management language in the JD as you pasted it | The role may be an individual contributor, or may be expected to lead analysts later | `[inferred]` from the JD's silence | Does this role have direct reports now, or is leading others expected later? | unresolved |
| RR4 | Salary withheld | unknown | — | No salary stated in the JD as you pasted it | Pay may be unpublished, or may sit outside what you would accept | `[inferred]` from the missing figure | What salary band is budgeted for this post? | unresolved |
| RR5 | Concrete deliverables named | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations" | The work is defined and measurable by what is delivered | `[grounded]` JD | What would a successful first year look like for this role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV: lead with two bullets in your own terms, "Built and maintained the GLM rating model for the young-driver book" and "Ran 14 price tests with the underwriting team", with the quarterly pricing review to the head of underwriting beside them. No new verbs or scope added | R4, R5, R6 | `[grounded]` your background | `resume_edits_pending_approval` |
| A1 | Positioning: say plainly that your GLM, price-test and underwriting-presentation work is in motor and not pet, then show how you would approach pet rating factors. Do not claim pet knowledge | R10, G4 | `[grounded]` your background | pending your approval |
| A2 | If asked about management, say you have not managed anyone. The JD as pasted asks for none | RR3 | `[grounded]` JD silent, your background | pending your approval |
| A3 | Before applying, find the role on Brindlemoor's own careers site yourself and confirm the posting is live | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | In the loop, ask Odile Varga the verification questions of RR1, RR2, RR3 and RR4 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst" was refused. It would have fed role reality's contradictions row and RR1 |
| 2. Role-family sweep | unavailable | The search "senior pricing analyst pet insurance UK salary remote" was refused. It would have fed the market calibration line and RR4 |
| 3. Hiring manager's public footprint | unavailable | The search "Odile Varga Director of Pricing Brindlemoor" was refused. It would have fed the scope read and which story to lead with |

I did not retry the searches.

I can save this as `tuesday-dossier.md` if you want a record to carry forward, and will do so on request.

## Upgrade menu

- A link to the live posting or Brindlemoor's careers page → RR1 and the contradictions row close, and the cap at `conditional_go` may lift.
- Allowing web search, or a pasted salary band → market calibration and RR4.
- A pasted public profile or talks list for Odile Varga, or allowing search → the scope read and which story the plan leads with.
- A sanitized model spec or validation summary → R4 to `high`.
- A sanitized test write-up → R6 to `high`.
- A sanitized review deck → R5 to `high`.
- A sanitized query set or notebook → R3 to `high`.
- Your answers to G2 and G3 → R7 and R8 firm up.

G1 — Are you UK-resident and able to work for a UK employer without sponsorship?
G2 — Have you presented price-test results or pricing recommendations to a product or commercial team, and what did you own?
G3 — For the young-driver book, did you own the model refresh, the monitoring and the test calendar yourself, or was that shared?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.