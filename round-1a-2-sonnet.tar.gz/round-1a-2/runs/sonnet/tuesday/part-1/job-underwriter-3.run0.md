Search permission was denied, so I finished from your posting and background alone. The research rows below are marked unavailable.

## Decision snapshot

**Is it worth pursuing? No: R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site Austin, 5 days a week), R2 (Base pay of $70–85k)
- `must_have` — direct: R3, R4a
- `important` — unclear: R4b (SEO, brand, PR, partnerships, sales ops), R5 (Team of one to start)

R1 and R2 — the posting's terms conflict with your stated location and pay constraints; R3 (`medium`) and R4a (`medium`) — your strongest rows, stated and not yet probed.

**Opportunity ledger.** The posting raises four risk signals from its own words: seven functions on one person (RR1), pay set against the mandate (RR2), evening and weekend expectations (RR3), and success metrics left open (RR4). The stage and profitability claims are unverified (RR5).

- **Hard gates:** failed: R1 (On-site Austin, 5 days a week), R2 (Base pay of $70–85k).
- **Severe red flags:** none found.
- **What would change this:** Novaline would have to put in writing both a remote arrangement from Portland (R1) and a base of at least $150k (R2). The posting says "no exceptions" on location.

Your instinct that something is off matches the register. The fit is real (R3, R4a), but the terms and scope are what's wrong.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD header; unverified, research did not run |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team and reporting | Team of one to start; reports to the CEO with a dotted line to the board | `[grounded]` JD |
| Schedule and location | Evenings and weekends "when it matters"; on-site Austin 5 days a week, "no exceptions" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside", with no equity figures | `[grounded]` JD |
| Scope read | Seven functions with no team is a very broad mandate for one hire | `[inferred]` from the function list against "team of one" |
| Market calibration | Not run. Search was denied, so no band is claimed and the posting's pay is not compared to the market | `[grounded]` research tier line below |
| Unknowns | Budget, decision rights, equity terms, definition of success, who owns each function today | `[grounded]` JD silence on each |
| Contradictions | "Head of Growth" with 8+ years required sits beside a team of one and a $70–85k base | `[inferred]` from the posting's own terms; not checked against the careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin 5 days a week, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your statement (remote-only, in Portland, not relocating), which is specific and your own. Fit fails because the posting requires daily on-site work and rules out exceptions | `[grounded]` JD quote and your stated constraint | none; only the employer changing the term resolves it |
| R2 | Base pay of $70–85k | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your $150k floor, which is specific and your own. Fit fails because the top of the posted range is $65k below it | `[grounded]` JD figure and your stated floor | none; only the employer changing the term resolves it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You state 9 years, as growth lead then Head of Growth at two B2C subscription companies. Prose self-report with no inspectable artifact yet, so `medium` | `[grounded]` your background | offer: a resume or LinkedIn profile would let me check the dates |
| R4a | Own paid acquisition and lifecycle/CRM | must_have | direct | medium | none | You state you owned paid, lifecycle and experimentation, with SQL, GA4 and Braze. You also state scaling one company from $8M to $40M ARR over three years with a budget you controlled. Confirmed and specific, but unprobed, so expect a question on what was yours versus the team's | `[grounded]` your background | offer: a sanitized channel-mix or ARR growth report would raise it to high |
| R4b | Own SEO/content, brand, PR, partnerships, sales ops | important | unclear | none | discovery | Your background names none of these five. Silence is not absence, and there is no claim to grade yet | `[grounded]` your background is silent on them | see G1 |
| R5 | Operate as a team of one to start | important | unclear | none | discovery | You have led teams of 3–7. Working without a team is not stated either way | `[grounded]` your background | see G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Five non-paid channels (R4b, important) | discovery | Paid, lifecycle and experimentation are stated; SEO/content, brand, PR, partnerships and sales ops are not | It matters only if you pursue despite the gates; it cannot change `no_go` | Owning a content or SEO calendar or agency; running a partner or affiliate program; leading a launch or PR push; CRM or handoff work with sales | A traffic or pipeline report, a partner program summary, a launch brief | `[grounded]` background silence; `[inferred]` that it cannot move the status |
| G2 | Working without a team (R5, important) | discovery | Team leadership of 3–7 is stated; solo operation is not | Same as G1 | Stretches between hires, an early-stage period, or an agency-run phase | A hiring plan or role-scope document | `[grounded]` background; `[inferred]` that it cannot move the status |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bundled functions, no team | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops. You will be a team of one to start" | Several full roles may be folded into one title, with responsibility but no stated authority or budget | `[inferred]` from the function list against "team of one" | Which of these seven functions have an owner today, and what budget and headcount come with the role? | unresolved |
| RR2 | Pay against mandate (see R2) | risk_signal | medium | "$70–85k base plus meaningful equity upside" | The base may not match "own all revenue growth" and "8+ years growth leadership required"; the equity is unquantified. The market band was not checked | `[inferred]` from the posting's own terms; no market comparison was made | What are the equity terms (percentage, strike price, vesting), and is the base range fixed? | unresolved |
| RR3 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Out-of-hours work may be routine rather than occasional, especially for a team of one | `[inferred]` from the phrasing against the solo scope | Over the last quarter, how many evenings and weekends did the team work, and what comes back in time off? | unresolved |
| RR4 | Success undefined | risk_signal | medium | "success metrics will evolve as we learn" | You could be accountable for all revenue with no agreed definition of success | `[inferred]` from the mandate against the missing metrics | Which revenue number should move in the first six months, and who judges whether it did? | unresolved |
| RR5 | Stage and profitability unverified | unknown | — | "Series A, profitable since day one" | These are the employer's own claims, and research to check them did not run | `[grounded]` JD wording; not verified | Which round did you close, when, and can you point me to the role on your careers page? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't spend resume or application time on this posting as written | see R1, R2 | `[grounded]` R1 and R2 rows | pending your approval |
| A2 | Only if you want to test the terms: a short check with Novaline, through contact details from its own site, on remote work and base pay before anything else. No wording drafted unless you ask | see R1, R2 | `[grounded]` the JD's "no exceptions"; `[inferred]` that the odds are low | pending your approval |
| A3 | If you proceed anyway, put RR1 to RR5's questions to the employer verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: the constraint statements behind R1 and R2 (your own words, this conversation). Unverified: the R3 and R4a claims, stated in prose and not yet probed or backed by an artifact.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Novaline e-commerce enablement startup Austin Series A", "Novaline careers Head of Growth Austin") were refused. Would have moved role reality's organization and contradictions rows and whether the employer exists as described |
| 2. Role-family sweep | unavailable | One search ("Head of Growth salary Series A startup Austin base salary 2026") was refused. Would have filled the market calibration row and tested RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

## Dossier offer and upgrade menu

I can save this as `tuesday-dossier.md` if you want it kept.

- Search permission granted → targets 1 and 2 run, which settles RR5, the contradictions row and a pay band for RR2.
- A resume, or a sanitized growth report for the $8M to $40M ARR work → R3 and R4a move toward `high`.
- Answers to G1 and G2 → R4b and R5 resolve, but only if you pursue despite the gates.
- The hiring manager's name → role reality's scope read.
- A deeper pass on Novaline (funding, leadership churn, recent news; up to 5 more searches and 2 more fetches) → say the word and it runs, once search is permitted.

## Questions

None this turn: neither G1 nor G2 can move a `no_go` that rests on R1 and R2, and you have already settled both.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.