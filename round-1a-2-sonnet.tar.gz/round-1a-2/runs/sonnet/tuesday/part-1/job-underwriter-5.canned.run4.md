Checking the posting is live on the company's careers page, then I'll write up the assessment.
**Pellucid Learning, Senior Data Engineer: yes, it's worth applying to, with two conditions.** R3, R4, R5, R6, R7 and R8 (the `must_have` rows) are all `direct`. R1 and R2 are hard gates that I can't check yet, because you haven't given me your location or your pay floor. R9, BigQuery, is the one real learning curve. Status: `conditional_go`.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery) · unclear: R10 (Ingestion from app and CRM), R11 (Data contracts analysts depend on)

R9 is a credible bridge with its limit named; R10 and R11 are responsibilities your background doesn't speak to yet.

**Opportunity ledger.** The pay is stated and sits in a sensible place against the market report (RR1). Three things are unknown: the team and reporting line (RR2), the equity terms (RR3) and the success measures (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you are in the US or can be in Denver (R1); (2) your pay floor is within the posted range (R2); (3) the BigQuery bridge is framed as adjacent and never as BigQuery experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company's about page, fetched. Only the company's own page states the funding; no independent source turned up |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, data contracts for analysts | `[grounded]` posting, fetched live |
| Stack | dbt, BigQuery, Airflow or similar, data quality testing, Python and SQL | `[grounded]` posting |
| Working pattern | Remote (US) or Denver office | `[grounded]` posting |
| Scope read | One domain's pipelines for reporting, with no direct reports or team named | `[inferred]` from the posting's mandate and its silence on reports |
| Market calibration | Posted $148,000–$166,000 against the report's base median $151,000 and IQR $139,000–$163,500 (Senior DE, Series B–D, n=2,310). The bottom of the range sits just under the median and the top above the 75th-percentile figure. The report puts "Senior" at 5–8 years and one domain's pipelines with no reports, which matches the posting's 5+ years and scope. A market band, never this employer's offer | `[grounded]` Datawright report as you gave it and the posting; `[inferred]` that Series C places Pellucid in the report's B–D group |
| Unknowns | Hiring manager (none named), team size, equity terms, whether the figure is base only, success measures | `[grounded]` posting silence |
| Contradictions | None between your pasted text and the live posting and about page | `[grounded]` both fetched/searched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and work-location limits weren't stated, so the gate is unsettled; confidence grades your statement, and there isn't one | `[grounded]` posting text; no candidate statement | Closing question R1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor given. The range is not low against the report you supplied (see role reality) | `[grounded]` posting and report; no candidate statement | Closing question R2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. Length of experience is graded as fit, not a gate. Stated in prose, CV not seen, so `medium` | `[grounded]` your stated background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily" is specific but uninspected | `[grounded]` your stated background | A repo or sample would raise to high |
| R5 | dbt | must_have | direct | medium | none | You built the company's dbt project, about 180 models, on Snowflake. Specific, nothing inspectable yet | `[grounded]` your stated background | A project README or lineage screenshot would raise to high |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. The posting's wording is generic here; BigQuery is carried in R9 | `[grounded]` your stated background and posting | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration. Your exact role on it isn't stated, so I claim no more than use | `[grounded]` your stated background | none |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. Specific, uninspected | `[grounded]` your stated background | A sanitized suite listing would raise to high |
| R9 | BigQuery as the warehouse | important | adjacent | medium | transferability | Credible adjacency: the same dbt modelling work on another cloud warehouse. Limit: no BigQuery use at all, so its specifics are untested. Pattern, not a claim about Pellucid: warehouse-specific tuning is the part new BigQuery hires usually have to learn | `[grounded]` stated no BigQuery use; `[generic]` what warehouse switches usually cost | G1: bridge plus a small BigQuery sample |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | Your background doesn't say what the payroll company's sources were, so I can't tell whether this is direct or adjacent | `[grounded]` background silent on sources | G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Nothing yet on contracts or analyst-facing guarantees; the Great Expectations suite may be adjacent but that's unconfirmed | `[inferred]` possible link from the GE suite | G3, asked below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Snowflake plus dbt at scale; no BigQuery | The posting names BigQuery in its mandate, so it is the likeliest objection to raise | A dbt-on-another-warehouse migration or evaluation; any BigQuery exposure in side work | A small dbt project run against BigQuery's free sandbox, with its README | `[grounded]` no BigQuery stated; `[generic]` that this is the likeliest objection |
| G2 | App and CRM ingestion (R10, important) | discovery | Sources at your last employer are unstated | The posting names this as core | Pulling data from a product database, event stream or Salesforce/HubSpot-type CRM; building loaders or CDC | A pipeline diagram or DAG screenshot | `[grounded]` background silent |
| G3 | Data contracts (R11, important) | discovery | Contracts or analyst-facing guarantees not mentioned | The posting names contracts as what analysts depend on | Agreed schemas or SLAs with analysts or producers; failing tests that blocked a bad load; model ownership docs | Schema docs, a test config, a sanitized runbook | `[grounded]` background silent; `[inferred]` GE suite as a possible link |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and within market range | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is transparent and set against the supplied report, bottom near median, top above its 75th-percentile figure | `[grounded]` posting and report | Is the range base only, and where in it would this role land? | noted |
| RR2 | Team and reporting line not stated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You may be the only data engineer, or part of a team; the posting names no hiring manager and no team | `[inferred]` from the posting's silence | Who is on the data team, and who would I report to? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | Grant size, vesting and strike aren't given, so its value can't be judged | `[inferred]` from silence | What is the equity grant, vesting schedule and strike price? | unresolved |
| RR4 | No success measures for the mandate | unknown | — | "Build and run the pipelines" | First-year outcomes aren't stated, so success is undefined | `[inferred]` from silence | What would a successful first year look like for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | `resume_edits_pending_approval`: lead with "Built our dbt project on Snowflake, about 180 models; Airflow for orchestration; set up our Great Expectations test suite", in your own words | see R3, R5, R7, R8 | `[grounded]` your stated background | pending your approval |
| W1 | A small dbt project run on BigQuery's free sandbox, with a short README | see R9, G1 | `[grounded]` R9 row | pending your approval |
| P1 | Positioning line for the screen: "I haven't used BigQuery; my warehouse experience is Snowflake, with dbt on top." | see R9 | `[grounded]` your stated background | pending your approval |
| Q1 | Ask RR1–RR4's questions verbatim in the screen | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer): live, "Accepting applications", text matches yours. Searched "Pellucid Learning Series C $52M tutoring Denver", which returned only "About Pellucid Learning" (pellucidlearning.com/about), matching your pasted text. Moved the contradictions row (none) and kept the employer-not-established entry off; funding stays self-reported |
| 2. Role-family sweep | skipped | The Datawright report's figures are in hand and fix the market calibration row and RR1 |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form |

I can also write this up as a `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- Your CV: any presentation gaps appear (so far I have only your prose), and R3–R8 can move toward `high`.
- A DAG screenshot, pipeline diagram or sanitized test config: R4, R7, R8, R10 and R11 firm up.
- A small BigQuery sample project: R9's bridge strengthens.
- Your location and pay floor: R1 and R2 settle, and the snapshot's hard-gates line closes.
- The hiring manager's name, once known: scope read and positioning get a reader.
- A deeper pass on Pellucid (funding and leadership, hiring patterns, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

R1 — Where are you based, and could you work US-remote or from Denver? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

R2 — Is your pay floor at or below $148,000 base? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G3 — Have you set up agreed schemas, SLAs or blocking tests between data producers and analysts, and what did you personally own? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.