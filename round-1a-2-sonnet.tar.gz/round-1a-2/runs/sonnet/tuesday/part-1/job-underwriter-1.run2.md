## Decision snapshot

**Yes, apply. R1, R2, R3, R4 and R5 are all `must_have` rows and all `direct`. Status: `conditional_go`.** The condition is that the employer and posting verify, because my research searches were refused (see Evidence status).

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: direct: R8a · adjacent: R8b (Partner with clinicians) · unclear: R7 (Define and maintain the metrics layer), R9 (Mentor two junior analysts)
- `preferred`: adjacent: R6 (Healthcare data experience, HIPAA)

R3 (`medium`): confirmed and specific, waiting on an artifact; R6: a bridge from GDPR/CCPA consent work, its limit named; R7, R9: nothing in your background speaks to them yet.

**Opportunity ledger.** The employer is not yet established from attributable sources (RR1) and the pay is withheld (RR2). The scope bundles several jobs under one title (RR3). The mentoring and clinician-partnership duties point to genuine seniority (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Harborlight and the live posting verify (RR1); (2) the pay clears your floor (RR2); (3) the healthcare gap is framed honestly as adjacent (R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C, with a care-navigation app | `[grounded]` JD header; not independently checked |
| Mandate | Own product analytics: metrics layer, A/B design and analysis, self-serve Looker dashboards, roadmap partnership with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Scope read | A senior individual-contributor role with light people leadership, and a broad remit for one title | `[inferred]` from the mix of ownership, mentoring and cross-functional duties |
| Market calibration | Not done. The salary search was refused, and I won't quote a band from memory | `[grounded]` the JD states no pay |
| Unknowns | Pay, location and remote policy, who you report to, what the metrics layer is built on today, how the two juniors' skills are set | `[grounded]` the JD is silent on each |
| Contradictions | None found within the JD | `[grounded]` JD read only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years at a ~2M-subscriber consumer company. It is confirmed in prose with no artifact inspected. | `[grounded]` your background | None |
| R2 | Expert SQL | must_have | direct | medium | none | You use SQL daily on Snowflake. "Expert" is a self-grade that a live SQL exercise would test. | `[grounded]` your background; `[generic]` that analyst loops commonly include a SQL exercise | Keep a sanitized query sample ready |
| R3 | Experiment design at scale | must_have | direct | medium | none | You describe 30+ A/B tests a year and a pricing test behind an 11% retention lift. It is specific, but there is no inspectable write-up yet. | `[grounded]` your background | Prepare a sanitized test write-up |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | You built the Looker instance from scratch with 40+ governed dashboards. | `[grounded]` your background | A screenshot or a LookML sample would raise this to `high` |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly exec metrics memo and present monthly to the VP Product. | `[grounded]` your background | Keep a redacted memo |
| R6 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | You built a consent-state model for the warehouse and handled GDPR/CCPA consumer PII. That is privacy-governed data work. It is not healthcare data and not HIPAA, and you have never worked with PHI. | `[grounded]` your background and the JD's "a plus"; `[generic]` that HIPAA obligations differ from GDPR/CCPA | Make the bridge case and state its limit |
| R7 | Define and maintain the metrics layer | important | unclear | low | discovery | "Governed dashboards" suggests shared definitions, but you never say you owned metric definitions or the semantic layer. | `[inferred]` from "governed" | Question G1 |
| R8a | Partner with product managers on roadmap decisions | important | direct | medium | none | You present monthly to the VP Product and write the exec memo that feeds decisions. | `[grounded]` your background | None |
| R8b | Partner with clinicians | important | adjacent | low | transferability | Your partners were non-technical business stakeholders. You have no clinical counterpart, and clinicians weigh evidence differently. | `[grounded]` your background; `[generic]` that clinical reviewers often ask for more rigor on causal claims | Prepare one example of taking a skeptical expert from analysis to a decision |
| R9 | Mentor two junior analysts | important | unclear | none | discovery | Nothing in your background mentions mentoring or managing analysts. | `[grounded]` your background is silent | Question G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R7, important) | discovery | Looker governance is evident. Who defined metrics and kept them consistent is not stated. | The JD lists the metrics layer first, so owning it would remove the clearest gap among the must-have-adjacent duties | Writing the canonical definition of an active subscriber or churn; LookML measures and explores others reused; a metric dictionary; resolving a conflict between two teams' numbers | A metric dictionary page, a LookML sample, a definitions doc | `[grounded]` your background is silent on ownership; `[generic]` that metrics-layer ownership is central to roles like this |
| G2 | Mentoring junior analysts (R9, important) | discovery | No evidence either way. | The JD names two juniors, so the role includes development work | Onboarding a new analyst; code or query reviews; running an analytics guild; informal coaching; managing an intern | Onboarding doc, review checklist, a testimonial | `[grounded]` your background is silent |
| G3 | Clinician partnership (R8b, important) | transferability | Strong stakeholder work, but not with clinicians. | Clinicians are a named partner group | Working with medical, legal, or other expert reviewers on a decision | A project where an expert group changed their mind from your analysis | `[grounded]` your background |

## Opportunity risk register

| ID | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Decision rule | Status |
|---|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | Verify the employer exists and the posting is live before investing effort. | unresolved |
| RR2 | Pay and location not stated | unknown | low | "Senior Product Analyst — Harborlight Health" (no pay or location given) | The JD gives no pay or location, so I cannot check either against any limit of yours. | `[inferred]` from the JD's silence | What is the pay range and where is the role based? | Ask at the first recruiter contact. | unresolved |
| RR3 | Bundled scope | risk_signal | low | "metrics layer… A/B tests… Looker… mentor two junior analysts" | One title carries a platform build, experimentation, BI delivery and people development. | `[inferred]` from the JD's duty list | Which of these duties is the main priority in the first 90 days, and what support does the role have? | Proceed if priorities are explicit. | unresolved |
| RR4 | Mentoring and clinician partnership | positive_signal | low | "mentor two junior analysts… partner with product managers and clinicians" | Named reports and named partners suggest a defined senior role rather than a lone-analyst job. | `[inferred]` from the JD's wording | Who are the two analysts, and what are their levels? | Treat as supportive, not proven. | unresolved |

## Application plan

- **Lead with:** the experimentation program (R3), then the Looker build (R4), then the exec memo and VP Product work (R5, R8a). These are `direct` rows.
- **Healthcare gap (R6):** present the consent-state model as privacy-governed data work you did under GDPR and CCPA. State plainly that you have not worked with PHI or HIPAA. Do not imply otherwise. A resume line saying "HIPAA experience" would be a prohibited claim.
- **Mentoring (R9):** make no mentoring claim until G2 is answered.
- **Approval:** any resume language, positioning or outreach text I propose is `resume_edits_pending_approval`. Nothing is final until you approve it, and that covers this prose as well as any table.

## Evidence status

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | unavailable | Search permission was refused. This would have moved RR1 and the employer row in role reality. |
| 2 | Role-family sweep | unavailable | Search permission was refused. This would have moved the market calibration and RR2. |
| 3 | Hiring manager's public footprint | n/a | No name was given. |

## Closing

I can write all of this up as a `tuesday-dossier.md` if you'd like one.

**Upgrade menu**

- Search permission, to verify Harborlight and band the pay: closes RR1 and sets the pay band in role reality.
- A metric dictionary page or LookML sample: G1 and R7 (R4 to `high`).
- A redacted test write-up or the monthly memo: R3 and R5 to `high`.
- Your pay floor, location and any other limits: turns the hard-gates line from unknown to checked.
- The hiring manager's name: scope read and positioning.

**Questions**

- C1 — What are your pay floor, location or remote needs, and work-authorization situation for this role?
- G1 — Did you personally define and maintain metric definitions that others used, such as the canonical churn or active-subscriber definition, and where do they live?
- G2 — Have you ever onboarded, coached or reviewed the work of other analysts? What did you do?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.