I'm writing up the full assessment. Two web searches (the company and the role's market) were refused, so the research below is marked unavailable. I did not retry them.

**Yes, apply, and you're a fit on the core of it. R1, R2, R3, R4 and R5 are `direct`. Status: `conditional_go`.** The healthcare gap is R9, a `preferred` row, so it isn't what blocks you. The conditions are below.

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5 · adjacent: R6 (Define and maintain the metrics layer)
- `important` — direct: R7a · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA)

R6 (`low`) — governed Looker work implies a metrics layer but does not state one; R9 — a credible bridge, its limit named; R7b and R8 — your message is silent.

**Opportunity ledger.** Sound on its face but unverified. The employer could not be checked from here (RR1), pay is unstated (RR2), and the metrics layer's starting state is unknown (RR3). Scope is wide for one title (RR4), though the posting does name concrete deliverables and a team (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the live posting verify (RR1); (2) pay turns out acceptable to you (RR2); (3) the metrics-layer starting point and the mentoring remit are clarified (R6, R8, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C, care-navigation app | `[grounded]` JD header, not independently verified |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Seniority shape | A senior individual contributor with a mentoring remit, not a people-management post | `[inferred]` from "mentor" against the absence of any management language |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Pay, location, work pattern | Not stated | `[grounded]` JD as pasted silent |
| Market calibration | Not available; the role-family sweep did not run | `[grounded]` search refused |
| Contradictions | None between the JD and your background as you described it; the JD was not checked against the company's careers page | `[grounded]` inputs compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years stated, in product analytics at a consumer-subscription company. Self-reported with nothing inspected yet, so `medium`, the intake ceiling | `[grounded]` your message | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake stated. "Expert" is the posting's level word, not yours. Hiring loops for analysts commonly include a live SQL exercise | `[grounded]` your message; `[generic]` on hiring loops | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ A/B tests a year and a designed and run program, including the pricing test behind an 11% retention lift. Specific, but no artifact inspected | `[grounded]` your message | offer: a sanitized readout of the pricing test would raise to high |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | Built the company's Looker instance from scratch, 40+ governed dashboards. Specific, not yet inspectable | `[grounded]` your message | offer: dashboard screenshots or a sanitized dashboard inventory |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly metrics memo read by the exec team, plus a monthly VP Product presentation | `[grounded]` your message | offer: a redacted memo excerpt |
| R6 | Define and maintain the metrics layer | must_have | adjacent | low | discovery | Governing 40+ Looker dashboards suggests shared definitions, but you did not say where the metric definitions lived or who owned changes. Low, not none, because there is a concrete thread to pull | `[grounded]` Looker claim; `[inferred]` that definitions existed, derived from "governed" | G1 question |
| R7a | Partner with product managers on roadmap decisions | important | direct | medium | none | Monthly VP Product presentations and a pricing test whose result you tied to a retention lift. Whether roadmap calls followed is the likely probe | `[grounded]` your message | none |
| R7b | Partner with clinicians | important | unclear | low | discovery | Nothing in your message touches domain-expert stakeholders outside product and data | `[grounded]` your message silent | carried; not asked this turn |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Your message is silent on mentoring or onboarding anyone | `[grounded]` your message silent | G2 question |
| R9 | Healthcare data experience (HIPAA) a plus | preferred | adjacent | medium | transferability | Consent-state modelling and GDPR/CCPA PII handling are real adjacent work. Limit: neither is health data, and HIPAA's rules for protected health information were not exercised | `[grounded]` your message; `[generic]` that HIPAA concerns protected health information | G4; bridge framing in E2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | 40+ governed Looker dashboards, but no statement of where definitions lived or who owned them | A `must_have` at `adjacent`; resolving it is the likeliest way to move the row to `direct` | LookML or a dbt layer you owned; a metric dictionary or definitions doc; resolving disagreements between teams' numbers | Screenshot of the definitions, a metric dictionary excerpt | `[grounded]` claim without detail; `[inferred]` that this row moves the decision most |
| G2 | Mentoring (R8, important) | discovery | Silence on mentoring or onboarding | The role names two junior analysts as part of the remit | Onboarding a new analyst; reviewing others' SQL or dashboards; coaching on experiment design | A short note describing it, a review checklist, an onboarding doc | `[grounded]` CV silence |
| G3 | Clinician partnership (R7b, important) | discovery | No evidence either way | The JD pairs clinicians with PMs as partners | Working with ops, nutrition or other domain specialists to shape an analysis | A project brief naming the partner function | `[grounded]` silence; carried, no question this turn |
| G4 | Healthcare data (R9, preferred) | transferability | Consent-state model and GDPR/CCPA handling. Limit: not health data, no HIPAA exposure | A `preferred` row, so a minor risk rather than a blocker | Consent or retention rules applied to sensitive data; access controls and audit work | A sanitized description of the consent-state model | `[grounded]` your message; `[generic]` that HIPAA is the named regime |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation unstated | unknown | — | (no pay language in the pasted posting) | Pay may be withheld in the posting, or lost when it was pasted | `[grounded]` posting as pasted is silent; `[inferred]` for the two readings | What salary band is budgeted for this role? | unresolved |
| RR3 | Metrics layer's current state unknown | unknown | — | "define and maintain the metrics layer" | The layer may be new, inherited, or shared with other teams | `[inferred]` from the JD's verbs against its silence on the starting point | What state is the metrics layer in today, and who else changes it? | unresolved |
| RR4 | Several specializations in one title | risk_signal | low | "design and analyze A/B tests, build self-serve dashboards in Looker … mentor two junior analysts" | Experimentation, metrics modelling, BI and mentoring may be folded into one seat | `[inferred]` from the count of distinct duties in the JD | Which of these duties have dedicated support, such as analytics engineering for the metrics layer? | unresolved |
| RR5 | Concrete team and stakeholders named | positive_signal | — | "mentor two junior analysts"; "partner with product managers and clinicians" | The seat has a defined team and defined partners | `[grounded]` JD | What should the first analyst in this seat have delivered by month six? | noted |

## Application plan

Everything in this table, including the quoted language, is proposed: `resume_edits_pending_approval`. Nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with two lines in your own words: "Designed and ran the experimentation program, 30+ A/B tests a year, including the pricing test behind an 11% retention lift" and "Built the company's Looker instance from scratch — 40+ governed dashboards" | R3, R4 | `[grounded]` your message, clause by clause | pending your approval |
| E2 | In the cover note, state the bridge and its limit: "built the consent-state model for our warehouse and handled GDPR/CCPA consumer PII; I have not worked with health data." Do not call this HIPAA or healthcare experience | R9 | `[grounded]` your message | pending your approval |
| Q1 | Ask the questions of RR1 to RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Confirm the posting is live on Harborlight's own careers page before investing application effort | RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | A search on the company and the role was sent and refused. It would have settled RR1 and role reality's organization and contradictions rows |
| 2. Role-family sweep | unavailable | A search on role-family pay and scope was sent and refused. It would have set market calibration and checked the unstated pay in RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## If you want to keep this

I can write it up as `tuesday-dossier.md` whenever you say so; it's optional.

## Upgrade menu

- Search permission, or a link to the live posting on Harborlight's careers page → RR1 closes and the decision likely simplifies to `go`. With search allowed, the remaining L1 budget is up to 3 searches and 2 fetches; a deeper pass (funding, leadership changes, recent news) would add up to 5 more searches and 2 more fetches.
- A posted pay band, or the market-pay sweep → RR2 closes and market calibration fills in.
- A sanitized pricing-test readout, a metric dictionary or LookML excerpt, or a redacted memo → R3, R4, R5 and R6 can reach `high`. In product analytics these are the inspectable artifacts.
- Your non-negotiables (pay floor, location, anything else) → gate rows get built and the hard-gates line becomes a real check.
- The hiring manager's name → the scope read and which of your stories to lead with.

**Questions**

- G1 — Where did the metric definitions behind your Looker dashboards live (LookML, a dbt layer, a doc), who owned changing them, and how did you keep dashboards agreeing with each other?
- G2 — Have you mentored or onboarded analysts, formally or informally, and what did that involve?
- C1 — What are your non-negotiables for a move, such as a pay floor, location or remote, or anything else, so I can check them against the role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.