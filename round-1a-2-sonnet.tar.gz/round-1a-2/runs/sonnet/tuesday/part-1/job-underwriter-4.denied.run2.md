Search permission was denied, so I'm assessing from the JD and your background only.

**Decision snapshot**

**Yes, this one is worth applying to. Status: `conditional_go`**, because Brindlemoor can't be verified from here (RR1) and R1 is still unconfirmed.

**Fit ledger.**

- `hard_gate`: unclear: R1 (UK-based, fully remote working)
- `must_have`: direct: R2, R3, R4, R5, R6, R8 · unclear: R7 (Monitor rating models)
- `important`: direct: R9 · unclear: R10 (Recommendations to product)
- `preferred`: direct: R11 · adjacent: R12 (Pet-insurance domain)

R4 (`medium`): the GLM claim is the centre of the role and rests on your account alone for now; R7, R10: monitoring and product-facing work aren't stated in what you gave me; R12: a bridge from motor, with its limit named.

**Opportunity ledger.** The role's deliverables are concrete (RR4). The employer is unverified (RR1), the pay is not stated (RR2), and the team shape around "own" is unstated (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (UK-based, fully remote working); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, RR1; (2) R1 confirmed; (3) the pet-domain bridge is framed as adjacent and never as pet-pricing experience, R12.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header as pasted; the entity itself is unchecked |
| Reports to | Odile Varga, Director of Pricing | `[grounded]` as you gave it |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Seniority read | The JD asks for 4+ years and your 5 years sits above that floor; "Senior" under a Director reads as an individual-contributor post | `[inferred]` from the JD's years and title against your stated background |
| People management | The JD states no direct reports and no management requirement; whether any exist is unknown | `[grounded]` JD silence |
| Compensation | Not stated in the JD as pasted | `[grounded]` JD silence |
| Market calibration | Not run; no band is offered, because none could be sourced | `[grounded]` research unavailable (see Evidence status) |
| Unknowns | Pay; team shape and reports; whether rating models exist today or are built from scratch | `[inferred]` from "build and monitor" against the JD's silence |
| Contradictions | None visible inside the pasted JD; JD against careers page not checkable | `[grounded]` JD as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK | hard_gate | unclear | low | hard_gate | You haven't stated residence or right to work. A UK employer is indirect evidence only, so confidence is `low` | `[grounded]` JD term; `[inferred]` from your UK employer | Question G-R1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years pricing analytics at a UK motor insurer, specific but self-reported | `[grounded]` your background | none; dated CV roles would let it be checked |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use shows frequency, not strength; taking the lower reading | `[grounded]` your background | A sanitized query or notebook would raise it |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. Limit: motor, not pet | `[grounded]` your background | A sanitized model summary or documentation would raise it |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R6 | Build rating models | must_have | direct | medium | none | Same evidence as R4 | `[grounded]` your background | none |
| R7 | Monitor rating models | must_have | unclear | low | discovery | "Maintained" may include monitoring (drift, loss-ratio tracking), but you didn't say so and I'm not assuming it | `[grounded]` your wording; `[inferred]` that monitoring may be involved | Question G1 |
| R8 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with underwriting. "Ran" covers delivery; design and read-out detail is what a hiring manager will probe | `[grounded]` your background | A short account of one test, from hypothesis to decision, would raise it |
| R9 | Recommendations for underwriting | important | direct | medium | none | Quarterly review and joint test work with underwriting | `[grounded]` your background | none |
| R10 | Recommendations for product | important | unclear | low | discovery | Nothing you gave me mentions product-team audiences | `[grounded]` your background silence | Question G2 |
| R11 | Insurance experience (a plus) | preferred | direct | medium | none | 5 years at a motor insurer | `[grounded]` your background | none |
| R12 | Pet-insurance domain (implied by owning the pet product's pricing) | preferred | adjacent | low | transferability | You've said you haven't worked on pet. Young-driver rating is a related technical problem, but this is a different risk | `[inferred]` bridge from your motor GLM work; `[generic]` that pet pricing uses different rating factors from motor | Bridge case G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R7, must_have) | discovery | You built and maintained the GLM; monitoring isn't described | A must-have; a confirmed answer moves R7 to `direct` | Tracking actual-versus-expected by segment; refitting after drift; a post-launch performance review | A sanitized monitoring dashboard or review pack | `[grounded]` the CV-style summary is silent; `[inferred]` that maintenance may include this |
| G2 | Recommendations to product (R10, important) | discovery | Your audiences are underwriting; product isn't mentioned | The JD names product as a second audience | Sizing a pricing change for a product launch or feature; briefing a product owner on a test result | A sanitized recommendation paper | `[grounded]` background silence |
| G3 | Pet domain (R12, preferred) | transferability | Motor GLM work on one segment | The most likely objection to your application | Bridge: your rating-model and test work. Limit: no pet claims, breed or age, or vet-cost experience. Strengthener: a short sample analysis on public pet or comparable data, if you want one | A small worked example | `[inferred]` bridge; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | "Fully remote (UK)" (the pasted JD ends with no figure) | The pay may be withheld or omitted from what was pasted | `[inferred]` from absence in the pasted JD | What salary range is budgeted for this role? | unresolved |
| RR3 | Team shape and reports unstated against "own" | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may be the only analyst on the product, or part of a team, and may or may not carry reports | `[inferred]` from "own" against silence on team | Who else works on pricing for this product, and does this role have or expect direct reports? | unresolved |
| RR4 | Deliverables stated concretely | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations" | The scope is defined and measurable | `[grounded]` JD | What does success look like in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with three things in your own terms: the GLM rating model you built and maintained for the young-driver book, the 14 price tests you ran with underwriting last year, and the quarterly pricing review you present to the head of underwriting | See R4, R8, R5 | `[grounded]` your background | pending your approval |
| A1 | Check the employer and the live posting on its own careers site before investing in the application | See RR1 | `[grounded]` RR1 | pending your approval |
| A2 | On the pet gap, say plainly that you haven't worked on pet insurance and that you bring rating-model and test work from motor | See R12 | `[inferred]` bridge, limit named | pending your approval |
| A3 | If asked about management, say you haven't managed people; the JD states no such requirement | See RR3 | `[grounded]` your statement and the JD | pending your approval |
| Q1 | Ask RR2, RR3 and RR4's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Odile Varga's public footprint wasn't researched, so nothing in this plan is tailored to her.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches on Brindlemoor and its careers page were refused. It would have settled RR1 and whether the posting is live |
| 2. Role-family sweep | unavailable | One search on UK pet-insurance pricing analyst scope and pay was refused. It would have given the market calibration and tested RR2 |
| 3. Hiring manager's public footprint | unavailable | One search on the Director of Pricing's public professional footprint was refused. It would have informed the scope read and which story to lead with |

## One offer

I can save all of this as `tuesday-dossier.md` if you want it for later.

## Upgrade menu

- Allow web search, and targets 1 to 3 run. That would resolve RR1, add a pay band for RR2, and add a public-footprint read of Odile Varga for the plan.
- A sanitized model summary, query or notebook raises R3 and R4 toward `high`.
- A short account of one price test, from hypothesis to decision, raises R8.
- Your answers on monitoring and product work resolve R7 and R10.
- A pay floor, notice period or other non-negotiables turn "candidate constraints not given" into real hard-gate checks.

## Questions

- **R1:** Are you UK-resident and able to work there without sponsorship, and is fully remote working fine for you?
- **G1:** In your motor role, did you track the GLM's live performance after launch (actual versus expected, drift, refits)? What did you personally do?
- **G2:** Have you ever taken a pricing result to a product team or owner, as opposed to underwriting? What was the decision?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.