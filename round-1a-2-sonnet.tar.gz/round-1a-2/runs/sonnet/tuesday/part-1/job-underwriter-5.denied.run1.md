## Decision snapshot

**Is it worth it? Yes, apply, on conditions. R1 and R2 (hard gates) aren't yet checked against your location and pay floor, and R8 (BigQuery) is only adjacent. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (BigQuery) · unclear: R9 (data contracts), R10 (ingestion from app and CRM)

R8 — a credible bridge, its limit named; R9 and R10 — not yet addressed in what you've told me.

**Opportunity ledger.** The pay is disclosed and sits at or above the report's band (RR2), and the stack and deliverables are concrete (RR4). I couldn't verify the employer from here (RR1), and the team structure is unstated (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The posting verifies as live on the company's own careers page (RR1).
  2. Your location and pay floor clear R1 and R2.
  3. The BigQuery gap is stated as adjacent, never claimed (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; I could not open the live page (see Evidence status) |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` the JD as pasted |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity; equity terms and whether "salary" means base are unstated | `[grounded]` JD |
| Scope read | "Senior" at 5+ years sits inside the report's typical 5–8 years, and no direct reports are mentioned. The mandate runs from ingestion through modelling to contracts, which may be wider than the report's typical "one domain's pipelines", or may be one domain (reporting). | `[inferred]` from the JD's mandate against the report's stated typical scope |
| Market calibration | The Datawright 2026 report (US, n=2,310, Senior Data Engineer at Series B–D companies) gives a base median of $151,000 and an interquartile range of $139,000–$163,500. The posting's low end is $3,000 under that median and its high end is $2,500 over the top of the range. The basis is the report your recruiter sent, not an independent sweep. | `[grounded]` the report as provided and the JD; the comparison is arithmetic |
| Unknowns | The hiring manager (the posting names none); team size and who owns ingestion versus modelling; equity terms; first-year outcomes or success measures; whether BigQuery is required or learnable, since it appears in the mandate sentence while the Requirements line says only "a cloud warehouse" | `[grounded]` JD silence |
| Contradictions | None between the JD and the about text as pasted. Nothing was cross-checked against the live pages. | `[grounded]` pasted text only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | The JD states the term. You haven't said where you're based or whether you have a location limit, so there is no statement of yours to grade. | `[grounded]` JD; your message is silent | Ask G1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The JD states the pay. You haven't given a floor. The range is at or above the report's median, so a floor is the only thing that could fail it. | `[grounded]` JD and report figures | Ask G1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. It is self-reported with nothing inspectable yet, so `medium`. | `[grounded]` your background message | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. Daily use is confirmed; "strong" is what an interviewer would probe. | `[grounded]` your background message | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built your company's dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse, so the stated requirement is met. | `[grounded]` your background message | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow for orchestration. Whether you wrote the DAGs or ran them isn't stated, so the claim stays at its plain wording. | `[grounded]` your background message | none; be ready to say which DAGs were yours |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up your company's Great Expectations test suite. | `[grounded]` your background message | none |
| R8 | BigQuery as the warehouse the role runs on | important | adjacent | medium | transferability | I tiered it `important` because the Requirements line says only "a cloud warehouse" and BigQuery sits in the mandate sentence. What carries over is your dbt modelling on Snowflake. The limit is that you've never used BigQuery. `[generic]` Warehouse-specific cost and performance habits differ between engines, and a hiring panel is likely to probe them on a move like this. | `[grounded]` JD and your statement; `[generic]` the probe pattern | See G2 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Your Great Expectations suite and dbt project are indirect context. Nothing says you agreed schemas or expectations with the people consuming the data. | `[inferred]` from the GE and dbt statements; the JD names the term | Ask G3 |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | Airflow implies pipeline work. The sources you ingested (product events, CRM or SaaS APIs, files) aren't stated. | `[inferred]` from the Airflow statement; the JD names the term | Ask G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay floor (R1, R2; hard_gate) | hard_gate | The JD's terms are stated and none of your constraints are | A failed gate would cap the decision regardless of fit | n/a | Nothing to attach; your own statement settles it | `[grounded]` your message gives no constraints |
| G2 | BigQuery (R8; important) | transferability | Adjacent: your Snowflake and dbt work. Limit: no BigQuery use. Strengthener: a small dbt project run against BigQuery, linked on your resume. | It is the warehouse the role runs on, so it's the likeliest objection | Any BigQuery querying in a past role, even occasional; a side project | The linked sample project above | `[inferred]` bridge from your Snowflake work; `[generic]` that a runnable sample narrows an adjacent-tool objection |
| G3 | Data contracts (R9; important) | discovery | Testing and modelling are shown; agreed expectations with consumers are not | The JD names contracts as a deliverable, so which of your work counts decides whether R9 closes | Agreeing column definitions or freshness expectations with analysts; failing a pipeline on a Great Expectations check that consumers relied on; documenting model ownership | A sanitized expectation suite, a dbt model with documented tests, or a schema agreement note | `[grounded]` the pasted background is silent; `[inferred]` that this would move R9 |
| G4 | Ingestion from app and CRM (R10; important) | discovery | Airflow pipelines are implied; the source systems aren't named | Ingestion is the first item in the mandate | Pulling product event data; syncing a CRM or other SaaS API through Airflow; loading files or database replicas into Snowflake | A sanitized DAG file or a pipeline diagram | `[grounded]` the pasted background is silent; `[inferred]` that this would move R10 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states." | I could not check the company or the posting: both page fetches were refused, and no search found anything against it. The entity may be well established, the posting may be stale, or it may not represent a real hiring employer. | `[generic]` pattern for any unverified employer, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay disclosed and at or above the report's median | positive_signal | — | "Salary $148,000–$166,000 plus equity." | Seniority and pay line up; no mismatch is visible. The equity terms and whether the figure is base are open. | `[grounded]` JD range against the report's median and interquartile range | Is the range base salary, and how is the equity structured (type, vesting, valuation)? | noted |
| RR3 | Team structure and ownership unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You may be the only data engineer, or one of several. "Build and run" plus three layers could mean wider scope than the report's typical single domain. | `[inferred]` from the JD's mandate against the report's typical-scope statement | How large is the data team, who owns ingestion versus modelling today, and what should this hire deliver first? | unresolved |
| RR4 | Concrete stack and deliverables named | positive_signal | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The work is defined well enough to prepare for and to check against in interviews. | `[grounded]` JD | What does success look like at six and twelve months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Open the careers and about pages on pellucidlearning.com yourself and confirm they read as you pasted them | See RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead the resume with "Built our dbt project on Snowflake — about 180 models", then "set up our Great Expectations test suite", then Airflow orchestration. Name the warehouse as Snowflake. I haven't seen your resume, so these are your own words and not edit rows yet. | See R5, R6, R7 | `[grounded]` your background message | `resume_edits_pending_approval` |
| E2 | Say the gap plainly early, in your own words: "I've built dbt on Snowflake and haven't used BigQuery" | See R8, G2 | `[grounded]` your statement | pending your approval |
| W1 | Optional: a small dbt project run against BigQuery, linked from the resume | See G2 | `[generic]` role-family pattern | pending your approval |
| Q1 | Ask RR1–RR4's verification questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A2 | Ask your recruiter whether the range is base, what the equity terms are, and who the hiring manager is | See RR2, RR3 | `[grounded]` RR2, RR3 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I tried to fetch pellucidlearning.com/careers/senior-data-engineer and pellucidlearning.com/about to check that the pasted text is genuine and current. Both fetches were refused, so nothing was read. I did not try other routes around that. The effect is RR1 and role reality's contradictions row. |
| 2. Role-family sweep | skipped | The Datawright report you pasted fixes the market calibration and the RR2 comparison, so a search could not change them. |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there is no query to form. |

## Dossier offer

If you want to keep this, I can write it up as `tuesday-dossier.md`; just say so.

## Upgrade menu

- Your resume or CV → R3, R4, R5, R6 and R7 can be checked against the text itself, and E1 becomes real edit rows.
- A sanitized dbt docs lineage view or model sample (no payroll data), a sanitized Airflow DAG file, or your Great Expectations suite config → R5, R6 and R7 can reach `high`, and G3 and G4 get inspectable proof.
- Your answers on location and pay floor → R1 and R2 move off `unclear`.
- The hiring manager's name (your recruiter may have it) → the scope read and which story the plan leads with.
- Base-versus-total pay and the equity terms → RR2 closes.
- Allowing the two page fetches, or telling me what the live pages say after you open them → RR1 and the contradictions row.

## Questions

- G1 — Where are you based relative to Remote (US) or Denver, and is there a pay floor or other non-negotiable this role would have to clear?
- G3 — Have you agreed expected schemas, definitions or freshness with the analysts who consume your data, and what happened when a check failed?
- G4 — What did your Airflow pipelines ingest, such as product events, a CRM or other SaaS APIs, or files, and which of those did you build yourself?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.