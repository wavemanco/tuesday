Running the two L1 research searches (employer check, then salary band), then I'll write up the assessment.
**Yes, apply. You're a fit on the core:** R1, R2, R3, R4 and R6 land `direct` and R5 lands `adjacent`. The soft spots are R7b, R8 and R9. Status: `conditional_go`.

Both research searches were refused because search permission wasn't granted, so I couldn't check that Harborlight exists as the posting describes. That unverified employer is why this is `conditional_go` and not `go` (RR1).

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R6 · adjacent: R5 (Define and maintain the metrics layer)
- `important` — direct: R7a · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA)

R5 (`medium`) — Looker build implies modeling, not a named metrics layer; R7b, R8 — nothing in your background addresses them yet; R9 (`medium`) — a bridge from your GDPR/CCPA consent work, limit named.

**Opportunity ledger.** The role is concrete about responsibilities and tooling (RR4), but the employer is unverified (RR1), the pay is unstated (RR2), and the team structure behind the mentoring duty is unknown (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) the pay clears your floor (RR2); (3) the mentoring and clinician-partnership rows (R8, R7b) are either evidenced by you or confirmed as light in the role (RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C, as stated in the pasted posting; not independently verified | `[grounded]` JD header |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, PM and clinician partnership, mentoring two junior analysts | `[grounded]` JD |
| Seniority and scope | A senior individual contributor with light lead duties: 5+ years plus two mentees, with no stated reports or budget | `[inferred]` from the JD's years requirement and mentoring line |
| Unknowns | Pay, location or remote policy, reporting line, how much clinician time the role gets, and the app's traffic volume for "experiment design at scale" | `[grounded]` JD silence on each |
| Market calibration | Not run, because the search was refused. No pay band is offered | `[grounded]` search refused |
| Contradictions | None inside the pasted JD; not checked against Harborlight's own pages | `[grounded]` JD |

## Evidence map

Your background is typed prose, so it counts as CV-equivalent self-report. That caps confidence at `medium` until you share something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years of product analytics at a ~2M-subscriber meal-kit company; specific, but no inspectable artifact | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | SQL daily on Snowflake. "Expert" is your call to make; interviewers usually probe it with live problems | `[grounded]` your background; `[generic]` on the probe | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ A/B tests a year, including the pricing test behind an 11% retention lift. Whether Harborlight's traffic makes "at scale" larger or smaller than yours is unknown | `[grounded]` your background; `[inferred]` on the scale unknown | An experiment-review doc or test-readout (sanitized) would raise this to `high` |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | Built the Looker instance from scratch, 40+ governed dashboards | `[grounded]` your background | A screenshot or sanitized dashboard inventory would raise this to `high` |
| R5 | Define and maintain the metrics layer | must_have | adjacent | medium | discovery | Governed dashboards and an exec metrics memo point toward metric definitions, but you have not said you owned a metric dictionary or modeling layer | `[grounded]` your background; `[inferred]` that the Looker build involved modeling | See G1 |
| R6 | Written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly metrics memo read by the exec team, monthly presentations to the VP Product | `[grounded]` your background | A sanitized memo would raise this to `high` |
| R7a | Partner with product managers on roadmap decisions | important | direct | medium | none | Monthly VP Product presentations; the 11% pricing test shows analysis feeding a decision | `[grounded]` your background | none |
| R7b | Partner with clinicians | important | unclear | low | discovery | You mention no domain-expert partnerships comparable to clinicians | `[grounded]` background silence | See G2 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | No mentoring or leading of analysts is stated | `[grounded]` background silence | See G3 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | You have GDPR/CCPA consumer-PII handling and built the warehouse's consent-state model. Limit: no health data, no HIPAA | `[grounded]` your background | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R5, must_have) | discovery | Governed Looker dashboards, but no stated ownership of metric definitions | A `must_have` at `adjacent`; confirming it could make R5 `direct` | Writing LookML or dbt metric definitions; a metric dictionary; resolving "two teams, two numbers" disputes | LookML excerpt (sanitized), a metrics glossary, a definition-change log | `[grounded]` background silence on ownership |
| G2 | Clinician partnership (R7b, important) | discovery | No domain-expert partner named | The JD names clinicians explicitly | Working with ops, nutrition, culinary or customer-care specialists to shape an analysis or test | A test brief or readout co-signed with a non-product specialist | `[grounded]` background silence; `[generic]` that domain-expert partnership is the nearest analogue |
| G3 | Mentoring (R8, important) | discovery | No mentoring or leading of analysts stated | The JD makes mentoring two juniors a duty | Onboarding analysts, reviewing their SQL or analyses, running office hours, an informal buddy role | A named mentee, a review checklist, or a team onboarding doc | `[grounded]` background silence |
| G4 | Healthcare data (R9, preferred) | transferability | Consent-state modeling for GDPR/CCPA PII. This is the adjacent evidence and it is real | Preferred, so it is not a blocker. The limit: no PHI, no HIPAA | Access controls, de-identification, audit trails or consent enforcement you built | A consent-model design doc (sanitized) | `[grounded]` your background; `[generic]` that regulated-data handling is the nearest analogue to HIPAA work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The company may be real and simply not yet checked, the posting may be stale, or it may not represent a live hiring employer | `[generic]` pattern for unchecked postings, not a claim about this company | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay unstated | unknown | — | (no figure in the posting) | The figure may sit below what a senior role with mentoring duties usually carries, or the company may just not publish it | `[inferred]` from the posting's silence | What is the budgeted range for this role? | unresolved |
| RR3 | Mentoring duty with no stated team structure | unknown | — | "mentor two junior analysts" | You may inherit two mentees with no formal reporting authority | `[inferred]` from the JD naming mentees but not reporting lines | Do the two analysts report to this role, and who owns their performance reviews? | unresolved |
| RR4 | Concrete responsibilities and tooling named | positive_signal | — | "define and maintain the metrics layer… build self-serve dashboards in Looker" | The scope is defined and matches a tooling stack you already know | `[grounded]` JD | What does success look like at 90 days and at one year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on Harborlight's own careers page before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead your summary with the Looker build and the experimentation program. These are your direct matches for R3 and R4 | R3, R4 | `[grounded]` your background | pending your approval |
| E2 | Frame the consent-state model as "GDPR/CCPA consent modeling in a Snowflake warehouse" and never as healthcare or HIPAA experience | R9 | `[grounded]` your background | pending your approval |
| Q1 | Ask the RR1 to RR4 verification questions verbatim during the process | The register doubles as interview prep | `[grounded]` register | pending your approval |

Don't claim HIPAA, PHI or clinical-data experience anywhere. Your evidence stops at consumer-PII privacy work.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Harborlight Health care navigation app careers Senior Product Analyst" was refused because permission wasn't granted. It would have settled RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | Search "senior product analyst digital health salary range experimentation Looker" was refused. It would have supplied the market calibration and a pay band for RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

I can offer the dossier, `tuesday-dossier.md`, whenever you want to keep this assessment.

## Upgrade menu

- Search permission, or a link to the live Harborlight posting → RR1 and the contradictions row close, and a market pay band for RR2 becomes available.
- Your pay floor, location and remote constraints → the hard-gates line gets real checks instead of "not given".
- A sanitized test readout, a dashboard inventory or an exec memo → R3, R4 and R6 move toward `high`.
- LookML, a metrics glossary or a definition-change log → G1 can lift R5 to `direct`.
- The hiring manager's name → role reality and the plan's lead story get tuned to that reader.

G1 — Did you personally own metric definitions at the meal-kit company (a metric dictionary, LookML models, a "which number is right" call), and who consumed them?
G2 — Have you worked closely with a domain expert outside product (nutrition, ops, culinary, care) to shape an analysis or test? What did each of you own?
G3 — Have you onboarded, reviewed the work of, or informally mentored other analysts? How many, and over what period?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.