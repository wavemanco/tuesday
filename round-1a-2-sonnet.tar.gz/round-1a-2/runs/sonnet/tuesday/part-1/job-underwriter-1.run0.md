Running the job-underwriter on this posting: fit against each requirement, then the posting's own risks. I haven't searched for anything yet.

## Decision snapshot

**Worth applying to, on the conditions below. Status: `conditional_go`.** You're a strong fit on the core of the role. The open questions are about the posting and your constraints, not your qualifications.

**Fit ledger.**

- `hard_gate`: none in the posting; none stated by you
- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: adjacent: R6, R8 · unclear: R7
- `preferred`: adjacent: R9 (healthcare data experience, HIPAA)

R9 is a bridge with a stated limit. GDPR/CCPA consent work is not HIPAA experience, and it should never be described that way. R6 is adjacent because "governed dashboards" doesn't prove you owned a metrics layer.

**Opportunity ledger.** The scope is clearly stated, with named responsibilities and a mentoring remit (RR3). Compensation and location are withheld (RR1, RR2). I couldn't confirm the employer exists as described (RR4).

- **Hard gates:** none failed; candidate constraints not given, so checks against them are unknown (comp floor, location, authorization).
- **Severe red flags:** none found.
- **Conditions for go:** (1) pay and location clear your constraints (RR1, RR2); (2) the employer checks out (RR4); (3) the healthcare bridge is framed as adjacent, never as HIPAA experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD header, not independently confirmed |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, Looker self-serve, roadmap partnership, mentoring two juniors | `[grounded]` JD |
| Scope read | A normal senior IC role with a light lead component. Mentoring two analysts is not a management title | `[inferred]` from "mentor two junior analysts" against no mention of reports or hiring |
| Market calibration | Senior product analyst roles at Series C health-tech typically pair this scope with experimentation plus BI ownership. The posting gives no pay, so I can't compare it to anything | `[generic]` role-family pattern, not researched |
| Unknowns | Pay, location or remote policy, experiment volume and traffic, whether a metrics layer already exists | n/a |
| Contradictions | None visible in the JD | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a ~2M-subscriber company. It's self-reported, so it stays a lead until verified | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily Snowflake use. "Expert" is your own word and will be probed | `[grounded]` your background | a query sample would raise it |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year, including the pricing test behind an 11% retention lift. Whether "at scale" matches their traffic is unknown | `[grounded]` your background; `[inferred]` scale comparison | none |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the instance from scratch, 40+ governed dashboards | `[grounded]` your background | a dashboard walkthrough would raise it |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly exec metrics memo and monthly VP Product presentation | `[grounded]` your background | a sanitized memo would raise it |
| R6 | Define and maintain the metrics layer | important | adjacent | low | discovery | Governed dashboards suggest metric definitions, but you didn't mention a semantic layer or metric ownership | `[inferred]` from "governed" | gap queue G1 |
| R7 | Mentor two junior analysts | important | unclear | low | discovery | Nothing stated about mentoring or managing | `[grounded]` silence in your background | gap queue G2 |
| R8 | Partner with clinicians to drive roadmap | important | adjacent | medium | transferability | You've partnered with PMs and the VP Product. Clinicians are a different stakeholder, and I've seen no evidence of that work | `[inferred]` from PM and exec partnership | none |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | GDPR/CCPA PII handling and a consent-state warehouse model are real, relevant privacy work. They are not HIPAA | `[grounded]` your background; `[inferred]` adjacency | none; a preferred item, so a minor risk |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, important) | discovery | Governed dashboards, but no mention of shared metric definitions | The JD lists it first among responsibilities | A metrics dictionary, LookML or dbt models you owned, a KPI-definition process | A sanitized definitions doc or model sample | `[inferred]` |
| G2 | Mentoring (R7, important) | discovery | Silence | They need someone to lead two juniors | Onboarding, code review, or coaching analysts informally, even without the title | A concrete example | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Compensation not stated | unknown | — | (no pay figure in the JD) | The band may or may not clear your floor. Many postings withhold pay | `[inferred]` from the posting's silence | What is the budgeted range for this level? | unresolved |
| RR2 | Location and remote policy not stated | unknown | — | (no location in the JD) | It may be on-site or hybrid, which may conflict with your constraints | `[inferred]` from silence | What is the location and remote policy? | unresolved |
| RR3 | Clear scope and mentoring remit | positive_signal | — | "mentor two junior analysts" | The role is defined, with a real team and decision partners | `[grounded]` JD | Who owns the metrics layer today? | noted |
| RR4 | Employer not independently verified | risk_signal | low | "digital-health scale-up, ~400 people, Series C" | The company may be exactly as described. I haven't checked | `[inferred]` from no research run | Is there a live careers-page posting that matches? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the experimentation program and the pricing test behind the 11% retention lift, worded as "designed and ran" the test, not as having caused the lift | R3 is your strongest direct row, and the wording stays within what you've claimed | `[grounded]` your background | pending your approval |
| E2 | Pair the Looker build with the exec memo and VP Product presentation, so it reads as BI plus stakeholder influence | R4 and R5 | `[grounded]` your background | pending your approval |
| E3 | Frame the consent-state model as "privacy and consent data modeling (GDPR/CCPA)", with no HIPAA claim | R9 is adjacent only | `[grounded]` your background | pending your approval |
| Q1 | Ask RR1 to RR4 early, as a recruiter-screen question or an application note | They decide the go | `[grounded]` register | pending your approval |
| A1 | Ask in interviews what experiment volume and traffic they get | Tests R3's "at scale" in both directions | `[inferred]` | pending your approval |

All rows above are proposals. Nothing here changes your resume or goes to anyone until you approve it.

## Evidence status

Verified: none yet.

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | No research consented yet. It would confirm the company exists as described and the posting is live (RR4, contradictions row) |
| 2. Role-family sweep | unavailable | No research consented yet. It would ground the market-calibration line and the pay comparison (RR1) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there's no query to form |

## Dossier offer

If it would help, I can save this as a `tuesday-dossier.md` for later steps such as interview prep.

## Upgrade menu

- Say the word and I'll run the standard research pass (up to 5 searches and 2 page fetches). It moves RR4, the market-calibration line, and RR1's comparison.
- Your pay floor, location and authorization constraints turn the hard-gates line from unknown into a real check.
- An answer to G1 or G2 moves R6 or R7.
- A sanitized metrics doc, memo or dashboard walkthrough would raise R2, R4 and R5 toward `high`.
- The hiring manager's name unlocks a scope read and which story to lead with.
- A resume-tailoring pass, if you decide to apply, is a separate step I can run next.

## Questions

1. **(Hard gates)** What's your pay floor, and any location or remote constraints? Is there anything else non-negotiable?
2. **(G1)** Did you own metric definitions at the meal-kit company, for example a KPI dictionary or LookML or dbt models, or only the dashboards?
3. **(G2)** Have you mentored or onboarded analysts, formally or not?

Answer any of these, say "skip", or paste a document.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.