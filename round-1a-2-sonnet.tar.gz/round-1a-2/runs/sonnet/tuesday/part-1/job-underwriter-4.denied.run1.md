Search permission was declined, so this runs on your pasted JD and background only.

## Decision snapshot

**Yes, apply. Status: `conditional_go`.** R2, R3, R4, R5, R6 and R7 (the `must_have` rows) all read `direct`. The conditions are about the employer, not your fit.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK-based)
- `must_have` — direct: R2, R3, R4, R5, R6, R7
- `important` — direct: R8a · unclear: R8b (Recommendations to product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance domain)

R4 (`medium`) — the closest match to the JD's GLM line, confirmed in your words and waiting on an artifact; R10 — a credible bridge, its limit named; R8b — nothing said yet about product.

**Opportunity ledger.** The responsibilities are concrete (RR3), but the employer could not be established because the searches were refused (RR1), no salary was in the posting as pasted (RR2), and what "own" means for team and review is unstated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK-based); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and the live posting verify — RR1; (2) R1 confirmed; (3) the salary clears your floor — RR2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech, with a pet-insurance product | `[grounded]` JD header |
| Mandate | Own pricing analytics for pet insurance: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` provided by you |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| People management | The JD lists no line-management duty or requirement, so your having managed no one touches no row | `[grounded]` JD silence |
| Scope read | A senior individual-contributor post with end-to-end ownership of one product's pricing analytics | `[inferred]` from "own" and the absence of reports in the JD |
| Market calibration | Not run: the role-family search was refused. The upgrade menu offers it | — |
| Unknowns | Salary; team size and who reviews model changes; current models and tooling; first-year outcomes | `[grounded]` none stated in the JD as pasted |
| Contradictions | None visible between the JD and your background. There was no careers page to compare against | `[grounded]` JD and your message only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You did not state where you are based or your right to work. A UK employer points that way but settles nothing | `[inferred]` from "UK motor insurer" | Question R1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years pricing analytics, stated in prose with no artifact inspected | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is stated and specific. No code or output has been inspected | `[grounded]` your background | Optional: a sanitized query or notebook would raise to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. It is confirmed and specific, with no inspectable artifact yet, so expect a probe on method | `[grounded]` your background | A sanitized model spec or monitoring pack would raise to `high` |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. The JD names underwriting or actuarial leads, so the audience matches | `[grounded]` your background | none |
| R6 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" is stated. Monitoring is implied by maintenance and not described, so the band takes the lower reading | `[grounded]` your background | Confirm in the loop what monitoring you ran (for example drift or loss-ratio tracking) |
| R7 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. "Ran" does not say whether you set the design, so the claim stays at what you said | `[grounded]` your background | Be ready to say which part of each design was yours |
| R8a | Turn results into recommendations for underwriting | important | direct | medium | none | The 14 tests were run with the underwriting team, and you present the quarterly review to its head | `[grounded]` your background | none |
| R8b | Turn results into recommendations for product | important | unclear | low | discovery | Nothing in your background mentions a product team. The JD names product as a recipient | `[grounded]` background silent; `[generic]` insurtechs often have a product function separate from underwriting | Question G1 below |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer. The domain is insurance, though not pet | `[grounded]` your background | none |
| R10 | Pet-insurance domain knowledge (not a stated requirement; the product is the JD's subject) | preferred | adjacent | medium | transferability | Pricing method, GLMs and test design carry over from motor. Limit: you have not priced pet risk, and its rating factors and claims drivers differ from motor | `[inferred]` bridge from your motor GLM work; `[generic]` that pet and motor rating factors differ | Say plainly it is adjacent; consider learning the pet rating factors before interviews |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Recommendations to product (R8b, important) | discovery | Underwriting is well covered. Nothing in your background names product stakeholders | One of the two audiences the JD names. A "yes" removes the only `important` row below `direct` | Pricing proposals that went to a product or proposition team; a price-test readout that changed a product feature or tier; a pricing paper for a commercial committee | A readout deck or a review pack, sanitized | `[grounded]` background silent; `[generic]` that the product audience is separate from underwriting at many insurtechs |
| G2 | Pet-insurance domain (R10, preferred) | transferability | Motor GLM and tests, nothing pet-specific | The likeliest objection from a pricing director hiring for this product | Any pricing work on a non-motor line; any personal or published analysis of pet-claims data | A short note on how you would adapt your rating-factor approach to pet | `[inferred]` bridge; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | no figure in the posting as pasted | The posting may omit pay, or your paste may have dropped it | `[grounded]` JD as pasted | What salary range is budgeted for this role? | unresolved |
| RR3 | Concrete responsibilities and requirements | positive_signal | — | "build and monitor rating models, design and read price tests" | The scope is specific and matches a recognizable pricing-analytics remit | `[grounded]` JD | Which rating models are in production today, and who owns them? | noted |
| RR4 | "Own" with no team described | unknown | — | "Own pricing analytics for our pet-insurance product" | The post may be the sole pricing analyst on the product, with little peer review or support | `[inferred]` from "own" against the JD's silence on team | Who else sits in pricing, and who reviews changes to a rating model? | unresolved |

## Application plan

All rows are proposals. `resume_edits_pending_approval` covers E1 and E2; each other row is marked on its own line.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with your own three facts: you built and maintained the GLM rating model for the young-driver book; you ran 14 price tests last year with the underwriting team; SQL and Python daily | See R4, R7, R3 | `[grounded]` your background | resume_edits_pending_approval |
| E2 | Keep the quarterly pricing review to the head of underwriting as its own line | See R5, R8a | `[grounded]` your background | resume_edits_pending_approval |
| P1 | Frame pet as adjacent: the method carries from motor, and you have not priced pet risk. Do not claim pet knowledge | See R10 | `[grounded]` R10 row | pending your approval |
| A1 | Confirm Brindlemoor and the live posting on its own careers site before investing in the application | See RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the RR1 to RR4 verification questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech careers"; the call was refused. It would have fed RR1 and the contradictions row of role reality |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst insurance UK salary remote"; the call was refused. It would have fed market calibration and the RR2 pay check |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; the call was refused. It would have fed the scope read and which story the plan leads with for Odile Varga |

I can write the full `tuesday-dossier.md` of this assessment if you want it.

**Upgrade menu**

- Allowing search → RR1 can clear or confirm, the market band sets against RR2, and the plan can be tuned to Odile Varga's public work.
- Your pay floor and other non-negotiables → RR2 and the hard-gates line get checked against them.
- A sanitized model spec, monitoring pack or test readout → R4, R6 and R7 can reach `high`.
- A product-facing readout or pricing paper → R8b resolves.

**Questions**

- R1 — Are you based in the UK with the right to work there, so a fully remote UK role is open to you?
- RR2 — Do you have a pay floor or any other non-negotiables, such as hours or location, that this role has to meet?
- G1 — Have you ever taken pricing results to a product or proposition team, and if so, what did you present and what changed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.