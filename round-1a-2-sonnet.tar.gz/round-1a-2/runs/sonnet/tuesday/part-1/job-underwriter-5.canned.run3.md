I fetched the live careers page and ran one search to confirm the company. Here's the assessment.

## Decision snapshot

**Yes, this looks worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (dbt-modelled warehouse in BigQuery); unclear: R10 (Ingestion from app and CRM), R11 (Data contracts for analysts)

R9 (`medium`): a credible bridge via Snowflake, its limit named; R10, R11: nothing in your background yet speaks to them.

**Opportunity ledger.** Pay is disclosed and overlaps the market range you sent (RR1). Team shape, reporting line and first-year outcomes are unstated (RR2, RR3), and whether pay varies by work location is unknown (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 checked against your own location, work authorization and pay floor; (2) team scope and reporting line verify in interviews (RR2, RR3); (3) the BigQuery bridge is framed as adjacent, never as BigQuery experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` About page, pellucidlearning.com/about, matches what you pasted. The Series C figure is the company's own statement and nothing independent corroborated it |
| Mandate | Build and run the pipelines behind the platform's reporting: ingestion from app and CRM, a dbt-modelled warehouse in BigQuery, data contracts for analysts | `[grounded]` careers page, which shows "Accepting applications" |
| Requirements | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` careers page |
| Terms | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` careers page |
| Scope read | The remit runs from ingestion through modelling to contracts, and no team or reporting line is named. That may be wider than one domain's pipelines | `[inferred]` from the posting's silence on team, against the typical scope in the Datawright report |
| Market calibration | The report puts Senior Data Engineer base at Series B–D companies at a median of $151,000, interquartile range $139,000–$163,500, n=2,310. "Senior" typically means 5–8 years, with ownership of one domain and no direct reports. The posting's range runs from just below that median to above the top of the interquartile range | `[grounded]` posting and report figures as supplied; `[generic]` for where they place the role |
| Unknowns | Hiring manager (the posting names none), team size, equity terms, first-year outcomes, whether pay is banded by location | `[grounded]` posting silent on each |
| Contradictions | None between your pasted text and the live pages | `[grounded]` pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't stated your location or work authorization, so nothing settles this term | `[grounded]` posting term; no candidate statement | Question G1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You haven't stated a pay floor, so the term is unchecked. The range itself is firm | `[grounded]` posting figure; no candidate statement | Question G2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years of data engineering at a B2B payroll company. Prose background is self-report and `medium` is the intake ceiling | `[grounded]` your message | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You said you use both daily. No inspectable artifact yet, so expect a probe on depth | `[grounded]` your message | Offer: sanitized code sample would raise to high |
| R5 | dbt | must_have | direct | medium | none | You built your dbt project on Snowflake, about 180 models. Confirmed and specific, no artifact inspected | `[grounded]` your message | Offer: dbt docs or lineage screenshot, sanitized |
| R6 | A cloud warehouse | must_have | direct | medium | none | Your warehouse was Snowflake, which is a cloud data warehouse. The posting's own wording says "a cloud warehouse" | `[grounded]` your message; `[inferred]` that Snowflake counts as one | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration. Scope of what you orchestrated isn't stated | `[grounded]` your message | Offer: DAG screenshot, sanitized |
| R8 | Data quality testing | must_have | direct | medium | none | You set up your company's Great Expectations test suite. No artifact inspected | `[grounded]` your message | Offer: suite config or results, sanitized |
| R9 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Snowflake plus dbt carries over. Limit: you have never used BigQuery, so its cost model, partitioning and tooling are untested by your history | `[grounded]` your message; `[generic]` that warehouses differ on those points | Bridge in G3 |
| R10 | Ingestion from the app and the CRM | important | unclear | low | discovery | Your payroll work may have involved similar ingestion, but you haven't said what your sources were | `[grounded]` your message silent on sources | Question G4 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Great Expectations testing is related to contracts but isn't the same thing, and you haven't described any contract with consumers | `[grounded]` your message; no contract described | See G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and authorization (R1, hard_gate) | hard_gate | The posting allows US-remote or Denver; nothing about your location or right to work | A failed gate would end this; a met one removes the biggest unknown | Not applicable: this is a yes/no term | None needed | `[grounded]` posting term; `[inferred]` that this is the quickest gate to settle |
| G2 | Pay floor (R2, hard_gate) | hard_gate | The range is stated; your floor is not | Settles whether the range clears your own line | Not applicable | None needed | `[grounded]` posting figure |
| G3 | BigQuery (R9, important) | transferability | Snowflake and dbt at scale; no BigQuery | The posting names it as the warehouse | A BigQuery project you set up, even small; a dbt adapter swap you've tried | A small dbt project running on BigQuery, linked | `[inferred]` bridge from your Snowflake work; `[generic]` that an interviewer will test the BigQuery limit |
| G4 | App and CRM ingestion (R10, important) | discovery | Sources at your payroll company not described | A named responsibility, and a recall prompt may turn it direct | Pulling from a product database or event stream; loading CRM or billing-system data; building or running a connector | An architecture diagram, sanitized | `[grounded]` your message silent; `[generic]` that ingestion work is probed in interviews of this kind |
| G5 | Data contracts (R11, important) | discovery | No contract with analysts described | The posting names contracts as a responsibility | Agreeing schemas or freshness expectations with analysts; Great Expectations suites that analysts relied on; dbt tests tied to a stated expectation | A sanitized contract, schema doc or SLA | `[grounded]` your message silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay disclosed, overlaps market range | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Posting is transparent about pay. Equity terms are not given | `[grounded]` posting and report figures | What is the equity grant for this level, and how does it vest? | noted |
| RR2 | Team shape and reporting line unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | Role may carry ingestion, modelling and contracts without a stated team | `[inferred]` from the posting's silence, set against the report's typical one-domain scope | Who does this role report to, and what does the data team around it look like? | unresolved |
| RR3 | No first-year outcomes stated | unknown | — | "the data contracts our analysts depend on" (no outcome or measure follows) | A demanding mandate with no stated definition of success | `[inferred]` from the posting's silence | What should be true of the reporting pipelines twelve months in? | unresolved |
| RR4 | Pay and location rules unstated | unknown | — | "Remote (US) or our Denver office" | One range is given for both options; whether it applies the same to each is unstated | `[generic]` some employers set pay by location | Does the salary range apply the same whether I work remotely or from Denver? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle R1 and R2 (G1, G2) before spending effort on the application | A failed gate ends it | `[grounded]` posting terms | pending your approval |
| A2 | Positioning advice: lead with the facts in your own words: 6 years of data engineering at a B2B payroll company; built the dbt project on Snowflake, about 180 models; Airflow for orchestration; set up the Great Expectations test suite | These are R3, R5, R7, R8, each traced to your sentences | `[grounded]` your message | pending your approval |
| A3 | Positioning advice: say plainly you haven't used BigQuery and name Snowflake as the warehouse you've done it on. Don't write BigQuery experience or an equivalent | Keeps R9 honest as adjacent | `[grounded]` your message | pending your approval |
| W1 | Optional work sample: a small dbt project run on BigQuery, only if you'd do it anyway | Narrows R9's limit | `[inferred]` from R9's limit | pending your approval |
| Q1 | Ask the verification questions of RR1 to RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | Ask your recruiter who the hiring manager is | The posting names none | `[grounded]` posting | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer); searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about). Both checked your pasted text: they match, and the posting is live. Moved role reality's Organization and Contradictions rows. No other source turned up, so the funding claim rests on the company's own page |
| 2. Role-family sweep | skipped | Your Datawright report is in hand and fixes the market calibration row and RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

I can save all of this as `tuesday-dossier.md` if you want it. It's optional.

## Upgrade menu

- Your CV or a sanitized artifact (dbt docs or lineage, a DAG screenshot, a Great Expectations suite, a code sample) → R4, R5, R7, R8 can move from `medium` toward `high`, and any presentation gaps in your CV would show.
- Your location, work authorization and pay floor → R1 and R2 resolve, and the decision likely simplifies to `go` or `no_go`.
- A small BigQuery project → R9's limit narrows.
- A description of your ingestion sources and any analyst-facing contracts → R10 and R11 resolve.
- The hiring manager's name from your recruiter → role reality's scope read, and the positioning in the plan.
- A deeper research pass on Pellucid Learning (independent check of the funding, leadership changes, employee and candidate reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

G1 — Can you work remotely from within the US, or in Denver, without needing visa sponsorship?

G2 — Is $148,000–$166,000 plus equity at or above your pay floor?

G4 — At your payroll company, which sources did you pull data in from, and which part of that pipeline did you personally build or run?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.