**Yes, apply, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6, R7a, R8 · unclear: R7b (recommendations for product)
- `important` — adjacent: R10 (pet-insurance domain knowledge)
- `preferred` — direct: R9

R10 (`medium`) — a credible bridge, its limit named; R7b — your account is silent on product; R6 (`medium`) — direct, waiting on how much of the test design was yours.

**Opportunity ledger.** The posting names three concrete duties (RR4), but the employer is unverified (RR1), the team scope is unstated (RR2) and no salary is given (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify on Brindlemoor's own careers page (RR1); (2) you confirm you are UK-based (R1); (3) the pet-insurance gap is framed honestly as adjacent motor experience (R10, G4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. The entity is not established (see Evidence status) | `[grounded]` JD header; `[grounded]` no search ran |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` as you gave it |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | Reads as a senior individual-contributor post on one product line, since the JD lists no reports or team | `[inferred]` from the title and the JD's silence on reports |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not calibrated: the salary sweep did not run and the JD states no pay | `[grounded]` JD silent on pay; research unavailable |
| Unknowns | Salary; direct reports or team size; pricing tooling and data maturity; how the product team receives recommendations | `[grounded]` JD silent on each |
| Contradictions | None visible inside the JD | `[grounded]` JD as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You have not stated where you are based. A UK employer suggests UK, but that is not confirmation | `[inferred]` from your employer being a UK motor insurer | G1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics, which clears 4+. It is self-reported with no CV or artifact yet | `[grounded]` your stated background | Share your CV |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You say you use both daily. "Strong" is not yet shown by anything inspectable | `[grounded]` your stated background | Offer: a sanitized query or notebook would raise to high |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for your employer's young-driver book. The claim is scoped to that one book | `[grounded]` your stated background | Offer: sanitized model documentation would raise to high |
| R5 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" covers building. Monitoring is implied by "maintained" but not stated, so take the lower reading and be ready to say what monitoring you did | `[grounded]` your stated background; `[inferred]` monitoring from "maintained" | Be ready to describe your monitoring |
| R6 | Design and read price tests | must_have | direct | medium | discovery | You ran 14 price tests last year with underwriting. Whether you designed them (control groups, sizing) and read the results is not stated | `[grounded]` your stated background | G3 |
| R7a | Turn results into recommendations for underwriting | must_have | direct | medium | none | You ran the tests with the underwriting team and present the quarterly pricing review to the head of underwriting | `[grounded]` your stated background | none |
| R7b | Turn results into recommendations for product | must_have | unclear | none | discovery | Your account mentions underwriting and says nothing about a product team | `[grounded]` silence in your account | G2 |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. Actuarial audiences are not mentioned | `[grounded]` your stated background | none |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer is insurance experience, though not pet | `[grounded]` your stated background | none |
| R10 | Pet-insurance domain knowledge (inferred from "our pet-insurance product") | important | adjacent | medium | transferability | Motor GLM rating work carries over in method. Limit: you have not priced pet, and pet rating inputs and claims patterns differ from motor | `[inferred]` bridge from your motor work; `[generic]` that pet differs from motor in rating inputs | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK-based, fully remote (R1, hard_gate) | hard_gate | Your background does not say where you live | A gate not yet established stays visible in the snapshot until you answer | Not applicable | Your answer is enough | `[grounded]` your account silent on location |
| G2 | Recommendations for product (R7b, must_have) | discovery | Underwriting is covered; a product team is not mentioned | A `must_have` row at `unclear`; answering could move it to `direct` | A price-test result that changed a rate or product feature; a pricing review where a product or commercial lead was in the room; a recommendation on rates or retention that a non-underwriting team acted on | A review deck extract or a test write-up, sanitized | `[grounded]` your account silent on product; `[generic]` that this role family usually hands pricing results to a product team |
| G3 | Price-test design (R6, must_have) | discovery | You ran 14 tests; your role in design and readout is not stated | "Design and read" is the JD's wording, and an interviewer will ask what was yours | Choosing test and control groups; sizing a test; deciding when a result was strong enough to act on; writing the readout | A sanitized test plan or readout | `[grounded]` your account says "ran"; `[generic]` that interviews probe design ownership |
| G4 | Pet-insurance knowledge (R10, important) | transferability | Motor GLM rating, no pet work | The likeliest objection to your application | Renewal or retention pricing; claims-inflation or trend analysis; any non-motor product contact | An optional one-page note on how a frequency-and-severity GLM structure would carry to pet, built from public information only | `[inferred]` bridge from your motor work; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Scope of "own" and team size unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may be the sole pricing analyst on the product, or may carry reports. The JD lists none, and you have not managed anyone | `[inferred]` from "own" against the JD's silence on team | Does this role have direct reports now or planned, and who else sits in pricing for the pet product? | unresolved |
| RR3 | No salary stated | unknown | — | No figure appears in the pasted JD | The figure may be withheld, or the pasted text may have omitted it | `[inferred]` from the pasted JD | What salary range is budgeted for this role? | unresolved |
| RR4 | Three concrete duties named | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations for underwriting and product" | The duties are specific and map onto your stated work, so the role looks defined | `[grounded]` JD states all three | Which of the three takes most of the week, and what does the pricing stack look like? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on Brindlemoor's own careers page, or ask the recruiter, before investing in the application | see RR1 | `[grounded]` RR1 | pending your approval |
| P1 | Lead with three items in your own words: you built and maintained the GLM rating model for the young-driver book; you ran 14 price tests last year with the underwriting team; you present the quarterly pricing review to the head of underwriting | see R4, R6, R8 | `[grounded]` your stated background | pending your approval |
| P2 | State the pet gap plainly: your pricing work is motor, you have not worked on pet insurance, and the method carries over | see R10, G4 | `[grounded]` your stated background | pending your approval |
| P3 | If asked about line management, say you have not managed anyone. The JD lists no management requirement, and RR2 asks whether the role has reports | see RR2 | `[grounded]` JD silent on management, your account | pending your approval |
| W1 | Optionally, a short sanitized write-up of one price test or model-monitoring routine, with nothing confidential | see R3, R4, R6 | `[grounded]` R3, R4, R6 rows | pending your approval |
| Q1 | Ask the questions in RR1 to RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search for Brindlemoor and its careers page was not permitted in this session. It would have confirmed the entity and whether the posting is live. It would have moved the organization row in role reality and RR1 |
| 2. Role-family sweep | unavailable | The search for senior pet-insurance pricing salary and scope was not permitted. It would have given the market calibration row and a band to set against RR3 |
| 3. Hiring manager's public footprint | unavailable | The search for Odile Varga's public professional footprint was not permitted. It would have informed the scope read and which story the application plan leads with |

I can offer a one-page dossier file of this assessment to keep, `tuesday-dossier.md`, if you want it.

**Upgrade menu**

- Your CV → R2 to R9 can move toward `high` where it carries inspectable detail, and presentation gaps become visible.
- A sanitized query, notebook, model document or price-test readout → R3, R4, R5 or R6 to `high`.
- A link to the live posting on Brindlemoor's own careers page, or the recruiter's email domain → RR1 closes, and the decision can move from `conditional_go` toward `go`.
- The budgeted salary → RR3 closes and can be set against your current pay once you share a floor.
- Permission for the searches to run (up to 5 searches and 2 fetches) → the organization row, market calibration and the hiring-manager read.

**Questions**

G1 — Are you UK-based and able to work remotely from the UK?

G2 — Have you taken price-test or rating results to a product, commercial or proposition team, as opposed to underwriting? What did you recommend, and what happened?

G3 — In the 14 price tests, what did you personally own: choosing test and control groups, sizing the test, running it, reading the result, or writing the recommendation?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.