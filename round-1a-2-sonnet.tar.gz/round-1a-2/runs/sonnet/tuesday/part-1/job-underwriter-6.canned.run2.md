# Job Underwriting — Revenue Operations Lead, Quillfield

## Decision snapshot

**Yes, apply, on conditions. R1 and R2 are hard gates only you can confirm, and R6, R7a and R7b are must-have rows to prepare for. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000)
- `must_have` — direct: R3, R4 · adjacent: R5 (strong SQL and spreadsheet modelling) · unclear: R6 (experience owning a forecast), R7b (revenue data with finance) · absent: R7a (billing data with finance)
- `important` — direct: R8 · adjacent: R9 (quarterly forecast with the CFO)

R7a — you confirmed it is absent; R6 and R7b — recoverable if earlier work counts; R9 — a credible bridge, its limit named.

**Opportunity ledger.** The employer matches the posting and the pay is stated (RR1, RR7). Unknowns remain on the listing source, equity, forecast ownership and success measures (RR2, RR3, RR5, RR6). One low-severity risk concerns scope that goes beyond your stated background (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm Bristol with two office days and the pay band work for you (R1, R2); (2) you can name any forecast you owned, or finance-linked revenue data you worked with, or you go in with those rows stated as limits (R6, R7b); (3) you say plainly that you have not worked on billing data and have a ramp answer ready (R7a, RR4); (4) the forecast and reporting-line split is clarified with the recruiter (RR5).
- **What would change this:** it becomes `no_go` if R1 or R2 fails, because a failed gate is not fixed by wording.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` quillfield.co.uk/about (search result) |
| Mandate | Own CRM and billing data, build pipeline and renewal reporting for sales and finance, run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Location and pay | Bristol, hybrid, two days a week in the office; £61,500–£67,000 plus share options; option terms not stated | `[grounded]` posting |
| Hiring manager | Tamsin Achebe is listed as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. Search snippet only, page not fetched | `[grounded]` search result, linkedin.example/in/tamsin-achebe |
| Scope read | Three functions in one post: data ownership including billing, reporting, and a forecast shared with the CFO. A revenue operations head already exists, so this is not a from-scratch function | `[inferred]` from the posting's responsibility list against the profile snippet |
| Market calibration | UK B2B software revenue operations lead: median base £64,200, interquartile range £57,800–£70,400, n=438. The posted band sits inside that range around the median. It is a market band, not Quillfield's offer | `[generic]` Ledgerline 2026 pay guide; `[grounded]` posting for the figure |
| Unknowns | Who owns the forecast today, reporting line, billing system and data model, share-option terms, first-year outcomes, listing on Quillfield's own careers page | `[grounded]` posting silent on each |
| Contradictions | None between the posting and the About page. The role itself did not appear on Quillfield's own site in the search (RR2) | `[grounded]` About page against posting |

## Evidence map

Your background was given in prose, so it counts as self-report and `medium` is the ceiling.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | You gave no location or commute constraint, so nothing settles this gate | `[grounded]` posting term; no candidate statement | Asked below; only you can answer |
| R2 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | You gave no pay floor. The posting states the band, which is the term to test | `[grounded]` posting; no candidate statement | Asked below |
| R3 | 4+ years in revenue operations, sales operations or similar analytics at a B2B software company | must_have | direct | medium | none | 5 years in sales operations at a B2B payments company, the last 2 running revenue operations for the UK team, is stated by you and uninspected. The posting says B2B software and your employer is described as payments, so the sector fit is a probe, not a gate | `[grounded]` your statement; years requirement is not a gate per the conventions | none |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, with the pipeline and renewal dashboards rebuilt. The certification is stated, not inspected | `[grounded]` your statement | The certification record would raise this to `high` |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | SQL weekly and Excel daily show use. Strength and modelling, as against reporting, are not stated | `[grounded]` your statement; limit is the silence on modelling | A sanitized query or model would raise it |
| R6 | Experience owning a forecast | must_have | unclear | low | discovery | You said finance owned the company forecast. Whether you owned any narrower forecast, such as a team or pipeline forecast, is not stated. The monthly pipeline review with your sales director is adjacent, not forecast ownership | `[grounded]` your statement and its silence | Asked below (G1) |
| R7a | Working with finance on billing data | must_have | absent | none | capability | You said you have never worked on billing data, and no adjacent work is stated | `[grounded]` your statement | Closure path in G3; carry as material risk |
| R7b | Working with finance on revenue data | must_have | unclear | low | discovery | The posting says "billing or revenue data". Renewal dashboards may have touched revenue data, but finance's involvement is not stated | `[grounded]` posting wording; `[inferred]` that the dashboards may count | Asked below (G2) |
| R8 | Build the pipeline and renewal reporting sales and finance run on | important | direct | medium | none | You rebuilt your company's pipeline and renewal dashboards. Whether finance used them is not stated | `[grounded]` your statement | none |
| R9 | Run the quarterly revenue forecast with the CFO | important | adjacent | medium | transferability | You run the monthly pipeline review with your sales director. That is not a quarterly company forecast and not at CFO level | `[grounded]` your statement; limit is mine | A sanitized pipeline-review pack would narrow the limit |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6, must_have) | discovery | Finance owned the company forecast. Nothing says whether you owned a narrower one | Resolving it moves a must-have row from `unclear` toward `adjacent` or `direct`, and it is the part of the role that works with the CFO | A UK-team bookings or renewals projection you produced; a pipeline-coverage call that fed finance's number; a quarterly target you set with the sales director | A sanitized forecast sheet or pipeline-review deck | `[grounded]` your statement and silence; `[inferred]` that it affects the decision |
| G2 | Revenue data with finance (R7b, must_have) | discovery | Renewal dashboards exist, but their data source and finance's involvement are not stated | The posting accepts "billing or revenue data", so this is the closest route to the finance requirement | Renewal values or ARR figures reconciled with finance; a dashboard finance reviewed or signed off | A dashboard screenshot with figures removed | `[grounded]` posting wording; `[inferred]` that renewals may count |
| G3 | Billing data (R7a, must_have) | capability | You have not worked on billing data, and nothing adjacent is stated | The posting makes billing data part of what the role owns (RR4) | None to ask about; you confirmed it. If an adjacent case surfaces later, this reopens | Nothing to request now | `[grounded]` your statement |
| G4 | Forecast with the CFO (R9, important) | transferability | Monthly pipeline review with a sales director | Bridge: the pipeline-review discipline carries over. Limit: not a quarterly company forecast, no CFO counterpart. Strengthener: a sanitized review pack | You presenting pipeline movement to someone senior and being challenged on it | A pipeline-review pack | `[grounded]` your statement; limit is mine |
| G5 | SQL and modelling depth (R5, must_have) | discovery | Usage frequency is stated, not depth or modelling | Confidence goes from `medium` to `high` only with an inspectable sample | A multi-table query behind a dashboard; a renewal or churn model in Excel | A sanitized query or workbook | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer matches the posting | positive_signal | — | "Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol; 96 employees." | The employer is a real, funded software company of the described type | `[grounded]` About page, search result | How large is the revenue operations team today? | noted |
| RR2 | Role not seen on the employer's own careers page | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | The Tallyboard listing may be a copy, or the careers page simply was not returned. A recruiter is already in contact, which points the other way | `[inferred]` from one search returning only the About page; `[generic]` that boards can carry stale copies | Is this role open now, and where is it listed on Quillfield's own site? | unresolved |
| RR3 | Share options unspecified | unknown | — | "plus share options" | Grant size, vesting and strike are unknown, so the pay package cannot be compared with R2 | `[grounded]` posting silent | What are the share-option grant size, vesting and strike price for this level? | unresolved |
| RR4 | Scope beyond your stated background | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting ... and run the quarterly revenue forecast with the CFO" | Two of the three jobs, billing data and the forecast, sit outside your stated experience, so ramp expectations may be higher than the title suggests. Severity is `low` because a stated ramp plan can address it | `[inferred]` from the posting's list against your background | Which of CRM, billing data and the forecast would I own on day one, and which would be handed over while I ramp? | unresolved |
| RR5 | Reporting line and forecast split | unknown | — | "run the quarterly revenue forecast with the CFO" | With a Head of Revenue Operations in post, this role may sit under that post and share the forecast | `[inferred]` from the profile snippet against the posting | Who owns the forecast today, and who does this role report to? | unresolved |
| RR6 | No success measures stated | unknown | — | the posting gives no first-year outcomes | Success is undefined in the posting | `[grounded]` posting silent | What would success look like for this role in the first year? | unresolved |
| RR7 | Pay stated and near the market median | positive_signal | — | "£61,500–£67,000" | The posting is transparent on base pay | `[grounded]` posting; `[generic]` Ledgerline band | Where in the band would this role sit, and what decides that? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm Bristol with two office days and the band with the recruiter before investing in the process | R1, R2 | `[grounded]` posting terms | pending your approval |
| A2 | Lead with the rebuilt pipeline and renewal dashboards and the monthly pipeline review with your sales director, in your own words and scope | R8, R9 | `[grounded]` your statements | pending your approval |
| A3 | Say plainly that finance owned the company forecast and that you have not worked on billing data, and have a ramp answer ready | R6, R7a, RR4 | `[grounded]` your statements | pending your approval |
| A4 | Ask RR2, RR3, RR5 and RR6 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | If you go ahead, resume-tailor can adjust your CV to this role | Fit and CV language are separate jobs | `[grounded]` request scope | pending your approval |

Positioning must stay inside what you told me. For example, "ran the monthly pipeline review with our sales director" cannot become "owned the forecast".

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers Revenue Operations Lead Bristol", which returned "About Quillfield" (quillfield.co.uk/about). It moved the Organization row and RR1. It did not return the role on Quillfield's own site, which is RR2 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). It moved the market calibration row and RR7. The guide is UK-wide, not Bristol-specific |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), a snippet only. It moved the hiring-manager row, the scope read and RR5 |

I can also write this up as `tuesday-dossier.md` if you'd like to carry it forward.

## Upgrade menu

- Your location and pay floor → R1 and R2 resolve, and the decision becomes `go` or `no_go`.
- A sanitized forecast sheet or pipeline-review pack → R6 and R9 firm up.
- A dashboard screenshot with figures removed, showing renewal or revenue values → R7b and R8 raise.
- The Salesforce certification record → R4 to `high`.
- A sanitized query or workbook → R5 to `high`.
- Your CV → presentation gaps can be checked against the rows.
- The recruiter's answers on forecast ownership, reporting line and share options → RR3 and RR5 close.
- The role's link on Quillfield's own careers page → RR2 closes.
- Deeper research on Quillfield, covering funding follow-through, leadership changes and recent news (up to 5 more searches and 2 more fetches) — say the word and it runs.

R1, R2 — Does working from Bristol two days a week, at £61,500–£67,000, fit what you need?

G1 — Have you ever owned any forecast, even a UK-team or renewals projection, and what did you own versus finance?

G2 — Did any of your renewal or pipeline dashboards use revenue figures that finance supplied or checked, and what was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.