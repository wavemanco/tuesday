I'm still loading the underwriter's remaining rule files (decision format, output rules, worked report) before I write the assessment.
## Decision snapshot

**No, you are not wasting your time. This role is a stretch rather than a long shot: R1a (3+ titled PM years) is absent, while R3, R4a and R7 land `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1b (PM-type work without the title), R2 (Shipped API or platform products) · unclear: R4b (Stakeholder work with sales), R5 (Agile delivery) · absent: R1a (3+ years of titled PM experience)
- `important` — direct: R7 · adjacent: R6 (Own the roadmap), R8 (Specs and drive two squads), R10 (Launches with sales and support) · unclear: R9 (Adoption metrics)

R1a — the one row no wording can fix; R1b and R2 — bridges with their limits named; R4b, R5, R9 — the resume is silent.

**Opportunity ledger.** The role is well-scoped on paper: it names two squads, partner discovery and adoption metrics (RR3). Four things are open: the employer is unverified because my research was refused (RR1), how strictly the years floor is applied (RR2), pay (RR4), and who wins when partner requests collide with the roadmap (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the years floor proves flexible for someone with your background (R1a, RR2); (2) the employer and live posting verify (RR1); (3) R2 and R9 get confirmed evidence, not just resume prose.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; not checked against the company's own site |
| Mandate | Own the roadmap for a partner-facing API platform, with discovery, specs, delivery with two squads, adoption metrics and launches | `[grounded]` JD |
| Scope read | A single-product-area PM post at roughly mid-level | `[inferred]` from the 3+ years floor and two squads |
| Market calibration | Not established: the role-family sweep did not run, and the JD states no pay | `[grounded]` JD silent on pay; sweep refused |
| Unknowns | Pay, how strictly the years floor is applied, roadmap authority, first-year targets, hiring manager | `[grounded]` JD silence |
| Contradictions | None found between the JD and your resume; the JD was not checked against a careers page | `[grounded]` the two documents compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years of PM experience, titled | must_have | absent | none | capability | You state you have never held a PM title, so there are no titled years. A years floor is often applied literally at first screen. | `[grounded]` your statement and the JD's must-have; `[generic]` on literal screening | Ask the employer about flexibility (RR2); see G4 |
| R1b | PM-type work done without the title | must_have | adjacent | medium | transferability | Your requirements documents, your coordination of engineers and PMs on custom builds, and your quarterly roadmap-input sessions are PM-adjacent. Limit: you fed product and did not decide it. | `[grounded]` your resume prose; limit read from the same text | Lead with these items (E1) |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | Over 30 client integrations of your vendor's REST APIs show deep use of an API product. Limit: nothing says you shipped or owned one. A possible internal triage tool is an unconfirmed lead only. | `[grounded]` resume prose; `[grounded]` the lead is unconfirmed | G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI reading and integration architecture are stated and specific. No artifact has been inspected yet. | `[grounded]` resume prose | Optional: a redacted integration design |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and PMs, and ran client workshops. The claim is specific but carries no artifact. | `[grounded]` resume prose | none |
| R4b | Stakeholder management with sales | must_have | unclear | low | discovery | The resume does not mention working with sales. | `[grounded]` resume silence | G3 |
| R5 | Agile delivery | must_have | unclear | low | discovery | UAT and go-live are described, but sprints, backlogs or tickets are not. | `[grounded]` resume silence on agile practice | G2 |
| R6 | Own the partner-API roadmap | important | adjacent | medium | transferability | You collected client feedback for product each quarter. Limit: that is input to someone else's roadmap, not ownership of one. | `[grounded]` resume prose | Name your input-to-outcome link if one exists |
| R7 | Run discovery with integration partners | important | direct | medium | presentation | Scoping workshops and feedback sessions with clients are close to this. The resume files them under implementation, not discovery. | `[grounded]` resume prose | E1 |
| R8 | Write specs and drive delivery with two squads | important | adjacent | medium | transferability | You wrote requirements documents and coordinated engineers on custom builds. Limit: nothing says you drove a squad's delivery or priorities. | `[grounded]` resume prose | G1 |
| R9 | Define and track adoption metrics | important | unclear | none | discovery | Nothing in the resume covers adoption measurement. | `[grounded]` resume silence | G1 |
| R10 | Launches with sales and support | important | adjacent | medium | transferability | You ran go-lives with clients. Limit: nothing says you coordinated a launch with sales and support teams. | `[grounded]` resume prose | none yet |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped product ownership and adoption (R2, R9, R8; must_have) | discovery | Heavy API use, but no confirmed product you owned, and no adoption measure | R2 is a `must_have` at `adjacent`; one confirmed owned thing could move several rows | The internal tool, the integration playbook, a custom build you specified, any tool whose uptake you tracked | A spec you wrote (redacted), usage numbers, a roadmap-input summary, release notes | `[grounded]` resume silence; `[inferred]` that one confirmed item would lift three rows |
| G2 | Agile delivery (R5, must_have) | discovery | No sprint, backlog or ticket evidence | An unevidenced `must_have` | Writing acceptance criteria a squad built from; backlog grooming; sprint reviews | Redacted tickets or a sprint board | `[grounded]` resume silence |
| G3 | Sales collaboration (R4b, must_have) | discovery | No mention of sales | A named `must_have` in the JD | Joint scoping with sales; handoffs from sale to implementation | A handoff template or deal-support note | `[grounded]` resume silence |
| G4 | Titled PM years (R1a, must_have) | capability | No titled PM years, confirmed by you | No wording closes it; it is a risk to carry | Not applicable; titles can't be reworded | none | `[grounded]` your statement; `[generic]` that API and platform PM roles often accept integration-side experience |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "B2B logistics-tech, ~150 people, Series B" | The employer was not checked; it may be too new or small for a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern, not a claim about this company; the search was refused | Can you point me to this role on your careers site, and who would I interview with? | unresolved |
| RR2 | Years floor may be applied literally | unknown | — | "3+ years product management experience (must-have)" | A candidate whose product work sat under another title may be screened out, or may be welcomed | `[generic]` years floors are often screened at first pass | Would you consider a candidate whose product work was done as an implementation lead, not under a PM title? | unresolved |
| RR3 | Clear scope, squads and metrics | positive_signal | — | "drive delivery with two engineering squads; define and track adoption metrics" | The role has a defined shape and measurable outcomes | `[grounded]` JD text | Which adoption metrics matter most in the first year? | noted |
| RR4 | Pay not stated | unknown | — | no compensation in the JD | The band may sit above or below what you need | `[grounded]` JD silence; no band was researched | What is the budgeted range for this post? | unresolved |
| RR5 | Roadmap authority against partner requests | unknown | — | "Own the roadmap" beside "coordinate launches with sales" | The PM may own the roadmap on paper while custom partner requests pull it around | `[generic]` platform PM roles at companies this size often face this | When a partner or sales request conflicts with the roadmap, who decides? | unresolved |

## Application plan

`resume_edits_pending_approval`

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Reorder only: move the roadmap-input sessions, the engineer-and-PM coordination, the requirements documents and the playbook above the integration-delivery bullets. Keep your title and every word of your own lines. | R1b, R7 | `[grounded]` your resume prose | pending your approval |
| E2 | Do not write "product management experience", "owned the roadmap" or any product-ownership claim until G1 is confirmed. | R1a, R2, R6 | `[grounded]` your statement and the map | pending your approval |
| A1 | Confirm the posting is live on Quartzline's own careers page before spending effort. | RR1 | `[grounded]` register | pending your approval |
| A2 | Ask RR2 and RR5 verbatim at the first recruiter contact. | RR2, RR5 | `[grounded]` register | pending your approval |
| A3 | Beyond this role, weigh other API, platform and integration PM postings where integration work is the stated differentiator. | R1b, R2 | `[generic]` role-family pattern, not a claim about any employer | pending your approval |

Beyond the spec, offered: a short cover-note draft built only from claims you confirm, with every clause traced to your own sentences. It is built only on your approval.

## Evidence status

Verified: none yet. Unverified leads: an earlier-conversation mention of an internal request-triage tool that support agents adopted. It is unconfirmed and serves only as the basis for the G1 question.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches sent ("Quartzline logistics technology Series B partner API platform"; "Quartzline careers Product Manager Platform APIs"), both refused. It would have settled RR1 and whether the posting is live. |
| 2. Role-family sweep | unavailable | One search sent ("platform API product manager salary requirements solutions engineer to product manager transition"), refused. It would have supplied the market calibration and the RR4 band. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

I did not retry the refused searches.

I can save this as `tuesday-dossier.md` to carry into later steps.

## Upgrade menu

- Permission to search: RR1 and the market calibration get checked.
- An answer to G1, or an inspectable artifact (a redacted spec, a roadmap-input summary, usage numbers for the tool): R2, R8 and R9 can rise a band.
- A sprint board or ticket sample: R5 resolves.
- The recruiter's answers to RR2, RR4 and RR5: the decision likely simplifies to `go` or `no_go`.
- Your non-negotiables on pay, location and title: the hard-gate checks run instead of showing unknown.
- A hiring manager's name: the scope read and the lead story get tuned.

## Questions

G1 — In an earlier conversation you mentioned an internal request-triage tool that support agents adopted. I haven't confirmed it. Did you build or own it, what did you decide versus others, and how did you know it was being used? Anything else you owned like a product counts.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — With your engineers on custom builds, did you write tickets or acceptance criteria they built from, or prioritise a backlog or sprint?

C1 — Do you have non-negotiables on pay, location or travel, or on taking a title step down?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.