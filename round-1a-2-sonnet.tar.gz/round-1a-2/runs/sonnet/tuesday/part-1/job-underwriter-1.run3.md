Checking whether Harborlight Health and this role exist as described, then I'll write up the verdict.
**Yes, apply. You fit the core requirements (R1, R2, R3, R4, R5 are `direct`), and the status is `conditional_go`.** The condition is that the employer and the posting check out. My web searches were refused, so I couldn't check them myself.

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5 · adjacent: R6 (metrics layer)
- `important` — direct: R7a · unclear: R7b (clinicians), R8 (mentor two junior analysts)
- `preferred` — adjacent: R9b (HIPAA/privacy) · absent: R9a (healthcare data)

R6 — a bridge, not proof of owning a metrics layer; R8 — your background is silent on mentoring; R9a, R9b — a thin plus, with a real privacy bridge on R9b.

**Opportunity ledger.** The employer is unverified because research did not run (RR1). Pay and location are not stated (RR2), and success metrics are not stated (RR3). On the positive side, the scope is concrete and a junior team already exists (RR4). Whether you would handle patient data is unknown (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) pay and location, once stated, fit your constraints (RR2); (3) you confirm you owned metric definitions before claiming them (R6, G1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C (as the posting states it; not independently checked) | `[grounded]` JD header |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, Looker self-serve dashboards, PM and clinician partnership, mentoring two juniors | `[grounded]` JD |
| Scope read | A normal senior individual-contributor scope with light people leadership; the strongest weight sits on experimentation and metrics | `[inferred]` from the responsibility list and the "mentor two" line |
| Market calibration | Not available: the role-family sweep did not run, and the JD states no pay | `[grounded]` JD silence; sweep refused |
| Unknowns | Pay, location or remote policy, first-year outcomes, current state of the metrics layer, reporting line, PHI exposure | `[grounded]` JD silence |
| Contradictions | None visible inside the JD; no outside source was available to compare | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years stated, at a ~2M-subscriber consumer company; self-reported, nothing inspected | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake is specific; "expert" rests on your word and has no inspectable artifact. Expect a live SQL exercise | `[grounded]` your background; `[generic]` that analyst loops usually test SQL live | Offer a sanitized query or model as an artifact |
| R3 | Experiment design at scale | must_have | direct | medium | presentation | 30+ tests a year and a pricing test behind an 11% retention lift are specific and outcome-bearing. Neither is inspectable yet, and the design choices (power, guardrails) are not on the page | `[grounded]` your background; `[generic]` that experiment roles probe design choices | E1 pending approval |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the instance from scratch, 40+ governed dashboards; stronger than the requirement asks | `[grounded]` your background | A screenshot or catalog list would raise it |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | A monthly exec metrics memo and a monthly VP Product presentation | `[grounded]` your background | A sanitized memo would raise it |
| R6 | Define and maintain the metrics layer | must_have | adjacent | low | discovery | "Governed dashboards" suggests shared definitions, but you did not say you owned definitions, a semantic layer or change control. Taking the lower band | `[grounded]` background silence on definitions | G1 |
| R7a | Partner with product managers on roadmap decisions | important | direct | medium | none | Monthly VP Product presentation; the pricing test is a decision-bearing analysis | `[grounded]` your background | none |
| R7b | Partner with clinicians | important | unclear | low | discovery | Nothing on clinician or subject-expert stakeholders either way | `[grounded]` background silence | G3 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | No mentoring mentioned in your background | `[grounded]` background silence | G2 |
| R9a | Healthcare data experience | preferred | absent | none | capability | No healthcare work; stated by you. A plus, not a requirement | `[grounded]` your statement | Carry as minor risk |
| R9b | HIPAA-relevant privacy handling | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII and a consent-state model in the warehouse. Limit: HIPAA's rules on health information, such as PHI and its de-identification standards, were not exercised | `[grounded]` your background; `[generic]` that HIPAA differs from consumer-privacy regimes | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | Governed Looker dashboards, but no stated ownership of definitions | It is the JD's first responsibility; confirming it could lift R6 to `direct` | Owning LookML or a metric dictionary; reconciling conflicting definitions of churn or retention; a change process for metric edits | A metric dictionary, LookML repo excerpt, or governance doc (sanitized) | `[grounded]` background silence; `[inferred]` that it is the most decision-moving gap |
| G2 | Mentoring (R8, important) | discovery | Silent | The JD names two junior analysts | Onboarding analysts, reviewing their SQL or analyses, running office hours | Any written feedback or onboarding doc | `[grounded]` background silence |
| G3 | Clinician partnership (R7b, important) | discovery | Silent | The role works with clinicians | Working with any subject-matter experts (nutritionists, ops, legal) to shape a metric or test | A brief or deck from such a project | `[grounded]` background silence |
| G4 | HIPAA bridge (R9b, preferred) | transferability | Strong consumer-privacy and consent work | It is the one named plus you can speak to | Consent-state model design, PII access controls, data-subject request handling | A sanitized consent-model diagram | `[grounded]` your background; `[generic]` that the regimes differ |

R9a has no closure path from your side and is carried as a minor risk, since it is a preferred item.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be too new or small for a footprint, the posting may be stale, or it may not be a live hiring employer; the check did not run, so none of these is ranked | `[generic]` pattern, not a claim about this company | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay and location not stated | unknown | — | The posting as pasted has no salary, location or work arrangement | The posting may omit them, or they may be in the full listing | `[grounded]` JD silence | What is the salary band, and is the role remote, hybrid or on-site? | unresolved |
| RR3 | No success metrics or first-year outcomes | unknown | — | "Own product analytics for our care-navigation app" | A broad ownership mandate with no stated outcomes could mean unclear priorities | `[inferred]` from the JD's silence on outcomes | What would success look like at twelve months, and what state is the metrics layer in today? | unresolved |
| RR4 | Concrete scope and an existing junior team | positive_signal | — | "mentor two junior analysts" | A named team and a named BI tool suggest an established function | `[inferred]` from the JD's specificity | Who does this role report to, and who do the juniors report to today? | noted |
| RR5 | PHI exposure terms unknown | unknown | — | "healthcare data experience (HIPAA) a plus" | A health app's analytics may involve PHI or de-identified data, with access training attached | `[generic]` pattern for health products | How is PHI handled in the analytics warehouse, and what access training is required? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the pricing test and the 30+ tests a year, and state your own role in them (designed and ran) | R3 | `[grounded]` your background | pending your approval |
| E2 | Present the consent-state model and GDPR/CCPA work as privacy-governed data work, never as HIPAA or healthcare experience | R9b, R9a | `[grounded]` your background | pending your approval |
| W1 | A sanitized one-page metric dictionary or LookML excerpt, only if G1 confirms you owned definitions | R6, R4 | `[grounded]` R6 | pending your approval |
| Q1 | Ask RR1 to RR5's questions verbatim in the process | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A1 | Verify the live posting on the company's own site before spending application effort | RR1 | `[grounded]` RR1 | pending your approval |

If you apply, resume-tailor can tailor your resume to this role as an approve-first edit list.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were sent ("Harborlight Health care navigation app Series C"; "Harborlight Health careers Senior Product Analyst") and both were refused. They would have settled RR1 and role reality's contradictions row |
| 2. Role-family sweep | unavailable | One search was sent ("senior product analyst digital health salary range experimentation Looker") and was refused. It would have filled the market-calibration row |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Everything marked `[generic]` above stands in for research that did not run.

If you want, I can save all of this as `tuesday-dossier.md` for later steps.

**Upgrade menu**

- Permission to run web searches → RR1 resolves, and the market-calibration row gets a pay band.
- A sanitized metric dictionary or LookML excerpt → R6 and R4 can reach `high`.
- A sanitized experiment write-up (the pricing test) → R3 can reach `high`.
- The hiring manager's name → role reality's scope read and which story to lead with.
- Your constraints (pay floor, location, authorization) → the hard-gate checks stop being unknown.

**Questions**

G1 — Did you personally own metric definitions at the meal-kit company, such as a metric dictionary, LookML definitions or a change process, or did they sit with someone else? What was yours?
G2 — Have you onboarded, mentored or reviewed the work of junior analysts, and how?
RR2 — What are your non-negotiables for this move: a pay floor, location or remote needs, and work authorization?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.