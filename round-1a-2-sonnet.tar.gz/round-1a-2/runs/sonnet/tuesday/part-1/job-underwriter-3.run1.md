Search permission wasn't granted, so I assessed from the posting and your background only and sent no further calls.

## Decision snapshot

**No, this isn't worth pursuing as written. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site in our Austin office 5 days), R2 ($70–85k base)
- `must_have` — direct: R3, R4, R5
- `important` — unclear: R6 (SEO/content), R7 (brand, PR, partnerships), R8 (sales ops), R9 (team of one)

R1 and R2 — each fails on its own, and no wording fixes either; R3, R4, R5 — the match you see on paper, which doesn't offset a failed gate.

**Opportunity ledger.** Beyond the two mismatches with your constraints (RR1, RR2), the posting folds seven functions into one title with no bench (RR3). It also signals always-on hours (RR4) and undefined success metrics (RR5). The employer couldn't be checked (RR6) and the equity is unquantified (RR7). The one entry running the other way is the CEO reporting line (RR8).

- **Hard gates:** failed: R1 (On-site in our Austin office 5 days), R2 ($70–85k base).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** R1 would need the five-day on-site rule dropped, and R2 would need a base of at least $150k. The posting says "no exceptions" and states a range, so it shows no sign of either.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD header, self-reported and not verified |
| Mandate | Own all revenue growth: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Reporting line | CEO, with a dotted line to the board | `[grounded]` JD |
| Team | "A team of one to start" | `[grounded]` JD |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside", unquantified. Against your $150k floor the base is $65–80k short | `[grounded]` JD figure and your stated floor |
| Scope read | Seven channels with no team is closer to several roles in one than to one head-of-function role | `[generic]` role-family pattern, not a claim about this employer |
| Market calibration | Not established. Research was unavailable, so no band is quoted | — |
| Unknowns | Equity size, budget, who the first hires would be, what "sales ops" covers, the hiring manager | — |
| Contradictions | None within the JD. A check against the company's own pages did not run | `[grounded]` JD read; no page check |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in our Austin office 5 days a week, no exceptions (your constraint: remote-only, Portland, no relocation) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your statement of the constraint, which is specific and your own. Fit fails because the JD rules out any remote arrangement | `[grounded]` JD quote and your stated constraint | Surface in snapshot; only the employer changing terms resolves it |
| R2 | Compensation: $70–85k base (your constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your floor, which is specific and confirmed. Fit fails because the top of the posted range is $65k below it | `[grounded]` JD figure and your stated floor | Surface in snapshot; only a changed range resolves it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You state 9 years in growth, with Growth lead then Head of Growth titles, but with no document yet. How many of those years were leadership isn't itemized, so expect a probe | `[grounded]` your stated history; no document inspected | Offer: CV or a dated role list would raise to `high` |
| R4 | Paid acquisition | must_have | direct | medium | none | You state that you owned paid, with a $8M to $40M ARR scale-up over three years on a budget you controlled. Confirmed and specific, with no inspectable artifact yet | `[grounded]` your stated history | Offer: a sanitized budget or channel report |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state that you owned lifecycle and work in Braze. Confirmed, with no artifact inspected | `[grounded]` your stated history | Offer: a sanitized lifecycle program overview |
| R6 | SEO/content | important | unclear | none | discovery | Your background doesn't mention it either way | `[grounded]` silence in your stated history | See G1 |
| R7 | Brand, PR, partnerships | important | unclear | none | discovery | Your background doesn't mention these either way | `[grounded]` silence in your stated history | See G2 |
| R8 | Sales ops | important | unclear | none | discovery | Your background doesn't mention it either way | `[grounded]` silence in your stated history | See G3 |
| R9 | Working alone: "a team of one to start" | important | unclear | low | discovery | You led teams of 3–7, which is managing, not hands-on delivery across seven channels at once. The adjacent work is real and its limit is that gap | `[grounded]` your team sizes; `[inferred]` limit from the posting's no-bench wording | See G4 |

## Gap recovery queue

All four gaps are moot while R1 and R2 stand. I'm not asking about them now, and they'd matter only if both terms changed.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R6, important) | discovery | Nothing stated | Part of "all revenue growth" | Owning organic traffic targets, briefing writers, a content calendar tied to revenue | Search-console or GA4 organic-traffic report | `[grounded]` silence in your stated history |
| G2 | Brand, PR, partnerships (R7, important) | discovery | Nothing stated | Three more functions in one requirement | Affiliate or co-marketing deals, press placements, a launch campaign | A partner agreement or launch recap | `[grounded]` silence in your stated history |
| G3 | Sales ops (R8, important) | discovery | Nothing stated | A B2B-flavored function beside B2C subscription work | CRM or pipeline reporting for a sales team, lead routing | A pipeline dashboard | `[grounded]` silence in your stated history |
| G4 | Hands-on solo execution (R9, important) | discovery | Team management is stated, solo delivery is not | The posting's no-bench model rests on it | Stretches with no reports where you built and ran campaigns yourself | A campaign you personally built end to end | `[grounded]` your team sizes; `[inferred]` that this is what the no-bench model tests |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | On-site rule conflicts with your remote-only constraint (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The role cannot be done from Portland on the stated terms | `[grounded]` JD quote against your stated constraint | Is the five-day on-site requirement fixed for this role? | confirmed |
| RR2 | Base pay below your floor (see R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | Even the top of the range is $65k under your stated floor | `[grounded]` JD figure against your stated floor | Is the posted base range the full cash range for this role? | confirmed |
| RR3 | Seven functions, one person, junior-priced pay | risk_signal | medium | "You will be a team of one to start — we believe in players who don't need a bench" | Accountability for a whole function without staff, and the pay may not match the mandate | `[inferred]` from the scope list against the pay range; the seniority-pay comparison to the market is unchecked | What budget and first hires are committed for this role? | unresolved |
| RR4 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Overtime may be routine, and the posting's own wording presents it as culture | `[inferred]` from the quote | What does a typical week's hours look like for this role? | unresolved |
| RR5 | No stable success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You could be accountable for results with no agreed definition of success | `[inferred]` from the quote against the scope | What would this role be judged on at 90 days and at 12 months? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR7 | Equity upside unquantified | unknown | — | "meaningful equity upside" | The value and terms of the equity can't be judged from the posting | `[inferred]` from the posting's silence on size and terms | What percentage, vesting and strike price come with this role? | unresolved |
| RR8 | CEO reporting line and board visibility | positive_signal | — | "Report to the CEO with a dotted line to the board" | Senior access is stated | `[grounded]` JD | Who owns growth decisions day to day: the CEO or this role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Pass on the posting as written | R1 and R2 each fail | `[grounded]` R1, R2 rows | pending your approval |
| A2 | Only if you want to test whether the terms flex: one message to the employer asking if the on-site rule and the base range are fixed. I'd draft it only on your approval | Only the employer changing terms resolves either gate | `[grounded]` R1, R2 rows | pending your approval |
| A3 | Reuse RR3–RR5 as screening questions for similar postings | They are the checks that this posting's wording raised | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search permission wasn't granted, so the call was refused. It would have fed role reality's contradictions row and RR6, and I did not retry |
| 2. Role-family sweep | unavailable | The same refusal. It would have fed the market calibration line and the seniority-pay check in RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

I'd offer to write this up as `tuesday-dossier.md` if you want to keep it.

**Upgrade menu**

- Search permission, so targets 1 and 2 can run → RR6 closes or stands, and role reality gets a market band.
- A link to the live posting on Novaline's own careers page → RR6, and whether the posting is genuine.
- The hiring manager's name → role reality's scope read.
- A dated role list or CV → R3 to R5 can reach `high`.
- Evidence of SEO, brand, PR, partnerships or sales ops work → R6 to R8.
- A deeper research pass once L1 has run (up to 5 more searches and 2 more fetches) — say the word and it runs.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.