I'm reading the last part of the underwriting playbook (the evidence-status and upgrade-menu formats). Then I'll load the web tools to check Brindlemoor and the role before I give you a verdict.
**Should you go for it? On substance, yes. Hold the application until the location terms are settled. Status: `hold_pending_answers`.** R1, the one hard gate, is unconfirmed. The JD says "Fully remote (UK)", but Brindlemoor's own careers page for this role says "Leeds office four days a week".

# Job underwriting: Senior Pricing Analyst, Brindlemoor

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5a, R6, R7 · adjacent: R5b (monitor rating models)
- `important` — adjacent: R8 (recommendations for underwriting and product)
- `preferred` — direct: R9

R5b — "maintained" is near monitoring, not the same; R8 — underwriting side shown, product side not.

**Opportunity ledger.** The role is real and live on the employer's own site, but its terms conflict (RR1), pay is withheld (RR2) and team scope is unstated (RR4). One entry runs the other way: the role reports to a Director of Pricing with public work on model monitoring (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** your answer on whether Leeds four days a week works for you (R1), and Brindlemoor confirming which location term is current (RR1). If you can do Leeds, this likely becomes `conditional_go`. If you need fully remote and the page is right, it becomes `no_go` on R1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech selling pet insurance; the posting is live on its careers page | `[grounded]` JD header; careers page fetched |
| Mandate | Own pricing analytics for the pet-insurance product: rating models, price tests, recommendations to underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing, Odile Varga | `[grounded]` careers page |
| Working pattern | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week". These contradict each other | `[grounded]` both texts |
| Scope read | A single-product pricing analytics post, with no team size or direct reports stated | `[inferred]` from the JD's "our pet-insurance product" against its silence on team |
| Market calibration | Median base £58,400, interquartile range £52,100 to £64,900 for senior pricing analysts at UK insurers and insurtechs. The posting withholds pay, so this is a band to expect and not Brindlemoor's offer (RR2) | `[generic]` role-family search, 2026 pay survey (search result snippet only, page not opened); `[grounded]` JD silent on pay |
| Unknowns | Salary; which location term is current; team size; whether the role has direct reports; pet-specific data and tooling | `[grounded]` JD and careers page silence |
| Contradictions | Location (see above) | `[grounded]` JD against careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You have not stated a location constraint, so there is no claim to grade. The role's own sources disagree (RR1) | `[grounded]` JD and careers page | Question R1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics at a UK motor insurer, stated in prose and not yet inspected | `[grounded]` your stated background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily", specific but with no artifact inspected | `[grounded]` your stated background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. Confirmed and specific, with no inspectable artifact yet, so expect a probe | `[grounded]` your stated background | A sanitized model spec or documentation would raise this to `high` |
| R5a | Build rating models | must_have | direct | medium | none | "Built" the young-driver GLM rating model | `[grounded]` your stated background | none |
| R5b | Monitor rating models | must_have | adjacent | low | discovery | You said "maintained". Maintaining a model is near monitoring but does not establish a monitoring practice, so this resolves downward | `[grounded]` your wording; `[inferred]` adjacency | Question R5b below |
| R6 | Design and read price tests | must_have | direct | medium | none | "Ran 14 price tests last year with the underwriting team". "Ran" does not say whether you designed them, so any line should say "ran" unless you confirm designing | `[grounded]` your stated background | none |
| R7 | Present to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your stated background | none |
| R8 | Turn results into recommendations for underwriting and product | important | adjacent | low | discovery | Underwriting side is shown through the price tests and the review. Nothing you have said touches product | `[grounded]` your stated background; `[inferred]` that the posting's "and product" is a real responsibility | Question R8 below |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer. Pet insurance is not required by the JD | `[grounded]` your stated background and JD | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location terms (R1, hard_gate) | hard_gate | The JD and the careers page give opposite working patterns, and your location limits are unstated | A gate the inputs do not settle decides the status; no wording can solve it | n/a, this is a term and not experience | Brindlemoor confirming the current term in writing | `[grounded]` the two texts; `[inferred]` that one is out of date |
| G2 | Monitoring rating models (R5b, must_have) | discovery | "Maintained" the young-driver GLM, with no detail on how performance was tracked | A must-have at `adjacent`, and the hiring manager's public talk is on monitoring rating models in small books (RR3) | Tracking actual-versus-expected by segment; drift or stability checks; a refit trigger; a dashboard or report others used | A monitoring report, a dashboard screenshot, or a model-review document | `[grounded]` your wording; `[generic]` that monitoring practice is what a probe would go after |
| G3 | Product-facing recommendations (R8, important) | discovery | Underwriting recommendations are shown, and product is not mentioned | Closes the one `important` row below `direct` | A pricing recommendation that went to a product owner; a price change that shaped a product feature or segment | A review deck or recommendation note, sanitized | `[grounded]` your wording; `[inferred]` that "product" is a distinct audience here |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Contradictory location terms (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One source may be stale, or the role may have changed terms between drafts | `[grounded]` both quotes; `[inferred]` that one is out of date | Is this role fully remote, or Leeds four days a week, and is that fixed? | unresolved |
| RR2 | Salary withheld | unknown | — | The JD states no pay figure | The figure may sit anywhere against the survey band in role reality | `[grounded]` JD silent; `[generic]` band | What salary range is budgeted for this post? | unresolved |
| RR3 | Reports to a Director of Pricing with public work on monitoring models in small books | positive_signal | — | "reports to the Director of Pricing" | The manager's published interests overlap the role's model-monitoring remit | `[grounded]` careers page and a search result describing a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors" (profile page not opened) | How does the team monitor its rating models today, and what would you want this hire to own? | noted |
| RR4 | Team size and direct reports unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The post may be a sole analyst or one of several, with or without direct reports | `[inferred]` from the JD's silence | Who else sits in pricing analytics, and does this role have direct reports? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the location term with Brindlemoor before investing in an application, using RR1's question | see R1, RR1 | `[grounded]` RR1 | pending your approval |
| E1 | CV line, every clause from your own sentences: "Built and maintained the GLM rating model for the young-driver book; ran 14 price tests last year with the underwriting team; present the quarterly pricing review to the head of underwriting." Do not add "monitored", "designed" or any product-side claim unless you confirm it | see R4, R5a, R6, R7 | `[grounded]` your stated background | resume_edits_pending_approval |
| A2 | Say plainly that your book is motor, not pet, and show that the GLM and price-test method carries across. Claim no pet-specific knowledge | see R9 | `[grounded]` your stated background; the JD treats insurance experience as a plus | pending your approval |
| A3 | Before any conversation with the Director of Pricing, have a precise account of how your model was tracked, covering only what you actually did | see R5b, RR3 | `[grounded]` RR3 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results) and "Brindlemoor careers Senior Pricing Analyst". Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It confirmed the posting is live, the reporting line, and the contradicting location term (RR1, R1) |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst insurance UK remote salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). It supplied the market calibration and RR2's band |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). It supplied RR3, G2's weighting and A3 |

The company-name search returned nothing, so the employer rests on its own careers page and the manager profile snippet.

I can offer one extra if you want it: a short note on how to raise the location contradiction with Brindlemoor without signalling doubt about the role. I'll write it only if you say yes.

I can also write up everything above as `tuesday-dossier.md` whenever you want it.

## Upgrade menu

- Your location answer (R1) → the hard gate settles, and the status likely moves to `conditional_go` or `no_go`.
- Brindlemoor's confirmation of the current working pattern → RR1 closes.
- The budgeted salary → RR2 closes, set against the survey band.
- A model-monitoring report, dashboard screenshot or review document, sanitized → R5b and R4 can rise.
- A recommendation note or review deck that reached a product owner → R8 closes.
- A deeper research pass on Brindlemoor (funding, leadership changes, hiring pattern, recent news): up to 5 more searches and 2 more fetches. Say the word and it runs.

## Questions

R1 — Is working from Leeds four days a week acceptable to you, or is fully remote something you need? Which is it?

R5b — How did you track your young-driver GLM's performance after launch, and what did you do when it drifted?

R8 — Has any of your pricing work gone to a product owner or product team, as opposed to underwriting, and what did you recommend?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.