Web search was blocked, so this runs only on the posting and what you told me.

## Decision snapshot

**No, this isn't worth pursuing. R1 and R2, both hard gates, fail against your stated constraints. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site Austin office, five days a week), R2 (Base pay of $70–85k)
- `must_have`: direct: R4, R5 · unclear: R3 (8+ years growth leadership)
- `important`: adjacent: R9 (Team of one, no bench) · unclear: R6 (SEO/content), R7 (Brand, PR, partnerships), R8 (Sales ops)

R1, R2: the role's terms conflict with your constraints, and wording can't fix that; R4 (`medium`): paid acquisition confirmed, no artifact inspected.

**Opportunity ledger.** The role is incompatible with your location constraint (RR1) and priced below your floor (RR2). It bundles seven functions into one seat (RR3), treats after-hours work as culture (RR4), leaves success undefined (RR5), and doesn't state authority, budget or equity terms (RR6). The employer is unverified (RR7). Direct CEO and board access (RR8) runs the other way. This is the "something feels off" you sensed. Your fit isn't the problem; the role's terms and structure are.

- **Hard gates:** failed: R1 (On-site Austin office, five days a week); R2 (Base pay of $70–85k).
- **Severe red flags:** none found.
- **What would change this:** the posted terms themselves would have to differ on R1 and R2, meaning a remote-eligible role with a base at or above your $150k floor. Nothing in how you present yourself moves either.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, "e-commerce enablement startup, Series A, profitable since day one" (the posting's own description, unchecked) | `[grounded]` JD header |
| Mandate | "Own all revenue growth end to end" across paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops | `[grounded]` JD |
| Team | "A team of one to start" | `[grounded]` JD |
| Reporting | CEO, with a dotted line to the board | `[grounded]` JD |
| Working pattern | Austin office five days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside", with no equity figures. Your floor of $150k is $65k above the top of the posted band | `[grounded]` JD and your stated floor |
| Success measures | "Will evolve as we learn"; no first-year outcomes stated | `[grounded]` JD |
| Scope read | Seven functions with one person in the seat reads as several roles folded into one | `[inferred]` from the JD's function list against its "team of one" |
| Market calibration | Not available. The role-family sweep did not run, so no pay band is quoted and the posted pay is not compared with the market (RR2) | `[grounded]` Evidence status below |
| Unknowns | Budget, decision rights, equity terms, funding and revenue claims, whether a first hire is planned | `[grounded]` JD silence |
| Contradictions | None between statements inside the posting; the employer's own pages are unchecked | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site Austin office, 5 days a week, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your statement (Portland, remote-only, not relocating), which is specific and your own. Fit fails because the JD rules out any exception | `[grounded]` JD quote and your stated constraint | Surface only; the employer changing the posted terms is the one thing that resolves it |
| R2 | Base pay $70–85k | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your $150k floor. Fit fails because the top of the posted band is $65k below it | `[grounded]` JD quote and your stated floor | Surface only; no reframing applies |
| R3 | 8+ years growth leadership | must_have | unclear | medium | discovery | You gave 9 years in growth, with Growth lead then Head of Growth at two companies. How many of those years were leadership isn't stated, so I take the lower reading | `[grounded]` your summary; the leadership-year split is not in it | Confirm leadership dates from the CV if it ever matters |
| R4 | Paid acquisition | must_have | direct | medium | none | You own paid at two companies and controlled a budget while scaling $8M to $40M ARR. It's confirmed and specific, with no artifact inspected, so expect a probe | `[grounded]` your summary | A channel P&L or spend report would raise this to `high` |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | Lifecycle ownership plus deep Braze, confirmed in your summary with no artifact inspected | `[grounded]` your summary | A Braze program report would raise this to `high` |
| R6 | SEO/content | important | unclear | none | discovery | You mentioned no SEO or content work. Silence isn't absence | `[grounded]` your summary's silence | Recall prompt G2 |
| R7 | Brand, PR, partnerships | important | unclear | none | discovery | No claim in your summary. The JD folds three functions into one line | `[grounded]` your summary's silence | Recall prompt G3 |
| R8 | Sales ops | important | unclear | none | discovery | Your background is B2C subscription, and sales ops is a B2B function. No claim exists either way | `[grounded]` your summary's silence; `[generic]` that sales ops usually sits in B2B settings | Recall prompt G4 |
| R9 | Operate as a team of one | important | adjacent | low | transferability | You built and managed teams of 3–7. Running a function solo is a different mode, and you didn't claim it | `[inferred]` from your team sizes against the JD's "team of one" | Bridge case G5 |

## Gap recovery queue

All five gaps are secondary. The decision is fixed by R1 and R2, so nothing here changes it unless the posted terms change.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leadership years (R3, must_have) | discovery | 9 years in growth; the leadership split isn't stated | Matters only if the gates open | Dates at Growth lead and Head of Growth levels | CV with dates | `[grounded]` summary lacks the split |
| G2 | SEO/content (R6, important) | discovery | Nothing stated | Matters only if the gates open | Owning an organic channel, content calendar or landing-page program as part of growth | Organic traffic report, content plan | `[grounded]` silence |
| G3 | Brand, PR, partnerships (R7, important) | discovery | Nothing stated | As above | Co-marketing, affiliate or referral partnerships; launch PR; brand campaigns you ran | Partnership deck, campaign brief | `[grounded]` silence |
| G4 | Sales ops (R8, important) | discovery | B2C background; nothing stated | As above | CRM or pipeline reporting you owned for a sales-assisted motion | Pipeline dashboard export | `[grounded]` background; `[generic]` B2B association |
| G5 | Solo operation (R9, important) | transferability | Team-builder, not a solo operator. The carry-over is breadth across paid, lifecycle and experimentation; the limit is that you led people rather than doing every function yourself | The posting names this as its mode | A period when you ran channels hands-on before hiring | Early-stage channel results | `[inferred]` from team sizes |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Five-day on-site against a remote-only constraint (R1) | red_flag | medium | "On-site in our Austin office 5 days a week — no exceptions." | Incompatible with your constraint. Severity stays medium because the term isn't unreasonable in itself; the gate lives in R1 | `[grounded]` JD quote and your constraint | Is the Austin on-site requirement fixed as written? | confirmed |
| RR2 | Base below the stated seniority and scope (R2) | risk_signal | medium | "$70–85k base plus meaningful equity upside" | The base may not match an 8+ year, seven-function mandate, and unquantified equity may be standing in for the difference. No market band was checked | `[inferred]` from the JD's years and scope against its base; the sweep did not run | What is the equity grant, its vesting and valuation, and how was the base set? | unresolved |
| RR3 | Bundled specializations | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops… a team of one" | Several full roles are folded into one seat | `[inferred]` from the function list against the team size | Which of these are year-one priorities, and when is the first hire? | unresolved |
| RR4 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work is framed as culture, with no stated frequency or compensating time | `[inferred]` from the framing and the missing frequency | How often did evenings and weekends happen last quarter, and is time off offered back? | unresolved |
| RR5 | No success metrics on a full revenue mandate | risk_signal | medium | "success metrics will evolve as we learn" | You'd be accountable for revenue with no yardstick set at the start | `[inferred]` from the JD's silence on measures | What outcome must this role hit by month 6 and month 12, and who judges it? | unresolved |
| RR6 | Authority, budget and equity unspecified | unknown | — | "Own all revenue growth end to end" | Decision rights and budget aren't stated | `[grounded]` JD silence | What budget does this role control, and which spend needs CEO sign-off? | unresolved |
| RR7 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small for a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR8 | Senior access | positive_signal | — | "Report to the CEO with a dotted line to the board." | The seat has direct senior visibility | `[grounded]` JD states it | Who is on the board, and how often would this role present? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't apply on the posted terms | R1, R2 | `[grounded]` map | pending your approval |
| P2 | If you proceed anyway, put RR1 to RR7 to the employer verbatim before investing effort, and check the employer through its own site first | The register doubles as your interview questions | `[grounded]` register | pending your approval |
| P3 | No resume edits proposed | The decision rests on terms, not presentation | `[grounded]` R1, R2 | pending your approval |

## Evidence status

Verified: R1, R2 (your constraints, user-confirmed). R3, R4, R5 and R9 rest on your own summary and are unverified. R6, R7 and R8 have no claim yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One search ("Novaline e-commerce enablement startup Austin Head of Growth") was refused. It would have fed role reality's organization and contradictions rows and RR7 |
| 2. Role-family sweep | unavailable | One search ("Head of Growth salary startup Series A 2026 base compensation range") was refused. It would have fed the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

I'm offering to save this as `tuesday-dossier.md` if you want a copy; no pressure.

## Upgrade menu

- Allowing web search would check the employer (RR7, role reality) and calibrate the pay (RR2, market calibration).
- Your CV with dates would settle R3. An inspectable artifact would raise R4 and R5 to `high`: a channel P&L, a Braze program report, or the growth report behind the $8M to $40M ARR scale-up.
- Any SEO, brand, PR, partnership or sales-ops work (R6, R7, R8) would turn those rows from unclear to a graded fit.
- A hiring manager's name, if one surfaces, would let me read the role's scope more precisely.

I have no questions for you, since nothing you could answer would change the decision.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.