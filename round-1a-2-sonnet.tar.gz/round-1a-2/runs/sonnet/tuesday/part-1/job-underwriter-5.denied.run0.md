Two of my web checks were refused, so this assessment runs on the material you pasted. The details are under Evidence status.

## Decision snapshot

**Yes, this looks worth applying to, on conditions. R3, R4, R5, R6 and R7, your must-haves, are all `direct`. R1 and R2, the two gates, are unconfirmed rather than failed. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (Pay $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7
- `important`: adjacent: R8 (BigQuery warehouse); unclear: R9 (Ingestion from app and CRM), R10 (Data contracts analysts depend on)

R8 (`medium`) — a credible bridge, its limit named; R9 — nothing you've told me settles it; R10 — nothing you've told me settles it.

**Opportunity ledger.** The pay is clear and sits at or above the report's median (RR3). The team, reporting line and what "run" means are unstated (RR1, RR5), the equity terms are unstated (RR2), and the employer's own pages were not independently checked (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Pay $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 confirmed met against your location, work authorization and pay floor; (2) BigQuery is framed as adjacent, never as experience (R8); (3) RR1, RR4 and RR5 get acceptable answers in the loop.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; not independently checked (RR4) |
| Mandate | Build and run the pipelines behind the platform's reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD as pasted |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity; equity terms not given | `[grounded]` JD |
| First-year outcomes | None stated | `[grounded]` JD is silent |
| Scope read | Three named responsibilities (ingest, model, contract) read as end-to-end ownership of a reporting stack. That is somewhat wider than the one-domain scope the pay report calls typical for the title | `[inferred]` from the JD's three responsibilities against the report's typical scope |
| Market calibration | Report base median is $151,000 and the interquartile range is $139,000–$163,500. The posted low end is $3,000 under the median and the posted high end is $2,500 above the range's upper bound. "Senior" typically means 5–8 years with no direct reports, and the posting's 5+ is in line with that. The report is a pattern, never this employer's offer | `[grounded]` JD figures and the report you supplied (US, n=2,310, Series B–D, matching a Series C company); `[generic]` for what the report says is typical |
| Unknowns | Hiring manager (the posting names none); data team size; what "run" involves; equity terms; whether the BigQuery warehouse already exists | `[grounded]` JD silence |
| Contradictions | None between the JD and about-page text as pasted. The live pages were not fetched | `[grounded]` pasted text only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you are based or your US work status, and "Remote (US)" implies a US base. Confidence is `none` because no statement of the constraint exists yet, not because of the role | `[grounded]` JD location line; `[inferred]` that a US base is implied | Question R1 below |
| R2 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your floor wasn't given, so whether the range clears it is unknown. The equity terms are unstated (RR2) | `[grounded]` JD figures; your floor not given | Question R2 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | "6 years of data engineering at a B2B payroll company" clears 5+. It is typed self-report with no artifact, so `medium`. Length of experience is a tiered requirement here, not a gate | `[grounded]` your message | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily" is confirmed use. "Strong" can't be inspected from prose, so `medium`. A technical screen commonly probes this | `[grounded]` your message; `[generic]` on screens | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse. Specific and confirmed, no inspectable artifact yet | `[grounded]` your message | A sanitized lineage graph or dbt docs excerpt would raise it to `high` |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | "Airflow for orchestration" matches. You didn't say whether you authored the DAGs or ran the deployment, so no ownership is claimed beyond that | `[grounded]` your message | A sanitized DAG excerpt would raise it to `high` |
| R7 | Data quality testing | must_have | direct | medium | none | "I set up our Great Expectations test suite" is a direct match, confirmed, no artifact yet | `[grounded]` your message | A sanitized suite listing would raise it to `high` |
| R8 | BigQuery warehouse (the JD's responsibilities name it) | important | adjacent | medium | transferability | The requirements list says "a cloud warehouse", but the responsibilities name BigQuery, and you've never used it. Snowflake with dbt is a credible bridge. The limit is that no BigQuery work has been exercised, and BigQuery differs from Snowflake in cost model and table design, so expect a probe | `[grounded]` your message and JD; `[generic]` on platform differences | See G3 and plan A2, A3 |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | You described orchestration, not which sources fed it or how they were ingested | `[grounded]` your message is silent on sources | See G1 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations suite (R7) is the nearest evidence, but it doesn't show agreements with analysts | `[grounded]` your message; `[inferred]` that R7 is the nearest | Question G2 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R9, important) | discovery | Airflow work is confirmed; the sources and ingestion method are not | One of the three named responsibilities; resolving it firms up the fit ledger's `important` line | Pulling product database or event data into a warehouse; pulling from a CRM's API; handling upstream schema changes; backfills | A sanitized DAG excerpt or architecture diagram | `[grounded]` silence on sources; `[inferred]` that these examples fit a payroll stack |
| G2 | Data contracts (R10, important) | discovery | A test suite exists; agreements with downstream analysts are not shown | It is a named deliverable ("data contracts our analysts depend on"), and analysts are its readers | Agreed schema or freshness expectations with analysts; tests on models analysts query; a failed check that blocked a load; documented model owners | A sanitized test list or a data-expectations doc | `[grounded]` JD wording; `[inferred]` from R7 as nearest evidence |
| G3 | BigQuery (R8, important) | transferability | Snowflake plus about 180 dbt models | The one platform named in the responsibilities that you haven't used | Adjacent: dbt on a cloud warehouse. Limit: no BigQuery exercised. Strengthener: a small dbt project on BigQuery using a public dataset (plan A3) | The project's repo | `[grounded]` your message; `[inferred]` that the project would narrow the limit |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team, reporting line and ownership unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may be the sole or one of few data engineers owning ingestion, modelling and contracts, or part of an established team; the posting doesn't say | `[inferred]` from three named responsibilities against silence on team size and reports | Who is on the data team today, who would I report to, and which of ingestion, modelling and contracts does someone already own? | unresolved |
| RR2 | Equity named, terms unstated | unknown | — | "plus equity" | The grant could be material or negligible; its value can't be judged | `[inferred]` from the posting giving no terms | What is the equity grant: type, size, vesting schedule, and the latest valuation or strike price? | unresolved |
| RR3 | Pay stated and inside the market band | positive_signal | — | "$148,000–$166,000" | The posting is transparent on pay, and the range brackets the report's median | `[grounded]` JD figures and the report you supplied; the report is not this employer's offer | Where in that range would someone with my experience start? | noted |
| RR4 | Employer and posting not independently checked | unknown | — | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The text is the company's own, and whether the posting is live and the funding as stated is untested here | `[grounded]` my fetch and search were refused, so nothing was checked | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR5 | "Run" may include operational duty | unknown | — | "Build and run the pipelines" | "Run" may mean on-call or incident support for the pipelines | `[inferred]` from the verb alone | What does "run" mean in practice: is there an on-call rotation, and what is the typical incident load? | unresolved |

## Application plan

Every row is proposed: pending your approval, and nothing here is final language.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with two of your own lines: you built the dbt project on Snowflake, about 180 models, and you set up the Great Expectations test suite | See R5, R7 | `[grounded]` your message | pending your approval |
| A2 | State BigQuery plainly: you haven't used it, and your dbt work was on Snowflake | See R8; every clause traces to your own sentences | `[grounded]` your message | pending your approval |
| A3 | Optional: a small dbt project on BigQuery using a public dataset, to narrow R8's limit | See G3 | `[inferred]` that it narrows the limit | pending your approval |
| A4 | Ask the questions in RR1, RR2, RR4 and RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I tried fetching pellucidlearning.com/careers/senior-data-engineer and searching "Pellucid Learning Series C $52M online tutoring Denver"; both were refused. Whether the posting is live and consistent with your paste, and the funding claim, are unchecked. This would have moved RR4 and the contradictions row |
| 2. Role-family sweep | skipped | The pay report you pasted already fixes the market calibration and the scope read, which are the outputs this target feeds |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there is no query to form |

I'd like to save this as a `tuesday-dossier.md` you can carry forward. Say so and I'll write it.

## Upgrade menu

- Your answers on R1 and R2 close both gates. If either fails, the status becomes `no_go` with that gate as the reason.
- Any further non-negotiables, such as schedule or travel, would add gate rows and tighten the hard-gates line.
- An answer to G2 (and later G1) settles R10 and R9, the two `important` rows still `unclear`.
- A sanitized dbt lineage graph, DAG excerpt or test-suite listing raises R5, R6 or R7 toward `high`. Your resume file would let me propose edits, which I can't do from prose.
- The hiring manager's name, once you have it, unlocks the scope read and which story to lead with.
- Search and fetch access would let the careers-page and funding checks run and close RR4. A deeper pass on Pellucid Learning (funding, leadership changes, public employee reports; up to 5 more searches and 2 more fetches) is offered once; say the word and it runs.

R1 — Are you based in the US, or able to work from Denver, and authorized to work in the US without sponsorship?

R2 — Does a base of $148,000–$166,000 clear your pay floor?

G2 — Have you set up or enforced agreed expectations (schema, freshness, ownership) between a pipeline and the analysts who used it, and what did you personally own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.