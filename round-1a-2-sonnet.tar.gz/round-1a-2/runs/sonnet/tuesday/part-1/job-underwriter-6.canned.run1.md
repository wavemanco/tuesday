**Yes, it's worth applying, provided the pay and the Bristol office days work for you. R6 and R7b are the real stretch. Status: `conditional_go`.**

I read the posting you linked (it covers the Quillfield role, Bristol hybrid, £61,500–£67,000 plus share options). I haven't seen your CV, only your summary, so the fit rows rest on that.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000)
- `must_have`: direct: R3, R4 · adjacent: R5 (SQL and spreadsheet modelling), R6 (Owning a forecast) · unclear: R7a (Working with finance on revenue data) · absent: R7b (Billing data)
- `important`: direct: R8

R6 — adjacent, you haven't owned the forecast; R7b — absent, you haven't worked on billing data; R5 (`medium`) — tool use confirmed, modelling depth not.

**Opportunity ledger.** Quillfield is a real employer with a stated salary in line with market (RR4). The forecast and billing scope are described but not explained (RR1, RR2), the share options are unpriced (RR3), and the posting isn't yet confirmed on Quillfield's own site (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the Bristol office days and the salary suit you (R1, R2); (2) Quillfield confirms the forecast is something you can grow into, not a day-one expectation (RR1, R6); (3) there is a ramp plan for billing data (RR2, R7b); (4) you describe both gaps as gaps, never as ownership.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. It was founded in Bristol in 2018, has 96 employees and closed a £11M Series A in April 2025 | `[grounded]` "About Quillfield" (quillfield.co.uk/about), search result |
| Role | Own CRM and billing data, build pipeline and renewal reporting for sales and finance, and run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Terms | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe is listed as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. I read the search snippet only. | `[grounded]` search result for her name; recruiter's naming is your report |
| Scope read | If Tamsin is your manager, the Lead sits under a Head of Revenue Operations. The posting does not say how forecast and CFO work split between them, or whether anyone reports to the Lead | `[inferred]` from her title against the posting's silence |
| Market calibration | The posted range sits inside Ledgerline's 2026 interquartile range of £57,800–£70,400 for UK B2B software revenue operations leads, near its £64,200 median (n=438). The band is national, not Bristol-specific, and is not Quillfield's offer | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide, search snippet; `[grounded]` posting for the posted figure |
| Unknowns | Direct reports, option terms, billing system, forecast split with the Head of RevOps | — |
| Contradictions | The posting and the About page agree on Bristol and on what the company does. I guessed the careers-page address and it returned no page (RR5) | `[grounded]` About page, failed fetch |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days | hard_gate | unclear | none | hard_gate | You haven't stated a location or commute constraint, so whether the terms fit is not established | `[grounded]` posting; your constraints not given | G1 question |
| R2 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | You haven't stated a pay floor. The figure is stated and inside the market range in role reality | `[grounded]` posting; `[generic]` band | G1 question |
| R3 | 4+ years in revenue ops, sales ops or similar at a B2B software company | must_have | direct | medium | none | You have 5 years in sales operations, the last 2 running revenue operations for the UK team, at a B2B payments company. Whether a payments company counts as B2B software is the posting's call; that is why the band is `medium` and not higher | `[grounded]` your summary | none |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, self-reported with nothing inspected yet | `[grounded]` your summary | offer: the certification record would raise to high |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | You use SQL weekly and Excel daily, but that describes frequency of use, not modelling. The requirement says modelling | `[grounded]` your summary | G5 |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director and rebuilt the pipeline dashboards, but you have not owned the company forecast; finance did. The bridge is adjacent work, and its limit is that no forecast was built or owned | `[grounded]` your summary; `[generic]` that pipeline views commonly feed forecasting | G2 |
| R7a | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | Your renewal dashboards touch revenue, but nothing says finance used them or that you worked with them | `[grounded]` your summary silent on finance | G3 |
| R7b | Own billing data | must_have | absent | none | capability | You confirmed you've never worked on billing data. The requirements list says "billing or revenue data", so R7a could satisfy that line, but the responsibilities name billing data directly | `[grounded]` your statement; posting wording | G4: closure path |
| R8 | Build pipeline and renewal reporting that sales and finance run on | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Whether finance relied on them is unconfirmed | `[grounded]` your summary | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Terms fit (R1, R2, hard_gate) | hard_gate | No pay floor or location constraint given | A failed term would end the decision however strong the fit | Your minimum salary; your tolerance for a twice-weekly Bristol commute | Your own statement | `[grounded]` constraints not given |
| G2 | Owning a forecast (R6, must_have) | transferability | Pipeline review and dashboards; no forecast built | The posting names the CFO forecast as a core duty, so this is the likeliest probe | Preparing pipeline numbers for a forecast call; building a coverage or conversion model finance used; reconciling your pipeline view with finance's number | A sanitized forecast-versus-actual sheet or pipeline review deck | `[grounded]` your summary; `[inferred]` that this is the probe most likely to land |
| G3 | Working with finance (R7a, must_have) | discovery | Renewal dashboards exist; finance's use of them is unknown | This could close the "billing or revenue data" requirement | Renewal figures finance checked; reconciling bookings to invoiced revenue; quarter-end inputs | A sanitized renewal dashboard or reconciliation sheet | `[grounded]` your summary silent |
| G4 | Billing data (R7b, must_have) | capability | No billing data work | The posting says you will own it | Any CRM-to-invoicing field mapping or quote-to-cash data issue you've handled. Otherwise the closure path is to ask Quillfield which billing system it uses and learn it before starting | The billing system's name from Quillfield | `[grounded]` your statement |
| G5 | SQL and spreadsheet modelling (R5, must_have) | discovery | Usage frequency only | The posting says "strong" and "modelling" | A SQL query that fed a retention or cohort analysis; an Excel model with scenarios | A sanitized model or query | `[grounded]` your summary |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast ownership and split with the Head of RevOps | unknown | — | "run the quarterly revenue forecast with the CFO" | The Lead may be expected to own the forecast from the first quarter, with no ramp | `[inferred]` from the posting against its silence on the split | Which parts of the quarterly forecast would I own, and which stay with you and the CFO? | unresolved |
| RR2 | Billing data ownership | unknown | — | "own our CRM and billing data" | Billing data may be owned outright by the Lead, with no handover | `[inferred]` from the posting's wording | Which billing system is it, who owns it today, and what is the ramp plan? | unresolved |
| RR3 | Share options unpriced | unknown | — | "plus share options" | The grant size, vesting and strike price are unstated, so their value is unknown | `[grounded]` posting silent | What is the option grant, vesting schedule and strike price? | unresolved |
| RR4 | Salary stated and within the market range | positive_signal | — | "£61,500–£67,000" | The posting states pay openly, and it sits inside the market range in role reality | `[grounded]` posting; `[generic]` band | Is there room within the range for experience? | noted |
| RR5 | Posting not found on Quillfield's own careers page | unknown | — | "Revenue Operations Lead, Quillfield" | My fetch was a guessed address, so a miss says little. The posting may simply live elsewhere on their site | `[grounded]` failed fetch; `[inferred]` that a guessed URL is weak evidence | Can you point me to the role on Quillfield's own site? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle your pay and location terms before investing more effort | R1, R2, G1 | `[grounded]` rows | pending your approval |
| A2 | Open with your own words: "5 years in sales operations at a B2B payments company, the last 2 running revenue operations for the UK team", then the Salesforce certification, the pipeline and renewal dashboards you rebuilt, and the monthly pipeline review with your sales director. Don't describe your company as B2B software | R3, R4, R6, R8 | `[grounded]` your summary | pending your approval |
| A3 | Say the gaps first: "At my company, finance owned the forecast; I run the monthly pipeline review with our sales director, and I haven't worked with billing data." Each clause traces to your words | R6, R7b | `[grounded]` your summary | pending your approval |
| A4 | Put RR1, RR2, RR3 and RR5 to Tamsin or the recruiter verbatim. Tamsin's own route was sales operations, then Head of Revenue Operations, so RR1 is a fair question to put to her | RR1–RR3, RR5 | `[grounded]` her search result | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol" and read the result "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers, which returned no page. Moved: Organization row and RR5; employer exists as described, posting not confirmed on their own site |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol UK B2B software"; result "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example). Moved: market calibration and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield"; result "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), snippet only. Moved: hiring manager and scope rows and A4 |

I can save this as `tuesday-dossier.md` if you want to reuse it later.

**Upgrade menu**

- Your pay floor and commute tolerance → R1 and R2 settle, and the status firms up to `go` or `no_go`.
- Your CV, which I haven't seen → the rows get checked against it instead of your summary.
- The Salesforce certification record or a sanitized dashboard screenshot → R4 and R8 can reach `high`.
- A sanitized forecast or pipeline review sample → G2's bridge strengthens.
- Option terms, the billing system and the forecast split from the recruiter or Tamsin → RR1, RR2 and RR3 close.
- A deeper research pass on Quillfield (funding and leadership changes, recent news, employee reports; up to 5 more searches and 2 more fetches) → just say the word and it runs.

**Questions**

G1 — What is your minimum salary, and would two days a week in a Bristol office work for you?

G2 — Have you built or fed numbers into a forecast that finance or a senior leader used? What did you own, and what happened?

G3 — Have you worked with finance on renewal or revenue numbers? Who checked them, and what did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.