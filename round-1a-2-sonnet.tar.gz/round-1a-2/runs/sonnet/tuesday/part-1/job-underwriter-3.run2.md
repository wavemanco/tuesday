Running the two L1 searches the skill calls for: one to check Novaline exists and the role is live, one for the market range for this title.
**Short answer: no.** Your instinct is right, and the main reason is that the posting breaks both of your hard constraints. My two web searches on Novaline and the market pay band were refused, so nothing below about the company or the market has been checked outside the posting.

## Decision snapshot

**No — R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R3 (Evenings and weekends when it matters) · hard_gate_fail: R1 (On-site in Austin, 5 days a week), R2 ($70–85k base)
- `must_have` — direct: R4, R5, R6 · unclear: R7 (SEO/content)
- `important` — unclear: R8 (Brand, PR, partnerships), R9 (Sales ops), R10 (Team of one to start)

R1, R2 — each a failed gate that alone fixes the status; R4, R5, R6 — your background matches on paper, which is the match you noticed.

**Opportunity ledger.** The role is shaped oddly, beyond the two failed gates. It bundles every growth discipline into a team of one (RR4), asks for 8+ years of leadership at $70–85k (RR3), expects after-hours work (RR5) and leaves success undefined with no budget stated (RR6). The employer is also not yet established (RR7). The one favorable entry is the CEO reporting line (RR8).

- **Hard gates:** failed: R1 (On-site in Austin, 5 days a week), R2 ($70–85k base); unconfirmed: R3 (Evenings and weekends when it matters).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** R1 would have to be met, with a remote arrangement from Portland, and R2 would have to be met, with a base of at least $150k. The posting says neither, and the decision is yours.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting header, as claimed; not verified (searches refused) |
| Mandate | Own all revenue growth end to end: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Resources | "A team of one to start"; no budget stated | `[grounded]` posting and its silence on budget |
| Reporting | CEO, dotted line to the board | `[grounded]` posting |
| Working pattern | On-site Austin 5 days a week "no exceptions"; "evenings and weekends when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside", with no percentage or valuation given | `[grounded]` posting |
| Success metrics | None defined; "will evolve as we learn" | `[grounded]` posting |
| Scope read | The bundle usually spans several specialist roles, so it is unusually broad for one seat | `[generic]` role-family pattern |
| Market calibration | Not run, because the role-family search was refused. The posting's own figure is the only pay data here | `[grounded]` posting |
| Unknowns | Budget, equity size, decision rights, any flexibility on location | — |
| Contradictions | A "Head of" title and "8+ years" sit beside a team of one at $70–85k, which is a tension in the posting | `[inferred]` from the posting's own terms |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin 5 days a week, no exceptions (your constraint: remote-only, Portland, no relocation) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own statement of the limit. The fit fails because the posting rules out exceptions and you will not relocate | `[grounded]` posting quote and your statement | Only the employer changing terms resolves it; see RR1 |
| R2 | Pay of $70–85k base (your constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor. The top of the band is $65k below it, and the unquantified equity is not base | `[grounded]` posting figure and your statement | Only the employer changing terms resolves it; see RR2 |
| R3 | Evenings and weekends "when it matters" | hard_gate | unclear | none | hard_gate | You stated no limit on hours, so nothing settles this gate | `[grounded]` posting quote; no candidate statement | Moot while R1 and R2 stand; the one allowed question is whether you can meet it |
| R4 | 8+ years of growth leadership | must_have | direct | medium | none | You report 9 years, as growth lead then Head of Growth, with teams of 3–7. It is a self-report with nothing inspected yet, so it stays at `medium` | `[grounded]` your intake statement | none |
| R5 | Paid acquisition | must_have | direct | medium | none | You report owning paid, and scaling one company from $8M to $40M ARR with a budget you controlled. It is confirmed but not inspected | `[grounded]` your intake statement | none |
| R6 | Lifecycle/CRM | must_have | direct | medium | none | You report owning lifecycle and being deep in Braze. It is confirmed but not inspected | `[grounded]` your intake statement | none |
| R7 | SEO/content | must_have | unclear | none | discovery | Your stated ownership is paid, lifecycle and experimentation, and SEO is not mentioned | `[grounded]` your statement's silence on SEO | See G1; held |
| R8 | Brand, PR, partnerships | important | unclear | none | discovery | Nothing you said touches these | `[grounded]` your statement's silence | See G2; held |
| R9 | Sales ops | important | unclear | none | discovery | Your background is B2C subscription, and nothing mentions sales operations | `[grounded]` your statement's silence | See G3; held |
| R10 | Working as a team of one | important | unclear | low | discovery | You have managed teams of 3–7 and are hands-on in SQL, GA4 and Braze, but running solo is not stated | `[inferred]` from your team sizes and tool depth | See G4; held |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R7, must_have) | discovery | No SEO ownership stated | A `must_have` row at `unclear`, but it cannot move a status fixed by R1 and R2 | Organic landing-page analysis in GA4; a content calendar you owned; SEO tickets run with engineering | An organic traffic report or content plan | `[grounded]` silence on SEO |
| G2 | Brand, PR, partnerships (R8, important) | discovery | Nothing stated | Same: it cannot move the status | Launch positioning; press coverage you drove; an affiliate or co-marketing deal | Press clips or a partner agreement | `[grounded]` silence |
| G3 | Sales ops (R9, important) | discovery | Nothing stated | Same | Lead routing or scoring; CRM hygiene alongside a sales team | A lead-routing doc or scoring model | `[grounded]` silence |
| G4 | Solo execution (R10, important) | discovery | Team leadership is shown, solo hands-on work is not | Same | Periods when you ran channels yourself | A channel report you built | `[inferred]` from team sizes and tools |

No questions are asked for these rows, because no answer can move a decision that R1 and R2 fix.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | On-site rule conflicts with your remote-only constraint (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | Rules out your Portland arrangement | `[grounded]` posting against your stated constraint | Is any remote or Portland-based arrangement possible for this role? | confirmed |
| RR2 | Pay below your floor (see R2) | red_flag | high | "$70–85k base" | The top of the band is $65k below your $150k floor | `[grounded]` posting figure against your statement | What is the ceiling on base for this role, and what share does the equity represent? | confirmed |
| RR3 | Seniority-pay mismatch | risk_signal | medium | "8+ years growth leadership required"; "$70–85k base" | The mandate may be priced below what it asks; no market band was run | `[inferred]` from the posting's terms; the `[generic]` band is unconfirmed | How was the base set against the seniority asked? | unresolved |
| RR4 | Bundled specializations with no bench | risk_signal | medium | "Own all revenue growth end to end ... a team of one" | Several full roles folded into one seat | `[generic]` pattern for bundled mandates, applied to the posting's text | Which of these functions is first priority, and what budget and hires are committed? | unresolved |
| RR5 | Always-on expectation (see R3) | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work may be routine | `[generic]` pattern | How often did the last person in a comparable role work outside business hours? | unresolved |
| RR6 | Accountability without defined success or resources | risk_signal | medium | "success metrics will evolve as we learn" | Revenue accountability with no agreed target or budget | `[inferred]` from the posting's silence | What target defines success at 12 months, and what budget do I own? | unresolved |
| RR7 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR8 | Senior reporting line stated | positive_signal | — | "Report to the CEO with a dotted line to the board" | The seat appears to carry real access | `[grounded]` posting | What decisions does this role make without CEO sign-off? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Spend no resume or outreach effort while R1 and R2 stand | see R1, R2 | `[grounded]` the two gate rows | pending your approval |
| P2 | If you want to test whether terms flex, ask RR1 and RR2 of Novaline first, using contact details you find on its own site, before any application work | see RR1, RR2 | `[grounded]` the register | pending your approval |
| P3 | Confirm the employer and the live posting on its own careers page | see RR7 | `[grounded]` the register | pending your approval |

No resume edits are proposed.

## Evidence status

Verified: none yet. Stage assumed: evaluating.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused. It would have confirmed the employer exists and the posting is live, feeding role reality and RR7 |
| 2. Role-family sweep | unavailable | The search was refused. It would have set the market band feeding role reality's calibration and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'd be glad to save this as `tuesday-dossier.md` if you want to keep it.

**Upgrade menu**

- Granting search access would run targets 1 and 2, settling RR7 and giving a market band for RR3.
- A link to Novaline's own careers page, or the recruiter's email domain, would settle RR7.
- Your actual CV, plus an inspectable artifact such as a channel report or an ARR chart, would let R4–R6 rise above `medium`.
- Novaline's written answers on remote work and base ceiling would settle R1 and R2, the only rows that could change the status.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.