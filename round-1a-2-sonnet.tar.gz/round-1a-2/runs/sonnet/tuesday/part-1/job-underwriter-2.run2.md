Search was denied, so this runs on your JD and resume alone, and everything about the employer or the market is unchecked.

## Decision snapshot

**No, this isn't a waste of time, but it's a stretch to approach deliberately rather than cold. R1 (3+ years of PM experience) is absent, while R4 and R5 land `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R4, R5 · adjacent: R2 (PM work done, whatever the title), R3 (Shipped API or platform products) · unclear: R6 (Stakeholder management with sales), R7 (Agile delivery) · absent: R1 (3+ years titled PM experience)
- `important` — adjacent: R8 (Discovery with integration partners), R9 (Own roadmap, specs, two squads) · unclear: R10 (Adoption metrics)

R1 — no PM title, so the other rows have to bridge it; R2 (`medium`) — the PM-type work done untitled; R3 (`medium`) — integrations delivered, product not shipped.

**Opportunity ledger.** The scope is concrete (RR4). The employer is unchecked (RR1), the titled-years requirement may be applied literally (RR2), and pay is unstated (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer accepts equivalent product work as meeting R1, which you ask at RR2; a literal titled-years answer ends this application; (2) the employer verifies as real and the posting as live, at RR1; (3) R3's bridge is framed as adjacent, never as shipped-product experience, unless G2 confirms it.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B, as the JD you pasted describes it; not checked | `[grounded]` JD header |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Scope read | Concrete on surface, squads and measurement; silent on seniority, reporting line and whether other PMs exist | `[inferred]` from the JD's named duties against what it omits |
| Market calibration | Not run. The role-family search was refused, so no pay band or remit norm is offered | `[grounded]` Evidence status below |
| Unknowns | Compensation; location or remote policy; hiring manager; what counts as a "shipped API product"; whether this is a first PM hire | `[grounded]` JD silent on each |
| Contradictions | None inside the JD text; not checked against a careers page | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management experience (the JD's own tier, "must-have") | must_have | absent | none | capability | You've said you've never held a PM title, so nothing supports titled years. This is a length-of-experience requirement, not a gate. R2 carries the untitled work | `[grounded]` your statement, JD | Wording can't supply the title; ask at RR2 whether equivalent work counts |
| R2 | Product-management work done in practice, whatever the title (basis: the work behind the 3+ years) | must_have | adjacent | medium | transferability | The CV shows roadmap-input sessions, requirements documents and coordination with PMs and engineers on custom builds. Those feed product decisions; the CV doesn't show you deciding priorities. Limit named wherever this bridge is used | `[grounded]` CV | Frame as adjacent; see plan E1 |
| R3 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your vendor's REST APIs and wrote the integration playbook. That's the implementer's side of an API, not shipping the API product. Limit: no CV evidence you specified or launched one | `[grounded]` CV | See G2 |
| R4 | Technical fluency: API docs and schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI reading and integration architecture are stated and specific. No inspectable artifact yet, so `medium`; expect a probe | `[grounded]` CV | Offer: a sanitized playbook page would raise to `high` |
| R5 | Stakeholder management across engineering and customers | must_have | direct | medium | none | Coordinated your engineers, client engineers and PMs across 30+ integrations, with workshops and UAT. Sales is not in this row; see R6 | `[grounded]` CV | none |
| R6 | Stakeholder management with sales | must_have | unclear | low | discovery | The CV is silent on sales work | `[grounded]` CV silence | See G4 |
| R7 | Experience with agile delivery | must_have | unclear | low | discovery | The CV shows UAT and go-live on custom builds but doesn't mention working in sprints | `[grounded]` CV silence on sprints | See G3 |
| R8 | Run discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and quarterly client roadmap-input sessions are close to discovery. The CV shows feedback going to product, not you owning the discovery agenda | `[grounded]` CV | Frame as adjacent; see E1 |
| R9 | Own the roadmap, write specs, drive two squads | important | adjacent | medium | transferability | You wrote requirements and integration architecture and coordinated engineers. The CV shows no backlog or prioritization ownership | `[grounded]` CV | Frame as adjacent; see E1 |
| R10 | Define and track adoption metrics | important | unclear | low | discovery | The CV is silent on adoption measures. An unconfirmed lead exists; see G2 | `[grounded]` CV silence; the lead is a `memory_lead` | See G2, G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Titled PM years (R1, must_have) | capability | No PM title, in your words | A `must_have` at `absent`; it sets the decision's ceiling | Not recoverable by recall. Closure paths are the employer accepting equivalent work (RR2), or a titled role elsewhere first | None | `[grounded]` your statement |
| G2 | Shipped API or platform product (R3, must_have) | transferability | Integrations delivered and a playbook written; no product you launched | Likely the objection raised first after R1 | Any tool, API change or internal platform you specified that others adopted | Usage numbers, a request thread, a launch note, a screenshot | `[grounded]` CV; `[generic]` that this is the likeliest follow-up objection |
| G3 | Agile delivery (R7, must_have) | discovery | UAT and go-live shown; sprint work not | A `must_have` that one answer could move to `adjacent` or `direct` | Sprint planning, backlog refinement or demos with the engineers building your clients' custom work | A sprint board export or a retro note | `[grounded]` CV silence |
| G4 | Sales stakeholder work (R6, must_have) | discovery | Sales not mentioned | The JD pairs launches with sales | Pre-sales scoping calls, solution sizing, joint launch planning | A scoping doc or handoff note | `[grounded]` CV silence |
| G5 | Adoption metrics (R10, important) | discovery | Silent | The JD names adoption metrics as a duty | Usage counts, adoption rates or go-live success rates you tracked | A dashboard or a report | `[grounded]` CV silence; G2's answer may also close this |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The search was refused, so the entity and the live posting are unchecked. It may be real and findable, or the posting may be stale or aggregated | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Titled-years requirement may be applied literally | risk_signal | medium | "3+ years product management experience (must-have)" | Screening may count titled PM years, so an application without a PM title may not reach a person | `[generic]` pattern, not a claim about this employer | Would you consider candidates whose product work was done in a solutions or implementation role, and what would you want to see? | unresolved |
| RR3 | Compensation unstated | unknown | — | no compensation appears in the JD you pasted | The pay may sit above or below what suits you; no band could be checked | `[grounded]` JD silent | What is the budgeted range for this role? | unresolved |
| RR4 | Concrete scope | positive_signal | — | "Own the roadmap for our partner-facing API platform … two engineering squads; define and track adoption metrics" | Surface, squads and measurement are named, so success is definable | `[grounded]` JD states each | Who owns the platform's adoption metrics today? | noted |

Hold: don't spend application effort until RR1 verifies.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with the roadmap-input sessions, requirements documents and playbook bullets, in your own words and without changing any titles. Don't write "product manager", "owned the roadmap" or "shipped a product" unless G2 or G3 confirms them | R2, R8, R9 | `[grounded]` CV | pending your approval (`resume_edits_pending_approval`) |
| A1 | Go through a referral or a recruiter conversation before a cold application | RR2 | `[generic]` role-family pattern, not a fact about this employer | pending your approval |
| A2 | Ask RR2's question verbatim before investing in the loop | R1 | `[grounded]` register | pending your approval |
| A3 | Verify the employer and live posting on its own site | RR1 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: an internal request-triage tool that support agents adopted, from prior context. It is a `memory_lead`, so it prompts G2's question and nothing else.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology Series B partner API platform" and "Quartzline careers Product Manager Platform APIs"; both refused. It would have moved RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | Searched "platform API product manager hiring requirements transition from solutions engineer technical product manager"; refused. It would have moved market calibration, the pay check in RR3, and how literally R1 is usually read |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Permission to search → RR1 and RR3 can close, and market calibration can run.
- Your non-negotiables (pay floor, location, work arrangement) → the hard-gates line stops reading "unknown".
- A sanitized playbook page or an OpenAPI-based integration design → R4 to `high`.
- An answer to G2 plus a usage artifact → R3 and R10 can move.
- The hiring manager's name → the scope read and who your story is told to.
- The recruiter's answer to RR2 → the decision likely settles.

If you want it, I can save this as a `tuesday-dossier.md` for later steps.

G2 — Prior context suggests you built an internal request-triage tool that support agents adopted, but that isn't confirmed. Did you, and if so, what did you own, how many people used it, and how did you know it worked?

G3 — On custom builds, did you work inside the engineers' sprint process (planning, backlog refinement, demos), and what was your part in it?

G4 — Did you work with sales on scoping or launching any of those integrations, and what was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.