## Decision snapshot

**Yes, worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R7, R8
- `important` — adjacent: R6 (BigQuery as the role's warehouse) · unclear: R9 (Ingestion from app and CRM), R10 (Data contracts for analysts)

R6 — a credible bridge, its limit named; R9 (`low`) — the background you gave is silent on source systems; R10 (`low`) — data contracts are not mentioned.

**Opportunity ledger.** The stated pay is in line with the market figures you sent (RR5). Three things are open: I could not verify the employer or that the posting is live (RR1), the scope may be wider than one domain (RR2), and the reporting line and equity terms are unstated (RR3, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location, work eligibility and pay floor fit the posting's terms (R1, R2); (2) the posting is confirmed live on Pellucid's own careers site (RR1); (3) the BigQuery bridge is framed as adjacent and never as BigQuery experience (R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C of $52M, February 2026 | `[grounded]` the about-page text you pasted; I could not check it against the live site |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Requirements | 5+ years data engineering; SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Pay and location | $148,000–$166,000 plus equity; Remote (US) or Denver | `[grounded]` JD |
| Scope read | Three layers of the pipeline (ingestion, modelling, contracts) are named in one role, and no team, manager or direct reports are mentioned | `[inferred]` from the JD's mandate sentence and its silence on team |
| Market calibration | Series B–D senior data engineers: base median $151,000, interquartile range $139,000–$163,500; "senior" typically means 5–8 years, with ownership of one domain's pipelines and no direct reports. The posting's range straddles that median, and its top is above the 75th percentile. Your six years sit inside the typical band. | `[grounded]` the Datawright figures you sent, n=2,310; `[generic]` that these are patterns for companies at that stage, not Pellucid's pay practice |
| Stage | Evaluating, assumed: nothing says you have applied or spoken to anyone | `[inferred]` from your message |
| Unknowns | Hiring manager and reporting line; team size; equity terms; whether the recruiter who sent the pay report represents Pellucid; your location, eligibility and pay floor | — |
| Contradictions | None between the JD and the about-page text you pasted | `[grounded]` the two pasted texts, compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You have not said where you live or whether you can work in the US, so the term is not established. Confidence is `none` because there is no stated constraint to grade. | `[grounded]` JD term; your message silent | Ask G1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You have not given a pay floor, so I cannot tell whether the range meets it. | `[grounded]` JD figure; your message silent | Ask G2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. It is self-reported with no CV or other artifact, so `medium`. Years of experience are graded as fit, not as a gate. | `[grounded]` your message | Offer: your CV would let me inspect titles and dates |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You say you use both daily. Specific, but nothing inspectable has been shown; expect a probe on depth. | `[grounded]` your message | Offer: a sanitized query or code sample would raise to `high` |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the company's dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse. Limited inspectable proof. | `[grounded]` your message | Offer: a dbt docs or lineage screenshot would raise to `high` |
| R6 | BigQuery as the role's warehouse | important | adjacent | medium | transferability | Adjacent evidence: dbt on Snowflake. Limit: you have never used BigQuery, so none of its specifics are exercised. dbt models usually carry over between warehouses with some adapter-specific SQL changes. The JD lists "a cloud warehouse", not BigQuery, in its requirements. | `[grounded]` your message and the JD sentence; `[generic]` dbt portability | See G5 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration at the payroll company. Confirmed, no artifact. | `[grounded]` your message | Offer: a sanitized DAG screenshot would raise to `high` |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. Confirmed and specific; the suite itself has not been inspected. | `[grounded]` your message | Offer: suite structure or a sample expectation file |
| R9 | Ingestion from the app and CRM | important | unclear | low | discovery | Your background mentions Airflow pipelines but not which sources fed them. Indirect context only. | `[grounded]` your message silent on sources | Ask G3 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations suite is nearby work, but nothing says you agreed formal contracts with downstream consumers. | `[grounded]` your message silent on contracts | G4, not asked this turn |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and eligibility (R1, hard_gate) | hard_gate | Nothing stated about where you live or your US work eligibility | A gate: if it is not met, no fit elsewhere rescues it | Not applicable; it is a fact about you | Your own statement | `[grounded]` your message silent |
| G2 | Pay floor (R2, hard_gate) | hard_gate | The range is stated; your floor is not | A gate; the answer decides whether the range works for you at all | Not applicable; it is your constraint | Your own statement | `[grounded]` your message silent |
| G3 | Ingestion from app and CRM (R9, important) | discovery | Pipelines on Airflow are confirmed; their sources are not | The role's first-named responsibility is ingestion; this decides how directly it maps | Event or app-database extracts, CRM syncs or API pulls, vendor file drops; any ingestion into the warehouse you owned, even on payroll data | A DAG screenshot, an ingestion design note, a sanitized architecture diagram | `[grounded]` your message silent on sources; `[inferred]` that ingestion is the role's first-named responsibility, from the JD's list order |
| G4 | Data contracts (R10, important) | discovery | Test suite confirmed; formal agreements with consumers not | The JD names contracts as something analysts depend on | Agreed schemas or SLAs with analysts; breaking-change reviews; tests failing a pipeline on a consumer's behalf | A schema agreement, a changelog, a dbt contract or tests file | `[grounded]` your message silent on contracts |
| G5 | BigQuery (R6, important) | transferability | Snowflake and dbt confirmed; BigQuery not used | The JD names it as the warehouse, so it is the most likely objection | The case: the dbt project you built, with its limit stated. The strengthener: a small dbt-on-BigQuery project | A small repo or write-up | `[grounded]` your statement you have not used it; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not verified | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | I could not check the posting or the company, because both research calls were refused. That is a check not run, not a failed check. The posting may also be stale or aggregated. | `[generic]` pattern for any unchecked employer, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Scope may exceed one domain | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | Ingestion, modelling and contracts together may be wider than the single-domain ownership typical for the title | `[inferred]` from the JD's three layers against `[generic]` Datawright scope | Do you own all three layers alone, and how many data engineers are on the team? | unresolved |
| RR3 | Hiring manager, reporting line and team unnamed | unknown | — | The posting names no hiring manager | Reporting line and team size are open | `[grounded]` the posting as you supplied it | Who does this role report to, and how large is the data team? | unresolved |
| RR4 | Equity unquantified | unknown | — | "plus equity" | The grant, vesting and valuation basis are unstated, so the equity cannot be priced | `[inferred]` from the JD's silence on terms | What is the equity grant, and what are the vesting and valuation basis? | unresolved |
| RR5 | Pay stated and in line with market | positive_signal | — | "$148,000–$166,000" | Transparent pay; the range straddles the sent median of $151,000 and its top exceeds the $163,500 75th percentile | `[grounded]` JD figures and the Datawright figures you sent; `[generic]` that those are stage-wide patterns, not Pellucid's offer | Where in the range would someone with six years' experience land? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on Pellucid's own careers site, from a link you find yourself, before investing effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with your dbt project on Snowflake, using your own words (about 180 models, built by you), then the Great Expectations suite you set up | see R5, R8 | `[grounded]` your message | pending your approval |
| A3 | Say plainly that you have not used BigQuery and that your dbt work was on Snowflake; do not claim BigQuery experience | see R6 | `[grounded]` your statement | pending your approval |
| A4 | Optionally build a small dbt-on-BigQuery project as a work sample to narrow the R6 limit | see G5 | `[inferred]` from the R6 limit | pending your approval |
| A5 | Ask RR2, RR3 and RR4's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I sent a fetch of the careers page URL and a search for "Pellucid Learning online tutoring K-12 Denver Series C"; both were refused. Would have moved: RR1 and role reality's contradictions row |
| 2. Role-family sweep | skipped | The Datawright report you sent already fixes the market calibration line and the pay-versus-market read in RR5 |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form |

I'm offering to save this as `tuesday-dossier.md` so a later pass can build on it; say the word and I'll write it.

## Upgrade menu

- Your location, US work eligibility and pay floor → R1 and R2 close, and the decision likely moves to `go` or `no_go`.
- Your CV, plus a sanitized query or code sample, a dbt docs or lineage screenshot, and a Great Expectations suite or DAG screenshot → R3, R4, R5, R7 and R8 can rise to `high`.
- An answer to G3, and later G4 → R9 and R10 resolve.
- Search and fetch permission → target 1 runs, and RR1 can reduce or confirm.
- The hiring manager's name → target 3 runs and informs which story to lead with.
- A deeper research pass on Pellucid (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs, once search is permitted.

**Questions**

G1 — Are you based in the US with the right to work there without sponsorship, and would you take the remote or the Denver option?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — What is the lowest base pay you would accept for this role?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G3 — Which source systems did your Airflow pipelines ingest from (app databases, CRMs, vendor files, APIs), and which of those did you personally own end to end?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.