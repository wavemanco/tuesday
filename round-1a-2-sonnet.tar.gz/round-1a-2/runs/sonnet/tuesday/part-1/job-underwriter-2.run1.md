I'm still loading the underwriter's reference files: the risk-and-decision rules, output discipline and research tiers. Then I'll write the assessment.
**Decision snapshot**

**No, not a waste of time. This role is worth applying to on conditions, but R1a (3+ years in a titled PM role) is absent and wording can't fix it. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1b (equivalent PM work), R2 (shipped API or platform products) · unclear: R4b (sales and launch coordination), R5 (agile delivery) · absent: R1a (3+ years titled PM)
- `important` — direct: R7 · adjacent: R6 (own the roadmap), R8 (specs, drive delivery) · unclear: R9 (adoption metrics)

R1a — the title gap, a plain fact; R2 — a bridge with a named limit; R7 — direct, but your resume files it under solutions work.

**Opportunity ledger.** The mandate is concrete (RR5), but the employer is unverified (RR1), the 3+ years may be screened literally (RR2), and pay, level and decision rights are unstated (RR3, RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The 3+ years is confirmed as flexible for equivalent product work (RR2, R1a, R1b).
  2. Quartzline is verified as a live employer with this posting (RR1).
  3. You can name something you shipped, not only integrated (R2, G1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B. Not checked beyond the posting | `[grounded]` JD header; existence unverified (RR1) |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Required | 3+ years PM experience (must-have), shipped API or platform products, technical fluency, stakeholder management across engineering, sales and customers, agile delivery | `[grounded]` JD |
| Scope read | An individual-contributor PM owning one product surface, with squads to drive but no stated reports | `[inferred]` from "two engineering squads" and no mention of managing people |
| Pay, level, reporting line, location | Not stated | `[grounded]` JD silent |
| Market calibration | Not run: search was not permitted | — |
| Unknowns | Decision rights over the roadmap; whether "3+ years" means titled years; pay | — |
| Contradictions | None within the posting text; careers page not checked | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years in a product management role (titled) | must_have | absent | none | capability | You have never held a PM title, so no titled years exist. The JD gives no sign the requirement is credential-bound, so it is not a gate. A literal screen would likely stop here | `[grounded]` your statement; `[generic]` that titled-years requirements are often screened literally | Ask whether equivalent work counts (RR2); closure path in plan A3 |
| R1b | The same requirement, as equivalent PM work | must_have | adjacent | medium | transferability | You coordinated engineers, client engineers and PMs on custom builds, and ran quarterly roadmap-input sessions for product. Limit: this was input to roadmaps and delivery on client builds, not owning a product's roadmap or its outcomes | `[grounded]` your resume summary; limit `[inferred]` from it | Name what you owned versus fed into (G1) |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ end-to-end client integrations of your vendor's REST APIs show deep use of an API product. Limit: integrating a product is not shipping one. An earlier-conversation lead about an internal triage tool is unconfirmed and not counted here | `[grounded]` your resume summary; `[grounded]` limit as stated | G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI specs and integration architecture are stated. No artifact inspected, hence `medium` | `[grounded]` your resume summary | Offer: a sanitized integration-architecture doc would raise to `high` |
| R4a | Stakeholder management: engineering and customers | must_have | direct | medium | none | Your own engineers, the client's engineers and PMs, plus workshops and UAT across 30+ clients. Limit: sales and support are not mentioned | `[grounded]` your resume summary | none |
| R4b | Working with sales and support on launches | must_have | unclear | low | discovery | Silent on both. The triage-tool lead touches support, but it is unconfirmed | `[grounded]` resume silence; lead is a `memory_lead` | G3 |
| R5 | Agile delivery | must_have | unclear | low | discovery | Go-lives and UAT are stated; sprints, backlogs or squads are not. Waterfall-style delivery is a fair reading until you say otherwise | `[grounded]` resume silence | G2 |
| R6 | Own the roadmap | important | adjacent | medium | transferability | You collected client feedback for product quarterly. Limit: no stated say in prioritization | `[grounded]` your resume summary; limit `[inferred]` | G1 |
| R7 | Discovery with integration partners | important | direct | medium | presentation | Scoping workshops and quarterly feedback sessions with clients are close to this. Your resume files them as solutions work | `[grounded]` your resume summary | Plan E1 |
| R8 | Write specs and drive delivery with squads | important | adjacent | medium | transferability | You wrote requirements documents and integration architecture for client builds. Limit: no squad you worked inside | `[grounded]` your resume summary; limit `[inferred]` | G1 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | No metrics are stated. The integration playbook your team uses and the triage-tool lead both involve adoption, but neither is quantified or confirmed | `[grounded]` resume silence | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped or owned something (R2, R1b, R6, R8) | transferability | Integration delivery and feedback-gathering, but nothing you built and others adopted | A `must_have` at `adjacent` — a confirmed shipped thing is the most direct way to narrow the objection | An internal tool or process others adopted; the integration playbook; a feature you specified that engineering built; a client-driven change you got onto the roadmap | The tool or playbook itself, a spec, a usage figure, a release note | `[grounded]` resume; `[inferred]` that a shipped artifact narrows the objection |
| G2 | Agile delivery (R5) | discovery | Delivery shown only as go-lives and UAT | A `must_have` at `unclear`; one sentence of truth could settle it | Sprints or standups with the client's squad; backlog grooming for custom builds | A sprint board or backlog screenshot (sanitized) | `[grounded]` resume silence |
| G3 | Sales, support and adoption metrics (R4b, R9) | discovery | Silent on both; the triage tool may answer both | Closes a `must_have` and an `important` row at once | A launch you coordinated with support; anything where you tracked usage | A usage figure, a support-team rollout note | `[grounded]` resume silence |
| G4 | Titled years (R1a) | capability | No titled PM role | Cannot be closed by wording | A real PM-titled stretch, even internal or part-time | — | `[grounded]` your statement; closure path in plan A3 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your careers site, and who I would be interviewing with? | unresolved |
| RR2 | "3+ years" may be a literal screen | risk_signal | medium | "3+ years product management experience (must-have)" | The filter or first reader may check for titled PM years, with no room for equivalent work | `[generic]` how requirements marked must-have are often read | Is the 3+ years a requirement for PM titles, or would you consider equivalent product work from an adjacent role? | unresolved |
| RR3 | Pay, level and reporting line not stated | unknown | — | "Own the roadmap for our partner-facing API platform" | The level could sit above or below what 3+ years normally buys | `[inferred]` from the posting's silence | What is the salary band and level, and who does the role report to? | unresolved |
| RR4 | Decision rights over the roadmap | unknown | — | "Own the roadmap … drive delivery with two engineering squads" | Ownership may be partly shared with sales-driven requests | `[inferred]` from the JD's silence on who sets priorities | Which roadmap decisions does this role make alone, and which go to sales or executives? | unresolved |
| RR5 | Scope and measures are concrete | positive_signal | — | "define and track adoption metrics"; "two engineering squads" | Success looks measurable and the delivery structure is defined | `[grounded]` JD | How do you measure adoption today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move your line about running quarterly roadmap-input sessions collecting client feedback for product to the top of the role's bullets, wording unchanged | R7, R6 | `[grounded]` your resume | resume_edits_pending_approval |
| E2 | Keep your actual title. Do not relabel any role as PM | R1a — wording cannot supply titled years | `[grounded]` your statement | pending your approval |
| A1 | Verify Quartzline and the live posting before spending effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the RR2 question to a recruiter before investing in a full application | R1a, RR2 | `[grounded]` RR2 | pending your approval |
| A3 | In parallel, also look at roles asking for fewer or no titled-PM years, such as technical product or implementation-to-product moves | R1a | `[generic]` role-family pattern | pending your approval |
| W1 | A sanitized one-page example: integration playbook excerpt or a requirements doc | R3, R8 | `[grounded]` your resume | pending your approval |

If you go ahead, resume-tailor can turn E1 into an approve-first edit ledger.

## Evidence status

Verified: none yet. Unverified lead: a prior-conversation mention of an internal request-triage tool that support agents adopted. It is unconfirmed and prompts G1 only.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | A search for the company was refused. It would have checked existence, size and whether the posting is live (RR1), so RR1 stays open |
| 2. Role-family sweep | unavailable | A search for role norms was refused. It would have fed role reality's market calibration and RR2's screening hypothesis, which stay `[generic]` |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Dossier and upgrade menu

I can save this as `tuesday-dossier.md` if you want it to carry into later steps.

- Permission to search → RR1 closes or confirms, and role reality gets a market calibration.
- A hiring manager's name → scope read and which story to lead with.
- A sanitized integration-architecture doc or playbook excerpt → R3 to `high`.
- Your answers to G1–G3 → R2, R5, R4b and R9 move, and the decision may firm up to `go` or soften.

G1 — Did you build the internal request-triage tool I may have heard about before? If so, what did you own, who adopted it, and is there a usage figure or screenshot? If it isn't yours, tell me what you did own that others used.
G2 — On any custom build, did you work inside the client's or your own engineers' sprints or backlog? Describe what that looked like.
G3 — Have you coordinated a launch or rollout with a support team, or tracked usage of anything you delivered? What was the figure?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.