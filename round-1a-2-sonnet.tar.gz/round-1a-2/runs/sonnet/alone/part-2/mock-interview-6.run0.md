I'll start by reading the skill's reference files.
Your prep pack for all three rounds is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/alone/part-2/rooms/case-6-denied-ddc83735/larkfield-systems_engineering-manager_interview_pack.md`. It has a shared fit snapshot, a separate mini-pack for each round with its own persona weights, question bank and reverse questions, and a list of claims the pack won't coach.

I built it from your note alone. Web search permission was refused, so nothing about Larkfield's values or strategy is researched. That means no values cheat sheet for Monday, and the company-strategy question is generic. The persona weights come from your description of each round, since no interviewer names were given.

The pack names B1 (the hardware-roadmap objection) as the highest-ROI prep. Every claim about you rests on four sentences from your message, quoted exactly.

Say the word and I'll play the Director as the Skeptic on B1 so you can rehearse it live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full job description and your CV, or should I stay with what you've told me? Either one turns the thin rows in the fit snapshot into real evidence and replaces several of the selection scaffolds with answers built from your own stories.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack (loop mode): Engineering Manager, Larkfield Systems

**Candidate:** Yusuf. **Rounds:** Tuesday, 45 minutes, the Director of Engineering (hiring manager, your would-be boss). The Thursday after, 60-minute panel of two staff engineers and a product manager. The following Monday, 30 minutes with the VP Engineering, described by the recruiter as "values and leadership philosophy". No interviewer names were given.

## How to use this pack

- **Personas are how a question is asked; types are what it scores.** Each round below has its own persona weights, bank and reverse questions. The fit snapshot, prohibited claims and sources are shared by all three rounds.
- **Type key.** VAL: past behavior against values or leadership. EXP: whether your own claims survive scrutiny. JD: the listed job, gaps included. CO: company and market thinking. CASE: a live problem from the role.
- **Provenance labels.** `[grounded]` rests on something you supplied. `[inferred]` is this pack's derivation. `[generic]` is a role-family pattern with no claim about Larkfield or about you. Where guidance says something about your past, the sentence it rests on is quoted beside the label.
- **Answer slots.** An instruction in a guidance cell that starts "Answer slot" is for the interview, not for this chat. Say the first branch only if it is true. The second branch is a complete, honest answer.
- **Guidance is scaffolding, not a script.** Everything is meant to be said in your own words.
- **Question IDs.** A to C: Tuesday. D to G: Thursday panel. H to J: Monday.
- **The highest-ROI prep in the pack is B1**, the hardware-roadmap objection. It is the likeliest hard question, it aims at your thinnest evidence, and a rehearsed, non-defensive answer changes the round.

## Fit snapshot (shared)

Requirements are quoted from the role description in your message. Evidence is your own sentences from your message, nothing inspected behind any of them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | The material says team lead of 6, not two squads and not 11 engineers, and the words stay there: "3 as a team lead of 6". Answer slot: the role's two-squads line makes a probe on scope likely. If any of your lead work reached beyond your own team, say what and how, in your own words; if it did not, say so plainly and stay with the team lead of 6 |
| F2 | "own delivery" — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote at its own scope: "I pushed a reliability quarter through against roadmap pressure". Your material says a quarter, not delivery ownership generally. Answer slot: the role's own-delivery line makes a probe on how delivery was tracked or traded off likely. If delivery commitments were yours to set or track, say how; if they were not, or there was no such practice, say so plainly and stay with the reliability quarter. The 60% raises the figure slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours |
| F3 | "hiring" — role description in your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap in terms, but a line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: "I run our hiring loop for backend roles". The figure counts interviews, and the quote does not tie them to hires or say who conducted them; the figure slots apply, and the one to settle first is which interviews were yours |
| F4 | "growth for 11 engineers" — role description in your message | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: the role's growth line makes a probe likely. If you have helped an engineer grow, say who or what and what part was yours, in your own words; if you have not, or it was not yours, say so plainly and say how you would approach it |
| F5 | "partner with hardware and product on roadmap" — role description in your message, product limb | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | The quote has roadmap pressure but not whose, and not whether a product partner was involved; linking it to product partnership is this pack's derivation. Answer slot: if a product partner was part of that quarter, say how you worked with them and what part was yours; if the pressure came from elsewhere, or no product partner was involved, say so plainly and stay with the reliability quarter |
| F6 | "partner with hardware and product on roadmap" — role description in your message, hardware limb | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | discovery | You stated an absence of owning a hardware-adjacent roadmap, not of working alongside hardware, so partnering is open. Words you may say: "I've never owned a hardware-adjacent roadmap". Answer slot: if you have worked alongside hardware teams in any capacity, say how and what part was yours; if you have not, say so plainly and say what you would ask them first |
| F7 | "industrial IoT" — role title line in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | The quote carries a payments company, not devices, and the words stay at "currently at a payments company". Answer slot: if any of your work touched devices or hardware-adjacent systems, say what and what part was yours; if none did, say so plainly and say what you would want to learn first |

Requirement coverage by question:

| Requirement | Questions covering it |
|---|---|
| "Lead two squads building device-management services" | A1, A3, D3, I2 |
| "own delivery" | A1, A2, D2, E3, I3 |
| "hiring" | A4, H3 |
| "growth for 11 engineers" | B3, I3 |
| "partner with hardware and product on roadmap" | A1, B1, E3, F1, I2 |
| "industrial IoT" | B2, I1 |

## Round 1: Tuesday, Director of Engineering (45 minutes)

### Persona weights

Relationship prior for a hiring manager is Case/Strategist plus Skeptic. Your note says this is your would-be boss and gives no recruiter focus areas, so the prior stands unadjusted. The weights rest on your description of the round, not on a documented Larkfield process.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems on the actual roadmap: a hardware shift, on-call against features | high: the hiring-manager prior, and the role is built around partnering on roadmap and owning delivery | Clarify, state the objective, give options with costs, name risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of the hardware gap, the domain switch and growth | high: the hiring-manager prior, and your own note names the hardware gap, so the person who would own that partnership with you reaches it early | Rehearse B1 until it is boring; bridge only from your quoted sentences; say the limit plainly |
| Conversational | The opener, and "what do you need from me" | low: a boss round opens casually, and casual questions are still scored | A 90-second arc for the opener; treat casual questions as scored |

### Bank A: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Hardware tells you a device launch has moved up, and product wants a feature that isn't on this quarter's plan. Your two squads are already full. What do you do first?" | CASE | [generic] | Clarify first: what moved, what is fixed, who decides. State the objective, give two options with their costs, say what you would tell hardware and product and when, name the risk you would watch, and challenge one premise, for example whether the squads must absorb it. The case needs no claim about your past, so the guidance makes none | The role's partner-on-roadmap line (F5, F6) turned into a live decision. CASE because the Director scores structure over the answer; the label is generic because the scenario is a pattern, not a Larkfield fact |
| A2 | "One of your squads is carrying heavy on-call while the other is shipping, and the roadmap is tight. How do you decide where the next quarter goes?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure the decision: what each squad's load is, what the roadmap commits you to, what you would trade and what you would protect, how you would tell both squads. If you reach for your own quarter, keep to its sentence: "I pushed a reliability quarter through against roadmap pressure". The figure's slots are rehearsed in D1; add nothing here beyond the quote | F2 is the closest evidence to the own-delivery requirement, so the Director may test it as a live case. CASE because it asks for a decision rather than a record |
| A3 | "You'd lead two squads and 11 engineers from day one. How would you spend your first 30 days?" | JD | [grounded] | A plan, not a past. Who you would listen to first among the engineers and among hardware and product, what you would ask, what you would hold back from changing, and what you would want the Director to decide early. Say what you do not yet know about this team | Scores the stated scope in the role line (F1). JD because it tests the listed job; the guidance makes no claim about the candidate |
| A4 | "You run the hiring loop for backend roles today. What would you keep and what would you change when hiring for these squads?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say it at the quote's scope: "I run our hiring loop for backend roles". The figure raises the number slots: how it was counted, including whether those were interviews you conducted or interviews the loop held, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. The change-and-keep part is a plan: what you would keep, and what you would ask the squads before changing anything | F3 is the headline figure on hiring, so a defend-the-number probe is likely. EXP because it tests attribution; JD is the secondary read since hiring is a listed duty |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've told me you've never owned a hardware-adjacent roadmap, and this role partners with hardware on roadmap. How do you handle that?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | The deepest rehearsal in the pack. Level 0, hold the plain acknowledgment and stop: "I've never owned a hardware-adjacent roadmap." Level 1, "Have you worked alongside hardware at all?": answer slot: if you have worked alongside hardware teams in any capacity, say how and what part was yours; if you have not, say so plainly. Level 2, "What's your plan?": a plan only, the first questions you would put to hardware and product, whom you would ask to teach you, and the one thing you know you do not yet know about hardware planning. Level 3, "What if that isn't enough?": concede specifically what you would need from the Director to ramp and how you would both tell early that it was not working. Never claim hardware-roadmap experience | F6 sits on the role's hardware-partnership line, which makes it the likeliest objection from the person who would own that partnership with you. JD because it scores a stated requirement; the Skeptic delivery is why it gets the most follow-up levels |
| B2 | "You're at a payments company today. Why industrial IoT, and why now?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Start from the quote's words: "currently at a payments company". Then your own two reasons, specific to this role rather than to the industry. Answer slot: if any of your work touched devices or hardware-adjacent systems, say what and what part was yours; if none did, say so plainly and say what you want to learn. Claim no IoT exposure you have not stated | F7 is the domain gap and motivation consistency is what a Skeptic scores. EXP because the answer must survive cross-examination about your own path |
| B3 | "Tell me about a time you helped an engineer grow." | JD | [generic] | Selection scaffold: pick a time with a named engineer or situation, something you did that was yours, and an outcome that engineer would recognize. If no such time comes to mind, say so plainly, then say how you would approach it | F4 has nothing quoted, so no story is mapped and the pack supplies none. The theme comes from the role's growth line; JD because growth is a listed duty |

### Bank C: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through your path to this point." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc on the quote's beats only: 9 years engineering, 3 as a team lead of 6, currently at a payments company. Then why this role, in your own words. Add no titles, tenures or team facts the quote does not state | Nearly certain to be asked; EXP because it is your own history in your own words (F1) |
| C2 | "What would you need from me, as your director, in the first month?" | JD | [generic] | Rehearse three asks in your own words: what you would want decided early, how you would want to hear bad news, and what you would want taught about hardware planning. No claim about your past | Casual in register, scored for how you would operate with a boss. JD because it tests role fit; the label is generic because it is a pattern |

### Reverse questions: Tuesday

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "What would you want the person in this seat to have changed by the end of the first ninety days?" | Surfaces the Director's own success definition, which you can hold your A3 plan against |
| R1.2 | "Where do the hardware and software roadmaps pull against each other today, and who has been absorbing it?" | Tests B1's gap against his reality and shows you are asking about the seam before being asked |
| R1.3 | "How is delivery for the two squads judged today, and what would tell you it was going well?" | Ties to the own-delivery line and tells you what you would be measured on |
| R1.4 | "How do you want to hear about problems: early and rough, or later and resolved?" | A working-relationship question that is also an answer to C2 |
| R1.5 | "What concerns do you have about my fit that I could address now?" | Invites B1 and B2 while you can still answer them in the room |

## Round 2: Thursday panel, two staff engineers and a product manager (60 minutes)

### Persona weights

No names or roles beyond the titles were given, so weights are blended per member: staff engineers as technical specialists (Prober plus Pressure), the product manager as cross-functional (Values/Behavioral plus Conversational). The Peer Evaluator is this pack's addition, because the role partners with all three on direction and roadmap; that addition is an inference. The weights rest on your description of the round.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Staff engineers reading your lines for inputs and denominators; the 60% and the 40 interviews are the obvious targets | high: the technical-specialist prior, two of three panelists | Know what you can and cannot say about how each number was counted; say plainly when you do not know; name your weakest assumption before they do |
| Peer Evaluator | Seam-splitting between EM and staff engineers; "what do you need from us"; the PM on how you would decide together | high: the role partners with all three, and a panel of peers prices what a hire does to their work | Reciprocity first: what you would take off their plates, as a plan; propose seam principles rather than claim to know the seam |
| Values/Behavioral | The PM's scenario probes on disagreement and customers | medium: the cross-functional prior for one panelist of three | Story-map from a quoted sentence where one carries a story; otherwise a selection scaffold with its honest branch |
| Pressure | A staff engineer pressing "how much was actually you" | low: the technical-specialist prior's second persona, one question deep | Pause, restate, hold through two follow-ups, concede specifically |

### Bank D: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how that 60% drop in on-call burden was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Say the sentence at its scope first. Then the four slots, in your own words: how it was counted, and if you do not know, say so plainly; what it is sensitive to; the assumption you would defend least, named before the prober names it; and which part was yours. Do not offer a measure or method you cannot repeat under a second question | F2 carries the pack's headline figure, and a defend-the-number probe is certain from this persona. EXP because it scores attribution and honesty about the count |
| D2 | "How did you decide a reliability quarter was worth the roadmap pressure?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer slot: the role's own-delivery line makes a probe on how the trade-off was decided likely. If the decision was yours, say how you decided and what you weighed; if it was shared or someone else's, or there was no formal decision, say so plainly and return to the sentence: "I pushed a reliability quarter through against roadmap pressure". Hold through two follow-ups by returning to it, never by adding to it | The premise is a decision the quote does not state, so the guidance is a slot whose second branch lets the premise be false (F2). EXP because it tests what was actually yours |
| D3 | "A device-management service pushes an update to a large fleet and some devices stop responding. You're the engineering manager. What do you do in the first hour, and what do you leave to your engineers?" | CASE | [generic] | Structure it: clarify how many and how bad, state the objective, say who you need in the room, what you would decide and what you would hand to your engineers, who you would tell in hardware, product and support, and what you would review afterwards. Say plainly what you do not know technically. The case asks about no past, so the guidance makes none | Staff engineers score where the EM stops and technical judgment starts, on the role's own service area (F1). CASE; the label is generic because the scenario is a pattern |

### Bank E: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where's the seam between an engineering manager and a staff engineer on technical direction, and what happens when you disagree?" | JD | [generic] | Offer seam principles instead of pretending to know the seam: ask each staff engineer where they want a say, say who decides what and how a disagreement is voiced and recorded. Reciprocity: say what you would take off their plates, as a plan. No claim about your past | A peer-evaluation staple for any panel member who will work beside the hire; JD because it tests how the role operates |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams, with the other team named, what each did, and how you said so aloud. If no such time comes to mind, say so plainly, then say how you would handle it | The persona's own stem. VAL because it tests behavior; no quoted sentence of yours speaks to it, so no story is mapped |
| E3 | "I'm the product manager. A quarter comes where reliability work and a feature I need collide. How do we decide together?" | CASE | [generic] | Structure it: ask what the feature is committed to and to whom, put the on-call cost and the feature cost in the same terms, propose a decision rule you would want agreed before the next collision, and say what you would concede. No claim about your past | The role's product-partnership line (F5) as a live decision, from the person who would be your partner on it. CASE because it is a live collaboration problem |

### Bank F: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you disagreed with a product partner." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-map on the sentence's beats: the reliability quarter, the push, the roadmap pressure, each in your own words. Answer slot: the role's product-partnership line makes a probe on who the disagreement was with likely. If a product partner was on the other side, say what you said and what part of it was yours; if the pressure came from elsewhere, or there was no disagreement with a product partner, say so plainly and stay with the quarter | F5 is the only quoted material near product partnership, and thin. The theme comes from the role description; VAL because it scores behavior in a disagreement |
| F2 | "When did you put a customer's need ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a named customer-facing stake, a moment where you chose, and an outcome. If no such time comes to mind, say so plainly, then say how you would handle it | The persona's own stem, asked by a PM who works with customers. No quoted sentence of yours speaks to it, so nothing is mapped |

### Bank G: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "That on-call result: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pause and restate the question. Hold the position the sentence carries: the push was yours, "I pushed a reliability quarter through against roadmap pressure", and the on-call burden that dropped was your team's. Hold through two follow-ups by returning to that. Then concede specifically, in your own words, any part that was your team's or someone else's. Do not extend the claim to cover what the sentence does not | The persona's own stem, aimed at F2. EXP because it is an attribution probe; Pressure is the delivery, which is why it carries hold-then-concede |

### Reverse questions: Thursday

| # | Question | Why it lands |
|---|---|---|
| R2.1 | To the staff engineers: "What could a new engineering manager do in the first month that would genuinely help your work?" | The reciprocity question: it asks what you can give before what you need |
| R2.2 | To the staff engineers: "Where do technical decisions get stuck today, and who breaks the tie?" | Shows interest in the seam you were just asked about in E1 |
| R2.3 | To the product manager: "When hardware timing moves, how does a roadmap decision get made and where would you want an engineering manager in it?" | Goes straight at the partnership line and tests your E3 answer against practice |
| R2.4 | To all three: "How does on-call work for these squads today?" | Lets you learn the baseline your reliability story would be measured against |
| R2.5 | To all three: "What would you tell a new engineering manager here that isn't in the job description?" | Invites candor from people who will work with you daily |

## Round 3: Monday, VP Engineering (30 minutes, "values and leadership philosophy")

### Persona weights

Relationship prior for a skip-level or executive is Case/Strategist plus Pressure. The recruiter's own words, "values and leadership philosophy", make Values/Behavioral the top persona, and a loop source documents a values-style round here. Larkfield's published values are not in hand, so the VAL bank is themed by the recruiter's words and your quoted sentences, and the values cheat sheet is not included.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes on leadership and what you stand for | high: the recruiter's description of the round | Story-map from a quoted sentence where one carries a story, a selection scaffold with its honest branch where none does; "we" for context, "I" for contribution |
| Case/Strategist | Altitude questions on where the work is heading and how to organize it | medium: the skip-level prior; 30 minutes leaves room for a few | State the hypothesis early; say what you would verify; use the role's own vocabulary |
| Pressure | A direct challenge on the one thing you have not done | medium: the skip-level prior's second persona, and your note gives the VP a clear target | Pause, restate, hold through two follow-ups, concede specifically; short answers |

### Bank H: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-map on the sentence's beats: the reliability quarter, the push, the roadmap pressure, in your own words. Answer slot: if the pressure came from leadership and you told them something unwelcome, say what you said and what happened next; if it did not come from leadership, or you did not have that conversation, say so plainly and stay with the quarter. Do not supply how it landed unless it is true | The persona's own stem, and F2 is the only quoted sentence near it. VAL because the recruiter named values and leadership as the focus |
| H2 | "What's your leadership philosophy, and how would your team see it day to day?" | VAL | [generic] | Selection scaffold: state it in two sentences in your own words, then name one thing a teammate would observe. If no instance of your own comes to mind that shows it, say so plainly and say how you would test it | The recruiter's own words are the raising source. No quoted sentence of yours states a philosophy, so none is attributed to you |
| H3 | "Tell me about a time your hiring standards were tested." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Start from the quote: "I run our hiring loop for backend roles". Answer slot: if a particular decision in the loop tested a standard, say what it was and what part was yours; if none comes to mind, say so plainly and say how you hold the loop to a standard | The role's hiring line raises it and F3 is the only quoted sentence near it. VAL because it tests behavior under a standard |

### Bank I: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "Where do you think device management for industrial customers is heading, and what should a team like ours bet on?" | CO | [generic] | Reason from first principles in your own words, state your hypothesis early, and mark what you would want to verify. Do not recite company facts and claim no IoT experience. Strategy-specific CO questions are generic here because research could not run | F7 is the domain gap, and an executive scores whether you can think at the company's altitude. CO because it tests market thinking; generic because no Larkfield strategy was in hand |
| I2 | "How would you set up two squads and 11 engineers so that hardware dates and platform reliability both get honored?" | CASE | [generic] | Structure it: what each squad owns, where the seam sits and who owns it, how hardware dates enter planning, and how reliability work is protected. Name a metric only if you have one of your own. The case asks about no past, so the guidance makes none | The role's scope and partnership lines (F1, F5, F6) at the VP's altitude. CASE because it is a live organizing problem |
| I3 | "What would success look like for you in this role after a year, and what would you need from me?" | JD | [grounded] | Outcomes in your own words against the role's own three parts: delivery, hiring and growth. Offer no figure of your own invention, and ask what the VP would measure. No claim about your past | Tests the stated scope (F2, F3, F4) as a forward plan. JD because it tests the listed job |

### Bank J: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Why should we take a risk on someone who's never managed managers?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Pause and restate. Hold the plain acknowledgment first, without hedging: "I've never managed managers". Then the facts your quotes carry: "3 as a team lead of 6". Hold through two follow-ups by returning to those, never by adding. Concede specifically what you have not done and say how you would close it, as a plan | The negative is your own, so it can be quoted back. The role description names squads and 11 engineers and does not say managers lead them, so do not assume it. JD because it scores fit against the role; Pressure is the delivery |
| J2 | "Which of your leadership instincts would your team say is a weakness?" | VAL | [generic] | Selection scaffold: pick one real instinct, say what it costs, and say what you do about it. If no instance comes to mind, say so plainly, then say how you would find out | A common closer to a leadership-philosophy conversation. No quoted sentence of yours speaks to it, so nothing is attributed |

### Reverse questions: Monday

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "Can you tell me about a recent decision where the company's values pulled against a commitment?" | Moves a values conversation from the wall to practice |
| R3.2 | "What do you see as the hardest leadership challenge for engineering managers here over the next year?" | Gives you the VP's own frame for the role |
| R3.3 | "How do you support an engineering manager who is new to the level?" | Asks about the support you would get without leading with a gap |
| R3.4 | "How does engineering get a voice in the hardware roadmap at the top?" | The role's partnership line at the VP's altitude |
| R3.5 | "What would make you say in a year that this hire was right?" | Gets the VP's success definition, to set against your I3 answer |

## Prohibited claims (shared)

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F6 | The plain acknowledgment: "I've never managed managers". No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F6 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap". The open point is working alongside hardware, and B1's slot asks only that |
| Led two squads, or owned delivery for 11 engineers | Inflated form of F1 | F1's quote at its own scope: "3 as a team lead of 6". The limit is the pack's observation: your material says a team lead of 6, not two squads |
| Owned delivery across a roadmap | Inflated form of F2 | F2's quote at its own scope: "I pushed a reliability quarter through against roadmap pressure". D2's slot stays inside that quarter |
| Made the hiring decisions for about 40 hires | Inflated form of F3 | F3's quote at its own scope: "I run our hiring loop for backend roles". The limit is the pack's observation: the quote counts interviews, not hires |
| Single-handedly cut on-call burden by 60% | Inflated form of F2 | F2's quote at its own scope: the push was yours, and the burden that dropped was your team's. G1 rehearses the limit |

## Sources

Provided documents: your message (the role description, the three round descriptions including the recruiter's phrase for Monday, and your background).

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Search "Larkfield Systems industrial IoT company values" was refused: web search permission was not granted. It would have moved the VAL bank's published-value mapping and a values cheat sheet for Monday |
| 2. Larkfield Systems interview process, engineering manager | skipped | Your own words fix the loop: three rounds, who runs each, and the recruiter's focus for Monday; persona weights follow from them |
| 3. Larkfield Systems strategy and recent news | unavailable | Search "Larkfield Systems industrial IoT device management strategy news" was refused for the same reason. It would have moved I1 and any strategy-grounded CO or CASE question, which are generic here |
| 4. Interviewer names | n/a | No names were given, so no query could be formed; the interviewer read is absent |
| 5. Representative engineering manager JD | unavailable | No call was sent after the first two were refused. It would have added role-requirement rows tagged `[inferred]` beyond the three limbs in your role description |

No fuller JD, no CV and no Larkfield published material were available. Nothing in this pack about Larkfield comes from outside your message.

## Upgrade menu

- Full JD text: any mid-list requirement beyond the three limbs in your role description becomes a fit row and a question
- Your CV: evidence cells beyond four sentences from your message, and more story-mapped answers in place of the selection scaffolds in B3, E2, F2, H2 and J2
- An inspectable artifact behind your claims: the paging or on-call export behind the 60% could lift F2 from medium, and the hiring-loop scorecards or rubric behind the 40 interviews could lift F3
- Your answers to the answer slots in F1, F2, F4, F5, F6 and F7: each becomes quoted material and the rows that draw on it are rebuilt
- Interviewer names, all three rounds: an interviewer read, persona weights adjusted from public footprint, and reverse questions tied to each person's path
- Web search permission for Larkfield's values and strategy: a values cheat sheet for Monday and strategy-grounded CO questions, after which a deeper pass of up to 6 more searches and 2 more fetches, several more minutes, can be added, offered once
- The recruiter's focus areas for the Thursday panel, including whether a case or presentation is expected: coverage that fits, and a build section for any declared deliverable
- Hours available across the two weeks: a prioritized prep triage sized to them
- A job-underwriter check of the role: verified evidence, allowed strategies per weak area and absolute prohibited claims, none of it needed to use this pack
