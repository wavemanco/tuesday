Research is limited, because the web searches were denied permission. I'm building the pack from your message alone and labelling what that costs.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/alone/part-2/rooms/case-5-denied-7592a6ac/kelverton-rail_senior-partnerships-manager_interview_pack.md`. It has 19 questions and a build section for the 15-minute POV. Its prep triage fits your four hours: POV first, then commercials, then defending your numbers.

- **No JD:** the pack is built from the recruiter's words as you quoted them, plus your own background. Requirements that came from no source are labelled `[generic]`.
- **Searches denied:** I sent five and permission was refused for each. The pack therefore has no values sheet, no grounding brief and no interviewer read, and the persona weights rest on your account of the panel.
- **Market report not read:** its text wasn't in front of me, so nothing in the pack draws on it. I built the POV's differentiation row around it anyway, and you choose which item to treat as the consensus.
- **Likeliest objection:** your own message states "never sold into rail specifically" and "never carried a direct quota". C1 rehearses that objection with three follow-up levels, and it's the question I'd spend the most time on.
- **Defend-the-number slots:** the £4M and the 6-to-40 are where Ross will probe. Those answers are slots only you can fill, such as how the £4M was counted and what counted as a partner.

Say the word and I'll play Deepa as the Skeptic on C1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the JD text? It would turn the `[generic]` rows into quoted requirements and show whether the posting sets any terms of its own.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, 60-minute panel, Tuesday. First 15 minutes are your own spoken POV on operator partnerships, then Q&A.
**Panel (from the recruiter's email as you quoted it):** Deepa, VP Partnerships, your future manager. Ross, Commercial Director, who "will push on commercials".
**Built on:** your message only. No JD was supplied, no web research was available, and the market report's text was not in front of me. What that removes is listed in Sources and the upgrade menu.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Past behaviour against the company's published values. No row uses it: no values-style round was detected and no values page was read |
| EXP | Whether what you said about your past survives follow-up questions |
| JD | The role's stated requirements, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem, reasoned aloud |

"Answer slot" lines are instructions for the interview itself. They ask nothing of you here. Answer them truthfully on the day, either way.

## Prep triage (about 4 hours over the weekend)

| Order | Time | What | Where |
|---|---|---|---|
| 1 | 70 min | Build the 15-minute POV and say it aloud three times, timed, phone recording | Section: Graded deliverable; A1 |
| 2 | 20 min | Re-skim the market report asking only: what would every candidate cite from it, and what would I do differently | A5; the POV's differentiation row |
| 3 | 40 min | Commercials: talk the structure case aloud twice, then the "how would you want to be measured" answer | B4, B5, A3, A4 |
| 4 | 45 min | Defend-the-number: write notes for yourself on what you know and do not know about how the figures were counted | B1, B2, B3, D2 |
| 5 | 45 min | The highest-ROI rehearsal: the "never sold into rail, never carried a quota" objection, with all three follow-up levels | C1, D1 |
| 6 | 20 min | Your 90-second arc and three reverse questions | E1; Reverse questions |

Everything else is insurance: A2, C2, C3, C4, D3, E2.

## Fit snapshot

No JD was supplied, so requirement rows quote the recruiter's own words as you gave them, and role-family expectations are plain prose labelled `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, quoted in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company, not operator partnerships, and your words stay there: "For four years I ran the ISV channel at a payments company, and took it from 6 partners to 40." Answer slot: the recruiter's POV ask makes a probe on what carries over to operators likely. If any part of how that channel worked carries over, say which and why in your own words; if none does, say so plainly and stay with the channel |
| F2 | "Please land on what it means for the operators themselves." — recruiter's email, quoted in your message | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, not train operating companies, and the words stay at that scope: "Before that I spent five years in transport consulting, on bus and light rail network planning." Answer slot: the recruiter's word "operators" makes a probe on your operator-side knowledge likely. If any of that work touched train operators, say how, in your own words; if it did not, say so plainly and return to bus and light rail |
| F3 | "Ross will push on commercials." — recruiter's email, quoted in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message; "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | medium | [grounded] | transferability | Your material gives a figure with a label on it: roughly £4M of influenced revenue, and no quota. Say it at that scope: "What I've had is roughly £4M of influenced revenue, not a direct quota." Answer slot: the figure raises four probes: how it was counted, what it is sensitive to, which assumption behind it you would defend least, and which part was yours. Answer each in your own words; "I don't know how that was counted" is an honest answer |
| F4 | Role-family expectation, no source: manages a portfolio of partners at senior level | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [generic] | none | No gap, but a line of your own with nothing inspected behind it, so expect a probe. Keep each number on its own noun: 6 partners to 40, and roughly £4M of influenced revenue |
| F5 | Role-family expectation, no source: carries a direct revenue target | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I haven't carried a direct quota." Then how you would want to be measured, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Graded deliverable: the 15-minute POV

The recruiter asked for it, so treat it as graded. The theses below are stances to hold, not facts about Kelverton. Each carries the concession that makes it defensible.

**Grounded facts to build on**

| Fact | Row | Quoted from that row's evidence | Provenance |
|---|---|---|---|
| The ask | F1 | Requirement quote: "present a short POV on where you'd take our operator partnerships over the next 18 months" | [grounded] |
| The close they want | F2 | Requirement quote: "Please land on what it means for the operators themselves." | [grounded] |
| Your channel experience, at its scope | F1 | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | [grounded] |
| Your operator-side knowledge, at its scope | F2 | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | [grounded] |

**Theses (pick two; say each with its concession)**

| # | Thesis (a stance) | Mandatory concession | Provenance |
|---|---|---|---|
| T1 | Go deeper with fewer operators, and make each one a co-owner of a stated outcome, rather than adding more | It slows coverage and deepens dependence on a few relationships, and you cannot judge from outside whether the current portfolio already leans too far that way | [generic] |
| T2 | Agree two or three operator-side outcome measures with each partner before scaling anything, and report partnerships against those first | Operator outcomes are slow and hard to attribute, so the first 18 months may show less revenue than counting partners would | [generic] |
| T3 | Treat third parties that make the operator's day easier as part of the partnership offer, not as a separate channel | It adds integration and relationship overhead, and it only works if operators actually want it, which you would test before committing | [generic] |

**Differentiation.** The report was written by their strategy team, so both panellists know it better than you. Never recite it. Bring one item from it that you expect every prepared candidate to cite, to show you read it. Then give one thesis that departs from it, with your reasons. I could not read the report, so choosing which item is consensus is yours to do.

**The anti-pick (the role includes saying no).** Name one thing you would not do in the first 18 months, for example a category of operator request you would decline to build partnerships around. Concession: it gives up some revenue, and you would say what would change your mind. Choose the item yourself, from your own judgement.

**Suggested 15-minute shape.** 1 min: state aloud how you read "operator partnerships" and invite correction. 2 min: what you would need to learn and what you are assuming. 6 min: two theses with concessions. 2 min: the anti-pick. 3 min: the operator close. 1 min: buffer, and an invitation to push.

**The operator close.** Finish on four beats in plain terms: who at the operator is affected, what changes for them, what they are asked to commit, and how they would know it worked. Operator-side specifics come only from what you actually know. Where you do not know how a particular operator works, say what you would ask instead. Do not narrate your consulting years as evidence of operator practice beyond what F2's quote says.

## Persona table

The loop rests on your own account of it: one session, a panel of two named people, a spoken POV, then Q&A. It is not an archetype fallback.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (Deepa) | Probes and extensions on your POV; live problems on operator partnerships | High. Hiring-manager prior is Case plus Skeptic, and the POV is 15 of 60 minutes, so most Q&A hangs off it | Clarify, then structure aloud, then challenge one premise respectfully. Use the POV's own vocabulary |
| Data-Driven Prober (Ross) | Counting, definitions, attribution on your figures; commercial structure | High. The recruiter named commercials as Ross's push, which moves Prober up from the executive prior | Know what you can and cannot say about how each figure was counted. Say plainly when you do not know |
| Skeptic (Deepa) | Quiet, persistent probing of the missing rail sales and missing quota | Medium to high. Your own message states both negatives, and a future manager prices them first | Rehearse C1 until it is boring. Name the limit before it is asked |
| Pressure (Ross) | Interruptions, time-boxes, "why you" in 60 seconds | Medium. Executive prior includes Pressure, but nothing in the recruiter's email says the panel will be hostile | Pause, restate, hold a position through two follow-ups, concede specifically |
| Conversational / Rapport | Opening "walk me through the journey" | Low to medium. Panels often open this way, and it is still scored | Pre-script a 90-second arc (E1) |

Values/Behavioral and Peer Evaluator are not built: no values-style round was detected, and neither panellist is a peer.

## Question banks

### A. Case / Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Take the floor: where would you take our operator partnerships over the next 18 months, and what does it mean for the operators?" | CASE | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | The build is in the POV section above. Open by saying how you read "operator partnerships" and inviting correction. Hold two theses with concessions, the anti-pick, then the operator close. Any reference to your past stays at the quote's scope: the ISV channel, 6 partners to 40. Answer slot: if a probe asks what from that channel carries over to operators, say what and why in your own words; if nothing does, say so plainly and stay with the channel | This is the pre-declared deliverable, so it is the most certain question in the pack. F1 and F2 are what it leans on. CASE because it is a live problem delivered aloud |
| A2 | "What would you need to know first, and who would you ask in your first 30 days?" | CASE | [generic] | Structure it: what the plan assumes, what would change it, who holds the answers, and what you would do before you had them. The question needs no claim about your past, so the guidance makes none | A clarify-first probe that follows naturally from any POV, and it lets you show structure. `[generic]` because it is a pattern for the problem |
| A3 | "An operator's team likes the plan but says it cannot commit people's time this year. What do you do?" | CASE | [generic] | Structure it: what you would ask them first, what smaller commitment you would offer instead, what you would stop asking for, how you keep the relationship warm, and what you would tell Ross about the commercial effect. No claim about your past | A live problem from the recruiter's "what it means for the operators" ask (F2's requirement), delivered as a decision. CASE because it asks for a path, not a record |
| A4 | "If you could keep only three of our operator partnerships going, how would you choose?" | CASE | [generic] | State your criteria aloud before naming anything, say what data you would want, and say what you would stop. It doubles as your anti-pick rehearsal. You do not know Kelverton's portfolio, so give criteria, never named operators | Tests judgement and the willingness to say no, which the differentiation row asks for. CASE because it is a prioritisation problem |
| A5 | "You've read the market report we sent. Which of its conclusions would you push back on?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Pick the one point you actually disagree with after re-skimming, and give your reason. Answer slot: if there is a conclusion you would challenge, say which and why, in your own words; if there is none, say so plainly and say which one you would test first. Never recite the report back to its authors | They wrote the report, so recitation scores as homework and a reasoned departure scores as judgement. CO because it tests altitude on their strategy. `[grounded]` on your own statement that you read it |

### B. Data-Driven Prober (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You say roughly £4M of influenced revenue. How was that counted?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue."; "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Give it at its own label: roughly £4M of influenced revenue. Answer slot: say how it was counted, what it is most sensitive to, and the assumption behind it you would defend least, each in your own words. If you do not know how it was counted, say so plainly. Do not call it a period you did not state | F3 is where Ross's commercial push lands first. EXP because it tests whether the number survives scrutiny |
| B2 | "Six partners to forty. What counted as a partner at each end?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Your sentence is "took it from 6 partners to 40". Answer slot: say what counted as a partner at each end and which part of that growth was yours, in your own words. If the definition shifted, say so plainly. If you cannot say, say that | A count is as soft as its definition, and a prober goes there next. F1 and F4 carry the figure. EXP because it tests attribution |
| B3 | "You've had influenced revenue and never a direct quota. What changes when you carry one?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Plain acknowledgment first: "I haven't carried a direct quota." Answer slot: if you have seen from close quarters what changes, say what, in your own words; if not, say so plainly and say what you expect to be different and how you would find out | F5's stated gap, probed collegially. EXP because it tests honest self-assessment about your own history |
| B4 | "We bring a train operating company a new scheduling module through a partner. How would you structure the commercials between us, the partner and the operator?" | CASE | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Walk it from first principles: who pays whom for what, what each side risks, what you would want to know before proposing anything, which term you would hold and which you would concede first. Answer slot: if any of the decisions in running that channel were yours, say which and how you decided, in your own words; if none were, or it was not yours, say so plainly and walk the case as a first-principles structure | The recruiter named commercials as the push (F3's requirement). CASE because it is a live commercial problem. Provenance carries the quote because the guidance refers to your channel |
| B5 | "How would you want to be measured in your first year?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Say what you would propose and why, as a plan, and ask what Kelverton uses. Plain acknowledgment if pushed: "I haven't carried a direct quota; what I've had is influenced revenue." You give no figure, because nothing in your material supplies one | A commercial director tests whether you will name a measure. F3 and F5 are the rows this exposes. JD because it scores the role's commercial terms |

### C. Skeptic (high-ROI persona)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't sold into rail and you haven't carried a direct quota. Why you for this role?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue."; "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue."; "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | **The highest-ROI rehearsal in this pack.** Name the limit before it is asked: "I haven't sold into rail specifically and I haven't carried a direct quota." Then hold what the quotes carry: "I ran the ISV channel for four years at a payments company, took it from 6 partners to 40, and before that I spent five years in transport consulting on bus and light rail network planning." Follow-up level 1, "bus and light rail isn't our operators": answer slot, if any of that work touched train operators, say how; if not, say so plainly and return to bus and light rail. Level 2, "influenced revenue isn't yours": concede exactly: "That's right, it was influenced revenue, not a quota," then return to B1's answers. Level 3, "so what is your plan?": say how you would close the gap, as a plan and never as a past. Never add to the quotes | This objection will arrive in some form, because your own message states both negatives. F2 and F3 are the rows it presses on. JD because it scores the role against your gaps |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Choose the weakness yourself, in your own words. The two your own sentence states are rail sales and a direct quota. If you choose another, say so. Then give the ramp as a plan | A standard Skeptic stem that rewards a limit named plainly. F5 is the nearest row. JD because it scores requirement-by-requirement fit |
| C3 | "Why leave payments for rail-tech, and why now?" | EXP | [generic] | Give your actual reason in your own words. Your material states none, so the pack supplies none. If a reason connects to the operator world in your consulting years, F2's sentence is the only quoted bridge, and it is only usable if it is true | Motivation consistency is a Skeptic standard. EXP because it tests whether your story holds across your own history. `[generic]` because it is a stem, not a claim about you |
| C4 | "You ran a payments ISV channel; our partners are operators. What would you leave behind?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: name one thing from how that channel worked that you would not carry over to operators, in your own words. If nothing comes to mind, say so plainly, and say what you would test first. Name the limit before they do | Candour about what does not transfer is the F1 limit, said first. JD because it scores fit and its edges |

### D. Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has sold into train operators?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue."; "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue."; "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Pause, restate. Three beats: the limit ("I haven't sold into rail specifically"), what the quotes carry (the channel, the bus and light rail planning), what you would do first, as a plan. Hold through two follow-ups, concede specifically, never fold the core | A time-boxed version of C1. F2 and F5 are the rows. JD because it scores fit against a named alternative |
| D2 | "How much of that £4M was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Hold your sentence: roughly £4M of influenced revenue. Answer slot: say which part was yours and which was not, in your own words; if you cannot split it, say so plainly. Concede the uncertainty specifically, not the whole claim | The standard Pressure stem. F3 carries the figure. EXP because it tests attribution |
| D3 | "I'll stop you there. What's the commercial case for this plan, and what do we get back in 18 months?" | CASE | [generic] | Hold your thesis. Say which numbers you would need and who holds them, name one risk, and concede that you cannot size it from outside. Do not invent a figure | Ross's push, delivered mid-POV. CASE because it asks for reasoning under interruption. `[generic]` because it makes no claim about your past |

### E. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue."; "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | A 90-second arc with only the beats your sentences carry: five years in transport consulting on bus and light rail network planning, nine years in partnerships, the last four running an ISV channel at a payments company. Keep the order you gave. Answer slot: the last link, why this role, is your own reason in your own words | A casual opener, still scored. F1 and F2 are the arc's only material |
| E2 | "What are you following in rail scheduling these days?" | CO | [generic] | Answer from what you actually follow. If it is little, say so plainly and name the one thing you would read next. Nothing from your material supports a claim here | A casual question on a hot topic. `[generic]` because it carries no claim about you or about Kelverton |

### Requirement coverage

| Requirement | Questions |
|---|---|
| POV on operator partnerships over 18 months (F1) | A1, A2, A3, A4, A5, D3 |
| Land on what it means for the operators (F2) | A1, A3, C4, E1 |
| Ross will push on commercials (F3) | B1, B2, B3, B4, B5, D2, D3 |
| Portfolio of partners at senior level, role-family (F4) | B2, E1 |
| Direct revenue target, role-family (F5) | B3, B5, C1, C2, D1 |
| Requirements from a JD | none, and why: no JD was supplied |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "If I did this job well, what would be different about operator partnerships 18 months from now?" | Turns your POV into their success measure and shows you think in outcomes |
| R2 | "How are operator partnerships measured today, and where would this role sit against that?" | Gets Ross's commercial expectations on the table before an offer |
| R3 | "Which operator relationship would you most want a new person to understand first, and why?" | Shows you start with the operators, which is the close the recruiter asked for |
| R4 | "What has changed since the strategy team's report went round last quarter?" | Shows you read it and invites their correction. Ask only if you mean it |
| R5 | "Where does this role end and the commercial team's work begin?" | Probes the seam with Ross directly and shows you are thinking about the working boundary |
| R6 | "What would a good first 90 days look like to each of you, and would your answers differ?" | Surfaces any disagreement between future manager and commercial director before you join |

## Prohibited claims

Built from your own sentences before any question was written. Each is a claim this pack will not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Negative you stated, F5 | The quote at its scope: "Never sold into rail specifically and never carried a direct quota, only influenced revenue." Plain acknowledgment: "I haven't sold into rail specifically." No slot |
| Has carried a quota | Negative you stated, F5 | Plain acknowledgment: "I haven't carried a direct quota." What you have is influenced revenue. No slot |
| Owned, closed or generated the £4M | Inflated form of F3 | The quote at its own scope: roughly £4M of influenced revenue. The limit is the pack's observation: the material says influenced revenue, with no period or counting method stated. B1 and D2 stay inside that |
| Personally brought in the partners that took the channel from 6 to 40 | Inflated form of F1 | F1's quote at its own scope: "took it from 6 partners to 40". The limit is the pack's observation: the material does not say which partners you brought in. B2's slot asks only what counted as a partner |
| Knows train operating companies from the inside | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning. The limit is the pack's observation: the material says bus and light rail, not train operating companies |
| Set the commercial terms with partners | Inflated form of F1 | F1's quote at its own scope: running the ISV channel. The limit is the pack's observation: the material says running a channel, not what was decided inside it. B4's slot stays inside the channel's scope |

## Sources

**Provided documents:** your message (your background, the recruiter's email as you quoted it, your note that you have read the market report). The market report itself was attached to the recruiter's email, but its text was not in front of me. Nothing in this pack draws on its content.

**Searches sent, all refused (permission to search was not granted; none returned anything):**

1. `Kelverton Rail values` — refused
2. `Kelverton Rail interview process partnerships` — refused
3. `Kelverton Rail strategy news scheduling software train operating companies` — refused
4. `Deepa VP Partnerships Kelverton Rail` — refused
5. `Senior Partnerships Manager rail technology job description train operating companies` — refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Would have fed a values cheat sheet. None was built, and no values-style round was detected from your account of the loop anyway |
| 2. `Kelverton Rail interview process partnerships` | unavailable | Would have confirmed the loop. Persona weights rest on your own account of the panel, not on a documented process |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Would have fed a grounding brief and a current-strategy CO question. A5 and D3 are built without it. The report you hold would have covered this, but its text was not in front of me |
| 4. `Deepa VP Partnerships Kelverton Rail` | unavailable | Would have fed an interviewer read and a reverse question tied to Deepa's path. Both are absent. Ross's name was not searched |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Would have given a fetched JD to quote for requirement rows. Rows rest on the recruiter's words and on `[generic]` role-family expectations |

## Upgrade menu

- The JD text → F4 and F5 become `[grounded]` instead of `[generic]`, JD-tagged questions get a raising source, and any term in the posting (location, pay, schedule) surfaces as its own row
- The market report's text, pasted → A5 and the POV's differentiation row can name which items are the consensus and where a departure would be safest
- Permission to search → values, loop structure, recent strategy news, and public professional footprint for Deepa and Ross, which would add a grounding brief, an interviewer read, and a reverse question tied to Deepa's own path
- A deeper research pass, offered once → up to 6 more searches and 2 more fetches, several more minutes, covering a strategy brief, the interviewers' talks and writing, loop reports for this role family, and recent org context. It needs search permission
- A partner programme report or attribution summary showing how the figures were counted and how a partner was defined → F1 and F3 move from medium to high, and B1 and B2 become story-mapped instead of slots
- Your own answers to the answer slots (F1, F2, F3) → quoted into the fit snapshot, and the rows and questions that draw on them regenerate
- One email to the recruiter asking whether the report carries the conclusions they expect you to react to, and whether Ross has said anything about the commercial topics → coverage of what the panel plans to probe
- A `tuesday-dossier.md`, if you hold one from earlier work → verified evidence and a named objection would replace the inferred ones here
