I'll read the skill's reference files before building the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/alone/part-2/rooms/case-3-denied-c779b4ac/stripe_product-operations-manager_interview_pack.md`. I built it from the company, the role and "final round" alone, with flat persona weights. I had no CV, no job description and no interviewer details. Web search was refused, so the pack has nothing about Stripe's values, interview loop or strategy, and the Stripe-specific question (A5) is generic.

It has 21 questions across seven interviewer styles. I've named B1 ("Why product operations, why Stripe, why now?") as the prep that pays off most. The guidance throughout is selection scaffolds, because I have no experience of yours to map them to.

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting in this final round: your future manager, a peer, a skip-level leader, or several sessions back to back? That answer reweights every bank, and the recruiter's guidance on focus areas or any pre-set deliverable would sharpen it further.
Can you paste your CV and the job description? I'll proceed without them if you'd rather, but those two are what turn the scaffolds into answers built on your real experience.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

**Round:** final round. **Interviewer(s):** not given. **Relationship:** not given. **Built on:** the company, the role and the round type, nothing else. No CV, no JD, no recruiter guidance and no research results went into it, so every row is `[generic]` and every answer is a scaffold you fill from your own experience.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: every answer slot and scaffold below ends with an honest branch, and you say only what you actually did, in your own words.

| Type | Meaning |
|---|---|
| VAL | Behavioral and values alignment: does past behavior show the company's published values |
| EXP | Work-experience deep-dive: do your claims survive scrutiny, and what was actually yours |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge: homework depth and altitude |
| CASE | Live problem from the role: structure and reasoning |

## Fit snapshot

This is the worksheet variant. With no CV in hand, every evidence cell reads `none given`. With no JD, no recruiter words and no fetched posting, the requirements are role-family areas written as plain prose, not quotes, and they raise no answer slot. Send a CV and a JD and these rows become real.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run a recurring operating rhythm and launch coordination across product teams (role-family area, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a rhythm or launch process you personally ran, with its cadence and who attended. Selection scaffold: pick one you can describe from start to finish, naming what you ran and what was someone else's. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Define, track and act on product or business metrics (role-family area, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a metric you reported or acted on, with how it was counted and what decision followed. Selection scaffold: pick one metric you can explain end to end, including the assumption you would defend least. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Build or improve processes and tools that product teams use (role-family area, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a process or tool you built or changed, who used it, and what you saw change afterwards. Selection scaffold: pick one where your part is clear and separable from the team's. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Influence across product, engineering, design, go-to-market and leadership without formal authority (role-family area, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a disagreement or alignment effort with named functions, your move in it, and how the relationship stood afterwards. Selection scaffold: pick one where you disagreed and it was resolved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Structure ambiguous problems and prioritize (role-family area, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a problem you were handed without a clear shape, how you framed it, and what you chose not to do. Selection scaffold: pick one where you can state the options you rejected. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 operating rhythm and launches | A1, A3, C1 |
| F2 metrics | A4, E1, E2 |
| F3 process and tools | A3, D3, G2 |
| F4 cross-functional influence | A2, C1, C2, C3, D1, D2 |
| F5 ambiguity and prioritization | A1, A2, A4, B2, D3 |

No stated JD requirement exists to map, so this table covers the five role-family areas above. Every one has at least one question.

## Persona table

No loop source was read, so the weights rest on the Generic archetype (screen, hiring manager, panel, flat weights), not on Stripe's documented process. Your recruiter can confirm the real shape in one email.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems on product launches, priorities, metrics | Highest (5 questions). A final round for an operations role is where a live problem is most likely, and the relationship is unknown, so the hiring-manager prior stays on | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| B. Skeptic | Probing why this role, why now, and the weakest area | High (4). Any final round tests motivation consistency, and with no CV the biggest gap is not yet visible | Rehearse the motivation answer until it is boring. Name a real day-one gap with a ramp plan |
| C. Peer Evaluator | Seam between product ops and adjacent teams, credit, collaboration | Medium (3). A final round often includes a peer, though nothing here confirms it | Offer seam principles rather than pretending to know the seam. Lead with what you bring them |
| D. Values / Behavioral | Scenario probes on judgment and candor | Medium (3). No loop source names a values round, so none is assumed, and the stems still appear in any final | Pick stories where the hard truth landed. Where none exists, say so |
| E. Data-Driven Prober | Counting method and assumptions behind any number you cite | Low (2). Needs numbers from your CV to bite | Know how each figure was counted and say plainly when you do not |
| F. Pressure | Time-boxed challenges to your motives and your share of results | Low (2). Composure test, possible at any final | Pause, restate, hold through two follow-ups, concede specifically |
| G. Conversational | Friendly opener and open interest questions | Low (2). Likely as the opener, and still scored | Prepare a 90-second arc. Never answer "I think you've covered everything" |

## Question banks

**Highest-ROI prep: B1.** In a final round, "why product operations, why here, why now" is the question most likely to arrive in some form. With no CV, this is inferred from the round type, so it will be replaced by your sharpest real gap once you share your background.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch went out three weeks ago and support tickets about it keep climbing. What do you need to know first?" | CASE | [generic] | Clarify before structuring: what changed, who is affected, since when. Then objective, segments of tickets, hypotheses, the data you would pull, who you would involve, and the risks of acting too early. Say the framework aloud, think aloud, and challenge one premise respectfully. The question asks about no past, so the guidance makes no claim about yours | Tests clarify-then-structure on a problem from the role-family area F1 and F5. CASE because it is a live problem |
| A2 | "Product, engineering and sales each name a different top priority for the quarter. How do you get to one shared view?" | CASE | [generic] | Clarify the decision that needs making and who owns it. Surface each function's goal and constraint, find the shared metric or trade-off, propose a forum and a decision rule, and say what you would escalate and when. Keep it to principles, since you do not yet know their org | F4 and F5 are the role-family areas this probes. CASE because the problem is hypothetical and set in the role |
| A3 | "Design an operating rhythm for a product org with several teams: what goes in it and what do you cut?" | CASE | [generic] | Start with who needs to decide or know what, and how often. Propose a small set of recurring forums or documents, name the signal each one carries, and say what you would remove to make room. Close with how you would tell whether it is working | F1 and F3 meet here. CASE because it asks for a design, not a diagnosis |
| A4 | "A key adoption metric dropped 20% week on week. Diagnose it." | CASE | [generic] | First check the data: definition, instrumentation, seasonality, a one-off event. Then segment by customer, product area, geography and channel, and look for a launch, outage or policy change. State your leading hypothesis early and say what would disprove it. Close with the owner and the next 48 hours | The persona stem for this type, mapped to F2. CASE because it scores the order of reasoning |
| A5 | "In two sentences, what does Stripe do and for whom, and where does a product operations function add the most value there?" | CO | [generic] | The pack holds no verified facts about Stripe, because research did not run. Build your two sentences from your own reading of the company's site and recent announcements, and tie the second sentence to a role-family area from F1 to F4. If you have not formed a view yet, say that plainly and describe how you would find out in your first month | A differentiator question that most candidates under-prepare. CO because it tests homework at the company's altitude. Generic until research runs |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why product operations, why Stripe, and why now?" | EXP | [generic] | Selection scaffold: three beats, each from your real history and real reasons. Why this function, why this company, and why this moment in your career. Each beat needs a specific you can defend under a follow-up. If one beat is thin, say so plainly, then say what is true about it, or how you would handle it | The motivation probe is the most predictable objection for any candidate, so it gets the deepest rehearsal: say it aloud five times and cut every clause you would not repeat under a follow-up. EXP because it tests whether your story survives cross-examination |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Choose a real gap, not a strength in disguise. Say it in one sentence, then give a concrete first-thirty-days plan, said as a plan and never as a past. Hold your position through one follow-up and concede only what is true. If nothing comes to mind quickly, say so plainly, then name the area you would verify first | The persona stem. JD because it scores honest self-assessment against the role |
| B3 | "What would make you decide this role is not right for you six months in?" | JD | [generic] | A forward-looking answer, so no claim about the past. Name two or three conditions that would genuinely matter to you, and one you would first try to fix before leaving. Keep it honest and specific | Tests whether your expectations are realistic. JD because it probes role fit |
| B4 | "Which part of this role is furthest from what you do today, and how would you close the distance?" | EXP | [generic] | Selection scaffold: name the part honestly, then the nearest thing your material does carry, in its real scope, then a learning plan. If no part is far from your current work, say so plainly, then say which part you would still verify | Probes F1 to F5 for the gap the pack cannot yet see. EXP because the honest answer depends on your history |

### C. Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where is the seam between product ops and product management, and what happens when we disagree?" | JD | [generic] | Offer seam principles rather than a map you cannot know yet: who decides what, who owns the process versus the product call, how a disagreement is escalated. Then say what you would ask in week one to find the actual seam | The persona stem, aimed at F1 and F4. JD because it tests role understanding |
| C2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work crossed teams, say what you did and what others did, and say how credit was shared. "We" for context, "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for F4. VAL because it scores collaboration behavior |
| C3 | "What would you need from me in your first month, and what could you give back?" | JD | [generic] | Reciprocity first: what you would bring that eases their work, then two or three concrete asks. Avoid a long list of needs | Peers price the load a new hire adds. JD because it tests partnership fit |

### D. Values / Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, what you said, how it was received, and where the relationship stood afterwards. Pick a story where the truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for F4. VAL because it scores candor |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: the metric, the customer need, the call you made, the cost, and what you learned. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem. VAL because it tests judgment on trade-offs |
| D3 | "Everything is labeled urgent. How do you decide what not to do?" | CASE | [generic] | A method, not a past: define impact and reversibility, check with the owners, make the trade-off visible, and say what you would drop and tell people. Challenge the premise that all of it is urgent | F5 is the target. CASE because it is hypothetical |

### E. Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick a number you have reported on in a past role and walk me through how it was counted." | EXP | [generic] | Selection scaffold: choose a number you can explain from source to slide. Say the definition, the data source and what it excludes. If you do not know how part of it was counted, say that plainly | Persona stem for F2. EXP because it tests attribution |
| E2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name the weakest assumption before the interviewer does, in your own words, and what you would check. If you cannot name one, say so plainly, and say how you would find out | Converts a gotcha into credibility. EXP because it tests self-awareness |

### F. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | EXP | [generic] | Pause, restate the question, then give one or two reasons you can stand behind, without disparaging anyone. Hold through two follow-ups and concede specifically what you do not know about the team | Persona stem. EXP because it tests composure and self-assessment |
| F2 | "Think of the achievement you lead with. How much of it was actually you?" | EXP | [generic] | Selection scaffold: separate your part from the team's in plain words. Hold your claim through two follow-ups and concede the parts that were not yours. If nothing you lead with has a clean split, say so plainly, then describe the part you can stand behind | Persona stem. EXP because it probes attribution honesty |

### G. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, one or two turning points in your own words, why product operations, and why this company now. End on the present, not the past | Opener, still scored for economy. EXP because it surfaces your story |
| G2 | "What have you been trying lately to make product teams run better?" | JD | [generic] | Selection scaffold: one small thing you tried or read, what you took from it, and what you would test next. If nothing comes to mind, say so plainly, then describe what you would want to try first | A casual question on F3 that is still scored. JD because it tests interest in the craft |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What is the problem you most need a product operations hire to solve in the first six months?" | Shows you think in outcomes and gives you the real scope of the role |
| R2 | "How do you tell, a year in, whether product operations is working here?" | Surfaces the success measure and signals you think in metrics |
| R3 | "Where does product operations end and product management, program management or business operations begin on this team?" | Tests the seam you were asked about, from your side |
| R4 | "What has changed about how product teams work here in the last year, and what has not worked?" | Invites candor and shows you want the real picture |
| R5 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question. Strongest if your interviewer is a peer |
| R6 | "What would you want me to have understood about this role that the job description does not say?" | Gives a final-round interviewer room to name their own concern |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Nothing listed | You have shared no material, so there is no sentence of yours to inflate and no negative you stated | Every scaffold and slot above ends in an honest branch. Share a CV and entries appear, each with the sentence that limits it |

## Sources

Provided documents: none. Your message gave the company, the role and the round type.

Searches sent, all refused, none returned a result:

- "Stripe operating principles values" — refused
- "Stripe interview process product operations manager" — refused
- "Stripe strategy news 2026" — refused
- "Stripe Product Operations Manager job description" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have fed a values cheat sheet and VAL questions by Stripe's own names. None of Stripe's principles appear here because none were read |
| 2. Stripe interview process, product operations | unavailable | Would have set persona weights from documented rounds. Weights rest on the Generic archetype instead |
| 3. Stripe strategy and recent news | unavailable | Would have grounded A5 and a grounding brief in current priorities. A5 is generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Would have turned the five role-family rows into inferred, quoted requirements |

## Upgrade menu

- The job description text → the five role-family rows become quoted, grounded requirements, and every JD question gets a real raising source
- Your CV, or the work you want to lead with → the evidence column fills, scaffolds become story maps, and B1 and B2 are rebuilt around your actual gap
- The interviewer's name and role → an interviewer read, reweighted personas and a reverse question tied to their path
- The recruiter's guidance on the loop, focus areas or any pre-set deliverable → real persona weights and, if a deliverable exists, a build section for it
- If your final is several sessions, the schedule → per-session mini-packs
- Permission to run web searches → Stripe's published values, loop structure and current strategy, so A5 and a values sheet stop being generic. A deeper pass would add up to 6 more searches and 2 more fetches, several more minutes
- Prep time available → a prioritized schedule sized to it
- A `tuesday-dossier.md`, if you have one → verified evidence and pre-set gap strategies in place of the inferred ones
