I'll read the skill's reference files before building the pack.
The pack is built and saved. I'm sending the closing message now.

Your prep pack is saved as `northwind-data_senior-gtm-strategy-lead_interview_pack.md`, in the working directory. I built it for one 60-minute peer conversation with Dan. It has 21 questions across six personas, each with answer guidance, a rationale and a type tag, plus a fit snapshot, a persona table with the weighting reasoning, reverse questions and a prohibited-claims list.

The three web searches I tried (Northwind's values, Dan's public footprint, a check on your research note) were refused in this session. The pack rests only on what you gave me, and the Sources section shows what each missing search would have changed.

I can play Dan live on D1, the question the pack names as the highest-ROI prep. D1 is the "no classic sales-ops or quota-setting experience" objection, and I'd follow it with A1, the $400M figure.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya (name as given by the coach). **Interviewer:** Dan Kovac, Director of Sales Strategy — a **peer** (both report to the same VP). **Format:** one 60-minute conversation with Dan. **Built on:** the coach's notes, the JD highlights and the research note supplied in this conversation. Web searches were refused in this session, so nothing here rests on fetched pages (see Sources).

## How to use this pack

Personas describe **how** a question is asked. Types describe **what is being scored**. Guidance is scaffolding, not a script: say it in your own words, and say only what you did. An **answer slot** is an instruction for the interview itself: it tells you what to say if you did the thing, and what to say plainly if you did not.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether the claims on the CV survive scrutiny, including who actually did what |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at Northwind's altitude: strategy, competition, priorities |
| CASE | Structure and reasoning on a live problem from the role |

A question that straddles two types carries one tag in its cell, and the rationale says what the other flavor is.

**Highest-ROI prep in this pack: D1.** It is the single most predictable objection to this candidate, so it gets the deepest rehearsal (three follow-up levels and exact concession wording). **Second:** A1, the headline figure, which a self-described data-driven peer will test.

## Fit snapshot

The JD requirements below are the "JD highlights" you supplied, quoted as supplied. Evidence is the coach's notes, quoted exactly. Gap type and confidence use the suite's vocabulary.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy & ops at a large consumer-tech company, not go-to-market strategy, with nothing inspected behind it, and the words stay there: "For nine years I worked in product strategy & ops at a large consumer-tech company." Answer slot: the JD's line on go-to-market strategy makes a probe on your part in how products reached customers likely. If any decision about that was yours to make, say which and how you decided, in your own words; if there was no such decision, or it was not yours, say so plainly and describe the product strategy and ops work you did |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The quote carries a proposal and a credit, not which stage of a customer relationship it acted on and not how the opportunity was found, and the words stay at that scope: "I proposed a store-surface change that was credited with an uplift of about $400M in ARR." Answer slot: the JD's four-stage line makes a probe on which stage your change touched likely. If it touched one, say which, in your own words; if it did not map to a stage, say so plainly and stay with the proposal. The figure itself raises the four slots in A1 |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | discovery | The quote names the tools and does not show what work sat behind it. Words: "I'm skilled in SQL and Tableau." Answer slot: expect a probe on a specific piece of work. If there is one where you used either tool yourself, say what question it answered and what you did, in your own words; if there is none to point to, say so plainly and stay with the two tools |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The quote carries a model that was built and used in negotiations, not the terms or structure of any partner arrangement. Words at that scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's partner-motion line makes a probe on your part in how partners were dealt with likely. If any decision there was yours, say which and how you decided; if the model informed the negotiations and the decisions were not yours, or there were none, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on the consensus. Lead with it in the quote's own terms — you set annual volume targets, with cross-org consensus — because a named record beats an adjective |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the plus in other terms: use, not building. Words: "I use AI tools daily." The pack observes that the material does not say which tools or for what, and that the research note's Compass launch makes a probe likely. Answer slot: name which tools and what you use them for, in your own words; if it is a narrower set than that, say so plainly |
| F7 | "own GTM strategy for two new product lines" — JD highlights | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and the note states it. The JD line does not itself name sales ops or quotas; that the interviewer will test this edge is the pack's inference from his title. Words: "I haven't had classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

No JD highlight is a term-type gate (authorization, location, schedule, pay, travel, credential), so no `hard_gate` row exists. The full JD may change that; see the upgrade menu.

## Reading the interviewer

Public-profile signals only, as you supplied them. Nothing here is inferred about Dan's personality.

| Signal (as given) | Provenance of signal | Implication for this round | Provenance of implication |
|---|---|---|---|
| Self-describes as "relentlessly data-driven" | [grounded] — research note | Every figure you give will be probed to its assumptions. Name the assumption you would defend least before he asks, and say plainly when you do not know how something was counted | [generic] |
| Career spine is pricing and monetization roles | [grounded] — research note | Cases tilt toward packaging, pricing and unit economics. Expect him to know that ground better than you, so concede it calmly and reason from first principles | [generic] |
| One early-stage-startup chapter | [grounded] — research note | Builder stories can land well with this kind of background, and a large-company-pace probe is plausible. Candid, scrappy framing of how you work beats polish | [generic] |
| Director of Sales Strategy; peer; same VP | [grounded] — research note | He is pricing what you cost and contribute to his own work. Frame what you bring his team, and propose seam principles rather than pretending to know the seam | [generic] |

**Mirror opportunity:** his pricing and monetization spine and F4's quote, "built a partner-level revenue model used in carrier negotiations", share revenue-economics vocabulary. The limit stays visible: the quote says a revenue model, not pricing work, and you should not call it that. His startup chapter is not offered as a shared jump, because no fit-snapshot row carries your side of one.

## Persona table

Weights are a shown judgment from three passes. Relationship prior (peer): Peer Evaluator plus Data-Driven Prober. Interviewer signals (table above): the "data-driven" line pushes Prober up, and the pricing spine tilts the cases. Loop: your own words establish one 60-minute conversation with Dan, so no archetype fallback is used and no values-style round is detected. Recalibrate if you know something this pack does not.

| Persona | How it shows up with Dan | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (bank A, 5) | Line-by-line probes of figures and models; follow-ups two levels deep | Highest. Peer prior plus the self-described data-driven signal, and F2 carries a headline figure | Know what you can and cannot say about how each number was counted; name the weakest assumption first (A1, A3, A5) |
| Peer Evaluator (bank B, 5) | Seam-splitting, credit, "what do you need from me" | Highest. This is the peer prior, and the shared VP makes the seam real | Reciprocity framing, seam principles, a disagreement style that shows spine and tact (B1 to B5) |
| Case / Strategist (bank C, 4) | Live problems on whitespace, bundling, Compass packaging | High. Pricing spine tilts cases to packaging and economics, and the JD asks you to own strategy for new lines | Clarify, objective, segmentation, approach, metrics, risks; challenge one premise per case (C1 to C4) |
| Skeptic (bank D, 3) | Quiet probing of the sales-ops edge, partner-motion fit and consumer-to-B2B jump | Medium-high. F7 is a stated gap, and even a peer will probe it. Contains the highest-ROI item | Rehearse D1 until it is boring; bridge only from stated evidence |
| Conversational (bank E, 2) | The "walk me through the journey" opener; AI asked casually | Medium. Casual-register questions are still scored, and the AI plus is a JD line | A short arc built from your stated beats; treat the AI chat as scored (E1, E2) |
| Pressure (bank P, 2) | Time-boxed "why you" and "how much was actually you" | Lower. A peer rarely interrupts, but attribution questions arrive in this register | Pause, restate, hold through two follow-ups, concede specifically (P1, P2) |
| Values / Behavioral (no bank) | Not expected | Low. No values-style round was detected, and Northwind's published values were not obtained | Covered indirectly by B2 and B4 |

## Question banks

Provenance carries the candidate sentences each guidance cell rests on. A label alone means the guidance makes no claim about your past. Company facts marked "research note" come from the research note you supplied; their currency was not independently checked.

### Bank A — Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've said a store-surface change you proposed was credited with about $400M in ARR uplift. Walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open at the quote's scope, in your own words: you proposed the change, and it was credited with the uplift. Then the four slots a figure raises. How it was counted: if you know, say how; if you do not know, say so plainly. What it is sensitive to: name it if you know it. The assumption you would defend least: name it before Dan does. Which part was yours: say what you did, and if others built, shipped or measured parts of it, say so plainly. Never explain a method you could not repeat under a second question | F2 carries the pack's headline figure, and a self-described data-driven peer is the likeliest person to test it. EXP because it scores counting and attribution rather than the role |
| A2 | "You'd run your own analysis in SQL and Tableau here. Tell me about a piece of analysis you ran yourself." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold: pick one piece of work where you used SQL or Tableau yourself. It needs the question it answered, what you looked at, what you concluded, and what you did with it, all in your own words. If no such piece comes to mind, say so plainly, then say how you would approach the kind of question the JD describes, or stay with "I'm skilled in SQL and Tableau" and no further | F3 is a bare skills line against a JD line that asks for independent analysis. JD because it scores that stated requirement; the Prober frame turns a claim into a demonstration |
| A3 | "Walk me through the revenue model you built for the carrier negotiations. Which assumption in it would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say what the quote says: you built a partner-level revenue model, and it was used in carrier negotiations. Name in your own words the assumption you would defend least, before Dan asks; if you do not know how a given input was set, say so plainly. Answer slot: say which part of the model was yours; if others contributed, or you do not know who else touched it, say so plainly and stay with the model you built. Describe it as the quote does, a revenue model | F4's model is the other concrete artifact Dan can probe, and the weakest-assumption move converts a gotcha into credibility. EXP because it scores what was actually yours |
| A4 | "Compass is launching. If you owned its adoption numbers, which metrics would you pull first, and which would you trust least?" | CASE | [grounded] research note: "an AI copilot launch ('Compass')" | Clarify first: what counts as adoption for a data-infrastructure buyer, who the user is versus who buys, and what Compass is sold alongside. Then structure: objective, the stages the JD names (land, adopt, expand, renew), one metric per stage, the cuts you would want. Name the metric you would trust least and why, which is the weakest-assumption move applied to a case. Challenge one premise respectfully, for example whether adoption is the stage to optimize first. Think aloud; the answer makes no claim about your past | Compass is one of three stated priorities in the research note, and the JD's stage language makes adoption a natural live problem. CASE with CO content; it also lets the Prober style score metric judgment without needing a past |
| A5 | "Walk me through how those annual volume targets were set. What did the target rest on, and where was it softest?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Say what the quote carries: you set annual volume targets, and it was with cross-org consensus. Answer slot: if you know what the target rested on, say so in your own words and name the softest input; if you do not know, or the basis was set by someone else, or there was no single basis, say so plainly and stay with the targets and the consensus. Keep to the word "targets"; see D1 on why | F5 is the evidence for cross-functional influence, and a data-driven peer will go one level below it. EXP because it scores what the candidate actually did in setting the targets |

### Bank B — Peer Evaluator (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between Sales Strategy and Emerging Products GTM, and what happens when we disagree?" | CASE | [generic] | Do not pretend to know the seam. Ask how it works today, then propose principles: whoever carries a number has the say on it, the other side gets a standing input before it changes, and disagreements go to shared data first and to the VP together second. Offer to write the principles down with him in the first weeks. The answer makes no claim about your past | The peer prior puts the seam question first, and the shared VP makes it real. CASE because it is a live collaboration problem, not a past event |
| B2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "set annual volume targets with cross-org consensus" | The story has the beats the quote states: you set annual volume targets, with cross-org consensus. Use "we" for context and "I" for what you did. Answer slot: expect a probe on whether credit was contested. If it was, say what happened and which part was yours; if it was not, say so plainly and stay with the targets. A5 and A1 hold the figure-related credit slots | The persona stem is a credit probe, and the JD's cross-functional line makes it scored. VAL because it tests collaboration behavior, though no values round was detected, so no published value is cited |
| B3 | "What would you need from my team in your first 90 days, and what would you bring to it?" | JD | [generic] | Lead with what you would offer, then what you need, as plans in the future tense. Offer: an early, shared look at the whitespace analysis before it reaches the VP. Need: how the segments and plays are currently defined, and data access. Ask him what he would add. The answer makes no claim about your past | The reciprocity question for a peer round: he is pricing what the hire adds to his load. JD because the role is defined by cross-team partnership |
| B4 | "The JD asks for strong cross-functional influence. Tell me about a time you moved a team that didn't report to you." | VAL | [grounded] "set annual volume targets with cross-org consensus" | Selection scaffold: pick a time you moved a team you had no authority over. It needs a named stake, a moment of real disagreement, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is the annual volume targets set with cross-org consensus, at that scope, or say how you would handle it | The JD line raises the theme, and the quote is the nearest evidence, so the honest branch is rehearsed. VAL because it tests behavior with equals, not a company value |
| B5 | "I'll probably pick apart your whitespace numbers in front of the VP. How should we handle that?" | CASE | [generic] | Welcome it, and propose a norm: share assumptions and the data cut before any review, label how confident each number is, and agree that challenge is on the number, not the person. Offer to do the same to his. Do not get defensive, and do not agree to everything. The answer makes no claim about your past | His profile's "relentlessly data-driven" line makes this collegial warning plausible. CASE because it is a live working-relationship problem; the peer lens scores disagreement style |

### Bank C — Case / Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Take either of the two new product lines. How would you find the whitespace across land, adopt, expand and renew, and what do you need to know first?" | CASE | [grounded] JD highlights: "identify whitespace across land/adopt/expand/renew" | Clarify before structuring: which line, which accounts, what the product is sold alongside, whether enterprise expansion (a stated priority in the research note) is the lens. Then objective, segments, one question per stage, the data you would pull, the risks. Say which stage you would look at first and why. Think aloud, state your hypothesis early, challenge one premise. The answer makes no claim about your past | This is the JD's core mandate as a live problem, and F2 is the thin spot. CASE because it scores structure and clarification; JD content |
| C2 | "A much larger platform vendor is bundling something that overlaps one of our lines. Where do you point GTM, and what would you not do?" | CASE | [grounded] research note: "main competitive threat is bundling by a much larger platform vendor" | Clarify what is bundled and in which accounts. Segment accounts by exposure. Then give options and choose, and give one anti-pick: something you would say no to, with the reason. Do not recite the obvious consensus answer; bring one point of view that departs from it, with reasons. Name the data that would change your mind. The answer makes no claim about your past | The research note names bundling as the main competitive threat, so a CO-grounded case is likely. CASE because the delivery is a live decision; the anti-pick scores judgment |
| C3 | "Compass launches as an AI copilot. Would you package it as an add-on, bundle it, or price it on usage? What would change your mind?" | CASE | [grounded] research note: "an AI copilot launch ('Compass')" | Do not pick too early. Clarify the buyer and what it costs to serve. Lay out the trade-offs of each option, then state a leaning and the evidence that would flip it. Say openly that his pricing and monetization background gives him the stronger instinct here and invite his challenge. Hold your leaning through one challenge, then concede what is fair. Propose a test. The answer makes no claim about your past | His pricing spine makes packaging his native language, and Compass is a stated priority. CASE because it is an open design problem. Calibrated candor beats bluffing a competency he owns |
| C4 | "Enterprise expansion, Compass and profitability are the three priorities. Where do they pull against each other for a new product line?" | CO | [grounded] research note: three stated priorities | Show the tension rather than reciting the list: expansion pulls toward investment and discounts, profitability pulls toward restraint, and Compass competes for the same attention. Say where you would put the new lines and what you would stop doing to protect margin. Say what you would want to check with him, since you are working from a research note rather than the inside. Currency of the priorities was not independently verified | The one CO question grounded in Northwind's stated priorities. CO because it tests altitude and homework; a bundle of priorities gives the interviewer a tension to probe |

### Bank D — Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see classic sales ops or quota setting in your background. How would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "built a partner-level revenue model used in carrier negotiations" and "set annual volume targets with cross-org consensus" | **Highest-ROI rehearsal.** State the limit first, in plain words: "I haven't had classic sales-ops or quota-setting experience." Then hold only what the quotes carry: you built a partner-level revenue model used in carrier negotiations, and you set annual volume targets with cross-org consensus. Follow-up 1, likely "isn't a volume target just a quota": describe what you did at the quote's scope and do not rename it; if you do not know how the two compare in a sales organization, say so plainly. Follow-up 2, likely "what would you do in the first 30 days": give your own future-tense plan for learning how it works here, asking him to walk you through it. Follow-up 3, likely "and if the VP asked you to set a quota next quarter": hold, then concede in these words: the limit is real, and you would rather learn it from the people who run it than around them. Never present learning as past work | F7 is the gap the notes state, and the interviewer's title sits next to it. This is the most predictable objection, so it gets the deepest rehearsal. JD because it scores the GTM-ownership line; it arrives in a Skeptic register |
| D2 | "Partner-motion design is a requirement for this role. Where does your experience sit relative to that?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say what the quote carries: you built a partner-level revenue model, and it was used in carrier negotiations. Answer slot: if any decision about how those partners were dealt with was yours, say which and how you decided, in your own words; if the model informed the negotiations and the decisions were not yours, or there were none, say so plainly and stay with the model. Then say how you would approach a partner motion for Northwind as a plan | F4 is the nearest evidence to a required item and sits only adjacent to it. JD because it scores a stated requirement; the Skeptic delivery is the one that finds the limit |
| D3 | "Your background is consumer tech. This is B2B data infrastructure. What carries over, and what doesn't?" | EXP | [grounded] "then 9 at a large consumer-tech company in product strategy & ops" | Acknowledge the context difference first, in plain words: "My nine years were at a large consumer-tech company, in product strategy & ops." Answer slot: say which skills carry over and why, in your own words; if you have worked on B2B buying or enterprise accounts, say what; if you have not, say so plainly and say how you would learn it. Do not claim enterprise or B2B experience | F1 puts the candidate in a different market from the employer's, and a profile with a startup chapter makes a pace-or-context probe plausible. EXP because it tests what actually transfers, and what does not |

### Bank E — Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey. Consulting, consumer tech, and now Northwind." | EXP | [grounded] "2 years strategy consulting at a top firm" and "then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with only the beats the quotes state: two years in strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy & ops. Answer slot: why Northwind and why now is yours to say; give your actual reason, and do not borrow one. End by turning it toward what you would bring to his side of the table | The biography question is asked in the friendliest register and scored anyway. EXP because it tests whether the story hangs together and is told economically |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say what the quote says: "I use AI tools daily." Answer slot: name which tools and what you use them for, in your own words; if it is a narrower use than the question suggests, say so plainly. Then show curiosity about Compass: say what you would want to learn about it, without claiming you have built anything like it | AI is a plus in the JD, asked casually so it is easy to under-prepare. JD because it scores a named plus-skill |

### Bank P — Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over someone who has carried a quota?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" and "set annual volume targets with cross-org consensus" and "No classic sales-ops or quota-setting experience." | Pause and restate the question. Hold at what the quotes carry: you built a partner-level revenue model used in carrier negotiations, and you set annual volume targets with cross-org consensus. Hold through two follow-ups by returning to those, never by adding to them. Then concede specifically: you have not had classic sales-ops or quota-setting experience, and say what you would do to close that. Do not fold on the core and do not argue the limit away | F7 returned in a time-boxed form, which tests composure on the same objection as D1. JD because it scores the requirement; the pressure register is what changes |
| P2 | "That $400M — how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold at the quote's scope: you proposed the change, and the change was credited with the uplift. Answer slot: say which part you did beyond the proposal; if others built, shipped or measured parts of it, or you do not know how the credit was assigned, say so plainly. Hold through two follow-ups by returning to the proposal, never by adding to it; concede only what you actually know | The attribution probe from the stem list, aimed at the pack's only headline figure (F2). EXP because it scores attribution honesty |

### Requirement coverage

| JD requirement (as supplied) | Question IDs |
|---|---|
| "own GTM strategy for two new product lines" | C1, C2, C3, C4, D1, P1 |
| "identify whitespace across land/adopt/expand/renew" | C1, A4 |
| "run independent analysis in SQL and Tableau" | A2, A4 |
| "partner-motion design experience required" | D2, A3, C2 |
| "strong cross-functional influence" | B2, B4, A5, B5 |
| "AI experience a plus" | E2, C3, A4 |

## Reverse questions

| # | Question to ask Dan | Why it lands | Provenance |
|---|---|---|---|
| RQ1 | "You've spent most of your career in pricing and monetization, with one early-stage chapter. What did you take from that chapter into how you run Sales Strategy now?" | Ties to his own path, and turns an interrogation into a peer conversation | [grounded] research note |
| RQ2 | "What could a new person on my side of the seam do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it shows you are pricing your impact on his load, not just your needs | [generic] |
| RQ3 | "Of the three priorities, which is hardest to staff GTM against right now?" | Shows homework on the stated priorities and asks for his view, not the press release | [grounded] research note |
| RQ4 | "How do you and the VP want land, adopt, expand and renew measured for the two new lines, and where do those definitions disagree today?" | Goes straight to the JD's stage language and the seam definitions | [grounded] JD highlights |
| RQ5 | "How is the bundling threat showing up in deals you see, and which part of it is a pricing problem versus a data problem?" | Invites his native pricing lens on the main competitive threat | [grounded] research note |
| RQ6 | "When your team and a product-line GTM lead disagree on a number, what's the best example of that going well here?" | Probes how the seam works in practice and signals you plan to work it constructively | [generic] |

## Prohibited claims

What this pack will not coach, with the basis and the honest form. The list was built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned go-to-market strategy for product lines | Inflated form of F1 | F1's quote at its own scope. The pack's observation is that the material says product strategy & ops, not go-to-market strategy. The F1 slot stays inside that work |
| Designed or structured partner arrangements, or a partner motion | Inflated form of F4 | F4's quote at its own scope. The pack's observation is that the material says a model used in negotiations. The D2 slot stays inside the model |
| Drove, delivered or owned the $400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: a proposal, and a change credited with the uplift. A1 and P2 slots ask only about counting and attribution |
| Ran independent SQL and Tableau analysis end to end | Inflated form of F3 | F3's quote at its own scope: skilled in the two tools. The A2 scaffold ends in its honest branch |
| Has sales-ops or quota-setting experience, or that annual volume targets are quotas | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I haven't had classic sales-ops or quota-setting experience." The annual volume targets stay called targets, at F5's scope |
| Built a pricing or monetization model | Inflated form of F4 | F4's quote at its own scope: a revenue model. The pack does not borrow the interviewer's vocabulary for it |
| Built or shipped AI products, or has Compass-like copilot experience | Inflated form of F6 | F6's quote at its own scope: "I use AI tools daily." The limit is the pack's observation: the material does not say which tools or for what |

## Sources

**Provided documents:** the coach's message in this conversation: JD highlights, notes on the candidate, the description of the interviewer's profile, and the research note on Northwind's three stated priorities and its main competitive threat. The loop (one 60-minute conversation, peer, same VP) comes from those same words, so no archetype fallback is used and no values-style round is detected. No dossier was supplied.

**Searches sent:**

| Query | Outcome |
|---|---|
| Northwind Data company values | refused |
| Dan Kovac Director of Sales Strategy Northwind Data | refused |
| Northwind Data Compass AI copilot strategy 2026 (aimed at checking the supplied research note) | refused |

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The one search was refused. It would have named the published values; with no values-style round detected, it would have themed VAL questions, so no values cheat sheet is built |
| 2. `Northwind Data interview process, strategy/GTM role` | skipped | Your own words already fix the loop: one 60-minute peer conversation. Persona weights follow that |
| 3. `Northwind Data strategy` / recent news | unavailable | The search, a check of the supplied research note, was refused. Bank C and A4 use the note as supplied, labeled by source, with its currency unverified |
| 4. `Dan Kovac Northwind Data` | unavailable | The search was refused. The interviewer read rests only on the profile description you supplied, and talks or writing would have been the extra |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access in this session → targets 1, 3 and 4 re-run: published values, a currency check on the research note, and Dan's public footprint, which would add to the interviewer read and RQ1. A deeper pass can follow on request: up to 6 more searches and 2 more fetches, several more minutes
- The full JD text → the six JD-highlight rows become exact quotes, and any term-type requirement (location, travel, schedule, authorization) would surface as a `hard_gate` row the highlights do not show
- Priya's CV → evidence cells move from the coach's notes to her own CV lines; confidence could rise toward `high` with an inspectable artifact in this field, such as the revenue-model file, a Tableau workbook, or the written proposal behind the store-surface change
- Priya's own answers to the answer slots in F1, F2, F3 and F4 (and A1, A3, A5, D2) → those four rows move from `transferability` and `discovery` toward story-mapped answers
- The recruiter's prep note, if any → any pre-declared deliverable, focus areas or process details change coverage and could add a build section
- Prep time available → a prep-triage section sized to the time you have
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence, a weak-area strategy for each gap, and an evidence-derived highest-ROI objection in place of the inferred one
