I'll read the reference files the skill points to before building the pack.
I've read the skill's rules and am now running the company research: values, interview process and recent strategy for Atlas Freight. After that I'll build the pack.
Company searches were refused, so I'm building the pack from your JD and background alone. Company-specific items will be labeled generic or marked unavailable, and I'm writing the file now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/alone/part-2/rooms/case-2-denied-25c2255e/atlas-freight_operations-manager_interview_pack.md`. It has 22 questions across seven interviewer styles, a fit table against the JD, and 7 questions for you to ask them.

I built it without knowing who is interviewing you or which round it is, so the interviewer styles aren't weighted to a relationship. The company searches were refused, so nothing in it is specific to Atlas beyond your JD. Everything else is marked as generic.

The question to rehearse most is **A1**: "You manage 3 supervisors today, and this role has 12 across four sites." Your Power BI gap is the next biggest, and the pack coaches a plain "I haven't used Power BI" followed by a learning plan.

Say the word and I'll play the skeptic on A1 so you can practise the answer out loud.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting (a future manager, a peer, a recruiter or a panel), and did the recruiter name any focus areas or anything to prepare in advance?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview pack: Operations Manager, Atlas Freight

Role: Operations Manager, Atlas Freight (regional logistics, 800 employees, per your JD).
Interviewer: not known. Relationship and round type: not known.
Built on one assumption: you did not say who you are meeting or in what round, so persona weights are not relationship-based, and no Atlas-specific research ran (the searches were refused). Everything beyond your JD and your own message is labeled `[generic]`.

## 1. How to use this pack

- Personas describe how a question is asked. Types describe what is being scored. Every question carries both, plus a provenance label.
- Type key:
  - VAL: past behavior against a value or principle, not generic virtue.
  - EXP: whether a claim in your background survives scrutiny; what was actually you.
  - JD: a stated requirement in the job description, gaps included.
  - CO: company and strategy knowledge. This pack has none, because no company research could run.
  - CASE: a live problem from the actual role, scored on structure and reasoning.
- Provenance labels: `[grounded]` rests on your own quoted words or the JD; `[inferred]` is a derivation from them; `[generic]` is a pattern with no claim about you or Atlas. The quote after a label is the sentence the guidance stands on.
- Guidance is scaffolding, not a script. Where it says "answer slot", it names a likely probe and gives you two honest branches; answer from your own experience, and if the practice was not yours or never existed, say so plainly.
- The highest-ROI prep in the pack is question A1, the step from 3 supervisors to 12.

## 2. Fit snapshot

The pack's spine. Requirements are quoted from your JD; evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message, "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says a shift manager over 3 supervisors and a surge plan for "the site"; it does not show terminal work or more than one site. The words stay at that scope: "I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's 4 sites make a probe on how far your current responsibility reaches likely; say plainly what it covers and what it does not, in your own words |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | discovery | The quote reaches the mis-pick rate; the material does not show whether on-time performance or cost moved. Answer slot: the JD names both measures, so a probe on them is likely; if you tracked either around the redesign, say which and what it showed; if you tracked neither, say so plainly and stay with the mis-pick rate |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The quote at its own scope: "I'm currently a senior shift manager over 3 supervisors." The pack's observation is that the material says 3 and the JD says 12. Answer slot: the step from 3 to 12 will be probed; if you have led more than 3 supervisors at any point, say when and how many; if not, say so plainly and describe how you would approach a larger team, as a plan |
| F4 | "build reporting in Excel/Power BI" — JD (the Excel half) | "solid Excel" — your message | low | [inferred] | discovery | The quote names a tool, not what was built with it. Answer slot: expect a probe on what you have built; say what you have used Excel for, in your own words; if you cannot name a specific piece of work, say so plainly and stay with "solid Excel" |
| F5 | "build reporting in Excel/Power BI" — JD (the Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI work, and nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message, "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | The quotes show 7 years in ops and a current supervisory role; they do not show how the seven years break down. Answer slot: expect the interviewer to split the seven years; say how they split in your own words; if you cannot split them cleanly, say so plainly and stay with the seven. The JD marks this required, so give the real split rather than a rounded one |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | discovery | The quote names a certification, not which program it is from or whether you have used it. Answer slot: say what your certificate names, exactly as written; if your work used its methods, say which piece of work and what you did; if none did, say so plainly and stay with the certification |

No requirement in the JD text is an eligibility term (authorization, licence, location, schedule, pay, a credential bar), so the snapshot has no gate rows. "5+ years" is graded as an experience requirement, not a gate.

## 3. Persona table

Relationship unknown, so no relationship prior was applied. Weights below come from the fit snapshot and the JD's own content, and every plausible persona is covered so no style is met for the first time live.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the 3-versus-12 jump, the Power BI gap and the warehouse-to-terminal move | High: F3 and F5 are the widest gaps in the snapshot, and the JD names both requirements | Rehearse A1 until it is boring: the limit first, then a plan, never an addition to your quotes |
| B. Case/Strategist | Live problems from the role: diagnose on-time, cut cost-per-shipment, scale a surge plan, design a daily view | High: the JD names the measures and the reporting task, so they are easy to turn into cases | Clarify, objective, segment, approach, metrics, risks; think aloud; challenge one premise respectfully per case |
| C. Data-Driven Prober | Goes line by line through the 40% figure and the surge plan | Medium: one headline figure and one multi-year claim in your material, each a natural target | Know what you can and cannot say about how the 40% was counted (C1); say plainly when you do not know |
| D. Pressure | Interrupts, time-boxes, asks how much was actually you | Medium: the same gaps as A, delivered under time pressure | Pause, restate, anchor in your quotes, hold through two follow-ups, then concede specifically (D1 to D3) |
| E. Conversational | A friendly opener that is still scored: the journey, the certification, why this role | Medium: some opener of this kind is likely in any round; the register is the risk | A 90-second arc built only from your quotes (E1); treat every casual question as scored |
| F. Values/Behavioral | Tell-me-about-a-time prompts | Medium: no published values or loop were read, so no values round is detected; the supervisor-leadership line in the JD alone makes behavioral prompts plausible | Choose stories where the hard truth landed; where you have none, say so plainly (F1 to F3) |
| G. Peer | Cross-site seams, shared resources, credit | Low to medium: four sites imply peers across sites, but nothing says a peer is in the loop | Propose principles rather than pretending to know the seam; bring what you offer, not only what you need |

## 4. Question banks

Ordered by weight. One token per Type cell; a dual-tagged call is explained in the rationale.

### Requirement coverage

| JD requirement or headline claim | Covered by |
|---|---|
| "Own daily terminal operations across 4 sites" | A3, B1, B2, B3, G1 |
| "drive on-time performance and cost-per-shipment down" | B1, B2, C2 |
| "lead a team of 12 supervisors" | A1, D2, F2 |
| "build reporting in Excel/Power BI" | A2, B4 |
| "5+ years operations leadership required" | A4, D3, E1 |
| "Lean/Six Sigma a plus" | E2 |
| Headline figure: the 40% mis-pick reduction | C1, C2, D1 |
| Peak-season surge plan | B3, C3, E1 |

### A. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You manage 3 supervisors today, and this role has 12 across four sites. What makes you ready for that step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI prep in this pack. State the limit before it is asked for: "I'm currently a senior shift manager over 3 supervisors; this role is twelve." That is the hold, and it is all the quote carries. Concession wording: "Twelve is more than three, and I'm not going to pretend the step is small." Answer slot: if you have led more than three supervisors at any point, say when and how many, in your own words; if not, say so plainly and move to how you would take on a larger team, said as a plan with the order you would do things in. Expect three follow-ups: what changes at twelve that does not at three, how you would handle a supervisor stronger than you, and what you would stop doing yourself. Answer each as intention, never as history | F3 is the biggest scale step in the snapshot and F1 adds four sites on top, so this objection will arrive in some form; JD because it scores the stated team size, with Skeptic delivery |
| A2 | "This role builds reporting in Excel and Power BI. Where are you with Power BI?" | JD | [grounded] "solid Excel, never used Power BI" | Short and plain: "I haven't used Power BI." That sentence is yours, because you stated it. Follow it at once with what is true: "solid Excel". Then a plan, said as a plan: what you would learn first, whom you would ask, and how you would check your first reports against what you can already build in Excel. Do not describe any Power BI exposure you cannot back with a specific, because the next question will ask for it | F5 is the one gap you stated, which is why the pack gives words only for what you stated; F4 is its Excel half; JD because it scores a named tool |
| A3 | "Your background is warehouse and distribution. This role is terminal operations across four sites. What would be new to you?" | JD | [grounded] "7 years in warehouse and distribution ops" | Hold only what the quote says: "I have 7 years in warehouse and distribution ops." Answer slot: the JD says terminal operations, and the material does not show whether any of your work was terminal work; if some was, say where and what you did, in your own words; if none was, say so plainly and say what you would ask in your first days to learn how a terminal differs. Do not describe how terminals differ from warehouses; the pack has not researched Atlas's terminals and you have not said you know them | F1 is the evidence for the operating requirement and the likeliest place for the background mismatch to be probed |
| A4 | "The posting asks for 5+ years of operations leadership. How do your 7 years break down?" | JD | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors" | Say the quotes at their scope: "7 years in warehouse and distribution ops, currently a senior shift manager over 3 supervisors." Answer slot: expect the interviewer to split the seven years; say how they split, in your own words, with roles and dates only as you know them; if you cannot split them cleanly, say so plainly and stay with the seven. Give the real split, not a rounded one, because the JD marks the requirement as required | F6 is a discovery row: the material does not show the split; JD because it scores a stated requirement, asked in a skeptic's register |

### B. Case/Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Four sites, and on-time performance has slipped at one of them this quarter. How do you diagnose it, and what do you want to know first?" | CASE | [generic] | Clarify first: how on-time is defined and measured, what "slipped" means in numbers, when it started, and whether anything else changed that month. Objective: recover the one site without breaking the others. Segment: by lane or customer, by shift, by day of week, inbound versus outbound. Approach: start with the segment holding most of the miss. Metrics: the first number you want to see, and what would make you drop your first hypothesis. Risks: fixes that trade cost or safety for on-time. Think aloud, and challenge one premise respectfully, for example whether the slip is real or a measurement artifact. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's on-time line and its four sites; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| B2 | "Cost-per-shipment is above target at all four sites. Where do you look first, and what would you refuse to cut?" | CASE | [generic] | Clarify what sits in the cost and what the denominator is. Decompose cost into its parts, then choose the first lever by size and by how much you control. Name what you would refuse to cut and why, and say how you would know a saving had not pushed cost or a miss somewhere else. Close with the one number you would report back first. No claim about your past | The JD's cost line, asked as a decision with a built-in trade-off against on-time; CASE delivery on JD content |
| B3 | "You've run a peak-season surge plan at your site. How would you build one that covers four sites?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Say the quote in its own words: you ran the site's peak-season surge plan, two years running. Answer slot: what the plan covered and what happened in either year are yours to state; if you can describe a part you set or decided, say what and how, in your own words; if others set it or you cannot say what it covered, say so plainly and stay with "two years running". Then the scaling answer, as a plan: ask how the four sites differ and what each site's peak plan looks like today, decide what must be common and what stays local, sequence the build. Do not present your site's practices as the answer | F1 holds the only evidence of the surge plan; CASE because the question is a scaling problem, with EXP content in its first half |
| B4 | "Supervisors need one daily view of on-time and cost-per-shipment across the four sites. What goes on it, and how do you build it?" | CASE | [grounded] "solid Excel, never used Power BI" | Structure: who reads it and what decision it drives each morning; the few measures, with definitions agreed before building; refresh rhythm and an owner; how you would check it against the source before anyone relies on it; what you would leave off. On tools: build in what you know ("solid Excel"), and if Power BI comes up, "I haven't used Power BI" followed by the plan from A2. Answer slot: what you have built in Excel is yours to name; if something others used, say what; if not, say so plainly and stay with "solid Excel" | The JD's reporting line as a live build, with F4 and F5 as the two halves of the tool question |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% reduction in mis-pick rate was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say it as the quote does: cut mis-pick rate 40% by redesigning the pick path. Then the four slots a figure raises, each in your own words: how it was counted; what it is sensitive to; which assumption behind it you would defend least, named before the interviewer names one; and which part of the redesign was yours. If you know whether 40% is a relative drop or a change in percentage points, say which. If you do not know how it was counted, say so plainly; that is an honest answer. The pack supplies no baseline, period or method | Your one headline figure, so it gets a defend-the-number question; F2 is its evidence row |
| C2 | "Did you track on-time performance or cost-per-shipment around the pick-path redesign?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: the JD names both measures, so this probe is likely; if you tracked either, say which, what it showed and how it was counted, in your own words; if you tracked neither, say so plainly and stay with the mis-pick rate as the quote states it. Never imply the redesign moved a measure you did not track | F2 is a discovery row; EXP because it tests whether the figure reaches the JD's measures, with JD content |
| C3 | "Did you measure how each peak season went, and what did the numbers say?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Answer slot: if you measured, say what, how you counted, and what it showed in each year, in your own words; the two years may differ, and the answer should say so only if they did. If you did not measure, say so plainly and stay with "ran the site's peak-season surge plan two years running". Do not describe results the quote does not carry | F1's surge-plan quote is a claim with no outcome attached, which is exactly where a prober goes next |

### D. Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold-then-concede. Pause, restate the question, anchor in the quote: "cut mis-pick rate 40% by redesigning the pick path." Hold through two follow-ups by returning to the redesign, never by adding to it. Answer slot: which part of the redesign was yours and what others contributed, in your own words; if others contributed part, concede that specifically and say what part was theirs; if the whole redesign was yours, say so plainly and describe what you did. Concede uncertainty on how the figure was counted only if it is true (C1) | The standard pressure probe on attribution; F2 is the row it presses |
| D2 | "Sixty seconds: why should we trust you with twelve supervisors when you manage three?" | JD | [grounded] "currently a senior shift manager over 3 supervisors", "cut mis-pick rate 40% by redesigning the pick path", "ran the site's peak-season surge plan two years running" | Sixty-second shape: the limit first ("I'm currently a senior shift manager over 3 supervisors"), then the two things you did, each in its quote's own words, then the step-up plan from A1 in one sentence. Say what you did and stop; do not tell the interviewer these show you can lead twelve, because an inference you assert for yourself is the one that gets tested. Hold through the interruption; concede only the size difference, which the quotes carry | F3 again, time-boxed; the same objection as A1 in a different delivery |
| D3 | "I think you're underqualified for this job. Convince me otherwise." | JD | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors", "solid Excel, never used Power BI" | Pause and restate. Hold the quotes at their scope: "7 years in warehouse and distribution ops, currently a senior shift manager over 3 supervisors." Concede the two gaps the material shows, specifically: the team today is three supervisors against the JD's twelve, and "I haven't used Power BI." Then stop; do not add claims to fill the silence | F3 and F5 are the gaps this challenge reaches for; hold-then-concede is the rubric for a pressure question |

### E. Conversational (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors", "cut mis-pick rate 40% by redesigning the pick path", "ran the site's peak-season surge plan two years running" | A 90-second arc with only the beats the quotes carry: 7 years in warehouse and distribution ops; currently a senior shift manager over 3 supervisors; the mis-pick redesign; the surge plan, two years running. Answer slot: how you moved between roles and why you are looking at this one are yours to state, in your own words; the pack does not know them. Keep the register casual and treat it as scored; end on why this role | F6 and F1 hold the biography; the opener is where a candidate either has an arc or rambles |
| E2 | "You're green belt certified. Have you applied it in your work?" | JD | [grounded] "green belt certified" | Say the quote, with the certification's name exactly as the certificate writes it; the pack does not know whether it says Lean or Six Sigma, so do not call it either until you have checked. Answer slot: if your work used its methods, say which piece of work and what you did, in your own words; if none did, say so plainly and stay with the certification | F7 is a discovery row and the JD's only plus; asked casually because a plus is often probed in passing |
| E3 | "What draws you to this role?" | JD | [generic] | Selection scaffold: pick two reasons that are true for you, each tied to a line of the JD you can quote (the four sites, the supervisors, the on-time and cost measures), and say what you would want to learn. If no reasons come to mind beyond the title, say so plainly and name what you want to find out in the interview. Do not say anything about Atlas you cannot source; the pack has not researched it | Motivation consistency is scored in any conversational round; JD because the reasons should come from the posting |

### F. Values/Behavioral (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you said the hard thing plainly, and a working relationship still intact afterward; "I" for what you said, "we" only for context; if the truth did not land, say so. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A persona stem; no company values were read, so it is generic; VAL because it scores behavior, not a skill |
| F2 | "Tell me about a time you had to coach a supervisor who was struggling." | VAL | [generic] | Selection scaffold: pick a time with a named stake, what you did, and how it ended; "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The JD's "lead a team of 12 supervisors" raises the theme; the pack holds no story, so it is a scaffold |
| F3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision with a named cost to your own metric, the reason you made it, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A persona stem; service-versus-metric trade-offs are the tension the JD's two measures create |

### G. Peer (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Two sites want the same extra labour in the same week and there isn't enough. How do you decide, and how do you handle the site that loses?" | CASE | [generic] | Ask what is driving each request. State your decision principles before any answer: what each site's miss costs, which is reversible, which service level is at risk. Say the principle, not an invented rule. Tell the losing site first and why, and say what you can offer instead. Reciprocity: name what each site manager brings to the decision. No claim about your past | The JD's four sites make a cross-site seam likely; CASE because it is a live decision |
| G2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Selection scaffold: pick an instance where work spanned teams; "we" for context, "I" for your contribution. Answer slot: if the pick-path redesign involved other teams, say which part was whose; if it did not, say so plainly | A persona stem; the quote gives it one place to land, and D1 presses the same attribution |

## 5. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does on-time performance look like across the four sites today, and which site is furthest from where you want it?" | Takes the JD's own measure and asks where the work is, so you are sizing the job rather than reciting it |
| R2 | "How is cost-per-shipment defined here, and who owns the inputs?" | Mirrors the definition-first habit you use in B2 and C1 |
| R3 | "What does reporting look like today: what runs in Excel, and what is in Power BI?" | Meets the Power BI gap directly and shows you are sizing the tool ramp |
| R4 | "Of the twelve supervisors, which are newest, and where would you want a new manager to start with them?" | Turns the 3-versus-12 objection into a question about the team |
| R5 | "What would you want to see changed in the first 90 days?" | Asks for the interviewer's definition of success, which you can then hold yourself to |
| R6 | "What do you wish the posting said about this job?" | Invites what the JD leaves out, which this pack cannot know |
| R7 | If a peer is in the room: "What could a new operations manager do in the first month that would genuinely help your team?" | Reciprocity: what you bring to their work, not only what you need |

## 6. Prohibited claims

Built from the fit snapshot before the banks were written. No cell in this pack asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned terminal operations across four sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says a shift manager over 3 supervisors and a surge plan for "the site", not terminal work or four sites |
| Led a team of twelve supervisors | Inflated form of F3 | F3's quote at its own scope: "I'm currently a senior shift manager over 3 supervisors." The pack's observation is that the material says 3 |
| Seven years of operations leadership | Inflated form of F6 | F6's quote at its own scope: "7 years in warehouse and distribution ops." The material does not show how the seven years break down |
| Has used Power BI, or has built Power BI reporting | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't used Power BI." No slot |

## 7. Sources

Provided documents: the JD text and your background, both pasted in your message. No dossier was consumed.

Searches sent, all refused (permission to search was not granted):

- `Atlas Freight regional logistics company values`: refused
- `Atlas Freight interview process operations manager`: refused
- `Atlas Freight regional logistics strategy news 2026`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Would have fed a values cheat sheet if a values-style round was documented, and published value names for VAL questions; the VAL bank is generic instead |
| 2. `Atlas Freight interview process operations manager` | unavailable | Would have set persona weights from a documented loop; the pack uses unweighted personas instead |
| 3. `Atlas Freight strategy` / recent news | unavailable | Would have grounded a CO or CASE question in current strategy; the pack has no CO question |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 8. Upgrade menu

- Round type and who is interviewing (your recruiter can usually say in one email) → persona weights re-cut to the relationship, and a tailored reverse question where an interviewer profile exists
- Recruiter or HR guidance (focus areas, anything to prepare in advance) → coverage of a pre-declared deliverable if there is one
- Atlas's published values and interview loop (paste the careers page, or grant search access) → a values cheat sheet if a values round is documented, loop-based weights, and a CO question grounded in current strategy; a deeper pass is optional, up to 6 more searches and 2 more fetches, several more minutes
- Your own answers to the answer slots, outside a drill → rows upgraded: F1 (how far your current responsibility reaches), F2 and C2 (whether on-time or cost was tracked), F3 (whether you led more than 3 supervisors), F4 (what you have used Excel for), F6 (how the 7 years break down), F7 (what the certificate names), C1 (how the 40% was counted)
- Inspectable artifacts → medium to high: the green belt certificate (F7), the before-and-after mis-pick report behind the 40% (F2), the surge plan document (F1)
- Hours you have before the interview → a prioritized prep schedule
- A `tuesday-dossier.md` from an earlier evidence check → verified evidence, per-gap strategy and prohibited claims in place of the ones inferred here
