I'll read the skill's reference files before building the pack.
Web search was denied, so I'm building the pack from your message alone. It will carry no Stripe-specific facts. I'm saving it now.
Your prep pack is saved as `Stripe_product-operations-manager_interview_pack.md`. I built it for a final round with an unknown interviewer and format, using only what your message said. It has 22 questions across seven interviewer styles, a fit worksheet, six questions for you to ask them, and a list of claims not to make.

Web search was denied this run, so the pack has no Stripe-specific facts. It has no values, no loop structure and no strategy. Interviewer styles are weighted equally and the questions are generic. The sources section records the four refused searches.

I'd start with A1, "Which part of this role would you be weakest at on day one?" I've marked it the highest-value rehearsal. It stays generic until I see your background.

Say the word and I'll play the Skeptic on A1 and hold it through follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting in the final round (hiring manager, a peer, a skip-level or a panel)? Did the recruiter mention any focus areas or something to prepare, such as a presentation or take-home? The answer reweights every question bank.
2. Can you paste your CV (or a few lines on your relevant work) and the job description? I'll proceed without them if you'd rather, but with them the fit worksheet and the story guidance get filled in with your own words.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

- Role: Product Operations Manager
- Company: Stripe
- Round: final round (the only thing your message gave about structure)
- Interviewer: not known. Relationship to you: not known
- Built on: your message alone. No CV, no job description, no recruiter guidance, and no web research (see Sources)

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values, not generic virtue |
| EXP | Whether your experience survives scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and can think at its altitude |
| CASE | Structure and reasoning on a live problem |

Provenance labels: `[grounded]` traces to a document you gave or to cited research; `[inferred]` is derived from an adjacent source; `[generic]` is a role-family pattern with no claim about Stripe or about you. This pack is almost entirely `[generic]`, because it has neither your material nor any research. Questions that ask about your past are open prompts with a selection scaffold. They end with an honest branch, because the pack cannot supply your stories.

## Fit snapshot (worksheet variant)

You gave no CV and no job description, so every evidence cell is empty and the requirements are role-family prose, not quotes from a Stripe posting. Fill the evidence column yourself, then send it back and the rows regenerate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate a launch or program across several teams (role-family pattern, no posting read) | none given | none | [generic] | discovery | Strong evidence is a specific launch or program you coordinated, with the teams involved and what was yours versus someone else's. Selection scaffold: pick one with a named set of teams and a decision you personally made; if no such program comes to mind, say so plainly, then give the nearest thing your material carries, or how you would approach it |
| F2 | Design and run a recurring process or operating rhythm (role-family pattern, no posting read) | none given | none | [generic] | discovery | Strong evidence is a recurring process you set up or ran, and how you knew it was working. Selection scaffold: pick one you can describe from start to current state; if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would approach it |
| F3 | Define and read metrics to inform product decisions (role-family pattern, no posting read) | none given | none | [generic] | discovery | Strong evidence is a metric you can explain end to end: how it was defined, how it was counted, what it is sensitive to, which part was yours. Selection scaffold: pick one such metric; if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would approach it |
| F4 | Work across product, engineering and business partners without direct authority over them (role-family pattern, no posting read) | none given | none | [generic] | discovery | Strong evidence is a disagreement with a peer or senior partner and how it resolved. Selection scaffold: pick one where the relationship stayed intact; if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would approach it |
| F5 | Structure and prioritize ambiguous problems (role-family pattern, no posting read) | none given | none | [generic] | discovery | Strong evidence is a problem you were handed with no clear shape and how you framed it. Selection scaffold: pick one with a visible before and after; if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would approach it |

No requirement here is a gate (a term such as location, authorization or schedule). No posting was read, so the pack cannot say whether Stripe's posting has any.

## Persona table

Flat weights, said plainly. No loop source was read, so there is no documented list of Stripe's rounds. The fallback archetype is Generic (screen, hiring manager, panel), which carries no tilt. Your message says only "final round", which names no relationship and no session format. Each persona therefore gets equal depth, and the weights should be recomputed once you say who you are meeting.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Quiet probing of gaps, motivation and why now | Flat. A final round is a decision round, and derisking is part of any decision. Given extra depth because the highest-ROI rule below applies | Rehearse the single most predictable objection until it is boring; calibrated candor over bluffing |
| Case / Strategist (bank B) | A live problem from the role | Flat. The role is operational, so a live problem is plausible in any round | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober (bank C) | Line-by-line probing of any number you cite | Flat. Prepare for it only because any metric you cite can draw it | Know how each number was counted and say plainly when you do not know |
| Values / Behavioral (bank D) | Scenario probes, STAR-shaped stories | Flat. No Stripe values were read, so no mapping to named values is possible here | Pick stories where your own sentence carries the beats; "we" for context, "I" for your contribution |
| Peer Evaluator (bank E) | Seam-splitting, "what would you need from me" | Flat. Possible if a peer sits on the final panel; relationship unknown | Reciprocity framing; propose seam principles, not a pretended seam |
| Conversational (bank F) | Friendly, unstructured, still scored | Flat. Common as an opener in any round | A 90-second arc for the biography; treat casual questions as scored |
| Pressure (bank G) | Interruptions, devil's advocate, time-boxing | Flat. Composure tests are plausible at a final stage; no evidence either way | Pause, restate, hold a position through two follow-ups, concede specifically |

Highest-ROI prep: A1, "Which part of this role would you be weakest at on day one?" It is the question the Skeptic stem names and the one any decision round can ask. Which of your actual gaps it lands on will only be visible once you supply a CV and a job description, so recalibrate this choice then.

## Question banks

No CV quotes exist, so no Provenance cell carries a candidate sentence. Every guidance cell is a scaffold, and none makes a claim about your past.

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one area in a single plain sentence: choose from the lowest-confidence rows of your filled fit snapshot. Then give a plan for closing it, said as a plan and never as a past. Do not pick a disguised strength. If no weakness comes to mind, say so plainly, then say how you would find out | The highest-ROI rehearsal in the pack. A final round tests whether your self-assessment is honest. JD because it scores fit to the role, including its gaps |
| A2 | "Why product operations, and why now?" | JD | [generic] | Choose the reason you would still give if asked three different ways. It must be consistent with every earlier round. Use your own reason. If you cannot yet give one that holds up, say that plainly and say what you are still working out | Motivation consistency is what the Skeptic persona scores. JD because it tests the match between you and the role as stated |
| A3 | "Why Stripe, rather than another company?" | CO | [generic] | Use only reasons you can source from something you read, used or watched yourself. This pack read nothing about Stripe, so it supplies no Stripe facts. Do not recite a values page. If you have no specific reason yet, say what you know, what you want to learn, and do your reading before the interview | A sourced answer separates prepared candidates. CO because it tests homework depth. Generic until research or your own notes exist |
| A4 | "What would make you decide, six months in, that this role was not for you?" | JD | [generic] | A hypothetical, so it asks for no past. State one honest condition tied to the work itself, and what you would do about it first. If you cannot name one yet, say you would want to find out and explain how | Tests honest self-assessment and whether your expectations of the role are realistic. JD because it probes role fit |

### Bank B: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A launch spanning three teams has slipped twice. What do you need to know first?" | CASE | [generic] | Clarify before structuring: what slipped, against which commitment, who agreed to it. Then objective, segmentation of causes, approach, metrics, risks. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | A live operational problem of the kind the role family handles. CASE because it scores structure |
| B2 | "Sketch an operating rhythm for a product org that is growing quickly. What do you need to know first?" | CASE | [generic] | Ask what is being coordinated and where it breaks today. Then propose cadence, owners, inputs and a way to retire the rhythm if it stops earning its time. Say the framework aloud before using it | Process design is a plausible core of the job. CASE because the answer is a structure, not a story |
| B3 | "An adoption metric for a feature fell 20% week over week. Diagnose it." | CASE | [generic] | Clarify the definition and the data first, then split by segment, time, release and measurement change. Rank hypotheses and say what you would check first and why. Name one assumption you would defend least | The standard diagnostic stem. CASE with a metric flavor, so it also exercises the weakest-assumption move |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a metric you have worked with. How was it defined and counted?" | EXP | [generic] | Pick one metric you can explain end to end: its definition, how it was counted, what it is sensitive to, and which part was yours. Use your own words and numbers, and nothing the pack supplies. If none comes to mind, or you do not know how it was counted, say so plainly, then give the nearest thing your material carries, or how you would approach it | Probers read for numbers. EXP because the test is attribution and counting, not the metric |
| C2 | "Which assumption behind a figure you would normally quote would you defend least?" | EXP | [generic] | Name the weak assumption yourself, before the interviewer does. Choose a figure you actually use. If you cannot name one, say plainly that you have not stress-tested it and say how you would | The weakest-assumption move turns a gotcha into a credibility gain. EXP because it tests ownership of your own numbers |
| C3 | "You roll out a new review process for launches. How will you know in 90 days whether it is working?" | CASE | [generic] | A hypothetical, so no past is asked. Define success before the rollout, pick two or three measures, name what could mislead each, and say what would make you change course | Measurement design is a plausible role skill. CASE delivery with a Prober's follow-ups |

### Bank D: Values / Behavioral

No published Stripe values were read, so these questions are themed from the persona stems, not from Stripe's values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, a message that was hard to hear, and a relationship intact afterward. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A standard values probe. VAL because it scores behavior, not knowledge |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick an occasion where the tradeoff was real and you can say what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Customer-first behavior is a common values theme. VAL because the evidence is a specific decision |
| D3 | "Tell me about a time you held a position under pressure from someone senior." | VAL | [generic] | It needs a named stake, a moment you did not fold, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Tests spine and tact together, which cross-team work requires. VAL |

### Bank E: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose principles for a seam, not a pretended map of it: who decides what, how disagreements escalate, what you would ask first. Do not claim knowledge of their team you do not have | Seam-splitting is the peer's core probe. JD because it scores the working relationship the role implies |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say what you do as a practice you can stand behind, then give one example from your own experience if one comes to mind. If none does, say so plainly and describe how you would handle it | Credit-sharing is a peer-collaboration check. VAL because it is behavioral |
| E3 | "What would you need from me in your first month?" | JD | [generic] | Reciprocity first: what you would bring their team, then two or three specific needs. Keep it about their load, not yours | Tests whether the hire adds to or reduces the peer's load. JD |

### Bank F: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, the step that led toward product operations, why this role. Every beat is a fact only you can supply. If a step does not connect, say so plainly and move on | The biography question is scored even when it sounds casual. EXP |
| F2 | "What are you playing with these days in product or operations practice?" | JD | [generic] | Name one thing you are genuinely trying, reading or building, and one thing you took from it. If nothing is current, say so, then name what you would explore first | A casual question about role-relevant interest. JD because it signals fit with the work |
| F3 | "Is there anything we have not asked that you would like us to know?" | EXP | [generic] | Do not answer "I think you have covered everything". Close with one point you want remembered, in your own words, that you have not yet made. If nothing is left, say so briefly and thank them | Often the last-scored slot of a conversation. EXP because it tests your own account of yourself |

### Bank G: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate, then give one reason you can back with something you have actually done. Hold it through two follow-ups, then concede specifically what you do not yet know. Do not fold on the core point to restore harmony. If you have no such reason yet, say that plainly | The stem tests composure. JD because it scores the case for your fit |
| G2 | "Product ops is often called coordination without ownership. Why is that not a weakness of the role?" | JD | [generic] | About the role, so no past is asked. Hold a position of your own through two pushbacks, then concede the part of the critique that is fair, specifically | Tests whether you can defend the role and your choice of it without defensiveness. JD |
| G3 | "What is the first thing you would change here, given what you know today?" | CASE | [generic] | Say what you do not yet know before proposing anything. Offer one change as a hypothesis, with how you would test it. If challenged, hold it through two follow-ups, then concede what you cannot know from outside | Tests humility and judgment together. CASE delivery with Pressure follow-ups |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Coordinate a launch or program across teams | B1, D3, E1 |
| F2 Design and run a recurring process or operating rhythm | B2, C3 |
| F3 Define and read metrics | B3, C1, C2, C3 |
| F4 Work across partners without direct authority | D1, D3, E1, E2, E3, G2 |
| F5 Structure and prioritize ambiguity | B1, B2, B3, G3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a successful first 90 days look like for this role, and how would you tell?" | Shows you think in outcomes and gives you the real success measure |
| R2 | "Where does this team's work most often get stuck between product and the rest of the business?" | Surfaces the seam and shows operational curiosity |
| R3 | "What is the hardest thing about this role that does not appear in the posting?" | Invites candor and signals you are weighing fit honestly |
| R4 | "How are decisions made when product operations and a product team disagree?" | Tests authority and escalation, which any ops role lives in |
| R5 | "What have previous hires in this role found hardest to get right?" | Shows you plan to learn from experience, and gives you a risk to address |
| R6 | "Is there anything in what I have said today that gives you pause, so I can address it now?" | Surfaces the unspoken objection while you can still answer it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None listed from your experience | You gave no CV or sentences about your past, so there is no quoted wording for the pack to list an inflated form of | Nothing to list yet. Once you supply material, this table is rebuilt against it |
| Any statement about Stripe's values, rounds, products or strategy | No Stripe source was read in this run | Use only what you have read yourself. The pack's own observation is that it holds no Stripe facts |

## Sources

Provided documents: none. Only the text of your message.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Calls sent, all refused (the host did not grant search permission):

- `Stripe operating principles values`: refused
- `Stripe interview process product operations manager`: refused
- `Stripe Product Operations Manager job description`: refused
- `Stripe strategy 2026 news annual letter`: refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Would have supplied the official value names for a values cheat sheet; none exist here, so section 10 is dropped |
| 2. `Stripe interview process product operations` | unavailable | Would have set the loop and persona weights; weights are flat on the Generic archetype instead |
| 3. `Stripe strategy` / recent news | unavailable | Would have grounded a CO or CASE question in current strategy; those questions are generic |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was no query to form |
| 5. representative `Product Operations Manager` JD | unavailable | Would have turned five `[generic]` requirement rows into quoted `[inferred]` ones |

## Upgrade menu

- Your CV, or a few sentences on your relevant work → every evidence cell fills with your own words, confidence moves off `none`, and the selection scaffolds become story maps. A project link or work sample would take a row higher still
- The job description text → five `[generic]` requirement rows become `[grounded]`, and any gate such as location or schedule surfaces
- Who you are meeting and in what format → persona weights stop being flat and the banks are reordered
- The recruiter's prep note → coverage of any assigned deliverable, with its own build section
- The interviewer's name → an interviewer read and a reverse question tied to their path
- Time available before the interview → a prioritized prep triage
- Search access, which was refused this run → Stripe's published values, a documented loop, a representative posting and recent strategy; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) could add a strategy brief and role-family loop reports
- A `tuesday-dossier.md` from an earlier evaluation, if you have one → verified evidence and claims to avoid, in place of the locally built list
