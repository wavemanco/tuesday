I'll read the reference files the skill requires before building the pack.
Dara, your prep pack is saved at /var/tmp/tuesday-measure/1a2/runs/sonnet/alone/part-2/rooms/case-8-denied-86cd03c0/ashgrove-credit-union_member-experience-lead_interview_pack.md.

I built it as a three-round loop for 29 November, with a question bank, persona weights and reverse questions for each round. It also has a values sheet for the panel round. I used your background paragraph in place of a CV and ran no web searches, because your pasted JD, values, recruiter email and strategy brief already covered what searches would have.

Round 2 (D1) has the question most worth rehearsing: "You haven't worked in a contact centre, and this role owns complaints there too." The pack coaches you to say the limit first, hold only what you actually told me, and give a plan rather than a claim.

Say the word and I'll play the Skeptic on D1 as the Head of Member Services. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Loop:** three rounds on 29 November 2026 (loop mode, because the recruiter's email gives the schedule)
**Interviewers:** Round 1 the recruiter (30 minutes); Round 2 the Head of Member Services, who would be your manager (45 minutes); Round 3 a panel of two branch managers (60 minutes, including a 20-minute case on a complaint escalation). Names beyond these roles are not yet assigned.
**Built:** 20 November 2026

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. The guidance in each row is scaffolding for a spoken answer, not a script. An answer slot is an instruction for the interview: it tells you what to say if something is true and what to say if it is not, and it asks nothing of you here.

Question IDs run by persona sub-table: A and B in Round 1; C, D and E in Round 2; G, H and J in Round 3. The letter F is skipped because F1 to F9 are the fit-snapshot rows.

| Type | Meaning |
|---|---|
| VAL | Behavioural or values alignment: whether past behaviour shows the company's published values |
| EXP | Work-experience deep-dive: whether the claims survive scrutiny, and what was actually yours |
| JD | Role and JD-driven: whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge: whether you can think at the company's altitude |
| CASE | A live problem from the role, delivered in the room |

**The highest-ROI prep in this pack is D1**, the contact-centre question. It is the most predictable objection to this background, and it is probably asked in Round 1 in a lighter form (B1) and again by the panel.

## The fit snapshot

The evidence column holds only your own sentences, quoted from your message. Everything the pack says about your past rests on them and on nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap on the years. It is a message line with nothing inspected behind it, so expect a probe on what the years held. Say it in the quote's own terms and let the interviewer draw the link to the JD's wording: six years in retail banking, the last three as a branch supervisor |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your material says a formal complaints log and does not show whether external rules governed what was in it. The words stay at "I handled the branch's formal complaints log." Answer slot: the JD's line makes a probe likely on which rules or timeframes applied to the complaints in that log and what your part was. If you know, say so in your own words; if you do not, or that part was someone else's, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | The quote carries one branch's log, at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe likely on which stages of a complaint reached you and which you followed to the end. Say which, in your own words; if you only held the log, or it covered only your own branch, say so plainly and stay with the log you handled |
| F4 | "and the contact centre" — JD, the end of the line that begins "Own the member complaints process" | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then what you would learn first and from whom, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says a monthly complaints spreadsheet and does not show what it counted. The words stay at "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names complaint volumes and resolution times, so expect a probe on what your spreadsheet counted and how. Say what it counted, in your own words; if it counted other things, say which; if you do not know how a figure in it was counted, say so plainly |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote says spreadsheet and the JD says Excel, and the pack does not assume they are the same tool. Answer slot: say which tool you built it in, in your own words; if it was not Excel, say so plainly and stay with the spreadsheet you built |
| F7 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | The quote carries the training of new tellers on a script, at that scope: "trained new tellers on our escalation script." Answer slot: the JD says supervisors, so expect a probe on whether you have coached anyone at supervisor level or above through an escalation. If you have, say who and what; if you have not, say so plainly and stay with the tellers |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing either way, so the pack writes no words about your past here. Answer slot: the JD puts digital teams in the role, so expect a probe. If you have worked with a digital team or on any self-service route, say what and what your part was, in your own words; if not, say so plainly and say how you would begin, as a plan |
| F9 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare for your first senior-leader presentation, said as a plan and never as a past. Your material says nothing about presenting at or below regional level, so that part is an answer slot in D2 |

## Grounding brief

From the 2026 strategy brief Ashgrove published in July 2026, which the recruiter sent you. Use its vocabulary: members, digital channels, hubs. Bring one item from it to show you have read it, then add a view of your own, because every other candidate has the same brief.

| Item | What it says or how to read it | Provenance |
|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | [grounded] |
| Branch consolidation | Consolidate eight branches into five hubs over 2027 | [grounded] |
| New product | Launch a small-business lending product in Q1 2027 | [grounded] |
| Competitive pressure | The main competitive pressure is app-only banks | [grounded] |
| Reading: where the JD sits | The JD's line about self-service journeys sits inside the 40% digital target. This is the pack's reading of two documents, not Ashgrove's stated link | [inferred] |
| Reading: the panel | Round 3 is two branch managers and the brief consolidates branches, so a panel member's own branch may be one of the eight. Nothing says so. Keep answers about members and process, never about a named branch | [inferred] |
| Reading: a new product | A new lending product is a new place for member complaints to arise. The pack's reading, not a statement in the brief | [inferred] |

---

# Round 1: recruiter, 30 minutes

## Persona weights

Weights rest on the recruiter's description of the loop, which establishes who runs each round. No interviewer names exist, so they follow the round-type prior.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | A friendly walk-through, then logistics: pay, notice, location, reason for leaving | High. A recruiter screen's prior is conversational with light probing, and the email gives 30 minutes with no stated focus | Rehearse the A1 arc until it runs in 90 seconds using only the sentences in A1's provenance. Treat every casual question as scored, and never answer "no" to the questions slot |
| Skeptic, light | Knockout checks on the two stated gaps, asked kindly | Medium. The JD lists contact-centre scope and presenting to senior leaders, and F4 and F9 are the rows a screen would test | Say the limit first, plainly, in your own words, then the plan. B1 rehearses it |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your six years in retail banking." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped, ninety seconds, with only the beats the quotes state: six years in retail banking, the last three as a branch supervisor; the formal complaints log you handled; the new tellers you trained on the escalation script; the monthly complaints spreadsheet your regional manager uses and you built. Answer slot: the years before the supervisor role are not described in your material, so say what you did in them, in your own words, or say there is nothing to add. Stop at the quotes' scope, because each clause is a place a follow-up lands | F1 is the years evidence and this question tests it. JD because it scores the 4+ years line, delivered as the casual biography opener a screen starts with |
| A2 | "The role needs experience handling regulated complaints. What's yours?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what the quote says, in your own words: you handled the branch's formal complaints log, and you trained new tellers on the escalation script. Answer slot: if you know which rules or timeframes applied to what was in the log, say so and say what your part was; if you do not, or that part was someone else's, say so plainly and stay with the log you handled. Do not describe the log as more than a log | F2 is the evidence for this requirement and the likeliest early knockout check. JD because it is the stated requirement, with a light Skeptic delivery |
| A3 | "What's prompting a move now?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words. Your material states no reason, so the pack supplies none. Say what you want next as well as what you are leaving, only as far as it is true | The recruiter asks it and the answer is compared with what you tell the later rounds. EXP because it tests whether the story stays consistent |
| A4 | "What are your salary expectations?" | JD | [generic] | Logistics slot: give your own figure, or ask for the role's band first. Never offer salary history unless you choose to. The posting states no pay, so the pack supplies no figure | Pay is a logistics check in a recruiter screen. JD because it concerns the listed job's terms |
| A5 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words. Your material states none, so the pack supplies none | A logistics check on the listed job's terms |
| A6 | "Is there anything about where the role is based, or the working pattern, that would affect you?" | JD | [generic] | Logistics slot: give your own constraints if you have any, or say there are none. The JD states no location or pattern, so ask the recruiter what they are before treating anything as a constraint | A logistics check on the listed job's terms. The role covers branches and the contact centre, so site and pattern are worth pinning down |
| A7 | "Why Ashgrove, and why now?" | CO | [grounded] | Name one thing from the strategy brief or the values, not a list, and say in your own words why it draws you. Answer slot: the reason is yours; if what draws you is on neither document, say that instead. Do not recite the brief | Homework depth and motivation in a friendly register. CO because the answer is stronger when it uses Ashgrove's own current vocabulary |
| B1 | "Which part of this job would be hardest for you on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose one limit from your own material and say it first, plainly: "I haven't worked in a contact centre" or "I've never presented to anyone above regional level." Then say, as a plan, what you would learn first and from whom. Do not name a limit your material does not hold, and do not pre-apologise for the other one | F4 and F9 are the stated gaps, so the screen is likely to find them. JD because it scores the listed requirements, asked in the Skeptic stem |
| B2 | "Are you comfortable with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F5 and F6: you built the monthly complaints spreadsheet your regional manager uses, and the beats stop there. Answer slot: say which tool you built it in; if you know what it counted, say so, and if you do not know how a figure in it was counted, say so plainly. If it was not Excel, say so and stay with the spreadsheet you built | F6 is the row where the JD names a tool and the evidence names a spreadsheet. JD because it scores a stated requirement |

## Reverse questions for Round 1

| # | Question | Why it lands |
|---|---|---|
| 1 | "What is the pay band and the working pattern for this role?" | It answers A4 and A6 with real numbers before you commit to either, and it is a normal question to put to a recruiter |
| 2 | "Who will I meet in each round, and can you share their names and roles?" | The names unlock an interviewer read for Rounds 2 and 3, which this pack does not have yet |
| 3 | "What does the 20-minute case usually involve, and is there anything to read beforehand?" | A recruiter can often answer this in one line, and it removes the largest unknown in the loop |
| 4 | "Is there anything in my background that you expect the Head of Member Services to want addressed?" | It surfaces the objection early from someone who has heard the hiring manager's view, and it shows you expect to be probed |
| 5 | "What happens after the panel, and when do you expect to decide?" | It closes the process loop and signals you are weighing the role seriously |

---

# Round 2: Head of Member Services, 45 minutes

## Persona weights

The recruiter described this round as "mostly behavioural", and this person would be your manager. Weights rest on that description and the hiring-manager prior.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values and behavioural | "Tell me about a time" prompts on coaching, putting members first and working across teams | High. The recruiter's own word is "behavioural" and the JD lists coaching and working with digital teams | Use "we" for context and "I" for contribution. Where no quoted sentence carries a story, use the selection scaffold and its honest branch, never a borrowed story |
| Skeptic | Quiet, persistent probing of F4 and F9, because a hiring manager is derisking gaps | High. The two stated gaps sit in the JD's core and this person owns the outcome | Rehearse D1 until it is boring: limit first, quoted material held, plan as a plan, one concession |
| Case and strategist | One short live problem on the digital shift or the complaints process across channels | Medium. A hiring-manager prior says live problems, but a mostly behavioural 45 minutes leaves room for one at most | Clarify, then objective, approach, metrics and risks, thinking aloud. Challenge one premise respectfully |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you coached someone through a difficult escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Nearest material, at its own scope: you trained new tellers on the escalation script, and the beats stop at the tellers and the script. Answer slot: if you coached someone through a live escalation, say what happened and what part was yours, in your own words; if you did not, or the training was the script only, say so plainly and stay with the training | F7 is the evidence for the coaching line and its scope is narrower than the JD's. JD because it scores the coaching requirement, delivered as a behavioural prompt |
| C2 | "When have you put a member ahead of an internal target?" | VAL | [generic] | Selection scaffold: pick a time with a named member situation, the internal target that pulled the other way, what you did, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Putting the member first is the first published value and a stock behavioural stem. VAL because it scores the value, not the CV |
| C3 | "Tell me about the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F5: you built it, it is monthly, it is about complaints, and your regional manager uses it. Answer slot: if you decided what it showed, say how; if its contents were set by someone else, or an earlier version existed, say so plainly and stay with building it. No figure is given, so no defend-the-number slot arises, and if a figure in it is probed, say how it was counted or say plainly that you do not know | F5 is the reporting evidence and the likeliest CV line for a hiring manager to read closely. EXP because it tests what was actually yours |
| C4 | "Tell me about a time you worked with a digital or product team." | JD | [grounded] | Selection scaffold: pick a time you worked with people outside branch operations on something members use, with who they were, what you needed from them and what changed for members. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would begin, as a plan | F8 has no evidence at all, so a story cannot be mapped. JD because the digital-teams line is the stated requirement |
| D1 | "You haven't worked in a contact centre, and this role owns complaints there too. How do you earn that team's trust?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The deepest rehearsal in the pack. Say the limit first, before the follow-up arrives: "I haven't worked in a contact centre." Then hold only what the quotes carry: you handled the branch's formal complaints log and trained new tellers on the escalation script, and widen neither clause. Then give a plan, never a past: what you would learn first, from whom, and what you would leave unchanged until you had. Level 1, "What if they say branch people never understand the phones?": restate the limit, do not defend, and say what you would ask to see first. Level 2, "What would you change in month one?": name what you would learn before changing anything and when you would review it. Level 3, "So you can't lead what you haven't done?": concede exactly one thing, that you have not done this work, and hold the other, the log you handled. Answer slot: if any part of what you did touched the contact centre, say what and how; if none did, say so plainly and stay with the branch | F4 is the stated gap in the JD's headline line and the one this panel most predictably presses. JD because it scores a stated requirement, delivered as the Skeptic's persistent probe |
| D2 | "This role presents to senior leaders. What's the most senior group you've presented to, and how did it go?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment first: "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level or below, say to whom and about what, in your own words; if you have not presented at all, say so plainly. Then say how you would prepare for a first senior-leader presentation, as a plan. Hold the limit through one follow-up without adding confidence you have not shown | F9 is the stated gap on the presenting requirement. JD because the requirement is explicit |
| D3 | "Sixty seconds: why you rather than someone who has run complaints in a contact centre?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pause and restate the question before answering. Hold only what the quote carries: you handled the branch's formal complaints log and trained new tellers on the escalation script. Concede exactly one thing: "I haven't worked in a contact centre." Do not claim to be the better candidate, and do not describe the log as more than a log. Hold through two follow-ups by returning to the quoted material, never by adding to it | F3 and F4 are the two rows this question sets against each other. JD because it scores honest self-assessment against the stated scope, delivered as the Pressure stem |
| E1 | "The strategy aims to move 40% of member service to digital channels by 2028. Which complaints would you keep a person on, and why?" | CO | [inferred] | Bring one fact to show you have read the brief: the 40% target by 2028. Then give a view of your own and concede its cost. Two options, adopt one only if you hold it: self-service for tracking a complaint with a person for the moment a member first tells it; or no unresolved complaint routed through a form-only channel, which is the thing the role should say no to. The concession for either is that it slows the shift toward the 40%. Name the complaint-mix data you would ask for first | The brief is public to every candidate, so reciting it scores as homework and departing from it with reasons scores as judgment. Derived from the July 2026 strategy brief and the JD's self-service line. CO because it asks for company altitude |
| E2 | "A member complained at a branch, was told it was resolved, then rang the contact centre. How would you find out what went wrong and what would you change?" | CASE | [generic] | Clarify first: who holds the complaint now, what the member is asking for, and what rules or timeframes apply here. Ask, and do not assert any regulator's timeframes you do not know. Then objective, where the handoff between branch and contact centre broke, the approach with one named owner, what you would track in the JD's own terms of volumes and resolution times, and the risks. Challenge one premise respectfully | A live problem set in the role, spanning both channels the JD names. CASE because it scores structure |

## Reverse questions for Round 2

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would a good first 90 days look like, and how will you judge it?" | It asks the future manager for their own scoring sheet |
| 2 | "Where does the complaints process work well today, and where would you most want it to change?" | It shows you are thinking about the process before you have touched it |
| 3 | "How do the digital team's self-service plans connect to the complaints process today?" | It moves the conversation to F8's territory on your terms, as a question, without a claim |
| 4 | "Which parts of this role are you most concerned about filling, and what support would you give me on the contact-centre side?" | It invites the manager's own view of the gap and turns D1 from an objection into a plan |
| 5 | "How would I get early time with senior leaders, and what do they most want from the monthly report?" | It addresses the presenting gap as a practical step and the reporting requirement as a stakeholder need |

---

# Round 3: panel of two branch managers, 60 minutes

## Persona weights

The recruiter wrote: "The panel is also the values round — they score against the four values." That makes values the guaranteed core, and the 20-minute case is named in the same email. Names are unknown, so weights follow the round and the relationship between a complaints lead and branch managers.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values and behavioural | A story for each of the four values, scored against each | High. The recruiter says this round scores against the four values | Prepare one story or one honest scaffold per value (the cheat sheet below). Choose stories where the hard truth actually landed, and where none exists say so rather than supplying one |
| Case and strategist | The 20-minute complaint-escalation case | High. The recruiter names a 20-minute case on a complaint escalation. Its content is unknown | Clarify, then objective, segmentation, approach, metrics and risks, thinking aloud. Time-box each phase |
| Peer evaluator | Seam-splitting between branches and the complaints lead, and what you would need from them | Medium. The JD has the role coaching branch supervisors, so these managers would work beside the role's reach | Offer seam principles instead of pretending to know the seam, and say what you would bring to their branches, not only what you need |
| Skeptic | One panel member probing F4 or F9 in a friendly way | Low. This round is scored on values, but a panellist can still press the gaps | Run the D1 and D2 structure unchanged: limit first, quote held, plan as a plan |

## Values and principles cheat sheet

Ashgrove's four published values, named as published. Each value has a story only where one of your own sentences carries one. Where none does, a selection scaffold ends in its honest branch.

| Value | Working meaning | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decisions are made from the member's side of the counter | No quoted sentence carries a story of this. Scaffold: pick a time you made a call from the member's side when the branch's or the process's convenience pulled the other way, with the member's situation, what you did and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs it explained twice, it was written wrong | F7 touches it only at the script: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The sentence says a script was trained on, not that its words were plain. Scaffold: pick a time you made something clearer for a member or a colleague, with who was confused, what you changed and how you knew it worked. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Neighbours, Not Numbers | Every branch is part of its town | F1 touches it only at branch work: "6 years in retail banking, the last 3 as a branch supervisor." The sentence carries a role, not a story about a town. Scaffold: pick a time you let what a community or branch needed outweigh what a report showed, with the number involved, the need and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F3 touches it only at the log: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The sentence carries a log, not an instance of keeping hold of a problem to the end. Scaffold: pick a problem you found and followed until it was solved, with what it was, what you did to keep hold of it and how you knew it was done. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. This value sits close to the JD's own "Own the member complaints process end to end", which is the pack's reading of two documents |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you made a call from the member's side of the counter." | VAL | [grounded] | Selection scaffold as in the Members First row of the cheat sheet: a named member situation, the pull the other way, what you did, what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first published value, and every value gets a VAL question. VAL because the panel scores against the four values |
| G2 | "Tell me about a time you made something clearer for a member." | VAL | [grounded] | Selection scaffold as in the Plain Words row: who was confused, what you changed, how you knew it worked. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The second published value. The prompt is an open one and supplies no event |
| G3 | "When have you let what a town needed outweigh what a report showed?" | VAL | [grounded] | Selection scaffold as in the Neighbours, Not Numbers row: the number involved, the need and what you did. Keep it about members and process and never about a named branch. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The third published value. The grounding brief's reading of the panel is why the scaffold says to keep branches unnamed |
| G4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Nearest material, at its own scope: you handled the branch's formal complaints log. The quote carries a log, not a problem followed to the end, so the beats stop there. Answer slot: if there was a complaint you followed until it was solved, say what it was and what part was yours, in your own words; if the log was a record and the solving was someone else's, say so plainly and stay with the log you handled | F3 is the nearest evidence for the fourth value and its scope is narrow. VAL because the panel scores the value |
| G5 | "Which of our four values would be hardest for you to live up to in this job, and why?" | VAL | [grounded] | Choose one honestly and say why in your own words. Do not pick the easy one, and do not claim none is hard. Name what you would do to hold yourself to it, as a plan | It tests self-awareness against the published values. VAL because it scores the values, in a Skeptic stem |
| H1 | "A member's complaint began at a branch, has reached you, and they have told the contact centre they will take it further. You have twenty minutes: what do you do first, and what do you need to know?" | CASE | [generic] | Practice case, since the real one is not known. Clarify first: who holds it now, what the member is asking for, what has been said to them so far, and what rules or timeframes apply here. Ask, and do not assert a regulator's timeframes you do not know. Then objective, where the branch and contact-centre handoff happened, the approach with one named owner, what you would track in volumes and resolution times, and the risks. Say your reasoning aloud and challenge one premise respectfully | The recruiter's email names a 20-minute case on a complaint escalation, so this is the rehearsal for the largest scored block in the loop. CASE because it scores structure on a live problem |
| H2 | "The branch supervisor says the branch handled it correctly. How do you coach them without losing them?" | CASE | [generic] | Listen to their account first. Then separate what the branch did right from what the member experienced, agree one change, and say when you would follow up. Explain it once, in plain words | A coaching follow-up the panel can add to H1, and the JD's coaching line in live form. CASE because it is a live problem |
| H3 | "Branches consolidate into hubs over 2027. What would you protect in the complaints process while that happens?" | CO | [inferred] | Bring one fact from the brief: eight branches into five hubs over 2027. Then give a view of your own and its cost. Two options, adopt one only if you hold it: no open complaint changes owner because a branch changes; and members told, in plain words, who holds their complaint. The cost is extra handover work. Name the data you would ask for first, and keep it about members and process | The brief is public to every candidate, so one fact then one view is the differentiation. Derived from the July 2026 strategy brief, and CO because it tests company-level thinking |
| J1 | "Our supervisors already handle escalations. Where is the seam between what a branch does and what you would own, and what happens when we disagree?" | JD | [generic] | Offer seam principles, not a seam you do not know: say what you would ask each branch for and what you would give back. For disagreement, use the selection scaffold: a time you disagreed with an equal, what you each wanted, how it was settled and what you would do differently. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The peer stem for a panel of branch managers, built on the JD's coaching line. JD because it scores how the role meets the branches |
| J2 | "How do you handle credit when a fix spans branches and the contact centre?" | VAL | [generic] | Say your principle first: the people who did the work are named. Then the selection scaffold: a time a result spanned teams, what each did and how credit was shared. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The standard credit-sharing probe, tied to the Own the Fix value. VAL because it scores partnership behaviour |

## Reverse questions for Round 3

| # | Question | Why it lands |
|---|---|---|
| 1 | "When a complaint comes back to your branch, what do your supervisors find hardest about the escalation step?" | It shows you are thinking about coaching from the supervisor's side |
| 2 | "How would you like to hear about complaints from your branch?" | A practical question that treats the panel as the role's customers |
| 3 | "As branches consolidate into hubs, what do you most want protected for members in your town?" | It ties to Neighbours, Not Numbers and lets the panel talk about what they care about |
| 4 | "What does a good escalation look like from your side of the counter?" | It borrows the value's own phrasing to ask for their standard |
| 5 | "What could a complaints lead do in a first month that would genuinely help your branch?" | The reciprocity question: it asks what you can bring them, not only what you need |

---

## Requirement coverage

| JD requirement | Covered by | Note |
|---|---|---|
| "Own the member complaints process end to end across branches" | A2, D1, E2, H1 | F3 and F4 hold the evidence limits |
| "report monthly on complaint volumes and resolution times" | B2, C3 | F5 |
| "coach branch supervisors on escalations" | C1, H2, J1 | F7 |
| "work with digital teams on self-service journeys" | C4, E1 | F8 |
| "4+ years in financial-services customer operations" | A1 | F1 |
| "experience handling regulated complaints" | A2 | F2 |
| "confident presenting to senior leaders" | D2 | F9 |
| "comfortable with Excel reporting" | B2 | F6 |
| Ashgrove's four published values | G1, G2, G3, G4 (one per value), G5 | Round 3 is the scored values round |
| Strategy: digital shift, hubs | E1, H3, A7 | Grounding brief |

## Prohibited claims

What this pack will not coach, and why. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F3 | F3's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says one branch's log, not a process across branches. A2 and F3's slots stay inside the log |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope. The pack observes that your material says a formal log and not the rules behind it. A2's slot asks only which rules or timeframes you know of |
| Coached branch supervisors on escalations | Inflated form of F7 | F7's quote at its own scope: "trained new tellers on our escalation script." C1's slot stays with the tellers |
| Reported on complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The pack observes that your material does not show what it counted. C3's slot asks only what it showed |
| Built the report in Excel | Inflated form of F6 | F6's quote at its own scope. The pack observes the quote says spreadsheet. B2's slot asks only which tool |
| Has worked in a contact centre | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F9 | The plain acknowledgment F9 gives: "I've never presented to anyone above regional level." No slot on the level itself |

## Sources

Provided documents: the JD you pasted; Ashgrove's four published values, copied by you on 20 November 2026 from ashgrovecu.org/about/values (pasted text, not fetched); the recruiter's email describing the three rounds, which is the loop source; the 2026 strategy brief Ashgrove published in July 2026, which the recruiter sent; and your background message. No dossier was present. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values already fix the value names and meanings in the cheat sheet |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email establishes three sessions, who runs each and which is the values round, so it fixes the persona weights and loop |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief, under six months old, already supplies priorities and the competitive frame for the grounding brief and CO questions |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names were given, only roles, so there was no query to form. The interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- A CV, or the lines under each job: the experience rows F1 to F9 are built only from your message, so a CV would add quotable evidence for the years before the supervisor role and for the complaints work
- A redacted copy of your branch complaints log format or the monthly spreadsheet: it is the inspectable artifact in this field, and it could lift F2, F5 and F6 from medium toward high
- Your own answers to the answer slots in F2, F3, F5, F6, F7 and F8: each one you give becomes quoted material and regenerates the rows and banks that draw on it
- The interviewers' names and titles when assigned: an interviewer read, persona weights tuned to each person and a reverse question tied to each one's own path
- How many days you have to prepare: a prioritized triage schedule for the nine days to 29 November, if you tell me your hours
- The recruiter's answer on the 20-minute case format: whether a case is read beforehand or live decides whether H1 stays a practice case or becomes a graded-deliverable build
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes, covering a fuller strategy and competitor brief, loop reports for this role family and recent organisational context. Offered once, and run only if you say yes
- A tuesday-dossier.md from an earlier evaluation: it would add verified evidence grades and a prohibited-claims list, and it is never required
