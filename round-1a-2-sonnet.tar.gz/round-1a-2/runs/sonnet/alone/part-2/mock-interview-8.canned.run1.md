I'll read the reference files the skill requires before building the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/alone/part-2/rooms/case-8-canned-54773c76/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it as a loop: one shared fit snapshot, then a mini-pack for each of the three sessions on 29 November. It holds 28 questions across the three rounds, with the panel's four values on a cheat sheet. I did no web research. Your pasted JD, values, recruiter email and strategy summary already fixed everything the research would have fed. No interviewer is named yet, so there is no interviewer read.

Say the word and I'll play the Head of Member Services on D1, the pack's highest-ROI question: "You've never worked in a contact centre, and this role covers it. Convince me you can own a process that runs through one."
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead — Ashgrove Credit Union — interview pack (loop mode)

Candidate: Dara. Prepared 20 November 2026 for three sessions on 29 November 2026.

| Session | Who | Length | What the recruiter's email says |
|---|---|---|---|
| Round 1 | The recruiter | 30 minutes | Nothing beyond the length |
| Round 2 | The Head of Member Services, who would be your manager | 45 minutes | "mostly behavioural" |
| Round 3 | A panel of two branch managers | 60 minutes | Includes "a 20-minute case on a complaint escalation"; "also the values round — they score against the four values" |

No interviewer has been named, so there is no interviewer read and persona weights rest on round type and the recruiter's own words.

## How to use this pack

- Personas describe how a question is asked; types describe what is being scored.
- Type key: VAL = behavioural or values alignment; EXP = work-experience deep-dive; JD = role or JD-driven; CO = company and strategy knowledge; CASE = hypothetical or live problem.
- Guidance is scaffolding, not a script. Every sentence about your past comes from your own words, quoted. Where the material is silent, the guidance is an answer slot: an instruction for the interview, with an honest second branch.
- Question IDs run by persona and skip F, so they never collide with fit-snapshot rows (F1 to F9).
- The question the pack names as its highest-ROI prep is D1.

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Your material says retail banking and branch supervision, and the JD says customer operations; whether the one counts as the other is the interviewer's call. Use your own terms: "I've spent six years in retail banking, the last three as a branch supervisor." Expect a probe, since nothing has been inspected behind the line |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says a formal complaints log, and does not show whether any rules from outside the branch governed those complaints. Words: "I handled the branch's formal complaints log." Answer slot: the JD's regulated-complaints line makes a probe on that likely. If you know whether outside rules applied, say which and how they shaped your handling, if at all; if you don't know, or none applied, say so plainly and stay with the log |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's formal complaints log, not a process across branches, and the words stay at that scope: "I handled the branch's formal complaints log." Answer slot: if any step after a complaint was logged was yours, say which and how you decided, in your own words; if the log was the extent of it, or the later steps were not yours, say so plainly and stay with the log |
| F4 | "and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The sentence shows a monthly complaints spreadsheet you built that your regional manager uses; it does not show what the spreadsheet counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet counted. Say what it recorded, in your own words; if you are not sure what it counted or how, say so plainly and stay with having built it |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers and the escalation script, not supervisors. Words: "I trained new tellers on our escalation script." Answer slot: the JD's supervisors line makes a probe on the step from tellers likely. Say plainly what the training covered, in your own words; if the step to supervisors was not yours, say so, and say what you would do first as a plan |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: if you have worked with digital or product people on anything members used themselves, say what and what part was yours, in your own words; if not, say so plainly and say what you would ask them first |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare for a first one, said as a plan and never as a past. Never a claim to senior presenting |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The sentence says spreadsheet, and does not show which tool. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it was built in Excel, say what you did with it, in your own words; if it was another tool, say so plainly and stay with having built it |

None of the nine requirements is a gate as the pack defines one: the JD states no licence, location, schedule or pay term, and "4+ years" is a length-of-experience line, graded like any other row.

## Grounding brief (the 2026 strategy brief, as you summarised it)

| Item | What it says, as you supplied it | Provenance | Where it is used |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | [grounded] | A6, E2, H5 |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" | [grounded] | A6, E1, H5, J1 |
| New product | "launch a small-business lending product in Q1 2027" | [grounded] | A6 |
| Competitive pressure | "the main competitive pressure is app-only banks" | [grounded] | A6, E2 |

Your summary of the July 2026 brief is the source; the pack has not read the brief itself.

---

# Round 1 — The recruiter (30 minutes)

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured: the journey, why now, logistics | High: the recruiter-screen prior is Conversational plus light Skeptic, and the email gives only a length, so nothing adjusts it | Rehearse the 90-second arc (A1) and treat casual questions as scored |
| Skeptic (light) | Knockout checks in a friendly register | Medium: the prior says light Skeptic, and F4 shows your material does not establish the contact-centre half of the JD | Rehearse B1 until it is boring |
| Not weighted in this round | Prober, Pressure, Case, Peer | Low: none is the recruiter-screen prior; they arrive in Rounds 2 and 3 | See those rounds |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey. How did you get to where you are now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Tell it as an arc in your own words using only what the sentence states: six years in retail banking, the last three as a branch supervisor, then what draws you to this role. Answer slot: the first three years are not in your material; say what you did in them if it helps the story, or leave them out. Close on your own reason for the role, inside 90 seconds | F1 is the evidence for the experience line, and the biography question is the first scored one in a recruiter screen; EXP because it tests the CV's claim |
| A2 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot: give your actual reason for leaving, in your own words, and point it at what this role offers. If you are not yet sure of the reason, say so plainly and say what draws you to the role | Reason for leaving is a standing recruiter-screen check; EXP because it tests motivation consistency; generic because it makes no claim about this employer |
| A3 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own figure, or ask for the role's band first; either is a fair answer. The JD you pasted states no pay, so the pack supplies no figure | Pay is a standing recruiter-screen check, JD because it concerns the listed job's terms |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | A standing recruiter-screen check on the job's terms |
| A5 | "Where would you be working from, and is there anything about travel or working pattern we should know?" | JD | [generic] | Logistics slot: give your actual location and any constraint you have, in your own words; if you have none, say so | A standing check on the job's terms; the JD you pasted states no location or pattern, so this is the likeliest place the term first appears |
| A6 | "What do you know about us, and why Ashgrove?" | CO | [inferred] derived from the strategy brief and the published values | Bring one item from the brief to prove grounding (the digital target, the hubs, the small-business product or app-only banks), then one view of your own: complaints are where members tell Ashgrove whether those changes are working for them. Say it as a view, in your own words, and invent no detail of how any of it will run. Name the member-owned model once | F1 sits behind the motivation question; CO because it tests homework depth, with the brief the recruiter sent as the shared source every prepared candidate holds, so the guidance asks for one consensus item and then a divergence |
| B1 | "The role covers the contact centre, and you've said you've never worked in one. How do you see that?" | JD | [grounded] "Never worked in a contact centre" | Hold the quote and nothing beyond it: "I've never worked in a contact centre." Concede it once, plainly, then say how you would learn it, as a plan in your own words. This is the short form of D1, which carries the deepest rehearsal | F4 is the one half of the JD your material does not establish, and a recruiter screens for it first; JD because it scores a stated requirement |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre", "I've never presented to anyone above regional level" | Choose the one you would actually be weakest at and state it in its quote's own words, then a plan for closing it. Do not pick a gap you have not stated, and do not volunteer one as a confession; the limit is a fact, said once | F4 and F8 are the two stated limits, and this is the Skeptic's stem; JD because it scores the listed requirements |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "Can you confirm the date and times of the three sessions? 29 November falls on a Sunday." | Sessions on a Sunday are unusual enough to confirm, and asking early shows you are planning |
| R1-2 | "Is anything shared ahead of the 20-minute case, or does it arrive in the room?" | Prepares you for the format and signals you take the case seriously |
| R1-3 | "Who will be on the panel, and can you tell me their roles once they are assigned?" | Interviewers are not yet assigned; this gets names you can prepare around |
| R1-4 | "How does the contact centre handle complaints today, and who runs it?" | Turns your one stated gap into curiosity about the real work |
| R1-5 | "How do the eight-branches-to-five-hubs and digital targets change what this role looks like next year?" | Ties to the brief and shows you read it as a complaints lead would |

---

# Round 2 — The Head of Member Services, your future manager (45 minutes, mostly behavioural)

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time…" probes on escalations and colleagues | High: the recruiter calls this round "mostly behavioural" | Pick stories from your own material where it carries one; use the scaffold and its honest branch where it does not |
| Skeptic | Quiet, persistent probing of the contact-centre, senior-presenting and digital gaps | High: a manager buying capability is the hiring-manager prior, and F4, F7 and F8 are the thinnest rows | Rehearse D1 until it is boring; every other gap uses the same plain-acknowledgment-then-plan shape |
| Case / Strategist | Short live problems on the strategy | Medium: the hiring-manager prior is Case plus Skeptic, but "mostly behavioural" pulls it down | Clarify, then structure, then answer; use Ashgrove's own words |
| Data-Driven Prober | Reads the log and spreadsheet closely | Low: your material has no outcome figures; D3 is the nearest | Know what the spreadsheet counted, and say plainly where you do not |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you handled the branch's formal complaints log." | JD | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F2: the branch's formal complaints log, which you handled; those are the beats the sentence states, told in your own words. Answer slot: the JD's regulated-complaints line makes a probe on the rules behind those complaints likely. If you know whether outside rules applied, say which and how they shaped your handling, if at all; if you don't know, or none applied, say so plainly and stay with the log | F2 and F3 are where the JD presses on complaints handling; JD because it scores that requirement, with EXP delivery since it asks what was actually yours |
| C2 | "Tell me about a time you had to tell a colleague something they didn't want to hear about how they'd handled a member." | VAL | [generic] | Selection scaffold: pick a time with a named situation, what you said, how it was taken, what changed, and the working relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD asks for coaching on escalations, and the unpopular-truth stem is the persona's own; VAL because the answer is scored on behaviour rather than a CV line |
| C3 | "You trained new tellers on the escalation script. How did that go?" | EXP | [grounded] "trained new tellers on our escalation script" | Story-mapped on F6: new tellers, the escalation script; those are the beats the sentence states. Answer slot: if how the training ran was yours to choose, say how and how you decided; if it was set for you, or there was no set format, say so plainly and describe the training. Then, since the JD says supervisors, say plainly that the training you have described was of tellers, and what you would do first with supervisors as a plan | F6 is the coaching evidence and sits one step from what the JD asks; EXP because it tests what was actually yours |
| D1 | "You've never worked in a contact centre, and this role covers it. Convince me you can own a process that runs through one." | JD | [grounded] "Never worked in a contact centre", "I handled the branch's formal complaints log" | Highest-ROI prep in the pack. Say the limit before they press: "I've never worked in a contact centre." Level 1: concede it once, plainly. Level 2, "what do you have?": the branch side at its scope, "I handled the branch's formal complaints log", with the observation that this is one branch's log and not the contact centre or the process across both. Level 3, "so how can you own it?": hold; do not borrow contact-centre vocabulary, and say what you would want to learn first and from whom, as a plan in your own words. Level 4, "be specific": give the first two or three things you would do, as a plan; if you cannot yet be specific, say what you would need to see first. Never describe contact-centre work as something you have done | F4 is the largest gap against the JD and the likeliest objection, and the manager is the person who would own the risk of it; JD because it scores the listed requirement, with the pressure carried by follow-ups |
| D2 | "Tell me about a time you worked with a digital or product team on something members used themselves." | JD | [grounded] | Selection scaffold, since your material has no sentence for this: pick a time with a named thing members used, who from the digital or product side was involved, what part was yours, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it and what you would ask a digital team first | F7 is silent in your material and the JD names it; JD because it scores the stated requirement |
| D3 | "Walk me through the monthly complaints spreadsheet you built." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F5 and F9: you built it, it is monthly, it is a complaints spreadsheet, and your regional manager uses it; those are the beats the sentence states. Answer slot: say what it recorded and which tool it was in, in your own words; if you are not sure what it counted, or it was another tool, say so plainly and stay with having built it | F5 and F9 are the reporting and Excel requirements, and the spreadsheet is your only quoted evidence for both; JD because it scores both, EXP delivery |
| D4 | "The JD asks for confidence presenting to senior leaders, and you've said you've never presented above regional level. How will you get there?" | JD | [grounded] "I've never presented to anyone above regional level" | Lead with the plain acknowledgment: "I've never presented to anyone above regional level." Then a plan in your own words: who you would ask what a senior audience needs from a report, and how you would rehearse before the first one. Never claim senior presenting; the limit is a fact, said once | F8 is a stated limit against a listed requirement; JD because it scores that requirement |
| E1 | "Complaints start arriving from members whose branch is moving into a hub. How would you set up for that, and what do you need to know first?" | CASE | [inferred] derived from the brief's hubs line | Clarify first, then structure: which branches and when, what members have been told, what the complaint picture looks like now. Objective: what members need through the move. Then segment, approach, what you would measure, risks. Think aloud and challenge one premise respectfully. This asks about no past, so the guidance makes no claim about yours | The brief's hubs line is the clearest strategy link to a complaints role; CASE because it is a live problem set in the role, CO in content |
| E2 | "Forty per cent of member service moves to digital by 2028. What should a complaint look like in a digital journey, and who needs to be in the room?" | CASE | [inferred] derived from the brief's digital line | Clarify first: which journeys move first and what members reach today if they want to complain in the app. State an objective, name the groups in the room, say how you would know it works, and name one risk. Link it to the Plain Words value. This asks about no past, so the guidance makes no claim about yours | F7 is silent in your material, so a structured answer is the honest way to show thinking at digital altitude; CASE because it is a live problem on the strategy |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "What would you want to see different in complaint handling six months in?" | Shows you think in outcomes and gets the manager's own definition of success |
| R2-2 | "Where do complaints work well today, and where do members have to come back a second time?" | Mirrors Own the Fix and finds the real problem areas |
| R2-3 | "How will the hub and digital changes land on complaints first?" | Ties to the brief and to what would be your own workload |
| R2-4 | "How would you want me to spend my first weeks getting to know the contact centre?" | Names your stated gap as something you will act on, without apologising for it |
| R2-5 | "What does a good monthly report look like to you, and who reads it?" | Covers the reporting requirement and the senior audience in one question |

---

# Round 3 — A panel of two branch managers (60 minutes, including a 20-minute case; also the values round)

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes scored against the four published values | Highest: the recruiter says the panel "also" scores against the four values | One story or scaffold per value; "we" for context, "I" for contribution |
| Case / Strategist | The 20-minute complaint-escalation case | High: the recruiter states it and gives it a third of the session | Clarify, structure, answer; think aloud; challenge one premise respectfully |
| Peer Evaluator | Seam questions between your team and the branches | Low to medium: a reading only, since the role coaches branch supervisors and the panel are branch managers; nothing documents these questions | Offer seam principles rather than pretending to know the seam, and say what you bring them |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "A member's complaint has been escalated for the second time. The branch says it was resolved; the member says it was not. You have the file. What do you do?" | CASE | [generic] | Clarify first: what the member asked for, what the record shows, what was promised and by whom, whether any time limits apply to the complaint, and who has been holding it. State the objective from the member's side, then segment, approach and next steps, then risks. Name who keeps hold of it until it is solved. Think aloud; challenge one premise respectfully. This is a live problem, so it makes no claim about your past | The recruiter announces a 20-minute escalation case; the actual scenario is unknown, so this is a pattern for the problem, not a prediction of the content |
| G2 | "The branch supervisor says the member is being unreasonable and the branch has done all it can. How do you respond?" | CASE | [generic] | Separate the member's issue from the supervisor's position. Ask before you judge, restate what you heard, and say what you would do with the supervisor and what you would do for the member. It makes no claim about past coaching; say what you would do as a plan | The JD pairs ownership with coaching on escalations (F3, F6), and the likeliest twist in an escalation case is a defensive supervisor |
| G3 | "You've resolved it. How do you tell the member, and how do you tell the branch what changes?" | CASE | [generic] | Say the member's message aloud in a few plain sentences, because "if a member needs it explained twice, we wrote it wrong." For the branch, say what changes and who holds the follow-up. This is a live problem, so it makes no claim about your past | Plain Words is scored here as behaviour inside the case; CASE because it is a live problem |
| G4 | "Complaint volumes at one branch double in a month. Diagnose it." | CASE | [generic] | Clarify first: what is being counted, over what period, and what changed. Segment by type, channel and branch; name your approach; and name the assumption behind the number you would trust least before they do. Say plainly what you would need to see before a conclusion. It makes no claim about your past | The JD names volumes and resolution times (F5); CASE because it is the diagnose-a-metric stem, with the weakest-assumption move built in |
| H1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold, mapped to Members First, Always: pick a time with a named stake, what you decided and why from the member's side, what it cost, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First is a published value and the panel scores against it; VAL because it tests behaviour against that value |
| H2 | "Tell me about a time you had to explain something to a member more than once. What did you change?" | VAL | [grounded] | Selection scaffold, mapped to Plain Words: pick a time with a named explanation, why the first try failed from the member's side, what you changed in the words, and how you knew it worked. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Plain Words is a published value and its own wording supplies the stem; VAL because it tests behaviour against that value |
| H3 | "Tell me about a time you did something because of who a branch's members were, not because the numbers said so." | VAL | [grounded] | Selection scaffold, mapped to Neighbours, Not Numbers: pick a time with a named branch or town, what you did and why, and what it showed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Neighbours, Not Numbers is a published value, and a panel of branch managers is the likeliest to ask about it; VAL because it tests behaviour against that value |
| H4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F2, mapped to Own the Fix: the branch's formal complaints log, which you handled, is the only beat the sentence states, and it does not show a problem solved. Answer slot: pick a problem you kept hold of, and say what you did, who you needed and how it ended, in your own words; if no such problem comes to mind, or the log was the extent of it, say so plainly and stay with the log | Own the Fix is a published value, and F2 is your only quoted sentence close to it; VAL because it tests behaviour against that value |
| H5 | "Our strategy consolidates eight branches into five hubs next year, and one of our values is that every branch is part of its town. How do you see the two together?" | CO | [grounded] | Hold: do not pretend there is no tension, and do not speak as if you know the plan; you have only the brief's one line. Say the tension plainly, say what you would want to know (which branches, and what happens to members in a town without one), and say how the complaints process could serve those members during the change. No defensiveness: the panel are branch managers | The brief and the values page, both supplied, point in different directions on this, and the panel are branch managers; CO because it tests whether you can think at the company's altitude, with VAL scoring on top |
| J1 | "Our branches and your team sit side by side. Where is the seam, and what happens when we disagree about an escalation?" | CASE | [generic] | Offer seam principles rather than claiming to know the seam: who holds the member relationship, who holds the process, and who decides when they disagree. Say what you would bring the branches, not only what you need from them. It makes no claim about your past | The role coaches branch supervisors, and a panel of branch managers is where a seam question would come from; a reading, not a documented question |
| J2 | "A complaint runs across a branch and the contact centre. How do you handle credit and blame?" | CASE | [generic] | Say your principle: whoever finds the problem keeps hold of it, credit goes to who fixed it, and the process, not a person, takes the blame. Give it as a view, not a past. Do not claim contact-centre knowledge; the limit is already stated at F4 | The JD puts both channels in one process (F3, F4); CASE because it is a hypothetical collaboration problem |

## Values cheat sheet

Source for the names: the values you pasted from ashgrovecu.org/about/values on 20 November 2026. None of your quoted sentences carries a story that ends in any of the four values, so each row is a selection scaffold.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decisions start from what the member needs, not from the institution's side of the counter | Selection scaffold (H1): a named stake, a decision from the member's side, what it cost, how it ended; if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it |
| Plain Words | The explaining is the institution's job, so a member who needs it twice shows the wording failed | Selection scaffold (H2): a named explanation, why it failed first time, what you changed, how you knew; the same honest branch |
| Neighbours, Not Numbers | Each branch belongs to its town, and decisions should not flatten that | Selection scaffold (H3): a named branch or town, what you did and why; the same honest branch |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Selection scaffold (H4), with your quoted log sentence at its own scope as the nearest thing; the same honest branch |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "How do your branches experience the complaints process today, and what would you want a Member Experience Lead to do differently for you?" | Puts the branch managers' own experience first and gives you real material |
| R3-2 | "What do your supervisors find hardest when an escalation lands?" | The role coaches supervisors, so the answer is the coaching brief |
| R3-3 | "How are branch teams thinking about the move to hubs, and what should complaints support look like through it?" | Ties to the brief without assuming how the panel feels about it |
| R3-4 | "Which of the four values is hardest to live up to day to day, and what does that look like?" | Signals you took the values seriously and invites an honest answer |
| R3-5 | "What could a new Member Experience Lead do in their first month that would genuinely help your branch?" | The reciprocity question: it asks what you can give, not only what you need |

---

## Requirement coverage

| JD requirement or scored item | Questions that cover it |
|---|---|
| "Own the member complaints process end to end across branches" | C1, G1, G2, J1 |
| "and the contact centre" | B1, B2, D1, J2 |
| "report monthly on complaint volumes and resolution times" | D3, G4 |
| "coach branch supervisors on escalations" | C2, C3, G2 |
| "work with digital teams on self-service journeys" | D2, E2 |
| "4+ years in financial-services customer operations" | A1 |
| "experience handling regulated complaints" | C1, G1 |
| "confident presenting to senior leaders" | B2, D4 |
| "comfortable with Excel reporting" | D3 |
| Each published value | H1 to H4 |
| Strategy (CO and CASE) | A6, E1, E2, H5 |
| Headline figures on your background | — none, and why: your material gives tenure only, with no outcome figure to defend |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: your material says one branch's formal complaints log, not the process across branches |
| Coached branch supervisors on escalations | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: your material says new tellers, not supervisors |
| Worked in or ran contact-centre operations | Negative you stated, F4 | The plain acknowledgment F4 gives: "I've never worked in a contact centre." No slot |
| Presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot |

## Sources

Provided documents:

- The JD, pasted.
- The values text, pasted, copied from ashgrovecu.org/about/values on 20 November 2026.
- The recruiter's email on the process.
- The 2026 strategy brief published in July 2026, as you summarised it; the pack has not read the brief itself.
- Your background message.

Searches sent: none. Fetches sent: none. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text fixes the four value names and the cheat sheet |
| 2. Ashgrove interview process, member services roles | skipped | The recruiter's email already gives the three sessions, who runs each and what each holds, which fix the loop and the persona weights |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the July 2026 brief fixes the grounding brief and the CO and CASE rows |
| 4. Interviewer name and Ashgrove | n/a | No interviewer has been assigned, so there was no query to form; the interviewer read is absent |
| 5. Representative member experience lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions |

## Upgrade menu

- Interviewer names and roles, once assigned → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- The recruiter's answer on what the 20-minute case holds and whether anything arrives beforehand → the G bank retuned to the real scenario; one email to the recruiter
- The recruiter's stated focus areas for the Head of Member Services round → the C, D and E banks reweighted from the recruiter's own words
- Your own-words answers to the slots in F2, F3, F5, F6, F7 and F9 → those rows move from discovery or transferability to quoted evidence, and C1, C3, D2 and D3 become story-mapped
- A real story for each of the four values, with what you did in it → H1 to H4 become story-mapped instead of scaffolds
- A blank copy or column list of the monthly complaints spreadsheet, and the escalation script you trained tellers on → F5, F9 and F6 can move toward high confidence, since those are the inspectable artifacts for this field
- Prep time available between now and 29 November → a prep triage section sized to it
- The role's pay band and location pattern from the recruiter → A3 to A5 filled with the job's real terms
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → interviewer talks, role-family loop reports and recent organisation context, sharpening the CO and CASE rows; run only on your say-so
- A `tuesday-dossier.md` from a verified-evidence pass → a list of user-confirmed claims, constraints on the weak areas and an evidence-derived top objection; never required
