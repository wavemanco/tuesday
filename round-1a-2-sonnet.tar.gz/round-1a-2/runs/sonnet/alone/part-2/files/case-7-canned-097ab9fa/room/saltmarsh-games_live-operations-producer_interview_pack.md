# Interview pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager (Saltmarsh's careers page describes the one session as an interview with the hiring manager; your note names Tobias and the function, not that he is your future manager). Candidate: Femi. Session: one 60-minute interview.

## How to use this pack

Personas describe how a question arrives. Types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did. Bank letters: A Case, B Values, C Skeptic, D Prober, E Pressure, G Conversational (F is skipped so question IDs never collide with fit-snapshot rows F1 to F9).

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your background claims survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework on the company and its current strategy |
| CASE | Structure and reasoning on a live problem from the role |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not live events and not two titles, and the words stay at that scope: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on more than one calendar likely. If you planned for any other title, say which and what you did, in your own words; if not, say so plainly and stay with the main title |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Never led a team, and never worked on a game with in-app purchases." — your message | low | [inferred] | discovery | The material shows a calendar and a stated absence of team leadership. It does not show whether running the calendar meant working with design, art, engineering or community teams, and coordinating is not leading. If asked about leading, the words are yours: "I haven't led a team." Answer slot: if running the calendar meant working with any of those disciplines, say which and what you did; if some were not part of it, or you did not work with them, say so plainly |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [inferred] | discovery | The material says you presented the monthly retention numbers; it does not say you ran a post-event review or chose any KPI. Words at that scope: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-review line makes a probe on reviews likely. If you ran or contributed to any review of a drop, say what it covered and what part was yours; if there was no such review, or it was not yours, say so plainly and stay with the retention presentations |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap in terms, but a one-line claim with nothing inspected behind it, so expect a probe on the checklist. Lead with it in the quote's own terms: you wrote it and your QA team still uses it. The JD's verb is manage and the quote's verb is wrote, so keep to wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Four years clears the number the JD names. The JD ties it to live-service games or apps, and your material gives a puzzle-game studio and a weekly content-drop calendar without saying whether the title ran as a live service. Answer slot: if the main title ran as a live service, say what made it so, in your own words; if it did not, or you are unsure how to describe it, say so plainly and stay with the years and the calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. Lead with the quote in its own terms: you ran it, weekly, for the main title, for two years. A named record beats an adjective, and nothing is inspected behind it, so expect a follow-up on how a week worked |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in terms. Lead with the quote: you presented the monthly retention numbers to the studio head. Nothing is inspected behind it, so expect a probe on how those numbers were counted (D1) |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | The checklist is a written artifact; the material does not show whether it, or anything else, was written for other teams to act on, or how clear it was. Answer slot: a probe on what you write is likely. If you wrote anything others relied on beyond the checklist, say what, in your own words; if the checklist is the only such document, say so plainly |
| F9 | Role-family expectation, not in the JD: familiarity with in-app purchases in a live game. Plain prose, [generic], raises no answer slot | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to monetization work |

## Reading the interviewer

Public professional footprint only.

| Fact | Source | Provenance | What it means for you |
|---|---|---|---|
| Head of Live Operations at Saltmarsh Games | Talk listing, GDC 2026 | [grounded] | He owns the function this role sits in, so expect him to judge on how you would run his calendar |
| Previously a QA lead at a console studio | Talk listing, GDC 2026 | [grounded] | A QA lens: your checklist stories (D2, E2, B3) are the ones he can test fastest, so be exact about what was yours |
| GDC 2026 talk "Patch Notes Are a Promise": a live team is judged by how often its patch notes describe what actually shipped | Talk listing, GDC 2026 | [grounded] | Expect probes on the gap between what was said and what shipped. Answer about plans in what happened and what you would announce, never in hoped-for outcomes |

Mirror opportunity, shared vocabulary: his talk is about the accuracy of what a team says it shipped, and F4's quote, "Wrote the release checklist our QA team still uses." is your nearest material on release hygiene. Offer it as that and no more. Limit: only the talk listing's summary was read, not the talk. If you raise it in the room, read or watch it first.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | The Outage Hour tabletop: a simulated outage during a live event | high — the careers page documents the tabletop, and the hiring-manager prior favors it | Clarify, objective, options, communication, record. Think aloud and challenge one premise respectfully |
| Values / Behavioral (B) | The second half of the Outage Hour: a values conversation | high — the careers page documents it and the studio publishes three named values | Choose a story per value from your own material; where none comes to mind, say so plainly and give the nearest thing or how you would handle it |
| Skeptic (C) | Quiet probing of the single-title, no-leadership, no-purchases profile | medium — hiring-manager prior, and the gaps are the ones F1, F2, F3 and F9 record | Rehearse C1 until it is boring: name the gap plainly, give a plan, never bluff |
| Data-Driven Prober (D) | Line-by-line probes of retention, checklist and writing | medium — his public argument is about accuracy of claims | Know what you can and cannot say about how each thing was done; say plainly when you do not know |
| Pressure (E) | Time-boxed challenges and attribution probes | low — nothing documented says the tabletop is time-boxed, but a live incident can feel it | Pause, restate, hold the position through two follow-ups, concede only what is true |
| Conversational (G) | Opening biography and a casual question about the games | low — the tabletop comes first in the documented format | Prepare a 90-second arc from your own sentences; treat casual questions as scored |

Highest-ROI prep: C1 (day-one weakest part), with C2 and C3 as its follow-ups. It will be asked in some form and the material is thinnest exactly there.

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Mid-event on a Saturday, reward claims start failing for some players and community reports it before your dashboards do. Walk me through your first fifteen minutes." | CASE | [generic] | Makes no claim about your past. Clarify first: how many players, which platforms, what changed, event configuration or build. State the objective (players protected first), who you pull in (engineering on call, community for a holding message, QA to reproduce), the decision you must make early (pause or continue), and what you record for the review afterward. Say each step aloud | The careers page documents a tabletop on a simulated outage during a live event, so this is the core format. CASE because it scores structure; the scenario is a generic pattern, not this studio's |
| A2 | "The fix needs a new client build that cannot reach players until tomorrow at the earliest. Extend the event, compensate, or end it early — and give me the first two lines players read." | CASE | [generic] | Makes no claim about your past. Lay out the three options and the criteria (player impact, fairness to those who already played, what is actually built versus hoped). Pick one and say what you would not promise. Then give two plain lines of announcement: what happened, what you are doing now | A natural second beat of the same tabletop, and the place the JD's written-communication line (F8) is tested live. CASE with JD content; the published value on announcing only what is built shapes the criteria |
| A3 | "Saltmarsh has announced a shared events calendar across Tidepool Tactics and Lantern Row. Two events from different titles want the same weekend. How do you decide?" | CO | [grounded] | Makes no claim about your past. Clarify first: each event's purpose, player overlap between the titles, team capacity, dependencies. Propose a decision rule rather than a pick, name the assumption you would defend least, and say who must agree. Speak only from the public announcement; do not claim to know how the studio does it internally | The Project Larkspur announcement is the current strategy source (see Sources). CO because it tests homework at the company's altitude, CASE in delivery; the JD's two-titles line (F1) is why it is likely |
| A4 | "Day-7 retention dips for three weeks after an event format changes. How do you work out whether the format is the cause?" | CASE | [generic] | Makes no claim about your past. Clarify the metric's definition and the cohorts, list what else changed in those weeks, compare like with like, decide what you would check first, and say what you would report and what you would refuse to conclude. Name the assumption you would defend least | Tests the JD's retention and KPI lines (F3, F7) as a live problem. CASE with JD content; generic because the scenario is a pattern |
| A5 | "Design, art, engineering and community each tell you their piece of next Thursday's update will slip a day. Walk me through the next hour." | CASE | [generic] | Makes no claim about your past. Ask what is fixed (the date or the scope), who is blocked by whom, what can ship without each piece, and when players are told. State your order of calls and what you would write down for the review | Scores the JD's coordination line (F2) without needing a claim about your past, which the material does not carry. CASE |

### B. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and what players needed pulled apart." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Value: Players Before Plans. Selection scaffold: pick a time something you had scheduled had to give way for players; it needs a named stake, what you changed and what it cost the plan. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, that you ran the weekly content-drop calendar for your main title for two years, or how you would handle it | The published value, from the studio's values page, themes this open prompt. F6 is the nearest material and carries no conflict, so the guidance is a scaffold, not a story map |
| B2 | "Tell me about a time you were asked to announce something that was not yet built." | VAL | [grounded] | Value: Ship the Patch Not the Promise. Your material has no sentence for this, so it is a scaffold: a moment you held back a date or a feature, what you said instead, and how the people waiting took it. If no such time comes to mind, say so plainly, then say how you would decide what to announce | The value's published meaning is announce what is built, not what is hoped, and his public talk argues the same; the open prompt lets you choose the instance. VAL; no quote carries it |
| B3 | "Tell me about a time a release left something better than it found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Value: Leave the Build Greener. Story-mapped on F4: you wrote the release checklist and your QA team still uses it, told in your own words. Answer slot: the value asks about leaving the checklist better, so expect a probe on whether it changed after you wrote it. If you revised it, say what changed and why; if it was not revised, or the revisions were not yours, say so plainly and stay with: you wrote it and QA still uses it | The one value your material carries directly. VAL because it asks for behavior, with EXP risk if you widen the quote |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Story-mapped on F7 at its own scope: you presented the monthly retention numbers to the studio head. Answer slot: if any month's numbers were unwelcome, say what they showed and how the conversation went, in your own words; if none were, or you only presented them, say so plainly and stay with the monthly presentations | A standard values-persona prompt, tied to the only place your material meets leadership. VAL; the hard-truth ending is yours to supply or to decline |
| B5 | "Tell me about a time you disagreed with design or engineering about whether something should ship." | VAL | [grounded] | The JD asks you to coordinate those teams, and your material has no sentence for a disagreement, so it is a scaffold: pick a time you disagreed about shipping, name what each side wanted, what you did and what happened. If no such time comes to mind, say so plainly, then say how you would handle it | Raised by the JD's coordination line (F2) and the shipping value; open prompt, so it presupposes nothing. VAL |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | The highest-ROI rehearsal. Level one: pick the weakest part from your own material, in your own words, and say it plainly; if it is leadership or in-app purchases the words are "I haven't led a team" or "I haven't worked on a game with in-app purchases." Then a ramp plan as a plan, never a past: what you would ask for in your first weeks, in your own words. Level two, if pushed on the gap: hold to what you ran, the weekly content-drop calendar for your main title, and concede that it is the extent of the quoted material. Level three, if pushed on leading: coordinating is not leading; concede you have not led a team and add nothing about it. Never add a claim to close a gap | Aimed at F2, F1 and F9, the gaps your material records. JD because it scores the whole listing; the persona's stem is the one a hiring manager uses to derisk |
| C2 | "Your background has no in-app purchases. How would that show up in how you run an event?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Open with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then say what you would ask in your first days to learn it, as a plan. Do not claim a parallel from your puzzle-game work, and do not name a monetization practice you have not worked with | F9 is a stated gap, so this is its direct probe. EXP because it tests honest self-assessment, not a requirement the JD names |
| C3 | "You ran the weekly content-drop calendar for your main title. This role covers two titles. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold at the quote: you ran the weekly content-drop calendar for your main title. Answer slot: if you planned for any other title or any cadence beyond weekly, say which and what you did; if not, say so plainly. Then say what you would ask first about the two titles, in your own words; you may refer to the public announcement of a shared events calendar as something you read, not something you know the workings of | Presses F1 where the JD says two titles. JD because it scores the headline requirement; transferability is what the interviewer is pricing |
| C4 | "Tell me about the post-event reviews you've owned." | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Start from what the quote carries: you presented the monthly retention numbers to the studio head. Answer slot: the JD names owning the post-event review, so if you ran or contributed to any review of a drop, say what it covered and what part was yours; if there was no such review, or it was not yours, say so plainly and stay with the monthly presentations | F3 is thin against a JD line that names ownership. JD with EXP delivery; the second branch allows that no review existed |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say what was measured and how it was counted, in your own words, as far as you know; if you did not build the calculation, say who did and what your part was; if you do not know how a figure was counted, say so plainly. Name the assumption you would defend least before he asks. Stay with what you presented | F7 has no figure, so this is the counting probe a prober runs on any metric claim. EXP; the weakest-assumption move is the point |
| D2 | "What's on the release checklist you wrote, and why?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Answer slot: choose items you can explain, and say why each is there in your own words; if you inherited an item, or cannot say why it is there, say so plainly. Keep to what the quote carries: you wrote it, and your QA team still uses it | F4 is the row a QA-trained interviewer can test fastest. EXP because it tests whether you can defend the document line by line |
| D3 | "What do you write for other teams on an update, and how do you know it landed?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Answer slot: the JD asks for clear written communication, so expect this. If you wrote anything others relied on beyond the checklist, say what and how you knew it was understood, in your own words; if the checklist is the only such document, or you did not check, say so plainly | F8 is the row with the least evidence behind a stated JD requirement. JD; the second branch lets the practice be absent |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run live events on two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | Pause and restate the question. Hold: you ran the weekly content-drop calendar for your main title for two years, and you wrote the release checklist your QA team still uses. Concede plainly what the other candidate has that you do not, which is the two titles. Hold through two follow-ups by returning to those two sentences, never by adding to them | Hold-then-concede on F1 and F4. JD because it scores fit against the listing, delivered as a time-boxed challenge |
| E2 | "The release checklist — how much of that was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold at the quote: you wrote it. Answer slot: if others contributed, say who and what, in your own words; if it was entirely yours, say so; if you are unsure which parts were yours, say so plainly. Do not widen it into owning releases or QA sign-off | The attribution probe on F4. EXP; precise attribution is what the pressure persona is scoring |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc built only from your four sentences, in the order that suits you: four years as an associate producer at a puzzle-game studio, two years running the weekly content-drop calendar for your main title, the release checklist your QA team still uses, the monthly retention numbers you presented. Why live operations and why Saltmarsh are yours to say in your own words | F5 and its neighbors. EXP because it tests whether the story is consistent with the record; conversational because it feels unscored and is not |
| G2 | "Which of our games have you played, and what did you notice about how they run their events?" | CO | [grounded] | Makes no claim about your past. If you have played Tidepool Tactics or Lantern Row, say what you noticed, in your own words; if you have not, say so plainly and say what you would look at first. Do this before the interview if you can; an honest observation beats a borrowed one | The titles are named in the Project Larkspur announcement (see Sources). CO because it tests homework; casual in delivery |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A3, C3, E1, G1 |
| coordinate design, art, engineering and community teams on each update | A5, B5, C1 |
| own the post-event review and the KPIs it reports | A4, C4, D1 |
| manage the release checklist with QA | B3, D2, E2 |
| 3+ years producing live-service games or apps | C1, E1, G1 |
| experience running a content calendar | B1, C3, G1 |
| comfortable with player-retention metrics | A4, B4, D1 |
| clear written communication | A2, D3 |
| In-app purchases (not in the JD; raised by your note) | C1, C2 |

## Values cheat sheet

A loop source documents a values conversation, so this section applies. The values are the studio's published ones.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Players Before Plans | When the schedule and the players conflict, the players decide | B1, selection scaffold with an honest branch; nearest material F6: "I ran the weekly content-drop calendar for our main title for the last two years." |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | B2, selection scaffold with an honest branch; no row carries it |
| Leave the Build Greener | Each release should leave the build and the checklist better than it found them | B3, story-mapped on F4: "Wrote the release checklist our QA team still uses." |

## Reverse questions

| # | Question | Provenance | Why it lands |
|---|---|---|---|
| 1 | "You came to live operations from QA lead at a console studio. What did QA teach you about running live events that you would want a new producer to learn first?" | [grounded] talk listing, GDC 2026 | Ties to his own path, and invites him to talk about the lens your checklist work sits in |
| 2 | "Your GDC talk argues a live team is judged by how often its patch notes describe what actually shipped. How does your team measure that today?" | [grounded] talk listing, GDC 2026 | Shows you took in his argument, and moves the conversation to how the role is judged. Read the talk first |
| 3 | "With Tidepool Tactics and Lantern Row moving to a shared events calendar from February 2027, how would this role's two titles and the single live-ops group fit together?" | [grounded] Project Larkspur announcement | Shows you read the current strategy and asks the question the JD's two-titles line raises |
| 4 | "How is the post-event review run today, and what does the producer own versus engineering and community?" | [grounded] JD line on post-event review | Turns the thinnest row, F3, into a question about the real scope of ownership |
| 5 | "What do the strongest Outage Hour answers have in common?" | [grounded] careers page | Shows respect for the format and tells you what he scores |
| 6 | "What would a strong first ninety days look like for someone coming from a single-title background?" | [generic] | Invites him to name the gap himself and shows you are planning a ramp |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated, F2 | The quote: "Never led a team, and never worked on a game with in-app purchases." The plain acknowledgment: "I haven't led a team." No slot |
| Has worked on a game with in-app purchases | Negative you stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Ran the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the weekly content-drop calendar for your main title. C3's slot stays inside that scope |
| Owned the post-event review and the KPIs it reports | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says you presented the monthly retention numbers. C4's slot asks only what that covered |
| Managed releases with QA | Inflated form of F4 | F4's quote at its own scope: you wrote the release checklist your QA team still uses |
| Produced a live-service game | Inflated form of F5 | F5's quotes at their own scope. The limit is the pack's observation: your material does not say whether the title ran as a live service |

## Sources

Provided documents: the job description and your background note, both pasted in your message.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | The three published values by name; the values cheat sheet and B1 to B3 |
| 2. Saltmarsh Games interview process, live operations | yes | Loop: recruiter call, then the Outage Hour (one 60-minute interview, tabletop then values conversation, no take-home); persona weights, bank A and bank B |
| 3. Saltmarsh Games strategy and recent news | yes | Project Larkspur (September 2026); A3, G2, reverse question 3. Only the search snippet was read, not the full page, because the fetches went to targets 1 and 2 |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Role, QA background, GDC 2026 talk; the interviewer read and reverse questions 1 and 2. Only the listing's summary was read |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Queries and what came back:

- "Saltmarsh Games values" — https://saltmarshgames.com/values
- "Saltmarsh Games interview process live operations producer" — https://saltmarshgames.com/careers/interviewing
- "Saltmarsh Games mobile studio news strategy" — https://saltmarshgames.com/news/project-larkspur
- "Tobias Wrenfield Saltmarsh Games" — https://talks.gdconf.example/2026/patch-notes-are-a-promise

Fetches: https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing.

Loop note: the careers page names the interviewer as the hiring manager; that Tobias is that person is an assumption here. The page's date was not shown.

## Upgrade menu

- Confirmation that Tobias runs your Outage Hour → persona weights and the interviewer read firm up, and banks reweight if he is a skip-level or a peer
- The recruiter's note on the tabletop (which titles, whether the scenario is given in advance) → bank A tuned to the real scenario
- Your answers to the slots in F1, F2, F3, F5 and F8 → those rows move from low or medium to stronger evidence, and the guidance for C1, C3, C4 and D3 becomes story-mapped
- Tobias's talk itself, or your notes on it → a fuller interviewer read and sharper reverse questions 1 and 2
- A tuesday-dossier.md from job-underwriter → verified evidence, a sourced highest-objection pick, and prohibited claims built from your confirmed material
