# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Date of the loop:** 29 November 2026. **Mode:** loop, three rounds, built from the recruiter's email.

| Round | Who | Length | What the recruiter said |
|---|---|---|---|
| 1 | The recruiter | 30 min | No focus areas stated |
| 2 | Head of Member Services, who would be your manager | 45 min | "mostly behavioural" |
| 3 | Panel of two branch managers | 60 min | Includes "a 20-minute case on a complaint escalation"; "also the values round — they score against the four values" |

The interviewers' names are not yet assigned, so there is no interviewer read in this pack. Rounds are prepared by role only.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Read each bank as a rehearsal for a style as well as for content.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values, not generic virtue |
| EXP | Whether what you said about your own work holds up, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know Ashgrove's strategy and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

Guidance cells are scaffolding, not a script. Wherever a cell says "answer slot", the pack does not know the answer. Say what is true for you, in your own words. If the thing never happened or was not yours, say so plainly. That is an acceptable answer.

**Highest-ROI prep in this pack: B2.** The scope objection (one branch's complaints log, no contact-centre experience, against a role that owns the process across branches and the contact centre) will be asked in some form in round 2 and probably again in round 3. Rehearse it until the concession is boring.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says a branch's log and training new tellers, not a process across the organisation, and the words stay there: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: the JD's end-to-end line makes a probe on the stages of that log likely. If any stage was yours to set, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says a monthly complaints spreadsheet that your regional manager uses, and does not show what it counted. Answer slot: expect a probe on what the spreadsheet showed. If you can say what it counted and how, say it in your own words; if you do not know how something was counted, or it did not count that, say so plainly and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers and the escalation script, and the words stay at that scope: "I trained new tellers on our escalation script." Answer slot: expect a probe on who you have trained. If it was anyone beyond new tellers, say who and what you did, in your own words; if not, say so plainly and stay with the new tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show work with digital teams. Answer slot: the JD's self-service line makes a probe likely. If you have worked with a digital or technology team on anything members use, say what it was and what part was yours, in your own words; if not, say so plainly and answer as how you would approach it |
| F6 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare for a first senior presentation, said as a plan. Answer slot: your sentence says nothing about regional-level presenting itself. If you have presented to your regional manager, say what the occasion was, in your own words; if you have not, say so plainly |
| F7 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your material says a spreadsheet, not which tool. Answer slot: the JD names Excel. If it was built in Excel, say so and say what you used it for, in your own words; if it was another tool, or you are unsure, say so plainly and stay with the spreadsheet you built |
| F8 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap, but a statement with nothing inspected behind it, so expect a probe on it. Lead with the years in the sentence's own terms: "6 years in retail banking, the last 3 as a branch supervisor." Answer slot: if asked what the years before supervision were, say the role you held, in your own words |
| F9 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says a formal complaints log, and does not show whether regulator rules applied to it. Answer slot: expect a probe on which rules governed the log. If any did, say which and what they required of you, in your own words; if none did, or you are unsure, say so plainly and stay with the log you handled |

No requirement in the JD is a gate in the sense of a term you meet or do not (a licence, a location, a schedule, a credential). The 4+ years line is experience, graded in F8.

## 3. Grounding brief

Source: the four points of Ashgrove's July 2026 strategy brief, as you supplied them. I did not have the full document, so nothing below goes beyond those four points.

| Item | What the brief says | Provenance | Where it surfaces in this loop |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | [grounded] | A9, B5, B6; the JD's self-service line is the same agenda |
| Branch network | Consolidate eight branches into five hubs over 2027 | [grounded] | C8; the panel of two branch managers may be personally affected, though which branches are involved is not known to this pack | 
| Business lending | Launch a small-business lending product in Q1 2027 | [grounded] | Least central to a complaints role; at most a one-line mention in A9 |
| Competition | The main competitive pressure is app-only banks | [grounded] | A9, B6; a complaint left unresolved is where a member has somewhere else to go, which is this pack's reading, not the brief's |

The brief reached every candidate the recruiter sent it to, so reciting it scores as homework. A9 and B6 therefore ask for one item to show grounding, then a thesis of your own with a concession.

## 4. Persona table

| Round | Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| 1 Recruiter | Conversational | A friendly walk through your history, then pay, notice, location and reason for leaving | High. Recruiter screens run on this register, and it is scored | A 90-second arc for the biography question; answer logistics in your own words |
| 1 Recruiter | Skeptic, light | A quick check on the two things the JD asks for that your material does not show | Medium. The JD names regulated complaints and the contact centre, and both are knock-out-sized checks in a screen | Short, plain, no over-apologising |
| 2 Head of Member Services | Values/Behavioral | Open "tell me about a time" prompts on escalations, coaching and reporting | High. The recruiter described the round as "mostly behavioural" | Pick stories where you can say what was yours; "we" for context, "I" for contribution |
| 2 Head of Member Services | Skeptic | Probes the scope gap between a branch log and an organisation-wide process | High. This person would be your manager and is buying capability and derisking gaps | Rehearse B2 until it is boring |
| 2 Head of Member Services | Case/Strategist, light | One live question about the first weeks, or the digital agenda | Medium. A manager's round usually carries a little of it even when mostly behavioural | Clarify, structure, then answer |
| 3 Panel | Values/Behavioral | Open prompts keyed to the four values, scored | Very high. The recruiter said the panel scores against the four values | One story or one honest scaffold per value |
| 3 Panel | Case/Strategist | The 20-minute escalation case | Certain to occur. The recruiter named it | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| 3 Panel | Peer Evaluator | Where the complaints lead and a branch manager meet, and what happens in a disagreement | Medium-high, an inference: branch managers are the colleagues whose supervisors the role coaches | Offer principles for the seam; show what you bring them |
| 3 Panel | Pressure, light | A branch manager pushing back on the numbers | Low-medium | Hold, then concede specifically |

## 5. Question banks

### Round 1 — recruiter (Conversational, light Skeptic)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc with the beats your sentences state: six years in retail banking, the last three as a branch supervisor; handling the branch's formal complaints log; training new tellers on the escalation script; building the monthly complaints spreadsheet. Tell each in your own words, at its own scope. Answer slot: if asked about the years before supervision, say the role you held; if asked about anything these sentences do not cover, say plainly that you would rather be exact than guess | F8 and F1 are the spine of the biography; EXP because it tests whether the story you tell matches what you can defend |
| A2 | "Why Ashgrove, and why this role?" | CO | [grounded] | Use one published value and one item from the strategy brief, by name, only if it fits your actual reason. Answer slot: the reason itself is yours to give, in your own words; this pack does not supply one | The JD and values page give raising sources; CO because it tests homework, VAL-adjacent because the values are the likely hook |
| A3 | "What is prompting you to look at a move?" | EXP | [generic] | Give your actual reason in your own words. Keep it about what you are moving toward. Answer slot: nothing here supplies a reason for you | Reason for leaving is a standard recruiter-screen logistics check; EXP because it tests consistency with the story in A1 |
| A4 | "What salary are you looking for?" | JD | [generic] | Give your own number, or ask for the role's band first. The JD you supplied gives no figure. Answer slot: the figure is yours | Pay is a recruiter-screen logistics check; JD because it concerns the listed job's terms |
| A5 | "What is your notice period?" | JD | [generic] | Give your actual notice period in your own words. Answer slot: the period is yours | Notice is a recruiter-screen logistics check; JD because it concerns the listed job's terms |
| A6 | "The role covers branches and the contact centre. Where are you based, and how do you feel about moving between sites?" | JD | [grounded] | Give your actual constraints on location and travel. The JD you supplied does not say where the role is based. Answer slot: the constraints are yours | Location is a recruiter-screen logistics check; the JD's "across branches and the contact centre" is the raising source |
| A7 | "The role needs experience of regulated complaints. What have you handled?" | JD | [grounded] "I handled the branch's formal complaints log" | Hold what the quote carries: "I handled the branch's formal complaints log." Answer slot: if any rules governed that log, say which and what they required of you, in your own words; if none did, or you are unsure, say so plainly and stay with the log you handled | F9 is the row this probe aims at; JD because it scores a stated requirement |
| A8 | "The role spans the contact centre, and you haven't worked in one. Is that a problem?" | JD | [grounded] "Never worked in a contact centre" | Two beats. Acknowledge in a sentence: "I haven't worked in a contact centre." Then a plan, in your own words: what you would learn first and from whom. Answer slot: the plan is yours; do not say you have contact-centre experience in any form | F2 is a stated gap and the likeliest knock-out check in the screen; JD because the contact centre is in the role's scope |
| A9 | "What do you know about where Ashgrove is heading?" | CO | [inferred] derived from the brief's digital target and its app-only-banks pressure | Bring one item to prove grounding: the 40% digital target by 2028. Then your own thesis: complaints are where the digital shift gets tested, because a member who cannot resolve something in the app has app-only banks as the alternative. Concede that self-service is the stated direction. The anti-pick: do not say that more digital is the answer to complaints. Do not correct the interviewer's framing | The brief is shared by every candidate, so one consensus item plus a divergence is the differentiator; CO because it tests altitude |

### Round 2 — Head of Member Services (Values/Behavioral, Skeptic, light Case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how you handled the branch's formal complaints log." | EXP | [grounded] "I handled the branch's formal complaints log" | The beats the sentence states: the log, and that it was formal. Tell them in your own words. Answer slot: if any stage of the log was yours to set, say which and how you decided; if there was no such step, or it was not yours, say so plainly and describe how you handled the log | F1 and F9 meet here; EXP because it tests what was actually yours |
| B2 | "This role owns complaints across every branch and the contact centre. You've handled one branch's log and haven't worked in a contact centre. Why should I think you can own it?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre" | The highest-ROI rehearsal in this pack. Hold, then concede. Hold only what the quote carries: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Concede explicitly: "I haven't worked in a contact centre." Then a plan, in your own words: what you would find out first, and from whom. Follow-up 1 will likely press on what differs when a process spans sites; answer from what you know, and where you do not know, say what you would find out first. Follow-up 2 will likely press for a bigger claim; return to the same sentence and never add to it. Answer slot: if any of that log's work reached beyond your own branch, say what and how; if none did, say so plainly | F1 and F2 together are the biggest gap in the loop, so this objection arrives in some form; JD because it scores the stated scope, Skeptic in delivery |
| B3 | "Tell me about training new tellers on your escalation script." | EXP | [grounded] "trained new tellers on our escalation script" | The beats the sentence states: new tellers, the escalation script. Tell them in your own words. Answer slot: if you have trained anyone beyond new tellers, say who and what you did; if not, say so plainly and stay with the new tellers. If asked about coaching more senior colleagues, answer from what is true for you, or as how you would approach it | F4 is the nearest evidence for the JD's coaching line; EXP because it tests scope and what was yours |
| B4 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The beats the sentence states: monthly, complaints, your regional manager uses it. Tell them in your own words. Answer slot: if you can say what it counted, say it and how it was counted; if you do not know how something was counted, say so plainly. Answer slot: if it was built in Excel, say so and say what you used it for; if it was another tool, say so plainly | F3 and F7 are both thin on this quote; EXP because it tests what you built, JD because it scores the reporting and Excel lines |
| B5 | "Tell me about a time you worked with a digital or technology team." | JD | [grounded] | A selection scaffold. Pick a time that had a named piece of work, what you contributed and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach working with a digital team on a self-service journey | F5 shows no evidence; the JD's self-service line is the raising source |
| B6 | "Ashgrove wants 40% of member service on digital channels by 2028. A member starts a complaint in the app. What has to be true for that to go well?" | CASE | [inferred] derived from the brief's digital target | Clarify first: which complaint types suit self-service, what must hand off to a person, what gets recorded. Then objective, segmentation (simple against complex or distressing), approach, metrics (resolution times, volumes), risks. Use Ashgrove's own words: "Plain Words" means the app wording is part of the fix. Concede that self-service lowers effort for the member and fits the target. The anti-pick: do not say digital fixes complaints | The brief is the raising source; CASE because it is a live problem from the role |
| B7 | "You'd be presenting to senior leaders. What's your experience of that?" | JD | [grounded] "I've never presented to anyone above regional level" | Acknowledge plainly: "I haven't presented to anyone above regional level." Then how you would prepare for a first senior presentation, as a plan. Answer slot: if you have presented to your regional manager, say what the occasion was; if not, say so plainly | F6 is a stated gap; JD because it scores a stated requirement |
| B8 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" | Choose from what you have stated, and say it with a plan. Do not add a weakness for show. Answer slot: your material also shows no digital work, so if asked about it, answer as in B5 | F2 and F6 are the stated gaps; JD because it scores the role's demands, Skeptic in delivery |
| B9 | "Sixty seconds: why you over someone who has run a contact-centre complaints team?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre" | Hold, then concede. Hold the sentence at its own scope. Concede the contact centre in one sentence. Do not claim to be better; describe what you have done and what you would learn. If pushed twice, return to the same sentence | F1 and F2 again, in a pressure register; Pressure persona, JD type |
| B10 | "Two weeks in, I ask how complaints are going across branches and the contact centre. What do you need to know first?" | CASE | [generic] | Clarify, then objective, segmentation, approach, metrics, risks. Ask what is recorded today, by whom, and how consistently; what counts as resolved; what the members are saying in their own words. Challenge one premise respectfully, for example whether one number can describe both channels | Live problem from the JD's reporting line; CASE because it asks for structure on the role, with no claim about your past |

### Round 3 — panel of two branch managers (Values/Behavioral, Case, Peer)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | A selection scaffold for Members First, Always. Pick a time when the member's interest and a rule, a target or convenience pulled apart. It needs a named stake, what you decided and what followed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries ("I handled the branch's formal complaints log") or say how you would decide | The published value is the raising source; VAL because the panel scores it |
| C2 | "Tell me about a time something you said or wrote to a member had to be explained twice." | VAL | [grounded] "trained new tellers on our escalation script" | A selection scaffold for Plain Words. Pick a time with a named message, what went wrong in the wording and what you changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries ("trained new tellers on our escalation script") or say how you would rewrite it | The published value is the raising source; VAL because the panel scores it |
| C3 | "You'll report on complaint numbers. How do you stop the numbers hiding the member?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Structure: what a number cannot show (which member, which branch, which town), what you would put beside it (cases read in words), when you would raise a pattern. Answer slot: if a figure ever hid a member's situation from you, say what happened; if not, say so plainly and answer as how you would work | Neighbours, Not Numbers set against the JD's monthly reporting is the tension a branch manager is likely to press; VAL because it scores the value |
| C4 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | A selection scaffold for Own the Fix. Pick a problem you found and saw through, with a named stake, a moment you could have passed it on and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries ("I handled the branch's formal complaints log") or say how you would hold one | The published value is the raising source; VAL because the panel scores it |
| C5 | "A member has complained three times about the same charge on their account. The branch says it is resolved; the member says it is not, and is talking about leaving. You have twenty minutes: what do you do?" | CASE | [generic] | Practice case; the real one is unknown. Clarify first: what has been promised, what is recorded, and what time limits apply to a formal response. Then the member first, one named owner until it is solved, a reply in plain words, the root cause of why the branch thought it resolved, and what goes in the report. Challenge one premise respectfully. Use the values as structure, not as slogans | The recruiter named the escalation case; CASE because it asks for structure on a live problem |
| C6 | "A supervisor in one of our branches mishandled an escalation. How do you coach them without undermining the branch manager?" | CASE | [generic] | Structure: what you would ask first, who hears it first, what the coaching covers, what gets recorded, and how the manager stays in the loop. Answer from how you would work, not from a claim about a past you have not stated | JD's coaching line is the raising source; CASE and Peer in delivery |
| C7 | "Where is the seam between my branch and the complaints lead, and what happens when we disagree about an escalation?" | JD | [generic] | Offer principles for the seam rather than pretending to know it: one owner per complaint, the member's interest as the tiebreaker, and both sides heard before anyone above is involved. Adapt these to what you believe. Add what you bring them: visibility of their members' complaints | Peer Evaluator; the branch managers are the colleagues the role works beside |
| C8 | "Over 2027 eight branches become five hubs. A member in a town that is losing its branch says Ashgrove has abandoned them. What do you do?" | CASE | [grounded] | Use Neighbours, Not Numbers as structure. Acknowledge what they have lost, ask what they need, own the fix, and say in plain words what is and is not being decided. Concede that you cannot change the strategy; you can own how it lands. Do not promise anything about the hubs that you do not know | The brief and the published value are the raising sources; CASE and CO because it asks for reasoning at Ashgrove's altitude |
| C9 | "A branch manager says your monthly report makes their branch look bad, unfairly. How do you respond?" | CASE | [generic] | Hold, then concede. Hold that the report shows what members experienced. Concede what a number cannot show, and offer to read the cases together. Do not become defensive and do not drop the figure to restore harmony | Pressure and Peer; the panel are branch managers and may take the report personally |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | B1, B2, B9, A8, C5 |
| "report monthly on complaint volumes and resolution times" | B4, B10, C3 |
| "coach branch supervisors on escalations" | B3, C6, C7 |
| "work with digital teams on self-service journeys" | B5, B6 |
| "4+ years in financial-services customer operations" | A1 |
| "experience handling regulated complaints" | A7, B1 |
| "confident presenting to senior leaders" | B7 |
| "comfortable with Excel reporting" | B4 |

## 6. Values cheat sheet

Published values, copied by you on 20 November 2026 from ashgrovecu.org/about/values. The panel scores against these four.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | "we decide from the member's side of the counter" | No story in your material carries this. Scaffold: a decision where the member's interest and a rule, target or convenience pulled apart, with a named stake and what followed. If none comes to mind, say so plainly, then give the nearest thing your material carries (F1: "I handled the branch's formal complaints log") or say how you would decide. See C1 |
| Plain Words | "if a member needs it explained twice, we wrote it wrong" | No story in your material carries this. Scaffold: a message that had to be explained twice, what was wrong in the wording and what changed. If none comes to mind, say so plainly, then give the nearest thing your material carries (F4: "trained new tellers on our escalation script") or say how you would rewrite it. See C2 |
| Neighbours, Not Numbers | "every branch is part of its town" | No story in your material carries this. Scaffold: a time a figure or target hid a local reality, and what you did. If none comes to mind, say so plainly, then give the nearest thing your material carries (F3: "I built the monthly complaints spreadsheet our regional manager uses.") or say how you would work. See C3, C8 |
| Own the Fix | "whoever finds the problem keeps hold of it until it is solved" | No story in your material carries this. Scaffold: a problem you found and saw through, with the moment you could have passed it on. If none comes to mind, say so plainly, then give the nearest thing your material carries (F1: "I handled the branch's formal complaints log") or say how you would hold one. See C4 |

## 7. Reverse questions

| # | Round | Question to ask | Why it lands |
|---|---|---|---|
| R1 | 1 | "Is the 20-minute case role-play or written, and does anything arrive beforehand?" | A process question that lets you rehearse the right format; it also shows you treat the case as a real piece of work |
| R2 | 1 | "Who sits on the panel with the two branch managers, and how are the four values scored?" | Shows you have taken the values round seriously; the answer can also unlock an interviewer read |
| R3 | 2 | "What does a good first ninety days look like for the complaints lead?" | Ties to Own the Fix: it shows you think about what you would keep hold of |
| R4 | 2 | "Where does complaints work sit today between branches and the contact centre, and where does it fall between them?" | Goes straight at the JD's end-to-end line and at your own contact-centre gap, from the side of wanting to understand it |
| R5 | 2 | "How does complaints reporting reach senior leaders today, and what would you want changed first?" | Ties to the JD's monthly reporting line and brings the senior-presenting gap into the open on your terms |
| R6 | 3 | "What could a new complaints lead do in their first month that would genuinely help your branch?" | The reciprocity question for a peer-style panel: it asks what you can give, not just what you need |
| R7 | 3 | "As eight branches become five hubs through 2027, what do you most want complaints handling to protect for your members?" | Ties to Neighbours, Not Numbers and to the brief; it asks the panel to say what they value rather than testing them |

## 8. Prohibited claims

What this pack will not coach, and why. The banks above are written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: your material says a branch's log and training new tellers, not a process across the organisation. B2's slot stays inside the log |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F6 | The plain acknowledgment F6 gives: "I haven't presented to anyone above regional level." The slot asks only about regional-level presenting |
| Coached supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: new tellers and the escalation script. B3's slot asks only who you trained |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: a monthly complaints spreadsheet your regional manager uses. B4's slot asks only what it counted |
| Handled regulated complaints | Inflated form of F9 | F9's quote at its own scope: a formal complaints log. The limit is the pack's observation: your material says formal, not regulated. A7's slot asks which rules governed the log |
| Built the monthly report in Excel | Inflated form of F7 | F7's quote at its own scope: a spreadsheet. B4's slot asks which tool |

## 9. Sources

**Provided documents:** the job description you pasted; the four published values you pasted (copied on 20 November 2026 from ashgrovecu.org/about/values); the recruiter's email about the process; the four points of the July 2026 strategy brief as you wrote them; your background as you described it. No dossier was present.

**Searches and fetches:** none were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values, copied this morning, fix the cheat sheet in section 6 |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email fixes the number of sessions, who runs each and what each holds, so persona weights follow it |
| 3. `Ashgrove Credit Union strategy` and recent news | skipped | The July 2026 brief you supplied is about four months old and fixes the grounding brief and the CO and CASE questions |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer has been assigned a name, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 10. Upgrade menu

- The panel members' names, once assigned → an interviewer read, persona weights read from their public footprint, and a reverse question tied to a path
- The recruiter's answer on the case format (role-play or written, anything sent beforehand) → a sharper version of C5 and C6
- Which complaint rules governed your branch's log, and whether any applied → F9 moves from discovery to evidence, and A7 stops being a slot
- What the monthly spreadsheet counted, the tool it was built in, and a version with member details removed → F3 and F7 upgrade; the spreadsheet is the inspectable artifact that would lift F3 from medium to high
- Anyone you have trained beyond new tellers → F4 upgrades and B3 gains a story
- Any work with a digital or technology team → F5 upgrades and B5 gains a story
- Whether you have presented to your regional manager, and what → F6 gains an honest, specific line
- Your own pay, notice, location and reason for leaving → A3 to A6 become answers in your own words
- A deeper research pass (L2) — up to 6 more searches and 2 more fetches, several more minutes. With the strategy brief supplied and no names yet, it would add only recent organisation context and loop reports, so it is not worth it before the panel is named
- A `tuesday-dossier.md` from an earlier evidence review → verified evidence and strategy limits per weak area, instead of the pack's own derivation
