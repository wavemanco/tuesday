# Interview pack: Product Manager, Platform APIs at Quartzline

- Round: hiring-manager conversation, 45 minutes (from your note). Interviewer name: not given.
- Built on: your tuesday-dossier.md (version 1.1, conditional_go). Its requirements stand as the JD, and its confirmed evidence stands as your CV.
- Persona weights rest on your own description of the round plus the hiring-manager prior. No interviewer profile adjusted them.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | Meaning |
|---|---|
| VAL | Behavioral and values alignment. Unused here: no values-style round was detected |
| EXP | Work-experience deep-dive: whether a claim survives scrutiny and what was actually yours |
| JD | Role and JD-driven: the stated responsibilities and requirements, including your gaps |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, solved aloud |

- Guidance is scaffolding, not a script. Speak it in your own words, 90 to 120 seconds at most.
- V1, V2 and V3 are the three entries of the dossier's verified_candidate_evidence, in order. Their confidence is high, high and medium.
- An answer slot is an instruction for the interview, not a question for you now. Answer it from your own experience, and say so plainly when the practice was not yours or never existed.
- All wording below is proposed language, pending your approval. Change anything you would not say aloud.

## Fit snapshot (proposed language, pending your approval)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD, dossier R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | low | [grounded] | transferability | The underwriter's positioning is adjacent, never PM experience. Your words stay at the quotes' scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live, and I ran quarterly roadmap-input sessions feeding client evidence to product." The limit is the pack's observation: your material shows integration leadership and a feed into product, not a product manager's years. Plain acknowledgment, sourced by the dossier's prohibited_claims field: "I haven't held a product manager title or role." V3 is confirmed with limited inspectable proof, so volunteer where it ends before a prober finds it. Answer slot: expect a probe on V3. Say what you brought to the sessions and who received it; where you do not know what product did with it, say so plainly and stay with the sessions you ran |
| F2 | "Shipped API or platform products" — JD, dossier R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [grounded] | transferability | V1 is strong, inspectable evidence of integrations of the vendor's APIs. It does not itself say an API or platform product was shipped, and the words stay at its scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, through go-live." Answer slot: the JD's line makes a probe on what you shipped likely. If any go-live was yours to run end to end, say which one and what you did, in your own words; if none was, or it was not yours, say so plainly and stay with the integrations you led |
| F3 | "Technical fluency: API docs, schemas" — JD, dossier R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Wrote the internal integration playbook her team uses" — dossier V2 | low | [inferred] | discovery | V1 names REST APIs and architecture, and V2 a playbook. Neither says API docs or schemas, so the pack derives the fit and does not assert it. Answer slot: the JD names API docs and schemas, so expect a probe on them. If you read, wrote or reviewed any in that work, say which and in what way; if you did not, say so plainly and stay with the REST integrations and the playbook you wrote |
| F4 | "Stakeholder management across engineering, sales, customers" — JD, dossier R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | medium | [grounded] | transferability | Your material carries clients (V1) and product (V3). It does not show engineering or sales, and it says clients where the JD says integration partners, so use "clients" for your own past. Answer slot: if engineering or sales were part of those integrations or sessions, say how and what you did; if they were not, say so plainly and stay with clients and product |
| F5 | "Agile delivery experience" — JD, dossier R5 | none given | low | [grounded] | discovery | The underwriter marked this clarify: the evidence may exist and was not established, and no entry speaks to it. Answer slot: the JD's wording is the interviewer's probe. If you have delivered work in an agile way, say how it ran and what your part was, in your own words; if you never worked that way, say so plainly, and say what you would want to confirm about how Quartzline defines it |
| F6 | "Own the roadmap for the partner-facing API platform" — JD, dossier responsibilities | none given | none | [grounded] | capability | The underwriter marked this acknowledge_gap, and the dossier's prohibited_claims field lists roadmap ownership and squad prioritization. Words: "I haven't owned a roadmap, and I haven't set prioritization for an engineering squad." Then a plan, said as a plan and never as a past: learn how the two squads decide today, and ask which roadmap decisions the PM makes alone. No bridge and no slot |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 5 questions) | Quiet, persistent probing of the missing title and roadmap | Highest. The hiring-manager prior includes the Skeptic, and the underwriter named a likely objection from evidence you confirmed (A1) | Rehearse A1 until it is boring: concede first, hold only the quoted adjacent work, name the limit before it is asked for |
| Case/Strategist (bank B, 5) | Live problems from the role: discovery, squad conflict, adoption | Highest. The hiring-manager prior includes it, and the JD's responsibilities supply ready scenarios. Unknowns in the dossier (squad authority, adoption baseline) become clarifying questions | Clarify, objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise respectfully |
| Data-Driven Prober (bank C, 3) | Line-by-line on the CV claims, especially the 30+ | Medium. The headline figure and the medium-confidence V3 are the natural targets | Say how you counted and what you do not know. Name the assumption you would defend least before they do |
| Conversational (bank D, 3) | The opening biography question and motivation, in a friendly register | Medium. A 45-minute conversation opens this way, and it is scored | Pre-script a 90-second arc built only from V1 to V3, then a reason that is genuinely yours |
| Peer Evaluator (bank E, 2) | Seams with the squad leads, collaboration scenarios | Low to medium. Squad authority is the open question, and a hiring manager may test it | Propose seam principles rather than pretending to know the seam |
| Pressure (bank G, 2) | Time-boxes and a "how much was actually you" probe | Low. Not part of the hiring-manager prior, and nothing in your note signals it | Pause, restate, hold through two follow-ups, concede specifically |

## Question banks (proposed language, pending your approval)

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product". Question from the dossier's likely_interviewer_objections; its negatives are sourced by prohibited_claims and the uncertain_or_weak_areas entry with strategy acknowledge_gap | The highest-ROI prep in this pack, named by the underwriter. Three beats. Concede first, plainly: "I haven't held a product manager title or role, and I haven't owned a roadmap or set prioritization for an engineering squad." Hold only what the quotes carry: "I led 30+ end-to-end client integrations of the vendor's REST APIs, and I ran quarterly roadmap-input sessions feeding client evidence to product." Name V3's limit before they ask: say what the sessions were and stop. Then the plan: learn how the two squads decide today, and ask which decisions the PM makes alone. Follow-up 1, "What would you be worst at on day one?": return to the concession and add no claim. Follow-up 2, "Did those sessions shape the roadmap?": answer slot: say what you brought and who received it; where you do not know what product did with it, say so plainly. Follow-up 3, "Someone with the title would ramp faster, wouldn't they?": concede that they have the practice you have not had, hold the quoted work, and do not argue the point or call the work equivalent. Hold through two follow-ups before conceding anything more | The objection is aimed at F1 and F6, where the material is thinnest, so it arrives in some form. JD because it scores the requirement. It gets the most follow-up levels because a rehearsed, non-defensive concession changes the interview |
| A2 | "Walk me through one of the client integrations you led, start to finish." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on V1. The beats are the five the quote states: scoping, requirements, architecture, UAT, go-live. Pick one integration and tell it in that order, in your own words. Answer slot: at each stage say what you did and what was decided, in your own words; where a stage was not yours, say so plainly and tell how it ran | F2 is your strongest, inspectable evidence, so lead with it. EXP because it tests what was actually yours inside a large claim |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] the uncertain_or_weak_areas entry with strategy acknowledge_gap: "Owning a roadmap and prioritization authority (R1 sub-claim)" | Name it plainly, sourced by that field: "I haven't owned a roadmap or set prioritization for an engineering squad." Then the ramp, as a plan only: learn how the two squads decide today, and ask which roadmap decisions the PM makes alone. Do not volunteer a past that closes the gap | F6 is the gap no wording closes, so the honest answer is a named weakness with a ramp. JD because it scores the responsibility directly |
| A4 | "The role asks for shipped API or platform products. What have you shipped?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what the quote carries: "I led 30+ end-to-end client integrations of the vendor's REST APIs, through go-live." Do not call the integrations products. Answer slot: if any go-live was yours to run end to end, say which and what you did; if none was, or it was not yours, say so plainly and stay with the integrations you led | F2's limit is the likeliest second probe after A1. JD because it scores a must-have requirement, and the premise is the JD's, so the guidance does not adopt it |
| A5 | "Tell me about the integration playbook you wrote — what does it cover and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Story-mapped on V2: you wrote it, it is internal, and your team uses it. It is your one inspectable artifact, so offer to walk through it end to end. Answer slot: what it covers is in the document itself, so describe its contents in your own words; the pack has not seen it and supplies none | F3 and the underwriter's high-confidence grading rest partly on this artifact. EXP because attribution to a team document is probed |

### Bank B: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You inherit the partner API platform. Before you plan anything, how would you decide what to build next?" | CASE | [generic] | Clarify first: how adoption is measured today and what the baseline is, and which decisions are yours versus the squad leads'. Then objective, who the platform serves, how you would gather evidence from partners, how you would choose and test, the metrics, and the risks. Think aloud. Where you reference your own work, use V1 or V3 at their scope only, and say "clients" for your own past | Takes the JD's discovery and roadmap responsibilities as a live problem. CASE because it scores structure. Generic because it makes no claim about you or Quartzline |
| B2 | "Two engineering squads want conflicting things and a customer is pushing for a third. How do you handle it?" | JD | [generic] | Ask who decides before anything else, and say you do not yet know Quartzline's decision rights. Then name criteria, bring the evidence you would gather, make the trade-off visible, and state the escalation path. Propose seam principles rather than a fixed rule | Scores R4's engineering, sales and customer breadth with CASE delivery. JD because the requirement is the target. It leads into reverse question 1 |
| B3 | "Partner API adoption has been flat for two quarters. How do you diagnose it?" | CASE | [generic] | Ask how adoption is defined and what the baseline is. Segment partners, then locate the drop-off. You may use the stages V1 names as a lens for where partners fall out; offer it as a lens only, since your material does not say you tracked drop-off. State the hypotheses, the data that would separate them, and what you would do first | The JD makes adoption metrics a responsibility, and the dossier flags that no baseline is stated. CASE because it scores diagnosis |
| B4 | "Walk me through how you would specify a new partner-facing endpoint." | CASE | [generic] | A structure only: the problem and the evidence behind it, who calls it, the contract including schema and error cases, rollout and deprecation, success measures, open questions. Answer slot: if you have read, written or reviewed API docs or schemas, say which and what your part was; if not, say so plainly and show the structure | Covers R3 and the spec-writing responsibility as a live task. CASE because it scores structure; it rests on no claim about you |
| B5 | "What do you know about Quartzline's partner platform, and where would you take it?" | CO | [generic] | Research for this pack was unavailable, so this stays generic. Before Thursday, read whatever public API or developer documentation Quartzline publishes, and ask the recruiter for it if none is public. Do not recite it: bring one thing you noticed and one question | CO because it tests homework at the company's altitude. Generic because no strategy source was available; see Sources |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say you led 30+ integrations. How did you count them, and which one would you least want me to dig into?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The figure counts integrations, not clients or projects. Answer slot, in your own words: how the 30+ was counted; what it is sensitive to; the assumption you would defend least; and which part was yours. If you do not know how it was counted, say so plainly. Name the weakest assumption before they ask | Defend-the-number question for the CV's headline figure. EXP because it tests attribution and counting |
| C2 | "In those integrations, what was your part and what was your team's?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Hold what the quotes say: you led the integrations and wrote the playbook your team uses. Answer slot: where your team did the work, say so plainly, in your own words, and say what was yours. Use "we" for context and "I" for what was yours | A prober tests where "led" ends. EXP, tied to F1 and F3 |
| C3 | "Tell me about the quarterly roadmap-input sessions you ran — what client evidence did you bring?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-mapped on V3. The dossier marks it confirmed with limited inspectable proof, so say what you have and where it ends before a prober finds the seam. Answer slot: say what evidence you brought and who in product received it, in your own words; where you do not know what product did with it, say so plainly | V3 is the medium-confidence item the underwriter said to expect a probe on (F1). EXP because it tests attribution on the evidence nearest the roadmap |

### Bank D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey. How did you get from integration work to wanting a product role?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in three beats the quotes carry: you led the integrations, you wrote the playbook your team uses, you ran the roadmap-input sessions. Answer slot: the reason you want the product side is yours to give, in one sentence; if no single moment comes to mind, say so plainly and say what you want more of | A friendly question that is still scored. EXP because it tests the story's coherence against F1 |
| D2 | "Why Quartzline, and why now?" | CO | [generic] | Say why partner-facing API platform work, in your own words. Say why Quartzline only from what you can point to in public material, and where you cannot yet say, say so and name what you want to learn today | Motivation consistency is probed in every hiring-manager conversation. CO because it needs company knowledge; generic because research was unavailable |
| D3 | "How do you keep current on API design and documentation?" | JD | [grounded] | Selection scaffold: pick something you actually use or read, name it, and say what you took from it. If nothing comes to mind, say so plainly, then give the nearest thing from your own work, or how you would build the habit | Casual questions about hot JD topics are scored (F3). JD because it scores R3's wording |

### Bank E: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "The squad leads and the PM sit side by side. Where is the seam, and what happens when you disagree?" | CASE | [generic] | Propose principles rather than pretend to know the seam: who owns the how, who owns the why, how a disagreement gets named and escalated. Say you do not yet know Quartzline's decision rights, and that you would ask | The JD asserts squad authority the dossier could not verify (F6). CASE because it is a live collaboration problem |
| E2 | "Tell me about working inside agile delivery — what did that look like for you?" | JD | [grounded] | Answer slot: the JD's wording is the probe. If you have delivered work in an agile way, say how it ran and what your part was; if you never worked that way, say so plainly, and say what you would want to confirm about how Quartzline defines it | The underwriter marked R5 clarify, so the answer is an honest question-shaped slot (F5). JD because it scores R5 |

### Bank G: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a PM with the actual three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A three-sentence version of A1: the concession, the quoted work at its own scope, the plan. Pause before you start and do not fill the time. Hold through two follow-ups; concede specifically, and never call your work equivalent | The time-boxed form of the highest-ROI objection (F1). JD because it scores the same requirement |
| G2 | "The roadmap-input sessions — how much of that was actually you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Hold what the quote says: you ran the sessions. Answer slot: where others did part, say so plainly, in your own words, and say what was yours. Name what you do not know about what came of them instead of guessing | Attribution is pressed hardest where proof is thinnest (F1, V3). EXP because it tests hold-then-concede |

## Requirement coverage

| Requirement | Questions |
|---|---|
| R1 3+ years product management experience | A1, A3, G1, D1 |
| R2 Shipped API or platform products | A4, A2 |
| R3 Technical fluency: API docs, schemas | D3, B4, A5 |
| R4 Stakeholder management across engineering, sales, customers | B2, E1, C3 |
| R5 Agile delivery experience | E2 |
| Own the roadmap (JD responsibility) | A1, A3, B1 |
| Define and track adoption metrics (JD responsibility) | B3, C1 |

## Reverse questions (proposed language, pending your approval)

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The JD asserts squad authority with no evidence behind it. It reads as diligence, and it answers what you need to know before accepting |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption metrics are a named responsibility, but no baseline is stated. The answer tells you what you would be judged on |
| 3 | "How do the two squads divide the platform, and where do they depend on each other?" | It shows you are thinking about the seam you will sit in (B2, E1), and the answer tells you where disputes will arise |
| 4 | "Which partner feedback reaches the roadmap today, and through what forum?" | It connects to your quoted work without claiming it, and the answer shows how mature discovery is |
| 5 | "What does a strong first ninety days look like, and what should I have learned by the end?" | It lets the hiring manager define success, and anchors the ramp plan you offered in A1 and A3 |
| 6 | "What would make you hesitate about hiring someone whose background is adjacent to product management?" | It invites the live concern, so you can address it in the room and not after it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| prohibited_claims: "Having held a product manager title or role" | Sourced entry: dossier prohibited_claims | V1 and V3 at their own scope, plus the plain acknowledgment: "I haven't held a product manager title or role." |
| prohibited_claims: "Having owned a product roadmap" | Sourced entry: dossier prohibited_claims, and the acknowledge_gap area | The plain acknowledgment: "I haven't owned a roadmap." Then a ramp plan. No slot |
| prohibited_claims: "Having set prioritization for an engineering squad" | Sourced entry: dossier prohibited_claims, and the acknowledge_gap area | The plain acknowledgment: "I haven't set prioritization for an engineering squad." Then a ramp plan. No slot |
| Shipped API or platform products | Inflated form of F2 | V1's quote at its own scope. The limit is the pack's observation: the material says integrations of the vendor's REST APIs, not shipping a product. A4's slot stays inside the go-lives |
| Has product management experience | Inflated form of F1 | V1 and V3 at their own scope. The limit is the pack's observation: the material shows integration leadership and a feed into product |

## Sources

- Provided: tuesday-dossier.md, version 1.1, dated 2026-08-14, so its evidence is as of that date. Sections consumed: role_profile (requirement text as the JD's lines, and its responsibilities), handoff_to_mock_interview (verified_candidate_evidence, uncertain_or_weak_areas, likely_interviewer_objections, opportunity_risks_to_validate, questions_for_employer, prohibited_claims), and decision as context only. The dossier carries no evidence_map, evidence_state or risk_register. Your note supplied the round: a 45-minute conversation with the hiring manager.
- Searches sent, all refused by the host (nothing came back): "Quartzline company values"; "Quartzline interview process product manager"; "Quartzline partner API platform strategy news".

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Would have fixed whether a values cheat sheet applies. None was built, and no values-style round is detected |
| 2. `Quartzline interview process product manager` | unavailable | Would have documented the wider loop. Your own words fix this session: one conversation with the hiring manager |
| 3. `Quartzline partner API platform strategy news` | unavailable | Would have grounded B5 and D2, which are generic instead |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewer's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their path
- The recruiter's prep email or any process details → the assumed coverage replaced by what they say will be probed
- Search access for Quartzline's public pages, or a pasted strategy or values page → B5 and D2 move from generic to grounded. A deeper research pass is also available: up to 6 more searches and 2 more fetches, several more minutes
- The artifact behind the roadmap-input sessions, such as an agenda, a deck or notes → V3 can move from medium confidence, and C3 and F2 get a firmer base
- Anything in your own words about API docs or schemas, working with engineering and sales, or agile delivery → F3, F4 and F5 regenerate, and their slots become stories
- Any change since the dossier of 2026-08-14 → the affected rows regenerate
