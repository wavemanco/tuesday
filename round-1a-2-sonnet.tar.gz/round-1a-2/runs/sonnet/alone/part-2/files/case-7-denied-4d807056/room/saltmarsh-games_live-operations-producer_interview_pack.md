# Interview prep pack: Live Operations Producer, Saltmarsh Games

- **Role:** Live Operations Producer, Saltmarsh Games (mobile game studio)
- **Candidate:** Femi
- **Interviewer:** Tobias Wrenfield, Head of Live Operations (title as you gave it)
- **Relationship:** assumed hiring manager. Your note did not say whether the role reports to him, so persona weights follow the hiring-manager prior. If that is wrong, the banks reweight.
- **Format:** one 60-minute interview on Friday

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Every question carries one persona (its bank), one type, a provenance label and the sentences of yours its guidance rests on.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows a value, as a specific decision |
| EXP | Whether a line of your background survives a follow-up, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and its field |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script. All wording in it is proposed, pending your approval, and is meant to be said in your own words. Answer slots are instructions for the interview: say which branch is true for you. Both branches are acceptable, and the second is never a confession.

**The highest-ROI prep in this pack is B1 and its three follow-ups.** It lands on the two gaps you stated yourself. Rehearse it aloud until it is boring.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [inferred] | discovery | Your material shows four years as an associate producer and two years on the weekly calendar. It does not show how the title's content ran in the first two years, and a 3+ line is likely to be checked against the number. Words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: say what the title's content schedule looked like in the first two of the four years, in your own words; if it had none, or it was not yours, say so plainly and stay with the last two years |
| F2 | "plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Words: "I ran the weekly content-drop calendar for our main title for the last two years." Your material says one title and content drops. The JD says two titles and live events, and your material does not say whether the title was on mobile. Answer slot: if any of the drops were time-limited events in your studio's terms, or the title was on mobile, say so in your own words; if not, say so plainly and stay with the weekly calendar for one title |
| F3 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | The calendar sentence touches this requirement without showing whom you worked with. Answer slot: say which of those teams you worked with on drops and what you coordinated with each, in your own words; if someone else coordinated them, or you worked with only some, say so plainly and stay with the calendar you ran |
| F4 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Words: "I presented the monthly retention numbers to the studio head." Your material says presenting, not reviewing events or owning KPIs. Answer slot: if you also produced, chose or reviewed those numbers, say so in your own words; if they came from someone else, or no event review existed, say so plainly and stay with presenting them |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Words: "I wrote the release checklist our QA team still uses." Your material says wrote, and that QA still uses it, with nothing inspected behind it, so expect a probe. Answer slot: if you ran releases against it with QA, say how, in your own words; if QA ran them, or it was not a process you ran, say so plainly and stay with having written it |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: you ran it, weekly, for the last two years, because a named record beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in terms, but expect a probe on which measures were in the numbers. Lead with what the sentence names: monthly, retention, to the studio head |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | One written document another team uses, and nothing else in your material about writing. Answer slot: name any other written material you produced, in your own words; if the checklist is the only one, say so plainly and stay with it |
| F9 | [generic] Role-family reading, not a JD line: event planning around in-app purchases | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F10 | [generic] Role-family reading, not a JD line: leading people. The JD's own word is coordinate (F3) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap you have stated. Words: "I haven't led a team." Then how you would work across the four teams, said as a plan and never as a past |

No row is a hard gate: the JD's 3+ years is a length-of-experience line, graded as a requirement and not a gate.

## Persona table

Weights rest on the hiring-manager prior and your own description of the round. No research on the company, its loop or the interviewer could run (see Sources), so nothing here comes from Saltmarsh material.

| Persona | Bank | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | A (5) | high: the hiring-manager prior puts it first, and the JD is a planning-and-running role with live problems built in (F2, F3, F5) | Clarify, objective, segmentation, approach, metrics, risks, thinking aloud; challenge one premise respectfully |
| Skeptic | B (4) | high: the hiring-manager prior puts it second, and you have stated two gaps (F9, F10) and the JD's years line needs checking (F1) | Rehearse B1 until boring; bridge only from your stated sentences, and say the limit plainly |
| Data-Driven Prober | C (3) | medium: the JD names retention metrics and KPIs (F4, F7) and you present retention monthly | Say what you know about how numbers were counted and say plainly what you do not; name the assumption you would defend least before being asked |
| Conversational | D (3) | medium: any 60-minute round opens conversationally, and those questions are still scored | A 90-second arc from your own sentences; treat casual JD-topic questions as scored |
| Pressure | E (2) | low: the hiring-manager prior does not lead with it and nothing in your material signals it | Pause, restate, hold through two follow-ups, concede specifically |
| Values/Behavioral | G (2) | low: no values-style round is detected and no Saltmarsh values are in hand, so these use generic stems | Selection criteria with the honest branch |
| Peer Evaluator | H (2) | low: Tobias is the head of the function, but the JD's cross-team coordination (F3) invites collegial seam questions | Offer seam principles, not a claim to know the studio's actual seam |

## Question banks

Wording below is proposed, pending your approval.

### Bank A: Case/Strategist (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Day-7 retention on one of our titles has dropped 20% since the last update. What do you need to know first, and what do you do with the calendar while you find out?" | CASE | [generic] | Clarify before structuring: what shipped in the update, which player cohorts moved, whether the drop is across platforms or one. State an objective (find the cause, or protect the next drops). Segment by cohort and by what each cohort saw. Say whether you would hold or keep the next drop, and why. Name the measures you would watch and the risk of acting on thin data. Challenge one premise aloud: is the 20% real, or a reporting artefact? The question needs no claim about your past, so the guidance makes none | A live problem from the JD's retention line (F7) that puts the calendar (F6) at stake. CASE because it scores structure; generic because it is a pattern for the problem |
| A2 | "Two of our titles want the same event slot in week three, and they share a design team. How do you decide?" | CASE | [generic] | Clarify capacity, each event's objective and dependencies. Set decision criteria before looking at either title. Say what data you would want. Decide, and say the trade-off in writing to all four teams. Concede what you could not know without the studio's own data. No claim about your past | The JD's two-title scope is where your material is one title (F2). CASE lets you rehearse the scope jump without claiming it |
| A3 | "On Tuesday QA tells you the build for Thursday's event crashes on one family of devices. Walk me through the next 48 hours." | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Severity and reach first. Then the options: ship with a fix, ship without the event feature, or slip. Say who decides and who must be told (QA, engineering, community). Say what you would write down afterwards. You may say you wrote the release checklist QA still uses and no more than that sentence says. The scenario itself claims nothing about your past | JD's release-checklist-with-QA line (F5), asked as a decision. CASE delivery over a JD requirement |
| A4 | "Sketch a post-event review for an event that ran two weeks. What is on the first page, and what decision does it end with?" | CASE | [generic] | State the event's objective before any number. Say which measures were chosen up front and what they are compared with. Say what the numbers cannot tell you. End with a decision (repeat, change, drop) and an owner. Write it so a reader outside the team follows it. No claim about your past | The JD makes the post-event review and its KPIs the role's own (F4). Asked as a live problem because your material is on the presenting side |
| A5 | "Community tells you players dislike the reward from last week's event. Engineering says it cannot change before the next drop. What do you do?" | CASE | [generic] | Separate what is known from sentiment. List the options and say what each team owns in each. Say what you would tell players, through community, and when. Say what you would record for the review, and what you would take to Tobias versus decide yourself. No claim about your past | JD coordination line (F3), where your material is silent. CASE because it scores how you work across disciplines without needing a past example |

### Bank B: Skeptic (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | Level 1: "Which part of this job would you be weakest at on day one?" Level 2: "You have told us you have not worked on a game with in-app purchases. How much does that matter for this job?" Level 3: "If it takes you six months to be useful on that side, is that a risk we should take?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." | Level 1: pick the gap you weigh as heavier for this role and say it in your stated words: "I haven't worked on a game with in-app purchases" or "I haven't led a team." Then a plan, not a past: what you would learn first, from whom, by when, chosen from what you would actually do. Level 2: say what you know about how this job leans on it; if you do not know yet, say so plainly and say how you would find out. Level 3: hold to what your two sentences say (the weekly calendar for the last two years, the monthly retention numbers to the studio head) and concede plainly that they do not cover the gap. Do not promise a timeline you cannot back, and do not widen either sentence to close the gap | F9 and F10 are the two gaps you stated, so a day-one stem is likely to land on one. The pack infers that this is the most likely objection; the JD does not mention in-app purchases, and that is exactly why the question is to be rehearsed to boring. JD because it scores fit to the listed job |
| B2 | "You have never led a team, and this role coordinates design, art, engineering and community on every update. Why should we trust you with that?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Start with the plain acknowledgment: "I haven't led a team." Note aloud that the JD's word is coordinate. Answer slot: if you coordinated those disciplines on drops, say with whom and how, in your own words; if you did not, or someone else did, say so plainly and stay with the weekly calendar you ran. Then your plan for working across the four teams, as a plan | F10 and F3 together. The JD raises coordination, your material states the limit on leading; JD because the question tests the listed duty |
| B3 | "The JD asks for 3+ years producing live-service games or apps. Your calendar work is two of your four years. Walk me through the other two." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Say the four years and the two years in those terms. Answer slot: say what the title's content schedule looked like in the first two years, in your own words; if it had none, or it was not yours, say so plainly and stay with the last two years. Hold through the follow-up by returning to the sentences, never by adding to them | F1 is a years line that is likely to be checked against the number; the gap is one of discovery. JD because it scores the stated requirement |
| B4 | "Why this role, and why now?" | JD | [generic] | Selection criteria: choose one reason that is true for you and tied to a line of the JD in its own words, and one about what you want next. If no clear reason comes to mind, say so plainly, then say what you do know about what you want next. Prepare the unasked version too: why leave your current studio | A standard Skeptic motivation probe from the persona stems. JD because it scores fit to the posting; generic because no sentence of yours carries a reason |

### Bank C: Data-Driven Prober (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers to the studio head. Which measures were in them, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say which measures, in your own words. Answer slot: if you built or chose the figures, say how; if you presented figures someone else produced, or you do not know how one was counted, say so plainly and stay with presenting them monthly to the studio head. Name the assumption behind the numbers you would defend least only if you know one; no figure has been given, so none is supplied here | F7 is stated and graded none, but a stated line is exactly what a Prober tests. EXP because it tests what you did |
| C2 | "Players who joined during an event retain well to day three, then flatten. What would you check before calling the event a success?" | CASE | [generic] | Compare against players outside the event; separate a novelty bump from a lasting change; ask how many players and over what window; say what you could not conclude. Then the weakest-assumption move: name the assumption in your own read that you would defend least, before the interviewer does. No claim about your past | JD's KPI line (F4) as a live problem. CASE because it scores reasoning from a metric; generic because it is a pattern |
| C3 | "Walk me through how you ran the weekly content-drop calendar." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Beats the sentence carries: weekly, content drops, your main title, the last two years, told in your own words. Answer slot: the JD's calendar lines make a probe on how drops were chosen and sequenced likely; if you chose or sequenced them, say how; if the contents were set by others, or there was no such step, say so plainly and stay with running the weekly calendar | F6 closes cleanly on paper, so this is the likeliest place a probe lands. EXP because it tests what was actually yours |

### Bank D: Conversational (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc in your own words using only those four sentences, in that order: four years as an associate producer at a puzzle-game studio; the last two running the weekly content-drop calendar for your main title; the release checklist QA still uses; the monthly retention numbers to the studio head. Close with one sentence on why this role, true for you | F1, F5, F6 and F7 together; a casual opener that is still scored. EXP because it is your biography under scrutiny |
| D2 | "What are you actually playing with in live-service mobile these days?" | CO | [generic] | Selection criteria: name a game you actually play, one thing about its event rhythm you noticed, and one thing you would question. If you do not play live-service mobile games, say so plainly, then say what you have studied or how you would learn in your first weeks | The JD's mobile-title wording (F2) asked casually. CO because it scores field knowledge; generic because no company research was possible |
| D3 | "Tell me about the release checklist you wrote for QA." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Beats the sentence carries: you wrote it, and QA still uses it. Do not explain why they still use it unless you can say so in your own words. Answer slot: the JD asks you to manage it with QA; if you ran releases against it with QA, say how; if QA ran them, or it was not a process you ran, say so plainly and stay with having written it | F5 is your strongest artefact and the likeliest to be probed. EXP because it tests attribution |

### Bank E: Pressure (weight low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a producer who has run two live titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." "Wrote the release checklist our QA team still uses." "Never led a team, and never worked on a game with in-app purchases." | Pause and restate. Hold to what the three sentences say (the weekly calendar, the monthly retention numbers, the checklist QA still uses). Concede two things plainly: "I haven't led a team, and I haven't worked on a game with in-app purchases." Hold through two follow-ups without widening any sentence, and never claim two titles | F2, F9 and F10. JD because it scores fit under pressure; the position held is only what your sentences carry |
| E2 | "That retention reporting. How much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say which part was yours in your own words; if the numbers came from someone else, or you do not know how they were produced, say so plainly and stay with presenting them. Hold the sentence's scope through the follow-up, and concede specifically where it ends | F4 and F7 are about presenting, so this is the attribution probe in its pressure form. EXP because it tests attribution |

### Bank G: Values/Behavioral (weight low)

No published Saltmarsh values are in hand and no values-style round is detected, so these use generic stems and are not mapped to the company's values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection criteria: pick a time the message was unwelcome; name what was said, to whom, and what happened next, with "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I presented the monthly retention numbers to the studio head," at its own scope, or how you would handle it | A persona stem; your nearest sentence is the retention presentation (F4). VAL because it scores a decision, not a trait |
| G2 | "When did you put a player's experience ahead of an internal metric?" | VAL | [generic] | Selection criteria: pick a decision with a named stake, the metric you set aside, and what you would say about the result. If no such time comes to mind, say so plainly, then say how you would weigh it | A persona stem for a values conversation. Generic because no sentence of yours carries it |

### Bank H: Peer Evaluator (weight low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Design wants a bigger event than engineering can build in time. Where does the producer sit in that, and what happens when you disagree with me about it?" | CASE | [generic] | Offer seam principles and not a claim to know this studio's seam: who owns scope, who owns the date, who makes the trade-off call. Say how you would disagree with spine and tact, and what you would bring to the team, not only what you would need | JD coordination line (F3). CASE because the question is a live seam problem |
| H2 | "How do you write an update plan so that design, art, engineering and community all read the same thing?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Say how you would check each team read it the same way, in your own words. You may cite the checklist at its own scope: you wrote it, and QA still uses it. Answer slot: name any other written material you produced; if the checklist is the only one, say so plainly and stay with it | F8, where your material has one written artefact. JD because it scores the written-communication line |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| 3+ years producing live-service games or apps | B3, D1, E1 |
| Plan and run the live-events calendar for two mobile titles | A2, C3, D2 |
| Coordinate design, art, engineering and community on each update | A5, B2, H1 |
| Own the post-event review and its KPIs | A4, C2, E2 |
| Manage the release checklist with QA | A3, D3 |
| Experience running a content calendar | C3, D1 |
| Comfortable with player-retention metrics | A1, C1, C2, E2 |
| Clear written communication | H2 |
| Company strategy (CO) | — none, research could not run |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| 1 | "What would a good first 90 days look like for the producer on each of the two titles, and what would you want to see by day 30?" | Shows you are planning the ramp, and it turns your day-one answer (B1) into a shared plan |
| 2 | "How are live events decided today: who proposes them, who approves them, and where does the producer sit in that?" | Tests the seam in the JD's coordination line (F3) before you are inside it |
| 3 | "How does the post-event review reach decisions: who reads it, and can you give an example of one changing the next calendar?" | Ties to the JD's review-and-KPI ownership (F4) and shows you care about the decision, not the report |
| 4 | "How do the titles' business models shape the live calendar, and how would you onboard a producer who hasn't worked on a game with in-app purchases?" | Raises your stated gap (F9) on your terms, as a plan conversation |
| 5 | "How do design, art, engineering and community hand work to each other on an update today, and where does it stick?" | Names the four disciplines in the JD's own words and asks about friction, which is where a producer is useful |
| 6 | "What separates a producer who is thriving here at six months from one who is struggling?" | Asks for the bar in his words, and lets you check your plan against it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the live-events calendar for two titles | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says one title and content drops |
| Produced live-service games for three or more years | Inflated form of F1 | F1's quotes at their own scope. The material shows four years as an associate producer and two on the calendar |
| Coordinated or led design, art, engineering and community | Inflated form of F3; negative you stated, F10 | The plain acknowledgment F10 gives: "I haven't led a team." Nothing claims coordination beyond your calendar sentence |
| Has in-app-purchase experience | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot |
| Owned the retention analysis or defined KPIs | Inflated form of F4 and F7 | F4's quote at its own scope: you presented the numbers. The limit is the pack's observation |
| Managed releases with QA | Inflated form of F5 | F5's quote at its own scope: you wrote the checklist QA still uses |

## Sources

Provided: the JD you pasted, your background as you wrote it in your message, and the interviewer's name and title from your message. No dossier was present.

Searches sent (all refused, nothing returned):

- "Saltmarsh Games values" — refused
- "Saltmarsh Games interview process live operations producer" — refused
- "Saltmarsh Games mobile studio strategy news" — refused
- "Tobias Wrenfield Saltmarsh Games" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Would have moved the values cheat sheet and the VAL bank; both are absent or generic |
| 2. Saltmarsh Games interview process | unavailable | Would have moved persona weights; they rest on the hiring-manager prior and your own description of a single 60-minute round |
| 3. Saltmarsh Games strategy and recent news | unavailable | Would have moved the CO and CASE grounding; those questions are generic and there is no grounding brief |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Would have moved the interviewer read, persona weights and a tailored reverse question; all three are absent |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access in this session → the default research pass (values, loop, strategy, Tobias's public footprint) would turn the generic VAL and CO rows into researched ones, and a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) could add a strategy brief
- Saltmarsh's published values or careers page, pasted → a values cheat sheet and grounded VAL guidance
- Tobias's public profile or talks, pasted → a reading-the-interviewer section, reweighted personas and a reverse question tied to his own path
- Whether the role reports to Tobias, and any recruiter notes on focus areas or a pre-declared exercise → persona weights corrected, and a build section for any deliverable
- Your answers to the slots in F1, F2, F3 and F4, stated plainly, including whether the main title was on mobile → those rows move from discovery or transferability to graded rows
- The release checklist itself, a content-drop calendar, or a retention report you presented → F5, F6 and F7 can rise from medium to high, and F8 gains a written sample
- How many hours you have before Friday → a prioritized prep schedule
- A `tuesday-dossier.md` → verified evidence, an evidence-derived top objection and a per-gap strategy limit
