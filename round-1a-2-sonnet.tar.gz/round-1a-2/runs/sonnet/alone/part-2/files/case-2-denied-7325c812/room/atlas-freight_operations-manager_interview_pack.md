# Interview prep pack: Operations Manager, Atlas Freight

- Role: Operations Manager, Atlas Freight (regional logistics, 800 employees)
- Interviewer: not known. Relationship and round type: not known, so persona weights are flat and the pack covers the full range of styles.
- Built from: the job description text you pasted and your background message. Web research was blocked in this session (see Sources), so nothing here is a fact about Atlas Freight beyond what the JD says.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Question IDs are letter-by-persona: A Skeptic, B Data-Driven Prober, C Pressure, D Case/Strategist, E Conversational, P Peer Evaluator, V Values/Behavioral. Fit-snapshot rows are F1 to F8.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: whether past behavior shows the values asked about |
| EXP | Work-experience deep-dive: whether your claims survive scrutiny and what was actually yours |
| JD | Role and JD-driven: whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge: homework and reasons for choosing this company |
| CASE | A live problem from the actual role, asked on the spot |

Guidance is scaffolding, not a script: say it in your own words. An answer slot is an instruction for the interview, not a question for anyone now. It gives two honest branches, and either one is a good answer. The first branch is what you did, in your own words. The second is saying plainly that there was no such step or it was not yours, then returning to what your material does say.

## Prep triage

You said the interview is next week, so this is sized to about a week. Do these in order. Everything else is insurance.

| Order | Do this | Where |
|---|---|---|
| 1 | Rehearse the scope step-up question aloud until it is boring: hold, concede, plan | A1 |
| 2 | Write out your own answers to the answer slots, one short paragraph each, starting with F7, F2 and F3 | Fit snapshot F1 to F8 |
| 3 | Rehearse defending the 40% mis-pick figure, including what part was yours | B1, B2, C2 |
| 4 | Say each of the four case answers aloud, five minutes each, thinking aloud | D1 to D4 |
| 5 | Prepare a 90-second journey and a plain one-line answer on Power BI | E1, E2, A3 |

## Fit snapshot

Requirement quotes come from the JD you pasted. Evidence quotes are your own words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says a senior shift manager over 3 supervisors and a surge plan run two years, not terminal operations across sites, and the words stay at that scope: "I'm currently a senior shift manager over 3 supervisors, and I ran the site's peak-season surge plan two years running." These are message lines with nothing inspected behind them, so expect a probe. Answer slot: the JD's 4 sites make a probe on multi-site scope likely. If any of your work reached beyond the site's own operations, say what it was and what part was yours, in your own words; if none did, say so plainly and stay with the senior shift manager role and the surge plan |
| F2 | "drive on-time performance and cost-per-shipment down" — JD (the on-time performance half) | none given | none | [grounded] | discovery | Your material does not show on-time performance. Answer slot: the JD names on-time performance, so a probe is likely. If you tracked on-time performance, or a figure close to it, on your shifts or during either surge, say what it was and what part of any change was yours, in your own words; if you did not track it, or it was not yours, say so plainly and say what you would look at first in your first weeks, as a plan |
| F3 | "drive on-time performance and cost-per-shipment down" — JD (the cost-per-shipment half) | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material says a mis-pick rate cut by redesigning the pick path, not a cost per shipment, and the words stay there: "I cut mis-pick rate 40% by redesigning the pick path." It is a message line with nothing inspected behind it, and the only quantified claim you gave, so expect a probe on how it was counted. Answer slot: the JD's cost-per-shipment makes a probe on cost likely. If any cost was tracked alongside the mis-pick work, say what and how, in your own words; if none was, or it was not yours to track, say so plainly and stay with the mis-pick rate |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says 3 supervisors where the JD says 12, and the words stay at 3: "I'm currently a senior shift manager over 3 supervisors." It is a message line with nothing inspected behind it, so expect a probe. Answer slot: if you have led or coordinated supervisors beyond those 3, in any role or setting, say who and what your part was, in your own words; if not, say so plainly and stay with the 3 |
| F5 | "build reporting in Excel/Power BI" — JD (the Excel half) | "solid Excel" — your message | low | [inferred] | discovery | "solid Excel" names the tool and not reports built in it, and the words stay there. Answer slot: if you have built reports in Excel, say what they covered and who read them, in your own words; if what you did in Excel was not reporting, say so plainly and stay with "solid Excel" |
| F6 | "build reporting in Excel/Power BI" — JD (the Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to dashboards or reports in it, and nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message | low | [inferred] | discovery | The quote gives 7 years in warehouse and distribution ops. It does not say how many of those years carried leadership, so the words stay at "I have 7 years in warehouse and distribution ops." Answer slot: say how many of those years carried responsibility for supervisors or a shift, and in which roles, in your own words; if the part that carried leadership is shorter than the JD's requirement, say so plainly and stay with the seven years and your current role |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [inferred] | discovery | The quote does not name the scheme, so the words stay at "I'm green belt certified." A certificate is the inspectable artifact here, and nothing has been inspected yet. Answer slot: if the certification is in Lean or Six Sigma, say which and who issued it, in your own words; if it is another scheme, say so plainly. If you have applied it since, say where and what your part was; if you have not, say so plainly and stay with the certification |

No row is a gate: the JD's 5+ years is a length-of-experience requirement, so F7 is graded like any other row.

## Persona table

Relationship and round type are unknown and no source documents the loop, so the relationship priors cannot set weights: the fallback is the generic archetype (screen, hiring manager, panel) with flat weights. Depth differs only where your fit snapshot or the JD pulls it: Skeptic and Case/Strategist get four questions because F1, F4 and F6 are the biggest gaps and the JD is an operating role. Values/Behavioral gets two because the generic archetype has no values-style round. Tell me who you are meeting and I will reweight.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet, persistent probing of the gaps: scope, background, why here, why now | Flat prior, depth 4: F1, F4 and F6 are where the material is thinnest against the JD | Rehearse A1 until it is boring; bridge only from what your quotes say; give the plan after the plain statement |
| Data-Driven Prober (B) | Reads your lines one by one, asks for how the number was counted | Flat prior, depth 4: F3 holds the only figure and F7 holds a titled-years requirement | Know what you can and cannot say about how the 40% was counted; say plainly when you do not know |
| Pressure (C) | Interrupts, time-boxes, tests attribution | Flat prior, depth 3: no signal either way | Pause, restate, hold two follow-ups, concede only what is specific |
| Case/Strategist (D) | Live problems from the role: diagnose, plan, design | Flat prior, depth 4: the JD is an operating role with named measures | Clarify, objective, segment, approach, metrics, risks; think aloud |
| Conversational (E) | Friendly, chatty openers, casual questions about the JD's listed skills | Flat prior, depth 3: no signal either way | Prepare the 90-second arc; treat casual questions on Excel, Power BI and Lean as scored |
| Peer Evaluator (P) | Seam-splitting and credit questions, collegial packaging | Flat prior, depth 2: relevant only if a peer is in the loop | Reciprocity first; offer principles rather than claims |
| Values/Behavioral (V) | Behavioral prompts, STAR-shaped stories | Flat prior, depth 2: no values-style round is detected under the fallback archetype | Choose a story where the hard truth landed; if none comes to mind, say so |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're over 3 supervisors today, and this role leads 12 across 4 sites. What's the step up?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI prep in this pack. Level 1, hold: "I'm currently a senior shift manager over 3 supervisors." Concede the arithmetic plainly and specifically: "Twelve is more than the three I'm over today." Do not widen the three, and do not describe leading a larger team. Level 2, expect "What would you do differently with twelve?" Answer as a plan in the future tense: what you would learn about each site and each supervisor before changing anything, and what you would measure first, in your own words. Level 3, expect "What if it doesn't work?" Say what you would watch for and who you would ask, as a plan. Answer slot: if you have led or coordinated supervisors beyond those 3, in any role or setting, say who and what your part was, in your own words; if not, say so plainly and stay with the 3 | F4 and F1 hold the largest distance between the JD's scope and the material, so this objection arrives in some form in any round. JD because it scores the stated lead-12 requirement, and the Skeptic asks it quietly, which is why it gets the most follow-up levels |
| A2 | "Your background is warehouse and distribution, and this role owns terminal operations. How does one carry into the other?" | JD | [grounded] "7 years in warehouse and distribution ops" | Hold: "I have 7 years in warehouse and distribution ops." Then say what from that work you would bring to running a terminal day to day, naming only things you did. Answer slot: if you have worked in or alongside terminal operations, say where and what your part was, in your own words; if you have not, say so plainly and stay with warehouse and distribution. Close with a plan, not a past: how you would learn each terminal's daily rhythm in your first weeks | F1 and F7 are where the role's scope presses on the material. JD because it scores the terminal-operations requirement |
| A3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Choose one gap you can name exactly and say it without padding. The material carries one stated gap: "I have never used Power BI." Follow it at once with a plan in the future tense: what you would learn first, how, and by when, in your own words. Answer slot: if another requirement is weaker for you than that one, such as the 12 supervisors, the 4 sites or cost-per-shipment, say which plainly and say what you would do about it first; if not, stay with Power BI. Do not name a gap you cannot describe precisely | F6 is the one gap you stated, and F1, F3 and F4 are rows where the material is adjacent or silent. JD because the question tests the whole requirement list at once |
| A4 | "Why this role, why Atlas Freight, why now?" | CO | [generic] | Give your real reasons in your own words: the pack has none from you, so it supplies none. Answer slot: say what draws you to this role, what draws you to Atlas Freight, and why now; if one of the three has no honest answer yet, say so plainly rather than inventing one. Name only what you have read about Atlas Freight yourself, since the pack holds no company facts | Motivation consistency is what the Skeptic scores. CO because the Atlas Freight part is where a generic answer shows; generic because research was blocked |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the sentence: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: say how the 40% was counted, what it is most sensitive to, the assumption behind it you would defend least (name it before the interviewer does) and which part was yours, each in your own words; if you do not know how it was counted, say so plainly. Never add a baseline, a period or a method you cannot repeat under a second question | F3 holds the only quantified claim, and probers go to figures first. EXP because it tests whether the figure survives a counting question |
| B2 | "What did the pick-path redesign change, and which part of it was yours?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Tell it in the sentence's own terms: the pick path was redesigned and the mis-pick rate fell 40%. Answer slot: if others contributed to the redesign, say what was theirs and what was yours, in your own words; if it was yours alone, say so plainly; if you do not remember the split, say that. Do not add steps, tools or approvals the sentence does not carry | F3 again, from the attribution side. EXP because it scores what was actually yours |
| B3 | "The role is measured on on-time performance and cost-per-shipment. What did you track on your shifts?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you tracked on-time performance, cost or anything close to either on your shifts, say what, how often and what you did with it, in your own words; if you tracked neither, or it was not yours to track, say so plainly and stay with the mis-pick rate: "I cut mis-pick rate 40% by redesigning the pick path." Then, as a plan, say which of the two you would put on a daily view first and why | F2 and F3 are the rows with no or adjacent evidence. JD because the two measures are the JD's headline |
| B4 | "The JD requires 5+ years of operations leadership. How many of your seven years carried responsibility for people?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Hold: "I have 7 years in warehouse and distribution ops." Answer slot: say how many of those years carried responsibility for supervisors or a shift, and in which roles, in your own words; if the part that carried leadership is shorter than the JD's requirement, say so plainly and stay with the seven years and your current role: "I'm currently a senior shift manager over 3 supervisors." Never round the number up or describe years you cannot name a role for | F7 is a titled-years requirement that the material answers only at the seven-years level. JD because it scores the stated requirement, in the prober's line-by-line register |

### C. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over someone who has run several sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | Pause and restate the question in one clause. Concede only what the question itself states: "I can't speak to their record. Here is mine." Then hold what your quotes carry, in order: "I ran the site's peak-season surge plan two years running" and "I'm currently a senior shift manager over 3 supervisors." Hold through two follow-ups by returning to those two sentences, never by adding to them. Answer slot: if there is a third thing you have actually done that bears on the role, say it in your own words; if there is not, stop at the two | F1 and F4 in the Pressure persona's time box. JD because the answer scores fit against the role as written |
| C2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause, then hold the claim as the sentence has it: "I cut mis-pick rate 40% by redesigning the pick path." Hold through two follow-ups. Concede only what you know, and where the split between you and others is uncertain, say that specifically. Answer slot: if others contributed, say what was theirs, in your own words; if the redesign was yours, say so plainly; if you do not know how much of the 40% came from the redesign itself, say that plainly | F3's attribution probe in the Pressure register. EXP because it scores precision under challenge |
| C3 | "You ran the surge plan twice. What's your evidence it worked?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Hold: "I ran the site's peak-season surge plan two years running." Answer slot: the JD makes on-time performance the likely yardstick. If you tracked on-time performance or another result during either surge, say what it was and what part was yours, in your own words; if you did not track one, or it was not yours, say so plainly and stay with the sentence. Never describe an outcome you did not see | F1's surge-plan quote has no outcome attached, which is where a pressure interviewer pushes. EXP because it tests what you can show |

### D. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "On-time performance at one of your four terminals has dropped sharply over two weeks. Diagnose it." | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Clarify first: what on-time means here and how it is measured, what changed in the two weeks, whether the drop is at one site or all. State the objective. Segment: by site, by shift, by lane or customer. Approach: compare with the same weeks before and look for the one change that lines up with the drop. Metrics: what you would watch daily. Risks: a fix that moves the problem elsewhere. Challenge one premise respectfully, for example whether two weeks is enough to call a trend | A live problem from the JD's on-time performance line, which is F2's requirement, asked as a decision. Generic because it is a pattern for the problem, not a fact about the employer |
| D2 | "Cost-per-shipment is rising at one terminal while on-time performance holds. Where do you look?" | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Clarify first: how cost-per-shipment is built here and which costs sit in it. Then split the movement: is the cost going up, or the number of shipments going down? Segment by site and shift, state your approach, name the metrics, and name the risk that cutting a cost damages service. Think aloud and say which assumption you would check first | A live problem from the JD's cost-per-shipment line, which is F3's requirement. Generic because it is a pattern, not a fact about the employer |
| D3 | "Suppose you start Monday with 12 supervisors across 4 sites. What do your first 30 days look like?" | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Structure it as a plan: what you need to know first, what you will deliberately not change yet, who you meet and what you ask each, what you measure from week one, and what you report at day 30. Say it in the future tense throughout | A live problem built from F4 and F1's requirements, so the scope step-up from A1 gets rehearsed as a plan. CASE because it asks for structure, not history; generic for the same reason |
| D4 | "Design the weekly report you'd give me for the four terminals: what's on it, and what would you build it in?" | JD | [grounded] "solid Excel"; "never used Power BI" | Structure the report before the tool: who reads it, what decision each line supports, then the lines, with on-time performance and cost-per-shipment by site first since the JD names both. On the tool, hold "solid Excel" in those terms and say "I have never used Power BI." Answer slot: if you have built a report in Excel, say what it covered and who read it, in your own words; if what you did in Excel was not reporting, say so plainly and stay with "solid Excel". Close with a plan, not a past: how you would build the first version in Excel and when you would learn Power BI | F5 and F6 are the reporting requirement. JD content with CASE delivery, so it is tagged JD because it scores the listed requirement |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | A 90-second arc with two fixed points, said in your own words: the start, "7 years in warehouse and distribution ops", and the present, "currently a senior shift manager over 3 supervisors". Answer slot: the quotes give the start and the present, not what lay between. If there were roles or moves in between, name each and what was yours, in your own words; if there were none, say so plainly and tell the two points as they stand. End on why this role, in your own words, with no reason the pack supplied | F7 and F4 are the two rows the arc has to carry, and this is the question a conversational round opens with. EXP because it is your background told aloud |
| E2 | "What are you actually playing with in Excel or Power BI these days?" | JD | [grounded] "solid Excel"; "never used Power BI" | Casual register, scored all the same. Say plainly where you are with each: "solid Excel" for the one and "I have never used Power BI" for the other, then what you intend to do about it as a plan. Answer slot: if you use Excel for reporting these days, say what for, in your own words; if you do not, say so plainly and stay with "solid Excel". Do not describe a dashboard you have not built | F5 and F6 asked casually. JD because it scores the listed tools, and Conversational because it arrives as small talk |
| E3 | "What are you actually playing with in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Say it plainly: "I'm green belt certified." Answer slot: the JD lists Lean/Six Sigma as a plus. If the certification is in Lean or Six Sigma, say which, in your own words; if it is another scheme, say so plainly. If you have applied it since, say where and what your part was; if you have not, say so plainly and stay with the certification | F8 is the row with the most upside for a plus. JD because it scores the listed plus, and Conversational because it arrives casually |

### P. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "How do you handle credit when work spans teams?" | VAL | [generic] | This asks how you handle credit, not what happened. Describe your practice in your own words, "we" for context and "I" for contribution, and name only a practice you actually follow. Answer slot: if a real instance comes to mind, tell it with who did what; if none does, say so plainly and say how you would handle it. For the pick-path work, use B2's slot rather than repeating it here | Peer evaluators probe partnership and credit. VAL because it scores behavior rather than a figure; generic because the pack holds no fact on this |
| P2 | "What would you bring to our team, and what would you need from us in your first month?" | JD | [generic] | The question needs no claim about your past, so the guidance makes none. Reciprocity first: what you offer before what you ask. Offer principles, such as how you would work across the sites and keep the other managers informed, and ask for concrete first-month access in your own words | The seam between a 4-site operations role and its neighbours is the JD's own shape, from F1's requirement. JD because it scores how you would work in the role; generic because it is a pattern |

### V. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, a moment you did not soften the message, and a working relationship still intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A stem from the Values persona. VAL because it scores behavior; generic because no company values were available |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time with a named customer need, the internal metric you gave up, and what followed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A stem from the Values persona, and a natural one for a role measured on on-time performance. VAL because it scores behavior; generic because no company values were available |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Own daily terminal operations across 4 sites | A1, A2, C1, D1, D3 |
| F2 on-time performance | B3, C3, D1 |
| F3 cost-per-shipment | B1, B3, D2 |
| F4 lead a team of 12 supervisors | A1, C1, D3 |
| F5 reporting in Excel | D4, E2 |
| F6 Power BI | A3, D4, E2 |
| F7 5+ years operations leadership | B4, E1 |
| F8 Lean/Six Sigma a plus | E3 |

## Reverse questions

No interviewer profile exists, so none is tied to an interviewer's path. P2's mirror is item 6.

| # | Question to ask them | Why it lands |
|---|---|---|
| 1 | "Which of on-time performance and cost-per-shipment is under more pressure across the four sites today, and what would a good year look like on each?" | The JD names both measures, so asking where the pressure is shows you think in the scorecard |
| 2 | "How are the 12 supervisors spread across the four sites, and where is the team strongest and thinnest?" | It addresses the span-of-control gap by asking about it, which is a sign you are planning for the step up |
| 3 | "What does reporting look like today, what is built in Excel, what is in Power BI, and who owns it?" | It meets the Power BI gap with curiosity and no claim, and it tells you what you would inherit |
| 4 | "What would you most want a new Operations Manager to have changed by day 90?" | It turns the interview toward the first 90 days, the same ground as D3 |
| 5 | "What is the hardest daily operating problem across the four sites right now?" | It lets you test your D1 and D2 diagnoses against a real problem |
| 6 | "What could a new person do in the first month that would genuinely help your team?" | Use it if the interviewer turns out to be a peer: it gives the reciprocity a peer is scoring |

## Prohibited claims

Claims this pack will not coach, built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned terminal operations across multiple sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says a senior shift manager over 3 supervisors and a surge plan, not terminal operations across sites. The slot stays inside that scope |
| Designed the peak-season surge plan | Inflated form of F1 | "I ran the site's peak-season surge plan two years running" at its own scope. The material says ran, not designed |
| Led a team of 12 supervisors | Inflated form of F4 | "I'm currently a senior shift manager over 3 supervisors" at its own scope. The A1 slot asks only about work beyond those 3 |
| Reduced cost per shipment | Inflated form of F3 | "I cut mis-pick rate 40% by redesigning the pick path" at its own scope. The material says a mis-pick rate, not a cost per shipment |
| Built operations reporting in Excel | Inflated form of F5 | "solid Excel" at its own scope. The material names the tool, not reports built in it |
| Has used Power BI or built dashboards in it | Negative you stated, F6 | The plain acknowledgment F6 gives: "I have never used Power BI." Then a plan, never a past. No slot |
| Has 5+ years of operations leadership | Inflated form of F7 | "I have 7 years in warehouse and distribution ops" at its own scope. The material says the seven years, not how many carried leadership |
| Has led Lean or Six Sigma projects | Inflated form of F8 | "I'm green belt certified" at its own scope. The material says the certification, not projects |

## Sources

Provided documents: the job description text you pasted, and your background message. No tuesday-dossier.md was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Query "Atlas Freight regional logistics company values" was refused. It would have supplied official value names for VAL themes and, if a values round were documented, a values cheat sheet |
| 2. `Atlas Freight interview process operations manager` | unavailable | Query "Atlas Freight interview process operations manager" was refused. It would have supplied loop structure, so persona weights rest on the generic archetype instead |
| 3. `Atlas Freight strategy` / recent news | unavailable | Query "Atlas Freight regional logistics strategy news" was refused. It would have grounded a CO or CASE question and a grounding brief in current strategy, so A4 is generic |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you pasted fixes the fit snapshot and every JD-tagged question |

## Upgrade menu

- The interviewer's name and role, and whether they are a manager, peer or recruiter → persona weights read from the relationship, a tailored reverse question, and a reading of their public footprint
- The recruiter's note on format, such as a case, a presentation or a take-home → a build section for any pre-declared deliverable
- Permission to run web searches → Atlas Freight's published values, interview process and recent news, which would move A4 and the generic case questions toward grounded ones, and a values cheat sheet only if a values round turns out to be documented
- Your written answers to the slots in F1 to F8, especially F2, F3, F5 and F7 → discovery rows become presentation or none, and the guidance can become story-mapped
- The green belt certificate, or a before-and-after mis-pick report, or any shift scorecard you hold → F8 and F3 move from medium toward high, since those are the inspectable artifacts for them
- Whether the interview is one session or several, with the schedule → per-round mini-packs
- Your actual prep hours → the triage resized from the week assumed here
- A tuesday-dossier.md from an earlier evidence review → user-verified evidence and an evidence-derived top objection in place of the inferred one in A1
