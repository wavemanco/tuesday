# Interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy. **Relationship:** peer, both reporting to the same VP. **Round:** a single 60-minute conversation with Dan.

Built from your pasted material only. The JD arrived as highlights rather than full text, so requirement wording below is quoted from those highlights.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for your own words, not a script. Every answer slot is an instruction for the interview: answer whichever branch is true for you.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows how you work with others, in behavioral form |
| EXP | Whether the claims about your background survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's altitude: priorities, competition, recent moves |
| CASE | Structure and reasoning on a live problem from the actual role |

**Highest-ROI prep in this pack: B1**, the question about your missing sales-ops and quota-setting experience. It will be asked in some form, and it comes from a peer who works in exactly that world. Second: D1, partner-motion design. Third: A1 and A2, the ~$400M figure.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm" — the coach's notes, "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy and ops, with no inspected artifact behind it, and the words stay there: "For nine years I was at a large consumer-tech company, in product strategy and ops." The pack's observation: the material does not say the work was go-to-market, and it places the work at a consumer company. Answer slot: the JD's opening requirement makes a probe on the nearest work likely. Say which of your product strategy and ops work, if any, sat closest to it and what part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with product strategy and ops |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | discovery | The words stay at the quote's scope: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." The material does not show whether the work looked across land, adopt, expand or renew. Answer slot: if the change related to any of those stages, say which and how, in your own words; if it did not, say so plainly and stay with the proposal and the credited uplift. The figure itself is rehearsed in A1, A2 and E1 |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap on the tools, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with the tools by name: "I'm skilled in SQL and Tableau." The word "independent" is the JD's and the quote does not carry it. Answer slot in A4: if you ran analyses end to end yourself, say which; if others supported them, say so plainly |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a revenue model at partner level and its use in carrier negotiations, with no inspected artifact. The words stay there: "I built a partner-level revenue model that was used in carrier negotiations." The pack's observation: the material does not show the design of the partnership itself. Answer slot in D1 stays inside the model and its use in the negotiations |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it. Lead with it in its own terms: you set annual volume targets, and the consensus was cross-org. A named result beats an adjective. Keep them as volume targets, which is what the quote says |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | The words: "I use AI tools daily." The pack's observation: your research note names Compass as the AI copilot launch, and the material says daily use of AI tools, not building or launching one |
| F7 | Familiarity with sales-ops and quota-setting, the working ground of a Director of Sales Strategy (role-family requirement, not in the JD highlights) | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and it has been stated. Words: "I haven't had classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. The nearest quote is F5's volume targets, and the material does not call them quotas, so they stay volume targets |

## Reading the interviewer

Everything here comes from the profile details you pasted. No web research ran (see Sources), so there is nothing beyond them.

| Signal | Source | Provenance | What it means for this conversation |
|---|---|---|---|
| Self-describes as "relentlessly data-driven" | your message | [grounded] | Expect every figure to be probed to its assumptions. Bring the weakest assumption before he asks (A1, A2, E1) |
| "career spine is pricing and monetization roles" | your message | [grounded] | Expect pricing, packaging and unit-economics angles (C2, C3). Your material says a revenue model and a credited ARR uplift, not pricing work, so stay at quote scope |
| "one early-stage-startup chapter" | your message | [grounded] | Builder stories likely land with him, and a probe on pace or scrappiness is possible (D3). Your material carries no startup chapter, so no mirror is offered on it |
| Peer, "both reporting to the same VP" | your message | [grounded] | He is weighing what you cost him and what you add to his work. Reciprocity beats self-presentation (B3, reverse questions) |

Mirror opportunity, shared vocabulary: his monetization vocabulary against your F2 quote, "proposed a store-surface change credited with a ~$400M ARR uplift", and your F4 quote, "built a partner-level revenue model used in carrier negotiations". Use revenue and ARR language only where those quotes support it. Shared jump: none offered, because no fit-snapshot row carries your side of his startup chapter.

## Persona table

Weights start from the peer prior (Peer Evaluator plus Data-Driven Prober), then adjust for Dan's signals. The loop is established by your own words: one 60-minute conversation with a peer, so no values-style round is detected.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Line-by-line probing of the ~$400M figure, the revenue model, your SQL and Tableau claim | Highest. Peer prior, raised by "relentlessly data-driven". Five questions (A1 to A5) | Know what you can and cannot say about how the figure was counted; name the weakest assumption first. Rows F2, F3, F4 |
| Peer Evaluator | Seam questions, "what would you need from me", credit across teams, your gap in his craft | High. Peer prior, and the F7 gap sits in his function. Four questions (B1 to B4) | Reciprocity framing; propose seam principles instead of claiming to know the seam. Rows F5, F7 |
| Case / Strategist | Whitespace, partner motion, bundling, sequencing under the profitability goal | Medium-high. Not a peer prior, but his pricing spine tilts cases toward pricing and packaging, and the JD asks for strategy. Four questions (C1 to C4) | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Partner-motion design, weakest-on-day-one, consumer to B2B | Medium. The JD marks partner-motion design as required and F4 is adjacent, and his startup chapter may raise a pace probe. Three questions (D1 to D3) | Rehearse the objection until it is boring; bridge only from the quotes; name the limit before it is asked for |
| Pressure | Time-boxed "why you", attribution of the ARR figure | Low-medium. A peer is less likely to stress-test composure, though a quota-carrier comparison is plausible. Two questions (E1, E2) | Pause, restate, anchor in what you stated, hold through two follow-ups |
| Conversational | The opener, and AI asked casually | Low-medium. A peer chat likely opens loosely, and AI is the JD's plus. Two questions (F1, F2) | A 90-second arc built only from your own sentences; treat casual AI questions as scored |
| Values / Behavioral | Credit and disagreement stories | Low. No values-style round is detected, so it gets no bank of its own. B2 carries the behavioral probe | Where a story exists, "we" for context and "I" for contribution |

## Question banks

### A. Data-Driven Prober (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open with the quote's own terms: you proposed the change, and the change was credited with the uplift. Then the four slots a figure raises, each in your own words. How it was counted: if you know, say how; if you do not know how it was counted, say so plainly. What the figure is sensitive to: say it if you know it. The assumption you would defend least: name it before Dan does. Which part was yours: the quote says you proposed it, so say plainly if more or less than that was yours | F2 holds the figure, and a self-described data-driven peer will go to it first. EXP because it tests what was actually the candidate's and how well the number is understood |
| A2 | "Which assumption behind that number would you defend least, and what happens to it if that assumption is wrong?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The weakest-assumption move, done in your own words. The pack does not name the assumption for you. If you know it, say it and say what it does to the figure; if you do not know how the figure was counted, say that plainly and say what you would want to see to judge it. Stay with a proposal that was credited with an uplift | A metric defended at its weakest point reads as credibility, not defensiveness. This is the second stem for the same quote because probers go two levels deep. Rows: F2 |
| A3 | "Walk me through the partner-level revenue model you built." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4 with only the beats the quote states: a revenue model, at partner level, used in carrier negotiations. Answer slot: the probe will go to how the model worked and what drove its outputs. Where you built those parts, say how, in your own words; where they were supplied by others, or the model was simpler than the probe assumes, say so plainly and return to the quote. Offer a full walkthrough only of an analysis you did yourself | F4 is the strongest quote against the JD's partner requirement and the likeliest place a prober digs. EXP because the test is what the model actually was and which parts were yours; JD content is covered in D1 |
| A4 | "Describe an analysis you ran yourself in SQL or Tableau, start to finish." | JD | [grounded] "skilled in SQL/Tableau" | The quote carries only the skill, so the story is a selection scaffold. Pick one analysis where you can name the question it answered, the data you used, what you did, and what changed because of it. Name your weakest assumption in it before he does. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would approach one | The JD says independent analysis in SQL and Tableau, and F3 has the tools but not the independence. JD because it scores a stated requirement, delivered as an open EXP prompt |
| A5 | "Two new product lines launched and accounts are landing but few seem to adopt. What data do you pull first, and what do you need to know before you pull it?" | CASE | [generic] | Structure aloud: clarify what adoption means for each line and what is tracked; set the objective; segment accounts; state the cuts you would pull and the thresholds that would change your mind; name the assumption most likely to be wrong. No claim about your past is needed, so the guidance makes none | Tests the SQL and Tableau requirement as live reasoning rather than a claim, in the land and adopt vocabulary of the JD. CASE because it is a live problem; `[generic]` because it is a pattern, not a fact about Northwind |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't done classic sales-ops or quota-setting work. How would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" | **The highest-ROI rehearsal in the pack.** Name the limit first, before he presses: "I haven't had classic sales-ops or quota-setting experience." Pause, restate his question, then hold on what the quotes carry: you set annual volume targets with cross-org consensus, and say them as volume targets. Follow-up 1 (so you have not carried a number the way my team does): do not argue the targets are close; say the acknowledgment again plainly and return to the targets quote. Follow-up 2 (what do you need from my team): reciprocity first, and ask how it works here before claiming to know. Offer seam principles as proposals, such as who decides, who is consulted and how a disagreement goes to the shared VP with data. Concede specifically: in the first months you would learn how that side works from his team. Then say what you bring, at quote scope: SQL and Tableau, and a partner-level revenue model used in carrier negotiations. Any plan is said as future, never as past | The stated gap in F7 sits in his own function, and he is the person it costs most. JD delivered as EXP: the question tests honest self-assessment under a peer's probe. Highest ROI because the negative is known, the asker owns the ground, and a calm, specific concession changes the conversation |
| B2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "set annual volume targets with cross-org consensus" | The quote carries a cross-org story with two beats: you set annual volume targets, and the consensus was cross-org. Say it with we for context and I for your contribution. Answer slot: where the consensus was yours to build, say how, in your own words; where it was reached some other way or by others, say so plainly and stay with the targets. Do not add a disagreement or a stakeholder reaction that the quote does not give | Credit-sharing is a peer stem, and F5 is the only quote that touches several teams. VAL because it is a behavioral probe on working with equals; no values round is detected, so this is the pack's only VAL item |
| B3 | "What would you need from me in your first 90 days, and what do you bring to my team?" | JD | [grounded] "skilled in SQL/Tableau" and "built a partner-level revenue model used in carrier negotiations" | Reciprocity framing, both halves. Needs: ask for how his team decides, what is already settled, and what he wants from a GTM plan that you should not guess. Bring, at quote scope: you are skilled in SQL and Tableau, and you built a partner-level revenue model that was used in carrier negotiations. Offer analysis in those terms, as an offer rather than a claim about what you would deliver | The peer is pricing what a hire costs and adds to his work. JD because it scores the cross-functional requirement (F5 row); the quotes limit what the bring side may claim |
| B4 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of claiming to know the seam: ask what is already decided on his side, suggest one owner per decision, say how you would bring data first when you disagree, and say the shared VP is the backstop, not the first move. Make no claim about a past disagreement | The standard peer stem. JD because it scores cross-functional influence; `[generic]` because it carries no claim about the candidate |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "For two new product lines with no sales history, where do you look for whitespace across land, adopt, expand and renew, and what do you need to know first?" | CASE | [generic] | Clarify first: what each line is, who buys, what exists today. State the objective, segment the base, say how each stage would be sized, and name the metric you would watch at each. Challenge one premise, such as whether all four stages matter equally in year one. No claim about your past | Covers the JD's whitespace requirement as a live problem, in the JD's own vocabulary. CASE because there is no past to claim; F2 is where the evidence is thin |
| C2 | "A much larger platform vendor is bundling a competing capability into its suite. How do you protect adoption and pricing for a new product line?" | CO | [grounded] | Use the bundling threat from your research note as the premise, and say it as one you have read, not one you know from inside. Clarify which line and which buyers, separate where bundling hurts land from where it hurts expand and renew, and give two or three responses with the trade-off for each. Stay in structure; do not claim pricing experience your material does not carry | His pricing and monetization spine makes this his native ground, and bundling is your note's main competitive threat. CO because it tests strategy fluency; the guidance makes no claim about your history |
| C3 | "Northwind is pushing on enterprise expansion, the Compass launch and profitability. Where do the two new lines fit, and where would you push back?" | CO | [grounded] | Use the three priorities from your research note. Do not assume Compass is one of the two lines; ask which it is. Pick one trade-off between the priorities, say what you would sequence first and why, and say what evidence would change your mind. Your push-back should be one reasoned point, not a list | Tests whether you can think at the company's altitude. CO because it is about priorities; the pack does not know how the two lines relate to Compass, so the guidance asks |
| C4 | "Sketch the partner motion for a new product line. What do you need to know first?" | CASE | [grounded] "built a partner-level revenue model used in carrier negotiations" | Clarify the line, the partner types and what a partner gets from it. Structure as objective, segmentation, approach, metrics, risks. If you use your model as an example, say it at its scope: you built a partner-level revenue model that was used in carrier negotiations. Do not describe it as a motion you designed | The JD requires partner-motion design, and this tests the reasoning when the experience is adjacent. CASE because it is live; the F4 quote limits any example you give |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Partner-motion design is a required piece of this role. What have you designed yourself?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | The second-deepest rehearsal. Hold only what the quote carries: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: say which part of the model, or of how it was used in the negotiations, was yours to shape and how you decided, in your own words; if none of it was, say so plainly and stay with the model. Hold through two follow-ups by returning to the model, never by adding to it. Concede specifically that the material you can speak to is the revenue side, then give a plan for learning the rest, said as future | F4 is adjacent to the requirement the JD marks as required, so this objection arrives in some form. JD because it scores a stated requirement; the honest branch is a limit, not a confession |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." | Choose the answer you would honestly give. The rows with the least in the material are F7, F4 and F1. If you pick the sales-ops side, the acknowledgment is: "I haven't had classic sales-ops or quota-setting experience." State it plainly, name the specific first step you would take as a plan, and say what you bring, using only the quotes in B1 | The standard skeptic stem, aimed at the snapshot's thinnest rows. JD because it scores honest self-assessment against the listed job |
| D3 | "You have spent nine years at a consumer-tech company. What from that carries over here?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" | The quote carries the nine years, the large consumer-tech company and the product strategy and ops. Selection scaffold for the rest: pick the one piece of work you would choose, make sure it touches revenue, partners or targets, say plainly why it carries over, and let him draw the inference. If no piece comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would learn the difference. A pace or scrappiness follow-up is possible; answer it from your own work only | F1 places the work at a consumer company, and Dan's profile includes a startup chapter. EXP because it tests what the background actually is; the transfer claim is left to the candidate's own material |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That ARR number. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold-then-concede. Pause and restate. Hold: "I proposed the change, and it was credited with the uplift." Hold through two follow-ups by returning to that sentence. Concede explicitly and specifically only what you do not know, such as how the credit was assigned, if that is true. Never claim more than proposing it, and never fold on the core sentence just to ease the moment | The standard attribution probe, aimed at the headline figure. EXP because it scores attribution honesty; F2 holds the quote |
| E2 | "Sixty seconds: why you, rather than someone who has carried a quota?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations", "set annual volume targets with cross-org consensus", "skilled in SQL/Tableau" and "No classic sales-ops or quota-setting experience." | Pause, restate, then three beats in the quotes' own terms: you built a partner-level revenue model used in carrier negotiations, you set annual volume targets with cross-org consensus, and you are skilled in SQL and Tableau. Include the acknowledgment so he does not have to: "I haven't had classic sales-ops or quota-setting experience." End on what you would bring his team, not on a claim to be better | A time-boxed version of B1 for a pressure register. JD because it scores fit to the listed job; the acknowledgment keeps the answer inside the stated limit |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" and "9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with only the beats the quotes carry: two years in strategy consulting at a top firm, then nine years at a large consumer-tech company in product strategy and ops. Answer slot: give your actual reason for this move to this role, in your own words, and keep it to what is true. End on why this seat, not on a recap | A peer chat usually opens loose, and a casual opener is still scored. EXP because the arc is the CV in spoken form; F1 holds both quotes |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say it at its scope: "I use AI tools daily." Answer slot: say which tools and what you use them for, in your own words; if the use is general rather than part of analysis or strategy work, say so plainly. If you mention Compass, say you know it as the AI copilot launch from your reading, and ask what it does. Do not describe building or launching an AI product | AI is the JD's plus and Compass is one of the company's three priorities. JD because it scores a stated plus, asked casually; F6 limits the claim |

## Requirement coverage

| Requirement | Source | Covered by |
|---|---|---|
| "own GTM strategy for two new product lines" | JD highlights | C1, C3, D2, D3, F1 |
| "identify whitespace across land/adopt/expand/renew" | JD highlights | C1, A5 |
| "run independent analysis in SQL and Tableau" | JD highlights | A4, A5, A3 |
| "partner-motion design experience required" | JD highlights | D1, C4, A3 |
| "strong cross-functional influence" | JD highlights | B2, B3, B4 |
| "AI experience a plus" | JD highlights | F2 |
| Sales-ops and quota-setting (stated gap, not in the highlights) | the coach's notes | B1, D2, E2 |
| The ~$400M headline figure | the coach's notes | A1, A2, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your background runs through pricing and monetization. How does that shape the way you want GTM and sales strategy to work together on new products?" | Tied to his own path. It lets him speak in his native language and shows you read him, not just the company |
| R2 | "What could a new person on my side do in the first month that would genuinely help your team?" | The reciprocity question for a peer. It moves the conversation from what you need to what you add |
| R3 | "Where would you want the seam to sit between GTM for the new lines and your team's work?" | Surfaces his view of the seam directly, which B1 and B4 depend on, and signals you propose principles rather than assume territory |
| R4 | "Which two or three metrics would you want us both watching to judge whether a new line is landing, adopting and expanding?" | Speaks to his self-described data-driven approach and gives you a shared scorecard |
| R5 | "How does bundling by the larger platform vendor show up in your conversations with sellers and partners?" | Uses the competitive threat from your research note and asks for his field view, which you cannot get from outside |
| R6 | "How are the profitability goal and the Compass launch shaping what the two new lines are expected to deliver this year?" | Shows you are thinking at the company's altitude and asks about priorities that bear on your plan |
| R7 | "You had an early-stage chapter too. What did it change about how you think about GTM at scale?" | Tied to his path, and it turns the pace-or-scrappiness probe into a peer conversation |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran GTM strategy for a product line | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: the material says product strategy and ops. The slot stays inside that work |
| Designed a partner motion or program | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says a revenue model used in carrier negotiations. D1's slot stays inside the model |
| Led or ran the carrier negotiations | Inflated form of F4 | The model, which "built a partner-level revenue model used in carrier negotiations" carries, and nothing about who ran the negotiations |
| Drove, delivered or implemented the ~$400M ARR uplift | Inflated form of F2 | "proposed a store-surface change credited with a ~$400M ARR uplift" at its own scope. A1 and E1 slots ask only how it was counted and what was yours |
| Set or owned sales quotas, or had sales-ops experience | Negative stated, F7 | The plain acknowledgment F7 gives: "I haven't had classic sales-ops or quota-setting experience." No slot |
| Called the annual volume targets quotas | Inflated form of F5 | F5's quote at its own scope: volume targets with cross-org consensus |
| Owned pricing or packaging decisions | Inflated form of F4 and F2 | Both quotes at their own scope: a revenue model and a proposal credited with an uplift. The pack's observation: the material does not say pricing |
| Built or launched an AI product or copilot | Inflated form of F6 | "uses AI tools daily" at its own scope |

## Sources

Provided documents: your message, which carried the role, the JD highlights, the candidate summary, the interviewer's profile details and your research note on Northwind's priorities. No dossier was present.

Searches sent:

- `Northwind Data company values` — refused
- `Northwind Data Compass AI copilot enterprise` — refused
- `Dan Kovac Director of Sales Strategy Northwind Data` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Search refused. It would have given the official value names for VAL stems. No values-style round is detected, so it would not have added a cheat sheet |
| 2. `Northwind Data interview process` | skipped | Your words fix the loop: one 60-minute conversation with a peer. Persona weights follow from that |
| 3. `Northwind Data strategy` and recent news | unavailable | Search refused. It would have checked and extended the three priorities in your note. C2 and C3 rest on your note alone |
| 4. `Dan Kovac Northwind Data` | unavailable | Search refused. It would have added his public talks or writing. The interviewer read rests on the profile details you pasted |
| 5. Representative `Senior GTM Strategy Lead` JD | skipped | Your JD highlights fix the fit-snapshot rows and the JD-tagged questions |

## Upgrade menu

- Full JD text → the six requirement quotes become the JD's own wording, and any mid-list requirement the highlights left out gets a row and a question
- Web search permission → the three refused lookups run: official values, Northwind's strategy and Compass, and Dan's public footprint
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), offered once → a strategy brief for C2 and C3, plus Dan's talks and writing for the reverse questions
- Priya's own answers to the answer slots in A1, A3, B1, B2, D1 and F2 → F1, F2, F4, F5 and F6 move from limits to quoted stories, and the guidance gets her real beats
- A Tableau workbook or SQL query she can walk through → F3 from medium to high and a real answer for A4
- The page or deck from the carrier negotiations, or a one-page description of the revenue model → F4 from medium to high and a firmer A3
- Whatever document credited the ~$400M uplift to the change → F2 from medium to high and a sharper A1, A2 and E1
- The recruiter's note on focus areas or any pre-declared deliverable → coverage beyond the round-type priors, and a build section if a deliverable exists
- Prep time available → a prioritized schedule
- A `tuesday-dossier.md`, if you have one → verified evidence and a hard guard against listed claims
