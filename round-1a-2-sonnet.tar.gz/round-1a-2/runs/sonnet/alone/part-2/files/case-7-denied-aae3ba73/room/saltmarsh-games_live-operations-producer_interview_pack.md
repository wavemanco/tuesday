# Interview pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. One 60-minute session on Friday. Relationship assumed to be hiring manager, because your note did not say. If that is wrong, the persona weights below change.

## How to use this pack

Personas describe how a question arrives. Types describe what it is scoring. The guidance is scaffolding, not a script: say what you actually did, in your own words.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment |
| EXP | Work-experience deep-dive: does your background survive scrutiny |
| JD | A question taken from the job description's own lines |
| CO | Company and strategy knowledge |
| CASE | A live problem from the actual role |

An "Answer slot" is an instruction for the interview, not a question for you now. It names what the interviewer is likely to probe and gives two honest branches. Fill it from your own experience, or say plainly it was not yours.

Highest-ROI prep in this pack: **B1**, the "one title to two titles" objection.

## Fit snapshot

Quotes are your own sentences from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says the main title's weekly content-drop calendar, not a live-events calendar across two titles, and the words stay at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-title line makes a probe on events and on the second title likely. If any drop was a timed event, or you had a hand in another title's schedule, say which and what your part was, in your own words; if not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message, "Never led a team, and never worked on a game with in-app purchases." — your message | low | [inferred] | discovery | The material touches the calendar without showing which teams a drop involved or what your part was in lining them up. Answer slot: if design, art, engineering or community had to line up for a drop, say how you got them lined up, in your own words; if some were not involved, or the lining up was not yours, say so plainly and stay with the calendar. Leading and coordinating are different things, and "Never led a team" is your own sentence about the first |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you owned a post-event review or chose the KPIs, and the words stay at that scope: "Presented the monthly retention numbers to the studio head." Answer slot: the JD's review line makes a probe on who produced the numbers and what followed them likely. If you produced them or chose what went into them, say how, in your own words; if they came from someone else, or no review followed, say so plainly and stay with what you presented |
| F4 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap on the face of the quote, but a single line with nothing inspected behind it, so expect a probe on the numbers themselves. Lead in the quote's own terms: you presented the monthly retention numbers to the studio head |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap on the face of the quote, but the verb is "wrote" and the proof is "still uses", so expect a probe on what it covers and who changes it. Keep the verb: you wrote the release checklist your QA team still uses |
| F6 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message, "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The years are stated; whether the title was a live-service game is not. Answer slot: expect the interviewer to place the title. If it was a live game with ongoing updates, say what the updates were, in your own words; if you are unsure whether they would count it, say so plainly and let them ask |
| F7 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a single line with nothing inspected behind it, so expect a probe on what a drop contained and who set the dates. Lead in the quote's own terms: the weekly content-drop calendar, the main title, the last two years |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The quote already reaches this in other terms: a written document a team still uses. The bridge rewords only that quote and adds nothing: "I wrote the release checklist our QA team still uses." Let the interviewer judge whether it is clear |
| F9 | Familiarity with in-app purchases and monetisation (not in the JD; a role-family concern, unquoted) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [generic] | capability | A gap you stated yourself. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to purchase-related work, and nothing added to make the gap feel smaller |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A1, A3, B1 |
| Coordinate design, art, engineering and community on each update | A5, B2, D3 |
| Own the post-event review and the KPIs it reports | A4, C2 |
| Manage the release checklist with QA | A5, C3 |
| 3+ years producing live-service games or apps | B5, D1 |
| Experience running a content calendar | A1, B1, E1 |
| Comfortable with player-retention metrics | A2, C1, C2 |
| Clear written communication | D3, C3 |
| Not in the JD: in-app purchases (F9) | B3, B4, E2 |

## Persona table

The weights rest on the one session you described and an assumed hiring-manager relationship. No loop source documented a values round, and no research reached this pack.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | Live scenarios from running two titles' calendars | high: hiring-manager prior, and most JD lines are planning and coordination work | Clarify, objective, options, metrics, risks. Think aloud and challenge one premise politely |
| Skeptic (bank B) | Quiet probing of one title to two, the missing purchases experience, and whether the experience is live-service | high: hiring-manager prior, and F1, F2, F9 are the thinnest rows | Rehearse B1 until it is boring. Return to your own quoted sentences and never add to them |
| Data-Driven Prober (bank C) | Reads the retention and checklist lines one at a time | medium: the JD names retention metrics and KPIs, and your background has a retention line | Know what you can and cannot say about how the numbers were counted, and say plainly when you do not know |
| Conversational (bank D) | Opens with the journey, asks about the company casually | medium: a 60-minute conversation often opens this way, and the register hides scored questions | Prepare a 90-second arc and treat casual questions as scored |
| Pressure (bank E) | Time-boxes, asks how much was actually you | low: no signal beyond the Skeptic overlap | Pause, restate, hold through two follow-ups, concede specifically |
| Peer Evaluator (no bank) | Seam questions between teams | low: assumed hiring manager, not a peer. The seam appears inside A5 | Propose seam principles rather than pretending to know the seam |
| Values / Behavioral (E3 only) | Scenario probes against published values | low: no values-style round documented, and no values page was read | Selection scaffold ending in its honest branch |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two titles each want a big event in the same fortnight, and engineering can only support one. How do you decide what goes in the calendar?" | CASE | [generic] | No claim about your past is needed. Clarify first: what each event is for, what is fixed by date, what engineering can actually support. State the objective you would optimise, give two options with the trade-off, say what you would tell each team and when, and name what the post-event review would check. Think aloud and challenge one premise politely, such as whether both events need that fortnight | The two-title calendar is the JD's centre (F1), asked as a decision because hiring managers score structure; generic because it is a pattern, not a fact about Saltmarsh |
| A2 | "Event retention is running below the previous event's by day two. What do you look at, and who do you talk to?" | CASE | [generic] | Clarify first: which retention measure, which players, compared with what, and whether anything in the event was broken or confusing. Diagnose before acting: separate a problem with the event from a problem with who it reached or when. Say who you would talk to on each branch and what you would record for the review. Name, in your own words, the assumption in your comparison that you would trust least | Retention is a JD line (F4) set as a live problem, so CASE delivery with the weakest-assumption move a metric question needs |
| A3 | "You start next week. What do you want to know about our two titles' calendars before you change anything?" | CASE | [generic] | Speak it as a plan. What is already scheduled and locked, how dates get set today and who has the last word, what each team needs lead time for, what the last few events reported and which numbers the studio trusts, and how events connect to in-app purchases, which you would ask about early. Say you would listen before proposing changes | A ramp plan answers the thin rows F1, F2 and F9 without claiming anything. CASE because it asks for structure, not history |
| A4 | "Walk me through how you would run the post-event review for an event that underperformed." | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Structure it as a plan: what the event was meant to do, what the numbers say against that, what you think happened and how sure you are, what changes next time, who needs to read it. The one thing your material carries is that you presented monthly retention numbers to the studio head. Answer slot: the JD's review line makes a probe on whether a written review came with those numbers likely. If you wrote one or recommended changes, say what, in your own words; if you presented numbers only, say so plainly and describe how you would run the review | F3 is the evidence for the review requirement. JD because it scores that line, with CASE delivery |
| A5 | "Design says an event is a week behind, community has already announced the date, and engineering says a late change is risky. What do you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Facts first: what is actually behind, what players were promised, what engineering means by risky. Then options: hold the date with reduced scope, move the date, ship in two parts. Say who decides, what you bring them, what community says and when, and what QA needs. The one thing your material carries is the checklist: "I wrote the release checklist our QA team still uses." Answer slot: the JD's QA line makes a probe on whether the checklist ever settled a ship decision likely. If it did, say what happened and what part was yours; if it was a reference only, or no such call came up, say so plainly and stay with what you wrote | F2 and F5 meet here, and the disagreement among teams is the coordination the JD names. CASE because it is a live problem |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've run the content calendar for your studio's main title. Why should I believe you can run live events for two of ours?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "For the last two years I ran the weekly content-drop calendar for our main title." Expect follow-up one to press on events versus drops and follow-up two on the second title. Answer slot: if any drop was a timed event, or you had a hand in another title's schedule, say which and what your part was, in your own words; if not, say so plainly and say how you would learn the second title's calendar. Hold by returning to the calendar, never by adding to it. The pack's own observation, not words for you: your material says the main title's calendar | F1 is where the JD presses hardest on thin evidence, so this objection arrives in some form. JD because it scores the stated requirement |
| B2 | "I understand you haven't led a team, and this role needs design, art, engineering and community moving together. How do you get that without being anyone's manager?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Plain acknowledgment first: "I haven't led a team." Keep coordinating separate from leading. Answer slot: if you had to get design, art, engineering or community lined up for a drop, say how, in your own words; if those teams were not involved or someone else did the lining up, say so plainly and describe how you would get agreement on a date from teams you do not manage | F2 is the coordination requirement and the stated absence of team leadership sits next to it. EXP because it tests attribution, and the negative has a source |
| B3 | "You haven't worked on a game with in-app purchases. Live events on mobile tend to touch them. How would you get up to speed?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "Presented the monthly retention numbers to the studio head." | Plain acknowledgment first, in the quote's terms: "I haven't worked on a game with in-app purchases." Then a plan, spoken as a plan: what you would ask for in your first two weeks, and that you would ask before changing an event that touches purchases. The adjacent thing your material carries, at its own scope: "Presented the monthly retention numbers to the studio head." Say it and do not say it covered revenue. Do not minimise the gap or bluff past it | F9 is a stated gap and the likeliest day-one probe on a mobile role. JD because the interviewer is scoring readiness |
| B4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pick one your material shows is thin, such as F1, F2, F3 or F9. Name it in one sentence, then give a first-thirty-days plan: what you would learn and from whom. If you pick purchases, the sentence is "I haven't worked on a game with in-app purchases." For any other pick, say what your material does and does not show, in your own words. If you cannot pick one, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The standard Skeptic probe, and a rehearsed honest answer is worth more than a fresh one. JD because it asks you to rank the listed requirements |
| B5 | "The role asks for three years producing live-service games. Tell me about the game you worked on and how it was updated." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Stay with the stated facts: four years as an associate producer at a puzzle-game studio, and for the last two the weekly content-drop calendar for the main title. Answer slot: if the title was a live game with ongoing updates, say what the updates were, in your own words; if you are unsure whether the interviewer would count it, say so plainly and let them ask. Do not add the words "live-service" for yourself | F6 leaves open whether the title was live-service. JD because it scores the first listed requirement |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers to the studio head. Which retention measures were in them, and how was each counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you know which measures were in the numbers, how each was defined and which part was yours, say so in your own words; if the definitions were set by someone else, or you do not know how a figure was counted, say so plainly and say what you presented. Then name, in your own words, the assumption behind those numbers you would trust least; if you do not know of one, say that. This guidance supplies no measure, definition or baseline | F4 is a single line with nothing inspected behind it, so a prober reads it first. EXP because it tests attribution. No figure was given, so only the four defend-the-number slots apply |
| C2 | "If I gave you our event KPIs tomorrow, which would you look at first to judge whether an event worked, and why?" | JD | [generic] | A reasoning answer with no claim about your past. Start from what the event was meant to do, pick the one or two measures that speak to it, say what each is compared against, and name, in your own words, the assumption you would trust least in that comparison. Say what you would ask for if you do not know how our KPIs are defined | F3 and F4 meet in the KPI line. JD because it scores the review requirement, with the weakest-assumption move a metric question needs |
| C3 | "Tell me about the release checklist you wrote: what is on it, and how did you decide that?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | The beats the quote states: you wrote it, and your QA team still uses it. Answer slot: if you decided what went on it, say how, in your own words; if QA or someone else shaped it, say so plainly and stay with what you wrote. Tell only what you can repeat under a second question | F5 is the one artifact in your background that someone else still uses. EXP because a prober tests what was actually yours |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you end up producing live content?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | A 90-second arc built only on the two quoted sentences: four years as an associate producer at a puzzle-game studio, the last two running the weekly content-drop calendar for the main title. Answer slot: say, in your own words, what drew you to live content and to this role; if no single reason stands out, say so plainly and give the nearest true one. Do not supply a turning point you did not have | F6 and F7 are the two facts the arc stands on. EXP because the journey question is a CV walk in a friendly register |
| D2 | "What do you know about Saltmarsh and the two titles this role would cover?" | CO | [generic] | No research reached this pack, so it supplies no facts about Saltmarsh. If you can find the two titles before Friday, play or read about them and note what you actually saw in their live events as a player. Say that you looked, and what you noticed, only if you did. If you did not get to look, say so plainly and ask which two titles and what is changing for them | Homework depth is scored even in a casual register. The question is generic because the research could not run |
| D3 | "How would you keep design, art, engineering and community in step on an update, and what would you put in writing?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Structure it as a plan: what each team needs to know, when, and in what form, one place where the plan lives, and which changes get written down. The one written thing your material carries: "Wrote the release checklist our QA team still uses." Answer slot: if you have written update notes or briefs for those teams, say what, in your own words; if you have not, say so plainly and stay with the checklist and your plan | F2 and F8 meet here. JD because it scores the coordination and written-communication lines in a casual register |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That calendar you ran. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold-then-concede. Hold: "I ran the weekly content-drop calendar for our main title for the last two years." Hold it through two follow-ups by returning to that sentence. Answer slot for the concede: if others set dates or content for the drops, say which parts and whose, in your own words; if you set them, say what you set; if you do not know which part would be counted as yours, say so plainly. Pause before you answer | F7 is the calendar line a pressure interviewer tests. EXP because it tests attribution under pressure |
| E2 | "Sixty seconds: why you over someone who has run live events with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." "Never led a team, and never worked on a game with in-app purchases." | Time-box it. Hold three stated facts in their own words: "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." Concede plainly and specifically: "I haven't worked on a game with in-app purchases." Close with your own reason for wanting the role, said as a reason and not as a credential | F9 is the concession and F5, F4 and F7 are the hold. JD because it scores fit against the listed requirements |
| E3 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | An open prompt, so pick your own instance. It needs a named stake, what you actually said, and how the relationship stood afterwards. Your material shows that you presented monthly retention numbers to the studio head, and does not show any occasion when they were unwelcome, so the story has to come from your own memory. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values stem, with no published Saltmarsh values read. VAL because it scores behavior, and F4 is the nearest evidence that you reported to leadership |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a strong first ninety days look like for this producer, and how would you judge it?" | It asks for the scoring sheet directly and opens the ramp conversation on the thin rows F1 and F2 |
| R2 | "How is the live-events calendar set for the two titles today, and who has the last word when they compete for the same team's time?" | It echoes A1 and shows you are thinking about the decision, not the document |
| R3 | "Which KPIs does the post-event review report today, and where do their definitions live?" | It is the prober's question turned round (C1, C2), and it shows you check definitions before trusting numbers |
| R4 | "Where would you expect someone who hasn't worked with in-app purchases to need the most support?" | You name the F9 gap yourself and ask for the ramp, which turns the gap into a plan |
| R5 | "What does the release checklist look like today, and what would you change?" | It connects to F5 and signals you would improve the process rather than inherit it |
| R6 | "What did the last update's review change about how you ship the next one?" | It shows you think in review loops (F3), and the answer tells you how the team treats its own misses |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Planned and ran the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: your material says the main title's weekly content-drop calendar. B1's slot stays inside the calendar |
| Owned the post-event review and the KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says you presented the numbers. A4's slot asks only who produced them and what followed |
| Managed the release checklist with QA release after release | Inflated form of F5 | F5's quote at its own scope: you wrote the checklist your QA team still uses. C3's slot asks only how its contents were decided |
| Has led a team | Negative you stated, F2 | The plain acknowledgment from your own sentence: "I haven't led a team." No slot |
| Has worked on a game with in-app purchases | Negative you stated, F9 | The plain acknowledgment from your own sentence: "I haven't worked on a game with in-app purchases." No slot |

## Sources

Provided documents: the JD text and your background, both in your message. No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Query "Saltmarsh Games values": refused. Would have fed a values cheat sheet, and no values-style round is detected without a loop source |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Query "Saltmarsh Games interview process live operations producer": refused. Would have fed loop structure and the persona weights, which now rest on your one described session |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Query "Saltmarsh Games strategy news mobile": refused. Would have fed CO and CASE questions grounded in current strategy, which are generic here |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Query "Tobias Wrenfield Saltmarsh Games": refused. Would have fed an interviewer read and a reverse question tied to his path, which are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web search permission, then ask me to re-run → values, loop structure, current strategy and Tobias's public footprint, which replace the generic D2, add an interviewer read and a tailored reverse question, and ground a CO or CASE question. A deeper pass would add up to 6 more searches and 2 more fetches, several more minutes
- Whether Tobias is your future manager or someone more senior → persona weights and every bank recomputed
- The recruiter's note on focus areas or any pre-set task → a build section for a graded deliverable
- Your own answers to the slots in F1, F2, F3 and F6 → those rows become mapped stories instead of slots
- The monthly retention deck you presented, a sanitised copy of the content-drop calendar, and the release checklist → F4, F7 and F5 move from medium toward high confidence
- Hours available before Friday → a prep triage in order of payoff
- A tuesday-dossier.md, if you have one → verified evidence and sharper limits on what the pack may coach; never required
