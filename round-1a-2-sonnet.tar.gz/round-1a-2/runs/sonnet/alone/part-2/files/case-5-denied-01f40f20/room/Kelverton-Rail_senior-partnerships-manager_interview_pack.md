# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

Round: second round, 60 minutes, a two-person panel. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). The first 15 minutes are your own POV on where you would take operator partnerships over the next 18 months, no slides, landing on what it means for the operators themselves. The rest is Q&A, and the recruiter's email says Ross will push on commercials.

Built from your message alone: no JD, no CV file and no text of the market report reached me, and my web searches were refused. Requirement rows therefore quote the recruiter's email as you pasted it, and nothing in this pack is a claim about Kelverton that you did not give me.

## How to use this pack

Personas describe how a question arrives. Types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words.

| Type | Meaning |
|---|---|
| VAL | Behaviour measured against the company's published values. None used here: no values round is documented for this session |
| EXP | Work-experience deep-dive: do your claims survive scrutiny |
| JD | Stated role requirements, including the gaps |
| CO | Company and market knowledge |
| CASE | A live problem set in the role |

Provenance labels: `[grounded]` traces to something you wrote or a document you gave me. `[inferred]` is my derivation, named. `[generic]` is a role-family pattern that makes no claim about this employer or about you.

An answer slot is an instruction for the interview where your material is silent. Answer it from your own experience. Either branch is a good answer, including "that was not mine" or "there was no such step".

## Prep triage (four hours)

| Block | Time | What | Tied to |
|---|---|---|---|
| 1 | 75 min | Build the POV, then say it aloud twice against a timer | POV build section, C1, D3 |
| 2 | 45 min | The objection: say A1 and D1 aloud, with a friend or a recording asking two follow-ups each. Hold, then concede | A1, D1 |
| 3 | 45 min | Defend the number: write your own answers to F3's four slots. Write "I don't know" wherever that is the truth | B1, B2, B3, D2 |
| 4 | 30 min | One more pass through the report for one point you agree with and one you would challenge | C2, F2 |
| 5 | 20 min | The 90-second arc and your reverse questions | F1, Reverse questions |
| 6 | 25 min | Full run: POV, then A1 and B1 back to back | all of the above |

Everything else in this pack is insurance.

## Fit snapshot

The requirements below are the recruiter's own words, as you quoted them, plus one role-family row. Evidence cells hold only your sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company, not operator partnerships, and the words stay there: "For four years I ran the ISV channel at a payments company." Answer slot: the POV asks where you would take operator partnerships, so expect a probe on how the channel carries over. If some of it carries over, say which part and why, in your own words; if none of it does, say so plainly and stay with the channel you ran |
| F2 | "Please land on what it means for the operators themselves." — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, not train operating companies, and the words stay there: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: expect a probe on how that carries to train operating companies. If some of it does, say how, in your own words; if none of it does, say so plainly and stay with network planning. The phrase "the operator world from the other side" can be read two ways, so if you are asked what it means, say in your own words who the work was for |
| F3 | "Ross will push on commercials." — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | discovery | The figure is "roughly £4M of influenced revenue" and stays at that scope. Your material does not show what period it covers, how it was counted or which part was yours. Answer slot: say what the figure counts, what it is sensitive to, the assumption behind it you would defend least and which part was yours, in your own words. If you do not know how it was counted, say so plainly |
| F4 | "Ross will push on commercials." — recruiter's email | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never sold into rail specifically and I have never carried a direct quota; my revenue number is influenced revenue." Then how you would learn it, said as a plan and never as a past. Never a claim to rail selling or quota-carrying, and nothing added to make the gap feel smaller |
| F5 | Grow a partner channel (role-family expectation, no source supplied) | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [generic] | none | No gap in the wording, and the quote already says it. Lead with it in its own terms: you took the channel from 6 partners to 40. The number counts partners, so expect a probe on what counted as a partner |

## POV build: "where I would take operator partnerships over the next 18 months"

The deliverable is a graded one. It is 15 minutes, no slides, and it must land on what it means for the operators themselves. Q&A is 45 of the 60 minutes, so a POV that runs over costs you questions.

Grounded facts to build on:

| Fact | Row | Your quoted sentence | How to use it | Provenance |
|---|---|---|---|---|
| Partner-channel growth | F1 | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Say it once, early, at its own scope. It is your credential for running a channel, not for operator partnerships | [grounded] |
| The operator-side sentence | F2 | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Say it at its own scope. Do not widen it to knowing train operating companies | [grounded] |
| The stated limit | F4 | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Decide on purpose whether to say the limit yourself inside the 15 minutes. Saying it before Ross asks is the weakest-assumption move applied to your whole background | [grounded] |

Three theses. Pick two to carry the talk and keep the third for Q&A. Every thesis comes with the concession you must say aloud. The report's text was not in hand, so check each thesis against it: keep what it supports and drop what it contradicts.

| # | Thesis | What it means for operators (the close) | Mandatory concession | Provenance |
|---|---|---|---|---|
| T1 | Judge every operator partnership by what changes for the operator, and choose partnerships by that test | An operator can say what the partnership changed for them, in their terms, not in Kelverton's | Operator-side measures are harder to forecast than Kelverton-side ones, and you cannot name the right measure before hearing from operators | [generic] |
| T2 | Stage the commitment: prove a small number of partnerships before scaling the programme, with stop-or-continue gates agreed up front | Operators are asked to commit in steps and see what each step delivered before the next | It is slower, which costs you if the commercial need is speed, and the gates are only as good as T1's measures | [generic] |
| T3 | Pick one commercial lever first, either deepening operators Kelverton already works with or reaching new ones, and decide it from Kelverton's own figures | Existing operators would see what is different in how Kelverton works with them; new ones would see a first conversation worth having | You cannot choose before seeing the numbers, so the thesis is the decision rule and not the answer | [generic] |

Differentiating from the report, which the panel has read and other candidates may have too:

| Step | What to do | Provenance |
|---|---|---|
| 1. One consensus item | Bring one point the report makes that you expect the panel to expect, to show you read it. Name it from your own reading, since the pack could not see the report | [generic] |
| 2. One divergence | Pick the thesis where your view departs from the report, with your reasons and its concession | [generic] |
| 3. The anti-pick | Name one thing you would decline to do in year one, the test you used to decline it and what declining costs | [generic] |

Shape of the 13 minutes: 1 minute to state your reading of "operator partnerships" and invite correction; 2 minutes on the consensus item; 6 minutes on two theses, each with its concession; 2 minutes on the anti-pick; 2 minutes on the close. The close is one sentence per thesis you carried, each naming what changes for an operator, in the operator's terms. Your own headline figure counts partners, so if your anti-pick is "do not chase partner count", expect Ross to ask what you counted yourself.

## Reading the panel

No public footprint was researched, because the search was refused. This reads only what the recruiter's email says, and it offers no shared-jump mirror, since nothing public is in hand.

| Panel member | What your material says | Practical implication | Provenance |
|---|---|---|---|
| Deepa | "VP Partnerships, your future manager" — recruiter's email | The POV is the part of the hour in which she can see how you would plan her function, so build it for her first | [inferred] |
| Ross | "Commercial Director" and "Ross will push on commercials." — recruiter's email | The commercial push is stated, so prepare F3 and F4 first and expect it in the Q&A rather than the POV | [grounded] |
| Both | The same email gives a 60-minute session with a 15-minute POV | Persona weights below follow that structure, with one blended pack for both | [grounded] |

## Persona table

The loop is established by the recruiter's own words: one session, two people, a POV and then Q&A. Relationship priors for a hiring manager and for a commercial executive are blended, then adjusted by the recruiter's note about Ross.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Probing the rail gap and the missing quota | High. F4 is a stated gap, and the hiring-manager prior is Case/Strategist plus Skeptic | Rehearse A1 until it is boring: hold the quoted sentences, concede the stated limits, then give a plan. Never bluff a competency Ross owns |
| Data-Driven Prober (bank B) | Ross on the figure and the partner count | High. The recruiter's email says Ross will push on commercials, and F3 is the figure he can push on | Know what you can and cannot say about how each number was counted, and say plainly when you do not know. Name your weakest assumption before he does |
| Case/Strategist (bank C) | Deepa extending the POV into live problems | Medium to high. The first 15 minutes is a strategy talk, and the hiring-manager prior supports it | Clarify, then objective, then approach, then metrics, then risks. Think aloud and challenge one premise respectfully |
| Pressure (bank D) | Ross time-boxing and testing attribution | Medium. A commercial executive prior, plus the stated push | Pause, restate, anchor in your quoted sentences, hold through two follow-ups, then concede specifically |
| Peer Evaluator (bank E) | A seam question between partnerships and commercial | Low. Inferred from Ross's role sitting beside Deepa's function, since no source states the seam | Offer seam principles instead of pretending to know the seam, and say what you would bring his team |
| Conversational (bank F) | A casual opener from Deepa | Low. Nothing documents it, but openers are still scored | A 90-second arc and a pre-chosen point from the report |
| Values/Behavioral | Not weighted | No loop source documents a values round in this session | None needed |

## Question banks

### Bank A: Skeptic (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't sold into rail and you haven't carried a quota. Why should we trust you with operator commercials?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | The highest-ROI rehearsal in this pack. Hold: "For four years I ran the ISV channel at a payments company, and I took it from 6 partners to 40." Then concede, in the quote's own scope: "I have never sold into rail specifically and I have never carried a direct quota; the revenue number I can point to is influenced revenue, roughly £4M." Hold through two follow-ups by returning to those two sentences, never by adding to them and never by calling one equivalent to the other. Close with a plan, said as a plan and never as a past: what you would ask Ross's team for in your first weeks. The limit is a limit, not a confession | F4 is where the stated commercials push presses hardest, so this objection arrives in some form. JD because it scores the role's commercial requirement, in a Skeptic's delivery |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Name the weakness your own message already names, not a decoy: "Selling into rail specifically, and carrying a direct quota, are things I haven't done." Then say how you would close each, as a plan. Answer slot: if there is a further weakness you would name, add it in your own words; if there is none, say so plainly and stop. Never offer a strength dressed as a weakness | F4 gives the honest answer ready-made. Skeptic stem, JD because it scores the role's requirements including its gaps |
| A3 | "Your background is payments and bus and light rail planning. What makes you credible with a train operating company?" | JD | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Hold at the sentences' scope: "I spent five years in transport consulting, in bus and light rail network planning, and for four years I ran the ISV channel at a payments company." Then concede, in your own words, that neither is a train operating company. Answer slot: if any of the consulting work was with train operators, say what and in your own words; if none of it was, or it was not yours, say so plainly and stay with network planning. If asked what "the operator world from the other side" meant, say in your own words who the work was for | F2 is the operator-side evidence and its limit is the likeliest follow-up to A1. JD because it scores the role's operator requirement |
| A4 | "Why leave payments for rail-tech, and why now?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | The reason is yours and your material gives none, so the pack supplies none. Answer slot: give your actual reason in your own words and keep it to what you would still say if asked a second time; if there is more than one reason, lead with the one about this role. Do not describe the payments channel as a problem unless it was one for you | F1 sits behind the question. EXP because it tests the consistency of your story. Motivation probes are Skeptic material in a hiring-manager round |
| A5 | "Your channel was ISV partners in payments. How is an operator partnership different?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Hold the scope: "I ran the ISV channel at a payments company." Then reason aloud, and say it is a hypothesis: name one difference you would test and how you would test it, from your own reading, since the pack supplies none. Answer slot: if you have seen the difference first-hand, say where, in your own words; if you have not, say the difference is your hypothesis and say how you would check it | F1 is where the transfer to operator partnerships is tested. JD because the recruiter's email names operator partnerships, with a CASE-style delivery |

### Bank B: Data-Driven Prober (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You say roughly £4M of influenced revenue. How was that counted?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Say the figure in its own words: "roughly £4M of influenced revenue." Answer slots, each in your own words: how it was counted, including what period and which partners it covers; what it is sensitive to; the assumption behind it you would defend least, named before Ross names it; and which part was yours. If you do not know how it was counted, say so plainly. Do not rebuild a method you cannot repeat under a second question | F3 is the headline figure and the likeliest target for the stated commercials push. EXP because it tests attribution |
| B2 | "What counted as a partner in the 6, and in the 40?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Hold the sentence: "I took the channel from 6 partners to 40." Answer slot: if there was a definition of a partner, say what it was; if there was none, or you do not know, say so plainly and stay with the count you gave | F5's count is the other number a prober can reach, and the denominator is what a prober asks for. EXP because it tests how the claim was counted |
| B3 | "Where does influenced revenue end and a sales number begin?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Hold: "My revenue number is influenced revenue, and I have never carried a direct quota." Answer slot: if there was a rule at the payments company for what counted as influenced, say it in your own words; if there was none, or you do not know how it was recorded, say so plainly and stay with the sentence. Never let "influenced" stretch into "sourced" or "closed" | F3 and F4 meet here, and a Commercial Director is the likeliest person to ask. EXP because it tests what was actually yours |
| B4 | "What would you want to see in Kelverton's numbers before you committed to your plan?" | CASE | [generic] | The question asks about no past. Clarify, then hypothesis, then what would change your mind: name two or three kinds of figure you would ask for and, for each, what answer would change the plan. Flag your weakest assumption before you are asked. The pack does not know Kelverton's numbers and supplies none | Ties the POV to commercials. CASE because it is a live problem with the role's own data |
| B5 | "Twelve months in, how would you tell whether an operator partnership was working?" | CASE | [generic] | Give one measure in the operator's terms and one in Kelverton's, and say which you would defend least. Do not quote a target you cannot source | This is the POV's required close made into a question. CASE because it is a metrics design problem |

### Bank C: Case/Strategist (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "If you could do only one thing in your first six months, what would it be, and what would you stop or refuse?" | CASE | [generic] | One choice, your reasoning, the cost of that choice and the trigger that would change your mind. Keep it consistent with the theses you carried in the POV | The first 15 minutes is a strategy talk, and this is the first live follow-up to it. CASE because it forces a priority |
| C2 | "Which part of the market report would you challenge?" | CO | [generic] | Differentiate and do not recite: one point you agree with, to show you read it, then one divergence with reasons, then the anti-pick. The pack could not read the report, so it supplies none of the three | The report is equally available to the panel, so reciting it is the consensus answer. CO because it tests homework depth |
| C3 | "Name a kind of partnership you would turn down in your first year, and why." | CASE | [generic] | State the test before the example. Say what declining costs you. Do not name specific operators unless the report does | The anti-pick, asked live. CASE because it needs a decision rule |
| C4 | "How would you decide which operators to work with first?" | CASE | [generic] | Clarify what "operator partnerships" covers, state a decision rule before any list, and say what data would change the order. Assert nothing about specific operators beyond what the report supports | A hiring-manager follow-up on T3. CASE because it is a live prioritisation |

### Bank D: Pressure (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Pause and restate the question. Hold: "For four years I ran the ISV channel at a payments company, and I took it from 6 partners to 40." Concede: "I have never sold into rail specifically." Close with a plan for closing that gap, said as a plan. Say nothing about the other candidate, and do not call your background equivalent. Practise it at 60 seconds | A1 in a time-boxed delivery, built on F4. JD because it scores the requirement under pressure |
| D2 | "That £4M, how much of it was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Hold the sentence: "roughly £4M of influenced revenue." Answer slot: say which part was yours, in your own words; if you cannot separate your part from anyone else's, say so plainly instead of estimating. Do not offer a percentage you cannot defend | F3's attribution slot, asked as pressure. EXP because it tests what was actually yours |
| D3 | "Suppose I tell you your plan is too slow. Defend it." | CASE | [generic] | Hold the thesis through two follow-ups, then concede the specific cost named in the POV build for that thesis. Do not fold just to restore harmony | Rehearses the POV build under pressure. CASE because it is a live defence of a plan |

### Bank E: Peer Evaluator (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Partnerships and commercial sit side by side. Where is the seam, and what happens when we disagree?" | CASE | [generic] | Offer seam principles and do not pretend to know the seam: say what you would ask Ross's team before proposing one. For a disagreement story, pick a time you disagreed with a colleague over credit or direction, with a named stake, a resolution and an intact relationship at the end. If no such time comes to mind, say so plainly, then say how you would handle it | Ross's function sits beside Deepa's, and the seam is the peer persona's native question. CASE because it is a collaboration scenario |
| E2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | State the principle first, in your own words. Answer slot: if there was a way credit was recorded where you worked, say how; if there was none, say so plainly. Keep "influenced revenue" as your sentence has it, and never say "my deals" | F4's influenced-not-direct limit is where credit questions bite. EXP because it asks for actual behaviour |

### Bank F: Conversational (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | A 90-second arc with only the beats your sentences state: five years in transport consulting, in bus and light rail network planning; nine years in partnerships; the last four at a payments company running the ISV channel, from 6 partners to 40. Tell them in the order they happened. The link between them and your reason for this role are yours to say in your own words, and the pack supplies neither. If there is no link you would claim, say so plainly | F1 and F2 are the two halves of the story. EXP because it is a biography question, and a casual one is still scored |
| F2 | "What from the market report stayed with you after you read it?" | CO | [generic] | Pick one point and say why it stayed with you, in your own words. Do not recite the report | A casual question on a hot topic. CO because it tests how you read the report |

### Requirement coverage

| Requirement (source) | Covered by |
|---|---|
| "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | POV build section, A5, B4, C1, C3, C4, D3 |
| "Please land on what it means for the operators themselves." — recruiter's email | POV build close, A3, B5 |
| "Ross will push on commercials." — recruiter's email | A1, A2, B1, B2, B3, D1, D2, E2 |
| Grow a partner channel (role-family, no source) | B2, F1 |
| A values requirement — none stated, and no values round is documented, so no VAL question | none, and why: nothing in the material raises one |

## Reverse questions

| # | Ask | Why it lands |
|---|---|---|
| 1 | To Deepa: "In 18 months, what would an operator say is different because of a good partnership with us?" | It asks for the panel's version of the close you were asked to land on, so you can set it beside yours |
| 2 | To Deepa: "What does operator partnerships cover today, and what sits outside it?" | It settles the scope your POV assumed, and it shows you checked your reading of the brief |
| 3 | To Ross: "How is influence credited against direct revenue in this role, and who decides?" | It raises your own stated limit as a question about the role's terms, instead of leaving the panel to raise it |
| 4 | To Ross: "What would commercial need from partnerships in the first quarter that would make your quarter easier?" | It is the reciprocity question: what you would bring his team, not only what you need |
| 5 | To both: "Which claim in the report are you least sure of?" | It shows an independent reading, and it invites the panel's own caveats on the document you were sent |
| 6 | To Deepa: "What would you want to have seen from me by day 90?" | It turns your plan into a shared yardstick you can be held to |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Negative you stated, F4 | The plain acknowledgment F4 gives: "I have never sold into rail specifically." No slot |
| Has carried a quota or owned revenue | Negative you stated, F4 | The plain acknowledgment F4 gives: "I have never carried a direct quota; my revenue number is influenced revenue." No slot |
| Generated, sourced or closed the £4M | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue". The limit is the pack's observation: the material says influenced, not generated or closed. B1's slots stay inside the figure |
| Knows how train operating companies work | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says bus and light rail network planning, not train operating companies. A3's slot stays inside the consulting work |
| Built the ISV channel from scratch | Inflated form of F5 | F5's quote at its own scope: "took it from 6 partners to 40". The limit is the pack's observation: the material says the channel began at 6 partners |

## Sources

Provided documents: your message, with your background in your own words and the recruiter's email as you quoted it. The market report you mention was not in the conversation, so nothing here draws on it. No dossier was present.

Searches sent (all refused, none returned anything):

- `Kelverton Rail values` — refused
- `Kelverton Rail scheduling software train operating companies strategy news` — refused
- `Deepa VP Partnerships Kelverton Rail` — refused
- `Senior Partnerships Manager rail technology job description train operating companies` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Search refused. Would have moved: VAL question themes, and a values cheat sheet only if a values round were documented, which none is. The upgrade menu offers it |
| 2. `Kelverton Rail interview process partnerships` | skipped | The recruiter's email, as you quoted it, fixes the session: one panel of two, 60 minutes, a 15-minute POV and then Q&A. Persona weights follow it |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Search refused. Would have moved: C2 and F2 from generic to company-specific, a grounding brief, and the thesis checks |
| 4. `Deepa VP Partnerships Kelverton Rail` | unavailable | Search refused. Would have moved: the panel read, with career pattern, and a reverse question tied to Deepa's path |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Search refused. Would have moved: the requirement rows and the JD-tagged raising sources |

## Upgrade menu

- JD text → the recruiter-words rows become JD rows, gate rows appear for pay, notice, location and right to work, and JD-tagged questions gain real raising sources
- The market report's text or headline sections → a grounding brief, a real consensus item and divergence for C2 and F2, and a check of T1 to T3 against it
- Permission to run web search → targets 1, 3, 4 and 5 move from unavailable: values, recent strategy, the panel's public footprint and a representative JD
- A deeper research pass, offered once → a strategy brief, the panel's talks and writing, loop reports for this role family and recent org context, at up to 6 more searches and 2 more fetches and several more minutes
- Your CV text → more evidence rows quoted from it, and F1 to F5 re-graded
- Any report or export that shows how the roughly £4M was counted → F3 moves from medium to high, and B1 becomes a walk-through instead of a slot
- Your own answers to the slots in F1 to F3 → those rows and the banks that draw on them are regenerated from your words
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence, constraints per weak area and absolute prohibited claims
