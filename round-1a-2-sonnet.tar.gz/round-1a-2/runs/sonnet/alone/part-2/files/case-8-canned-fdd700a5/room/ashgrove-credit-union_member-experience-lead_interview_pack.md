# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode: three rounds on 29 November 2026, built on the recruiter's email.

| Round | Who (role only; no names assigned yet) | Length | Relationship | Source |
|---|---|---|---|---|
| 1 | The recruiter | 30 min | Recruiter screen | Recruiter's email |
| 2 | Head of Member Services | 45 min | Your future manager; mostly behavioural | Recruiter's email |
| 3 | Panel of two branch managers; includes a 20-minute case on a complaint escalation; also the values round, scored against the four values | 60 min | Panel | Recruiter's email |

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | What it is scoring |
|---|---|
| VAL | Whether your past behaviour shows the company's published values, not generic virtue |
| EXP | Whether what you say about your own work survives follow-up questions |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company's strategy and can think at its level |
| CASE | A live problem from the role, scored on structure and reasoning |

- Guidance is scaffolding, not a script. Say it in your own words.
- An **answer slot** is an instruction for the interview, not a question for me. Fill it with what actually happened. Every slot has an honest second branch: if there was no such step, or it was not yours, say so plainly and go back to what your own words already carry.
- Provenance labels: `[grounded]` traces to a document you gave me. `[inferred]` is derived, with the derivation named. `[generic]` is a pattern for the role family, with no claim about Ashgrove or about you.
- Question IDs run across all three rounds (A to H) so you can name any one in a drill.

## Prep triage

Built on the nine days between 20 and 29 November. It does not assume hours per day. Everything not listed here is insurance.

| Order | Do this | Tied to |
|---|---|---|
| 1 | Rehearse D1 out loud until it is boring: say the contact-centre limit first, hold what your sentences carry, then give the plan. This is the highest-ROI prep in the pack | D1, F4, F5 |
| 2 | Write down your real answers to the slots (what governed the log, what the spreadsheet tracked and which tool it was in, any digital work). Send them to me and the rows upgrade | F2, F3, F4, F6, F7, F9 |
| 3 | Pick one real story for each of the four values. Write one plain sentence per story to see whether you can tell it | F1 to F4 in round 3, cheat sheet in section 10 |
| 4 | Run the 20-minute case G1 aloud against a timer, twice | G1, G2 |
| 5 | Write your own answers to pay, notice, location and the reason for leaving before the recruiter call | A2 to A5 |
| 6 | Say D2 aloud once, plainly | D2, F8 |

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is your own words only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Your words already reach the years. Say them in retail-banking terms: "I've spent six years in retail banking, the last three as a branch supervisor." Do not relabel the branch work in the JD's terms. Nothing has been inspected behind this line, so expect a probe on what the supervisor role covered |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your words stay at the log: "I handled the branch's formal complaints log." Answer slot: the JD's line makes a probe on what governed the log likely. If rules set outside your branch decided how complaints in it were handled, say which and what that meant day to day, in your own words. If it was the branch's own way of working, or you cannot say what governed it, say so plainly and stay with the log |
| F3 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your words are tellers and a script: "I trained new tellers on our escalation script." Answer slot: expect a probe on how you worked with the people you trained. If any part of how the training ran was yours to decide, say which and how you decided, in your own words. If none was, say so plainly and describe the training as your sentence states it |
| F4 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your words are the branch's log: "I handled the branch's formal complaints log." Answer slot: if any part of how the log was kept was yours to set, say which and how you decided, in your own words. If none was, say so plainly and describe how you handled the log |
| F5 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your words are the spreadsheet: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's line makes a probe on what the spreadsheet tracked likely. Say what it tracked, in your own words. If you cannot say how a figure in it was counted, say that plainly. If it tracked something else, or others contributed, say so |
| F7 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | Derived from: a spreadsheet may or may not have been built in the tool the JD names, and your sentence does not say. Answer slot: say which tool the spreadsheet was in and what you did in it, in your own words. If it was another tool, say so plainly and stay with the spreadsheet you built |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: if you have worked with a digital or product team on something members do for themselves, say what and what your part was, in your own words. If you have not, say so plainly and say how you would approach it |

No JD line is a gate: none states a licence, credential, pay, location or schedule term, and the 4+ years line is an experience requirement, graded as such in F1.

## Grounding brief

Source: your message, which summarises the strategy brief Ashgrove published in July 2026. I have not seen the brief itself, only the four points you gave. Differentiate from it rather than reciting it; the recruiter sent it to you, so assume other candidates have it too.

| Point (as you gave it) | What it could mean for this role | Provenance |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | The JD's digital-teams line (F9) is where the strategy meets this role. Expect CO questions on which complaints stay with a person (E1, E3) | [inferred] |
| "consolidate eight branches into five hubs over 2027" | Complaints cross a changing branch map. The panel are branch managers, who may have a stake in this; that is a reading, not a known fact (G3, H1) | [inferred] |
| "launch a small-business lending product in Q1 2027" | Nothing in the brief ties this to complaints. A reverse question could ask how complaints on a new product will be handled | [inferred] |
| "the main competitive pressure is app-only banks" | Frames how a complaints experience is a competitive matter (E2) | [inferred] |
| The brief is dated July 2026 | About four months old on 20 November 2026, inside the six-month freshness window for strategy | [grounded] |

## Round 1: the recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured, logistics folded into chat | Highest. The recruiter-screen prior is Conversational plus a light Skeptic, and this is the recruiter's own 30-minute slot. The risk is treating it as unscored | A1's arc uses only the quoted beats; give logistics answers that are true and short |
| Skeptic (light) | Quick knockout checks against the JD | Medium. F5 and F8 are stated absences, so a short check on them is likely; depth is the manager's job in round 2 | Plain acknowledgment plus one plan line; the full rehearsal is D1 |

### Question bank

**A. Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your journey in banking so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc with four beats, each only what its quote says: six years in retail banking; the last three as a branch supervisor; the complaints log you handled and the new tellers you trained on the escalation script; the monthly spreadsheet you built that your regional manager uses. Tell each in your own words and stop there. Close with one sentence, in your own words, on why this role. The pack does not supply your reason | The opening question of every screen and the cheapest place to sound clear. EXP because it tests whether your own claims come out plainly. The arc draws on F1, F2, F3 and F6 |
| A2 | "What's prompting you to look at a move now?" | EXP | [generic] | The reason-for-leaving slot: give your actual reason in your own words. Keep it true, and say what you are moving toward as well as what you are leaving. The pack supplies no reason | Motivation consistency is the recruiter's standing check; EXP because it must match everything else you say across the three rounds |
| A3 | "What are you looking for salary-wise?" | JD | [generic] | A logistics slot. Either give your own number, or ask for the role's band first and respond to it. The pack supplies no figure | The pasted JD states no salary, so the recruiter's question is the first place the term is set. JD because it is a term of the listed job |
| A4 | "What's your notice period?" | JD | [generic] | A logistics slot: give your actual notice period | A knockout-style logistics check. JD because it is a term of the listed job |
| A5 | "Where could you work from, and is there anything on location or travel we should know?" | JD | [generic] | A logistics slot: give your actual constraints as they are. If they depend on which site the role sits at, say that and ask which site it is | The role spans branches and the contact centre, and the brief's hub plan may change sites (see the grounding brief). JD because it is a term of the listed job |
| A6 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Choose one of the four published values (Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix) that is true for you and say why in your own words. Add one point from the strategy that connects to the role. Do not recite either list; the recruiter has both | The JD calls Ashgrove "member-owned", and the values page and brief make this answerable from documents. CO because it tests homework, not history |

**B. Skeptic (light)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre too, and I see you haven't worked in one. How do you see that?" | JD | [grounded] "Never worked in a contact centre" | Thirty seconds. The plain acknowledgment: "I haven't worked in a contact centre." Then one plan sentence: you would start by learning how complaints reach and move through the contact centre from the people who do that work. Stop there; D1 is the full rehearsal | F5 is a stated gap and a screener will check it. JD because it tests the stated remit |
| B2 | "The role asks for experience handling regulated complaints. What did that look like for you?" | JD | [grounded] "I handled the branch's formal complaints log" | Say it at its scope: "I handled the branch's formal complaints log." Answer slot: say what governed how complaints in the log were handled, in your own words. If it was the branch's own way of working, or you cannot say what governed it, say so plainly and stay with the log | F2 is the row the JD's line presses on. JD because it scores a stated requirement |
| B3 | "The role presents to senior leaders. How comfortable are you with that?" | JD | [grounded] "I've never presented to anyone above regional level" | The plain acknowledgment: "I haven't presented to anyone above regional level." Then a plan sentence: you would agree with your manager what a senior audience wants from the monthly report before the first one. Anything you have presented below that level is yours to say, in your own words, with no stretch | F8 is a stated gap; the screener is checking it is known, not fixed. JD because it tests a stated requirement |

### Reverse questions (round 1)

| # | Ask | Why it lands |
|---|---|---|
| R1.1 | "Who will be on the panel in round three, and could I know their roles ahead of time?" | Unassigned interviewers are the one thing the recruiter can resolve; it lets the pack's persona weights be tuned |
| R1.2 | "Which site would the role be based at, and does that change with the plan to consolidate eight branches into five hubs?" | Settles a location term early and shows you read the brief |
| R1.3 | "Is the 20-minute case on paper beforehand, or discussed live, and should I prepare anything?" | Format changes how G1 is rehearsed, and asking is normal |
| R1.4 | "What is the salary band and the timeline for decisions?" | Backs the A3 option of asking first, and gives you the timeline |
| R1.5 | "What does the Head of Member Services most want in the first six months from this role?" | Gives round 2 a target before you meet them |

## Round 2: the Head of Member Services (45 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time" prompts | Highest. The recruiter described this round as mostly behavioural | Map each story to a quoted sentence, or use the selection scaffold; "we" for context, "I" for contribution |
| Skeptic | Quiet, persistent probing of the gaps | High. The hiring-manager prior is to derisk gaps, and F5 and F8 are stated | Rehearse D1 until boring; name the limit before it is asked |
| Case / Strategist | Live problems from the roadmap | Medium. Hiring managers usually run live problems, but the recruiter said mostly behavioural, so three questions tied to the brief | Clarify, then structure, then answer; use the strategy's own vocabulary sparingly |

### Question bank

**C. Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you helped someone handle an escalation better." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F3, with only the beats the quote states: new tellers, the escalation script, your training of them. Answer slot: expect a probe on one occasion. If there was a moment where how someone handled an escalation changed after you worked with them, say what happened and what part was yours, in your own words. If there was no such moment, or it was not yours, say so plainly and describe the training as your sentence states it | F3 is the row nearest the JD's escalations line. VAL because it asks for a story, though the JD supplies the theme |
| C2 | "Walk me through the monthly complaints spreadsheet you built — what did it track, and who used it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Tell it at the quote: you built it, it is monthly, your regional manager uses it. Answer slot: say what it tracked and which tool it was in, in your own words. Name, before they ask, the part of it you would trust least. If you cannot say how a figure in it was counted, say that plainly. If others contributed, say so | F6 and F7 meet here, and the monthly-reporting line is a JD requirement. EXP because it is a defend-what-you-built probe |
| C3 | "Tell me about a time you had to give someone senior news they didn't want." | VAL | [generic] | A selection scaffold. Pick a time with a named piece of news, who the person was, how you said it, and what happened after, including that the hard truth landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem the manager can use to probe F8 sideways. VAL because it scores past behaviour; nothing in your material carries this story, so this is a scaffold |

**D. Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "This role owns complaints across every branch and the contact centre. You've handled your branch's complaints log and you haven't worked in a contact centre. Why should I believe you can do it?" | JD | [grounded] "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "Never worked in a contact centre" | **Highest-ROI prep in the pack.** Pause and restate the question. Say the limit first, in your first answer: "I haven't worked in a contact centre." Hold only what your sentences carry: "I handled the branch's formal complaints log, and I trained new tellers on our escalation script." Give the plan as a plan, never a past: your first weeks go on learning how complaints reach and move through the contact centre, from the people who do that work, before changing anything. Follow-up 1, "that's one branch": return to the log and widen nothing; say what you would need to learn about the other branches. Follow-up 2, "what would you get wrong first": answer slot; name the thing you would most want to check first, in your own words, or say plainly you cannot name one. Follow-up 3, "why you over someone who has run a contact centre": concede that someone who has worked in one would know that side better, then return to the quotes | This objection is built on the JD's headline responsibility, so it will arrive in some form. F4 and F5 are its rows. JD because it scores the stated remit; the pressure form is the follow-ups |
| D2 | "How much have you presented to senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level" | The plain acknowledgment: "I haven't presented to anyone above regional level." Then a plan: agree with the Head of Member Services what a senior audience wants from the monthly report, and ask to have the first one reviewed before it goes up. Anything you have presented below that level is yours to say, in your own words. Say it in plain words, once; the values reward that | F8 is a stated gap against a JD requirement. JD because it tests a stated requirement |
| D3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Pick from your own list, name it before they find it, and give a one-line plan. Do not offer a gap you do not have or hide one you do | A persona stem. Your material shows two stated gaps (F5, F8) and one silence (F9). JD because it scores honest self-assessment against the listed job |
| D4 | "What governed the complaints you handled?" | JD | [grounded] "I handled the branch's formal complaints log" | Open with "I handled the branch's formal complaints log." Answer slot: say what governed how complaints in the log were handled, whether rules set outside the branch, the credit union's own policy, or something else, in your own words. If you cannot say, or it was the branch's way of working, say so plainly and stay with the log | F2 is the deeper version of B2, and a manager is likelier to press. JD because it scores a stated requirement |

**E. Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "The plan is to move 40% of member service to digital channels by 2028. Which complaints would you keep with a person, and why?" | CO | [grounded] | Cite the 40% once to show you read it, then bring a view of your own. One option: keep a person for complaints where the member is upset or the problem is unclear, and use digital to show members where their complaint stands; concede that some members will prefer to complain digitally. The anti-pick is saying complaints should be fully self-service. Answer slot (F9): if you have worked with a digital or product team on something members do for themselves, say what and your part, in your own words. If not, say so plainly and say how you would approach it | The JD's digital-teams line meets the brief here. CO because it needs the strategy; the thesis is yours to defend |
| E2 | "App-only banks are our main competitive pressure. How does the way we handle complaints help or hurt us there?" | CO | [grounded] | Structure it two ways: where complaint handling can differ from an app-only bank, and where it must match one on speed and visibility. Say which side you would back, hold it through one follow-up, and concede the other side's strongest point | The brief names the pressure. CO because it tests altitude |
| E3 | "A digital team wants members to be able to log a complaint through a digital channel. What would you want to be true before it goes live?" | CASE | [generic] | Clarify first, then structure: what the member sees and in what words (Plain Words); who owns the complaint the moment it is logged (Own the Fix); how it reaches the log and the contact centre and branches; what you would report on it. Challenge one premise politely | Live version of the JD's self-service line. CASE because it is a decision, not a history |

### Reverse questions (round 2)

| # | Ask | Why it lands |
|---|---|---|
| R2.1 | "What would be different about complaints at six months if this went well?" | Gets their success criteria and shows you work backwards |
| R2.2 | "How are complaints split between branches and the contact centre today, and where does the handover hurt most?" | End-to-end thinking, and a cheap way to learn the contact-centre side (F5) |
| R2.3 | "Who would I report the monthly numbers to, and what do they do with them?" | Addresses F6 and F8 and signals you think about the audience |
| R2.4 | "What is the digital team working on in self-service, and where would complaints fit?" | Addresses F9 and shows you read the brief |
| R2.5 | "Is there anything in my background you'd want me to say more about?" | Invites the objection while you can still answer it, and signals you take feedback |

## Round 3: the branch-manager panel (60 minutes, with a 20-minute case)

### Persona weights

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Stories scored against the four published values | Highest. The recruiter said the panel is also the values round and scores against the four values | Cheat sheet in section 10; one story per value; "we" for context, "I" for contribution |
| Case / Strategist | The 20-minute complaint-escalation case | High. The recruiter announced it and it takes a third of the hour | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise politely |
| Peer Evaluator | "Where's the seam, what do you need from us" | Medium. Two branch managers sit beside the role. This is an inference: the pack does not know the reporting lines, and the unassigned interviewers may differ | Reciprocity: say what you bring them; propose principles for the seam, not claims about it |

With two panellists, answer to both, and give the case's reasoning aloud so each can score it.

### Question bank

**F. Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you decided something from the member's side of the counter when it was the harder thing for the branch." | VAL | [grounded] | A selection scaffold for Members First, Always. Pick a decision with a named cost to the branch, a moment you chose the member, and what followed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first published value. VAL because it scores past behaviour against that value. No quoted sentence carries this story, so it is a scaffold |
| F2 | "Tell me about a time something you wrote or said had to be explained twice. What did you change?" | VAL | [grounded] | A selection scaffold for Plain Words. Pick a time with the original wording, the moment you saw it had not landed, and what you changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Speak plainly in the interview itself: that is scored too | The second published value. VAL because it scores behaviour; no quoted sentence carries this story |
| F3 | "You'll report monthly on numbers. How do you stop a number hiding a person or a town?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Hold the quote: you built the monthly spreadsheet your regional manager uses. Answer slot: expect a probe on what it showed beyond totals. If it showed anything at branch level, say what, in your own words. If it showed totals only, or you cannot say, say so plainly and stay with the spreadsheet. Then a plan: pair each number with a reading of the branches and members behind it | Neighbours, Not Numbers pulls against the JD's monthly-reporting line (F6). VAL because it tests the value, with a CASE-like hypothetical |
| F4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F2, with the only beat the quote states: the log you handled. Answer slot: pick one problem where you can say what it was, who else had to act, and how you kept hold of it. If none ended with you holding it to the end, say so plainly and describe how you handled the log | Own the Fix is the value closest to the JD's headline responsibility. VAL because it scores past behaviour |

**G. Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "A member rings the contact centre on Friday to say a complaint she raised at her branch two weeks ago has gone nowhere and nobody has called her back. She says she is thinking of moving to an app-only bank. The branch says it passed it on; the contact centre cannot find it. You are the Member Experience Lead. Walk us through what you do." | CASE | [generic] | Clarify first: what was said, when, through which channel, and what time limits apply to the complaint. Objective: one named person holds the complaint until it is solved (Own the Fix), and the handover gets fixed. Then in order: the member today (a call in plain words, who owns it, when she hears next); tracing where it was lost without assigning blame; resolving it; confirming in plain words; recording and reporting it. Risk: branch against contact centre, with branch managers on the panel. Time-box: about two minutes on clarifying, the rest by section. The scenario is my own illustration; the panel will use its own | The recruiter announced the case, so the topic is grounded; its content here is a pattern. CASE because it tests structure and reasoning |
| G2 | "The branch manager says the supervisor handled it by the book. How do you talk to the supervisor?" | CASE | [grounded] "trained new tellers on our escalation script" | A coaching structure, said as a plan: start from what happened to the member, ask what the supervisor saw, agree one change, and check back later. No blame. Answer slot (F3): if you have coached a peer or someone more senior on an escalation, say so in your own words. If not, say so plainly and describe the training as your sentence states it | Extends G1 into the JD's escalations line. CASE because it is a live problem |
| G3 | "We're consolidating eight branches into five hubs over 2027. What happens to complaints for a member whose branch becomes part of a hub?" | CO | [grounded] | Ask before answering: what changes for the member, and what stays the same. Then structure: the member's route in, one owner, the same plain words, and how the monthly report shows hub and branch. Do not take a side on the decision; the panel may be affected, which is an inference | The brief's consolidation meets Neighbours, Not Numbers. CO because it needs the strategy |

**H. Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Where's the seam between a branch and the Member Experience Lead on a complaint, and what happens when we disagree about a case?" | JD | [generic] | Offer principles for the seam, not claims about it: the one who finds it keeps hold of it until it is solved, the member hears from one person, and a disagreement goes to the member's outcome first. Say you would want their view of where it sits today | Seam-splitting is the peer's core probe. JD because it tests the role's remit |
| H2 | "How do you handle credit when a fix spans teams?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: if anyone else contributed to the spreadsheet or the log, say who and how you credit them, in your own words. If it was yours alone, say so plainly. Give a principle: credit where it was earned, and no one's fix lost in the handover | A persona stem. VAL because it scores behaviour toward others |
| H3 | "What would you need from us, and what could we count on from you?" | JD | [generic] | Lead with what you offer them: a single owner for each complaint and a monthly picture of their branch. Then what you need: their view of the seam and early notice of cases. Propose a first-month practice rather than claiming to know theirs | The reciprocity move for a peer panel. JD because it tests the working relationship the role needs |

### Reverse questions (round 3)

| # | Ask | Why it lands |
|---|---|---|
| R3.1 | "How do complaints reach the Member Experience Lead today, and what is most frustrating about that from a branch manager's seat?" | Invites their pain and treats them as partners |
| R3.2 | "When a complaint goes wrong between a branch and the contact centre, what do you wish had happened?" | Own the Fix, in their words |
| R3.3 | "What could a new person in this role do in the first month that would help your branch?" | The peer reciprocity question |
| R3.4 | "What would you want a member to experience when something goes wrong in a branch that is becoming part of a hub?" | Neighbours, Not Numbers meets the brief, and you stay curious rather than taking a side |
| R3.5 | "Which of the four values is hardest to live up to day to day, and what does it look like when it's done well?" | Shows you took the values seriously and gives you their working definition |

## Section 10: Values cheat sheet (round 3)

Value names are as published on the page you pasted. None of your quoted sentences carries a story for any value, so every row is a selection scaffold. Say a story only if it is true.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold (F1): a named cost to the branch, a moment you chose the member, what followed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs it explained twice, the wording failed | Scaffold (F2): the original wording, the moment it didn't land, what you changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Neighbours, Not Numbers | Every branch is part of its town | F3 holds "I built the monthly complaints spreadsheet our regional manager uses" at its scope; anything about what it showed at branch level is the F3 answer slot. If it showed totals only, say so plainly |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | F4 holds "I handled the branch's formal complaints log" at its scope; the rest is the F4 slot. If none ended with you holding it, say so plainly |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | B1, D1, G1, G3, H1 |
| Report monthly on complaint volumes and resolution times | C2, F3 |
| Coach branch supervisors on escalations | C1, G2 |
| Work with digital teams on self-service journeys | E1, E3 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | B2, D4 |
| Confident presenting to senior leaders | B3, D2, D3 |
| Comfortable with Excel reporting | C2 |
| The four published values | F1, F2, F3, F4 |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says the branch's log, not the process across branches or the contact centre. D1's slots stay inside the log |
| Has handled regulated complaints | Inflated form of F2 | F2's quote at its own scope. Your material says a formal complaints log and does not show what governed it. B2 and D4 ask only what governed the log |
| Coached branch supervisors on escalations | Inflated form of F3 | F3's quote at its own scope. Your material says tellers and a script, not supervisors. C1 and G2 stay inside the training |
| Has contact-centre experience | A negative you stated, F5 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Is experienced in presenting to senior leaders | A negative you stated, F8 | The plain acknowledgment: "I haven't presented to anyone above regional level." No slot |
| The monthly spreadsheet reported complaint volumes and resolution times | Inflated form of F6 | F6's quote at its own scope. Your material does not show what it tracked. C2 and F3 ask what it tracked |
| Built the reporting in Excel | Inflated form of F7 | F7's quote at its own scope. A spreadsheet is not a named tool. C2 asks which tool |

## Sources

Provided documents: the JD you pasted; the four values pasted from the values page, copied on 20 November 2026; the recruiter's email; your summary of the July 2026 strategy brief (the brief itself was not seen); your background message. No dossier was present. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values are in hand and fix section 10 and the VAL bank |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email gives three sessions with who runs each and what each holds, so the loop and persona weights are fixed |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The four points you gave from the July 2026 brief fix the grounding brief and the CO bank. The brief itself is the upgrade-menu item |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names were given, only roles, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewers' names, once assigned → an interviewer read, persona weights tuned to each, and a reverse question tied to each person's path
- The strategy brief itself, pasted → CO and CASE questions built on its own wording and numbers instead of a four-point summary
- Your typed answers to the slots in F2, F3, F4, F6, F7 and F9 → each becomes quoted evidence, and those rows and the questions that draw on them regenerate with story maps in place of slots
- A redacted page of the monthly complaints spreadsheet with member details removed, and the written escalation script, if you may share them → F6 and F3 could move from medium to high
- A CV → quote-ready lines for F1 to F4 and fewer reliance on your message alone
- The recruiter's reply on the case format (R1.3) → G1 rehearsed to its real shape
- Hours per day available → resizes the prep triage
- Your country or the complaints regulator's name → D4 and G1 could be sharpened to the rules that apply, which I would research on your say
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → loop reports, recent organisation context and the interviewers' public footprint, if you want it
- A `tuesday-dossier.md` from an earlier check of this role → the highest-ROI objection would come from recorded evidence instead of inference
