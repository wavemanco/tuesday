# Interview pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager, in a single 60-minute session (the pack's reasoning is in the persona table; if either assumption is wrong, the weights change).

## How to use this pack

Personas describe how a question is asked; types describe what is scored. Guidance is scaffolding for your own words, not a script, and every claim about your past rests on a sentence you wrote, quoted next to it.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether the claims about your experience survive scrutiny |
| JD | Whether you can do the listed job, including its gaps |
| CO | How well you know the company and its current strategy |
| CASE | Structure and reasoning on a live problem from the role |

The highest-ROI prep in this pack is B1, the question about coordinating four disciplines without having led a team. B2 (in-app purchases) is a close second. Rehearse both until they are boring.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a content-drop calendar for the main title, with nothing inspected behind it. It does not say live events, and it does not say two titles. Words, at the quote's scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's "two of our mobile titles" makes a probe on handling two calendars likely. If you ever worked across more than one calendar, say how; if not, say so plainly and stay with the main title's calendar. Likewise, if any of the drops were time-limited events, say how they differed from ordinary drops; if none were, say so |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show work with any of these four teams. "Never led a team" says nothing about coordinating, and the JD's verb is coordinate. Answer slot: if you worked with design, art, engineering or community on the content drops, say which, what you needed from them and how you got it, in your own words; if you did not, or it was not your role, say so plainly and stay with the calendar and the checklist |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | discovery | The quote shows presenting retention numbers monthly. It does not show whether you set the KPIs or ran any review of a release. Words, at the quote's scope: "I presented the monthly retention numbers to the studio head." Answer slot: if the figures you presented were ever discussed against a particular drop, say what you said and what was decided; if they were not, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: "I wrote the release checklist our QA team still uses." Manage is the JD's verb, not yours |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | The quote gives four years in an associate producer role. It does not say whether the main title was live-service. Answer slot: if the main title was a live game receiving ongoing updates, say so in your own words; if it was not, say what it was. The title is associate producer, and the JD says producer, so expect that to be noticed |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, with nothing inspected behind it. Lead with the quote's terms: weekly, main title, two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Presenting a figure is not the same as owning how it was counted, so expect the probe in D1 and keep to "presented" |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist is writing, but the quote does not show who it reached or how clear it was. Answer slot: if there is other writing of yours that people used, such as notes or reports, name it in your own words; if the checklist is the clearest example, say so plainly and stay with it |
| F9 | Comfort with a monetized live game: role-family, not in the JD; the season-pass move in Sources makes it likely to come up | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [generic] | capability | You stated this one, so the words are yours: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing is added to make the gap smaller |

## Reading the interviewer

Public professional footprint only.

| # | What is public | Source | What it means for Friday | Provenance |
|---|---|---|---|---|
| I1 | Head of Live Operations at Saltmarsh Games; previously a QA lead at a console studio | GDC 2026 talk page, search snippet | He will read release process and QA hand-offs closely. D3 and C3 are where that shows | [grounded] |
| I2 | GDC 2026 talk "Patch Notes Are a Promise": a live team is judged by how often its patch notes describe what actually shipped | GDC 2026 talk page, search snippet | His own framing matches the value "Ship the Patch Not the Promise". Honest "what shipped" language will land; hopeful language will not. Watch the talk before Friday and refer to it only if you did | [grounded] |
| I3 | Mirror opportunity: his path runs through QA; your side of it is "Wrote the release checklist our QA team still uses." (F4) | The two rows above, F4 | A shared professional touchpoint, not a shared identity. Use the quote at its own scope and let him ask about the rest | [grounded] |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A, 5 questions) | A live outage during an event, then follow-ups | Highest. The careers page says the interview opens with a live-incident tabletop on a simulated outage during a live event, and a hiring manager's prior is live problems | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (bank B, 4) | Quiet probing of the gaps in F1, F2, F5 and F9 | High. A hiring manager derisks gaps, and the gaps here are stated in your own message | Rehearse B1 and B2 until boring; bridges only from your quoted sentences; the limit said plainly |
| Values / Behavioral (bank C, 4) | A values conversation after the tabletop | Guaranteed in this session. The careers page documents a values conversation as the second half of the hour | One story per published value where a quote carries one, a selection scaffold with its honest branch where none does |
| Data-Driven Prober (bank D, 3) | Counting questions on the retention numbers and checklist questions | Medium. Retention is a named requirement, and his QA background makes checklist depth likely | Say plainly how much you know about how each number was counted; name the weakest assumption first |
| Pressure (bank E, 2) | Time-boxed, "how much was actually you" | Lower-medium. A tabletop is time-pressured by design, and attribution probes follow any CV | Pause, restate, hold two follow-ups, concede specifically |
| Conversational (bank F, 2) | The opening journey question | Lower. A friendly register at the start, but still scored | A 90-second arc built only from your quotes |
| Peer Evaluator | Not included | Dropped. The relationship is assumed to be hiring manager, so no peer-style round is expected | If Friday turns out to include a peer, tell me and I will add bank G |

Loop note: the careers page names one 60-minute session with the hiring manager as the shape of the interview, so no archetype fallback is used. A values-style round is detected because that page documents a values conversation.

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Day two of a live event, and the reward screen stops loading for a share of players. You have the first ten minutes. What do you do, and who do you talk to?" | CASE | [generic] | Clarify first: what is affected, since when, on which platforms, how many players, what is known and what is guessed. Objective: protect the players and keep what you say true. Then who needs to know and what each needs: engineering, QA, community, design and art. What players are told and when, and what you record for the review afterwards. Name one premise you would challenge, such as whether the event should keep running while it is broken. The question needs no claim about your past, so the guidance makes none | The tabletop is the documented first half of the hour, so this is the likeliest opening. CASE because it asks for structure on a live problem; `[generic]` because it is a pattern, not Saltmarsh's actual scenario |
| A2 | "Engineering says the fix needs two hours, and the event ends in three. Players are asking questions in the community channels. What do you say, and what do you do about the event?" | CASE | [generic] | State what you know and what you do not, and give a time for the next update. Lay out the options (extend, compensate, leave it) and say what fact would choose between them. The published value "Players Before Plans" says that when the calendar and the players disagree, the players win, so the calendar flexes. Concede openly what depends on facts you do not have yet | A follow-up escalation is how a tabletop tests whether the structure holds. CASE with a VAL flavor, because the published value is the likely scoring lens |
| A3 | "We are moving to one shared events calendar across titles. What breaks first when two titles share a calendar, and how would you find out?" | CO | [grounded] | Do not recite the announcement. Ask what shared means in practice, then segment: players who play both titles, content collisions, team capacity, release checklists. Say how you would find out: look at the calendar, then ask each team. Challenge one premise, such as whether a single calendar is the right unit. Bring one fact from the announcement to show you read it, then your own view | Research at L1 found the September 2026 announcement, so a strategy-grounded question is owed. F1 is the experience gap behind it. CO because it tests company knowledge; CASE delivery |
| A4 | "You would plan the calendar for two titles. How would you spend your first two weeks?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Ask what is already scheduled, what is locked, and which team needs the longest lead time. Then inventory both titles, mark dependencies by team, look for collisions, and decide how the plan gets reviewed. Your own reference point is the quote, at its scope: the main title, weekly, two years. Answer slot: if you ever worked across more than one calendar, say how; if not, say so plainly and stay with the main title's calendar | F1 is the JD requirement that presses hardest, and F6 shows what is solid underneath it. JD because it scores the stated requirement; CASE delivery |
| A5 | "A patch note went out saying a fix shipped. It did not. Give me the correction you would post, in two or three sentences." | JD | [generic] | Say what is true now, what did not ship, what happens next and when players will hear again. No excuses and no hope-language: the published value "Ship the Patch Not the Promise" says to announce what is built, not what is hoped. Say the correction aloud, since it is a spoken sample of your writing. The question needs no claim about your past | F8 is the only row with no strong written-communication evidence, and this tests it live. JD content, CASE delivery, and it matches a published value and the interviewer's public theme (I2) |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background doesn't include leading a team, and this job puts four disciplines behind every update. How would you get them there without being anyone's manager?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | **Highest-ROI rehearsal in the pack.** Start with the plain acknowledgment: "I've never led a team." Hold what the JD actually says: its verb is coordinate. Answer slot: if you worked with design, art, engineering or community on the content drops, say who, what you needed from them and how you got it, in your own words; if you did not, or it was not your role, say so plainly and stay with the calendar and the checklist. Then a plan, said as a plan: ask each discipline for its lead times and blockers, put dependencies in writing, and take calendar conflicts to Tobias. Follow-up 1: if asked about a disagreement, give the nearest real one or say none comes to mind. Follow-up 2: if pressed on authority, concede it plainly and return to what you would do. Never claim leadership you did not have | F2 is the biggest unquoted gap and Never led a team is stated in your message, so the objection is both likely and sourced. JD because it scores the coordinate requirement; Skeptic because it targets the gap |
| B2 | "You haven't worked on a game with in-app purchases. How would you plan events for a title where they matter?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment first: "I've never worked on a game with in-app purchases." Hold the part you do have, in the quote's scope: "I ran the weekly content-drop calendar for our main title for the last two years." Then the ramp as a plan: what you would ask first about how events connect to the store and the pass, who on the live-ops group could teach it, and what you would check in the first month. Follow-up: if asked how you would know an event was hurting the economy, say you would not know yet and say how you would find out. No slot, because this is a stated absence | F9 is a stated capability gap, and the season-pass move in Sources makes the probe likely. EXP because it tests what your experience does and does not reach |
| B3 | "You have run a calendar for one title. This role has two. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Concede that you do not know the second title's load. Answer slot: if you ever worked across more than one calendar, say how; if not, say so plainly. Then what you would ask first: overlap in players, lead times and which team is the constraint. If the calendar is shared, the question becomes collisions between titles | F1 directly. JD because it scores the two-titles requirement |
| B4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Choose one you can say truthfully and name it plainly. On this material the clearest is in-app purchases: "I've never worked on a game with in-app purchases." Then what you would do about it in the first month. If a different gap feels larger to you, name that one instead. Do not offer a gap and then argue it away | A staple Skeptic stem; the honest answer is rehearsed so it sounds calm. JD because it scores self-assessment against the listed job |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time what the calendar needed and what players wanted pulled in different directions." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Value: Players Before Plans. No quoted sentence carries this story, so this is a selection scaffold: pick a time a scheduled drop and the players' experience diverged. It needs a named stake, what you did to the calendar, and who agreed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the weekly content-drop calendar for our main title for the last two years", or how you would handle it | Every published value gets a mapped question when a values conversation is documented. VAL because it scores behavior against a named value |
| C2 | "Tell me about a time you told people what was built rather than what you hoped." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Value: Ship the Patch Not the Promise. A selection scaffold: pick a time you reported something less good than hoped, or corrected something already said. It needs what was promised, what was actually true and how you said it. If none comes to mind, say so plainly, then give the nearest thing your material carries, "I presented the monthly retention numbers to the studio head", at that scope, or how you would handle it. Do not describe the numbers as unwelcome unless they were | Matches the interviewer's public theme (I2) as well as the value. VAL because it scores behavior against a named value |
| C3 | "Tell me about a time a release taught you something that changed your checklist." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Value: Leave the Build Greener. The quote carries two beats, at its own scope: "I wrote the release checklist our QA team still uses." Answer slot: the value says every release leaves the checklist better than it found it, so expect a probe on whether the checklist changed. If you changed it after a release, say what prompted it and what changed; if it never changed, or someone else changed it, say so plainly and stay with the two beats the quote carries | F4 is your most solid row and the value names the checklist outright. VAL because it maps a quoted story to a published value |
| C4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | A selection scaffold, since the quote shows presenting and not unwelcome news: pick a time the content was unwelcome, say what you said, and what happened to the relationship. If none comes to mind, say so plainly, then give the nearest thing your material carries, "I presented the monthly retention numbers to the studio head", or how you would handle it | A standard values stem, and the monthly presentation is your only quoted contact with leadership. VAL because it scores candor |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold the quote: "I presented the monthly retention numbers to the studio head." Four slots, in your own words: how the figure was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Never describe a method you did not use | F7 is a quoted claim with nothing inspected behind it, and a Prober goes straight to the denominator. EXP because it tests attribution |
| D2 | "Retention for players who joined during an event is down a week later. How do you diagnose it?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Clarify: down against what baseline, which cohort, and did anything else ship or break that week. Then segment, check in a sensible order and say which assumption you would test first. Answer slot: if you have diagnosed a retention change yourself, say what you looked at first; if not, say so plainly and walk through the method as you would run it | The retention requirement scored live. JD content, CASE delivery |
| D3 | "Walk me through the release checklist you wrote for QA." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Say what you can at the quote's scope: you wrote it, and QA still uses it. Answer slot: the JD says manage the checklist with QA, so expect a probe on how you worked with QA on it. If you did, say how; if QA owned it afterwards, or you did not work with them on it, say so plainly and stay with the two facts the quote carries | His QA background (I1) makes this the likeliest deep dive. EXP because it tests whether the line survives scrutiny |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "The calendar and the checklist. How much of that was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | Pause and restate the question. Hold what the quotes carry: "I ran the weekly content-drop calendar for our main title for the last two years" and "I wrote the release checklist our QA team still uses." Answer slot: if someone else set any part of either, say which part and how; if none, say so plainly. Hold through two follow-ups, then concede specifically, never on the core claim | The standard attribution stem. EXP because it tests precision, with Pressure delivery |
| E2 | "Sixty seconds. Why should we take an associate producer who has never led a team?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "Never led a team, and never worked on a game with in-app purchases." | Acknowledge, then give what you carry, in the quotes' words: "I ran the weekly content-drop calendar for our main title for the last two years", the checklist QA still uses, and the monthly retention presentation. Do not argue that you are better than someone who has led a team. Hold through the follow-up, then concede what is true | F5 and F9 together create this objection. JD because it scores the fit against the listed role |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | A 90-second arc built only from your quotes: four years as an associate producer at a puzzle-game studio, then the weekly content-drop calendar for the main title for the last two years, the checklist and the monthly retention presentation. Answer slot: if the main title was a live game receiving ongoing updates, say so in your own words; if it was not, say what it was. Why live operations, and why now, is yours to say in your own words | F5 is the "3+ years" requirement, and a casual biography question is where it gets checked. JD content, conversational delivery |
| F2 | "What do you know about how we run live operations?" | CO | [grounded] | Use only what you actually read: the values page, the interviewing page, the September 2026 announcement. Name a value only if you can say what it means in your own words. Bring one fact and one view of your own, and do not recite | Homework depth, asked casually. CO because it tests company knowledge |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A3, A4, B3 |
| Coordinate design, art, engineering and community on each update | A1, B1 |
| Own the post-event review and the KPIs it reports | D1, D2 |
| Manage the release checklist with QA | D3, C3, E1 |
| 3+ years producing live-service games or apps | F1, E2 |
| Experience running a content calendar | A4, B3, E1 |
| Comfortable with player-retention metrics | D1, D2 |
| Clear written communication | A5 |

## Values cheat sheet

Values are quoted by name from the company's values page.

| Value | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold in C1, ending in its honest branch |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold in C2, ending in its honest branch |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "In your talk you argue a live team is judged by how often its patch notes describe what actually shipped. How does your team measure that today?" | Ties to his own public work. Ask it only if you have watched the talk |
| R2 | "With the move to a single live-ops group, what does the first shared calendar need to prove by February?" | Shows you read the announcement and turns the strategy into a practical question |
| R3 | "How much of this role's calendar is tied to the store and the season pass, and who would teach me that side?" | Honest about F9 and converts the gap into a ramp plan |
| R4 | "What does the post-event review look like today, and which KPIs does it report?" | Maps to the JD's own words and tells you what you would inherit |
| R5 | "Which of the four disciplines is hardest to keep aligned on an update, and why?" | Shows you think about coordination as a problem, not a title |
| R6 | "What would make someone clearly excellent in this role at six months?" | A forward-looking question that shows you are thinking about the work, not the offer |

## Prohibited claims

Not coached in any cell of this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed teams | Negative you stated, F9's quote | "I've never led a team." No slot |
| Has worked on a game with in-app purchases | Negative you stated, F9's quote | "I've never worked on a game with in-app purchases." No slot |
| Ran the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one title's content drops |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says presenting monthly retention numbers |
| Managed the release checklist with QA | Inflated form of F4 | F4's quote at its own scope: "I wrote the release checklist our QA team still uses." Manage is the JD's verb |
| Owned how retention is counted | Inflated form of F7 | F7's quote at its own scope. D1's slots ask only what you know about how it was counted |

## Sources

Provided: your message, containing the JD text and your background. No CV file and no dossier.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Query or fetch | Returned |
|---|---|
| Search: Saltmarsh Games values | https://saltmarshgames.com/values |
| Search: Saltmarsh Games interview process live operations producer | https://saltmarshgames.com/careers/interviewing |
| Search: Saltmarsh Games strategy news mobile | https://saltmarshgames.com/news/project-larkspur (snippet only) |
| Search: Tobias Wrenfield Saltmarsh Games | https://talks.gdconf.example/2026/patch-notes-are-a-promise (snippet only) |
| Fetch: https://saltmarshgames.com/values | Page text: three values and their definitions |
| Fetch: https://saltmarshgames.com/careers/interviewing | Page text: recruiter call, then a single 60-minute interview with the hiring manager, tabletop then values conversation, no take-home |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | yes | Values cheat sheet; three named values; C1 to C3 |
| 2. Interview process | yes | Loop structure; persona weights follow the tabletop and values conversation |
| 3. Strategy and recent news | yes | A3 and R2; the announcement page itself was not fetched, so only its summary line is used |
| 4. Interviewer | yes | Interviewer read; R1; the talk page was not fetched, so only its summary line is used |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Confirmation that Tobias is the hiring manager and that Friday is the Outage Hour → persona weights confirmed, or bank G added for a peer
- The recruiter's prep email → any stated focus areas, and whether the tabletop has pre-reading
- Your answers to the slots in F1, F2, F3, F5 and F8 → those rows move from discovery toward grounded stories, and the matching bank cells become story-mapped
- The checklist itself, a calendar export or the retention deck, redacted → confidence on F4, F6 and F7 can rise from medium to high
- The full Project Larkspur announcement pasted → A3 and R2 get specifics instead of a summary line
- A transcript or slides from his GDC talk → R1 can be tailored to what he actually said
- A `tuesday-dossier.md` from a prior role evaluation → the highest-ROI objection and the weak-area strategies come from evidence rather than inference
