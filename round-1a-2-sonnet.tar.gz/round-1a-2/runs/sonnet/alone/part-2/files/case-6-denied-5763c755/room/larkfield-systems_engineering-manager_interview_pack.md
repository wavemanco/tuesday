# Interview pack — Engineering Manager, Larkfield Systems (three-round loop)

**Candidate:** Yusuf. **Role:** Engineering Manager, Larkfield Systems.

| Round | When | Who | Relationship | Length |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering (name not given) | Hiring manager, your would-be boss | 45 min |
| 2 | The Thursday after | Two staff engineers and a product manager (names not given) | Panel | 60 min |
| 3 | The following Monday | VP Engineering (name not given), described by the recruiter as "values and leadership philosophy" | Skip-level executive | 30 min |

Loop mode: one shared fit snapshot, then a mini-pack per round with its own persona weights, question bank and reverse questions. The prohibited claims, sources and upgrade menu are shared and sit at the end.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows values and leadership philosophy, not generic virtue |
| EXP | Whether your own claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge, and thinking at the company's altitude |
| CASE | A live problem from the actual role, scored on structure and reasoning |

Guidance is scaffolding, not a script. Every sentence about your past comes from something you wrote, quoted in the fit snapshot. Where the material does not say, the cell is an answer slot, an instruction for the interview with two honest branches. Answer slots ask nothing of you here.

## Prep triage

Sized to the three dates, in order. Do these well; everything else is insurance.

| Before | Do | Where |
|---|---|---|
| Tuesday | Rehearse B1 until it is boring; it is the highest-ROI prep in this pack | B1, then B2 and B3 |
| Tuesday | Say the reliability-quarter sentence and the team-of-6 sentence aloud at their own scope | C1, C2, A2 |
| Thursday | Be ready to be taken apart on your two figures, 60% and about 40 | D1, D2, D4 |
| Thursday | Practise the hardware seam answer in a collegial register | E3 |
| Monday | Choose one principle you actually act on, and say it in your own words | G1, G2 |
| Monday | Rehearse the sixty-second hold on hardware and the "how much was you" hold | H1, H2 |

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the role description in your message. Evidence is your own words and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description, your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says a team lead of 6 for 3 of 9 years, with nothing inspected behind it, and the words stay there: "Of my 9 years in engineering, 3 were as a team lead of 6." Answer slot: the role description's two squads make a probe on leading beyond one team likely. If you have coordinated work across more than one team, say how and which part was yours, in your own words; if not, or it was not yours, say so plainly and stay with the team of 6 |
| F2 | "own delivery, hiring and growth for 11 engineers" — role description, your message (the delivery strand) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Your material says a reliability quarter pushed through against roadmap pressure, and the words stay there: "I pushed a reliability quarter through against roadmap pressure." It does not say who owned the delivery plan. Answer slot: "own delivery" makes a probe on how delivery was owned likely. If delivery commitments were yours to set or answer for, say which and how, in your own words; if not, or there was no such commitment, say so plainly and stay with the reliability quarter. The 60% is a figure, so four slots apply: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours |
| F3 | "own delivery, hiring and growth for 11 engineers" — role description, your message (the hiring strand) | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap in role terms, but a line from your message with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: "I run our hiring loop for backend roles." The "about 40" is a figure, so the same four slots apply: what the 40 counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Whether you decide hires is not in the material; D4 holds that as a slot |
| F4 | "own delivery, hiring and growth for 11 engineers" — role description, your message (the growth strand) | none given | none | [grounded] | discovery | Your material does not show growth work. Answer slot: the role description names growth, so expect a probe on it. If you have helped engineers grow, say who, what you did and what changed, in your own words; if not, or it was not yours, say so plainly and say what you would do first |
| F5 | "partner with hardware and product on roadmap" — role description, your message (the hardware strand) | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. The role description says partner and your sentence says own; the pack reads neither into the other. Never a claim to hardware roadmap work |
| F6 | "partner with hardware and product on roadmap" — role description, your message (the product strand) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | Your sentence says roadmap pressure, not who applied it or how the quarter was agreed. Answer slot: the role description's product partnership makes a probe on working with product likely. If you worked the quarter out with product, say with whom and how, in your own words; if not, or there was no such negotiation, say so plainly and stay with "I pushed a reliability quarter through against roadmap pressure." |

F6's derivation: the quoted sentence touches roadmap tension, which is adjacent to product partnership; it does not show it.

The role description gives no gates (no location, travel, pay or credential terms), so no row is a hard gate.

## Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| Lead two squads building device-management services (F1) | A3, B2, B3, G3 |
| The device-management domain itself | A4, D3, I2 |
| Own delivery (F2) | A1, A2, D3, E2 |
| Own hiring for 11 engineers (F3) | D2, D4, G4 |
| Own growth for 11 engineers (F4) | B4 |
| Partner with hardware on roadmap (F5) | A1, A3, B1, E3, H1, I1 |
| Partner with product on roadmap (F6) | A1, A2, E2, F3 |
| Headline figure: 60% on-call drop | C2, D1, H2 |
| Headline figure: about 40 interviews | D2 |
| Values and leadership philosophy (recruiter's words, Monday) | F1, F2, F3, G1, G2, G3, G4 |

---

# Round 1 — Tuesday, 45 min, Director of Engineering (hiring manager)

## Persona weights

| Persona | How it shows up | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | Live problems from the two squads' roadmap | high | Relationship prior for a hiring manager (personas.md); your note says this is your would-be boss, and no interviewer profile exists to move it | Clarify, then objective, options, decision rule, risks; think aloud |
| Skeptic | Quiet probing of the gaps | high | Same prior; two of your own sentences name gaps (managing managers, hardware roadmap), so the objection is already in the material | Rehearse the likeliest objection until it is boring: plain acknowledgment, then a plan |
| Conversational | The opening "walk me through" | medium | Opens most conversations in a 45-minute slot; still scored | A 90-second arc built only from your own sentences |
| Prober, Peer, Pressure, Values | Follow-ups, seam questions, composure checks | low | Covered in rounds 2 and 3, where the relationship priors put them | Not weighted here |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Hardware wants a firmware-compatibility fix, product wants a customer-facing feature, and you can staff only one this quarter. How do you decide, and what do you need to know first?" | CASE | [generic] | Clarify first: what each request protects or costs, who is affected, and what happens if each waits. Then name the objective, two or three options, the decision rule you would use, the risks, and how you would tell each partner the outcome. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | A live problem built from the role's two partner lines (F5, F6). CASE because it scores structure; generic because no Larkfield facts could be researched |
| A2 | "Product asks you to pull two engineers off reliability work mid-quarter for a customer deadline. Walk me through what you would do." | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure it: what you would ask first, the options, the rule that decides, and what you would say back to the product manager. If you reach for your own history, say only what the sentence says: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you know how that quarter was agreed or what it cost the roadmap, say it in your own words; if you do not, or it was agreed some other way, say so plainly and stay with the sentence. Do not present the 60% as the result of the decision you describe here | F2 and F6 are where delivery and product partnership meet your one roadmap-tension sentence. CASE because the delivery is a live decision |
| A3 | "You inherit 11 engineers across two squads and a delivery plan someone else wrote. What do you do in your first 30 days?" | CASE | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Structure: listen first, understand the plan and where it is fragile, meet the people, agree what to stop. When hardware dependencies come up, say it plainly: "I've never owned a hardware-adjacent roadmap." Then give the plan as a plan: what you would ask hardware counterparts, in what order, in your own words. Nothing in this answer describes what you have done with hardware | F1 and F5 are what a first-30-days question presses on. CASE because it is hypothetical; the quote is there only so the acknowledgment has its source |
| A4 | "What makes device management hard in an industrial setting, and where would you point two squads first?" | CO | [generic] | Give a point of view as a view, not as a fact about Larkfield: pick two or three tensions you would test, say what you would ask the interviewer to confirm, and say how you would tell you were pointing the squads the right way. No company fact is supplied here because the research searches were refused; add only a fact you have read yourself | CO because it tests altitude on the domain. Generic because no strategy source was available; the upgrade menu says what would change that |
| B1 | "You've never owned a hardware-adjacent roadmap, and this role partners with hardware on ours. Why should I be comfortable with that?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Hold through two follow-ups by staying with that sentence and giving a plan, not a past: what you would ask hardware counterparts first, and what you would want the Director to teach you in the early weeks. If pressed, concede specifically: you would be learning this seam on the job. Answer slot: the role description says partner with hardware. If you have worked with hardware or firmware counterparts in any way, say what and which part was yours, in your own words; if you have not, say so plainly. The limit, named before it is asked for: the material says own, not partner, and the pack reads neither into the other | F5 is the gap you named yourself and the role description puts hardware partnership in its roadmap line, so this objection arrives in some form. JD because it scores a stated requirement |
| B2 | "You've led a team of 6. This is two squads and 11 engineers. What changes?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Say what is in the sentence: "Of my 9 years in engineering, 3 were as a team lead of 6." Answer slot: if you have coordinated work across more than one team, say how and which part was yours, in your own words; if not, or it was not yours, say so plainly and stay with the team of 6. Then say what you would expect to change as a plan: what you would learn about the second squad before deciding anything. Hold through two follow-ups; concede only what you do not yet know, such as how the squads are structured today | F1 is the evidence for the squad-leadership line and the likeliest place to be probed on scale. EXP because it tests what was actually yours |
| B3 | "You haven't managed managers. How do you think about that if one of the squads has a lead?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Plain acknowledgment: "I've never managed managers." Then turn the question back instead of answering about a past you do not have: ask how the two squads are structured today. Give what you would do first as a plan, such as meeting each lead before changing anything. Describe no experience of managing managers; the material carries none. The acknowledgment is the whole claim, so hold it | The negative is yours and sourced, so the question may presuppose it; F5's quote carries it. JD because it probes the role's structure rather than your history |
| B4 | "Tell me about a time you helped an engineer grow." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Selection scaffold: pick a time with a named person, something you did yourself, and a change you can describe afterwards in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is the team of 6 at its own scope, or how you would approach growth for 11 engineers. Answer slot: the role description names growth, so expect a follow-up on what you would do in the first quarter; give your own plan | F4 has no evidence in your material, so the honest form is a scaffold with its fallback. EXP because it asks for a real instance; the theme comes from the role description |
| C1 | "So, walk me through the journey. How did you get here, and why this role?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc with three beats the sentence states: 9 years in engineering, 3 as a team lead of 6, currently at a payments company. Answer slot: the reason for this role is yours to give, in your own words; if the honest reason is a step from team lead toward managing a larger group, say that plainly rather than reaching for the company's language | F1 is the whole of the biography material. EXP because it checks the story hangs together; asked casually, so it is easy to underprepare |
| C2 | "I see on-call dropped 60% on your team. Tell me about that quarter." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The beats the sentence states: on-call burden dropped 60%, you pushed a reliability quarter through, against roadmap pressure. Say "after", not "because". Weakest-assumption move: name, in your own words, the assumption behind the 60% you would defend least before they do. Answer slots: how the figure was counted; what it is sensitive to; which part was yours. If you do not know how it was counted, say so plainly | F2 is where the pack's one headline figure lives, and every later round returns to it. EXP because it checks attribution; delivered in a friendly register |

## Reverse questions for round 1

| # | Question | Why it lands |
|---|---|---|
| V1 | "What does success look like in this role at 90 days and at 12 months?" | Gives you the scoring sheet the rest of the loop is judged against; it bears on F1 and F2 |
| V2 | "How are the two squads structured today, and is there a lead under the manager in each?" | Settles the managing-managers question in F5's sentence from the employer's side instead of leaving it as a guess |
| V3 | "How does hardware's roadmap reach the squads today, and where does it hurt?" | Meets F5 by asking to learn the seam, which is the plan B1 rehearses |
| V4 | "What is the biggest delivery risk on the squads right now?" | Moves the conversation to F2's territory as a problem you are helping with |
| V5 | "What would tell you in the first 30 days that a new manager is on track?" | Hands you the interviewer's own test, and fits A3's plan |

---

# Round 2 — Thursday, 60 min, panel: two staff engineers and a product manager

No names were given, so persona weights follow the blended relationship priors for each seat, not the individuals.

## Persona weights

| Persona | How it shows up | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | Staff engineers pressing on figures and technical depth | high | Technical-specialist prior (personas.md) for two of the three seats; your two figures are the obvious targets | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know |
| Peer Evaluator | Seam questions with staff engineers and the product manager | medium | Collaboration probes fit all three seats, and the role description puts partnership with product on its roadmap line | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Values/Behavioral | The product manager's scenario probes | medium | Cross-functional prior; a behavioural conversation from outside the function | Selection scaffolds with their honest branch; "we" for context, "I" for contribution |
| Case/Strategist, Skeptic, Conversational, Pressure | Occasional | low | Round 1 and round 3 carry them; a panel mixes questions | Not weighted here |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the 60% on-call drop was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | State the sentence at its own scope. Weakest-assumption move: name, in your own words, the assumption behind the figure you would defend least, before they do. Answer slots: how it was counted; what it is sensitive to; the assumption you would defend least; which part was yours. If you do not know how it was counted, say so plainly. The sentence supports "after", and the pack supplies no cause | F2 holds the figure. EXP because it tests whether the number survives scrutiny; a prober asks for the denominator |
| D2 | "You say about 40 interviews last year. What did the 40 count?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say the sentence in its own words: "I run our hiring loop for backend roles." Weakest-assumption move: name the assumption behind the 40 you would defend least before they do. Answer slots: what the 40 counted, whether interviews you conducted or interviews the loop held; what it is sensitive to; which part was yours. Keep "about" as you wrote it. If you do not know exactly how it was counted, say so plainly | F3 holds the second figure. EXP because the 40 is ambiguous on its face, and a prober resolves ambiguity downward |
| D3 | "A service your squads own has an outage that traces to a firmware change from hardware. Walk me through the first hour and the follow-up." | CASE | [generic] | Structure it: stabilise and communicate first, establish what changed and who owns each part, decide what to roll back, then the follow-up, covering the review, the interface with hardware and what you would change. Say what you would delegate to staff engineers and what you would keep. The question needs no claim about your past, so the guidance makes none | Tests technical credibility for the role's device-management domain and F5's hardware seam from the engineers' side. CASE because it is a live problem; generic because no Larkfield facts were researched |
| D4 | "Walk me through your hiring loop for backend roles. What does each stage test?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Lead with: "I run our hiring loop for backend roles." Answer slot: the role description names hiring, so expect a probe on how the stages were set. If any stage or its criteria were yours to set, say which and how you decided, in your own words; if the structure was set by someone else, or there is no staged structure, say so plainly and describe how you run the loop. Whether you decide hires is not in the material, so say only what you know | F3 is the strongest-matching row, and the probe lands where the material is silent about who set the stages. JD because it scores the stated hiring line |
| E1 | "Our teams sit side by side. Where is the seam between a staff engineer's call and the manager's, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than claiming to know the seam: who decides what, how disagreement is raised, what gets written down. Add reciprocity: what you would want from staff engineers and what they could expect from you. The question needs no claim about your past, so the guidance makes none | Peer-evaluator probe. JD because it scores the role's collaboration with its engineers; generic because it is a pattern, not a Larkfield fact |
| E2 | "A customer has been promised a feature by the end of the quarter. Your squads say it is two quarters of work. What do you say in the room?" | CASE | [generic] | Clarify what was promised, to whom and what flexibility exists. Then options, what you can offer, how you would say no to part of it, and how you would bring the squads and the product manager to the same page. The question needs no claim about your past, so the guidance makes none | F6's product partnership as a decision. CASE because it scores structure and judgment in a live seam |
| E3 | "How would you work with hardware on a roadmap when firmware timelines move?" | CASE | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | If hardware experience comes up, the plain acknowledgment is: "I've never owned a hardware-adjacent roadmap." Then give the plan as a plan: what you would want to know about how hardware schedules are set, how you would keep both squads informed, and how you would surface a slip early. Frame it as what you bring to the seam, not only what you need. Nothing here describes what you have done with hardware | F5 again, in a collegial register where the objection returns. CASE because it is hypothetical |
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The sentence may or may not be your instance; it names roadmap pressure, not who applied it. If it fits, say only what it says: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you delivered a message to leadership, say what it was, to whom and how it landed, in your own words; if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. Do not supply an ending the sentence does not carry | Behavioural probe from the cross-functional seat. VAL because it scores behaviour; the theme is a standard values stem, and F2 is the only sentence near it |
| F2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a named customer need, an internal metric that pointed the other way, and a decision you made. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. The pack knows no instance and supplies none | Standard values stem. VAL because it scores behaviour; generic because no sentence of yours speaks to a customer |
| F3 | "Tell me about a time you disagreed with a product partner and how it was resolved." | VAL | [grounded] | Selection scaffold: pick a time with a real disagreement, a position you held and a resolution you can describe. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. The theme comes from the role description's product partnership, and the material carries no instance | F6 has only a low-confidence lead, so the guidance is a scaffold with its fallback. VAL because it tests behaviour with an equal |

## Reverse questions for round 2

| # | Question | Why it lands |
|---|---|---|
| W1 | "What could a new manager do in the first month that would genuinely help you?" | Reciprocity question for a seat that is a peer on the work; it turns the exchange toward what you contribute |
| W2 | "What would make you say a new manager had improved your squad in 90 days?" | Hands you the staff engineers' own test and links to F1 |
| W3 | "How do roadmap trade-offs between product and hardware get settled today?" | F5 and F6 asked from the working level |
| W4 | "Where have reliability work and feature work collided recently, and how was it settled?" | Lets the panel tell their own story on F2's theme without you claiming one |
| W5 | "Where is the hiring bar contested for these squads?" | Meets F3 and prepares D4's follow-up |

---

# Round 3 — The following Monday, 30 min, VP Engineering

The recruiter's own words, "values and leadership philosophy", are the loop source for a values-style round here. The company's published values were not available, so the cheat sheet is not built; the questions are themed from the recruiter's words and standard values stems.

## Persona weights

| Persona | How it shows up | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Values/Behavioral | Leadership philosophy and behaviour stories | high | The recruiter's description names it directly | A principle in your own words plus an instance your material carries; scaffolds with their honest branch where it does not |
| Pressure | Time-boxed challenges on the gaps | medium | Skip-level executive prior (personas.md); 30 minutes invites short, sharp probes | Pause, restate, hold through two follow-ups, concede specifically |
| Case/Strategist | Altitude questions on the domain | low | Same prior, outranked by the recruiter's framing | Offer a view as a view and ask the VP to test it |
| Prober, Peer, Skeptic, Conversational | Occasional | low | Covered in rounds 1 and 2 | Not weighted here |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "How would you describe your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say one principle you actually act on, in your own words, then one instance your material carries, kept at its scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: the principle is yours to name, and whether the quarter was an instance of it is yours to say; if no principle comes to mind, say so plainly and describe what you try to do for your team. Let the interviewer draw the inference | The recruiter's framing makes this near-certain. VAL because it scores philosophy; F2 is the only sentence of yours that touches a trade-off |
| G2 | "Tell me about a time you had to choose between what your team wanted and what the business needed." | VAL | [grounded] | Selection scaffold: pick a time with a named stake on each side, a decision you made and a relationship that was intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. The material carries no instance, and the pack supplies none | Leadership-philosophy theme from the recruiter's words. VAL because it scores behaviour at the VP's level |
| G3 | "You haven't managed managers. What would you want to learn from me about leading at that level?" | VAL | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Plain acknowledgment: "I've never managed managers." Then ask the VP real questions: how they developed as a leader of leaders, and what they would watch first in someone making that step. Offer a plan, not a past, such as how you would build trust with each lead before changing anything. Describe no experience of managing managers | The negative is yours and sourced. VAL because a values interviewer turns a gap into a conversation about learning; F1 and F5 meet here |
| G4 | "What do you look for when you hire an engineer?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say what you look for in your own words; the pack supplies no criteria. Anchor it at "I run our hiring loop for backend roles." If the criteria are the loop's rather than yours, say so plainly | F3 gives you a real basis here. VAL because hiring philosophy is leadership philosophy |
| H1 | "Sixty seconds: why should we trust you with hardware dependencies when you've never owned a hardware-adjacent roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Pause and restate. Hold: "I've never owned a hardware-adjacent roadmap." Then what the quotes carry, at their scope: "I run our hiring loop for backend roles" and "I pushed a reliability quarter through against roadmap pressure" — only if they fit your answer, and let the interviewer draw the inference. Hold through two follow-ups, then concede specifically: you would be learning the hardware side from the people who own it. Answer slot: if you have worked with hardware or firmware counterparts in any way, say what and which part was yours; if not, say so plainly | The same objection as B1, compressed and made adversarial. JD because it scores the stated requirement; the time box tests composure |
| H2 | "That 60%. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold: the sentence is yours, and it says you pushed a reliability quarter through. Answer slot: which part of the drop was yours is for you to say in your own words; if others did work you do not know the share of, say so plainly. Concede specifically and keep "after", not "because". The structure is hold through two follow-ups, then concede what you do not know | F2's figure under pressure; the stem is the standard attribution probe. EXP because it checks how much was yours |
| H3 | "Why you over an internal candidate?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year." | Pause, restate, and give one differentiator at the scope your sentences carry: 9 years in engineering, 3 as a team lead of 6, and that you run a hiring loop for backend roles. Answer slot: why you want this role is yours to say in your own words. Do not claim to know the internal candidate or the company's needs beyond what you have been told | A standard pressure stem for an executive seat. JD because it scores fit; F1 and F3 are the evidence |
| I1 | "Six months in, one squad's roadmap is full of hardware-driven work. What do you protect?" | CASE | [generic] | Clarify what hardware-driven means here and what is at stake. Then name the principle you would protect and the trade-offs you would accept, say who you would tell, and say what you would watch. State your priority as your own judgment, not as a fact about Larkfield. The question needs no claim about your past, so the guidance makes none | F5 and F6 at the VP's altitude. CASE because it scores principles under a live constraint |
| I2 | "What do industrial customers most need from device management over the next few years, and how would you tell if we were delivering?" | CO | [generic] | Offer a view as a view, say what you would ask the VP to correct, and name one or two measures you would look at first. No company fact is supplied here because the research searches were refused; add only what you have read yourself | CO because it tests strategy fluency. Generic because no strategy source was available |

## Reverse questions for round 3

| # | Question | Why it lands |
|---|---|---|
| X1 | "What leadership habit do you most want engineering managers here to share?" | Directly in the recruiter's "leadership philosophy" frame, and gives you the VP's own standard |
| X2 | "How do you develop managers who are taking on a larger scope for the first time?" | Meets G3 and F5's first sentence without hiding the gap |
| X3 | "What separates the engineering managers who thrive here from those who struggle?" | Gives you the VP's own test, usable in any later conversation |
| X4 | "Where do you want the device-management services to be in three years?" | A strategy question that is a reverse question, so A4 and I2 get answered from the source |
| X5 | "What do you wish candidates asked about the company's values?" | Invites the VP to point you at what matters, in a round framed as values |

---

## Prohibited claims

Built from the fit snapshot before the banks were written. These are claims the pack will not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed managers | Negative you stated, in F5's quote | "I've never managed managers." No slot |
| Owned a hardware-adjacent roadmap | Negative you stated, in F5's quote | "I've never owned a hardware-adjacent roadmap." No slot |
| Led two squads or led 11 engineers | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a team lead of 6 |
| Owned delivery across squads | Inflated form of F2 | F2's quote at its own scope: "I pushed a reliability quarter through against roadmap pressure." The slots stay inside the reliability quarter |
| Cut on-call burden by 60% through a particular action | Inflated form of F2 | The sentence as written: the burden "dropped 60% after" the quarter. Never "because" |
| Negotiated the reliability quarter with product | Inflated form of F6 | F6's quote at its own scope; the slot asks who applied the pressure and how the quarter was agreed |
| Conducted about 40 interviews yourself | Inflated form of F3 | F3's quote as written: "about 40 interviews last year", with the slot on what it counted |
| Made the hiring decisions for your team | Inflated form of F3 | "I run our hiring loop for backend roles." D4's slot asks who set the stages |

## Sources

**Provided documents:** your message (role description, round schedule, your background sentences). No CV or full JD was supplied. No dossier was present.

**Searches sent (all refused by the host in this session):**

| Query | Outcome |
|---|---|
| Larkfield Systems industrial IoT company values | refused |
| Larkfield Systems interview process engineering manager | refused |
| Larkfield Systems industrial IoT device management strategy news | refused |

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have fed a values cheat sheet for round 3; not built, since no published values are in hand |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have added loop detail; your own words already establish the three rounds and who runs each |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have moved A4 and I2 from generic to grounded, and added a grounding brief |
| 4. interviewer name | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative Engineering Manager JD | skipped | The role description in your message fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names and titles (public footprint only) → an interviewer read per round, persona weights adjusted to each person, and a reverse question tied to each one's own path
- Larkfield's published values (paste the page) → a values cheat sheet for Monday, and G1 to G4 mapped to named values
- Larkfield strategy or recent news (paste, or allow search) → A4 and I2 move from generic to grounded, and a grounding brief is added
- The full JD text → the six requirement quotes broaden, and any gate in it (location, travel, pay) gets its own row
- Your CV → F1 to F4 gain evidence sentences beyond your message, and confidence can move
- An on-call paging report for the reliability quarter, the quarter's planning document, or your hiring loop's scorecard or rubric → the inspectable artifact that would raise F2 and F3 from medium toward high
- Your own answers to the answer slots in F1, F2, F4 and F6 → those rows regenerate on your words instead of slots
- The recruiter's guidance for the Thursday panel (focus areas, any pre-declared deliverable) → a build section for any deliverable, and tighter persona weights
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → strategy brief, interviewer footprint, role-family loop reports and recent org context; offered once
- A `tuesday-dossier.md` from an earlier session → verified evidence, allowed strategies per weak area and absolute prohibited claims, if you have one
