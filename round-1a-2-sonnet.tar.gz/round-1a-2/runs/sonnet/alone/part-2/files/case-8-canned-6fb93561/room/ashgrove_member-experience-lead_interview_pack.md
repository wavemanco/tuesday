# Member Experience Lead — Ashgrove Credit Union: interview pack for Dara

Loop mode: three rounds on 29 November 2026, built on 20 November 2026.

| Round | Who and length | Relationship | Focus, in the recruiter's words |
|---|---|---|---|
| 1 | The recruiter, 30 minutes | Recruiter screen | Not stated beyond the process email |
| 2 | The Head of Member Services, 45 minutes | Future manager | "mostly behavioural" |
| 3 | A panel of two branch managers, 60 minutes | Panel, also the values round | "a 20-minute case on a complaint escalation"; "they score against the four values" |

Interviewers beyond their roles are not yet assigned, so there is no interviewer read and no per-panelist persona assignment.

## How to use this pack

- Personas describe how a question arrives; types describe what is being scored. Rehearse both.
- Guidance is scaffolding, not a script. Say it in your own words and only at the scope of the sentences quoted beside it.
- An **Answer slot** is an instruction for the interview, not a question for you now. Answer it from your own experience, or say plainly that the practice was not yours or did not exist, and return to what your quotes carry. Either branch is a good answer.
- Labels: `[grounded]` traces to something you or the employer supplied; `[inferred]` is this pack's derivation, named; `[generic]` is a role-family pattern with no claim about Ashgrove or about you.
- Shared sections come first (fit snapshot, coverage, grounding brief). Then one mini-pack per round. The values cheat sheet sits in round 3, which the recruiter's email calls the values round. Prohibited claims, sources and the upgrade menu close the pack.
- **Highest-ROI prep in the pack: D1**, the contact-centre objection, rehearsed to four levels of follow-up. Round 1's B1 is its light version.

| Type | What it is really scoring |
|---|---|
| VAL | Whether past behaviour demonstrates Ashgrove's published values |
| EXP | Whether your own background survives scrutiny, including how much of it was you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at Ashgrove's altitude: its strategy and competition |
| CASE | Structure and reasoning on a live problem from the role |

## Fit snapshot

Your background comes from your own message. Every quote below is your sentence.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD (branch side) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says a branch's formal complaints log, not a process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" makes a probe on what happened to a complaint around the log likely. If any part of how a complaint was handled from the moment it was logged was yours to decide, say which part and how you decided, in your own words; if none was, or it was not yours, say so plainly and stay with the log |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD (contact-centre side) | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then a plan, said as a plan and never as a past: what you would ask to see first about how complaints reach the contact centre and how they leave it. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | The sentence says a monthly complaints spreadsheet you built and your regional manager uses, not what it counted. Stay at that scope. Answer slot: the JD's "volumes and resolution times" makes a probe on what it counted likely. If it counted volumes, resolution times or both, say which, in your own words; if it tracked something else, or you do not know exactly how a figure was counted, say so plainly and stay with the spreadsheet |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers and an escalation script, so the words are "I trained new tellers on our escalation script." Answer slot: the JD's audience is supervisors, so expect a probe on whether you have advised supervisors. If you advised a supervisor or another colleague on a live escalation, say what happened and what part was yours; if not, say so plainly and stay with the tellers and the script |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Strong evidence here would be one specific time you worked with a digital or product team on something members use, or passed them a pattern you saw in complaints. Answer slot: the JD's line makes this probe likely. If you worked with any digital or product team, say who and what you did; if you did not, say so plainly, and say what pattern in complaints you would bring them first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | The quote already reaches the length asked for, in branch-banking terms. Say it in your terms: "I have six years in retail banking, the last three as a branch supervisor." Do not relabel it in the JD's phrase; let the interviewer place it |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | The sentence says formal complaints, not regulated ones, and nothing about what rules governed them. Answer slot: the JD's "regulated" makes a probe on what rules or deadlines applied likely. If external rules, deadlines or reporting duties applied to the complaints in your log and you worked to them, say what they were and what you did; if you do not know which applied, or the log ran on internal rules only, say so plainly and stay with "I handled the branch's formal complaints log." |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented above regional level." Then a plan, said as a plan: how you would prepare a first report for senior leaders. The material does not show whether Ashgrove counts regional level as senior, which is a question for the recruiter (Round 1 reverse question 1) |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | The sentence says a spreadsheet, not which tool. Answer slot: the JD names Excel, so expect a probe on the tool. If it was built in Excel, say what you built in it, in your own words; if it was another tool, or your skill differs from the JD's word, say so plainly and stay with the spreadsheet |

Reading of the table: none of the eight JD requirements is a term such as a licence, location, pay or schedule, so there is no hard gate. F6 is a length-of-experience requirement and is graded like the rest.

## Requirement coverage

| JD requirement | Covered by | Note |
|---|---|---|
| Own the complaints process end to end across branches and the contact centre | B1, D1, D2, H1, H2, J1, J2 | D1 is the deepest rehearsal |
| Report monthly on volumes and resolution times | C2, H3, E1 | |
| Coach branch supervisors on escalations | C1, H4, J3 | |
| Work with digital teams on self-service journeys | C4, E1, H3 | |
| 4+ years in financial-services customer operations | A1 | |
| Experience handling regulated complaints | B2, H1 | |
| Confident presenting to senior leaders | B3, D2, D4 | |
| Comfortable with Excel reporting | C2 | |

## Grounding brief

From your summary of the July 2026 strategy brief the recruiter sent. I have not read the brief itself, only your four items; nothing in them reads as stale.

| Item | What the material says | Reading for this role | Provenance |
|---|---|---|---|
| Who they are | "member-owned, about 900 staff" — JD | The JD and the values page say "member", not "customer". Use their word | [grounded] |
| Digital shift | "move 40% of member service to digital channels by 2028" — your message | The role's link to this is the JD's "work with digital teams on self-service journeys" (E1) | [grounded] |
| Branches | "consolidate eight branches into five hubs over 2027" — your message | Round 3 is two branch managers; expect hub questions (E2, G3, J1) | [grounded] |
| Lending | "launch a small-business lending product in Q1 2027" — your message | A new product is a new place complaints can come from; it feeds a Round 3 reverse question | [grounded] |
| Competition | "the main competitive pressure is app-only banks" — your message | Gives E3 its frame | [grounded] |

---

# Round 1 — the recruiter, 30 minutes

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured; logistics and "walk me through" | High. The recruiter-screen prior is conversational plus a light Skeptic, and the email gives this round "30 minutes with me" with no other focus | A 90-second arc ready; treat every casual question as scored; give your own answer to each logistics question |
| Skeptic, light | Knockout checks on JD lines in a friendly register | Medium. Same prior. The likeliest knockouts are the rows where your material shows a stated absence or no quote (F2, F7, F8) | A plain acknowledgment from the quote, then a plan; never bluff a competency |

### Bank A — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your journey so far, and what's drawn you to Ashgrove." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F6 and F1 with only the beats the quotes state: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on your escalation script. Say them in your own words. Then the draw. Answer slot: say why Ashgrove in your own words, and pick the one published value or brief item you would say without notes; if none truly draws you, say what does | The biography question opens most recruiter screens and is scored; F6 is the length requirement and F1 the first line of the JD. EXP because it tests whether the background holds as told |
| A2 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own figure in your own words, or ask for the role's band first. The JD you shared states no figure, so the band is the recruiter's to give. Do not volunteer salary history | Pay is one of the four logistics the recruiter-screen row names. JD because it is the listed job's term |
| A3 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period in your own words, and any flexibility only if it is real | Same row as A2. JD because notice is a term of the listed job |
| A4 | "Where would you be working from, and how does getting to branches and the contact centre look for you?" | JD | [generic] | Logistics slot: give your own location and any travel limits in your own words. The JD you shared states no location, so ask the recruiter where the role is based and how the working pattern runs | The role spans branches and the contact centre, so location is a live question and the JD is silent on it. JD because location is the listed job's term |
| A5 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot: give your actual reason in your own words, in one sentence, framed toward what this role offers where that is true. Keep it identical to your answer to D3, because round two will test the match | Reason for leaving is the fourth logistics item. EXP because it tests motivation consistency across rounds |

### Bank B — Skeptic, light

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the branches and the contact centre. Where does your experience sit against that?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Under a minute. Branch side first, at its own scope: "I handled the branch's formal complaints log." Then plainly: "I haven't worked in a contact centre," and the plan from F2 as a plan. This is the light version of D1; do not add reassurance the quotes do not carry | F1 and F2 are the JD's first line and the likeliest knockout. JD because it scores the stated requirement |
| B2 | "Have you handled regulated complaints?" | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold at the quote: "I handled the branch's formal complaints log." Answer slot: if external rules, deadlines or reporting duties applied to the complaints in that log and you worked to them, say what they were and what you did; if you do not know which applied, or the log ran on internal rules only, say so plainly and stay with the log | F7 is an explicit JD requirement and the material shows "formal", not "regulated". `[inferred]` because the probe's shape is derived from the JD line. JD because it is a stated requirement |
| B3 | "How comfortable are you presenting to senior leaders?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment first: "I haven't presented above regional level." Then the plan from F8, as a plan: how you would prepare a first report. Ask the recruiter who counts as senior leaders in this role. Do not claim comfort the sentence does not carry | F8 is a stated absence against an explicit requirement. JD because it scores that line |

### Round 1 reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Who counts as senior leaders for this role's monthly reporting, and where would the first presentation be?" | Settles what F8's gap measures against, and shows you are planning the work |
| 2 | "Which regulator or framework governs the complaints this role handles?" | The JD says "regulated" without naming one; asking shows you treat it as a duty, and answers F7's open question |
| 3 | "Once the interviewers for rounds two and three are assigned, could you tell me who they are?" | Unlocks an interviewer read and a sharper reverse question for each |
| 4 | "Can you tell me anything about the format of the complaint-escalation case in round three, such as whether to talk it through or present it?" | One email's worth of recruiter guidance that decides how the H bank is rehearsed |
| 5 | "Who would the contact-centre side of complaints report to, and how does it meet the branch side today?" | Maps the seam F2 leaves open, from a neutral source |

---

# Round 2 — the Head of Member Services, 45 minutes

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time…", STAR-shaped probes on JD themes | High. The recruiter calls the round "mostly behavioural" | "We" for context, "I" for contribution; where no quoted sentence carries a story, use the scaffold and its honest branch rather than a constructed story |
| Skeptic | Quiet, persistent probing of the gaps | High. The hiring-manager prior is Case plus Skeptic, this person "would be your manager" so is derisking, and F2 and F8 are stated absences | Rehearse D1 until it is boring; plain acknowledgment, plan, hold, concede specifically |
| Case / Strategist | Live problems from the roadmap, using the brief | Medium. The hiring-manager prior includes it; "mostly behavioural" lowers it; the brief is public, so a prepared candidate will have it too | Clarify, structure, one consensus point to show grounding, then one reasoned divergence with a concession |

### Bank C — Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you coached someone through a difficult escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4 with only the beats the quote states: you trained new tellers, on your escalation script. Say those in your own words. Answer slot: the question asks about a difficult escalation, so expect a probe on a specific one. If you coached anyone through a live escalation, say who and what you did and what part was yours; if the training was the script only, or none of it was a live escalation, say so plainly and stay with training new tellers on it | The JD's coaching line; F4 is the evidence and the likeliest place to be probed. JD because it scores the stated duty, EXP in how it will be pressed |
| C2 | "Walk me through the monthly complaints spreadsheet your regional manager uses. What's in it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start with the quote's own beats: you built it, your regional manager uses it. Answer slot: the JD asks for volumes, resolution times and Excel, so expect a probe on what it counted, the tool, and how the figures were counted. Say what you know in your own words; if you do not know how a figure was counted, say so plainly. Weakest-assumption slot: if there is an assumption behind a figure you would defend least, name it before they do; if there is none you know of, say so | F3 and F9 are the reporting and Excel requirements; a spreadsheet is the nearest thing to a defend-the-number target in the material. EXP because it tests what was actually yours |
| C3 | "Tell me about a time you disagreed with a colleague or someone more senior about how a complaint should be handled." | VAL | [generic] | Selection scaffold: pick a time with a named complaint, a real disagreement, what you held to and why, and an intact working relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD makes complaint handling the role's centre and the manager is scoring judgement under disagreement. VAL because it tests behaviour more than knowledge; no quoted sentence carries this story, so the pack supplies none |
| C4 | "Tell me about a time you worked with a team outside your own branch to fix something that wasn't yours to fix." | JD | [generic] | Selection scaffold: pick a time with a named team, a named problem, what you did and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or what you would bring a digital team first | F5 has no evidence, and the JD's digital line makes this likely. JD because it scores that line; the scaffold stays open because the material is silent |

### Bank D — Skeptic (D1 is the highest-ROI prep in the pack)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see contact-centre experience in your background. How would you handle that part of the role?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Limit named first: your material holds the branch's log and the teller training, not any contact-centre work, and the hold never goes past that. Level 1: "I haven't worked in a contact centre," said plainly, then the plan as a plan (learn how complaints reach and leave the contact centre before changing anything, and who you would ask), then the branch side at its scope: "I handled the branch's formal complaints log." Level 2, "They're different animals; why do you think you can own both?": hold the plan, do not claim similarity. Level 3, "Who would you lean on in your first 90 days?": name roles and what you would ask them, not people. Level 4, "What if the contact-centre team doesn't see a branch supervisor as credible?": concede it is a fair risk, specifically, and say you would listen first. Concession line: "That's a real gap, and I'd rather name it than talk around it." Never fold to "I can't", never claim credibility you cannot back | The most predictable objection to this candidate: F2 is the JD's first line and a stated absence, and the person asking would be the manager. JD because it scores the stated requirement, with a pressure delivery |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Your sentence supports two honest answers: the contact centre, or presenting above regional level. Pick the one you can say most calmly, in its own words ("I haven't worked in a contact centre" or "I haven't presented above regional level"), then the plan. Do not name a third weakness the material does not show | F2 and F8 are the two stated absences, so a candid answer is available without inventing one. JD because it scores the whole list |
| D3 | "Why this move, and why now?" | EXP | [generic] | Logistics slot: your actual reason, in your own words, identical to your A5 answer. Add what this role offers only where it is true for you | Motivation consistency is the Skeptic's standing probe, and round two compares notes with round one. EXP because it tests whether the story holds |
| D4 | "You haven't presented above regional level. What would you put in front of our senior leaders in your first monthly complaints report?" | CASE | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Concession first, one line: "I haven't presented above regional level." Then a structure, as a plan: lead with the headline, show the JD's own measures (volumes and resolution times), say what is changing and why, end with one decision you need from them. Plain Words applies: if they need it explained twice, it was written wrong | F8 stated absence, tested as a live task; a candid plan converts it. CASE because it is a live problem in the role's own reporting |

### Bank E — Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our brief says we'll move 40% of member service to digital channels by 2028. Where do complaints fit in that?" | CO | [inferred] | Clarify first: does "member service" include complaints, and what counts as moved. Consensus point to show grounding: complaints are data on where a self-service journey fails. One divergence to hold if you believe it: keep a human route into complaints even as other service moves, because someone complaining has often already tried the self-service route. Concession: you cannot see from outside what share of complaints digital can fix. Anti-pick: do not propose a digital-share target for complaints themselves | The brief is public, so the consensus answer is available to every prepared candidate; differentiation is the score. `[inferred]` because the thesis is derived from the brief, the JD and the values. CO with CASE delivery |
| E2 | "Eight branches become five hubs over 2027. What would you watch for in complaints?" | CO | [inferred] | Clarify which towns and when. Structure: segment complaints by the member's home branch, not only the hub they now use; track volumes and resolution times (the JD's measures) for those groups; name the risk that members in affected towns feel unheard. Use the value's own words, "every branch is part of its town", rather than a slogan. Concession: the summary does not say which branches close or in what order | The panel is two branch managers and the brief is the loop's main strategy fact. `[inferred]` because the structure is derived from the brief and the values. CO with CASE delivery |
| E3 | "The brief names app-only banks as our main competitive pressure. What can a complaints process do about that?" | CO | [inferred] | Consensus point: speed and ease of digital routes. One divergence to hold if you believe it: a member who keeps one named person through a problem, which is the "Own the Fix" value in practice. Concession: this is a hypothesis you could not price from outside. Anti-pick: do not promise to beat app-only banks on speed of first response | Departing from a shared source with reasons scores as judgment. `[inferred]` because the thesis is derived from the brief and the values |

### Round 2 reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does owning the complaints process end to end look like today: which parts sit with branches, which with the contact centre, and where are the handoffs?" | Uses the JD's own phrase and turns F2 into a joint mapping of the seam |
| 2 | "Who receives the monthly complaints report today, and what decision do they make from it?" | Shows you care about use, not production, and reveals who the senior audience is |
| 3 | "What would good look like at six months: volumes, resolution times, or something else?" | Asks for the manager's own scoring sheet |
| 4 | "With the move to digital, how closely will this role sit with the digital team, and who holds the complaints data for self-service journeys?" | Ties the JD's digital line to the brief and surfaces ownership |
| 5 | "What would you most want a new lead to learn about the contact centre in the first month, and who would help?" | Converts a stated gap into a plan the manager can shape |

---

# Round 3 — panel of two branch managers, 60 minutes (values round plus a 20-minute case)

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes mapped to the four published values | High. The recruiter says "The panel is also the values round — they score against the four values" | Stories chosen for a specific decision, "we" for context and "I" for contribution; the scaffold's honest branch where no quote carries a story |
| Case / Strategist | The 20-minute complaint-escalation case | High. The recruiter says the round includes "a 20-minute case on a complaint escalation" | Clarify, objective, first move, cause, system, risks; think aloud; challenge one premise respectfully |
| Peer Evaluator | Seam-splitting between the role and the branches; "what would you need from us" | Medium. A reading from the JD's "coach branch supervisors on escalations": branch managers are the supervisors' managers. The email does not say this | Reciprocity: what the role brings the branch; propose seam principles, not a pretended seam |

### Bank G — Values (see the cheat sheet below)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time doing right by a member and following the usual process pulled in different directions." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold for Members First, Always: pick a time with a named member's situation, the two pulls, what you decided from the member's side of the counter and why, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is what you handled in the branch's formal complaints log and no more, or how you would handle it | The published value is the raising source. F1 is the nearest evidence, and carries no decision, so the pack supplies no story |
| G2 | "Tell me about a time something you wrote or said needed explaining twice. What did you change?" | VAL | [grounded] | Selection scaffold for Plain Words: pick a time with a specific piece of wording, who was confused, and what you changed. Answer slot: if you changed or rewrote anything you used with members or tellers, say what and why; if nothing, or none of it was yours, say so plainly. If no such time comes to mind, say so plainly, then give how you would handle it | The value says "if a member needs it explained twice, we wrote it wrong", the likeliest source of the question. The material shows training on a script, not changes to wording, so the pack supplies none |
| G3 | "Tell me about a time you put one town's or one member's circumstances ahead of what the numbers said." | VAL | [grounded] | Selection scaffold for Neighbours, Not Numbers: pick a time with a named circumstance, the figure that pointed the other way, what you decided and what it cost. If no such time comes to mind, say so plainly, then give how you would handle it | The brief's branch consolidation gives this value teeth, and the role reports monthly on numbers. No quoted sentence carries it |
| G4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold for Own the Fix: pick a time with a named problem, what keeping hold meant in practice (what you did when it would have been easy to pass on), and how you knew it was solved. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is what you handled in the branch's formal complaints log and no more, or how you would handle it | The published value is the raising source. F1 shows what you handled, not that you held a problem to a fix, so the pack supplies no story |
| G5 | "Which of our four values would you find hardest to live by in this role, and why?" | VAL | [grounded] | A candour question with no past claim. Pick one in your own words. One honest tension to consider: the role reports monthly on volumes and resolution times while one value is "Neighbours, Not Numbers"; if you pick it, say how you would keep the numbers from replacing the neighbours. If another is harder, say that | Panels use it to see whether values were read or recited. VAL because it tests alignment rather than a story |

### Bank H — Case (the 20-minute complaint escalation)

The scenarios below are rehearsal patterns, not predictions. Rehearse the structure; the real case will differ.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "A member has complained three times in a month about the same disputed card payment. The branch supervisor escalated it to the contact centre, which closed it as resolved. The member is now at the counter asking for a manager. You're the Member Experience Lead. What do you do?" | CASE | [generic] | Clarify first: what the member has been told, what was recorded as resolved and by whom, and whether any formal-complaint deadline is running under the rules that apply to you (ask, do not assume). Objective from the member's side of the counter. First move: someone owns it from now until it is fixed, and say what you would tell the member in plain words. Then the cause: challenge one premise, what "resolved" meant. Then the system: how it would appear in monthly volumes and resolution times if closed does not mean fixed. Risks last. Concede where you would need facts you lack | The recruiter names a complaint-escalation case, and this pattern touches each JD line in the first one. CASE because it is a live problem from the role. `[generic]` because it claims nothing about Ashgrove or about you |
| H2 | "In that case, the branch manager wants to settle it with a goodwill payment and move on. You think the cause needs fixing first. What do you say?" | CASE | [generic] | Ask first what discretion exists and who holds it. Then propose both: do right by the member now, and fix the cause so it does not recur. Disagree on the cause without disputing the payment, then say what you would need to agree. Reciprocity: what the branch gets from the fix | The panel are branch managers, so a disagreement with one is the natural second beat. CASE with Peer delivery |
| H3 | "Complaints about the same thing are showing up at three branches. How do you work out whether it's a branch problem, a contact-centre problem or a self-service problem?" | CASE | [generic] | Clarify what the complaints are about. Segment by branch, channel and cause. Start with the JD's own measures, volumes and resolution times, then ask what would change your mind. Name the digital team as someone you would involve, as a plan. Concede that a fall in volume can mean members stopped complaining rather than that things improved | Covers the reporting and digital lines through one problem. CASE because the structure is the score |
| H4 | "A branch supervisor escalates nearly everything to you. How do you coach them?" | CASE | [generic] | Ask what is making escalation feel safer than deciding. Agree which cases are theirs to close. Work through a live case together, then check in. Concede you would not know their constraints until you ask | Tests the JD's coaching line as a decision rather than a record. `[generic]` because it asks about no past |

### Bank J — Peer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Our teams sit side by side. Where's the seam between what you'd own and what stays with the branch, and what happens when we disagree?" | JD | [generic] | Offer seam principles, not a pretended seam: whoever holds a complaint keeps hold of it until it is solved, the lead owns the process and the branch owns the member in front of them. On disagreement: say it early, say what the member needs, and agree who decides. Reciprocity: what the role takes off the branch | The peer stem for the panel; the JD's end-to-end line sits across branch boundaries |
| J2 | "When a complaint's cause sits in a branch, how do you handle that with the branch manager in the room?" | CASE | [generic] | Separate the member's fix from the cause. Name what happened plainly, not whose fault it was. Ask what the branch needs to stop it recurring. Concede that you may be missing context they hold | Credit and blame across teams is the standing peer probe. CASE with Peer delivery |
| J3 | "From your time as a branch supervisor, what would you have wanted from a Member Experience Lead?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Answer as an opinion from the supervisor's side of the counter, in your own words. Answer slot: if there was a specific time a lead or another function made an escalation easier or harder for you, say what happened; if there was not, say so plainly and stay with what you would have wanted | Reciprocity from F6: the panel manages the supervisors the role coaches. EXP because it uses your background without claiming a story |

### Values / principles cheat sheet

No quoted sentence carries a complete story for any of the four values, so each row is a selection scaffold, not a story.

| Value (official name) | Working meaning, paraphrased | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | G1 scaffold; nearest evidence F1, "I handled the branch's formal complaints log and trained new tellers on our escalation script." — it shows what you handled, not a decision. If no story comes to mind, say so plainly |
| Plain Words | If a member needs it explained twice, the writing was wrong | G2 scaffold; nearest evidence F4, "I handled the branch's formal complaints log and trained new tellers on our escalation script." — it shows training on a script, not changes to wording. If no story comes to mind, say so plainly |
| Neighbours, Not Numbers | Every branch is part of its town | G3 scaffold; no quoted sentence is near it. If no story comes to mind, say so plainly, then how you would handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | G4 scaffold; nearest evidence F1, "I handled the branch's formal complaints log and trained new tellers on our escalation script." — it shows what you handled, not that you kept hold of a problem to a fix. If no story comes to mind, say so plainly |

### Round 3 reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What could a new lead do in their first month that would genuinely help your branch?" | The reciprocity question for peers: it asks what you can give them first |
| 2 | "How do escalations reach you today, and what would you most want from the lead on those?" | Asks the panel for their own pain, which is what they are scoring against |
| 3 | "With eight branches becoming five hubs, how do you expect complaints to travel between hubs and the towns that lose a branch?" | Uses the brief and the Neighbours value in one question |
| 4 | "Which of the four values does the team find hardest to live by day to day?" | Turns G5 around and shows you read the values as practice |
| 5 | "With the small-business lending product launching in Q1 2027, what would you want complaint handling ready for?" | Brief-specific and forward-looking, so it cannot be a generic question |

---

## Prohibited claims

Claims this pack will not coach, built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material says a branch's log, not a process across branches. Slots stay inside the log |
| Has worked in a contact centre, or handled contact-centre complaints | Negative you stated, F2 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Presents, or is practised at presenting, to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I haven't presented above regional level." No slot |
| Coached or advised supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: "I trained new tellers on our escalation script." The limit is the pack's observation: the material says new tellers and a script |
| Wrote or designed the escalation script | Inflated form of F4 | The same quote. The limit is the pack's observation: the material says trained on it, not wrote it |
| Reported monthly on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The limit is the pack's observation: the material does not say what it counted |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material says formal, not regulated |

## Sources

Provided documents: the JD; the four values, copied on 20 November 2026 from ashgrovecu.org/about/values; the recruiter's process email; your summary of the July 2026 strategy brief, which I have not read directly; your background in your own message. No dossier was consumed.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values page fixes the cheat sheet and bank G |
| 2. Ashgrove interview process, role family | skipped | The recruiter's email names three rounds, who runs each and what each holds, so it fixes the loop and the persona weights |
| 3. Ashgrove strategy, recent news | skipped | Your four-item summary of the July 2026 brief fixes the grounding brief and bank E |
| 4. Interviewer name and Ashgrove | n/a | No interviewer is assigned, so there is no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The strategy brief itself, as the recruiter sent it: the grounding brief gets direct quotes and any figure beyond your four items, and bank E sharpens
- The names of the round 2 and round 3 interviewers once assigned: an interviewer read, persona weights per panelist, and a tailored reverse question for each
- One real episode for each of the four values: G1 to G4 become story-mapped instead of scaffolds
- What your monthly spreadsheet counted, how, and in which tool: F3 and F9 move from `[inferred]` to quoted evidence and C2 gets a story map
- Whether the complaints in your branch's log were subject to external rules or deadlines: F7 gets evidence and B2 a mapped answer
- Any time you worked with a digital team or any team outside your branch: F5 and C4 get a story
- Any time you advised a supervisor or colleague on a live escalation: F4 and C1 get a story
- The recruiter's answer on the round 3 case format: bank H is tuned to it, and it is one email
- Your pay, notice, location and reason for moving, if you want them rehearsed in your words: A2 to A5 and D3 quote them
- How much prep time you have before 29 November: a prep triage section, sized to it
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes. It would cover interviewer footprint when names arrive, role-family reports on complaint-escalation case formats, and recent organisation context
- A tuesday-dossier.md: an evidence-derived ranking of the likeliest objections and limits per gap, in place of this pack's inference
