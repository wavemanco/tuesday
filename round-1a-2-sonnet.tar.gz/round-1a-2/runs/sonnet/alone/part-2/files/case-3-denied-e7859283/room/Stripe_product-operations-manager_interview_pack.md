# Interview prep pack: Product Operations Manager, Stripe

**Round:** final round. **Interviewer(s):** not given. **Relationship:** not given. **Built on this assumption:** a session-mode pack with flat persona weights, because no JD, CV, interviewer or round structure was supplied and web search was declined. Nothing here comes from Stripe's own published material.

## How to use this pack

- **Personas are how a question is asked; types are what it scores.** Rehearse both: the same question arrives warm, hostile or collegial.
- **Type key.** VAL: behavior that demonstrates a company's published values. EXP: whether your past claims survive scrutiny. JD: the stated job and its gaps. CO: company and strategy knowledge. CASE: a live problem, structured aloud.
- **Guidance is scaffolding, not a script.** With no CV in hand, every guidance cell is a selection scaffold or a method for a live problem. Fill each one only with things you actually did, in your own words.
- **Provenance labels.** `[grounded]` traces to a document you gave me or research cited in Sources, `[inferred]` is derived from an adjacent source, `[generic]` is a role-family pattern with no claim about Stripe or about you. This pack is almost entirely `[generic]`, and the upgrade menu says what turns that around.

## Fit snapshot (worksheet variant)

You gave no CV and no background, so this is a worksheet. The requirements are role-family patterns for a product operations manager, not Stripe's own wording, because no JD was supplied or fetched. Fill the evidence column yourself before you rehearse.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate cross-functional launches or releases end to end (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is one named launch you can describe from kickoff to aftermath, with your part separated from the team's. Selection scaffold: pick a launch where several functions had to agree, where a decision was yours or you influenced it; it needs a named stake and an outcome you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Build and run operating cadences such as planning cycles and metric reviews (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a recurring forum you set up or ran, with what changed because of it. Selection scaffold: pick a cadence you ran or reshaped; it needs who attended, what decisions it fed and what you changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Use data to find, size and track product or process problems (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is one figure you can defend end to end: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Selection scaffold: pick a metric you owned or tracked. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Communicate clearly in writing and aloud to leadership and partner teams (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a document or readout you can point to and the decision it fed. Selection scaffold: pick one piece of writing or one briefing where the audience acted on it. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Improve processes and tooling that teams depend on (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is one process you changed, what it was before, and what you can show about what happened after. Selection scaffold: pick a process change that was yours to propose. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Influence partners across product, engineering and go-to-market without direct authority (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a disagreement with a partner team and how it resolved, with the relationship intact. Selection scaffold: pick a time you needed a team that did not report to you to change course. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 launches | A1, B4 |
| F2 operating cadences | A2, D3 |
| F3 data and metrics | A3, G1, G2 |
| F4 communication | none, and why: written skill is shown through a sample or take-home, and no deliverable was declared. A1 and C1 test explaining a decision aloud |
| F5 process improvement | A2, A4 |
| F6 cross-functional influence | A1, C3, D1, D2 |

## Persona table

The weights rest on a generic archetype, not on Stripe's documented process: no loop source was read, and "final round" alone does not say how many sessions there are or who runs them. If your final is several back-to-back sessions, send the schedule and the pack can split into per-session mini-packs.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A, 5 questions) | A live operations problem: a slipping launch, a dead meeting, a metric drop | High. The role is an operating one, and a final round commonly tests live judgment. Weight is a prior, not a finding about this company | Clarify, then objective, then segmentation, then approach, metrics and risks; think aloud; challenge one premise respectfully |
| Skeptic (bank B, 4 questions) | Quiet probing of motivation and gaps: why this role, why Stripe, weakest area | High. The round type is final, and your material shows no gaps to aim at yet, so the probes will be the standard ones | Rehearse the weakest-area answer until it is boring: name the gap, concede it plainly, give a ramp plan |
| Values / Behavioral (bank C, 3 questions) | Past-behavior stories on truth-telling, customer focus and holding a position | Medium. No published values were read, so these themes come from standard persona stems, not Stripe's own list | A story per theme that you can stand behind, "we" for context and "I" for your part |
| Peer Evaluator (bank D, 3 questions) | Seam-splitting between product operations and product management, credit sharing | Medium. Likelihood rises sharply if one of your interviewers is a peer on an adjacent team | Offer seam principles, not a pretended map; bring what you give their team, not only what you need |
| Conversational (bank E, 3 questions) | Biography and what-are-you-learning questions in a friendly register | Medium. Common in any final session, and still scored | A 90-second arc made only of facts you stand behind |
| Pressure (bank F, 2 questions) | Time-boxed challenges to your edge and your attribution | Low to medium. It depends on who is in the room | Pause, restate, hold through two follow-ups, then concede specifically |
| Data-Driven Prober (bank G, 2 questions) | A figure from your past, walked back to how it was counted | Low to medium. It depends on whether your interviewers have read a CV, and none was supplied | Know what you can and cannot say about how each of your figures was counted |

**Highest-ROI prep: B1, "Which part of this role would you be weakest at on day one?"** This is provisional. With no CV or JD, the pack cannot see where your material is thin, so it names the one probe that final rounds almost always contain. Send a CV and the pack replaces B1 with the objection your own material actually invites.

## Question banks

All provenance cells are `[generic]` alone: no guidance below makes a claim about your past, because no sentence of yours was supplied to rest one on. Where a guidance cell says to pick an example, the example must be yours.

### Bank A: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A major launch is two weeks out. Engineering says it is on track, support says they are not ready, and the product lead wants to hold the date. How do you decide what happens?" | CASE | [generic] | Clarify first: what does ready mean to each side, what a slip would cost, what can be reversed after launch. State the objective, then lay out options such as ship as planned, ship in stages, or move the date. Say who owns the decision and when you would escalate. Name the metric you would watch after launch and the risk you would take on knowingly. Challenge one premise aloud, such as whether the date is fixed | Covers F1 and F6 together; a launch call is a standard operating problem. CASE because it scores structure under ambiguity, not a past |
| A2 | "A product team's weekly metrics review has become a status readout that nobody acts on. What would you change?" | CASE | [generic] | Ask what decision the meeting is meant to drive and who needs to make it. Then diagnose: attendance, the metrics shown, whether anyone owns an action afterward. Propose a small first change, how you would check it worked, and what you would stop doing if it did not | F2 and F5; tests whether you fix a forum by purpose and not by cosmetics. CASE because it is a live problem with no past assumed |
| A3 | "A key adoption metric for a recently shipped feature dropped 20 percent week over week. Diagnose it." | CASE | [generic] | Check measurement first: did tracking, definitions or a data pipeline change. Then segment by customer type, geography and platform, line the drop against releases and outages, and look at funnel steps. Rank your hypotheses by how cheaply you can test them. Say what you would tell stakeholders while you investigate | F3; a metric-drop diagnosis is the standard stem for data judgment. CASE because it scores structure, not the right answer |
| A4 | "You have capacity to improve one internal process this quarter: launch checklists, roadmap intake, or customer feedback routing. How do you choose?" | CASE | [generic] | Name your criteria before the choice: pain, frequency, who is affected, cost of delay, how reversible the change is. Say what you would ask each team lead first. Pick one, say what you are giving up, and say how you would know in a quarter whether it worked | F5; tests prioritization and tradeoff honesty. CASE because it asks for reasoning, not experience |
| A5 | "What do you understand about what Stripe does, who it serves and where you think product operations matters most there?" | CO | [generic] | I could not research Stripe in this session, so the pack supplies no facts about it. Build a short answer yourself from Stripe's own website and recent official posts, and say only what you read. Separate what you know from what you infer, and end with the one thing you would want to learn from this team | No row covers company knowledge; CO is a coverage requirement for any final round. Left generic because research did not run, and the upgrade menu says what changes |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal in this pack. Choose a real gap, one you would accept being probed on, and say it in one sentence in your own words. Then give a ramp plan: what you would do in the first weeks and who you would ask. Hold through two follow-ups by repeating the gap and the plan, never by adding a claim you cannot back. If you cannot name a gap honestly, say so plainly and name the area where you have least practice | F1 to F6 all sit unevidenced in the worksheet, so this probe can land on any row. JD because it scores the role's demands and your self-assessment |
| B2 | "Why product operations, and why now?" | EXP | [generic] | Two true sentences: what pulled you toward this kind of work, and what makes this the moment. Both must be reasons you hold, not reasons that sound right. Do not claim a company-specific reason here; that is B3 | A motivation probe is standard for a Skeptic; no row reaches it. EXP because it tests consistency between your history and your story |
| B3 | "Why Stripe, rather than another company where you could do this work?" | CO | [generic] | Use specifics you have read yourself, and name where you read them. If you use the product or have worked with it, say so only if true. If your reasons are mostly about the role or the people you have met, say that plainly instead of dressing it up | Companion to A5; the Skeptic asks it to see whether homework backs the enthusiasm. CO because the answer needs company knowledge |
| B4 | "What is the nearest thing in your background to this role, and where does it fall short?" | JD | [generic] | Pick one experience and describe it in the terms you would use for a colleague. Then say plainly where it stops short of this role, without being asked twice. Close with how you would cover the distance. If nothing comes close, say so, then say what you would learn first | F1 and F6 are the likeliest places the interviewer measures distance. JD because it scores the fit against the listed job, gaps included |

### Bank C: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time where the truth landed and the relationship survived. It needs a named stake, what you said and how you said it, and what happened next. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 and F6; this is a standard values stem. VAL because it scores behavior against a value, not a skill. Stripe's own published values were not read, so the theme is generic |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a decision where the metric and the customer pulled apart and you chose. Name both sides, what it cost, and how you explained it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard values stem. VAL because it tests a tradeoff made in practice. Generic until Stripe's published values are in hand |
| C3 | "Tell me about a time you held a position under pressure from someone senior." | VAL | [generic] | It needs a named stake, a moment you did not fold, and an intact relationship at the end. Say what you conceded, if anything, and why. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6; links the values bank to the Pressure persona. VAL because the score is on behavior under pressure |

### Bank D: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | JD | [generic] | Do not pretend to know their seam. Offer two or three principles for drawing one, such as who owns the decision and who owns the follow-through, and say you would want to learn how they split it today. Say how you disagree with an equal: raise it early, in private, and bring a proposal | F6; a peer prices how much work the hire adds or removes. JD because the answer concerns the role's own boundary |
| D2 | "How do you handle credit when work spans teams? Give me an example." | VAL | [generic] | Pick a project that spanned teams, say who did what, and say how credit was shared. Name the other people by role. If no such example comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6; a credit-sharing stem is standard for peers. VAL because it scores collaboration behavior |
| D3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Answer both halves. What you need: context, access, the two or three people to meet. What you give: a concrete first contribution you could make without knowing their systems, such as mapping how work currently reaches them. Do not promise outcomes | F2; reciprocity is the point, so the answer must offer something, not only ask. JD because it scores what you would do in the role |

### Bank E: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [generic] | Script a 90-second arc in three beats: where you started, the turn that led to product operations, and why this role is the next step. Each beat must be a fact you would stand behind if asked a second question. I cannot map it to your history until I see a CV | The biography question is almost certain in some form, and a casual register still scores economy of communication. EXP because it exposes your history to follow-up |
| E2 | "What are you working on or learning these days that is relevant to this role?" | JD | [generic] | Name one specific thing: a tool, a method, a problem you are chewing on. Say what you have done with it so far and what you do not yet know. If nothing comes to mind, say so plainly, then say what you would pick up first | F3 and F5; casual questions about hot topics are scored. JD because it checks current engagement with the job's craft |
| E3 | "What would you want to be doing in this role a year from now?" | JD | [generic] | Give a direction, not a promise: the kind of problems you hope to own and what you would want to have built or fixed. Tie it to the team's needs, which means asking about them rather than assuming | F2 and F5; tests whether your ambition matches the role. JD because it scores fit against the role's scope |

### Bank F: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why should we hire you over the other finalists?" | JD | [generic] | Pause, restate the question, then give three beats you can stand behind: what you do well, what evidence you can offer, what you would do first. Hold through the follow-up without disparaging anyone. Concede plainly where another candidate might be stronger, without folding on your core case | Tests composure and brevity. JD because it scores your case for the role |
| F2 | "Think of the best result you have been part of. How much of it was actually you?" | EXP | [generic] | Say your part specifically, in verbs you would use for a colleague. Credit others by role. Hold through two follow-ups by returning to your own part, never adding to it, and concede what you do not know about how the result was counted. If no such result comes to mind, say so plainly, then give the nearest thing your material does carry | Attribution probes exist to catch inflation, so rehearse candor. EXP because it tests what was yours |

### Bank G: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Pick a number you would stand behind from your past work. Walk me through how it was counted." | EXP | [generic] | Cover the four slots a figure raises, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Saying "I don't know how that part was counted" is an honest branch. If no figure comes to mind, say so plainly, then give the nearest thing your material does carry | F3; probers go two levels deeper than the headline. EXP because it tests whether a number survives scrutiny |
| G2 | "For a metric you have owned or tracked, which assumption behind it would you defend least?" | EXP | [generic] | Name the assumption before they do. Say what would change if it were wrong and what you would check first. If no metric comes to mind, say so plainly, then say how you would find the weakest assumption in an unfamiliar metric | F3; turns a gotcha into a credibility gain. EXP because it scores self-knowledge about your own evidence |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first ninety days look like in this role, and how would you tell I was on track?" | It shows you are planning to be measured, and the answer tells you what the team scores |
| R2 | "Where does product operations create the most leverage for your teams today, and where is it still asked to do work it should not?" | It probes the real boundary of the job and signals that you think about scope |
| R3 | "How do you and the product teams decide what operations owns and what product managers keep?" | It converts the seam question into a conversation and surfaces the actual working agreement |
| R4 | "What is the hardest tradeoff this team has made recently between process and speed?" | It invites a real story, and a candid answer tells you how the team handles pressure |
| R5 | "What has changed about this role since it was first opened, and what is still unsettled?" | It shows you want the unvarnished version and reveals open decisions you may be asked to help with |
| R6 | If your interviewer is a peer: "What could a new person do in their first month that would genuinely help your team?" | Reciprocity framing for a peer; it turns the interview toward what you would add |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any claim about your own past that you have not told me and could not repeat under a second question | No CV or background was supplied, so this pack has no sentence of yours to stretch, and no entry is built from one | Every guidance cell above is a selection scaffold or a method for a live problem. Each scaffold ends in an honest branch: say plainly that no such time comes to mind, then give the nearest thing your material does carry, or how you would handle it |

## Sources

**Provided documents:** none. The company, the role and the words "final round" came from your message.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | The search was refused, so no published values were read. It would have fed a values cheat sheet and given the VAL bank Stripe's own value names; both are absent |
| 2. `Stripe interview process product operations` | unavailable | The search was refused. It would have established the loop and moved the persona weights; the weights rest on a generic archetype instead |
| 3. `Stripe strategy` / recent news | unavailable | The search was refused. It would have grounded A5 and B3 in current strategy; both stay generic |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `Product Operations Manager` JD | unavailable | The search was refused. It would have replaced the role-family requirements in F1 to F6 with quoted ones, labeled `[inferred]` |

Queries sent, all refused: `Stripe operating principles`; `Stripe interview process Product Operations Manager final round`; `Stripe strategy news 2026`; `Stripe Product Operations Manager job description`.

## Upgrade menu

- Search permission for this session → the four unavailable targets run: Stripe's published values (a values cheat sheet and value-by-value VAL questions), the documented loop (persona weights that rest on a source), recent strategy (A5 and B3 grounded in current priorities), and a representative JD (F1 to F6 requirements quoted and labeled `[inferred]`)
- A deeper research pass, offered once → up to 6 more searches and 2 more fetches, several more minutes: a strategy brief, the interviewers' talks and writing, role-family loop reports, and recent org context; it needs search permission first
- The job description text → the six `[generic]` rows in the fit snapshot become `[grounded]` rows and each JD-tagged question gets a raising source
- Your CV or a few lines on your background → the evidence column fills with your own sentences, the guidance becomes story-mapped instead of selection scaffolds, B1 is replaced by the objection your material actually invites, and each headline figure gets a defend-the-number question
- Who you are meeting and how they relate to the role → reweighted banks, an interviewer read from their public footprint, and a reverse question tied to their own path
- If your final is several sessions, the schedule → per-session mini-packs, each with its own persona weights
- The recruiter's prep email → any pre-declared deliverable gets its own build section, and stated focus areas replace assumed coverage
- Any term the posting states, such as location, office pattern or work authorization → gate rows that are surfaced and never bridged
- How much prep time you have → a prioritized schedule sized to it
- A tuesday-dossier.md from an earlier evaluation of this role, if you have one → verified evidence and a dossier-named objection to rehearse; the pack does not need it
