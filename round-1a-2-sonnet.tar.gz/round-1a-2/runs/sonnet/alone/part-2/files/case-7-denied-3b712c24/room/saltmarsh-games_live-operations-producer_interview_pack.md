# Interview prep pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Session: one 60-minute interview. Relationship assumed: hiring manager, because the material does not say how Tobias relates to the role. If that is wrong, the persona weights and banks below are the part that changes.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Type key: `VAL` values alignment, `EXP` whether a claim about your work survives scrutiny, `JD` a stated responsibility or requirement, `CO` knowledge of the company and its market, `CASE` a live problem from the role.
- No `VAL` questions appear: no values-style round is documented in anything you gave me, and no published Saltmarsh values were read.
- Provenance labels: `[grounded]` rests on your words or the JD you pasted. `[inferred]` is a derivation, named. `[generic]` is a role-family pattern with no claim about Saltmarsh or about you.
- Guidance is scaffolding, not a script. An "answer slot" is an instruction for the interview: answer it from your own experience, or say plainly that the practice was not yours or did not exist.
- Question IDs run by persona: A Case/Strategist, B Skeptic, C Data-Driven Prober, D Conversational, E Peer Evaluator, P Pressure. Fit rows are F1 to F10.
- Highest-ROI prep in this pack: B1, then B5 and B2. B1 is the question most likely to be asked in some form, and it is aimed at the two things you told me you have not done.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, and the words stay there. The JD says live events and two titles, so expect a probe on both. Answer slot: if you ever worked on a calendar for a second title, or any drop was an event with its own start and end, say which and how, in your own words; if not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | The quote touches running a calendar without showing who you worked with on it, so no coordination claim is written from it. Answer slot: if you worked with any of those four teams on a drop, say which and what you did, in your own words; if none, or it was not yours to do, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says presenting monthly retention numbers, not choosing KPIs or reviewing events, and the words stay at "I presented the monthly retention numbers to the studio head." Answer slot: the JD's review and KPI lines make a probe on who chose what was reported likely. If you chose or helped choose what went into those numbers, say what and how; if someone else did, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and QA still uses it, which is adjacent to managing it with QA. Lead with the quote in its own terms: you wrote it and the QA team still uses it. Answer slot: if you ran releases with QA against it, say how, in your own words; if QA ran it without you in each release, or you only wrote it, say so plainly and stay with the checklist |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | The quote gives four years and the title associate producer at a puzzle-game studio; it does not show whether the title was live-service. The JD says producing, so expect the title to be read literally. Answer slot: if the title received updates after launch, say what kind, in your own words; if it did not, say so plainly and stay with the four years |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap on the words: the quote already says what the JD asks. Lead with it in its own terms, weekly, your main title, the last two years, because a named calendar beats an adjective. Expect probes on it; B2, B3 and P2 rehearse them |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap on the words, but nothing inspected sits behind the line, so expect a probe on how the numbers were counted. Lead with the quote and say plainly what you do not know about how they were counted. C1 rehearses it |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | The quote shows a written document others use; it does not show how clear it is, which is the reader's judgement. Answer slot: if you wrote anything else that others relied on, say what it was and who read it, in your own words; if not, say so plainly and stay with the checklist |
| F9 | Experience with in-app purchases on mobile titles — role-family expectation, labeled generic, not a JD line | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to monetisation work, and nothing added to make the gap feel smaller |
| F10 | Leading a team — role-family expectation, labeled generic; the JD's verbs are plan, run, coordinate, own and manage the checklist, none of them lead people | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't led a team." Then what you would do about coordinating four disciplines, said as a plan and never as a past. Never a claim to have managed people |

## Persona table

Weights start from the hiring-manager prior (Case/Strategist plus Skeptic) and are adjusted by what your material shows. The loop is one session with Tobias, from your own words; nothing else about the loop is known.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | Live problems from the role: a slipping release, two titles competing for one team, a post-event review | High. Hiring-manager prior; the JD is built from planning, coordinating and reviewing, which are all problems that can be set live. 5 questions | Clarify before structuring, then objective, approach, metrics, risks; think aloud; challenge one premise respectfully per case |
| Skeptic (B) | Quiet probing of what the JD asks and your material does not show | High. Hiring-manager prior; you have stated two things you have not done (F9, F10), and F1, F3 and F5 stop short of the JD's wording. 5 questions | Rehearse B1 until it is boring; bridges only from the quotes in the fit snapshot; where none carries the point, say the limit plainly and give a plan |
| Data-Driven Prober (C) | Line-by-line probing of the retention numbers and who chose the KPIs | Medium. The JD names retention metrics and KPIs, and your material has a retention line a prober can open. 3 questions | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know; name the assumption you would defend least before they do |
| Conversational (D) | A friendly opener, then casual questions on topics the JD cares about | Medium. Most manager conversations open with a journey question, and casual questions are still scored. 3 questions | A 90-second arc built only from your four quoted sentences; treat casual questions about the calendar and checklist as scored |
| Peer Evaluator (E) | The seam between disciplines, who decides, how credit is shared | Low. Tobias is assumed to be the hiring manager, not a peer, but the JD's four-team coordination invites the seam question. 2 questions | Propose seam principles rather than claiming to know Saltmarsh's seam; show spine and tact together |
| Pressure (P) | Time-boxed challenge on why you, and how much of the work was yours | Low. Not a hiring-manager prior; kept because attribution probes on a two-year calendar are common. 2 questions | Pause, restate the question, hold the position through two follow-ups, concede specifically and never the core |

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Suppose a seasonal event is three weeks out and engineering tells you the build is a week behind. What do you do?" | CASE | [generic] | Structure it aloud. First, what you would ask: what is behind and why, what is fixed by a date players already know, what can be cut or staged. Then the options with the cost of each, who decides, who needs telling among design, art, engineering and community, and what you would record for the post-event review. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's coordination line (F2) and release line (F4), set as a decision rather than a record. `[generic]` because it is a pattern for the problem, not a fact about Saltmarsh |
| A2 | "Suppose two titles share one engineering team and both want a major event in the same fortnight. How do you plan the calendar?" | CASE | [generic] | Clarify first: what is fixed, what each event is for, what the shared team can actually carry. Then objective, sequencing options, the trade-off you would put to Tobias and what you would measure. Challenge one premise, for example whether both events must land in that fortnight. No claim about your past | The JD's two-titles line (F1) turned into a live problem. CASE because it scores structure; `[generic]` because it assumes nothing about how Saltmarsh shares teams |
| A3 | "An event we ran last month lifted engagement while it was on, but players dropped off faster than usual afterwards. How do you diagnose it?" | CASE | [generic] | Clarify the definitions first: which retention measure, which players, compared with what. Then hypotheses, the data each would need, the order you would check them in, and what you would report back. Say aloud which assumption you would test first. No claim about your past | Tests the JD's retention line (F7) and review line (F3) on a problem rather than a record. Diagnose-the-drop is a standard case stem; `[generic]` because the scenario is invented |
| A4 | "Design the post-event review you would run on one of our events. What is on the first page, and who gets it?" | CASE | [grounded] "Presented the monthly retention numbers to the studio head." | Structure: what the review is for, which KPIs are fixed before the event, the baseline, what worked and what did not, the actions, and who reads it. The one thing your material carries is that you presented the monthly retention numbers to the studio head; say that and no more. Answer slot: if you have reviewed content drops after they shipped, say how, in your own words; if you have not, say so plainly and describe the review you would run | The JD's review and KPI line (F3) and its written-communication line (F8) meet here. CASE because it is a design problem, with a quote only for the single fact it can lean on |
| A5 | "What would you want to know in your first two weeks, before you touched either calendar?" | CASE | [generic] | A list of questions, not answers: the current calendar and what is committed in it, how recent events performed against their goals, how releases move through QA, who signs off on scope, how the four disciplines hear about changes. Say which two you would ask first and why. No claim about your past | The "what do you need to know first" stem for a role you have not held; it also shows how you handle the gaps in F9 and F10 without claiming anything. `[generic]` because it is a method |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack. Name it before Tobias does, in the words your message supports: "I haven't worked on a game with in-app purchases." and "I haven't led a team." Then hold what you have, at its own scope: you ran the weekly content-drop calendar for your main title for the last two years, you wrote the release checklist your QA team still uses, and you presented the monthly retention numbers to the studio head. Expected follow-up 1, how long until you are comfortable: give your own honest estimate or say what you would need to judge it. Expected follow-up 2, what you would do first: a plan, said as a plan. Limit named in advance: do not describe monetisation work or leading people, and do not stretch the three quotes to cover them. Concede the two gaps specifically and do not fold on the three things you have done | F9 and F10 are the two stated gaps and the likeliest place to be probed; F1, F4 and F7 are the evidence that limits them. JD because it scores the stated role; asked as a Skeptic because it invites you to name the weakness yourself |
| B2 | "You ran the calendar for one title. We have two. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold only the quote: "For the last two years I ran the weekly content-drop calendar for our main title." Concede the scope plainly: one title. Answer slot: if you ever worked on a calendar for a second title, say how, in your own words; if not, say so plainly. Then what you would need to learn about the second title, said as a plan. Hold through two follow-ups by returning to the calendar you ran, never by adding to it | F1 is the evidence for the calendar requirement and the JD says two titles; this is where that gap presses hardest. JD because it scores the stated requirement |
| B3 | "You ran a content-drop calendar. Our role runs live events. What is the difference, from where you sat?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Describe the calendar in the quote's own terms: weekly, your main title. Answer slot: if any drop was an event with its own start and end, say so in your own words; if the drops were content releases only, or you are not sure how the studio categorised them, say so plainly and return to the calendar you ran. Do not adopt "live events" as a description of your own work unless your answer to the slot supports it | F1's content-drop versus live-events wording is the seam an interviewer will test. EXP because it checks how precisely you describe your own work |
| B4 | "The JD asks for three-plus years producing live-service games. You have four years as an associate producer. How much of that was live-service work?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | Hold the quote at its own scope: "I have four years as an associate producer at a puzzle-game studio." Answer slot: if the title received updates after launch, say what kind and what your part was, in your own words; if it did not, say so plainly and stay with the four years. Do not restate the title as anything other than associate producer | F5 is where the JD's years requirement presses against your title, and the JD reads literally on years. JD because it scores the stated requirement |
| B5 | "You have not led a team. The JD asks you to coordinate design, art, engineering and community on each update. Why should I think you can?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Hold-then-concede. Concede first, in your words: "I haven't led a team." Then the JD's own verb: it says coordinate, so keep the answer on coordination and do not recast it as managing people. Answer slot: if you worked with any of those four disciplines on a drop, say which and what you did, in your own words; if none, or it was not yours to do, say so plainly and describe how you would run the first update. Hold through two follow-ups; do not stretch the calendar quote into coordination | F10 is the stated gap and F2 is the row with no evidence behind it. JD because it scores the stated requirement; the negative is yours, quoted |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers to the studio head. Walk me through how those numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Open with the quote: "I presented the monthly retention numbers to the studio head." Answer slot, one for each thing a prober opens: how the numbers were counted, what they were sensitive to, the assumption you would defend least, and which part was yours. Answer each from what you know, in your own words; where you do not know, say plainly that you do not know how that was counted | F7 is the retention evidence and a CV-style line with nothing inspected behind it; this is the defend-the-number question. EXP because it checks attribution and honesty about method |
| C2 | "Which retention measures would you put on the first page of an event review, and which would you distrust?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Pick the few measures you can explain in a sentence each and say what question each one answers. Answer slot: if the monthly numbers you presented included any of them, say which, in your own words; if you do not remember what was in them, say so plainly and answer as a design choice. Name the measure you would distrust and why, before being asked | The JD's retention and KPI lines (F7, F3) asked as a design choice. JD because it scores the stated requirement |
| C3 | "Who decides which KPIs an event is reported against, and where were you in that?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold the quote: you presented the monthly retention numbers to the studio head. Answer slot: if you chose or helped choose what went into them, say what and how, in your own words; if someone else set them, or they were fixed, say so plainly and return to presenting them. Then say who you would want to agree the KPIs with before an event | F3's JD wording says own the KPIs, and the quote says present. EXP because the question tests which side of that line you stood on |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you get to producing, and why live operations?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc in four beats, each one a sentence you wrote: four years as an associate producer at a puzzle-game studio; for the last two years the weekly content-drop calendar for your main title; the release checklist your QA team still uses; the monthly retention numbers presented to the studio head. Answer slot: why live operations and why Saltmarsh are yours to say, in your own words; if the honest answer is simpler than a mission statement, say that | F5 and F1 supply the arc; the motivation is the candidate's alone. EXP because it is the biography question; delivered in the conversational register, where answers still get scored |
| D2 | "What mobile live-service games do you play, and what do their event calendars get right or wrong?" | CO | [generic] | Choose a game you genuinely play and say one specific thing you have observed about its calendar. If you do not play mobile games, say so plainly and look closely at one before the interview, then say what you saw. No claim about Saltmarsh's titles: if you can, play both of its games first | The casual version of a homework question; without research the pack cannot ground a company question in Saltmarsh's strategy, so this one is `[generic]`. CO because it scores genuine interest in the product category |
| D3 | "Tell me about the release checklist you wrote for QA." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold the quote: you wrote it and your QA team still uses it. Describe it in your own words, and let the interviewer draw their own inference. Answer slot: the JD says manage the checklist with QA, so if you ran releases with QA against it, say how; if QA ran it without you in each release, or you only wrote it, say so plainly and stay with what you wrote | F4 is the evidence for the checklist requirement and the likeliest place a casual question turns into a probe. EXP because it checks what was yours |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Design, art, engineering and community will all want a say in an update's scope. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose principles, not a claim about Saltmarsh's current seam: one named decision owner per update, a point after which scope is locked, a way for the losing side to be heard. Say which principle you would hold hardest. Answer slot: if you have been in a disagreement like this on a drop, say what it was and what you did; if there was none, or it was not yours to resolve, say so plainly | The JD's four-team coordination line (F2) as a collegial question. JD because it scores the stated requirement; `[generic]` because it supplies principles, not a story |
| E2 | "How do you handle credit when an update spans teams?" | EXP | [generic] | A selection scaffold: pick an instance where credit was shared across disciplines; it needs a named piece of work, what each side contributed, and how it was said aloud. If no such instance comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard peer stem, tied to the JD's coordination line (F2). EXP because it tests how you describe shared work |

### P. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over someone who has already run live events with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." "Never led a team, and never worked on a game with in-app purchases." | Pause and restate the question. Hold, in your own words, three things you have: the weekly content-drop calendar for your main title for the last two years, the release checklist your QA team still uses, the monthly retention numbers you presented to the studio head. Concede the gap specifically: "I haven't worked on a game with in-app purchases." Do not claim a faster ramp or a better instinct than your material shows. Hold through two follow-ups | F9 is the stated gap and F1, F4 and F7 the evidence that limits it. JD because it scores fit against the stated requirements, delivered under time pressure |
| P2 | "That calendar you ran. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: say which parts were yours and which were set by others, in your own words; if you cannot separate them, say so plainly. Hold through two follow-ups by returning to the quote, never by adding to it | F6 is the evidence for the calendar and the most direct attribution probe. EXP because it checks attribution under pressure |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A2, A5, B2, B3 |
| "coordinate design, art, engineering and community teams on each update" | A1, B5, E1, E2 |
| "own the post-event review and the KPIs it reports" | A3, A4, C2, C3 |
| "manage the release checklist with QA" | A1, D3 |
| "3+ years producing live-service games or apps" | B4, D1 |
| "experience running a content calendar" | B2, B3, P2 |
| "comfortable with player-retention metrics" | A3, C1, C2 |
| "clear written communication" | A4, D3 — no dedicated question: it is scored through the first-page review in A4, the checklist in D3, and any written follow-up after the interview |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What would a good first event look like for a new Producer here, and what would tell you early that it was going wrong?" | Turns your two stated gaps into a ramp plan, and shows you are thinking about the first event rather than the title |
| R2 | "Across the two titles, what makes the calendar hardest to run: shared teams, different cadences, or something else?" | Shows you registered the two-title requirement as the hard part, and gets Tobias's own account of the seam |
| R3 | "How are the KPIs for an event agreed: before it ships, in the review, or by a separate analytics group?" | Finds out how far the JD's own line really goes, which decides how much of F3 is yours to carry |
| R4 | "How does the release checklist work with QA today, and where would you want it to change?" | A concrete question about the one document you wrote that is closest to the role |
| R5 | "How closely does Live Operations work with whoever owns revenue decisions on these titles?" | Addresses the in-app-purchase gap constructively without claiming anything, and shows you know where to look |
| R6 | "How does the team decide an event was a miss, and what happens next?" | Signals you take the post-event review seriously, and shows the standard you would be held to |

## Prohibited claims

Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team, or managed people | Negative you stated, F10 | The plain acknowledgment F10 gives: "I haven't led a team." No slot |
| Worked on in-app purchases or monetisation | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot |
| Ran live events for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a weekly content-drop calendar for your main title. B2 and B3 stay inside that |
| Owned the KPIs or the post-event review | Inflated form of F3 | F3's quote at its own scope. The material says presenting the monthly retention numbers, not choosing KPIs or reviewing events. C3's slot asks only who set what went into the numbers |
| Managed the release process with QA | Inflated form of F4 | F4's quote at its own scope. The material says you wrote the checklist and QA still uses it. D3's slot stays inside the checklist |
| Held a producer role in live-service games | Inflated form of F5 | F5's quote at its own scope. The material says four years as an associate producer at a puzzle-game studio. B4's slot asks only what updates the title received |

## Sources

Provided documents: the JD text you pasted; your background summary in your message; the interviewer's name and title. No dossier was present.

Searches sent, all refused because search permission was not granted:

- `Saltmarsh Games mobile studio values` — refused
- `Saltmarsh Games interview process live operations producer` — refused
- `Saltmarsh Games strategy news mobile games` — refused
- `Tobias Wrenfield Saltmarsh Games Head of Live Operations` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have moved a values cheat sheet and `VAL` questions. Every call was refused; nothing from this target is used |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have moved the loop structure and persona weights. Every call was refused; the one-session loop comes from your own words, and the weights rest on the hiring-manager prior |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Would have moved the CO question and the case bank toward Saltmarsh's actual titles and priorities. Every call was refused, so D2 and the cases are `[generic]` |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have moved an interviewer read and a reverse question tied to Tobias's path. Every call was refused; the interviewer read is absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- How Tobias relates to the role (future manager, skip-level, peer) → reweights every persona and bank; a peer relationship would add a reciprocity reverse question
- The recruiter's prep note (focus areas, any exercise or presentation) → a graded-deliverable build section and coverage of the stated focus areas
- Saltmarsh's published values or interview page, pasted → a values cheat sheet and loop structure in place of the hiring-manager prior
- The names of the two titles and any recent studio news, pasted → D2 and the case bank grounded in Saltmarsh's actual products and calendar
- Tobias's public profile or talks, pasted → an interviewer read, tuned persona weights and a reverse question tied to Tobias's own path
- Search access, if granted → the four refused lookups re-run at the L1 budget; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) runs only if you say so
- Your answers to the slots in F1, F3, F4, F5 and F8, said outside a drill → those rows regenerate on your own words; the artifacts that would raise them from medium are the calendar itself, the release checklist document and one monthly retention deck
- A tuesday-dossier.md from an earlier session → verified evidence and a sharper objection list; this pack is complete without one
