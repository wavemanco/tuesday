# Kelverton Rail — Senior Partnerships Manager: interview pack

**Round:** second round, panel of two, 60 minutes. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director), as the recruiter's email gives them. The first 15 minutes are a POV from you, with no slides. The rest is Q&A, and the recruiter wrote that Ross will push on commercials.
**Built from:** the recruiter's email as you quoted it, and your background as you stated it. No JD or CV text was supplied, and the market report's text is not in this conversation, so nothing here is drawn from it.
**Prep time:** about four hours over the weekend.

## How to use this pack

- Personas describe how a question arrives. Types describe what it scores. Every question carries both.
- Types: VAL (values alignment; no values-style round is detected for this session, so there is no VAL bank), EXP (the background survives scrutiny), JD (the stated role requirements; with no JD supplied, this scores the recruiter's stated requirements), CO (company and strategy knowledge), CASE (a live problem).
- Provenance: `[grounded]` rests on your own quoted words or a supplied source. `[inferred]` is a derivation, named. `[generic]` is a pattern with no claim about Kelverton or about you.
- Answer guidance is scaffolding, not a script. An answer slot is an instruction for the interview, not a question to you.

## Prep triage (about 4 hours)

| Order | Time | Do | Where |
|---|---|---|---|
| 1 | 90 min | Choose your thesis, write the spoken spine of the POV, say it aloud against a timer twice, and rehearse the last minute until it lands on operators the same way both times | Graded deliverable; A1, A2 |
| 2 | 45 min | Rehearse the highest-ROI question until it is boring: C1 with every follow-up, then D1 and D3 | C1, D1, D3 |
| 3 | 45 min | Defend the figures aloud: what you can say, and what you cannot say, about how each was counted | B1, B2, D2 |
| 4 | 30 min | Write the 90-second opening arc and choose three reverse questions | E1; R1 to R6 |
| 5 | 30 min | One live drill, on C1 or A1 | C1 or A1 |

Everything else is insurance: A3, A4, A5, B3, B4, C2, C3, C4, E2.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, quoted in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company, not operator partnerships and not rail, with nothing inspected behind it, and the words stay there: "I have nine years in partnerships, and for the last four I was running the ISV channel at a payments company." Answer slot: the recruiter's line says operator partnerships, so expect a probe on what from the ISV channel carries across. If any of that work involved operators, say how and which part was yours, in your own words; if none did, say so plainly and stay with the ISV channel |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email, quoted in your message | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | low | [inferred] | discovery | The quote names bus and light rail network planning and says you know the operator world "from the other side"; your material does not show whose side that was, which operators, or whether train operating companies were among them. Answer slot: the recruiter asked you to land on operators, so expect "what do you know about an operator's day?" If you worked with or for operators, say who and what part was yours; if that work was bus and light rail only, or did not involve operators directly, say so plainly and stay with the network planning |
| F3 | "Ross will push on commercials" — recruiter's email, quoted in your message | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message; "never carried a direct quota, only influenced revenue" — your message | medium | [grounded] | transferability | Your material gives a partner count and an influenced-revenue figure, with no period and no counting method shown, and the words stay there: "I took it from 6 partners to 40, with roughly £4M of influenced revenue; I have not carried a direct quota." Answer slot: expect questions on the commercial side of those partnerships. If any of it was yours, say which part, in your own words; if none was, or it sat with someone else, say so plainly and stay with the figures as you gave them |
| F4 | Kelverton "sell scheduling software to train operating companies" — your message (a description of the company; no rail requirement is stated in the recruiter's words) | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't sold into rail specifically." Then how you would learn it, said as a plan and never as a past. Never a claim to rail sales, and nothing added to make the gap feel smaller |

## Graded deliverable: the 15-minute POV

The recruiter's email asks for it in these words: "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it", and "Please land on what it means for the operators themselves".

**Grounded facts to build on** (only these; each at its own scope):

- F1: "9 years in partnerships, last 4 at a payments company running the ISV channel"
- F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"
- F3: "took it from 6 partners to 40, roughly £4M of influenced revenue"
- F4: "Never sold into rail specifically"

**Three theses to choose between (pick one as your spine; each needs its concession said aloud):**

| Thesis | Spoken shape | Mandatory concession | Rests on | Provenance |
|---|---|---|---|---|
| T1: Deeper before wider. Choose a small number of operator partnerships and make each one measurable in the operator's own terms before adding more | Why depth first; what measurable-in-their-terms means and that you would ask them; what you would stop doing to make room | It is slower to cover ground, and it concentrates risk in a few operators. It also runs against the direction of the F3 quote, which counts partners going from 6 to 40; say so before they do | F3 quote, at its own scope | [generic] |
| T2: The operator's outcome is the unit of partnership. Start each partnership from what changes for the operator and plan Kelverton's side backwards from it | One partnership walked through backwards; what you would ask an operator first; what you would not promise | You are proposing it without having sold into rail (F4), and the operator's definition of an outcome has to come from them, not from you | F4 quote, at its own scope | [generic] |
| T3: Widen the model beyond the direct operator relationship, with partners built around operators the way an ISV channel extends a product | What the partner layer would add for an operator; how you would test it with a couple of operators before committing | Your quote is an ISV channel at a payments company, not at Kelverton and not in rail (F1); operators may not want more parties around their systems, and you would need to test that | F1 quote, at its own scope; derived from it and from your description of Kelverton | [inferred] |

**Differentiation strategy.** Your message says Kelverton's strategy team circulated the report internally, which makes its shortlist shared ground with the panel. This pack has not seen the report, so it names no consensus item. Bring exactly one of the report's headline items, early, to show grounding. Then make one thesis above, or your own, the departure, and say why you depart. Add the anti-pick: one kind of partnership you would decline or wind down (rehearsed as A5).

**The requested close.** The recruiter asked you to land on operators, so the last three minutes answer it directly. Give one sentence per move on what changes for an operator, then what you would need from the operators to do it. End on the operator, not on Kelverton's revenue. Rehearse the last 60 seconds until it is the same twice, because Q&A opens from it.

**Suggested 15-minute shape (aim for 13 to 14):**

| Minutes | Content |
|---|---|
| 1 | Signpost aloud what is coming (what you would find out, the moves, what it means for operators) and name your two stated limits yourself: you haven't sold into rail specifically, and you haven't carried a direct quota |
| 3 | What you would want to find out, and one or two hypotheses labelled as hypotheses |
| 7 | The moves, each with its concession |
| 3 | What it means for the operators themselves |
| 1 | What you would verify first |

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (weight 5 questions) | Deepa, and the 15-minute POV itself; follow-ups on your moves | High. The recruiter's own words make the POV a graded, case-shaped task, and the hiring-manager prior is Case/Strategist plus Skeptic | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober (4) | Ross, on the figures and the commercial side | High. The recruiter wrote that Ross will push on commercials, and F3 holds two numbers a prober goes after | Know what you can and cannot say about how each figure was counted; say plainly when you do not know; name the assumption you would defend least before they do |
| Skeptic (4) | Deepa, on the gaps you have stated | High. The hiring-manager prior includes the Skeptic, and F4 and F3 hold limits you stated yourself | Rehearse C1 until it is boring; build bridges only from adjacent quotes, and say the limit plainly where none exists; bring a ramp plan said as a plan |
| Pressure (3) | Ross, as a time-boxed challenge on the number | Medium. Ross's relationship to the role is not stated; the executive prior is Case/Strategist plus Pressure, and a commercial push can arrive time-boxed | Pause, restate the question, anchor in what you actually stated, hold through two follow-ups, then concede specifically |
| Conversational (2) | Either panelist, as the opener | Medium-low. A panel often opens warmly, and a casual question is still scored | A 90-second arc made of your quoted sentences; treat casual questions as scored |

No Peer persona: no peer is on the panel. No Values persona: neither the recruiter's words nor a loop source documents a values-style round.

## Question banks

### A. Case/Strategist (Deepa, and the POV)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk us through where you'd take our operator partnerships over the next 18 months." | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | This is the graded 15 minutes; the build is in the section above. Say the shape aloud first so the panel can follow without slides: what you would find out, two or three moves, what it means for operators. Place yourself in one sentence the quote carries: nine years in partnerships, the last four running the ISV channel at a payments company. Then the moves, each with its concession. Answer slot: the recruiter's line says operator partnerships, so expect a probe on what carries across from the ISV channel. If any of that work involved operators, say how and which part was yours; if none did, say so plainly and stay with the ISV channel | The recruiter named this as the deliverable, so it is certain rather than likely; F1 is the row it draws on. JD because it scores the stated task, with CASE delivery |
| A2 | "What does that mean for the operators themselves?" | JD | [inferred] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — derived from F2, a low-confidence row that touches operators without showing whose side or which operators | The recruiter asked you to land here, so your last three minutes already answer it; here, answer it again, shorter, with one concrete change an operator would see or do under your first move. Say what follows from your own moves and do not assert what operators want. For your own knowledge, say the quote as it stands: bus and light rail network planning, and knowing the operator world from the other side. Answer slot: if you worked with or for operators, say who and what part was yours; if that work was bus and light rail only, or did not involve operators directly, say so plainly and stay with the network planning | The close the recruiter asked for; F2 is thin, so the answer is built from your moves rather than from claimed insight into operators. JD because it scores the stated close |
| A3 | "A large operator partner tells you Kelverton's roadmap isn't giving them what they need, and they're thinking of pausing their expansion. What do you do in your first two weeks?" | CASE | [generic] | Clarify first: what exactly they mean, who is saying it, and what a pause would cost each side. Then the objective, who needs to be in the room on each side, the first conversation you would have, what you would take back internally, and what you would not promise. Think aloud, and challenge one premise respectfully, for instance whether the roadmap is the real issue. The question needs no claim about your past, so the guidance makes none | A live problem set in the role for the Strategist persona; generic because it is a pattern for the problem, not a fact about Kelverton. CASE because it scores structure and reasoning |
| A4 | "Where do you think our operator partnerships are weakest today, and what would you want to find out before saying?" | CO | [generic] | Answer the second half first: what you would need to find out, because you are outside the company. Then one hypothesis, labelled as a hypothesis, and what would change your mind. If you use the market report, bring one item from it to show grounding, then one place you would depart and why; the report is shared ground with the panel, so reciting it scores as homework. The question needs no claim about your past, so the guidance makes none | The CO question for this loop; generic because no research ran and the report's text is not in this conversation, which is the honest cost the upgrade menu addresses. CO because it tests thinking at the company's altitude |
| A5 | "Name one kind of partnership you'd decline or wind down in your first 18 months. Why?" | CASE | [generic] | This is the anti-pick, a departure from the shortlist every prepared candidate assembles. Give the criteria you would apply (what the operator gets, what Kelverton gets, what it costs to serve), then one example kind of partnership, not a named operator you cannot know about. Say what you would check before acting. The question needs no claim about your past, so the guidance makes none | A strategist's test of judgment as well as ambition; it differentiates from the consensus answer. CASE because it asks for reasoning on a live choice |

### B. Data-Driven Prober (Ross, on commercials)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the £4M was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Say the figure as your message gives it, roughly £4M of influenced revenue, never as sold or closed. Then the four slots, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say that plainly; it is an honest answer and better than an explanation you cannot repeat under a second question. Do not name a method, a baseline or a period you cannot stand behind | F3 holds the figure, and the recruiter said Ross will push on commercials, so a denominator question is likely. EXP because it tests whether the number survives scrutiny |
| B2 | "You took the channel from 6 partners to 40. What was your part in that, and what counted as a partner?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Hold at what the sentence carries: you took it from 6 partners to 40. Answer slot: which parts of that growth were yours, and which were a team's or someone else's, in your own words; if you cannot separate them, say so plainly. Answer slot: what counted as a partner, whether signed, live or producing revenue; if you know, say; if you do not, say so. Say only what you did | The second headline number on F3, defended on attribution. EXP because it tests what was actually yours |
| B3 | "Tell me about the commercial side of a partnership you've run. What was yours to decide?" | EXP | [grounded] "roughly £4M of influenced revenue"; "never carried a direct quota, only influenced revenue" | Pick the partnership where you had the clearest hand in how the commercial side worked. It needs a named type of partner, your specific part, and an outcome you can state without stretching it. If no such time comes to mind, or the commercial side sat with someone else, say so plainly, then give the nearest thing your material carries: you have not carried a direct quota, and your figure is influenced revenue. Never describe terms or decisions you did not hold | The recruiter's "push on commercials" raises this, and F3 limits it. An open prompt, so it presupposes no commercial role. EXP because it tests what was actually yours |
| B4 | "A partnership is nine months in. What would you want to see in the numbers to know it's working, for the operator and for us?" | CASE | [generic] | Pick two or three indicators and split them by whom they serve; start with the operator's, since you were asked to land on operators. Name the assumption you would defend least. Say which you would confirm with Ross as what Kelverton actually counts. The question needs no claim about your past, so the guidance makes none | A commercial-altitude problem for Ross; generic because no research ran on what Kelverton tracks. CASE because it scores structure on a live measure |

### C. Skeptic (Deepa, on the gaps)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't sold into rail and you haven't carried a direct quota. Why should we believe you can do this job?" | JD | [grounded] "Never sold into rail specifically"; "never carried a direct quota, only influenced revenue"; "took it from 6 partners to 40, roughly £4M of influenced revenue"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | **Highest-ROI prep in this pack.** Level 0: name both limits yourself in the last minute of the POV, before they ask. Level 1: the plain acknowledgment, "I haven't sold into rail specifically, and I haven't carried a direct quota", then the record at its own scope: "I took it from 6 partners to 40, with roughly £4M of influenced revenue", and the five years of bus and light rail network planning. Follow-up 2, "influenced isn't sold": concede that it is influenced revenue, hold the 6-to-40 sentence, and do not recast the figure. Follow-up 3, "light rail isn't train operating companies": answer slot: if any of that work touched heavy-rail operators, say how and which part was yours; if it did not, say so plainly and stay with bus and light rail. Follow-up 4, "what do you do in your first 90 days?": a plan in your own words, said as a plan and never as a past. Say the limit before you are asked for it: your material shows no rail sales and no quota, and the consulting quote names bus and light rail only | Every route through this loop reaches these two stated limits: the recruiter said Ross will push on commercials, and Deepa is the person who would manage you. F4 and F3 hold the limits. JD because it scores the stated job including its gaps; the deepest rehearsal because it will be asked in some form |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically"; "never carried a direct quota, only influenced revenue" | Choose from the limits you stated yourself rather than inventing a modest one. Say it plainly in one sentence, then give the ramp plan as a plan: what you would do first and who you would learn from, in your own words. Calibrated candor beats bluffing a competency that the titles the recruiter gave suggest the panel personally owns | The standard Skeptic stem; F4 and F3 hold the limits. JD because it scores can-you-do-the-listed-job |
| C3 | "Why leave a payments company for rail-tech, and why now?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | Give your actual reason for leaving in your own words; this pack supplies none. Say what you are moving toward as well as away from, one sentence each. The facts you may use are the quote: nine years in partnerships, the last four at a payments company. Answer slot: if the transport consulting years are part of why now, say how; if they are not, leave them out | Motivation-consistency probe on the F1 row. EXP because it tests the story of the career, with the reason for leaving as your own |
| C4 | "What would an operator get from you that they wouldn't get from someone who has worked in rail for years?" | JD | [inferred] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — derived from F1 and F2, the second a low-confidence row | Use your own record at its own scope: nine years in partnerships, the last four running the ISV channel, and the network planning years "so I know the operator world from the other side", said as your sentence and not as insider status. Do not assert what operators need. Answer slot: say what you would do in your first conversation with an operator, as a plan; if you do not yet know, say what you would ask first | The Skeptic's version of A2, aimed at F2, the thinnest row. JD because it scores fit for the stated operator focus |

### D. Pressure (Ross, time-boxed)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you, and not someone who has carried a quota in rail?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue"; "Never sold into rail specifically"; "never carried a direct quota, only influenced revenue" | Pause and restate the question, then three short sentences: the limit, the record, what follows. Limit: "I haven't carried a direct quota and I haven't sold into rail specifically." Record: "I took it from 6 partners to 40, with roughly £4M of influenced revenue." Hold the record through two follow-ups; concede specifically what influenced revenue is not; do not fold the record to restore harmony. Answer slot: what follows, in one sentence of your own; if you cannot make the link without stretching it, say what you would need to learn | A Pressure stem on the pairing of F3 and F4. EXP because it tests whether a position is held honestly rather than inflated |
| D2 | "That £4M: how much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" | Hold the sentence at its own words: roughly £4M of influenced revenue. Answer slot: if you can say which part of the influence was yours, say it in your own words; if it was a team's, or cannot be separated, say so plainly and do not estimate a share you cannot defend. Concede the specific thing you do not know before the second follow-up. Never turn influenced into sold or owned | The standard Pressure attribution stem, aimed at F3. EXP because it tests what was actually yours |
| D3 | "'Influenced revenue' is what people say when they didn't own the number. Convince me otherwise." | EXP | [grounded] "never carried a direct quota, only influenced revenue"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Do not argue it away; this is the hold-then-concede test. Concede the true part in your own words: "I haven't carried a direct quota, and my figure is influenced revenue." Then hold only what the quotes carry: "I took it from 6 partners to 40." Answer slot: if any of your work shifted what partners produced, say what and how, in your own words; if there is nothing you can state, say so plainly and move to your 90-day plan | A challenge to a stated limit, in the register of F3. EXP because it tests composure and honest concession |

### E. Conversational (opener)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | A 90-second arc made only of those sentences: the consulting years, the partnerships years, the ISV channel and its growth. Say the order as it actually was; your message does not show whether the consulting years sit inside the nine or before them, so state the dates in your own words. End on why this role, in your own words; this pack supplies no reason | The conversational biography question, scored though casual; F1, F2 and F3 supply the beats. EXP because it tests whether the background holds together |
| E2 | "What are you most interested in about rail-tech right now?" | CO | [generic] | Pick one topic you can take three follow-ups on, and say where it comes from: your own work, or the market report. If your honest answer is that you are newer to rail, say so plainly and say what you would learn first. The question needs no claim about your past, so the guidance makes none | A casual question on a hot topic of the role, still scored. CO because it tests homework depth; generic because no research ran |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1: POV on operator partnerships over 18 months | A1, A3, A4, A5, B4, C4 |
| F2: land on what it means for operators | A2, C4, E2 |
| F3: commercials, and the two headline figures (6 to 40 partners, roughly £4M influenced) | B1, B2, B3, B4, D1, D2, D3 |
| F4: rail sales, a stated gap | C1, C2, D1 |
| No stated requirement: opening biography and motivation | E1, C3 — none, and why: no source states a requirement; the questions are the panel openers and the motivation probe |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | To Deepa: "What would you want operators to say about Kelverton's partnerships in 18 months that they can't say today?" | It echoes the brief you were given and keeps the conversation on operators |
| R2 | To Deepa: "Which operator partnership do you most want to be different by this time next year, and what's in the way?" | It asks for a real constraint you can set against your POV |
| R3 | To Ross: "When you push on a partnership's commercials, which number or term tells you it's working?" | It names his lens and leaves you knowing what you would be measured on |
| R4 | To Ross: "How is partnership performance counted at Kelverton, and what would count toward my number and what wouldn't?" | It addresses influenced against direct before the panel does, and shows you care about counting honestly |
| R5 | To both: "Where in what I presented would you push back first?" | It invites live pushback on your thesis, which is the hold-then-concede skill, shown |
| R6 | To Deepa: "What would my first 90 days look like if I haven't sold into rail yet, and who would I spend time with?" | It owns a limit you stated yourself and shows a ramp plan, in your words |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Sold into rail, or has rail sales experience | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't sold into rail specifically." No slot |
| Carried a quota, owned the number, or sold the £4M | Negative you stated, F3 | The plain acknowledgment: "I haven't carried a direct quota", with the figure as "roughly £4M of influenced revenue". No slot |
| Built the channel from scratch, or recruited the partners yourself | Inflated form of F3 | F3's quote at its own scope: "took it from 6 partners to 40". The limit is the pack's observation, not words for you: the material gives the growth, not how it happened or which part was yours. B2's slot stays inside the sentence |
| Advised train operating companies, or knows what operators need | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says bus and light rail network planning and "the operator world from the other side", not whose side or which operators. A2's slot stays inside the quote |
| Set the terms of partner agreements | Inflated form of F1 and F3 | F1's and F3's quotes at their own scope. The limit is the pack's observation: the material says you ran the ISV channel and gives influenced revenue, not who held the commercial side. B3's slot asks only what was yours |
| A total career length, or that the consulting years count as partnerships years | Inflated form of F1 and F2 | The two quotes, each at its own scope. The limit is the pack's observation: the material gives nine years in partnerships and, separately, five years in transport consulting before that, and does not show whether they overlap. E1's slot has you state the dates |

## Sources

**Provided:** your message, including the recruiter's email as you quoted it. The market report is named in your message, but its text is not in this conversation, so nothing is drawn from it. No tuesday-dossier.md was present.

**Searches sent (all refused; the host had not granted web search):**

| Query | Outcome |
|---|---|
| Kelverton Rail company values | refused |
| Kelverton Rail scheduling software train operating companies news strategy | refused |
| Deepa VP Partnerships Kelverton Rail | refused |
| Ross Commercial Director Kelverton Rail | refused |
| Senior Partnerships Manager rail technology job description train operating companies | refused |

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Would have fed a values cheat sheet and VAL themes; no values-style round is detected for this session, so no section changed either way |
| 2. `Kelverton Rail interview process partnerships` | skipped | The recruiter's email, quoted in your message, fixes this session: two panelists, 60 minutes, a 15-minute POV and then Q&A. Persona weights and the loop follow from it |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Would have grounded A4, A5, B4 and E2, now generic, and supported a grounding brief |
| 4. `Deepa` and `Ross` with title and company | unavailable | Would have added an interviewer read, adjusted persona weights, and tied a reverse question to each panelist's path |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Would have given the fit snapshot fetched requirements to quote; its rows rest on the recruiter's quoted words instead |

## Upgrade menu

- The JD text → the recruiter-quoted requirements become JD-quoted rows, any gate such as location, travel or pay appears as its own row, and the JD-tagged questions firm up
- The market report's text, or its key pages → a grounding brief, A4, A5 and B4 move from `[generic]` to grounded, and the POV's one consensus item and one departure are named exactly
- Web search permission → loop and strategy checks, an interviewer read for Deepa and Ross, and reverse questions tied to their paths; a deeper pass (L2, up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief and recent organisation context
- Deepa's and Ross's surnames or profile links → the interviewer read and a reverse question tied to each one's career path
- The partner list and the influenced-revenue report behind the £4M and the 6-to-40 count → B1, B2 and D2 become story-mapped answers, and the evidence on F3 can move from medium to high
- Your actual dates for the consulting and partnerships years → E1's arc and the career-length entry in the prohibited list resolve
- The recruiter's notes on what Ross will probe in commercials → B3 and B4 retuned to his real focus
- A tuesday-dossier.md, if you have one from an earlier session → verified evidence and its prohibited claims arrive pre-graded, and this pack's hold language is checked against them
