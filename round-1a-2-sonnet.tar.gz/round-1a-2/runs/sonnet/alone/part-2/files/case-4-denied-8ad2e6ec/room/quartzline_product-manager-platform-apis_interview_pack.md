# Interview pack: Product Manager, Platform APIs at Quartzline

- **Role:** Product Manager, Platform APIs, Quartzline
- **Round:** one 45-minute conversation with the hiring manager (your words). The interviewer is not named, so there is no interviewer read.
- **Built on:** your `tuesday-dossier.md` (decision `conditional_go`). Its role profile supplies the requirements and its handoff section supplies your confirmed evidence, the gap strategies, the named objection and the prohibited claims.
- **Decision conditions carried in:** the bridge is positioned as adjacent and never as PM experience (rehearsed in A1 and E1), and the squad-authority question gets verified in the interview (RQ1).

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script. Say it in your own words and only what you did. An answer slot is an instruction for the interview: it tells you where to answer from your own experience, and it always allows that the practice was not yours or never existed.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values (none in this pack, see Sources) |
| EXP | Whether a claim about your work survives scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

## Fit snapshot

Evidence is your confirmed claims from the dossier, quoted exactly. Confidence and gap type for F1, F2 and F6 are the dossier's. The dossier gives no graded row for R2, R3 or R4, so F3 to F5 are this pack's own grading and are labeled `[inferred]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | low | [grounded] | transferability | Strategy from the dossier: bridge, positioned as adjacent and never as PM experience. Words stay at the quotes' scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs" and "I ran quarterly roadmap-input sessions feeding client evidence to product". The limit is the pack's observation: your material shows integration leadership and roadmap input, not a PM title or product ownership. The second quote carries the dossier's medium grade (confirmed, limited inspectable proof), so volunteer what you can show and what you can only describe before a prober extracts it. Plain acknowledgment, sourced to `prohibited_claims: "Having held a product manager title or role"`: "I haven't held a product manager title." |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | Strategy from the dossier: acknowledge_gap, so no bridge. Plain acknowledgment, sourced to the dossier's `acknowledge_gap` area "Owning a roadmap and prioritization authority (R1 sub-claim)" and to `prohibited_claims: "Having owned a product roadmap"`: "I haven't owned a roadmap." Then a plan, said as a plan and never as a past: in the first weeks, learn from the two squad leads which roadmap decisions sit with whom and how adoption is measured today, before proposing anything. The roadmap-input sessions in F1 stay at their own scope. Your material shows them feeding product, not setting a roadmap, so they are not offered here |
| F3 | "Shipped API or platform products" — dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | low | [inferred] | transferability | Derived by the pack, since the dossier grades no R2 row. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs." The limit is the pack's observation: your material says integrating the vendor's REST APIs for clients, not a product of your own. Answer slot: R2's wording makes a probe on what went live likely. Say which integrations went live and what part of each was yours, in your own words; if what went live was client integrations and nothing beyond them, or the part was not yours, say so plainly and stay with the integrations as quoted |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence 2 | low | [inferred] | discovery | Derived by the pack. The quotes touch REST APIs and architecture without showing whether API docs or schemas were part of the work. Answer slot: R3 names API docs and schemas, so expect a probe on each. If you worked with them, say which and how, in your own words; if you did not, say so plainly and stay with the architecture work and the playbook as quoted |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | medium | [inferred] | transferability | Derived by the pack. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs" and "I ran quarterly roadmap-input sessions feeding client evidence to product". The JD says customers and your sentences say clients, so keep your word. The second sentence is medium (confirmed, limited inspectable proof), so name its limit first. Answer slot: R4 names engineering and sales, which the quotes do not carry, so expect a probe on each. If you worked with engineering or sales on those integrations, say how, in your own words; if you did not, or it was not yours, say so plainly and stay with the clients and product as quoted |
| F6 | "Agile delivery experience" — dossier role_profile R5, preferred; dossier weak area "Agile delivery inside a product org (R5)" | none given | low | [grounded] | discovery | Strategy from the dossier: clarify, meaning the evidence may exist but was not established. None of your three confirmed entries speaks to this requirement, so none is quoted. Answer slot: expect a probe on what agile delivery has meant in your work. If you worked that way, say how, in your own words; if you never worked that way, say so plainly, and say what you would want to confirm about how Quartzline's squads define it |

## Persona table

The loop is one hiring-manager conversation, from your own words. The weights below rest on the hiring-manager prior, not on a documented Quartzline process, because no source on Quartzline's interviewing could be read.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 5 questions) | Quiet, persistent probing of the gap between your background and the PM title | High. A hiring manager is derisking gaps, and the dossier names a gap-probing objection for this role (A1) | Concede the limit before it is extracted, hold the adjacent case at its own scope, then give a plan |
| Case / Strategist (bank B, 5 questions) | Live problems from the actual roadmap: adoption, prioritization across two squads, spec disputes | High. The hiring-manager prior expects live problems, and the role's responsibilities are roadmap, delivery with two squads and adoption metrics | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober (bank C, 3 questions) | Reads your evidence line by line and asks how the number was counted | Medium. "30+" is the one figure in your evidence, and the integration playbook is the one inspectable item | Know what you can and cannot say about how the figure was counted; say plainly when you do not know |
| Conversational (bank D, 3 questions) | Friendly opener, then casual questions on hot JD topics that are still scored | Medium. A 45-minute conversation usually opens with the biography, and the casual questions carry the technical and stakeholder requirements | A 90-second arc built only from your quoted sentences; treat casual questions as scored |
| Pressure (bank E, 2 questions) | Time-boxes the objection: "sixty seconds" | Low to medium. No signal of a stress style, but A1 may arrive time-boxed | Pause, restate, hold the position through two follow-ups, concede specifically |
| Peer Evaluator (bank F, 2 questions) | Collegial seam questions about the two squad leads | Low. The interviewer is your future manager, but the JD names two squads and the dossier lists squad authority as unknown | Offer seam principles instead of claiming to know the seam; show tact and spine together |

No Values / Behavioral bank: no source read shows a values-style round, and your own description is a single hiring-manager conversation. Published values were not fetched, so no VAL question has a raising source.

## Question banks

Quotes in Provenance are your confirmed evidence, exactly as in the fit snapshot. Each row quotes the sentences it rests on.

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | **Highest-ROI prep in the pack.** Four levels, in order. (1) Concede first, before it is extracted: "I haven't held a product manager title, and I haven't owned a roadmap." Sources: `prohibited_claims: "Having held a product manager title or role"` and `prohibited_claims: "Having owned a product roadmap"`. (2) Hold the adjacent case at its own scope, and call it adjacent, not PM experience: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live", "I wrote the internal integration playbook my team uses" and "I ran quarterly roadmap-input sessions feeding client evidence to product". Offer the playbook to look at. For the sessions, say what you can show and what you can only describe, because that line is medium (confirmed, limited inspectable proof). (3) Follow-up on what happened to the evidence after those sessions. Answer slot: the JD's roadmap line makes this likely. If you know what product did with it, say what, in your own words; if you do not know, or it was not tracked, say so plainly and return to the sessions as you ran them. (4) Follow-up that a PM with three years has done this daily: concede specifically that roadmap ownership is the part you have not done. `prohibited_claims: "Having set prioritization for an engineering squad"` is the other line you do not cross: "I haven't set prioritization for an engineering squad." Then the plan: learn from the squad leads which decisions sit with whom. Never fold on the core claim, and never stretch the integration work into the title | The dossier's underwriter named this objection; it was derived from evidence you confirmed, not inferred here. F1 is the bridge and F2 the acknowledged gap. JD because it scores R1, the must-have the dossier's decision is conditioned on |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] `acknowledge_gap: "Owning a roadmap and prioritization authority (R1 sub-claim)"` | Name it first and plainly: the weakest part is owning a roadmap and prioritization authority, which the dossier records as an area to acknowledge. Words: "I haven't owned a roadmap." Then the plan, said as a plan: in the first weeks, learn from the two squad leads which roadmap decisions sit with whom, and how adoption is measured today, before proposing anything. Do not name a second weakness for effect, and do not soften this one with the sessions line, which belongs in A1 | F2 is the gap the interviewer will look for, and this stem asks for it directly. JD because it scores the role's first responsibility |
| A3 | "What's pulling you from integration delivery toward product?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Your material states no reason, so the reason is an answer slot: give your actual reason, in your own words, in two sentences at most. If asked what you have done toward product work, say "I ran quarterly roadmap-input sessions feeding client evidence to product" at that scope, and name its limit before a prober does: it is medium, confirmed, with limited inspectable proof. Do not describe it as product work you owned | The skeptic's motivation probe. F1 is the only row where your work touches product. EXP because it tests whether the story holds across questions |
| A4 | "Which API or platform products have you taken from start to go-live?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold only the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: the premise of this question is the JD's, and R2 is a must-have. If a product of that kind went live and you had a part in it, say which and what part, in your own words; if none did, or the part was not yours, say so plainly and stay with the integrations as quoted. Hold through one follow-up by returning to the integrations, never by widening them | F3 is where R2 presses hardest and the dossier grades no row for it, so it is the likeliest second probe after A1. JD because it scores a stated must-have |
| A5 | "How have you worked in an agile delivery process?" | JD | [grounded] | Nothing about your past is asserted here. Answer slot: the JD reads "Agile delivery experience", and the dossier marks this area clarify. If you worked that way, say how, in your own words; if you never worked that way, say so plainly, and say what you would want to confirm about how Quartzline's squads define it. It is a preferred requirement, so a short honest answer costs little | F6 is a discovery gap, not a capability gap, so the honest answer may be better than the dossier assumes. JD because it scores R5 |

### Bank B: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partners tell us the API is hard to adopt. How would you find out why, and what would you do first?" | CASE | [generic] | Clarify before you structure: what counts as adopted, how adoption is measured today, and which partners are saying it. The dossier lists measurement as unknown, so asking is real diligence. Then objective, segmentation (for example by partner type and by stage from first call to production traffic), approach (talk to partners, read onboarding and support evidence), metrics, risks. Think aloud and challenge one premise respectfully: "hard to adopt" may mean different things at different stages. Keep the case on the problem; it asks about no past | The JD's discovery-with-partners responsibility, as a live problem. CASE because it scores structure; `[generic]` because it is a role-family pattern, not a fact about Quartzline |
| B2 | "We have two squads and more partner asks than capacity. How do you decide what goes on the roadmap?" | CASE | [generic] | Say the concession in one clause up front: "I haven't owned a roadmap, so this is how I would approach it, not how I have done it." Source: the dossier's `acknowledge_gap` area "Owning a roadmap and prioritization authority (R1 sub-claim)". Then clarify who decides what between the PM and the squad leads, and state criteria as principles (partner reach, strength of evidence, cost to the squads, reversibility) with the trade-off between two of them. Name one decision you would escalate. Propose principles; claim no authority | F2 under live pressure. CASE because the answer is a method, and the concession keeps it honest |
| B3 | "How would you define and track adoption for a partner API platform?" | CASE | [generic] | Ask first what is measured today and what baseline exists, so you propose against it rather than around it. Then a small set of stages from sign-up to first successful call to production traffic, each with a definition. Name the assumption you would defend least: that one definition of adopted fits every partner. Say how you would test it | The JD's adoption-metrics responsibility, and the dossier's open risk that no baseline is stated. CASE because it asks for a design, not a history |
| B4 | "Two squads read the same spec differently and a partner's go-live date is at risk. Walk me through what you do." | CASE | [generic] | Clarify what is ambiguous, what each squad has built and how much room the date has. Find out who owns the decision rather than assuming you do. Resolve against the written spec, record the decision where both squads will see it, tell the partner early and plainly, then fix the cause so the next spec closes the gap. It asks about no past, so claim none | The JD's specs-and-delivery-with-two-squads responsibility. CASE because the interviewer scores the order of your moves |
| B5 | "What do you know about where our partner API platform is today?" | CO | [generic] | This pack could not research Quartzline, so it holds no company facts. Say only what you have read yourself, and say where you read it. If Quartzline publishes API docs or a changelog, read them before the call. Turn the gap into the questions you would ask: how adoption is measured today and which roadmap decisions the PM makes alone (RQ1, RQ2). Do not guess at strategy or competitors | The honest cost of unavailable research: the company question stays generic. CO because it scores homework |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ integrations. How did you count them?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The figure is in your sentence: "30+" attached to integrations. Answer in four slots, each in your own words: how it was counted, what the number is sensitive to, the assumption behind it you would defend least, and which parts were yours. Say plainly when you do not know how something was counted. Keep "led" as the verb, and do not turn the figure into 30+ clients or 30+ go-lives unless that is how you counted it | The only figure in your evidence, so a magnet for probers. F1 and F3 both rest on it. EXP because it tests attribution and counting |
| C2 | "Walk me through one of those integrations, from scoping to go-live." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pick one integration and tell the five stages your sentence states, in your own words: scoping, requirements, architecture, UAT, go-live. Say "led" at the scope the sentence gives. Your material states no incident or outcome, so none is supplied; add only what you remember and can stand behind. If asked what was yours at a stage, answer from that stage, and if a part was not yours, say so | The probe that tests whether the headline sentence is a story or a line. EXP because it asks what you actually did |
| C3 | "Tell me about the integration playbook. Who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Say what the sentence says: "I wrote the internal integration playbook my team uses." It is the item with something to inspect, so offer to walk the interviewer through it. If asked how it is used day to day, say what you know; if you do not know, say so plainly. Do not extend it to other teams or to a measured effect | The best-evidenced item you have, so the one to lean on. EXP because it tests the claim's edges |

### Bank D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in three beats, in your own words: the integrations you led, the playbook you wrote, the roadmap-input sessions you ran. Then why this role: your actual reason, as in A3. Close by naming the position as adjacent, not PM experience. Add no dates and no team sizes, since your material gives none | The casual opener is scored. EXP because it fixes the story every later question has to match |
| D2 | "What are you working with in API docs and schemas these days?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: R3 reads "Technical fluency: API docs, schemas". If you work with API docs or schemas, say which and how, in your own words; if you do not, say so plainly and stay with the architecture stage of the integrations as quoted. Name nothing you have not touched | F4 is a discovery gap, so the honest answer may be better than the pack can see. JD because it scores R3 |
| D3 | "How have you worked across engineering, sales and customers?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Start with what is quoted: "I led 30+ end-to-end client integrations of the vendor's REST APIs" and "I ran quarterly roadmap-input sessions feeding client evidence to product", with the second line's limit named (medium, limited inspectable proof). Keep your word clients. Answer slot: R4 names engineering and sales, which the quotes do not carry. If you worked with either on those integrations, say how, in your own words; if you did not, or it was not yours, say so plainly and stay with the clients and product as quoted | F5 is partial evidence for R4, and the interviewer will test the two groups it does not cover. JD because it scores a stated requirement |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who's done the job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause and restate the question. One concession sentence: "I haven't held a product manager title." Source: `prohibited_claims: "Having held a product manager title or role"`. One hold sentence: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Then stop. Hold through two follow-ups by restating the same sentence in different words, never by adding to it, and concede uncertainty specifically | A1 under a clock. JD because it scores R1; the pressure is in the delivery |
| E2 | "That roadmap-input work — how much of it was actually you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Hold the verb in your sentence: "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot: if others co-ran the sessions or product led them, say who and what each of you did; if you ran them yourself, say that. Do not extend it to deciding what went on the roadmap. Name the limit before it is extracted: this line is medium, confirmed with limited inspectable proof, so say what you can show and what you can only describe | The attribution probe aimed at the thinnest-evidenced line. F1 and F5 both lean on it. EXP because it tests exactly what was yours |

### Bank F: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Where's the seam between you and the squad leads, and what happens when you disagree?" | CASE | [generic] | Offer seam principles, not a claimed seam: the dossier lists decision authority against the two squad leads as unknown, so say you would want to agree it early. One concession: "I haven't set prioritization for an engineering squad." Source: `prohibited_claims: "Having set prioritization for an engineering squad"`. For disagreement, state a principle: agree who decides before the disagreement, bring partner evidence, name the trade-off. Tell no disagreement story | The squad-authority condition in the dossier's decision, rehearsed from your side. CASE because it asks for a method, not a history |
| F2 | "When work spanned teams, how did you handle credit?" | EXP | [generic] | A selection scaffold: pick an instance where a result involved other teams. It needs a named split of who did what, "we" for the context and "I" for your part, and credit going where it was due. If no such instance comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The peer stem on credit. EXP because it tests attribution habits; `[generic]` because the pack has no sentence of yours on cross-team work |

### Requirement coverage

| Requirement or responsibility (source) | Questions |
|---|---|
| "3+ years product management experience" — dossier role_profile R1 | A1, A2, A3, E1 |
| "Shipped API or platform products" — dossier role_profile R2 | A4, C1, C2 |
| "Technical fluency: API docs, schemas" — dossier role_profile R3 | D2, C3 |
| "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | D3, E2, F1, F2 |
| "Agile delivery experience" — dossier role_profile R5 | A5 |
| "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | A1, A2, B2 |
| "Run discovery with integration partners" — dossier role_profile responsibilities | B1 |
| "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | B4, F1 |
| "Define and track adoption metrics" — dossier role_profile responsibilities | B3 |
| The figure "30+" in your evidence | C1 |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Reads as diligence, and it answers the dossier's open condition: the JD asserts authority over the squads, and nothing in your material shows it. The answer tells you whether you would hold what the JD implies | [grounded] |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | The JD names adoption metrics as a responsibility and states no baseline. A real answer tells you what you would be measured against | [grounded] |
| RQ3 | "How do the two squads divide the platform today, and where do requests that cross both get decided?" | Ties to the seam you rehearsed in B4 and F1, and shows you are thinking about how the work is actually run | [generic] |
| RQ4 | "What would a strong first quarter look like for someone arriving from integration delivery rather than a PM role?" | It invites the interviewer to name the gap and its ramp, which turns A1 from an objection into a plan | [generic] |
| RQ5 | "How does partner feedback reach the roadmap today, and who carries it?" | Opens the roadmap-input topic on the interviewer's terms, so you learn how that work is organized before you describe yours | [generic] |
| RQ6 | "Is there anything in my background you'd want more evidence on before the next step?" | It lets the A1 objection surface in the room, where you can answer it, rather than after the call | [generic] |

## Prohibited claims

Built from the dossier's `prohibited_claims` and from the fit snapshot. Nothing in this pack coaches these, and no answer slot names them.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | F1's quotes at their own scope, plus the plain acknowledgment sourced to `prohibited_claims: "Having held a product manager title or role"`: "I haven't held a product manager title." |
| Having owned a product roadmap | Dossier `prohibited_claims`, and the dossier's `acknowledge_gap` area | The plain acknowledgment sourced to `prohibited_claims: "Having owned a product roadmap"`: "I haven't owned a roadmap." The roadmap-input line stays at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product" |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | The plain acknowledgment sourced to `prohibited_claims: "Having set prioritization for an engineering squad"`: "I haven't set prioritization for an engineering squad." |
| Shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says integrating the vendor's REST APIs for clients. A4's slot asks only what went live from those integrations and what part was yours |
| Ran product discovery with integration partners | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: the material says sessions feeding client evidence to product, not discovery. No slot |

## Sources

**Provided documents:** `tuesday-dossier.md`, pasted in the conversation (dossier_version 1.1, generated 2026-08-14 by the dossier's own header). Consumed sections: role_profile (requirements and responsibilities, standing as the JD), handoff_to_mock_interview (verified evidence, weak areas and strategies, objection, risks, employer questions, prohibited claims) and decision (context only). The dossier carries no evidence_map, evidence_state or risk_register section, so F3 to F5 are this pack's own grading. If anything in your evidence has changed since 2026-08-14, tell me and the affected rows regenerate.

**Searches sent:**

- "Quartzline company values" — refused
- "Quartzline interview process product manager" — refused
- "Quartzline strategy news partner API platform" — refused

No pages were fetched. Nothing in this pack comes from outside the dossier, and every company-facing question is labeled `[generic]`.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Every call was refused. It would have given VAL questions a raising source and, if a values round is documented, a values cheat sheet |
| 2. `Quartzline interview process product manager` | unavailable | Every call was refused. It would have named Quartzline's actual rounds and case format; persona weights rest on the hiring-manager prior instead |
| 3. `Quartzline strategy` / recent news | unavailable | Every call was refused. B5 and the CASE questions stay `[generic]` instead of resting on current priorities |
| 4. `{interviewer name} Quartzline` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access → the values, process and strategy lookups run, so B5 becomes a sourced company question and any documented values round gets its own bank; a deeper pass would add up to 6 more searches and 2 more fetches, several more minutes, and is yours to ask for
- The interviewer's name → an interviewer read, persona weights tuned to their public footprint, and a reverse question tied to their own path
- The recruiter's note on format or focus areas → coverage for a case, presentation or take-home if one is expected; usually one email
- Prep time available → a prioritized schedule sized to it, with everything else marked as insurance
- An agenda or deck from one of your roadmap-input sessions → F1, F5 and E2 could move from medium toward high on the sessions line
- Your CV behind the confirmed claims, or a dossier evidence map for R2 to R4 → F3 to F5 move from `[inferred]` to `[grounded]`
