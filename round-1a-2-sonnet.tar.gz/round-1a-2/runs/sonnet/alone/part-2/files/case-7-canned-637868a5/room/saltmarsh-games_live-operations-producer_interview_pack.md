# Interview prep pack: Live Operations Producer, Saltmarsh Games

- **Candidate:** Femi
- **Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager. The careers page (Sources, target 2) describes the one 60-minute interview as being with the hiring manager, and the pack treats Tobias as that person until you say otherwise.
- **Round:** the careers page describes it as the Outage Hour, a live-incident tabletop on a simulated outage during a live event, then a values conversation, with no take-home (Sources, target 2). Persona weights rest on that page, not on an archetype.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Rehearse both: say the answers aloud, in your own words.

| Type tag | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values, not generic virtue |
| EXP | Whether your own claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's altitude: strategy, recent moves |
| CASE | Whether you structure a live problem from the real role |

Guidance is scaffolding, not a script. An answer slot is an instruction for the interview, not a question for you now: it names what an interviewer is likely to probe and gives two honest branches. Either branch is a good answer. Provenance labels: grounded means traceable to your words, a provided document or cited research; inferred means derived from a representative or adjacent source; generic means a role-family pattern with no claim about you or this employer.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one title's weekly content-drop calendar, not a live-events calendar and not two titles. The words stay at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-title and live-events lines make a probe on both likely. If any of your drops were events, or you ran a second title's calendar, say which and what you did, in your own words; if not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show whether you worked with these four disciplines on drops. Answer slot: the JD names all four, so expect a probe on who you coordinated with. If you worked with any of them on a drop, say which, what you needed from them and what you did when they disagreed, in your own words; if you did not, or the disciplines were different ones, say so plainly and answer as a plan |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says presenting monthly retention numbers, not owning a review or the KPIs in it. The words stay at that scope: "Presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-review line makes a probe on who set what the review covered likely. If any part of that was yours to set, say what and how you decided; if none was, or no review of that kind existed, say so plainly and stay with presenting the numbers |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says wrote, with QA still using it, not managed. The words stay at that scope: "I wrote the release checklist our QA team still uses." Answer slot: the JD's manage-with-QA line makes a probe on the checklist in use likely. If you ran it through releases with QA, say how, in your own words; if you did not, or that part was not yours, say so plainly and stay with the checklist you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The years are stated, four against the JD's three. Your material does not say whether the game was run as a live-service title. Words at the sentence's scope: "I spent four years as an associate producer at a puzzle-game studio." Answer slot: if the game was run live, say what that meant week to week, in your own words; if it was not live-service in the way the JD uses the term, say so plainly and stay with the weekly calendar you ran |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a one-line claim with nothing inspected behind it, so expect a probe. Lead with the sentence's own terms: you ran it, weekly, for the main title, for two years, because a named cadence beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in subject, but the sentence says presented, not analyzed or owned. Lead with its own words and expect a probe on how the numbers were counted (D2) |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A written checklist touches the requirement and does not show how clear it was to its readers; your material holds no writing sample. Answer slot: the JD's written-communication line makes a probe on how you knew it was clear likely. If QA or anyone else gave you feedback on it, or you changed it from how it was used, say what; if none, say so plainly and describe what the checklist covers |

## 3. Reading the interviewer

Public professional footprint only. The talk was read as a search-result listing; the talk itself was not read.

| Observation | Source | What it means for you |
|---|---|---|
| Head of Live Operations at Saltmarsh Games; previously a QA lead at a console studio | GDC 2026 talk listing (Sources, target 4) | The release checklist (F4) is likely to get a close read from someone with that background. Speak about it in the sentence's own terms and no wider |
| 2026 GDC talk "Patch Notes Are a Promise"; his argument is that a live team is judged by how often its patch notes describe what actually shipped | GDC 2026 talk listing (Sources, target 4) | The values half is likely to turn on announced versus delivered (B2). Keep every claim at what you did and what shipped, never at what was planned |

Mirror opportunity, shared vocabulary only: QA and the release checklist. When the checklist comes up, the one sentence to place is F4's: "Wrote the release checklist our QA team still uses." Do not offer it as a shared path; the pack has no evidence of one. Shared identity is never a strategy.

## 4. Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The tabletop on a simulated outage during a live event | High. The loop page names the tabletop as the interview's first half (Sources, target 2), and a hiring manager's prior is also case-led | Clarify, state the objective, assign roles, say what you would tell players, name what you would measure, challenge one premise. Think aloud |
| Values / Behavioral | The values conversation that follows the tabletop | High. The loop page names a values conversation (Sources, target 2), and the three published values are in hand (Sources, target 1) | Map a story to each value where your own sentences carry one; otherwise pick by the scaffold and use its honest branch |
| Skeptic | Quiet probing of what the background does not show | Medium. Hiring-manager prior; your material shows no team led and no in-app purchases, and the shared-calendar announcement (Sources, target 3) makes the second one live | Rehearse C1 until it is boring: hold what your sentences carry, concede the limit in a plain sentence, then give a plan, never a past |
| Data-Driven Prober | Line-by-line questions on the calendar and the retention numbers | Medium. Hiring-manager prior; the interviewer's talk theme is shipped versus announced, which invites precision on attribution | Say plainly what you do and do not know about how each number was counted, and name the assumption you would defend least before he does |
| Conversational / Rapport | The opening biography question and the written-communication question | Low to medium. A single hiring-manager hour leaves little room for a separate rapport round, but the biography opener is near-certain | A 90-second arc built only from your own sentences |
| Pressure / Stress | Time-boxed "why you" and "how much of that was you" | Low. Nothing in the loop page or the profile signals it; included because the tabletop may be time-boxed | Hold a challenged position through two follow-ups before conceding anything real |
| Peer Evaluator | Seam-splitting between adjacent teams | Not likely. The loop page describes a single hiring-manager interview, so no bank | None needed for this round |

## 5. Question banks

Highest-ROI prep in the pack: **C1**, the in-app purchases question. It is the likeliest objection, it is asked about exactly where the material is thinnest, and it gets the deepest rehearsal below.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's hour one of a weekend event. Reward grants are failing for some players on one title and support tickets are climbing. You're the producer on call. Walk me through your first fifteen minutes." | CASE | [generic] | Think aloud, in order. Clarify before acting: who is affected and since when, what is confirmed versus suspected, whether it is spreading, whether the event can be paused and what pausing costs, who is reachable in engineering, QA and community. State the objective in one line: stop the harm to players, then fix. Assign: engineering diagnoses, community talks to players, QA verifies, you hold the timeline and the decisions. The first player message says only what is confirmed, which is the company's own second value, "we announce what is built, not what is hoped". Name what you would measure to know it is contained. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The tabletop format is documented in Sources, target 2. CASE because it scores structure over a right answer; generic because the pattern is the problem's, not this company's runbook |
| A2 | "The fix needs about four hours. The event's final-day bonus window closes in two. Community is asking what to tell players and engineering wants to keep going. What's your call?" | CASE | [generic] | Clarify first: is the four-hour figure firm or a guess, what the window is worth to players, whether it can move, what players lose either way. Then decide aloud: give the recommendation and the one fact that would change it. The company's first value, when the calendar and the players disagree the players win, is the criterion to lean on. Tell players only what is confirmed and commit to a next update time you can keep. Say what you would need engineering and design to confirm. No claim about your past | A trade-off between the plan and the players, the exact tension the first published value names. CASE with a decision at the end, so the concession wording matters as much as the call |
| A3 | "The fix is ready. QA says the release checklist isn't complete for this hotfix, and engineering wants it live now. Where do you land?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Structure it: what is incomplete, and whether any of it blocks; what shipping unchecked risks for players versus what waiting costs; who decides; a decision rule you can state aloud; what you would record for the review afterward. Where your own checklist comes in, the sentence carries only this: "I wrote the release checklist our QA team still uses." Answer slot: the JD's manage-with-QA line makes a probe on whether the checklist was ever held against a deadline likely. If it was, say what happened and what part was yours, in your own words; if not, or the call was not yours, say so plainly and answer as a plan | F4 is the evidence for the release-checklist requirement. JD content, CASE delivery: the requirement is scored as a live decision rather than a record |
| A4 | "Forty-eight hours later, retention for the event cohort is down against the last event, and the outage overlapped it. What goes in the post-event review, and what do you refuse to conclude?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Separate what the numbers show from what they cannot: which cohort, compared against what, how much of the dip the outage window covers, what else differed between the two events. Name the weakest assumption in your comparison before he does. End the review with decisions, an owner for each and what you will measure next time. Your own material carries this: "Presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-review line makes a probe on who chose the comparison likely. If you did, say how you decided; if someone else set it, or there was no comparison of that kind, say so plainly and stay with presenting the numbers | F3 and F7 are the evidence for the review and retention requirements. JD content, CASE delivery, with the weakest-assumption move a metric question needs |
| A5 | "Project Larkspur moves Tidepool Tactics and Lantern Row to a season pass and one shared events calendar from February. Sketch the first eight weeks of that calendar. What do you need to know first?" | CO | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Clarify before structuring: what the pass contains and who owns it versus events, whether the two titles' players overlap, whose cadence yields when drops collide, who sits in the single live-ops group, what the first eight weeks must prove. Then objective, segmentation, approach, metrics, risks. Challenge one premise, for example whether one calendar suits two different games. The pack knows only the announcement's one-line description, so do not describe the pass beyond it. Where a question reaches the pass's purchases, say your limit once, in these words: "I haven't worked on a game with in-app purchases." Then ask who owns that part | The one strategy-grounded item (Sources, target 3). The JD does not name the two titles, so the pack does not assume they are the role's two; the question works either way. The sourced limit is Prohibited list entry P3 |

### B. Values / Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold, with the first published value as the criterion, "when the calendar and the players disagree, the players win": pick a time with a named decision, what the players' side was, what the calendar's side cost, and who you told. Say which way you went and why. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I ran the weekly content-drop calendar for our main title for the last two years.", or how you would handle it | Published value 1 (Sources, target 1). VAL because it asks for behavior against a named value; no story is mapped because F1's sentence does not state one |
| B2 | "When have you had to correct something that was announced before it was built?" | VAL | [grounded] | Selection scaffold, with the second published value as the criterion, "we announce what is built, not what is hoped": pick a time with a named announcement, what was actually built, how the correction was received and what changed afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Keep every claim at what you did | Published value 2 (Sources, target 1), and the theme of the interviewer's talk (Section 3). VAL; no quoted sentence of yours carries this story, so it stays a scaffold |
| B3 | "Our third value is Leave the Build Greener: every release leaves the checklist better than it found it. Tell me about the release checklist you wrote." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: the checklist you wrote, which QA still uses. Those are the beats the sentence states, told in your own words. Answer slot: the value's checklist-better line makes a probe on whether the checklist changed after releases likely. If you revised it after a release, say what changed and why; if it was not revised, or the revisions were not yours, say so plainly and stay with the checklist you wrote | Published value 3 (Sources, target 1) set against the one story your sentences carry. VAL content with JD overlap on F4; likely given the interviewer's QA background (Section 3) |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "Presented the monthly retention numbers to the studio head.", or how you would handle it. Never supply an ending the sentence does not carry | A values-round stem (Section 4). VAL because it scores whether the hard truth landed; the sentence shows presenting, not what happened after |

### C. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "From February our titles move to a season pass, and I don't see in-app purchases anywhere in your background. How do you handle that?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | The highest-ROI rehearsal. Name the limit before you are pressed: "I haven't worked on a game with in-app purchases." Hold only what your sentence carries: "I ran the weekly content-drop calendar for our main title for the last two years." Then a plan, never a past: on day one you would ask who owns the pass's design and pricing, what players see now, and which numbers it is judged on, and you would want those owners in the room for any decision about what is sold. Follow-up 1, "so what would you get wrong?": name the decisions you would defer to its owners, and say you would ask rather than guess. Follow-up 2, "and if nobody owns it?": say that is a risk you would raise in week one, not fill yourself. Never say your calendar work transfers to a season pass, and never describe any purchase experience. The pack knows only the announcement's one-line description of the pass | F1 and F5 show the thinnest ground against the announced direction (Sources, target 3), and the limit is sourced in Prohibited list entry P3. JD content with CO delivery: the question scores how a stated limit meets the company's current direction |
| C2 | "You've never led a team, and this role coordinates design, art, engineering and community on every update. Where does your authority come from?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment first: "I haven't led a team." Then, as a plan: agree who decides each kind of call before an update starts, keep the calendar and the checklist where everyone can see them, and escalate the decision rather than the dispute. Answer slot: the JD's four-discipline line makes a probe on whether you did this on drops likely. If you worked with any of those disciplines, say which, what you needed from them and what you did when they disagreed, in your own words; if you did not, or they were different disciplines, say so plainly and answer as a plan | F2 is the requirement this presses; the sourced limit is Prohibited list entry P2. JD because it scores a stated requirement, with the gap named rather than bridged |
| C3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pick one you honestly believe and say it in a sentence. The pack's observation: the material is thinnest on F1 and F2 and on in-app purchases. Two of those have a sourced plain acknowledgment: "I haven't led a team." and "I haven't worked on a game with in-app purchases." If you pick anything else, say it in your own words and give the first-month plan as a plan. Never pick a weakness to look modest if it is not true | The Skeptic's standard stem. JD because it scores honest self-assessment against the listed requirements; rehearsed so that candor, not hedging, is the answer |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the weekly content-drop calendar you ran." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F1 and F6: the calendar, weekly, for the main title, for two years. Those are the beats the sentence states, told in your own words. Answer slot: the JD's two-title, live-events and live-service lines make a probe on scale, kind and who set what went in each drop likely. If any drop was an event, you ran another title's calendar, or the game was run live week to week, say what that meant; if the content or order was set by others, or none of that applies, say so plainly and stay with the one calendar you ran | F1, F5 and F6 are the evidence for the calendar requirements. JD content with EXP delivery: the same sentence is scored three ways, so it needs three rehearsed honest edges |
| D2 | "Walk me through how those monthly retention numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold to the sentence: "I presented the monthly retention numbers to the studio head." Answer slot: if you know how they were counted, say it in your own words and name the assumption you would defend least before he does; if you do not know how they were counted, say so plainly and say what you would ask. Never explain a method you cannot repeat under a second question | F7 is the evidence for the retention requirement. EXP because a prober scores whether you know your own numbers' assumptions; no figure is given, so only the counting and assumption slots apply |
| D3 | "After an event, what would you report, and which number would you trust least?" | JD | [generic] | Structure: the question the event was meant to answer, two or three numbers tied to it, the comparison baseline, and the number you would trust least with the reason (a small cohort, overlap with other changes, an outage). No claim about your past | F3 and F7 are the requirements this tests. JD content, CASE delivery, and generic because it is a pattern for the problem, not a fact about this employer |

### E. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc built only from those four sentences, in your own words: four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar you ran for the main title, the release checklist you wrote that QA still uses, the monthly retention numbers you presented to the studio head. Answer slot: why live operations and why Saltmarsh. The pack supplies no motivation; say in your own words what draws you, and nothing more than is true | F5 and F6 supply the arc. EXP because it tests whether the story you tell matches the page; casual register, still scored |
| E2 | "This role leans on clear writing. Tell me about something you wrote that other people had to act on." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4 and F8: the checklist you wrote, which QA still uses. Answer slot: the JD's written-communication line makes a probe on how you knew it was clear likely. If QA or anyone gave you feedback on it, or you changed it from how it was used, say what; if not, say so plainly and say what the checklist covers | F8 is the evidence for the writing requirement and is the thinnest row on it. JD because it scores a stated requirement; open prompt, so the instance is yours to choose |

### F. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a producer who has run live events across two titles and led a team?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." "Never led a team, and never worked on a game with in-app purchases." | Pause, restate the question, then hold and concede. Hold with your own sentences: "I ran the weekly content-drop calendar for our main title for the last two years." "I wrote the release checklist our QA team still uses." "I presented the monthly retention numbers to the studio head." Concede specifically before you are pressed: "I haven't led a team, and I haven't worked on a game with in-app purchases." Hold through two follow-ups by returning to the sentences, never by adding to them. Do not describe the rival | F1, F3 and F4 are the evidence held; the sourced limits are Prohibited list entries P2 and P3. JD because it scores fit against the listed job; the pressure stem tests composure |
| F2 | "That calendar you ran: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause, then hold what the sentence says: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: say which parts were yours to decide and which were set by others, in your own words; if the content or order was set elsewhere, or you ran it alongside others, say so plainly and stay with "I ran the calendar". Hold through two follow-ups by returning to that sentence | F1 is the evidence. EXP because it is the attribution probe; the honest branch is a limit, not a confession |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | D1, A5 |
| "coordinate design, art, engineering and community teams on each update" | C2, A1 |
| "own the post-event review and the KPIs it reports" | A4, D3 |
| "manage the release checklist with QA" | A3, B3 |
| "3+ years producing live-service games or apps" | D1, E1 |
| "experience running a content calendar" | D1, F2 |
| "comfortable with player-retention metrics" | A4, D2, D3 |
| "clear written communication" | E2 |

## 6. Values cheat sheet

A values-style round is detected: the loop page names a values conversation (Sources, target 2). Value names are from the company's values page (Sources, target 1).

| Value | Working meaning, paraphrased | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | No sentence of yours carries a story here. Selection scaffold in B1: a named decision, the players' side, the calendar's cost, who you told. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No sentence of yours carries a story here. Selection scaffold in B2: a named announcement, what was built, the correction, what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." Beats the sentence states: you wrote it, and QA still uses it. Answer slot in B3: whether it changed after releases |

## 7. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "You came to live operations through QA. What did that change about how you run an update, and what would you want a new producer to take from it?" | Ties to his own path as his public profile gives it (Sources, target 4), and turns the interview toward a working conversation about the checklist |
| 2 | "Your GDC talk argues a live team is judged by how closely its patch notes match what shipped. How do you review that here, and who owns it on a given update?" | Shows you read his published argument, and the ownership half maps to the JD's post-event review line |
| 3 | "Project Larkspur moves to a single live-ops group and one shared events calendar from February. Where would this role sit in it, and what changes for the producer's calendar?" | A strategy question the JD does not answer, built on the announcement (Sources, target 3) |
| 4 | "How does the season pass change what a post-event review reports, and who decides which numbers count?" | Asks for the part of the job you have not done, from the side of the review you are being hired to own |
| 5 | "What do strong candidates do in the Outage Hour that weaker ones don't?" | Signals preparation for the named format (Sources, target 2) and invites the interviewer to say what he scores |
| 6 | "What would tell you, ninety days in, that I was ahead or behind?" | Turns the gap rows into a shared definition of success, not a verdict |

## 8. Prohibited claims

The pack will not coach these. Entries P2 and P3 rest on a negative you stated; the others are stretched wordings of sentences you did say. Built before the banks and held against every cell.

| # | Not coached | Basis | Honest form |
|---|---|---|---|
| P1 | Planned and ran live events for two titles | Inflated form of F1 | F1's sentence at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The limit is the pack's observation: the material says one title's weekly drops, not events and not two titles. C1 and D1's slots stay inside that calendar |
| P2 | Led a team, or managed the design, art, engineering and community teams | Negative you stated: "Never led a team, and never worked on a game with in-app purchases." — your message | The plain acknowledgment: "I haven't led a team." C2 gives the plan form |
| P3 | Has worked on a game with in-app purchases | Negative you stated: "Never led a team, and never worked on a game with in-app purchases." — your message | The plain acknowledgment: "I haven't worked on a game with in-app purchases." C1 gives the plan form |
| P4 | Owned the post-event review and the KPIs it reports | Inflated form of F3 | F3's sentence at its own scope: "Presented the monthly retention numbers to the studio head." The limit is the pack's observation: the material says presenting numbers, not owning a review or its KPIs |
| P5 | Managed the release checklist with QA | Inflated form of F4 | F4's sentence at its own scope: "Wrote the release checklist our QA team still uses." The limit is the pack's observation: the material says wrote, not managed |

## 9. Sources

Provided documents: the job description text as supplied, and your background message. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

Searches sent, by query:

- `Saltmarsh Games values` returned https://saltmarshgames.com/values
- `Saltmarsh Games interview process live operations producer` returned https://saltmarshgames.com/careers/interviewing
- `Saltmarsh Games strategy news mobile` returned https://saltmarshgames.com/news/project-larkspur (read as a search-result summary; the page was not fetched)
- `Tobias Wrenfield Saltmarsh Games` returned https://talks.gdconf.example/2026/patch-notes-are-a-promise (read as a search-result summary; the page was not fetched)

Fetches sent: https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing, both returned.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet and B1 to B3: three values by official name, with the company's own definitions |
| 2. `Saltmarsh Games interview process live operations producer` | yes | The loop: one 60-minute interview, a tabletop then a values conversation, no take-home. Persona weights, section choices (no graded deliverable) and the A bank follow |
| 3. `Saltmarsh Games strategy` / recent news | yes | Project Larkspur, September 2026: A5, C1 and reverse questions 3, 4. Summary only, so the pack describes nothing beyond it |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Interviewer read, B2, B3 and reverse questions 1, 2. Summary only |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 10. Upgrade menu

- Confirmation that Tobias is your hiring manager → persona weights confirmed or reweighted, and the interviewer read adjusted if he is not
- Anything your recruiter says about the Outage Hour, such as the kind of outage, who plays which role, whether a runbook is provided → the A bank rewritten against the real scenario
- Your own answers to the answer slots in F1, F2, F3, F5 and F8 → those rows quote what you say and the slots in A3, A4, C2, D1 and E2 become story maps
- The release checklist itself, with anything confidential removed, or a post-event write-up you authored → F4 and F8 rise from medium and low to high, and B3 and E2 gain beats that are checkable
- Any retention figure you presented → a defend-the-number question and its slots
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes → a grounding brief on Project Larkspur, the interviewer's talk read in full, and loop reports for this role
- A `tuesday-dossier.md`, if you have one → verified evidence, a pre-ranked objection and prohibited claims carried in; never required
