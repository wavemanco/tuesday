# Interview prep pack: Product Operations Manager, Stripe

- **Role:** Product Operations Manager, Stripe
- **Round:** final round; the interviewer's name and relationship to you are not known, and neither is whether the final is one session or several
- **Built on:** your note naming the company, the role and the round, and nothing else. No JD, no CV, no interviewer profile, and no research (see Sources), so every requirement and question below is `[generic]` and the persona weights are flat

## How to use this pack

Personas are how a question is asked; types are what it scores. The guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your own account of your work survives follow-up, including what was actually you |
| JD | The role's responsibilities and where you would be weakest |
| CO | How much you know about the company and can think at its altitude |
| CASE | Structure and reasoning on a live problem |

Question IDs run by persona and skip the letter F, which the fit snapshot uses for its rows.

## Fit snapshot

No background was supplied, so this is the worksheet variant: each evidence cell is empty, and the bridge column says what strong evidence would look like and gives a way to choose a story. The requirements are role-family prose, not quotes, because no JD was supplied or fetched.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run a recurring operating rhythm across product teams, such as planning, reviews or launch readiness — role family | none given | none | [generic] | discovery | Strong evidence is one of your own sentences saying what you ran, how often and for whom. Selection scaffold: pick one rhythm you ran, with a named audience, a recurring slot and a decision it fed; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would set one up |
| F2 | Define metrics for product programs and report them to leadership — role family | none given | none | [generic] | discovery | Strong evidence is a sentence of yours naming a metric and who read it. Selection scaffold: pick one metric you reported, with how it was counted and what moved it; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would choose one |
| F3 | Drive decisions across teams that do not report to you — role family | none given | none | [generic] | discovery | Strong evidence is a sentence of yours naming the teams, the decision and your part in it. Selection scaffold: pick a time a decision needed several teams and no one was your report; it needs a named disagreement and a stated outcome; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would proceed |
| F4 | Diagnose a broken process or data problem and change how teams work — role family | none given | none | [generic] | discovery | Strong evidence is a sentence of yours saying what was broken and what changed afterwards. Selection scaffold: pick one process you changed, with the symptom you saw first and how you knew it worked; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would diagnose one |
| F5 | Communicate concisely with senior stakeholders in writing and live — role family | none given | none | [generic] | discovery | Strong evidence is a sentence of yours naming the audience and the format. Selection scaffold: pick one update you gave to someone senior, with the decision it needed; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would structure one |
| F6 | The location and in-office schedule the role requires — role family | none given | none | [generic] | hard_gate | Your material does not establish whether this term is met. Wording cannot solve it; it is surfaced here and rehearsed nowhere |
| F7 | Authorization to work in the country where the role is based — role family | none given | none | [generic] | hard_gate | Your material does not establish whether this term is met. Wording cannot solve it; it is surfaced here and rehearsed nowhere |

## Persona table

No loop source establishes how this final round is run and no interviewer information exists, so the archetype fallback is Generic: flat weights, and because a final can be several back-to-back sessions, all seven personas are plausible. Recalibrate if you learn who you are meeting.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems set in the role: plan this, diagnose that | Equal; a final round for an operations role plausibly includes one, but nothing in hand says so | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of weak spots and of why this move, why now | Equal; every candidate meets this somewhere | Rehearse the most predictable objection until it is boring; name your own weak spot before they do |
| Values / Behavioral | Scenario probes, expects specific stories | Equal; no loop source documents a values round, so this is not assumed | Use "we" for context and "I" for contribution; pick stories where the hard truth actually landed, or say you have none |
| Peer Evaluator | Seam-splitting with adjacent teams, credit-sharing | Equal; likely only if a peer is in the loop, which is unknown | Offer what you bring their team; propose seam principles rather than pretending to know the seam |
| Data-Driven Prober | Walks any figure down to its counting method | Equal; operations roles report numbers | Know what you can and cannot say about how each number was counted; name the weakest assumption first |
| Pressure | Interrupts, time-boxes, tests composure | Equal; common in final rounds but not established here | Pause, restate the question, hold a position through two follow-ups before conceding anything real |
| Conversational | Friendly, unstructured, still scored | Equal; the casual opener is where unrehearsed candidates ramble | A 90-second arc for the biography question; treat casual questions as scored |

## Question banks

**Highest-ROI prep: G2**, the attribution question under pressure. In an operations role that works through other teams, "how much of it was actually you" is the question most likely to arrive in some form. This pick is inferred from the role family, not from your background; it should be replaced once a CV shows where the real objection sits.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch-readiness review keeps slipping because three teams report status in three different ways. What do you ask first, and what do you change first?" | CASE | [generic] | Clarify before structuring: what decision the review feeds, who reads it, what slipping means in practice. Then objective, a way to segment the problem, one change you would test first, how you would know it worked, and what could go wrong. Challenge one premise, such as whether the reporting formats are the real problem. The question needs no claim about your past, so the guidance makes none | Tests F1 and F4 as a live problem; CASE because it scores structure, not a remembered story |
| A2 | "Product teams say weekly planning costs a lot of time and produces little. You now own it. What do you do in your first thirty days?" | CASE | [generic] | Start with listening and measurement before redesign: who attends and why, what each output is used for, what would be lost if it stopped. Propose a small change with a stated test and a way to read the result. Say aloud which assumption you are least sure of. No claim about your past is needed | F1 and F4 again from the owner's seat; CASE because the answer is a plan and its reasoning |
| A3 | "How would you decide which metrics a product program should report to leadership?" | CASE | [generic] | Begin with the decision each metric serves and who acts on it, then the few measures that change that decision, then how each is counted and what would make it misleading. Say which one you would drop first. No claim about your past is needed | F2 as a design problem; CASE with JD content, since it scores reasoning about the stated responsibility |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Choose the part you honestly judge weakest, name it in one sentence, and give a concrete first-month plan for it. If no weakness comes to mind, say so plainly, then name what you would most want to learn first | Predictable for any candidate; F1 to F5 are the candidate pool for the answer. JD because it scores the role's requirements |
| B2 | "Why product operations, and why now?" | EXP | [generic] | Selection criteria: a specific decision or experience in your own history that moved you toward this work, said in two or three sentences, with the present moment explained by something real. If no single moment comes to mind, say so plainly, then give the nearest thing your material does carry | Motivation consistency is what a Skeptic scores; EXP because the answer must survive cross-examination about your own path |
| B3 | "Operations roles can drift into coordination with no ownership. How would you make sure you own outcomes here?" | JD | [generic] | Answer about the future, not the past: how you would agree what you own, what you would measure, and how you would handle a result that depends on teams you do not manage. Name one limit of your own authority and how you would work within it | F3 is the requirement behind it; JD because it probes the role's design, not your history |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: a named stake, a moment you did not soften it, and an intact relationship afterwards. Choose a story where the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5 sits behind it; VAL because it scores behavior under pressure, not skill |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: the metric and the customer both named, what it cost, who agreed and who did not. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would weigh the two | A standard values probe; no published Stripe value was read, so this is a generic pattern, not an alignment claim |
| C3 | "Your leadership asks you to report a program as green, and the data says amber. What do you do?" | VAL | [generic] | A live problem, so no claim about your past: what you would check first, how you would put the data in front of the person asking, what you would and would not sign your name to, and what you would record. Say what you would do if they still insisted | F2 and F5 under strain; VAL with CASE delivery, since it scores judgment through a hypothetical |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know this team's seam: who decides, who prepares, who is told. For disagreement, say how you would surface it early and when you would escalate. Offer what you would bring their team | F3's requirement in collegial form; JD because it scores partnership fit with the role |
| D2 | "When work spans teams, how do you handle credit?" | EXP | [generic] | Selection criteria: one piece of cross-team work where you can say plainly which part was yours and which was another team's. If no such work comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Credit-sharing is the peer's usual probe of F3; EXP because it tests honest attribution |
| D3 | "What would you need from me in your first month, and what could you do that would help my team?" | JD | [generic] | Answer both halves: two specific things you would ask for, then something that reduces their load. Keep the second half as long as the first | The reciprocity question; JD because it scores whether the hire adds to or removes from a peer's work |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick a metric you have owned or reported and walk me through how it was counted." | EXP | [generic] | Choose one you can explain end to end. Say in your own words how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you cannot say how a figure was counted, say so plainly. If you have no such metric, say so plainly, then give the nearest thing your material does carry | F2 is the evidence row; EXP because the Prober scores attribution and method |
| E2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name it before being pushed, in one sentence, then say how you would test it. "I do not know how that part was counted" is an honest answer. No assumption is supplied here, because none of yours is known | The follow-up that turns a gotcha into credibility; EXP, tied to E1 |
| E3 | "A weekly metric moves twenty percent overnight. Diagnose it." | CASE | [generic] | Clarify first: the definition, the data source, recent changes to either, whether the move is real. Then segment, check the cheapest explanations before the exotic ones, and say what you would tell leadership before you know. No claim about your past is needed | F2 and F4 as a live problem; CASE because it scores process |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, then give two reasons you can back, each tied to the role's requirements and to something you can say you did. Hold the position through two follow-ups; concede specifically what you do not know about the internal context | Composure under a time-box; JD because the answer must map to the stated role |
| G2 | "Take the result you just described in E1. How much of it was actually you?" | EXP | [generic] | Name before they ask what was not yours, then say exactly what was. Hold that line through two follow-ups, concede what you cannot document, and never add to your part to restore the mood. Follow-up levels to rehearse: what you did, who else did what, what would have happened without you. If the result was shared, say so plainly | The highest-ROI prep; EXP because it tests attribution honesty |
| G3 | "Your recommendation was just overruled by a senior leader in the room. Do you push back or let it go?" | CASE | [generic] | Take a position and say why: what you would ask to understand the decision, what you would say once, and what you would do after the room. Concede the limit of your view. No claim about your past is needed | F3 and F5 under live pressure; CASE because it scores judgment now |

### H. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, the two or three turns that mattered, why this role is the next one. Keep every beat to something you did, in your own words. If a turn was not your choice, say so plainly | The casual opener is still scored; EXP because the arc will be cross-checked |
| H2 | "What have you been reading or building lately that has changed how you work?" | EXP | [generic] | One real thing, said in two sentences, with the change it made. If nothing comes to mind, say so plainly, then name what you would like to try | Rapport interviewers use it to read interest; EXP because it must be true |
| H3 | "What do you know about Stripe, and what drew you to it?" | CO | [generic] | No research ran for this pack, so nothing about Stripe is supplied. Say only what you have read in Stripe's own materials, and give your own reason for wanting this role | A CO question the pack cannot ground; the upgrade menu says what research would add |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 operating rhythm | A1, A2, B1 |
| F2 metrics and reporting | A3, C3, E1, E2, E3 |
| F3 decisions across teams | B3, D1, D2, D3, G3 |
| F4 diagnose and change process | A1, A2, E3 |
| F5 senior communication | C1, C3, G1, G3 |
| F6 location and schedule | none: a term you meet or do not, so it is asked, not rehearsed |
| F7 work authorization | none: a term you meet or do not, so it is asked, not rehearsed |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a strong first ninety days look like for this role, and how would you tell?" | Shows you think in outcomes and gives you the scoring bar |
| R2 | "Where does product operations sit relative to the product teams, and what is it not expected to own?" | Shows you are testing the ownership boundary before accepting it |
| R3 | "What is the most useful thing the last person to do this work changed?" | Invites a concrete answer in place of a job description |
| R4 | "Which recurring process do the teams most want fixed?" | Converts the interview into a first problem to think about |
| R5 | "What do you wish candidates asked about this role and rarely do?" | Gives the interviewer room to volunteer the real concern |
| R6 | "If your team sat beside mine, what could a new person do in the first month that would help you?" | The reciprocity question, kept in case the interviewer is a peer |

## Prohibited claims

None are listed. The pack holds no sentence of yours, so it has no wording to inflate and no negative you stated. When you supply a CV or answers, this section is rebuilt against them before any bank is rewritten.

## Sources

Provided documents: none. The only inputs were your message naming Stripe, Product Operations Manager and the final round.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Query | Result |
|---|---|
| Stripe operating principles values | refused |
| Stripe interview process Product Operations Manager final round | refused |
| Stripe strategy news 2026 | refused |
| Stripe Product Operations Manager job description responsibilities qualifications | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Every call was refused. It would have moved a values cheat sheet and the VAL bank |
| 2. Stripe interview process, product operations | unavailable | Every call was refused. It would have moved the persona weights and whether a values round is detected |
| 3. Stripe strategy and recent news | unavailable | Every call was refused. It would have moved the CO question and a grounded CASE question |
| 4. Interviewer name | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Every call was refused. It would have turned the F1 to F5 role-family requirements into quoted, `[inferred]` rows |

## Upgrade menu

- Your CV, or a few lines on your recent work → the empty evidence cells in F1 to F5 become your own quoted sentences, and the selection scaffolds become story maps
- The JD text → F1 to F7 become quoted `[grounded]` rows and the JD questions follow the posting's own list
- Who you are meeting and whether the final is one session or several → persona weights replace the flat ones; if the final is several sessions, send the schedule and I will build per-session mini-packs
- The recruiter's prep email → any pre-declared presentation or case gets its own build section
- The interviewer's name → a reading of their public path and a reverse question tied to it
- Permission to run web search → Stripe's published values, loop structure, current strategy and a representative JD, which would ground H3, add CO and CASE questions, and decide whether a values round is detected; a deeper pass would add up to 6 more searches and 2 more fetches, several more minutes
- How long you have to prepare → a prioritized prep schedule
- A `tuesday-dossier.md` from an earlier session → verified evidence and a named objection to build the deepest rehearsal on
