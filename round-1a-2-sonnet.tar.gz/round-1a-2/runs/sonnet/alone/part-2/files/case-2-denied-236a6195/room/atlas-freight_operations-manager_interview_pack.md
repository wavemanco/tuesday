# Interview prep pack: Operations Manager, Atlas Freight

- **Role:** Operations Manager, Atlas Freight (the JD's words: "regional logistics, 800 employees")
- **Interviewer:** not known. Relationship assumed: hiring manager. This is an assumption, and the persona weights below move if it is wrong.
- **Built from:** the JD text and the background you wrote in your message. No search ran (see Sources), so nothing here is about Atlas Freight beyond that JD.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Where the pack cannot know what you did, the guidance is an answer slot: say it in your own words if it is true, and if it is not, say so plainly and return to the facts you do have.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem |

This pack has no VAL or CO questions. No source named a values round, and the company research could not run.

Question IDs run by persona: A Skeptic, B Case, C Prober, D Pressure, E Conversational, G Peer. Letter F is skipped so that question IDs cannot be confused with fit-snapshot rows (F1 to F7).

## Prep triage

You said the interview is next week. In order:

1. A2, A3 and A5: the distance between your current scope and this role's scope. A2 is the highest-ROI prep in the pack.
2. C1, C2 and D2: defending the 40% figure to its assumptions and to what was yours.
3. A4 and B5: Power BI said plainly, and a plan for the reporting.
4. E1: a 90-second arc for "walk me through the journey".
5. B1, B2 and B3: say your structure aloud twice each.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message, "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says a shift-manager role and a site's surge plan, not terminal operations and not four sites. The words stay at that scope: "Currently I'm a senior shift manager over 3 supervisors, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's terminal and four-site wording makes a probe on scope likely. If any of your work involved terminal operations or more than one site, say what and which part was yours, in your own words; if none did, say so plainly and stay with your shift and the surge plan |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material gives a mis-pick figure, not on-time performance and not cost per shipment, and the bridge does not stretch it. Words: "I cut mis-pick rate 40% by redesigning the pick path." The figure raises the four defend-the-number slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if on-time performance or cost per shipment was tracked or moved in your work, say what and how; if not, say so plainly and stay with mis-pick rate |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says 3 supervisors, not 12. Words: "Currently I'm a senior shift manager over 3 supervisors." Answer slot: expect a probe on how many people you have led before. Give the actual number and when, in your own words; if it is the 3 you have now, say so plainly. How you would run a larger team is said as a plan, never as a past |
| F4 | "build reporting in Excel/Power BI" — JD (the Excel half) | "solid Excel" — your message | low | [inferred] | discovery | Your material says solid Excel and is silent on reporting, so the words are an answer slot. Words that stand: "I'm solid in Excel." Answer slot: if you have built reports in Excel, say what they showed and who used them, in your own words; if you have not, say so plainly and stay with "solid Excel" |
| F5 | "build reporting in Excel/Power BI" — JD (the Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used Power BI." Then how you would get to working level, said as a plan and never as a past. Never a claim to a course, trial or dashboard you have not told me about, and nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message, "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | A years-of-experience requirement is a risk to rehearse, not a gate. Your material gives seven years in the field and a current leadership role, and does not show how many of those years were spent leading people, so the words are an answer slot. Answer slot: give your actual count of years leading people, and the roles, in your own words; if the count is under what the posting asks, say so plainly and stay with what you led |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a self-stated line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: "I'm green belt certified." Holding the certificate itself would raise this row to high |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet, persistent probing of scope, years led and tools | High. [generic] hiring-manager prior, and the snapshot's widest distances (F1, F3, F5, F6) are where a Skeptic aims | Rehearse A2 until it is boring: hold only the F1 and F3 quotes, concede the scale in the quote's own numbers, give a plan for the rest |
| Case / Strategist (B) | Live problems from the role: diagnose on-time performance, a cost increase, a surge | High. [generic] hiring-manager prior; the JD's metrics (F2) and reporting line (F4, F5) are natural case material | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully per case |
| Data-Driven Prober (C) | Line-by-line on the 40% figure and on what was tracked | Medium. [generic] the prior is for a peer, raised because F2's headline number is the item a prober tests | Know what you can and cannot say about how the figure was counted; say plainly when you do not know; name your weakest assumption first |
| Pressure (D) | Time-boxed, devil's advocate on scale and attribution | Low to medium. [generic] hiring-manager rounds carry a light pressure tilt | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real |
| Conversational (E) | A friendly opener and a casual question on the Lean plus | Low. [generic] it appears as the warm-up or close, and is still scored | A 90-second arc built only from quotes; treat the casual Lean question as scored |
| Peer Evaluator (G) | Where your site ends and the next begins; credit across teams | Low. [generic] it applies only if a peer joins the loop | Reciprocity framing; offer seam principles rather than claiming to know the seam |

No loop source established this company's rounds, so the loop archetype is Generic (screen, hiring manager, panel) and no values-style round is detected. The weights rest on the hiring-manager prior, which you can correct.

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI", "currently a senior shift manager over 3 supervisors" | Choose one and name it plainly. Your material carries two honest choices: "I haven't used Power BI", or the scale of the team: "Currently I'm a senior shift manager over 3 supervisors." Then say how you would close it, as a plan and never as a past, in your own words, with no course, tool or date you have not told me about. Calibrated candor beats bluffing a skill the interviewer may own | F5 and F3 are the rows where this question lands; JD because it scores the stated requirements, and an open prompt because it names no event |
| A2 | "You're a senior shift manager over 3 supervisors today. This role leads 12 supervisors and owns operations across four sites. What makes you ready for that step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors", "ran the site's peak-season surge plan two years running" | The highest-ROI rehearsal in this pack, and the hold is only what the quotes carry: "Currently I'm a senior shift manager over 3 supervisors, and I ran the site's peak-season surge plan two years running." Describe, in your own words, how you lead the supervisors you have now. Answer slot: expect a follow-up on how many people you have led before. Give the actual number and when; if it is the 3 you have now, say so plainly, then give how you would run a larger team as a plan. Hold through two follow-ups by returning to the quotes, never by adding to them; concede the scale in the quote's own number: "The team I lead today is 3 supervisors." | F3 and F1 are where the role's scale presses hardest, so this objection arrives in some form; JD because it scores two stated requirements together |
| A3 | "The role requires five-plus years of operations leadership. How many of your seven years in warehouse and distribution were spent leading people?" | JD | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors" | Keep two facts apart: "I have 7 years in warehouse and distribution ops" is the field, and "I'm currently a senior shift manager over 3 supervisors" is the leadership the quotes carry. Answer slot: give your actual count of years leading people, and the roles, in your own words; if the count is under what the posting asks, say so plainly and stay with what you led | F6 is the requirement the JD marks as required, and the quote gives years in the field, not years leading; JD because it scores a stated requirement |
| A4 | "The role builds reporting in Excel and Power BI. Where are you with Power BI?" | JD | [grounded] "never used Power BI", "solid Excel" | Say it plainly: "I haven't used Power BI. I'm solid in Excel." Then how you would get to working level, said as a plan in your own words and never as a past. Never claim a course, trial or dashboard; answer slot for the Excel half: if you have built reports in Excel, say what they showed and who used them; if not, say so plainly | F5 is a stated negative and F4 is silence on reporting; JD because it scores the tool requirement directly |
| A5 | "Your background is warehouse and distribution. This role is terminal operations across four sites. What changes for you?" | JD | [grounded] "7 years in warehouse and distribution ops" | Start from the quote: "I have 7 years in warehouse and distribution ops." Answer slot: if any of your work involved terminal operations or more than one site, say what and which part was yours; if none did, say so plainly. Then say what you would learn first, as a plan, in your own words | F1 is the row where this requirement presses; JD because it scores the stated scope, and the premise is carried by the quote and the JD |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of our four sites has dropped ten points in two weeks. What do you need to know first, and how do you structure the diagnosis?" | CASE | [generic] | Clarify before structuring: when it started, which shifts and lanes, what changed. Then objective, segmentation, approach, metrics, risks, thinking aloud. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's on-time performance line (F2's requirement); `[generic]` because it is a pattern for the problem, not a fact about this employer |
| B2 | "Cost per shipment is up six percent over a quarter and volume is flat. How do you find out why?" | CASE | [generic] | Define the measure first: what is counted in cost, and per what. Then split by site and by cost component, find the largest variance, test hypotheses, separate quick fixes from structural ones. No claim about your past | A live problem from the JD's cost-per-shipment line (F2's requirement); CASE because it scores structure and not recall |
| B3 | "Peak volume is forecast well above normal at all four sites at once. How do you plan for it?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Tell the beats the quote states, in your own words: you ran the site's surge plan, two years running. Then structure the four-site version as a plan: what you would ask first, what you would decide centrally and what by site, how you would know it is working. The guidance gives the plan no past | F1 is the row this draws on; CASE with an EXP edge because the quote is the only past it may touch |
| B4 | "One of your supervisors keeps missing shift targets. What do you do in the first week?" | CASE | [generic] | Structure it: what you would check first, what you would ask the supervisor, what you would put in place, when you would escalate. No claim about your past | A live problem from the JD's supervisor-leadership line (F3's requirement); CASE because it asks for a decision, not a history |
| B5 | "You find the four sites each report on-time performance and cost per shipment in their own way. How do you get to one weekly view?" | CASE | [generic] | Agree definitions first: what counts as on time, what is in cost. Then one common template, an owner for the data, and the tool as a later decision. Say Excel is where you would start only if that is true for you; do not claim Power BI work | A live problem from the JD's reporting line (F4 and F5); CASE because it shows how you would build reporting without needing a past |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the sentence: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: how the figure was counted, what period and measure, and what it is sensitive to, in your own words; if you do not know how it was counted, say so plainly. Name the assumption you would defend least before they do | F2 holds the headline number a prober tests; EXP because it checks the figure against what you did |
| C2 | "How do you know the pick path redesign, and not something else, moved that number?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the assumption behind attributing it to the redesign that you would defend least, in your own words; if you cannot separate it from other changes, say so plainly and say what you do know | F2's attribution is where a second probe goes; EXP because it scores precise attribution |
| C3 | "The role is about driving on-time performance and cost per shipment down. What have you tracked on either?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you tracked either, say what, how, and what you did with it, in your own words; if you did not, say so plainly and stay with the mis-pick figure. Then say what you would measure first in this role, as a plan | F2's thin bridge, rehearsed so the honest answer is ready; the premise is the JD's, and the guidance does not adopt it |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who already runs a bigger operation?" | JD | [grounded] "currently a senior shift manager over 3 supervisors", "cut mis-pick rate 40% by redesigning the pick path", "ran the site's peak-season surge plan two years running" | Pause, restate, then hold on the three facts in your own words: the shift role over 3 supervisors, the 40% cut by redesigning the pick path, the surge plan run two years running. Concede specifically, from your own sentences: "I haven't used Power BI", and the team you lead today is 3 supervisors. Hold through two follow-ups by returning to the facts | F1, F2 and F3 are the evidence; JD because it scores fit to the role under time pressure |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the sentence's own attribution: you redesigned the pick path. Answer slot: which parts were yours alone and which others did, in your own words; if you do not know how much of the movement came from the redesign, say so plainly. Concede that specifically and do not fold on the core claim | F2's attribution, asked the way a Pressure interviewer asks it; EXP because it scores what was yours |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors" | A 90-second arc with only the beats the quotes carry: 7 years in warehouse and distribution ops, then currently a senior shift manager over 3 supervisors. Add one achievement in your own words. Answer slot: why you want this role; the pack has no source for your reason, so give your actual one | F6 and F3 are the arc's backbone; EXP because it is your own history, and the casual register is still scored |
| E2 | "What are you actually using Lean or Six Sigma for these days?" | JD | [grounded] "green belt certified" | Lead with "I'm green belt certified." Answer slot: if you apply it in your work now, say where and what, in your own words; if you do not, say so plainly and say what you would apply first, as a plan. Whether the pick path redesign used that method is yours to say if it did | F7 is the row; JD because the posting lists it as a plus, asked casually |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "How do you handle credit when work spans teams?" | EXP | [generic] | Pick a time work crossed shifts or teams, name who did what, say which part was yours, and use "we" for context and "I" for contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; EXP because it scores credit-sharing, and a selection scaffold because no quoted sentence carries the story |
| G2 | "I run the site next to yours and a late shipment crosses both. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Propose seam principles rather than claiming to know the seam: one agreed definition of on time, data both sides trust, who decides and by when, how you escalate. Frame what you bring the peer's team, not only what you need | A live problem set in the role; CASE because it scores reasoning about a shared boundary |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own daily terminal operations across 4 sites" | A2, A5, B3, D1 |
| "drive on-time performance and cost-per-shipment down" | B1, B2, C3 |
| "lead a team of 12 supervisors" | A2, B4, D1 |
| "build reporting in Excel/Power BI" | A4, B5 |
| "5+ years operations leadership required" | A3, E1 |
| "Lean/Six Sigma a plus" | E2 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| 1 | "How is on-time performance measured across the four sites today?" | It shows you care about the definition before the target, and it tells you the baseline you would inherit |
| 2 | "How is cost per shipment calculated here, and who owns the inputs?" | It ties to the JD's own metric and surfaces how reliable the data is |
| 3 | "How is the team of 12 supervisors organized across the four sites?" | It tests the scale you are stepping into and signals you are planning for it |
| 4 | "Where does reporting live today, and who builds it?" | It is honest about the tool gap and asks where the learning would come from |
| 5 | "What would the first 90 days need to deliver for you to call this hire a success?" | It converts the interview into an agreement on what good looks like |
| 6 | "What has been the hardest operating stretch in the past year, and what did the team change afterwards?" | It invites a real story and shows interest in how the operation behaves under strain |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team of 12 supervisors | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: the material says 3 supervisors, not 12. A2's slot stays inside the number you give |
| Owned terminal operations across four sites | Inflated form of F1 | F1's quotes at their own scope. The material says a shift role and a site's surge plan |
| Drove on-time performance or cost per shipment down | Inflated form of F2 | F2's quote at its own scope. The material says a mis-pick figure, not these measures. C3's slot asks only what you tracked |
| Built operational reporting in Excel | Inflated form of F4 | F4's quote at its own scope: "I'm solid in Excel." The material is silent on reporting. A4's slot stays inside that sentence |
| Has used Power BI | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't used Power BI." No slot |
| Has five or more years of operations leadership | Inflated form of F6 | F6's quotes at their own scope: years in the field and a current leadership role. The material does not show how many years were spent leading. A3's slot asks for your own count |

## Sources

Provided documents: the JD text as written in your message, and your background as written in your message. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | The query was refused, so no values were read; it would have fed a values cheat sheet, which this pack drops |
| 2. Atlas Freight interview process, operations manager | unavailable | The query was refused; it would have fixed the loop and persona weights, which fell back to the Generic archetype |
| 3. Atlas Freight strategy and recent news | unavailable | The query was refused; it would have fed CO questions and a strategy-grounded case |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. Representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Queries sent:

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics strategy news 2026" — refused

## Upgrade menu

- The interviewer's name and title → an interviewer read, persona weights read from their public footprint, and a reverse question tied to their path
- The round type and who you are meeting, and anything the recruiter said about focus areas or something to prepare → persona weights that stop resting on the hiring-manager assumption, and a build section for any announced deliverable
- Search permission → Atlas Freight's values, loop and strategy replace the three unavailable rows above, and CO and VAL questions become `[grounded]`. A deeper pass of up to 6 more searches and 2 more fetches, several more minutes, can be offered once that is in place
- Your answers to the slots in A2, A3, A5 and C3 → F1, F3, F6 and F2 become rows built on your own quoted words instead of slots
- A sentence on whether you have ever built a report in Excel, and what it showed → F4 moves from discovery to a row with evidence
- The green belt certificate → F7 moves from medium to high
- A before-and-after sheet for the pick path redesign → F2 moves from medium toward high, and C1 and C2 get exact beats
- Your full CV → more quotable rows for F1, F3 and F6
- A tuesday-dossier.md from an earlier evidence check, if you have one → verified claims and prohibited claims that tighten every guidance cell, though the pack stands without it
