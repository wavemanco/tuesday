# Interview prep pack: Live Operations Producer, Saltmarsh Games

- **Candidate:** Femi
- **Interviewer:** Tobias Wrenfield, Head of Live Operations
- **Round:** one 60-minute session. Built as the hiring-manager round, which is an assumption: Saltmarsh's careers page describes every loop as a recruiter call, then one 60-minute interview with the hiring manager, and your note does not say Tobias is the hiring manager.
- **Format as documented:** a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | What it scores |
|---|---|
| VAL | Whether your past behavior shows Saltmarsh's published values |
| EXP | Whether a claim about your experience survives follow-ups |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script. Say it in your own words. Wherever you see "answer slot", the pack does not know the answer and will not guess it: say what is true, or say plainly that the step was not yours or did not exist.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Words: "I ran the weekly content-drop calendar for our main title for the last two years." The pack's observation: your material says weekly content drops on one title, and the JD's line names live events and two titles. Answer slot: if the calendar carried anything beyond routine drops, say what, in your own words; if it did not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which teams you worked with on an update. Answer slot: the JD names four teams, so expect a probe on who you worked with for a drop. If you worked with any of them, say which and what you did, in your own words; if you did not, or that was not yours, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Words: "I presented the monthly retention numbers to the studio head." The pack's observation: your material says you presented the numbers, not that you ran a review or owned the KPIs. Answer slot: if you looked back at how a drop performed, say what you looked at and what part was yours; if you did not, or someone else owned the numbers, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Words: "I wrote the release checklist our QA team still uses." The pack's observation: your material says you wrote it and QA still uses it, not that you ran releases against it. Answer slot: if you worked with QA as releases went out, say how, in your own words; if QA ran the checklist without you, or there was no such step, say so plainly and stay with the checklist you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | A length-of-experience line is not a gate, but expect it to be read literally. Words: "I was an associate producer at a puzzle-game studio for four years, and for the last two I ran the weekly content-drop calendar for our main title." The pack's observation: your material does not show which of the four years were on a title with ongoing content. Answer slot: say which years were, in your own words; if it is not all four, say so plainly |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with the calendar in the quote's own terms (weekly, main title, two years), because a named cadence beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but "presented" is the quote's verb and the probe will be on how the numbers were counted. Lead with what the quote says: monthly, to the studio head. Answer slots, in your own words: how they were counted, what they are sensitive to, the assumption you would defend least, and which part was yours. "I don't know how that was counted" is an honest branch |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | Writing a checklist touches this without showing it reaches clear written communication, and the bridge should not be stretched. Answer slot: expect to be asked for something you wrote. If you have a piece you would point to, name it in your own words; if the checklist is the only one, say so plainly |
| F9 | Familiarity with in-app purchases in a mobile live game (role-family requirement, not in the JD) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [generic] | capability | You stated this absence. Words: "I haven't worked on a game with in-app purchases." Then a plan, said as a plan and never as a past: what you would learn first and how. The announcement summary the pack found describes a season-pass model for two titles from February 2027, which is why the probe is likely |
| F10 | Leading a team (role-family requirement; the JD says "coordinate", not lead) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [generic] | capability | You stated this absence. Words: "I haven't led a team." Then how you would get four disciplines moving, said as a plan. Coordination is F2's row and its answer slot, not this one |

## Reading the interviewer

Public professional footprint only, from a search result for Tobias Wrenfield (his GDC 2026 talk listing). The page itself was not fetched.

| Item | What the public footprint shows | Practical implication |
|---|---|---|
| Role and path | Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio | Release and QA vocabulary will be native to him. Expect F4 to be probed closely |
| Self-described argument | His GDC 2026 talk is titled "Patch Notes Are a Promise"; its listed argument is that a live team is judged by how often its patch notes describe what actually shipped | Keep every claim at its own scope. The prohibited list below is the same discipline he is publicly arguing for |
| Mirror: shared vocabulary | Release checklists, patch notes, what actually shipped. Your side, F4: "Wrote the release checklist our QA team still uses." | Use his words (checklist, patch notes, what shipped) only where your own sentence already carries them |
| What the pack does not do | No inference about personality or preferences | Delivery is tuned by the persona table below, not by guessing at him |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | The outage tabletop, then calendar and release problems | High. The careers page names a live-incident tabletop on a simulated outage during a live event. It is the documented first half of the format | Clarify, objective, people, decisions, record. Think aloud. Challenge one premise politely |
| Values / Behavioral (bank B) | The values conversation, keyed to three published values | High. The careers page names a values conversation, so a values-style round is detected. Saltmarsh's values page names three values | Selection scaffolds per value, with the honest branch ready where no story comes to mind |
| Skeptic (bank C) | Quiet probing of what you have said you have not done | High. Hiring-manager prior, plus two stated absences (F9, F10) | Rehearse C1 until it is boring. Plain acknowledgment, then plan |
| Data-Driven Prober (bank D) | Retention numbers and calendar decisions, taken two levels down | Medium. F7 and F3 invite it, and the interviewer's public argument is about claims matching what shipped | Know what you can and cannot say about how the numbers were counted. Say plainly when you do not know |
| Pressure (bank E) | Time-boxed challenges on attribution and on why you | Medium-low. A tabletop is time-pressured by design, but no source documents a stress style. This is the pack's inference | Pause, restate, hold through two follow-ups, concede only what the quotes do not carry |
| Conversational (bank F) | Opening arc and motivation | Medium-low. Every loop opens somewhere, and casual questions are still scored | A 90-second arc built only from your own sentences |
| Peer Evaluator | No bank | Low. The interviewer is the Head of the function, not a peer | Not rehearsed |

## Question banks

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Live-events calendar for two titles (F1) | A3, A4, D3 |
| Coordinate design, art, engineering, community (F2) | A1, C2 |
| Post-event review and KPIs (F3) | A2, B4, D2 |
| Release checklist with QA (F4) | A5, B3, E1 |
| 3+ years live-service (F5) | C4, F1 |
| Content calendar (F6) | A4, D3 |
| Player-retention metrics (F7) | D1, D2 |
| Clear written communication (F8) | A6 |
| Stated gaps (F9, F10) | C1, C2, C3, E2 |
| Published values | B1, B2, B3, B4 |

**Highest-ROI prep in this pack: C1.** The in-app-purchase absence is the likeliest objection, and the season-pass move makes it sharper.

### A. Case / Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Day two of a live event. The reward claim is failing for a share of players, and engineering says the fix needs a new build. You have one hour in the room. Go." | CASE | [generic] | Clarify aloud first: how many players, since when, whether progress is blocked or only rewards, what engineering can promise and by when. Objective: protect players first. Then people: which of design, art, engineering and community you bring in and what you ask each. Name the two decisions: keep the event running or pause it, and what players are told and when. Tell players only what is built, not what is hoped (the published value's own words). Close with what you would record afterwards. Challenge one premise politely, such as whether the hour is for diagnosis or for a decision | The careers page documents an outage tabletop during a live event, so this is the likeliest shape of the session. CASE because it scores structure on a live problem. F2's requirement is exercised here without any claim about your past |
| A2 | "The event has ended. How would you run the review, and which three numbers would you put in front of me first?" | CASE | [generic] | Start from the decision each number serves: what would you change next time because of it? Choose numbers you can say how you would count, and name the assumption you would trust least before I ask. Say what you would do if the numbers disagreed with how the event felt to players. Keep it to three and offer the next ten. No guessed figures | The JD's review-and-KPI line is a requirement (F3). CASE because it asks you to design the review, not recount one |
| A3 | "From February 2027 two of our titles share one events calendar, and the per-title event teams fold into one live-ops group. What do you do in your first thirty days?" | CASE | [inferred] | Derived from a search summary of Saltmarsh's Project Larkspur announcement; the full post was not read. Clarify: which titles, what a season-pass cadence requires, what each title's players expect. Objective: one calendar without collisions or fatigue. Segment by title audience, event type and cadence. Approach: map what exists, find clashes, agree handover rules with the single group. Metrics and risks: one slip now hits two titles. Use the announcement's own vocabulary (shared events calendar, single live-ops group, season pass). Do not correct the interviewer on anything | CO and CASE grounded in current strategy, which the coverage rules require when research succeeded. CASE because it is a live planning problem. F1's two-title requirement is why it is likely |
| A4 | "Take the weekly content-drop calendar for your main title. What would you need to know before running the same thing across two titles at once?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold only what the quote carries: "I ran the weekly content-drop calendar for our main title for the last two years." Then think aloud as questions, not as things you have done: audience overlap, shared teams, what kinds of events, how collisions are decided. Answer slot: if the calendar carried anything beyond routine drops, say what, in your own words; if it did not, say so plainly and say what would be new. Never describe a second title as familiar | F1 is where the JD's two-title and live-events wording presses past the evidence, so this question arrives in some form. JD because it scores the stated requirement, with CASE delivery |
| A5 | "It's release morning for an update. QA has one open item on the checklist and design wants to ship at noon. What happens?" | CASE | [generic] | Clarify first: how severe is the item, who owns the call. Lay out the options: ship, ship with a named risk, hold. Say who decides and what players are told if it slips. Afterwards, put what you learned back into the checklist. That is the published value "Leave the Build Greener": every release leaves the checklist better. Make no claim about past releases | F4's requirement is checked live. CASE because it asks for a decision under a deadline; the interviewer's QA background makes it likelier |
| A6 | "Write me the first two lines of the player note for an event that's slipping a day." | CASE | [generic] | Say what is true now, what players get, and when you will next update. Do not promise a fix time you do not control. Leave out hope language: Saltmarsh's value is to announce what is built, not what is hoped. Read it aloud and offer to adjust it per channel | The JD asks for clear written communication (F8) and this is the only place it is tested aloud. CASE because it is a live drafting task |

### B. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players pulled in different directions. What did you do?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Maps to "Players Before Plans". The quote carries the calendar, not a clash. Pick a time with a named stake for players, a call you made, what players saw, and what it cost the plan. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The values page names this value, and a values conversation is documented. VAL because it scores behavior against a published value; F1 is the setting only |
| B2 | "Tell me about a time you told people something would not ship as planned." | VAL | [grounded] | Maps to "Ship the Patch Not the Promise". Pick a time the news was unwelcome and the audience could check what you said afterwards: the message, who heard it, what actually shipped. "We" for context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Second published value. A scaffold because no quoted sentence carries this story |
| B3 | "Walk me through the release checklist you wrote." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Maps to "Leave the Build Greener". Beats the quote states: you wrote it, and QA still uses it. Tell it in your own words. Answer slot: the value says every release leaves the checklist better, so expect a probe on whether it changed after releases. If it did, say what changed and why; if it did not, or the changes were not yours, say so plainly and stay with the checklist as you wrote it | F4 is the only quote that carries a story for a published value. VAL for the scoring, EXP in content |
| B4 | "Tell me about a time you had to put a hard number in front of leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Nearest quote: "I presented the monthly retention numbers to the studio head." Beats: the numbers, monthly, the studio head. Answer slot: if a month's numbers were not what leadership hoped, say what you said and what happened; if none were, say so plainly and stay with presenting them. Never supply the ending | F3 and F7 hold the nearest evidence. VAL because the value is about announcing what is real; the honest branch matters because the hard truth landing is not in your material |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't worked on a game with in-app purchases, and our next year is a season-pass model. Why should I think you can run this calendar?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Hold, then concede. Open with the plain acknowledgment, once and flat: "I haven't worked on a game with in-app purchases." Then what the quote carries: "I ran the weekly content-drop calendar for our main title for the last two years." Let him draw the link; do not say the work proves it carries over. Then a plan, said as a plan: the first thing you would learn about how purchases and a season pass shape a calendar, who you would ask, how you would check you had it. Follow-up 1, "that is a promise, not an answer": return to the quote and the plan. Follow-up 2, "what would you get wrong first?": name the assumption you would trust least, in your own words. Follow-up 3, "what do you know about season passes?": say plainly what you know; if little, say little | F9 is the biggest stated gap, and the Larkspur summary makes it salient. The deepest rehearsal in the pack because it will be asked in some form. JD because it scores whether you can do the listed job despite the gap |
| C2 | "You haven't led a team. This role coordinates design, art, engineering and community on every update. How do you get four disciplines to move?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment first: "I haven't led a team." Then the approach, said as a plan: what you would agree up front with each discipline, how you would surface a disagreement early, when you would escalate. Answer slot: if you worked with any of the four on an update, say which and what you did, in your own words; if you did not, say so plainly and stay with the calendar you ran | F10 and F2. The JD says coordinate, and the question separates the stated absence from the requirement. JD because it tests the listed job |
| C3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Choose one that is true, from the rows where the material is thin: F9, F10, or F2. For the two stated absences the plain acknowledgment is in your message; for F2 it is its answer slot. Name it, say it plainly, give the ramp, stop. Calibrated candor beats bluffing | The standard Skeptic stem, and F9 to F10 are where it lands. JD because it scores honest self-assessment against the listed job |
| C4 | "You've been an associate producer for four years. What would be different about this job?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Say what the quotes carry: "I was an associate producer at a puzzle-game studio for four years, and for the last two I ran the weekly content-drop calendar for our main title." Answer slot: the JD asks for years producing live-service, so expect a probe on which years were on a title with ongoing content. Say which, in your own words; if it is not all four, say so plainly. Then what would be new, as things to learn, not things you have done | F5. EXP because it tests what the title and the years actually covered |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what the quote carries: you presented them, monthly, to the studio head. Answer slots, in your own words: how they were counted, what they are sensitive to, the assumption you would defend least, which part was yours. "I don't know how that was counted" is an honest branch. The pack supplies no method, baseline or figure | F7 is a headline metric line, so a defend-the-number question is expected. EXP because it tests attribution |
| D2 | "What did the studio head do differently after hearing those numbers?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if anything changed after you presented them, say what and what part of it was yours; if nothing did, or you do not know, say so plainly and stay with presenting them monthly. Never supply the outcome | F3 and F7. The question presupposes an outcome the quote does not carry, so the guidance is a slot whose second branch allows that there was none. EXP because it tests what the numbers led to |
| D3 | "How did you decide what went into each weekly drop?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: the JD says plan and run, so expect this probe. If you decided what went into a drop or when it shipped, say how, in your own words; if the contents or timing were set elsewhere, or there was no such decision, say so plainly and stay with the calendar you ran | F1 and F6. EXP because it tests what was actually yours; the premise is the JD's, not an adopted fact |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Pause and restate. Hold: "I wrote the release checklist our QA team still uses." Return to the quote through two follow-ups; do not add to it. Answer slot: if anyone else contributed, say so plainly and say who and what; if no one did, say that. Concede only what the quote does not carry | F4. Attribution probes exist to catch inflation, and the checklist is the line most likely to be pushed. EXP because it scores precise attribution |
| E2 | "Sixty seconds: why you over someone who has already run a monetized live title?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." "Never led a team, and never worked on a game with in-app purchases." | Time-box it. State what the quotes carry, each at its own scope: the calendar you ran, the checklist you wrote, the numbers you presented. Concede the stated absences once: "I haven't worked on a game with in-app purchases," "I haven't led a team." Do not claim the work proves fit; stop on your plan | F9 and F10 under time pressure. JD because it is the job-fit question; the pressure is in delivery |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | A 90-second arc with only these beats: four years as an associate producer at a puzzle-game studio, and for the last two, the weekly content-drop calendar for your main title. Answer slot: what drew you to live operations is yours to say, in your own words; if nothing in particular did, say that and say what draws you to this role | F5. Casual questions are still scored; EXP because the arc must match the CV claims |
| F2 | "Why Saltmarsh, and why now?" | CO | [grounded] | Answer slot: the reason is yours. Then one thing you have actually read, such as the values page or the careers page. Do not recite all three values and do not flatter. If you cite the shared-calendar announcement, read the full post first; this pack saw only a search summary | The standard motivation probe, scored for homework. CO because it tests whether you know Saltmarsh |

## Values cheat sheet

Source: saltmarshgames.com/values, fetched.

| Value | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Setting only, F1: "I ran the weekly content-drop calendar for our main title for the last two years." The quote carries no clash. Selection scaffold: a named stake for players, the call you made, what players saw, what it cost the plan. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No sentence carries this. Selection scaffold: a time you told people something would not ship as planned and they could check afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." The quote carries the checklist and QA's use, not changes after releases; see B3's answer slot |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You've argued that patch notes are a promise, and you came up through QA. What does that mean for what you want the producer to own at release?" | Ties to his own path and talk, and invites his definition of the role's release duties | [grounded] |
| R2 | "With per-title event teams folding into one live-ops group from February 2027, what does the producer's first quarter look like?" | Shows you read the announcement and asks about the work you would actually do | [inferred] |
| R3 | "Which of the post-event review's KPIs matter most at six months?" | Shows you think about what you would be measured on | [grounded] |
| R4 | "Which of design, art, engineering and community is hardest to align on an update today?" | Treats coordination as the real job rather than a box to tick | [grounded] |
| R5 | "When has holding a calendar date cost the team, and when has holding back cost it more?" | Tests the "Players Before Plans" value in practice and invites a real example | [grounded] |
| R6 | "What does someone coming from a title without in-app purchases most need to learn here?" | Names the gap before he does and asks for the onboarding path, without apologizing | [generic] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says weekly content drops on one title |
| Owned post-event reviews and the KPIs they report | Inflated form of F3 | F3's quote at its own scope: you presented the numbers. A slot asks only what you looked at and what part was yours |
| Managed releases with QA | Inflated form of F4 | F4's quote at its own scope: you wrote the checklist and QA still uses it |
| Four years producing live-service games | Inflated form of F5 | F5's quotes at their own scope. The slot asks only which years were on a title with ongoing content |
| Has worked on a game with in-app purchases | Negative you stated, F9 | Your plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Has led a team | Negative you stated, F10 | Your plain acknowledgment: "I haven't led a team." No slot |

## Sources

Provided: the JD text and your background, both in your message.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Fetched the values page. Values cheat sheet and bank B: three values by name |
| 2. Saltmarsh Games interview process, live operations | yes | Fetched the careers page. One 60-minute session with the hiring manager, a tabletop then a values conversation, no take-home. Persona weights, bank A and bank B |
| 3. Saltmarsh Games strategy and recent news | yes | Summary of the Project Larkspur announcement (September 2026). A3 and reverse question R2. The page was not fetched, so these rows are `[inferred]` |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Talk listing only; the page was not fetched. Interviewer read and reverse question R1 |
| 5. Representative live operations producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Searches sent, with what came back:

- "Saltmarsh Games values" returned saltmarshgames.com/values
- "Saltmarsh Games interview process live operations producer" returned saltmarshgames.com/careers/interviewing
- "Saltmarsh Games mobile studio news strategy" returned saltmarshgames.com/news/project-larkspur
- "Tobias Wrenfield Saltmarsh Games" returned talks.gdconf.example/2026/patch-notes-are-a-promise

Fetches: saltmarshgames.com/values, saltmarshgames.com/careers/interviewing.

## Upgrade menu

- The recruiter's prep note, or one email asking what the tabletop covers → the assumed format becomes a documented one, and personas can be reweighted
- Your own answers to the slots in F1 to F5 and F8 (which drops carried more than routine content, who you worked with on an update, how a drop was looked back on, which years were on a title with ongoing content, anything you wrote beyond the checklist) → those rows move toward grounded evidence in your own words
- A sample week of your content calendar, the release checklist, or one retention report page → confidence on F1, F3, F4, F6 and F7 can move from medium toward high
- A deeper research pass (asked in the message) → a grounding brief on Saltmarsh's strategy and recent org changes, Tobias's talks and writing, and role-family loop reports
- The full text of the Project Larkspur announcement → A3, R2 and F9's salience note move from inferred to grounded
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence and a named worst-objection would sharpen the banks; the pack does not need one
