# Interview prep pack: Live Operations Producer, Saltmarsh Games

- **Role:** Live Operations Producer, Saltmarsh Games (mobile game studio)
- **Candidate:** Femi
- **Interviewer:** Tobias Wrenfield, Head of Live Operations
- **Relationship and round:** assumed to be the hiring manager, in the Outage Hour: one 60-minute interview, a live-incident tabletop on a simulated outage during a live event, then a values conversation, with no take-home (Saltmarsh's interviewing page, named in Sources). Neither the relationship nor the format is confirmed by you; the persona weights and the banks rest on both.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Every question carries both, plus a provenance label and the sentence of yours its guidance rests on.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Saltmarsh's published values, not general virtue |
| EXP | Whether a line of your background survives scrutiny and what was actually yours |
| JD | Whether you can do a listed responsibility, including where the material is thin |
| CO | Whether you know Saltmarsh's current strategy well enough to think at its level |
| CASE | Structure and reasoning on a live problem from the role |

- Guidance is scaffolding, not a script. Say it in your own words.
- Wherever a question could reach past what your material says, the guidance is an answer slot: an instruction for the interview, with one branch for "I did this" and one for "that was not mine, or did not happen". Both branches are fine answers.
- Provenance labels: grounded means traceable to a document you gave me or a source in the Sources section; inferred means derived from one, with the derivation named; generic means a pattern for the role, with no claim about Saltmarsh or about you.
- The highest-ROI rehearsal in this pack is C1. Do it aloud, more than once.

## Fit snapshot

Your sentences sit in the evidence column word for word. Everything this pack says about your past comes from those sentences and from nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one main title, not a live-events calendar and not two titles, and the words stay at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's live-events line makes a probe on events likely. If any of your drops were time-limited events, say which kind and what part of running them was yours, in your own words; if all were regular content drops, or none of that was yours, say so plainly and stay with the weekly calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | The calendar sentence touches this requirement without showing which teams were involved or how. Answer slot: the JD names four teams, so expect a probe on which you worked with. If you worked with any of them on a drop, say which and what your part was, in your own words; if some were not part of your drops, or the coordinating was not yours, say so plainly and stay with the calendar |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [inferred] | discovery | Presenting monthly retention numbers touches the KPI half of this line; the material says nothing about a post-event review or about who produced the numbers. Answer slot: the JD says own the review and its KPIs, so expect a probe on both. If you produced or chose any of the numbers, or ran a review of a release or an event, say what and how, in your own words; if you presented numbers someone else produced, or no review like that existed, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and that QA still uses it, not who runs it at each release; the words stay there: "I wrote the release checklist our QA team still uses." Answer slot: the JD's manage-with-QA line makes a probe on running it likely. If you ran releases against the checklist with QA, say how, in your own words; if QA ran it without you, or if the writing was shared, say so plainly and stay with what you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The first sentence gives four years as an associate producer and the second two years on a weekly calendar; the material does not say how many of the four years were on a live title, and the JD's 3+ years makes a probe on the count likely. Answer slot: say how many of the four years were on a title that received live updates, from your own records; if the calendar years are the whole of it, say so plainly and stay with the four years as an associate producer and the two on the calendar |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap on the words: the sentence already says monthly, retention numbers and the studio head. Lead with it in those terms: "I presented the monthly retention numbers to the studio head." It is a line with nothing inspected behind it, so expect a probe on what was in the numbers and how they were counted (D1) |
| F7 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [inferred] | presentation | The sentence reaches this requirement in other terms: a written document a team still uses. Say it as it stands: "I wrote the release checklist our QA team still uses." It claims nothing about how clear the checklist is, and the words should not either |
| F8 | Leading a team: not in the JD, which says coordinate (F2); a role-family expectation written from no source | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I haven't led a team." Then how you would work with the four disciplines in your first weeks, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F9 | Experience with in-app purchases: not in the JD; a role-family expectation for mobile titles, written from no source | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then what you would learn first, said as a plan and never as a past. The retention sentence in F6 stays at its own scope and does not stand in for purchase work |

## Reading the interviewer

Public professional footprint only. These rows come from a search result's snippet; the talk page itself was not fetched.

| Fact | Source | Provenance | What it means for you |
|---|---|---|---|
| Head of Live Operations at Saltmarsh Games | talks.gdconf.example/2026/patch-notes-are-a-promise (search result) | [grounded] | The person running your Outage Hour leads the function this role sits in; the JD's calendar and release-checklist lines are his territory |
| Previously a QA lead at a console studio | same | [grounded] | Expect depth on QA and on your checklist (D3, E2). Common vocabulary: QA and checklists, which F4's sentence carries: "Wrote the release checklist our QA team still uses." That is shared vocabulary, not a shared career jump, and should not be offered as one |
| Gave a GDC 2026 talk, "Patch Notes Are a Promise": a live team is judged by how often its patch notes describe what actually shipped | same | [grounded] | His stated argument and Saltmarsh's second published value both turn on announcing only what is built, so A2 and B2 are where an overpromise would cost most. This reading is the pack's own |

## Persona table

The weights come from three passes: the hiring-manager prior (Case/Strategist and Skeptic), the interviewer's public signals, and the loop. The loop is established by Saltmarsh's interviewing page, which describes one 60-minute session of tabletop then values. If your session is not that, say so and I will reweight.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (bank A, 5 questions) | The tabletop: a simulated outage during a live event | High. The interviewing page names the tabletop as the first part of the hour | Clarify, then objective, segments, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Values/Behavioral (bank B, 4 questions) | The second part: a values conversation against Saltmarsh's three published values | High. The interviewing page names it, and the values page names the three values, each given a question here | Where your material carries a story, tell exactly its beats; where it does not, pick an instance by the criteria given and take the honest branch if none comes |
| Skeptic (bank C, 4 questions) | Quiet probing of the two gaps you stated and the live-service count | Medium. Hiring-manager prior plus the gaps you stated; the interviewing page does not mention gap probing | Rehearse C1 until it is boring: plain acknowledgment, then only what your sentences carry, then a plan said as a plan |
| Data-Driven Prober (bank D, 3 questions) | Line-by-line questions on the retention numbers and the checklist | Medium. Low as a hiring-manager prior; raised by his QA background and a talk about what actually shipped, which is the pack's reading | Say plainly what you do not know about how a figure was counted; name the assumption you would defend least before he does |
| Pressure (bank E, 2 questions) | Time-boxed or interrupting follow-ups inside the tabletop | Low. The page says the outage is simulated and does not say it is time-boxed or adversarial; the bank is insurance | Pause, restate, hold through two follow-ups, concede one thing specifically |
| Conversational (bank F, 2 questions) | The opening of a 60-minute session, and a casual question about live events | Medium. A session this long usually opens with the biography; the page does not describe an opener | Rehearse the biography arc at F1; treat casual questions about live events as scored |
| Peer Evaluator | Not built | The loop source names one session with the hiring manager and no peer session | Not applicable |

## Question banks

### Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| Plan and run the live-events calendar for two titles | A3, A5, C3, D2, F2 |
| Coordinate design, art, engineering and community on each update | A1, C2 |
| Own the post-event review and the KPIs it reports | A4, D1, D2 |
| Manage the release checklist with QA | A3, B3, D3, E2 |
| 3+ years producing live-service games or apps | C3, F1 |
| Comfortable with player-retention metrics | A4, D1, D2 |
| Clear written communication | A2, B3 |

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "An event is live and a reward is paying out the wrong amount, and players are already posting about it. What do you need to know first, and what do you do in the first hour?" | CASE | [generic] | Clarify before you structure: how many players are affected, whether the payout can be stopped without taking the event down, and what has already been said publicly. State the objective aloud, then the order of your calls and whom you pull in; the JD names design, art, engineering and community. Decide what you protect first when the schedule and the players pull apart, and say why. Challenge one premise respectfully, such as whether pausing the event is allowed. Think aloud; structure is scored over the answer | The interviewing page names a live-incident tabletop during a live event as the hour's first part, so this is the likeliest shape of the opening. CASE because it presupposes nothing about your past; the four teams in F2's requirement are why the convening step is in the guidance |
| A2 | "Community needs a statement in fifteen minutes and engineering does not know the cause yet. What does it say?" | CASE | [grounded] | Write it as you would send it: what is confirmed, what is not yet known, what players can do now, and when the next update comes. The second published value, Ship the Patch Not the Promise, says Saltmarsh announces what is built, not what is hoped, so leave out any fix time you cannot stand behind. Say the draft aloud in full sentences; written clarity is scored here too | The values page's second value and the interviewer's public talk both centre on announcements matching what shipped (see Reading the interviewer). CASE because it is a live problem; it also scores F7's requirement, clear written communication |
| A3 | "The calendar says the next event goes live tonight. Last night's fix is not verified, design wants to go, and QA has not signed off. What do you do?" | CASE | [grounded] | Name the decision and its owner first. Lay out the options: hold, narrow the launch, or ship with a known issue disclosed. Say what the checklist should settle and what you would ask QA, and what players are told. The first published value says that when the calendar and the players disagree, the players win; show you know which way that points and what you would trade for it. Close with what you record so the next release is better, which is the third value. Say plainly what you would not decide alone | A calendar-versus-players call is where the JD's calendar and release-checklist lines (F1, F4) meet the first value. CASE because it asks for a decision under conflict and presupposes nothing about your past |
| A4 | "The event has ended. What does your post-event review cover, and what do you report on Monday?" | JD | [grounded] | Start from the event's stated goal and ask what it was meant to change. Choose the few numbers that answer that, the JD names retention, and say which one you would trust least and why. Say what you would not conclude from a single event, and end with what changes in the next event's plan. This is a plan, not a past; do not describe a review you ran unless you did | The JD's own-the-review line is F3's requirement and the likeliest place a hiring manager tests it live. JD because it scores a stated responsibility, with CASE delivery |
| A5 | "From February 2027 two of our titles run on one events calendar under a single live-ops group. What is the first thing you would want to know or fix?" | CO | [grounded] | Know the published fact: the September 2026 Project Larkspur announcement moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027 and replaces per-title event teams with a single live-ops group. Use it to ask, not to claim inside knowledge: how events from the two titles are sequenced, who decides when they collide, and what a post-event review reports under a season pass. The JD does not name the two titles, so ask which are meant before leaning on them. If the talk turns to purchases, C1 is the rehearsal | The one strategy source this research found is the Larkspur announcement, from a search snippet; it makes the shared calendar the likeliest CO topic. F1's requirement of two titles is why it is asked as a calendar question |

### B. Values/Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed, and which one won." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold, since your sentence carries the calendar and not a disagreement: pick an occasion where something scheduled and something players needed pulled apart. It needs a named stake, the decision, who made it, and what changed afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: you ran the weekly content-drop calendar for your main title for two years, or how you would handle the clash | The first published value is Players Before Plans: when the calendar and the players disagree, the players win. VAL because the story must show the value in a decision, not recite it; F1 is the nearest evidence |
| B2 | "Tell me about a time you held an announcement back until the thing was actually built." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Selection scaffold: pick an occasion where a date or an announcement was wanted before something was ready. It needs what was asked, what you said, and what happened to the date. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: you wrote the release checklist your QA team still uses, or how you would handle it | The second published value is Ship the Patch Not the Promise: announce what is built, not what is hoped. VAL; F4 is the nearest evidence, and the interviewer's public talk makes this the value he is likeliest to probe |
| B3 | "Tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote the release checklist, and your QA team still uses it; tell those two beats in your own words. Answer slot: the third value talks about leaving the checklist better, so expect a probe on what it replaced or what changed. If it replaced something, or changed after you wrote it, say what and how you know; if there was nothing before it, or you do not know what changed, say so plainly and stay with writing it and QA still using it | The third published value is Leave the Build Greener: every release leaves the codebase and the checklist better than it found them. VAL because it is behavioural; F4 and F7 are the evidence |
| B4 | "Tell me about a time you had to tell a leader something about a number or a release that they did not want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick an occasion with a named message, a named listener, how it was received, and whether the working relationship held. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: you presented the monthly retention numbers to the studio head, and stop there unless you can say how a particular month landed, or how you would handle it | Pairs the first and second values: players win, and what you announce is what is built. VAL; F6 is the nearest evidence and supplies no occasion on its own |

### C. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our titles are moving to a season pass, and you haven't worked on a game with in-app purchases. How do you get useful on the numbers?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack: hold, then concede. Open with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then say only what your sentence carries: you presented the monthly retention numbers to the studio head. First follow-up, retention is not purchase data: concede that specifically, and hold on what you presented. Second follow-up, what would you get wrong first: name, in your own words, what you would expect to be slowest to learn, and the plan for your first weeks, said as a plan and never as a past. Do not describe purchase work you did not do | F9 is a gap you stated, and the Larkspur announcement (A5) makes it matter to the role. Named highest-ROI because it is the likeliest objection and the one where thickening the material does the most damage. JD because it scores a missing competency against the role's KPIs |
| C2 | "This role coordinates design, art, engineering and community on every update, and you haven't led a team. Why would they follow you?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Plain acknowledgment first: "I haven't led a team." Then the JD's own verb is coordinate; say what your material carries, which is that you ran the weekly content-drop calendar for your main title for two years. Answer slot: if you worked with any of the four disciplines on a drop, say which and what your part was, in your own words; if some were not part of your drops, or you took no part in coordinating them, say so plainly and stay with the calendar. Hold through two follow-ups by returning to the calendar, never by adding to it | F8 is a gap you stated, and F2's requirement is where it presses. JD because the question scores a stated responsibility, in Skeptic delivery |
| C3 | "The role asks for three or more years producing live-service games. How many of your four years were on a live title?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: give the number from your own records, in your own words. If the calendar years are the whole of it, say so plainly and stay with the four years as an associate producer and the two on the calendar. Do not round up and do not defend the requirement; the count is the answer | F5 is where a titled-years requirement is likeliest to be checked literally, and it is a reading of the experience line and not a gate. JD; EXP delivery, because it tests which of your years were on a live title |
| C4 | "Why this role, why Saltmarsh, why now?" | CO | [grounded] | Your own reason, in your own words, checkable against what Saltmarsh publishes: its three values, the single live-ops group in the September 2026 announcement, or the interviewer's GDC talk. Use only what you have actually read; if you have not seen the talk, do not mention it. Pick one value you can attach to something you did and say why; do not recite the three | A motivation probe that a hiring manager asks while testing the same gaps as C1 and C2. CO because a strong answer depends on current Saltmarsh facts. The guidance supplies no reason, because only yours survives a follow-up |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented to the studio head. What was in them, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Story-mapped on F6: monthly, retention numbers, the studio head; tell those beats in your own words. Answer slot: say what the numbers covered and how they were counted if you know; if you do not know how a figure was counted, say so plainly. Name the assumption behind the numbers that you would defend least, in your own words, before he asks. If you produced them, say which part; if someone else produced them and you presented them, say so plainly and stay with presenting | The only retention evidence is F6, and a prober reads the line for its denominator. EXP because it tests what was yours; the weakest-assumption move is the metric-question bar |
| D2 | "Tell me about a time a number changed what you put on the calendar." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick one occasion where a figure, the JD names retention, changed a decision about what to schedule. It needs the number, what it told you, what you changed, and what you still did not know. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: you ran the weekly calendar and presented monthly retention numbers, or how you would connect the two | F3's requirement joins KPIs to the review that acts on them, and F1 and F6 hold the nearest evidence without showing a decision. JD with EXP follow-ups |
| D3 | "Tell me about the release checklist you wrote: what it was for and how your QA team uses it today." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote it, and QA still uses it; say both in your own words. Answer slot: the JD's manage-with-QA line makes a probe on who runs it at each release likely, and the interviewer's public background is in QA. If you ran releases against it with QA, say how; if QA ran it without you, or you only wrote it, say so plainly and stay with writing it and QA still using it | F4 is the strongest evidence you have and the one a former QA lead will test hardest. EXP because it tests what was actually yours |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run live events on a game with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | Pause and restate the question, then say only what your sentences carry: you ran the weekly content-drop calendar for your main title for two years, you wrote the release checklist your QA team still uses, and you presented the monthly retention numbers to the studio head. Concede one thing, specifically, without being asked twice: "I haven't worked on a game with in-app purchases." Hold through two follow-ups by returning to what you did, never by adding to it, and do not argue the comparison | F9 is the gap this question presses. JD for the scored responsibility, Pressure for the delivery |
| E2 | "That checklist, how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold the sentence as it stands: "I wrote the release checklist our QA team still uses." Answer slot: if others contributed, say who and what; if it was yours alone, say so; if you do not know how much of its current form is yours, say that plainly. Concede only what is true, keep your verb, and do not fold on the core claim to restore harmony | F4 is the claim an attribution probe tests. EXP because it tests attribution honesty; the hold-then-concede structure is the Pressure bar |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | A 90-second arc in your own words with the beats your sentences carry: four years as an associate producer at a puzzle-game studio, and the last two running the weekly content-drop calendar for the main title. End on your own reason for this role; the guidance supplies none. Add nothing the two sentences do not say | F5's sentences are the whole biography the material gives. EXP because it sets the facts every later probe tests |
| F2 | "What is a live event in a mobile game that you thought was run well, and why?" | JD | [grounded] | Pick one you can describe as a player: what was announced, what shipped, and how the studio handled anything that went wrong. If you have played either Saltmarsh title, Tidepool Tactics or Lantern Row as the September 2026 announcement names them, say so honestly; if you have not, say that and do not pretend. If no event comes to mind, say so plainly and say how you would judge one | A casual question on a hot JD topic, the live-events calendar of F1's requirement, and still scored. JD because the topic comes from the JD line, in Conversational delivery |

## Values cheat sheet

A values-style round is detected: Saltmarsh's interviewing page documents a values conversation as the second part of the hour. The names below are as the values page gives them.

| Value | Working meaning, paraphrased | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold (B1): pick an occasion where something scheduled and something players needed pulled apart, with the decision and who made it. If none comes to mind, say so plainly, then give the nearest thing your material carries, F1: "I ran the weekly content-drop calendar for our main title for the last two years." |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold (B2): pick an occasion where an announcement or a date was wanted before something was ready. If none comes to mind, say so plainly, then give the nearest thing your material carries, F4: "Wrote the release checklist our QA team still uses." |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | Story-mapped (B3), F4: "Wrote the release checklist our QA team still uses." The two beats are that you wrote it and that QA still uses it; what it replaced or changed is an answer slot in B3 |

## Reverse questions

| # | Question to ask Tobias | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You came to live operations from QA. What did QA teach you that you still use when an event goes wrong?" | Ties to his own path and turns an interrogation into a conversation between two people who care about release quality. Ask it only if the talk's biography is something you have actually read | [grounded] |
| R2 | "Your GDC talk argues a live team is judged by how often its patch notes match what shipped. How does your team measure that today?" | Shows you read him rather than the company, and asks for the measure behind his own argument. Use it only if you have seen the talk | [grounded] |
| R3 | "Once per-title event teams become one live-ops group, who owns the call when the two titles' events collide?" | Takes the Larkspur announcement to the decision the role will face and signals that you think at the shared-calendar level | [grounded] |
| R4 | "Which numbers does the post-event review report today, and who reads it?" | Tests the JD's own-the-review line from the other side and tells you whether the KPIs are retention-led or something else | [generic] |
| R5 | "What does good look like for this role at ninety days, and what would tell you I was behind?" | Gives you the interviewer's own scoring sheet, and shows you expect to be measured | [generic] |
| R6 | "Since I haven't worked on a game with in-app purchases, what would you want me to learn first?" | Takes the objection to him in your own words before he has to raise it a third time; use it only if C1 came up | [grounded] |

## Prohibited claims

What this pack will not coach, and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed the teams on each update | Negative you stated, F8 | The plain acknowledgment: "I haven't led a team." Then F2's sentence at its own scope |
| Worked on or owned in-app purchase numbers | Negative you stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot; F6's sentence stays at its own scope |
| Ran a live-events calendar across two titles | Inflated form of F1 | F1's sentence at its own scope. The limit is the pack's observation: the material says a weekly content-drop calendar for one main title. A3 and C3 stay inside it |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's sentence at its own scope. The limit is the pack's observation: the material says you presented the numbers. D1 asks only what the numbers covered and which part was yours |
| Managed the release process with QA | Inflated form of F4 | F4's sentence at its own scope. The limit is the pack's observation: the material says you wrote the checklist and QA still uses it |
| Produced live-service games for three or more years | Inflated form of F5 | F5's sentences at their own scope. The limit is the pack's observation: the material gives four years as an associate producer and two on a weekly calendar |

## Sources

Provided documents: the job description text and your background paragraph, both in your message. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

Searches sent:

- "Saltmarsh Games values" returned https://saltmarshgames.com/values
- "Saltmarsh Games interview process live operations producer" returned https://saltmarshgames.com/careers/interviewing
- "Saltmarsh Games mobile studio strategy news" returned https://saltmarshgames.com/news/project-larkspur
- "Tobias Wrenfield Saltmarsh Games" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise

Fetches sent: https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing, both returned. The Larkspur and talk pages were not fetched; their rows use the search snippet only.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet and bank B: the three value names and meanings, from the fetched official page |
| 2. Saltmarsh Games interview process, live operations | yes | Persona weights and bank A: the Outage Hour, one 60-minute session with tabletop then values, no take-home, from the fetched official page |
| 3. Saltmarsh Games strategy and recent news | yes | A5, C4, F2 and R3: the Larkspur announcement of September 2026, from a search snippet |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | The interviewer read, D3, E2, B2, R1 and R2: a GDC 2026 talk and a QA background, from a search snippet |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- How many hours you have before Friday: adds a prep-triage section ordered to that time
- Your answers to the slots in F1, F2, F3, F4 and F5 (events among your drops, which teams you worked with, who produced the numbers, who ran the checklist, how many years were live): moves those rows from low or medium confidence toward grounded and turns slot guidance into story-mapped guidance
- A redacted copy of the release checklist and one retention report you presented: these are the inspectable artifacts in this field, and they would raise F3, F4, F6 and F7 from medium toward high
- The recruiter's confirmation of the Outage Hour format and of which two titles the role covers: replaces the assumption this pack's weights rest on, and tells A5 and F2 whether the two titles are the ones the announcement names
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes): fetches the Larkspur announcement and the talk page in full, and sweeps for loop reports and recent org context; offered once, say the word to run it
- A tuesday-dossier.md from an evidence review: would add confirmed evidence and a list of claims to avoid, in place of the ones this pack inferred itself
