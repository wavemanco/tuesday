# Interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy — a peer, both reporting to the same VP
**Format:** one 60-minute conversation with Dan (stated in the coach's notes)
**Built from:** the coach's notes only (role, JD highlights, candidate summary, interviewer profile, research note). Every web search was refused in this session, so nothing here rests on outside research.

## How to use this pack

- **Personas describe how a question is asked; types describe what it scores.** Each bank is one persona. Each question carries one type tag, sometimes two, primary first.
- **Type key**
  - **VAL**: whether past behavior shows the values a company publishes, not generic virtue.
  - **EXP**: whether the CV claims survive scrutiny, and what was actually yours.
  - **JD**: whether you can do the listed job, gaps included.
  - **CO**: company and strategy knowledge, and whether you can think at the company's altitude.
  - **CASE**: structure and reasoning on a live problem from the role.
- **Guidance is scaffolding, not a script.** All wording proposed in a guidance cell is proposed language, pending your approval. Change anything that isn't how you would say it.
- **An answer slot is an instruction for the interview.** It never asks you anything here. Answer it with whichever branch is true: say how you did it in your own words, or say plainly that there was no such step or it wasn't yours.
- **Highest-ROI prep:** D1, the question about classic sales-ops and quota-setting. Dan owns that territory and will probably ask it in some form. It gets the deepest rehearsal below.

## Fit snapshot

Provenance: the JD lines are the coach's highlights, quoted as written, not the full JD text. Candidate evidence is the coach's notes, not a CV. Proposed bridge wording in the last column is pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, the coach's notes | "2 years strategy consulting at a top firm" — the coach's notes; "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | low | [inferred] | discovery | Your material says strategy consulting, then product strategy and ops, and nothing about a new product line or a go-to-market plan. Words stay at the quotes: "I spent two years in strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company." Answer slot: the JD's line on owning go-to-market strategy for two new product lines makes a probe on new-product work likely. If any of your product strategy work took something new to market, say what it was and what part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the product strategy and ops you did |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, the coach's notes | none given | none | [grounded] | discovery | Your material does not show work across those stages. Answer slot: the JD's land/adopt/expand/renew line makes a probe likely. If any of your work looked at where customers or partners were won, grew or were lost, say what you looked at and what you did with it, in your own words; if none did, or it was not yours, say so plainly, and say what you would look at first, as a plan and never as a past |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, the coach's notes | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap on the tools themselves, but a one-line claim with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: "I'm skilled in SQL and Tableau." The quote says skilled, not what you built with them, and A3 rehearses that probe |
| F4 | "partner-motion design experience required" — JD highlights, the coach's notes | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a revenue model at partner level, used in carrier negotiations, not the motion around it, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's partner-motion line makes a probe on what else you decided likely. If any part of the partner work beyond the model was yours to decide, say which part and how you decided, in your own words; if none was, or it was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, the coach's notes | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap, but a one-line claim with nothing inspected behind it, so expect a probe. Lead with the targets and the consensus in the quote's terms: "I set annual volume targets with cross-org consensus." Answer slot: expect a probe on how agreement was reached. If the orgs differed at the start, say how it resolved and what part was yours; if they did not, or the part was not yours, say so plainly and stay with the targets and the consensus |
| F6 | "AI experience a plus" — JD highlights, the coach's notes | "uses AI tools daily" — the coach's notes | medium | [grounded] | none | No gap, but a one-line claim, so expect a casual probe (E2). Lead in the quote's terms: "I use AI tools daily." The quote says use, not what was built with them |
| F7 | Classic sales-ops and quota-setting fluency, the home turf of a peer who directs sales strategy (role-family expectation, not in the JD highlights) — no source [generic] | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and the coach has said so. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Never a claim to that work, and no relabeling of the annual volume targets as quotas |
| F8 | A quantified commercial result the candidate can defend under a data-driven probe (role-family expectation) — no source [generic] | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | none | No gap, but the headline figure with nothing inspected behind it, so expect it to be probed to its assumptions. Keep the quote's own verbs: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slots for the figure are in A1 and F1 |

## Reading the interviewer

Public footprint only. The profile facts below are as given in the coach's notes. No talks or writing were found, because search was refused, so nothing is inferred beyond them.

| Observation | Source | What it means for you | Provenance |
|---|---|---|---|
| Self-describes as "relentlessly data-driven" | Profile, the coach's notes | Expect every figure probed to its inputs and assumptions. Say plainly what you don't know about how a number was counted, and name the weakest assumption you know of before he does. F8 and F5 are the exposed rows | [grounded] |
| Career spine is pricing and monetization roles | Profile, the coach's notes | Case questions will tilt to pricing, packaging and unit economics (C2). Mirror opportunity: shared revenue vocabulary. Your side of it is F4's sentence, "built a partner-level revenue model used in carrier negotiations". Offer it at that scope and don't present it as pricing experience | [grounded] |
| One early-stage-startup chapter | Profile, the coach's notes | Builder stories land well with him, and a big-company background may draw a pace or scrappiness probe. The notes hold no startup or zero-to-one sentence for you, so no mirror is offered. D4 and E1 carry the motivation slots | [grounded] |
| Peer reporting to the same VP | Coach's notes | He is pricing what you cost and contribute to his work. Lead with seam principles and what you bring his team (B1, B3), not only what you need | [grounded] |

## Persona table

Weights reflect three passes: relationship priors, interviewer signals, then the loop. The loop is one 60-minute conversation, per the coach's notes, so no separate values round is detected and no company values were available to fetch.

| Persona | How it shows up with Dan | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober (5 questions) | Line-by-line on every figure and model: inputs, denominators, what you did yourself | Highest. A peer prior carries Prober, and "relentlessly data-driven" pushes it up | Know what you can and cannot say about how the figure was counted, and say plainly when you don't know. Name your weakest assumption first |
| B. Peer Evaluator (4) | The seam between his team and yours, what you need from him, credit when work spans teams | High. The peer prior is the strongest relationship signal here | Seam principles rather than pretending to know the seam. Reciprocity: what you bring his team. Disagreement answers that show spine and tact |
| D. Skeptic (4) | The sales-ops and quota gap, the partner-motion gap, why leave a big company and why here | High. F7 is a stated capability gap in his own territory, and F1, F2 and F4 are thin or adjacent. The startup chapter adds a pace probe | Rehearse D1 until it is boring. Bridges only from what you stated. Where nothing was stated, say the limit plainly and give a plan |
| C. Case/Strategist (3) | Pricing, packaging and expansion problems on Northwind's own priorities | Medium. His pricing spine tilts the cases, but a peer conversation is rarely case-led | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise respectfully |
| E. Conversational (2) | The journey question and a casual AI question | Medium-low. These arrive as warm openers and are still scored | A 90-second arc built only from your quotes, and treat the AI question as scored |
| F. Pressure (2) | Time-boxed challenges on the ARR figure and on why you over a sales leader | Low-medium. Not his likely style as a peer, but the figure and the gap invite it | Pause, restate, hold the quoted position through two follow-ups, then concede specifically |
| G. Values/Behavioral (2) | An unpopular-truth story and a customer-over-metric story | Low. No values round is detected and no published values were available | Pick stories where the hard truth landed. Where none comes to mind, say so |

## Question banks

Provenance cells carry the quotes the guidance rests on, exactly as they sit in the fit snapshot. All wording proposed in guidance is pending your approval.

### A. Data-Driven Prober (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold the quote's own verbs: you proposed the change, and the uplift was credited to it. Then the four slots a figure raises, each in your own words. How it was counted: if you know, say how; if you don't, say so plainly. What it is sensitive to. The assumption behind it you would defend least, named before Dan names one. Which part was yours beyond the proposal: if you did more, say what; if the rest was others' or you don't know, say so and return to the proposal | F8 is the headline number and the likeliest place a data-driven peer starts. EXP because it scores whether the figure survives scrutiny, not whether you can do the job |
| A2 | "Walk me through the partner-level revenue model that was used in carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-map only the beats the quote states: you built it, it was at partner level, and it was used in carrier negotiations. Tell them in your own words. Answer slot: expect a probe on which part of the model was yours and what it was sensitive to. If you chose its inputs or checked it yourself, say how; if others supplied them, or you don't recall, say so plainly and return to the model. Do not describe your role in the negotiations beyond what the quote says | F4 is the evidence nearest the partner requirement, so it gets probed for depth. EXP because it tests what was actually yours |
| A3 | "Tell me about an analysis you ran in SQL or Tableau, from question to decision." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold: pick one analysis from your own work where you can say what question it answered, what data it used and what followed from it. If no such analysis comes to mind, say so plainly, then say what your SQL and Tableau skill covers in the words of your quote, or how you would approach one. Offer to walk it end to end only if it is yours | F3 is the JD's tools line and Dan's native ground. JD because it scores the stated requirement, delivered as an open prompt |
| A4 | "How were the annual volume targets set, and where did the orgs disagree?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Beats the quote carries: you set the targets, annually, with cross-org consensus. Answer slot: the JD's cross-functional line raises a probe on how agreement was reached. If the orgs differed at the start, say how it resolved and what part was yours; if they did not, or the part was not yours, say so plainly and stay with the targets and the consensus. Do not call the targets quotas | F5 is the cross-functional evidence and Dan will test whether consensus was influence or paperwork. EXP because it checks what you did inside a cross-org process |
| A5 | "Tell me about a time you shaped the plan to take something new to market." | JD | [inferred] "9 at a large consumer-tech company in product strategy & ops" | Selection scaffold from the JD's two-new-product-lines line: pick a time with something new, a decision you made about how it reached users, and an outcome you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is nine years in product strategy and ops, or say how you would approach it. F1's answer slot applies | F1 is the thinnest row against the role's first requirement, so an open prompt on it is likely. JD because it scores the headline responsibility |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between sales strategy and emerging-products GTM, and what happens when we disagree?" | JD | [generic] | Offer principles, not a map of a seam you haven't seen: shared definitions for land, adopt, expand and renew; who owns which decision; how a disagreement is escalated to the VP you share. Say you would want his view of where the seam is today. The question needs no claim about your past, so the guidance makes none | The peer prior makes turf the central worry. JD because it scores the cross-functional requirement; `[generic]` because it is a pattern for the problem, not a fact about Northwind |
| B2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "set annual volume targets with cross-org consensus" | Beat the quote carries: targets set across orgs, with consensus. Answer slot: if credit for that work was shared or contested, say how it was handled and what part was yours; if it was not, say so plainly and stay with the consensus. If you reach for the ARR figure, keep its verb: it was credited | A peer pricing his own credit exposure will ask this, and F5 and F8 both involve credit. VAL because it scores collaborative behavior, not a published value |
| B3 | "What would you need from my team in your first ninety days, and what could you give us?" | JD | [generic] | Reciprocity first, needs second. Offer what your quotes carry, as skills and not as past wins: SQL and Tableau skill, and a partner-level revenue model built for carrier negotiations. Ask for the definitions and data access you would want, and for a walk-through of how his team sees the funnel. Say nothing about Northwind's current process, which you have not seen | The peer prior asks whether the hire adds to or reduces his load. JD because it scores partnership in the role |
| B4 | "Tell me about a time you disagreed with a peer team and how it resolved." | VAL | [grounded] "set annual volume targets with cross-org consensus" | Selection scaffold: pick a disagreement with a named stake, a position you held, and a relationship intact at the end. The quote shows consensus across orgs, not whether anyone disagreed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the targets and the consensus, or say how you would handle it | The JD's cross-functional line raises an open prompt like this, and a peer tests spine and tact together. VAL because it scores behavior with equals |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Enterprise expansion is a priority and a new product line's expansion revenue is lagging. Where would you look across land, adopt, expand and renew, and what would you pull in SQL first?" | CASE | [grounded] | Clarify first: what lagging means, against what baseline, for which segment. Name the objective, split by stage and segment, say what you would pull first and why, and name the weakest assumption in your own diagnosis. Use land/adopt/expand/renew as your headings, since the JD does. Your material has no whitespace example, so this is a method and not a story: F2's slot applies if you reach for past work | Dan's data-driven lens meets the JD's whitespace line. CASE because it is a live problem, and the research note's enterprise-expansion priority makes it concrete |
| C2 | "We're launching an AI copilot, Compass. How would you price and package it for enterprise expansion, and what do you need to know first?" | CASE | [grounded] | Clarify before structuring: who buys it, what it replaces, who already has the data. Then objective, segments, the packaging options (standalone, attached, tiered), what each does to expansion and to margin, and the metrics and risks. Pricing is his native ground, so state the hypothesis early and ask for his view. Make no claim to pricing experience, which your material does not show | The research note names the Compass launch and his spine is pricing and monetization. CASE because it is a live problem from the role; the AI plus in F6 rides on it |
| C3 | "Our stated priorities are enterprise expansion, Compass and profitability, and a much larger platform vendor is bundling. If you could fund only two, which two, and what would you tell the VP about the third?" | CO | [grounded] | The priorities and the bundling threat are public consensus, so bring one of them to prove grounding and then your own divergence with reasons. Pick two and name the anti-pick, the thing you would say no to, with a mandatory concession on what that costs. Tie the choice to land/adopt/expand/renew. Ask whether Compass is one of the two product lines | The research note supplies all three priorities and the bundling threat, and recitation scores as homework. CO because it tests altitude on the company's strategy; CASE delivery |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't done classic sales-ops or quota-setting. How does that change how you'd work with my team on a launch?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus" | **Highest-ROI rehearsal.** Level 0: say it first and plainly: "I don't have classic sales-ops or quota-setting experience." Then the nearest thing, at its own scope: "I set annual volume targets with cross-org consensus." Follow-up 1, answer slot: if Dan asks how the targets relate to quotas, say in your own words what the targets covered and how they differ from or resemble quotas; if you can't draw that line, say so plainly and stay with the targets and the consensus. Follow-up 2, the plan, in future tense only: what you would ask his team to walk you through and what you would want to see in your first weeks. Concession wording: "I haven't done that work, and I'd want to learn it from your team rather than guess." Never relabel the targets as quotas, and never fold the acknowledgment into a claim | F7 is a stated gap sitting in the interviewer's own territory, and he is a peer, so it lands on his work. JD because it scores whether you can do the listed job alongside his team, delivered as a Skeptic probe |
| D2 | "The JD requires partner-motion design experience. What part of a partner motion have you designed yourself?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold only what the quote carries: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if any part of the partner work beyond the model was yours to decide, say which and how you decided, in your own words; if none was, or it was not yours, say so plainly and describe the model. Hold through two follow-ups by returning to the model, never by adding to it. The honest branch is a limit, not a confession | F4 is where the JD's requirement presses on a model, not a motion, so this objection arrives in some form. JD because it scores a stated requirement |
| D3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" | Pick the gap you actually have, which your own statement already names: classic sales-ops and quota-setting. Say it plainly, then give a plan in future tense: what you would learn first and from whom. Do not choose a weakness you don't have to sound modest, and do not name the thin rows as gaps you cannot back | A calibrated answer beats bluffing a competency he owns. JD because it scores honest self-assessment against the listed job |
| D4 | "You've spent nine years at one large consumer-tech company and we're B2B data infrastructure. Why leave, why here, why now?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Answer slot, motivation: no quote carries your reason, so give your actual reason for leaving and your actual reason for this company and this role, in your own words. If the move is partly toward B2B, say what draws you to it. Keep each answer to what is true for you. The pace probe from his startup chapter may follow: answer it with how you work, not with a claim about past scrappiness | The consumer-to-B2B move and the single long tenure are the standard motivation probes, and a startup-chapter peer may add pace. EXP because it tests whether the story survives cross-examination |

### E. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with three beats: two years in strategy consulting at a top firm, then nine in product strategy and ops at a large consumer-tech company, then why this role. The third beat is D4's slot, in your own words. Add detail only from your own memory, not from this pack | A casual opener is still scored for communication economy. EXP because it checks the CV arc, and E is where it arrives |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say it in the quote's terms: you use AI tools daily. Answer slot: name which tools and what for, in your own words; if the use is light or narrow, say so plainly. Don't claim you built or shipped AI work. Tie to Compass only as interest, not experience | The JD names AI as a plus and Compass is a stated priority, so a casual question here is scored. JD because it scores a stated plus, asked casually |

### F. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That ARR number: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause and restate the question. Hold the quoted position through two follow-ups: you proposed the change, and the uplift was credited to it. Concede specifically where the quote stops. Answer slot: if you did more than propose it, say what; if you don't know how the credit was assigned, say so plainly. Never say you drove or delivered the uplift | F8 is the figure a prober or pressure style goes after. EXP because it scores attribution honesty, with a hold-then-concede structure |
| F2 | "Sixty seconds: why you over a candidate who has run a sales org?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus"; "skilled in SQL/Tableau"; "No classic sales-ops or quota-setting experience" | Restate, then hold on what the quotes carry: a partner-level revenue model used in carrier negotiations, annual volume targets set with cross-org consensus, and SQL and Tableau skill. Concede in one sentence: "I don't have classic sales-ops or quota-setting experience." Don't claim to be better; let him draw that | F7 makes this challenge predictable for a peer who runs sales strategy. JD because it scores fit for the listed job, with a pressure delivery |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a truth that landed, and a relationship intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or say how you would handle it. Choose a story where the truth actually landed | A data-driven peer weights candor. VAL; `[generic]` because no published Northwind values were available and the stem is a persona pattern |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision with a named customer need, an internal number that pointed the other way, and what you chose. If none comes to mind, say so plainly and say how you would weigh it. Don't borrow the ARR story unless it truly fits | The profitability priority makes growth-versus-customer tension plausible. VAL; `[generic]` for the same reason as G1 |

### Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| "own GTM strategy for two new product lines" | A5, C2, C3 |
| "identify whitespace across land/adopt/expand/renew" | C1, C3 |
| "run independent analysis in SQL and Tableau" | A3, C1 |
| "partner-motion design experience required" | D2, A2 |
| "strong cross-functional influence" | A4, B1, B2, B3, B4 |
| "AI experience a plus" | E2, C2 |
| Sales-ops and quota fluency (role-family, F7) | D1, D3, F2 |
| Headline figure (F8) | A1, F1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your career has been pricing and monetization. Where do pricing and packaging decisions for the new lines get made, and where do you want strategy's input?" | Tied to his own path. It treats his spine as expertise and finds the seam |
| R2 | "You had an early-stage-startup chapter. What from it do you still use here?" | Tied to his path, and it invites a builder story instead of a probe |
| R3 | "What's one thing a new peer could do in the first month that would help your team?" | The reciprocity question for a peer. It shows you are thinking about his load |
| R4 | "Where do you expect our teams to overlap on land, adopt, expand and renew, and where do you want a clear line?" | Turns the seam probe from B1 into your question |
| R5 | "Is Compass one of the two product lines, and how do you weigh its success measures against the profitability priority?" | Shows you worked from the stated priorities and asks what the research note could not say |
| R6 | "What would a data-driven view of success look like for me at two quarters, and which numbers would you hold me to?" | Meets his self-described lens and gets the scorecard in the open |
| R7 | "When sales strategy and emerging products want different things, how does the VP usually arbitrate?" | Asks about the seam in practice and shows you expect the disagreement B1 rehearses |

## Prohibited claims

Built from the fit snapshot before the banks. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has classic sales-ops or quota-setting experience, or treating the annual volume targets as quotas | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." The targets stay "annual volume targets" at F5's scope. No slot beyond D1's |
| Drove, delivered or owned the ~$400M ARR uplift | Inflated form of F8 | F8's quote at its own scope: proposed, credited. The limit is the pack's observation, not words for you: the material says proposed and credited, not delivered. A1 and F1 slots stay at that scope |
| Designed a partner motion | Inflated form of F4 | F4's quote at its own scope: a partner-level revenue model used in carrier negotiations. The limit is the pack's observation: the material says the model, not the motion. D2's slot stays inside the model |
| Led or ran the carrier negotiations | Inflated form of F4 | F4's quote at its own scope: the model was used in carrier negotiations. The limit is the pack's observation: the material does not say you took part in them |
| Ran independent analyses end to end in SQL and Tableau | Inflated form of F3 | F3's quote at its own scope: skilled in SQL and Tableau. The limit is the pack's observation: the material says the skill, not what was built. A3 stays a scaffold |
| Built, shipped or led AI products or AI work | Inflated form of F6 | F6's quote at its own scope: uses AI tools daily. The limit is the pack's observation: the material says use, not building. E2's slot stays at use |

## Sources

**Provided documents:** the coach's notes in the request (role and company, JD highlights, candidate summary, interviewer profile summary, and a research note stating Northwind's three priorities — enterprise expansion, the AI copilot Compass, reaching profitability — and the main competitive threat, bundling by a much larger platform vendor). No CV, no full JD, no dossier.

**Searches sent (all refused by the environment, none returned results):**
- "Northwind Data values" — refused
- "Northwind Data interview process strategy GTM" — refused
- "Dan Kovac Northwind Data Director of Sales Strategy" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Would have named the published values to theme the G bank and check for a values round. G is `[generic]` and no values section is built |
| 2. `Northwind Data interview process` | unavailable | Would have documented loop structure. The coach's words fix one 60-minute peer conversation, so the persona weights stand on that, not on a documented loop |
| 3. `Northwind Data strategy` / recent news | skipped | The research note supplies the three priorities and the competitive threat, so it fixes C1 to C3. The note's age and source were not checked |
| 4. `Dan Kovac Northwind Data` | unavailable | Would have added talks and writing to the interviewer read, which rests on the profile as given |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights fix the fit snapshot and the JD-tagged questions, though they are highlights and not the full text |

## Upgrade menu

- Full JD text → the six JD highlight rows become verbatim JD quotes, and any mid-list requirement the highlights dropped gets a row and a question
- Priya's CV → quotes from the CV replace the coach's notes in every evidence cell, and rows may move from medium to higher confidence once an inspectable artifact is cited, such as the revenue model workbook, the target-setting memo, the proposal behind the surface change, or a Tableau workbook
- Priya's answers to the slots in A1, A2, A4, A5, D1, D2 and E2 → each becomes quoted evidence, and the rows F1, F2, F4, F5 and F8 regenerate
- The recruiter's prep email → stated focus areas and any pre-declared deliverable, which would add a graded deliverable section
- Search access, or Northwind's published values and interview page → the G bank themed on the published values by name, a values cheat sheet if a values round is documented, and persona weights checked against a documented loop
- Dan's public talks or writing → a fuller interviewer read and a tailored reverse question
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), offered once → a grounding brief on strategy, recent moves and leadership context for the C bank
- The research note's date and source → a check that the three priorities are current before C3 relies on them
- A `tuesday-dossier.md` from an earlier evidence pass → verified evidence and absolute prohibited claims in place of the locally built list; none was present
