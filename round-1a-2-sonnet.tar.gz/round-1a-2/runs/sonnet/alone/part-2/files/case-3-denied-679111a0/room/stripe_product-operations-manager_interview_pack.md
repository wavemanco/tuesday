# Interview prep pack: Product Operations Manager, Stripe

Final round. Interviewer and relationship not yet known, so the persona weights are flat. No CV and no job description were provided, so every candidate-evidence cell is empty and every question is `[generic]` rehearsal, not story-mapped.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the company's published values |
| EXP | Work-experience deep-dive: do your claims survive scrutiny, and what was actually yours |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge: homework depth and altitude |
| CASE | Live problem from the role, scored on structure and reasoning |

Question IDs run by persona (A1, A2, B1 and so on) so a drill can name them. Answer slots are instructions for the interview itself and need no reply here.

## Fit snapshot

No CV and no job description were provided, so this is the worksheet variant. The requirements are role-family patterns written as plain prose with no source, so each is `[generic]`. Fill the evidence column from your own CV and the pack regenerates around it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run launches or an operating cadence across product, engineering and go-to-market teams (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is a quoted line of your own naming the launch or cadence and what you did in it. Selection scaffold: pick a launch or recurring process you worked on that crossed teams, and note what you did in it. If none comes to mind, say so plainly, then give the nearest work your material does carry, or how you would set one up |
| F2 | Define and track product or adoption metrics (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is a figure of your own with how it was counted and what part was yours. Selection scaffold: pick a metric you were accountable for, and be ready to say how it was counted and what it is sensitive to. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or what you would measure first |
| F3 | Improve how product teams plan and work, through process or tooling (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is a process or tool change of your own and what happened to it. Selection scaffold: pick a change you proposed or ran, including one that did not stick. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it |
| F4 | Bring customer and go-to-market feedback into product priorities (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is a feedback channel or decision of your own, in your words. Selection scaffold: pick an occasion customer input changed what a team did. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would build the loop |
| F5 | Influence senior people and peers without direct authority (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is a disagreement or persuasion moment you can narrate with a named stake. Selection scaffold: pick a time you moved someone you did not manage. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Communicate clearly in writing and to executives (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is a document or briefing of your own you can describe. Selection scaffold: pick one you wrote or presented and who read it. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would structure one |
| F7 | Work through ambiguity when scope and priorities shift (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is a time scope changed on you and what you did. Selection scaffold: pick one such occasion. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it |

## Persona table

No loop source established Stripe's loop, so the Generic archetype applies: flat weights, and nothing in this pack asserts how Stripe's final is structured. If your final is several back-to-back sessions, the schedule would let the pack split into per-session mini-packs.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problem: plan a launch, diagnose a metric | Flat. No source establishes this loop, so no persona is weighted above another | Clarify, state the objective, segment, approach, metrics, risks. Think aloud and challenge one premise politely |
| Skeptic | Quiet probing of gaps and of why this role, why now | Flat. No source establishes this loop; included because gaps and motives are where an interviewer can probe | Rehearse the day-one-weakness answer until it is boring. State a limit plainly and pair it with a ramp plan |
| Values / Behavioral | Scenario prompts about unpopular truths and customers | Flat. Stripe's published values were not retrievable, so the pack cannot place a values round | Choose a story only where one of your own sentences carries it, otherwise say so plainly |
| Data-Driven Prober | Goes two levels deep on any number | Flat. Included because any metric you cite can be probed | Know how each figure was counted and say plainly when you do not know |
| Peer Evaluator | Seam between product operations and product management | Flat. Relevant if a product peer is on the loop, which the material does not show | Offer seam principles rather than a claimed seam, and say what you bring their team |
| Pressure / Stress | Time-boxed challenges to your reasons and your credit | Flat. Interviewer relationship unknown, so included for completeness | Pause, restate, hold through two follow-ups, concede specifically |
| Conversational / Rapport | Friendly, unstructured openers | Flat. Included so no style is met for the first time live | A 90-second arc built only from things you did |

## Question banks

Highest-ROI prep: **B1**, "Which part of this role would you be weakest at on day one?" Without a CV this pack cannot name an objection specific to you, but this question is likely to arrive in some form, and a rehearsed, non-defensive answer changes the interview. Once a CV is shared, B1 is rebuilt around the largest gap it exposes.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch has slipped twice, and engineering and go-to-market each say the other side was not ready. What do you do in your first week?" | CASE | [generic] | Clarify before structuring: what slipped, what each side means by ready, who decides. Then objective, approach, metrics, risks. Challenge one premise aloud, for example whether the problem is the launch or the definition of ready. Think aloud for two minutes | Live problem in the role family, covering F1, F3 and F7. CASE because it scores structure and carries no claim about your past |
| A2 | "Adoption of a recently shipped feature is 20 percent below plan. Diagnose it." | CASE | [generic] | Ask how the plan was set and what adoption means here, then segment: who, where in the flow, since when. State hypotheses in order, say what data would separate them, and name what you would do first. No past is claimed | Metric-diagnosis case for F2. CASE because delivery matters more than the answer |
| A3 | "What should product operations be doing for Stripe's product teams right now, and what should it say no to?" | CO | [generic] | Before the interview, read Stripe's own current published material and note what you actually read. In the answer, name where you got each point. Where you have not read something, say so plainly and frame it as a hypothesis plus the question you would ask. Include one thing product operations should decline, since the role often involves saying no | The pack could not retrieve current Stripe strategy, so this question stays generic and the homework is yours. CO with JD delivery, covering F3 and F4 |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal. Choose a real gap by comparing your own background with F1 to F7, not a disguised strength. State it in one plain sentence in your own words, then a ramp plan: what you would read, whom you would ask, what you would do in the first 30 days. Follow-ups to rehearse: how do you know that is the real gap, what would your last manager say, and what if the person you work with owns that area. If no gap comes to mind, say so plainly, then name where you expect the steepest learning at a new company | Likely to arrive in some form. JD because it scores honest self-assessment against the listed job |
| B2 | "Why Stripe, why product operations, and why now?" | CO | [generic] | Three short parts, each a reason of your own. The Stripe part should rest on something you actually read or used, not general admiration. If a reason is not yet formed, say what draws you and what you still want to learn | Motivation consistency is the Skeptic's score. CO because the first part tests homework |
| B3 | "Why are you looking to leave your current role?" | EXP | [generic] | Give your actual reason in your own words, once, forward-looking, without disparaging anyone. Do not offer a reason you do not hold | Probes motivation consistency. EXP because it tests whether your account stays consistent |
| B4 | "Suppose six months in, the product teams see you as a process tax. What went wrong?" | JD | [generic] | A hypothetical, so no past is claimed. Name two or three plausible causes, such as process added without a clear payoff, and what you would watch for early to avoid each. Show you would ask the teams | Tests self-awareness about the failure mode of this role family, covering F3 and F5 |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you said it anyway, and a relationship that was intact afterward. Use I for your contribution and we for context. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Values-style prompt, covering F5 and F6. VAL because it scores behavior rather than a claim |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the two pulled apart, what you chose and why, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would weigh it | Customer-first prompt for F4. The pack does not know Stripe's published values, so it ties the question to no named one |
| C3 | "Tell me about a time you held a position under pressure from someone more senior." | VAL | [generic] | Selection scaffold: it needs a named stake, a moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Pairs with the Pressure bank, covering F5 |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a metric you were accountable for. How was it counted?" | EXP | [generic] | Answer slot: say how it was counted, what it is sensitive to, and which part was yours, in your own words. If you do not know how it was counted, say so plainly and say what you would check | Defend-the-number rehearsal for F2. EXP because it tests attribution |
| D2 | "Think of a number you have reported to others. Which assumption behind it would you defend least?" | EXP | [generic] | Name the weakest assumption you know of before the interviewer does. If no such number comes to mind, say so plainly, then describe how you would find the weakest assumption in a number you were handed | Naming the weakness first turns a gotcha into credibility, covering F2 |
| D3 | "How would you know product operations is working for a product organization?" | JD | [generic] | A design question. Separate outcomes from activity, propose two or three signals, and say how you would avoid measuring only what is easy. No past is claimed | Covers F2 and F3. JD because it tests how you would run the role |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | JD | [generic] | Do not claim to know the seam. Offer principles: who owns the decision and who owns the mechanism, how disagreements escalate, and what you would ask them about how it works today. Add what you bring their team, not only what you need | Peer reciprocity, covering F1 and F5 |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick an occasion, say what was yours and what was shared, in those words. If no such occasion comes to mind, say so plainly, then say how you would handle it | Credit-sharing probe, covering F5 |
| E3 | "Tell me about a time you disagreed with a peer team and how it resolved." | VAL | [generic] | Selection scaffold: show spine and tact together, with a named stake and the state of the relationship afterward. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Disagreement style with equals, covering F5 |

### F. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who already knows our product?" | JD | [generic] | Pause and restate. Lead with one thing from your own background that you can back with a sentence you wrote on your CV. Hold through two follow-ups, then concede the limit specifically and without folding on the core | Tests composure under a challenge to your fit. Covers F6 |
| F2 | "Tell me about a result you are proud of. How much of it was actually you?" | EXP | [generic] | Hold-then-concede. Say what was yours and what was shared, in those words. Hold through two follow-ups. Concede any uncertainty explicitly and specifically. If you cannot separate your part from the team's, say so plainly | Attribution probe in its pressure form, covering F1 |
| F3 | "Product operations is a cost center. Convince me it is not." | JD | [generic] | Pause, restate, hold one position through two follow-ups. Say what you would measure and concede plainly which effects are hard to measure | Devil's-advocate challenge to the role itself, covering F2 and F3 |

### G. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc of three beats, each something you did: where you started, the through-line, why this role. Build it from your own CV once shared. If a beat is thin, say so plainly and keep the arc short | Opener that is still scored, covering F6 |
| G2 | "What is something from Stripe you have read or used lately that you found interesting?" | CO | [generic] | Pick something you actually looked at and say what you noticed. If nothing comes to mind, say so plainly, then name what you would look at first | Casual question that scores genuine interest. The pack cannot name current Stripe material |
| G3 | "What does a great week look like for you in a role like this?" | JD | [generic] | Describe it in your own terms. Keep it concrete about the kind of work, not claims about the past | Casual register, scored for fit with the role family, covering F7 |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 launches and cadence | A1, E1, F2 |
| F2 metrics | A2, D1, D2, D3, F3 |
| F3 process improvement | A1, A3, B4, D3, F3 |
| F4 customer and go-to-market feedback | A3, C2 |
| F5 influence without authority | B4, C1, C3, E1, E2, E3 |
| F6 communication | C1, F1, G1 |
| F7 ambiguity and shifting scope | A1, G3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would make the first 90 days in this role a clear success from your side?" | Shows you are already thinking about delivery, and gives you the interviewer's own bar to prepare against |
| R2 | "How do product teams currently decide when to bring in product operations, and when not to?" | Surfaces the seam and the political reality of the role without presuming either |
| R3 | "What is the hardest process problem across the product organization right now?" | Invites a live problem you could be asked to help with, and signals you want the real one |
| R4 | "How is the success of this role measured, and by whom?" | Connects to the metric questions and shows you expect to be held to something |
| R5 | "What do you wish you had known when you started working with this group?" | Collegial, and often gets candid detail a polished answer would not |
| R6 | "If we were peers, what could a new person do in the first month that would genuinely help your team?" | Use only if the interviewer turns out to be a peer: it is the reciprocity question |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None listed | No quoted sentence of yours exists for an inflated form to stretch, and silence is an answer slot, not a prohibited claim | Until a CV is shared, the pack coaches no claim about your past. Every slot and scaffold above ends in the branch where the thing was not yours or did not happen |

## Sources

Provided documents: none beyond your message naming the company, the role and the final round.

Searches sent (all four were refused by the host, none returned anything):

- Stripe operating principles values: refused
- Stripe interview process Product Operations Manager final round: refused
- Stripe strategy 2026 news: refused
- Stripe Product Operations Manager job description: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have moved the values cheat sheet and given VAL questions a named value to map. The cheat sheet is dropped and C1 to C3 are `[generic]` |
| 2. Stripe interview process, role family | unavailable | Would have established the loop and the persona weights. The Generic archetype and flat weights stand in |
| 3. Stripe strategy and recent news | unavailable | Would have grounded A3, B2 and G2 in current priorities. They stay `[generic]` and the homework is yours |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Would have turned F1 to F7 into quoted `[inferred]` requirements. They are plain `[generic]` prose instead |

## Upgrade menu

- Your CV → F1 to F7 get quoted evidence, confidence bands and gap types, the bank gets story-mapped answers, and B1 is rebuilt around your real largest gap
- The job description text → the seven `[generic]` requirements become `[grounded]` and JD questions get quoted sources
- Your interviewer's name and role → an interviewer read, persona weights adjusted from their public footprint, and a tailored reverse question
- The recruiter's guidance, including any pre-declared deliverable such as a presentation → coverage of the stated focus areas and a build section for each deliverable
- Your schedule, if the final is several sessions → per-session mini-packs with their own weights
- Permission for web search in this session, or a deeper research pass of up to 6 more searches and 2 more fetches, several more minutes → Stripe's published values, a current strategy brief, loop reports and a values cheat sheet
- A `tuesday-dossier.md` from an earlier session → verified evidence, per-gap strategy limits and a prohibited-claims list, none of which is needed to use this pack
