# Interview prep pack: Product Manager, Platform APIs at Quartzline

Interviewer: the hiring manager (no name given). Round: one 45-minute conversation on Thursday.

## How to use this pack

Personas describe how a question is asked; types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether the claims about your work survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

The question named as this pack's highest-ROI prep is A1. The underwriter's dossier named that objection, and it will be asked in some form.

## Fit snapshot

Requirement text comes from the dossier's `role_profile`, which stands as the job description. Confidence on F1, F2 and F6 is the underwriter's grading. On F3, F4 and F5 it is the band the dossier gives the quoted claims, and the gap type says how far those claims reach.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [grounded] | transferability | Strategy is bridge, with the limit named: the material is integration leadership, adjacent to the job and not product management experience, and the bridge never calls it that. Hold the first quote at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." The second quote is rehearsed in C3 and not used to answer the title question. Plain acknowledgment, sourced by `prohibited_claims`: "Having held a product manager title or role" — "I haven't held a product manager title." |
| F2 | "Owning a roadmap and prioritization authority (R1 sub-claim)" — dossier uncertain_or_weak_areas | none given | none | [grounded] | capability | The dossier's `acknowledge_gap` strategy is binding, so there is no bridge and no slot. Words, sourced by `acknowledge_gap` and by `prohibited_claims`: "Having owned a product roadmap" — "I haven't owned a product roadmap." Then a plan stated as a plan: learn which decisions belong to the role alone and which to the squad leads, and learn how adoption is measured today. Never a claim to roadmap or prioritization work |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | high | [grounded] | transferability | The band grades the integration claim. Your material says integrations led onto the vendor's REST APIs and a playbook written, not an API or platform product shipped, and the words stay at that scope. Answer slot: the requirement's "Shipped API or platform products" makes a probe likely. If you shipped an API or platform product, say which and what was yours, in your own words; if you did not, or it was not yours, say so plainly and return to the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | high | [grounded] | discovery | The quotes touch REST APIs and architecture and do not show whether API docs or schemas were part of the work. Answer slot: "API docs, schemas" makes a probe likely. If you worked with either, say how, in your own words; if you did not, say so plainly and stay with the REST integrations you led |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | The quotes show clients and a feed to product, and do not show engineering or sales. The second quote is confirmed with limited inspectable proof, so volunteer the limit before a prober extracts it. Answer slot: the requirement names engineering and sales. If you worked with either, say how and what was yours; if you did not, say so plainly and return to the client work the quotes carry |
| F6 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | No quote speaks to this, and the strategy is clarify. Answer slot: "Agile delivery experience" makes a probe on how you define it likely. If you have worked that way, say how, in your own words; if you have not, say so plainly, and say what you would want to confirm about how Quartzline defines it |

## Persona table

The loop rests on your own words: one 45-minute conversation with the hiring manager. Weights start from that relationship's prior, which is Case/Strategist plus Skeptic, then move with the dossier's findings.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the title and roadmap gaps | High. The hiring-manager prior favors it, and the underwriter named an objection aimed at F1 and F2 | Concede the gaps first and plainly, hold the adjacent quote at its scope, and close with a ramp plan. Bank A |
| Case/Strategist | Live problems from the role: partner onboarding, breaking changes, adoption metrics, week one | High. Hiring managers buy capability on their own roadmap, and these questions need no past claims | Clarify, then objective, approach, metrics and risks, thinking aloud, and challenge one premise respectfully. Bank B |
| Data-Driven Prober | Reads the quoted claims line by line and asks how the 30+ was counted | Medium. A figure and a medium-confidence claim sit in the verified evidence, so a probe is likely | Know what you can and cannot say about how each claim was counted, and say plainly when you do not know. Bank C |
| Conversational | A friendly opener: "walk me through the journey" | Medium. It opens most 45-minute conversations and is still scored | A pre-built 90-second arc that stays inside the quotes. Bank D |
| Pressure | Time-boxes you on "why you over a PM with three years of the job" | Low. Nothing signals a stress style, but the gap invites one pointed moment | Pause, restate, hold through two follow-ups, then concede specifically. Bank E |
| Peer Evaluator | Squad-lead seam and credit questions | Low. The squad leads are peers, but they are not in this conversation | Offer seam principles rather than pretend to know the seam. Bank F |
| Values/Behavioral | Scenario probes against published values | Low and unweighted. No values-style round is detected, because your note names one conversation with the hiring manager and no published values were obtained | F2 carries one behavioral scaffold, and a values bank waits on the upgrade menu |

## Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; `prohibited_claims`: "Having held a product manager title or role"; `prohibited_claims`: "Having owned a product roadmap"; `prohibited_claims`: "Having set prioritization for an engineering squad" | The highest-ROI rehearsal in the pack, worded as the underwriter wrote it. Concede first, before you are pressed: "I haven't held a product manager title, and I haven't owned a product roadmap." Then the bridge at the quote's own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Name the limit yourself: that is integration leadership, adjacent to this job and not product management, and you let them draw the inference. Close with a plan in future tense: learn which decisions are the role's alone and which sit with the squad leads, and learn how adoption is measured today. Follow-up 1, "three years of the actual job is what we asked for": return to the concession and the quote, and do not argue the years away. Follow-up 2, "what breaks first on day one?": name roadmap decisions and the call between competing asks as the new part, and give the same plan. Follow-up 3, "tell me about a time you told an engineering team no": if your material carries no such time, say "I haven't set prioritization for an engineering squad," and stop rather than reach for a story | F1 and F2 are where the role's mandate presses hardest, and the underwriter derived this objection from evidence you confirmed. JD because it scores the stated requirement, with the pressure carried by the Skeptic's delivery |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] `acknowledge_gap`; `prohibited_claims`: "Having owned a product roadmap" | Answer with the real gap, not a disguised strength: "I haven't owned a product roadmap," then what you would do first, stated as a plan. Do not close with a story that makes the gap smaller. A weakness named plainly before they name it is the credibility gain | F2 is the dossier's acknowledged gap, and this stem is its most direct form. JD because it asks you to rank the role's demands against your own material |
| A3 | "Tell me about your experience with agile delivery." | JD | [grounded] | Open prompt on the requirement's own wording, so the guidance is the F6 slot. If you have worked in agile delivery, say how and what your part was, in your own words; if you have not, say so plainly, and say what you would want to confirm about how Quartzline defines it. Do not offer ceremony names or tools you have not used | F6 is a discovery row, and no quote establishes the practice, so the honest answer is for you to supply or decline. JD because R5 is a stated preferred requirement |
| A4 | "Tell me about an API or platform product you've shipped." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Open prompt on R2's wording. Story-map only what the quote states: you led the integrations, end to end, across scoping, requirements, architecture, UAT and go-live. Answer slot: if you shipped an API or platform product, say which and what was yours; if you did not, or it was not yours, say so plainly and stay with the integrations you led. Hold the integration story, and do not let it drift into a product you built | F3 is a transferability row and the likeliest R2 probe. JD because R2 is a must-have |
| A5 | "Why this move, and why now?" | JD | [generic] | Your reason is yours, and no quote carries one. Selection criteria: it should connect to work you actually did, name what you want next in the role's own terms, and hold up if they ask why not a role closer to integrations. If no clear reason comes to mind, say so plainly and give the nearest honest thing, or what draws you to this job description | Motivation consistency is what a Skeptic scores once the gap is on the table. JD because it tests fit with the role's direction, and the answer cannot be supplied by this pack |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner tells us our API's onboarding takes too long and they are weighing a competitor. What do you need to know first, and what do you do?" | CASE | [generic] | Clarify before structuring: which partners and which stage, how onboarding time is measured today, and what changed. Then the objective, a hypothesis with a way to test it, a discovery step with the partner, a metric, and a risk. Challenge one premise respectfully, such as whether the stated complaint is the real one. The question needs no claim about your past, so the guidance makes none | The role includes discovery with integration partners, and a live onboarding problem tests whether you clarify before answering. CASE because it is a live problem; generic because it is a pattern for the problem and no fact about this employer |
| B2 | "Two partners want opposite breaking changes to the same endpoint, and the squad leads disagree on the cost. Walk me through how you decide." | CASE | [generic] | Ask first who decides, since the answer shapes everything and is the question you most need answered. Then separate each partner's request from its underlying need, set decision criteria before options, and agree the tradeoff with the squad leads on evidence. Say what you would record and how you would communicate the decision. Make no claim about having decided such a thing | The decision-authority question is open in the dossier, and this case probes it from the candidate's side. CASE because it is a live conflict in the role, with F2 as the gap it presses on |
| B3 | "How would you define and track adoption for our partner API platform? Where would you start?" | CASE | [generic] | Start by asking what exists today and what the current baseline is, because the dossier flags that as unknown. Then offer candidate measures and say which one you would defend least. Say how you would validate the choice with partners before committing. No figure or measure is supplied here, because none is yours yet | Adoption metrics are a named responsibility and the baseline is an unresolved risk, so a hiring manager will test this directly. CASE because it asks for structure and reasoning on the role's own problem |
| B4 | "You have two squads and your first week. What do you do?" | CASE | [generic] | A ramp plan in future tense: listen first, with the squad leads and with partners, learn which decisions are yours and which are theirs, find the adoption baseline, and read what exists before proposing anything. Say what you would not do yet. This is where the acknowledged roadmap gap becomes a credible plan | F2 has a plan and no bridge, and this is the question that plan answers. CASE because it asks you to structure the first week |
| B5 | "Sales has promised a partner a date for a feature engineering hasn't scoped. How do you handle it?" | CASE | [generic] | Clarify what was promised, to whom and in what words. Then align with sales and engineering on what is true now, set the partner's expectation honestly, and decide what you would change so it does not recur. The case needs no past, so tell no story as though it were yours | R4 names engineering, sales and customers together, and this case puts all three in one problem. CASE because it is a live conflict in the role |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ integrations. How was that number counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend the number in your own words: what counted as one integration, what the count is sensitive to, the assumption you would defend least, and which part was yours. The pack supplies none of these. If you do not know how a part of the count was derived, say so plainly. The figure counts integrations, so keep it attached to them | F1 and F3 both rest on this figure, so a Prober starts here. EXP because it tests whether the claim survives scrutiny |
| C2 | "Walk me through the integration playbook you wrote — what's in it, and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Say that you wrote it and that your team uses it, in first person and in your own words. What is in it is yours to describe from the document itself, and the pack supplies no contents. The playbook is inspectable, so offer to walk through it | The playbook is the inspectable artifact behind F3 and F4, which makes it the strongest thing a probe can land on. EXP because it tests attribution |
| C3 | "Walk me through the quarterly sessions where you fed client evidence to product." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Expect a probe: this claim is confirmed with limited inspectable proof, so volunteer the limit before it is extracted. Say what the sessions were, as the quote states, and what you can show of them. If asked what came of the evidence and you do not know, say so plainly. Do not describe it as owning the roadmap | F5 and F1 share this quote, and the medium band names it as the seam a prober finds. EXP because it checks a claim with thin proof behind it |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | A 90-second arc in three beats: the integrations you led, the playbook you wrote, and where you want to go next in your own words. Stay inside those two sentences for the middle, and add no title, years or employer the quotes do not carry | A casual opener is still scored, and F1 and F3 are the claims it should land first. EXP because it tests the account of your own work |
| D2 | "What have you been looking at lately in API design or documentation?" | JD | [grounded] | Open prompt on R3's wording. Pick something you have actually read or used, and say what you took from it. If nothing comes to mind, say so plainly, then give the nearest honest thing from your REST integration work, or how you would get up to speed. Name no tool you have not used | F4 is a discovery row, and a casual question on a JD topic is how it gets probed. JD because R3 is an important requirement |
| D3 | "What's drawing you to Quartzline specifically?" | CO | [generic] | No company research was available for this pack, so build the answer from the job description alone: the partner-facing platform, working with integration partners, and adoption as a measurable outcome, if those are true for you. Say that you want to learn more, and ask them something real. Do not claim to know their strategy or customers | CO is thin without research, and the pack says so. A rapport-style interviewer weights this answer, and a generic one is the common miss |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; `prohibited_claims`: "Having held a product manager title or role" | Pause and restate. Hold the quote at its scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Concede the title once and specifically: "I haven't held a product manager title." Hold through two follow-ups by returning to the quote, never by adding to it, and do not claim to be the better candidate | A compressed A1 under time pressure, so the hold-then-concede structure is what is scored. JD because it tests the stated requirement |
| E2 | "That integrations result — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold what the quote says: you led them. Then say which part was yours and which was shared or done by others, in your own words. If parts were shared, say so plainly and name them. Conceding a specific shared part reads as credibility, not weakness | F1 and F3 rest on the word "led", and this is the stem that tests it. EXP because it checks attribution |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our two squads each have a lead with strong views. Where is the seam between you and them, and what happens when you disagree?" | CASE | [generic] | Offer seam principles rather than pretend to know the seam: who decides what should be agreed up front, decisions made on partner evidence, and a way to escalate. Then ask where the line sits today, since the dossier flags it as unresolved. Tell no disagreement story you have not got | The squad leads are the people most affected by the authority question, and a hiring manager may probe how you would meet them. CASE because it asks about a future seam and no past |
| F2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection criteria: pick a time when work crossed team lines and credit was shared, with a named piece that was yours and a named piece that was another team's. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. Say "we" for context and "I" for your contribution | Collegial credit-sharing is what a peer probe scores, and it tests attribution honesty from another angle. EXP because it asks about your own history, which this pack cannot supply |

## Requirement coverage

| Requirement | Questions |
|---|---|
| R1 "3+ years product management experience" | A1, A2, A5, D1, E1 |
| R1 sub-claim: roadmap and prioritization authority | A1, A2, B2, B4 |
| R2 "Shipped API or platform products" | A4, C1, E2 |
| R3 "Technical fluency: API docs, schemas" | C2, D2 |
| R4 "Stakeholder management across engineering, sales, customers" | B5, C3, F1 |
| R5 "Agile delivery experience" | A3 |

## Reverse questions

The first two come from the dossier's unresolved risks, written from the risk's own hypothesis.

| # | Question | Why it lands |
|---|---|---|
| G1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The posting asserts the authority and nothing shows it, so this settles a risk you need answered before accepting, and it reads as diligence |
| G2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption is a named responsibility with no stated baseline, and your answer tells you what you would be judged against |
| G3 | "How do the squad leads and the PM usually resolve a disagreement about what ships first?" | It tests the same authority risk from the working side and shows you are thinking about the seam |
| G4 | "How do the two squads run delivery day to day?" | It resolves F6 from the employer's side, so you learn what "Agile delivery experience" means here before you answer for it |
| G5 | "Given my background is integration work and not product management, what would you want me to ramp on first?" | It names the limit before you are asked and turns the hardest objection into a plan you build together |
| G6 | "What would a good first 90 days look like for the person in this seat?" | It surfaces the hiring manager's real measure of success and gives you something concrete to answer against |

## Prohibited claims

All three come from the dossier's `prohibited_claims`, which bind every cell of this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| "Having held a product manager title or role" | Dossier `prohibited_claims` | F1's quote at its own scope, with "I haven't held a product manager title." No slot |
| "Having owned a product roadmap" | Dossier `prohibited_claims` and the `acknowledge_gap` area | "I haven't owned a product roadmap," then a ramp plan stated as a plan. No bridge and no slot |
| "Having set prioritization for an engineering squad" | Dossier `prohibited_claims` | "I haven't set prioritization for an engineering squad," then stop. No bridge and no slot |

## Sources

Provided: the dossier `tuesday-dossier.md`, pasted into the conversation, version 1.1, generated by job-underwriter on 2026-08-14 (a decision of `conditional_go`). The pack consumed three of its sections: `handoff_to_mock_interview`, which supplied the verified evidence, weak areas with strategies, the named objection, risks, employer questions and prohibited claims; `role_profile`, which supplied the requirement text; and `decision`, as context only. The dossier has no `evidence_map`, `evidence_state` or `risk_register`. Your own words supplied the round: one 45-minute conversation with the hiring manager, on Thursday.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Queries sent, all refused because the permission to search was not granted:

- "Quartzline company values" — refused
- "Quartzline interview process product manager" — refused
- "Quartzline API platform strategy news" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Search refused. It would have moved VAL questions themed from published values and a values cheat sheet if a values-style round were documented |
| 2. `Quartzline interview process product manager` | unavailable | Search refused. It would have confirmed or reweighted the loop. Weights rest on your own words instead |
| 3. `Quartzline strategy` / recent news | unavailable | Search refused. It would have grounded D3 and given the CASE bank current company vocabulary, so those cells are `[generic]` |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there is no query to form |
| 5. representative `Product Manager` JD | skipped | The dossier's `role_profile` requirement text fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewer's name → an interviewer read, persona weights from their public footprint, and a reverse question tied to their own path
- The recruiter's prep email → coverage of any focus areas or deliverable the recruiter has declared
- Permission to search the web → a re-run of the three refused L1 searches (company values, loop, strategy), which would ground D3 and add current vocabulary to bank B; a deeper pass would add up to 6 more searches and 2 more fetches, several more minutes
- Session agendas or the written client-evidence summaries you sent to product → the C3 claim could move from `medium` toward `high` on F1 and F5
- Your answers to the slots in F3, F4, F5 and F6, said in your own words in a message → those rows regenerate on what you actually did
- How much prep time you have before Thursday → a prioritized schedule tied to question IDs
