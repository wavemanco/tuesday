# Engineering Manager, Larkfield Systems: three-round interview pack (loop mode)

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, ~600 people), as described in your message.
**Candidate:** Yusuf.
**Rounds, in order:**

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| R1 | Tuesday | Director of Engineering (hiring manager, your would-be boss) | 45 min | Hiring manager |
| R2 | The Thursday after | Panel: two staff engineers and a product manager | 60 min | Panel, blending peer and cross-functional |
| R3 | The following Monday | VP Engineering, described by the recruiter as "values and leadership philosophy" | 30 min | Skip-level and executive |

No interviewer names were given, so no interviewer read is included. Version 1; nothing regenerated yet.

## How to use this pack, and the type key

The pack is one shared fit snapshot, then a mini-pack per round, then shared coverage, prohibited claims, sources and an upgrade menu. Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the values being probed, not generic virtue |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | The listed job: can you do it, gaps included |
| CO | Homework: the company, its strategy, its domain |
| CASE | A live problem from the role, reasoned through aloud |

Question IDs read round, persona letter, number: R1-A1 is round 1, persona A. Persona letters are fixed across the pack: A Skeptic, B Case/Strategist, C Data-Driven Prober, D Conversational, E Peer Evaluator, F Pressure, G Values/Behavioral.

**Highest-ROI prep in the whole pack: R1-A1.** The objection that you have not owned a hardware-adjacent roadmap, in a role that partners with hardware on the roadmap, is the one most likely to be asked in some form, and you have already stated it yourself. It returns in R2-E1 and R3-F1. Rehearse it until it is boring.

## Prep triage

Sized to three rounds across about two weeks. The few things done well, in order:

1. **Before Tuesday:** say the two plain acknowledgments aloud until they are steady: "I haven't managed managers" and "I haven't owned a hardware-adjacent roadmap". Then run R1-A1 and R1-A2 through the hold-then-concede structure.
2. **Before Tuesday:** write down, in your own words, what you know about how the 60% and the "about 40 interviews" were counted. R1-C1 and R1-C2 turn on it, and "I don't know how that was counted" is an honest branch.
3. **Before Tuesday:** pick two or three reverse questions from R1 and decide which you most need answered.
4. **Between Tuesday and Thursday:** note what the Director tells you about squad structure and the hardware seam. It changes R2 and R3, and the upgrade menu says how to feed it back.
5. **Before Thursday:** R2-E1, R2-C1, R2-C2 and R2-C3.
6. **Before Monday:** R3-F1, R3-G1, R3-G2 and R3-F2.

Everything else is insurance.

## Fit snapshot (shared by all three rounds)

Requirements are quoted from the role description in your message. Evidence is quoted from your own message. "Role description" below means that sentence of your message, which is a short summary and not a full job description.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message; "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | medium | [grounded] | transferability | Your material says a team lead of six, not two squads, and the role description does not say whether the squads have leads of their own. Words at the quote's scope: "Three of my nine years in engineering have been as a team lead of six." The stated negative gives a plain acknowledgment: "I haven't managed managers." Answer slot: the two-squads line makes a probe on how you would divide your attention likely. If your team of six ever worked as more than one group or stream, say how, in your own words; if it did not, say so plainly and stay with the team of six |
| F2 | "own delivery" — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | discovery | The quote shows a reliability quarter pushed through against roadmap pressure and says nothing about how delivery was planned or tracked; it is a message line with nothing inspected behind it, so expect a probe on it and on the 60%. Answer slot: the delivery line makes a probe on how that quarter was planned likely. If you can say how it was planned and who decided what went into it, say so in your own words; if you cannot, or it was not yours to decide, say so plainly and stay with what you did in it |
| F3 | "hiring" — role description | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap in terms, but a message line with nothing inspected behind it, so expect a probe. Lead with the loop in the quote's own terms: you run it, for backend roles. The 40 stays attached to interviews. The quote does not say whether they were interviews you conducted or the loop's total, so take the lower reading unless you know |
| F4 | "growth for 11 engineers" — role description | none given | none | [grounded] | discovery | Your material is silent on developing engineers, and silence is not an absence. Answer slot: the growth line makes a probe on how you have helped engineers develop likely. If you have, say what you did and what changed for the person, in your own words; if you have not, or it was not yours, say so plainly and say how you would approach it |
| F5 | "11 engineers" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says a team of six; the role's eleven is a different size. The bridge stays at the quote's scope: a team lead of six. Answer slot: the eleven makes a probe on what changes beyond six likely. Say what you expect to change at that size, in your own words, as an expectation and never as a past |
| F6 | "partner with hardware and product on roadmap" — role description (hardware half) | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. The quote speaks to owning a roadmap, not to working alongside hardware teams; on the second your material is silent, and R1-A1 holds that slot |
| F7 | "partner with hardware and product on roadmap" — role description (product half) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | The quote shows roadmap pressure pushed against and does not say who applied it or whether it came from product. Derivation: the pressure is the only roadmap contact in your material. Answer slot: the product-partnership line makes a probe on who the pressure came from likely. If you can say who applied it and what was said back, say so in your own words; if you cannot, or it was not a conversation, say so plainly and stay with the quarter |
| F8 | "building device-management services" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | low | [inferred] | discovery | The quote names your current employer's domain and nothing about device management. Derivation: the domains differ, and nothing shows whether any work is close to the role's. Answer slot: if any of your work is close to managing fleets of devices, say what it was and which part was yours; if none is, say so plainly and say how you would close the distance, as a plan |

No row is a gate: the role description states no eligibility, location, pay, schedule or credential term, so nothing here is surfaced as `hard_gate`.

---

# Round 1: Tuesday, Director of Engineering (hiring manager, 45 min)

## Persona weights

The loop is the one you described, with three sessions and who runs each, so no archetype fallback is used. Weights start from the hiring-manager prior (live problems on their roadmap, plus derisking gaps) and adjust for your message: it states two negatives and two figures.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of the two gaps your own message names, by the person deciding | High. The hiring-manager prior is derisking gaps, and you have stated two, so the probe is close to certain | R1-A1: concede plainly, give a ramp plan as a plan, hold through two follow-ups, add nothing the quotes do not carry |
| Case/Strategist (B) | Live problems on the two squads' roadmap | High. The same prior, and the role description is built around delivery and roadmap partnership | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober (C) | Your two figures taken to their assumptions | Medium. No interviewer profile exists to lift it, but the 60% and the "about 40 interviews" are the kind of figure a Director opens | The four defend-the-number slots in your own words; "I don't know how that was counted" is allowed |
| Conversational (D) | The opening journey question | Low in weight, but scored. It sets the frame for everything after | A 90-second arc built only from quoted facts |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "You haven't owned a hardware-adjacent roadmap, and this role partners with hardware on the roadmap. Why should I believe you can do that?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The highest-ROI rehearsal in this pack. Concede first, in the sentence your message gives you: "I haven't owned a hardware-adjacent roadmap." Then stop and let them respond. If asked for more, the nearest thing your material carries is the reliability quarter, at its own scope: on-call burden dropped 60% after you pushed that quarter through against roadmap pressure. Offer it as roadmap-tradeoff experience, never as hardware experience. Then give a ramp plan said as a plan: the first things you would ask hardware counterparts, whom you would spend time with, what you would read, in your own words. Answer slot: if you have worked alongside a hardware team in any form, say how; if you have not, say so plainly and stay with the plan. Hold through two follow-ups by returning to the concession and the plan. Never add to the quarter | F6 is the plainest gap in the material and the role's roadmap line presses on it hardest, so this objection arrives in some form. JD because it scores a stated responsibility; the delivery is Skeptic |
| R1-A2 | "You've led a team of six. This role is two squads and eleven engineers, and you haven't managed managers. What changes for you?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers and never owned a hardware-adjacent roadmap" | Start from the quote at its scope: three of your nine years in engineering as a team lead of six. Concede in your message's own words: "I haven't managed managers." Answer slot: say what you expect to change at eleven engineers across two squads, in your own words, as an expectation and never as a past, and name the part you expect to be slowest to learn. Then turn it into a fact-finding step: whether the two squads have leads of their own is not in the role description, so ask the Director (see R1-V1). Hold through a second probe by repeating the concession, not by adding to the six | F1 and F5 together are the scale-and-structure objection a hiring manager prices first. JD because the requirement is stated; Skeptic delivery |
| R1-A3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Pick the one you honestly believe is weakest. Your own message names two. Name it in one sentence, then give the ramp plan as a plan: what you would do in the first weeks to close it. Do not volunteer a third weakness your material does not show, and do not shrink the one you pick. A candid, specific answer is the point | F1 and F6 are the stated gaps, so this stem is a free rehearsal of the same honesty. JD because it scores the listed job; Skeptic delivery |
| R1-A4 | "Tell me about a time you helped an engineer grow." | JD | [grounded] | Your material carries no sentence on this, so this is a selection scaffold. Pick a time that has a named person, what you did yourself, and what changed for them. Say "I" for your part and "we" for context. Answer slot: if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach growth for eleven engineers | F4 is silence, not absence, and the role description names growth outright. JD because the requirement is stated, with EXP delivery |
| R1-B1 | "You inherit two squads. One keeps missing dates because hardware samples arrive late, and the other is fine. What do you need to know first, and what do you do in your first month?" | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Clarify first: what "missing dates" means, how late the samples are, what the squad does while waiting, and what each squad's plan assumed. Then objective, segmentation, approach, metrics, risks, thinking aloud. Challenge one premise respectfully, for example whether the samples are the cause. Name what you would ask hardware before changing anything | F6 and F7 are the roadmap-partnership gaps, and a live problem lets you show structure where you cannot show experience. CASE because it is a decision, not a history; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| R1-B2 | "One of your services mishandles an update for some of the devices it manages, and some of those devices sit in customers' plants. Walk me through the first hour and the follow-up." | CASE | [generic] | No claim about your past is needed, so the guidance makes none. Structure it: contain and protect customers first, communicate to hardware and product and customers, diagnose, then the follow-up that changes the system. Clarify before you structure: how many devices, what the failure does, whether it can be rolled back. If you want to draw on a past incident, it has to be one you can name; your message carries none, so otherwise stay with how you would run it | F8 is the domain gap, and an incident case tests judgment where domain experience is thin. CASE with a reliability flavor; `[generic]` because no research on Larkfield's services ran |
| R1-B3 | "You have one quarter of capacity. Product wants new features, hardware needs a change for a new device model, and on-call is noisy. How do you decide what goes in?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | State your decision criteria in your own words first. If you draw on your own history, say it as the quote does: on-call burden dropped 60% after you pushed a reliability quarter through against roadmap pressure. That is the whole story your material carries. Answer slot: the roadmap-partnership line makes a probe on who pushed back likely. If you can say who applied the pressure and what you said back, say so in your own words; if you cannot, or it was not a conversation, say so plainly and stay with the quarter | F2 and F7 are where this case meets your evidence, and it is the one case your material can partly answer. JD content (own delivery, roadmap partnership) with CASE delivery |
| R1-C1 | "On-call burden dropped 60%. How was that counted, and how much of it was the reliability quarter?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Say it in the quote's own order: dropped 60% after you pushed the quarter through. The word is "after", so do not upgrade it to "because". Answer slots, each in your own words: how the 60% was counted, if you know; what it is sensitive to; the assumption behind it you would defend least; which parts were yours and which were your team's. If you do not know how it was counted, say so plainly. Naming the weakest assumption before they do turns a gotcha into credibility | F2's figure is the magnet target for a prober, and the guidance stops at the quote. EXP because it tests attribution |
| R1-C2 | "You said about 40 interviews last year. Whose interviews were those, and how does your loop work?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say the quote at its scope: you run the hiring loop for backend roles; about 40 interviews last year. Keep 40 attached to interviews. Answer slots, in your own words: whether the 40 were interviews you conducted or the loop's total; how it was counted. For the loop itself: if any stage of it was yours to set, say which and how you decided; if the loop was set before you and you ran it, say so plainly and describe how you ran it. If you do not know which reading of 40 is right, say the lower one | F3's figure is a defend-the-number target, and "whose interviews" is the first thing a prober asks of it. EXP because the claim is yours to attribute precisely |
| R1-D1 | "Walk me through your journey, and tell me why Larkfield." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc made only from quoted facts: nine years in engineering, three of them as a team lead of six, currently at a payments company. Your message also carries the hiring loop and the reliability quarter, so those are the facts available to land. Answer slot: why management, why industrial IoT and why now are your reasons, in your own words; this pack supplies none. For the Larkfield half, read Larkfield's own pages before Tuesday, since no research on them ran | An opener is still scored, and F8's domain gap makes the "why here" half the part to rehearse. EXP for the journey, with a CO element |

## Reverse questions (R1)

| # | Question to ask | Why it lands |
|---|---|---|
| R1-V1 | "Do the two squads have leads of their own, and where would you expect me to spend my first month?" | Settles whether F1's managers gap applies and how big F5's step is. The answer reshapes the Thursday and Monday prep |
| R1-V2 | "Where does the hardware roadmap meet ours today, and what has been hard at that seam?" | Turns F6 from a defensive topic into a shared problem, and tells you what R1-B1 is closest to |
| R1-V3 | "What would you want to see from me by the end of the first quarter to say this hire is working?" | Gives you the Director's own success measure, which no research could supply |
| R1-V4 | "Is the team of eleven fully staffed today, and would I be hiring?" | F3 is your clearest strength, and this finds out whether the role uses it |
| R1-V5 | "How is on-call handled for these services today?" | Connects to F2 without claiming more than the quote carries |
| R1-V6 | "What is the biggest risk in this role that we have not talked about?" | Invites the objection you have not rehearsed, while you can still answer it |

---

# Round 2: Thursday, panel of two staff engineers and a product manager (60 min)

## Persona weights

Panel rule: blend the top two personas of each member's relationship. No names were given, so the assignment is by role. The two staff engineers sit under the peer prior (Peer Evaluator, Prober). The product manager sits under the cross-functional prior (Values/Behavioral, Conversational). Objections from Round 1 return in collegial packaging, which earns the Skeptic a small slot. The loop is the one you described, so no archetype fallback is used.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (E) | Seam-splitting with hardware and product, "what would you need from us", credit and disagreement | High. Peer prior for the staff engineers, plus the product manager's stake in the roadmap seam | Reciprocity: what you bring, as facts at the quote's scope. Offer seam principles, not a pretended knowledge of the seam |
| Data-Driven Prober (C) | The reliability quarter, the hiring loop and the payments-to-IoT distance, taken technical | High. Second persona of the peer prior, and staff engineers will test depth | Know what you can and cannot say; say plainly where you do not know |
| Values/Behavioral (G) | Scenario probes about disagreeing with product and delivering unwelcome news | Medium. Cross-functional prior for the product manager | Choose stories where the hard truth landed; where your material shows none, say so rather than supplying the ending |
| Conversational (D) | Friendly questions about IoT interest | Low to medium. Second persona of the cross-functional prior | Treat casual questions on the role's domain as scored |
| Skeptic (A) | Your gaps asked as "what would worry you" | Low to medium. Collegial return of the R1 objections | Same plain acknowledgments as R1, shorter |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-E1 | "Our squads depend on a hardware team we don't control. Where is the seam between you, hardware and us, and what happens when we disagree?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Do not describe a seam as though you had worked it: your message says you have not owned a hardware-adjacent roadmap. Say that you do not yet know where this seam sits, offer two or three principles for how a seam like this should work, in your own words, and ask them to correct you. The disagreement half is a process answer: who decides, on what evidence, and what gets written down. Answer slot: if you have worked alongside a hardware team in any form, say how; if you have not, say so plainly and stay with the principles | F6 returns here in collegial packaging, and the role description's roadmap line is the raising source. JD content, with Peer delivery |
| R2-E2 | "What would you need from us in your first month, and what would we get from you?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Give the need and the offer as separate halves. Need: your list, in your own words. Offer: facts at the quotes' scope, with no inference stated on your behalf. You run a hiring loop for backend roles, and your team's on-call burden dropped 60% after you pushed a reliability quarter through against roadmap pressure. Let them draw the conclusion; a conclusion you assert about yourself is the one that gets tested | F3 and F2 are the only strengths your material quotes, and a reciprocity answer is where they belong. JD because it tests partnership fit, with Peer delivery |
| R2-E3 | "Tell me about a time a senior engineer disagreed with a decision of yours." | VAL | [generic] | Your material carries no sentence on this, so this is a selection scaffold. Pick a time that has a named disagreement, what you did yourself, and a working relationship intact afterward. Show spine and tact together, and say how credit was handled. Answer slot: if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The peer prior includes credit and disagreement probes, and the stem comes from the Peer Evaluator persona. VAL because it scores behavior with an equal; `[generic]` because no sentence of yours carries it |
| R2-C1 | "Tell me about the reliability quarter you pushed through." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped to the quote's beats only: a reliability quarter, pushed through, against roadmap pressure, and on-call burden dropped 60% after. Answer slot: staff engineers will probe the technical content. If you can say what the quarter's work was and which part you did yourself, say so in your own words; if your part was something else, or you cannot recall the detail, say so plainly and stay with the beats above. Hold through the third question by repeating what you did, not by adding to it | F2 is your strongest quoted story and the first place staff engineers will look for depth. EXP because it tests what was yours |
| R2-C2 | "Tell me how you run a hiring loop for backend roles, from the first screen to the decision." | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Story-mapped to the quote: you run the loop, for backend roles, about 40 interviews last year. Answer slot: staff engineers will sit on your loops, so expect a probe on stages. If any stage was yours to set, say which and how you decided; if the loop was set before you and you ran it, say so plainly and describe how you ran it. Keep 40 attached to interviews | F3 is the one requirement your quote already reaches, so it is where to be most precise. JD because hiring is a stated responsibility, with Prober delivery |
| R2-C3 | "You're coming from payments. What have you worked on that's close to managing a fleet of devices?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Your quote names the domain and nothing about devices, so the guidance makes no claim of similarity. Answer slot: if any of your work is close, say what it was and which part was yours, in your own words; if none is, say so plainly and say how you would close the distance, as a plan: what you would read, whom you would ask, what you would build first in a sandbox. Do not argue that payments systems are the same kind of work | F8 is the domain gap and staff engineers will test it technically. JD because it scores the stated service area |
| R2-G1 | "Tell me about a time you delivered an unpopular truth to a product partner." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The nearest quote is the reliability quarter, but it does not say who applied the roadmap pressure or whether it was product, so use it only if it was. Selection scaffold otherwise: a named truth, the moment you did not fold, and the relationship intact afterward. Answer slot: if the pressure came from product and you said no or changed the plan, say how and what happened, in your own words; if it did not, or you cannot say, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F7's pressure is the one roadmap contact in your material, and the product manager is the person to test it. The stem is from the Values persona; VAL because the product manager is cross-functional |
| R2-G2 | "Tell me about a time you and a product manager disagreed about what to build next." | VAL | [generic] | Your material carries no sentence on this, so this is a selection scaffold. Pick a named disagreement, what each side wanted, how it was resolved and what you did yourself. Say "we" for context and "I" for your part. Answer slot: if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Product partnership is half of F7, and a panel member from product will ask for an instance. VAL because it scores behavior with a cross-functional peer |
| R2-D1 | "What are you actually playing with in IoT these days?" | CO | [generic] | Your material is silent here, so the guidance supplies no interest for you. Answer slot: say honestly what you have read, built or tried, in your own words; if nothing yet, say so plainly and say what you will start with and why. The question is scored even though it is casual | F8 again, asked casually; the stem is from the Conversational persona. CO because it tests homework depth in the role's domain |
| R2-A1 | "From where you sit, what would worry you about someone coming into this seat from a payments company?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Answer as a peer assessing a risk. Name the two gaps your message states, using the same plain acknowledgments as R1, then your ramp plan as a plan. Do not add a worry your material does not show, and do not soften the ones it does | The collegial version of R1-A1 and R1-A2. JD content, Skeptic delivery |

## Reverse questions (R2)

| # | Question to ask | Why it lands |
|---|---|---|
| R2-V1 | "What could a new manager do in their first month that would genuinely help you?" | The reciprocity question for the staff engineers: it asks what you can do for their work, not only what you need |
| R2-V2 | "What is the hardest part of operating these services at the moment?" | Gives you the staff engineers' own picture, which narrows the F8 distance |
| R2-V3 | "How do product and hardware roadmaps get reconciled today, and where does that land on engineering?" | Aimed at the product manager, and the best available test of what R1-A1 will be like in practice |
| R2-V4 | "How do you decide what is a squad's technical call and what is a manager's?" | Shows you will not take decisions that belong to the engineers |
| R2-V5 | "What would you want a manager of these squads never to do?" | Surfaces the failure modes the panel has actually seen |
| R2-V6 | "How do customers experience the device-management service today, and what do they say about it?" | Aimed at the product manager, and a CO question you can ask because no research could answer it |

---

# Round 3: the following Monday, VP Engineering (30 min, "values and leadership philosophy")

## Persona weights

A values-style round is detected here: the recruiter's description, as relayed in your message, names values and leadership philosophy. Larkfield's published values were not in hand (see Sources), so there is no values cheat sheet, and the VAL questions are themed from the recruiter's phrase and the Values persona stems. The skip-level prior adds Case/Strategist and Pressure, and 30 minutes makes time-boxing likely.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (G) | Stories mapped to leadership and values; "tell me about a time" | High. The recruiter described the round as values and leadership philosophy | Map a story only where one of your quoted sentences carries it; otherwise a scaffold ending in its honest branch; "we" for context, "I" for contribution |
| Pressure (F) | Time-boxed challenges to your motives and attribution | Medium to high. Skip-level prior, and 30 minutes forces compression | Pause, restate, anchor in what you stated; hold through two follow-ups, then concede specifically |
| Case/Strategist (B) | Altitude questions about how you would run the org | Medium. Skip-level prior | Clarify before structuring; use the role's own vocabulary |
| Conversational (D) | Why this job, why now | Low. Likely a warm-up or closer | A short, honest arc; never answer the questions slot with "you've covered everything" |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-G1 | "How would you describe your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure"; "I run our hiring loop for backend roles — about 40 interviews last year" | Choose your principles first, in your own words. Then check that each has a sentence of your own material behind it. The two your message carries are the reliability quarter and the hiring loop, at the scope the quotes state. A principle with no story behind it stays out of the answer. Say the principle, then the story, and stop | The recruiter's phrase is the raising source, and the open question is where a candidate over-claims. VAL because it scores whether stated values match past behavior |
| R3-G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The reliability quarter is the nearest quote, but it does not say who applied the roadmap pressure or whether they were leadership, so use it only if they were. Selection scaffold otherwise: a named truth, who needed to hear it, the moment you did not fold, and what happened. Answer slot: if the pressure came from leadership and you pushed back, say how and what followed, in your own words; if it did not, or you cannot say, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The stem is from the Values persona, and your one strong story touches it only partly. VAL because it scores whether the hard truth landed |
| R3-G3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Your material carries no sentence on this, so this is a selection scaffold. Pick a time with a named customer need, the internal metric it cost, and what you decided yourself. Answer slot: if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The stem is from the Values persona and fits an industrial customer base. VAL because the aim is behavior, not slogans; `[generic]` because no sentence of yours carries it |
| R3-G4 | "Tell me about a time you had to make a hard call about someone on your team." | VAL | [grounded] | Your material carries no sentence on this, so this is a selection scaffold. Pick a time with a named stake, what you decided yourself, how you handled the conversation, and where the relationship stood afterward. Answer slot: if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The role description names hiring and growth for eleven engineers, and a VP interested in leadership philosophy will want a people decision. VAL with EXP delivery |
| R3-F1 | "Sixty seconds: why you, when you haven't managed managers or owned a hardware-adjacent roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold, then concede. Pause, restate the question in a clause, then concede in your message's own words: "I haven't managed managers, and I haven't owned a hardware-adjacent roadmap." Then say what you do have, at the quotes' scope and with no comparison to other candidates: three of nine years as a team lead of six, a hiring loop you run for backend roles, and a reliability quarter after which on-call burden dropped 60%. Hold through two follow-ups by repeating, not adding. A claim that you are better than someone who has done those things is not one your material supports | The executive version of R1-A1 under time pressure. JD content with Pressure delivery |
| R3-F2 | "That 60%: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Say it in the quote's own order and stop: on-call burden dropped 60% after you pushed the quarter through. Answer slots, in your own words: which part was yours and which part your team's; how the 60% was counted, if you know; the assumption behind it you would defend least. If you do not know how it was counted, say so plainly. Do not claim the drop as caused by you alone | A stem from the Pressure persona, aimed at F2's figure. EXP because attribution is the point |
| R3-B1 | "How would you decide in your first ninety days whether the two squads are working on the right things?" | CASE | [generic] | No claim about your past is needed, so the guidance makes none. Clarify what "right things" means here and who decides, then objective, segmentation, approach, metrics, risks, thinking aloud. Say what you would ask product and hardware before forming a view, and name one premise you would test | The skip-level prior is altitude, and F1 and F7 mean you will be asked to show it. CASE; `[generic]` because it is a pattern |
| R3-B2 | "What do you think makes device management hard to get right for industrial customers?" | CO | [generic] | No research on Larkfield or its domain ran, so the guidance supplies no facts about either. Answer slot: give your own view in your own words, built from whatever you read before Monday; if you have no view yet, say so plainly and say how you would form one and whom you would ask. Read Larkfield's own product and careers pages first | F8 is the domain gap and a VP is the likeliest person to test the candidate's grasp of it. CO because it scores homework depth; `[generic]` because it is a pattern |
| R3-D1 | "What do you want the next three years to look like, and why this job?" | CO | [generic] | Answer slot: your reasons are yours, in your own words; this pack supplies none. Keep it short and honest, and connect it to the role as described in your message: two squads, delivery, hiring and growth, and partnership with hardware and product. If part of your reason is learning, say so plainly | A closing question likely in a 30-minute executive slot. CO with VAL delivery |

## Reverse questions (R3)

| # | Question to ask | Why it lands |
|---|---|---|
| R3-V1 | "What does Larkfield expect an engineering manager to do that an excellent tech lead would not?" | Tests F1's step directly, and the answer is the VP's own definition of the job |
| R3-V2 | "Can you tell me about a recent decision that shows how engineering leadership here weighs speed against reliability?" | Connects to F2 and uses the values frame the recruiter named |
| R3-V3 | "How does Larkfield develop managers who are growing into larger scope?" | F1's stated negative made into a forward-looking question, with no first-person claim |
| R3-V4 | "Where do hardware and software strategy pull against each other here, and how do you decide?" | The VP's view of the seam you will be asked about in R1 and R2 |
| R3-V5 | "What would success look like a year in, and what would the early signals be?" | Gives you the VP's measure to set against the Director's from R1-V3 |
| R3-V6 | "What do you want to be true of the engineering organization in two years that is not true now?" | A leadership-philosophy question in the VP's own register |

---

## Requirement coverage

| Requirement (role description) | Fit rows | Question IDs |
|---|---|---|
| "Lead two squads building device-management services" | F1, F8 | R1-A2, R1-B1, R1-B2, R2-C3, R3-B1 |
| "own delivery" | F2 | R1-B3, R2-C1, R3-B1 |
| "hiring" | F3 | R1-C2, R2-C2, R3-G4 |
| "growth for 11 engineers" | F4 | R1-A4, R3-G4 |
| "11 engineers" | F5 | R1-A2, R3-F1 |
| "partner with hardware and product on roadmap" | F6, F7 | R1-A1, R1-B1, R1-B3, R2-E1, R2-G1, R2-G2, R3-F1 |
| "industrial IoT, ~600 people" (context in the role description, not a requirement) | none | — none, and why: it states no responsibility; R2-D1 and R3-B2 test domain homework |

## Prohibited claims

Built from the fit snapshot before any question was written. Nothing here is coached, and no guidance cell asserts, softens or implies it.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed managers | Negative you stated, F1 | The plain acknowledgment: "I haven't managed managers." No slot |
| Owned a hardware-adjacent roadmap | Negative you stated, F6 | The plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." No slot; the slots ask only about working alongside hardware teams |
| Led two squads or a team of eleven | Inflated form of F1 and F5 | The quote at its own scope: three of nine years as a team lead of six. The limit is the pack's observation: your material says a team of six |
| Owned delivery for the team | Inflated form of F2 | The quote at its own scope: a reliability quarter pushed through against roadmap pressure. The limit is the pack's observation: the material says the quarter, not how delivery was planned |
| The reliability quarter caused the 60% drop | Inflated form of F2 | The quote's own order: on-call burden dropped 60% after you pushed the quarter through. The slots ask only how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours |
| Owned hiring decisions, or 40 hires | Inflated form of F3 | The loop quote at its own scope: you run the hiring loop for backend roles; about 40 interviews last year. The 40 stays attached to interviews |

## Sources

**Provided documents:** your message, which supplied the role description, the three rounds and who runs each, the recruiter's description of the Monday round, and your background. No dossier was present. No interviewer profile was supplied.

**Searches sent (all refused, none returned anything):**

- "Larkfield Systems values" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The search was refused. It would have moved a values cheat sheet for Round 3 and named the themes of the VAL questions; Round 3's VAL questions are themed from the recruiter's phrase instead |
| 2. `Larkfield Systems interview process engineering manager` | skipped | Your own words fix all three sessions and who runs each, which settles the persona weights and loop structure |
| 3. `Larkfield Systems strategy` / recent news | unavailable | The search was refused. It would have moved a grounding brief and grounded the CO and CASE questions in current strategy; those questions are `[generic]` as a result |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names were given, so there was no query to form; the interviewer read is absent |
| 5. representative `Engineering Manager` JD | skipped | Your role description fixes the fit snapshot and the JD-tagged questions, though it is a short summary rather than a full posting |

## Upgrade menu

- Web search permission, or Larkfield's values page and careers or interview page pasted in → a values cheat sheet for Round 3, the VAL questions retitled to the published value names, and CO and CASE questions grounded in Larkfield's current strategy instead of `[generic]`
- A deeper research pass (up to 6 further searches and 2 further fetches, several more minutes), offered once → a grounding brief, the role-family loop reports, and recent org context
- The full job description → the rows now sourced from your short role description become `[grounded]` on the posting's own wording, and any mid-list requirement it names that your summary left out gets a question
- Your CV → F1 to F5 are graded on a few message lines, so every `medium` row has nothing inspected behind it; an inspectable artifact for a management role such as a team charter, a reliability-quarter write-up, or the hiring loop's scorecards would raise them
- Your answers to the answer slots, in your own words (how the 60% was counted, which stages of the hiring loop were yours, whether the team of six ever worked as more than one group, anything on developing engineers) → F2, F3, F4 and F5 are regenerated on what you say
- The recruiter's guidance for Tuesday and Thursday, or any take-home or presentation → coverage assumed from round-type priors becomes grounded, and a graded-deliverable section is added for each
- Interviewer names → an interviewer read, persona weights adjusted from public footprints, and a reverse question tied to each interviewer's own path
- What you learn on Tuesday (squad structure, hardware seam, anything the Director raises) → Rounds 2 and 3 are reweighted and regenerated
- A `tuesday-dossier.md` from a prior session → verified evidence and a prohibited-claims list that replaces the one built here
