I'll read the reference files before building the pack.
Dara, your prep pack is saved at `/var/tmp/tuesday-measure/1a2/runs/sonnet/alone/part-2/rooms/case-8-denied-30d25a27/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it as a three-round loop on the recruiter's schedule. There is one shared fit snapshot, and each round has its own persona weights, questions and reverse questions. Round 3 also carries the values sheet and three practice escalation cases. Practice cases are my own scenarios, because you haven't been told the real one.

I didn't run any searches. Your pasted values, strategy points, JD and recruiter email already covered what research would have. Interviewer names aren't assigned yet, so there is no interviewer read.

Say the word and I'll play the Skeptic on B3, the pack's highest-ROI question. It asks how a branch complaints log becomes owning the process across branches and the contact centre. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Prepared 20 November 2026 for the loop on 29 November 2026. Loop mode: three scheduled rounds, one shared fit snapshot, a mini-pack per round. Interviewer names are not yet assigned, so the pack works from each round's role only.

## How to use this pack

- Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words.
- Type key: VAL = behavioural or values alignment; EXP = work-experience deep-dive; JD = role and job-description requirement; CO = company and strategy knowledge; CASE = live hypothetical problem.
- An answer slot is an instruction for the interview, not a question for me. Meet it from your real experience, or take its honest branch.
- Highest-ROI prep in the pack: B3, in round 2. It is the objection this fit snapshot makes most likely, and it gets the deepest rehearsal.
- Question IDs run by persona across the pack: A = Conversational, B = Skeptic, C = Values/Behavioral, D = Case/Strategist, E = Peer Evaluator, F = Data-Driven Prober.

## The loop at a glance

| Round | Who and how long | What you were told | Provenance |
|---|---|---|---|
| 1 | The recruiter, 30 minutes | "30 minutes with me" | [grounded] |
| 2 | The Head of Member Services, who would be your manager, 45 minutes | "mostly behavioural" | [grounded] |
| 3 | A panel of two branch managers, 60 minutes, including a 20-minute case on a complaint escalation | "The panel is also the values round — they score against the four values." | [grounded] |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | The quote already carries the length. Lead with it in its own terms: "I've spent 6 years in retail banking, the last 3 as a branch supervisor." The JD says customer operations and the quote says retail banking and a branch; leave the relabelling to the interviewer. A CV-style line with nothing inspected behind it, so expect a probe on the last three years |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Say it at its own scope: "I handled the branch's formal complaints log." Your material shows a formal log; it does not show what rules or deadlines it ran to. Answer slot: the JD's line makes a probe on that likely. If the log was kept to any rules or deadlines, say which and what they required, in your own words; if it was not, or you do not know, say so plainly and describe how you handled the log |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | At its own scope: "I handled the branch's formal complaints log." The quote is one branch's log, and nothing in your material reaches past your branch. Answer slot: if you followed any complaint beyond your own branch, say how far and what part was yours, in your own words; if you did not, or none went further, say so plainly and stay with the log |
| F4 | "and the contact centre" (the same JD line as F3) — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | As written: "I built the monthly complaints spreadsheet our regional manager uses." The quote does not show what the spreadsheet counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours counted. If it tracked either, say how each was counted, in your own words; if it tracked neither, or you do not know how a figure was counted, say so plainly and stay with the spreadsheet |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote says spreadsheet, not which tool. Answer slot: the JD names Excel, so expect the tool to be asked. Say which tool it was built in and what you built, in your own words; if you do not remember or it was another tool, say so plainly and stay with the spreadsheet |
| F7 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | Words: "I haven't presented to anyone above regional level." Then how you would prepare for it, said as a plan and never as a past. Nothing added, and no presentation described that your material does not carry |
| F8 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | At its own scope: "I trained new tellers on our escalation script." The JD names supervisors and the quote names new tellers. Answer slot: if you coached any supervisor or colleague beyond new tellers on escalations, say who and how, in your own words; if not, say so plainly and stay with the tellers |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing on digital or self-service work. Answer slot: if you have worked with any digital or product team, or on any self-service tool, say what and what part was yours, in your own words; if you have not, say so plainly and say how you would start, as a plan |

## Grounding brief

You gave me four points from Ashgrove's July 2026 strategy brief. I have not seen the brief itself, so these rows carry your summary, not its wording.

| Point as you gave it | Where it shows up in this pack | Provenance |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | D1, F9, round 2 reverse questions | [grounded] |
| "consolidate eight branches into five hubs over 2027" | E1, C7, round 3 reverse questions | [grounded] |
| "launch a small-business lending product in Q1 2027" | Round 2 reverse questions only | [grounded] |
| "the main competitive pressure is app-only banks" | A2, D1 | [grounded] |

---

## Round 1: the recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly opener, then pay, notice, location and reason for leaving | high — a recruiter screen's prior is Conversational plus a light Skeptic, and this round is the recruiter's own 30 minutes | Prepare the 90-second arc in A1 from your own sentences; treat every casual question as scored |
| Skeptic (light) | Knockout checks on the two things the JD names that your material is thin on | medium — the JD names the contact centre and regulated complaints, and F2 and F4 are where your material is thinnest | Say the stated limit plainly (B1); hold B2 at the log's scope |

### Bank: Conversational (6 questions, four of them logistics)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc whose beats are only the stated ones: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log; training new tellers on the escalation script; the monthly complaints spreadsheet your regional manager uses. Tell them in your own words and add no turning point or result the sentences do not state. End on why this role. Answer slot: say your actual reason, in your own words; if there is more than one, give the one you would defend | F1 supplies the length, and F2 and F5 the complaints and reporting material the JD centres on. EXP because it tests what the background claims, in a conversational register |
| A2 | "What draws you to Ashgrove?" | CO | [grounded] | Pick one or two of the four published values and one strategy point (digital by 2028, hubs over 2027, small-business lending in Q1 2027, app-only banks), and say in your own words why it matters to you. The JD calls Ashgrove member-owned; say what that means to you only if it is true. Reciting all four reads as homework. Answer slot: if the real draw is the role rather than the organisation, say so plainly | Casual motivation questions are scored for specificity. CO because it tests homework depth, and the pasted values and strategy points are the source |
| A3 | "What are you looking for, salary-wise?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first and say you will respond to it; say whichever is true. Do not state a figure you have not decided or a salary history you would not stand behind | The only safe answer is your own. JD because it concerns the job's terms |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words; if you are unsure what it is, say you will confirm it and then do | A recruiter screen asks it for planning. JD because it concerns the job's terms |
| A5 | "Where can you work, and how often?" | JD | [generic] | Logistics slot: give your actual constraints, in your own words, or say you have none. The pasted JD does not say where the role sits, so you may ask the recruiter where it is based and how often it needs you on site before you answer | The JD gives no location, and the hubs plan means branch locations are changing. JD because it concerns the job's terms |
| A6 | "Why are you looking to move on from your current role?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words, one you would repeat to the Head of Member Services in round 2 (B4). Say nothing about your employer you would not say to them directly | Motive consistency is checked across rounds, and B4 asks the same thing again. EXP because it tests your own history |

### Bank: Skeptic (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre as well as the branches. What's your experience there?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment first, short: "I haven't worked in a contact centre." Then a plan, said as a plan: what you would ask or look at first to learn how complaints reach and move through a contact centre. Offer nothing nearer than your material carries, and stop after the plan | F4 is the gap the JD's first line names, so a recruiter screening for knockouts reaches it early. JD because it scores a stated responsibility |
| B2 | "The role needs experience handling regulated complaints. What have you handled?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold at the quote's scope: "I handled the branch's formal complaints log." Answer slot: if the log was kept to any rules or deadlines, say which and what they required, in your own words; if it was not, or you do not know, say so plainly and describe how you handled the log. Do not name a regulator or rule you did not work to | F2 is the requirement a screen checks first, and the one where a formal log and a regulated process can be run together. JD because it scores the stated requirement |

### Round 1 reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1-1 | "What would the Head of Member Services want to be different six months in?" | Tells you what the hire is measured on and gives round 2 something to build on |
| R1-2 | "How does the 20-minute case work: do I get anything beforehand, and what is it scored on?" | Closes the biggest unknown in round 3 before you rehearse blind |
| R1-3 | "Where is the role based, and how will the move from eight branches to five hubs change that?" | Settles the location slot honestly and shows you read the strategy |
| R1-4 | "Do you know yet who the two branch managers on the panel are?" | Names let this pack add an interviewer read for round 3 |
| R1-5 | "What happens after the 29th, and when would you expect to come back to me?" | A plain close that fixes the next step |

---

## Round 2: the Head of Member Services (45 minutes, your would-be manager)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Past-behaviour prompts | high — the recruiter called this round "mostly behavioural" | Use "we" for context and "I" for what you did; where no quoted sentence carries a story, use the selection scaffold and its honest branch |
| Skeptic | Probes on what the JD names and your material lacks | high — a hiring manager prices the gaps, and F3, F4 and F7 are all in this round's reach | Rehearse B3 until it is boring; state the limit yourself before it is asked |
| Case/Strategist | Strategy and live-problem questions | medium — a hiring manager asks about the role's own roadmap, and the brief supplies it | Clarify first, then structure; think aloud |
| Data-Driven Prober | One question on the spreadsheet | low — the JD's reporting line points here, and F5 and F6 rest on one sentence | Say what you can and cannot say about how it counted, and say plainly where you do not know |

### Bank: Values/Behavioral (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you coached someone through an escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The beats the quote states: new tellers, our escalation script, and that you trained them, in your own words. Add no outcome or reaction the quote does not hold. Answer slot: the JD says supervisors, so expect "and supervisors?"; if you coached anyone beyond new tellers, say who and how; if not, say so plainly and stay with the tellers | The JD's coaching line is the likeliest behavioural entry, and F8 is thin on audience. JD because it scores the responsibility, delivered as behavioural |
| C2 | "Tell me about a time you delivered an unpopular truth to someone senior." | VAL | [generic] | Selection scaffold: pick a time you told someone more senior something they did not want to hear. It needs a named stake, a moment you did not soften the message, and a relationship that was intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem, and it fits a role whose reporting reaches senior leaders (F5, F7). VAL because it scores behaviour, not capability |
| C3 | "When did you put a member ahead of an internal target or metric?" | VAL | [grounded] | Selection scaffold on the value Members First: pick a time you decided from the member's side when it cost something internally. It needs the decision, what it cost, and where it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First is a published value, so it is asked here and again in round 3 (C5). VAL because it scores a decision, not a claim |
| C4 | "Tell me about a complaint you found hard to close." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold anchored on the log: the quote carries only that you handled it, so every other beat is yours to supply truthfully. Pick one complaint from it; say what made it hard, what you did and how it ended, in that order, with "I" for your part. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F2 is the one place the background holds complaints material, and a manager asks for the deepest example from it. EXP because it tests what you did |

### Bank: Skeptic (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B3 | "Your experience is a branch's complaints. This role owns the process across the branches and the contact centre. Why should I believe you can do that?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre" | Highest-ROI prep in the pack. Name the limit yourself before it is asked: "What I've handled is the branch's formal complaints log. I haven't worked in a contact centre." Hold that scope through every follow-up and concede nothing wider. Follow-up 1, "a branch log is not a process": stay with the log. Answer slot: if you followed any complaint beyond your own branch, say how far and what part was yours; if not, say so plainly. Follow-up 2, "what would you want to know first about the contact centre": give a plan, never a past, covering what you would ask, where you would look and who you would sit with. Follow-up 3, "how would you start across the branches": a plan again, in your own words. Follow-up 4, "which part would you be weakest at on day one": answer from the two limits you have stated, the contact centre and presenting above regional level, with the plan for each | F3 and F4 together are this snapshot's biggest gap, and the JD's first line asks for exactly what they leave open. JD because it scores the stated responsibility, delivered under pressure |
| B4 | "Why this move, and why now?" | EXP | [generic] | Your actual reason, in your own words, matching what you gave the recruiter (A6). Add what draws you to Ashgrove (A2) only if it is true. Answer slot: if the honest answer is partly about the role's scope, say so plainly | A manager-to-be tests motive consistency across rounds. EXP because it tests your own history |
| B5 | "I don't see presenting to senior leaders in your background. How would you handle that in this role?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented to anyone above regional level." Then a plan, said as a plan: who you would ask for feedback, what you would rehearse, how you would keep it short and in plain words. Describe no presentation you have not given | F7 is the second stated gap, and the JD names the audience. JD because it scores a stated requirement |

### Bank: Case/Strategist (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our strategy is to move 40% of member service to digital channels by 2028. How would you think about complaints in that world?" | CO | [grounded] | Clarify first: which services move, what counts as a complaint when no person is involved, and who owns it. Then think from the member's side: where a self-service journey can fail, how the member says so, and how the fix stays owned. Say it as thinking, never as experience. Answer slot: the JD's digital-teams line makes a probe on your own contact with digital work likely; if you have worked with any digital or product team, say what and what part was yours; if you have not, say so plainly and return to how you would approach it | The 40% point is the brief's headline and F9 is the gap beside it. CO because it needs the strategy; CASE in delivery |
| D2 | "You have five minutes with our senior leaders to explain why complaint volumes moved last month. How do you open?" | CASE | [generic] | Structure: the answer in your first sentence; the one thing members experienced; what is being done about it; what you need from them; then stop. Plain words throughout. Think aloud and say what you would want to know first. It asks about no past, so the guidance claims none | It tests F5 and F7 together, live. CASE because it is a hypothetical on the role's own monthly report |

### Bank: Data-Driven Prober (1 question)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk me through your monthly complaints spreadsheet — what did it count?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Hold: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times; if yours tracked either, say how each was counted and which assumption behind a count you would defend least, in your own words; if it tracked neither, or you do not know how a figure was counted, say so plainly and stay with the spreadsheet. Say which tool it was built in. Describe no view or feature you could not walk through end to end | F5 and F6 rest on this one sentence, so a prober starts here. EXP because it tests whether the claim survives |

### Round 2 reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R2-1 | "What does the complaints process look like across the branches and the contact centre today, and where does it hurt most?" | Asks about the whole process the JD says you would own, and shows you are thinking about it end to end |
| R2-2 | "How do complaint volumes and resolution times reach senior leaders today, and what would you change?" | Ties to the JD's reporting line and to the audience you have not yet presented to |
| R2-3 | "With 40% of service moving to digital by 2028, how do you see complaints being raised and closed in the app?" | Uses the brief's headline and the app-only-bank pressure |
| R2-4 | "How will the small-business lending launch in Q1 2027 touch the complaints process?" | Shows you read the whole brief, not only the digital point |
| R2-5 | "What would you want me to know about the contact centre before I walk in?" | Names your known gap openly and turns it into a working question |

---

## Round 3: the panel of two branch managers (60 minutes, including a 20-minute case)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Every answer scored against the four values | high — the recruiter said "they score against the four values", so the lens applies to the whole hour, the case included | One story or scaffold per value; in the case, say aloud where each value shapes a step |
| Case/Strategist | The 20-minute escalation case | high — the recruiter named it, and 20 of 60 minutes is a third of the round | Clarify, then structure, then plain words; think aloud |
| Peer Evaluator | Seam and credit questions from the two managers | medium — branch managers sit beside the role in the JD's coaching line and in the hubs plan | Offer seam principles rather than pretending to know the seam; bring something to their side |

### Bank: Values/Behavioral (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C5 | "Tell me about a time you decided from the member's side of the counter." | VAL | [grounded] | Selection scaffold on Members First: pick a time what the member needed and what was easiest for the branch differed; name the decision you made, what it cost and where it ended, with "I" for the decision. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The question is the published value in its own words. VAL because it scores behaviour against a named value |
| C6 | "Tell me about a time something had to be explained to a member twice." | VAL | [grounded] | Selection scaffold on Plain Words: pick one occasion; say what was unclear, whose wording it was, and what you said the second time. Whether you changed the wording afterwards is yours to say truthfully. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Plain Words says that a second explanation means the wording was wrong, and the panel scores against it. VAL because it scores a named value |
| C7 | "Tell me about a time local knowledge of a branch's members changed how you handled something." | VAL | [grounded] | Selection scaffold on Neighbours, Not Numbers: pick a time what you knew about the town or its members shaped what you did; name what you knew, what you did differently and what followed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The hubs plan makes this value live for a panel of branch managers. VAL because it scores a named value |
| C8 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold on Own the Fix, anchored on the log: the quote says you handled it, not that you followed any item to its end, so the story is yours to supply truthfully. Pick one problem; say how you found it, who else touched it, what you did to keep hold of it and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Own the Fix is the value closest to a complaints role, so expect it in some form. VAL because it scores a named value against F2 |

### Bank: Case/Strategist (3 questions)

The recruiter said only that the case is 20 minutes on a complaint escalation. D3 to D5 are practice cases built for rehearsal, not the real scenario.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D3 | "A member complained at the branch last week. The branch says it is the contact centre's issue, the contact centre says the branch should have fixed it, and the member has now written in again. You have the file in front of you. What do you do?" | CASE | [generic] | Clarify first: what the member asked for and what they have been told, what has been done and by whom, any deadline the complaint is running to, and who holds the file now. Then: what the member needs today; who keeps hold of it, by name, until it is solved or handed over by name; what you write to the member in plain words; what you record; what the case says about the process. Say aloud where Members First and Own the Fix shape each step | The recruiter named an escalation case; a hand-off dispute between branch and contact centre is a practice stand-in. CASE because it is a live problem with no claim about your past |
| D4 | "A branch supervisor escalated a complaint three days after the member first raised it, and the member is angry about the delay. What do you say to the supervisor, and what do you say to the member?" | CASE | [generic] | Two audiences, two answers. To the member: plain words, what happens next and who holds it. To the supervisor: the coaching line the JD names, framed as how to make the next one faster, not who was late. Say what you would ask the supervisor before concluding anything. Add no history of your own | It rehearses the JD's supervisor-coaching line inside a case. CASE because it is hypothetical |
| D5 | "Write the first two sentences of your reply to the member." | CASE | [generic] | Plain Words in practice: the answer or next step first, no policy language, nothing the member would have to ask twice. Say your sentences aloud; read them as the member would | The panel scores against Plain Words, and a spoken sentence shows it fastest. CASE because it is a live task |

### Bank: Peer Evaluator (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Eight of our branches become five hubs through 2027. When a member complains at a hub, where does your job end and a branch manager's begin?" | CO | [grounded] | Do not claim to know the seam; offer principles. The member should not have to find the seam. Whoever finds the problem keeps hold of it until it is solved or handed over by name. Hand-offs get written down. Then ask the managers what a hub complaint looks like today | The hubs point is the brief's, and branch managers are the people it affects. CO because it needs the strategy; the Peer register |
| E2 | "Our teams sit side by side — where's the seam, and what happens when we disagree?" | EXP | [generic] | Principles first: agree who holds a case before arguing about how to handle it; disagree about the case, not the person; take it to the Head of Member Services only after you have tried between yourselves. Answer slot: if you have disagreed with a colleague about how to handle a complaint, say how it went; if not, say so plainly and stay with the principles | Peers press on the seam where the role meets a branch. EXP because it asks how you act with equals |
| E3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work crossed teams; say who did which part, using "we" for context and "I" for yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard peer probe on credit-sharing. VAL because it scores behaviour with equals |

### Values cheat sheet

The values below are as you copied them from ashgrovecu.org/about/values on 20 November 2026. No quoted sentence of yours carries a story for any of them, so each row is a selection scaffold with its honest branch.

| Value | Working meaning | Your story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold (C3, C5): pick a decision where the member's need and the easier internal path differed; the decision, its cost, where it ended. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs it explained twice, the wording was wrong | Scaffold (C6, D5): pick one occasion of a second explanation; what was unclear, what changed. F8 is the nearest row; the quote names the script and not its wording. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold (C7, E1): pick a time local knowledge shaped what you did. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Scaffold (C8, D3): F2 is the nearest row; the quote says you handled the log, not that you followed an item to its end, so pick one you did. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

### Round 3 reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R3-1 | "What could someone in this role do in their first month that would genuinely help your branch?" | Reciprocity: it asks what you can bring to their side, not only what you need |
| R3-2 | "How do escalations work in your branch today, and where do your supervisors get stuck?" | Ties to the JD's coaching line and asks for the managers' own view |
| R3-3 | "As eight branches become five hubs, what are members in your town most worried about, and how do complaints show it?" | Neighbours, Not Numbers in a working question, using the brief's hubs point |
| R3-4 | "What does keeping hold of a complaint look like in practice when it crosses teams?" | Own the Fix as a real question, and it invites them to describe the seam |
| R3-5 | "What would you want a member to say about how Ashgrove handled their complaint?" | Members First as a closing question, and it tells you what the panel scores |

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| "4+ years in financial-services customer operations" | A1 |
| "experience handling regulated complaints" | B2, C4 |
| "Own the member complaints process end to end across branches and the contact centre" | B1, B3, D3, E1 |
| "report monthly on complaint volumes and resolution times" | F1, D2 |
| "coach branch supervisors on escalations" | C1, D4, E2 |
| "work with digital teams on self-service journeys" | D1 |
| "confident presenting to senior leaders" | B5, D2 |
| "comfortable with Excel reporting" | F1 |

Your message holds no headline figure, so there is no defend-the-number question. Each of the four published values has a VAL question: C3 and C5, C6, C7, C8.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end across branches and the contact centre | Inflated form of F3 | F3's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material says one branch's log, not a process across branches. The slot stays inside the log |
| Has handled regulated complaints | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says a formal log, not what governed it. The slot asks only what rules or deadlines the log was kept to |
| Coached or led branch supervisors on escalations | Inflated form of F8 | F8's quote at its own scope: "I trained new tellers on our escalation script." The slot asks only whom else you coached |
| Reported complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The limit is the pack's observation: the material does not show what it counted |
| Has worked in a contact centre | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F7 | The plain acknowledgment F7 gives: "I haven't presented to anyone above regional level." No slot |

## Sources

Provided documents: the JD; the values text you copied from ashgrovecu.org/about/values on 20 November 2026; the recruiter's email on the process; your summary of four points from the July 2026 strategy brief (not the brief itself); your background paragraph. No dossier was consumed.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the values cheat sheet and the VAL questions |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email names three sessions and who runs each, which fixes the loop and the persona weights |
| 3. `Ashgrove Credit Union strategy` | skipped | The four brief points you supplied fix the CO questions; the brief is from July 2026 |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer has been named, so there is no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The three interviewers' names, once assigned → an interviewer read per round, persona weights tuned to each person's public footprint, and a reverse question tied to each person's path
- The recruiter's answer on the 20-minute case (format, any materials, what it is scored on) → a build section for the case if anything is announced in advance; D3 to D5 stay `[generic]` practice cases until then
- The strategy brief itself → the grounding brief moves from your four-point summary to the brief's own wording, and any stale framing can be flagged
- Your answers to the slots in F2, F3, F5, F6, F8 and F9, and any presenting you have done at or to regional level (F7), stated outside a drill → those rows move from discovery to your own words, and the guidance that draws on them is rewritten around your sentences
- Hours you have before 29 November → a prep triage in priority order
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a fuller strategy grounding, role-family loop reports and recent organisation context
- A `tuesday-dossier.md` from an earlier evidence pass → verified claims and prohibited-claims constraints would replace this pack's locally built list
