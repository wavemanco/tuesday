I'll read the reference files the skill points to before drafting.
Your prep pack for all three rounds is saved at `/var/tmp/tuesday-measure/1a2/runs/sonnet/alone/part-2/rooms/case-6-denied-a3e1a762/larkfield-systems_engineering-manager_interview_pack.md`. It has a shared fit snapshot and a mini-pack for each round. The persona weights use the rounds as you described them. The Director round leans on the Skeptic and Case personas, the panel on Peer Evaluator and Prober, and the VP round on Values, with a Pressure element.

Web search was refused in this session, so I couldn't look up Larkfield's values, interview process or strategy. The company-specific parts are limited to your role description and are labeled generic. That means no values cheat sheet for the Monday round, and the case questions don't draw on Larkfield's current priorities.

The highest-ROI rehearsal is A2: "You haven't owned a hardware-adjacent roadmap. How would you handle the hardware partnership?" It comes back in D2 and I1, so one practiced answer covers three rounds.

Say the word and I'll play the Skeptic on A2, with follow-ups.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the full job description text or your CV to paste in (I'll carry on without them if not)?
Has the recruiter told you anything about the panel or the VP round, such as the format, an exercise, or the interviewers' names?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems (loop of three rounds)

**Candidate:** Yusuf. **Mode:** loop (three scheduled rounds), one shared fit snapshot and per-round mini-packs.

| Round | When | Who (names not given) | Relationship | Format |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering | Hiring manager, your would-be boss | 45 min |
| 2 | The Thursday after | Two staff engineers and a product manager | Panel, mixed peers and cross-functional | 60 min |
| 3 | The following Monday | VP Engineering | Skip-level, described by the recruiter as "values and leadership philosophy" | 30 min |

Persona weights below rest on the relationships and formats you gave, which is the only loop source this pack has. No research ran (see Sources), so nothing here is specific to Larkfield beyond the role description you pasted.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values and leadership, not generic virtue |
| EXP | Whether claims about your experience survive follow-ups, including attribution |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

The single most predictable objection to you, and the highest-ROI prep in this pack, is question A2: your own sentence says you have not owned a hardware-adjacent roadmap, and the role has you partnering with hardware. The same objection returns in D2 and I1, so one well-rehearsed answer is used three times.

## Fit snapshot (shared across all three rounds)

Requirements are quoted from the role description you pasted, and from the recruiter's words as you relayed them. Your evidence is quoted exactly from your message. The "none given" rows are silence, not a finding that you lack the thing.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (the two-squads part) — role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message; "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | medium | [grounded] | transferability | Your material says a team lead of 6, not two squads, and nothing inspected sits behind it. Words at the quote's own scope: "I've spent 3 of my 9 years as a team lead of 6." Plain acknowledgment from your own sentence: "I haven't managed managers." Answer slot: the two-squads line makes a probe on running more than one team likely. If any part of your 3 years went beyond the team lead of 6, say what, in your own words; if not, say so plainly and stay with the team lead of 6 |
| F2 | "Lead two squads building device-management services" (the device-management part) — role description in your message | none given | none | [grounded] | discovery | Your material does not show work on device-management services, and names no domain but payments. Answer slot: the role's device-management line makes a probe on what you know of this domain likely. If any service you have worked on managed devices, say what, in your own words; if none did, say so plainly and say what you would learn first |
| F3 | "own delivery, hiring and growth for 11 engineers" (the delivery part) — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | discovery | The sentence shows a reliability quarter pushed through against roadmap pressure and a 60% drop after it. It does not show whether delivery commitments were yours to own. Words at its own scope: "I pushed a reliability quarter through against roadmap pressure." The 60% raises four slots: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours. Answer slot: the own-delivery line makes a probe on what you were accountable for likely. If your team's roadmap commitments were yours, say which and how you held them, in your own words; if not, or if you only influenced them, say so plainly and stay with the reliability quarter |
| F4 | "own delivery, hiring and growth for 11 engineers" (the hiring part) — role description in your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap in kind, but a line with nothing inspected behind it, so expect a probe. Lead with the loop in the quote's own terms: you run it, for backend roles. The figure raises the same four slots, and the quote does not say whether about 40 interviews means ones you conducted or the loop's total, so take the reading that claims less unless your own account says otherwise |
| F5 | "own delivery, hiring and growth for 11 engineers" (the growth part) — role description in your message | none given | none | [grounded] | discovery | Your material shows nothing on growing engineers. Answer slot: the growth line makes a probe on an engineer you have helped develop likely. If there is one, say what you did, in your own words; if there is not, or it was not yours, say so plainly and say how you would start with the 11 engineers |
| F6 | "partner with hardware and product on roadmap" — role description in your message | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | transferability | Derived: the roadmap-pressure clause is adjacent to a roadmap partnership and does not reach hardware or product. The limit is stated in your own sentence. Words: "I haven't owned a hardware-adjacent roadmap," then at its own scope "I pushed a reliability quarter through against roadmap pressure." Answer slot: the partner line makes a probe on working beside a hardware or product team likely. If you have, say how, in your own words; if not, say so plainly and say how you would set up the partnership, as a plan |
| F7 | "values and leadership philosophy" — the recruiter's description of Round 3, relayed in your message | none given | none | [grounded] | discovery | Your material states no leadership philosophy, and this pack will not write one for you. Answer slot: expect a "how do you lead" probe. Choose one belief that actually guides you and one thing you do because of it, in your own words; if none comes to mind, say so plainly and describe what you actually do |

## Sources (shared)

Provided documents: your message (role description, the three rounds, your background). Not provided: a full job description, a CV, interviewer names, any recruiter guidance on the panel or the VP round.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Query sent | Outcome |
|---|---|
| Larkfield Systems industrial IoT values | refused |
| Larkfield Systems interview process engineering manager | refused |
| Larkfield Systems industrial IoT device management strategy news | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | The search was refused. It would have moved the Monday values cheat sheet, which is dropped, and let VAL questions name published values |
| 2. Larkfield Systems interview process, engineering manager | unavailable | The search was refused. The loop itself is fixed by your own words, so it would have added only documented round formats and case styles |
| 3. Larkfield Systems strategy and recent news | unavailable | The search was refused. It would have grounded CO and CASE questions in current priorities, so those are labeled generic |
| 4. Interviewer name and company | n/a | No names were given, so no query could be formed. There is no interviewer read |
| 5. Representative Engineering Manager JD | skipped | The role description you pasted fixes the fit snapshot rows and the JD-tagged questions. A fuller JD is in the upgrade menu |

No dossier was present.

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 two squads | A1, A3, G3, I1 |
| F2 device-management services | B1, E3, H2 |
| F3 own delivery | B3, D1, E1, I2 |
| F4 hiring | E2, F2 |
| F5 growth | C3, G4 |
| F6 partner with hardware and product | A1, A2, B2, D2, I1 |
| F7 values and leadership philosophy | F1, G1, G2 |
| Values-style round: published company values | none — values not in hand (searches refused), so no cheat sheet and no value-by-name questions |

---

# Round 1 — Tuesday, Director of Engineering (hiring manager, 45 min)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the hardware and two-squad gaps and of why this role | Highest. A hiring manager derisks gaps, and F1 and F6 are where your own sentence limits the fit | Rehearse A2 until it is boring: state the limit in your own words, then a plan, held through follow-ups |
| Case / Strategist | Live problems from the real roadmap: device fleets, hardware dependencies, two squads | High. A hiring manager buys capability and expects live problems on the actual roadmap | Clarify, objective, approach, metrics, risks; think aloud; challenge one premise |
| Conversational | Biography opener, first-30-days chat, growth question | Medium. A 45-minute boss conversation opens casually, and casual questions are scored | A 90-second arc built only from your own sentences |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold, then concede. Name the weak spot before they do, in your sentence's words: "I haven't managed managers" or "I haven't owned a hardware-adjacent roadmap," whichever you would put first. Then, at its own scope: "I pushed a reliability quarter through against roadmap pressure." Hold through two follow-ups by returning to those sentences and adding nothing. If a follow-up goes past what you have done, say so plainly, then say how you would find out | F1 and F6 are where the material is thinnest, so a hiring manager asks this in some form. JD because it scores the stated role; Skeptic because it probes gaps |
| A2 | "You haven't owned a hardware-adjacent roadmap. How would you handle the hardware partnership this role needs?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then give your approach as a plan, never as a past: what you would ask hardware and product in your first weeks and how you would check what you heard. Answer slot: the partner line makes a probe on working beside a hardware or product team likely. If you have, say how, in your own words; if not, say so plainly and stay with the plan. Rehearse three follow-ups: what you would do first; what if hardware says no; and "so you would be learning on our time", which gets a specific concession that this is the part you would be closing, with nothing added | F6 is the objection a Director is most likely to press, because the role's partner line meets your own stated limit. JD because the line is the role's; Skeptic delivery because it arrives as a gap |
| A3 | "This role leads two squads. How would you structure leading across them?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers and never owned a hardware-adjacent roadmap" | Say it at its own scope first: "I've spent 3 of my 9 years as a team lead of 6," and "I haven't managed managers." Then your structure, as a plan: how you would learn each squad's state and how you would split your attention. Answer slot: if any part of your 3 years went beyond the team lead of 6, say what, in your own words; if not, say so plainly and stay with the plan | F1's two-squads line against a team lead of 6 is the second likeliest probe. JD because it scores the stated requirement |
| A4 | "Why this role, and why now?" | JD | [generic] | Selection scaffold: choose the reason that is truly yours and tie it to a line the role description states, such as the two squads, the hiring and growth, or the hardware and product partnership. Two sentences. If your reasons are mixed, say which is strongest. The guidance makes no claim about your past | Motivation consistency is what a Skeptic scores, and the role is a step in scope from the material in F1. JD because it ties to the posting's lines |
| B1 | "Your service pushes a configuration change to a large fleet of industrial devices, and hardware says a bad change cannot be undone remotely. How do you decide whether and how it ships?" | CASE | [generic] | Clarify first: what breaks, who is affected, what staged release is possible. Then objective, approach, metrics, risks, thinking aloud. Challenge one premise respectfully, for example what "cannot be undone" covers. The question needs no claim about your past, so the guidance makes none | A live problem from the device-management line (F2's requirement), delivered as a case. Generic because it is a pattern for the problem, not a fact about Larkfield |
| B2 | "Product wants a feature this quarter, hardware says the parts will not be ready, and your two squads disagree. Walk me through your first week." | CASE | [generic] | Clarify what is fixed and what is flexible, then who needs to be in the room, then a first-week sequence and the decision you would bring back. Challenge one premise, such as whether the squads' disagreement is about scope or about date. No claim about your past | F6's requirement set as a decision. Generic because it describes a problem pattern |
| B3 | "You take over two squads. One has a heavy on-call load and the roadmap is full. What do you do?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure first: clarify, objective, options, what you would measure, risks. If you tell your own story, say it at its scope: "I pushed a reliability quarter through against roadmap pressure." The 60% raises four slots, in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours. Answer slot: the own-delivery line makes a probe on who made the trade-off likely. If it was yours, say so; if you made the case to someone who decided, say that; if neither, say so plainly and stay with the structure | F3 holds your one reliability sentence and a figure, and this case invites it. CASE delivery over EXP content, because the structure is scored first |
| C1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc with the beats the sentence states: 9 years in engineering, 3 as a team lead of 6, now at a payments company. Anything further, such as what you built, is yours to say in your own words, and only what you did. End on why this role | A casual biography opener is still scored, and F1 is its only source. EXP because it tests what you claim |
| C2 | "What would you want your first 30 days here to look like?" | CASE | [generic] | A plan, not a past: who you would meet, what you would ask, what you would not change yet. Keep it to what you would actually do. No claim about your past | A casual-register question that scores judgment about F1, F2 and F6 together. Generic because it is a plan pattern |
| C3 | "Tell me about an engineer you helped grow." | EXP | [generic] | Selection scaffold: pick an instance where you can say what you did, what the engineer did and what changed, with nothing you cannot back. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would start with the 11 engineers | The growth line (F5) has no quote behind it, so this scaffold is the honest form. The theme comes from the role description |

## Reverse questions for Round 1

| Question | Why it lands |
|---|---|
| "What would a good first 90 days look like for the two squads, and how would you tell?" | It turns the vague success definition into one you and your boss share, and signals you plan to be measured |
| "Where does the seam between my squads and hardware hurt most today?" | It asks for the hardest part of the thing you have not owned, which is honest and gets you the real picture |
| "How are the two squads led day to day today?" | It surfaces the leadership structure behind your stated limit on managing managers, without raising it first |
| "What do the best engineering managers here do differently from the rest?" | It asks your future boss to describe the bar in their own terms |
| "After today, what would make you hesitate about me?" | It gives you a chance to answer the doubt in the room, rather than after |

---

# Round 2 — Thursday, panel: two staff engineers and a product manager (60 min)

## Persona table

Names are unknown, so personas are assigned by relationship, not by person. The panel row blends the top two personas of each member's relationship.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting between product and engineering, "what would you need from us", credit and disagreement | Highest. Staff engineers and a product manager are pricing what a new manager costs and contributes to their own work | Reciprocity: what you offer them, not only what you need. Principles for the seam, without pretending to know it |
| Data-Driven Prober | Your figures, to their assumptions | High. Technical staff will pick the 60% and the 40 interviews apart because they are the only numbers you have given | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know |
| Values / Behavioral | Scenario prompts from the product manager, outside engineering | Medium. Cross-functional interviewers tend to run behavioral questions, though no published values are in hand | Stories only from your own sentences, "we" for context and "I" for contribution; where none fits, say so |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Where is the seam between product and engineering, and what happens when we disagree?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Offer principles for the seam rather than claiming to know theirs, and ask what theirs is today. For an instance, the nearest sentence you have is "I pushed a reliability quarter through against roadmap pressure," at its own scope. Answer slot: if the pressure came from product and you disagreed with them, say how it went, in your own words; if it came from elsewhere, or was not a disagreement, say so plainly and stay with the sentence | F6's partner line with F3's only roadmap sentence. JD because it is the role's own partnership, delivered in a peer register |
| D2 | "You haven't owned a hardware-adjacent roadmap. What would you need from us in your first month?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Open with the plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then what you would ask for, as a plan, and what you would offer in return, as a commitment you would actually make. Reciprocity, not a wish list. Hold if pushed by returning to that sentence and the plan | The same objection as A2 in collegial packaging, from the people who will work beside you. F6 is its source |
| D3 | "How do you handle credit when work spans teams?" | VAL | [generic] | State the principle you actually hold in two sentences. If you give an instance, choose one where you can say what each team did and what was yours. If no such time comes to mind, say so plainly and give the principle. No claim about your past is made by this guidance | A standard peer probe on partnership fit. VAL because it scores behavior, not a published value |
| D4 | "A staff engineer says your squad's design is wrong a week before a committed date. What do you do?" | CASE | [generic] | Clarify what is wrong and what it costs to change. Then objective, options, who decides, and how you would keep the disagreement useful. Challenge one premise, such as whether the date or the design is the real constraint. No claim about your past | Staff engineers test whether a manager defers, steamrolls or reasons. Generic because it is a problem pattern |
| E1 | "Walk me through how the 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Four slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. "I don't know how it was counted" is an honest answer. Say "after", as your sentence does, and not "because of" unless your own account supports it | A headline number on your message, and technical staff will probe it first. F3 is the source; EXP because it tests attribution |
| E2 | "About 40 interviews last year. How was that counted?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | The same four slots: whether the 40 means interviews you conducted or the loop's total, what it is sensitive to, the assumption you would defend least, which part was yours. Resolve the ambiguity downward unless your own account says otherwise | The second figure you have given. F4's reading is open, so this is where a prober lands |
| E3 | "What would you want to understand first about a service that manages devices in the field?" | CASE | [generic] | Your list of clarifying questions is the answer, so think aloud and do not claim familiarity. Answer slot: if any service you have worked on managed devices, say what, in your own words; if none did, say so plainly and say what you would learn first | F2 has no quote behind it, so a staff engineer will test it. JD content, CASE delivery, and generic because it is a pattern |
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The nearest sentence you have, at its own scope: you pushed a reliability quarter through against roadmap pressure. Answer slot: whether what you said was unwelcome, who it was said to and how it landed, in your own words; if the quarter was not that, or it did not land, say so plainly and pick another time, or say none comes to mind and give the nearest thing your material carries | The unpopular-truth stem is a standard values prompt, and F3 holds your only pressure sentence. VAL because it scores behavior |
| F2 | "You run your hiring loop for backend roles. How would you run it for engineers on a device-management team?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say it at its scope: you run the loop, for backend roles. Answer slot: the hiring line makes a probe on how the loop is built likely. If any part of how it runs was yours to set, say which, in your own words; if you inherited it or only ran it as designed, say so plainly. Then, as a plan, what you would change for a different kind of engineer | F4 is your strongest-fit row, and the panel will test how far it stretches to a new domain. JD because it scores the hiring line |

## Reverse questions for Round 2

| Question | Why it lands |
|---|---|
| "What could a new manager do in their first month that would genuinely help your team?" | The reciprocity question for peers: it asks what you can give, not what you need |
| "Where does the design review process hurt most today?" | Staff engineers know where the process is painful, and it signals you are thinking about their work |
| "How do roadmap decisions get made between product and hardware, and where do they stall?" | It asks the product manager about the exact seam the role covers, and about the part you have not owned |
| "What do you wish engineering managers here did differently?" | It invites candid feedback on the role you are joining |
| "What does a good disagreement between product and engineering look like here?" | It lets the panel describe the culture, and shows you care about disagreement style |

---

# Round 3 — Monday, VP Engineering (30 min, "values and leadership philosophy")

## Persona table

A values-style round is detected here from the recruiter's own words as you relayed them. Larkfield's published values are not in hand, so there is no values cheat sheet and no question names a value.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Leadership philosophy and behavior prompts | Highest. The recruiter described the round this way, which outweighs the skip-level prior | Start from what you actually do, not a slogan; "we" for context, "I" for contribution; stories only from your own sentences |
| Case / Strategist | Altitude questions: trade-offs across squads, planning, what is hard about the domain | High. A skip-level prior is strategy-heavy, and 30 minutes means short, structured answers | Clarify, structure, answer in a minute or two; say what you would ask rather than bluff domain knowledge |
| Pressure | Time-boxed challenges to the thinnest part of your story | Medium. A VP at skip level tests composure, and the same gaps return in short form | Hold through two follow-ups, then concede specifically; never fold on what your sentences carry |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "What is your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Start from what you actually do, not a slogan: one belief that really guides you, and one thing you do because of it. If you point to your own work, the nearest sentence is "I pushed a reliability quarter through against roadmap pressure," at its own scope, without saying what it proves. If no clear philosophy comes to mind, say so plainly and describe what you actually do | F7 is the recruiter's stated focus and nothing in your material states a philosophy. VAL because it scores the leader, not a published value |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a moment where you can name the metric, the customer need and what you gave up, without claims you cannot back. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would decide | A standard values stem, used here because the recruiter named values and no published ones are in hand. Generic because it is a stem |
| G3 | "You haven't managed managers. How do you think about growing into that?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | First sentence: "I haven't managed managers." Then, as a plan: how you would learn to lead leaders, who you would ask, and how you would check you were doing it well. No claim to having coached leads | F1's stated limit, asked at VP altitude. JD because it scores the growth path of the role |
| G4 | "What do you want the engineers on your squads to say about working for you in two years?" | VAL | [generic] | Say what you actually intend, plus one concrete thing you would do to make it true. No claim about your past | A leadership-philosophy question in a different form, tied to the growth line (F5) and F7. Generic because the guidance makes no claim about you |
| H1 | "A major customer escalation needs the same engineers as your committed roadmap. How do you decide?" | CASE | [generic] | Clarify the customer impact and the commitment, then objective, options, who you would involve, what you would tell each side. Challenge one premise, such as whether it is really the same engineers. No claim about your past | A skip-level trade-off across your two squads. Generic because it is a problem pattern |
| H2 | "What do you think is hardest about running device-management services for industrial customers?" | CO | [generic] | You cannot know Larkfield's specifics from what you have in hand, so say what you would want to find out and ask one question back. Answer slot: if any service you have worked on managed devices, say what; if none did, say so plainly | The only CO-style question the pack can write without research, so it is generic. F2 is the gap it presses |
| H3 | "How would you plan your first 90 days across two squads?" | CASE | [generic] | A plan: what you would learn first, whom you would meet, what you would not change yet, how you would know it was working. Keep it to what you would actually do | A skip-level wants to see judgment about sequence. Generic because it is a plan pattern |
| I1 | "Sixty seconds: why should we choose a manager from a payments company for this role?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers and never owned a hardware-adjacent roadmap"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold, then concede, in three sentences. Hold on what your sentences carry: "9 years engineering, 3 as a team lead of 6," and "I pushed a reliability quarter through against roadmap pressure." Concede in your own words: "I haven't owned a hardware-adjacent roadmap." Do not compare yourself to other candidates, because you cannot know them | The F6 objection again, time-boxed. JD because it scores fit to the role; Pressure delivery because of the sixty-second box |
| I2 | "That 60%. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold, then concede. Hold on your sentence: "after I pushed a reliability quarter through." Say which part was yours, in your own words. Concede plainly anything you do not know about how the figure was counted. Do not say "because of" unless your own account supports it | The attribution probe on F3's figure, in the form a Pressure persona uses |

## Reverse questions for Round 3

| Question | Why it lands |
|---|---|
| "What part of engineering leadership here would you most like to see stronger?" | It asks a VP for a priority, and lets you place your fit against it |
| "What does a manager here do that makes you trust them with more scope?" | It asks for the bar for growth in the exact terms of your stated limit on managing managers |
| "How do you want leaders here to handle pressure from the roadmap?" | It ties to the one sentence of yours about roadmap pressure without leaning on it |
| "What has the hardware and engineering relationship looked like at its best?" | It asks for the good version of the seam you have not owned |
| "What would make you say this hire worked, a year in?" | It turns a values conversation into a shared definition of success |

---

## Prohibited claims

Built from the fit snapshot before the banks were written. These are what this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F1 | The plain acknowledgment from your sentence: "I haven't managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F6 | The plain acknowledgment from your sentence: "I haven't owned a hardware-adjacent roadmap." No slot |
| Has led two squads or a team of eleven | Inflated form of F1 | F1's quote at its own scope: "3 of my 9 years as a team lead of 6." The limit is the pack's observation: your material says a team lead of 6, not two squads. The slot stays inside that scope |
| Owned hiring for the team, including headcount and offer decisions | Inflated form of F4 | F4's quote at its own scope: you run the hiring loop for backend roles. The slot asks only which parts of how it runs were yours to set |
| The reliability quarter caused the 60% drop | Inflated form of F3 | F3's quote at its own scope: the drop came "after" the quarter. The slots ask how it was counted and which part was yours |
| Personally conducted about 40 interviews | Inflated form of F4 | F4's quote at its own scope, with the ambiguity resolved downward unless your own account says otherwise |

## Upgrade menu

- The full job description text → F1 to F6 requirements become the posting's own lines instead of a short role description, and any mid-list requirement it holds gets its own question
- Your CV → evidence cells quote CV lines as well as your message, and F2, F5 and F7 may stop reading "none given"
- An inspectable artifact behind each figure, such as the on-call metrics report or the write-up of the reliability quarter for the 60%, and the written structure of your hiring loop for the 40 interviews → the F3 and F4 rows can move from medium toward high
- Interviewer names → an interviewer read, per-member personas for the panel, and a reverse question tied to each interviewer's own path
- The recruiter's guidance on the panel and the VP round, including format, any exercise and stated focus areas → coverage for any pre-declared deliverable, and persona weights tuned to what they name
- Search access, or Larkfield's published values page and any strategy notes pasted in → the Monday values cheat sheet and CO questions grounded in Larkfield's current priorities; a deeper pass of up to 6 more searches and 2 more fetches, several more minutes, is available on request
- Your own answers to the answer slots, stated outside a drill → the rows they touch are regenerated with your words quoted in
- A tuesday-dossier.md from an earlier session → verified evidence and allowed strategies per weak area
