I'll read the reference files first, since the skill requires them before I write anything.
The pack is written and saved. I'm now sending the presenting message.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/alone/part-2/rooms/case-7-denied-ab074bf2/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it assuming Tobias is your future hiring manager, since your note didn't say. Web search was refused in this session. Nothing about Saltmarsh's values, its interview loop, its strategy or Tobias's background is in it, and the pack rests on your JD and your note.

Say the word and I'll play the Skeptic on B2, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, or a peer or skip-level, and has the recruiter said anything about focus areas or something to prepare? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

- Candidate: Femi
- Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager, because the note did not say; the persona weights below rest on that assumption
- Session: one 60-minute interview

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. The fit snapshot is the spine, and every question bank draws only on the sentences quoted in it.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. No values-style round was detected, so this pack has no VAL bank |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework on the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` traces to a document you provided; `[inferred]` is this pack's derivation from one, named in the row; `[generic]` is a role-family pattern with no claim about you or Saltmarsh.

## Fit snapshot

No requirement in the JD is a gate. The years line is graded like any other requirement.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [inferred] | discovery | Your material gives the four years as an associate producer and the last two as the calendar; it does not say whether the studio's titles were live-service throughout, and the JD's years line makes a probe on that split likely. Answer slot: if the years before you ran the calendar were also on a live title, say how, in your own words; if they were not, say so plainly and stay with the two years of the weekly calendar |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe on it. Lead with the quote's own terms: you ran it, it was weekly, it was for the main title, it covered the last two years, and add nothing the sentence does not say |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [inferred] | transferability | Words stay at the quote's scope: "I ran the weekly content-drop calendar for our main title for the last two years." The JD asks for live events across two mobile titles; the pack's observation is that the sentence says weekly content drops for the main title, and reaches neither live events nor a second title. Answer slot: expect a probe on how a weekly content drop differs from a live event, and on running two titles at once. If any of the drops were time-limited events, say how they ran, in your own words; if none were, say so plainly and stay with the weekly calendar |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message; "Never led a team, and never worked on a game with in-app purchases" — your message | low | [inferred] | discovery | The JD's verb is coordinate, not lead. Your second sentence states you have not led a team and says nothing on whether you worked with these four disciplines, so the pack cannot tell. Plain acknowledgment, sourced to that sentence: "I haven't led a team." Answer slot: if you worked with design, art, engineering or community on an update, say which and what part was yours, in your own words; if you did not work with one of them, or the work was not yours, say so plainly and stay with the weekly calendar |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [inferred] | transferability | Words stay at the quote's scope: "I presented the monthly retention numbers to the studio head." The JD asks you to own a review and its KPIs; the pack's observation is that the sentence says presented, and shows neither who chose the numbers nor any review of events. Answer slot: if you chose which numbers went into the monthly presentation, or a review followed any content drop, say what it covered and what part was yours, in your own words; if the numbers were handed to you, or no such review existed, say so plainly and stay with presenting them |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe on how the numbers were counted. Lead with the quote's terms: you presented them, they were monthly, they went to the studio head, and add nothing the sentence does not say |
| F7 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [inferred] | transferability | Words stay at the quote's scope: "I wrote the release checklist our QA team still uses." The JD says manage; the pack's observation is that the sentence says wrote, and that QA still uses it, and does not show who ran it at each release. Answer slot: if you ran the checklist at releases or changed it after any, say how and what part was yours, in your own words; if you wrote it and others ran it, or it was never changed, say so plainly and stay with having written it |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | The sentence shows a checklist you wrote and QA still uses, and says nothing about what else you have written. Answer slot: if other written work shows this requirement, name it and say what it was for, in your own words; if the checklist is the nearest example, say so plainly and stay with it |
| F9 | Familiarity with in-app purchases in a mobile live-ops role: a role-family expectation, not stated in the JD | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [generic] | capability | A gap wording cannot close, and you stated it. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to monetization work, and nothing added to make the gap feel smaller |

## Persona table

Weights rest on two things: your own words, which establish one session with the Head of Live Operations, and the hiring-manager relationship prior, which is an assumption. No loop source names any other round, so no archetype fallback is used and no values-style round is detected. Depth follows weight: the top two personas get five questions each.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (bank A) | Live problems on a two-title calendar, an update that slips, a retention dip, a post-event review | High: the hiring-manager prior leads with it, and the JD's calendar, coordination and review lines can each be posed as a live problem | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (bank B) | Quiet probing of F9, F4, F1 and F3 | High: the same prior, and your note names two things you have not done (F9 and F4 quote them), while F1 and F3 are thin | Rehearse B2 until it is boring. State the limit before it is pressed: "Never led a team, and never worked on a game with in-app purchases" (F9). Bridges only from the quotes in F1 to F8 |
| Data-Driven Prober (bank C) | The retention numbers, the post-event KPIs, the checklist | Medium: retention is a named JD requirement, and F6 is a line a prober can test | Know what you can and cannot say about how the numbers were counted, and say plainly when you do not know: "Presented the monthly retention numbers to the studio head" (F6) |
| Conversational (bank D) | The biography question, "what do you know about us", written communication | Medium: the one session likely includes an open conversational stretch, and casual questions on JD topics are still scored | A 90-second arc built from the quotes in F1, F2, F7 and F6 (D1) |
| Pressure (bank E) | Attribution probe, a time-boxed why-you | Low: the hiring-manager prior does not lead with it and no signal raises it | Pause, restate, anchor in what you stated, hold through two follow-ups |
| Values/Behavioral (no bank) | A scored values conversation | Low: your words name one conversation, and no source names a round that assesses values | None needed; if your recruiter names a values round, send it and a bank is added |
| Peer Evaluator (no bank) | Seam-splitting between teams | Low: Tobias is assumed to be your future manager, not a peer | If he is a peer, the answer reweights every bank |

## Question banks

Highest-ROI prep in this pack: B2, the in-app-purchases question. It is the one gap you stated yourself, it cannot be reworded away, and a rehearsed, plain answer changes how the rest of the hour reads.

### Bank A: Case/Strategist (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two titles each want the same weekend for their biggest event. What do you need to know first, and how do you decide?" | CASE | [generic] | Say your structure aloud before you use it. Clarify first: what each event is meant to do, what lead time each of design, art, engineering and community needs, what is already committed, who breaks ties. Then objective, options (move one, shrink one, stagger the content), the numbers you would watch, the risks. Challenge one premise, such as whether they must collide. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's two-title calendar line, aimed at F3, where the evidence is thinnest. CASE because it scores structure; `[generic]` because it is a pattern, not a fact about Saltmarsh |
| A2 | "It is Wednesday. Engineering says Thursday's build will slip two days, and community has already announced the event time. Walk me through the next hour." | CASE | [generic] | Clarify what is fixed and what can move. Then who needs telling, in what order, and what each of design, art, engineering, community and QA needs from you. Name the options (ship late, ship reduced, move the event) with the cost of each, and say what you would record afterward. The guidance makes no claim about your past | The JD's coordination and release-checklist lines (F4, F7) posed as a live problem, so the answer is reasoning and not history. CASE because it scores clarify-then-structure |
| A3 | "You ran the weekly content-drop calendar for your main title. What changes when it becomes a live-events calendar across two titles?" | JD | [inferred] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold the quote at its scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD asks for live events across two titles, so expect a probe on how weekly drops differ from events. If any drops were time-limited events, say how they ran; if none were, say so plainly and stay with the weekly calendar. For what would change, ask rather than assert: what the second title's cadence is, which teams are shared, where the calendars collide | F3 is the evidence for the calendar requirement and the likeliest place for a manager to press. JD because it scores the stated requirement; the premise is your own sentence, nothing wider |
| A4 | "Player retention in the week after an event is down against the weeks before it. Diagnose it." | CASE | [generic] | Clarify first: which players, compared with what, whether anything else shipped or broke that week. Segment, state two or three hypotheses with the data that would separate them, say what you would tell the team today. Name the assumption in your diagnosis you would defend least, before they do. No claim about your past | F6 and F5 meet here: retention is a named requirement and the post-event review is the place it is read. CASE with JD content; the weakest-assumption move is built in |
| A5 | "An event has just ended. Design the post-event review: what goes in it, who sees it, and what happens next." | CASE | [generic] | Start from the decision the review feeds, then the few numbers that answer it, what each is compared against, who receives it and in what written form, and what changes as a result. Keep it short enough to read in one sitting. No claim about your past | The JD's post-event review line (F5) as a design problem, with F8's written-communication line riding along. CASE because it scores structure; JD content |

### Bank B: Skeptic (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The JD asks for three or more years producing live-service games or apps. How do your four years add up to that?" | JD | [inferred] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Hold the quotes at their scope: "I was an associate producer at a puzzle-game studio for four years, and for the last two I ran the weekly content-drop calendar for our main title." Answer slot: if the years before the calendar were also on a live title, say how, in your own words; if they were not, say so plainly and stay with the two years of the weekly calendar. Do not call all four years live-service unless the first branch is true. Hold through two follow-ups by returning to those sentences, never by adding to them | F1 is the years row and the first place a screen-minded manager looks. JD because it scores the stated requirement |
| B2 | "You haven't worked on a game with in-app purchases. Which part of this role does that make hardest for you on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Presented the monthly retention numbers to the studio head" | The deepest rehearsal in the pack. Four moves, in order. One, name the limit before it is pressed: "I haven't worked on a game with in-app purchases." Two, hold what your sentences carry, at their own scope: "I ran the weekly content-drop calendar for our main title for the last two years" and "I presented the monthly retention numbers to the studio head", and stop there; let the interviewer draw any inference. Three, a plan, said as a plan: what you would ask to be shown and who you would ask in the first weeks. Four, hold through two follow-ups by repeating moves one and two, and on the third concede specifically: that part is not something you have done, and you would rather have it explained than guess. Follow-ups to rehearse: how long until you are useful there, answered with your own estimate or with what you would do first and no figure you cannot stand behind; and whether the gap reaches the KPIs, answered from C2's slot | F9 is a capability gap you stated, which wording cannot close, so the rehearsal is candor plus a plan. JD because it scores whether you can do the listed job including its gaps; named the highest-ROI prep because it will arrive in some form |
| B3 | "You would be coordinating design, art, engineering and community on every update, and you haven't led a team. How do you get four disciplines to move to your calendar?" | JD | [inferred] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years" | Name the limit plainly: "I haven't led a team." Keep the JD's verb: the role says coordinate, so do not let it be heard as lead, and do not volunteer lead either. Answer slot: if you worked with design, art, engineering or community on an update, say which and what part was yours, in your own words; if you did not work with one of them, or the work was not yours, say so plainly and stay with the weekly calendar. For how you would start, say it as a plan: ask each team its lead times and what it needs from the calendar | F4 is a discovery row: the material shows the limit you stated and not the coordination the JD asks about. JD because it scores a stated responsibility |
| B4 | "Why this move, and why now?" | EXP | [generic] | The only safe answer is your own reason; none is quoted in your material, so the pack supplies none. Structure it: what you want to do next, said about the work and not about what you are leaving, then which listed parts of this job pull you (the two-title calendar, the post-event review, the release checklist with QA). Keep it under a minute | A motivation-consistency probe that a skeptic asks of any move. EXP because it tests whether the story is consistent; `[generic]` because the pack has no sentence of yours on it |
| B5 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Choose the one answer you can say plainly with a plan, and state it in your own words: "I haven't led a team" or "I haven't worked on a game with in-app purchases". Then the plan, said as a plan, then where the work you have done reaches the nearest requirement, using only the quotes in F5 to F7. Do not pick a weakness that is not one | The standard skeptic stem, and your own sentence supplies two honest answers (F4 and F9). JD because it scores honest self-assessment against the listed job |

### Bank C: Data-Driven Prober (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented to the studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | The beats are the sentence's own: the numbers were retention numbers, monthly, presented to the studio head. Answer slots, each in your own words: how the numbers were counted; what they are sensitive to; the assumption behind them you would defend least; which part was yours. If you do not know how they were counted, say so plainly. Never offer a figure or a method that is not yours | F6 is the line a prober can test. EXP because it checks what was actually yours; defend-the-number slots because retention numbers are the quantified part of the material |
| C2 | "The role owns the post-event review and the KPIs it reports. After an event, which player-retention numbers would you put in front of the team, and why?" | JD | [inferred] "Presented the monthly retention numbers to the studio head" | Reason aloud about which numbers and why, and name the assumption in your choice you would defend least. Where you refer to your past, stay at: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which numbers went into that presentation, or a review followed any content drop, say what it covered and what part was yours; if the numbers were handed to you, or no such review existed, say so plainly and stay with presenting them | F5 is a transferability row and this is where it gets pressed; F6 rides along. JD because it scores the stated ownership line |
| C3 | "Walk me through the release checklist you wrote and how QA uses it." | JD | [inferred] "Wrote the release checklist our QA team still uses" | Beats the sentence states: you wrote it; QA still uses it. Answer slot: the JD says manage the checklist with QA, so expect a probe on who ran it at each release. If you ran it at releases or changed it after any, say how and what part was yours; if you wrote it and others ran it, or it was never changed, say so plainly and stay with having written it | F7 is the evidence for the checklist requirement and a short premise a prober can walk through. JD because it scores the stated responsibility |

### Bank D: Conversational (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc whose beats are the four sentences, in your own words and at their own scope: the four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for the main title over the last two years, the release checklist QA still uses, the monthly retention numbers presented to the studio head. Answer slot for the close: why live operations and why this role, in your own words; none is quoted, so the pack supplies none | The opener a conversational interviewer uses, and a casual question that is still scored. F1, F2, F7 and F6 supply the beats; EXP because it tests whether the story hangs together |
| D2 | "Tell me about the weekly content-drop calendar. What was it like to run?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Beats: it was weekly, it was content drops, it was for the main title, it covered the last two years. Say what the work consisted of in your own words. If some parts were not yours to decide, say so plainly and stay with the sentence | F2 is the strongest direct line against a JD requirement, so a friendly probe on it is likely. JD because it scores the content-calendar requirement in a casual register |
| D3 | "The job leans on clear written communication. Tell me about something you wrote that other people relied on." | JD | [inferred] "Wrote the release checklist our QA team still uses" | Story-mapped on the sentence: you wrote the checklist, and QA still uses it. Answer slot: if other written work shows this requirement, name it and say what it was for; if the checklist is the nearest example, say so plainly and stay with it. Do not call your writing clear; describe what you wrote and let them judge | F8 is a discovery row with a thin quote. JD because the question comes straight from the written-communication line |
| D4 | "What do you know about Saltmarsh Games, and why this role?" | CO | [generic] | Research on Saltmarsh did not run for this pack, so use only what you have found yourself. Pick two things you actually know about the studio or its titles, say where you found them, and tie one to a listed part of the job (the two-title calendar, the post-event review). If you know little, say so plainly, then say what drew you to the listed work. Your reason is your own | The homework question. CO because it tests altitude on the company; `[generic]` because no research ran, and the upgrade menu says what would change that |

### Bank E: Pressure (weight low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Pause and restate the question. Hold: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: say which parts were yours to decide, in your own words; if the contents were set by others, or the decisions were not yours, say so plainly and stay with that sentence. Hold through two follow-ups, then concede only what you cannot back | F2 is the line an attribution probe aims at. EXP because it tests precise attribution |
| E2 | "Sixty seconds: why you over someone who has already run live events on a game with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Presented the monthly retention numbers to the studio head" | Three beats in sixty seconds. What you have done, at scope: "I ran the weekly content-drop calendar for our main title for the last two years" and "I presented the monthly retention numbers to the studio head". The limit, plainly: "I haven't worked on a game with in-app purchases." Then what you would do first, as a plan. Do not assert a trait such as learning fast; let the plan carry it. Hold through two follow-ups | F9 is the gap this pressure question uses, and F2 and F6 are what you hold. JD because it scores fit against the listed job |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1, 3+ years producing live-service games or apps | B1, D1 |
| F2, running a content calendar | D2, E1, D1 |
| F3, live-events calendar for two mobile titles | A1, A3 |
| F4, coordinating design, art, engineering and community | A2, B3 |
| F5, post-event review and KPIs | C2, A5 |
| F6, player-retention metrics | C1, C2, A4 |
| F7, release checklist with QA | C3, A2 |
| F8, clear written communication | D3, A5 |
| F9, in-app purchases (role-family, not in the JD) | B2, B5, E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first 90 days look like for this role on each of the two titles?" | It asks what success means and shows you are planning for two titles, the part F3 leaves thin |
| R2 | "When an event under-performs, what does the post-event review change, and who reads it?" | It tests how seriously the review is used, the line F5 rests on, and signals you care about what happens after the numbers |
| R3 | "I haven't worked on a game with in-app purchases, so which numbers does the team look at first after an event?" | It names the limit once, on your terms (F9), and turns it into a question about your first month |
| R4 | "How do design, art, engineering and community work with the calendar today, and where does it creak?" | It asks about the coordination in the JD (F4) and invites the honest answer a new producer needs |
| R5 | "How is the release checklist used between producers and QA today?" | It shows interest in the line F7 touches, and tells you how much of that practice is already set |
| R6 | "What would you most want the person in this role to have changed by the end of the first year?" | It ends on the outcome the role is for, and gives you the interviewer's own words to refer back to |

## Prohibited claims

Built before the banks. The honest form is always the quote at its own scope; the limit is the pack's observation and not words for you, except where you stated the negative yourself.

| Not coached | Basis | Honest form |
|---|---|---|
| Led, managed or directed the design, art, engineering or community teams | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't led a team." No answer slot reopens it |
| Worked on, owned or measured in-app purchases or monetization | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." Then a plan, said as a plan |
| Ran live events across two titles | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says weekly content drops for the main title. A3's slot stays inside the calendar |
| Owned the post-event review or the KPIs | Inflated form of F5 | F5's quote at its own scope. The material says presented the monthly retention numbers, not who chose them. C2's slot stays inside what you presented |
| Managed the release checklist with QA | Inflated form of F7 | F7's quote at its own scope. The material says wrote it and QA still uses it. C3's slot stays inside having written it |
| Three or more years producing live-service games | Inflated form of F1 | F1's quotes at their own scope: four years as an associate producer, and the last two running the weekly calendar. B1's slot asks only about the years before the calendar |

## Sources

Provided documents: the job description pasted in your message; your background as written in your message; the interviewer's name and title and the interview's length, from your message. No dossier was present, so no section rests on one.

Searches sent, every one refused because web search was not permitted in this session:

- "Saltmarsh Games values": refused
- "Saltmarsh Games interview process live operations producer": refused
- "Saltmarsh Games mobile studio strategy news": refused
- "Tobias Wrenfield Saltmarsh Games": refused

No page was fetched.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have moved a values cheat sheet, if a values round is documented, and the VAL questions. None was written; nothing about Saltmarsh's values is in this pack |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have moved loop structure and persona weights. Your own words establish the one session, so the weights rest on that and the assumed relationship |
| 3. `Saltmarsh Games mobile studio strategy news` | unavailable | Would have moved a strategy-grounded CO or CASE question and a grounding brief. D4 is `[generic]` instead |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have moved the interviewer read, any persona adjustment from his public footprint, and a reverse question tied to his path. The read is absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web search permission → the four refused searches can run: a values cheat sheet if a values round turns up, strategy-grounded CO and CASE questions in place of D4's generic version, an interviewer read, and a reverse question tied to Tobias's own path. A deeper pass, up to 6 more searches and 2 more fetches and several more minutes, can follow on request
- The recruiter's note on focus areas, or a pre-declared task such as a presentation or a case → coverage tuned to it, plus a build section for any declared deliverable
- Confirmation that Tobias is your future manager, or a peer or skip-level → persona weights recomputed and banks added or dropped
- How much prep time you have → a prioritized schedule of the few questions worth doing first
- The release checklist itself, a redacted calendar page, or a slide from the monthly retention presentation → F7, F2 and F6 from `medium` toward `high`, because each is an inspectable artifact in this field
- Your answers to the answer slots in F1, F3, F4, F5, F7 and F8, said outside a drill → each row regenerates with your own words in its evidence cell
- Saltmarsh's published values or careers page, pasted → a values cheat sheet from the page, without a search
- A `tuesday-dossier.md` with verified evidence and a named highest-risk objection → B2's objection becomes evidence-derived rather than inferred, and each weak area carries a strategy constraint
