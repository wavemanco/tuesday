I'll read the reference files the skill points to before building the pack.
Dara, your prep pack for all three rounds on 29 November is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/alone/part-2/rooms/case-8-canned-7c9f4efa/ashgrove-credit-union_member-experience-lead_interview_pack.md`. It has one shared fit snapshot and a mini-pack per round, with 30 questions in all. Round 3 includes a cheat sheet for the four values.

Interviewers beyond their roles aren't named yet, so persona weights come from the round types and the recruiter's email. I ran no web searches, because your pasted JD, values text, recruiter email and strategy summary already cover everything I would have looked up.

The most likely objection is that you've never worked in a contact centre, while the JD's headline line has you owning complaints across branches and the contact centre. Question B1 rehearses it with two follow-ups, and I'd spend your first hour there. Presenting above regional level is the other limit your message states. It's covered in A8 and B5.

The pack also flags where your material is thin: the regulated-complaints requirement, what your spreadsheet counted and whether it was Excel, coaching beyond tellers, and any work with digital teams. Those rows give you two honest answers each, and the upgrade menu lists what to send me to firm them up.

- I can play one of the interviewers live. I'd suggest the Head of Member Services on B1.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- I can convert the pack to a Word document if you'd like.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack — Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara · **Loop mode:** three rounds on 29 November 2026 · **Built:** 20 November 2026

| Round | Who | Length | What the recruiter's email says |
|---|---|---|---|
| 1 | The recruiter | 30 min | Process conversation |
| 2 | Head of Member Services, who would be your manager | 45 min | Mostly behavioural |
| 3 | Panel of two branch managers | 60 min | Includes a 20-minute case on a complaint escalation; the panel is also the values round, scored against the four values |

Interviewers beyond their roles have not been assigned, so there is no interviewer read in this pack; persona weights come from the round types and what the recruiter wrote.

**Highest-ROI prep in the pack: B1** — the contact-centre objection, rehearsed with two follow-ups. It is the objection the fit snapshot finds in the JD's headline line, and your own message states the limit behind it.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Rehearse both. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Tag | Name | What it is scoring |
|---|---|---|
| VAL | Behavioural / values alignment | Whether past behaviour shows Ashgrove's published values |
| EXP | Work-experience deep-dive | Whether your background survives scrutiny; what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth; thinking at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

An answer slot is an instruction for the interview: it names what an interviewer is likely to probe and gives you two honest branches, one if you did the thing and one if you did not. It asks nothing of you here.

## Fit snapshot (shared across all three rounds)

Quotes in the evidence column are your own sentences from your message. Everything the pack says about your past rests on them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | The quote already reaches the years, in other terms. Say it in its own terms: you spent six years in retail banking, the last three as a branch supervisor. The JD says customer operations and the quote says retail banking, so use the quote's words for your own past. A message sentence with nothing inspected behind it, so expect a probe on it |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | Your material says a formal complaints log and does not show whether the complaints in it were regulated. Answer slot: the JD's regulated-complaints line makes a probe on what rules governed the log likely. If rules of that kind applied to the complaints you logged, say which, and what your part in following them was, in your own words; if none did, or you did not deal with that side, say so plainly and stay with the log: "I handled the branch's formal complaints log." |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's across-branches line makes a probe on what happened to complaints beyond your own branch likely. If any complaint from your log went on elsewhere and you stayed with it, say what happened and what part was yours; if none did, or it left your hands, say so plainly and stay with the log |
| F4 | "and the contact centre" (the same JD line) — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says a monthly complaints spreadsheet your regional manager uses, and does not show what it counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what your spreadsheet showed. If it counted complaint volumes or how long complaints took to resolve, say which and how each was worked out, in your own words; if it counted neither, say so plainly and say what it did show |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote says spreadsheet, not Excel. Answer slot: the JD names Excel, so expect the tool to be asked. Name the tool you built it in; if it was Excel, say what in it was yours to build, in your own words; if it was another tool, say so plainly and say what it was |
| F7 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | Your message states the limit and does not show what you have presented below it. Words: "I haven't presented to anyone above regional level." Then how you would prepare for a first senior audience, said as a plan and never as a past |
| F8 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers and an escalation script, not coaching at supervisor level, and the words stay there: "trained new tellers on our escalation script." Answer slot: the JD says supervisors, so expect a probe on that. If you ever coached a supervisor or a peer on an escalation, say how and what happened, in your own words; if you did not, say so plainly and stay with the tellers and the script |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | What strong evidence looks like: a named piece of work with a digital or technology team, and your part in it. Answer slot: if you have worked with such a team, say on what and what your part was, in your own words; if you have not, say so plainly and say how you would approach it, as a plan |

## Grounding brief — Ashgrove's July 2026 strategy

The recruiter sent you the 2026 strategy brief. These are the four points you gave me from it; the brief itself was not pasted, so nothing beyond these four is claimed. It is public and every prepared candidate has read it, so bring one fact to show grounding and then your own view with a reason (the differentiation rule is applied in B10, B11 and C11).

| Item | Provenance | Why it matters for this role |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | [grounded] | The JD asks the lead to work with digital teams on self-service journeys (F9); expect the target to frame digital questions in all three rounds |
| Consolidate eight branches into five hubs over 2027 | [grounded] | The JD's across-branches line (F3) and the branch-manager panel make the hub change a likely topic; whether these two managers are affected is not known |
| Launch a small-business lending product in Q1 2027 | [grounded] | Not in the JD; a use is one line of homework in A2 or a reverse question, not a case topic |
| Main competitive pressure is app-only banks | [grounded] | Gives the digital target its competitive reason; useful vocabulary for B10 |

## Round 1 — Recruiter screen (30 minutes)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly opener, journey question, pay, notice, location, reason for leaving | High. A recruiter screen sits at this persona by round-type prior; the recruiter's email describes only the length and the interviewer. It is scored even when it feels casual | Prepare the ninety-second arc (A1) and a plain answer to each logistics question (A3 to A6) |
| Skeptic (light) | Quiet check of the two limits your own message states | Medium. The prior for a screen is a light Skeptic; the JD's contact-centre and senior-presentation lines meet the two negatives you stated (F4, F7), so a short probe on each is plausible | Say each limit plainly in one sentence, then stop and give the plan (A7, A8) |

### Question bank

**Conversational / Rapport Builder**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Open with the span in the quote's words: six years in retail banking, the last three as a branch supervisor. Then the three things your material states about those years, each in its own scope: you handled the branch's formal complaints log, you trained new tellers on your escalation script, and you built the monthly complaints spreadsheet your regional manager uses. Close on why you want this role, in your own words; the pack supplies no reason. Keep it to ninety seconds | F1 is the years the screen checks first, and F2, F3, F5 are what the arc leads into. EXP because it tests your account against what the recruiter has read; it arrives in rapport register but is scored |
| A2 | "What draws you to Ashgrove, and to this role?" | CO | [grounded] | Give your real reason in your own words; the pack supplies none. Show current homework with one fact from the grounding brief, such as 40% of member service moving to digital by 2028 or eight branches becoming five hubs over 2027, and say how it connects to the job. Use one of Ashgrove's value phrases only if it is true for you; do not offer a slogan as your reason | The strategy brief and the values page are the two things any candidate can cite, so the differentiator is a reason that is yours. CO because it scores homework depth |
| A3 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first. The pack supplies no figure and your message states none | A recruiter screen carries a pay question; JD because it concerns the terms of the listed job |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | The recruiter screen's notice check; JD because it concerns the listed job's start |
| A5 | "The role covers branches and the contact centre. Where could you be based, and how would getting between sites work for you?" | JD | [grounded] | Logistics slot: say your actual location and any limit on moving between sites. If the recruiter has not said where the role is based, ask | The JD's across-branches line is the source of the question, and the 2027 hub change could make it a live one. JD because it concerns the listed job's terms |
| A6 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot: give your real reason in one plain sentence, then what you are moving toward. The pack supplies no reason and does not suggest one | The screen's motivation-consistency check; EXP because it is about your own history |

**Skeptic (light)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A7 | "The role covers the contact centre as well as the branches. What's your background there?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say it plainly: "I haven't worked in a contact centre." Then what your material does carry, at its own scope: "I handled the branch's formal complaints log." Then a plan in your own words: what you would want to see first and who you would ask. Do not dress the branch work up as contact-centre exposure. Forty-five seconds | F4 is the stated gap in the headline requirement and the first thing a recruiter relays to the manager. JD because it scores a stated requirement |
| A8 | "Part of the job is presenting to senior leaders. What's your experience of that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Say it plainly: "I haven't presented to anyone above regional level." Then what you built, at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." Then a plan in your own words for preparing a first senior audience | F7 is the second stated limit and the JD lists the requirement by name. JD because it scores a stated requirement |

### Reverse questions — Round 1

| Question | Provenance | Why it lands |
|---|---|---|
| "How is the contact-centre side of this role set up today, and who would I work with there day to day?" | [grounded] | It meets your stated gap head-on and shows you are already thinking about how to learn it |
| "Is there anything in my background you would want me to address before I meet the Head of Member Services?" | [generic] | It surfaces the recruiter's own doubts while you can still answer them |
| "Which sites would the role be based at, and how much movement between branches, hubs and the contact centre does it involve?" | [grounded] | Builds on the JD's across-branches line and the brief's hub plan; also settles your logistics |
| "What does the panel's 20-minute case usually look like: a scenario you read beforehand or one given on the day?" | [grounded] | The recruiter's email names the case but not its format; the answer decides how you rehearse C6 to C8 |
| "Where does the digital team sit in relation to this role, and who leads the self-service work?" | [grounded] | Shows you read the JD's digital line and the 40% target together |

## Round 2 — Head of Member Services (45 minutes, your future manager)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps in the JD against your background: contact centre, regulated complaints, presenting, the spreadsheet | High. A hiring manager sits at Case/Strategist and Skeptic by round-type prior because they are derisking the hire; F2, F4, F5, F6 and F7 are where your material is thin or states a limit | Rehearse B1 until it is boring; state each limit plainly, hold your quoted material at its own scope, then give a plan (B1 to B5) |
| Values / Behavioral | "Tell me about a time" questions, themed on the JD and the published values | High. The recruiter wrote that this round is "mostly behavioural", which moves this persona up from the manager prior | Choose stories your own sentences carry; where none does, use the selection scaffold and its honest branch (B6 to B9) |
| Case / Strategist | A live problem from the strategy brief | Medium. The prior says a manager brings problems from their own roadmap, but "mostly behavioural" lowers it; the brief gives them two ready topics | Clarify, structure, then one respectful challenge to a premise; bring one brief fact then your own view (B10, B11) |

### Question bank

**Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked in a contact centre, and this role owns the complaints process across it. Help me understand how that works." | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Deepest rehearsal in the pack. Pause, restate the question in a few words. Opening hold: "I haven't worked in a contact centre. I handled the branch's formal complaints log." Then a plan in your own words: what you would learn first and from whom. Follow-up 1, likely "So you can't tell me what the contact centre's people need": agree to the limit in one sentence and name what you do not know, which is how the contact centre handles its side of the process; do not offer knowledge you have not claimed. Follow-up 2, likely "Why take that risk over someone from a contact centre": hold the same ground, using the log, the escalation script and the spreadsheet each at its own scope and nothing more, and concede that a contact-centre candidate would know a channel you have not worked in. Never say you would match them on day one. The limit, named before it is asked for: this answer holds the log, the script and the spreadsheet, and holds no contact-centre claim. Ninety seconds for the opening, short for each follow-up | F4 is the stated gap in the JD's headline line and your manager owns the outcome of the hire, so this question will arrive in some form. JD because it scores a stated requirement; the delivery is a Skeptic's with a pressure edge |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one and mean it; your own message states two limits, the contact centre and presenting above regional level. Say it as "I haven't...", then your plan. Do not name a strength dressed as a weakness | F4 and F7 are the two limits you stated; the question asks you to choose between them. JD because it scores the stated requirements |
| B3 | "The role needs experience of regulated complaints. What have you handled?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold the quote at its scope: "I handled the branch's formal complaints log." Answer slot: the JD says regulated, so expect a probe on what governed the log. If rules of that kind applied to the complaints you logged, say which and what your part in following them was, in your own words; if none did, or you did not deal with that side, say so plainly and stay with the log. Hold through two follow-ups by returning to the log, never by adding to it | F2 is the place the "regulated" word presses hardest, and the manager will test it. JD because it scores the stated requirement |
| B4 | "Tell me about the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what it is in the quote's own words. Answer slot: the JD asks for volumes, resolution times and Excel, so expect all three probed. Say what the spreadsheet counted and how, name the tool, and say what in it was yours; where you do not know how a figure was counted, say so plainly rather than offering a method. If it counted neither volumes nor resolution times, or it was not built in Excel, say so plainly and say what it was | F5 and F6 are the evidence for the reporting lines and neither shows what was counted or which tool was used. EXP because it tests what was actually yours |
| B5 | "Your monthly report would go to senior leaders. Walk me through how you would present a month where complaint volumes rose." | CASE | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Clarify first: what the leaders already see and what decision the report feeds. Then say it in the order you would present it: the headline, what you know, what you do not yet know, what you are doing about it, what you need from them. Think aloud. If asked about your experience of presenting at this level, the plain answer is: "I haven't presented to anyone above regional level." This guidance makes no other claim about your past | The JD names monthly reporting and senior leaders together (F5, F7), so a live version of the task is likely. CASE because it asks for a structure on a role problem; JD content, CASE delivery |

**Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B6 | "Tell me about a time you helped someone handle an escalation they were struggling with." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on the quote: new tellers, an escalation script, and your training of them, told in your own words. Answer slot: the JD says supervisors, so expect a probe on coaching at supervisor level. If you ever coached a supervisor or a peer on an escalation, say how and what happened; if you did not, say so plainly and stay with the tellers and the script. Do not tell how any session went unless it is something you remember happening | F8 is the evidence for the coaching line and stops at tellers. JD because it scores the stated responsibility in behavioural form |
| B7 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold; the log is the nearest thing your material carries and it does not show a problem you stayed with. Pick a problem that became yours when you found it, a point where it could have been handed on and was not, and an outcome you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it | The theme is the published value "Own the Fix". F3 is where the same idea meets the JD's ownership line. VAL because the scoring is about behaviour matching a value |
| B8 | "Tell me about a time you worked with a digital or technology team." | JD | [grounded] | Answer slot for F9: nothing in your material speaks to this. If you have, say on what, what your part was and what changed for members, in your own words; if you have not, say so plainly and say how you would approach it as a plan, starting from the member problems you would bring | F9 has no evidence given and the JD names the line. JD because it scores a stated responsibility |
| B9 | "When did you put a member ahead of an internal metric?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold; your material does not carry such a decision. Pick a time a member's interest and an internal measure pulled apart, you chose the member, and you can say what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it | The theme is the published value "Members First, Always". VAL because a specific decision is the bar |

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B10 | "The strategy aims to move 40% of member service to digital channels by 2028. Which complaints would you keep with a person, and which could go to self-service?" | CO | [grounded] | Clarify first: what the data show about complaint types and volumes, and which complaints fall under formal handling rules. Then objective, segments, approach, metrics (the JD names volumes and resolution times) and risks. Bring one brief fact to show grounding, then your own thesis with a reason; two to test: the human share gets harder cases, so escalation coaching matters more; or self-service fails if members must explain twice. Concede what you cannot know without their data. This guidance makes no claim about your past | The 40% target meets the JD's digital line (F9). CO because it tests strategy at the company's altitude; CASE delivery |
| B11 | "Eight branches are becoming five hubs over 2027. What does that do to the complaints process?" | CASE | [grounded] | Clarify first: what moves when, and how a member raises a complaint during the change. Objective: no member has to explain twice and no complaint falls between a branch and a hub. Bring the brief's fact, then a thesis of your own, such as the risk being the hand-off, and say why. Concede you do not know their current set-up beyond the brief. This guidance makes no claim about your past | The hub plan meets the JD's across-branches line (F3). CASE because it is a live problem from the role |

### Reverse questions — Round 2

| Question | Provenance | Why it lands |
|---|---|---|
| "Which complaints are hardest for the branches to resolve today, and what happens to them?" | [generic] | Shows you are thinking about the work before the process |
| "How do you expect the 40% digital target to change what reaches the complaints process?" | [grounded] | Uses the brief and asks the manager's own view rather than reciting it |
| "What would a good first ninety days look like, and what would you want me to have learned about the contact centre by then?" | [grounded] | Turns your stated gap into a joint plan |
| "Where does this role sit between the branches, the contact centre and the digital team, and who decides when they disagree?" | [grounded] | Tests the seam you will meet in round 3 and shows you read the JD |
| "What do senior leaders want from the monthly report, and who would I present it to first?" | [grounded] | Addresses your stated presenting limit without naming it and asks for a first audience |

## Round 3 — Panel of two branch managers (60 minutes, including a 20-minute case)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes scored against Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | Very high. The recruiter wrote that the panel is the values round and scores against the four values, and a loop source documents it | One story or scaffold per value; "we" for context, "I" for contribution; pick stories where the hard truth landed and, where your material shows none, say so (C1 to C5) |
| Case / Strategist | The 20-minute complaint-escalation case | High. The recruiter's email names the case; the scenario itself is not known, so C6 to C8 are a rehearsal pattern, not a prediction | Clarify, objective, approach, metrics, risks; think aloud; challenge one premise respectfully (C6 to C8) |
| Peer Evaluator | Branch-side questions on the seam with the complaints lead and the coaching of supervisors | Medium. Branch managers sit on the branch side of a role that coaches branch supervisors; this is the pack's reading of their position, not something the email says | Reciprocity: ask what they need first, offer principles rather than a made-up seam (C9 to C11) |

A panel blends the top two personas of each member's relationship. No panel member is named, so no per-member assignment is possible. Skeptic questions from rounds 1 and 2 can return in collegial form; C7 and C9 carry your two stated limits.

### Question bank

**Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: your material does not carry such a decision. Pick a decision where the member's side and another side differed, you chose the member's, and you can say what it cost or what followed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, such as the log, at its own scope, or say how you would handle it | Theme is the published value "Members First, Always". F3 is the nearest evidence and does not show the decision. VAL because specific behaviour is the bar |
| C2 | "Tell me about a time you made something clearer for a member or a colleague." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold. Your sentence says you trained new tellers on the escalation script; it does not say you wrote or rewrote the script, so do not claim that. Pick a time something had to be explained a second time and you changed how it was said, and say what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it | Theme is the published value "Plain Words" ("if a member needs it explained twice, we wrote it wrong"). F8 is the nearest evidence and stops at training. VAL because the value is about wording |
| C3 | "You built a monthly complaints spreadsheet. Neighbours, Not Numbers: how do you keep the member behind the number in view?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Hold the quote at its scope, then the hard truth: a monthly report is numbers, and the value asks that they not be all you see. Answer slot: if anything in your reporting kept a branch or a member visible beyond counts, say what, in your own words; if nothing did, say so plainly and say what you would add in this role, as a plan | Theme is the published value "Neighbours, Not Numbers", and the panel can set it against the JD's reporting line. F5 is the only reporting evidence. VAL because the value is the target |
| C4 | "Tell me about a time you found a problem that was not only yours to fix." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold. The value says whoever finds the problem keeps hold of it until it is solved, and the JD makes the lead the owner of the process; your story should show you staying with a problem across a hand-off. Pick a problem where others had a part, say what you kept hold of and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, such as the log, at its own scope, or say how you would handle it | Theme is the published value "Own the Fix". F3 shows the log, not a hand-off. VAL because the bar is a specific decision |
| C5 | "Which of our four values would be hardest for you, and why?" | VAL | [grounded] | Choose honestly. Name the value, say why in terms you can stand behind, and say what you would do about it. A real difficulty with a specific response scores better than "none". This guidance makes no claim about your past | The panel scores against the four values, and a hardest-value question tests self-assessment. VAL because the answer is scored on the published values |

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C6 | "A member tells you they have complained twice and nobody has come back to them. The supervisor on shift is not sure what to do. Walk us through what you do." | CASE | [generic] | Clarify first: what has been recorded, what the member has been told, whether the complaint is already formal. Objective: the member leaves knowing who holds it and when they will hear, in plain words. Approach: the member and the supervisor now, the fix next, and a coaching moment for the supervisor afterwards. Metrics and risks. Challenge one premise respectfully. Concede what you do not know about Ashgrove's process | The recruiter named a 20-minute case on a complaint escalation but not its scenario, so this is a rehearsal pattern built from the JD's escalation line; `[generic]` for that reason. CASE because it is a live problem from the role |
| C7 | "The supervisor says the contact centre already told the member it was sorted. Whose problem is it now?" | CASE | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Take it: whoever finds the problem keeps hold of it until it is solved, and bring the contact centre in. If asked about the contact centre's process, the plain answer is: "I haven't worked in a contact centre." Then ask how hand-offs are recorded. Concede that you do not know their process | F4 meets Own the Fix in one question, and a panel can combine them. CASE because it extends the live problem |
| C8 | "How would you know the fix worked, and what would go in the monthly report?" | CASE | [generic] | Name what you would measure and why: the JD names volumes and resolution times, and you can add the member's own view as a plain-words check. Say what the report would say about this complaint and what you would not put in it. Concede what you would need to learn about how Ashgrove already measures. This guidance makes no claim about your past | A case ends with a measure, and the JD's reporting line (F5) gives the panel the vocabulary. CASE because it closes the live problem |

**Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C9 | "Our supervisors are stretched at the counter. How would you coach them on escalations without adding to the load?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Reciprocity first: what you would ask them about what supervisors find hardest. Then one principle of your own, said as a principle and not as something you have done. Hold the quote at its scope: "trained new tellers on our escalation script". Answer slot: if you ever coached a supervisor or a peer, say how and what happened; if you did not, say so plainly and stay with the tellers and the script. Concede you do not know their current load | F8 is the evidence for the coaching line and stops at tellers. JD because it scores the stated responsibility |
| C10 | "Where is the seam between a branch and the complaints lead? What stays with us, what comes to you, and what happens when we disagree?" | CASE | [grounded] | Propose principles, not a made-up seam. The published value says whoever finds the problem keeps hold of it until it is solved, so offer your own view on what a branch keeps and what the lead owns, and say why. Say how you would settle a disagreement. Concede that you do not know the current set-up and ask what works today. This guidance makes no claim about your past | The JD makes the lead the end-to-end owner (F3) and Own the Fix gives the finder the problem; the two can be set against each other. CASE because it asks for reasoning about a role boundary |
| C11 | "With branches becoming hubs over 2027, what would you want from us, and what could we count on from you?" | CO | [grounded] | Reciprocity: ask what members in their town need first. Offer a principle, such as no complaint falling between a branch and a hub. Bring one brief fact, then your own view. Concede what you do not know about which branches move and when. This guidance makes no claim about your past | The hub plan is the brief's most local change, and a branch-manager panel is closest to it. CO because it tests strategy at the company's altitude |

### Values cheat sheet (Round 3)

Source: the values page text you pasted on 20 November 2026. The meaning column is paraphrased; use the official names.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quote carries a decision; use the selection scaffold in C1 and, if none comes to mind, its honest branch. Nearest row: F3, "I handled the branch's formal complaints log and trained new tellers on our escalation script." |
| Plain Words | If a member needs it explained twice, the wording was wrong | No quote carries it; the closest row is F8, "I handled the branch's formal complaints log and trained new tellers on our escalation script." It shows training on a script, not writing one; use C2's scaffold |
| Neighbours, Not Numbers | Every branch is part of its town | Row F5, "I built the monthly complaints spreadsheet our regional manager uses." It is the numbers side of the value, so C3's hard truth is the one to land |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Row F3, "I handled the branch's formal complaints log and trained new tellers on our escalation script." It shows the log, not a problem you stayed with; use C4's scaffold and its honest branch |

### Reverse questions — Round 3

| Question | Provenance | Why it lands |
|---|---|---|
| "What would you want from a complaints lead that you do not get today?" | [generic] | Puts you on their side of the seam before they ask C10 |
| "When a problem is found in a branch, how do you want the lead to work with your supervisors?" | [grounded] | Uses Own the Fix in a question about their practice |
| "What does Neighbours, Not Numbers look like in a monthly complaints report?" | [grounded] | Shows you heard the value and asks them to define it |
| "As branches become hubs over 2027, how will complaints ownership work for your teams?" | [grounded] | Uses the brief's most local change and asks for their view |
| "Which of the four values shows up most in how your branch handles a difficult complaint?" | [grounded] | A panel scoring on the values will have an answer, and yours becomes a conversation |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | A7, B1, B2, C6, C7, C10 |
| "report monthly on complaint volumes and resolution times" | B4, B5, C8 |
| "coach branch supervisors on escalations" | B6, C9 |
| "work with digital teams on self-service journeys" | B8, B10 |
| "4+ years in financial-services customer operations" | A1 |
| "experience handling regulated complaints" | B3 |
| "confident presenting to senior leaders" | A8, B5 |
| "comfortable with Excel reporting" | B4 |
| Published values (all four) | C1, C2, C3, C4, C5 |
| Strategy (digital, hubs) | A2, B10, B11, C11 |
| Pay, notice, location, reason for leaving — logistics, not JD requirements | A3, A4, A5, A6 |

## Prohibited claims

What this pack will not coach, with the basis and the honest form. Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Worked in, or has exposure to, a contact centre | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't worked in a contact centre." Then a plan, never a past |
| Presented to senior leaders | Negative you stated, F7 | The plain acknowledgment F7 gives: "I haven't presented to anyone above regional level." Then a plan, never a past |
| Presented the complaints reporting to regional management | Inflated form of F5 and F6 | F5's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The limit is the pack's observation: your material says a spreadsheet your regional manager uses, not that you presented it |
| Owned the complaints process across branches | Inflated form of F3 | F3's quote at its own scope. Your material says the branch's log, not the process across branches |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope. Your material says a formal complaints log, not that the complaints were regulated |
| Coached branch supervisors on escalations | Inflated form of F8 | F8's quote at its own scope. Your material says new tellers and a script, not supervisors |
| Reported complaint volumes and resolution times in Excel | Inflated form of F5 and F6 | F5's quote at its own scope. Your material says a monthly complaints spreadsheet, not what it counted or which tool built it |

F9 is silence in your material, so it is an answer slot (B8) and not a listed claim.

## Sources

**Provided documents:** the job description you pasted; the values text you pasted, copied on 20 November 2026 from ashgrovecu.org/about/values (named as where the text came from, not fetched); the recruiter's email on the three rounds; your summary of Ashgrove's July 2026 strategy brief (the brief itself was not pasted); your background message. No dossier was present.

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you pasted fixes the four values and the cheat sheet |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email establishes three sessions and who runs each, which fixes the loop and the persona weights |
| 3. `Ashgrove Credit Union strategy` and recent news | skipped | Your summary of the July 2026 brief supplies the four points the CO and CASE rows use; the brief itself is not in hand |
| 4. `interviewer name Ashgrove Credit Union` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The names of the Head of Member Services and the two panel managers (the recruiter can usually send them) → an interviewer read, persona weights tuned to each person's public footprint, and a reverse question tied to someone's own path
- How many hours you have before 29 November → a prep triage ordered to your time, with an explicit insurance line
- The full text of the strategy brief → the grounding brief beyond four points, and CO and CASE rows resting on its own wording
- Your answers to the answer slots, in a message to me: what governed the complaints in your log (F2), what the spreadsheet counted and which tool it used (F5, F6), whether you ever coached a supervisor or peer (F8), any work with a digital team (F9), and anything you have presented at or below regional level (F7) → each of those rows is regenerated from your own words
- An anonymised copy of the monthly complaints spreadsheet or the log's structure, with member details removed → the inspectable artifact that would raise F2, F5 and F6 from `medium` or `low` toward `high`
- The recruiter's description of the 20-minute case, or a sample scenario → C6 to C8 become `[grounded]` rows
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, covering role-family loop reports and recent organisation context → the CO and CASE rows and the persona weights rest on more than the brief and the recruiter's email
- A `tuesday-dossier.md` from an earlier evidence check, if you have one → verified claims, an objection ranking that is evidence-derived and prohibited claims that bind every cell
