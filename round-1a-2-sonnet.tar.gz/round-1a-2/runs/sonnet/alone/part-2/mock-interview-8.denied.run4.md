I'll start by reading the skill's reference files.
Bash was declined for that compound command, so I'll make the edits with the Edit tool.
Your prep pack for all three rounds is saved at `/var/tmp/tuesday-measure/1a2/runs/sonnet/alone/part-2/rooms/case-8-denied-c344f4a2/ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it from the recruiter's email, since you gave the full schedule, and nothing you sent needed a follow-up question.

- **Evidence:** the pack quotes only your own sentences, so it never claims more than you said. Two rows are gaps you stated yourself: you've never worked in a contact centre, and you've never presented above regional level. The others are thin or silent: regulated complaints, what your spreadsheet counted, whether it was Excel, coaching supervisors rather than tellers, and digital teams.
- **Rounds:** each round has its own bank and reverse questions. Round 3 also has a values cheat sheet and a practice complaint-escalation case, because the panel scores against the four values.
- **Highest-ROI prep:** question 2B1, where the Head of Member Services sets the role's scope against what you've actually done. It's rehearsed in three levels: hold what your sentences carry, concede the contact centre and senior presenting plainly, then give a plan for each.
- **Gaps to watch:** I did not coach you to claim you owned the process end to end, handled regulated complaints or coached supervisors. Where the interviewer is likely to probe those, the pack leaves a slot for your own answer. The slot also allows "that wasn't my part."
- **Research:** I ran no searches. Your pasted values, the recruiter's email, the strategy points and the JD already covered every target.
- **Limits:** the pack has no interviewer read, because no names are assigned yet. The strategy section holds only the four points you relayed, not the brief's own text.

Say the word and I'll run a live drill as a skeptical Head of Member Services on 2B1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Mode: loop, three rounds on 29 November 2026, as laid out in the recruiter's email. Built 20 November 2026.

| Round | Who | Length | What the recruiter's email says |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | A conversation about the process and you |
| 2 | The Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | A panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; the panel is also the values round, scored against the four values |

No interviewer names are assigned yet, so there is no interviewer read and persona weights come from the round types and the recruiter's own words.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Question IDs read round, persona letter, number: 2B1 is round 2, persona B, question 1. Guidance is scaffolding, not a script: say it in your own words.

| Type | What it is scoring |
|---|---|
| VAL | Whether your past behaviour shows the company's published values |
| EXP | Whether the claims about your background survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | How well you know the company's strategy and competition |
| CASE | How you structure a live problem from the role |

Provenance labels: `[grounded]` traces to something you or the recruiter supplied; `[inferred]` is this pack's derivation, with the source named; `[generic]` is a role-family pattern that makes no claim about Ashgrove or about you.

An answer slot tells you what an interviewer is likely to probe and gives two honest branches. Answer from your own experience; if there was no such step, or it was not yours, say so plainly and return to what you did do. The slots ask nothing of you here.

The highest-ROI rehearsal in this pack is 2B1, the question that sets the role's scope against what your sentences carry. Rehearse it first.

## Fit snapshot

Your evidence column holds only your own sentences from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Words stay at the sentence's scope: the branch's formal complaints log, and training new tellers on your escalation script. The pack's observation: your material says one branch's log and the training, not the process across branches and the contact centre. Answer slot: the JD's scope line makes a probe on what surrounded the log likely. If other steps in handling a complaint were yours, say which and how you worked, in your own words; if the log and the training were your part, or there was no such step, say so plainly and stay with them |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap you stated, and wording cannot close it. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | Your sentence says a formal complaints log; the JD says regulated, and whether those are the same thing is not in your material. Words: "I handled the branch's formal complaints log." Answer slot: if the complaints in that log came under external rules, say how you knew and what the rules asked of you, in your own words; if you did not know, or the log was not tied to any such rules, say so plainly and stay with the log |
| F4 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Your sentence reaches the years in its own terms, retail banking, where the JD says financial-services customer operations. Say it in the sentence's words: six years in retail banking, the last three as a branch supervisor. Do not relabel the work in the JD's vocabulary; let the interviewer make the match |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says a monthly complaints spreadsheet that your regional manager uses; what it counted is not in your material. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's reporting line makes a probe on what the spreadsheet counted likely. Say what it counted, in your own words; if you do not know how a figure on it was counted, or it counted neither of the things the JD names, say so plainly and stay with the spreadsheet you built |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The JD names Excel and your sentence names a spreadsheet; which tool it was is not in your material. Answer slot: say which tool you built it in; if it was not Excel, say so plainly and stay with the spreadsheet you built |
| F7 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap you stated. Words: "I've never presented to anyone above regional level." The JD does not say who counts as a senior leader; your material shows nothing above regional level. Then how you would prepare for a first senior presentation, said as a plan and never as a past |
| F8 | "coach branch supervisors on escalations" — JD | "6 years in retail banking, the last 3 as a branch supervisor."; "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Adjacent work at the sentences' scope: three years as a branch supervisor, and training new tellers on your escalation script. The audience differs: your material says tellers, not supervisors. Answer slot: the JD's coaching line makes a probe on what happened after the training likely. If you followed up with any teller afterwards, say how and what part was yours; if the training was where your part ended, or there was no such step, say so plainly and stay with the training |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing on digital teams or self-service journeys. Answer slot: if you have worked with a digital team or on a self-service journey, say what and which part was yours, in your own words; if you have not, say so plainly and say how you would start |

No row here is a gate: the years and complaints lines are experience requirements, graded like any other.

### Requirement coverage

| JD requirement | Fit row | Question IDs |
|---|---|---|
| Own the complaints process across branches and the contact centre | F1, F2 | 1A1, 1B1, 2B1, 2C1, 3B1, 3D1, 3D2 |
| Regulated complaints | F3 | 1B3, 3B1 |
| 4+ years in financial-services customer operations | F4 | 1A1, 1B2 |
| Report monthly on complaint volumes and resolution times | F5 | 1A1, 2D1, 2D2, 3B3 |
| Comfortable with Excel reporting | F6 | 1B4, 2D1 |
| Confident presenting to senior leaders | F7 | 2A1, 2A4, 2B1, 3B3 |
| Coach branch supervisors on escalations | F8 | 2A2, 2B2, 3B2, 3C1 |
| Work with digital teams on self-service journeys | F9 | 2A3, 2B3, 2C2 |

## Grounding brief

Source: the 2026 strategy brief Ashgrove published in July 2026, which the recruiter sent you. Only the four points you relayed are in hand, so this table holds those and nothing more.

| # | Brief point, as you relayed it | Provenance | Where the pack uses it |
|---|---|---|---|
| G1 | "move 40% of member service to digital channels by 2028" | [grounded] | 1A2, 2C2, 2R3 |
| G2 | "consolidate eight branches into five hubs over 2027" | [grounded] | 2C3, 3R3 |
| G3 | "launch a small-business lending product in Q1 2027" | [grounded] | 2R4 |
| G4 | "the main competitive pressure is app-only banks" | [grounded] | 1A2, 1A3 |

## Round 1: the recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational | Friendly, unstructured openers; casual questions that are still scored | High: the email gives a 30-minute conversation with the recruiter, and the recruiter-screen prior is Conversational plus a light Skeptic | A pre-scripted 90-second arc (1A1); treat casual questions about the JD's hot topics as scored |
| B. Skeptic, light | Knockout checks on the gaps, then logistics: pay, notice, location, reason for leaving | Medium: the screen sits before the manager round, and F2 and F3 are the likeliest knockouts; the logistics rows sit here because they are the screen's checks | Rehearse the contact-centre acknowledgement until it is boring (1B1); give the logistics answers as your own facts |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc from three sentences, in this order and no wider: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on your escalation script; you built the monthly complaints spreadsheet your regional manager uses. Close with why you want this move, in your own words; your material states no reason, so it is yours to give. Add no figures, team sizes or outcomes the sentences do not carry | F4, F1 and F5 are the rows it draws on. EXP because it tests whether the story told matches the record; the register is the Conversational persona's |
| 1A2 | "What do you know about Ashgrove, and what drew you to us?" | CO | [grounded] | Use the four values by their official names and one point from the strategy brief (G1 or G4); one is enough. Say what you would weigh in this job, not a recitation. What drew you is your own reason, in your own words; nothing in this pack supplies it | The recruiter email makes motivation a screen topic; G1 and G4 plus the values cheat sheet in round 3 supply the vocabulary. CO because it tests homework depth; no fit row applies because it asks nothing about your past |
| 1A3 | "Who do you think we're up against, and what does that mean for how we handle complaints?" | CO | [inferred] derived from G4 and the JD's complaints scope | Open with the brief's own framing, app-only banks as the main pressure (G4), to show grounding; then one view of your own, offered as a view to test and not a fact: a complaint is a moment where a member meets the credit union directly, so how it is handled may be one place it differs from an app. Concede that you do not know how app-only banks handle their own complaints | G4 is the consensus item every prepared candidate brings; the divergence is the thesis. CO with CASE delivery because the answer needs structure under a strategy frame |
| 1B1 | "You haven't worked in a contact centre. How would you get up to speed?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say it plainly: "I haven't worked in a contact centre." Then a plan in the future tense: what you would do in your first month to learn how the contact centre handles complaints, and who you would ask. Claim no contact-centre exposure; your material carries none. If pushed on credibility, return to the log, the script training and the spreadsheet at their own scope | F2 is the stated gap on the scope line, and the likeliest first knockout. JD because the role covers the contact centre |
| 1B2 | "The role asks for four-plus years in financial-services customer operations. How does your background line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say it in the sentence's own words: "I have six years in retail banking, the last three as a branch supervisor." Let the interviewer judge the match; do not relabel your work as customer operations unless they do first | F4 is the requirement your sentence reaches most directly. JD because it scores a stated requirement |
| 1B3 | "Tell me about your experience with regulated complaints." | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start where the sentence stops: "I handled the branch's formal complaints log." Answer slot: if the complaints in that log came under external rules, say how you knew and what the rules asked of you, in your own words; if you did not know, or the log was not tied to any such rules, say so plainly and stay with the log. Do not stretch "formal" into "regulated" | F3 is the thin bridge on a stated requirement, so the probe is likely. JD because it scores the requirement; the label is inferred because formal-to-regulated is this pack's derivation |
| 1B4 | "How comfortable are you with Excel?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say the sentence: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: say which tool you built it in; if it was not Excel, or there was no such step, say so plainly and stay with the spreadsheet you built. Describe no functions or features you did not use | F6 is a discovery row, so the honest answer is rehearsed before the probe. JD because it scores a stated requirement |
| 1B5 | "What are you looking for, salary-wise?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first; either is yours to choose. Offer no salary history you do not choose to share | The recruiter-screen row for pay. Nothing in your material states it, so no fit row applies and the only safe answer is your own |
| 1B6 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | The recruiter-screen row for notice; nothing in your material states it |
| 1B7 | "Where are you based, and is getting to our sites workable for you?" | JD | [generic] | Logistics slot: say where you would be working from and any limits, in your own words. Ask which site the role sits at, since the brief's hub plan (G2) changes the branch footprint over 2027 | The recruiter-screen row for location; the JD you pasted names no site, so the ask is the candidate's to make |
| 1B8 | "Why are you looking to move on?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words, and keep it about what you want from this role. Your material states no reason, and the pack supplies none | The recruiter-screen row for the reason for leaving; EXP because a reason has to stay consistent across the three rounds |

### Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| 1R1 | "After the three rounds, what happens next and when do you expect to decide?" | Shows you are planning around the process and gives you a date to hold them to |
| 1R2 | "Is the panel's case set in advance or on the day, and is there anything I should prepare?" | Treats the 20-minute case as the graded part of round 3 and asks for any pre-declared material |
| 1R3 | "When the panel and any further interviewers are assigned, could you tell me their roles?" | Unlocks an interviewer read and per-person weights; the email says interviewers beyond the three roles are not yet assigned |
| 1R4 | "What matters most in this role in its first six months?" | Moves from the JD's list to the priority order, which sets your first-ninety-days answer in 2C1 |
| 1R5 | "How does the work split between branch-facing and contact-centre-facing time?" | Probes the scope line behind F2 and tells you how much of your gap the day-to-day touches |

## Round 2: the Head of Member Services (45 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Values and Behavioral | Open behavioural prompts: "tell me about a time" | High: the recruiter's own words call this round mostly behavioural | Story-map from your sentences where one carries it; where none does, use the selection scaffold and its honest branch |
| B. Skeptic | Quiet probing of the gaps in F1, F2, F7 and F9 | High: this person would be your manager, and the hiring-manager prior pairs Skeptic with Case | Rehearse 2B1 first; concede specifically, never fold on what your sentences carry |
| C. Case and Strategist | Live problems on the role's roadmap: first ninety days, digital shift, hubs | Medium: the manager prior is Case, tempered down by the recruiter's mostly-behavioural | Clarify, objective, segments, approach, metrics, risks; think aloud and challenge one premise respectfully |
| D. Data-Driven Prober | Walks the spreadsheet line by line | Low: you have no headline figure, but one sentence (F5) is the only reporting evidence and a manager reads it closely | Know what you can and cannot say about how it was counted, and say plainly where you do not know |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2A1 | "Tell me about a time you had to deliver an unwelcome message to someone more senior than you." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a message you did not soften away, and a working relationship intact at the end; use "we" for context and "I" for your own part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | An open behavioural prompt for the manager round; F7 is why the honest branch matters here. VAL because it scores whether the hard truth landed |
| 2A2 | "Tell me about a time you helped someone work through an escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-map from the sentence: you trained new tellers on your escalation script; say that in your own words. Answer slot: the JD's coaching line makes a probe on what happened after the training likely. If you followed up with any teller on a live escalation, say how and what part was yours; if the training was where your part ended, or there was no such step, say so plainly and stay with the training | F8 is the adjacent evidence for the coaching line. JD because it scores the stated requirement, with EXP delivery |
| 2A3 | "Tell me about a time you worked with a team outside your own to change how members did something." | JD | [generic] | Selection scaffold: pick a time with a named partner team, what you wanted to change, which part you owned and how it ended. If no such time comes to mind, say so plainly, then say how you would begin working with a digital team on a self-service journey | F9 has no evidence in your material, so the honest branch is the rehearsal. JD because the digital line is a stated responsibility |
| 2A4 | "Tell me about a time you had to present something to people who knew more than you." | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Start with what your material gives: "I've never presented to anyone above regional level." Answer slot: if a nearer instance is yours, say what you presented, to whom and how it went; if you walked no one through the spreadsheet your regional manager uses, or there was no such occasion, say so plainly. Then, in the future tense, how you would prepare a first senior presentation | F7 is a stated gap; the question is the likeliest form of the probe. JD because it scores the presenting requirement |
| 2B1 | "This job owns complaints across every branch and the contact centre. What you've described is the branch you supervised. Why should we think you're ready for the wider job?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | The highest-ROI prep in this pack: hold, then concede, in three levels. Level 1, hold: only what your four sentences carry, at their scope: three years as a branch supervisor, the branch's formal complaints log, training new tellers on your escalation script, the monthly complaints spreadsheet your regional manager uses. Add nothing to them. Level 2, the contact centre: concede in your own words, "I haven't worked in a contact centre," then your plan to learn it. Level 3, senior presenting: "I've never presented to anyone above regional level," then your plan. Name each limit before you are asked for it, then return to the four sentences. Describe what you did and let the interviewer draw the inference; do not claim the wider scope | F1, F2 and F7 together make the likeliest objection: the role's scope is wider than the evidence. Skeptic delivery; JD because it scores the role's stated scope; deepest rehearsal because it will be asked in some form |
| 2B2 | "You've been a branch supervisor yourself. How will you coach people in that seat?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold the sentences as they stand: three years as a branch supervisor, and you trained new tellers on your escalation script. Then say how you would go about it as a plan in the future tense, for instance what you would ask a supervisor first. Answer slot: if you have advised other supervisors, say how and what part was yours; if you have not, or there was no such step, say so plainly and stay with the tellers' training | F8 sits at the coaching line; the audience gap is the probe. JD because it scores the stated requirement |
| 2B3 | "The role works with digital teams on self-service journeys. What's your experience there?" | JD | [grounded] | Answer slot: if you have worked with a digital team or on a self-service journey, say what and which part was yours, in your own words; if you have not, or there was no such step, say so plainly and say how you would start | F9 has no evidence, and G1 makes the digital line more central to the role. JD because it scores a stated responsibility |
| 2C1 | "It's your first ninety days. Where do you start?" | CASE | [generic] | Clarify first: what exists today, who owns what, what is reported and to whom. Then objective, segments (branches, contact centre, digital), approach, the monthly measures the JD names, and risks. Challenge one premise respectfully, and say where you would ask the contact centre's people to teach you | A hiring-manager case from the JD's scope line. CASE because it scores structure; generic because the pack has no source for the current process |
| 2C2 | "The strategy moves 40% of member service to digital by 2028. What happens to complaints?" | CASE | [inferred] derived from G1 and the JD's self-service line | Clarify what the 40% measures; the brief's definition is not in your material, so ask. Then structure: which complaints can move to self-service, which still need a person, what the member sees. Offer a view as a view to test, and concede what you cannot know from outside | G1 is the consensus item; the structure and the view are the differentiation. CASE with CO content because it scores reasoning on strategy |
| 2C3 | "Eight branches become five hubs over 2027. What does that do to complaints, and to the supervisors you would coach?" | CASE | [inferred] derived from G2 and the JD's coaching line | Clarify timing and which sites; do not speculate on which branches close. Then think through members whose branch changes, supervisors' escalation load and keeping the record continuous. Concede that you cannot know the plan from outside | G2 is the most sensitive item in the brief for supervisors. CASE with CO content |
| 2D1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say the sentence, then answer slot: the JD's reporting line makes a probe on what the spreadsheet counted likely. Say what it counted and how an entry got into it, in your own words; where you do not know how a figure on it was counted, say so plainly; name the assumption you would defend least only if you know one. Stay with the spreadsheet | F5 is the only reporting evidence. EXP because it tests what was actually yours |
| 2D2 | "How did you decide what went on it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if you chose what it tracked, say how you decided, in your own words; if its contents were set for you, or there was no such decision, say so plainly and stay with the spreadsheet you built | The follow-up that separates built from specified; F5 and F6 are the rows it draws on. EXP delivered as a Prober probe |

### Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| 2R1 | "What would a good first quarter look like to you in this role?" | Asks your future manager for the scorecard and sets your 2C1 answer |
| 2R2 | "What does the monthly complaints report look like today, and who reads it?" | Shows you are reading the JD's reporting line and tells you how senior the audience is |
| 2R3 | "With 40% of member service moving to digital by 2028, how do you see complaints and the self-service work fitting together?" | Uses G1 and the JD's digital line in one question |
| 2R4 | "When the small-business lending product launches in Q1 2027, how do you expect complaints on it to be handled?" | Uses G3, the one brief item no other question touches |
| 2R5 | "How do you like to be told when a complaint is going badly?" | A manager-style question that shows you are thinking about working for them |

## Round 3: the panel of two branch managers (60 minutes, includes a 20-minute case)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Values and Behavioral | Scenarios mapped to the four values | High: the recruiter's email says the panel scores against the four values | A story for each value where a sentence carries one, a scaffold with the honest branch where none does; the values cheat sheet below |
| B. Case and Strategist | The 20-minute complaint escalation case | High: the email names the case and gives it a fixed slot | Clarify, owner, steps, plain words to the member, record and report; say the structure aloud |
| C. Peer Evaluator | Seam questions: where branch ends and the role begins, what the supervisors get | Medium: branch managers' supervisors are who the role coaches, and the panel prior blends each member's relationship | Reciprocity first, then seam principles to test with them, never a claim to know their seam |
| D. Skeptic, with one Pressure delivery | The same gap probes in collegial form; a time-boxed challenge | Low: two members' names and roles are not known, so the blend rests on the panel prior | The 2B1 structure carries over |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3A1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold for Members First, Always: pick a time with a member, a decision where the easy path was the branch's convenience, what you chose and what it took. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide | The first published value. No fit row carries a story for it, so it is a scaffold. VAL because it scores behaviour against that value |
| 3A2 | "Tell me about a time something you wrote or said had to be explained twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-map for Plain Words from the sentence's second clause: you trained new tellers on your escalation script; say that in your own words. Answer slot: the value asks about wording that needed explaining again; if you changed any wording of the script, or of a letter or explanation, because someone needed it explained again, say what and why; if you did not, or there was no such step, say so plainly and stay with the training | F1's sentence is the nearest your material carries. VAL because it scores the value |
| 3A3 | "When did you put what a branch means to its town ahead of a number?" | VAL | [grounded] | Selection scaffold for Neighbours, Not Numbers: pick a time with a named branch or community, the number that pulled the other way, what you did and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would weigh it. Take no position on the hub plan; ask about it instead | The third published value, and G2 is why branch managers will care about it. No fit row carries a story for it. VAL |
| 3A4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-map for Own the Fix from the sentence's first clause: you handled the branch's formal complaints log. Answer slot: the value asks who kept hold; if a problem you found stayed with you until it was solved, tell that one: what it was, what you did, how it ended; if the log recorded problems that others solved, or there was no such case, say so plainly and stay with the log | The best-mapped value, via F1. VAL |
| 3B1 | "A member complained in branch about a fee on their account. The supervisor's reply did not settle it, and the member has now phoned the contact centre. Take us through what you would do." | CASE | [generic] | A practice case written for this pack; the panel will bring theirs. Structure for 20 minutes, said aloud: clarify first (what the member complained about, what they have been told, what the contact centre has recorded, any deadlines the complaint is under); the objective; one named owner who keeps hold of it until it is solved; the steps in order; what you tell the member, in plain words; how it appears in the monthly figures; what the supervisor takes from it; the risks. Challenge one premise respectfully | The email names the case, and F1, F2, F3 and F8 are the rows it tests. CASE; generic because the pack has no source for how Ashgrove handles escalations |
| 3B2 | "The supervisor followed the script and the member is still unhappy. What do you say to the supervisor?" | CASE | [generic] | Start with what the supervisor did right and ask what they saw; agree one next step with them; the person who found the problem keeps hold of it while you support. Use plain words | F8 at the coaching altitude. CASE |
| 3B3 | "What would you want senior leaders to see each month about cases like this?" | CASE | [generic] | Name what you would report, starting with the two measures the JD names, then the story behind the numbers in plain words and what you would do next. Choose one thing to recommend. Say your reasoning aloud | F5 and F7 meet here; the panel is where reporting to leaders is tested live. CASE |
| 3C1 | "Our supervisors are stretched. How do you coach them without adding to their load?" | JD | [generic] | Reciprocity first: what the supervisor gets from the coaching. Ask what is hardest about escalations in their branch before proposing anything, and offer principles to test with them | F8 from the branch managers' side. JD because it scores the stated coaching line, with Peer delivery |
| 3C2 | "Where does the branch end and your role begin on a complaint, and what do we do when we disagree?" | CASE | [inferred] derived from the JD's coaching line and the Own the Fix value | Propose a principle to test with them, not a claim about how Ashgrove works: the person who finds the problem keeps hold of the member's problem, and the role owns the process, the standards and the reporting around it. Ask how they would want disagreements settled | The seam question. CASE because it scores reasoning about a boundary |
| 3C3 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a time work spanned teams, what you did, who else did what and how credit was shared. If no such time comes to mind, say so plainly, then say how you would handle it | A peer-evaluator stem. EXP because it tests attribution honesty |
| 3D1 | "You've told us about the branch you supervised. What do you know about how a different branch runs its complaints?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold what the sentences carry. Answer slot: if you have seen how another branch handled complaints, say what and how you saw it; if you have not, or there was no such occasion, say so plainly and say what you would ask first | F1's limit in a branch manager's mouth. JD with Skeptic delivery |
| 3D2 | "Sixty seconds: why you, rather than someone who has run a contact centre?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pause, restate the question, then hold: you handled the branch's formal complaints log, trained new tellers on your escalation script and built the monthly complaints spreadsheet your regional manager uses. Concede in your own words: "I haven't worked in a contact centre." Describe what you did and let the panel draw the inference; do not assert what it proves | The Pressure delivery of the F2 gap. EXP because it scores attribution under time pressure |

### Values cheat sheet

The panel scores against these four published values. Names are copied from the page you pasted.

| Value | Working meaning | Mapped story | Questions |
|---|---|---|---|
| Members First, Always | Make the call from where the member stands | Selection scaffold: pick a time you chose the member's side when the easy path was the branch's, what it took and how it ended; if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would decide | 3A1 |
| Plain Words | When a member needs it explained twice, the fault is in the wording | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The training clause is the story; answer slot in 3A2 covers whether any wording changed | 3A2 |
| Neighbours, Not Numbers | Treat each branch as part of its town, not as a line in a table | Selection scaffold: pick a time a branch's place in its community and a figure pulled different ways, what you did and how it ended; if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would weigh it | 3A3 |
| Own the Fix | Whoever finds the problem stays with it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The log clause is the story; answer slot in 3A4 covers whether a problem stayed with you through to its solution | 3A4 |

### Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| 3R1 | "When a complaint lands in your branch, what do you most want from the person in this role?" | Puts the branch managers' own need first and answers 3C1 from their side |
| 3R2 | "What would help your supervisors most from this role in its first months?" | A reciprocity question that points the role at their load |
| 3R3 | "How are your branches preparing for the move to hubs, and where do you expect complaints to come from?" | Uses G2 and asks rather than takes a position |
| 3R4 | "Tell me about a complaint that went well in your branch. What made it go well?" | Gets their working definition of a good outcome, which is what the case is scored against |
| 3R5 | "Which of the four values is hardest to keep hold of on a busy day in a branch?" | Treats the values as practice, not slogans, and invites a story you can answer with |

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before the banks.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's sentence at its own scope. The limit is the pack's observation: your material says the branch's log and the training, not the process across branches and the contact centre. The slots stay inside the log |
| Handled regulated complaints | Inflated form of F3 | F3's sentence at its own scope: your material says a formal complaints log, not whether it was regulated. The slot stays inside the log |
| Coached branch supervisors on escalations | Inflated form of F8 | F8's sentence at its own scope: your material says training new tellers. The slot stays inside the training |
| Reported complaint volumes and resolution times each month | Inflated form of F5 | F5's sentence at its own scope: your material says you built the monthly spreadsheet your regional manager uses; what it counted is not in it. The slots ask only what it counted |
| Has Excel reporting experience | Inflated form of F6 | F6's sentence at its own scope: your material says a spreadsheet, not which tool |
| Has worked in a contact centre | A negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | A negative you stated, F7 | The plain acknowledgment F7 gives: "I've never presented to anyone above regional level." No slot |

## Sources

Provided documents: the job description you pasted; the values text you copied on 20 November 2026 from ashgrovecu.org/about/values (not fetched, since its content was in hand); the recruiter's email on the process; the four points you relayed from the 2026 strategy brief published in July 2026; your message on your background. No dossier was consumed. Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text gives all four by name and wording; it fixes the values cheat sheet and the VAL questions |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email gives three sessions with who runs each and what each holds; it fixes the loop and the persona weights |
| 3. Ashgrove strategy and recent news | skipped | The brief's four points, dated July 2026, fix the grounding brief and the CO and CASE questions |
| 4. Interviewer names at Ashgrove | n/a | No names were given, so no query could be formed; the interviewer read is absent and the upgrade menu says what names would unlock |
| 5. Representative Member Experience Lead JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full 2026 strategy brief → the four grounding rows take the brief's own wording and numbers, and 2C2 and 2C3 can clarify against its definitions
- Interviewer names and roles, once the recruiter assigns them (1R3 asks) → an interviewer read, per-member persona weights for round 3 and one reverse question tied to each person's own path
- Your CV, or any document that shows what the complaints log and spreadsheet held → F1, F3, F5, F6 and F8 can move from your sentences to inspected evidence and a higher confidence band
- Your own answers to the answer slots in F1, F3, F5, F6, F8 and F9 → each row's bridge is rewritten from your words, and the discovery rows can close
- Your own pay, notice, location and reason for leaving → 1B5 to 1B8 hold your words instead of instructions
- The hours you have before 29 November → a prioritised schedule, with everything beyond the first few items marked as insurance
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → Ashgrove strategy beyond the brief, role-family loop reports and recent organisation context, which would sharpen the CO and CASE banks
- A tuesday-dossier.md from an earlier evaluation of the role → verified evidence and a list of claims to avoid, in place of the ones built here from your message
