I'll read the skill's reference files before building the pack.
The pack is written and saved. I'm now sending it to you with the closing notes.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/alone/part-2/rooms/case-4-denied-d5cf49c7/quartzline_product-manager-platform-apis_interview_pack.md`. I built it for a hiring-manager round from your dossier's requirements, confirmed evidence and prohibited claims. It has 18 questions across five personas, and the Skeptic and Case/Strategist personas carry the most weight.

My three web searches on Quartzline's values, interview process and strategy were all refused, because search permission wasn't granted. So the pack has nothing current on the company. The company-strategy questions are scenario-based rather than Quartzline-specific, and D3 ("Why Quartzline?") leaves the company-specific half for you to fill. The pack has no values cheat sheet or interviewer read.

**Where to spend your time:**
- **A1:** the dossier's own objection ("never held the PM title or owned a roadmap"). It's the deepest rehearsal in the pack. The answer concedes both points plainly, keeps your integration work at the scope you confirmed, and closes on a plan.
- **A2:** "Which part would you be weakest at on day one?" This is the roadmap and prioritization gap. The dossier found no evidence for it, so there is no bridge, only an honest acknowledgment and a ramp plan.
- **C2:** the quarterly roadmap-input sessions. The dossier confirmed them with limited proof, so volunteer that limit before a prober finds it.

The reverse questions include the dossier's two on squad decision authority and the adoption baseline. The pack's prohibited-claims section carries the dossier's three prohibited claims, plus "shipped an API or platform product", which I added as the stretched version of your integration work.

Say the word and I'll play the Skeptic on A1 so you can run it live. I can also save an updated `tuesday-dossier.md` recording the gaps this prep exposed. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: 45-minute conversation with the hiring manager (interviewer's name not given, so no interviewer read). Built on your Tuesday dossier (conditional_go): requirements and evidence come from it, and its prohibited claims bind every cell below.

## How to use this pack

Personas describe how a question is asked; types describe what it is scoring. Guidance is scaffolding for your own words, not a script, and it is only ever as strong as the sentence quoted beside it.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values (no values round detected, so none in this pack) |
| EXP | Whether your claims survive scrutiny: what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

Question IDs run by persona: A Skeptic, B Case/Strategist, C Data-Driven Prober, D Conversational, E Pressure. The deepest rehearsal is A1, the objection your underwriter named: do it first, out loud, until it is boring.

## Fit snapshot

Requirements are the dossier's `role_profile` lines. Evidence is your confirmed entries from the dossier's `handoff_to_mock_interview`, quoted exactly; the confidence notes the dossier attached are in the Confidence column and the bridge, not in the quotes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [grounded] | transferability | Graded low by the dossier, with bridge as the allowed strategy. Words stay at the quotes' scope: you led 30+ end-to-end client integrations and wrote the playbook your team uses, positioned as adjacent work and never as PM experience. The title point is conceded in sourced words: "I haven't held a product manager title or role." Answer slot: the JD's 3+ years line makes a probe on how long you did this work likely; give your own span from your own records, and if you cannot state it, say so plainly |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier records this as an acknowledge_gap area ("Owning a roadmap and prioritization authority (R1 sub-claim)") and lists prohibited_claims: "Having owned a product roadmap". Words: "I haven't owned a product roadmap." Then a ramp plan said as a plan and never as a past. No bridge on this row, and F5's sessions are not coached here as roadmap ownership |
| F3 | "Shipped API or platform products" — dossier R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | transferability | Derived from an adjacent entry: the material says integrations of the vendor's REST APIs, which is not the same as shipped API products, and the words stay at the quote: you led 30+ end-to-end client integrations. Answer slot: expect a probe on which go-lives were yours to run; if any were, say which and your part in your own words, and if none were or they were not yours, say so plainly and stay with the integrations |
| F4 | "Technical fluency: API docs, schemas" — dossier R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quote touches REST APIs and architecture without showing whether API docs or schemas were part of it. Answer slot: if you read or wrote API docs or worked with schemas in those integrations, say which and what you did; if not, say so plainly and stay with the integrations as quoted |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier R4, important | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | medium | [grounded] | transferability | The sessions entry is confirmed with limited inspectable proof, so expect a probe and volunteer the limit yourself. Words stay at scope: you ran quarterly sessions that fed client evidence to product. Answer slot: the JD names engineering and sales alongside customers; if either worked with you in these integrations or sessions, say who and about what, and if neither did, say so plainly and stay with clients and product. If asked what came of the sessions, say what you know of it, and if you cannot show what came of them, say that plainly |
| F6 | "Agile delivery experience" — dossier R5, preferred | none given | low | [grounded] | discovery | The dossier marks this clarify: the evidence may exist and was not established. Answer slot: expect a probe on agile delivery in the JD's own words; if you worked that way, say how in your own words, and if you never did, say so plainly, then say what you would want to confirm about how this team defines it |

## Persona table

Weights start from the hiring-manager prior (Case/Strategist and Skeptic), then adjust for the dossier. The round is the one session you described; no source in hand documents the rest of Quartzline's loop, so this pack prepares Thursday only.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the title and roadmap gaps; why leave integration work, why this role | Highest. The hiring-manager prior includes it, and the dossier names a likely objection aimed at F1 and F2 | Rehearse A1 until it is boring; concede the sourced negatives first and plainly, hold the quoted evidence at its own scope, close on a plan |
| B. Case/Strategist | Live problems from the role: partner discovery, adoption diagnosis, squad disagreement, schema breakage | Highest, tied with A. The hiring-manager prior includes it, and the JD's responsibilities (discovery, specs, delivery with two squads, adoption metrics) are the raw material | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully per case |
| C. Data-Driven Prober | Line-by-line on the "30+" figure and on the roadmap-input sessions | Medium. A headline number is on your confirmed evidence, and the sessions entry is medium confidence | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know; name the weakest assumption before they do |
| D. Conversational | Opening "walk me through the journey," why this role, what you are playing with | Medium. A 45-minute manager conversation almost always opens in this register, and casual questions are still scored | A 90-second arc told from your three confirmed sentences only; treat casual questions about the JD's topics as scored |
| E. Pressure | Time-boxed "why you over a PM who has done this," "how much was actually you" | Low to medium. The hiring-manager prior does not favor it, but the objection invites a compressed, sharper version | Pause, restate, hold the position through two follow-ups, concede only what is true and specific |

Values/Behavioral and Peer Evaluator have no bank: no source in hand documents a values round or a peer round for this session.

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | The highest-ROI rehearsal in this pack, the objection your underwriter named. Concede first, in the dossier's sourced terms (prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap"): "I haven't held a product manager title or role. I haven't owned a product roadmap." Then the adjacent case at its own scope: you led 30+ end-to-end client integrations, scoping through go-live, and you wrote the playbook your team uses; tell it in your own words and let the interviewer draw the line to product. Close on a plan, never a past: you would want to learn which roadmap decisions are yours versus the squad leads and how adoption is measured today. Follow-ups: why not the PM with three years, so return to the quoted work and add nothing; what you would do first, so the plan; what you would get wrong first, so name roadmap prioritization plainly and the plan to close it | F1 and F2 are where the hire is most exposed, and the underwriter named this objection from evidence you confirmed; JD because it scores the title requirement, with the roadmap half held as a plain acknowledgment |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] | Answer from the area the dossier records as acknowledge_gap: roadmap ownership and prioritization. Concede it by name, in sourced words (prohibited_claims: "Having owned a product roadmap"; prohibited_claims: "Having set prioritization for an engineering squad"): "I haven't owned a product roadmap. I haven't set prioritization for an engineering squad." Then the ramp as a plan: the questions you would ask in the first weeks about decision rights with the squad leads and about how adoption is measured. No bridge here: the underwriter found no credible evidence, and an improvised one is how candidates get caught | F2 is the likeliest day-one answer and the one a manager is listening to hear straight; JD because it asks about the listed job's gaps |
| A3 | "The role needs someone who has shipped API or platform products. Tell me about the work of yours closest to that." | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on F3: tell the integrations as the quote has them (you led them, 30+, end-to-end, scoping through go-live) at that scope; the limit is the pack's observation, not words for you: the material says integrations of the vendor's REST APIs. Answer slot: expect a probe on which go-lives were yours to run and what your part was. If any were, say which and how, in your own words; if none were, or they were not yours, say so plainly and stay with the integrations you led | F3 is a must-have requirement with only adjacent evidence, so this probe is near certain; JD because it scores a stated requirement |
| A4 | "The JD lists agile delivery experience as preferred. How have you worked in an agile delivery setting?" | JD | [grounded] | No confirmed entry speaks to this, so the answer is a slot, not a story. Answer slot: if you worked in an agile delivery setting, say how in your own words; if you never did, say so plainly, then ask how the squads define their delivery process, which is the honest question-shaped answer. Nothing about your past goes in beyond what you can stand behind | F6 is a clarify area the dossier could not settle; a preferred item, so low stakes if answered straight, JD because it scores a stated requirement |
| A5 | "Why leave integration delivery for product, and why now?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Give your actual reason in your own words; the pack does not know it. If the sessions are part of it, tell them as quoted: you ran them quarterly, they fed client evidence to product, and say the limit yourself in sourced words (prohibited_claims: "Having owned a product roadmap"): "I haven't owned a product roadmap." Never describe the sessions as roadmap ownership | The skeptic's standard motivation probe, aimed at the F1 leap; F5's sessions are the nearest honest thing to cite, JD because it scores whether you want the listed job |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner tells you your API's auth flow is why their integration stalled. How do you run discovery before you touch the roadmap?" | CASE | [generic] | Clarify first: which partners, how many affected, what stalled and where. Then objective, segmentation of partners by integration stage, how you would gather evidence, what you would measure, risks. The question needs no claim about your past, so the guidance makes none | The JD's responsibilities include running discovery with integration partners; CASE because it is a live problem, and generic because the scenario is a pattern and not a fact about this team |
| B2 | "Partner API adoption has been flat for two quarters. Diagnose it." | CASE | [generic] | The first move is to ask how adoption is defined and what the baseline is: the dossier lists how it is measured today as unknown, so asking is both the right case move and a diligence signal. Then segment (new versus existing partners, endpoints, integration stage), form hypotheses, name the metric you would check first and what would change your mind | The JD names adoption metrics as a responsibility with no stated baseline; CASE because it scores structure under ambiguity |
| B3 | "You and a squad lead disagree on whether a partner-requested endpoint beats a reliability fix. Walk me through it." | CASE | [generic] | Do not assume authority you were not told you have: say you would first learn how this decision is made here. Where the call is the squad lead's, bring partner evidence and a clear recommendation; where it is shared, agree the criteria before the options. Offer principles for the seam, not a claim to know where it sits | The dossier flags decision authority versus the two squad leads as unevidenced; CASE with a JD target because it tests whether you read the seam correctly and avoid presuming it |
| B4 | "A partner says last week's response-schema change broke their integration. What do you want to know in the first hour, and who do you pull in?" | CASE | [generic] | Clarify: which change, which endpoint, how many partners, whether it was versioned and announced, whether a rollback exists. Then triage order, who owns the fix, how you would communicate to partners, and what you would change in the process. The question needs no claim about your past, so the guidance makes none | F4's requirement is technical fluency, and a live schema problem tests it without asking you to claim a background; CASE because it scores clarifying before solving |
| B5 | "Sales wants one endpoint, a partner wants another, and engineering says neither fits this quarter. How do you decide what goes forward?" | CASE | [generic] | Clarify what each request is worth and to whom, what evidence exists for each, and what engineering's constraint really is. Then criteria first, a recommendation, who is told what, and how you would record why. Challenge one premise respectfully, for example whether the quarter is the real constraint | F5's requirement names engineering, sales and customers; CASE with a JD target because it scores stakeholder judgment live |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say 30+ client integrations. Walk me through how that number was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | The figure has four slots only you can fill, in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how a figure was counted, say that plainly. The playbook is the inspectable item the dossier records: offer to show it as what you can show, not as a record of the count | The headline figure is a magnet for probers; EXP because it scores whether the claim survives attribution |
| C2 | "Tell me about the quarterly roadmap-input sessions you ran. What happened to what you fed product?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Tell the sessions at the quote's scope: you ran them quarterly and they fed client evidence to product. The dossier marks this confirmed with limited inspectable proof, so volunteer the limit before it is extracted. Answer slot: if you know what came of the evidence, say what and how you know; if you cannot show what came of it, or it was not yours to track, say so plainly and stay with the sessions | F5 is the medium-confidence entry and the likeliest seam a prober finds; EXP because it scores attribution on a claim with little to inspect |
| C3 | "The JD asks for technical fluency with API docs and schemas. Where does yours show up?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: the quote touches REST APIs and architecture without saying more, so expect the probe to go to docs and schemas specifically. If you read or wrote API docs or worked with schemas in those integrations, say which and what you did; if not, say so plainly and stay with the integrations as quoted | F4 is an important requirement on a discovery gap; JD because it scores a stated requirement |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc built from your three confirmed sentences and nothing else: the integrations you led, the playbook you wrote, the sessions you ran. Keep it in integration terms and let the interviewer draw the line to product. Close on why you want this role, in your own words; the pack does not know your reason | A warm opener is still scored, and this arc sets the frame A1 later tests; EXP because it scores what you did, told economically |
| D2 | "What are you actually playing with in API docs and schemas these days?" | JD | [grounded] | Answer slot: name what you actually use, in your own words; if nothing, say so plainly and say what you would start with. No claim about your tooling goes in unless you can stand behind it | A casual question on F4's topic, so it is scored; JD because the JD names the skill |
| D3 | "Why Quartzline, and why this role?" | CO | [grounded] | Research on Quartzline could not run, so the pack has nothing current on the company and makes no claim about it. Stay with what the role description gives: a partner-facing API platform, two engineering squads, adoption metrics. The reason you pick from that is yours; the pack does not know it | A why-us question is near certain in a manager conversation; CO because it scores homework, with the honest cost that the company half is yours to fill |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who has done this job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The compressed A1. Pause and restate the question, concede the title in sourced words (prohibited_claims: "Having held a product manager title or role"): "I haven't held a product manager title or role." Then the quoted work at its scope in one sentence, then one plan clause. Hold through two follow-ups by returning to the quote, and concede only the title | The same objection in a time-boxed delivery, because pressure interviewers use it to test whether the answer survives interruption; JD because it scores F1 |
| E2 | "That integration work: how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Hold the sentence: you led them, and the stages it names. Answer slot: if any of scoping, requirements, architecture, UAT or go-live were carried by others, say which and say your part; if you carried them all, say so plainly. Concede only specifics that are true, and never fold on the core claim just to restore harmony | The stock pressure probe on F1's evidence; EXP because it scores attribution under pushback |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1 3+ years product management experience | A1, A2, A5, E1 |
| R2 Shipped API or platform products | A3 |
| R3 Technical fluency: API docs, schemas | C3, D2, B4 |
| R4 Stakeholder management across engineering, sales, customers | C2, B5 |
| R5 Agile delivery experience | A4 |
| Responsibility: own the roadmap | A2, A5 |
| Responsibility: run discovery with partners | B1 |
| Responsibility: deliver with two squads | B3 |
| Responsibility: define and track adoption metrics | B2 |
| Responsibility: write specs | — none, and why: a 45-minute round has room for 18 questions, and B1 and B4 touch the raw material of a spec without scoring it |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The JD names two squads and a roadmap owner but the dossier finds decision authority unevidenced; it reads as diligence and answers something you need before accepting |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption metrics are named as a responsibility with no baseline stated, so this tests whether the metric exists yet and reads as seriousness about the job |
| 3 | "How do the two squads split the platform work, and where do they hand off?" | It maps the seam B3 asks about, and the answer shows how much of the delivery the role actually steers |
| 4 | "Where does partner feedback reach the roadmap today, and who owns that channel?" | It is the channel F5 sits next to, and the answer shows where integration-side evidence enters product decisions |
| 5 | "What would you need to see in my first ninety days to know the hire was right?" | It turns the F1 gap into a shared definition of success and surfaces the manager's real bar |
| 6 | "What would make you comfortable bringing in someone from integration delivery rather than from a PM role?" | It invites the A1 objection on your terms; use it only if the conversation has not already settled the title question |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | F1's quotes at their own scope, plus the plain acknowledgment: "I haven't held a product manager title or role." No slot |
| Having owned a product roadmap | Dossier prohibited_claims and the acknowledge_gap area on roadmap ownership | The plain acknowledgment: "I haven't owned a product roadmap." Then a ramp plan said as a plan. F5's sessions stay at their own scope: they fed client evidence to product |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | The plain acknowledgment: "I haven't set prioritization for an engineering squad." No slot |
| Shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: the material says integrations of the vendor's REST APIs. A3's slot stays inside the integrations |

## Sources

Provided: tuesday-dossier.md, dossier_version 1.1 (a major version this skill reads). Sections supplied: `role_profile` (requirements and responsibilities, the fit snapshot's requirement lines), `handoff_to_mock_interview` (verified evidence, weak areas and their allowed strategies, the named objection, prohibited claims, reverse questions), and `decision` (context only). The dossier carries no `evidence_map`, `evidence_state` or `risk_register`, so confidence grading rests on the handoff's notes.

Searches sent (all refused, permission to search was not granted):

- "Quartzline values": refused
- "Quartzline interview process product manager": refused
- "Quartzline strategy news API platform": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | All calls refused. Would have fed a values cheat sheet; none is in this pack |
| 2. Quartzline interview process, product manager | unavailable | All calls refused. Would have documented the loop and tuned persona weights; this session's round rests on your own description |
| 3. Quartzline strategy / recent news | unavailable | All calls refused. Would have grounded the CO and CASE banks in current strategy; D3 and bank B are generic as a result |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Product Manager, Platform APIs JD | skipped | The dossier's `role_profile` fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access → target 1 to 3 results: Quartzline's published values, its loop and current strategy, which would ground D3 and bank B, and could add a values cheat sheet if a values round is documented; deeper research (up to 6 further searches and 2 further fetches, several more minutes) is available once on request
- The interviewer's name → persona weights read from their public footprint and a reverse question tied to their own path
- The recruiter's prep note → coverage of any pre-declared deliverable and stated focus areas
- Your raw CV behind the confirmed claims → dates and titles for F1's evidence cell, which the dossier's decision prose summarises more broadly than any confirmed entry does
- A record of what the roadmap-input sessions fed to product (session notes, a ticket list or a roadmap change log) → lifts F5 and C2 from medium
- Your answers to the slots in A3, A4, C2, C3 and D2 → turns F3, F4, F5 and F6 from slots into quoted evidence
