I've read the skill's rules, so now I'm running the capped company research (values, strategy, interviewer, a representative job description) before I build your prep pack.
Your prep pack is saved as `kelverton-rail_senior-partnerships-manager_interview_pack.md`. I built it for a two-person panel, with a 15-minute POV first and then Q&A. Web search was refused, so nothing in it comes from Kelverton's public material. Everything about the company is what you told me, and the recruiter's email as you quoted it. The market report didn't reach me, so I haven't used it.

The pack has:
- **Your POV:** three thesis options, each with a concession and a closing line about what it means for operators, plus an anti-pick and a 13-minute timing plan.
- **Questions:** 19, grouped by how each panelist is likely to ask them.
- **Highest-ROI prep:** B1, "you haven't sold into rail and haven't carried a direct quota, what will you be weakest at on day one", which comes straight from what you told me.
- **Your four hours:** a schedule, with everything else marked as insurance.

Say the word and I'll play the Skeptic on B1, or Ross on the £4M questions (C2 and C3, then D1 to D3).
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the job description? It would turn the role-family requirement row, which is currently generic, and the generic questions into ones quoted from the posting.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, 60 minutes, two-person panel. **Deepa**, VP Partnerships (your future manager), and **Ross**, Commercial Director. First 15 minutes: you present a short POV with no slides. The rest is Q&A, and the recruiter's email says Ross will push on commercials. Built for your Tuesday round, from your message alone (company research was refused, see Sources).

## How to use this pack

- **Personas are how a question is asked. Types are what it scores.** Rehearse both.
- **Type key:** VAL = behavioral or values alignment. EXP = work-experience deep-dive. JD = role or requirement-driven. CO = company and strategy knowledge. CASE = live problem set in the role.
- **Guidance is scaffolding, not a script.** Every claim about your past in this pack is a sentence you wrote, quoted. Where the material is silent, the guidance is an answer slot: say what is true, in your own words, and if there was no such step, or it was not yours, say that plainly.
- **Labels:** [grounded] traces to something you gave me. [inferred] is derived from it. [generic] is a role-family pattern with no claim about Kelverton or about you.

## Prep triage (about four hours across the weekend)

| Block | Time | Do | Where |
|---|---|---|---|
| 1 | 60 min | Pick one thesis and one anti-pick for the POV, then outline it against the market report you have read | Graded deliverable section; A3 |
| 2 | 45 min | Say the POV aloud twice, timed to 13 minutes, so the last two are for the close on operators | Graded deliverable section |
| 3 | 60 min | The highest-ROI objection, said aloud until it is boring, with all three follow-up levels | B1, then C2 and C3 |
| 4 | 35 min | Defend-the-number answers, including saying plainly what you do not know about how the figure was counted | D1, D2, D3, D4 |
| 5 | 25 min | Case structure out loud on the two operator-side cases | A1, A2 |
| 6 | 15 min | Reverse questions, pick three | Reverse questions |

Everything else in the pack is insurance.

## Fit snapshot

The requirements come from the recruiter's email as you quoted it, since no job description was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message | medium | [grounded] | transferability | Your material says nine years in partnerships and a channel you ran, with nothing inspected behind it. It does not say operator-partnership work, and the words stay at that scope: "For the last four years I ran the ISV channel at a payments company." Answer slot: an 18-month view on operator partnerships makes a probe on how that channel compares likely. If any of what you did there maps onto operator partnerships, say which part and how, in your own words; if none of it does, say so plainly and stay with the channel you ran |
| F2 | "Please land on what it means for the operators themselves." — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says transport consulting in bus and light rail network planning. It does not say train operating company work, and the words stay there: "For five years I was in transport consulting, in bus and light rail network planning." Answer slot: because the close must land on operators, expect a probe on what you saw of operators from that work. If you saw any, say what, in your own words; if you saw none, or it was not train operators, say so plainly and stay with the network planning |
| F3 | "Ross will push on commercials." — recruiter's email | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | Your material gives a count of partners and a figure of influenced revenue, and says nothing about how either was counted. Words stay at that scope: "roughly £4M of influenced revenue." Answer slot: a figure raises four probes, how it was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours. Answer each in your own words; where you do not know how some part was counted, say so plainly |
| F4 | Rail-sector selling and direct commercial ownership: a role-family requirement, no source supplied | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [generic] | capability | A gap wording cannot close, and you have stated it. Words: "I haven't sold into rail specifically, and I haven't carried a direct quota; what I have is influenced revenue." Then how you would learn it, said as a plan and never as a past. Never a claim to rail sales or to a quota, and nothing added to make the gap feel smaller |

## Graded deliverable: the 15-minute POV

The recruiter's ask, in their words: "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves."

**Facts to build on**

- The format is a talk with no slides, to a future manager and a commercial director. Ross will push on commercials afterwards, so every thesis needs its commercial cost said before he says it.
- What you can say about yourself is limited to F1: "9 years in partnerships, last 4 at a payments company running the ISV channel"; to F3: "took it from 6 partners to 40, roughly £4M of influenced revenue"; and to F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)". Say each at that scope.
- The market report was circulated by Kelverton's strategy team, so both panelists have probably read it. Its shortlist is the answer any prepared candidate gives.

**Thesis options.** Pick one. Each carries the concession you say aloud, and the operator close you end on.

| Thesis | What it means for the operators (your close) | Mandatory concession | Rows | Provenance |
|---|---|---|---|---|
| T1: Depth before breadth. Fewer, deeper operator relationships first, before widening the partner count | Each operator in the first group has a named counterpart and a shared plan, instead of being one account among many | Depth leaves the rest of the operators unserved for a while, so it is a sequencing choice, not a better model. Your quoted ISV experience is about breadth, "took it from 6 partners to 40, roughly £4M of influenced revenue", so expect Ross to ask why you would not use it here (F3) | F1, F3 | [generic] |
| T2: Shared outcomes. Tie each operator partnership to one result the operator already answers for, chosen from the market report | The operator gets a supplier accountable to a result it is measured on, not to a feature list | Shared outcomes put Kelverton's revenue at risk and need operator data that operators may not share, so the first step is one pilot, and the commercial terms of that pilot are what Ross will probe (F3, F4) | F3, F4 | [generic] |
| T3: Operator voice into the roadmap. Partnerships as the route by which operator planners shape what gets built | Operators see their own constraints reflected in the product they buy | Partnerships influence the roadmap and do not own it, so the honest claim is influence. Say your operator-side material at its scope, "bus and light rail network planning", and not as train operator experience (F2) | F2, F1 | [generic] |

**Differentiation against the consensus answer.** Bring one item from the market report that you agree with, to show you read it, and say why in a sentence. Then take the thesis above as your divergence, with the reason you differ. Frame any disagreement with the report as a hypothesis or a question, never as a correction of their strategy team.

**The anti-pick.** The role includes saying no, so end the thesis with one thing you would not do in the 18 months, with its cost. Two candidates, either with a reason you can defend: not widening the partner count first (pairs with T1), or not offering operator-specific commercial terms before one pilot has run (pairs with T2).

**The requested close.** Last two minutes, land on operators. Answer slot: name one difference an operator would notice by month 18, in the operators' own terms, from the market report or from what you saw in transport consulting; if you cannot name one from either, say what you would ask operators first to find out.

**Timing (13 minutes plus a 2-minute buffer).** 1 minute: frame the question you are answering. 3 minutes: the consensus read and your agreement with one item. 5 minutes: your thesis. 2 minutes: the concession and the anti-pick. 2 minutes: what it means for operators.

## Persona table

The loop is established by the recruiter's email: one session, a panel, a 15-minute POV and then Q&A. Persona weights are therefore from relationship priors and from the recruiter's words, with no archetype fallback.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Follow-ups on the POV; live operator-side problems | High. Deepa is a hiring manager and the recruiter announced the POV, so the Q&A will start from it | Clarify, objective, segmentation, approach, metrics, risks; challenge one premise respectfully |
| Skeptic | Quiet probing of the rail and quota gaps from Deepa | High. A hiring-manager round prices gaps, and F4 is a gap you stated | Rehearse the single most predictable objection until boring, using only your quotes |
| Pressure | Ross interrupting and time-boxing on commercials | Medium-high. An executive prior, plus the recruiter's own words, "Ross will push on commercials" | Pause, restate, anchor in what you actually said, hold through two follow-ups, then concede specifically |
| Data-Driven Prober | Ross taking the £4M and the 6-to-40 apart | Medium-high. Commercial questions arrive as figures, and F3 is the only figure | Know what you can and cannot say about how each number was counted, and say plainly where you do not know |
| Conversational | The opening "tell me about yourself" from Deepa | Low-medium. Likely brief, but still scored | A 90-second arc built from your quoted sentences |
| Values/Behavioral | Not banked | Low. Nothing in the recruiter's email describes a values round | n/a |
| Peer Evaluator | Not banked | Low. Neither panelist is a peer | n/a |

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch the 18-month plan for our operator partnerships — what do you need to know first?" | CASE | [generic] | Clarify before structuring: what the report treats as the operator segments, what counts as a working partnership here, what is fixed and what is open. Then objective, segmentation, approach, metrics, risks. Challenge one premise respectfully. This is the POV's own structure, said again in two minutes. The question needs no claim about your past, so the guidance makes none | The announced POV makes this the likeliest follow-up. CASE because it is a live plan on the real role, JD content in CASE delivery. It is generic because no job description or report is in hand |
| A2 | "An operator asks why it should partner with us rather than just buy the software. What do you say?" | CASE | [generic] | Start from the operator: ask what they want to be different before answering. Then answer in their terms, outcome, risk and effort. Say the cost to them out loud, since a partnership asks something of an operator. No claim about your past | The recruiter's "land on what it means for the operators themselves" makes the operator's view the scoring lens. CASE because it is a live conversation, not a recitation |
| A3 | "What would you refuse to do, or stop doing, in the first 18 months?" | CASE | [generic] | Use the anti-pick from the graded deliverable. Give the reason and the cost, and say who would be unhappy about it. Do not use a refusal you cannot defend through a second follow-up. No claim about your past | Differentiating from a report both panelists have read means showing judgment, and saying no is where a partnerships role shows it. CASE because it is a decision made live |
| A4 | "How would you know an operator partnership is working, from the operator's side?" | CASE | [generic] | Name two or three measures operators already track, taken from the market report, and say which one you would trust least and why. Name a measure here only if the report or your own transport-consulting material gives it, and do not name one for them. No claim about your past | Keeps the answer on operators and gives Ross a commercial question to follow. CASE because it asks for a structured view |
| A5 | "You've read the market report our strategy team circulated. What would you challenge in it?" | CO | [generic] | Agree with one item, to show you read it. Diverge on one, with the reason, framed as a hypothesis or a question to them rather than a correction. Both panelists hold the same report, so reciting its shortlist scores as homework only. No claim about your past | Homework depth on strategy. CO because it tests altitude. It is generic because the report did not reach me, so nothing from it is used here |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail and haven't carried a direct quota. What will you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | The highest-ROI prep in this pack. Level 1, the concession, said first and flat: "I haven't sold into rail specifically, and I haven't carried a direct quota; what I have is influenced revenue." Level 2, the hold, at the quotes' scope only: "9 years in partnerships, last 4 at a payments company running the ISV channel" and your transport consulting years. Do not add to them under pressure. Level 3, the plan, said as a plan and never as a past: what you would learn first about how operators and Kelverton do business, and from whom, in your own words. Answer slot: if there is an adjacent thing in your material you would offer as the nearest evidence, say it at its own scope; if there is none, say so plainly and stay with the plan | F4 is a gap you stated, and this is where the panel's first Skeptic probe is aimed. JD because it scores a stated gap against the role, EXP in delivery. Deepest rehearsal because it will arrive in some form |
| B2 | "Your operator experience is bus and light rail network planning. How does that carry to train operating companies?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Say the quote's scope first: five years in transport consulting, in bus and light rail network planning. Answer slot: if any of that work touched train operators, say how, in your own words; if it did not, say so plainly, then say what you would check against rail before assuming it carries over | F2 is the only operator-side material, and the question probes its edge. EXP because it tests whether the claim survives scrutiny |
| B3 | "Why leave payments for rail-tech, and why now?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)", "9 years in partnerships, last 4 at a payments company running the ISV channel" | Selection scaffold. State your reason for the move in your own words, one you would say to a friend. The two facts the arc can carry are the transport consulting years and the last four at the payments company. Answer slot: the reason for the move is not in your material. Give the one you would defend under a second question; if you have more than one, lead with the one that is true today | The standard motivation probe from a future manager. EXP because it tests the CV's story, not a skill |
| B4 | "When you took the channel from 6 partners, what was already running?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Start from the quote's own starting point: 6 partners. Answer slot: if there was a structure, a programme or a team already in place at 6, say what it was and which parts were yours to change; if there was none, or none of it was yours, say so plainly and stay with the partners count | The quote starts from six, which invites the question of what existed. EXP because it tests attribution |

### C. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue.", "9 years in partnerships, last 4 at a payments company running the ISV channel", "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Pause, restate the question. Concede first: "I haven't sold into rail specifically." Hold on the two quoted facts at their scope, the partnerships years with the last four on the ISV channel, and the transport consulting years. Do not say anything about the other candidate. Hold through two follow-ups by returning to the quotes, never by adding to them | F4 is the gap this question aims at, in a time-boxed register. JD because it scores the stated requirement against the gap, with Pressure delivery |
| C2 | "That result — how much of it was actually you?" | EXP | [grounded] "last 4 at a payments company running the ISV channel", "took it from 6 partners to 40, roughly £4M of influenced revenue" | Hold the sentence at its own scope: you ran the channel, and the quote says it grew from 6 partners to 40. Answer slot: which part of the figure was yours, in your own words; if part of it came from work that was not yours, say so plainly and name only the part that was. Say "we" for context and "I" only for what you did | An attribution probe on the only figure, from the interviewer whose job is commercials. EXP because it tests what was actually yours |
| C3 | "Influenced revenue isn't booked revenue. What would you commit to on a direct quota here?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Concede the plain fact first: "I haven't carried a direct quota; mine was influenced revenue." Then hold. What you would commit to is a decision for the room, so give no target you cannot defend through a second question. Answer slot: if you have a view on what a first-year commitment would look like, say it in your own words with the basis for it; if you do not, say so plainly and ask how the role is measured and how it is counted here | The recruiter's "push on commercials" points here, and F4 is the stated gap. JD because commercial accountability is the role's own measure |
| C4 | "An operator asks for a discount in return for becoming a reference partner. Your move?" | CASE | [generic] | Do not answer yes or no first. Ask what the discount is buying, a reference, data, volume or co-development, and what is fixed on price. Then lay out a give and a get, hold it through two pushes, and concede the cost out loud. No claim about your past | A live commercial problem in Ross's register. CASE because it asks for structure under pressure. It is generic because pricing in this business is not in my material |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How was that roughly £4M of influenced revenue counted?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Say the figure as you gave it, "roughly £4M of influenced revenue". Answer slot: how it was counted, in your own words; where you do not know how part of it was counted, say so plainly. Do not explain a method you cannot repeat under a second question | F3 is the headline figure, and a prober asks how it was counted first. EXP because it tests the claim, not the role |
| D2 | "What is that figure most sensitive to?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: what the figure moves with, in your own words; if you do not know, say so plainly rather than guessing | A prober's second level, on the same figure. EXP because it tests whether you know your own number |
| D3 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | The weakest-assumption move: name it yourself, in your own words, before they do. Answer slot: if you know of one, say it; if you do not know how part of the figure was counted, say that plainly, which converts a gotcha into a credibility gain. Never invent an assumption to sound candid | The standard prober close. EXP because it tests whether you know where your number is weakest |
| D4 | "At 40 partners, what counted as a partner?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: if there was a threshold or a definition, say what it was in your own words; if there was no formal one, say so plainly and say how you counted the 40 | The count of partners is a figure too, and a prober asks what is inside it. EXP because it tests how a number was counted |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel", "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | A 90-second arc with the beats your two quotes carry: five years in transport consulting, then the partnerships years, with the last four at a payments company running the ISV channel. Answer slot: why each move happened is not in your material, so give the real reason in your own words | The casual opener is scored. EXP because it tests the CV's story |
| E2 | "What did you see from the consulting side that operators wish their suppliers understood?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Selection scaffold. Pick one thing you saw in the bus and light rail network planning work that you can describe from what you actually saw. If nothing comes to mind that carries over to rail, say so plainly, then say how you would find out | The recruiter's "land on what it means for the operators themselves" makes operator insight a likely casual question. EXP because it tests whether the operator-side claim has content |

## Requirement coverage

| Requirement | Questions |
|---|---|
| POV on operator partnerships over 18 months (F1) | A1, A3, A5, B4, E1 |
| Land on what it means for operators (F2) | A2, A4, B2, E2 |
| Commercials (F3) | C2, C3, C4, D1, D2, D3, D4 |
| Rail selling and direct commercial ownership, role-family (F4) | B1, C1, C3 |
| Talk without slides, 15 minutes | Graded deliverable section, A1 |

## Reverse questions

No interviewer profile is in hand, so none of these is tied to a panelist's path.

| Question | Why it lands |
|---|---|
| To Deepa: "What would you want an operator to say about our partnership in 18 months that they wouldn't say today?" | Takes the operator's view you were asked to land on and hands it to your future manager |
| To Deepa: "How is the first year of this role measured, by influence on revenue or by a direct commercial target?" | Puts the quota gap on the table on your terms, before it is used against you |
| To Ross: "When an operator pushes on commercial terms, which terms hold and which flex?" | Shows you think about margin, and gives you his real position for later |
| To both: "What did the strategy team's report change in how you think about the next 18 months?" | Moves from reciting the report to asking about its use, which is how you differentiate from it |
| To both: "What would make you say in six months that hiring me was the right call?" | Converts the interview into an agreed definition of success |
| To both: "Which operator partnership today would you point to as the model, and what makes it work for the operator?" | Gives you a real example to refer back to in the follow-up, and tests the operator lens |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Sold into rail | Negative you stated, F4 | The plain acknowledgment: "I haven't sold into rail specifically." Quote: "Never sold into rail specifically and never carried a direct quota, only influenced revenue." No slot |
| Carried a direct quota or owned a revenue number | Negative you stated, F4 | The plain acknowledgment: "I haven't carried a direct quota; what I have is influenced revenue." No slot |
| Closed or booked £4M | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue". The limit is the pack's observation: your material says influenced revenue, not booked. D1 asks only how it was counted |
| Built the channel from nothing | Inflated form of F1 and F3 | The quotes at their own scope: ran the ISV channel, grew from 6 partners to 40. The limit is the pack's observation: your material does not say who started the first six. B4's slot stays inside what was running at 6 |
| Worked with train operating companies | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning in transport consulting. The limit is the pack's observation: your material does not say train operator work. B2's slot stays inside the network planning |
| Was on the operator's side of the table | Inflated form of F2 | F2's quote at its own scope: transport consulting. The limit is the pack's observation: your material says consulting, not employment at an operator |

## Sources

Provided documents: your message, including the background you gave and the recruiter's email as you quoted it. The market report you named did not reach me, so nothing from it is used here. No job description was supplied.

Searches sent, all refused, with nothing returned: "Kelverton Rail values"; "Kelverton Rail interview process partnerships manager"; "Kelverton Rail scheduling software train operating companies strategy news"; "Deepa VP Partnerships Kelverton Rail"; "Senior Partnerships Manager rail technology job description train operating companies". No pages were fetched.

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | All calls refused. Would have supplied official value names for VAL themes; no values-style round is detected, so the pack carries no values sheet either way |
| 2. `Kelverton Rail interview process partnerships manager` | unavailable | All calls refused. Would have added documented loop detail beyond the recruiter's email, which already fixes this session's format |
| 3. `Kelverton Rail strategy` and recent news | unavailable | All calls refused. The CO question A5 stays generic, and there is no grounding brief |
| 4. `Deepa VP Partnerships Kelverton Rail` | unavailable | All calls refused. The interviewer read is absent, and no reverse question is tied to a panelist's path. No query was sent for Ross |
| 5. representative `Senior Partnerships Manager` JD | unavailable | All calls refused. The fit snapshot rests on the recruiter's words, and the role-family row is generic |

## Upgrade menu

- The job description text → F4's generic row becomes grounded rows, and the generic questions in banks A to C become JD-quoted
- The market report's text, pasted → a grounding brief, A5 and the consensus item in the POV become grounded, and the CO questions stop being generic
- The panelists' surnames or profile links → an interviewer read, persona weights read from their public footprint, and a reverse question tied to each one's path
- Permission to run web search, or a deeper research pass of up to 6 more searches and 2 more fetches, several more minutes → values, strategy and loop rows resolved from sources, and the unavailable rows above filled in
- A deal sheet or partner revenue report showing how the roughly £4M of influenced revenue was counted → F3 moves from medium to high and D1 to D4 get your own words behind them
- Your own answers to the slots in B2, B4, C2 and D1 to D4, given outside a drill → F1 to F3 regenerate from your words
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence and constraints on what each weak area may say
