I'll read the reference files the skill points to before writing anything.
Next I'll check the file's tables for stray pipes and brackets, and confirm no watch-out line leaked into it.
Dara, your prep pack is saved as `ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as a three-round loop, with a separate set of questions for each round. It has 31 questions in all: 8 for the recruiter, 11 for the Head of Member Services and 12 for the panel.

It's built only from what you pasted, so I ran no searches. There are no interviewer names yet, so there's no interviewer read.

- **Biggest risk:** The likeliest hard question is D1, about the contact centre. The JD puts it inside the role, and you've told me you haven't worked in one. D1 has the deepest rehearsal, in three follow-up levels.
- **Second gap:** Presenting above regional level (D2) is the next one to rehearse.
- **What your note covers:** Your note covers part of each JD line (the complaints log, the escalation script, the monthly spreadsheet) but stops short of the JD's wording on "end to end", "regulated", "Excel" and coaching supervisors. Those rows are marked as answer slots. If something is true, say it in your own words. If not, say so plainly. I haven't written any of it in for you.
- **Values round:** None of your sentences carries a story for the four values, so those answers are scaffolds that end in an honest fallback. If you have real stories, send them and I'll map them.

I can play the Skeptic on D1 if you want to rehearse it live. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word if you'd like.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union (loop mode)

Candidate: Dara. Three rounds on 29 November 2026: a 30-minute recruiter conversation, a 45-minute round with the Head of Member Services (who would be your manager), and a 60-minute panel of two branch managers that includes a 20-minute complaint-escalation case and is also the values round. Interviewer names beyond these roles are not yet assigned, so there is no interviewer read. Built on 20 November 2026 from your JD, the four values as you pasted them, the recruiter's email, your summary of the July 2026 strategy brief, and your background note. There is no CV, only that note.

## How to use this pack

- Personas are how a question is asked; types are what it scores. Guidance is scaffolding for a spoken answer, not a script.
- Type tags: VAL (past behaviour against the published values), EXP (whether your own claims survive scrutiny), JD (the listed requirements, gaps included), CO (company and strategy homework), CASE (a live problem from the role).
- An answer slot is an instruction for the interview, not a question for you now. It says what to cover if it is true for you, and what to say plainly if it is not. Either branch is a good answer; the one thing it never wants is the practice invented.
- Highest-ROI prep in the whole loop: D1, the contact-centre question. It is asked in some form because the JD puts the contact centre inside the role and your own note says you have not worked in one. Rehearse it until it is boring.
- Question IDs run by persona and are unique across the loop, so the drill can point at any of them.

## Loop overview

| Round | Who | Length | What the email says it holds | Provenance |
|---|---|---|---|---|
| 1 | The recruiter | 30 minutes | Nothing further stated | [grounded] |
| 2 | Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural | [grounded] |
| 3 | Panel of two branch managers | 60 minutes | A 20-minute case on a complaint escalation; also the values round, scored against the four values | [grounded] |

## Fit snapshot (shared by all three rounds)

Requirements are quoted from the JD you supplied. Evidence is your own words from your message and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD, branch half | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's log and the tellers' script, not the process end to end, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" makes a probe on how far your part ran likely. If you handled any part of a complaint beyond the log, say which part and what was yours, in your own words; if the log was the extent of it, or the rest was not yours, say so plainly and stay with the log and the script |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD, contact-centre half | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work or to something near it, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote says the monthly complaints spreadsheet, and the material does not show what it counted. Lead with it as written: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what it showed. If it showed either, say which and how it was worked out, in your own words; if it showed neither or something else, say so plainly and say what it did show |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message, "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | Your material says new tellers and an escalation script, not coaching supervisors, and the words stay at that scope: you "trained new tellers on our escalation script". It also says you were a branch supervisor for the last three of your six years in retail banking, which you can say as that and no more. Answer slot: the JD asks about supervisors, so expect a probe on whether you have helped a fellow supervisor through an escalation. If you have, say what you did and what was yours, in your own words; if not, say so plainly and stay with the tellers and the script |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on digital work, which is not a statement that there is none. Answer slot: if you have worked with any digital team or on any member-facing digital process, say what and which part was yours, in your own words; if you have not, say so plainly, and say what you would want to learn first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Say the quote in its own terms: six years in retail banking, the last three of them as a branch supervisor. Let the interviewer match that to the JD's wording; do not relabel it in the JD's vocabulary |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | The quote says a formal complaints log, and the material does not show whether those complaints were regulated. Answer slot: the JD's word "regulated" makes a probe on what rules applied likely. If the complaints in that log carried regulatory requirements, say which and what they required of you, in your own words; if you do not know, or they did not, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." The pack's observation is that your material gives only that negative: it does not say whether you presented at regional level, so say nothing about it. Then how you would prepare for a first senior audience, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | The quote says spreadsheet, not Excel, and the pack takes the reading that claims less. Answer slot: the JD names Excel, so expect a probe. If the spreadsheet was in Excel, say what you did in it, in your own words; if it was another tool, or Excel was not what you used, say so plainly and say what you built it in |

## Requirement coverage

| JD requirement | Fit rows | Covered by |
|---|---|---|
| Own the complaints process end to end, branches half | F1 | A1, C1, E1, J1, J2, K2 |
| Own the complaints process end to end, contact-centre half | F2 | B2, D1, E1, K2 |
| Report monthly on complaint volumes and resolution times | F3 | E1, G1, G2, J1, J3 |
| Coach branch supervisors on escalations | F4 | C4, D3, K1 |
| Work with digital teams on self-service journeys | F5 | A6, E2, L1 |
| 4+ years in financial-services customer operations | F6 | A1 |
| Experience handling regulated complaints | F7 | B1, C1 |
| Confident presenting to senior leaders | F8 | B2, C2, D2 |
| Comfortable with Excel reporting | F9 | G1, G2 |

## Grounding brief: the 2026 strategy

This comes from your four-point summary of the brief the recruiter sent. I have not read the brief itself. Use the vocabulary exactly as the brief gives it.

| Point | Provenance | How it touches this role |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | [grounded] | The JD's self-service line (F5) sits under this target. E2 rehearses it |
| Consolidate eight branches into five hubs over 2027 | [grounded] | The round-3 panel is two branch managers. Which branches they run is unknown, so keep to the member's side of any hub question. J3 rehearses it |
| Launch a small-business lending product in Q1 2027 | [grounded] | A new product is a reasonable thing to ask about on the reverse-question slot: who will hold complaints for it. Reverse question R2.5 |
| The main competitive pressure is app-only banks | [grounded] | The pressure behind the digital target. L1 asks about your own experience of banking through an app |

The brief is a document every other candidate can get. Reciting its four points scores as homework; use one point to show you read it, then add a position of your own with a concession. E2 and J3 are built that way.

---

# Round 1: the recruiter (30 minutes)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured; biography, motivation, and logistics woven in | High. The recruiter-screen prior is Conversational plus a light Skeptic, and the email gives this round 30 minutes and names no focus | Pre-script the 90-second arc in A1; treat every casual question as scored; use the reverse-question slot rather than "I think you've covered everything" |
| Skeptic (light) | Knockout-style checks of the JD's stated lines, in a friendly register | Medium. The JD's contact-centre and regulated-complaints lines meet one stated absence (F2) and one fact your material does not show (F7); the prior says light | Short plain acknowledgments, one sentence of plan, then move on |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through the journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc in the three beats those sentences state: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Say each at its stated scope, the branch's log, new tellers, your regional manager, and no bigger noun. Finish with one sentence on why you are moving, in your own words (see A5). Time it aloud | F6, F1 and F3 are the spine of your story, so the opener should be built from them. EXP because it checks that the story told matches the story on paper |
| A2 | "What salary are you looking for?" | JD | [generic] | Logistics slot. Give your own number, or ask for the role's band first; either is your call and the pack supplies no figure. Say it once, plainly, and stop | Recruiters price the match early, and the only safe answer is yours. JD because pay is a term of the listed job |
| A3 | "What's your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period, as your contract states it, in one sentence | A recruiter needs it to plan the loop's close. JD because it is a term of the listed job |
| A4 | "Is there anything about location or working pattern we should know?" | JD | [generic] | Logistics slot. State your actual constraints, or say there are none; the JD has the role spanning branches and the contact centre, so listen for which sites are meant before answering | Location knockouts are cheap to check early. JD because it is a term of the listed job |
| A5 | "Why are you looking to move?" | EXP | [generic] | Logistics slot. Give your actual reason in your own words, in one or two sentences, pointed at what you are moving toward if that is true. Do not criticise your current employer | Motivation consistency is the recruiter's core check. EXP because the reason has to match the history in A1 |
| A6 | "What draws you to Ashgrove?" | CO | [grounded] the JD's "member-owned, about 900 staff"; the published value names "Members First, Always", "Plain Words", "Neighbours, Not Numbers", "Own the Fix"; the brief's "40% of member service to digital channels by 2028" | Pick the one thing that is truly your reason and say it in your own words: a value by its exact name, the member-owned model, or the digital target. One reason, said well, beats a tour of all four. The pack names no reason for you | Homework depth shows up in how exactly the value names are used. CO because it tests company knowledge, with a motivation edge |
| B1 | "The role involves regulated complaints. What's your experience of that?" | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what the quote says, at its scope: "I handled the branch's formal complaints log." Answer slot: the JD's word "regulated" makes a probe on what rules applied likely. If the complaints in that log carried regulatory requirements, say which and what they required of you, in your own words; if you do not know, or they did not, say so plainly and stay with the log | F7 is where the JD's wording runs past what your material shows. JD because it scores a stated requirement |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" | Name the gap before they do, using your own statements: "I haven't worked in a contact centre" and "I've never presented to anyone above regional level." Then one sentence of plan for whichever you pick, said as a plan: who you would spend time with first, or how you would prepare. Do not claim anything nearby. Under 30 seconds with a recruiter | F2 and F8 are your two stated absences, and this question asks for exactly them. JD because it scores the listed requirements, gaps included |

## Reverse questions for round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "What happens after the three rounds, and when do you expect to decide?" | Shows you are planning around the process, and it settles your own scheduling |
| R1.2 | "Is there anything you'd steer me toward for the 45-minute round?" | Pulls out recruiter guidance on focus, which is the single most useful thing a recruiter can add |
| R1.3 | "Will I know the panel's names beforehand?" | Unlocks an interviewer read for round 3 |
| R1.4 | "Is the 20-minute case given in advance, or live on the day?" | The email does not say; the answer changes how you prepare J1 |
| R1.5 | "Is this a new role or a replacement, and how long has it been open?" | Tells you what the manager is reacting to in round 2 |

---

# Round 2: the Head of Member Services (45 minutes)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time" scenarios | High. The recruiter calls this round mostly behavioural | Map a story where one of your sentences carries it, scaffold where none does; "we" for context, "I" for contribution; choose stories where the hard truth actually landed, and where your material shows none, say so rather than supply an ending |
| Skeptic | Quiet, persistent probing of the contact-centre and senior-presenting gaps | High. The manager prior is derisking gaps, and F2 and F8 are your stated absences | Rehearse D1 until it is boring; hold your position through two follow-ups, then concede the limit specifically |
| Case / Strategist | A live problem on the role's own roadmap | Medium. The hiring-manager prior favours it, tempered by "mostly behavioural" | Clarify, objective, segmentation, approach, metrics, risks, aloud; challenge one premise respectfully |
| Data-Driven Prober | Line-by-line questions on the one reporting artifact you have | Low. The spreadsheet (F3, F9) is your only reporting item, and a manager who must trust monthly reporting may test it | Know what you can and cannot say about it; name the weakest assumption before they do |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you dealt with a complaint that was escalated." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold. Pick an instance with a named member's problem, the step where it reached you or left you, and what happened at the end. Say "we" for the context and "I" only for what was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", or how you would handle it | The JD's escalation line raises it, and Own the Fix is the value it scores. VAL because it is a behavioural story; F1 and F7 supply the nearest material but no story |
| C2 | "Tell me about a time you had to deliver an unwelcome message to someone more senior." | VAL | [generic] | Selection scaffold. Pick a time with a named stake, what you said in plain words, and an intact relationship afterwards; prefer one where the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A stock behavioural stem, and F8 makes the senior-audience theme live for you. VAL because it scores behaviour, not a requirement |
| C3 | "When did you put a member ahead of an internal target?" | VAL | [grounded] the published value "Members First, Always — we decide from the member's side of the counter." | Selection scaffold. Pick a decision where the member's side and the organisation's side pulled apart; name the moment, what you chose, and what it cost you. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Members First is the first value and the manager will have read it closely. VAL because it scores the published value |
| C4 | "Tell me about a time you taught a colleague to handle something difficult." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "6 years in retail banking, the last 3 as a branch supervisor" | Story-mapped on F4: the beats the quotes state are that you trained new tellers, on the escalation script, and that you were a branch supervisor for the last three of your six years. Tell them in your own words. Answer slot: the JD asks about supervisors, so expect a probe on what happened after the training. If you saw what happened after, say what you saw; if you did not follow it up, say so plainly and stay with the training | F4 is your nearest evidence for the coaching line. EXP because it tests what you actually did |
| D1 | "You haven't worked in a contact centre. How would you hold that half of the job?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The highest-ROI rehearsal in this pack. Level 1, the hold: "I haven't worked in a contact centre." Then what your material carries, at its scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script." That is the branch, so say the branch. Level 2, if pressed on how a branch log helps: return to the log and the script, never add to them, and concede the difference between the two places in your own words. Level 3, if asked whether you would be credible with that team: name the limit before they do. Say what you would ask the contact-centre team to teach you first, and what you would leave unchanged until you had learned it. Levels 2 and 3 are plans, said as plans, never as a past | F2 is a stated absence against the JD's contact-centre line, so the objection arrives in some form. JD because it scores the stated scope; it gets the most follow-up levels because it is the likeliest and the least bridgeable |
| D2 | "The role means presenting to senior leaders. You haven't presented above regional level. How will you get ready?" | JD | [grounded] "I've never presented to anyone above regional level" | Hold, then concede. Say it plainly: "I've never presented to anyone above regional level." Say nothing about presenting at regional level, because your material does not. Then a plan, said as a plan: what you would prepare before a first senior audience and who you would ask to challenge it first. Do not promise confidence you have not yet had | F8 is a stated absence against a stated requirement. JD because it scores the listed requirement |
| D3 | "A supervisor with ten years of escalations behind them asks, 'What can you tell me?' What do you say?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Ask before you tell: what do they do now, and where does it stick. Then offer only what is yours: the last three of your six years in retail banking you were a branch supervisor, and you trained new tellers on the escalation script. Do not say you have coached supervisors. Answer slot: if you have helped a fellow supervisor with an escalation, say what you did and what was yours; if not, say so plainly and stay with the tellers | F4 is transferability, so this is where the coaching line gets tested. JD because it scores the stated requirement, delivered as a pressure scenario |
| E1 | "Our complaints are handled in branches and in the contact centre. What would you want to know before you changed anything?" | CASE | [generic] | Structure it aloud. Clarify first: where complaints come in, who holds each one at each step, what members say, and what is measured today. Objective in plain words, then segment by channel, then approach, then metrics: the JD's complaint volumes and resolution times, plus one measure a member would recognise. Risks: changing a process you have not learned yet. Challenge one premise, for instance whether both channels should be measured the same way. The question needs no claim about your past | A live problem from the JD's first two lines, asked at the level a manager would set it. CASE because it scores structure |
| E2 | "Ashgrove wants 40% of member service on digital channels by 2028. What does that mean for complaints?" | CO | [grounded] the brief's "40% of member service to digital channels by 2028" | Bring the consensus item to prove grounding: the target, stated as the brief states it. Then one position of your own, held with a concession. Option A: put the route to complain inside each digital journey from the start, in plain words, so no member needs it explained twice. Option B, the anti-pick: some complaints should stay with a person, and the role's job includes saying so; say which and why. Concede what you cannot see from outside: before committing you would want the complaint volumes and the channel mix | The brief is public, so reciting it scores as homework and departing from it with reasons scores as judgment. CO because it tests thinking at the company's altitude; the options are derived from the target and the Plain Words value |
| G1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F3: the beats the quote states are that you built it, it is monthly, it is about complaints, and your regional manager uses it. Say each at that scope. Answer slot: the JD names volumes, resolution times and Excel, so expect a probe on what it showed and in what. If it showed either measure, say which and how it was worked out; if it showed neither or something else, say so plainly and say what it did show; if it was not built in Excel, say what it was built in | F3 and F9 are the only reporting evidence you have. EXP because it tests whether the claim survives a line-by-line read |
| G2 | "If you rebuilt that spreadsheet tomorrow, what would you change?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The weakest-assumption move: before they ask, name the part of it you would defend least, in your own words. If you cannot name one, say plainly that you have not tested it that way. Never invent a flaw or a fix you did not consider | A manager who will depend on monthly reporting wants to see you stress-test your own work. EXP because it scores self-knowledge about a built artifact |

## Reverse questions for round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "How is ownership of a complaint split today between the branches and the contact centre, and where does it come apart?" | It is the end-to-end question from the JD, asked from the outside, and it shows you start by learning the current state |
| R2.2 | "What would you want complaints work to have changed six months in?" | Tells you the manager's real success measure and lets you echo it back |
| R2.3 | "Who reads the monthly report, and what decision does it feed?" | Turns the reporting line into a purpose and tells you who the senior audience is |
| R2.4 | "As service moves toward digital, how do you expect the complaints you see to change?" | Shows you thought about E2 before arriving, and invites the manager's view rather than yours |
| R2.5 | "Who will hold complaints for the small-business lending product launching in Q1 2027?" | A strategy-grounded question that few candidates ask, built from a published plan |
| R2.6 | "Who in the contact centre would I shadow first, and how quickly could that happen?" | Turns the gap in F2 into a plan the manager can help with, which is how that gap is best handled |

---

# Round 3: the panel of two branch managers (60 minutes, with a 20-minute case; also the values round)

## Persona table

The panel's names are not yet assigned, so this is one blend rather than a per-member assignment.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes scored against the four values | High. The recruiter says this panel is the values round and scores against the four values | Land one value by its exact name per answer; use a mapped story only where one of your sentences carries it, a scaffold ending in the honest branch where none does |
| Case / Strategist | The live escalation case and its follow-ups | High. Twenty of the 60 minutes are the case | Think aloud: clarify, objective, approach, metrics, risks; challenge one premise respectfully; use their value vocabulary without reciting it |
| Peer Evaluator | Seam, credit and disagreement probes | Medium. Branch managers are the people whose supervisors you would coach, so where your job meets theirs is a natural probe | Reciprocity framing: what you bring their branch, not only what you need; propose seam principles rather than pretending to know the seam |
| Conversational / Rapport Builder | Friendly, branch-focused openers | Low. The email says nothing about tone, so this is a prior only | Treat casual branch questions as scored; keep answers short and concrete |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell us about a time you decided something from the member's side of the counter." | VAL | [grounded] the published value "Members First, Always — we decide from the member's side of the counter." | Selection scaffold. Pick a decision where the member's side and the organisation's side pulled apart; name the moment, what you chose, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. Use the value's name once, naturally | The panel scores each value, and the question lifts the value's own wording. VAL because it is the published value as a prompt; no quote in your material carries a story for it |
| H2 | "Tell us about a time a member needed something explained twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." the published value "Plain Words — if a member needs it explained twice, we wrote it wrong." | Selection scaffold. Pick a case where the first explanation did not land, what it said, and what you changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: you trained new tellers on the escalation script, which is training on a script and not writing one, so say it at that scope. Or say how you would handle it | The value turns the question into a test of how you treat your own wording. VAL because it scores the published value; F4 is the nearest material but carries no story |
| H3 | "Tell us about a time the numbers and the neighbours pointed different ways." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." the published value "Neighbours, Not Numbers — every branch is part of its town." | Selection scaffold, and expect this one to be pointed at you: the one reporting artifact in your material is a spreadsheet. Pick an instance where the figures said one thing and the people another; name what each said and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: you built the monthly complaints spreadsheet your regional manager uses, which is the numbers side only, or how you would handle it | Branch managers are the ones who live the "not numbers" half, and F3 puts you on the numbers side. VAL because it scores the published value |
| H4 | "Tell us about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." the published value "Own the Fix — whoever finds the problem keeps hold of it until it is solved." | Selection scaffold. Pick a problem you found, not one handed to you; name it, how long you held it, and what solved meant to the member. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: you handled the branch's formal complaints log, which says handling a log, not keeping hold of a problem until solved, or how you would handle it | The value is the closest to the JD's "own" wording, so expect it to be probed hardest. VAL because it scores the published value; F1 is the nearest material but carries no story |
| H5 | "Which of our four values will be hardest for you, and why?" | VAL | [grounded] the published value names "Members First, Always", "Plain Words", "Neighbours, Not Numbers", "Own the Fix" | Pick honestly. The value whose scaffold above you found hardest to fill is your answer; name it by its exact name, say plainly why, and say what you would do about it. Do not choose a weakness that is secretly a strength | Panels that score against four values often ask for the weakest. VAL because it scores self-awareness against the published values; it carries no claim about your past |
| J1 | "A member's complaint has been escalated twice and they are still unhappy. Take us through how you would handle it." | CASE | [generic] | The real case may differ from this one, so rehearse the structure, not the story. Clarify first: what the member has been told, by whom and in what words, what exactly they are asking for, and where the complaint sits now. Objective in plain words: the member's problem solved, not only the case closed. Then approach, who holds it at each step, measures, and risks. Think aloud and challenge one premise, for instance that twice is a signal to look at why before a third time. The question needs no claim about your past | The recruiter names a 20-minute escalation case. CASE because it scores structure; the contents are a pattern, not a fact about Ashgrove's case |
| J2 | "In your approach, who keeps hold of the problem at each step, and how does that fit with escalating it to someone else?" | CASE | [inferred] | A position to hold, not a fact about your past. Thesis: escalating hands over the work, not the ownership, so whoever found it stays informed and keeps the member told. Hold it through two follow-ups, then concede the limit: it can pile up on one person, and you would say where you would draw the line. You may choose a different position; what matters is that it is yours and has a concession | The Own the Fix value and the JD's escalation line pull against each other, and a panel that scores both will probe the seam. CASE because it extends the live case; the derivation is from the value's wording and the JD's escalation line |
| J3 | "Eight branches become five hubs over 2027. What would you watch on complaints while that happens?" | CO | [grounded] the brief's "consolidate eight branches into five hubs over 2027" | Bring the consensus item to prove grounding: the plan as the brief states it. Then your own position: watch volumes and resolution times by branch, as the JD names them, and what members say in their own words, so the numbers carry the neighbours. Concede what you cannot see from outside: which branches change and when. The panel may include managers whose own branches are affected and the pack cannot know, so stay with the member's side and ask what has been decided rather than predicting harm | The strategy brief and the values sit side by side, and a branch-manager panel will feel the seam between them. CO because it tests strategy fluency at the panel's own altitude |
| K1 | "You would coach our supervisors on escalations. Where is the seam between your job and ours, and what happens when we disagree?" | JD | [generic] | Propose seam principles and do not claim to know the seam: agree who keeps hold at each step before a problem arrives; disagree with the branch manager first, in private; take any unresolved disagreement to both managers, and only after the member is looked after. Add what you bring their branch, not only what you need. The question needs no claim about your past | The JD's coaching line puts you in their supervisors' working life. JD because it scores the stated requirement, in a peer's collegial register |
| K2 | "A complaint starts in one of our branches and ends in the contact centre. Who owns it, and who takes the blame if it goes wrong?" | JD | [grounded] "Never worked in a contact centre" | Say who keeps hold in plain words: whoever found it keeps it, with a named person at each handover. Credit is shared by name; blame is treated as a finding about the route first. You can add, from your own stated limit: "I haven't worked in a contact centre", so you would ask the people who do where the handover tends to break. That is a plan, not a past | The JD's end-to-end line crosses both channels, and F2 means you should expect the cross-channel question. JD because it scores the stated scope |
| L1 | "What is your own experience of banking through an app, good or bad?" | JD | [generic] | Answer from your real use: one thing that worked, one that did not, in plain terms. Answer slot: the JD asks you to work with digital teams on self-service journeys. If you have worked with any digital team or on any member-facing digital process, say what and which part was yours; if you have not, say so plainly, and say what you would want to learn first | A friendly opener on the JD's digital line, and the brief's main competitive pressure is app-only banks. JD because it scores F5 in conversational form |
| L2 | "Tell us about your branch and the town around it." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | The beat your material states is that you were a branch supervisor for the last three of your six years in retail banking. Answer slot: describe your branch's members and the town in your own words, only what is true. If you cannot speak to the town, say so plainly and describe the branch you ran | The Neighbours, Not Numbers value makes a branch-manager panel curious about where you come from. EXP because it checks your own account of your branch |

## Values cheat sheet

Where no sentence of yours carries a story, the cell is a selection scaffold ending in the honest branch. Names are the official ones as you pasted them.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decisions start from the member's position, not the organisation's convenience | No row carries a story. Scaffold: pick a decision where the member's side and the organisation's side pulled apart; name the moment, what you chose and what it cost; if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it |
| Plain Words | If an explanation has to be repeated, the fault is in the writing | F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." That is training on a script, not writing one. Scaffold: pick a case where your first explanation did not land and say what you changed; if none comes to mind, say so plainly |
| Neighbours, Not Numbers | Each branch matters to the town it sits in, beyond what its figures say | F3: "I built the monthly complaints spreadsheet our regional manager uses." That is the numbers side only. Scaffold for the neighbours side: pick a time the figures and the people pointed different ways; if none comes to mind, say so plainly |
| Own the Fix | The person who finds a problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." That says handling a log, not keeping hold of a problem until solved. Scaffold: pick a problem you found and held; if none comes to mind, say so plainly |

## Reverse questions for round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What could a new person in this role do in their first month that would genuinely help your branch?" | The reciprocity question: it puts the panel's load, not your needs, at the centre |
| R3.2 | "When a complaint from your branch has been handled well, what did it look like from where you sit?" | Gives you their definition of good before you are scored against it |
| R3.3 | "How are your supervisors feeling about the hub plans, and what would help them from my seat?" | Keeps you on the member and the supervisors' side of the change, rather than staffing, and it respects that panel members may be affected |
| R3.4 | "When Ashgrove says Own the Fix, what does it look like on a bad day in a branch?" | Uses the value's own name and asks for the real version, not the slogan |
| R3.5 | "What would tell you, a few months in, that complaints work was helping your branch rather than adding to its load?" | Turns the peer probe back into a measure they set |

---

# Prohibited claims

What this pack will not coach, and why. Two kinds of entry: negatives you stated, and stretched forms of sentences you did say.

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked in a contact centre, or anything near it | Negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders, or above regional level | Negative you stated, F8 | "I've never presented to anyone above regional level." No slot |
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says the branch's log and the script, not the process end to end. The slot stays inside the log |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: you trained new tellers on the escalation script, and were a branch supervisor for the last three of six years. The slot asks only whether you helped a fellow supervisor, with the plain branch for either answer |
| Reported complaint volumes and resolution times monthly | Inflated form of F3 | F3's quote at its own scope: you built the monthly complaints spreadsheet your regional manager uses. The slot asks only what it showed |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: the branch's formal complaints log. The limit is the pack's observation: the material says formal, not regulated |
| Has Excel reporting skills | Inflated form of F9 | F9's quote at its own scope: a spreadsheet you built. The limit is the pack's observation: the material says spreadsheet, not Excel |

# Sources

Provided documents: the JD as pasted; the four values as pasted, which you said were copied on 20 November 2026 from the company's values page; the recruiter's email describing the three rounds; your four-point summary of the July 2026 strategy brief, with the brief itself not read; your background note, quoted in the fit snapshot. No `tuesday-dossier.md` was present. No search or fetch was sent, and no link was given to read.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values page is in hand and fixes the four names and wordings in the cheat sheet and the VAL bank |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email fixes the rounds, their lengths, who runs them and the values round, which fix the persona weights and the mini-pack structure |
| 3. `Ashgrove Credit Union strategy` | skipped | The brief you summarised, dated July 2026, fixes the strategy points the CO bank and the grounding brief use; only your summary was in hand |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names were given, only roles, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

# Upgrade menu

- Interviewer names for the Head of Member Services and the two branch managers → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to each one's own path
- A CV, or any fuller account of your work → F1, F3, F4, F6, F7 and F9 can quote beyond your one-paragraph note, and where it carries a story the H1 to H4 scaffolds become mapped stories
- Your answers to the answer slots, stated here: what the complaints log covered and whether the complaints in it were regulated (F1, F7), what the monthly spreadsheet showed and whether it was in Excel (F3, F9), any work with a digital team (F5), and any help you gave a fellow supervisor on an escalation (F4) → those rows move from discovery to graded evidence and C4, D3, G1 and L1 become story-mapped
- A story from your own work for each of the four values → H1 to H4 and the values cheat sheet become mapped stories instead of scaffolds
- The strategy brief's own text → the grounding brief and E2, J3 and R2.5 use its exact vocabulary instead of your four-point summary
- The recruiter's answer on whether the 20-minute case is shared in advance → if a pre-read or deliverable exists, a build section is added for it; otherwise J1 stays a structure rehearsal
- Hours available before 29 November → a prep triage that orders the questions that earn the most
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, covering the strategy, interviewer footprints, role-family loop reports and recent organisation news → a current grounding brief, and the interviewer read when names arrive
- A `tuesday-dossier.md` from job-underwriter's check of this role → evidence graded beyond your own note and the objection to rehearse deepest chosen from checked material rather than inferred
