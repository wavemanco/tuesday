I'll read the skill's reference files before building the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/alone/part-2/rooms/case-8-canned-9df5d80e/ashgrove-credit-union_member-experience-lead_interview_pack.md`. It is a three-round loop built from the recruiter's email. A shared fit snapshot comes first. Each round then gets its own persona weights, question bank and reverse questions. The values cheat sheet sits with the panel round, since the recruiter said the panel scores against the four values.

I ran no searches because your pasted values, the recruiter's email, the JD and your strategy summary already covered every research target. The Sources section has the full accounting. The pack has no interviewer read yet, because no names are assigned.

The question I'd rehearse hardest is D1 in Round 2: "You'd own complaints across the contact centre too, and you haven't worked in one. Why should I believe you can?" You said you've never worked in a contact centre, so some version of that question is likely.

Say the word and I'll play the Skeptic on D1, with follow-ups that react to what you say.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Mode:** Loop, three rounds on 29 November 2026 (built 20 November 2026)

| Round | Who | Length | Relationship | What the recruiter's email says it holds |
|---|---|---|---|---|
| 1 | The recruiter | 30 min | Recruiter screen | Not stated |
| 2 | Head of Member Services | 45 min | Would be your manager | "mostly behavioural" |
| 3 | Panel of two branch managers | 60 min | Panel | A 20-minute case on a complaint escalation; "the values round — they score against the four values" |

Interviewer names are not assigned yet, so there is no interviewer read. The question this pack names as your highest-ROI prep is **D1** in Round 2.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored. Every question carries one type tag.
- Guidance is scaffolding, not a script. It holds only what your own sentences say, plus answer slots: places where the interviewer is likely to probe and the honest answer is yours, in your own words, including "that wasn't mine" or "that didn't exist".
- Rehearse out loud. Rounds 2 and 3 are where delivery matters most.

| Type | Meaning |
|---|---|
| VAL | Behavioural or values alignment: does past behaviour show the published values |
| EXP | Work-experience deep-dive: does what you said survive follow-ups |
| JD | Role and JD requirements, including the gaps |
| CO | Company and strategy knowledge |
| CASE | A live problem from the actual role |

## Fit snapshot (shared across all three rounds)

Your sentences are quoted exactly from your message. "Experience" requirements here are graded like any other row; none is a gate (no licence, location, schedule or pay term is stated in the JD).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Your sentence already reaches the years. Say it as you wrote it: "Six years in retail banking, the last three as a branch supervisor." The words stay at retail banking, which is what the sentence says |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your sentence says a formal log; your material does not show which rules or deadlines governed it. Words: "I handled the branch's formal complaints log." Answer slot: the JD says regulated, so expect a probe on what the log had to meet. If rules or deadlines applied to it, say which and what was yours to do about them, in your own words; if you do not know, or none applied, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your sentence carries one branch's formal log, so the words stay there: "I handled the branch's formal complaints log." Answer slot: "end to end" invites a probe on what happened to a complaint before it reached the log and after it left. If any of that was yours, say which part, in your own words; if the log was where your part began and ended, say so plainly and stay with the log |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You stated this limit, and wording cannot close it. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says a monthly complaints spreadsheet your regional manager uses; it does not show what the spreadsheet counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet showed. Say what it counted, in your own words; if it did not count resolution times, or you do not know how a figure in it was counted, say so plainly and stay with the spreadsheet you built |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence names a spreadsheet, not the tool. Answer slot: the JD names Excel, so expect a probe on the tool. Say which tool it was built in, in your own words; if it was not Excel, say so plainly and stay with the spreadsheet you built |
| F7 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your sentence carries training new tellers on the escalation script, so the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's audience is supervisors, so expect a probe on coaching people at or above your own level. If you have coached a supervisor, say how and what part was yours; if not, say so plainly and stay with the tellers |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You stated this limit. Words: "I haven't presented above regional level." Then how you would prepare, said as a plan and never as a past. Your message does not say what you have presented at regional level, so nothing here claims it |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: if you have worked with a digital or product team on anything members use themselves, say what and which part was yours, in your own words; if you have not, say so plainly and say how you would start |

### Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| 4+ years in financial-services customer operations | B2, A1 |
| Experience handling regulated complaints | D3, C1 |
| Own the complaints process end to end across branches and the contact centre | D1, B1, E1, H1 |
| Monthly reporting on complaint volumes and resolution times | F1, E1 |
| Coach branch supervisors on escalations | C2, H2, I1 |
| Work with digital teams on self-service journeys | C3, H4 |
| Confident presenting to senior leaders | D2, C4 |
| Comfortable with Excel reporting | F1 |
| Published values (Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix) | G1, G2, G3, G4 |
| Strategy (digital shift, hubs, app-only competition) | A6, H3, H4 |

---

# Round 1: The recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly career walk-through, then logistics | High. Recruiter-screen prior is Conversational plus a light Skeptic, and the email gives this round no stated focus | A pre-scripted 90-second arc built only from the beats in A1's quotes; treat the casual questions as scored |
| Skeptic (light) | Knockout checks on the JD's headline requirements | Medium. The recruiter screens against the JD, and your message states a contact-centre limit | The plain acknowledgment from F4, then one sentence of plan, then stop (B1) |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your career so far, and what brings you to this role." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc with only the beats those sentences state: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log; you trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Add nothing the sentences do not say unless you can tell it from memory under a follow-up. Answer slot: why you want this role, in your own words | The opener is the recruiter screen's one near-certain question, and F1, F2, F5 and F7 all enter through it. EXP because it tests whether your own account holds together |
| A2 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own number or range in your own words, or ask for the role's band first. Offer no figure or salary history that is not yours | The recruiter row of the persona model names pay as a standing screen question. JD because it concerns the listed job's terms |
| A3 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | Standing recruiter logistics; JD because it is a term of the listed job |
| A4 | "Where are you based, and could you work across more than one site?" | JD | [generic] | Logistics slot: say where you are based and what travel between sites you can actually do. Say only what is true for you | The JD's "across branches and the contact centre" makes site coverage a plausible screen. JD because it concerns the listed job's terms |
| A5 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot: give your own reason, in your own words, in one or two sentences. Keep it consistent with the reason you give for wanting this role in A1 | Standing recruiter question on motivation consistency. EXP because it is about your own history, not the job |
| A6 | "What do you know about Ashgrove, and why this role?" | CO | [grounded] Strategy summary and values page as pasted | Bring one fact from the strategy brief to show you read it, such as the 2028 digital target. Then one view of your own, flagged as a view: a digital-first plan is tested by the complaints that self-service does not resolve. Concede it plainly: "That is a view, and I haven't seen Ashgrove's complaints data." Do not recite the brief. Answer slot: your own reason for choosing a member-owned organisation | The brief was sent to you and published, so other candidates hold it too; one fact proves grounding and a reasoned divergence shows judgment. CO because it scores homework depth |
| B1 | "You haven't worked in a contact centre. How do you see that for this role?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | The short version of D1. One plain sentence: "I haven't worked in a contact centre." Then one sentence of plan in your own words, then stop. Add nothing about phone work or call handling | F4 is a stated limit the recruiter can read straight from the JD. JD because it scores a listed requirement; the full rehearsal is D1 |
| B2 | "The role asks for four or more years in financial-services customer operations. How do your years line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say it as you wrote it: "Six years in retail banking, the last three as a branch supervisor." Then stop and let them ask. Answer slot: if they ask what the first three years covered, answer from your own memory; this pack does not supply it | F1 is the one requirement your sentence already reaches, so the rehearsal is brevity. JD because it checks a stated requirement |

### Reverse questions

| Question | Why it lands | Provenance |
|---|---|---|
| "Which rules does the complaints process have to meet, and how are those deadlines tracked today?" | It shows you will work to the rules the JD's word "regulated" points at, and it asks the thing your material does not establish | [grounded] |
| "What happens today when a complaint moves between a branch and the contact centre?" | It goes to the JD's "end to end across branches and the contact centre" and to the value "Own the Fix" | [grounded] |
| "After Round 3, what does the decision process look like and by when?" | Ordinary and low-risk; it closes the screen on logistics | [generic] |

---

# Round 2: Head of Member Services, your manager (45 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time" prompts | Highest. The recruiter describes the round as "mostly behavioural" | Pick stories before the day; "we" for context, "I" for what you did; where no story comes to mind, the honest branch in each scaffold |
| Skeptic | Quiet probing of the contact-centre, senior-presenting and regulated-complaints gaps | High. The hiring-manager prior is Skeptic plus Case, and two of your gaps are stated in your own words | Rehearse D1 until it is boring: plain concession, then plan, never a claim |
| Case / Strategist | One live problem from the role | Medium-low. "Mostly behavioural" suggests fewer cases here, and the formal case is announced for Round 3 | Clarify, then structure, then answer; say the structure aloud |
| Data-Driven Prober | The monthly spreadsheet, line by line | Low-medium. The JD names monthly reporting, and your sentence names a spreadsheet | Say what you know about what it counted and say plainly what you do not |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold, because your sentence carries the log and no solved case. Choose one case from your own work with a named stake, the part you personally kept hold of, and how it ended. "We" for context, "I" for what you did. If no such case comes to mind, say so plainly, then give the nearest thing your material carries, that you handled the branch's formal complaints log, or how you would handle it | Own the Fix is a published value and the JD makes you the owner of the process. F2 is your only complaints evidence and carries no story. VAL with EXP content |
| C2 | "Tell me about a time you coached someone through an escalation." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The beat your sentence states: you trained new tellers on the escalation script; tell it in your own words. Answer slot: the JD's audience is supervisors, so expect a probe on coaching people at or above your own level. If you have coached a supervisor, say how and what part was yours; if not, say so plainly and stay with the tellers | F7 is where the JD's coaching line meets your evidence. EXP because it tests what you actually did |
| C3 | "Tell me about a time you worked with a digital or technology team." | JD | [grounded] JD line "work with digital teams on self-service journeys" | Selection scaffold, because no sentence of yours speaks to this. Choose a time with a named team, what members would use, and the part that was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would start | F9 is silent in your material, so the honest rehearsal is the branch where it is not yet your experience. JD because it scores the listed requirement |
| C4 | "Tell me about a time you had to give a senior person news they did not want." | VAL | [generic] | Selection scaffold: choose a time with a named stake, a moment you did not fold, and the relationship intact at the end. Choose one where the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The JD asks for confidence with senior leaders, and F8 is a stated limit. VAL because it is a standard behavioural stem |
| D1 | "You'd own complaints across the contact centre too, and you haven't worked in one. Why should I believe you can?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **The highest-ROI rehearsal in this pack.** Hold only what the quotes carry: "I handled the branch's formal complaints log." Concede in one plain sentence: "I haven't worked in a contact centre." Limit, named before it is asked: your material shows one branch's log, not a view across channels. Follow-up 1, "How long before you're useful there?": answer as a plan, what you would learn first and from whom, and give no timing you cannot defend. Follow-up 2, "Their team will know more than you. How do you earn trust?": stay with what you would ask them and look at, and claim no contact-centre knowledge. Hold through both by returning to the log, never by adding to it | This objection will arrive in some form because the JD names the contact centre and F4 is stated. JD because it scores a listed requirement; the Skeptic delivery is the rehearsal |
| D2 | "You'd present to senior leaders every month, and you haven't presented above regional level. How will you manage?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Concede plainly: "I haven't presented above regional level." Then your preparation as a plan in your own words. The one thing your sentences give you to talk about is the spreadsheet you built, so offer to walk them through that. Answer slot: if you have presented at regional level, say to whom and about what; if not, say so plainly | F8 is a stated limit and the JD names senior leaders. JD because it scores a listed requirement |
| D3 | "Tell me about handling a regulated complaint." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what your sentence says: you handled the branch's formal complaints log. Answer slot: the JD says regulated. If rules or deadlines applied to the log, say which and what part was yours, in your own words; if you do not know, or none applied, say so plainly and stay with the log. Never describe a rule you cannot name under a second question | F2 is the row where the JD's word "regulated" is least carried by your sentence. JD because it scores the stated requirement |
| D4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose from your own list. Your message states two limits, the contact centre and presenting above regional level. Pick one you can give a plan for, say it plainly, then the plan. Do not choose a weakness that costs you nothing | A standard Skeptic stem. JD because it asks you to rank the listed requirements; F4 and F8 are the candidates |
| E1 | "Suppose branches and the contact centre record complaints in different ways. How would you build one picture of volumes and resolution times each month?" | CASE | [generic] | Clarify first: what each channel records and how it defines a complaint, who reads the report. Then objective, segmentation by channel and issue type, approach, the two measures the JD names, and risks. Challenge one premise politely. The question needs no claim about your past, so the guidance makes none | The JD makes this monthly picture the role's core output. CASE because it is a live problem from the role |
| F1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The beats your sentence states: you built it, it was monthly, your regional manager used it. Answer slot: the JD names volumes and resolution times and Excel, so expect probes on both. Say what it counted and which tool it was built in, in your own words; if it did not count resolution times, if it was not Excel, or you do not know how a figure was counted, say so plainly and stay with the spreadsheet | F5 and F6 are discovery rows, so this is where a Prober tests them. EXP because it checks a CV claim; no figure is quoted, so there is no number to defend |

### Reverse questions

| Question | Why it lands | Provenance |
|---|---|---|
| "What would you want to see fixed in the complaints process by the end of the first 90 days?" | It asks your future manager for the outcome they are buying | [generic] |
| "How do senior leaders use the monthly complaints report today?" | It speaks to the JD's monthly report and your stated gap on senior audiences | [grounded] |
| "Which parts of the 2027 branch-to-hub plan touch the complaints process?" | It shows you read the strategy brief and asks where the role meets it | [grounded] |
| "What would make you say, a year in, that this hire worked?" | A manager-round standard that invites the success measure | [generic] |

---

# Round 3: Panel of two branch managers (60 minutes, 20-minute case)

### Persona weights

The panel members are not named, so personas are not assigned per person.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Stories scored against the four published values | Highest. The recruiter says the panel is the values round and scores against the four values | One story or scaffold per value (G1 to G4); the cheat sheet below |
| Case / Strategist | The announced 20-minute complaint-escalation case | High. The recruiter states the case and its length; its content is not known, so H1 is a rehearsal case | Clarify, then structure, then answer, in the company's own words |
| Peer Evaluator | The seam between a branch and your role | Low-medium. [inferred] Branch managers sit beside the supervisors the JD says you would coach; this reading is mine, not stated by the recruiter | Offer seam principles and what you bring their branch, rather than pretending to know the seam |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] Values page as pasted: "Members First, Always — we decide from the member's side of the counter." | Selection scaffold, because none of your sentences carries a decision of this kind. Choose a time with a named decision, what the member needed and what it cost you or the branch. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | Members First, Always is a published value and the panel scores against it. VAL because it tests behaviour against a named value |
| G2 | "Tell me about a time something you wrote or said had to be explained twice." | VAL | [grounded] Values page as pasted: "Plain Words — if a member needs it explained twice, we wrote it wrong." | Selection scaffold. Choose a time with what was unclear, what you changed, and how it read afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it. Say your answer in plain words | Plain Words is a published value, and the listener will hear how you speak as much as what you say. VAL |
| G3 | "When have you weighed what a number said against what a local community needed?" | VAL | [grounded] Values page as pasted: "Neighbours, Not Numbers — every branch is part of its town." | Selection scaffold. Choose a time with the number, the local need, and what you decided. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it. The strategy brief consolidates eight branches into five hubs, so expect this to be heard against that plan | Neighbours, Not Numbers is a published value and the panel are branch managers. VAL |
| G4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold, as in C1: your sentence carries the log, not a solved case. Choose one case with a named stake, the part you kept hold of, and how it ended. If no such case comes to mind, say so plainly, then give the nearest thing your material carries, that you handled the branch's formal complaints log, or how you would handle it | Own the Fix is a published value and C1 rehearses it earlier; the panel scores it. VAL |
| H1 | "Case, 20 minutes: a member's complaint has been passed between a branch and the contact centre, has now reached you, and the member says they will move to an app-only bank. Walk us through it." | CASE | [generic] | A rehearsal case, because the real one is not known. Clarify first: what the complaint is, what has been promised, how long it has run, which deadlines apply and whether the clock is running, who holds it now. Then objective, this complaint versus the pattern, approach, measures, risks. Use Ashgrove's own words: someone keeps hold until it is solved; explain to the member in plain words. Challenge one premise politely, such as whether the member's move is stated or implied. No claim about your past | The recruiter announced a complaint-escalation case. CASE because it is a live problem; the app-only framing comes from the brief |
| H2 | "A branch supervisor escalates every complaint to you, including simple ones. How do you coach them?" | CASE | [generic] | Clarify why it happens before coaching: authority, confidence, an unclear route. Objective, approach, a measure such as escalations against resolutions, risks. The question needs no claim about your past | The JD's coaching line, asked as a decision in front of branch managers. CASE with JD content |
| H3 | "In 2027 eight branches become five hubs. What happens to the complaints process for members whose branch closes?" | CO | [grounded] Strategy summary as pasted: "consolidate eight branches into five hubs over 2027" | Structure: clarify what changes and when, objective, which members are affected, approach, measures, risks. Name what you do not know about Ashgrove's data. Weigh it against Neighbours, Not Numbers, aloud. No claim about your past | The hub plan is the brief's most branch-facing move and the panel are branch managers. CO with CASE delivery |
| H4 | "By 2028, 40% of member service moves to digital. Which complaints should never sit behind a self-service journey?" | CASE | [grounded] Strategy summary as pasted: "move 40% of member service to digital channels by 2028" | Structure: clarify what self-service covers, objective, segment complaints by kind, approach, measures, risks. A reasoned anti-pick is the divergence from the consensus answer: say what you would keep with a person and why, and concede the limit of your view. Link to F9 only through its answer slot | Ties the JD's digital line to the brief's main target. CASE because it is a live problem |
| I1 | "Suppose a branch manager tells you a new escalation route does not suit their branch. Where is the seam, and what happens when we disagree?" | CASE | [generic] | Seam principles, not a map you do not have: who holds a complaint at each stage, what each side can decide, how you disagree in the open. Reciprocity: say what you bring the branch. No claim about your past | A Peer Evaluator stem, applied to the escalation route the JD says you coach on. CASE with a peer delivery |
| I2 | "How do you handle credit when a result spans more than one branch?" | VAL | [generic] | Selection scaffold: choose a time with a shared result, who did what, and how credit was handled. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | A standard peer stem on collaboration; the loop crosses branches |

### Values cheat sheet

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold (G1): no sentence of yours carries it; the honest branch is built in |
| Plain Words | If a member needs it explained twice, the writing was wrong | Selection scaffold (G2): no sentence of yours carries it; the honest branch is built in |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold (G3): no sentence of yours carries it; the honest branch is built in |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Selection scaffold (G4): F2, "I handled the branch's formal complaints log and trained new tellers on our escalation script." is the nearest, and it carries a log with no solved case |

### Reverse questions

| Question | Why it lands | Provenance |
|---|---|---|
| "How do escalations work for your branch today, and what would you want to change?" | It asks the people the JD says you would coach what they need | [grounded] |
| "What could a new person in this role do in their first month that would genuinely help your branch?" | The reciprocity question for a peer-style panel | [generic] |
| "Where do you see Own the Fix working or failing when a complaint crosses from a branch to the contact centre?" | It uses the published value on the exact seam the role owns | [grounded] |

---

## Grounding brief

| Item | What your summary of the brief says | Using it without reciting it | Provenance |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | One fact to prove grounding (A6); H4 builds on it | [grounded] |
| Hubs | "consolidate eight branches into five hubs over 2027" | H3; heard against Neighbours, Not Numbers | [grounded] |
| Small-business lending | "launch a small-business lending product in Q1 2027" | Reverse-question material only; no complaints claim rests on it | [grounded] |
| Competition | "the main competitive pressure is app-only banks" | Frames H1 and H4 | [grounded] |

The brief is dated July 2026, about four months before today. The pack has your summary of it, not the document.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process across branches | Inflated form of F3 | F3's quote at its own scope: you handled the branch's formal complaints log. The limit is the pack's observation: your material says one branch's log, not a cross-branch process. The slot stays inside the log |
| Handled regulated complaints to a regulatory standard | Inflated form of F2 | F2's quote at its own scope: a formal log. Your material says a formal log, not what governed it. The slot asks only what the log had to meet |
| Has contact-centre experience or managed across channels | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders or executives | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't presented above regional level." No slot |
| Has coached branch supervisors | Inflated form of F7 | F7's quote at its own scope: you trained new tellers on the escalation script. The slot asks only about coaching at or above your level |
| Built dashboards or reporting on resolution times in Excel | Inflated form of F5 and F6 | F5's quote at its own scope: a monthly complaints spreadsheet. The slot asks what it counted and in which tool |

## Sources

Provided documents: the JD as pasted; the four values as pasted, with a stated copy date of 20 November 2026 from ashgrovecu.org/about/values (named as the source of the paste, not fetched); the recruiter's email on the process; your summary of the July 2026 strategy brief; your background message. No dossier was present.

No search or fetch was sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove values` | skipped | The pasted values page fixes the values cheat sheet and G1 to G4 |
| 2. `Ashgrove interview process member experience` | skipped | The recruiter's email names three rounds with who runs each and what each holds, which fixes the loop and the persona weights |
| 3. `Ashgrove strategy` / recent news | skipped | Your summary of the July 2026 brief fixes the grounding brief and the CO and CASE questions |
| 4. `{interviewer name} Ashgrove` | n/a | No interviewer names are assigned, so there is no query; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names, once assigned → an interviewer read, per-member personas for the Round 3 panel, and a reverse question tied to each person's own path
- The recruiter's detail on the 20-minute case → H1 becomes a build around their actual case rather than a rehearsal
- The strategy brief's full text → the grounding brief rests on the document instead of your summary
- Your answers to the slots in F2, F3, F5, F6, F7 and F9 (what the log had to meet, what the spreadsheet counted and which tool it used, whether you have coached a supervisor or worked with a digital team) → those rows move from slots to mapped stories, and C1, C2, D3, F1 and G4 get story-mapped guidance
- How many hours you have before 29 November → a prioritised prep schedule
- A one-line reply from the recruiter confirming the date and format: 29 November 2026 falls on a Sunday on the calendar, and the email names three rounds on that day → confirmed times, in person or on video, and whether the rounds run back to back
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → interviewer talks and writing once names exist, loop reports for this role family, recent organisation context
- A tuesday-dossier.md from a job-underwriter run → verified evidence and prohibited claims in place of the ones built here; the pack stands without it
