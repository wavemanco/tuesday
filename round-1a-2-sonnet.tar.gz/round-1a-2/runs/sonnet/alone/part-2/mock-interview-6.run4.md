I'll read the skill's reference files before building the pack.
Your pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/alone/part-2/rooms/case-6-denied-26bf3d26/larkfield-systems_engineering-manager_interview_pack.md`. It covers all three rounds: a shared fit snapshot, then a mini-pack per round with persona weights, 8–10 questions and reverse questions.

**Assumptions it's built on:**
- I worked from your one-line role description and the facts in your message. There's no full posting, no interviewer names and no declared exercise.
- The role description names no location, pay or schedule terms, so the snapshot has no gate rows.
- All three web searches (Larkfield's values, interview process and strategy) were refused for lack of permission. Nothing in the pack comes from outside your message, and the company-knowledge and case questions are labelled `[generic]`.
- Because of that, the Monday values cheat sheet is left out. The upgrade menu says what would unlock it.

**Highest-ROI prep:** 1B2, the "team of six to two squads, eleven engineers and a hardware partnership" objection. Your stated gaps (managing managers, owning a hardware-adjacent roadmap) are where that question will land. 3C1 is the same objection in a 60-second version. The single on-call figure is probed in 1C1, 2B3 and 3C2, so it's the second priority.

Say the word and I'll play the Skeptic on 1B2, with follow-ups that react to what you actually say.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full job posting, plus anything the recruiter told you about the panel's format? Either would restructure rows in the fit snapshot and the panel bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems (three-round loop)

**Candidate:** Yusuf. **Role:** Engineering Manager, Larkfield Systems (industrial IoT, about 600 people), leading two squads that build device-management services.

| Round | Who | Length | Relationship |
|---|---|---|---|
| 1. Tuesday | Director of Engineering, the hiring manager | 45 min | Your would-be boss |
| 2. The Thursday after | Panel: two staff engineers and a product manager | 60 min | Peers and a cross-functional partner |
| 3. The following Monday | VP Engineering | 30 min | Skip-level; the recruiter's words are "values and leadership philosophy" |

No interviewer names are known, so there are no per-person reads. This pack is loop mode: one shared fit snapshot, then a mini-pack per round with its own persona weights, question bank and reverse questions.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Where guidance says "answer slot", it is an instruction for the interview: answer it truthfully from your own experience, and the second branch ("say so plainly") is always an acceptable answer.

| Type | What it is really scoring |
|---|---|
| VAL | Whether past behavior shows values and leadership, not generic virtue |
| EXP | Whether what you say about your work survives follow-up questions; what was actually yours |
| JD | The stated responsibilities, including the ones you are thinner on |
| CO | How well you know the company and its strategy |
| CASE | Structure and reasoning on a live problem from the actual role |

Question IDs are round, then persona letter, then number: 1B2 is round 1, persona B, question 2.

## Prep triage

Two weeks, three rounds. The same few answers carry across all three, so rehearse those first.

1. Rehearse 1B2 aloud until it is boring, before Tuesday. It is the highest-ROI item in the pack, and 3C1 is the same objection in a shorter form.
2. Rehearse the three answer slots that F2 raises through 1C1, 1C2, 2B3 and 3C2. They are asked in three rounds, and the second follow-up is where a thin answer breaks.
3. Before Tuesday, also prepare 1D1 (the 90-second arc) and 1B3 (your reason for moving).
4. Before Thursday: 2A1, 2B1, 2B3, 2C1. Say each answer slot out loud once.
5. Before Monday: 3A1, 3A2, 3A3, 3B1. Read Larkfield's own published material yourself for 3B1, because this pack could not.

Everything else is insurance.

## The fit snapshot (shared across the loop)

The requirements are quoted from the role description in your message. It is a one-line description, not a full posting, so the rows below cover only what it states. It names no location, pay, schedule or credential, so the snapshot has no gate rows.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message; "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | medium | [grounded] | transferability | Your material carries a team of six at a payments company. It does not show two squads, eleven engineers or device-management work, and nothing is inspected behind it. Words at the quote's own scope: "Three of my nine years have been as a team lead of six." The plain acknowledgment your sentence gives: "I haven't managed managers." Answer slot: the role description's two squads and eleven engineers make a probe on the step up from six likely. If you have worked with more people than your own team of six, say how, in your own words; if not, say so plainly and stay with the team of six. The role description also names device-management services, and your material is silent on whether you have worked on anything like them. If you have, say what; if not, say so plainly and say how you would learn it, as a plan |
| F2 | "own delivery, hiring and growth for 11 engineers" — role description in your message (the delivery part) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The sentence carries a reliability quarter and a 60% figure, not delivery ownership as such, and nothing is inspected behind it. Words at its own scope: "I pushed a reliability quarter through against roadmap pressure." The word in your sentence is after, so the figure follows the quarter and is not credited to it. The figure raises four slots, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly |
| F3 | "own delivery, hiring and growth for 11 engineers" — role description in your message (the hiring part) | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | The sentence already speaks to hiring in role-relevant terms. Lead with it in its own terms: you run the loop for backend roles. It is a message line with nothing inspected behind it, so expect a probe on the number: what the "about 40" counts, how it was counted, and which interviews were yours |
| F4 | "own delivery, hiring and growth for 11 engineers" — role description in your message (the growth part) | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | low | [inferred] | discovery | The quote touches leading people without showing whether it reached growing them, and you have stated no absence. Answer slot: the role says growth for eleven engineers, so expect a probe on how you have helped people grow. If you have a case, say what happened and what part was yours, in your own words; if you do not, say so plainly and say how you would approach it with eleven people, as a plan |
| F5 | "partner with hardware and product on roadmap" — role description in your message (the product part) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Roadmap pressure appears in the sentence as something you pushed against. The sentence does not show a partnership with product. Words at its own scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: expect a probe on who that pressure came from and how you worked through it. Say who and how, in your own words; if the pressure was not from product, or it was not worked through in conversation, say so plainly and stay with the quarter |
| F6 | "partner with hardware and product on roadmap" — role description in your message (the hardware part) | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. The pack's observation: your sentence is about owning, the role says partnering, and your material is silent on working alongside a hardware team; 1B1 holds that as a slot |

## Round 1: Tuesday, Director of Engineering (hiring manager), 45 min

### Persona weights

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | Live problems on the squads' actual roadmap: a hardware date moves, a reliability call, your first thirty days | High. The hiring-manager prior is Case plus Skeptic, because a would-be boss is buying capability and checking gaps, and the role description is a roadmap-partnership role | Clarify, objective, options, risks; think aloud; challenge one premise respectfully |
| Skeptic (bank B) | Quiet, persistent probing of the step from F1 and the hardware gap in F6, and why you are moving | High. Same hiring-manager prior; the gaps in F1 and F6 are in your own message, so they will be found | Rehearse 1B2 until it is boring; hold then concede (see 1B2); calibrated candor |
| Data-Driven Prober (bank C) | Reads your account line by line; asks how the figure in F2 was counted | Medium. A Director reading closely will go to the one number you have given; no prior says Prober dominates here | Know what you can and cannot say about how the figure was counted; say plainly when you do not know |
| Conversational / Rapport Builder (bank D) | The opening "walk me through your journey" and a casual question about the domain | Medium. A 45-minute first conversation with your would-be boss opens this way; casual questions are still scored | A 90-second arc built from your own sentences; treat the domain question as scored |
| Pressure / Stress | Time-boxes you, questions your motives | Low. Not a hiring-manager prior; 1B2 carries its hold-then-concede rehearsal | Pause, restate, anchor in what you stated |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "Imagine hardware tells you on Monday that a device revision ships six weeks earlier than planned, and both squads' roadmaps assumed the old date. What do you ask first, and what do you do this week?" | CASE | [generic] | No claim about your past is needed. Structure aloud: clarify first (what changed, what is already committed to whom, what hardware actually needs on the new date); state the objective; set out two or three options with the cost of each; name who you would talk to this week and what you would not promise yet; end with the risk you would watch. Challenge one premise respectfully, for example whether the old date was ever firm | The JD's hardware partnership (F6) is the part of this role you have least to say about, so a live problem there is likely. CASE because it tests structure, not history; `[generic]` because the scenario is a pattern for the problem, not a fact about this team |
| 1A2 | "You take over two squads and a roadmap you didn't write. What do you do in the first thirty days?" | CASE | [generic] | No claim about your past is needed. Shape: listen before changing anything; learn the services and the domain; get a picture of delivery and a picture of each person; make one small commitment early; say what you would deliberately leave alone. Put learning the domain in as a step of the plan | F1 is where the role outruns your material, and a first-thirty-days question is how a Director probes it. CASE because it is a live problem with no history presupposed |
| 1A3 | "Product wants a feature quarter. The on-call load on a device-management service is climbing. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure the decision first, in your own terms: what the on-call load tells you, what waiting costs, what product gets in return, and who decides. Then one sentence from your own experience at its own scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: expect a probe on who that pressure came from and how you worked through it; say who and how, in your own words; if it was not worked through in conversation, or the pressure was not from product, say so plainly and stay with the quarter. If the figure comes up, use 1C1 | F5 is your nearest evidence for partnering with product on a roadmap, and this is the live version of it. CASE because the decision is the scored part; the quote is the only history the guidance leans on |
| 1B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Name it plainly and early. Words from your own sentence: "I haven't owned a hardware-adjacent roadmap." Then a plan, said as a plan: whom you would learn from first and what you would read, in your own words. Answer slot: the role says "partner with hardware and product on roadmap" and your sentence is about owning; if you have worked alongside a hardware team in any way, say how, in your own words; if you have not, say so plainly and stay with the plain acknowledgment. Do not pick a weakness that is not true in order to soften this one | F6 is the gap you have stated yourself, so the weakest-part question lands on it. JD because it scores a stated responsibility, asked as a Skeptic would |
| 1B2 | "You've led a team of six at a payments company. This role is two squads, eleven engineers and a hardware partnership. What is the biggest gap between the two?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers and never owned a hardware-adjacent roadmap." | The highest-ROI rehearsal in this pack. Hold only what the sentences carry: "Three of my nine years have been as a team lead of six." Concede specifically and in your own words: "I haven't managed managers" and "I haven't owned a hardware-adjacent roadmap." Rehearse three follow-up levels. (1) "Why would that transfer?" Return to the team of six at its scope; do not widen it. (2) "Give me an example of leading beyond your own team." Answer slot: if you have one, say what it was and what part was yours; if not, say so plainly and return to the team of six. (3) "What do you do in the first sixty days?" Give a plan, said as a plan. Never answer a gap by adding to the quote; the second follow-up is where that breaks | F1 and F6 are where the material is thinnest against the role, so this objection will arrive in some form. JD because it scores the stated responsibilities; the most follow-up levels and the exact concession wording are here because the objection is aimed where the quotes are thin |
| 1B3 | "Why leave payments for industrial IoT, and why now?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | The reason is yours, and nothing in your material gives one, so the pack supplies none. Give your actual reason in your own words, and keep it to something you could defend under a second question. Anything you say about Larkfield must be something you have actually read or been told by them; this pack could not research the company. If you do not yet know your reason, work it out before Tuesday | Motivation consistency is the Skeptic's standing probe, and a move out of an unrelated domain makes it near-certain. EXP because it tests whether your account of your own path holds together |
| 1C1 | "Your team's on-call burden dropped 60%. Walk me through how that number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say the sentence at its own scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through." The word is after; do not turn it into because. Answer slots, in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least, named before the interviewer names it; which part was yours. If you do not know how it was counted, say so plainly | F2's figure is the only number in your material, so it is the one a Prober goes to. EXP because it tests whether the number survives scrutiny; the weakest-assumption move turns a gotcha into credibility |
| 1C2 | "Tell me about the pressure on the roadmap that quarter." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Start from the sentence: you pushed a reliability quarter through against roadmap pressure. Answer slot: expect "who, specifically". If a person or group pushed back, say who and what you said, in your own words; if it was general pressure rather than a particular disagreement, or you cannot recall it, say so plainly and stay with the quarter | F5 is the sentence your partnership evidence rests on, so a closer reader follows it to the people involved. EXP because it checks what was actually yours |
| 1D1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year."; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc built only from your own sentences, in this order: nine years in engineering; three of them as a team lead of six; currently at a payments company; you run the hiring loop for backend roles; a reliability quarter you pushed through against roadmap pressure. Tell each in your own words at its scope. The last beat is why this role, and your own reason is the same slot as 1B3 | A first conversation with a would-be boss opens here, and F1, F2 and F3 are the sentences a Director will already have read. EXP because it checks that your account matches your material; casual in register, scored in fact |
| 1D2 | "What are you actually playing with in device management these days?" | JD | [generic] | Treat it as scored. Answer from what you have actually done or read: if you have read or tried something about device management, say what; if you have not started, say so plainly and name what you will read before Tuesday, as a plan you will actually carry out. Your material says nothing about the domain, so the pack supplies no content | The role description names device-management services, and the Conversational persona asks about the domain casually. JD because it scores the stated domain; `[generic]` because it is a pattern question and not a fact about this team |

### Reverse questions for Round 1

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "What would make the first six months a clear success in this role, and what would make you doubt it by month three?" | A would-be boss answers it with their real bar, and it shows you are working toward their definition of success |
| R1-2 | "Where do the hardware and software roadmaps collide hardest today, and who decides when they do?" | It goes straight at the part of the role you have least ownership of (F6) and asks how it really works |
| R1-3 | "How are the two squads' remits divided, and where does the seam give you the most trouble?" | It shows you are thinking about two squads as a system, not as two teams of six |
| R1-4 | "What does the on-call and reliability picture look like for these services right now?" | It links to the reliability story you can tell (F2) without asserting anything about this team |
| R1-5 | "How do you prefer to be kept informed, and how do you want disagreement to reach you?" | It tells your would-be boss you are already planning how to work with them |
| R1-6 | "What did you most hope the person in this seat would take off your plate?" | It invites the real motive for the hire, which no posting contains |

## Round 2: The Thursday after, panel of two staff engineers and a product manager, 60 min

### Persona weights

Names are unknown, so weights are by role. The panel prior is to blend the top two personas of each member's relationship.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (bank A) | "Where's the seam, what do you need from us, how do you handle credit" | High. Staff engineers and a product manager sit beside a manager; the peer prior is Peer Evaluator plus Prober | Reciprocity framing; offer seam principles instead of pretending to know the seam |
| Data-Driven Prober (bank B) | Technical depth on the reliability quarter, the hiring loop and its number | High. Staff engineers verify depth, and your two concrete items (F2, F3) are what they can probe | Know what you can and cannot say; say plainly when you were not close to the detail |
| Values / Behavioral (bank C) | A product manager asking for a disagreement or a "no" story | Medium. A cross-functional interviewer leans behavioral, but the recruiter named no values round for this session | Selection scaffolds with honest branches; a named stake, a moment you held, a relationship intact |
| Case / Strategist (bank D) | Live problems that need product and engineering to agree | Medium. The role is a roadmap-partnership role and a PM brings those problems | Clarify, structure, one premise challenged |
| Pressure | A staff engineer who pushes a second time | Low to medium. The bar-raiser prior is Prober plus Pressure; the second follow-up in 2B1 and 2B3 is where it shows | Pause, restate, hold the sentence, concede the specific |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2A1 | "Where is the seam between engineering and product here, and what happens when we disagree?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Propose seam principles instead of pretending to know the seam: who decides what, who decides how, how a disagreement is settled and who is told. Offer them as how you would work, not as a record. Include reciprocity: what you bring product, not only what you need. One sentence from your experience is available at its own scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if the pressure came from product, say how you settled it with them; if it did not, or it was not settled with them, say so plainly and leave the sentence out | F5 is the only evidence you have for working a roadmap against pressure, and the PM's seam question is the Peer persona's stem. CASE because it asks how you would handle a live collaboration problem |
| 2A2 | "What do you need from the staff engineers on this team, and what can they expect from you?" | JD | [generic] | Reciprocity: lead with what they can expect from you, as commitments you would keep from week one, then what you need. No claim about past dealings with staff engineers is made, because your material carries none. Keep each commitment to something you would actually do | The Peer persona prices what the hire costs and contributes to its own work. JD because it scores the partnership the role names; `[generic]` because it is a pattern question |
| 2A3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams and credit was shared or contested; it needs a named piece of the work, who else was involved, and what you did about credit. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard peer probe, and the role names no hardware or product credit rule, so the pack supplies no story. VAL because it scores behavior toward peers |
| 2B1 | "About 40 interviews last year. How many of those were yours, and how was that figure counted?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say the sentence at its own scope: "I run our hiring loop for backend roles." Answer slots, in your own words: what the "about 40" counts; how it was counted; which part was yours. If you do not know exactly, say so plainly | F3's number is a figure on your account, and staff engineers who interview will check it. EXP because it tests attribution and counting |
| 2B2 | "A staff engineer says the candidate you favor isn't strong enough. You disagree. What do you do?" | CASE | [generic] | No claim about your past is needed. Structure aloud: ask what evidence they saw; compare both views to the same bar; check whether the bar was agreed before the interview; decide who decides, and say so up front; concede when the evidence warrants it, and hold your view when it does not | Hiring is a stated part of the role (F3), and staff engineers are the people a manager's hiring decisions most often meet. CASE because it is a live disagreement, not a history question |
| 2B3 | "What was in that reliability quarter?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Staff engineers will go to the detail. Answer slot: describe the work in your own words, and which parts you did yourself and which others did; if you were not close to the technical detail, say so plainly, say who was, and describe your own part. Stay inside the sentence: a reliability quarter pushed through, after which the on-call burden dropped | F2 is the only technical story in your material, and the panel contains the people who can test it. EXP because the probe is how much of it was actually yours |
| 2C1 | "Tell me about a time you disagreed with a product manager and the working relationship held." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The nearest sentence you have is "I pushed a reliability quarter through against roadmap pressure." Answer slot: if that involved a disagreement with a product manager, tell it with a named stake, a moment you did not fold, and the relationship afterward; if it did not, or you cannot name such a time, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's partnership with product is the raising source, and F5 is your nearest evidence. VAL because it scores how you behave with a cross-functional peer |
| 2C2 | "How do you decide what to say no to?" | JD | [generic] | A principle question, so say how you decide in your own terms: what you check, who you tell, and how you leave the door open. No claim about your past is made. Keep it to two or three criteria you would apply the same way twice | A roadmap partner is asked this by the PM; the role description makes roadmap partnership a duty. JD because it scores the stated duty; `[generic]` because it is a pattern question |
| 2D1 | "A PM asks you to commit to a date for a feature that depends on a device revision hardware hasn't finalized. What do you say?" | CASE | [generic] | No claim about your past is needed. Clarify what is firm and what is not; say what you can commit to now and what you can commit to only once hardware confirms; give the PM a date for the next decision, not only the answer; name the risk and who you will tell. Challenge one premise respectfully | It combines the product and hardware halves of F5 and F6 into one decision. CASE because the reasoning is the score |
| 2D2 | "A device-management service pages on-call twice a night after a release. Staff engineers want a rewrite and product wants the next feature. What is your call?" | CASE | [generic] | No claim about your past is needed. Structure: what the pages show; what a stop costs and what a rewrite costs; what can be done short of either; who decides and how you tell the other side. Concede what you do not know and say what you would find out first | Reliability against roadmap is the one tension your material names (F2), and the panel contains both sides of it. CASE because it is a live conflict |

### Reverse questions for Round 2

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "What could a new manager do in their first month that would genuinely help your team?" | The reciprocity question for peers: it asks what you can give them, not only what you want |
| R2-2 | "What is the biggest source of unplanned work for the squads today?" | It tells staff engineers you are looking at their load, not just your own remit |
| R2-3 | "How do product and engineering settle a roadmap disagreement here, in practice?" | The PM answers with the real mechanism, and you learn the seam before you manage it |
| R2-4 | "How do staff engineers and the manager share technical direction on these services?" | It asks about the seam between you and the staff engineers directly, which is the one they care about |
| R2-5 | "What is the hardest decision the team has had to make about a device in the field?" | It invites a real story from the panel and shows interest in the domain you are new to (F1) |

## Round 3: The following Monday, VP Engineering, 30 min

### Persona weights

The recruiter's words are "values and leadership philosophy". That is a loop source naming a values-style round, so Values / Behavioral is guaranteed here. It displaces the skip-level prior, which would put Case / Strategist first.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (bank A) | "Tell me about a time", "what is your philosophy", "how do you hire" | High. The recruiter's own description of the round | Map a story only where a sentence of yours carries one; otherwise a selection scaffold ending in its honest branch; "we" for context, "I" for contribution |
| Conversational / Rapport (bank B) | "Why this role, why Larkfield", "what does good look like" | Medium. A 30-minute leadership conversation is largely conversational; casual questions are still scored | Answer concisely; keep reasons to ones you can defend |
| Pressure (bank C) | Time-boxed: "sixty seconds, why you", "how much of that was you" | Medium. The skip-level prior includes Pressure, and 30 minutes forces short answers | Pause, restate, hold the sentence through two follow-ups, concede the specific |
| Case / Strategist | A strategy-level question about engineering at Larkfield | Low. The skip-level prior favors it, but the recruiter's framing displaces it, and this pack has no strategy research to ground one; 3B1 stands in | Clarify, then structure |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3A1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The nearest sentence you have is "I pushed a reliability quarter through against roadmap pressure." Answer slot: if that meant telling someone senior something they did not want to hear, say who, what you said, and how it landed, in your own words; if it did not, or nothing like it comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Stem for the Values persona, and F2 is the only sentence of yours that sits near it. VAL because it scores whether the hard truth actually landed |
| 3A2 | "What is your philosophy on leading engineers?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year."; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | State two or three beliefs of your own, each in one sentence. After a belief, add something you did only if one of your two sentences genuinely fits it, at its own scope: "I run our hiring loop for backend roles", or "I pushed a reliability quarter through against roadmap pressure." Do not say what the work proves; let the VP draw the inference. If a belief has no example of yours, say so plainly and say how you would act on it | The recruiter's words, "leadership philosophy", raise it directly. VAL because it scores whether stated values show up in what you did; F2 and F3 are the only sentences available to illustrate |
| 3A3 | "Tell me about a time you helped someone on your team grow." | VAL | [inferred] | Selection scaffold: pick a time that has a named person, something you did, and where that person ended up; no story of yours is supplied, because your material carries none. If no such time comes to mind, say so plainly, then say how you would approach growth with eleven people, as a plan | The role says growth for eleven engineers, which F4 shows your material does not reach. `[inferred]` because the question is derived from the JD line and not from a sentence of yours. VAL because it scores behavior |
| 3A4 | "What do you look for when you hire?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Your criteria are yours; the pack supplies none. Start from the sentence at its own scope: "I run our hiring loop for backend roles." Then say what you look for and how you check for it, in your own words. Answer slot: expect a probe on a time the loop disagreed with you or got it wrong; if you have a case, tell it; if not, say so plainly | Hiring is a stated part of the role, and F3 is the strongest row in your material, so it should be easy to get right here. JD because it scores a stated responsibility |
| 3B1 | "Why this role, and why Larkfield?" | CO | [generic] | The pack could not research Larkfield, so it supplies nothing about the company. Use only what you have read or been told by them: the role description's own words (two squads, eleven engineers, device-management services, a partnership with hardware and product) are safe to refer to. Say what draws you in your own words; do not recite their website back | The VP asks the question in a values conversation, and company knowledge is what separates candidates. CO because it scores homework; `[generic]` because the pack has no company research |
| 3B2 | "What does good engineering management look like to you, and where are you still learning?" | VAL | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Your own definition first, in two or three sentences. For "still learning", your own sentence is the source: "I haven't managed managers" and "I haven't owned a hardware-adjacent roadmap." Say them plainly and say what you are doing about them, as a plan, or as something already under way only if it is | F1 and F6 are the stated gaps, and this is the gentlest form in which a VP asks about them. VAL because it scores self-awareness |
| 3C1 | "Sixty seconds: why you, rather than someone who has already managed managers?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers and never owned a hardware-adjacent roadmap." | Pause, then restate the question. Hold the sentence at its own scope: "Three of my nine years have been as a team lead of six." Concede plainly: "I haven't managed managers." Do not add a claim to close the gap; hold through two follow-ups by returning to the sentence | This is 1B2 time-boxed, and F1 is where it presses. JD because it scores the stated responsibility; the Pressure persona is how it is delivered |
| 3C2 | "That 60%: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The sentence says you pushed a reliability quarter through, and that the burden dropped after it. Answer slot: say which parts were yours and which were others', in your own words; if you were not the one who did parts of the work, say so plainly and say what you did. Hold the sentence through two follow-ups, and concede what you do not know | The Pressure stem aimed at F2's figure, the one number you have. EXP because it tests attribution |

### Reverse questions for Round 3

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What do you hope engineering leaders at Larkfield are known for?" | It invites the VP's own statement of values, which is what this round is about |
| R3-2 | "What is the hardest thing about moving from leading one team to leading across squads here?" | It names the step up in F1 directly, and shows you have already thought about it |
| R3-3 | "How does Larkfield develop managers at this level?" | It answers whether growth is supported, and shows you care about your own as well as your team's |
| R3-4 | "What does engineering most need to get right in the next year?" | It asks for the VP's real priority and gives you something to hang later answers on |
| R3-5 | "What would tell you in six months that you hired the right person?" | It asks for the bar directly and is hard to answer generically |

## Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| "Lead two squads building device-management services" | 1A2, 1B1, 1B2, 1D2, 3C1 |
| "own delivery, hiring and growth for 11 engineers": delivery | 1A3, 2D2, 3A1 |
| "own delivery, hiring and growth for 11 engineers": hiring | 2B1, 2B2, 3A4 |
| "own delivery, hiring and growth for 11 engineers": growth | 3A2, 3A3 |
| "partner with hardware and product on roadmap" | 1A1, 1A3, 2A1, 2C1, 2C2, 2D1 |
| Device-management domain (named in the role description) | 1D2, 3B1 |

## Prohibited claims

What this pack will not coach, each with its basis and the honest form. The list was built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led more than one team, or led two squads | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a team lead of six. Slots stay inside the team of six |
| Has managed managers | Negative you stated, F1 | The plain acknowledgment: "I haven't managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F6 | The plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." No slot |
| The reliability quarter caused the on-call burden to drop | Inflated form of F2 | F2's quote at its own scope: the burden dropped after you pushed the quarter through. The slot asks only what the figure counts and what part was yours |
| Ran or decided the whole hiring function, or made 40 hires | Inflated form of F3 | F3's quote at its own scope: you run the hiring loop for backend roles, and the "about 40" counts interviews. The slot asks only what it counts and which were yours |

## Sources

**Provided documents:** the role description, round descriptions, recruiter's description of the third round, and background in your message. The round descriptions are the loop source: they give three sessions, who runs each, and their length, so the loop is established and no archetype was used.

**Searches sent:** all three were refused, because search permission was not granted. No further search or fetch was attempted, and nothing in this pack comes from outside your message.

- `Larkfield Systems industrial IoT company values`: refused
- `Larkfield Systems interview process engineering manager`: refused
- `Larkfield Systems industrial IoT device management strategy news`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | The call was refused. It would have supplied Larkfield's published value names for a values cheat sheet for Round 3 and for CO and VAL questions grounded in them; 3B1 is `[generic]` instead |
| 2. `{company} interview process {role family}` | unavailable | The call was refused. It would have checked the loop against published sources; the pack's loop rests on your own description |
| 3. `{company} strategy` / recent news | unavailable | The call was refused. It would have grounded at least one CO or CASE question in current strategy; the CASE questions are `[generic]` instead |
| 4. `{interviewer name} {company}` | n/a | No interviewer name was given, so there was no query to form; the interviewer reads are absent |
| 5. representative `{role title}` JD | unavailable | The search permission was refused on the other targets, so no call was sent for this one. It would have added `[inferred]` requirements beyond the one-line role description |

## Upgrade menu

- The full job posting text → more requirements quoted in the fit snapshot, more JD-tagged questions, and the one-line description's rows checked against the real wording
- The recruiter's notes on the panel format, or any exercise or deliverable → graded-deliverable sections if one was declared, and per-member persona assignment for the panel
- The interviewers' names → interviewer reads from their public professional footprint, personalised persona weights and reverse questions tied to their own paths
- Larkfield's published values page, or pasted text of it → a values cheat sheet for Round 3 (the recruiter's words detect a values-style round) and VAL questions mapped to named values
- Search access, or a pasted strategy brief → a grounding brief and CO and CASE questions anchored in current strategy; a deeper research pass is also possible if you want it (up to 6 more searches and 2 more fetches, several more minutes)
- Your own answers to the answer slots in rows F1, F2, F4 and F5, given outside a drill → those rows regenerate on your own words, and the questions that draw on them are rewritten
- A `tuesday-dossier.md` from an earlier evaluation of this role, if you have one → verified evidence and any prohibited claims, which would sharpen the bank; none is needed for this pack
