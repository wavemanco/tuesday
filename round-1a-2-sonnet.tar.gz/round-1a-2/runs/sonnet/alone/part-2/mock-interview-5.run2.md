I've read the skill's reference files and am now running the first research searches on Kelverton Rail: values, interview process, strategy, the two panelists, and a representative JD.
Bash was declined, so I'll make the three cross-reference fixes with Edit instead.
Your prep pack is saved as `kelverton-rail_senior-partnerships-manager_interview_pack.md` in the working directory. I built it for a two-person panel (Deepa as hiring manager, Ross as commercial leader), using only your message and the recruiter's email as you quoted it. The web searches I tried (company values, strategy, interview process, both panelists, a sample JD) were all refused. That means no company or interviewer research went into it, and the research table in the pack shows each one as unavailable. I couldn't check the pack against the market report either, because you didn't paste it.

- **The objection to rehearse first:** C1 is "you haven't sold into rail and haven't carried a direct quota", asked by a panel where Ross will push on commercials. Both gaps are in your own words, so the pack coaches you to concede them first and then hold only what you said. Three levels of follow-up are written out.
- **The 15-minute POV:** section 4 gives three thesis options with a concession each, a way to differ from the report, a minute-by-minute timing and the operators close they asked for. It has more detail than I can fit here.
- **Your £4M figure:** B1 to B3 ask how it was counted, which assumption you'd defend least, and what counted as a partner. The pack has no answers because your message doesn't say how you got the number. If you can find the record behind the £4M before Tuesday, B1 to B3 get much stronger.
- **Four-hour schedule:** section 2 splits your prep across the weekend, with the POV first and everything else after the C1 and D2 concessions.

I can also run a live drill with Ross or Deepa. The pack suggests C1, then D3, the interruption mid-POV. I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. I can convert the pack to a Word document if you want one.

1. Can you paste the job description and your CV, or tell me to go without them? Either would turn the pack's questions from recruiter-word guesses into ones quoted against the posting and your own sentences.
2. Would you approve web search so I can run the standard research pass (up to 6 searches, 2 page fetches), or the deeper one (6 more searches, 2 more fetches, several more minutes)?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Kelverton Rail — Senior Partnerships Manager — second-round panel pack

**Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director), per the recruiter's email as you quoted it. 60 minutes: a 15-minute POV from you, then Q&A, where "Ross will push on commercials".

**Built on:** the recruiter's email as you quoted it, and your own summary of your background. No job description, no CV, no market-report text, and no web research (searches were refused in this session). Where the pack could not rest on a quote it says so.

## 1. How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only say what you actually did.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows the company's published values (no values-style round is detected for this panel, so no VAL bank) |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the role as described, gaps included |
| CO | Company and strategy knowledge, thinking at the company's altitude |
| CASE | A live problem from the role, reasoned out loud |

An **answer slot** is an instruction for the interview, not a question for me. Fill it with your own experience. Either branch is a good answer: if you did the thing, say how; if there was no such step, or it was not yours, say so plainly and go back to what your own words carry.

**The highest-ROI prep in this pack is C1**: the objection that you have not sold into rail and have not carried a direct quota, asked by a panel whose Commercial Director has been flagged as pushing on commercials. It is the one question that will be asked in some form. Rehearse it until it is boring.

## 2. Prep triage (about four hours, spread over the weekend)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | about 75 min | Build the 15-minute POV and say it aloud, timed. Write the operators close first, then work backwards | Section 4; A3 |
| 2 | about 45 min | Say the concession sentences in C1 and D2 aloud until they are flat and calm. Practise the three follow-up levels in C1 | C1, D2 |
| 3 | about 45 min | Write down what you do and do not know about how the roughly £4M and the 40 partners were counted. If you can look at the record behind them before Tuesday, do | B1, B2, B3 |
| 4 | about 30 min | Live drill with me: C1, then D3 (the interruption mid-POV) | C1, D3 |
| 5 | about 20 min | Set the 90-second journey arc and pick three reverse questions | E1; section 7 |
| 6 | about 25 min | One full uninterrupted run of the POV on the day before | Section 4 |

Saturday: items 1 and 2. Sunday: items 3 to 5, then item 6 on Monday if you can find the time. Everything else in this pack is insurance.

## 3. The fit snapshot

Requirements come from the recruiter's own words as you quoted them, since no JD was supplied. Evidence is your own sentences only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, as you quoted it | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company, not operator partnerships in rail, and the words stay at that scope: "In the last four years I ran the ISV channel at a payments company and took it from 6 partners to 40." The figure is yours to defend and is probed in B1 to B3. The POV itself is a view about the future, so it is built as hypotheses with concessions in section 4, never as past experience |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email, as you quoted it | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, and the words stay there: "In five years of transport consulting I did bus and light rail network planning, so I know the operator world from the other side." Answer slot: expect a probe on whether that carries to train operating companies. If you can name something from that work that carries, say what, in your own words; if nothing does, or you are not sure, say so plainly and stay with bus and light rail |
| F3 | "Ross will push on commercials" — recruiter's email, as you quoted it | "roughly £4M of influenced revenue" — your message; "never carried a direct quota, only influenced revenue" — your message | medium | [grounded] | transferability | Your material says influenced revenue and says no direct quota. Words you have a source for: "It was roughly £4M of influenced revenue, and I never carried a direct quota." Answer slot: expect a probe on the commercial terms themselves. If you had a hand in any terms with partners, say which and what your part was, in your own words; if you did not, say so plainly and stay with the influenced revenue |
| F4 | "they sell scheduling software to train operating companies" — your message (company context you gave, not a posted requirement) | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never sold into rail specifically." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

No row is a gate: nothing in the material states an eligibility, location, pay or schedule term.

## 4. Graded deliverable: the 15-minute POV

The recruiter's words, as you quoted them: "First 15 minutes we'd like you to present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it." The close they asked for: "Please land on what it means for the operators themselves." Both panellists will have read the same market report you did, so reciting it scores as homework; departing from it, with reasons, scores as judgement.

### 4.1 Grounded facts to build on

| Fact | Source | Provenance |
|---|---|---|
| 15 minutes, no slides, talk them through it, 18-month horizon, operator partnerships | Recruiter's email as you quoted it | [grounded] |
| The close must land on what it means for the operators themselves | Recruiter's email as you quoted it | [grounded] |
| Ross will push on commercials in the Q&A | Recruiter's email as you quoted it | [grounded] |
| F1 (row in section 3): "took it from 6 partners to 40, roughly £4M of influenced revenue" | Your message | [grounded] |
| F2 (row in section 3): "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Your message | [grounded] |
| F4 (row in section 3): "Never sold into rail specifically" | Your message | [grounded] |
| The strategy team's report exists and you have read it. Its contents are not in this pack | Your message | [grounded] |

### 4.2 Thesis options (pick two, hold the third for Q&A)

Each thesis is a hypothesis to argue, built from role-family patterns, not a fact about Kelverton or its operators. Say them as views you would test.

| # | Thesis | What it means for the operators (the requested close) | Mandatory concession | Provenance |
|---|---|---|---|---|
| T1 | Go deeper before wider: fewer operator partnerships, each run against an outcome the operator already tracks, rather than partner count as the headline | The operator gets one accountable counterpart and a shared scorecard, instead of another vendor relationship to manage | "I've never sold into rail specifically", so which outcome matters is something you would confirm with operators first, not assume | [generic] |
| T2 | Start from the operator's side of the problem: every partnership begins from a named operator pain, checked with operators before anything is pitched | The operator is asked what is wrong before it is told what is on offer | Your own sentence is bus and light rail (F2): "In five years of transport consulting I did bus and light rail network planning." The report and the operators outrank it on train operating companies | [generic] |
| T3 | Make the partner ecosystem carry integration work so an operator integrates once, if operators are carrying that burden today | Fewer integration projects landing on the operator's own team | The ISV channel was in payments (F1). Answer slot: if any of what you did growing that channel transfers, say which, in your own words; if you cannot name one, say you would treat it as untested. The premise that operators carry that burden is for the report or an operator to confirm, not for you to assert | [generic] |

### 4.3 Differentiation against the report

I have not seen the report, so I cannot name its items. You choose them, by these rules.

| Move | What to do | Why |
|---|---|---|
| Consensus item | Name one thing the report leans on, in one sentence, to show you read it. Do not walk through it | Proves grounding without handing the authors their own document back |
| Divergence | Give one thesis of your own (T1 or T2) and the reason it differs or adds to the report, from the operator's side | Departing from a shared source with reasons reads as judgement |
| Anti-pick | Name one thing you would decline or sequence last in the 18 months, with a reason from the operator's side and what would change your mind. One option, if you have no better: partner count as a headline goal. Say it as a view, never as a correction of their strategy | A role that includes saying no is shown by saying no once; this one is a pattern, so use it only if it is a view you hold |

If the report uses a framing that has since moved on, do not correct it in the room.

### 4.4 Timing

| Minutes | Beat | What it holds |
|---|---|---|
| 0:00 to 1:30 | Frame | One sentence on what you will argue; one plain concession: "I've never sold into rail specifically" (F4). Decide in advance whether to volunteer the quota limit here too (F3); volunteering it before Ross asks is the stronger order if you can say it flatly |
| 1:30 to 4:00 | Where things stand | One consensus item from the report; one thing you would want to know that the report leaves open |
| 4:00 to 9:00 | Two theses | About two and a half minutes each, each with its concession spoken, not skipped |
| 9:00 to 12:30 | The operators close | One kind of operator, from their desk, month one to month eighteen, as hypotheses. This is the requested landing, so rehearse it first |
| 12:30 to 14:00 | Commercials preview | How you would know it is working: two or three measures named without invented numbers, and what each is sensitive to. This answers Ross before he asks |
| 14:00 to 15:00 | Close | One sentence restating what it means for the operators. Stop and invite Q&A |

Time it aloud. If it runs over, cut a thesis, never the operators close.

## 5. Persona table

The loop rests on the recruiter's own words: one session, a panel of two, a 15-minute presentation then Q&A. Weights follow each panellist's relationship (Deepa is the future manager; Ross is a senior commercial leader), adjusted by the recruiter's one signal about Ross. No interviewer profile exists, so no public-footprint adjustment is applied.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Deepa and Ross pressing on the POV: clarifying, sequencing, what it means for operators | High. The first 15 minutes are a strategy presentation, and a hiring manager buying capability tends to test the plan live | Clarify, objective, approach, measures, risks; think aloud; challenge one premise respectfully (A1 to A5) |
| Data-Driven Prober | Ross on the £4M and the 40 partners, and on commercial shape | High. The recruiter named commercials for Ross, and your summary gives one headline figure that a prober reads line by line | Know what you can say about how each figure was counted, and say plainly where you do not know (B1 to B4) |
| Skeptic | The rail gap and the missing quota, from either panellist | High. Both gaps are stated in your own words and the role sells into rail | Rehearse the one objection until it is boring: concede first, hold only what your words carry, then a plan (C1 to C4) |
| Pressure / Stress | Ross interrupting mid-POV, time-boxing, asking how much was actually you | Medium. A Commercial Director who will push may also interrupt; no source says he will | Pause, restate, anchor in what you said, hold through two follow-ups, concede specifically (D1 to D3) |
| Conversational / Rapport | Deepa opening with "walk me through the journey", a friendly question on the report | Medium-low as a style, but near-certain as an opener in a 60-minute panel | A 90-second arc built only from your own sentences; treat the casual questions as scored (E1, E2) |
| Values / Behavioral | None detected | Low. The recruiter's email names no values round, so no bank. C4 is the nearest open prompt | Not applicable |
| Peer Evaluator | None detected | Low. Neither panellist is described as a peer, so no bank | Not applicable |

## 6. Question banks

### A. Case / Strategist (weight: highest, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have fifteen minutes. Where would you take our operator partnerships over the next eighteen months?" | CASE | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Build it from section 4, not from this cell. The only past you cite is the quotes at their own scope: "I ran the ISV channel at a payments company and took it from 6 partners to 40." Everything else is a hypothesis, said as one: "my view is", "I would test". Land on the operators | The recruiter's own words make this the deliverable; F1 is the only row that speaks to partnerships at all. CASE because it is a live plan for the role |
| A2 | "Before you give us the plan, what would you want to know about our operator partnerships?" | CASE | [generic] | Clarify before structuring. Ask two or three questions aloud, each a question and not an assumption: what an operator partnership is here (what the operator is to the company: a customer, a co-developer, both), what counts as working, and which operators matter most. Then state the working assumption you will proceed on, so the panel can correct it. The question makes no claim about your past, so the guidance makes none | Panels that score structure look for clarifying before answering; the recruiter's wording ("our operator partnerships") leaves the term undefined. CASE because it scores process, not content |
| A3 | "Take one operator. What does your plan mean for them, from their first month to their eighteenth?" | CASE | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | This is the requested close. Pick one kind of operator and speak from their desk: what changes for them, what they are asked to do, what they get, and when. For what you know of operators, say the sentence at its own scope: "In five years of transport consulting I did bus and light rail network planning, so I know the operator world from the other side." Answer slot: expect a probe on whether that carries to train operating companies. If you can name something from that work that carries, say what, in your own words; if nothing does, or you are not sure, say so plainly and stay with bus and light rail | F2 is the evidence, and the recruiter's last line makes this question certain. CASE because it is delivered as a walkthrough |
| A4 | "Pick one thing in our strategy team's report that you would not do. Why not?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | I have not seen the report, so choose from what you read. Criteria: it is something the report implies, you can give a reason from the operator's side, and you can say what would change your mind. Say it as a view to be tested, never as a correction of their strategy. Answer slot: if nothing in the report is something you would decline, say so plainly, and name what you would sequence last and why | The anti-pick from section 4.3, asked directly. CO because it tests homework depth; a shared source is the consensus answer, so departing from it with reasons is the differentiator |
| A5 | "Eighteen months in, how will we know it worked?" | CASE | [generic] | Name two or three measures in two groups: what operators would say has changed, and what the company would count. For each, say what it is sensitive to. Where a figure would go, name the measure, not a number you do not have. Expect Ross to ask how you would count it; say plainly where you would need to ask someone first. The question makes no claim about your past, so the guidance makes none | Bridges the POV to the commercial push the recruiter flagged for Ross. CASE because it is a live design problem; the measures are not drawn from F1 |

### B. Data-Driven Prober (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the roughly £4M of influenced revenue was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Hold at the quote's scope: "roughly £4M of influenced revenue." Answer slot, each part in your own words: how it was counted; what it is sensitive to; which part was yours. If you do not know how it was counted, say so plainly. Stay with the word influenced, as in your own sentence | A headline figure is the first thing a prober tests, and a Commercial Director will test it hardest. F1 and F3 hold the figure; EXP because it scores attribution |
| B2 | "Which assumption behind that £4M would you defend least?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Name the weakest assumption before they do. Nothing quoted states one, so this pack does not name it. Answer slot: say which assumption you would defend least, in your own words; if you do not know how the figure was built, say so plainly, and say what you would want to see in order to defend it | Converts a gotcha into a credibility gain. EXP because it tests whether you know your own number |
| B3 | "You said 40 partners. What counted as a partner?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | The count is attached to the noun it came from: partners. Answer slot: how a partner was counted. If there was a definition, say it in your own words; if there was none, say so plainly. Keep the quote's numbers as they are: 6 partners to 40 | F1's second figure is a count, and a count with no definition is a standard probe. EXP because it tests the denominator |
| B4 | "Sketch the commercial shape of a partnership with an operator. Who pays whom, for what, and what do we need to believe?" | CASE | [generic] "Never sold into rail specifically" | Clarify first, aloud: what the partnership is. Then set out what a commercial shape has to answer: what each side gives, what each side gets, over what period, and how either side can leave. Offer one shape as a hypothesis, name the assumption you would defend least, and say you would test it with the commercial team before committing. Concede in the quote's words: "I've never sold into rail specifically", so this is reasoning, not experience | Ross is flagged as pushing on commercials (F3). CASE because it is a live design problem; the concession rests on F4 |

### C. Skeptic (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't sold into rail and you haven't carried a direct quota. Why should we trust you with our operator relationships, and the commercials that come with them?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue"; "roughly £4M of influenced revenue"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | **Highest-ROI rehearsal.** Concede first, in your own words, flat and unhurried: "I've never sold into rail specifically, and I never carried a direct quota; it was influenced revenue." Hold only what the quotes carry: roughly £4M of influenced revenue, and bus and light rail network planning, each at its own scope. Then a plan, said as a plan: what you would do in your first ninety days to learn how operators work, your own steps. Follow-up 1, "bus and light rail is not train operating": concede the scope, say what carries if you can (answer slot from A3). Follow-up 2, "influenced is not earned": the figure is what it is and you have said what it is not; answer slot: if any part of your role was measured against a number, say which and how, in your own words; if none was, say so plainly and return to the influenced revenue. Follow-up 3, "then why not hire someone who has done it": give the three-sentence answer from D2. Volunteer the quota limit before Ross asks if you can | F3 and F4 are both stated gaps and the recruiter has flagged the commercial push, so this question will arrive in some form. JD because it scores whether the role can be done; deepest rehearsal because the hold must not extend past what your own words carry |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | Name the weakness your own words already state: "I've never sold into rail specifically" and "I never carried a direct quota". Then what you would do first, as a plan. Answer slot: if you see a weaker area than either of those, say it in your own words; if not, say so plainly. Do not invent one to look humble | A stock Skeptic stem; the answer is already in F3 and F4, so rehearse saying it without adding to it |
| C3 | "Why rail, and why now?" | EXP | [generic] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The reason is yours, and no text in front of this pack states it. Answer slot: give your actual reason for the move, in two or three sentences, in your own words. If part of it connects to your years in transport consulting, say how; if it does not, leave that out | Motivation consistency is the standard Skeptic test. EXP because it scores whether your story holds under cross-examination |
| C4 | "Tell me about a time an operator or customer was sceptical of a vendor and you changed their mind." | EXP | [generic] | Selection scaffold, since none of your quoted sentences carries this story: pick a time with a named stake, something you did that was yours, and a relationship still intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The recruiter's close on operators makes a sceptical-operator probe likely. EXP because it scores a real instance; a scaffold because nothing quoted states one |

### D. Pressure / Stress (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How much of the move from 6 partners to 40 was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Pause, restate the question, then hold at the quote's scope through two follow-ups: "I ran the ISV channel and took it from 6 partners to 40." Answer slot: say which parts were yours and which were shared or someone else's, in your own words; if you are not sure where one part sits, say so plainly rather than rounding up. Concede specifically, never on the core | The standard attribution stem. F1 is where it lands; EXP because it scores precision about your own share |
| D2 | "Sixty seconds: why you over a candidate who has sold into rail?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue"; "took it from 6 partners to 40, roughly £4M of influenced revenue"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Three sentences, one beat each. Position, from the quotes only: you took the ISV channel from 6 partners to 40, and you did bus and light rail network planning. Concession: "I've never sold into rail specifically." Plan: what you would do first. Do not argue the other candidate is weaker. Hold through two follow-ups by returning to the same three sentences | Time-boxed comparison is the Pressure stem; F4 is the concession. JD because it scores fit against the role |
| D3 | "Stop there. Operators have heard this from every vendor. What is different about your plan?" | CASE | [generic] | An interruption mid-POV. Pause, restate the objection in your own words, then answer from the thesis you actually proposed (T1 or T2 in section 4), not a new one. Hold through a second push; concede specifically what you cannot know before talking to operators. Do not defend with experience your quotes do not carry. The question makes no claim about your past, so the guidance makes none | Rehearses holding a position under interruption inside the deliverable. CASE because it is a live problem on your own plan |

### E. Conversational / Rapport (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | A 90-second arc in your own sentences, in the order you gave them: the transport consulting years, then the partnerships years and the ISV channel, then 6 partners to 40. Say them at their own scope. Answer slot: if a step between the two is part of your story, say it in your own words; if there was none, leave it out. Then your actual reason for this role, in your own words, ending on operators because that is where the POV begins | An opener that is still scored. F1 and F2 give the beats; EXP because it scores whether your account matches your claims |
| E2 | "You've read our strategy team's report. What stood out?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | One point you agree with and one question it left you with, a sentence each. Do not recite its contents back to its authors. Choose the point you can tie to operators. Answer slot: if you disagree with any part, say which and why, in your own words; if you do not, say so | A casual question on the homework, scored. CO because it tests whether you can discuss the company's own analysis at its altitude |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1: POV on operator partnerships over 18 months | A1, A2, A4, A5, D3, E2, and section 4 |
| F2: land on what it means for the operators | A3, C4, E1 |
| F3: commercials | A5, B1, B2, B3, B4, C1, D1 |
| F4: selling into rail (company context) | B4, C1, C2, C3, D2 |
| JD requirements | — none, and why: no JD was supplied, so there is no JD scoring sheet to cover; the upgrade menu says what one would add |

## 7. Reverse questions

Interviewer profiles were not available, so none is tied to a panellist's own path.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would you want this role to have changed for operators by month eighteen, and who decides if it has?" | Puts the operators and the measure of success on the table, which is the line the recruiter asked you to land on |
| R2 | "Ross, where does the line fall between partnerships and your commercial team when an operator is involved in both?" | Shows you are thinking about the seam your Commercial Director owns, and gives you information you need before accepting |
| R3 | "Which of the report's recommendations has the company already started acting on, and which is still open?" | Turns the report from a thing you recited into a live conversation, and shows you read it for what is open |
| R4 | "What would an operator say today is the hardest part of working with Kelverton?" | Operator-side, and a candid answer tells you what the role inherits |
| R5 | "What do you most want me to have learned about the operator world by day ninety?" | Frames the ramp the concession in C1 promises, and invites the panel to set your first-quarter priorities |
| R6 | "Deepa, how do you like to work with someone in their first quarter?" | Aimed at your future manager; it is cheap, un-researchable, and shapes how you start |

## 8. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a revenue quota, or was measured against one | Negative you stated, F3 | The plain acknowledgment F3 gives: "I never carried a direct quota; it was influenced revenue." C1's slot asks only whether any part of your role was measured against a number, and allows that none was |
| Sold into rail | Negative you stated, F4 | The plain acknowledgment F4 gives: "I've never sold into rail specifically." No slot |
| Closed, booked or personally sourced the roughly £4M | Inflated form of F1 and F3 | F1's quote at its own scope: "roughly £4M of influenced revenue." The limit is the pack's observation, not words for you: your material says influenced and does not say how it was counted. B1 asks only how it was counted and which part was yours |
| Worked inside, or sold to, train operating companies, or knows them from the inside | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says bus and light rail network planning and does not establish train operating companies. A3's slot asks only what from that work carries |
| Personally recruited, signed or managed all 40 partners | Inflated form of F1 | F1's quote at its own scope: "took it from 6 partners to 40." The limit is the pack's observation: your material does not say who recruited or signed which partners. D1's slot asks which parts were yours |

## 9. Sources

**Provided documents:** your message in this session, including the recruiter's email as you quoted it. The market report is named in your message but its text was not pasted, so it was not read. No dossier was present.

**Searches sent (all refused, none returned anything):**

- `Kelverton Rail values` — refused
- `Kelverton Rail interview process partnerships manager` — refused
- `Kelverton Rail strategy news scheduling software train operating companies` — refused
- `Deepa VP Partnerships Kelverton Rail` — refused
- `Ross Commercial Director Kelverton Rail` — refused
- `Senior Partnerships Manager rail technology job description train operating companies` — refused

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | The call was refused. Would have moved a values cheat sheet; none is built, and no values-style round is detected anyway, since the recruiter's email names none |
| 2. `Kelverton Rail interview process partnerships manager` | unavailable | The call was refused. The loop rests on the recruiter's own words, which establish this one session; a documented loop would have checked the persona weights |
| 3. `Kelverton Rail strategy` or recent news | unavailable | The call was refused. Would have fed a grounding brief and a CO question grounded in current priorities; A4, A5 and E2 are built on your reading of the report instead |
| 4. `Deepa` and `Ross` with `Kelverton Rail` | unavailable | Both calls were refused. Would have fed an interviewer read and a reverse question tied to a panellist's path; both are absent |
| 5. Representative `Senior Partnerships Manager` JD | unavailable | The call was refused. Would have supplied inferred JD requirements for the fit snapshot; requirements come from the recruiter's words only |

## 10. Upgrade menu

- The role's job description text → the fit snapshot would quote the posting's own requirements instead of the recruiter's words alone, and every JD requirement would get a question in the coverage table
- Your CV → evidence cells beyond your message summary, and story-mapped answers in place of scaffolds where a CV sentence carries the story (C4 first)
- The record behind the roughly £4M and the 40 partners (the partner-attributed revenue report or CRM export it came from) → F1 and F3 move from medium toward high, and B1 to B3 become story-mapped on how it was counted
- The market report's text → a grounding brief, A4 and E2 tied to named items, and section 4.3's consensus, divergence and anti-pick named instead of selected
- Deepa's and Ross's public profiles, or web search allowed in this session → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to a panellist's own path
- A tuesday-dossier.md from an earlier session, if you have one → confirmed evidence and a named objection in place of this pack's inferred one
