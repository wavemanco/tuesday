I'll read the reference files the skill requires before writing anything.
I've written the pack. I'm fixing one wrong cross-reference in the upgrade menu, then I'll give you the summary.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/alone/part-2/rooms/case-4-denied-f90e5734/quartzline_product-manager-platform-apis_interview_pack.md`. I built it for one 45-minute hiring-manager conversation, using your dossier for the requirements and your confirmed evidence.

- **Research didn't run.** My three Quartzline searches (values, interview process, strategy) were refused, so there are no Quartzline-specific sections and no company-strategy questions. The case questions are generic or inferred from the JD lines in your dossier.
- **Highest-ROI prep is A1.** It's the underwriter's objection: "never held the PM title or owned a roadmap — why you over a PM with three years?" The guidance concedes first in sourced words, names the limit before they ask, and then gives three follow-up levels.
- **R2 may be a bigger gap than the dossier shows.** "Shipped API or platform products" is a must-have, but the dossier doesn't list it as a weak area. Your evidence is leading client integrations of the vendor's REST APIs, which isn't the same as shipping an API product. I graded it as a transferability gap and wrote A3 with an answer slot for you to fill in your own words.
- **Pack contents.** It has 18 questions across five interviewer styles, a requirement-coverage table, six reverse questions (including both of the dossier's employer questions), and a list of claims the pack won't coach.

I can run a live drill, playing the Skeptic on A1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

- Round: one 45-minute conversation with the hiring manager, on Thursday (your words)
- Interviewer: not named; relationship is hiring manager
- Built on: your round description, and the dossier you carried in (`tuesday-dossier.md`, decision `conditional_go`). Quartzline-specific research did not run (see Sources), so company-level material is absent rather than guessed

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. The guidance is scaffolding for a spoken answer, not a script. Every sentence in it about your past is one you gave, quoted in the Provenance column, or an answer slot you fill from your own experience. Where a slot's second branch applies, say so plainly: it is a limit, not a confession.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values. None in this pack: no values page was read and no values-style round is detected |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | The listed requirements and responsibilities, gaps included |
| CO | Company and strategy knowledge. None in this pack: the research that feeds it did not run |
| CASE | A live problem set in the role, scored on structure and reasoning |

The single highest-ROI rehearsal is A1. The underwriter named that objection, and this pack gives it the deepest follow-up ladder.

## Fit snapshot

Requirements are the dossier's `role_profile` lines. "dossier R1" and the like name the verified-evidence entry mapped to that requirement.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD via dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier R1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier R1 | low | [grounded] | transferability | The underwriter's strategy is bridge, with the limit named: this is adjacent integration leadership, never product management experience. Your material carries integration leadership and quarterly input to product, not a product management role. Words at the quotes' own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live," and "I ran quarterly roadmap-input sessions that fed client evidence to product." The title is sourced by `prohibited_claims: "Having held a product manager title or role"`, which gives the plain acknowledgment "I haven't held a product manager title." The second quote is medium confidence: confirmed, limited inspectable proof, so expect a probe |
| F2 | "Own the roadmap for the partner-facing API platform" — JD via dossier role_profile responsibilities, and the R1 sub-claim in the handoff | none given | none | [grounded] | capability | The underwriter's strategy is acknowledge_gap, and it is binding: no bridge and no slot. The words are sourced by the `acknowledge_gap` area of `uncertain_or_weak_areas` and by `prohibited_claims: "Having owned a product roadmap"`: "I haven't owned a product roadmap." Then a ramp plan, said as a plan and never as a past: what you would learn first, from whom, and how you would check it. Nothing is added to make the gap feel smaller |
| F3 | "Shipped API or platform products" — JD via dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier R2 | low | [inferred] | transferability | The dossier lists this must-have among its high-priority requirements but not among its weak areas, so this grading is the pack's own reading of the quote. Your material says integrations of the vendor's REST APIs taken through go-live, not an API product you shipped, and the words stay at that scope. Answer slot: the JD's wording makes a probe on what you shipped likely. If you shipped anything on the API's own side, something other clients or teams built on, say what it was and which part was yours; if everything was on the client-integration side, or you shipped no product, say so plainly and stay with the integrations. Say which organisation's API it was and which side of it you worked on |
| F4 | "Technical fluency: API docs, schemas" — JD via dossier role_profile R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier R3 | medium | [inferred] | discovery | The quote shows REST API integrations with architecture as one stage; it does not show API docs or schemas. Answer slot: the JD names both, so expect a probe on them. If you read, wrote or reviewed API docs or schemas in those integrations, say which and what you did with them; if you did not, say so plainly and stay with the integrations as quoted. The playbook is not API documentation, and the pack does not call it that |
| F5 | "Stakeholder management across engineering, sales, customers" — JD via dossier role_profile R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier R4; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier R4 | medium | [inferred] | discovery | The quotes reach clients and product; they do not show engineering or sales. Answer slot: if you worked with engineering or with sales in those integrations, say with whom, on what, and what part was yours; if you did not, say so plainly and stay with clients and product |
| F6 | "Agile delivery experience" — JD via dossier role_profile R5, preferred | none given | low | [grounded] | discovery | The underwriter's strategy is clarify. No verified entry speaks to agile delivery itself, so there is nothing to quote. Answer slot: if you have worked in an agile delivery process, say how it ran, in your own words; if you never worked that way, say so plainly. Then the question back: how do the squads define agile delivery, so you answer against their definition |

## Persona table

| Persona | How it shows up | Weight and reasoning | Basis | Counter-strategy |
|---|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the title and roadmap gap, and of why now | Highest, 5 questions. The hiring-manager prior pairs Skeptic with Case; the underwriter named a specific objection aimed at you, which lifts this one | [generic] prior, adjusted by the dossier's `likely_interviewer_objections` | Rehearse the A1 objection until it is boring: concede in sourced words, name the limit before it is asked, hold your quotes through two follow-ups |
| B. Case / Strategist | Live problems from the role: discovery, adoption metrics, two-squad sequencing, schema changes | Highest, 5 questions. Hiring-manager prior; the JD's responsibilities are the problem set. All five are `[generic]` or `[inferred]` because the strategy research did not run | [generic] prior | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise politely. Ask who decides before claiming any decision right |
| C. Data-Driven Prober | Goes line by line through your three confirmed claims, asking how the figure was counted | Medium, 3 questions. The 30+ figure and the medium-confidence quarterly sessions are what a prober reaches for | [generic] prior, adjusted by the dossier's confidence bands | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know. Volunteer the limit on the sessions before it is extracted |
| D. Conversational | The friendly arc question and the casual API chat | Medium, 3 questions. You described a conversation, which makes a rapport register likely; casual questions are still scored | [generic] prior | A 90-second arc built only from your three quotes, with your own reason for the move as its close |
| E. Pressure | Interrupts, time-boxes, asks how much was actually you | Low, 2 questions. The hiring-manager prior does not lean here, but the A1 objection can arrive time-boxed | [generic] prior | Pause, restate, hold the quoted position through two follow-ups, concede specifically |

No values-style round is detected: your own description establishes one conversation, and no loop source names a values round. No interviewer information exists, so no interviewer-signal adjustment was made.

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | The underwriter named this objection; it is the highest-ROI rehearsal in the pack. Move 1, concede first and plainly, in sourced words: "I haven't held a product manager title, and I haven't owned a product roadmap" (`prohibited_claims` and the `acknowledge_gap` area). Move 2, name the limit before they ask: what follows is adjacent work, not product management. Move 3, the quotes at their own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live," and "I ran quarterly roadmap-input sessions that fed client evidence to product." Move 4, a ramp plan said as a plan: what you would learn first and from whom. Follow-up 1, "A PM with three years has done the job — what do you bring that they don't?": return to the quotes and describe them; let the interviewer draw the inference, and do not assert what the work proves. Follow-up 2, "So you're asking us to take a risk?": hold that the adjacent work is real at the scope stated, and concede specifically that years in the seat are not in your material. Follow-up 3, "What would make you fail in this seat?": name the roadmap gap and the plan again, in different words. Never claim the title, a roadmap or squad prioritization (section 13) | F1 and F2 are the rows this objection presses on, and the underwriter derived it from evidence you confirmed. JD because it scores the must-have requirement, with the gap itself as the subject |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] | Say the weakest part plainly. On roadmap ownership the words are sourced: "I haven't owned a product roadmap" (`acknowledge_gap` area of `uncertain_or_weak_areas`; `prohibited_claims`), followed by the ramp plan as a plan. Do not pre-concede agile delivery: your material does not establish an absence there, so ask how they define it, as in A4. Candor about a named gap, with a plan, is the whole answer | F2 is the plainest gap and F6 the open one; the question tests honest self-assessment, which is why it types as JD rather than EXP |
| A3 | "The role asks for shipped API or platform products — what is your closest experience to that?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold only what the quote carries: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Answer slot: if you shipped anything on the API's own side, something other clients or teams built on, say what it was and which part was yours, in your own words; if everything was on the client-integration side, or you shipped no product, say so plainly and stay with the integrations. Say which organisation's API it was and which side of it you worked on, since the probe is likely to land there | F3 is a must-have the dossier did not flag, so this is the second place a skeptic can press. JD because it scores a stated requirement; `[inferred]` because the row's grading is the pack's reading |
| A4 | "Tell me about a time you worked in an agile delivery process." | JD | [grounded] | An open prompt from the JD's "Agile delivery experience". Your verified material has no sentence on it, so nothing is quoted. Answer slot: if you have worked in an agile delivery process, say how it ran and what your part was, in your own words; if you never worked that way, say so plainly. Then the clarifying move: "Before I answer, how do your squads define agile delivery in practice, so I can answer against that?" | F6 is a clarify row: the evidence may exist and was never established. The question is asked casually and scored anyway; JD because the requirement is stated |
| A5 | "Why move from integration work into product management, and why now?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Your reason is yours to give and the pack will not write it. Answer slot: give your actual reason, in your own words. Anchor it to what you did at its own scope: "I ran quarterly roadmap-input sessions that fed client evidence to product." Describe that work and let the interviewer draw the connection. Keep it a reason for the move, not a claim to already being in the role | F1 is the transition this question probes; EXP because it tests whether your motivation story matches your confirmed work |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch how you would run discovery with integration partners for the API platform — what do you need to know first?" | CASE | [generic] | Say the structure aloud first. Clarify: who the partners are, which decisions discovery has to feed, what is already known. Then objective, how you would segment partners, approach, what you would measure, risks. Challenge one premise politely, such as how discovery sits alongside the squads' own partner contact. The case asks nothing about your past, so the guidance makes no claim about it | The JD's responsibility "Run discovery with integration partners" is the problem set; CASE because it is a live problem, `[generic]` because it is a pattern for the problem and not a fact about this team |
| B2 | "How would you define and track adoption for a partner-facing API platform, starting from whatever baseline exists?" | CASE | [generic] | Clarify what counts as adopted before measuring anything: options to weigh aloud are a partner starting an integration, reaching a first live call, and sustaining use. These are options, not facts about Quartzline. If no baseline exists, make establishing one the first step, and say what you would ask for. Name the assumption in your own metric you would defend least before the interviewer does, and ask how adoption is measured today (reverse question 2) | The JD's responsibility "Define and track adoption metrics" is the source; the dossier lists the current baseline as unknown. CASE with the metric weakest-assumption move built in |
| B3 | "Both squads want the first quarter for their own work. How do you decide what the platform does first, and who has the final say?" | CASE | [generic] | Do not claim a decision right you have not had. Say the principles you would propose: what evidence you would gather, what criteria you would make visible, how a disagreement is surfaced. Then ask how decisions are split today (reverse question 1). The case asks about a hypothetical, so the guidance makes no claim about your past | The JD's "two engineering squads" and the dossier's open authority risk make this likely; the question probes the area where roadmap and prioritization claims are prohibited, so the answer stays in principles |
| B4 | "A partner asks you to add a field to an API response and rename another. What do you need to know before you say yes?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer the case on its merits: who consumes the fields, what breaks for existing partners, how the docs and schema would change, how you would tell partners. If you tie it to your work, use the quote at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Answer slot: the JD names API docs and schemas, so if you read, wrote or reviewed either in those integrations, say what you did; if you did not, say so plainly and stay with the integrations as quoted | F4 is a discovery row, and a live schema problem is the quickest way for a hiring manager to test it. JD because it scores the technical-fluency requirement, with CASE delivery |
| B5 | "Sales has promised a partner a capability that engineering says is not feasible this quarter. What do you do?" | JD | [generic] | Clarify the facts first: what exactly was promised, what is feasible, what the partner actually needs. Then options, who must be in the room, and how you would communicate back to each of the three parties. The case asks about a hypothetical, so the guidance makes no claim about your past | F5 asks about engineering, sales and customers together, and this case puts all three in one problem. JD because it scores that requirement, with CASE delivery |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say you led 30+ client integrations of the vendor's REST APIs — how was that number counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The number stays attached to its noun: 30+ client integrations. Answer slots, each in your own words: how it was counted; what it is sensitive to; which assumption behind it you would defend least; which part was yours. "I don't know how it was counted" is an honest branch. Do not supply a method for the interviewer | F1, F3, F4 and F5 all lean on this one figure, which makes it the likeliest defend-the-number target |
| C2 | "Walk me through the integration playbook you wrote." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Beats the quote carries: you wrote it, and your team uses it. Say that in your own words, at that scope. The dossier records it as inspectable, so offer to walk through it end to end. Answer slot: what is in it and how you decided what went in, in your own words; if parts were written by others or inherited, say so plainly | The playbook is the pack's best inspectable evidence; EXP because it tests attribution of authorship. The row it supports is the integration work behind F1 |
| C3 | "Walk me through how the quarterly roadmap-input sessions worked." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Medium confidence: confirmed, limited inspectable proof, so volunteer the limit before it is extracted. Beats the quote carries: you ran them, they were quarterly, and they fed client evidence to product. Answer slot: if there is an artifact from the sessions you can offer to share, say so; if there is none, say so plainly. If you know what happened to the evidence after it reached product, say what; if you do not know, or nothing came of it, say so plainly and stay with the sessions | F1 and F5 both draw on this quote and it is the thinnest of the three. The JD's stakeholder requirement raises the probe on what happened next |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, each at its quote's scope: the integrations you led, the playbook you wrote, the quarterly sessions you ran. The quotes carry no dates, so the order is yours to choose. Close with your actual reason for this role (A5). Do not describe any of it as product management | F1 holds all three beats; EXP because the arc is a claims check in a friendly register |
| D2 | "What are you actually working on with APIs these days?" | EXP | [generic] | Pick something real that you are working on now: it needs a specific thing, your part in it, and something you are still working out. If nothing comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would find out. Do not invent a current project | The casual register is still scored, and the JD's technical-fluency line makes API chat likely; no raising source supplies a current project, so this is a selection scaffold |
| D3 | "Tell me about a partner or client whose feedback changed how you worked." | EXP | [generic] | Pick one real instance: it needs the partner or client, what they said, and what changed on your side. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle that feedback. Do not supply an event you did not have | The JD's partner discovery responsibility and F5's customers raise the theme; no quote carries a feedback story, so this is a scaffold, not a story map |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM with three years in the seat?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A1 compressed and interrupted. Three beats and no padding: concede ("I haven't held a product manager title" — `prohibited_claims`), the first quote, the second quote. If cut off, stop and restate the concession. Hold through two follow-ups by returning to the quotes, never by adding to them | F1 is the same objection delivered under time pressure; the compression is the rehearsal |
| E2 | "How much of those 30-plus integrations was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the position the quote carries: you led them, through the stages it lists. Answer slot: if some were co-led, handed off or finished by others, say which and what your part was; if all were yours end to end, say so plainly. Concede specifically where you do not know a detail, and never fold on the core claim to restore harmony | F1's lead claim is the one an attribution probe tests; EXP because it scores precise attribution under pressure |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| R1: 3+ years product management experience | A1, A2, A5, E1 |
| R1 sub-claim: roadmap and prioritization authority | A1, A2, B3 |
| R2: Shipped API or platform products | A3, C1 |
| R3: Technical fluency: API docs, schemas | B4 |
| R4: Stakeholder management across engineering, sales, customers | B5, C3, D3 |
| R5: Agile delivery experience | A4 |
| Responsibility: Run discovery with integration partners | B1, D3 |
| Responsibility: Write specs and drive delivery with two engineering squads | B3, B4 |
| Responsibility: Define and track adoption metrics | B2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier records decision authority versus the two squad leads as asserted but not evidenced. It reads as diligence, and the answer tells you what you would be accepting |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption metrics are named as a responsibility with no baseline stated. The answer sets what a good first quarter looks like and pairs with B2 |
| 3 | "When a PM and a squad lead see sequencing differently, what is the path to a decision?" | A second angle on the authority risk that asks for a process rather than a rule, which tends to draw out a real example |
| 4 | "How does evidence from partner integrations reach product today, and who owns that loop?" | It connects to F1's quarterly-sessions quote, inviting you to speak to your own work at its scope while you learn how the loop runs now |
| 5 | "How do the two squads run delivery today — what does a normal cycle look like?" | It is the confirming question A4 leaves open: F6 is a discovery row, and this gets their definition before you answer against it |
| 6 | "What would the first 90 days need to show for you to call this hire a good one?" | It surfaces the criteria behind A1's objection, so a later follow-up can be answered against them |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims`, and the F1 bridge limit | F1's two quotes at their own scope, plus the plain acknowledgment `prohibited_claims` sources: "I haven't held a product manager title." |
| Having owned a product roadmap | Dossier `prohibited_claims`, and the `acknowledge_gap` area of `uncertain_or_weak_areas` | The plain acknowledgment: "I haven't owned a product roadmap," then a ramp plan said as a plan. No bridge and no slot |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims`, and the `acknowledge_gap` area, which names prioritization authority with roadmap ownership | The plain acknowledgment `prohibited_claims` sources: "I haven't set prioritization for an engineering squad." No bridge and no slot |
| Shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: the material says integrations of the vendor's REST APIs, not a shipped product. A3's slot stays inside the integrations |
| Ran product discovery with partners | Inflated form of F1 and F5 | The two quotes at their own scope. The material says scoping and requirements within client integrations, and client evidence fed to product, and the pack does not call either discovery. B1 asks nothing about your past |

## Sources

- Provided: `tuesday-dossier.md`, pasted in the conversation. Its envelope is version 1.1, which this skill reads. It supplied `handoff_to_mock_interview` and `role_profile`, and `decision` as context only. `evidence_map`, `risk_register` and `evidence_state` were not in the pasted text, so the rows above rest on `verified_candidate_evidence` and `uncertain_or_weak_areas` rather than a per-requirement map. The dossier is dated 2026-08-14; if the posting has changed since, the requirement rows follow the dossier's text and not the live posting.
- Your own words: "a 45-minute conversation with the hiring manager", which fixes the round type and the relationship.
- Searches sent, each refused (the host did not grant search permission): `Quartzline company values`; `Quartzline interview process product manager`; `Quartzline API platform strategy news`. No pages were fetched.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Would have fed a values cheat sheet and VAL questions. None are in this pack |
| 2. `Quartzline interview process product manager` | unavailable | Would have documented the loop. Persona weights follow your own description of one hiring-manager conversation instead |
| 3. `Quartzline strategy` or recent news | unavailable | Would have fed CO questions and a grounding brief. The CASE questions are `[generic]` or `[inferred]` as a result |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Quartzline's values page or a short strategy note, pasted → a grounding brief, CO questions and, if a values round turns out to exist, a values cheat sheet; or grant search access and I rerun the three refused searches
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → role-family loop reports, recent org context and a strategy brief for the CASE bank
- The full JD text → catches any mid-list requirement the dossier's five lines did not carry
- The hiring manager's name → a reading of their public career path, a tailored reverse question and adjusted persona weights
- The recruiter's guidance for the 45 minutes, usually one email → focus areas and any pre-declared deliverable
- How much prep time you have before Thursday → a prioritized schedule sized to it
- The integration playbook itself, and an agenda or notes from one quarterly roadmap-input session → the artifacts that would let the playbook's quote and the sessions' quote be inspected, which is what raises a medium band
- Your own answers to the slots in F3, F4, F5 and F6, stated outside a drill → those rows regenerate from your words, and A3, A4 and B4 get story maps in place of slots
