I'll read the reference files the skill points to before building the pack.
The pack is saved, and I'm now presenting it.

Your prep pack is saved as `atlas-freight_operations-manager_interview_pack.md`. It has 20 questions across six interviewer styles, plus a fit snapshot of the JD against your own words and reverse questions. I built it for an unknown round type with flat persona weights. All three web searches on Atlas Freight were refused, so nothing in it about the company goes beyond your JD, and there are no company-strategy or values questions.

**Highest-ROI prep:** A1, the jump from 3 supervisors to 12 across four sites. Rehearse it aloud with all three follow-ups.

**Gaps the pack found in the JD match:**
- **Scale (F1, F4):** the JD is four sites and 12 supervisors. Your material shows one role over 3 supervisors.
- **Power BI (F6):** you've said you've never used it, so the pack coaches a plain acknowledgment and a plan, not a bridge.
- **Years of leadership (F7):** the JD asks for 5+. Your 7 years are in ops, and your material doesn't say how many of them were spent leading people.
- **Metrics (F2, F3):** the 40% mis-pick cut and the surge plan don't show what was tracked for on-time performance or cost. Several answers are slots for you to fill from your real experience.

Say the word and I'll play the Skeptic on A1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you know whether this is a recruiter screen, a hiring-manager round or a panel, and did the recruiter give you any focus areas or ask you to bring anything? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer and relationship: unknown. You said you don't know who is interviewing you, so this pack is built for an unknown round type with flat persona weights. No web research ran, so nothing here is a fact about Atlas Freight beyond the JD you pasted.

## How to use this pack

Personas describe how a question is asked; types describe what it is scored on. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values (none in hand, so no VAL questions here) |
| EXP | Whether your background claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none here, because no research ran) |
| CASE | A live problem from the role, scored on structure and reasoning |

An answer slot is an instruction for the interview, not a question for you now. Answer it in the room from your own experience; either branch is a fine answer.

## Prep triage

Interview next week, so these come in this order.

1. A1, the highest-ROI prep in the pack. Say it aloud with all three follow-ups until it is boring.
2. The answer slots on F1, F4 and F7: decide, from your own experience, which branch is true for you. They feed A1, A3 and A4.
3. A2 and D2 together, the Power BI hold.
4. C1: the four defend-the-number answers, aloud.
5. B1 and B4, once each aloud.
6. E1, a 90-second arc.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message, "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution operations and a shift-manager role, with nothing inspected behind it. It does not say terminal operations or more than one site, and the words stay at that scope: "I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's four-sites line makes a probe on your span likely. If your responsibility has covered more than one site, say which, in your own words; if it has not, say so plainly and stay with the role you hold |
| F2 | "drive on-time performance and cost-per-shipment down" — JD, the on-time half | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | The surge plan touches the requirement without showing whether on-time performance was part of it; the material is silent on what was tracked. Answer slot: the JD names on-time performance, so expect a probe on what you tracked. If on-time or service levels were tracked during the surge, say what and how it was counted, in your own words; if nothing like that was tracked, say so plainly and stay with the plan you ran: "I ran the site's peak-season surge plan two years running." |
| F3 | "drive on-time performance and cost-per-shipment down" — JD, the cost half | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | A lower mis-pick rate is not a cost figure, and the bridge does not stretch it. Answer slot: the JD names cost-per-shipment, so expect a probe on whether the pick-path change moved cost. If cost or time was tracked before and after, say what moved and how it was counted; if it was not, say so plainly, say what you would measure first, and stay with the quote: "I cut mis-pick rate 40% by redesigning the pick path." |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material carries 3 supervisors against the JD's 12, and the words stay at 3: "I'm currently a senior shift manager over 3 supervisors." The difference in scale is the pack's observation, not words to soften. Answer slot: if an earlier role had you over more supervisors, say which role and how many, in your own words; if none did, say so plainly and give, as a plan and never as a past, how you would get to know twelve |
| F5 | "build reporting in Excel/Power BI" — JD, the Excel half | "solid Excel" — your message | low | [inferred] | discovery | A self-rating of Excel does not show what was built with it. Answer slot: the JD says build reporting, so expect a probe on what you built. If you built reports in Excel, say what they showed and who read them, in your own words; if your Excel use was not reporting, say so plainly and stay with "solid Excel" at that scope |
| F6 | "build reporting in Excel/Power BI" — JD, the Power BI half | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI work, and nothing added to make the gap feel smaller. The JD's slash does not say whether both tools are required; reverse question 1 asks |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message, "currently a senior shift manager over 3 supervisors" — your message | medium | [inferred] | discovery | The first quote gives seven years in operations and the second a leadership role today; neither says how many of the seven years were spent leading people, and the pack takes the reading that claims less. Answer slot: the JD sets a five-year bar, so expect the arithmetic. Say in your own words which roles involved leading people and for how long; if fewer than five years did, say so plainly and stay with the quotes. A length-of-experience line is a risk, not a gate |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a certification line with no certificate inspected, so expect a probe on it. Say it as you said it: "I'm green belt certified." Answer slot: if asked which belt system and who certified you, answer from your certificate; the material names neither |

## Persona table

Weights are flat. No round type or interviewer was given (relationship priors unavailable), no interviewer signals exist, and no loop source was read, so the generic archetype applies: screen, hiring manager, panel, with flat weights. Bank sizes differ only because of where the fit snapshot has material to rehearse.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of scale, terminal versus warehouse work, Power BI and years of leadership | Flat prior. Sized 4 because F1, F4, F6 and F7 are the snapshot's biggest gaps, and the Skeptic is where gaps get tested | Rehearse the single most predictable objection (A1) until it is boring; bridge only from your quotes and say the limit plainly |
| B. Case/Strategist | Live operations problems on the JD's own duties: on-time performance, cost-per-shipment, supervisor consistency, reporting | Flat prior. Sized 4 because the JD gives four concrete duties to build cases from; all four are generic because no company research ran | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| C. Data-Driven Prober | Goes line by line through the 40% figure and the surge plan, two follow-ups deep | Flat prior. Sized 4 because F2 and F3 are where a figure and a plan meet the JD's metrics | Know what you can and cannot say about how the figure was counted; say plainly when you do not know; name the weakest assumption before they do |
| D. Pressure | Time-boxed, interrupts, tests composure on your two clearest limits | Flat prior. Sized 3 because the limits it would press on (F4, F6) are already rehearsed in bank A | Pause, restate, hold through two follow-ups, then concede only the specific limit |
| E. Conversational | Friendly biography and Lean questions that are still scored | Flat prior. Sized 3 because the biography question arrives in almost any round | A pre-built 90-second arc from your quotes; treat casual questions as scored |
| P. Peer Evaluator | Seam-splitting with other site leaders, credit-sharing | Flat prior. Sized 2 because a peer is only one possible interviewer | Reciprocity framing; propose seam principles rather than claiming to know the seam |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're over three supervisors today and this role has twelve across four sites. Why should I believe that jump is safe?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I'm currently a senior shift manager over 3 supervisors." Name the limit before it is asked for: the role is bigger than that number, in your own words. Follow-up 1, "Three is not twelve": agree with the number and return to the quote. Follow-up 2, "What breaks first at twelve?": answer as a judgment about scale in the future tense, claiming no past instance. Follow-up 3, "Have you ever led more than three?": answer slot: if an earlier role had you over more supervisors, say which and how many; if none did, say so plainly. Close with, as a plan, how you would get to know twelve supervisors | F4 is the evidence for the 12-supervisor requirement and the likeliest place to be probed, so this objection arrives in some form. JD because it scores a stated requirement |
| A2 | "Your background says no Power BI, and the job asks you to build reporting. How do you close that?" | JD | [grounded] "never used Power BI", "solid Excel" | Hold only the quotes: "I've never used Power BI." Then, in the future tense and as a plan, how you would get to working reporting; the pack supplies no tool, course or timeline because your material gives none. Pair it with what you can say at its scope: "solid Excel". Answer slot: if you built reports in Excel, say what they showed; if you did not, say so plainly. Hold through two follow-ups by returning to the plan, never by adding past Power BI work | F6 is a gap wording cannot close, and F5 is the Excel half of the same JD line. JD because the reporting line is stated in the posting |
| A3 | "This role is terminal operations, not warehouse operations. What's different, and what would you need to learn first?" | JD | [grounded] "7 years in warehouse and distribution ops" | Start from the quote at its scope: "I have 7 years in warehouse and distribution ops." Say what you would ask first about how the four terminals run; the pack names no terminal practice because nothing in hand does. Answer slot: if you have worked in terminal operations, say where and what you did, in your own words; if you have not, say so plainly and say, as a plan, which parts of your warehouse work you expect to carry over and which you would ask about first | F1 is the evidence for the terminal-operations requirement, and the material says warehouse, not terminal. JD because it scores the stated duty, with the gap in the open |
| A4 | "The posting asks for five or more years of operations leadership. How many of your seven were leading people?" | EXP | [inferred] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors" | Answer slot: the JD's five-year bar makes this arithmetic likely. Say in your own words which roles involved leading people and for how long; if fewer than five years did, say so plainly and stay with the quotes: "I have 7 years in warehouse and distribution ops" and "I'm currently a senior shift manager over 3 supervisors." Never round the leadership years up to the seven | F7 is the evidence for the five-year requirement, and the quotes do not separate leading from doing. EXP because it tests what the seven years actually were |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance has slipped at one of your four terminals for three weeks. Walk me through your first 48 hours." | CASE | [generic] | Structure it. Clarify first: what on-time is measured against, over what window, and whether the slip is one shift, lane or customer. Then the objective, how you would split the problem, what you would look at in the data and on the floor, the metric you would watch daily, and the risk of fixing the symptom. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's on-time line (F2's requirement). Generic because it is a pattern for the problem, not a fact about this employer |
| B2 | "Cost-per-shipment has risen for two quarters. What do you do?" | CASE | [generic] | Clarify what cost-per-shipment is built from at this company before proposing anything, then split it into its components and check whether the rise is volume, mix or a single site. Name one premise you would challenge, such as whether the metric is comparable across sites. Make no claim about your past | A live problem from the JD's cost line (F3's requirement). Generic because no company research ran |
| B3 | "Two of your twelve supervisors run the same process differently. Do you standardize it?" | CASE | [generic] | Clarify what the difference is and what each version produces before choosing. Decide on a rule: standardize where the outcome gap is real, leave it where it is not. Say how you would explain the decision to both supervisors. A plan, not a past | A live problem from the JD's supervisor line (F4's requirement). CASE because it scores judgment under the role's real span |
| B4 | "Sketch the weekly view you'd want from four terminals. Which five numbers, and why?" | CASE | [generic] | Pick five numbers and tie each to a decision it would trigger, starting with the JD's own two, on-time performance and cost-per-shipment. Say honestly which tool you would mock it up in today. Make no claim about reports you have built; that is an answer slot on F5 | A live problem from the JD's reporting line (F5 and F6's requirement). CASE because it scores what you would measure, not which tool you know |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say what the quote says: "I cut mis-pick rate 40% by redesigning the pick path." Then the four defend-the-number answers, each in your own words: how the rate was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. Answer slot: if you do not know how it was counted, say so plainly; the pack supplies no baseline, period or method. If you know whether 40% is a relative drop or a change in points, say which | F3's quote is the only quantified claim in the material, so it is the magnet target. EXP because it tests whether the figure survives a second question |
| C2 | "Which part of redesigning the pick path was yours?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the part you did, in your own words, at the scope of the quote: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if others contributed, say what they did and give them credit; if the redesign was yours alone, say so plainly. Never widen the quote to a team or a site | F3's quote does not say who else was involved, so attribution is the next probe. EXP because it scores what was actually you |
| C3 | "What did you track during the peak-season surge plan?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Answer slot: the JD names on-time performance, so expect this. If you tracked on-time or service levels during the surge, say what and how it was counted, in your own words; if you did not, say so plainly and stay with the quote: "I ran the site's peak-season surge plan two years running." Name no measure you did not track | F2 is the evidence for the on-time requirement and it is thin on what was measured. EXP because the question tests whether the plan had numbers behind it |
| C4 | "Cost-per-shipment is on our scorecard. Did the pick-path change move it, if you tracked it?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if cost or time was tracked before and after, say what moved and how it was counted; if it was not, say so plainly, say what you would measure first, and stay with the quote: "I cut mis-pick rate 40% by redesigning the pick path." Never describe a cost result you did not track | F3 holds a quality figure against a cost requirement. JD because it scores the stated cost line, with the honest branch ready |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has already run four sites?" | JD | [grounded] "7 years in warehouse and distribution ops", "ran the site's peak-season surge plan two years running", "cut mis-pick rate 40% by redesigning the pick path", "currently a senior shift manager over 3 supervisors" | Pause and restate the question. Three beats, each a quote in your own words: "I have 7 years in warehouse and distribution ops", "I ran the site's peak-season surge plan two years running", "I cut mis-pick rate 40% by redesigning the pick path." Then one concession on scale: "This role is bigger than the 3 supervisors I'm over today." Stop there and claim no network experience. Hold through two follow-ups | F1 and F4 are where the role outsizes the evidence, and a time-boxed comparison is the pressure form of that probe. JD because it scores fit to the stated duty |
| D2 | "No Power BI and three supervisors. Why are we talking to you?" | JD | [grounded] "never used Power BI", "currently a senior shift manager over 3 supervisors", "cut mis-pick rate 40% by redesigning the pick path", "ran the site's peak-season surge plan two years running" | Pause and restate. Hold the position the quotes carry, then concede both limits plainly and specifically: "I've never used Power BI" and "I'm currently a senior shift manager over 3 supervisors." Return to what you can stand behind: "I cut mis-pick rate 40% by redesigning the pick path" and "I ran the site's peak-season surge plan two years running." Hold through two follow-ups and concede nothing beyond those two limits | F6 and F4 are the two limits the material states outright, so a pressure interviewer will combine them. JD because it scores whether you stay composed about the gaps in the posting |
| D3 | "Imagine a supervisor tells you the surge plan you ran won't work this peak. You have ten seconds." | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Pause and restate. Say you would want the objection before defending the plan, ask what the supervisor sees, then decide. Hold your position through two pushes unless they give you a fact, and concede the specific point if they do. The scenario is hypothetical, so claim no past disagreement | F2's quote supplies the plan the question refers to. CASE because it is a live decision, delivered under time pressure |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors", "cut mis-pick rate 40% by redesigning the pick path" | A 90-second arc from the quotes: "I have 7 years in warehouse and distribution ops", "I'm currently a senior shift manager over 3 supervisors", then one headline result: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: name your earlier roles in the order you held them, in your own words; the material names none. End on why this role, in your own reason | F1 and F7 are the evidence an arc has to carry. EXP because a biography question is a CV check in a friendly register |
| E2 | "What are you actually playing with in Lean and continuous improvement these days?" | JD | [grounded] "green belt certified" | Start at the quote's scope: "I'm green belt certified." Answer slot: if you are running any improvement work now, say what, in your own words; if you are not, say so plainly and say, as a plan, what you would start with at a new site | F8 is the evidence for the Lean line, and a casual question about a JD plus is still scored. JD because the plus is stated in the posting |
| E3 | "What draws you to a regional logistics business?" | JD | [generic] | Give your own reason in one or two sentences; the pack has no source for your motivation and supplies none. Say nothing about Atlas Freight that you have not read yourself before the interview; no company research ran here | The JD describes a regional logistics business, and a motivation question is routine in a friendly round. Generic because it is a pattern, not a fact about this employer |

### P. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Where's the seam between my terminal and yours, and what happens when we disagree?" | CASE | [generic] | Offer seam principles instead of claiming to know the seam: who decides, how a disagreement gets escalated, what each side owes the other. Frame what you would bring to the other terminal as well as what you would need. Make no claim about your past | A peer round tests partnership across four sites (F1's requirement). Generic because it is a pattern for the problem |
| P2 | "How do you handle credit when a result spans teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Use "we" for context and "I" for your contribution: "I cut mis-pick rate 40% by redesigning the pick path" is your contribution as you stated it. Answer slot: if others contributed, name what they did and give them credit; if none did, say so plainly | F3's quote is the story a credit question would reach for. EXP because it tests attribution honesty with an equal |

### Requirement coverage

| JD requirement | Fit row | Questions |
|---|---|---|
| "Own daily terminal operations across 4 sites" | F1 | A3, B1, B3, D1, P1 |
| "drive on-time performance and cost-per-shipment down" | F2, F3 | B1, B2, C3, C4 |
| "lead a team of 12 supervisors" | F4 | A1, B3, D2, D3 |
| "build reporting in Excel/Power BI" | F5, F6 | A2, B4, D2 |
| "5+ years operations leadership required" | F7 | A4, E1 |
| "Lean/Six Sigma a plus" | F8 | E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "The posting says Excel/Power BI. Is Power BI where the reporting lives today, or is it Excel, and is the person in this seat expected to build in both?" | F6 is your one stated gap, and the JD's slash does not say whether both tools are required; the answer tells you how much the gap matters |
| 2 | "Of the four sites, which would you want fixed first, and what would on-time performance and cost-per-shipment need to look like for you to call it fixed?" | It turns the JD's two metrics into a first target, and it shows you read them |
| 3 | "How are the twelve supervisors spread across the four sites?" | F4's scale gap becomes information you can plan against |
| 4 | "In a normal week, how does this seat split between the terminals and the reports?" | It tells you what owning daily terminal operations means in practice, which F1's evidence does not show |
| 5 | "What would make you say, six months in, that this hire was the right call?" | It gets the interviewer to state the scorecard, so your first months can be aimed at it |
| 6 | "What is the operational problem you would most like the next person to inherit in better shape?" | It invites the interviewer to name the real priority, and it fits a case-led or skeptic round equally |

## Prohibited claims

Claims this pack will not coach, and why. Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned daily terminal operations across four sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: the material says warehouse and distribution operations and a shift-manager role, not terminal operations or multiple sites. A1's and A3's slots stay inside what you actually held |
| Led a team of twelve supervisors | Inflated form of F4 | F4's quote at its own scope: "I'm currently a senior shift manager over 3 supervisors." A1's slot asks only about earlier roles |
| Drove on-time performance down | Inflated form of F2 | F2's quote at its own scope: "I ran the site's peak-season surge plan two years running." C3's slot asks only what was tracked |
| Brought cost-per-shipment down | Inflated form of F3 | F3's quote at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." C4's slot asks only whether cost was tracked |
| Built reporting in Excel | Inflated form of F5 | F5's quote at its own scope: "solid Excel". B4 and A2 never assert a report you built |
| Built reporting in Power BI | Negative you stated, F6 | The plain acknowledgment F6 gives: "I've never used Power BI." No slot |
| Leads or practises Lean or Six Sigma | Inflated form of F8 | F8's quote at its own scope: "I'm green belt certified." E2's slot asks only about current improvement work |
| Led operations teams for the full seven years | Inflated form of F7 | F7's quotes at their own scope. A4's slot asks which roles involved leading people |

## Sources

Provided documents: the JD text pasted in your message; the background you gave in your message; your statement that you don't know who is interviewing you. No dossier was present.

Searches sent, all refused, none returned a result:

- "Atlas Freight regional logistics company values": refused
- "Atlas Freight interview process operations manager": refused
- "Atlas Freight regional logistics terminals news strategy": refused

Fetches: none sent. Nothing about Atlas Freight comes from model memory; every company-level statement in the pack is the JD's own words or labeled generic. No loop source was read, so the loop falls back to the generic archetype with flat weights, and no values-style round is detected, so there is no values cheat sheet and no CO question.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | The search was refused. It would have supplied the values page for a cheat sheet and VAL questions |
| 2. Atlas Freight interview process, operations manager | unavailable | The search was refused. It would have supplied the loop structure that persona weights follow |
| 3. Atlas Freight strategy and recent news | unavailable | The search was refused. It would have supplied current priorities for CO questions |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who you're meeting (recruiter screen, hiring manager, peer, panel) → persona weights recomputed; a recruiter screen adds pay, notice, location and reason-for-leaving questions
- The interviewer's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- The recruiter's prep email (focus areas, anything you are asked to bring or present) → coverage of announced topics and a build section for any deliverable
- Your own sentence on each answer slot in F1, F2, F3, F4, F5 and F7 → those rows quote your words, `[inferred]` rows can become `[grounded]`, and the bridges replace the slots
- A CV with role titles and dates → F1, F4 and F7: how many of the seven years involved leading people, and any earlier supervisor counts
- Your green belt certificate (belt system and issuer) → F8 moves from medium to high confidence
- A before-and-after report for the mis-pick figure → F3 moves from low confidence, and C1's slots become a story
- Atlas Freight's values page, careers page or loop details, pasted, or search permission granted → a values cheat sheet, grounded CO questions, and persona weights that follow the named rounds
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, which needs search permission → a company strategy brief and recent organization context
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence, a strategy per weak area, and a claims-to-avoid list built from your confirmed answers
