I'll read the reference files the skill requires before building anything.
The pack is built and saved. I'm now writing the closing message.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/alone/part-2/rooms/case-1-denied-2e1f63d6/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. It's built for one 60-minute peer conversation with Dan. The searches I tried on Northwind and Dan were refused because web-search permission wasn't granted. So the pack rests on what you gave me, including your research note, and none of it was checked against the web.

What's in it:
- **Questions:** 23 in six banks. Prober and Peer Evaluator are weighted highest, then Case, Skeptic, Conversational and a short Pressure bank. Each question has a type tag, answer guidance and a rationale.
- **Fit snapshot:** seven rows covering the six JD highlights plus the stated sales-ops gap, graded against Priya's own notes.
- **Also included:** a reading of Dan, a requirement-coverage table, six reverse questions, a prohibited-claims list and an upgrade menu.
- **Highest-ROI prep:** D1, the required partner-motion question. Her partner evidence is a revenue model used in carrier negotiations, not a partner motion. Second is the ~$400M ARR figure (A1 and F1).
- **No values bank:** no published values were in hand and a single conversation with Dan isn't a values round.

Say the word and I'll play Dan on D1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

- **Candidate:** Priya
- **Interviewer:** Dan Kovac, Director of Sales Strategy at Northwind Data. He is Priya's peer: both would report to the same VP.
- **Round:** one 60-minute conversation, as stated in your note. The pack is built for that single session, not a loop.
- **Highest-ROI prep:** D1, the partner-motion question. It is the likeliest objection to this candidate. Second is A1 and F1, the ~$400M ARR figure.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and only what you can defend to a second question. An answer slot is an instruction for the interview. It is not a question for you today.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. Not used here: no published values were in hand and no values-style round was detected |
| EXP | Whether your background survives scrutiny, and what was actually yours |
| JD | The stated responsibilities and requirements, including the gaps |
| CO | Company and strategy knowledge, thinking at the company's altitude |
| CASE | A live problem from the role, scored on structure and reasoning |

## 2. Fit snapshot

Requirements are quoted from the JD highlights in your message. Evidence is quoted from your notes on Priya. F7 is a role-family expectation, not a JD line.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes; "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material shows a proposal credited with an uplift, and years in product strategy and ops. It does not show go-to-market ownership, and the words stay at that scope: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: the JD's own-the-strategy line makes a probe on go-to-market decisions likely. If any part of that work set who an offering was sold to or how it reached them, say what and how you decided, in your own words; if it did not, or none of it was yours, say so plainly and stay with the proposal |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | low | [inferred] | discovery | Setting annual volume targets touches this requirement without showing whether it reached whitespace across a customer lifecycle, and the bridge should not be stretched. Answer slot: the JD's land/adopt/expand/renew line makes a probe on where volume was missing likely. If any of your target-setting looked at where volume was untapped, say what you looked at, in your own words; if it did not, say so plainly, and say how you would look for whitespace first on a new product line |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | discovery | The quote names the tools, not an analysis you ran on your own. Answer slot: the JD's independent-analysis line makes a probe on one specific analysis likely. If there is one you ran yourself, offer to walk through it end to end, in your own words; if the work was shared with others or done by them, say so plainly and say which part was yours |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a model used in negotiations, not a partner motion, and the words stay there: "I built a partner-level revenue model used in carrier negotiations." Answer slot: the JD's required partner-motion line makes a probe on how partners were approached or structured likely. If any of that was yours to set, say which part and how you decided; if it was not yours, or there was no such structure, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms, so lead with it as it stands: "I set annual volume targets with cross-org consensus." Nothing is added to it. The quote does not say which orgs or how consensus was reached, so expect a probe there and answer only from what you know |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | The quote reaches the requirement in other terms; lead with it at its own scope: "I use AI tools daily." It says use, not building or launching, and the words stay at use |
| F7 | Sales-ops or quota-setting experience, a role-family expectation for a sales-strategy peer, not in the JD highlights | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and the note states it. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Never a claim to sales-ops work, and nothing added to make the gap feel smaller |

## 3. Reading the interviewer

Public professional signals only, taken from the profile summary you supplied.

| Signal | What it implies for this conversation | Provenance |
|---|---|---|
| Self-describes as "relentlessly data-driven" | Every number you say will be probed to its inputs. A1, A5 and F1 are the likeliest places. Name the assumption you would defend least before he does | [grounded] |
| Career spine is pricing and monetization roles | His native cases are packaging, pricing and unit economics. Expect C2 in that shape, and expect revenue vocabulary to land with him | [grounded] |
| One early-stage-startup chapter | Expect a probe on operating with little structure (D4). Your material carries no builder story, so none is supplied | [grounded] |
| Peer, same VP | He is judging what you would cost and contribute to his work: the seam, disagreement style, credit. See B1 to B5 | [grounded] |
| Mirror opportunity: shared revenue vocabulary | His spine is pricing and monetization; F4's quote is "built a partner-level revenue model used in carrier negotiations". Use the shared vocabulary, and do not claim pricing experience: the material does not say you have it | [grounded] |

## 4. Persona table

Weights start from the peer relationship prior (Peer Evaluator and Data-Driven Prober), then move on his signals. The loop is fixed by your own words: one conversation with Dan. No values-style round was detected, so no archetype fallback applies.

| Persona (bank) | How it shows up with Dan | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (A) | Reads each claim to its inputs, two follow-ups deep | Highest. The peer prior plus his "relentlessly data-driven" self-description move it to the top. Your headline figure is a magnet | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know |
| Peer Evaluator (B) | Seam-splitting, "what would you need from me", credit and disagreement | High. Peer prior, and the role sits beside his | Reciprocity framing, and seam principles rather than pretending to know the seam |
| Case/Strategist (C) | Live problems on Northwind's three stated priorities, tilted to pricing and packaging | Medium. His pricing and monetization spine tilts cases that way, and a peer may still run one | Clarify, objective, segmentation, approach, metrics, risks, aloud; challenge one premise respectfully |
| Skeptic (D) | Quiet probing of required-but-thin items | Medium. A required requirement rests on thin evidence (F4) and a stated gap sits in his own function (F7), though a peer is less likely to cross-examine | Rehearse D1 until it is boring; calibrated candor over bluffing a competency he may own |
| Conversational (E) | Opening biography and casual AI and motivation questions | Medium-low. A 60-minute conversation usually opens loosely | A 90-second arc; treat casual questions on hot JD topics as scored |
| Pressure (F) | Time-boxed challenge on attribution and fit | Low. Unusual from a peer, but the figure and the required gap make two items worth having ready | Pause, restate, hold the quoted position through two follow-ups, concede specifically |
| Values/Behavioral | Not banked | Lowest. No published values were in hand and no values round was detected | Not rehearsed here |

## 5. Question banks

### Bank A: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Story-mapped only to what the quote states: you proposed a store-surface change, and it was credited with a ~$400M ARR uplift. Say it at that scope, in your own words. Then the four slots a figure raises, each answered from what you know and nothing else: how it was counted, what it is sensitive to, the assumption behind it you would defend least (name it before Dan does), and which part was yours. If you do not know how it was counted, say that plainly | F1 holds the headline figure, the first thing a self-described data-driven peer tests. EXP because it scores whether the number survives scrutiny; it sits with the Prober because the probe is about inputs, not the story |
| A2 | "Walk me through the revenue model you built for the carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Three beats, all from the quote: a model, built at partner level, used in carrier negotiations. Tell them in your own words. If Dan asks about inputs, assumptions or what the negotiations did with it, answer only from what you know and say plainly where you do not. The model's mechanics are not in the material, so the pack names none | F4 is the only partner evidence, so it will be pressed for mechanics. EXP because it asks what the candidate built; Prober because the probe is inputs and assumptions |
| A3 | "Tell me about an analysis you ran yourself, end to end, in SQL or Tableau." | JD | [grounded] "skilled in SQL/Tableau" | The quote carries the tools and no story, so this is a selection scaffold. Pick an analysis where you wrote the queries or built the view yourself. Give four beats from your own memory: the question it answered, where the data came from, what you found, and what changed because of it. If no such analysis comes to mind, say so plainly, then give the nearest work your material carries, or how you would run one on a new product line. Keep the tool claim at what the note states | F3 is the JD's independent-analysis line, and a data-driven peer will ask for a specific piece of work. JD because it scores a stated requirement; the delivery is an EXP-style walk-through |
| A4 | "A product line is six months old with very little history. Which metrics would you trust, and which would you refuse to read yet?" | CASE | [grounded] "identify whitespace across land/adopt/expand/renew" — JD highlights | Clarify first: what the product does, who buys it, and what the VP means by working. Then structure by the JD's own stages: land, adopt, expand, renew. Say which stages have any signal at six months and which are too early. For each metric you trust, name the assumption you would defend least. Challenge one premise respectfully, such as whether volume or adoption depth should lead. No past claim is needed | F2's evidence is thin, so a hypothetical lets honest structure carry the answer. CASE because it is a live problem; it sits with the Prober because it scores metric discipline |
| A5 | "Tell me about the annual volume targets you set — what did the process look like?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Two beats from the quote: you set annual volume targets, and it was with cross-org consensus. Say them as they stand. Dan will ask how the targets were derived and how consensus was reached. Answer only from what you know, and say plainly where you do not remember or where it was not yours. The pack names no method, baseline or stakeholder. Keep the word targets and use no other name for them | F5 is both your influence evidence and a claim a data-driven peer will probe for derivation. EXP because it asks what was actually yours |

### Bank B: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side — where's the seam, and what happens when we disagree?" | JD | [generic] | You do not know the seam yet, and saying so is the strong answer. Offer principles instead: agree who owns each number before work starts, share one set of definitions, and when you disagree write down both options and bring them to your shared VP together. Then turn it back and ask where he sees the seam sitting. No claim about your past is needed | The Peer Evaluator's core stem, and the JD's cross-functional influence line (F5's requirement) in collegial form. JD because it scores a stated requirement; the principles are a rehearsal method, not a fact about Northwind |
| B2 | "What would you need from my team, and what would you bring to it?" | JD | [generic] | Lead with what you bring, then what you need. Say what you bring in your own words and only from what you have actually done. State needs as specific inputs, not general support. This is the reciprocity answer: a peer is pricing whether you add to his load or reduce it | The reciprocity question the peer round calls for, and an F5 requirement probe. JD because it scores cross-functional fit; it makes no claim about the candidate's past |
| B3 | "Tell me about a time work spanned teams and the credit had to be shared. How did you handle it?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Nearest carried story: you set annual volume targets with cross-org consensus. Say it at that scope, using we for the context across orgs and I for the part you set. Expect a probe on how consensus was reached. If you moved anyone, say who and how, in your own words; if consensus needed no moving, or none of it was yours, say so plainly and stay with the targets. If a different time fits better, pick one with shared work, a named other team and credit that could have gone either way; if none comes to mind, say so plainly | The Peer Evaluator's credit-sharing stem, answered from F5's evidence. EXP because it asks what the candidate actually did; open prompt, so it supplies no event |
| B4 | "Tell me about a time you disagreed with an adjacent team on a number. Where did it land?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Selection scaffold: pick a disagreement where you held a view, the other team held another, and the relationship was intact after. Show spine and tact together: what you held, what you conceded, and what you would do again. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is setting annual volume targets with cross-org consensus, at that scope, or how you would handle it | Disagreement style with equals is what the peer round scores, and F5 is the nearest evidence. EXP because it tests a real instance; the candid fallback is part of the rehearsal |
| B5 | "My team has already told the VP a number for the core business. Your new line needs sellers' time that number assumes is spoken for. How do we settle it?" | CASE | [generic] | Clarify whose number is firmer and what each option costs. Then structure: make the trade-off visible with data, agree a decision rule before choosing, and bring the options to the VP jointly rather than around each other. Offer to build the comparison with him. No claim about your past is needed | The seam made concrete: the likeliest real collision between his remit and this role. CASE because it is a live problem; generic because it is a pattern, not a fact about Northwind |

### Bank C: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You'd own GTM for two new product lines. What do you need to know in your first two weeks, and what does your first ninety days look like?" | JD | [grounded] "own GTM strategy for two new product lines" — JD highlights | Aloud: clarify, objective, segmentation, approach, metrics, risks. Ask first what the two lines are, who buys each, what stage each is at, and what the VP expects to be true in a year. Then sequence your own plan. The pack does not pick it for you. Challenge one premise, such as whether both lines deserve equal go-to-market effort | F1's requirement stated as a plan, the cleanest place to show structure without needing go-to-market history. JD because it is the headline requirement; CASE delivery |
| C2 | "Compass is launching. Standalone, add-on or bundled in — how would you decide, and what do you need to know first?" | CASE | [grounded] Compass, enterprise expansion and profitability as stated priorities — your research note | Clarify what evidence exists on willingness to pay, what an AI copilot costs to serve, how it interacts with existing contracts, and how complex it is to sell. Then lay out the options against the three stated priorities, which pull in different directions: expansion, the Compass launch, profitability. Use the company's own words. Name the assumption you would defend least. Challenge one premise, such as whether the three options are exclusive | Dan's pricing and packaging spine makes this his native case, and it is grounded in the priorities you researched. CASE because it is live; it also scores CO fluency, since the candidate must use Northwind's own vocabulary |
| C3 | "A much larger platform vendor starts bundling a competing capability into what customers already pay for. What changes in your GTM across land, adopt, expand and renew?" | CASE | [grounded] bundling by a much larger platform vendor as the main competitive threat — your research note | Bring one consensus move to show grounding, such as differentiating on what a bundle cannot do. Then give one thesis of your own with its concession, and where the role's real job includes saying no, one segment you would not defend. Go stage by stage and say where bundling hurts first. The threat is in your research note, which interviewers share, so depart from the consensus answer and do not recite it | The differentiator question: the competitive threat is stated and most prepared candidates will recite the shared frame. CASE because it is live; CO is the secondary tag, carried in the rationale |
| C4 | "Where would you look first for whitespace across land, adopt, expand and renew, and what cuts of the data would you want?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" — JD highlights | Clarify what whitespace means to them: accounts, products, seats or stages. Structure by stage. Name the cuts you would pull and where you would start the analysis, as an approach and not a past. Name the assumption that would most change the answer | F2 is the thinnest row, so the hypothetical form lets an honest structure stand in for history. JD because it scores the requirement; the form is a case, with a data-driven interviewer listening for the cuts |

### Bank D: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Partner-motion design is listed as required for this role. Where does it show up in your background, and where doesn't it?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | The highest-ROI rehearsal in this pack, three levels deep. Level 1: hold only what the quote carries, "I built a partner-level revenue model used in carrier negotiations." The pack's observation, not words for you: the material says a model used in negotiations, not a partner motion, so name that limit yourself before Dan does. Level 2, if he asks how partners were approached or structured. Answer slot: if any of that was yours to set, say which part and how you decided; if it was not yours, or there was no such structure, say so plainly and return to the model. Level 3, if he says the model is not a motion. Concede in your own words the part of partner work your history did not cover, and give how you would close it as a plan. Never describe a motion you did not design | F4 is a required requirement resting on one adjacent quote, so this objection will arrive in some form. JD because it scores the stated requirement; it is the deepest item because a rehearsed, non-defensive answer here changes the interview |
| D2 | "Your background doesn't include classic sales-ops or quota-setting work. How do you earn credibility with the sales org, and with me?" | JD | [grounded] "No classic sales-ops or quota-setting experience" "set annual volume targets with cross-org consensus" | Hold-then-concede, in order. Concede first, plainly: "I don't have classic sales-ops or quota-setting experience." Then what you can truthfully carry: you set annual volume targets with cross-org consensus, at that scope and under that name. Then the ramp, said as a plan: what you would ask Dan's team for in your first month, in your own words. Do not claim sellers' credibility from the targets; earn it through the plan. If he presses on how your targets were set, answer from what you know and say plainly where you do not | F7 is a stated gap in the function Dan leads, so the concession is the strongest move available. JD because it tests whether the hire can work beside sales, although F7 is a role-family expectation and not a JD line |
| D3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" | Calibrated candor: pick the part you actually believe is weakest. The pack's observation: your material is thinnest on the whitespace and partner-motion rows (F2, F4) and states a gap on F7. If your pick is sales-ops mechanics, say "I don't have classic sales-ops or quota-setting experience," then your plan to learn it. If it is another part, say it in your own words and say how you would close it, as a plan. Never answer that there is nothing | The persona's own stem, and the fastest way to see whether the candidate's self-assessment matches the JD. JD because it scores honest fit against the listed job; the thin rows are named only by ID |
| D4 | "You're coming from a large consumer-tech company, and these two product lines will have a lot less scaffolding. Where does that worry you, if at all?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Selection scaffold: pick a time you worked with less structure than you were used to. It needs a named gap in structure, what you did first, and what you would keep. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would start. The pack finds no builder story in your material and supplies none | Dan's one early-stage chapter makes a scrappiness probe plausible, and F1's requirement is about two new lines. JD because the lines are the job; the question is about the candidate's fit to them |

### Bank E: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with two chapters as stated: two years in strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company. Then one or two work items you can defend to a second question, at their own scope. Close with why this role now, in your own words, because the material gives no reason and the pack supplies none | A 60-minute conversation usually opens loosely, and casual questions are still scored. EXP because it tests the CV's story; the arc is the pre-scripted rehearsal the persona calls for |
| E2 | "What draws you to Northwind, and to B2B data infrastructure after consumer tech?" | CO | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Your reasons are yours; the pack supplies none. Use the company's own vocabulary where it helps: per your research note, enterprise expansion, the Compass launch and profitability are the stated priorities, and bundling by a much larger vendor is the main threat. Connect only to the part that genuinely interests you. Do not claim B2B experience; the material says nine years in consumer tech | The motivation question every peer round carries, with CO as the primary tag because it scores homework at the company's altitude. The consumer-to-B2B move is the part the Skeptic bank also presses |
| E3 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say it at its scope: you use AI tools daily. Then name the tools and what you actually use them for, in your own words; the pack names none. Tie it to Compass only as curiosity, as a question, and do not claim building or launching anything. Casual register, still scored | The JD's AI plus (F6) asked casually, with Compass making it live. JD because the plus is a stated line; the rapport register is why it sits here |

### Bank F: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That ~$400M ARR result — how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause and restate. Hold only what the quote carries: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Hold it through two follow-ups by returning to the proposal, never by adding to it. Concede explicitly and specifically what you do not know, whether how the credit was assigned, how it was counted or what others did; if your part ended at the proposal, say so plainly. Never fold on the core claim to restore harmony | F1's attribution probe, the one that exists to catch inflation. EXP because it scores what was the candidate's; Pressure because the delivery is a challenge and the concession must be specific |
| F2 | "Sixty seconds: why you, rather than someone who has run a partner program for a B2B software company?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" "set annual volume targets with cross-org consensus" | Pause and restate in one line. Then only what the quotes carry: "I built a partner-level revenue model used in carrier negotiations" and "I set annual volume targets with cross-org consensus." Concede, in your own words, the part of partner work your history does not cover, and say how you would close it as a plan. Hold the two sentences through a second push and do not add a third | F4 and F5 are the only fit evidence for the required partner line and for influence. JD because it scores the stated requirement; Pressure because the time-box tests composure |

## 6. Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| own GTM strategy for two new product lines (F1) | C1, C2, C3, E2, A1, F1 | C1 is the JD-tagged item |
| identify whitespace across land/adopt/expand/renew (F2) | C4, A4 | |
| run independent analysis in SQL and Tableau (F3) | A3 | |
| partner-motion design experience required (F4) | D1, F2, A2 | D1 is the deepest rehearsal |
| strong cross-functional influence (F5) | B1, B2, B3, B4, A5 | |
| AI experience a plus (F6) | E3 | |
| Sales-ops or quota-setting, role-family (F7) | D2, D3 | Not a JD line; covered because it is a stated gap in Dan's function |

## 7. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your background is mostly pricing and monetization. How does that shape the way you look at a go-to-market plan for a new product?" | Ties to his own path and invites him to talk about his craft, which turns the interrogation into a peer conversation |
| R2 | "What could a new peer do in their first month that would genuinely help your team?" | The reciprocity question for a peer round: it asks what reduces his load, not only what you need |
| R3 | "Where do you expect the line between your remit and this role's to sit, and what would you want us to agree in the first month?" | Proposes seam principles rather than pretending to know the seam, and shows you expect to share an owner |
| R4 | "Which early-traction metric do you trust most for a new product, and which do you distrust?" | Speaks to a data-driven interviewer's own judgment and gives you the metric vocabulary for C4 and A4 |
| R5 | "When a much larger vendor bundles, where does your team feel it first: land, expand or renew?" | Grounded in the competitive frame from your research note; it shows altitude without reciting the note |
| R6 | "What would make you say, six months in, that this hire worked?" | A success criterion you can plan against, asked of the person who will work beside you |

## 8. Prohibited claims

Built from the fit snapshot before the banks were written. No guidance cell asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Designed partner motions or a partner program | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says a model used in negotiations, not a partner motion. D1's slot stays inside the model |
| Owned go-to-market for a product line | Inflated form of F1 | F1's quote at its own scope: a proposal credited with an uplift, not go-to-market ownership. C1 is a plan, not a past |
| Generated, drove or delivered the ~$400M ARR | Inflated form of F1 | F1's quote at its own scope: "proposed a store-surface change credited with a ~$400M ARR uplift". A1 and F1 slots ask only how it was counted and which part was yours |
| Has sales-ops or quota-setting experience | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| Described the volume targets under another name | Contradicted by F7's stated negative | F5's quote at its own scope: "set annual volume targets with cross-org consensus". Nothing more |
| Has built or launched AI products | Inflated form of F6 | F6's quote at its own scope: "uses AI tools daily". E3 stays at use |

## 9. Sources

Provided documents: the JD highlights, the notes on Priya's background, the summary of Dan's profile, and the research note on Northwind's three stated priorities and its main competitive threat, all from your message. The research note is used as given and could not be checked against the web.

Searches sent, all refused because web-search permission was not granted:

- `Northwind Data B2B data infrastructure company values`: refused
- `Northwind Data Compass AI copilot launch enterprise expansion profitability`: refused
- `Dan Kovac Director of Sales Strategy Northwind Data`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The call was refused. It would have given published value names for VAL-themed questions; with no values-style round detected, no bank is missing a section because of it |
| 2. `Northwind Data interview process {role family}` | skipped | Your own words fix the loop as one 60-minute conversation with Dan, which fixes the persona weights and the values-round finding |
| 3. `Northwind Data strategy` / recent news | unavailable | The call was refused. It was a check of your research note's currency; it would have confirmed or dated the priorities behind C2, C3, E2 and R5 |
| 4. `Dan Kovac Northwind Data` | unavailable | The call was refused. It would have added public talks and writing to the interviewer read and to R1; the read now rests on the profile summary you supplied |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## 10. Upgrade menu

- Full JD text → the six JD rows now rest on highlights; the full text would add mid-list requirements and any location, pay or travel terms as rows of their own
- Search permission for a research pass → the values, the interviewer's public footprint and a current-strategy check; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a grounding brief and sharper CO and CASE questions
- Your account of what Priya actually did on F1, F2, F3 and F4, in her own words → those rows move from transferability or discovery to stories the banks can map
- An inspectable artifact for F1 (the document or report that shows how the ARR credit was assigned) and for F4 (the revenue model itself or its summary) → confidence on those rows can move from medium toward high
- The recruiter's guidance on what the conversation will cover → coverage beyond the round-type priors
- Prep time available → a prioritized schedule sized to it
- A saved evidence dossier from an earlier evaluation → verified evidence, per-gap strategy limits and absolute prohibited claims
