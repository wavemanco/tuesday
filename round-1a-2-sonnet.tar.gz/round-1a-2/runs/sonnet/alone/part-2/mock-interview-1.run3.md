I'll read the skill's reference files before building the pack.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a2/runs/sonnet/alone/part-2/rooms/case-1-denied-c11f7193/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. It has 22 questions across seven personas, each with type, provenance, answer guidance and rationale. It also has a fit snapshot, an interviewer read, a requirement-coverage table, reverse questions, prohibited claims, sources and an upgrade menu.

I built it for a single 60-minute peer conversation with Dan. I weighted it toward the Peer Evaluator and the Data-Driven Prober, then added pricing-tilted cases because of his monetization background.

- **Web research didn't run.** My three searches (values, loop structure, Dan's footprint) were refused, so the interviewer read rests only on your profile summary. The strategy cases rely on your research note.
- **Highest-ROI prep is C1.** Dan is the peer who owns sales strategy, and your own note says Priya has no classic sales-ops or quota-setting experience. The guidance has her say that plainly, hold only what her sentences carry, and give a ramp plan. G1 is the time-boxed version.
- **Two lines to keep in her own scope.** She "set annual volume targets", which isn't quota-setting. She "proposed" the store-surface change that was "credited with" the ~$400M uplift, which isn't driving it. Both are in the prohibited list with their honest forms.

I can play Dan live on C1, the highest-ROI question, with reactive follow-ups and feedback against its guidance cell. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy — a peer: both of you would report to the same VP
**Round:** one 60-minute conversation with Dan, as you described it
**Built on:** your message only (JD highlights, candidate summary, interviewer profile summary, your research note). The three web searches I sent were refused, so company values, loop structure and Dan's public footprint are not researched; see Sources.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether the CV's claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company's strategy and competitive position |
| CASE | Structure and reasoning on a live problem from the role |

Question IDs run by persona: A, B, C, D, E, G, H. The letter F is skipped so it never collides with the fit-snapshot rows F1 to F7. An answer slot is an instruction for the interview, not a question to me: fill it from your own experience, or take the honest second branch. **The highest-ROI prep in this pack is C1**, the sales-ops and quota-setting objection, with G1 as its time-boxed version.

## Fit snapshot

The requirements are quoted from the JD highlights in your message, and the evidence is quoted from your description of Priya. F7 is the one role-family row: it comes from no JD line you gave me.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message | low | [inferred] | transferability | Words stay at the quote's scope: two years of strategy consulting, then nine years in product strategy and ops at a large consumer-tech company. The pack's observation: your material says product strategy and ops, not go-to-market, and nothing inspected sits behind it. Answer slot: the JD's two-new-lines line makes a probe likely on how any of that work reached customers. If any part of your product strategy and ops work involved how customers first found or bought a product, say which part and what was yours, in your own words; if none did, or it was not yours, say so plainly and stay with product strategy and ops |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | low | [inferred] | discovery | The quote touches revenue growth and does not show whether it looked across stages of a customer's life with a product. Answer slot: the JD's land/adopt/expand/renew line makes a probe likely on how you would find whitespace. If any of your work looked at where revenue was or was not being captured, say what you looked at and what was yours; if none did, say so plainly, then say how you would start in your first weeks, as a plan and not a past |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — your message | medium | [grounded] | discovery | The quote names the tools and does not show independent analysis. Answer slot: the JD's independent-analysis line makes a probe likely on what you did with them. Say what you used each tool for, in your own words; if others did the analysis, or you used them differently, say so plainly and return to "skilled in SQL/Tableau" |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | A term of experience, not a gate: it is graded like any other row. Words stay at the quote: "I built a partner-level revenue model used in carrier negotiations." The pack's observation: a model of partner revenue is adjacent work, and your material does not say how any partner arrangement was structured. Answer slot, inside the model's scope: if any of the model's inputs were yours to choose, say which and how you decided; if it was built to someone else's specification, or there was no such choice, say so plainly and return to the quote |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Reword only it: "I set annual volume targets with consensus across orgs." Lead with the named record, which is the targets, set annually, with consensus across orgs. Nothing inspected sits behind it, so expect a probe |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — your message | medium | [grounded] | none | No gap at the quote's scope, and the verb is use. Keep the verb at use. Casual-register questions on this are still scored |
| F7 | Sales-ops and quota-setting fluency expected of a peer in sales strategy (role-family expectation, not in your JD highlights) | "No classic sales-ops or quota-setting experience." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Reading the interviewer

Public footprint was not researched (the search was refused). This read rests on the profile summary you gave me, nothing more.

| Signal | Source | Provenance | What it means for the conversation |
|---|---|---|---|
| Describes himself as "relentlessly data-driven" | Your profile summary | [grounded] | Prober weight up: expect every number probed to its assumptions. Use the weakest-assumption move on B1 and B2 before he asks |
| Career spine in pricing and monetization roles | Your profile summary | [grounded] | Cases tilt toward pricing, packaging and unit economics, his native language. D1 to D3 are built that way |
| One early-stage-startup chapter | Your profile summary | [grounded] | Builder stories may land, and scrappiness or big-company-pace probes are possible. Hold that lightly: it is one chapter |
| Peer, same VP as the role | Your message | [grounded] | Peer Evaluator weight up: he is pricing what your hire costs and gives his own work. Bring reciprocity, not only needs (A3) |
| Mirror opportunity: shared revenue and monetization vocabulary. Your side of it is a sentence from F2: "proposed a store-surface change credited with a ~$400M ARR uplift" | F2 evidence, your message | [inferred] | Use his words (pricing, monetization, ARR) in questions you ask. Offer it as a shared domain, not as a claim of equivalent experience; the quote stays at its own scope |

## Persona table

The weights rest on your description of one session with a peer. No company loop source was read, because the loop search was refused.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (A) | Seam-splitting between his team and the new lines, "what do you need from me", credit across teams | Highest: relationship prior for a peer, plus the JD's influence line | Reciprocity framing; propose seam principles, not a seam you cannot know yet; for any story, use only F5's quote or an answer slot |
| Data-Driven Prober (B) | Number-by-number probes on the ~$400M, the model, the SQL and Tableau claim | Highest: peer prior plus his "relentlessly data-driven" self-description | Say how each figure was counted if you know, and say plainly when you do not; name the weakest assumption you know before he does |
| Skeptic (C) | The sales-ops and quota-setting gap, partner-motion design, go-to-market ownership | High: F7 is a stated gap and F1, F4 are adjacent; a peer asks these collegially | Rehearse C1 until it is boring; bridges only from F4, F5 and the quotes; a concrete ramp plan stated as a plan |
| Case / Strategist (D) | Live problems on bundling, Compass, profitability | Medium: not the hiring manager, but his pricing spine pulls cases toward his native ground | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Conversational (E) | The journey question, "what are you playing with in AI" | Medium-low: it opens most conversations, and the JD flags AI as a plus | A pre-scripted 90-second arc; treat the AI question as scored |
| Pressure (G) | "Sixty seconds", "how much was actually you" | Low-medium: a peer rarely stress-tests, but these questions arrive politely inside probes | Pause, restate, hold through two follow-ups, concede specifically |
| Values (H) | Unpopular truth, customer over metric | Low: no values-style round is established. Your description names one conversation and no loop source was read | A selection scaffold for each; no mapped story is claimed |

## Question banks

### A. Peer Evaluator (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where is the seam between GTM strategy for the new lines and sales strategy, and what happens when we disagree?" | JD | [generic] | Clarify first: what does his team own today, and which decisions touch both. Then offer seam principles rather than a seam you cannot know: who decides what is named up front, definitions for shared numbers are agreed, disagreements are settled on the data first and escalated to the shared VP only if the data does not settle them. Say you would want his view before proposing anything firmer. The question needs no claim about your past, so the guidance makes none | F5 is the requirement this presses on. JD because it scores the stated influence line; the peer relationship makes the seam the natural delivery |
| A2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Say what the sentence says and no more: you set annual volume targets, with consensus across orgs. Answer slot: if credit was ever divided on that work, say how, in your own words; if it never came up, or was not yours to divide, say so plainly and return to the sentence. Then say how you would handle credit with his team going forward, as a stated approach | A standard peer stem; F5 is the only evidence in reach, so the answer must stay at its scope. EXP because it tests what the candidate actually did, not a general view |
| A3 | "What could a new person on my side do in the first month that would help your team, and what do you need from me?" | JD | [generic] | Reciprocity first: what you would give his team (shared definitions, a first pass at whitespace views he can challenge, early sight of the new lines' plans) as offers, then what you would need. Offers are proposals, not claims about your past | The reciprocity question a peer round almost always contains. JD because the role is explicitly cross-functional (F5); it makes no claim about the past |
| A4 | "Tell me about a time you had to bring other orgs to agreement." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story map with only the beats the sentence states: the annual volume targets, and consensus across orgs. Answer slot: the question asks where the orgs stood at the start; if they differed, say how and what you did; if they did not, or you were not the one who got agreement, say so plainly and stay with the targets and the consensus | The JD's influence line raises this as an open prompt; F5 is the one story in reach. EXP because it tests attribution under a second question |
| A5 | "You will depend on my team's pipeline data and I will depend on your whitespace work. How do we agree what counts as whitespace before either of us builds a model?" | CASE | [generic] | Structure: clarify what stages and accounts are in scope; agree definitions for each of land, adopt, expand and renew; agree which data source is authoritative for each; propose a small test where both of you compute a slice and compare. Everything here is a proposal you would make to him | The JD's whitespace line (F2) made live and seam-shaped, which is what a peer scores. CASE because it is a decision about method, not a past event |

### B. Data-Driven Prober (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You proposed a store-surface change credited with a ~$400M ARR uplift. Walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Lead with the sentence at its own scope, in your words: you proposed a store-surface change that was credited with a ~$400M ARR uplift. Answer slot: how the figure was counted. Say how, if you know; if you do not know how it was counted, say so plainly, because an honest "I don't know how that was counted" survives the next question and a method you cannot repeat does not | The headline metric on the profile is the first thing a self-described data-driven interviewer reads. F2 holds the quote. EXP because it tests the figure's provenance |
| B2 | "Which assumption behind that ~$400M would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The weakest-assumption move, before he asks. Answer slot: if you know the assumption you would defend least, name it in your own words, and say what the number is most sensitive to if you know that too; if you do not know how the figure was built, say so plainly and say what you would ask to find out. Never name an assumption you cannot back | The stem from the Prober persona. F2's figure raises exactly four slots: how counted, what it is sensitive to, the assumption defended least, and which part was yours |
| B3 | "The role runs independent analysis in SQL and Tableau. Walk me through one analysis you ran that way." | JD | [grounded] "skilled in SQL/Tableau" | Say what you used each tool for, in your own words. Answer slot: the question presumes an analysis you ran; if you ran one, say what question it answered and what was yours; if others did the analysis, or you used the tools differently, or there was no such analysis, say so plainly and return to "skilled in SQL/Tableau". Offer to walk through a real analysis only if one exists | F3 is a named JD requirement and the quote names tools only. JD because it scores the stated qualification; a Prober will test it first |
| B4 | "Your partner-level revenue model: what went into it, and what did you leave out?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold the sentence at its scope: you built a partner-level revenue model, and it was used in carrier negotiations. Answer slot: inputs and omissions. If you chose them, say which and how you decided; if they were set by others, or you do not remember, say so plainly and return to the quote. Name the weakest assumption in it only if you know it | F4's evidence, probed for method. EXP because the question tests what the candidate actually did inside the model |
| B5 | "The role finds whitespace across land, adopt, expand and renew. What data would you want before you trusted a whitespace number, and where would you distrust it?" | JD | [generic] | Structure aloud: define each stage with his team first; ask what usage, contract and renewal data exists for each of the two new lines; then name where you would distrust a figure (thin history on new lines, segment definitions that differ by team, anything counted twice across stages) and the assumption you would defend least. A method for the job, with no claim about your past | The JD's whitespace line (F2) as a data-quality probe, the Prober's native register. JD because it scores the stated responsibility, with CASE delivery |

### C. Skeptic (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your experience isn't classic sales ops or quota-setting. What does that cost this role on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." "set annual volume targets with cross-org consensus" "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | **Highest-ROI rehearsal in this pack.** Step 1, acknowledge first and plainly: "I don't have classic sales-ops or quota-setting experience." Step 2, hold only what the sentences carry: you set annual volume targets with consensus across orgs, after nine years in product strategy and ops. Do not let those targets become quotas in your wording. Step 3, concede the limit specifically and ask: "I'd want your read on how quotas are set here before I put forward a view." Step 4, the ramp, stated as a plan: sit with how quotas and pipeline are built and where they break, using his team's data, before proposing anything. Follow-ups to rehearse: what do you bring that I lack (answer from the quotes at their scope, with no claim of equivalence); would you trust my numbers (answer with the data-first plan); what if the gap is bigger than you think (concede specifically and keep the plan) | F7 is the one stated gap, and a peer in sales strategy is the person who owns that territory. JD because it scores a capability the role touches; Skeptic because it tests honest self-assessment, and it is why the pack names it first |
| C2 | "The JD asks for partner-motion design experience. Tell me about the closest thing you've done." | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story map from the sentence only: you built a partner-level revenue model, and it was used in carrier negotiations. Answer slot, inside the model's scope: if any of its inputs were yours to choose, say which and how you decided; if it was built to someone else's specification, or there was no such choice, say so plainly and return to the quote. Then say how you would learn how Northwind's partners work before designing anything, as a plan | The JD's required-experience line (F4) is the likeliest place the gap is named. The open prompt lets the honest branch say "closest thing" without claiming a design |
| C3 | "You'd own go-to-market for two new lines. Tell me about a time you took a product to customers." | JD | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Selection scaffold: pick an instance where your product strategy and ops work met how customers first found or bought something. It needs a named decision, what was yours, and a result you can source. If no such time comes to mind, say so plainly, then give the nearest thing your material carries (that you proposed a store-surface change credited with a ~$400M ARR uplift, at that scope) or how you would approach it | F1 is adjacent rather than direct. The JD's ownership line raises the open prompt, and the nearest quote is held at its own scope |

### D. Case / Strategist (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A much larger platform vendor is bundling a competing capability. You own go-to-market for one of our new lines. What do you need to know first, and what's your first move?" | CASE | [grounded] | Clarify first: which line, which segments the bundle actually reaches, and how our customers buy today. Then objective, segmentation, approach, metrics, risks. Use his pricing language: price against standalone value, packaging against the bundle, and where a partner motion helps or hurts. Challenge one premise respectfully (for example, that the bundle is equally relevant to every segment). A method only; it makes no claim about your past | Your research note names bundling by a much larger platform vendor as the main competitive threat. CASE because it is a live problem in the role's own vocabulary |
| D2 | "Compass is launching. How would you decide which customers get it first, and how does that connect to enterprise expansion?" | CO | [grounded] | Clarify first: is Compass one of the two new lines or a feature across both. Then criteria for sequencing (customer segments, expansion potential, readiness), the metrics you would watch, and the risk of crowding out the other line. Say you would test the sequencing with his data. A method only | Your research note names the Compass AI copilot launch and enterprise expansion as two of the three priorities, so this is the differentiator question. CO because it tests altitude on the company's own agenda; it also touches F6 |
| D3 | "Profitability is a stated priority. For one of the new lines, what would you want true about its unit economics before we scale go-to-market spend?" | CASE | [grounded] | Clarify the line and the time horizon first. Then name the economics you would want to see before scaling (what each acquired and expanded customer costs against what they pay and keep, and how long that takes), and the assumption you would defend least. Link back to his pricing instinct and ask what he would want to see | Your research note names reaching profitability as a priority, and a pricing-and-monetization interviewer will read this answer for fluency. CASE because it asks for reasoning and not for a past |

### E. Conversational (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with the sentence's beats only: two years of strategy consulting at a top firm, then nine years at a large consumer-tech company in product strategy and ops. Answer slot: the move toward go-to-market for new products. Give your actual reason, in your own words; if there was no single reason, say so and give the true one. The pack does not supply it | The opener of most conversations, and the one answer fully in your control. EXP because it checks the story against the CV; a peer will also hear the motivation in it |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say what you use and what you use it for, in your own words, keeping the verb at use. Answer slot: if any of it was building or shipping rather than using, say so; if it was only use, say so plainly. Then link to Compass only as a question about how he sees AI changing the sales workflow | The JD flags AI as a plus (F6), asked in the casual register that is still scored. JD because it checks the stated plus |

### G. Pressure (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you rather than someone who has set quotas?" | EXP | [grounded] "No classic sales-ops or quota-setting experience." "set annual volume targets with cross-org consensus" | Pause and restate the question. Concede the premise first, in a clause: "I don't have classic sales-ops or quota-setting experience." Hold the rest at the quotes: you set annual volume targets with consensus across orgs. Through two follow-ups, return to what the sentences say and do not add to them. Concede only what is true, specifically, and do not fold on the rest | The time-boxed form of C1, for the interview where the same objection arrives as a stress test. EXP because it tests what you can actually stand behind in sixty seconds |
| G2 | "That ~$400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold the sentence: you proposed a store-surface change, and it was credited with a ~$400M ARR uplift. Answer slot: which part was yours. Say what you did, in your own words; if you do not know how the credit was assigned, say so plainly. Hold through two follow-ups by returning to the sentence, never by adding to it | The attribution stem. F2 holds the figure; the verb is proposed and the credit is the figure's, and the answer must keep both |

### H. Values / Behavioral (2 questions)

No published values were read (the values search was refused) and no values-style round is established, so these are persona stems, not mapped stories.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time where the truth was unwelcome, the stake was named, and it landed. It needs what you said, to whom, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | A standard values stem; low weight, because no values round is established. VAL because it scores behavior, not content |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the customer's need and an internal number pulled apart. It needs the decision, the cost you accepted, and the outcome you can source. If no such time comes to mind, say so plainly, then give the nearest thing or how you would decide | A standard values stem that suits a buyer-facing product role. VAL for the same reason |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1: own GTM strategy for two new product lines | C3, D1, D2, D3, E1 |
| F2: identify whitespace across land/adopt/expand/renew | A5, B5 |
| F3: run independent analysis in SQL and Tableau | B3 |
| F4: partner-motion design experience required | B4, C2 |
| F5: strong cross-functional influence | A1, A2, A3, A4 |
| F6: AI experience a plus | E2, D2 |
| F7: sales-ops and quota-setting (role-family, not in the JD highlights) | C1, G1 |
| Headline metric (~$400M ARR uplift) | B1, B2, G2 |
| Values stems, no JD line behind them | H1, H2 — no JD requirement, and no values round is established |

## Reverse questions

| # | Question | Why it lands | Tied to |
|---|---|---|---|
| 1 | "You've worked through pricing and monetization roles and had an early-stage-startup chapter. What did that chapter change about how you think about sales strategy at Northwind's scale?" | It asks about his own path and turns an evaluation into a peer conversation | His path |
| 2 | "What could a new person on my side do in the first month that would genuinely help your team?" | The reciprocity question: it shows you are thinking about his load, not only yours | Peer relationship |
| 3 | "Where do your team's work and this role's overlap today, and which decision would you least want to be surprised by?" | It brings the seam to the surface and shows you would rather agree it than assume it | Seam with the role |
| 4 | "Which data would I most want access to in the first two weeks, and where is it least trustworthy?" | It speaks to a self-described data-driven interviewer in his own terms | His "relentlessly data-driven" self-description |
| 5 | "How is the bundling threat showing up in the deals your team sees now?" | It shows you read the competitive frame and asks for what only he can see | Your research note |
| 6 | "What would make you say in six months that this hire had been a clear success?" | It asks for the bar directly, and the answer tells you what the VP is likely to ask him | The role |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned go-to-market strategy for a product line | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says product strategy and ops, not go-to-market. C3's slot stays inside product strategy and ops |
| Has sales-ops or quota-setting experience | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| Treated the annual volume targets as quotas | Inflated form of F5 | F5's quote at its own scope: "set annual volume targets with cross-org consensus". The pack's observation: your material says volume targets, not quotas |
| Drove, delivered or generated ~$400M ARR | Inflated form of F2 | F2's quote at its own scope: "proposed a store-surface change credited with a ~$400M ARR uplift". The pack's observation: the material says proposed and credited, and does not say who credited it or how it was counted |
| Designed or owned partner motions | Inflated form of F4 | F4's quote at its own scope: "built a partner-level revenue model used in carrier negotiations". The pack's observation: the material says a model, not how any partner arrangement was structured |
| Ran analyses independently, start to finish, in SQL and Tableau | Inflated form of F3 | F3's quote at its own scope: "skilled in SQL/Tableau". B3's slot asks only what each tool was used for |
| Built or shipped AI products | Inflated form of F6 | F6's quote at its own scope: "uses AI tools daily". E2's slot keeps the verb at use |

## Sources

**Provided documents:** your message, covering the JD highlights, the candidate summary, the interviewer profile summary and the research note on Northwind's priorities. Its date was not given, so the research note is treated as current only as far as you vouch for it. No `tuesday-dossier.md` was present.

**Searches sent, all refused (permission to search was not granted):**

- `Northwind Data values` — refused
- `Northwind Data interview process strategy GTM` — refused
- `Dan Kovac Northwind Data Director of Sales Strategy` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Would have named the values, for a cheat sheet and VAL themes. Nothing moved: H1 and H2 are persona stems, and no values round is established |
| 2. `Northwind Data interview process GTM` | unavailable | Would have established the loop and persona weights. Weights rest on your description of one conversation with a peer |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note already supplies the three priorities and the main competitive threat, which fix D1 to D3. Its age is unknown |
| 4. `Dan Kovac Northwind Data` | unavailable | Would have added published talks and writing to the interviewer read. It rests on your profile summary only |
| 5. Representative Senior GTM Strategy Lead JD | skipped | Your JD highlights fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full JD text → F1 to F6 are quoted from your highlights, and mid-list requirements (a named tool or method) may appear in the full text; each would get a JD question and a row in the coverage table
- The recruiter's focus areas or any declared exercise → coverage assumed from the peer-round priors today; a declared exercise would get its own build section
- Dan's public talks, posts or interviews → a deeper interviewer read and likelier reverse questions, once search is permitted
- Northwind's published values page → H1 and H2 become value-mapped, if a values round appears in the loop
- Your own words on how the ~$400M was counted, what part was yours, and what you used SQL and Tableau for → F2 and F3 move from `low` and `discovery` toward `medium` and a stated story, and B1, B2, B3 and G2 get mapped answers
- The artifacts that raise a `medium` row to `high` in strategy and ops work: the partner revenue model file, the proposal memo behind the store-surface change with its ARR attribution, and a Tableau workbook → F2, F3 and F4 would be backed by something inspected
- Prep time available → a prioritized schedule for the days you have
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, offered once and needing search permission) → a strategy grounding brief and a firmer company picture for D1 to D3
- A `tuesday-dossier.md` from an earlier evidence review → verified evidence, an evidence-derived top objection and absolute prohibited claims, none of which this pack needs in order to stand
