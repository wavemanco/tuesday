I'll read the reference files the skill points to before building the pack.
Your prep pack is done and saved. I'm writing up the message that presents it now.
Femi, your prep pack is saved as `saltmarsh-games_live-operations-producer_interview_pack.md`. I built it for a hiring-manager round, since you gave Tobias's title but not how he relates to the role.

The host refused all four web searches, so nothing in the pack comes from research on Saltmarsh or Tobias. The company-knowledge questions (A5, B5) are generic, there is no interviewer read, and the persona weights rest on the hiring-manager default. The Sources section has the detail.

The pack has 18 questions across five interviewer styles. The one to rehearse hardest is B1, the in-app-purchase question: say "I haven't worked on a game with in-app purchases" plainly, then give a concrete plan for learning it. E2 comes second. It is the question on your four years against the JD's "3+ years", and your note dates the content-drop calendar at only two of those four years.

Every answer sticks to your own sentences. Where the JD asks for something your note doesn't show, such as which teams the drops involved or who produced the retention numbers, the guidance tells you to answer from your real experience or say plainly it wasn't yours.

Say the word and I'll play Tobias as the Skeptic on B1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Two questions would change the pack:
- Is Tobias the person you'd report to, or a level above? That reweights the banks.
- Has the recruiter named any focus areas or asked you to prepare anything? That could add a build section.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

- **Candidate:** Femi
- **Interviewer:** Tobias Wrenfield, Head of Live Operations (title as you gave it)
- **Round:** one 60-minute interview, on Friday. Built as a hiring-manager round, because your note gives Tobias's title and not how he relates to the role. If he is a level above the person you would report to, the weights in section 3 change.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what the question is scored on. Every question carries one of each, so you can see your coverage at a glance.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values. No question here carries it, because no values-style round was detected |
| EXP | Whether your own account of your work holds up: what you did, and how much of it was you |
| JD | Whether you can do the listed job, including the parts your material carries least |
| CO | Whether you know the company and can think at its altitude |
| CASE | A live problem from the actual role: clarify, structure, then answer |

Guidance is scaffolding, not a script. Wherever a guidance cell says "answer slot", it is an instruction for the interview: answer it from your own experience, in your own words, and if the practice was not yours or never existed, say so plainly and return to what you did do. Both branches are good answers.

The highest-ROI prep in this pack is **B1**, the in-app-purchase question. It will be asked in some form, and a calm, specific answer changes the interview. Second is **E2**, the question on your four years against the JD's three-plus.

## 2. Fit snapshot

Each requirement is quoted from the JD you supplied. Each evidence cell holds your own sentences from your message, word for word, and nothing else. F9 and F10 are role-family requirements the JD does not state. They are written as plain prose and labeled `[generic]`, and they raise no answer slots.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The material gives four years as an associate producer and two years of the calendar. The pack's observation is that it does not say whether the title was run as a live service, and that it dates the calendar at two of the four years. Answer slot: expect a probe on the years the quotes do not date. If the years before the calendar involved work on the same title, say what in your own words; if not, say so plainly and stay with the four years and the two years of the calendar as you stated them |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you ran the weekly content-drop calendar for your main title, for the last two years. The artifact that would raise the band is the calendar itself, an export or screenshot of it |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | The material says a weekly content-drop calendar for one main title, and the words stay at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: expect a probe on what the weekly drops contained. If any of the drops were time-limited events, say which in your own words; if none were, say so plainly and stay with the weekly drops |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | The material does not show which teams the weekly drops involved. Answer slot: the JD names four teams, so expect a probe on each. If the drops involved any of them, say which and what part of the coordinating was yours, in your own words; if you did not work with a team, or the coordinating was someone else's, say so plainly and stay with the calendar you ran |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | The material says presented, not owned: the pack's observation is that who produced the numbers, and what came before the presenting, are not shown. The words stay at: "Presented the monthly retention numbers to the studio head." Answer slot: expect a probe on what came before the presenting. If you produced or interpreted any of the numbers, say which in your own words; if you only presented them, say so plainly and stay with presenting |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Lead with it as stated: you wrote the release checklist, and your QA team still uses it. The words stay at wrote and still uses |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe on the numbers themselves. Lead with it in the quote's terms: you presented the monthly retention numbers to the studio head. The artifact that would raise the band is the monthly report or deck itself |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [grounded] | discovery | The quote shows something written and still in use. It does not show how clear it is or what else you have written. Answer slot: expect a request for an example. If there is a piece you could show or describe, say what it was for in your own words; if there is none, say so plainly and stay with the checklist as the thing you wrote |
| F9 | leading a team, a role-family requirement the JD does not state | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [generic] | capability | You stated the absence. Words: "I haven't led a team." Then a plan, said as a plan and never as a past: how you would work across four disciplines without having led one. The pack's reading is that the JD says coordinate, and does not say lead |
| F10 | monetized live-event work on a mobile title, meaning in-app purchases, a role-family requirement the JD does not state | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [generic] | capability | You stated the absence. Words: "I haven't worked on a game with in-app purchases." Then a plan, said as a plan and never as a past: who you would ask and what you would learn first. Nothing added to make the gap feel smaller |

No requirement is a gate: "3+ years" is a length-of-experience requirement, graded like any other row.

## 3. Persona table

Weights come from three passes. The relationship prior for a hiring manager is Case/Strategist plus Skeptic. No interviewer public footprint was available, so no signal adjusts it. Your own words establish the loop as one 60-minute session with Tobias, and name no values round, so none is detected. Persona weights therefore rest on the hiring-manager prior you can recalibrate, not on a documented Saltmarsh process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the role: plan a calendar, diagnose a retention dip, resolve a dependency slip | High. It is the hiring-manager prior, and the JD is mostly a list of things to plan and run | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully (A1 to A5) |
| Skeptic | Quiet, persistent probing of the stated gaps: in-app purchases, never having led a team, associate to producer | High. It is the second hiring-manager prior, and you have stated two gaps outright | Rehearse B1 until it is boring. Say the limit plainly, then a plan. Never bluff a competency (B1 to B5) |
| Data-Driven Prober | Reads your lines closely and asks how the retention numbers were counted | Medium. The JD asks for comfort with retention metrics, and you presented them monthly | Know what you can and cannot say about each number. Say plainly what you do not know (C1 to C3) |
| Conversational | A friendly opener, then casual questions that are still scored | Medium. The session is a 60-minute conversation, which leaves room for an opener, and the JD asks for written communication | Have a 90-second arc built only from your own sentences. Treat casual questions as scored (E1 to E3) |
| Pressure | Interrupts, time-boxes, asks how much was actually you | Low. Nothing in your material points to a stress format, but attribution probes are asked politely too | Pause, restate, hold the quote through two follow-ups, concede specifically (D1, D2) |
| Peer Evaluator | Seam-splitting between adjacent teams | Low. Tobias's title is a head of function, and no peer relationship is stated. No bank is written | If the relationship turns out to be a peer, say so and the pack regenerates with this bank |
| Values/Behavioral | Scenarios mapped to published values | Low. No values round is named in your words, and no published values were available this session. No bank is written | None needed unless a values round turns up |

## 4. Question banks

Types are one token each. Where a question has JD content and CASE delivery, the rationale says so.

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You take over the live-events calendar for two mobile titles next month. What do you need to know first, and what do you do in your first two weeks?" | CASE | [generic] | Clarify before structuring: what each title is trying to achieve right now, what the current cadence and event types are, who is on the team and what each discipline needs from you, and what the release process already is. Then the objective, what you would look at in the numbers, your first moves and your risks. Say your structure aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The JD's calendar line (F3) asked as a decision rather than a record. CASE because it scores clarify-then-structure, and `[generic]` because it is a pattern for the problem, not a fact about this employer |
| A2 | "Suppose an event ships and day-7 retention for players who joined during it comes in below the usual range. Diagnose it." | CASE | [generic] | Clarify what below means: against which baseline, how many players, how noisy the figure normally is. Then segment (new versus returning, platform, install source), check what else changed in the same window, say what you would do before the next event, and say how the post-event review would report it. Name the assumption in your diagnosis you would defend least before they do. The question needs no claim about your past | Retention (F7) and the post-event review (F5) turned into a live problem. CASE because it scores diagnostic structure, with JD content |
| A3 | "Design says the update date is fixed, art says the event's main asset lands a week late, and engineering says a slip breaks the release. You own the calendar. Walk me through it." | CASE | [generic] | Clarify first: what the asset is for, what depends on it, what each team can and cannot move. Then the options (cut scope, ship a reduced version, move the date, change what the community is told), the trade-off in each, who you would decide with, and what you would record afterward. Say which decision you would not take alone. The question needs no claim about your past | The four-team coordination line (F4) asked as a decision. CASE because the scoring is structure under competing constraints, with JD content |
| A4 | "How would you structure the post-event review for a live event, and which KPIs would it report?" | CASE | [generic] | Structure it: what the event was meant to change, the comparison you would use, the few measures you would report and why, what the review would decide, and who needs to read it. Say which numbers you would not trust yet. If the studio already reports KPIs, ask which before proposing yours. The question needs no claim about your past | The review-and-KPIs line (F5) asked as design rather than history, which is safer ground for you than a history question. CASE with JD content |
| A5 | "Which of our games have you played, and what would you change about how their events run?" | CO | [generic] | The pack could not research Saltmarsh, so this answer has to be your own homework before Friday: open the studio's titles, note what events appear and how they are presented, and decide what you would ask rather than assert. In the room, say what you saw, offer one observation framed as a question, and if you have not played them, say so plainly and say what you would look at first. The question needs no claim about your past | The one company-knowledge question, kept generic because company research was unavailable. CO because it scores homework depth |

### B. Skeptic (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked on a game with in-app purchases. Which part of this job does that cost you on day one?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment the quote supports: "I haven't worked on a game with in-app purchases." Then say, as a plan and never as a past, how you would learn it: who you would ask, what you would look at in this studio's own titles, and what you would want explained before you touched anything that depends on it. Do not reach for a near substitute from puzzle-game work. Expect a ladder: "So who teaches you?", then "What if your first event under-delivers?" Answer each as a plan. Hold by repeating the acknowledgment and the plan, never by adding experience. Concede specifically: "I haven't worked on a game with in-app purchases, so in my first weeks I would ask before I decided anything that depends on it." | F10 is the largest gap you stated and the one a Skeptic reaches first. EXP because it scores honest self-assessment against what you told me |
| B2 | "You haven't led a team, and this role coordinates design, art, engineering and community on every update. Where do you expect that to be hardest?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Acknowledge once, in the quote's words: "I haven't led a team." Then give your own view of where coordinating across four disciplines gets hard and what you would need from each. Answer slot: the JD names four teams, so expect a probe on which ones the weekly drops involved. If any, say which and what part of the coordinating was yours; if none, or it was not yours, say so plainly and stay with the calendar you ran | F9 and F4 together: the stated gap meets the JD's coordination line. JD because it scores the listed responsibility |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] | Pick one, from the thinnest rows of your own snapshot: F3, F4, F5 or F10. Name it, say in plain terms why it is the weakest, and give the first thing you would do about it, as a plan. Do not offer a strength dressed as a weakness. If none of those rings true, say so plainly and pick the row your own material carries least. The guidance makes no claim about your past | The standard Skeptic stem, answered from the snapshot so the choice is made before the room. JD because it scores the JD's gaps |
| B4 | "You've run weekly content drops as an associate producer. This is a producer role running live events for two titles. What changes?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Hold what the quotes carry, at their scope: four years as an associate producer at a puzzle-game studio, and the weekly content-drop calendar for your main title for the last two years. Then say, as your own view, what you expect to be different in the producer role. Do not describe the difference as one you have already crossed. Answer slot: expect a probe on what the weekly drops contained. If any were time-limited events, say which in your own words; if none were, say so plainly and return to the calendar | F1 and F3: the step in scope and level. JD because it scores fit to the stated role |
| B5 | "Why mobile live operations, why this studio, and why now?" | CO | [generic] | Motivation has to be your own and the pack cannot supply it. Give the real reasons in order: what draws you to live operations, what you have seen of the studio's games that draws you here, and why now. The studio-specific part needs your own look at the titles, since the pack could not research them. If you have no studio-specific reason yet, say so plainly and give the reason you do have. The guidance makes no claim about your past | The Skeptic's motivation-consistency probe. CO because the studio-specific half scores homework, and `[generic]` because the pack has no researched fact to put in it |

### C. Data-Driven Prober (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented. Which ones, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | The beats the quote states: monthly, the retention numbers, to the studio head. Then the defend-the-number slots, each in your own words: which numbers they were, how each was counted, what it is sensitive to, the assumption behind it you would defend least, and which part of the work was yours. If you do not know how a figure was counted, say so plainly rather than reconstructing it. Name the weakest assumption before they ask | F7 is the evidence for the retention requirement and the likeliest place to be probed. EXP because it tests what you actually know about the numbers |
| C2 | "The role owns the post-event review and the KPIs it reports. What has been yours: producing the numbers, interpreting them, or presenting them?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Hold to the quote: "Presented the monthly retention numbers to the studio head." Answer slot: if you produced or interpreted any of the numbers, say which and how, in your own words; if you only presented them, say so plainly and say how you would take on the rest. Hold through two follow-ups by returning to the presenting, never by adding to it | F5 is where the JD's ownership language presses hardest on your material. JD because it scores the stated responsibility |
| C3 | "Tell me about the release checklist you wrote. How does QA use it today?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | The beats the quote states: you wrote it, and your QA team still uses it. Answer slot: expect a probe on how QA uses it today. If you know how, say so in your own words; if you do not, or it is not something you saw, say so plainly and stay with having written it. Do not describe its contents unless they are yours to describe | F6 is a strong line, so it will be probed for detail. EXP because it tests whether the line survives a second question |

### D. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause, restate the question, then hold the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Hold through two follow-ups by returning to it, never by adding. Concede specifically from your own knowledge where the limit is. Answer slot: if some parts of running it were yours to decide, say which; if they were set by someone else, or shared, say so plainly and stay with running the calendar | F2 and F3 rest on this one sentence, so an attribution probe lands here. EXP because it scores attribution under pressure |
| D2 | "Sixty seconds: why you over someone who has already run monetized live events for two games?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." "Never led a team, and never worked on a game with in-app purchases." | Time-box it: concede first, then hold. Concede in the quote's words: "I haven't worked on a game with in-app purchases." Hold on what the quotes carry, each at its own scope: you ran the weekly content-drop calendar for your main title for the last two years, wrote the release checklist your QA team still uses, and presented the monthly retention numbers to the studio head. Then stop. Do not argue you are the better candidate, and do not claim the missing experience under another name | F9 and F10 are the stated gaps, so the comparison question lands on them. JD because it scores fit against the listed role, in the Pressure register |

### E. Conversational (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey. How did you get here?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc built from those four sentences and nothing else: four years as an associate producer at a puzzle-game studio, then the calendar for your main title for the last two years, the checklist your QA team still uses, and the retention numbers you presented. The order is yours. Use "I" for what you did and "we" for context. End on why this role, in your own words. Do not add scope, team sizes or outcomes | The opener is scored even when it feels casual. EXP because it is the first test of whether your account is consistent with your lines |
| E2 | "The role asks for three or more years producing live-service games or apps. How do your four years line up?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Say both at their scope: four years as an associate producer at a puzzle-game studio, and the weekly content-drop calendar for your main title for the last two years. The pack's observation is that the quotes date the calendar at two of the four years, so expect the probe to land on the other two. Answer slot: if the years before the calendar involved work on the same title, say what in your own words; if not, say so plainly and stay with the four years and the two years of the calendar as you stated them | F1 is the years requirement and the second-highest-ROI prep. JD because it scores the first line of the JD's requirements |
| E3 | "What's a piece of writing of yours you'd want me to read, and why?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | An open prompt, so choose the instance. Pick a piece you could show or describe; the release checklist you wrote is one candidate, not the only one. Say what it was for and who read it, in your own words, and why you chose it. If you have nothing you could show, say so plainly and name the checklist as the thing you wrote. Do not describe how it was received unless you know | F8 is the thinnest row on a stated requirement. JD because the JD lists written communication, asked here in a casual register |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "3+ years producing live-service games or apps" | E2, B4, E1 |
| "experience running a content calendar" | D1, B4, E1 |
| "Plan and run the live-events calendar for two of our mobile titles" | A1, B4, D1 |
| "coordinate design, art, engineering and community teams on each update" | A3, B2 |
| "own the post-event review and the KPIs it reports" | A4, C2, A2 |
| "manage the release checklist with QA" | C3 |
| "comfortable with player-retention metrics" | C1, A2 |
| "clear written communication" | E3 |

## 5. Reverse questions

No interviewer profile was available, so none of these is tied to Tobias's own career path. Asking the third one aloud is the honest way to turn your stated gap into a conversation.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would you want to have seen from this role by the end of the first month, and by the end of the third?" | It asks what success looks like in his terms and tells you what you would be measured on |
| R2 | "Which of the two titles has the harder calendar to run right now, and what makes it hard?" | It shows you think per title, and it surfaces what you would be handed first |
| R3 | "How do events connect to monetization in your titles today, and who on the team owns that side?" | It names your stated gap as something you are already learning, rather than something you hope goes unasked |
| R4 | "How is a post-event review run today, which KPIs does it report, and what would you want to change about it?" | It shows you want to own the review and its numbers properly, and it tells you where the role starts |
| R5 | "How does the release checklist work between the producer and QA today?" | It follows the JD's own line and shows you care about the mechanics, not only the calendar |
| R6 | "Where do producers here get stuck when coordinating design, art, engineering and community, and what helps most?" | It turns the coordination question into a request for a practical lesson, which suits someone who has not led a team |

## 6. Prohibited claims

What this pack will not coach, and why. Built before the banks were written, so the banks are written against it.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated, F9 | F9's quote at its own scope, and the plain acknowledgment it supports: "I haven't led a team." No answer slot |
| Worked on a game with in-app purchases, or on monetization | Negative you stated, F10 | F10's quote at its own scope, and the plain acknowledgment it supports: "I haven't worked on a game with in-app purchases." No answer slot, and no substitute from puzzle-game work |
| Owned the post-event review or its KPIs | Inflated form of F5 | F5's quote at its own scope: "Presented the monthly retention numbers to the studio head." The limit is the pack's observation: the material says presented, not owned. C2's slot stays inside the numbers |
| Ran a live-events calendar, or the calendars for two titles | Inflated form of F3 | F3's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The limit is the pack's observation: the material says one main title and weekly content drops |
| Produced live-service games for four years | Inflated form of F1 | F1's quotes at their own scope: "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." The limit is the pack's observation: the calendar is dated at two of the four years |
| Managed releases with QA | Inflated form of F6 | F6's quote at its own scope: "Wrote the release checklist our QA team still uses." The limit is the pack's observation: the material says wrote and still uses, not who ran releases. C3's slot stays inside the checklist |

## 7. Sources

**Provided documents:** the JD text you pasted, and your background as you wrote it in your message. No `tuesday-dossier.md` was present. No documents came from the company.

Searches sent, every one refused by the host (the permission to search was not granted), so nothing came back and nothing from them is used:

- `Saltmarsh Games company values` — refused
- `Saltmarsh Games interview process live operations producer` — refused
- `Saltmarsh Games mobile studio strategy news` — refused
- `Tobias Wrenfield Saltmarsh Games` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have fed a values cheat sheet and any VAL questions. Neither is in this pack, and no values round was detected from your words |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have named the real rounds and set persona weights from them. Weights rest on the hiring-manager prior and your own description of one 60-minute session instead |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Would have grounded A5 and B5 in current strategy. Both are `[generic]` and say so |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have produced an interviewer read and a reverse question tied to his path. Both are absent, and the upgrade menu says what a profile would unlock |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and every JD-tagged question |

## 8. Upgrade menu

- **Search access in this session** → the four rows above, run again: a values and process read, a strategy brief, and Tobias's public professional footprint. That would turn A5 and B5 from `[generic]` to `[grounded]`, add a tailored reverse question, and replace the hiring-manager prior with a documented loop where one exists
- **A deeper research pass (offered once)** → up to 6 further searches and 2 further fetches, several more minutes, covering a strategy brief, deeper interviewer footprint, loop reports and recent org context. It needs the same search access
- **Who Tobias is to the role** (your future manager, or a level above) → the persona weights in section 3 and the depth of banks A and B are recalculated
- **The recruiter's guidance** (focus areas, anything you are asked to prepare, how the 60 minutes is split) → coverage stops being assumed from the round-type prior, and a prepared piece would get its own build section
- **Your answers to the answer slots** (F1, F3, F4, F5, F8) → those rows move from discovery or transferability toward `none` or `presentation`, and the matching guidance (B2, B4, C2, E2, E3) becomes story-mapped
- **Your full CV, or the exact sentences you would put there** → every evidence cell now rests on a one-sentence summary you gave me, so more quotes raise most rows' coverage
- **The inspectable artifacts for this field** → the calendar itself (F2, F3), the monthly retention report or deck (F5, F7) and the checklist (F6, F8) are the artifacts that would raise `medium` to `high`
- **How many hours you have before Friday** → a prioritized prep schedule, naming the few questions worth doing well and treating the rest as insurance
- **A `tuesday-dossier.md` from an earlier evidence check** → verified evidence rows and allowed strategies for each weak area would replace the ones this pack inferred, and the objection it rehearses most would be the dossier's own
