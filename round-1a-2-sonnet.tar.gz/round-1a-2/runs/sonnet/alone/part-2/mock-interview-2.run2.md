I'll read the skill's reference files before building the pack.
Your prep pack is saved as `atlas-freight_operations-manager_interview_pack.md`. I built it with flat persona weights because you didn't say who is interviewing. Company research didn't run, because the three searches were refused, so nothing about Atlas beyond your JD is in it.

The pack's highest-ROI prep is A2: going from three supervisors to twelve across four sites. Its guidance holds to your "3 supervisors" quote and concedes the size difference. The Power BI gap gets a plain acknowledgment and a plan, with nothing added to soften it.

Say the word and I'll play the Skeptic on A2 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting (recruiter, hiring manager, peer or a panel), and has the recruiter given you any focus areas? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview pack: Operations Manager, Atlas Freight

Interviewer and relationship: not given. Built as a full-loop pack with flat persona weights, tilted only by the gaps in the fit snapshot. Telling me who you are meeting reweights every bank.

## How to use this pack

- **Personas are how a question is asked; types are what it scores.** The same gap arrives as a quiet probe, a time-boxed challenge or a friendly aside, so each bank rehearses the delivery as well as the content.
- **Guidance is scaffolding, not a script.** Say it in your own words. Every sentence about your past comes from something you told me, quoted next to the question. Where the material is silent, the cell is an answer slot.
- **An answer slot is an instruction for the interview, not a question for now.** Meet it with either honest branch: say what you did in your own words, or say plainly it was not yours or did not exist, then return to what you can stand behind. The second branch is a limit, not a confession.
- **Highest-ROI prep: A2**, the step from three supervisors to twelve across four sites. It will be asked in some form. Rehearse it until it is boring.

Type key:

| Tag | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the behavior, not generic virtue |
| EXP | Work-experience deep-dive: do your claims survive scrutiny, and what was actually yours |
| JD | Role or JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Live problem from the role: structure and reasoning |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution operations and a surge plan for "the site", not terminal operations or a second site, and the words stay at that scope: "I ran the site's peak-season surge plan two years running." Answer slot: the four-site line makes a probe on multi-site and terminal work likely. If any of your work touched more than one site or a freight terminal, say which and what part was yours; if none did, say so plainly and stay with the site you ran the plan for |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material gives a mis-pick figure, a different measure from the two the JD names, and the words stay there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked any other measure at your site, say which, how it was counted and what was yours; if none, say so plainly and stay with the mis-pick figure. Defending the figure itself is B1 |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The JD's twelve sits beside your quoted three, and the words stay at three: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have led or coordinated more than three supervisors, in this role or an earlier one, say how many and what part was yours; if not, say so plainly and return to the three |
| F4 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" names a skill and does not show whether reports were built with it. Answer slot: if you built reports in Excel, say what they covered and who used them, in your own words; if your Excel work was something else, say that plainly |
| F5 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan in the future tense and never as a past. Nothing added to make the gap feel smaller. The JD lists Excel and Power BI together, which is the pack's observation about the posting and not a claim for you |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your material gives seven years in operations, not how many of them were leadership. A length-of-experience line, graded here like any other row and not a gate. Answer slot: say how many of the seven years you supervised or managed others, and in what role; if that portion is shorter than the posting's five, say so plainly and hold what the quotes carry |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap on the requirement, but a certification line with nothing inspected behind it (the certificate is the artifact that would raise this), so expect a probe. Lead with it in its own terms: "I'm green belt certified." |

## Persona table

No source established Atlas Freight's rounds, so the weights rest on the Generic archetype (flat), tilted by the gaps above. They reset once you tell me who you are meeting.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of scale and background | Highest (5 questions). F1 and F3 are the widest gaps between your quotes and the JD, and F5 is a stated one | Rehearse A2 until it is boring; bridges only from the quotes the rows carry; a ramp plan said as a plan |
| B. Data-Driven Prober | Reads claims line by line; asks how each number was counted | High (4). F2 holds your only figure, and B2 and B3 probe the other two stated results | Know what you can and cannot say about how the figure was counted; say plainly when you do not know |
| C. Case / Strategist | Live problems from the role: diagnose, plan, design | High (4). A manager-level role with on-time, cost and reporting lines (F2, F4) invites live problems | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| D. Pressure | Interrupts, time-boxes, questions motives | Medium (3). F3 and F5 are natural pressure targets | Pause, restate, hold through two follow-ups, concede specifically and never fold on the core |
| E. Conversational / Rapport | Friendly, unstructured, still scored | Medium (3). Casual openers about your journey and Lean/Six Sigma (F7) are likely in any round | A 90-second arc built only from your quotes; treat casual questions about JD topics as scored |
| G. Values / Behavioral | Scenario probes: unpopular truths, customer over metric | Lower (2). No source shows a values-style round, so this is insurance | Pick stories with a named stake and an intact relationship, or say plainly none comes to mind |
| H. Peer Evaluator | Seam-splitting, credit, disagreement with equals | Lower (2). Unknown relationship, and a four-site role touches peers | Reciprocity framing; propose principles, not a seam you have not seen |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Name one real gap first, before they do, in plain words. The quote gives one you can say as it stands: "I've never used Power BI." Follow it with how you would learn it, as a plan in the future tense, with no step you have not actually taken. Then stop. If a bigger gap than the tool comes to mind, that is the better answer | F5 is the one gap your material states outright, so it is the safest to name first. JD because it scores the stated list; the Skeptic stem asks for the weakest point |
| A2 | "Today you're over three supervisors; this role has twelve across four sites. What makes you ready for that step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I'm currently a senior shift manager over 3 supervisors." Concede the size difference plainly, since the question's own numbers set it up, and do not argue it away. Answer slot: the posting's twelve supervisors across four sites makes a probe on scale likely. If you have led or coordinated more than three people or worked across more than one site, say which and what part was yours; if not, say so plainly and return to the three. Then give your ramp as a plan. Hold through two follow-ups by returning to the three, never by adding to them | F3 is where the role's scope presses hardest and F1 compounds it with four sites, so this objection arrives in some form. JD because it scores the team-size requirement; delivered as a Skeptic probe |
| A3 | "Your background is warehouse and distribution; this job owns terminal operations across four sites. What's different, and what would you learn first?" | JD | [grounded] "7 years in warehouse and distribution ops" | Start with the quote as it stands: "7 years in warehouse and distribution ops." Answer slot: if any of that work touched freight terminals or more than one site, say which and what part was yours; if none did, say so plainly. Then your first learning priorities, said as a plan; you pick them, because the pack does not know the terminals | F1 is the kind of gap, warehouse against terminal, a skeptic tests first. JD because it scores the first requirement; the learning half tests honest self-assessment |
| A4 | "What's drawing you from a shift manager role to this one?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors" | Selection scaffold, since only you can give your reasons: one reason tied to the role as the posting states it (daily ownership, four sites, twelve supervisors, reporting), and one that is not a complaint about your current job. If no reason beyond "the next step" comes to mind, say that plainly and say what the step involves | The why-leave, why-here probe is standard for a Skeptic and reads as consistency. EXP because it tests whether the move story fits the career; F3 is the step it is about |
| A5 | "The posting asks for 5+ years of operations leadership. How many of your seven years was that?" | JD | [grounded] "7 years in warehouse and distribution ops" | Answer slot: say how many of the seven years you supervised or managed others, and in what role, in your own words; if that portion is shorter than five, say so plainly and hold what the quotes carry. Do not stretch the seven into a leadership figure | F6 is a discovery row: the number that answers this is not in the material. JD because it scores the stated years requirement; a literal screen on it is possible |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say it as the quote has it: "I cut mis-pick rate 40% by redesigning the pick path." Then four answer slots, each in your own words: how it was counted, what the figure is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how something was counted, say so plainly. The pack supplies none of the four | F2 holds the only figure in your material, so it is the likeliest target. EXP because it tests counting and attribution |
| B2 | "Tell me about the peak-season surge plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Beats the quote states: a peak-season surge plan, the site's, run two years running, told in your own words. Answer slot: the posting's performance line makes a probe on results likely. If you tracked any outcome of the plan, say what and how it was counted; if no outcome was tracked, say so plainly and describe what you ran | F1 draws on this quote for ownership of operations. EXP because it tests what you actually ran and what it produced |
| B3 | "What did redesigning the pick path involve, and who else was in it?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Describe the redesign in your own words at the quote's scope: you redesigned the pick path. Answer slot: if others worked on it, say who and what each did; if you did it alone, say that; if someone else decided parts of it, say which. Add no step the quote does not carry | F2's attribution probe in collegial packaging. EXP because it tests what was yours |
| B4 | "The posting's two headline measures are on-time performance and cost-per-shipment. What do you track at your site?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: the posting's two headline measures make this probe likely. If you track any measure at your site besides mis-pick rate, say which, how it is counted and what was yours; if none, say so plainly and stay with the mis-pick figure, saying it is the figure you have | F2's transferability gap, rehearsed so the honest answer is ready. JD because it scores the stated measures |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Peak season is three weeks out and on-time performance at one of the four sites has slipped. What do you need to know first, and how do you structure the first week?" | CASE | [generic] | Clarify first: what slipped, where, since when. Then objective, segmentation by site, shift and period, approach, metrics, risks. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's on-time line (F2). `[generic]` because it is a pattern for the problem, not a fact about this employer |
| C2 | "Cost-per-shipment is rising at one site but not the others. How do you diagnose it?" | CASE | [generic] | Define the measure before diagnosing: what is in the cost and what is the denominator. Compare the sites, split volume effects from cost effects, rank hypotheses, name the cheapest test for each. Say what data you would ask for | A live problem from the JD's cost line (F2). CASE because it scores structure over the right answer |
| C3 | "You take over twelve supervisors across four sites, and results vary widely between sites. What are your first thirty days?" | CASE | [generic] | Listen before changing: what each site's results are and how supervisors are measured. Set one common standard, hold one-to-ones, pick one early change you can verify. Make no claim about having done this | A live problem from the JD's team line (F3). CASE because it tests how you would step up to the scale in A2 |
| C4 | "Design the weekly reporting pack for the four sites. What goes in it, and what tool do you build it in?" | CASE | [grounded] "solid Excel"; "never used Power BI" | Structure: who reads it and what decisions it serves, then measures, cadence and definitions, then tool. On the tool, say Excel as the quote has it, "solid Excel", and Power BI plainly: "I've never used Power BI," then the plan. Answer slot: if you built reports in Excel, say what they covered and who read them; if not, say so plainly and design it as a plan | F4 and F5 are the reporting rows. CASE because the design is live; JD content in a case delivery |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate. Hold what the quote states: you redesigned the pick path and the rate fell 40%. Answer slot: say which parts were yours and which were others', in your own words; if you cannot separate them, say so plainly. Hold through two follow-ups; concede a specific uncertainty ("I don't know how X was counted") rather than the core | F2's attribution probe in its sharpest form. EXP because it tests attribution under pressure |
| D2 | "Sixty seconds: why you over someone who has already run multi-site terminal operations?" | JD | [grounded] "7 years in warehouse and distribution ops"; "green belt certified" | Pause, restate, then build only from the quotes: "7 years in warehouse and distribution ops," "green belt certified." Concede only what the question sets up, that the other candidate has run multi-site terminals, and say how you would close it, as a plan. Do not claim to be better; hold your own ground | F1, F6 and F7 are the evidence it can draw on. JD because it scores fit against the posting; Pressure because of the time box |
| D3 | "The posting lists Power BI and you've never used it. Why isn't that a problem?" | JD | [grounded] "never used Power BI"; "solid Excel" | Pause. Plain acknowledgment: "I've never used Power BI." Then your plan to learn it, in the future tense. Excel at its own scope: "solid Excel." Do not claim the two are equivalent. Answer slot: if you built reports in Excel, say what they covered; if not, say so plainly. Hold through two follow-ups; concede what you do not yet know | F5 is a stated gap and F4 the adjacent skill. JD because it scores the reporting requirement |

### E. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | A 90-second arc with two fixed points from your quotes: "7 years in warehouse and distribution ops," and "currently a senior shift manager over 3 supervisors." Answer slot: the middle, which roles you held between and in what order, is yours; say it in your own words and keep to the roles that bear on the posting. End on why this role | F6 and F3 give the two ends of the arc. EXP because it is the biography question, scored for economy |
| E2 | "Tell me about your Six Sigma training — how do you use it day to day?" | JD | [grounded] "green belt certified" | Lead with it in its own terms: "I'm green belt certified." Answer slot: the posting's Lean/Six Sigma line makes a probe on application likely. If you have applied it, say where and how; if the pick-path redesign was run as a belt project, say so, and if it was not, say so; if you have not applied it, say so plainly | F7 is the plus-skill, asked casually. JD because it scores the stated plus |
| E3 | "Why logistics, and why Atlas?" | CO | [generic] | Selection scaffold: two reasons only you can give. For Atlas, use only what the posting states: regional logistics, 800 employees, four sites. The pack holds nothing else about them, so do not invent knowledge of their strategy. If you have researched them, bring one fact you can source. If no Atlas-specific reason comes to mind, say what the role itself draws you to | The CO question any round can open with; `[generic]` because no company research ran, which the upgrade menu addresses |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time where the truth was unwelcome, you said it anyway, and the relationship was intact afterwards. It needs a named stake, the moment you said it and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A standard values stem; no source shows a values round here, so it is insurance. `[generic]` because none of your quotes carries this story |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Same scaffold: a specific decision, the metric it cost, the customer outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A standard values stem, insurance for the same reason |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Four sites will compete for the same people and equipment at peak. How do you decide, and how do you handle a supervisor who disagrees?" | CASE | [generic] | Principles over a seam you have not seen: state the decision criteria before the decision, share the data, give the disagreeing supervisor a route to be heard, record the call. Make no claim about having done it | F1 and F3 together make this a likely seam question. CASE because it is a live problem |
| H2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | We for context, I for contribution. Say what the quote says is yours, the redesign and the figure as stated. Answer slot: if others contributed, name what they did; if you did it alone, say so plainly | A peer credit-sharing probe aimed at F2. VAL because it scores collaboration behavior |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A3, B2, C1, C2, H1 |
| "drive on-time performance and cost-per-shipment down" | B1, B4, C1, C2 |
| "lead a team of 12 supervisors" | A2, C3, H1 |
| "build reporting in Excel/Power BI" | A1, C4, D3 |
| "5+ years operations leadership required" | A5, E1 |
| "Lean/Six Sigma a plus" | E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would on-time performance and cost-per-shipment need to look like at each site a year from now for you to call my first year a success?" | Turns the posting's headline measures into the scoring sheet and shows you think in outcomes |
| 2 | "How are the twelve supervisors spread across the four sites today, and where is the bench thinnest?" | Shows scale-up thinking and surfaces the real size of the step in A2 |
| 3 | "What does reporting look like across the sites today: which tools, and who builds it?" | Reporting is a posting line; the answer shows where Power BI sits without you having to raise it |
| 4 | "What is the hardest operational problem at the terminals right now?" | Moves the conversation from your background to a live problem |
| 5 | "Is there anything about my background you would want me to address before we finish?" | Invites the objection while you are in the room, so you answer it rather than lose to it |
| 6 | "If you are a peer on the team: what could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer round; skip it otherwise |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned daily terminal operations across multiple sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: the material says warehouse and distribution and the site's surge plan |
| Drove on-time performance or cost-per-shipment down | Inflated form of F2 | F2's quote at its own scope: the mis-pick figure. The limit is the pack's observation: the material gives a different measure |
| Led a team of twelve supervisors | Inflated form of F3 | F3's quote at its own scope: "currently a senior shift manager over 3 supervisors" |
| Built reporting or dashboards | Inflated form of F4 | F4's quote at its own scope: "solid Excel". The material does not show what was built |
| Has used Power BI | Negative you stated, F5: "never used Power BI" | The plain acknowledgment F5 gives: "I've never used Power BI." Then a plan, never a past. No slot |

## Sources

Provided documents: your message, which held the job description text and your background.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent, each refused (the host did not grant search permission):

- `Atlas Freight regional logistics company values` — refused
- `Atlas Freight interview process operations manager` — refused
- `Atlas Freight strategy recent news` — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call refused. Would have fed a values cheat sheet and VAL questions tied to published values; the VAL bank is `[generic]` instead |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call refused. Would have named the loop's rounds and set the persona weights; the weights are flat on the Generic archetype instead |
| 3. `Atlas Freight strategy` / recent news | unavailable | Every call refused. Would have grounded a CO question; E3 is `[generic]` instead |
| 4. `{interviewer name} Atlas Freight` | n/a | No interviewer name was given, so there was no query to form |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you are meeting and the round type: persona weights replace the flat ones, banks are reordered, and sections for a peer or a values round are added or dropped
- The recruiter's prep email, if any: any focus areas or pre-declared deliverable get their own build section
- Company research (the three searches were refused): published values, the loop's rounds and current strategy would ground E3 and G1 to G2 and could add a values cheat sheet
- The interviewer's name: an interviewer read and a reverse question tied to their own path
- Your answers to the answer slots on F1, F2, F3, F4 and F6, such as how many of the seven years were leadership: each answer is quoted into the snapshot and the rows and banks that draw on it are rewritten
- Your green belt certificate (F7): the artifact that would move that row from medium to high
- Hours you have for prep: a triage schedule that puts A2, B1 and D3 first
- A `tuesday-dossier.md` from an earlier evidence review: verified claims and per-gap strategy limits would tighten the guidance cells
