Web searches were refused, so I'm building the pack from your message alone. Next I'll write it to a file.
Before the prep, one thing in the invite. It says "Our hiring process is fully remote and is carried out entirely on Telegram", and that "if you are successful your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern. A chat can't show who is behind the account, and the message may not come from who it names. Until you've checked, don't send documents, ID or bank details through it. That includes anything onboarding would ask for. Check the invite with Lumenvale using contact details you find yourself on its own website or careers page, not through the chat or any number the sender gives. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `lumenvale-software_customer-support-specialist_interview_pack.md`. Web searches were refused, so nothing in it is researched about Lumenvale. It rests on your message alone and has no company or strategy questions. It assumes the support team lead is a hiring-manager-style interviewer.

It has 18 questions across five interviewer styles, reverse questions, and a list of claims it won't coach. The question to rehearse most is B1: "You've never worked for a software company." You stated that limit yourself, so the pack coaches you to say it plainly and then stay with what you actually told me.

The pack also flags two gaps in your material that the interviewer will probably find:
- **Escalations:** you haven't said anything about handling them. Think of a real case you handled, or be ready to say there wasn't one.
- **Written communication:** the Telegram interview is itself a writing sample, so expect it to be judged live.

Say the word and I'll play the interviewer on B1, live, with follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the support team lead the person you'd report to? The answer reweights the pack. Can you paste the full job ad, so the requirements come from its own words and not my summary of your summary?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview pack: Customer Support Specialist (remote), Lumenvale Software

Interviewer: the support team lead, unnamed, in a text chat on Telegram. Relationship assumed to be hiring-manager style, since your message did not say whether the lead is your future manager. This pack rests on your message alone: no Lumenvale research ran (see Sources), so nothing here is a claim about how Lumenvale works.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Types: **VAL** values alignment (none detected for this round, so none appear here); **EXP** what your work history can bear; **JD** the ad's listed requirements; **CO** company and strategy knowledge (none here, because no research ran); **CASE** a live problem set in the role.
- Guidance is scaffolding, not a script. Where it says answer slot, answer from your own experience, in your own words. If the thing was not yours, or never existed, say so plainly. That is an honest answer, not a failure.
- The interview is a text chat, so your answers will be read, not heard. Write them the way you would write a customer reply.
- The highest-ROI prep in this pack is **B1**, the question about not having worked for a software company. It is the likeliest objection, and it is the one place your material states a limit.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad, as relayed in your message | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap on the years. It is your own statement with nothing inspected behind it, so expect a probe on it. Lead with the quote in its own terms: three years, customer service advisor, at an energy supplier |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad, as relayed in your message | "I use Freshdesk every day" — your message | medium | [grounded] | none | No gap on the tool line, but the quote names Freshdesk, not Zendesk, and the words stay there: "I use Freshdesk every day." Expect a probe on what you use it for, and on Zendesk by name |
| F3 | "clear written communication" — the ad, as relayed in your message | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote has emails among the calls and does not show how clear the writing was, so the bridge stays there. Answer slot: the ad's written-communication line, and an interview held as a text chat, make a probe on your writing likely. If you have an example of a written reply that went well, or feedback on your writing, say what it was, in your own words; if you have none, say so plainly and stay with the emails you answered |
| F4 | "confidence handling escalations" — the ad, as relayed in your message | none given | none | [grounded] | discovery | Your material does not establish this either way. Answer slot: the ad's escalation line makes a probe likely. If you handled any escalated case, say what it was and what you did, in your own words; if there was none, or it was not yours to handle, say so plainly and stay with the calls and emails you answered |
| F5 | Familiarity with a software product and its customers (role-family expectation, [generic], not in the ad as you relayed it) | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | Helping colleagues beyond your own queue (role-family expectation, [generic], not in the ad as you relayed it) | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | Say it at its own scope: four new starters, the refunds process, last year. Expect a probe on what the training involved and which part was yours |

## Persona table

The loop rests on your own words: one text chat with the support team lead. No Lumenvale source describes a wider loop, so these weights come from the hiring-manager relationship prior and the shape of your material, not from a documented process. If you know the lead is a peer or a recruiter, the weights change.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | The lead sets live support scenarios and watches how you reply in the chat itself | Highest. A hiring-manager prior favours live problems, and the ad's escalation line (F4) has no quote behind it, so a scenario is the lead's easiest way to test it | Clarify before you answer, say what you would do and by when, and write the reply as you would send it to a customer |
| B. Skeptic | Quiet, persistent probing of the software-company gap and of why you want to move | High. F5 is a limit you stated yourself, and a hiring manager is derisking gaps | Rehearse B1 until it is boring: the plain acknowledgment, then only what your quotes carry, then a plan said as a plan |
| C. Conversational | Friendly openers about your background and your writing, which feel unscored | Medium. An invite in a friendly register suggests a warm opening, and every casual answer is still scored | Prepare a 90-second arc from your own quotes; treat the writing question as scored |
| D. Data-Driven Prober | Reads your lines closely and asks how the figures were counted | Medium. Your material has two figures, the daily volume and the four new starters | Know what you can and cannot say about how each figure was counted; say plainly when you do not know |
| E. Pressure | Time-boxes you and asks how much of a result was yours | Low. Nothing in the invite signals a stress style, so this is insurance | Pause, restate the question, hold your position through two follow-ups, then concede only what is true |

## Question banks

### A. Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same unresolved refund and says they will cancel. Reply to them here, now." | CASE | [generic] | Say what you would want to know first, then write the reply as you would send it: acknowledge it plainly, say what you will do and by when, and say how they will hear back. The question asks about no past of yours, so the guidance makes no claim about it | A live problem in the role's own terms. CASE because it scores the reply, not your history; [generic] because it is a pattern for the problem, not a fact about this employer |
| A2 | "A customer is abusive and demands a manager. Walk me through what you do." | CASE | [generic] | Structure it: what you say to the customer first, what you check before passing it up, what you hand over so the next person does not start from zero, and how you close it out with the customer. No claim about your past is made. If your own material later offers a real case, A-guidance gives way to B3 | The ad's escalation line (F4) is where your material is silent, so this is the likeliest live test of it. CASE because it is a live problem |
| A3 | "A customer says our app logged them out and they lost their work. You cannot reproduce it. What do you do?" | CASE | [generic] | Structure it: what you would ask the customer for, what you tell them while you look into it, what a clear write-up for the people who can fix it would contain, and how you follow up. This question tests a software-support habit, so name your own plan and not a past; your material says you have not worked for a software company | A software-flavoured scenario that touches F5 without asking you to claim software experience. CASE because it is a problem, not a history |
| A4 | "You use Freshdesk every day. How would that carry over if we use Zendesk?" | JD | [grounded] "I use Freshdesk every day" | Hold the quote: "I use Freshdesk every day." Answer slot: if you have used Zendesk, say where and for how long; if you have not, say so plainly and stay with Freshdesk. Describe how you would pick up a new tool as a plan, never as something you have already done | F2 is the evidence for the tool line, and the ad names Zendesk. JD because it scores the stated requirement |
| A5 | "You have a customer on live chat, a dozen open tickets and an urgent one from me. How do you decide what to do first?" | CASE | [generic] | Structure it: what you need to know about each, what you would tell the waiting customer, how you would decide order and say it aloud. The question asks about no past of yours | Prioritisation under load is a common support scenario; [generic] because nothing here came from Lumenvale |

### B. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never worked for a software company. Why would you succeed here?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't worked for a software company." Then say what your quotes carry, at their own scope: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Do not say what that proves; let the interviewer draw it. Hold through two follow-ups by returning to those facts, never by adding to them. Concede the product knowledge you do not have yet, and give a plan for learning it, said as a plan | F5 is the one limit you stated yourself, so this objection arrives in some form. JD because it scores the fit with the role; the hold-then-concede structure is Skeptic's own |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Pick the weakness your material actually shows. It shows two places with least behind them: F4, where it is silent, and F5, where you stated the limit. Say the true one plainly, in your own words, then give a concrete plan. If neither is true for you, say what is | A persona stem for the Skeptic, and a free miss if you have not chosen the answer beforehand. JD because it scores the listed job, gaps included |
| B3 | "The ad asks for confidence handling escalations. Tell me about a time you handled one." | EXP | [generic] | A selection scaffold: choose a real case that needed more than the first reply, where you can name what was at stake, what you did and how it ended. If no such time comes to mind, say so plainly, then say how you would handle one | F4 has no evidence behind it, so this is the probe it invites. EXP because it asks what you actually did; the question is an open prompt, so it supplies no event |
| B4 | "Why leave energy for software, and why now?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Say your own reason, in your own words; this pack does not supply one. State the three years at an energy supplier as the quote does, and keep the reason to something you can repeat under a second question | The Skeptic's motivation-consistency check. EXP because it tests the story of your own career |
| B5 | "Your support has been calls and emails. How is chat or ticket support different?" | JD | [grounded] "answering around 60 calls and emails a day"; "I use Freshdesk every day" | Hold what the quotes say: calls and emails, and Freshdesk every day. Answer slot: if you have done live chat or ticket-based support, say where; if you have not, say so plainly and stay with the calls and emails | The role is remote and chat-led, and F1 is calls and emails. JD because it probes the requirement's edge |

### C. Conversational (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey. How did you end up in customer service, and what made you apply here?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day" | A 90-second arc using only your quotes for the facts: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Give the reason you applied in your own words; this pack does not supply it | The biography question is nearly certain and scored despite its casual register. F1 and F2 supply the facts. EXP because it tests your own history |
| C2 | "Tell me about a reply you wrote that you were proud of." | JD | [generic] | A selection scaffold: choose one real written reply, and be ready to say what the customer needed and what you wrote. If no such reply comes to mind, say so plainly, then say how you would write a reply to a case like that | The ad's written-communication line (F3) has little behind it, and this interview is itself a writing sample. JD because it scores the stated requirement |
| C3 | "What are you actually using Freshdesk for day to day?" | JD | [grounded] "I use Freshdesk every day" | Say what you use it for, in your own words, naming only what you really use. Answer slot: if you can name the features you use, do; if you use only part of it, say so plainly | F2 is a CV-style line with nothing inspected behind it, and a casual question about a tool is a probe on it. JD because the tool is a requirement |

### D. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Keep the number with the nouns it came with: calls and emails, not tickets. Answer slot: say how you know it, what could make it higher or lower, which assumption in it you would defend least, and which part of it was yours; if you do not know how it was counted, say so plainly | A headline figure draws a defend-the-number question. EXP because it tests your own account of your work |
| D2 | "You trained four new starters last year. What did that involve?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Say it at its own scope: four new starters, the refunds process, last year. Answer slot: say what the training involved and which part was yours, in your own words; if it was less formal than that, say so plainly | F6 is a specific figure and a specific claim, so a prober asks what stood behind it. EXP because it tests attribution |
| D3 | "Three years at an energy supplier. What changed in the work between your first year and your third?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Answer slot: if the work changed, say what changed, in your own words; if it stayed much the same, say so plainly and say what you took from the three years | F1 is a duration with nothing inspected behind it. EXP because it asks what the time actually held |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I've never worked for a software company" | Pause and restate the question first. Hold the position your quotes carry: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Hold it through two follow-ups. Concede, once and specifically: "I haven't worked for a software company." Do not fold on the rest to restore harmony | A persona stem for the Pressure style, aimed at F5. JD because it scores fit for the role |
| E2 | "How much of that training was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold the quote at its scope: four new starters, the refunds process, last year. Answer slot: say which part was yours, and what was not, in your own words; if you do not know how the split looked, say so plainly. Concede only what is true | The attribution probe on F6. EXP because it tests what was actually yours |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" | C1, D3, E1 |
| "experience with Zendesk or a similar ticketing tool" | A4, C3 |
| "clear written communication" | C2, A1 |
| "confidence handling escalations" | A2, B3 |
| Software-company familiarity (role-family, not in the ad) | A3, B1, B2, B5, E1 |
| Helping colleagues (role-family, not in the ad) | D2, E2 |
| Company and strategy knowledge | none, because no research ran |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What would my first month look like, and which kinds of tickets would I start on?" | It shows you are planning to be useful quickly, and it surfaces what the role really holds |
| R2 | "How are escalations handled on the team, and when would you want me to pass one up?" | It answers F4 from the team's side and shows you care about the boundary |
| R3 | "What does good written support look like here? Is there a style guide or examples I could read?" | It treats the ad's writing line as a standard to meet, not a box to tick |
| R4 | "How does the team help people who have not worked in software before get up to speed?" | It turns the F5 gap into a practical question about onboarding |
| R5 | "Which ticketing tool does the team use, and how are new starters set up on it?" | It shows interest in the tool line without claiming Zendesk |
| R6 | "What are the next steps after this chat, and how are contracts and onboarding handled?" | It is a normal question about process, and the answer tells you how the rest of the hiring works |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material names Freshdesk, not Zendesk. A4's slot stays inside that quote |
| Handles around 60 tickets a day in Freshdesk | Inflated form of F3 and F2 | The figure stays with its own nouns: "answering around 60 calls and emails a day". D1's slot asks only how that was counted |
| Owns or runs the refunds process | Inflated form of F6 | F6's quote at its own scope: you trained four new starters on it. D2's slot asks only what the training involved |
| Has worked for a software company or in software support | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't worked for a software company." No slot |

## Sources

Provided documents: your message (the invite text, the requirements of the ad as you described them, and your background). No dossier was provided.

Searches sent:

- "Lumenvale Software company values": refused
- "Lumenvale Software Customer Support Specialist interview process": refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Would have fed a values section and VAL questions if a values-style round exists; both searches were refused, so none is detected here |
| 2. `Lumenvale Software interview process Customer Support Specialist` | unavailable | Would have documented the loop; your message establishes one text chat with the support team lead, so persona weights follow that |
| 3. `Lumenvale Software strategy` / recent news | unavailable | Would have moved CO and strategy-grounded CASE questions; no search was permitted, so none is written |
| 4. interviewer public footprint | n/a | The interviewer, the support team lead, is not named, so there is no query to form; the interviewer read is absent |
| 5. representative `Customer Support Specialist` JD | skipped | The requirements you relayed fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full ad text → F1 to F4 take the ad's own wording instead of your summary of it, and any mid-list requirement gets a question
- Permission to search the web, or a pasted Lumenvale values page and strategy summary → a values section if a values round exists, and CO questions grounded in Lumenvale's current priorities
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a company brief and recent organisation context, once search is allowed
- The support team lead's name → an interviewer read, and a reverse question tied to their own path
- Your answers to the F3 and F4 slots, said in your own words → both rows get evidence quotes in place of slots, and B3 and C2 become story-mapped
- Any recruiter detail on the chat format, such as how long it runs and whether there is a task → coverage for a pre-declared deliverable
- How much prep time you have → a prioritised schedule
- A `tuesday-dossier.md`, if you have one → verified evidence, a strategy per gap and a list of claims to avoid
