I've read the skill's rules and I'm now running the three company searches (values, interview process, recent news). Then I'll build the prep pack.
Before the prep, one thing in the invite: it says the process is "carried out entirely on Telegram", that "your interview will be a text chat here with our support team lead", and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern, and nothing in the chat itself shows who is behind it. Because offer and onboarding are also meant to happen there, I'd hold any payment, documents or bank details until you've checked the invite with Lumenvale. Use contact details you find yourself on its own website or careers page, never ones from the Telegram chat. The invite may not come from who it names. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as lumenvale-software_customer-support-specialist_interview_pack.md. I built it for one typed chat with a support team lead, treated as a hiring-manager style round, since nothing more was given. My web searches were refused, so nothing in it is researched. The company question (D2) is a labeled generic scaffold and there is no values section. The pack has 20 questions across six personas. The one to rehearse hardest is A2: you've told me you haven't worked for a software company, so expect "why should we believe you can support a software product?"

Say the word and I'll play the Skeptic on A2, live, in the same text format.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full job ad, or say skip? It would turn your four listed requirements into quoted ones and may add pay, hours or time-zone terms that reshape the snapshot.
Would you allow web search, so I can add Lumenvale's own values, process and recent news? Say no and the pack stands as it is.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software

- **Role:** Customer Support Specialist (remote), Lumenvale Software
- **Interviewer:** the support team lead, name not given. Relationship assumed: hiring-manager style, because your invite names one text chat with the team lead and nothing else about the round
- **Format:** one typed chat on Telegram, as the invite describes it
- **Built from:** your message and the invite text only. The web searches I tried were refused, so nothing here is researched; company-specific rows are labeled accordingly

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values (none established here, so unused) |
| EXP | Whether your CV claims survive follow-up questions; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | What you know about the company and its strategy |
| CASE | A live problem from the role, answered on the spot |

An answer slot is an instruction for the interview, not a question for me. Where one appears, answer whichever branch is true for you. The honest second branch is never a failure.

## Fit snapshot

Requirements are quoted from your message, where you listed what the ad asked for. I have not seen the ad itself.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad as you listed it, your message | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap on length, but a line with nothing inspected behind it, so expect a probe. Say it in its own terms, "3 years as a customer service advisor at an energy supplier", and keep your real job title rather than the ad's wording |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad as you listed it, your message | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Your material names Freshdesk, not Zendesk. Say it by name, "I use Freshdesk every day", and let the interviewer judge how close the two are; the ad's "a similar ticketing tool" leaves room for that. Answer slot: expect a probe on what you do in it, and on Zendesk. If you have used or seen Zendesk, say where; if you have not, say so plainly |
| F3 | "clear written communication" — the ad as you listed it, your message | "answering around 60 calls and emails a day" — your message; "I trained four new starters on our refunds process last year" — your message | low | [inferred] | discovery | The first quote counts calls and emails together and says nothing about how clear the writing was; the second touches explaining a process, not writing. Neither is stretched here. Answer slot: the ad's "clear written communication" makes a probe on your emails likely. If you know roughly how many of the 60 were emails, or any of your replies were reviewed or praised, say so in your own words; if you do not know, or none were, say so plainly and stay with the quote. This Telegram chat is itself a writing sample: short, plain messages |
| F4 | "confidence handling escalations" — the ad as you listed it, your message | none given | none | [grounded] | discovery | Your material is silent on escalations, which is not the same as a gap you stated. Answer slot: if you handled escalated customers, or passed them on, say what the situation was and what you did, in your own words; if you did not, or they went to someone else, say so plainly and say how you would handle one |
| F5 | Software-company background (a role-family point, not in the ad as you listed it) | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| The Skeptic (bank A, 5 questions) | Quiet, persistent probing of the software gap, the escalation gap, and why you want to move | Highest. Relationship prior for a team lead is Case plus Skeptic, and F4 and F5 are the two rows your material leaves thinnest | Rehearse the F5 objection until it is boring; hold what your quotes carry, concede the rest in one plain sentence, add a learning plan |
| The Case / Strategist (bank B, 5 questions) | Live support scenarios typed into the chat: an angry customer, an unfamiliar product, a queue spike | Highest. Same relationship prior, and a support lead can build cases straight from the job | Clarify first, then structure, then reply; think aloud in short messages |
| The Data-Driven Prober (bank C, 3 questions) | Takes the CV lines one at a time: the 60-a-day figure, the training, the tool | Medium. Three of your five quotes are specific enough to probe | Know what you can say about each line; say plainly what you do not know |
| The Conversational / Rapport Builder (bank D, 3 questions) | A friendly opener, "walk me through your journey", then casual questions about writing and the company | Medium, raised by the loop: the invite makes the whole interview typed, so your writing is scored live from your first message | Prepare a 90-second written arc; treat casual questions as scored |
| The Pressure Interviewer (bank E, 2 questions) | Time-boxed "why you" and "how much was you" | Low. Typed chat is a weak medium for interruption, and nothing you shared signals a stress style | Pause, restate, hold through two follow-ups, then concede specifically |
| The Values / Behavioral Interviewer (bank F, 2 questions) | Scenario prompts, here drawn from the ad's escalation line | Low. No values-style round is documented: the loop comes from the invite, which names one chat with the team lead | Choose stories where you know the ending; say plainly when none comes to mind |

The Peer Evaluator is not given a bank: a support team lead is not your peer, and nothing in the invite suggests a peer round.

## Question banks

### Bank A: The Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Name the real one in your own words. Your material names one limit, "I've never worked for a software company". If that is your weakest part, say it in those words, then say how you would learn the product in your first weeks, as a plan and not a past. Answer slot: if a different part of the job is your weakest, name it plainly and say what you would do about it | F5 is a gap you stated, and this stem goes straight to it. JD because it scores honest self-assessment against the role |
| A2 | "Your background is an energy supplier, and you've said you haven't worked for a software company. Why should we believe you can support a software product?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier", "I use Freshdesk every day", "I've never worked for a software company" | The highest-ROI rehearsal in this pack. Hold only what the quotes carry: "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day". Concede in one sentence: "I've never worked for a software company." Then a learning plan. Hold through two follow-ups by returning to those sentences, never by adding to them | F5 is where the role's company type presses hardest, so this objection arrives in some form. F1 and F2 are what you can hold. JD because it scores fit with the listed job |
| A3 | "The ad names Zendesk and your tool is Freshdesk. How would you get up to speed on ours?" | JD | [grounded] "I use Freshdesk every day" | Say Freshdesk by name: "I use Freshdesk every day". Do not say you have used Zendesk; your material does not say so. Answer slot: if you have used or seen Zendesk, say where, in your own words; if you have not, say so plainly and say how you would learn the team's tool, as a plan | F2 is the requirement this tests, and the tool name is where a stretch would creep in. JD because it scores the listed tool requirement |
| A4 | "Tell me about a time you had to escalate a customer issue, or deal with one that was escalated to you." | JD | [grounded] | Selection scaffold: pick a case with the customer's issue, what you did, who you handed it to or took it from, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle one | F4 is silent in your material, and the ad lists escalations. JD because it scores that stated requirement; the scaffold supplies no event |
| A5 | "Why move from an energy supplier into software, and why Lumenvale?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Give your actual reason in your own words; your material carries none. Answer slot: say why software and why this company, with whatever you have really read about them; if you have read little, say so plainly and say what drew you to the role itself | The Skeptic's why leave, why here, why now. F1 is the history it starts from; EXP because it tests consistency of your story |

### Bank B: The Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes in that their refund hasn't arrived and they have now written three times. Write me your reply." | CASE | [generic] | Structure it: acknowledge the three attempts, say what you need from them, say what happens next and when, and promise only what you can deliver. Keep it short, since the interviewer reads your typing. The question needs no claim about your past, so the guidance makes none | A live problem a support lead can build in seconds; F3's requirement is graded in the reply itself. `[generic]` because it is a pattern, not a fact about this employer |
| B2 | "A customer says the app isn't working, and you don't know the product well yet. What do you do?" | CASE | [generic] | Clarify what they see and on what device, check what you can find yourself, never guess an answer, say what you will do next and by when, and hand over with the full details if you cannot fix it. No claim about your past | F5 is the likeliest source of this scenario. CASE because it tests structure under a knowledge gap |
| B3 | "Ticket volume doubles on a Monday morning. How do you decide what to answer first?" | CASE | [generic] | Clarify what you can see in the queue, say how you would rank urgency and customer impact, say what you would tell waiting customers, and say who you would flag it to. Build from the problem and not from your past, which your material does not describe on this | Prioritization is a standard support problem. CASE because it scores reasoning rather than a right answer |
| B4 | "A customer demands to speak to a manager. How do you handle the escalation?" | CASE | [generic] | Listen and restate the issue, say what you can do yourself, say when and to whom you would escalate, and what you would pass along so the customer never repeats themselves. No claim about your past | F4 is the ad's escalation line, asked here as a decision rather than a record. CASE with JD content |
| B5 | "A customer's email runs to three paragraphs with four separate problems in it. Show me your reply." | CASE | [generic] | One clear reply: acknowledge, answer the problems in the order the customer raised them, keep sentences short, close with what happens next. No claim about your past | F3 is graded live in a text interview, so this is the likeliest place the requirement is tested. CASE with JD content |

### Bank C: The Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say it at its own scope: "around 60 calls and emails a day". Answer slot: say how the figure was counted, if you know; what it depended on; which part of it you would defend least; and whose workload it describes. If you do not know how it was counted, say so plainly. Never present it as 60 emails | F3's only figure, so it is the number a prober defends first. EXP because it tests attribution and honesty about the count |
| C2 | "Walk me through the training you did." | EXP | [grounded] "I trained four new starters on our refunds process last year" | The beats the sentence states: four new starters, the refunds process, last year. Tell them in your own words. The sentence says "trained"; keep to that and do not describe a programme or a leadership role | F3's second quote and your clearest example of explaining a process. EXP because the probe is what was actually yours |
| C3 | "Tell me what you do in Freshdesk day to day." | JD | [grounded] "I use Freshdesk every day" | The beats the quote states: Freshdesk, every day. Answer slot: the ad's "experience with Zendesk or a similar ticketing tool" makes a probe on what you do in it likely. Say which parts you use and how, in your own words; if you use only a narrow part, say so plainly and stay with the quote | F2 is the requirement this tests. JD because it scores the listed tool experience |

### Bank D: The Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey so far and what brought you here." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier", "answering around 60 calls and emails a day", "I use Freshdesk every day", "I trained four new starters on our refunds process last year" | A 90-second typed arc in this order: where you are now, what a day looks like, the training, then why this role. Use the quotes at their own scope and add nothing. Answer slot: the why-this-role beat has no source in your material, so give your real reason; if it is partly practical, say so plainly | The usual opener, and your first written sample. F1 is the spine; EXP because it is your story in your words |
| D2 | "What do you know about Lumenvale and what we build?" | CO | [generic] | Nothing about Lumenvale was established, because the searches were refused. Before the chat, spend 15 minutes on their careers page and product pages and note two things you can honestly say you read. In the chat, say what you read; if you found little, say so plainly and ask what the product does | No company facts are written here because none were verified. CO because it tests homework; `[generic]` because it is a scaffold |
| D3 | "What makes a message to a customer clear, in your view?" | JD | [generic] | Selection scaffold: name two or three habits you really follow when you write to customers, and give your reason for each. If no habit comes to mind that you can name, say so plainly, then describe how you would write your reply to B5 | F3's requirement asked casually, which is still scored. JD because it tests the stated written-communication requirement |

### Bank E: The Pressure Interviewer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who already works in software support?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier", "I use Freshdesk every day", "I've never worked for a software company" | Hold: "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day". Concede in one sentence: "I've never worked for a software company." Hold through two follow-ups by returning to the quotes and never by claiming more | F5 under time pressure; F1 and F2 are what you can hold. EXP because it tests composure and honest self-assessment |
| E2 | "The training you described, how much of that was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold the sentence: "I trained four new starters on our refunds process last year". Answer slot: if part of it was shared, say which part was yours and which was not; if it was all yours, say so plainly. Do not widen "trained" into a bigger role under pushback | A probe on exactly the line a candidate is tempted to inflate. F3 holds the quote; EXP because it tests attribution |

### Bank F: The Values / Behavioral Interviewer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you stayed calm with a difficult customer." | EXP | [generic] | Selection scaffold: pick a time with a named situation, what the customer said, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The ad's escalation line raises the theme; F4 holds no story. EXP because it asks for a past instance |
| F2 | "When did you put a customer ahead of an internal metric?" | EXP | [generic] | Selection scaffold: pick a time where the customer's need and an internal target pulled apart, say what you did and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A stock behavioral stem, with no published Lumenvale values behind it; nothing in your material carries it. EXP because it asks for a past instance |

### Requirement coverage

| Requirement | Questions covering it |
|---|---|
| "2+ years in customer support" (F1) | A2, A5, D1, E1 |
| "experience with Zendesk or a similar ticketing tool" (F2) | A3, C3 |
| "clear written communication" (F3) | B1, B5, C1, C2, D3 |
| "confidence handling escalations" (F4) | A4, B4, F1 |
| Software-company background (F5, not in the ad as you listed it) | A1, A2, B2, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is the support team set up, and what does a new person's first month look like?" | It shows you are planning your ramp, which answers the software gap (F5) before it is raised again |
| R2 | "Which ticketing tool does the team work in day to day?" | The ad names Zendesk or similar; the real answer tells you what to compare Freshdesk against (F2) |
| R3 | "How are escalations handled here: who takes them, and what makes a good handover?" | It turns your thinnest row (F4) into a conversation about how you would work |
| R4 | "How does the team judge good support, and is written quality reviewed?" | It shows you take written clarity seriously (F3) and tells you what is scored |
| R5 | "What are the working hours and time-zone expectations for this remote role?" | Your material does not establish these terms, and it is better to know them before any offer |
| R6 | "How does the rest of the process work from here, and who signs off an offer?" | It gives you something to check against Lumenvale's own website, which is also your verification route |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope, "I use Freshdesk every day". The limit is the pack's observation: your material names Freshdesk, not Zendesk. A3's slot stays on whether you have seen Zendesk |
| Answered about 60 emails a day | Inflated form of F3 | F3's quote at its own scope, "answering around 60 calls and emails a day". The limit is the pack's observation: the figure covers calls and emails together |
| Led or ran training, or a training programme | Inflated form of F3 | F3's quote at its own scope, "I trained four new starters on our refunds process last year". C2 and E2 stay inside it |
| Has software-company or SaaS support experience | A negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |

## Sources

Provided documents: the invite text you pasted; your message listing the ad's requirements and your background. No dossier was consumed. I have not seen the full job ad.

Searches sent, all refused, none returned any result:

- "Lumenvale Software values" — refused
- "Lumenvale Software interview process customer support specialist" — refused
- "Lumenvale Software company news strategy" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | The one call was refused. It would have named published values for a values cheat sheet and the VAL themes; neither section exists in this pack |
| 2. `Lumenvale Software interview process customer support specialist` | unavailable | The call was refused. It would have shown whether other rounds exist; persona weights rest on the invite's own words, which describe one chat with the team lead |
| 3. `Lumenvale Software company news strategy` | unavailable | The call was refused. It would have grounded D2 and the CO coverage, which are `[generic]` here |
| 4. interviewer name and company | n/a | The interviewer is described only as the support team lead, so there is no name to form a query; the interviewer read is absent |
| 5. representative `Customer Support Specialist` JD | unavailable | No further search was sent after the refusals. It would have added `[inferred]` rows beyond the four requirements you listed |

## Upgrade menu

- The full job ad text → the four requirement rows become quoted from the ad itself, and any pay, hours, time-zone or other terms become gate rows
- Permission for web search, which was refused in this session → Lumenvale's own values, process and recent news replace `[generic]` D2, add a values cheat sheet if a values round is documented, and move the research rows from unavailable to yes
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes, after the first pass runs → a strategy brief for sharper CO and CASE questions, offered once
- The support team lead's name → an interviewer read from public professional footprint, persona weights adjusted to it, and a reverse question tied to their path
- Your answers to the slots in F2, F3 and F4, said outside any drill → those rows are rewritten from your own words, and the matching bank cells become story-mapped
- A saved `tuesday-dossier.md` → carries the gaps this prep exposed into later sessions
