Before the prep, one thing in the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ...", to send "a photo of your passport and your bank details before the interview", and says that "you deposit the cheque and send the balance on to the vendor". Each of these is a known scam pattern. Money up front, ID and bank details before any offer, and a cheque you pay in and then forward money from are the same shape. The cheque can be returned after your own money has gone. The fee, the passport and bank request, and the cheque arrangement are very likely a scam. Please hold all three until you've checked the invite with the employer, using contact details you find yourself on its own website or careers page. Don't use the invite's email, chat or any number in it. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `Brennock-Facilities-Ltd_remote-administrative-assistant_interview_pack.md`. It covers the one session the invite describes, a 30-minute video call with the office manager. Your message didn't say how that person relates to the role, so I built it for a hiring-manager-style interviewer. It has 18 questions in five styles, a fit table, claims I won't coach, and six questions for you to ask them. I ran no research, so there is nothing about the company itself in it.

What to expect is mostly practical questions on your four duties, plus friendly biography questions. Your thinnest spots are supplier invoices, travel booking and Excel. Rehearse C2 most. It asks "What's your experience with processing supplier invoices?" Your material says you chased unpaid invoices, so you should answer at that size and say plainly where it stops.

Say the word and I'll play the Skeptic on C2.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the office manager the person you'd report to, or a colleague on the team? The answer reweights every bank.
Can you paste the ad's full text? It would turn my paraphrase of the duties into the ad's own words.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock-Facilities-Ltd_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

- Role: Remote Administrative Assistant
- Company: Brennock Facilities Ltd
- Session: one 30-minute video call with the office manager, as the invite describes it
- Interviewer: office manager, name not given; relationship to you not stated, so this pack is built on a hiring-manager-style prior (see the persona table)
- Candidate: Aoife

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your own background claims hold up when probed |
| JD | Whether you can do the listed job, gaps included |
| CO | How well you know the company and its strategy |
| CASE | How you structure a live, realistic problem |

An answer slot is an instruction for the interview, not a question for you now. Where it offers two branches, either is a good answer if it is true.

## Fit snapshot

The requirements are the ad's duties as you described them in your message. Evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "I ran the appointment book for four physios" — your message | medium | [grounded] | transferability | Your material says an appointment book for four physios, with nothing inspected behind it, and the words stay there: "I ran the appointment book for four physios." It does not say whether that book was a meeting calendar. Answer slot: the ad line makes a probe on how the book worked likely. If it ran on a particular calendar program, name it; if it was paper or another system, or you do not remember, say so plainly and describe how you ran it |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show travel booking, and the pack writes no words for it. Answer slot: the ad line makes a probe likely. If you have booked travel for anyone, say for whom and what you handled, in your own words; if you have not, say so plainly and say what you would ask first |
| F3 | "preparing documents in Word and Excel" (Word) — the ad, as you described it | "I'm good with Word" — your message | medium | [grounded] | presentation | Say it at its own size: "I'm good with Word." The quote says skill with Word, not which documents were prepared, so expect a probe on that. Answer slot: if you can name the kinds of documents you have prepared, do so in your own words; if none comes to mind, say so plainly and stay with the Word skill you described |
| F4 | "preparing documents in Word and Excel" (Excel) — the ad, as you described it | "okay with Excel" — your message | low | [inferred] | discovery | The quote touches the requirement without showing whether it reaches it, and the bridge should not be stretched. Say it at its own size: "I'm okay with Excel." Answer slot: if there is anything you have used Excel for, say what in your own words; if "okay" is the honest whole of it, say so plainly and say what you would practise first |
| F5 | "processing supplier invoices" — the ad, as you described it | "I ran the appointment book for four physios and chased unpaid invoices" — your message | medium | [grounded] | transferability | The quote carries chasing unpaid invoices, at its own scope. Your material does not say whose invoices those were or what dealing with them involved, so nothing beyond the chasing is carried. Answer slot: the ad line makes a probe on invoice handling likely. If dealing with those invoices involved anything beyond chasing them, say what in your own words; if it did not, say so plainly and stay with the chasing |

## Persona table

The weights rest on the hiring-manager prior, because the invite says "office manager" and not how that person relates to the role. That makes the weighting weaker than it would be with the relationship known. A reply to the question in the covering message would reweight it.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport | Friendly, unstructured opener; casual questions that are still scored | Highest. The invite describes one 30-minute video call, so an opening biography question is near-certain in any style; the tilt above the hiring-manager prior is this pack's judgment and is wrong if the call is a tightly structured screen | Prepare a 90-second arc (A1) from the two quotes it names; treat casual questions about Excel or travel as scored |
| B. Case / Strategist | Short practical scenarios: a booking, a clash, a mismatched invoice | High. The prior for a hiring manager is Case plus Skeptic, and the ad's duties are all things a scenario can test; the scenarios here are role-family patterns, not this employer's cases | Clarify first, then structure, then say what you would record; think aloud |
| C. Skeptic | Quiet probing of the thin spots: invoices, travel, Excel, why this move | High. F2, F4 and F5 are where the material is thinnest against the ad, and the prior puts Skeptic beside Case | Rehearse C2 until it is boring: say what the quote carries, state the limit plainly, then the learning plan |
| D. Data-Driven Prober | Takes one claim and asks how it actually worked | Medium. Your background has few figures, so probes land on the appointment book and the invoices | Know what you can and cannot say about each line, and say plainly when you do not know |
| E. Pressure | Time-boxed or blunt: why you, is that enough | Low. Nothing in the invite suggests a stress format; included so the style is not new | Pause, restate the question, hold your position through two follow-ups, concede only what is true |

## Question banks

### A. Conversational / Rapport (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey: how did you end up in admin, and why this role?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Build the arc from what the quote states: a receptionist, a physiotherapy clinic, two years. Answer slot: say in your own words what drew you to the role the ad describes; if the honest reason is simple, keep it simple and say so plainly | The near-certain opener in any format, and the one place to set the tone. EXP because it tests that your account matches your background |
| A2 | "What did a normal day on the front desk look like?" | EXP | [grounded] "I ran the appointment book for four physios and chased unpaid invoices" | Tell the beats the quote states: running the appointment book, for four physios, and chasing unpaid invoices. Answer slot: if other regular parts of the day matter to this role, say what they were in your own words; if the quote covers it, stop there | A casual question that is really F1 and F5 together, so it is scored. EXP because it checks the same lines the Skeptic will probe |
| A3 | "What are you actually playing with in Excel these days?" | JD | [grounded] "okay with Excel" | The honest anchor is the quote at its own size: "I'm okay with Excel." Answer slot: if there is something you use it for, say what in your own words; if not much, say so plainly and say what you would practise first. Name no functions you have not used | The persona stem applied to the ad's Excel line (F4). JD because it scores a listed skill; the friendly register is why it is easy to under-prepare |
| A4 | "How do you keep yourself organised when several people want your time at once?" | JD | [grounded] "I ran the appointment book for four physios" | Open prompt, so choose the instance yourself. The quote carries one place where several people's time was in one book: you ran it, for four physios. Answer slot: the ad's calendars line makes a probe on clashes likely. If the four physios' needs ever clashed, say what happened and what part was yours; if they did not, or it was not yours, say so plainly and stay with running the book | Calendars are the first duty in the ad as you described it (F1). JD because it scores that duty, delivered as a casual question |
| A5 | "How do you feel about working remotely, mostly on your own?" | JD | [generic] | The question needs no claim about your past, so the guidance makes none. Answer slot: if you have worked remotely, say how it went in your own words; if you have not, say so plainly and say how you would structure a working day alone | The role title says remote, so the question is likely in some form. JD because it scores a stated feature of the role; `[generic]` because it is a pattern, not a fact about this employer |

### B. Case / Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A manager asks you to book a two-day trip for two people leaving from different cities, and both must be at a 10am meeting on day two. What do you ask first, and how do you go about it?" | CASE | [generic] | Structure it aloud: clarify first (dates, budget, preferences, who approves), then the fixed point (the 10am meeting and a buffer before it), then options, then confirming and sharing a single itinerary. The question asks about no past, so the guidance claims none | Tests the travel duty (F2) as a live problem, which is the fairest way to show reasoning where there is no travel history to quote |
| B2 | "A meeting three people have accepted needs to move, and the new slot suits everyone but one. What do you do?" | CASE | [generic] | Clarify how fixed the meeting is and who is flexible; offer two or three options; check the person who cannot make it before changing anything; confirm the change in writing to everyone. No claim about your past | A calendar problem set in the ad's first duty (F1). CASE because it scores process under a small conflict |
| B3 | "A supplier invoice arrives and its total does not match the order. What happens before anything is paid?" | CASE | [generic] | Do not process it as it stands; find what the invoice should be checked against; ask the person who placed the order; query it with the supplier; keep a record; pass it to whoever approves payment. The guidance claims nothing about your past | The invoices duty (F5) as a live problem, set so that the honest answer needs no invoice history |
| B4 | "Here is this month's invoice list for me to review. Some dates are missing and one supplier name is spelled two ways. How would you tidy it?" | CASE | [generic] | Clarify who it is for and what it will be used for; keep an untouched copy; check against the source documents; flag what you cannot resolve rather than guessing; say what you changed. No Excel features need naming, and none should be named unless you have used them | Combines F4 and F5 in one practical task. CASE because it scores care and judgment more than the tool |

### C. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "okay with Excel" | Pick the part that is truly weakest, not the safest. If it is Excel, the quote at its own size is the plain version: "I'm okay with Excel." Then give a learning plan as a plan, not a past. Answer slot: if travel booking or invoice handling is the honest answer instead, say that plainly | The Skeptic stem, and the answer is an honest choice from F2, F4 and F5. JD because it scores self-assessment against the listed duties |
| C2 | "What's your experience with processing supplier invoices?" | JD | [grounded] "I ran the appointment book for four physios and chased unpaid invoices" | The highest-ROI rehearsal in this pack. The hold is only what the quote carries: you chased unpaid invoices. Answer slot: if dealing with those invoices involved anything beyond chasing them, say what in your own words; if it did not, say so plainly and stay with the chasing. Hold through two follow-ups by returning to the chasing, never by adding to it; concede the limit specifically if pressed, and say what you would learn first | F5 is where the ad's wording and your material sit furthest apart, so some form of this question is the likeliest objection. JD because it scores a stated duty, with the limit named before it is asked for |
| C3 | "Part of the role is booking travel. Have you done that before?" | JD | [generic] | A yes-or-no question about your past, so the guidance is a slot and no more. Answer slot: if you have booked travel for anyone, say for whom and what you handled; if you have not, say so plainly and say what you would ask before booking anything | F2 has no evidence in your material, so this is the question that finds it. JD because the duty is the ad's; `[generic]` because the guidance claims nothing about your past |
| C4 | "You've been a receptionist for two years. Why a remote admin role, and why now?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | State the background at the quote's size. Answer slot: give your actual reasons for the move and for remote work, in your own words; if one of them is more practical than ambitious, say so plainly, since a simple true reason holds up better than a polished one | Motivation consistency is a standard Skeptic probe and has no source in the material, so the reasons must come from you. EXP because it tests whether your story is consistent |

### D. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you ran the appointment book for four physios." | EXP | [grounded] "I ran the appointment book for four physios" | Tell what the quote states: you ran the book, for four physios. Answer slot: the ad's calendars line makes a probe on how the four physios' availability was handled likely. If you set or followed particular rules, say which, in your own words; if there were none, or they were not yours, say so plainly and describe how you ran it | F1 is the line a prober will pick, since it is the most specific one. EXP because it tests what was actually yours |
| D2 | "Tell me about the unpaid invoices. How did you chase them, and how did it go?" | EXP | [grounded] "I ran the appointment book for four physios and chased unpaid invoices" | Say you chased unpaid invoices, and how, in your own words. Answer slot: if there is an outcome you can speak to, say what happened and what part was yours; if there is none to speak to, say so plainly. Give no figure you do not know | The second half of F5, probed for its outcome. EXP because it checks the claim to its end |
| D3 | "What kinds of documents have you prepared in Word?" | JD | [grounded] "I'm good with Word" | The hold is the quote: "I'm good with Word." Answer slot: name the kinds of documents you have prepared, in your own words; if you cannot name specifics, say so plainly and stay with the Word skill you described | F3 says skill, not output, so the probe goes to what was made. JD because it scores a listed skill |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone with more admin experience?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios and chased unpaid invoices"; "okay with Excel" | Pause, restate the question, then hold on what the quotes carry: two years as a receptionist at a physiotherapy clinic, running the appointment book for four physios, chasing unpaid invoices. If pressed on Excel, concede it at its own size: "I'm okay with Excel." Do not concede more than that, and do not claim more than the quotes | The stem tests composure, not content. EXP because it asks for what was yours; the concession draws on F4 |
| E2 | "You say you're okay with Excel. That's not much for a role that works in spreadsheets. Is that fair?" | JD | [grounded] "okay with Excel" | Hold, then concede: restate the quote at its own size, "I'm okay with Excel", agree that it is the level you would describe, and say what you would practise first as a plan. Answer slot: if there is something you have done in Excel, say what in your own words; if not, say so plainly. Do not argue the premise or add skills | The question's premise is the interviewer's and the guidance does not adopt it. JD because it scores the Excel requirement (F4) under pressure |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "managing calendars" (F1) | A2, A4, B2, D1 |
| "booking travel" (F2) | B1, C1, C3 |
| "preparing documents in Word and Excel" (F3, F4) | A3, B4, C1, D3, E2 |
| "processing supplier invoices" (F5) | A2, B3, B4, C2, D2 |
| Remote working (from the role title, not a duty) | A5, C4 |
| Company and strategy knowledge | none: no research ran, so no CO question can be grounded; the upgrade menu says what would change that |

## Reverse questions

| # | Question to ask them | Why it lands |
|---|---|---|
| R1 | "Could you walk me through how equipment and onboarding work for a new assistant, from offer to first day?" | It puts the invite's equipment arrangements into the interviewer's own words, so you can compare them with the invite before you act on either |
| R2 | "What does a typical week look like in this role: how much is calendars, travel, invoices and documents?" | Shows the weight of the duties where your material is thinnest (F2, F4, F5), so you know what to prepare first |
| R3 | "Which tools would I work in: calendar, spreadsheets, any invoice or accounting system?" | Turns the open questions in F1, F4 and F5 into specific things to get ready before day one |
| R4 | "Who would I work with day to day, and who approves invoices?" | Shows you are thinking about where the work sits, and ties to the invoice duty |
| R5 | "What would a good first month look like, and what could I do in it that would genuinely help the team?" | A reciprocity question: it asks what you can add, not only what you need |
| R6 | "What are the next steps after this call, and when should I expect to hear?" | Closes the call on process and gives you a date to hold them to |

## Prohibited claims

Claims this pack will not coach. Each entry is the stretched wording of something you did say, so the honest form is your own sentence at its own size.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars or diaries for a team of managers or executives | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation, not words for you: the material says an appointment book, not business calendars. A4 and D1 keep their slots inside the book |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: you chased unpaid invoices. The limit is the pack's observation: the material says chasing, not processing. C2 and D2 stay inside the chasing |
| Strong or advanced Excel skills | Inflated form of F4 | F4's quote at its own scope: "I'm okay with Excel." A3 and E2 hold that and no more |

## Sources

Provided documents: your message, which holds the invite's text, the ad's duties as you described them, and your background. No dossier was provided.

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | No search was sent. It would have themed VAL questions; none are in this pack |
| 2. `Brennock Facilities Ltd interview process administrative assistant` | skipped | The invite states the one session (a 30-minute video call with the office manager), which fixes the loop and the persona weights |
| 3. `Brennock Facilities Ltd strategy` / recent news | unavailable | No search was sent. It would have fed CO questions, which the pack lacks |
| 4. `{interviewer name} Brennock Facilities Ltd` | n/a | No name was given, only a title, so there was no query to form; the interviewer read is absent |
| 5. representative `Remote Administrative Assistant` JD | skipped | The ad's duties, as you described them, fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's full text → the five requirement quotes become the ad's own words, and any duty you did not mention becomes a row and a question
- Who the office manager is, and whether you would report to them or work beside them → reweighted personas, a short interviewer read and a reverse question tied to their path
- A research pass on the company (up to 6 searches and 2 page fetches, several minutes; a deeper pass adds up to 6 more and 2 more) → CO and VAL questions grounded in what the company publishes, and a loop check; results that cannot be tied to this company would be reported as not established
- What you have actually done on travel booking, with invoices (whose, and what you did with them), in Excel and in Word → the discovery rows F2, F4 and F5 move toward evidence, and the answer slots become your own sentences
- Any guidance the employer gave about what the call will cover → coverage now rests on a hiring-manager prior
- How much prep time you have → a prioritised schedule instead of the full pack
- A tuesday-dossier.md → verified evidence and any prohibited claims as constraints, in place of the ones this pack built itself
