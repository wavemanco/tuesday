Loading the research step: I'm running two searches on Lumenvale Software (its published values, then recent strategy or news) before I write the prep pack.
Before the prep, one thing in the invite: it says "Our hiring process is fully remote and is carried out entirely on Telegram" and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern. Hold off on paying anything, sending documents, or sharing bank or ID details through that chat. First check the invite with Lumenvale. Use a phone number, email address or form you find yourself on its own website or careers page, not anything in the Telegram chat. The invite may not come from who it names. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/alone/part-5/rooms/case-10-denied-27b40180/lumenvale-software_customer-support-specialist_interview_pack.md`. It has 18 practice questions with answer guidance, a table matching your experience to the ad, reverse questions to ask them, and a list of claims I won't coach you to make. I built it for a hiring-manager round, because the invite names the support team lead but not their relationship to the role. My searches on Lumenvale were refused, so nothing in the pack says anything about the company's products, values or strategy.

The question I'd rehearse most is A1: "You haven't worked for a software company before. How would you get up to speed on our product?" Your own line, "I've never worked for a software company", is the honest opening, followed by a plan for learning the product.

Say the word and I'll play the interviewer on A1 as a live text drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Did the Lumenvale careers page you applied through ask for your Telegram username, and does that page list this role?
2. Is the support team lead likely to be your future manager? The answer reweights the question banks.
3. Can you paste the full text of the job ad and your CV? The pack works without them, but they would replace my summary of the ad with its own words.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software

Round: a text chat on Telegram with the support team lead, named in the invite as "our support team lead". The lead's name and their relationship to the role are not given, so this pack is built as a hiring-manager round.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | Meaning |
|---|---|
| VAL | Behaviour against the company's published values |
| EXP | Whether your own experience holds up to follow-up questions |
| JD | A requirement from the job ad, including its gaps |
| CO | Company and strategy knowledge |
| CASE | A live problem set in the role |

No VAL or CO question appears: no values-style round is detected, and no company research ran (see Sources). Guidance is scaffolding, not a script. Answer in your own words, in short typed messages. An answer slot is an instruction for the interview: answer it truthfully from your own experience, or say plainly that the practice was not yours.

## Fit snapshot

Requirements are quoted from the ad as you listed them in your message. The full ad text was not supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad, as you listed it in your message | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | The quote already reaches the requirement, but it is a self-reported line with nothing inspected behind it, so expect a probe. Lead in its own terms: three years, customer service advisor, energy supplier. Keep "around", and keep calls and emails as one combined figure. Answer slot: expect probes on how the figure was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer each in your own words, and say plainly if you do not know how it was counted |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad, as you listed it in your message | "I use Freshdesk every day" — your message | medium | [inferred] | none | The pack reads Freshdesk as a similar ticketing tool; confirm that against the full ad. Say the quote as it stands. Zendesk is not in your material (section 13). Answer slot: expect a probe on what you do in the tool; say what you actually do there, in your own words, and if you use only part of it, say so plainly |
| F3 | "clear written communication" — the ad, as you listed it in your message | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote shows emails were part of the job, not how they were written. The pack's observation: this chat is itself a sample of your writing. Answer slot: expect a request to write a reply live or describe one. If you have a reply, template or message you wrote, say what it was and why it worked, in your own words; if you have none, say so plainly and describe how you would write the reply in front of you |
| F4 | "confidence handling escalations" — the ad, as you listed it in your message | none given | none | [grounded] | discovery | Your material says nothing about escalations, and silence is not absence. Answer slot: expect a "tell me about a time" probe. If you handled one, say what it was and what part was yours; if you never did, or it was not yours, say so plainly and say how you would handle one |
| F5 | Experience of a software company or its product (plain prose, not in the ad as you listed it) | "I've never worked for a software company" — your message | none | [generic] | capability | The gap is one you stated, and no wording closes it. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. No claim to software or product-support work, and nothing added to make the gap feel smaller |
| F6 | Training or supporting colleagues (plain prose, not in the ad as you listed it) | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | Say it at its own scope: four new starters, the refunds process, last year, with "trained" as the verb. Answer slot: expect "what did that involve"; say what you actually did, and if you taught a process you did not write or change, say so plainly |

## Persona table

The invite establishes one session: a text chat with the support team lead. The weights rest on hiring-manager priors because the lead's relationship to the role is not stated. If the lead is not your future manager, the weights shift.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the software gap and the escalation gap | High, weight 5: a hiring-manager prior, and F5 and F4 are the thinnest rows | Rehearse A1 until it is boring; hold on F1 and F2, concede F5 in plain words |
| Case / Strategist | Live customer scenarios you answer by typing | High, weight 5: a hiring-manager prior, and a text chat suits live writing | Clarify first, structure the reply, keep messages short; no claim about your past is needed |
| Data-Driven Prober | Questions on "around 60 a day", Freshdesk and the four starters | Medium, weight 3: F1, F2 and F6 are the lines a reader can test | Know what you can say about how the figure was counted, and say plainly where you do not know |
| Conversational / Rapport Builder | Friendly opener, then casual questions that are still scored | Medium, weight 3: the invite's register is friendly and the medium is chat | Prepare the three-sentence arc in D1; treat casual questions as scored |
| Pressure | Short time-boxed challenges | Low, weight 2: nothing in the invite signals it, and chat slows interruption | Pause, restate, hold through two follow-ups, concede one thing specifically |
| Values / Behavioral | Not weighted | No loop source documents a values-style round, and the invite names one chat with the team lead | A behavioural prompt on escalations is covered in A3 |
| Peer Evaluator | Not weighted | The invite names the support team lead, not a peer | None needed |

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't worked for a software company before. How would you get up to speed on our product?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | The highest-ROI rehearsal in this pack. Level 1: say the plain acknowledgment, "I've never worked for a software company", then a plan in your own words for learning the product: what you would read, who you would ask, how you would check you had understood. It is a plan, so claim no product knowledge. Level 2, if pressed on why support in energy would carry over: hold on what the quote carries, three years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day, and add no claim about what that proves. Level 3, "what if you get a technical question you cannot answer": describe the steps you would take, as a plan. Level 4, "so you would be slower than someone from software": concede the one thing, "on the product, yes, I've never worked for a software company", then stop | F5 is the largest stated gap and F1 is what the hold stands on. JD because it scores the fit with the role as a software company's; Skeptic because it is the objection most likely to arrive in some form |
| A2 | "The ad says Zendesk or a similar tool, and you've said you use Freshdesk. How would you get on with a new ticketing tool?" | JD | [grounded] "I use Freshdesk every day" | Hold on the quote: "I use Freshdesk every day." Answer slot: expect a probe on moving between tools. If you have moved from one tool to another, say what happened and how you found it, in your own words; if you have not, or it was not yours to do, say so plainly and say how you would approach a new one | F2 is the evidence for the ticketing-tool requirement; the premise is the ad's and the quote carries the Freshdesk part |
| A3 | "Tell me about a time you handled an escalation." | JD | [generic] | Selection scaffold: choose a case that went beyond what you could settle yourself, or where the customer asked for someone else. It needs a clear problem, what you did yourself, where it went next and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 is silent on escalations, and the ad raises the theme; JD for the stated requirement, and the guidance claims nothing about your past |
| A4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Name the gap you genuinely believe is largest. The pack's observation: your material states no software work (F5) and shows nothing either way on escalations (F4). If your answer is software, say "I've never worked for a software company" and follow it with the plan from A1. If it is something else, name it plainly | F5 and F4 are the rows an interviewer reaches for; JD because it asks you to self-assess against the ad |
| A5 | "What draws you to a software company when your background is energy?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I've never worked for a software company" | Give your own reasons in your own words. Nothing in your material states them, so the pack supplies none. If you have no specific reason to name, say what you do know about this job and why it holds your interest | F1 and F5 together make the motivation probe likely; EXP because it tests consistency between your history and your stated reasons |

### B. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes in saying the latest update broke a feature they rely on, and they want a refund. What is your first reply?" | CASE | [generic] | Acknowledge in one line; ask what they see and since when; do not promise a fix or a refund you cannot grant; say what happens next and by when; note it on the ticket. The question needs no claim about your past | A live problem from the role, one the ad's escalation and written-communication lines make likely; CASE because reasoning is scored over the answer |
| B2 | "A customer has written in three times in two days about the same problem and says nobody has answered properly. What do you do first?" | CASE | [generic] | Read the whole history before replying; reply once, owning it; say what is known and what is not; decide whether it needs someone else and say who and why; give a time for the next update | F4 raises the escalation theme; CASE with JD content |
| B3 | "A customer asks how a feature works and you don't know. Walk me through the next ten minutes." | CASE | [generic] | Tell the customer honestly that you are checking and when you will reply; look in the knowledge base or ask a colleague; reply only with what is confirmed; note the gap. It is a plan, so do not say you have done it unless you did | The F5 gap rehearsed as a live problem |
| B4 | "I'll send you a customer message: 'Your app is rubbish, fix it now.' Type your first reply." | CASE | [generic] | Short and calm; one line acknowledging; one clarifying question; no promise you cannot keep; plain words. Read it once before you send it | F3 is thin, and a chat interview can test writing directly; CASE with JD content |
| B5 | "Two customers write in at once: one wants a password reset, one is upset about a billing error. Who do you reply to first, and why?" | CASE | [generic] | Ask one clarifying question first, such as whether the reset blocks something time-sensitive. State the rule you would actually use in one sentence, then say what you would send each. The reasoning is scored, not the order | Prioritisation under load; CASE because it is a decision, not a record |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said around 60 calls and emails a day. How was that figure counted?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Keep "around" and keep calls and emails together as one figure. Answer slot: say where the figure came from, in your own words, whether your own estimate or something else; say what made a day busier or quieter; say the assumption you would defend least; say which part was yours. If you do not know how it was counted, say so plainly | The headline figure on F1 gets a defend-the-number question |
| C2 | "What do you actually do in Freshdesk in a normal day?" | JD | [grounded] "I use Freshdesk every day" | Say what you actually do, in your own words, and name only what you use. If you use only part of the tool, say so plainly | F2 is a one-line claim, so a probe on it is likely |
| C3 | "You trained four new starters on the refunds process. What did that involve?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell it at the quote's scope: four new starters, the refunds process, last year. Answer slot: expect a probe on how the training ran and whether the process was yours; say what you actually did, and if you taught a process you did not write or change, say so plainly | F6 holds a figure and a verb, both of which a prober tests |

### D. Conversational / Rapport Builder (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, tell me about yourself and how you came to apply." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | A three-beat arc built only from the quotes: three years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day; Freshdesk every day; four new starters trained on the refunds process last year. Answer slot: the closing beat, why this job, is yours to give in your own words; nothing in your material states it | F1, F2 and F6 are the sentences an opener can stand on |
| D2 | "The role is remote and the ad asks for clear written communication. How do you feel about working that way?" | JD | [grounded] | Answer slot: if you have worked remotely, say how it went in your own words; if you have not, say so plainly and say what you would do to stay in touch with the team. The guidance claims nothing about your past | F3's requirement asked casually; the remote setting comes from your message |
| D3 | "What does a clear written reply look like to you?" | JD | [generic] | State your own standard in a sentence or two, such as what the customer should be able to do after reading it. Answer slot: if you have a reply of your own that you can describe, say what it was; if not, say so plainly | F3 asked as an opinion, which is how a rapport-style interviewer scores it |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, rather than someone who has already worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I've never worked for a software company" | Pause and restate the question. Hold on the first two quotes. Hold through two follow-ups by returning to them, not by adding to them. Concede the one specific thing: "I've never worked for a software company." Do not claim to be better than the other candidate, and stop after the concession | F1 and F2 are the hold and F5 is the concession |
| E2 | "That figure of around 60 a day. How much of that was actually you?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Hold on the sentence: it says you were answering. Answer slot: if any part of the figure was a team number or an estimate, say so plainly; if it was yours, say that and add nothing | The attribution probe on F1, in a pressure register |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" | C1, D1, E1, E2 |
| "experience with Zendesk or a similar ticketing tool" | A2, C2 |
| "clear written communication" | B4, D2, D3 |
| "confidence handling escalations" | A3, B2 |
| Software company gap (not in the ad as you listed it) | A1, A4, A5, B3, E1 |
| Company values and strategy | none, because no values-style round is detected and no research ran |

The single most likely objection is A1. It gets the deepest rehearsal and is the highest-ROI prep in the pack.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does the first month look like for someone new to your product?" | It puts the F5 gap in the interviewer's terms and turns it into an onboarding conversation |
| 2 | "How does the team handle escalations, and what does a good handover look like?" | It follows the ad's escalation line and shows you think about the handover, not only the case |
| 3 | "Which ticketing tool does the team use, and how are new starters trained on it?" | It follows the ad's tool line and asks about training, not only the tool |
| 4 | "What does a clear reply look like on your team? Is there one you would point a new starter to?" | It shows you care about the written standard the ad asks for |
| 5 | "What do hours and coverage look like for this remote role, and how does the team stay in touch day to day?" | A reasonable remote-role question, and the answer tells you how the team works |
| 6 | "How would you judge a new person's first 90 days?" | It asks what good looks like and gives you something to aim at |
| 7 | "Is there a way I can confirm the role and the rest of the process through Lumenvale's own website or careers page?" | A reasonable thing for a candidate to ask, and how the answer comes back is informative |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Experience with Zendesk | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says Freshdesk, not Zendesk. A2's slot stays on how you would approach a new tool |
| Having worked in, or supported, a software company or its product | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |
| Led, managed or owned the training or the refunds process | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: your material says you trained four new starters on the refunds process, not that the process was yours. C3's slot stays inside the training |
| Handled 60 tickets a day | Inflated form of F1 | F1's quote at its own scope: "around 60 calls and emails a day", calls and emails together |

## Sources

Provided documents: the invite text you pasted, and your description of the job ad and of your background in your message. No CV and no full ad text were provided.

Searches sent:

- "Lumenvale Software values" — refused
- "Lumenvale Software company strategy recent news" — refused

Nothing in this pack states anything about Lumenvale's products, values or strategy.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | The search was refused. It would have fed VAL themes and a values cheat sheet; none appears |
| 2. `Lumenvale Software interview process customer support` | skipped | The invite fixes the loop: one text chat with the support team lead. Persona weights follow it |
| 3. `Lumenvale Software strategy` / recent news | unavailable | The search was refused. It would have fed a CO or CASE question grounded in current strategy; none appears |
| 4. `{interviewer name} Lumenvale Software` | n/a | The interviewer is unnamed in the invite, so there was no query to form; the interviewer read is absent |
| 5. representative `Customer Support Specialist` JD | skipped | The requirements in your message fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full text of the job ad → the four requirement rows quote the ad itself instead of your summary, and any further requirement gets its own row and question
- Your CV → the evidence cells quote it, and F3 and F4 may be upgraded
- Your answers to the F3 and F4 slots, a written reply you wrote and an escalation you handled → those rows can move from discovery to stronger evidence, and A3 and B4 can be mapped to a real story
- Permission for company research, values and recent news → a values cheat sheet if a values round is documented, and a CO question grounded in current strategy
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → a grounding brief with current vocabulary, and role-family loop reports
- The support team lead's name → an interviewer read, persona weights adjusted from their public professional footprint, and a reverse question tied to their path
- Anything the recruiter says about what the chat will assess → coverage of those areas instead of round-type priors
- Your prep time → a prioritised schedule sized to it
- A `tuesday-dossier.md` → verified evidence and a rehearsal priority taken from evidence rather than inferred
