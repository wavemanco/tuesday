I'll read the reference files the skill points to before building the pack.
I've finished the research (5 searches, 2 page fetches) and am now writing the prep pack to a file.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/alone/part-5/rooms/case-9-canned-9bcd0180/halvering-elementary_fourth-grade-teacher_interview_pack.md`. It has 19 questions across six panel styles, plus reverse questions and a fit snapshot of your résumé against the role. I built it for a panel with Principal Vantongeren and two fourth-grade teammates. I didn't have the district's own posting, so the requirement rows come from a representative listing and are labelled as inferred. Your licence line meets the invite's licence requirement as you stated it. Checking the licence record is yours.

Your résumé text included a Social Security number. Interview prep doesn't need it. I haven't used it or repeated it, and I'd keep it out of anything you paste or send before an offer. I also left your licence number out of the pack and out of every search.

Say the word and I'll play the Skeptic on A1, the question the pack names as your highest-ROI prep: "You've taught third grade, not fourth." I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Did HR say anything about what the panel will cover, or ask you to bring or prepare something such as a sample lesson? A named deliverable would add a build section.
2. Can you paste the district's own posting for this role? If you can't, the pack stays on the representative listing.
3. Do you want a deeper research pass, with up to 6 more searches and 2 more fetches and several more minutes? It would add a grounding brief and could fill the gap on Halvering itself, which my one school-name search didn't find.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

- Role: Fourth Grade Teacher
- Employer: Halvering Elementary School, Orrinsford Community School District
- Round: 45-minute panel on Thursday, with Principal Dolores Vantongeren and two members of the fourth-grade team (the two team members are not named in the invite)
- Built on: the invite and your résumé text. The district's own posting was not in hand, so requirement rows that come from a representative listing are labelled inferred.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scored on. Every question carries one persona letter and one type tag.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs, not generic virtue |
| EXP | Whether your own statements survive scrutiny, and what was actually yours |
| JD | The listed responsibilities and qualifications, including where your material is thin |
| CO | Homework on the district, the school and the people |
| CASE | A live problem from the actual job, answered aloud |

Question IDs run A to E and then G for the conversational bank. F is kept for the fit-snapshot rows (F1 to F11), so a question never shares an ID with a row. Answer guidance is scaffolding, not a script: speak it in your own words, and rehearse only what you actually did. An answer slot is an instruction for the interview, not a question for you now.

Highest-ROI prep: A1, the fourth-grade question. It is your own stated gap, it has the most follow-up levels, and it arrives from a Skeptic and a Peer alike.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate, shown met by your CV on its face: licence, endorsement, status and expiry are all stated, so say it in the quote's own terms. It is a CV line with nothing inspected behind it, and checking the record is yours. The pack asks nothing here |
| F2 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board listing (a representative listing, not the district's posting) | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | discovery | The quote shows the grade and the years, not which subjects. Typical for the role, not this team's practice. Answer slot: expect a probe on subject range. Say which subjects you planned and taught, in your own words; if some were taught by others, or you did not teach them, say so plainly and stay with the third grade you taught |
| F3 | "differentiate instruction using assessment data" — K12 Jobs Board listing | none given | none | [inferred] | discovery | Your material is silent here, which is not the same as a gap. Answer slot: if you adjusted teaching using assessment results, say what and how, in your own words; if you did not, or it was not yours to decide, say so plainly and say how you would begin |
| F4 | "keep clear classroom routines" — K12 Jobs Board listing | none given | none | [inferred] | discovery | Silence, not a gap. Answer slot: say which routines you actually used and why, in your own words; if routines were set by your school or by someone else, say so plainly and stay with the third grade you taught |
| F5 | "communicate regularly with families" — K12 Jobs Board listing | "I write a weekly email to families" — your CV | medium | [inferred] | none | The quote already reaches the requirement in role-relevant terms. Lead with it as it stands: a weekly email, to families. A CV line with nothing inspected behind it, so expect a probe, and the pack adds no other way of communicating |
| F6 | "work with the grade-level team" — K12 Jobs Board listing | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [inferred] | presentation | Say the first sentence as it stands. It speaks to working with a grade-level team through that move and to nothing else the team did. Keep it apart from the second: the move is not a team-lead role, and you have said you have not been one. Plain acknowledgment: "I haven't been a team lead." |
| F7 | "experience in grades 3 to 5 preferred" — K12 Jobs Board listing | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | none | Third grade sits inside the listing's range, so lead with it in the quote's own terms. The listing marks it preferred, not required, and it is a representative listing, not this district's |
| F8 | "Fourth Grade Teacher position" — the invite | "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet" — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then the adjacent fact at its own scope: six years teaching third grade at a public elementary school in Joliet. Then how you would learn fourth grade, said as a plan and never as a past |
| F9 | "Every Child a Reader: no student leaves third grade without a reading plan" — Orrinsford Mission and Beliefs page | "I've run the after-school reading club for the last two years" — your CV; "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | discovery | Both quotes touch reading and neither shows whether it reaches a student's reading plan. Answer slot: if any of your third graders left with a reading plan, say who made it and what part was yours; if none did, or it was not yours, say so plainly and stay with the club and the curriculum move |
| F10 | "Families Are Partners: each teacher speaks with every family each term" — Orrinsford Mission and Beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | A weekly email is adjacent to speaking with families and does not reach it. Words: "I write a weekly email to families." Answer slot: if you have spoken with families, say how and how often, in your own words; if you have not, or not every term, say so plainly and stay with the email |
| F11 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it" — Orrinsford Mission and Beliefs page | none given | none | [grounded] | discovery | Silence. Answer slot: if an assessment result and your own read of a student ever pointed different ways, say what you did, in your own words; if that never happened, say so plainly and say how you would weigh the two |

## Reading the interviewer

Public professional footprint only. It covers the principal; the two team members are not named, so no read exists for them.

| # | What the public record says | Source | Provenance | What it means for you |
|---|---|---|---|---|
| I1 | Dolores Vantongeren has been principal of Halvering Elementary School since 2022 | ilprincipalsforum.example speaker page (search result text; page not fetched) | [grounded] | Treat her questions as hiring-manager questions: capability and gaps first |
| I2 | She was a reading specialist for nine years before that | Same | [grounded] | Reading questions come from someone who has worked in reading instruction. Say what you did and what you have not done; do not describe methods you have not used |
| I3 | Her 2025 forum talk, "Small Groups, Big Readers", covered weekly reading conferences in grades 3 to 5 | Same | [grounded] | The topic may come up. Give any view on small groups or conferences as a view unless you have done it (G2) |
| I4 | Mirror opportunity: her path runs from reading specialist to principal, and your side of the shared subject is "I've run the after-school reading club for the last two years" (F9) | I2 and F9 | [grounded] | Offer it as shared subject matter, never as a similar career jump and never as shared identity. Use it in a reverse question rather than by pointing it out |

## Persona table

The invite is a loop source: one 45-minute panel with the principal and two fourth-grade team members. It names no values round, so none is detected. The weights blend hiring-manager priors for the principal and peer priors for the two team members.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Skeptic | The principal and the team probing the fourth-grade gap and the seam between leading a move and not being a team lead | High: you stated two negatives (F8, F6), and hiring-manager priors tilt to Skeptic | Rehearse A1 until it is boring. Hold your position through two follow-ups, then concede the specific limit. Use bridges only from your own quoted sentences | A1 to A4 |
| Peer Evaluator | The two fourth-grade teammates asking about seams, disagreement and credit | High: the panel includes two teammates, and the listing line is "work with the grade-level team" | Reciprocity: what you offer them as well as what you need. Offer principles for the seam rather than pretending to know it | B1 to B4 |
| Case/Strategist | The principal posing live reading problems | Medium-high: hiring-manager prior, plus a reading background (I2, I3) and the board's literacy plan | Clarify, then objective, approach, how you would know it works, risks. Think aloud and challenge one premise respectfully | C1 to C4 |
| Values/Behavioral | Behavioral questions themed on the three published beliefs | Medium: the beliefs page says three beliefs guide every hire, but the invite names no values round, so none is detected | Map a story where a quoted sentence carries one; use a selection scaffold with an honest branch where none does | D1 to D3 |
| Data-Driven Prober | A teammate asking for a walk-through of the routines or the curriculum move | Low-medium: peer prior only. No data-driven self-description turned up, and your résumé text holds no results figures | Know what you can and cannot say about how each step happened, and say plainly when you do not know | E1, E2 |
| Conversational | The opening "tell me about yourself" | Medium: panels commonly open this way, and it is still scored | A 90-second arc built from your own sentences (G1) | G1, G2 |
| Pressure | Not expected | Low: no signal in the invite or the research. Hold-then-concede is practised inside A1 and A2 | None separate | none |

## Question banks

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade, not fourth. What will be different for you in fourth, and how do you plan to get up to speed?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | The highest-ROI rehearsal in this pack. Beat 1, the plain acknowledgment: "I haven't taught fourth grade." Beat 2, the adjacent fact at its own scope: six years teaching third grade at a public elementary school in Joliet, in your own words. Beat 3, the plan, said as a plan and never as a past: what you would ask the fourth-grade team first, and what you would want to see before your first week, naming only things you would really do. Follow-up one, what worries you most: name the difference you honestly expect to matter most; if you do not know what it will be, say so plainly. Follow-up two, why not someone who has taught fourth grade: concede the real difference and return to beats 2 and 3. Do not argue that third grade is the same job or that you learn quickly; your material shows neither. Say once, before anyone asks, what you do not yet know about fourth grade | F8 is the plainest gap in the pack, and a panel hiring a Fourth Grade Teacher is likely to reach it in some form. JD because it scores the title itself, with F7 as the adjacent evidence |
| A2 | "You led your grade level's move to a new reading curriculum, but you haven't been a team lead. How do those fit together?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Hold both sentences at their own scope and let the panel do the fitting: "I led our grade level's move to a new reading curriculum in 2024" and "I haven't been a team lead." Say them as two separate facts. Do not call the first team leadership, and do not play it down because of the second. Answer slot: expect a probe on what your leading the move covered. Say which parts were yours, in your own words; if some parts were shared with others or decided by others, say so plainly and stay with your grade level's part. Hold through two follow-ups by returning to the move, never by adding to it | F6 puts the two statements side by side, and a panel is likely to test the seam. EXP because it tests attribution. Skeptic because it presses on a limit you stated yourself |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Name the one that is actually true for you. Your material states one: "I haven't taught fourth grade." If something else is truer, say that instead and say why. Then say how you would close it, as a plan. Avoid a weakness chosen to sound like a strength; this question exists to test that. Answer slot: if the truest answer is one your material is silent on, say it plainly in your own words | The standard Skeptic stem, aimed at F8 and the silent rows F3 and F4. JD because it scores the listed responsibilities |
| A4 | "Why fourth grade, why Halvering, and why now?" | CO | [grounded] research on the district: the beliefs page and the board's literacy plan | Your reasons are yours to give; this pack cannot supply them. Anchor "why here" in what you have read, said as what you read: the district's beliefs page names Every Child a Reader, Families Are Partners, and Teach for Tomorrow, Not for the Test. A board literacy plan adopted in August 2026 was found as search result text only; read the page before Thursday. Say which of these actually draws you; if none does, say what does. Answer slot: why fourth grade and why now are yours to give, in your own words | Motivation consistency is what a Skeptic scores. CO because "why here" needs homework. No search returned anything on Halvering itself, so the school-level answer rests on the principal and the district pages |

### Bank B: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Suppose two teachers on the team disagree about how to run the reading block. What do you do?" | CASE | [generic] | A live problem, so the guidance makes no claim about your past. Offer principles: ask what each person wants for the students, separate a preference from a need, ask how the team normally decides, and accept a call that belongs to someone else. Say aloud one thing you would want to know before taking a side | Peer-style seam question aimed at the listing line "work with the grade-level team" (F6). CASE because it is a live scenario with no past premise |
| B2 | "What would you need from us in your first month, and what could you do for the team?" | JD | [grounded] "I've never taught fourth grade"; "I've run the after-school reading club for the last two years"; "I led our grade level's move to a new reading curriculum in 2024" | Reciprocity, both halves. The need: say that you have not taught fourth grade ("I haven't taught fourth grade") and ask what the team would want you to learn first. The offer: say the club and the curriculum move at their own scope, as things you have done, and offer only what you would actually do for the team. Answer slot: what you offer beyond those two sentences is yours to name; if there is nothing more yet, say so plainly | Peers price what a hire adds to their load. F8 and F9 are the evidence. JD because it scores working with the team |
| B3 | "How do you handle credit when work spans several people?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Use "we" for context and "I" for contribution. The quote is the story: the move was your grade level's, and you led it. Say that and no more. Answer slot: say which part was yours and which was shared; if some of it was decided by others, say so plainly and stay with your part. Do not describe how the work was shared unless you can say it from what happened | A stock peer stem (credit-sharing). F6 is the only evidence of work across people. VAL because it scores partnership behavior rather than a listed duty |
| B4 | "What has working on a grade-level team looked like for you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Start with the move, as it stands. Keep the second fact separate: "I haven't been a team lead." Answer slot: if you worked with your grade-level colleagues on anything beyond the curriculum move, say what and what was yours, in your own words; if not, say so plainly and stay with the move | F6 is the listing line. EXP because it tests what your team experience actually consists of |

### Bank C: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A fourth grader starts September reading well below grade level. What do you need to know first, and what does the first month look like?" | CASE | [generic] | A live problem, so no claim about your past. Structure it aloud: clarify (what the assessment shows, what the student can do, what has been tried, what the family says), then the objective, the approach, how you would know it is working, and the risks. Challenge one premise respectfully, such as how "below grade level" was measured. In front of a former reading specialist, say plainly where you would ask the team or a specialist rather than guess | I2 and I3 make reading problems the likeliest live case from the principal. CASE because it scores structure over the right answer |
| C2 | "The board's literacy plan includes a new grades 3 to 5 reading curriculum from fall 2027. How would you want to take part, as a fourth-grade teacher?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say what you know as what you read, and no more: a three-year literacy plan adopted in August 2026, with a new grades 3 to 5 reading curriculum from fall 2027 (found as search result text; read the page first, since it may have changed). Then your side, at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Do not present that as experience with this district's curriculum. Answer slot: if that move taught you something you would bring to a new curriculum, say what, in your own words; if what you can say is limited, say so plainly and ask what the team needs | The one CO question grounded in current strategy, from research at L1. F9 is the nearest evidence, and the move at your own grade level is not the district's plan |
| C3 | "Plan one week across the subjects you would teach in a fourth-grade class. What do you need to know first?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" | A live problem. Clarify where the class is starting from and what the team's shared plans and the school's existing materials already cover. Then the objective, a weekly arc, how you would check in, and the risks. Answer slot: expect a probe on breadth across subjects. Say which subjects you planned and taught in third grade; if some were taught by others, or not yours, say so plainly and stay with what you taught | F2 raises plan-and-teach across subjects from a representative listing, typical for the role and not this team's practice. JD content, CASE delivery |
| C4 | "Your class's reading assessment results come back mixed. What changes in next week's teaching, and what doesn't?" | JD | [grounded] research on the district: the beliefs page | Use the district's own wording as your frame: assessments inform teaching and never replace it. Structure: what the data does and does not say, what you would change, what you would deliberately keep, how you would know. Answer slot: if you have adjusted your own teaching using assessment results, say what and how, in your own words; if you have not, or it was not yours to decide, say so plainly and walk through how you would | F3 is silent in your material, and F11 is the district's published belief. JD because it scores the listed differentiation line, in CASE form |

### Bank D: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Every Child a Reader is one of our three beliefs. Tell me about a time you helped a student with their reading." | VAL | [grounded] "I've run the after-school reading club for the last two years"; "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on the club: it is after school, it is a reading club, and you have run it for two years. Those are the beats the sentence states; tell them in your own words. Answer slot: the beliefs page ties Every Child a Reader to a reading plan, so expect a probe on plans. If any of your third graders left with a reading plan, say who made it and what part was yours; if none did, or it was not yours, say so plainly and stay with the club | F9 is the evidence. VAL because the question is themed on a published belief |
| D2 | "Families Are Partners is another of our beliefs. When have you worked with families on a student's learning?" | VAL | [grounded] "I write a weekly email to families" | Story-mapped on the one sentence: you write a weekly email to families. Say it as it stands. Answer slot: the beliefs page says each teacher speaks with every family each term, so expect a probe on spoken contact. If you have spoken with families, say how and how often, in your own words; if you have not, or not every term, say so plainly and stay with the email | F10 is the evidence, adjacent to the belief and not reaching it. VAL because it is themed on a published belief, with the listing line in F5 as the second raising source |
| D3 | "Teach for Tomorrow, Not for the Test. Tell me about a time an assessment result and your own read of a student pointed in different directions." | VAL | [grounded] research on the district: the beliefs page | No sentence of yours carries this one, so this is a selection scaffold. Pick a time with a named student situation, a moment where you weighed the two, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F11 is silent in your material. VAL because it is themed on a published belief |

### Bank E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "What classroom routines do you keep, and why those?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: the representative listing asks for clear classroom routines, typical for the role. Say which routines you actually used and why, in your own words; if routines were set by your school or by someone else, or you used none you would name, say so plainly and stay with the third grade you taught. Say plainly if you do not know why a routine was the way it was | F4 is silent in your material. JD because it scores a listed duty, delivered as a walk-through |
| E2 | "Walk me through how your grade level moved to the new reading curriculum." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The sentence is the only story: your grade level moved to a new reading curriculum, and you led the move, in 2024. Say that as it stands. Answer slot: expect a probe on the steps. Say which steps were yours and how you decided them, in your own words; if some steps were taken by others, or there was no step like that, say so plainly and return to the move itself. Say plainly where you do not know how something was counted or decided | F6 and F9 rest on this one sentence, so a prober will go through it clause by clause. EXP because it tests attribution |

### Bank G: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through your journey." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc, one beat per sentence and each at its own scope: six years teaching third grade at a public elementary school in Joliet, then the curriculum move, then the club, then the weekly family email. Close with your actual reason for this role. Answer slot: that reason is yours to give; say it in your own words | The opener is scored even when it feels friendly. F7, F6, F9 and F5 supply the beats |
| G2 | "What are you curious about in reading instruction right now?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | There is no right answer, so give a real one. If you have a view on small groups or weekly reading conferences, the subject of the principal's 2025 talk (I3), say it as a view. Answer slot: if you have used either, say how, in your own words; if you have not, say so plainly and say what you would want to learn. Link to the club only at its own scope | Casual questions on a hot topic are still scored. I3 makes reading a likely subject |

### Requirement coverage

| Requirement | Fit rows | Questions |
|---|---|---|
| Licence with elementary endorsement | F1 | none, and why: it is a term your CV states as met, not something scored by an answer; keep the record to hand |
| Plan and teach across subjects | F2 | C3 |
| Differentiate instruction using assessment data | F3, F11 | C4, D3 |
| Clear classroom routines | F4 | E1 |
| Communicate with families | F5, F10 | D2 |
| Work with the grade-level team | F6 | A2, B1, B2, B3, B4, E2 |
| Experience in grades 3 to 5 | F7 | A1, G1 |
| Fourth Grade Teacher position | F8 | A1, A3, A4 |
| Every Child a Reader | F9 | D1, C2 |

Defend-the-number: your résumé text states years (six, and two) and a year (2024), and no results figures, so the pack holds no defend-the-number question.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "You came to the principalship after years as a reading specialist. How has that shaped what you want fourth-grade reading to look like here?" | Ties to the principal's own path (I2) and invites her to talk about her subject, which turns a screen into a conversation |
| 2 | "What could a new teammate do in the first month that would help your team most?" | The peer reciprocity question: it shows you are thinking about their load as well as your own |
| 3 | "What does the fourth-grade team already have planned for reading that I would step into, and what is still open?" | Gets the real shape of the first weeks, and answers part of the fourth-grade gap in F8 from the people who know |
| 4 | "The board's literacy plan mentions a new grades 3 to 5 reading curriculum from fall 2027. What will fourth grade be doing between now and then?" | Shows you read the district's own plan. Confirm the plan on the district site first, since it came from search result text |
| 5 | "The district's beliefs say each teacher speaks with every family each term. How does the fourth-grade team make that work?" | Shows you read the beliefs page, and tells you what family contact is expected (F10) |
| 6 | "What would a clearly successful first year in this role look like?" | A closing question every panel can answer, and it shows you are aiming at their measure rather than yours |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't taught fourth grade." Then F8's third-grade quote at its own scope. No slot |
| Has been a team lead | A negative you stated, F6 | The plain acknowledgment F6 gives: "I haven't been a team lead." Then "I led our grade level's move to a new reading curriculum in 2024" at its own scope |
| Led, or has experience with, this district's coming reading curriculum | Inflated form of the curriculum-move quote in F9, widened by C2's setting | The move quote at its own scope. The limit is the pack's observation: your material gives a move at your own grade level in 2024, and nothing about the district's plan. C2's slot stays inside the move |

## Sources

Provided documents: the invite text and your résumé text. No dossier was present. Two sensitive items in what you pasted were not used.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

Searches, by query:

- "Orrinsford Community School District mission values" returned https://orrinsfordschools.example/about/mission-and-beliefs
- "Halvering Elementary School Orrinsford Community School District" returned no results
- "Orrinsford Community School District strategic plan news" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan (search result text only; page not fetched)
- "Dolores Vantongeren principal Halvering Elementary" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren (search result text only; page not fetched)
- "fourth grade teacher job description elementary school Illinois" returned https://k12jobsboard.example/listings/fourth-grade-teacher

Fetches: the Orrinsford Mission and Beliefs page and the K12 Jobs Board listing, both read in full. The listing is a representative one from a jobs board, not the district's posting.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | Query 1 and a fetch of the official beliefs page: the three beliefs by name, rows F9 to F11 and bank D |
| 2. `{company} interview process {role family}` | skipped | The invite's own words establish the loop (one 45-minute panel with the principal and two fourth-grade team members), so persona weights follow from it and no result could have changed them |
| 3. `{company} strategy` / recent news | yes | Query 3, search result text only: C2, A4 and reverse question 4 |
| 4. `{interviewer name} {company}` | yes | Query 4, search result text only: rows I1 to I4 and reverse question 1. The two team members are unnamed, so no read exists for them |
| 5. representative `{role title}` JD | yes | Query 5 and a fetch: rows F2 to F7 and the JD-tagged questions, all labelled inferred |
| Outside the declared targets | yes | Query 2, a search on the school's name. It returned no results and moved nothing: school-level facts about Halvering are not established |

## Upgrade menu

- The district's own posting for this role → F2 to F7 move from inferred to grounded, and the JD-tagged questions are re-keyed to its actual lines
- What HR said about the panel's focus, or anything to bring or prepare, such as a sample lesson → coverage re-weighted, and a build section if a deliverable was announced
- The names of the two fourth-grade team members → a per-member interviewer read, persona weights adjusted to each, and a tailored reverse question
- Your answers to the answer slots (which subjects you taught, what your curriculum move covered, whether you used assessment results, whether you have spoken with families, which routines you used, whether any third graders had reading plans) → F2, F3, F4, F9, F10 and F11 gain story-mapped guidance in place of slots
- A copy of your licence record showing status and endorsement → F1 moves from medium to high
- A tuesday-dossier.md from an evaluation of this role → verified evidence and a sharper ranking of the likeliest objection; the pack does not need one
