# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Employer:** Orrinsford Community School District (Halvering Elementary School)
**Format:** 45-minute panel, Thursday
**Panel:** Principal Dolores Vantongeren (hiring-manager role), plus two members of the fourth-grade team (peers, names not given)
**Built from:** the invite and your resume. No posting was supplied, so beyond the license line the role's requirements are role-family prose or the district's published beliefs.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Every question carries both, so you can see the coverage at a glance.

| Type | What it scores |
|---|---|
| VAL | Whether your behavior shows the district's published beliefs, not generic virtue |
| EXP | Whether a line of your resume survives detail, and what was actually yours |
| JD | The role as stated: can you do the listed job, gaps included |
| CO | Whether you have done your homework on the district and can think at its level |
| CASE | A live problem from the role, scored on structure and reasoning |

- Guidance is scaffolding, not a script. Say it in your own words, in 90 to 120 seconds.
- Provenance labels: `[grounded]` traces to your documents or to a page read for this pack; `[inferred]` is derived from an adjacent source, with the derivation named; `[generic]` is a role-family pattern with no claim about this school or about you.
- An answer slot is an instruction for the interview, not a question for you now. It has two branches, and both are honest answers.
- Fit-snapshot rows are F1 to F7. Question banks use letters A to E, G and H. The letter F is skipped so that a question ID never collides with a row ID.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The requirement is a gate, and your material shows it met: kind, endorsement and status are all in your quote, and the grades 1–6 span includes grade 4. It is a CV line with nothing inspected behind it, so confidence stays at medium, and checking the license record is yours to do. The license number that follows the quote in your CV is left out of this pack and out of every search on purpose. Say it in the quote's own terms: "I hold an Illinois Professional Educator License with an Elementary Education endorsement for grades 1–6, registered and active through June 30, 2029." |
| F2 | "Fourth Grade Teacher position" — invite | "I've never taught fourth grade" — your CV | none | [grounded] | capability | A gap wording cannot close, and your CV says so. Words: "I haven't taught fourth grade." Then the adjacent evidence in F3, then how you would learn the grade, said as a plan in the future tense and never as a past. Never a claim to fourth-grade work, and nothing added to make the gap feel smaller |
| F3 | Teach a whole class across the core subjects (role-family requirement, no posting supplied) | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [generic] | transferability | Your material says six years of third grade; the grade differs from this role's, and the line does not say which subjects. Words at the quote's own scope: "For six years I taught third grade at a public elementary school in Joliet." The step to fourth grade is F2's acknowledgment and a plan, not a claim. No answer slot here, because no source raises a further probe on this row |
| F4 | "no student leaves third grade without a reading plan" — district Mission and Beliefs page, belief Every Child a Reader (fetched) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Your material says a curriculum move and a club, with nothing inspected behind either, and the words stay there: "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." Answer slot: the belief about reading makes a probe on how the move or the club reached individual readers likely. If either did, say how, in your own words; if neither did, or it was not yours to say, say so plainly and stay with the move and the club |
| F5 | "each teacher speaks with every family each term" — district Mission and Beliefs page, belief Families Are Partners (fetched) | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | Your material says a weekly email, not conversations, and the words stay there: "I write a weekly email to families." Answer slot: the belief makes a probe on your other contact with families likely. If any other contact was yours, say what it was and how often, in your own words; if there was none, or it was not yours, say so plainly and stay with the weekly email |
| F6 | Work alongside the fourth-grade team (role-family requirement; the invite names "two members of our fourth-grade team" on the panel) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your CV | medium | [generic] | none | No gap on the requirement as worded, but the two quotes sit side by side and a probe on the pair is likely. Lead with the move in the quote's own terms. When the title comes up, the words are the quote's: "I've never been a team lead." Do not let the move become leading a team; see the prohibited list |
| F7 | "assessments inform teaching and never replace it" — district Mission and Beliefs page, belief Teach for Tomorrow, Not for the Test (fetched) | none given | none | [grounded] | discovery | Your material does not show how assessments have informed your teaching, and the evidence may exist. Answer slot: the belief makes a probe on this likely. If assessments have informed what you taught, say how, in your own words; if they have not, or it was not yours to decide, say so plainly and stay with what you did do |

## Reading the interviewer

Public professional footprint only. The two fourth-grade team members are unnamed, so no read of them exists.

| # | Public fact | Source | Provenance | What to do with it |
|---|---|---|---|---|
| I1 | Dolores Vantongeren has been principal of Halvering Elementary School since 2022 | Principals forum speaker page (search result, page not fetched) | [grounded] | She is the decision-maker the invite names. Her side of the panel carries the hiring-manager weights: Skeptic and Case |
| I2 | She spent nine years as a reading specialist before that | Same page | [grounded] | Expect reading to be probed deeper than the curriculum label. Prepare D1, D2 and G2 |
| I3 | Her 2025 forum talk, *Small Groups, Big Readers*, covered weekly reading conferences in grades 3 to 5 | Same page | [grounded] | Expect reading themes in small groups and one-to-one conversations. Your material carries neither, so describe them as yours only if they are |
| I4 | Shared vocabulary: reading instruction in grades 3 to 5 | Derived from I3 and F4 | [inferred] | Pair her theme with your two F4 sentences, in their own terms: "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years" |

No career jump is offered as shared: no fit-snapshot row carries your side of her path from reading specialist to principal.

## Persona table

Weights rest on the invite's composition (a principal and two fourth-grade teammates), the principal's public footprint, and the district's published beliefs. No loop source beyond the invite was read, so no archetype was applied. No dedicated values round is documented, so no values cheat sheet is built; the published beliefs still theme the Values bank.

| Persona | Bank | Questions | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|---|
| Skeptic | A | 5 | Quiet, persistent probing of the grade gap and the move to fourth | High: F2 is the biggest gap, and the hiring-manager prior puts Skeptic beside Case | Rehearse A1 until it is boring: F2's plain acknowledgment, then F3's sentence, then a plan in the future tense |
| Peer Evaluator | B | 4 | Two teammates asking about seams, credit, and what you would cost and add to their work | High: the invite puts two fourth-grade team members on the panel, and the peer prior is Peer Evaluator plus Prober | Reciprocity: offer only what F4 and F5 carry, and ask about principles, not specifics you cannot know |
| Case / Strategist | C | 3 | The principal setting live problems from the role and the board's plan | Medium to high: hiring-manager prior, and the literacy plan gives a current-strategy question | Clarify, objective, approach, checks, risks; think aloud; bring one question of your own |
| Data-Driven Prober | D | 3 | Line-by-line probing of the move and the club | Medium: peer prior, and the principal's reading background pushes depth. Nothing published calls her data-driven, so no further adjustment | Know what you can and cannot say about the move and the club, and say plainly when you do not know |
| Values / Behavioral | E | 3 | Prompts mapped to the district's three published beliefs | Medium: the district page says the beliefs guide every hire, but the invite shows no separate values round | Pick a story by criteria; where none comes to mind, use the honest branch |
| Conversational | G | 2 | An opening arc and casual reading questions | Medium: a 45-minute panel has to open somewhere and the invite names no format; this is a pattern, not this panel's documented practice | Script a 90-second arc from F3, F4 and F5 quotes; treat casual questions as scored |
| Pressure | H | 2 | Interrupts, time-boxes, tests attribution | Low: nothing in the invite or the research points to a stress style; included so the style is never first met live | Pause, restate, hold through two follow-ups, then concede specifically |

## Question banks

### Bank A: Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never taught fourth grade. How would you handle that in this role?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet." | The highest-ROI rehearsal in this pack. Say the limit first, before they ask for it: "I haven't taught fourth grade." Then the adjacent sentence at its own scope: "For six years I taught third grade at a public elementary school in Joliet." Then a plan in the future tense: say in your own words what you would want to learn first about the grade and how you would go about it. Hold through two follow-ups by returning to the third-grade sentence, never by adding to it, and concede specifically: "I don't yet know what fourth grade at Halvering asks that third grade did not, and I would ask your team." Answer slot: if a follow-up asks what differs between the grades, say what you know from your own classroom if anything; if nothing, say so plainly | F2 is the largest gap and the one the whole panel orbits, so this objection arrives in some form. JD because it scores fit with the grade the role names |
| A2 | "Why fourth grade, and why now?" | JD | [generic] | Give one reason in a sentence, and make it yours; the pack supplies none because a reason the panel can test must be one you hold. Test it aloud: a follow-up of "why not stay in third grade" should leave the same reason standing. If part of the reason involves your current school, say it without criticizing anyone. If you cannot yet state a reason in a sentence, finding it is the preparation to do before Thursday | F2 raises motivation consistency, and a gap wording cannot close, so the reason carries the weight. JD because it asks about this role and makes no claim about your past |
| A3 | "You led your grade level's move to a new reading curriculum, and you've never been a team lead. Help us understand how both are true." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Hold the sentence, not a bigger one: "I led our grade level's move to a new reading curriculum in 2024." Then the plain acknowledgment: "I've never been a team lead." Answer slot: if the move was yours to lead, say in your own words how that came about and what you did; if it was a shared effort, or "led" was less formal than the word sounds, say so plainly and stay with the sentence. Let them draw the conclusion about leadership; an inference you assert for yourself is the one that gets tested | F6's two quotes sit side by side and a prober will notice. EXP because it tests attribution, not the claim itself |
| A4 | "Tell us about your Illinois license and endorsement." | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it in the quote's own terms: "I hold an Illinois Professional Educator License with an Elementary Education endorsement for grades 1–6, registered and active through June 30, 2029." Stop there; a short exact answer is the answer. Checking your license record before Thursday is yours to do, and nothing in this pack replaces that | F1 is the one requirement the invite states as a condition, so expect a check in a friendly register. JD because it scores a stated requirement |
| A5 | "How long do you think you'd need before you're fully effective in fourth grade?" | JD | [generic] | Give your own honest estimate and say what it depends on; the pack supplies no duration because a number you cannot defend is worse than a range you can. If you do not know yet, say so plainly and say what you would look to the team to tell you | F2's follow-up in a practical register; two grade-level colleagues care about the ramp. JD because it scores readiness for the listed job |

### Bank B: Peer Evaluator (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Suppose you and a fourth-grade teammate disagree about how to teach a unit. What happens next?" | CASE | [generic] | Structure it aloud: what you would ask first, what you would propose, what stays one person's call and what is shared, and when you would bring in the principal. Show spine and tact together: say what you would hold and what you would give. The question needs no claim about your past, so the guidance makes none | Peers price what a hire costs their own work, and F6 is the row this presses. CASE because it is a live problem |
| B2 | "When you led your grade level's move to the new reading curriculum, who else was involved, and what was yours?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold the sentence. Answer slot: if others did parts of the move, say which parts were theirs and which yours, in your own words; if the move was yours alone, or it did not divide that way, say so plainly and stay with the sentence. Credit given exactly is a strength with peers; do not widen "grade level" into the school | F6 and F4 both rest on this sentence, so peers will test the share. EXP because it scores attribution |
| B3 | "What would you want from us in your first month, and what would you bring us?" | JD | [grounded] "I've run the after-school reading club for the last two years"; "I write a weekly email to families." | Answer in two halves. What you would want: ask about principles, such as how the team plans and how decisions get made, not specifics you cannot know. What you would bring: say only what is yours, in these words: "I've run the after-school reading club for the last two years" and "I write a weekly email to families." Stop there and let them ask | F6 is the peer row, and a reciprocity framing turns a probe into a conversation. JD because it scores fit with the team's work |
| B4 | "Tell me about a time a conversation with a family was difficult. What did you do?" | VAL | [grounded] "I write a weekly email to families." | Selection scaffold: pick a conversation you can describe with a named stake, what you said or wrote, and how the relationship stood afterwards. The only family-contact sentence your material carries is "I write a weekly email to families." It shows an email, not a conversation, so do not stretch it. If no such time comes to mind, say so plainly, then describe how you would handle it | F5 is where the Families Are Partners belief presses. VAL because it tests a published belief through a behavior |

### Bank C: Case / Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The board adopted a literacy plan in August that brings a new grades 3–5 reading curriculum from fall 2027. What would you want to know first about how fourth grade takes it on?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The page is public, so any prepared candidate can recite it. Bring one item to show you read it, the fall 2027 grades 3–5 curriculum, then one question of your own. Think aloud: what you would ask, of whom, and why that first. If you mention your own move, use the sentence only, "I led our grade level's move to a new reading curriculum in 2024", and let them ask more | The strategy-grounded question, built from the board page the pack fetched. F4's sentence is the only link to curriculum change in your material. CO because it tests district-level awareness |
| C2 | "As a fourth-grade teacher, what would you want to be handed about each student's reading by their third-grade teacher?" | CASE | [grounded] | Answer as the receiver. Structure: what you would ask for, how you would use it in the first weeks, and how you would check it against what you see yourself. The district's own wording on assessment, in F7, is that it informs teaching and never replaces it. The question needs no claim about your past, so the guidance makes none | F4's belief names the third-grade exit, and this question turns it into a fourth-grade entry. CASE because it asks for reasoning, not history |
| C3 | "A fourth grader is reading well below grade level in September. Walk us through your first month." | CASE | [generic] | Clarify before you structure: what you would want to see first, how you would decide on support, how you would involve the family, what you would check and when. Say aloud what you would not decide before you had seen the child read. The belief in F7 asks that assessment inform teaching and not replace it, so name what you would observe as well as what you would score. No claim about your past | A live problem from the role's core, touching F4 and F7. CASE because it is a pattern for the problem, not a fact about this school |

### Bank D: Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk us through your grade level's move to the new reading curriculum, start to finish." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The sentence carries these beats: the move, the year 2024, your grade level, and that you led it. Tell those in your own words: "I led our grade level's move to a new reading curriculum in 2024." Follow-ups will go past the sentence; when one reaches something it does not carry, answer from your own memory if you have it, and say plainly if you do not. Name no figure you cannot repeat under a second question | F4 and F6 both rest on this sentence, so a prober starts here. EXP because it tests whether the line survives detail |
| D2 | "What do you look at to tell whether the after-school reading club is helping?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Hold the sentence. Answer slot: the district's assessment belief in F7 makes this probe likely. Say what you look at, in your own words; if you do not track how it is going, say so plainly and say what you would start with. Name the weakest part of whatever you look at before they do | F7 and F4 meet here, and a prober wants to know how you know. EXP because it tests what the claim rests on |
| D3 | "Where are fourth graders typically in their reading in September, and how do you know?" | JD | [generic] | Say what you know and where it comes from: your own third-grade classroom, something you have read, or nowhere yet. All three are acceptable if true; claiming fourth-grade knowledge from nowhere is the one that fails the second follow-up. If you do not know, say so plainly and say what you would ask the fourth-grade team | F2 again, tested for knowledge rather than experience. JD because it scores readiness for the listed grade |

### Bank E: Values / Behavioral (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you helped a student who was behind as a reader." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Selection scaffold: pick a student or a moment you can describe with a named stake, what you did yourself, and what happened. If it comes from the reading club, only "I've run the after-school reading club for the last two years" is yours as written; everything else is in your own words. If no such time comes to mind, say so plainly, then describe how you would handle it | The Every Child a Reader belief (F4) is the first of the three the district says guide every hire. VAL because it tests behavior against a published belief |
| E2 | "How do you keep families partners in a child's learning?" | VAL | [grounded] "I write a weekly email to families." | Start with what you do, in the sentence's terms: "I write a weekly email to families." Answer slot: if you have other contact with families, say what it is and how often, in your own words; if you do not, or it was not yours, say so plainly and stay with the weekly email. Do not describe the email as conversations | F5 is where the Families Are Partners belief presses. VAL because it is asked through a published belief |
| E3 | "Tell me about a time assessment results shaped what you taught next." | VAL | [grounded] | Selection scaffold: choose one instance with a named stake: what you saw, what you changed, how you knew it worked. If assessment and your own observation pointed different ways, say which you trusted and why. If no such time comes to mind, say so plainly, then describe how you would handle it | F7's belief, Teach for Tomorrow, Not for the Test, is the third of the three. VAL because it asks for behavior, not for the slogan |

### Bank G: Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk us through the journey." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families." | A 90-second arc built only from your own sentences, in this order. Where you are: "Six years teaching third grade at a public elementary school in Joliet." What you have led and run: "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years." Then one line on families: "I write a weekly email to families." End on why this position, in your own words; the pack supplies no reason (see A2). Your start in teaching is yours to add or leave out | A panel has to open somewhere, and F3 is the spine of the arc. EXP because it is the resume in your own words, scored for economy |
| G2 | "What are you trying with your readers these days?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" | Answer slot: say what you have actually tried and what you noticed, in your own words; if nothing is new lately, say so plainly and say what you would like to try. If you reach for your own sentences, they are "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years." Do not describe weekly reading conferences or small groups as yours unless they are | The principal's public work is on reading in grades 3 to 5 (I3), so casual reading questions are scored. F4 is the row it draws on. EXP because it asks about live practice |

### Bank H: Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Pause and restate the question. Hold: "I led our grade level's move to a new reading curriculum in 2024." Hold it through two follow-ups by returning to the sentence, not adding to it. Then concede specifically: name any part that was others', or any part you cannot speak to, in your own words; if you cannot name one, say plainly what you do not know. Never fold the core sentence to restore harmony | The pressure form of A3 and B2, on the sentence F4 and F6 share. EXP because it tests attribution under pushback |
| H2 | "Sixty seconds: why you over a candidate who has already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet." | Pause, restate, then hold. Start with the limit you can say plainly: "I haven't taught fourth grade." Then only what your sentences carry: "Six years teaching third grade at a public elementary school in Joliet." Answer slot: the rest of the sixty seconds is your own reason; if you cannot say honestly why you would be a good choice, say what you would bring that you can stand behind. Concede specifically that another candidate may be stronger on grade experience, if that is true; do not concede that you would be a weak teacher | The pressure form of A1, resting on F2 and F3. JD because it scores the choice the panel must make |

### Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| F1 license and endorsement | A4 | The one JD-tagged question for the invite's stated condition |
| F2 fourth-grade teaching | A1, A2, A5, D3, H2 | Deepest rehearsal is A1 |
| F3 whole class, core subjects | G1, C3 | No subject-by-subject questions: the material neither names nor excludes a subject, so a posting would be needed to add them |
| F4 reading belief | C1, C2, D1, D2, E1, G2, H1 | |
| F5 families belief | B4, E2 | |
| F6 team | A3, B1, B2, B3, H1 | |
| F7 assessment belief | C3, D2, E3 | |
| Headline metrics | none, and why | Your resume gives dates and durations but no performance figure, so no defend-the-number question applies |

## Reverse questions

| # | Question | Basis | Why it lands |
|---|---|---|---|
| R1 | "You were a reading specialist for nine years before becoming principal. What from that work shows up in how Halvering teaches reading now?" | Principals forum speaker page (I1, I2) | Tied to her own path; it invites her to talk about the work she knows best and shows you read about her |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for the two peers | It reverses the peer probe: you ask what the team needs, not only what you need |
| R3 | "The board's plan brings a new grades 3–5 reading curriculum from fall 2027. Where does a new fourth-grade teacher come in?" | District literacy plan page | It shows you read the plan and asks about your own place in it without claiming anything |
| R4 | "What does a strong first term look like for a teacher who is new to the grade?" | F2 | It turns the gap into a conversation about support, and her answer tells you what the ramp is |
| R5 | "How do fourth-grade teachers here make time to speak with every family each term?" | District Mission and Beliefs page | It shows you read the beliefs and learns the practice behind the line |
| R6 | "What are the next steps, and when should I expect to hear?" | Generic close | It ends the panel on process and is routine |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated, F2 | The plain acknowledgment: "I haven't taught fourth grade." No slot |
| Has been a team lead | Negative you stated, F6 | The plain acknowledgment: "I've never been a team lead." No slot |
| Led the grade-level team | Inflated form of F6 and F4 | The quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024". The limit is the pack's observation: your material says the move, not the team |
| Made sure every student left with a reading plan | Inflated form of F4 | The F4 quotes at their own scope: the curriculum move and the club. The limit is the pack's observation: your material says a move and a club, not reading plans |
| Speaks with every family each term | Inflated form of F5 | "I write a weekly email to families." The limit is the pack's observation: your material says an email, not conversations |

## Sources

**Provided documents:** the interview invite and your resume, as pasted. The license number in the resume was not used in the pack or in any search.

**Searches sent:**

1. `Halvering Elementary School Orrinsford Community School District mission values` returned https://orrinsfordschools.example/about/mission-and-beliefs
2. `Dolores Vantongeren principal Halvering Elementary School` returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
3. `Orrinsford Community School District strategic plan news` returned https://orrinsfordschools.example/news/board-adopts-literacy-plan
4. `fourth grade teacher job description Illinois elementary school responsibilities qualifications` returned https://k12jobsboard.example/listings/fourth-grade-teacher

**Pages fetched:** https://orrinsfordschools.example/about/mission-and-beliefs and https://orrinsfordschools.example/news/board-adopts-literacy-plan. Interviewer facts in I1 to I3 rest on a search result for the speaker page, which was not fetched.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | Fit rows F4, F5 and F7 take their requirements from the fetched beliefs page; Values bank E. No values cheat sheet, because no values-style round was detected |
| 2. `{company} interview process {role family}` | skipped | The invite fixes every output this target feeds: one 45-minute panel with the principal and two fourth-grade team members sets the session, and persona weights follow its composition |
| 3. `{company} strategy` / recent news | yes | Question C1 and reverse question R3, from the fetched board literacy-plan page |
| 4. `{interviewer name} {company}` | yes | Section Reading the interviewer, question G2 and reverse question R1. The two team members have no names, so there was no query to form for them |
| 5. representative `{role title}` JD | yes | One listing came back whose snippet cut off mid-sentence, and no fetch was left, so no line of it is quoted. It moved F3's wording only, which stays plain role-family prose |

## Upgrade menu

- The full posting → F3's role-family requirements become quoted `[grounded]` requirements, and JD-tagged questions can be added for each line the posting raises
- The two team members' names and roles → a read of each, and persona weights for Bank B tuned to them
- HR's prep guidance, such as whether a sample lesson or any task is expected → a build section for each declared deliverable
- Your answers to the answer slots in F4, F5 and F7, said outside a drill → those rows move from a slot to a story map, and the guidance in A3, B2, D2, E2 and E3 is regenerated from them
- The license record itself, checked by you → F1 moves from medium toward high
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes → the principal's talks and writing, and recent district context for the Case bank
- A tuesday-dossier.md from an earlier opportunity check → verified evidence and prohibited claims would arrive checked instead of built here; optional, and nothing in this pack depends on it
