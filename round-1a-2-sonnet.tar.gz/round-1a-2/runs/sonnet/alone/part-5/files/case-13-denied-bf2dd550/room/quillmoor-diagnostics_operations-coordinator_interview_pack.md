# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter phone screen, Thursday at 2pm, 30 minutes
**Interviewer:** Hannah Lowther, Talent Partner. She will ring the mobile number on your application.
**Her stated agenda, from her message:** "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move, and then I'll tell you about the team and the next steps."
**Built on:** your message, the advert and Hannah's message only. Research could not run (see Sources), so nothing here rests on the web.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values. None in this pack: no values round is documented for this call. |
| EXP | Whether your own account of your work survives a follow-up question |
| JD | Whether you fit a stated term or requirement of the advertised job |
| CO | What you know about the company and why you want to work there |
| CASE | A live problem from the role, answered aloud |

An **answer slot** is an instruction for the interview, not a question for you now. It names what an interviewer is likely to probe and gives two honest branches: if you did it, say how, in your own words; if you did not, or it was not yours, say so plainly and go back to what you have said. The second branch is always a legitimate answer.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — the advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with the role and the four years in the quote's own terms, because a named role beats an adjective |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — the advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material says delivery scheduling for three depots, not production schedules, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who you coordinate with likely. If any of those functions were people you worked with, say who and how, in your own words; if not, say so plainly and stay with the three depots |
| F3 | "track supplier deliveries" — the advert | "I schedule deliveries for our three depots" — your message | low | [inferred] | discovery | The sentence touches deliveries without showing whether you track supplier deliveries. Answer slot: if you track them, say how, in your own words; if you do not, or it is not yours, say so plainly and stay with scheduling for the three depots |
| F4 | "chase late orders" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap, but nothing inspected sits behind the line. Lead with the quote's own terms: you chase suppliers when orders slip |
| F5 | "keep stock records accurate" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap on the quote's terms, but the figure is a magnet for probing. Keep "about a third" as "about a third". The four slots a figure raises sit in C1 and C2: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours |
| F6 | "report weekly on on-time dispatch" — the advert | none given | none | [grounded] | discovery | Your material does not show this requirement either way. Answer slot: the advert's weekly on-time dispatch line makes a probe on reporting likely. If you produce any regular report, say what it covers and how often, in your own words; if you do not, say so plainly and stay with "I schedule deliveries for our three depots" |
| F7 | "confident with Excel" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | low | [inferred] | discovery | The quote says spreadsheet, and your material does not say it was Excel. Answer slot: if it was Excel, say what you did in it, in your own words; if it was another tool, or you used little of its features, say so plainly and stay with the rebuild |
| F8 | "ERP experience (SAP or similar) a plus" — the advert | "Never used SAP — we run our own in-house stock system" — your message | medium | [grounded] | transferability | The acknowledgment is yours to say: "I haven't used SAP." The adjacent fact stays at its own scope: "we run our own in-house stock system." Your material does not say whether that system is an ERP. Answer slot: the advert's "or similar" makes a probe on what the system did likely. Say what you used it for, in your own words; if it was not like an ERP, or the use was not yours, say so plainly and stay with "I haven't used SAP" |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" — the advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | The term is shown met by your own statement. Say it at its own scope, with its limit: two days is fine, and you wouldn't want more than three |
| F10 | "£38,000–£44,000" — the advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | The term is shown met by your own statement: £42,000 sits inside the advert's band. Say your figure once, plainly, in your own words |

## Persona table

Loop: Hannah's message establishes this one session, a 30-minute call with her. It establishes nothing about later rounds, so these weights prepare for this call only.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder (A) | Friendly, unstructured: pay, notice, days, why you're moving, your background | Highest. Hannah's message lists four topics and then team and next steps, so her questions are mostly logistics in a friendly register. Casual questions are still scored | Rehearse A1 to A5 aloud until each is a short, plain answer |
| Skeptic (B) | Quiet probing of where your background meets the advert | High, as a light version. The advert lists SAP as "a plus" and the planning, warehouse and QA coordination, and your own note says you have not used SAP | Rehearse B1 until it is boring. B1 is the highest-ROI prep in this pack |
| Data-Driven Prober (C) | Asks how a figure was counted and which part was yours | Medium-low. Skills are not in Hannah's stated agenda, but the one-third figure is the only quantified claim in your material | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| Pressure / Stress Interviewer (D) | Pushes back on pay, days or your reasons, politely | Medium-low. A pay or office-day push can arrive inside a friendly call | Pause, restate, hold your stated position through two follow-ups, concede only what you have already decided |
| Case / Strategist (E) | A short live problem from the role | Low. Not in Hannah's stated agenda | Clarify first, then structure, think aloud |
| Peer Evaluator and Values / Behavioral | Not banked | Not plausible for this call: Hannah's message names no peer or values session, and no values round is documented for this call, so there is no values cheat sheet | None needed for this call |

## Question banks

Weights: A 5 questions, B 5, C 3, D 3, E 2.

**Highest-ROI prep: B1.** It is the question your own note makes certain, it is aimed at where the advert and your material are thinnest, and a plain, rehearsed answer changes how the screen feels. Rehearse it through all three follow-ups.

### A. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000" | Logistics slot, filled from your own statement: say "I'm hoping for £42,000" in those words, once, and stop. If she asks what the figure rests on, give your own reason in your own words; the pack supplies none | Hannah named salary expectations first, so this is near-certain. F10 is the evidence row; JD because pay is a term of the listed job |
| A2 | "What's your notice period?" | JD | [grounded] Hannah's message: "your notice period" | Logistics slot: give your actual notice period, in your own words. If you have any flexibility on it, say that too, only if it is true | Hannah named notice as a topic. The advert states no notice term, so no F row speaks to it; JD because it is a term of the listed job |
| A3 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Logistics slot, filled from your statement: two days at Avonmouth is fine. If days beyond two come up, say your limit as you stated it: you wouldn't want more than three. Do not add commute details you have not given | Hannah named the hybrid pattern as a topic. F9 is the evidence row; JD because location and pattern are terms of the listed job |
| A4 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say the facts in the quote's own terms: the Bristol office is closing next year, the only offer is relocating to Reading, and you don't want that. Add nothing about how or when it was decided. Answer slot: if she asks about timing or what is on offer, say what you know and say plainly what you don't | Hannah named the reason for leaving as a topic, and a recruiter checks it for consistency with your later answers. EXP because it is your own account; no F row speaks to it |
| A5 | "So, walk me through your background and how it lines up with the two years in operations or logistics coordination we're asking for." | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Three beats, in this order, each in your own words at its own scope: the four years as a logistics coordinator at a wholesaler; scheduling deliveries for your three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet with discrepancies falling about a third over a year. Add nothing beyond them. Answer slot: say which line of the advert draws you, in your own words; if none stands out yet, say so plainly | The biography question is almost always asked. F1 is the hard requirement it scores, and F4 and F5 supply the other two beats; JD because it scores the years requirement |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The advert lists ERP experience, SAP or similar, as a plus. Where do you stand on that?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Name the limit first, in your own words: "I haven't used SAP." Then the adjacent fact at its own scope: "we run our own in-house stock system." Follow-up 1, what the in-house system did: answer slot, say what you used it for, in your own words; if it was not like an ERP, or the use was not yours, say so plainly and stay with "I haven't used SAP". Follow-up 2, how you would get up to speed: say it as a plan in your own words, never as a past. Follow-up 3, is it a problem: concede specifically that you haven't used SAP, and hold that the advert lists ERP experience as a plus. Never say the in-house system is equivalent to SAP | Your note states the gap, so some version of this arrives. F8 is the evidence row; JD because it scores a stated requirement |
| B2 | "The role coordinates production schedules between planning, the warehouse and QA. What's the nearest thing you do now?" | JD | [grounded] "I schedule deliveries for our three depots" | Say it at its scope: "I schedule deliveries for our three depots." Do not call it production scheduling. Answer slot: if any of planning, the warehouse or QA were people you worked with, say who and how, in your own words; if not, say so plainly and stay with the three depots | F2 is the advert's headline duty and the nearest-but-not-reaching row. JD because it scores a stated responsibility |
| B3 | "How confident are you with Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say what you rebuilt, in those words. The pack does not know the spreadsheet was Excel. Answer slot: if it was Excel, say what you did in it, in your own words; if it was another tool, or you used little of its features, say so plainly and stay with the rebuild. Do not rate yourself with an adjective | F7 is a hard requirement with only an indirect quote behind it. JD because it scores a stated requirement; the label is inferred because the Excel link is the pack's derivation |
| B4 | "What do you know about Quillmoor, and why this role?" | CO | [grounded] the advert | Say what the advert itself says: a diagnostic-test manufacturer of about 400 staff, a role coordinating production schedules between planning, the warehouse and QA, and a hybrid pattern at the Avonmouth site in Bristol. The pack could not research the company, so nothing beyond the advert is offered as fact; read their own website and careers page before Thursday and add only what you read there. Answer slot: say why this role, in your own words; if you have not formed a reason yet, say so plainly and name the part of the advert you want to hear more about | Recruiters ask this as a motivation check, and the pack has only the advert to build it on. CO because it scores homework; no F row speaks to it |
| B5 | "The role reports weekly on on-time dispatch. Tell me about a time you reported on performance." | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Pick a report you produced yourself: what it covered, how often, and who read it. If no such time comes to mind, say so plainly, then give the nearest thing your material carries at its own scope: "I rebuilt our stock-count spreadsheet." Do not call the spreadsheet a report | F6 has no evidence behind it, so this is where the advert's reporting line is least covered. JD because it scores a stated responsibility |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say discrepancies fell by about a third. Walk me through how that was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say the sentence as written first. Then answer the four slots in your own words: how it was counted, what the figure is sensitive to, the assumption behind it you would defend least, and which part was yours. If you don't know how it was counted, say so plainly. "About a third" stays "about a third". Name the weakest assumption yourself before they do, if you can name one | Every headline figure draws a defend-the-number question. F5 is the evidence row; EXP because it tests whether the claim survives a second question |
| C2 | "Which part of that was you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold the sentence as written: "I rebuilt our stock-count spreadsheet." Answer slot: if anyone else worked on the rebuild or the counts, say who and what, in your own words; if it was yours alone, say that plainly. On the fall in discrepancies, if anything else changed over that year that could explain part of it, say what; if you don't know, say so plainly | Attribution probes follow every figure. F5 is the evidence row; EXP because it scores what was actually yours |
| C3 | "The role tracks supplier deliveries and chases late orders. How do you keep track of them now?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Say the sentence as written, with its tense: "I schedule deliveries for our three depots and chase suppliers when orders slip." Answer slot: if you track supplier deliveries, describe how, in your own words; if you do not, or it is not yours, say so plainly and stay with the chasing | F3 and F4 are the two advert duties this question scores. JD because it tests a stated responsibility |

### D. Pressure / Stress Interviewer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "£42,000 is towards the top of our band. Could you do £40,000?" | JD | [grounded] "I'm hoping for £42,000" | Hold: say "I'm hoping for £42,000" again in the same words, not a new number, through two follow-ups. Concession slot, a choice between named options that supplies no figure: either say you would like to hear how the band is set before discussing a lower figure, or give your own floor in your own words if you have already decided one. Never name a figure on the call you haven't decided beforehand | A friendly pay push is common. F10 is the evidence row; JD because pay is a term of the listed job |
| D2 | "Sixty seconds: why not take the offer to relocate to Reading?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Hold on the quote's terms: "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading." Hold through two follow-ups by returning to it. Answer slot: if asked why you don't want Reading, give your own reason in your own words; if you'd rather not go into it, say so plainly and return to the quote | A4's answer gets re-tested here under time pressure. EXP because it is your own account; no F row speaks to it |
| D3 | "Could you manage three or four days at Avonmouth if the team needed it?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Hold the statement as you made it: "two days at Avonmouth is fine, but I wouldn't want more than three." Do not offer four. Answer slot: whether three days would be acceptable in practice is yours to answer, in your own words; the quote states only that more than three is not something you'd want | F9 sets a limit that this probe tests. JD because the office pattern is a term of the listed job |

### E. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you at 2pm that a delivery QA needs tomorrow will arrive two days late. Walk me through what you do." | CASE | [generic] | Structure it: what you need to know first (what the delivery feeds, who is waiting), what you would tell planning, the warehouse and QA, what options you would put to them, and what you would record. Think aloud and name one premise you would check. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's supplier-tracking and coordination lines (F3 and F4's requirements); CASE because it asks for a decision, not a record; generic because it is a pattern, not a fact about this employer |
| E2 | "You find a stock record that doesn't match what is on the shelf. What do you do first?" | CASE | [generic] | Structure it: confirm the count, trace what moved recently, tell whoever relies on the record, correct it and note why, then what would stop a repeat. The guidance makes no claim about your past | A live problem from the advert's stock-records line (F5's requirement); CASE; generic for the same reason as E1 |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1: 2+ years in operations or logistics coordination | A5 (JD) |
| F2: coordinate production schedules | B2 (JD), E1 (CASE) |
| F3: track supplier deliveries | C3 (JD), E1 (CASE) |
| F4: chase late orders | C3 (JD), E1 (CASE) |
| F5: keep stock records accurate | C1 (EXP), C2 (EXP), E2 (CASE). No JD-tagged question: C1 and C2 carry the requirement's quote and test the claim, which is the type the figure calls for |
| F6: report weekly on on-time dispatch | B5 (JD) |
| F7: confident with Excel | B3 (JD) |
| F8: ERP experience, SAP or similar | B1 (JD) |
| F9: hybrid, two days at Avonmouth | A3 (JD), D3 (JD) |
| F10: £38,000–£44,000 | A1 (JD), D1 (JD) |
| Hannah's other topics: notice period, reason for leaving | A2 (JD), A4 (EXP), D2 (EXP) |

## Reverse questions

| # | Question to ask | Why it lands | Provenance |
|---|---|---|---|
| R1 | "Which people would I work with day to day across planning, the warehouse and QA, and where do they sit?" | The advert names three functions to coordinate between, so it shows you read the duty and want to meet the people it involves | [grounded] the advert |
| R2 | "What does on-time dispatch reporting look like today, and what would good look like in my first months?" | It turns the weekly reporting line into a practical conversation instead of a test | [grounded] the advert |
| R3 | "Which systems does the team use for stock and orders now, and what training is there for them?" | It turns your SAP gap into a question about onboarding rather than a defect | [grounded] the advert's "ERP experience (SAP or similar) a plus" |
| R4 | "How are the two Avonmouth days set: fixed days, or agreed with the team?" | It tests how the hybrid pattern works in practice, which Hannah wanted to cover | [grounded] the advert's hybrid line |
| R5 | "How is a place within the £38,000–£44,000 band decided?" | It gives you information on how pay is set before or after she asks about your figure | [grounded] the advert's band |
| R6 | "What are the next steps, and who would the next conversation be with?" | She said she will cover next steps; this confirms who and when so you can plan your preparation | [grounded] Hannah's message |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP | A negative you stated, F8 | The plain acknowledgment F8's quote supports: "I haven't used SAP." No answer slot on this claim |
| Your in-house stock system counts as ERP experience | Inflated form of F8 | F8's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation, not words for you: your material says an in-house stock system, not that it is an ERP. B1's slot asks only what you used it for |
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F2 | F2's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: your material says delivery scheduling, not production schedules. B2's slot stays inside the depots |
| Your spreadsheet alone cut discrepancies by a third | Inflated form of F5 | F5's quote at its own scope, with both facts as stated: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The limit is the pack's observation: your material states the two facts side by side, not that one caused the other. C2's slot asks only what else changed |
| Flexible on office days beyond three, or happy to do four | Inflated form of F9 | F9's quote at its own scope: "two days at Avonmouth is fine, but I wouldn't want more than three." The limit is the pack's observation: your material states a ceiling of three, not willingness for more. D3's slot stays inside that ceiling |
| Was made redundant | Inflated form of the reason quoted in A4 | The reason as quoted: "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading." The limit is the pack's observation: your material states the office closure and the offer, not the terms of your own role |

## Sources

Provided documents: Hannah Lowther's LinkedIn message; the Quillmoor Diagnostics advert; your own note about your background and what you would say. No tuesday-dossier.md was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Query sent, refused. It would have fed VAL-themed questions and the values cheat sheet, but only if a loop source documented a values round |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Query sent, refused. It would have fed loop structure and persona weights beyond this call |
| 3. `Quillmoor Diagnostics Avonmouth news` | unavailable | Query sent, refused. It would have fed a CO question grounded in current priorities; B4 rests on the advert alone |
| 4. `Hannah Lowther Quillmoor Diagnostics Talent Partner` | unavailable | Query sent, refused. It would have fed an interviewer read and a reverse question tied to her path; both are absent |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

Queries sent, all refused: `Quillmoor Diagnostics values`; `Quillmoor Diagnostics interview process operations coordinator`; `Quillmoor Diagnostics Avonmouth news`; `Hannah Lowther Quillmoor Diagnostics Talent Partner`.

## Upgrade menu

- Search permission, so the four targets above can run → values, loop structure, recent news and Hannah's public professional footprint, which would replace B4's advert-only answer with researched points and could add a tailored reverse question
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → a strategy brief for CO and CASE questions, further interviewer footprint, role-family loop reports and recent organisation context
- Your actual notice period → fills A2 in your own words
- What your in-house stock system did and what you did in it → F8 and B1's slot become a quoted story
- Whether the stock-count spreadsheet was Excel and what you did in it → F7 moves from low to a stronger band and B3 gets a story map
- Any regular report you produce, what it covers and how often → F6 gains evidence and B5 gets a story map
- How the one-third discrepancy figure was counted → C1 and C2 become quoted answers instead of slots
- A copy of the stock-count spreadsheet's discrepancy tally, with any confidential detail removed → F5 can move from medium to high, because it is the inspectable artifact in stock control
- Your CV → F1 moves from your message to your CV's own lines, with dates
- A reply from Hannah on whether the call will touch ERP or Excel → coverage of B1 and B3 can be reweighted
- A tuesday-dossier.md, if you have one → verified evidence quotes and a prohibited-claims list that replace the locally built one in this pack
