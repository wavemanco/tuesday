# Interview prep pack — Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. One 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given). Built from your invite, your résumé text and the district's public pages; no posting for this position was supplied.

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. Where a cell says "Answer slot", it asks nothing of you here; it tells you what to do in the room, and either honest branch is a good answer.

Question IDs use the letters A to E, G and H. The letter F is skipped so question IDs never collide with fit-snapshot row IDs (F1 and on).

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs, not generic virtue |
| EXP | Whether what you say you did survives follow-up; what was actually yours |
| JD | The role as posted: can you do this job, including the parts you have not done |
| CO | Whether you know the district's current direction |
| CASE | A live problem from the role; structure and reasoning over the "right" answer |

## Fit snapshot

Requirements come from the invite and from the district's own pages (named in each row). No posting was supplied, so F10 is a plain-prose requirement labeled `[generic]` and raises no answer slot.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The material shows this gate met: kind, endorsement, status and expiry are all in your CV's own sentence, and that is how to say it. It is a CV line with nothing inspected behind it, so confirming your registration is yours to do before Thursday. The licence number stays in your CV and is not repeated in this pack |
| F2 | "reading instruction" — the district's "How we hire teachers" page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Your material says a move you led and a club you run, nothing inspected behind either, and the words stay at that scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: reading instruction is a topic the panel is documented to ask about, so expect a probe on how reading was taught in your room day to day. If it was yours to plan, say how, in your own words; if the curriculum set it or it was not yours, say so plainly and stay with the move and the club |
| F3 | "classroom routines" — the district's "How we hire teachers" page | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [inferred] | discovery | Six years in a classroom touches routines without showing any; the bridge is derived from the topic, not from your words. Answer slot: the panel is documented to ask about classroom routines, so expect a probe on how your room ran. If you set routines, say which and why, in your own words; if you did not, or none comes to mind, say so plainly and stay with the six years |
| F4 | "how you work with families" — the district's "How we hire teachers" page | "I write a weekly email to families" — your CV | medium | [grounded] | none | No gap: the quote reaches the requirement in role-relevant terms. Lead with it in its own words, "I write a weekly email to families," because a named record beats an adjective. Nothing is inspected behind the line, so expect a probe on it |
| F5 | "each teacher speaks with every family each term" — the district's "Mission and Beliefs" page | "I write a weekly email to families" — your CV | low | [inferred] | transferability | Your material says an email, and the district's line says speaking; the bridge does not stretch one into the other. Answer slot: expect a probe on direct conversations with families. If you speak with families directly, say how and how often, in your own words; if you do not, or not with every family, say so plainly and stay with the weekly email |
| F6 | "no student leaves third grade without a reading plan" — the district's "Mission and Beliefs" page | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [inferred] | discovery | Your grade matches the belief's grade, and the quote shows nothing about plans; the bridge is derived from that match. Answer slot: if reading plans for students were part of your work, say what they were and who made them, in your own words; if there were none, or they were not yours, say so plainly and stay with the six years |
| F7 | "assessments inform teaching and never replace it" — the district's "Mission and Beliefs" page | none given | none | [grounded] | discovery | Nothing in your material speaks to this belief. Strong evidence would be one specific moment an assessment result changed what you taught. Answer slot: if such a moment exists, say what the result was and what you changed, in your own words; if none comes to mind, say so plainly and say how you would use assessment results |
| F8 | "Fourth Grade Teacher position" — the invite | "I've never taught fourth grade" — your CV | none | [grounded] | capability | A gap wording cannot close, and your CV says so. Words: "I haven't taught fourth grade." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F9 | "Fourth Grade Teacher position" — the invite | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [grounded] | transferability | Your material says six years in third grade at one school, nothing inspected behind it, and the words stay there: "Six years teaching third grade at a public elementary school in Joliet." The step to fourth grade is a plan, not a claim, and the pack does not say what differs between the grades |
| F10 | Works as part of a grade-level team (plain prose, no source supplied) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your CV | low | [generic] | transferability | The first quote is a move at your grade level, and your CV also says you have never been a team lead; the pack's observation is that these are two statements to keep as written, side by side. Words stay at the quote's scope: "I led our grade level's move to a new reading curriculum in 2024." Never a team-lead role |

## Reading the interviewer

Public professional footprint only. The two fourth-grade team members are not named, so no read is possible for them.

| Fact | Provenance | Source | What it means for you |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | [grounded] | Illinois principals forum speaker page, Sources S3 | Reading questions from her will likely go deeper than a general question would; prepare F2 rows and C1 to C3 first |
| Gave a 2025 forum talk titled "Small Groups, Big Readers" on weekly reading conferences in grades 3 to 5 | [grounded] | Same page | Her talk's grade band spans the grade you teach and the grade you are applying for; mention the talk only if you have read or heard it yourself, and then only what you took from it |
| Shared vocabulary: reading | [grounded] | Same page, and F2's evidence: "I've run the after-school reading club for the last two years" — your CV | Use the club in its own words when reading comes up; do not describe its activities beyond that sentence unless you can say what they were |

## Persona table

The district's hiring page documents one building panel of the principal and two grade-level teachers, which matches your invite, so the weights follow that panel. Relationship priors: the principal reads as a hiring manager (Case and Skeptic), the two teammates as peers (Peer Evaluator and Prober). Interviewer signals tilt toward reading depth.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| A Skeptic | Quiet, persistent probing of the fourth-grade gap and the "led versus never a team lead" seam | High: your own material states both gaps (F8, F10), and the principal is the likeliest to raise them | Rehearse A1 until it is boring; bridges only from the quotes; a concrete learning plan |
| B Peer Evaluator | Teammates asking what you bring them and what you would need from them | High: two of three panelists are fourth-grade teammates | Reciprocity framing; propose principles for working together rather than pretending to know their routines |
| C Data-Driven Prober | Follow-ups on the reading curriculum move and the reading club | Medium: reading instruction is a documented panel topic and the principal's background is reading | Say what the quote carries, then the answer slot's branch; name plainly what you do not know |
| D Values / Behavioral | Scenario prompts tied to the district's three published beliefs | Medium: the district says the beliefs guide every hire, but its hiring page names no values round, so this is a tilt and not a documented round | Stories only from your own experience; selection scaffolds where nothing in your material carries one |
| E Case / Strategist | Live classroom problems and a question on the district's literacy plan | Medium: principal as hiring manager; routines and reading are documented topics | Clarify first, then structure, then approach; think aloud |
| G Conversational | An easy opener such as "walk me through your journey" | Low to medium: a rapport-style opener is a persona prior, not something the district documents; casual questions are still scored | A 90-second arc built from your quoted sentences |
| H Pressure | A time-boxed challenge on why you for a grade you have not taught | Low: nothing sourced suggests a stress style; included so no style is new live | Pause, restate, hold through two follow-ups, concede only the sourced limit |

## Question banks

Highest-ROI prep in this pack: A1. It will be asked in some form, it aims at F8, and a plain, rehearsed answer changes the interview.

### A — Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your background is third grade, and this is a fourth-grade position. What would be hardest for you on day one?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | The deepest rehearsal here. Level one: the plain limit, "I haven't taught fourth grade," then what the quote carries, six years teaching third grade at a public elementary school in Joliet. Level two, if pressed on why third grade carries over: hold at what you did there and stop; let them draw the link, and do not assert what it proves. Level three, if pressed on what if it is harder than expected: a plan said as a plan, what you will ask the two fourth-grade teachers to show you first and what you will read or observe before day one; pick only what you would actually do. Limit named in advance: this pack does not know what differs between the grades, so name no differences; ask them | F8 and F9 are the biggest gap and its adjacent evidence, and this is the likeliest form the objection takes; JD because it scores the stated role, with a Skeptic delivery |
| A2 | "You led your grade level's move to a new reading curriculum. What part of that was yours?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold the quote at its scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: expect a probe on which parts of the move were yours. If a part was yours to decide or carry out, say which and how, in your own words; if the curriculum or its timing was set by others, or a part was not yours, say so plainly and stay with the move you led at your grade level. Hold through two follow-ups by returning to the move, never by adding to it | F2 is the evidence for reading instruction and the likeliest place for an attribution probe; EXP because it tests what was actually the candidate's |
| A3 | "Your CV says you led that move, and also that you have never been a team lead. Help us square those." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Say both as written, side by side: "I led our grade level's move to a new reading curriculum in 2024" and "I've never been a team lead." Do not explain the difference with a title, an informal role or a reason; none of those is in your material. Answer slot: expect a probe on how the move came to be yours. Say how, in your own words, whether it was assigned, shared or something else; if you cannot say, say so plainly and stay with the move | F10 holds the seam between two true statements, and the invite names teammates on the panel who will notice it; EXP because it tests attribution |
| A4 | "Why fourth grade, why here, and why now?" | JD | [generic] | A motivation probe that needs your actual reasons, which this pack does not have. Give your real reason in your own words; use the district's published beliefs only where something there truly bears on your reason, and name which one. Keep it under a minute | Skeptics score motivation consistency; the material states no reasons, so the guidance is an instruction and not a story |

### B — Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You would be joining our fourth-grade team. What do you bring us, and what would you need from us in your first month?" | JD | [grounded] "I've run the after-school reading club for the last two years"; "I write a weekly email to families"; "I've never taught fourth grade" | Reciprocity first: what you bring, in the quotes' own words, the reading club you have run for the last two years and the weekly email to families. Then the need, honestly: "I haven't taught fourth grade," and what you would ask the team to show you first, in your own words. Offer a principle for working together rather than guessing their routines | The peers are pricing what the hire costs and contributes to their own work; F8 is the need, F2 and F4 are the offer; JD because it scores fit for the team's role |
| B2 | "How do you handle credit when work is shared across a grade level?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Peer stem on credit. Use the quote's own split: "our grade level's move" and "I led." Answer slot: if credit for shared work was ever divided or discussed, say how you handled it, in your own words; if the question never came up, say so plainly and say how you would handle it | F10's quote is the only shared-work sentence in your material; EXP because it tests whether your attribution is easy to repeat under a second question |
| B3 | "Tell me about a time you and a colleague saw a reading problem differently." | EXP | [generic] | An open prompt from the peer stem on disagreement; choose an instance. It needs a named disagreement about reading, your actual part in it, and an ending that is true. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the move you led at your grade level, at its own scope, or how you would handle it | Collegial packaging of a disagreement probe; nothing in your material shows one, so it is a selection scaffold |
| B4 | "A teammate on our team runs a classroom routine very differently from yours, and students notice. What do you do?" | CASE | [generic] | A live problem that asks about no past. Structure it: what you would want to understand first, who you would talk to and in what order, what you would keep different and what you would align, and how you would tell whether it worked. Propose principles, not a fix | Combines the peer seam question with routines, a documented panel topic (F3); CASE because it is judged on structure |

### C — Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the reading curriculum your grade level moved to in 2024." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Tell it at the quote's scope: your grade level, the move, 2024. Answer slot: expect follow-ups on what the curriculum asked of teachers day to day. If you taught from it, say how it ran in your room, in your own words; if parts were not yours, or you cannot say, say so plainly and stay with the move | F2; the principal's reading background makes depth likely; EXP because it checks the CV line |
| C2 | "How did you know the new reading curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The district's published belief is that assessments inform teaching, so a measure probe is likely. Answer slot: if you tracked how it was working, say what you looked at and how, in your own words; if nobody did, or it was not yours, say so plainly and stay with the move | F2 and F7; the belief page is the raising source; the guidance supplies no measure | 
| C3 | "You run the after-school reading club. What happens in a session, and how do you know it helps?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Start with the quote: you have run the after-school reading club for the last two years. Answer slot: if you can describe a session, do it in your own words; if you track anything about whether it helps, say what; if you do not, say so plainly and stay with the two years | F2; a CV line with nothing inspected behind it is the kind a prober opens |

### D — Values / Behavioral (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "One of our beliefs is Every Child a Reader: no student leaves third grade without a reading plan. Tell us about a time you made sure a student had a plan." | VAL | [grounded] "I've run the after-school reading club for the last two years" | A selection scaffold. Pick a time with a named student need, your actual part, and a true ending. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the after-school reading club, at its own scope in the words "I've run the after-school reading club for the last two years," or how you would handle it | F6; the belief is published on the district's page, so VAL is raised by a source, and no quote carries a plan story |
| D2 | "Families Are Partners is one of our beliefs. How do you work with families?" | VAL | [grounded] "I write a weekly email to families" | Lead with the quote: "I write a weekly email to families." Answer slot: the belief says teachers speak with every family each term, so expect a probe on direct conversations. If you speak with families directly, say how and how often, in your own words; if you do not, or not with every family, say so plainly and stay with the weekly email | F4 and F5; the email is your evidence and the conversation is the probe |
| D3 | "Tell us about a time assessment results changed what you taught." | VAL | [grounded] | An open prompt from the district's published belief, Teach for Tomorrow, Not for the Test. A selection scaffold: one specific result, what you changed, and what happened. If no such time comes to mind, say so plainly, then say how you would use assessment results | F7 has no evidence in your material, so this is where the belief gets tested for you |

### E — Case / Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our board adopted a three-year literacy plan in August 2026, with a new grades 3 to 5 reading curriculum from fall 2027. What would you want to know before teaching under it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Clarify first: what changes for fourth grade and when, what support teachers get, how families are brought in. Then objective, approach, risks, thinking aloud. If you refer to your own experience, use the quote alone, "I led our grade level's move to a new reading curriculum in 2024," and do not claim more about what it taught you. Check the plan on the district site yourself before Thursday; this pack read only a search snippet of it | F2 meets the plan's grades 3 to 5 curriculum; CO because it scores knowledge of current direction |
| E2 | "It is October and a student in your fourth-grade class is well behind in reading. Walk us through your first two weeks." | CASE | [generic] | A live problem that asks about no past. Structure: what you need to know first, who you talk to, what you try, how you tell whether it is working, how the family hears about it. A plan, not a story | Reading and families are both documented panel topics; CASE because it is judged on structure |
| E3 | "Describe the first week of school in your room. What do you set up?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: classroom routines are a documented panel topic, so expect this. If you set routines, say which and why, in your own words; if none were yours, or none comes to mind, say so plainly and stay with the six years teaching third grade | F3; the question's premise is the topic's, and the guidance does not adopt it |

### G — Conversational (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through your journey to this point." | EXP | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029"; "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc made only of those sentences, in your own words: the licence and endorsement, the six years in third grade, the 2024 move, the club, the weekly email. End on why fourth grade and why here in your own reason, not the pack's | F1, F2, F4, F9 give every beat; casual openers are still scored |
| G2 | "What is on your mind about reading instruction these days?" | JD | [grounded] "I've run the after-school reading club for the last two years" | Treat it as scored. Say what you are actually thinking about or trying; if nothing specific comes to mind, say so plainly and talk about the reading club at its own scope, two years of running it | Reading is the documented topic and the principal's field; a conversational register carries the same scoring |

### H — Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you for a grade you have not taught?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | Pause and restate. Hold: what the quotes carry, six years teaching third grade, the reading club you have run for two years, the weekly email. Concede only the sourced limit: "I haven't taught fourth grade." Do not compare yourself with other candidates; you know nothing about them. Hold through two follow-ups | F8 and F9 under time pressure; hold-then-concede keeps the position to what the quotes carry |
| H2 | "Why should a weekly email count as working with families?" | VAL | [grounded] "I write a weekly email to families" | Do not defend the email as more than it is. Hold: "I write a weekly email to families." Answer slot: if you also talk with families directly, say how, in your own words; if you do not, say so plainly and stay with the email. Concede that the email is one channel, then stop | F4 and F5; pressure packaging of the families belief |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 licence gate | — none, and why: a gate shown met is a fact check, and its whole rehearsal is F1's bridge and G1's first beat |
| F2 reading instruction | A2, C1, C2, C3, E1, E2, G2 |
| F3 classroom routines | B4, E3 |
| F4 how you work with families | D2, H2 |
| F5 speaking with every family | D2, H2 |
| F6 reading plans | D1, E2 |
| F7 assessments inform teaching | C2, D3 |
| F8 fourth grade not taught | A1, A4, B1, H1 |
| F9 third-grade experience | A1, E3, G1, H1 |
| F10 grade-level team | A3, B1, B2, B3, B4 |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "What would you want a teacher new to fourth grade to learn first, and who on the team would show me?" | It states your limit once and turns it into a peer conversation instead of a defense | [grounded] your CV: "I've never taught fourth grade" |
| R2 | "What could a new fourth-grade teacher do in the first month that would genuinely help your team?" | The reciprocity question for the two teammates on the panel | [generic] |
| R3 | "Your Small Groups, Big Readers talk covered weekly reading conferences in grades 3 to 5. What does that look like in a fourth-grade classroom here?" | Ties to the principal's own path and field; ask it only if you have looked at the talk yourself, and ask rather than recite | [grounded] Illinois principals forum speaker page, S3 |
| R4 | "How is the new grades 3 to 5 reading curriculum planned for fall 2027 expected to reach fourth grade, and what support will teachers have?" | Shows you know the board's August 2026 literacy plan; verify the plan on the district site first | [grounded] district news page, S4 (search snippet only) |
| R5 | "The belief says each teacher speaks with every family each term. How do teachers here schedule that?" | Uses the district's published words and signals you read them | [grounded] district Mission and Beliefs page, S1 |
| R6 | "What are the next steps after the panel?" | Practical close; the hiring page says references come after the panel | [grounded] district hiring page, S2 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade or has fourth-grade experience | Negative you stated, F8 | The plain acknowledgment: "I haven't taught fourth grade." Then F9's quote at its own scope and a plan, no past |
| Has been a team lead | Negative you stated, F10 | "I've never been a team lead," beside "I led our grade level's move to a new reading curriculum in 2024," each as written |
| Chose, rolled out or trained colleagues on the new curriculum | Inflated form of F2's quote | The quote at its own scope: the move, your grade level, 2024. The limit is the pack's observation: your material says the move you led, nothing about those steps. A2's slot stays inside the move |
| Speaks with every family each term | Inflated form of F4's quote | The quote at its own scope: a weekly email. The limit is the pack's observation: your material says an email, not conversations. D2's slot stays inside the email |

## Sources

Provided documents: the invite (HR, Orrinsford Community School District) and your résumé text. A government-ID number in your message was not used or repeated, and the licence number was sent in no search.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| # | Query or fetch | Returned |
|---|---|---|
| S1 | Search "Orrinsford Community School District mission values"; fetch of the page | https://orrinsfordschools.example/about/mission-and-beliefs — three published beliefs, read in full |
| S2 | Search "Orrinsford Community School District teacher interview process"; fetch of the page | https://orrinsfordschools.example/careers/how-we-hire-teachers — one 45-minute building panel, topics, references after the panel, read in full |
| S3 | Search "Dolores Vantongeren principal Halvering Elementary School" | https://ilprincipalsforum.example/speakers/dolores-vantongeren — snippet only |
| S4 | Search "Orrinsford Community School District strategic plan news" | https://orrinsfordschools.example/news/board-adopts-literacy-plan — snippet only |
| S5 | Search "fourth grade teacher job posting Illinois elementary school responsibilities qualifications" | https://k12jobsboard.example/listings/fourth-grade-teacher — snippet only |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. District values | yes | Three belief names for D1 to D3, F5 to F7 and R5; no values cheat sheet, because no loop source documents a values round (the hiring page names reading, routines and families) |
| 2. Interview process | yes | Persona weights follow the documented panel; F2 to F4 requirements and E3, B4 |
| 3. District strategy and news | yes | E1 and R4; read as a search snippet only, so verify on the district site |
| 4. Interviewer | yes | The interviewer read, R3 and the reading tilt of the weights |
| 5. Representative posting | yes | Moved nothing: the result is a search snippet, so no row quotes it and no question rests on it |

## Upgrade menu

- The district's posting for this position → F10's `[generic]` requirement and the F2 to F7 requirements become quoted from the posting, and JD questions gain a raising source
- Anything HR said about the panel's focus or a deliverable → coverage beyond the hiring page's three topics, and a build section for any announced task
- The names and roles of the two fourth-grade team members → per-member persona weights and a reverse question tied to each
- Your own answers to the answer slots in F2, F3, F5, F6 and F7 → those rows upgrade from discovery or transferability, and the banks regenerate from them
- Your licence registration record, checked by you → F1's confidence rises from medium to high
- How many hours you have before Thursday → a prioritized prep triage
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence and constraints in place of the inferred objection
