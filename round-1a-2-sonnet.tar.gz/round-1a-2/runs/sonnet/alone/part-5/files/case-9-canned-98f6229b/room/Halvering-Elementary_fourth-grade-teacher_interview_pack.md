# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Employer: Orrinsford Community School District. Panel on Thursday, 45 minutes: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given). Relationship: hiring manager (the principal) plus two future peers. Highest-ROI prep in this pack: A1, the "never taught fourth grade" objection.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Every question carries one persona (its bank) and one type tag.

| Type | Meaning |
|---|---|
| VAL | Behavioral and values: does past behavior show the district's published beliefs |
| EXP | Work-experience deep-dive: do your résumé claims survive follow-up, and what was actually yours |
| JD | Role-driven: can you do the listed job, including its gaps |
| CO | Company and strategy knowledge: how well you know the district's current direction |
| CASE | A live problem from the actual job, answered aloud |

Guidance is scaffolding, not a script. Anything in double quotation marks that is about you is your own sentence, quoted. An answer slot is an instruction for the interview: answer it from what really happened, or say plainly that the practice was not yours or never existed.

## Fit snapshot

The role's duties come from the district's published hiring page and from a representative posting, because the full posting for this opening was not supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — the invite from Human Resources | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | No gap on what you state: the licence, the endorsement and the registration status are in the quote's own terms, and its grades 1–6 span fourth grade. It is a CV line with nothing inspected behind it, so expect the district to verify it, and checking your registration is yours to do before Thursday. Say it as the quote says it |
| F2 | "Fourth Grade Teacher position" — the invite from Human Resources | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "plan and teach reading, writing, math, science and social studies" — a representative posting, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | discovery | The quote gives the grade, the years and the setting, and does not show which subjects were yours to teach. Answer slot: the posting is a typical one, not this team's, but a probe on subjects is likely. If you taught across those subjects, say which, in your own words; if some were taught by others or you did not teach them, say so plainly and stay with what you taught |
| F4 | "reading instruction" — the district's How we hire teachers page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years." — your CV | medium | [grounded] | transferability | Your quotes carry a curriculum move and a club, and they do not show what reading instruction looked like in your classroom. The words stay at that scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: the page names reading instruction as a panel topic, so expect a probe on it. If there is classroom reading instruction you can describe, say what it was, in your own words; if the move and the club are the nearest things you have, say so plainly |
| F5 | "each teacher speaks with every family each term" — the district's Mission and Beliefs page, belief Families Are Partners | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | The quote is a weekly email, and it does not show conversations with families. The words stay there: "I write a weekly email to families." Answer slot: the belief makes a probe on how you and families communicate likely. Say what the email does, in your own words; if you and families communicate in other ways, say what they are; if the email is the way, say so plainly |
| F6 | "classroom routines" — the district's How we hire teachers page | none given | none | [grounded] | discovery | Your material does not show routines. Answer slot: the page names classroom routines as a panel topic. If there are routines you set up, say what they were and how you chose them, in your own words; if routines were the school's or not yours to set, or you cannot name one, say so plainly and describe how you would set them up |
| F7 | "assessments inform teaching and never replace it" — the district's Mission and Beliefs page, belief Teach for Tomorrow, Not for the Test | none given | none | [grounded] | discovery | Your material does not show how assessment results were used. Answer slot: the belief makes a probe on this likely. If assessment results changed what you taught, say what they showed and what changed, in your own words; if they did not, or that was not yours to decide, say so plainly and describe how you would use results |
| F8 | "work with the grade-level team" — a representative posting, K12 Jobs Board | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [inferred] | presentation | The first quote already reaches working with a grade-level team in other terms. Lead with it as written, "I led our grade level's move to a new reading curriculum in 2024", and keep it separate from a team-lead role, which you have said you have not held: "I haven't been a team lead." Expect the two to be set side by side |

## Reading the interviewer

Public professional footprint only. The two fourth-grade team members are unnamed, so there is no read for them.

| # | Public fact | Source | Provenance | What it means for you |
|---|---|---|---|---|
| IR1 | Principal of Halvering Elementary School since 2022 | Illinois principals forum speaker page, search result | [grounded] | She is the hiring-manager seat on the panel: expect the Skeptic and Case/Strategist styles from her |
| IR2 | Nine years as a reading specialist before that | Illinois principals forum speaker page, search result | [grounded] | Reading questions come from someone whose specialty was reading. Candor beats bluffing a competency she owns: stay inside F4's quotes |
| IR3 | A 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5 | Illinois principals forum speaker page, search result | [grounded] | Expect small-group and one-to-one reading questions (B2). Do not describe a conference practice your quotes do not carry |
| IR4 | Mirror opportunity: her talk's theme is reading in grades 3 to 5. Your side: "I've run the after-school reading club for the last two years." — your CV, row F4 | Illinois principals forum speaker page, search result; F4 | [grounded] | A shared subject, not a shared career jump: nothing in the material pairs her path with a jump of yours. Use the quote in its own words if reading comes up, and let her draw the connection |

## Persona weights and table

| Pass | Reading | Source |
|---|---|---|
| Relationship priors | Principal as hiring manager: Case/Strategist and Skeptic. Two fourth-grade teachers as peers: Peer Evaluator and Data-Driven Prober. Panel: blend each member's top two | The invite |
| Interviewer signals | Reading-specialist background and a talk on reading conferences lift reading-centered Case questions | IR2, IR3 |
| The loop | One 45-minute building panel of the principal and two grade-level teachers, asking about reading instruction, classroom routines and families, with references taken after the panel. The loop is established by the district page and the invite, so no archetype fallback applies. No values round is documented, so there is no values cheat sheet; the district's published beliefs theme the Values bank as a raising source | The district's How we hire teachers page; the invite |

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Skeptic (A) | The principal and teammates probe the fourth-grade gap and the team-lead line | Highest, depth 5. F2 is a gap you stated, the principal seat favors this style, and F8 sets two of your own sentences side by side | Rehearse the A1 objection until it is boring: plain acknowledgment, your quotes at their scope, then a plan | A1 to A5 |
| Case/Strategist (B) | Live problems: first-week routines, a struggling reader, assessment use, the district's literacy plan | High, depth 4. The hiring page names routines and reading instruction, and IR2 and IR3 tilt the principal toward reading cases | Clarify first, state the objective, structure, then risks. Think aloud | B1 to B4 |
| Peer Evaluator (C) | Teammates ask what you would need and what you would give, and how you handle disagreement | Medium, depth 3. Two of the three panelists would be your future teammates | Reciprocity first: what you bring them, not only what you need. Offer principles for the seam, not a claim to know it | C1 to C3 |
| Values/Behavioral (D) | Open prompts themed on the published beliefs: families, readers, assessment | Medium, depth 3. The hiring page names families, and no values round is documented, which keeps this below a dedicated values interview | Map a story only where one of your quoted sentences carries it. Where none does, use the scaffold and its honest branch | D1 to D3 |
| Conversational (E) | An opening biography prompt and a licence check | Low to medium, depth 2. Panels open warmly, and the invite itself names the licence | A 90-second arc built only from your quoted sentences | E1, E2 |
| Data-Driven Prober (F) | Attribution and detail on the club and the weekly email | Low, depth 2. Your material has no figures to defend, so probing goes to what each line involved | Say what each line involves, in your own words, and say plainly where you do not know | F1, F2 |
| Pressure | Interruptions and time-boxing | Not banked. Nothing in the sources points to this style in a school panel. A1's hold-then-concede covers the one place it would land | n/a | n/a |

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I don't see fourth grade in your background. How will you handle that in this role?" | JD | [grounded] "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet." — your CV | The highest-ROI rehearsal in this pack. Hold then concede, in three steps. Concede first, in the words you stated: "I haven't taught fourth grade." Then say what you have, at its own scope: "Six years teaching third grade at a public elementary school in Joliet." Then say how you would learn the grade, as a plan and never as a past: in your own words, what you would find out first and from whom. Hold through two follow-ups by returning to those two sentences, never by adding to them, and do not say third grade is the same as fourth. Answer slot: if the panel asks what third grade gave you that carries over, name only what you actually did there; if you cannot name a specific, say so plainly and return to the plan | F2 is the gap you stated, so this objection arrives in some form from at least one panelist. JD because it scores the position's own requirement, delivered in the Skeptic's register |
| A2 | "Which part of the job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" — your message | Give a real answer in your own words, in a sentence or two, and what you would do about it first. Fourth grade is the one you have already stated: "I've never taught fourth grade." If something else is your honest weakest point, say that instead. Do not pick a weakness only to look modest, and do not claim a strength to cover one | A stock Skeptic stem, and F2 makes it likely. JD because it scores readiness for the listed job |
| A3 | "Why fourth grade, and why now?" | EXP | [generic] | Logistics slot, in your own words: give your actual reason in two or three sentences. If your reason is mainly wanting a change, say that plainly rather than dressing it up. If you mention the district, take it from Sources, such as the board's literacy plan, and say only what you have read | Motivation consistency is what the Skeptic scores, and F2 makes the question unavoidable. EXP because the reason is yours alone |
| A4 | "The job covers reading, writing, math, science and social studies. Where are you strongest, and where would you want support?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet." — your CV | The list comes from a typical posting for this role, not this team. Answer slot: say which of those subjects you taught in third grade, in your own words; if some were taught by others or you did not teach them, say so plainly. Strongest and support-wanted are your own judgments; name them honestly and do not invent a strength | F3 is where the multi-subject requirement meets a quote that names no subjects. JD because it tests the posting's duties list |
| A5 | "You mention leading your grade level's move to a new reading curriculum. What was your role on that team?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | Story-mapped on F8 and F4, at the quote's scope: your grade level, a new reading curriculum, 2024, and "I led". If asked about role, say both sentences as you stated them: "I led our grade level's move to a new reading curriculum in 2024", and "I haven't been a team lead." Answer slot: if the panel asks what the move involved, say what you did, in your own words; if parts were others' or there is no step you can point to, say so plainly and return to the quote | F8 sets two of your own sentences side by side, so a careful panelist will ask how they fit. EXP because it tests what was actually yours |

### B. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "It's the first week of school with a brand-new class of fourth graders. Walk us through the routines you'd set up, and why." | CASE | [grounded] | Structure it aloud: what you would ask first (the schedule, what the team already does, what the school expects), what the routines are for, two or three routines with the reason for each, how you would tell they are working, and what you would change. The question needs no claim about your past, so the guidance makes none. Answer slot: if a routine you choose is one you actually ran, say so in your own words; if you are adapting rather than recalling, say that | The district's hiring page names classroom routines as a panel topic, and F6 has no evidence behind it. CASE because it is a live problem set in the role |
| B2 | "One of your students is reading well below the class. What do you do over the next month?" | CASE | [grounded] | Clarify first: what the data and the student's own reading show, and what the family and the team already know. Then the objective, two or three moves, how you would track progress, and what you would do if it is not working. Use the district's own phrase, a reading plan, as vocabulary. The question asks about no past, so the guidance claims none | The principal's reading background (IR2, IR3) and the district's reading emphasis point here; F4 is thin on classroom instruction. CASE because it is a decision under uncertainty |
| B3 | "The board's literacy plan brings a new grades 3–5 reading curriculum from fall 2027. What would that mean for a fourth-grade teacher, and what would you want to know?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Show you read the plan: take one item from it, as the Sources table gives it, then add one question or view of your own about what a fourth-grade teacher would need, your own thinking and not one this pack supplies. If you refer to your own move, use the quote at its scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if asked what you learned from that move, say it in your own words; if you cannot name a specific lesson, say so plainly. Do not suggest you chose or judged Orrinsford's curriculum | The board's August 2026 literacy plan is the district's current direction, and F4's curriculum move sits next to it. CO because it scores strategy awareness |
| B4 | "How would you use assessment results to plan for a class with a wide range of readers?" | CASE | [grounded] | Structure: what you would look at first, what decisions the results inform, how you would keep results informing the teaching and not replacing it, and how you would tell a plan is working. The question asks about no past, so the guidance claims none | The district's belief on assessment, with F7 empty. CASE because the live problem sits in the role |

### C. Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You'd be joining a team that already works together. What do you want from us in your first month, and what can you give us?" | JD | [inferred] | Reciprocity first: lead with what you would offer, then what you would need. Keep the offer real and in your own words, and propose principles for working together rather than claiming to know this team's seams. The question needs no claim about your past, so the guidance makes none | F8's team requirement comes from a typical posting, not this team, and two panelists would be your teammates. JD because it scores the listed teamwork duty |
| C2 | "A teammate teaches a skill differently than you would. Where do you step in, and where do you leave it?" | CASE | [generic] | Structure: what you would ask first, which differences are matters of style and which affect students, and how you would raise the second kind with tact. The question asks about no past, so the guidance claims none | Peers test disagreement style with equals. CASE because it is a live collaboration problem |
| C3 | "How do you handle credit when work spans several teachers?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Story-mapped on F8 at the quote's scope: your grade level, a new reading curriculum, 2024, and "I led". Answer slot: if others contributed and you shared credit in a way you can describe, say how; if the question never arose, say so plainly and return to the quote. Use "we" for context and "I" only for what the quote says is yours | The Peer Evaluator's credit-sharing stem lands on the one team-scale line in your material, F8. EXP because it tests attribution |

### D. Values/Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you built a partnership with a family." | VAL | [grounded] "I write a weekly email to families." — your CV | Theme: the district's belief Families Are Partners. Story-mapped on F5 at the quote's scope: a weekly email, to families. Answer slot: expect a probe on how families reach you and you reach them. Say what the email does, in your own words; if you and families communicate in other ways, say what they are; if the email is the way, say so plainly. Do not describe a family relationship the quote does not carry | The families belief is a published theme and the hiring page names families as a panel topic. F5 is your only family evidence and is a one-way channel. VAL because it scores a published belief |
| D2 | "Tell me about a time you helped a student who was behind in reading." | VAL | [grounded] "I've run the after-school reading club for the last two years." — your CV | Theme: the belief Every Child a Reader. No quoted sentence carries a story about a student who was behind, so use a selection scaffold. Pick a student or small group where you can name what you noticed, what you changed and what happened next, in that order. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, in its own words: "I've run the after-school reading club for the last two years." | A published belief, and F4 has no student-level story. VAL because it tests whether past behavior shows the belief |
| D3 | "Tell me about a time assessment results changed how you taught." | VAL | [grounded] | Theme: the belief Teach for Tomorrow, Not for the Test. No quoted sentence carries this, so use a selection scaffold. Pick a moment where you can name what the results showed, what you changed and what followed. If no such time comes to mind, say so plainly, then say how you would use results, as a plan and never as a past | A published belief with nothing behind it in F7. VAL because it scores behavior against the belief |

### E. Conversational/Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey. How did you get from third grade in Joliet to applying here?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." — your CV; "I've run the after-school reading club for the last two years." — your CV; "I write a weekly email to families." — your CV | A 90-second arc built from your own sentences, in this order: "Six years teaching third grade at a public elementary school in Joliet." Then the club: "I've run the after-school reading club for the last two years." Then the email: "I write a weekly email to families." Then why fourth grade and why this school, in your own words, as A3's logistics slot. Do not add outcomes or numbers your sentences do not carry | Warm openers are still scored, and this one frames everything after it. EXP because it asks for your history in your own words |
| E2 | "Can you confirm your licensure: a current Illinois Professional Educator License with an elementary endorsement?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | Say it in the quote's own terms and stop: the licence, the endorsement, and the registration status. Check your registration before Thursday, since that check is yours | F1 is the invite's stated requirement and the only gate. JD because it scores a listed qualification |

### F. Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "What does the after-school reading club do, and what have you seen from it?" | EXP | [grounded] "I've run the after-school reading club for the last two years." — your CV | Beats the sentence states: after-school, a reading club, run by you, for two years. Answer slot: describe a session in your own words. If you tracked anything, say what you tracked; if you did not, say so plainly. Say plainly what you do not know rather than offering a result | F4 is one of your two reading quotes, and a Prober tests what a line involves. EXP because it tests attribution and detail |
| F2 | "What goes into your weekly email, and what do families do with it?" | EXP | [grounded] "I write a weekly email to families." — your CV | Beats the sentence states: weekly, an email, to families, written by you. Answer slot: say what it contains in your own words; if you know how families respond, say what you know; if you do not know, say so plainly | F5 is a one-line claim, and a Prober asks what is behind it. EXP because it tests attribution |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 licence | E2 |
| F2 fourth grade | A1, A2, A3 |
| F3 subjects | A4 |
| F4 reading instruction | B2, B3, D2, F1 |
| F5 families | D1, F2 |
| F6 classroom routines | B1 |
| F7 assessments inform teaching | B4, D3 |
| F8 grade-level team | A5, C1, C2, C3 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "You came to the principalship after nine years as a reading specialist. How has that shaped the way reading is taught in grades 3 to 5 at Halvering?" | It ties to the principal's own path (IR1, IR2) and shows you read about her, not only the district |
| R2 | "Your 2025 talk covered weekly reading conferences in grades 3 to 5. What does that look like in a fourth-grade classroom here?" | It draws on her published work (IR3) and moves the conversation to craft |
| R3 | "What could a new fourth-grade teacher do in the first month that would genuinely help your team?" | The reciprocity question for the two teammates: it puts what you give ahead of what you need |
| R4 | "The board's literacy plan brings a new grades 3–5 reading curriculum from fall 2027. How is the fourth-grade team getting ready for it?" | It shows you read the district's current plan (B3) and asks about the team's real work |
| R5 | "Each teacher speaks with every family each term. What have teachers here found works best for that?" | It uses the district's own published belief and signals you take family partnership seriously (F5) |
| R6 | "What support is there for a teacher who is new to fourth grade?" | It names the F2 gap on your own terms and asks for the plan you would follow |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated, F2 | "I've never taught fourth grade" — your message, and the plain acknowledgment: "I haven't taught fourth grade." |
| Has been a team lead | Negative you stated, F8 | "I've never been a team lead" — your message, and the plain acknowledgment: "I haven't been a team lead." |
| Led the grade-level team, or led a school-wide or district-wide curriculum adoption | Inflated form of F4 and F8 | The quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024". The limit is the pack's observation: your material says the grade level's move, not a team-lead role or a wider adoption. A5's slot stays inside the move |
| Meets every family one-to-one each term | Inflated form of F5 | The quote at its own scope: "I write a weekly email to families." The limit is the pack's observation: your material says a weekly email, not conversations with each family. D1's slot stays inside the email |

## Sources

Provided documents: the invite from Human Resources of the Orrinsford Community School District, and your résumé and message. No other document was supplied, and no dossier was present.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Query or fetch | Returned | What came back |
|---|---|---|
| Search: Orrinsford Community School District mission values | https://orrinsfordschools.example/about/mission-and-beliefs | Three beliefs: Every Child a Reader, Families Are Partners, and Teach for Tomorrow, Not for the Test. Families Are Partners: each teacher speaks with every family each term. Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it |
| Search: Orrinsford Community School District teacher interview process hiring | https://orrinsfordschools.example/careers/how-we-hire-teachers | One 45-minute building panel of the principal and two grade-level teachers. Panels ask about reading instruction, classroom routines and how you work with families. References are taken up after the panel |
| Search: Orrinsford Community School District strategic plan news | https://orrinsfordschools.example/news/board-adopts-literacy-plan | In August 2026 the board adopted a three-year literacy plan: structured phonics from kindergarten to second grade, a new grades 3–5 reading curriculum from fall 2027, and a family reading night at every school each term |
| Search: Dolores Vantongeren principal Halvering Elementary School | https://ilprincipalsforum.example/speakers/dolores-vantongeren | Principal of Halvering Elementary School since 2022, after nine years as a reading specialist. A 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5 |
| Search: Fourth Grade Teacher job description Illinois elementary school responsibilities qualifications | https://k12jobsboard.example/listings/fourth-grade-teacher | A representative posting: plan and teach reading, writing, math, science and social studies; differentiate instruction using assessment data; keep clear classroom routines; communicate regularly with families; work with the grade-level team |
| Fetch: https://orrinsfordschools.example/about/mission-and-beliefs | page text | The three beliefs above, in the district's own words |
| Fetch: https://orrinsfordschools.example/careers/how-we-hire-teachers | page text | The panel description above |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. District values | yes | The three published beliefs themed D1 to D3 and fixed F5 and F7. No values cheat sheet, because no values round is documented |
| 2. Interview process | yes | Established the loop: one 45-minute panel of the principal and two grade-level teachers. Persona weights follow it, and F4 and F6 come from its topics |
| 3. Strategy or recent news | yes | The August 2026 literacy plan fed B3 and R4 |
| 4. Interviewer name | yes | The principal's public footprint fed the interviewer read, B2 and R1 to R2. The two teammates are unnamed |
| 5. Representative role posting | yes | Supplied the duties behind F3 and F8, labeled inferred |

## Upgrade menu

- The full job posting for this opening: F3 and F8 move from a typical posting to this team's own words, and F6 and F7 may gain a second requirement source
- The recruiter's note on what the panel will focus on: replaces the hiring page's topics as the assumed coverage
- The names of the two fourth-grade team members: a public-footprint read for each, and sharper peer weights
- Your answers to the answer slots on F3, F4, F5, F6 and F7: they become quoted evidence, and the stories in A4, B1, D1 and D3 can be mapped to your own sentences
- A copy of your licence's registration record as the issuer shows it: F1 can move from medium to high
- A tuesday-dossier.md from job-underwriter: verified evidence and a ranked objection list in place of this pack's inferred ones
