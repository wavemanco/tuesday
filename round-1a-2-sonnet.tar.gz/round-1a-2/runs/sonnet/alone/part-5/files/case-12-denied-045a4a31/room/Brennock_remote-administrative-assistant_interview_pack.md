# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

- **Candidate:** Aoife
- **Round:** one 30-minute video call with the office manager, as the invite describes it
- **Interviewer:** the office manager; name not given, and whether they would be your manager or a peer is not stated. This pack is built as a hiring-manager-style round and says so wherever it matters.
- **Version:** first pass

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Every question has a persona letter (A to E) and a number, so you can say "drill B1" and mean one thing.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows the company's published values. Not used here: no published values were in hand |
| EXP | Whether what you say about your experience survives follow-ups, and what was actually you |
| JD | Whether you can do the listed duties, gaps included |
| CO | Whether you know the company and its direction. Not used here: no company research was in hand |
| CASE | A live problem from the actual job, answered aloud |

The guidance cells are scaffolding, not a script. Where a cell says answer slot, it is an instruction for the interview itself: answer from your own experience, or say plainly that the practice was not yours or never existed. Either answer is a good answer. Each guidance cell is meant to be speakable in about two minutes.

The single highest-ROI rehearsal in this pack is B1, the invoices question. It is the most likely objection to your background, and your material is thinnest exactly there.

## Fit snapshot

Requirements are quoted from the ad as you described it in your message. Evidence is your own words from your message. No CV or full ad text was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Your sentence already carries the work in other terms, so the words stay at its scope: "I ran the appointment book for four physios." The material says an appointment book for four physios, and the bridge goes no further than that. Expect a probe on it, since nothing inspectable sits behind a single line |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show whether travel booking was part of your work. Answer slot: the ad names booking travel, so expect a probe. If you have booked travel for anyone, say what and for whom, in your own words; if you have not, or it was not yours, say so plainly, then say how you would go about it as a plan, and stay with the appointment book you ran |
| F3 | "preparing documents in Word and Excel" — the ad, as you described it | "I'm good with Word, okay with Excel" — your message | low | [inferred] | discovery | The quote is a self-rating, not a description of what you prepared, so the bridge asks rather than says. Answer slot: if you have prepared documents in either program, say what kind and what you did, in your own words; if you have not, or it was not yours, say so plainly and stay with your own rating: "I'm good with Word, okay with Excel." |
| F4 | "processing supplier invoices" — the ad, as you described it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your quote says chasing unpaid invoices, and the words stay there: "At the clinic I chased unpaid invoices." The material says chasing, not processing, and does not say whose invoices they were. Answer slot: the ad's wording makes a probe on that likely. If any other handling of invoices was yours, say what, in your own words; if there was none, or it was not yours, say so plainly and stay with the chasing |

## Persona table

The weights rest on one thing you told me and one thing I assumed. The invite says the interview is a 30-minute video call with the office manager, which is one session, so there is no loop to weight across. I assumed the office manager would be your manager, because the invite does not say. That assumption is the starting point for the hiring-manager prior in `references/personas.md`: Case/Strategist and Skeptic on top. The persona weights rest on that pattern and not on any documented process of this employer. No values-style round is detected, so there is no values cheat sheet.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems from the four duties in the ad: a clash in a calendar, a trip to book, a spreadsheet to set up, an invoice that does not match | High. It is the hiring-manager prior, and the ad lists concrete duties that are easy to turn into problems. Five questions | Ask what you need to know first, then give your order of steps, then say how you would tell people. Think aloud. Describe only what you know how to do |
| B. Skeptic | Quiet probing of what your background does not show: invoices, travel, Excel, why leave reception, why remote | High. It is the other half of the hiring-manager prior, and your material is thinnest on these duties. Five questions | Rehearse B1 until it is boring. Hold your own sentences through two follow-ups, then say where the experience stops and how you would learn the rest |
| C. Conversational | Friendly opener: "walk me through the journey." Feels unscored, is scored | Medium. A 30-minute video call by an office manager is likely to open this way, but nothing you gave me says so. Three questions | Prepare a 90-second arc built only from what you have said. Treat casual questions about Excel and the appointment book as scored |
| D. Data-Driven Prober | Pins down your numbers: four physios, two years, the unpaid invoices | Medium. Your background has a few figures and one line about invoices, and an office manager who handles supplier invoices may probe detail. Three questions | Know what you can and cannot say about each figure, and say plainly when you do not know how something was counted |
| E. Peer Evaluator | "Where is the line between asking and fixing?" and "what happens when two people want the same thing first?" | Low. It matters only if the office manager turns out to be a peer, which the invite does not say. Two questions | Offer principles for how you would work with the team, and ask what would help them, not only what you need |

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two people each need you to book the same hour on Thursday, and only one of them can have it. What do you do?" | CASE | [generic] | Structure it aloud: first ask what is fixed and what can move, and who decides when priority is unclear; then say what you would do; then say how both people would hear about it, promptly and in the same way; then what you would record. The question asks for no claim about your past, so the guidance makes none | The ad's calendar duty, which F1 covers on the evidence side, asked here as a decision. CASE because it is a live problem. [generic] because it is a pattern for the problem and not a fact about this employer |
| A2 | "A colleague needs to be at a client site in Cork by 10am on Tuesday and back that night. What do you need to know before you book anything?" | CASE | [generic] | Say the questions before the plan: what is fixed, who approves the cost, what the colleague prefers, what happens if the meeting moves, and who you confirm the booking with. Then give the order you would book in. Nothing here claims past travel booking, so the guidance makes none | The ad's travel duty, where F2 shows no evidence either way. A live problem lets you show your reasoning without a claim you cannot back. CASE because it is hypothetical |
| A3 | "A supplier's invoice arrives for more than the quote on file, and the person who ordered the work is away until Friday. What do you do?" | CASE | [generic] | Ask first what you can check yourself and who is allowed to approve payment. Say you would not approve or pay on your own, and say what you would tell the supplier and who you would ask. Say what you would write down. No claim about your past | The ad's invoice duty, where F4 shows chasing only. A decision question lets you show judgment without claiming invoice processing. CASE because it is a live problem |
| A4 | "Here's a list of supplier invoices with amounts and due dates. How would you set it up in Excel so you can see at a glance what is due this week?" | CASE | [generic] | Ask what exists already and who needs to read it. Then describe the set-up in steps, using only steps you actually know how to do. For anything you would have to look up, say so plainly and say where you would look. No claim about your past | The ad's Excel duty, where F3 gives a self-rating only. Thinking aloud tests the skill without resting on the rating. CASE because it is a live task |
| A5 | "You're the only administrator on a remote team. In one hour you get a calendar change, a travel request and a supplier asking about an unpaid invoice. How do you order them?" | CASE | [generic] | Say how you would decide what is urgent, by deadline and by consequence, then give your order. Say how each person would learn when to expect their answer. Say what you would ask your manager. No claim about your past | Combines three of the ad's duties under the role's remote setting, which comes from the invite's job title. CASE because the question tests prioritising |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "At the clinic you chased unpaid invoices. This job is processing supplier invoices. What have you actually done with invoices?" | JD | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack, and the hold is only what the quote carries: "At the clinic I chased unpaid invoices." Answer slot: the ad's wording makes a follow-up on whose invoices they were and what else you did with them likely. If any other handling was yours, say what, in your own words; if there was none, or it was not yours, say so plainly and stay with the chasing. Hold through two follow-ups by returning to the chasing, never by adding to it. Then say plainly where the experience stops and how you would learn the rest, said as a plan | F4 is the row where the ad's duty and your sentence are furthest apart, so this objection arrives in some form. JD because it scores a stated duty |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I'm good with Word, okay with Excel" | Choose the part yourself. If it is Excel, your own sentence is "I'm good with Word, okay with Excel", so say that and then what you would practise first, said as a plan. If it is travel booking, answer slot: if you have booked travel for anyone, say what and for whom; if you have not, or it was not yours, say so plainly. Do not claim to have no weak spot | F3 and F2 are the likeliest answers, and a candid pick converts the probe into credibility. JD because it scores the listed duties |
| B3 | "Why move from reception into an administrative role, and why remote?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Give your actual reasons, in your own words. The pack supplies none. Keep each to a sentence or two, begin from the clinic work as you described it, and say nothing against the clinic | Motivation consistency is what the Skeptic scores, and the answer is yours alone. EXP because it tests whether your story holds together |
| B4 | "Tell me about a time you had to work something out without anyone available to ask." | EXP | [generic] | Selection scaffold: pick a time with a named problem, what you tried, what you did and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The theme comes from the invite's job title, Remote Administrative Assistant. EXP because it asks for a past instance, and [generic] because no sentence of yours carries a story for it |
| B5 | "You say you're good with Word. What was the last document you prepared with it?" | JD | [grounded] "I'm good with Word, okay with Excel" | Answer slot: the ad names preparing documents in Word and Excel, so expect this probe. If you prepared documents, name the kind and what you did, in your own words; if you did not, or it was not yours, say so plainly and return to your own rating: "I'm good with Word, okay with Excel." | F3 is a self-rating, so this question tests it directly. JD because it scores the listed duty |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey: how did you get from the clinic to this?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios" | A 90-second arc in three beats: the clinic job, "two years as a receptionist at a physiotherapy clinic"; the appointment book, "I ran the appointment book for four physios"; then your own reason for this role, which the pack does not supply. Add no other beats | The biography opener is almost certain in a short video call, and it is where a candidate over-explains. EXP because it tests whether the CV story is consistent |
| C2 | "What did you like most about running the appointment book?" | EXP | [grounded] "I ran the appointment book for four physios" | Give your own honest answer in a sentence or two, anchored in the work as you did it. Add no detail you would not stand behind if asked a second question. A casual question is still scored, for genuine interest | It is the friendly version of F1's probe. EXP because it tests whether your interest is real |
| C3 | "What are you actually playing with in Excel these days?" | JD | [grounded] "I'm good with Word, okay with Excel" | Answer slot: the ad names Excel, so treat this as scored. If you use Excel for anything now, say what, in your own words; if you do not, say so plainly and say what you would start with, as a plan | F3 raised casually. JD because it scores the Excel duty |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through a normal day running that appointment book." | EXP | [grounded] "I ran the appointment book for four physios" | The beats your sentence states are the appointment book and the four physios. Answer slot: the ad names managing calendars, so expect a probe on how you ran the book day to day. If any of it was yours to decide, say what and how, in your own words; if there was no such step, or it was not yours, say so plainly and describe the day as you actually saw it | F1 tested for what was actually yours. EXP because it checks the CV line against your own account |
| D2 | "You say four physios and two years. Which part of running their book was yours alone?" | EXP | [grounded] "I ran the appointment book for four physios"; "two years as a receptionist at a physiotherapy clinic" | The figures raise four slots, each answered in your own words: how the number four was counted, what it depends on, the assumption behind it you would defend least, and which part was yours. If you do not know how a figure was counted, say so plainly. Never name a part you did not do | Every headline figure on the page gets a defend-the-number question, and these are F1's. EXP because it tests attribution |
| D3 | "Walk me through how you chased unpaid invoices." | EXP | [grounded] "chased unpaid invoices" | The beats your sentence states are the unpaid invoices and the chasing. Answer slot: the ad names processing supplier invoices, so expect a probe on what the invoices were and who they were owed to. Say what you know, in your own words; if you do not know, or it was not yours, say so plainly and stay with the chasing | F4 again, at the Prober's depth. EXP because it checks the CV line against your own account |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You'll be booking things for several people who each want theirs first. Where is your line between asking someone and just fixing it?" | CASE | [generic] | Offer a principle, not a story: ask when the choice affects someone else, costs money or cannot be undone; fix it yourself when it is small and easy to reverse. Say the principle aloud, then say you would check with the office manager which cases they want to hear about. No claim about your past | A peer-style question about turf and trust. CASE because it is a live judgement. [generic] because it is a pattern for the problem |
| E2 | "How do you handle it when two of the people you're supporting want the same thing first?" | CASE | [grounded] "I ran the appointment book for four physios" | If an instance from the appointment book you ran comes to mind, tell it as it happened. If none does, say so plainly and say how you would handle it. Either way, end on what you would do to keep both people informed | Credit and priority between equals is the Peer's usual probe. CASE because it is a hypothetical, with F1 as the only evidence it could draw on |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "managing calendars" | A1, A5, D1, D2, E1, E2 |
| "booking travel" | A2, A5, B2 |
| "preparing documents in Word and Excel" | A4, B2, B5, C3 |
| "processing supplier invoices" | A3, A5, B1, D3 |

No question carries a CO or VAL tag, because no company research and no published values were in hand.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which of calendars, travel, documents and invoices takes most of the week for the person in this role?" | It uses the ad's four duties and tells you where to spend your prep |
| R2 | "How do supplier invoices arrive and get approved here, and where does this role sit in that?" | It shows you take invoices seriously and addresses your thinnest row without claiming experience |
| R3 | "Which tools do you use for calendars, travel booking and spreadsheets?" | It closes the Excel and travel questions in your favour by asking, not guessing |
| R4 | "How do you and the person in this role stay in touch through the day, since the role is remote?" | It shows you have thought about working without anyone beside you |
| R5 | "How is equipment provided for remote staff, and does anything have to be paid for before someone starts?" | It is a normal onboarding question, and the answer tells you plainly how this employer works |
| R6 | "What could a new person do in their first month that would really help you?" | A reciprocity question, useful if the office manager turns out to be a peer, and a good close either way |

## Prohibited claims

Built from the fit snapshot before the banks were written. None of these is a finding that you lack the thing. Each lists wording this pack will not put in your mouth.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars for a team or an office | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation, not words for you: the material says an appointment book for four physios. A1 and D1 stay inside the book |
| Processed supplier invoices | Inflated form of F4 | F4's quote at its own scope: "chased unpaid invoices." The material says chasing, not processing. B1 and D3 stay with the chasing |
| Advanced Excel skills | Inflated form of F3 | F3's quote at its own scope: "I'm good with Word, okay with Excel." |

## Sources

Provided documents: the invite email you pasted, and your message (the ad's duties as you described them, and your background). No CV and no full ad text were supplied. No dossier was supplied.

Searches sent:

- `Brennock Facilities Ltd values` — refused
- `Brennock Facilities Ltd interview process remote administrative assistant` — refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | The search was refused. It would have supplied published values for VAL questions; none is in the pack |
| 2. `Brennock Facilities Ltd interview process remote administrative assistant` | unavailable | The search was refused. It would have checked the loop; the invite's own words, one 30-minute video call with the office manager, stand in |
| 3. `Brennock Facilities Ltd strategy` and recent news | unavailable | No call was sent, because search permission was not granted. It would have supplied a CO question; none is in the pack |
| 4. `{interviewer name} Brennock Facilities Ltd` | n/a | No name was given, so there was no query to form |
| 5. representative `Remote Administrative Assistant` JD | skipped | The ad's duties as you described them fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The office manager's name and whether they would be your manager or a peer → persona weights recomputed, and a reverse question tied to their own path
- The full ad text → the four requirement quotes become the ad's own words, and any further requirement gets a row and a question
- Your CV text → more evidence rows quoted in your own words, and F1 to F4 re-graded
- Your own answers to the slots in F2, F3 and F4 (travel booking, documents prepared, invoices beyond chasing) → those rows upgrade from discovery or transferability, and B1, B2, B5 and D3 get story maps
- Search permission, plus a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → published values, strategy and loop details, a CO question and a values cheat sheet if a values round is documented
- The recruiter's notes on focus areas or anything you are asked to prepare → coverage of any pre-declared deliverable
- How much prep time you have → a prioritised schedule over the 18 questions
- A tuesday-dossier.md from an earlier evaluation of this opportunity → verified evidence and a sourced list of claims to avoid, in place of the ones built here
