# Interview pack: Operations Coordinator, Quillmoor Diagnostics

Recruiter screen with Hannah Lowther, Talent Partner. Thursday at 2pm, a 30-minute phone call; she rings the mobile number on your application. Her own agenda, from her LinkedIn message: "salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move, and then I'll tell you about the team and the next steps."

## How to use this pack

Personas are how a question arrives (friendly, sceptical, time-boxed). Types are what it is scoring. Every question carries one type tag:

| Tag | Meaning |
|---|---|
| VAL | Does past behaviour show the company's published values |
| EXP | Do the claims about your work survive scrutiny; what was actually you |
| JD | Can you do the listed job, gaps included |
| CO | Homework on the company and its strategy |
| CASE | A live problem from the role, reasoned out loud |

Guidance is scaffolding, not a script. Where a cell says "answer slot", it is an instruction for the interview: answer from your own experience in your own words, and where the practice was not yours or never existed, say so plainly. Where a cell says "logistics slot", the answer is your own fact, said as you stated it.

## Fit snapshot

Requirements are quoted from the advert you pasted, or from Hannah's message. Evidence is your own words from your message to me.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says delivery scheduling, not production scheduling, and says nothing about planning or QA, so the words stay at the quote's scope: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who your scheduling involves likely. If it involved coordinating with other teams, say which and what part was yours, in your own words; if it did not, or was not yours, say so plainly and stay with the deliveries you schedule |
| F2 | "track supplier deliveries" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | Your material does not say whether the deliveries you schedule are supplier deliveries, or how you follow one. Answer slot: the advert's tracking line makes a probe on how you know where a delivery stands likely. If you track deliveries from suppliers, say how, in your own words; if the deliveries you schedule are not supplier deliveries, or tracking is someone else's, say so plainly and stay with the scheduling you do |
| F3 | "chase late orders" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap, but a statement with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: you chase suppliers when orders slip |
| F4 | "keep stock records accurate" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap on the quote's face, but a figure with nothing inspected behind it, so a defend-the-number probe is expected (C1, E2). Keep "about a third" and "over a year" exactly as said. The sentence puts the rebuild and the fall side by side and does not say the rebuild caused the fall, and the words stay there |
| F5 | "report weekly on on-time dispatch" — the advert | none given | none | [grounded] | discovery | Your material shows no regular reporting either way. Answer slot: the advert's weekly-report line makes a probe on what you report today likely. If you report on deliveries or dispatch, say what and to whom, in your own words; if there is no such report, or it is not yours, say so plainly and say what you would measure first |
| F6 | "2+ years in operations or logistics coordination" — the advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap, but a one-line statement with nothing inspected behind it. Say it as written: the years, the title, the kind of employer |
| F7 | "confident with Excel" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | Your sentence says spreadsheet and does not say which software, so the pack does not call it Excel. Answer slot: the advert's Excel line makes a probe on what you do in it likely. If the spreadsheet was in Excel, say what you did in it, in your own words; if it was another tool, or Excel is not what you use, say so plainly and stay with the spreadsheet you rebuilt |
| F8 | "ERP experience (SAP or similar) a plus" — the advert, the SAP part | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. The advert's own word is "a plus", which is the pack's reading of how much weight it carries. Words: "I've never used SAP." Then how you would learn it, said as a plan and never as a past. Never a claim to SAP work |
| F9 | "ERP experience (SAP or similar) a plus" — the advert, the "or similar" part | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | discovery | Your sentence names an in-house stock system and does not say whether it is an ERP, so the pack does not call it one. Answer slot: the advert's "or similar" makes a probe on what that system does likely. Say what you do in it, in your own words; if you use it for little, or it is nothing like an ERP, say so plainly and stay with "we run our own in-house stock system" |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — the advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | A term your own words show met: two days is fine. Say both halves as stated and keep "wouldn't want" at the strength you gave it |
| F11 | "£38,000–£44,000" — the advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Say the figure as you stated it, as a hope, with nothing added about floors or flexibility. The figure raises no defend-the-number question |
| F12 | "your notice period" — Hannah Lowther, LinkedIn message | none given | none | [grounded] | discovery | Your material gives no notice period, so the pack supplies none. Logistics slot: give your actual notice period, in your own words |
| F13 | "what's prompting a move" — Hannah Lowther, LinkedIn message | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | No gap. Say it as you said it to me, with the facts in the same order and nothing added |

## Persona table

Weights for this session rest on Hannah's own stated agenda (above) and this skill's recruiter-screen prior. Later rounds are not documented by any source I could read, so the weights for Case, Prober and Pressure rest on the generic screen, hiring manager, panel pattern and are insurance, not prediction.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport | Friendly walk-through, then pay, notice, hybrid and reason for leaving, each asked in an easy register | High. Hannah's message lists exactly these topics, and a screen run as a friendly logistics call is where casual questions still get scored | Pre-script the 90-second arc (A1); give each logistics answer as your own fact, as stated; do not treat the call as unscored |
| B. Skeptic | Quiet probing of the gaps: the SAP line, the wholesaler-to-manufacturer step, why Quillmoor | Medium. She named "what's prompting a move" herself, and F8 is a stated gap against a line in the advert | Rehearse B1 until it is boring; bridges only from your own sentences; where there are none, say the limit plainly |
| C. Data-Driven Prober | Closed checks on the advert's measurable duties: the figure, the tracking, the Excel, the weekly report | Medium. The advert names stock accuracy and weekly dispatch reporting, and your one figure invites a how-was-it-counted question | Know what you can and cannot say about how the third was counted, and say plainly where you do not know |
| D. Case / Strategist | A live problem from the role: a late supplier, a record that does not match the shelf, competing priorities | Low on this call, higher in a later team conversation. The call is 30 minutes and Hannah's agenda has no case | Clarify, then objective, then who needs to know, then options, then how you record it; think aloud |
| E. Pressure | Time-boxed or devil's-advocate versions of the SAP and motivation questions | Low. Nothing in Hannah's message suggests it; it is here so the second follow-up on SAP is not a first | Pause, restate, hold the position the quotes carry through two follow-ups, concede one point specifically |

## Question banks

Highest-ROI prep: B1 (SAP and systems). It is the one gap you have stated, the advert names it, and it is the question most likely to be asked in some form.

### A. Conversational (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey: what you do now and how you got here." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | A 90-second arc with only the beats the two sentences state: four years, logistics coordinator, a building-supplies wholesaler; you schedule deliveries for three depots; you chase suppliers when orders slip. Tell it in your own words and stop there. Anything before this job, or any beat beyond these, is yours to add only if it is true and you could answer a second question on it. Close by naming the advert line your sentences sit nearest | F6 and F3 carry the beats. EXP because it tests whether the one-line background holds up when told aloud; casual in register, scored all the same |
| A2 | "What's prompting a move at the moment?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Logistics slot. Say it as you said it to me: the Bristol office is closing next year, the only offer is relocating to Reading, and you don't want that. That is the whole of your stated reason, so add no second reason and nothing about your employer beyond the closing. Expect "why not Reading?": the sentence already answers it, so say that you don't want it and stop | F13 holds the reason. EXP because it scores whether the reason for leaving is consistent and candid; Hannah named it herself |
| A3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot. Give the figure you gave me, in those terms: you are hoping for £42,000. Keep it a hope, as said, with no floor, no flexibility and no salary history added. Say it once, then stop | F11 holds the figure beside the advert's band. JD because pay is a listed term of the job |
| A4 | "What's your notice period?" | JD | [grounded] | Logistics slot. Give your actual notice period, in your own words. If you do not know it exactly, say so and say when you will confirm it. Nothing here to quote: your material gives none, so the pack supplies none | F12 is empty on purpose. JD because notice is a term of the job's start, asked by Hannah in her own words |
| A5 | "How would the hybrid pattern work for you, with two days a week at Avonmouth?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot. Say both halves as you said them: you live in north Bristol, two days at Avonmouth is fine, and you wouldn't want more than three. Keep "wouldn't want" at that strength: do not harden it into "can't" or soften it into "flexible". Answer slot: if she asks about the journey to Avonmouth, say how you would make it, in your own words; if you have not worked it out, say so plainly | F10 is a term your words show met. JD because the advert states the pattern |

### B. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "ERP experience is a plus here. What systems have you worked in, and have you used SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | The deepest rehearsal in the pack. Level 1, "Have you used SAP?": the plain answer your sentence gives, "I've never used SAP." Say it first and do not qualify it. Level 2, "What do you use?": the other half of the sentence at its own scope, "we run our own in-house stock system". Answer slot: if she asks what you do in it, say what you actually do, in your own words; if you use it for little, or it is not like an ERP, say so plainly and stay with the sentence. Level 3, "How would you get up to speed on SAP?": a plan, said as a plan in the future tense, with what you would do first. If you have already started, that is a separate true sentence you add yourself. The limit, named before it is asked: your material says an in-house stock system and nothing on whether it counts as an ERP, so do not call it one | F8 and F9 are the gap you stated and the line the advert names. JD because it scores a listed plus; the likeliest objection because a stated absence meets a named system |
| B2 | "Which part of this advert would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | One gap is stated, so one answer is whole and honest: "I've never used SAP", with how you would learn it as in B1 level 3. Answer slot: if another line of the advert is the one you would pick, say which and why, in your own words, as a plan for closing it; if SAP is the one, stop there. Do not present a strength as a weakness | F8 is the stated gap; F1 and F5 are the rows where your material is adjacent or silent. JD because it asks for self-assessment against the advert's own lines |
| B3 | "We coordinate production schedules between planning, the warehouse and QA, and you've come from a wholesaler. How does your work compare?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Hold only what the sentences carry: "I schedule deliveries for our three depots." Answer slot: the advert names planning, the warehouse and QA, so expect a probe on who your scheduling involves. If it involved coordinating with other teams, say which and what part was yours, in your own words; if it did not, or was not yours, say so plainly and stay with the deliveries. If there was no production scheduling in your work, say what you would learn first, as a plan | F1 is the widest step between your sentence and the advert's duty. JD because it scores the headline responsibility; Skeptic because the wholesaler-to-manufacturer step is the natural doubt |
| B4 | "What draws you to Quillmoor?" | CO | [generic] | Answer slot: say what actually draws you, in your own words, from what the advert says (a diagnostic-test manufacturer, about 400 staff, a site at Avonmouth in Bristol) or from anything you have learned since; if nothing beyond the fit with the role and the location, say so plainly. Your reason for looking (A2) is why you are moving, not why Quillmoor, so keep the two answers apart. No company research ran, so the pack holds nothing about Quillmoor beyond the advert | F13 holds your reason for looking. CO because it tests homework; generic because the searches were refused and no fact about Quillmoor beyond the advert is in hand |

### C. Data-Driven Prober (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third over a year. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Beats the sentence states: you rebuilt the stock-count spreadsheet, discrepancies fell by about a third, over a year. Say "about a third", not a rounder or sharper figure. Defend-the-number slots, each in your own words: how it was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how it was counted, say so plainly. Keep the sentence's order, rebuilt and then fell, and say "because" only if you could back it under a second question | F4 holds your one headline figure. EXP because figures are where probers check attribution |
| C2 | "Walk me through how you schedule deliveries across your three depots." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Beats the sentence states: you schedule deliveries, for three depots, and you chase suppliers when orders slip. Answer slot: the advert's "track supplier deliveries" line makes a probe on how you know where a delivery stands likely. If you track deliveries, say how, in your own words; if tracking is not part of the scheduling, or not yours, say so plainly and stay with the scheduling | F1 and F2 are the rows this probe presses on. EXP because it tests what you did day to day |
| C3 | "The advert asks for confidence with Excel. What do you do in it day to day?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Start from the one sentence: you rebuilt the stock-count spreadsheet. Answer slot: if it was Excel, say what you did in it, in your own words; if it was another tool, or Excel is not what you use day to day, say so plainly and say what the spreadsheet did | F7 is discovery: the sentence says spreadsheet, not software. JD because Excel is a stated requirement |
| C4 | "The role reports weekly on on-time dispatch. What do you report on today?" | JD | [grounded] | Answer slot: if you report on deliveries or dispatch, say what and to whom, in your own words; if there is no such report, or it is not yours, say so plainly and say what you would measure first. Nothing in your material to quote, so the pack supplies no report, cadence or measure | F5 is empty. JD because the weekly report is a stated duty |

### D. Case / Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you on Monday that a delivery the site needs this week will arrive a week late. Walk me through what you do." | CASE | [generic] | Clarify first: what is in the delivery, what the new date really is, what is already in stock. Then the objective: keep the schedule, or protect the critical items. Then who needs to know; the advert names planning, the warehouse and QA. Then options, such as a part delivery or another source, and how you would record it and follow up. Think aloud and challenge one premise politely. This asks for no past, so the guidance makes no claim about yours | Advert lines "track supplier deliveries" and "chase late orders" (F2, F3) as a live problem. CASE; generic because it is a pattern for the problem, not a fact about Quillmoor |
| D2 | "The system says 120 of an item and the shelf holds 108. What do you do before you change the record?" | CASE | [generic] | Clarify: when each count was taken, and what has moved since. Objective: a record people can trust. Check the count, ask who handled it, correct the record with a note of why, then look for the cause so it does not recur. Think aloud; no claim about your past | F4's requirement as a decision rather than a record. CASE; generic |
| D3 | "Planning wants a rush batch out, QA is holding another, and the warehouse is short of space. How do you sequence it?" | CASE | [generic] | Clarify what is firm and what is only wanted, and what depends on what. Do not pretend to know who decides between planning and QA; propose a principle for how you would find out and bring them together. Then sequence, then communicate the result to all three. Think aloud | The advert's three-way coordination line (F1). CASE; generic, and the likeliest case form if a team conversation follows |

### E. Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a candidate who has used SAP?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "Never used SAP — we run our own in-house stock system." | Hold-then-concede. Pause and restate the question. Hold the facts, with no comparison to someone you have not met: four years as a logistics coordinator at a building-supplies wholesaler; you schedule deliveries for three depots; you chase suppliers when orders slip. Concede in the middle, plainly: "I've never used SAP." Follow-up 1, "that doesn't answer it": return to the facts. Follow-up 2, "so SAP is a risk?": concede only that one point, that you have not used it, and stay with the three sentences. Do not fold on the facts, and add no claim about how fast you learn that you could not back | F8, F6 and F3 are the rows it presses. JD because it scores the listed plus; Pressure because the time box tests whether the concession stays specific |
| E2 | "That drop in discrepancies. How much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold: the sentence says "I rebuilt" the spreadsheet, so the rebuild was yours. Concede specifically: the sentence puts the rebuild and the fall side by side and does not give the rebuild's share of the fall. Answer slot: if you can say what share of the fall was the rebuild's, say it in your own words and how you know; if you cannot separate it, say so plainly and return to the rebuild. Hold through two follow-ups by returning to what the sentence says, never by adding to it | F4 holds the figure. EXP because attribution is what a how-much-was-you probe scores |
| E3 | "You're leaving because your office is closing. Is this a job you want, or just a job?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Hold-then-concede. Pause. Hold what you said: the closing office is why you started looking, and Reading is the only offer, which you don't want. Concede that the closing is a different thing from why this job, then go to B4's answer slot for what draws you, from the advert or from what you have learned; if nothing beyond the fit, say that plainly. Do not claim an enthusiasm you do not have, and do not disown the closing | F13 holds the reason. EXP because it scores motive consistency under a pushed framing |

## Requirement coverage

| Advert requirement | Covered by |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B3, D3, D1 |
| Track supplier deliveries | C2, D1 |
| Chase late orders | C2, D1 |
| Keep stock records accurate | C1, D2, E2 |
| Report weekly on on-time dispatch | C4 |
| 2+ years in operations or logistics coordination | A1 |
| Confident with Excel | C3 |
| ERP experience (SAP or similar) a plus | B1, B2, E1 |
| Hybrid, two days a week at Avonmouth | A5 |
| £38,000–£44,000 | A3 |
| Hannah's topics: notice period, what's prompting a move | A4, A2, E3 |

## Reverse questions

| # | Question to ask Hannah | Why it lands |
|---|---|---|
| R1 | "Which of planning, the warehouse and QA would this person work with most in a normal week?" | It picks up the advert's three-way coordination line and tells you which team the role leans on |
| R2 | "Which systems does the team use for stock and supplier tracking, and how does someone new get up to speed on them?" | It meets the SAP line directly, as a question about learning rather than a claim, and the answer tells you whether training exists |
| R3 | "Are the two Avonmouth days fixed, or agreed with the team?" | It follows from your own two-days-is-fine position and shows you have thought about how the pattern runs |
| R4 | "What does the weekly on-time dispatch report look like today, and who reads it?" | It turns the advert's last duty into something concrete and shows you read the whole list |
| R5 | "Who would my next conversation be with, and what will it focus on?" | She has said she will cover next steps; this asks what the next round will test, so the right bank gets your prep time |
| R6 | "What would a good first three months look like in this role?" | A generic closer that still shows you are thinking past the offer; it works because it invites her to say what the team lacks |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: the material says delivery scheduling, not production scheduling |
| Has used SAP | Negative the candidate stated, F8 | "Never used SAP — we run our own in-house stock system." The plain acknowledgment F8 gives: "I've never used SAP." No slot |
| Has ERP experience, or that the in-house stock system is an ERP | Inflated form of F9 | F9's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation: the material does not say whether it is an ERP |
| Cut discrepancies by a third because of the rebuild | Inflated form of F4 | F4's quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The limit is the pack's observation: the sentence sets the rebuild and the fall side by side |
| Advanced or expert Excel | Inflated form of F7 | F7's quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The limit is the pack's observation: the material says spreadsheet, not which software |

## Sources

Provided documents: Hannah Lowther's LinkedIn message; the Operations Coordinator advert; your own account of your background and what you would tell her, in your message. No CV was provided; the background in your message stands in for it. No dossier was provided.

Searches sent, all refused (the host did not grant search permission):

- `Quillmoor Diagnostics values` — refused
- `Quillmoor Diagnostics interview process operations coordinator` — refused
- `Quillmoor Diagnostics news strategy` — refused
- `Hannah Lowther Quillmoor Diagnostics` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Every call was refused. It would have fed a values cheat sheet only if a loop source documented a values round; no such section is in this pack, and B4 is generic |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Every call was refused. It would have named later rounds and moved the Case, Prober and Pressure weights; those rest on the generic archetype and are said to |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | Every call was refused. It would have grounded B4 and added a strategy-based CO question |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Every call was refused. It would have supplied a public-footprint read and a reverse question tied to her path; both are absent |
| 5. representative `Operations Coordinator` JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access, so the four refused searches can run → B4 becomes grounded, a values and loop picture of Quillmoor if one is published, and an interviewer read plus a reverse question tied to Hannah's path if public information is attributable to her
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, needing the same search access → a strategy brief for a CO question and notes on recent company context
- Your full CV → more rows move from your one-paragraph background to quoted CV lines, and F1, F2 and F7 may change grade
- Your notice period, said outside a drill → F12 gets a quote and A4's slot is filled in your words
- Whether the deliveries you schedule are from suppliers, whether the stock-count spreadsheet is in Excel, what you do in the in-house stock system, and whether you report on dispatch → F2, F5, F7 and F9 can be re-graded from discovery
- Your prep time before Thursday → a prioritised schedule of the few questions to rehearse in order
- Anything Hannah or the advert says about the next round → per-round mini-packs for the later conversations
- A tuesday-dossier.md from job-underwriter, if you have one → verified evidence and agreed positioning on the SAP gap, so B1 and E1 rest on it rather than inference
