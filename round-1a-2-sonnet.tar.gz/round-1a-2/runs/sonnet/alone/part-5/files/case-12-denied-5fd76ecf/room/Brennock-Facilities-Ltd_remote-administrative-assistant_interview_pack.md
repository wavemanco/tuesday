# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

- **Role:** Remote Administrative Assistant
- **Company:** Brennock Facilities Ltd
- **Interviewer:** "our office manager", name not given. The invite says the interview is "a 30-minute video call with our office manager"
- **Relationship:** not stated. This pack assumes the office manager could be your day-to-day manager. If not, the persona weights below change
- **Version:** first pack, no regeneration

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and only what you actually did.

| Type | What it tests |
|---|---|
| VAL | Whether past behaviour shows the company's published values. None are used here: no values source was available |
| EXP | Whether a claim about your past survives follow-up questions |
| JD | Whether you can do the listed duties, gaps included |
| CO | What you know about the company |
| CASE | A live problem from the job, answered by structuring it aloud |

An "answer slot" is an instruction for the interview, not a question for you now. It names the honest branches: say what you did if you did it, or say plainly that it was not yours or did not happen.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (the ad, as you described it) | "I ran the appointment book for four physios" (your message) | medium | [grounded] | transferability | Your material says an appointment book for four physios, with nothing inspected behind it, and the words stay there: "I ran the appointment book for four physios." Answer slot: the ad's calendar line makes a probe on how that book compares with managing calendars likely. If any part of running it meant working around changes or competing requests, say what happened and what part was yours, in your own words; if not, or it was not yours, say so plainly and stay with the book you ran |
| F2 | "booking travel" (the ad, as you described it) | none given | none | [grounded] | discovery | Your material does not show travel booking either way, so the pack writes no words for you. Answer slot: if you have arranged travel for anyone, yourself included, say what and how, in your own words; if you have not, say so plainly and say how you would learn it |
| F3 | "preparing documents in Word and Excel" (the ad, as you described it) | "I'm good with Word" (your message) | low | [grounded] | discovery | A self-rating with nothing inspected behind it, and it touches Word without showing what was prepared in it. The words stay: "I'm good with Word." Answer slot: expect "what documents?"; say what you have prepared, in your own words; if little, say so plainly |
| F4 | "preparing documents in Word and Excel" (the ad, as you described it) | "okay with Excel" (your message) | low | [grounded] | discovery | The level you stated is "okay with Excel", and the words stay at that level. Answer slot: expect "what have you used it for?"; say what you used it for, in your own words; if little, say so plainly and say what you would practise first |
| F5 | "processing supplier invoices" (the ad, as you described it) | "chased unpaid invoices" (your message) | medium | [grounded] | transferability | The pack's observation: your material says chasing unpaid invoices, not processing supplier invoices. The words stay: "I chased unpaid invoices." Answer slot: if any invoice work at the clinic involved invoices coming in, being checked or being paid, say what and what part was yours, in your own words; if there was none, or it was not yours, say so plainly and stay with the unpaid invoices you chased |

Your background line, for reference: "two years as a receptionist at a physiotherapy clinic" (your message).

## Persona table

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of the gaps: travel, Excel, the invoice side | Highest. The relationship prior for a manager-type interviewer is Case plus Skeptic, and F2 to F5 are the thin rows | Rehearse the invoice objection (A2) until it is boring: say what the quote says, name the limit before they do, give a learning plan |
| B. Case/Strategist | Small live problems from the duties: a clash, a trip, a mismatched invoice | High. Same prior; the ad lists four concrete duties, each easy to turn into a problem | Clarify, then structure, then answer, thinking aloud. These cases ask for no claim about your past |
| C. Conversational | Friendly opener, "tell me about yourself", casual tool talk | Medium. A 30-minute video call opens with it; casual questions are still scored | A 90-second arc built only from your quoted sentences; treat casual tool questions as scored |
| D. Data-Driven Prober | Goes line by line through the clinic experience | Medium-low. The only figure in your material is "four physios" | Know what you can say about that figure, and say plainly what you do not know |
| E. Pressure | Time-boxed "why you?" challenges | Low. Nothing in the material points to a stress interviewer | Pause, restate, hold the position through two follow-ups, concede only what is true |

The loop rests on your own words from the invite: one 30-minute video call. Nothing documents how the employer interviews beyond that, so these weights come from relationship priors and the ad's duties.

## Question banks

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would be newest to you on day one?" | JD | [grounded] "ran the appointment book for four physios" "chased unpaid invoices" "I'm good with Word" "okay with Excel" | Name the duty your material carries least before they do. The ad lists calendars, travel, Word and Excel documents, and invoices. Your quoted sentences cover the appointment book, unpaid invoices, Word and Excel; the pack's observation is that they say nothing on booking travel. Answer slot: if you have arranged travel, say what and how; if not, say so plainly, then give a ramp plan for the first weeks in your own words. Do not pad the answer with a duty you cannot back | F2 is the thinnest row and the likeliest first probe; JD because it scores the ad's own duty list, Skeptic because it asks for self-assessment |
| A2 | "At the clinic you chased unpaid invoices. Here you would be processing supplier invoices. How does one carry over to the other?" | JD | [grounded] "chased unpaid invoices" | **The highest-ROI rehearsal in this pack.** Hold only what the quote carries: "I chased unpaid invoices." Say it first, in one sentence. The pack's observation, not words for you: your material says chasing unpaid invoices, not processing supplier invoices. Answer slot: if any invoice work at the clinic involved invoices coming in, being checked or being paid, say what and what part was yours; if there was none, or it was not yours, say so plainly and stay with the unpaid invoices you chased. Hold through two follow-ups by returning to what you did, never by adding to it, and say how you would learn the supplier side | F5 is where the ad's invoice duty presses hardest, so this objection arrives in some form; JD because it scores a stated duty, with the deepest follow-up rehearsal because it aims at where the material is thinnest |
| A3 | "How would you rate yourself in Excel?" | JD | [grounded] "okay with Excel" | Rate it at the level you stated, "okay with Excel", and do not upgrade the word in the room. Answer slot: expect "what have you used it for?"; say what you used it for, in your own words; if little, say so plainly and say what you would practise first. If pushed on "okay", hold the word and let your example carry it | F4 is low confidence and the ad names Excel; JD because it scores a listed tool |
| A4 | "What is drawing you from a physiotherapy clinic to a remote administrative role?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Start from the fact: "two years as a receptionist at a physiotherapy clinic". Then give your own reason for the move in one or two sentences; the pack does not supply it. Answer slot: give your actual reason, and if part of it is practical, such as the remote format, say so plainly rather than dressing it up | Motivation consistency is the Skeptic's core test; EXP because it asks you to account for your own path |
| A5 | "Tell me about a time you arranged travel for someone." | JD | [grounded] "ran the appointment book for four physios" | No quoted sentence carries this, so this is a selection scaffold: pick any time you arranged travel, for yourself, family or work; it needs a named trip, what you had to weigh, and how it turned out. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the appointment book for four physios", or how you would handle it | F2 is the only duty with no quote behind it; JD because the ad's "booking travel" line raises it, and an open prompt so it presupposes nothing |

### B. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two people you support both need the same hour tomorrow, and neither knows the other asked. What do you do?" | CASE | [generic] | Structure it aloud: ask who has priority and whether either can move; check what is fixed; offer options to both; confirm in writing; record the outcome. The question needs no claim about your past, so the guidance makes none | The ad's calendar duty as a live problem; generic because it is a pattern, not a fact about this employer |
| B2 | "Your manager asks you to book a trip for Thursday and the only sensible flight is well over the budget. Walk me through it." | CASE | [generic] | Clarify first: who approves, how fixed the dates are, what flexibility there is. Then options with costs, ask for the decision, book, send the itinerary, record it. No claim about your past | The ad's travel duty as a live problem, which suits F2 because a case needs no travel history |
| B3 | "A supplier invoice arrives and the amount does not match the order. What do you do?" | CASE | [generic] | Do not pay yet; check the order and delivery against the invoice; query it with the supplier; tell whoever approves payment; keep a record of what was agreed. Say how you would find out the company's own approval rule. No claim about your past | The ad's invoice duty as a live problem; it lets you show care on the supplier side without claiming experience (F5) |
| B4 | "Your manager sends rough notes and asks for a one-page summary by end of day. What do you ask first?" | CASE | [generic] | Ask who it is for, what decision it supports, what must be in it, and the deadline. Then draft, check, and send with a line on anything unconfirmed. No claim about your past | The ad's document duty as a live problem |
| B5 | "It is three in the afternoon: a travel change, an invoice due today and a calendar request all arrive. In what order do you take them?" | CASE | [generic] | Say your sorting rule aloud before the order: what has a hard deadline, what blocks someone else, what can wait. Then say what you would tell the people waiting. No claim about your past | Tests structure across all four listed duties at once |

### C. Conversational (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" "I ran the appointment book for four physios" "chased unpaid invoices" | A 90-second arc in three beats, each from a quote: "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios"; "chased unpaid invoices". Then one sentence in your own words on why this role. Add no detail the quotes do not carry | The biographical opener is scored even though it feels casual; EXP because it tests whether the story matches the material |
| C2 | "How are you with Word and Excel, day to day?" | JD | [grounded] "I'm good with Word" "okay with Excel" | Keep the two levels as stated: "I'm good with Word", "okay with Excel". Answer slot: say what you have prepared in Word and used Excel for, in your own words; if little, say so plainly and say what you would build first | The ad names both tools; casual phrasing, same scoring as A3 |
| C3 | "What would make working remotely work well for you?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic" | The invite titles the role "Remote Administrative Assistant", so expect this. Describe your own setup and how you would stay in touch with the team, in your own words; the pack supplies none. Answer slot: if you have worked remotely, say how it went; if not, say so plainly and say what you would put in place | The role title is the raising source; the quote is only the starting fact for someone coming from a clinic front desk |
| C4 | "What do you know about us, and why us?" | CO | [generic] | Say only what you have confirmed yourself from the company's own website, and name it. If you find little, say so plainly and say what in the ad drew you. Never repeat claims you could not check | No company research was available (see Sources), so this is generic; CO because it tests homework |

### D. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You ran the appointment book for four physios. How did that work day to day?" | EXP | [grounded] "I ran the appointment book for four physios" | "Four physios" is the one figure you have, so rehearse its four slots in your own words: how it was counted, what it depends on, the assumption about it you would defend least, and which part was yours. If you do not know how something was counted, say so plainly. Say "I ran the appointment book for four physios" and no more than that | F1's quote is the only quantified claim, and probers go to numbers; EXP because it tests attribution |
| D2 | "Walk me through how you chased unpaid invoices." | EXP | [grounded] "chased unpaid invoices" | Say "I chased unpaid invoices" first. Answer slot: if you kept a list or record, say what and how; if there was none, or it was not yours, say so plainly and describe how you chased them, in your own words | F5 again, collegially packaged; EXP because it tests what you actually did |
| D3 | "If I gave you a list of supplier invoices in Excel, how would you get totals by supplier?" | JD | [generic] | Say what you would do at the level you can honestly claim. If a function or feature is unfamiliar, say so plainly and say how you would find it. Ask what the columns hold before you start. No claim about your past | Probes F4 without asking you to claim anything; JD because it scores a listed tool |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone with an office-administration background?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" "I ran the appointment book for four physios" "chased unpaid invoices" | Pause, restate the question, then hold on the three quoted facts at their own scope. Hold through two follow-ups. Concede only what is true and specific: the tools you rated "I'm good with Word" and "okay with Excel", and that the supplier side is still to learn. Never fold on what you did | The standard pressure framing for a candidate switching sectors; EXP because it tests what you will stand behind |
| E2 | "That appointment book: how much of it was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold on the quote: "I ran the appointment book for four physios." Answer slot: if any part was handled by someone else or shared, say which and keep your part precise; if you do not know where the line sat, say so plainly. Never claim more than the sentence | The attribution probe is the classic pressure test; EXP because it checks ownership honesty |

## Requirement coverage

| Requirement (source) | Questions |
|---|---|
| "managing calendars" (the ad, as you described it) | B1, B5, C1, D1, E2 |
| "booking travel" (the ad, as you described it) | A1, A5, B2 |
| "preparing documents in Word and Excel" (the ad, as you described it) | A3, B4, C2, D3 |
| "processing supplier invoices" (the ad, as you described it) | A2, B3, D2 |
| "Remote Administrative Assistant" (the invite's role title) | C3 |

## Reverse questions

1. "What does a good first month look like in this role?" Why it lands: it shows you are thinking about doing the job well, not just getting it.
2. "Which of the four duties would take most of my week?" Why it lands: it shows you care about priorities, and it tells you where to prepare.
3. "How does the team work together day to day when everyone is remote?" Why it lands: it shows you take the remote format seriously.
4. "Who would I report to, and who approves invoices and travel?" Why it lands: it shows you want to know how decisions get made, and it also tells you who the employer is in practice.
5. "Could you tell me where the company is registered, and which official contact details I can use to confirm this interview?" Why it lands: a genuine employer can answer this easily; the answer is also a check you can make independently of the invite.
6. "What systems do you use for calendars, travel and invoices?" Why it lands: it signals you are ready to learn their tools, and it exposes whether they have real ones.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed executive or business calendars | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation, not words for you: the material says the appointment book, not other people's calendars |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "I chased unpaid invoices." The limit is the pack's observation: the material says chasing unpaid invoices, not supplier invoices |
| Advanced skills in Excel | Inflated form of F4 | F4's quote at its own scope: "okay with Excel". The limit is the pack's observation: the material states a modest level |
| Expert in Word | Inflated form of F3 | F3's quote at its own scope: "I'm good with Word". The limit is the pack's observation: the material is a self-rating with nothing inspected behind it |

## Sources

- Provided documents: your message, containing the invite text, your description of the ad, and your background.
- Searches sent (all refused by the host, none returned anything):
  - `Brennock Facilities Ltd values`: refused
  - `Brennock Facilities Ltd interview process remote administrative assistant`: refused
  - `Brennock Facilities Ltd strategy news`: refused
- Fetches: none.
- No dossier was provided.

Research tier: L1, searches 3 of 6 sent and all refused, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Would have fed a values cheat sheet; none is built because no values source was in hand |
| 2. Interview process | unavailable | Would have named the loop's rounds; the persona weights rest on your own words and relationship priors instead |
| 3. Strategy and recent news | unavailable | Would have fed the company-knowledge question; C4 is generic |
| 4. Interviewer name | n/a | The invite names a role, "our office manager", and no name, so there was no query to form |
| 5. Representative JD | skipped | The ad's duties as you described them fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full text of the ad → the five requirement quotes become the ad's exact words
- Whether the office manager would be your day-to-day manager → persona weights reordered, and reverse questions retuned
- Anything the employer's own website says about its values and how it interviews, found through contact details on that website → a values section and a grounded company-knowledge answer in place of C4
- The office manager's name → an interviewer read and a reverse question tied to their path
- Your own answers to the slots on travel, Excel, Word and supplier invoices → rows F2 to F5 upgrade from discovery to quoted evidence
- A Word document or Excel sheet you have produced, with anything private removed → F3 and F4 can move above low confidence
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, if search is permitted → a company brief and loop reports
- A `tuesday-dossier.md` → verified evidence and a named list of prohibited claims for later sessions
