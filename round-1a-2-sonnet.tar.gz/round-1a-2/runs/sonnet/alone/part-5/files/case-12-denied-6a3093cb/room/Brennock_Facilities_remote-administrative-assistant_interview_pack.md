# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager (name not given). Format: a 30-minute video call. Built on the assumption that the office manager is the person you would work for or alongside; if that is wrong, the persona weights below shift.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment against the company's published values (not used here: no published values were in hand) |
| EXP | Work-experience deep-dive: whether your account survives follow-ups, and what was actually you |
| JD | Role-driven: can you do the listed duties, gaps included |
| CO | Company and strategy knowledge (not used here: no company research could run) |
| CASE | A live problem set in the role, answered aloud |

An answer slot is an instruction for the interview, not a question for you now. Where it offers two branches, either is a good answer if it is true.

## Fit snapshot

Requirements are quoted from the ad as you described it in your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms, but it is a self-reported line with nothing inspected behind it, so expect a probe. Words: "I ran the appointment book for four physios." The material says an appointment book, not other people's calendars, so let the interviewer draw the link rather than asserting it for them |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: the ad names travel booking, so expect a probe on it. If you have booked travel for anyone, say what and for whom, in your own words; if you have not, or it was not yours, say so plainly and describe, as a plan and never as a past, how you would go about it |
| F3 | "preparing documents in Word and Excel" — the ad, as you described it | "I'm good with Word" — your message | medium | [grounded] | discovery | The quote names the tool, and the material does not show whether it reaches the preparing of documents. Words stay at "I'm good with Word." Answer slot: if you have prepared documents in Word, say which kinds and who used them; if none, or it was not yours, say so plainly and stay with that sentence |
| F4 | "preparing documents in Word and Excel" — the ad, as you described it | "okay with Excel" — your message | low | [grounded] | discovery | The quote is a hedge and the pack keeps it: "I'm okay with Excel." Answer slot: if you have built or edited a spreadsheet, say what it was for and what you did in it; if not, or it was not yours, say so plainly and say what you would practise first, as a plan |
| F5 | "processing supplier invoices" — the ad, as you described it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing, not processing, and the words stay there: "I chased unpaid invoices." Answer slot: if chasing involved other steps with those invoices, such as recording or checking them, say which and what part was yours; if there were none, or they were not yours, say so plainly and stay with the chasing |

## Persona table

The loop is established by the invite's own words: one 30-minute video call with the office manager. No archetype fallback is used.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | Small live problems from the ad: a calendar clash, a trip to book, a messy invoice list | High. The relationship prior for a manager is Case plus Skeptic, and every duty in the ad is easy to turn into a scenario in 30 minutes | Clarify first, then structure, then answer; think aloud; say which part you would need to look up |
| Skeptic (B) | Quiet probing of the thin rows: travel, Excel, supplier invoices | High. F2, F4 and F5 are where the material is thinnest, and the same prior applies | Rehearse the supplier-invoice objection until it is boring (B1); keep each answer at the scope of your own words |
| Conversational (C) | Friendly opener, "walk me through your background" | Medium. A first video call from a manager usually opens this way, and casual questions are still scored | A 90-second arc made only of clauses you actually wrote (C1) |
| Data-Driven Prober (D) | Asks how things were done and checked | Medium. Invoices and spreadsheets invite "how did you check that" follow-ups | Say plainly what you do not know; never explain a method you did not use |
| Peer Evaluator (E) | "What would you need from me" | Low to medium. It depends on whether the office manager works alongside you, which the invite does not say | Offer what you would bring and propose working principles, not a claimed seam |
| Pressure (F) | "Sixty seconds, why you" | Low. Nothing in the invite signals a stress style, and the call is short | Hold the position your words carry through two follow-ups, then concede specifically |
| Values / Behavioral | Not banked | No published values were in hand and the invite names no values round, so none is detected | Open prompts that come up (D1, E1, C3) have selection scaffolds |

## Question banks

Highest-ROI prep: B1. The ad names supplier invoices and your material says chasing unpaid invoices, so this probe is the most likely to arrive and the one where a rehearsed, non-defensive answer changes the interview most.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two managers want the same one-hour slot tomorrow, one internal and one external. What do you do?" | CASE | [generic] | Clarify before acting: who decides priority, whether either meeting can move, how much notice each person has. Then propose one option, say what you would send each person, and say how you would record the outcome. The question needs no claim about your past, so the guidance makes none | A live problem from the calendar duty in F1's requirement; CASE because it scores structure, not history |
| A2 | "A manager needs to be in Cork for a 10am meeting on Thursday. What do you ask first, and what do you send back?" | CASE | [generic] | Ask what the trip is constrained by: budget, preferences, who approves, whether a return is needed the same day. Send back two options with the trade-off stated, flag anything tight, and say you would confirm before booking. No claim about your past | F2's requirement, where the material has no evidence; a live problem lets you show reasoning without claiming experience |
| A3 | "Here is a spreadsheet of forty supplier invoices and some may be duplicates. How would you check?" | CASE | [generic] | Clarify what counts as a duplicate, say what you would compare, and say that you would flag rather than delete. Name the tools you would use and say plainly which part you would need to look up. No claim about your past | F4 and F5 requirements in one live problem; the honest "I would look that up" is part of the answer |
| A4 | "A supplier says an invoice is sixty days overdue and nobody here has seen it. What happens next?" | CASE | [generic] | Establish whether it arrived and where, who needs to approve it, and what you would tell the supplier and when. Say how you would record it so it is not lost again. No claim about your past | F5's requirement set as a scenario; the order of steps is what is scored |
| A5 | "You are given rough notes and asked for a two-page briefing document by end of day. What do you ask, and how do you check it before it goes out?" | CASE | [generic] | Ask who it is for, what decision it supports and what format they expect. Say how you would proofread and who you would let see it first. No claim about your past | F3's requirement as a live problem; checking before sending is the beat interviewers listen for |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The job includes processing supplier invoices. What experience do you have with that?" | JD | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I chased unpaid invoices." Answer slot: if chasing involved other steps, such as recording or checking invoices, say which and what part was yours, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the chasing. Follow-up ladder, each answered by returning to your own account: first "What did chasing an unpaid invoice involve, step by step", then "Which of those steps would carry over to invoices coming in from suppliers", then "What would you want to know in your first week". For the second, name only the steps your own account carries, and concede the rest specifically, in your own words. For the third, give a plan and say it as a plan | F5 is the thinnest row against a duty the ad names, so this probe is the likeliest to land. JD content, with EXP follow-ups |
| B2 | "How comfortable are you with Excel, honestly?" | JD | [grounded] "okay with Excel" | Keep your own word at its own scope: "I'm okay with Excel." Answer slot: if you have built or edited a spreadsheet, say what it was for and what you did in it; if not, or it was not yours, say so plainly. Then say, as a plan, what you would practise first. Do not upgrade the word | F4 is a hedge in your own words, and the ad names Excel, so the interviewer will test it. JD because it scores the stated tool requirement |
| B3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "okay with Excel", "chased unpaid invoices" | Choose the one that is true for you. Your own sentences give two candidates: Excel, which you called "okay", and invoices, where you wrote "chased unpaid invoices". Say it at that scope, then give a ramp plan said as a plan. If travel booking is where you are thinnest, say so instead, because the answer must be yours | The Skeptic stem, aimed at F2, F4 and F5; calibrated candor scores better than bluffing |
| B4 | "You have been a receptionist. Why move into an admin assistant role, and why remote?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Answer slot: give your actual reasons, in your own words, for the move and for remote work; the pack supplies none, and a reason you do not hold will not survive a follow-up. Keep any claim about the receptionist job to the sentence you wrote | Motivation consistency is what a skeptical interviewer checks; EXP because it tests whether your story holds together |
| B5 | "This job is remote and you would mostly be working alone. How would you stay organised and keep me informed?" | JD | [grounded] | Answer as a plan: a daily priorities list, a check-in rhythm you propose and then ask the manager to adjust, and flagging problems early. Say these as what you would do. No claim about your past | The invite's title names the job as remote. JD because it scores a stated working arrangement |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices; I'm good with Word, okay with Excel" | A 90-second arc using only the clauses of that sentence: the two years as a receptionist at a physiotherapy clinic, the appointment book for four physios, chasing unpaid invoices, then Word and Excel at the levels you gave. Close with why this role, using your own reason from B4 | Casual openers are still scored; F1 to F5 all sit in this one sentence |
| C2 | "Tell me about running the appointment book for four physios. How did it work day to day?" | EXP | [grounded] "I ran the appointment book for four physios" | The beats are the clauses the quote states: the book, the four physios, you running it; tell them in your own words. Answer slot: the ad's calendar duty makes a probe on clashes or changes likely. If appointments clashed or changed and you dealt with it, say what happened and what part was yours; if that did not come up, or it was not yours, say so plainly and stay with the book you ran | F1 is your strongest row against the first duty in the ad, so it will be opened up. EXP because it tests what was actually yours |
| C3 | "Tell me about a time you prepared a document that someone else relied on." | EXP | [generic] | Selection scaffold: pick an occasion with a named reader, something you produced, and what you did to check it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The ad names document preparation (F3 and F4); an open prompt lets you choose the instance |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time a booking went wrong and how you fixed it." | EXP | [generic] | Selection scaffold: pick a time with a specific error, something you did that was yours, and what changed afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The calendar duty (F1's requirement); a prober tests the part nobody puts on a list |
| D2 | "Walk me through what chasing an unpaid invoice involved." | EXP | [grounded] "chased unpaid invoices" | Tell it in your own words, staying with the clause you wrote: you chased unpaid invoices. Answer slot: expect "how did you know it was unpaid, and who did you tell". If you recorded or tracked them yourself, say how; if you did not, or it was not your process, say so plainly and describe what you did do | F5 again, from the prober's angle; EXP because it asks for the denominator behind the sentence |
| D3 | "If I gave you a spreadsheet of supplier invoices and asked what we owe by supplier, how would you do it?" | CASE | [generic] | Clarify the data, say what you would check before totalling, and say how you would check the total against its source. Name the tools you would use and say plainly which part you would look up. No claim about your past | F4 and F5 requirements; "okay with Excel" is honest when the guidance says where you would look something up |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time two people you supported wanted different things from you at once." | EXP | [grounded] "I ran the appointment book for four physios" | Selection scaffold: pick an occasion with two named wants, a choice you made, and how the relationship stood afterwards. If your appointment book for four physios produced one, tell it; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The peer stem, themed on the calendar duty in F1 |
| E2 | "What would you need from me to do this job well?" | JD | [generic] | Reciprocity framing: propose working principles, not demands. How requests should reach you, how priorities are set, what you may approve alone for travel and invoices, and how often you check in. Then say what you would do to make the manager's week lighter, as plans | A peer-style question; the reciprocity move is what is scored |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has done this job before?" | EXP | [grounded] "I ran the appointment book for four physios", "chased unpaid invoices", "I'm good with Word" | Pause and restate the question. Hold the sentences you wrote, at their own scope. Concede the parts your own words do not carry, specifically and in your own words, rather than covering them. Then say, as a plan, how you would close them | The Pressure stem; the position held is only what the quotes carry |
| F2 | "You say you ran the appointment book for four physios. How much of that was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold "I ran the appointment book for four physios" through two follow-ups by returning to it. Answer slot: if any part of the book was set by someone else, or shared, say which part, plainly; if all of it was yours, say that and stop | The attribution probe, aimed at F1; hold-then-concede is what is scored |

## Requirement coverage

| Requirement | Questions |
|---|---|
| managing calendars | A1, C2, D1, E1, F2 |
| booking travel | A2, B3 |
| preparing documents in Word and Excel | A3, A5, B2, C3, D3 |
| processing supplier invoices | A3, A4, B1, D2, D3 |
| remote working (from the invite's title) | B4, B5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who would I be supporting day to day, and how do they like to work?" | Shows you are already thinking about the person, not just the tasks |
| R2 | "What does a good first month look like in this role?" | Turns the call toward what success is, and gives you the interviewer's own bar |
| R3 | "How do supplier invoices reach this role, and who approves them?" | Shows you think about the process end to end, and the answer tells you what the invoice duty really involves |
| R4 | "How does the company supply equipment for remote staff, and who would I speak to about it?" | A practical onboarding question that sounds natural; the interviewer's own account of the process is something you can check against the invite |
| R5 | "What could a new person do in their first month that would genuinely help you?" | The reciprocity question for a peer-style interviewer; it signals partnership |
| R6 | "What would you want me to ask you now that I have not?" | Leaves room for what the interviewer cares about that the ad did not say |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed or ran other people's calendars | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation: the material says an appointment book, not other people's calendars |
| Processed or handled supplier invoices | Inflated form of F5 | F5's quote at its own scope: "chased unpaid invoices." The material says chasing, not processing; B1's and D2's slots stay inside the chasing |
| Advanced or confident Excel skills | Inflated form of F4 | F4's quote at its own scope: "okay with Excel" |
| Prepared documents in Word for others | Inflated form of F3 | F3's quote at its own scope: "I'm good with Word." The material names the tool, not the documents |

## Sources

Provided documents: the invite email, the ad as you described it, and your background, all in your message. No dossier was present.

Searches sent, all refused by the host before returning anything:

- `Brennock Facilities Ltd values`: refused
- `Brennock Facilities Ltd interview process Remote Administrative Assistant`: refused
- `Brennock Facilities Ltd Ireland company news`: refused

Research tier: L1 — searches 3 of 6 sent (all refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Would have fed a values sheet only if a values round were detected; none is, so nothing in the pack changes |
| 2. `{company} interview process {role family}` | unavailable | Would have documented the loop; the invite's own words (one 30-minute video call with the office manager) establish it |
| 3. `{company} strategy` / recent news | unavailable | Would have fed CO questions; the pack has no CO bank and says so in the type key |
| 4. `{interviewer name} {company}` | n/a | No name was given, only "office manager" |
| 5. representative `{role title}` JD | skipped | The duties you described fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full text of the ad → F1 to F5's requirement cells quote the ad itself rather than your description, and any duty your summary left out gets a row and a question
- Your CV, or a few lines on each duty in your own words → F2 to F5 can quote what you actually did; the artifacts that would raise confidence for admin work are a booking confirmation you arranged, a document you wrote, or a spreadsheet you built, each with names removed
- The office manager's name and role → an interviewer read, persona weights adjusted to the relationship, and a reverse question tied to their path
- Any email from the employer on format or focus areas → coverage assumptions replaced by what they said
- The employer's published values or careers page, found through its own website → a values sheet if the loop names a values round
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, once search is allowed in this session → the strategy and recent-context rows this pack could not run
- A `tuesday-dossier.md` from an earlier evidence check → banks drawn on verified evidence and bound by its prohibited claims
