# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

Candidate: Sam. Round: recruiter screen, a 30-minute phone call, Thursday at 2pm. Interviewer: Hannah Lowther, Talent Partner (recruiter). Built from the advert, Hannah's LinkedIn message and Sam's own notes. No CV text was supplied, so every evidence quote is a sentence from Sam's message.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scored on. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether the claims about your work survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you did your homework on the company |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` traces to a document you or the recruiter supplied, `[inferred]` is derived from an adjacent source with the derivation named, `[generic]` is a role-family pattern with no claim about Quillmoor or about you.

The pack's highest-ROI prep is B1, the production-scheduling question. Rehearse it first.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says delivery scheduling for three depots, not production scheduling, and says nothing about planning or QA. The words stay at "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on whom you coordinate with likely. If any of your scheduling involved teams like those, say which and how it worked, in your own words; if none did, or it was not yours, say so plainly and stay with the three depots |
| F2 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | The sentence touches deliveries and suppliers without showing whether following supplier deliveries was part of it. Answer slot: if you followed supplier deliveries as part of your scheduling, say how you kept track, in your own words; if you did not, or it was not yours, say so plainly and stay with the sentence |
| F3 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap on the chasing half, but a message sentence with nothing inspected behind it, so expect a probe on how. Lead with it in the sentence's own terms: you chase suppliers when orders slip, because a named action beats an adjective |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | The sentence already reaches the requirement in role-relevant terms. It carries a figure, so expect the defend-the-number probe in C1. Say it as you said it, keeping the verb and the order: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material is silent on reporting. Answer slot: if you produce any regular report, say what it covers and how often, in your own words; if you do not, or it was not yours, say so plainly and say what you would put in a weekly on-time dispatch report |
| F6 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | The sentence carries the years and the role in the requirement's own terms; say it as it stands. Experience length is not a gate. Nothing is inspected behind it yet, so expect it to be taken at your word |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The sentence says spreadsheet, not which program. Answer slot: say which program it was built in, in your own words; if it was not Excel, say so plainly and say what it was. Then say what you rebuilt in it, and if part of it was not yours, say that |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | medium | [grounded] | transferability | Words you can say: "I've never used SAP." Beyond that your material says an in-house stock system and nothing about what it covered, and the pack does not call it an ERP. Answer slot: say what you used the in-house system for, in your own words; if you used it for little, or it was not yours to use, say so plainly |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your figure sits inside the advertised band, so there is no gap. Say it as you said it, "I'm hoping for £42,000", at that strength. The pack coaches neither a floor nor a concession you did not state |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol." — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | The stated two days are met. Keep the ceiling at the strength you gave it: "I wouldn't want more than three" is a preference, and the pack does not turn it into a limit or a flexibility |
| F11 | "what's prompting a move" — recruiter's message | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | Say it in the sentence's own terms: the office is closing next year, the only offer is relocation to Reading, and you don't want that. The pack adds nothing about how it was decided or announced |

## Reading the interviewer

Public footprint was not researched (see Sources), so this section holds only what Hannah's own message sets up.

| What her message says | What it means for the call |
|---|---|
| "a 30-minute phone call with me. I'll ring the mobile number on your application." | Check that the number on your application is the one you will answer at 2pm Thursday |
| "I'd like to cover your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move" | Her agenda is four items in that order, so pay arrives first: rehearse A2 to A5 until they are boring |
| "and then I'll tell you about the team and the next steps" | The team and next steps come last, so hold your own questions (Reverse questions below) for that slot |
| "If anything changes, message me here." | A change goes to her by LinkedIn message, not by phone |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport builder (A) | Friendly, unstructured: logistics and motivation asked casually | High. Relationship prior for a recruiter screen, and her message names pay, notice, hybrid and reason for the move as her own agenda | Rehearse the 90-second arc (A1) and a plain one-line answer for each logistics item (A2 to A5); treat casual questions as scored |
| Skeptic (B) | Quiet probing of the gaps: what the role asks that your material does not carry, and why this move | Medium. The prior calls for a light Skeptic, adjusted up because F1 and F8 are the snapshot's biggest gaps and her agenda includes what is prompting the move | Rehearse B1 until it is boring; build every bridge only from the sentences quoted in the snapshot, and say the limit plainly where one exists |
| Data-driven prober (C) | Takes a figure or a requirement line and asks how it was counted or done | Low to medium. Her stated agenda has no experience deep-dive, but a quantified claim is the likeliest thing to be probed if she goes into experience | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| Case / strategist (D) | A short live problem from the role, such as a late supplier or a stock mismatch | Low. Her agenda lists none and she says she will describe the team herself; the advert's lines make these likelier in a later round | Clarify first, structure second, think aloud; no past claim is needed |
| Pressure (E) | Time-boxed or devil's-advocate challenges to motive or attribution | Low. Nothing in her message signals it; included so the style is not new live | Pause, restate the question, hold the quoted position through two follow-ups, concede specifically |
| Peer evaluator (F) | Seam and credit questions between adjacent teams | Low in this call. No peer is named and her message gives no sign of one; the role sits between planning, the warehouse and QA, so a later round may use it | Offer seam principles rather than pretending to know the seam |

Depth follows weight: A has five questions, B four, C and D three each, E and F two each.

## Question banks

Requirement coverage, JD line by JD line:

| Requirement | Questions |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B1, B3, D1, F1 |
| track supplier deliveries | C3, D1 |
| chase late orders | C3, D1 |
| keep stock records accurate | C1, D3, E2 |
| report weekly on on-time dispatch | D2 |
| 2+ years in operations or logistics coordination | A1 |
| confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B2, E1 |
| £38,000–£44,000 | A2 |
| Hybrid: two days a week at our Avonmouth site | A4 |
| Recruiter agenda: notice period | A3 |
| Recruiter agenda: what is prompting a move | A5 |

### A. Conversational (weight 1 of 6)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey: where have you been, and where are you now?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Story-mapped, about 90 seconds, with only the beats the quotes state: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling by about a third over a year. Tell them in your own words, in that order, and add nothing between them. Hand over to A5 for why you are looking | F6 is the years and role, F1 and F3 the daily work, F4 the headline figure. EXP because it tests what you actually did, asked in a rapport register |
| A2 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot, filled with your own words: "I'm hoping for £42,000." Say it at that strength, then stop and let her respond. Add no other figure | F9 is the stated figure, and pay is the first item on her agenda. JD because it concerns the listed job's terms |
| A3 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period as it stands, and if it is not fixed or you are not sure, say so plainly. The pack supplies no figure | Her second agenda item, with no fit-snapshot row because the advert states no start date. JD because it concerns the listed job's terms |
| A4 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot, filled with your own words: you live in north Bristol, two days at Avonmouth is fine, and you wouldn't want more than three. Keep the three at the strength you gave it. If she asks how firm the three is, answer from your own position; the pack supplies none | F10 is the stated pattern, her third agenda item. JD because it concerns the listed job's terms |
| A5 | "What's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say it in the sentence's terms: the office is closing next year, the only offer is relocating to Reading, and you don't want that. Then name what in the advert you want to do; if the honest answer is mostly the closure, say so plainly and say what in the work appeals | F11 is the reason, and motivation consistency is what this question scores. EXP because it asks for your own circumstances |

### B. Skeptic (weight 2 of 6)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role coordinates production schedules between planning, the warehouse and QA. What have you coordinated that's like that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal in this pack. Say the scope first, before she presses: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on whom you coordinate with likely. If any of your scheduling involved teams like those, say which and how it worked, in your own words; if none did, or it was not yours, say so plainly and stay with the three depots. Follow-up 1: she asks how that compares with what the role does; answer from the branch you took, never wider than the sentence. Follow-up 2: she asks what you would need to learn; say what you would ask first and whom, as a plan and not as a past. Follow-up 3: she tests the hold; return to the sentence, never add to it. The limit is named before she asks for it, and the honest branch is a limit, not a confession | F1 is the snapshot's biggest gap and the advert's headline duty, so this objection arrives in some form. JD because it scores the stated responsibility |
| B2 | "The advert says ERP experience, SAP or similar, is a plus. What have you used?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Start with the plain acknowledgment: "I've never used SAP." Then the sentence as said: you run your own in-house stock system. Answer slot: say what you used it for, in your own words; if you used it for little, or it was not yours to use, say so plainly. Do not compare it to SAP; let her draw any comparison. Then say how you would learn a new system, as a plan | F8 is a stated negative plus adjacent work at its own scope. JD because the line is a stated plus in the advert |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [inferred] | Selection scaffold, derived from the snapshot rows F1, F5, F7 and F8, where your sentences stop short of the advert's line. Pick one, name it before she does, and say how you would close it, as a plan. If no honest pick comes to mind, say so plainly and name the part you would want most support learning | The stem is the Skeptic's standard probe, and the snapshot shows where it will land. JD because it scores the stated requirements; the guidance makes no claim about your past |
| B4 | "What do you know about Quillmoor, and why this role?" | CO | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Company research could not run, so the only company facts in this pack are the advert's: a diagnostic-test manufacturer with about 400 staff, with a role between planning, the warehouse and QA. Say what draws you to those, in your own words. For the role, the advert's line is "track supplier deliveries and chase late orders"; your sentence says you chase suppliers when orders slip, and you can say both as they are. Answer slot: say what else you looked at; if you looked only at the advert, say so plainly and say what in it interests you | F3 is the nearest sentence to the advert's chasing line. CO because it tests homework depth; the strategy-grounded CO rule does not bind, since research was refused |

### C. Data-driven prober (weight 3 of 6)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third over a year. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say the sentence as it stands: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. Four slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how it was counted, say so plainly. Keep the sentence's verbs and order | F4 holds the headline figure, and quantified claims are where probes land. EXP because it tests whether the claim survives |
| C2 | "How confident are you in Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say what you rebuilt: "I rebuilt our stock-count spreadsheet." Answer slot: say which program it was built in, in your own words; if it was not Excel, say so plainly and say what it was. If part of the rebuild was not yours, say so | F7 is a discovery row: the sentence says spreadsheet, not Excel. JD because Excel is a stated requirement |
| C3 | "Walk me through how you chase a supplier when an order slips." | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The beats the sentence states: you chase suppliers, when an order slips. Answer slot: the advert's track-and-chase line makes a probe on how you spot a slipping order and what you do next likely. If you have a routine, say what it is, in your own words; if you do not, or it was not yours, say so plainly and stay with the sentence | F3 carries the chasing and F2 the tracking, which is a discovery row. JD because it scores the advert's line; EXP delivery, since it asks for your own routine |

### D. Case / strategist (weight 4 of 6)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "It's 4pm. A supplier tells you a delivery QA needs tomorrow will be two days late, and planning and the warehouse are both waiting on it. What do you do first?" | CASE | [generic] | Structure it aloud. Ask what the delivery holds and who is waiting on it; ask what can move: a partial delivery, another source, a different schedule slot. Say who needs to hear today, what you would record, and when you would chase again. The question needs no claim about your past, so the guidance makes none | A live problem built from the advert's supplier-chasing and three-team coordination lines (F1 to F3). `[generic]` because it is a pattern for the problem, not a fact about Quillmoor |
| D2 | "We report weekly on on-time dispatch. How would you set that report up?" | JD | [generic] | Structure it aloud: agree what counts as on time; where the dispatch dates come from; the weekly cut-off; a short list of late items with reasons; who reads it. Answer slot: if you produce any regular report today, say what it covers, in your own words; if you do not, say so plainly | F5 is a discovery row, so this is the line most likely to be unrehearsed. JD content, CASE delivery |
| D3 | "The system says 50 of an item are in stock, and the shelf count is 45. What do you do?" | CASE | [generic] | Structure it aloud: recount first; check recent movements; look for where the five went; record the adjustment and its likely cause; say who needs to know if it affects a schedule. No claim about your past is needed | F4's requirement, asked as a decision rather than a record. `[generic]` because it is a pattern for the problem |

### E. Pressure (weight 5 of 6)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, when other applicants have used SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Pause and restate the question. Hold only what the quotes carry: you schedule deliveries for three depots and chase suppliers when orders slip. Concede specifically with the plain acknowledgment: "I've never used SAP." Hold through two follow-ups by returning to those sentences, never by adding to them | F8 is the gap this challenge presses on, and F3 supplies what you hold. JD because it scores the advert's plus; the pressure delivery is the point |
| E2 | "That result — how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Pause. The position held is the sentence: "I rebuilt our stock-count spreadsheet." Concede specifically what you know and do not: answer slot, if anything else changed over that year that could have moved the figure, say what, in your own words; if nothing did, say so plainly; if you do not know, say that. Do not say the rebuild alone caused the fall unless you can back it | F4 is the figure, and attribution is what the stem scores. EXP because it tests what was actually yours |

### F. Peer evaluator (weight 6 of 6)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Planning and the warehouse disagree about a schedule and you sit between them. Where's the seam, and what do you do?" | CASE | [generic] | Offer seam principles rather than claiming to know the seam: each side states what it needs and by when; the trade-off is made visible; the decision is recorded. No claim about your past is needed | The advert's three-team coordination line (F1) asked as a collegial scenario. `[generic]` because it is a pattern for the problem; likelier in a later round |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work crossed teams. It needs your own part named, the others' parts named, and what you said afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Peer persona's standard stem. VAL because it scores behavior, though no published value was available to anchor it |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is the team set up across planning, the warehouse and QA, and where would this role sit?" | The advert's central duty is coordinating those three, and her answer shows how much of it is scheduling and how much is relationship work |
| R2 | "What does a good first three months look like in this role?" | It shows you are thinking about delivering, and her answer tells you what to prioritise in a later round |
| R3 | "Which systems does the team use for stock and schedules?" | The advert lists SAP or similar as a plus; her answer tells you how large that line really is, and you ask it without claiming anything |
| R4 | "How do the two Avonmouth days usually work: set days, or agreed with the team?" | Hybrid is one of her agenda items; the answer lets you check the pattern against what you told her |
| R5 | "What does the weekly on-time dispatch report look like today?" | The advert names that report; asking shows you read the duty, and the answer is material for D2 |
| R6 | "You said you'd tell me the next steps. What does the next stage involve, and who would I meet?" | It turns her closing remarks into a concrete picture of the loop, and tells you which persona to expect next |
| R7 | "When would you like someone in post?" | It lets you connect her timing to the notice period you gave in A3 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | The quote at its own scope: "I schedule deliveries for our three depots and chase suppliers when orders slip." The limit is the pack's observation: the material says delivery scheduling, not production scheduling. B1's slot stays inside the depots |
| Has used SAP | Negative the candidate stated, F8 | The plain acknowledgment the quote gives: "Never used SAP — we run our own in-house stock system." No slot |
| Described the in-house stock system as an ERP or as equal to SAP | Inflated form of F8 | The quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation: the material says what the system is called, not what it covered |
| Cut discrepancies by a third, or caused the fall | Inflated form of F4 | The quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The limit is the pack's observation: the sentence gives a rebuild and a fall, with no stated cause. C1 and E2 ask only how it was counted and what was yours |
| £42,000 is the minimum I will accept | Inflated form of F9 | The quote at its own scope: "I'm hoping for £42,000." The limit is the pack's observation: the figure is stated as a hope, not a floor |
| Three days on site is my firm limit, or I can be flexible beyond three | Inflated form of F10 | The quote at its own scope: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." The limit is the pack's observation: it is a stated preference, not a limit or a concession |
| I was made redundant | Inflated form of F11 | The quote at its own scope: "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." The limit is the pack's observation: the sentence says closure and a relocation offer, nothing more |

## Sources

Provided documents: the Operations Coordinator advert (pasted); Hannah Lowther's LinkedIn message (pasted); Sam's background and talking points (message). No dossier was present.

Searches sent, all refused (search permission was not granted this session):

- "Quillmoor Diagnostics values": refused
- "Quillmoor Diagnostics strategy news": refused
- "Hannah Lowther Quillmoor Diagnostics": refused

No fetches were sent.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Every call was refused. It would have named published values for VAL questions; no values-style round is detected, so a cheat sheet was not due either way |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | skipped | Hannah's message fixes this session as one 30-minute phone call with her, which settles the persona weights and the bank structure |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | Every call was refused. It would have supplied current strategy for B4, which is therefore grounded in the advert alone |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Every call was refused. It would have fed the interviewer read and a reverse question tied to her path; the read holds only her own message |
| 5. representative `Operations Coordinator` JD | skipped | The advert Sam supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your actual notice period → A3's slot answered in your own words
- Which program the stock-count spreadsheet was built in, and how the third was counted → F7 and C1 gain your own sentences; a before-and-after count record would be the inspectable artifact that could lift F4 above medium
- What the in-house stock system covered → F8's slot answered, and B2 and E1 sharpened
- Any production, planning or QA contact in your scheduling work, in your own words → F1's and B1's slot answered
- Any regular report you produce, in your own words → F5's slot answered and D2 tightened
- Whether following supplier deliveries is part of your scheduling → F2's slot answered and C3 tightened
- Your CV text → evidence cells now quote only your message; a CV would add sentences and could turn discovery rows into grounded ones
- How many days you have before Thursday → a prioritized prep schedule keyed to question IDs
- Search permission → the values, strategy and interviewer-footprint targets re-run; a deeper research pass (L2, up to 6 more searches and 2 more fetches, several more minutes) is available on your say-so and adds a strategy brief for B4 and the CO questions
- Your schedule for later rounds → per-round mini-packs, since D and F are likelier after this call
- A tuesday-dossier.md → verified evidence and absolute prohibited claims for the guidance cells; the pack stands without it
