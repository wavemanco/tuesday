# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

- **Interviewer:** the support team lead, unnamed. The invite says the interview is "a text chat here with our support team lead".
- **Round assumed:** one text interview with the person who leads the team you would join, so hiring-manager style. Your message did not say more, and the invite's account of the process is unverified.
- **Built from:** the invite you pasted, the four requirements you quoted from the ad, and five sentences about your background.

## How to use this pack

- **Personas** are how a question arrives. **Types** are what it scores. Rehearse both.
- **Type key:**
  - **VAL**: whether past behaviour shows good values in practice.
  - **EXP**: whether your own account of your work survives follow-ups.
  - **JD**: whether you can do the job in the ad, gaps included.
  - **CO**: how well you know the company. There is no CO question here because company research was unavailable (see Sources).
  - **CASE**: a live problem from the role, reasoned through aloud.
- **Guidance is scaffolding, not a script.** Use your own words.
- **An answer slot** is an instruction for the interview, not a question for this chat. Answer it truthfully from your own experience. The honest branch is always allowed: "that wasn't part of my role" or "I don't know how it was counted" is a complete answer.
- **Provenance labels:**
  - `[grounded]` means traceable to something you wrote or the invite.
  - `[inferred]` means derived from a thin source, with the derivation named.
  - `[generic]` means a pattern for the role, with no claim about you.
- **The interview is written.** Your messages are the writing sample, so keep each one readable on its own.

## Fit snapshot

The requirements are quoted from your description of the ad. The evidence column holds your own words and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad, as you described it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap in the words, but a line in your message with nothing inspected behind it, so expect a probe. Say it in its own terms: three years, customer service advisor, an energy supplier. Do not relabel it with the ad's wording |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad, as you described it | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Say the tool you named: "I use Freshdesk every day." The ad's "or a similar ticketing tool" leaves the comparison to the interviewer, so give the name and let them judge. Your material names Freshdesk and not Zendesk |
| F3 | "clear written communication" — the ad, as you described it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Your sentence says calls and emails. It does not show how clear your writing was, and the bridge stops there. Answer slot: the ad's written-communication line makes a probe on your replies likely. If your written replies were reviewed, scored or sampled, say how, in your own words. If they were not, say so plainly and describe how you write a reply |
| F4 | "confidence handling escalations" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show escalation work either way. Answer slot: the ad's escalations line makes a probe likely. If you handled escalated cases, say what you did and what part was yours, in your own words. If escalations were not part of your role, or none came to you, say so plainly and say how you would handle one |
| F5 | Working at a software company: unquoted prose, not in the ad as you described it, but the employer is Lumenvale Software | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Your words: "I've never worked for a software company." Then your plan for learning the product, said as a plan and never as a past. No claim to have supported software customers, and nothing added to make the gap feel smaller |
| F6 | Supporting colleagues: unquoted prose, not in the ad as you described it | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | No gap, and an extra strength rather than a requirement. Keep it at its scope: you trained four new starters on the refunds process, last year. Expect "what part was yours" (D2) |

**Gates:** none appear in the ad as you described it. Hours, time zone, pay and right to work are not in your material, so this pack does not establish them. Confirm them in writing with Lumenvale through its own website, not in the chat.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 4 questions) | Quiet, persistent probing of the gap: software background, tool, motivation | **High.** A team lead is a hiring-manager-style seat, and that seat leans Skeptic. F5 is a gap you stated, which is the Skeptic's best material. The invite's own words establish one text interview, so no loop shifts this | Rehearse A2 until it is boring: hold the quotes, concede the gap in your own words, give a plan as a plan |
| Case / Strategist (bank B, 4 questions) | Live support scenarios you reason through in writing | **High.** Same hiring-manager prior. The ad's escalation and written-communication lines are easy to turn into scenarios | Clarify first, state your criteria, then answer in short messages. Your past stays out of cases unless a quote carries it |
| Conversational (bank C, 3 questions) | Friendly biography and "tell me about your work" openers | **Medium.** The invite is warm and informal and the interview is a chat. Casual questions are still scored | Three short beats from your own sentences. Do not answer the closing question with "no questions" |
| Data-Driven Prober (bank D, 3 questions) | Takes one line of your message and asks how it was counted | **Medium.** You gave two figures, "around 60" and "four", and both invite a "how was that counted" probe | Know what you can and cannot say about each number. Say plainly when you do not know |
| Pressure (bank E, 2 questions) | Time-boxed or blunt versions of the same objections | **Low to medium.** A support lead may test composure, but nothing in the invite signals it | Hold the position through two follow-ups before conceding anything real |
| Values / Behavioral (bank F, 2 questions) | "Tell me about a time" prompts | **Low to medium.** No source I read names a values round, so none is assumed. The ad's escalation line still produces one open prompt | Choose a story only if your own experience carries it, and use the honest branch if none does |

**Loop:** the invite's own words establish one text interview with the support team lead, followed by an offer and onboarding in the same chat. That account is unverified, and the weights rest on it.

## Question banks

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Pick the weakest part from your own honest view of the ad. Your material states one candidate: "I've never worked for a software company." If you name it, say it in those words, then give your plan for learning the product as a plan, in your own words. Answer slot: if you see another part of the ad where you would be weaker, name it and say why. If not, say so plainly and stay with the one you stated | F5 is the gap you stated, so this stem lands there first. JD because it asks you to score yourself against the ad. The question presupposes nothing about your past |
| A2 | "You haven't worked for a software company before. What makes you think you can pick up our product?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day" | **The highest-ROI rehearsal in this pack.** Hold only what the quotes carry: "I've got 3 years as a customer service advisor at an energy supplier, and I use Freshdesk every day." Concede in your own words before they press: "I've never worked for a software company, so the product would be new to me." Expect two follow-ups: a push on whether that is enough, and "what would you do in your first month?" Answer the first by returning to the quotes, never by adding to them. Answer the second with a plan, in your own words, said as a plan. Do not claim knowledge of software customers. Your material does not carry it | F5 is the most predictable objection to this candidate, and a software employer will raise it in some form. JD because it scores fit against the employer. The guidance follows hold-then-concede and names the limit before it is asked for |
| A3 | "Why software, and why now?" | JD | [generic] | Give your actual reason in two or three sentences, in your own words. Your material gives none, so the pack writes none. Keep it about what draws you to this role | The Skeptic checks that your motive is consistent and your own. JD because it tests fit with the role. The question presupposes nothing about your past |
| A4 | "The ad mentions Zendesk or a similar ticketing tool. What do you use, and what do you do in it?" | JD | [grounded] "I use Freshdesk every day" | Name Freshdesk and say you use it every day: "I use Freshdesk every day." Describe what you do in it, in your own words. Answer slot: the ad names Zendesk, so expect a follow-up on it. If you have used Zendesk, say how. If you have not, say so plainly and return to Freshdesk | F2 is the evidence for the tool requirement and the row where a Zendesk follow-up is likeliest. JD because it scores a stated requirement |

### Bank B: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes in angry for the third time about the same problem and says they will cancel. Walk me through your reply." | CASE | [generic] | Structure it: acknowledge the repeat first, read the history before replying, say what you will do and by when, say who else you would involve if it needs someone, and close the loop. Think aloud in short messages. The question needs no claim about your past, so the guidance makes none | Live problem built from the ad's escalation line (F4's requirement), asked as a decision. `[generic]` because it is a pattern for the problem, not a fact about this employer |
| B2 | "Two customers are waiting. One asks how to export their data. The other says they can't log in at all. Who do you answer first, and why?" | CASE | [generic] | Clarify before choosing: what you would ask, and what the queue rules are. State your criteria out loud (who is blocked, how urgent, how long they have waited). Say what you would tell the second customer in the meantime. The question presupposes nothing about your past | Triage is a common live problem for support roles, and the answer shows reasoning more than a right choice. `[generic]` throughout |
| B3 | "A customer asks a product question you can't answer, and your team lead is offline. What do you do?" | CASE | [generic] | Say plainly that you do not know. State what you would check, what you would tell the customer about timing, how you would hand it on with the full context written up, and how you would follow up. Do not bluff an answer | Aimed at F5. A candidate new to software is most tested on honesty about not knowing. CASE because it is a live problem with no claim about your past |
| B4 | "A customer asks for a refund that falls outside the policy. How do you handle it?" | CASE | [grounded] "I trained four new starters on our refunds process last year" | Structure it: listen, explain what the policy allows, find out whether anyone has discretion and who, offer what you can, and escalate with the case laid out. If you mention your own refunds work, keep it at that sentence's scope: you trained four new starters on the refunds process | Refunds is the one process your material names (F6), so a refunds scenario is likely to come up. CASE because it is a live decision; the quote is only a bounded reference |

### Bank C: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey: how did you end up in customer service?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Three beats the quote states: three years, customer service advisor, an energy supplier. How you got there and what keeps you in the field are yours to say. Your material gives neither, so the pack adds none. End on why this role. Send it as three or four short messages, not one block | F1 is the evidence for the experience requirement, and this is the biography question every chat opens with. EXP because it tests whether your account holds up |
| C2 | "What do you enjoy most about helping customers?" | VAL | [generic] | Give your own answer in a sentence or two. Add an example only if you can stand behind it under a follow-up. The question presupposes nothing about your past | Casual, and scored for genuine interest. VAL because it surfaces what you value in the work |
| C3 | "You trained four new starters on your refunds process. How did that go?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Beats the quote states: four new starters, the refunds process, last year. Say how it went in your own words. Do not claim an outcome, such as how they did afterwards, unless you can show it. Answer slot: say which part of the training was yours. If the process was set by others and you passed it on, say so plainly | F6 is your clearest example of supporting colleagues. EXP because the follow-up will test what was yours |

### Bank D: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said you were answering around 60 calls and emails a day. How was that figure counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Keep "around": do not turn it into an average or a daily count of resolved tickets. Answer slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly | Your one headline figure, so it is the number most likely to be probed. EXP because it tests attribution and honesty about counting |
| D2 | "Which part of training four new starters on refunds was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold at the quote's scope: you trained four new starters on the refunds process, last year. Answer slots, in your own words: how "four" was counted, the assumption behind it you would defend least, and which part was yours. If others shared the training, say so plainly | The second figure in your material, so a prober will go straight to it. EXP because "how much of that was you" is its standard probe |
| D3 | "What makes a written reply to a customer good, in your view?" | JD | [grounded] "answering around 60 calls and emails a day" | Give your own criteria in a few lines. Include only criteria you apply when you write. Answer slot: if anyone reviewed or scored your replies, say how. If not, say so plainly. This chat is itself a writing sample, so your answer should read the way you would write a reply | F3 is a thin row and the ad names written communication outright, so expect this question. JD because it scores a stated requirement |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I've never worked for a software company" | Pause and restate the question before answering. Hold: "I have 3 years as a customer service advisor at an energy supplier, and I use Freshdesk every day." Concede plainly: "I've never worked for a software company, so I'd be learning the product." Hold through two follow-ups by returning to those quotes. Do not claim you would learn faster than another candidate | The comparison is the pressure version of A2. JD because it scores fit against the role. The hold is only what your quotes carry |
| E2 | "At around sixty a day, what happens to quality?" | EXP | [grounded] "answering around 60 calls and emails a day" | Pause and restate. Hold only the quote: "around 60 calls and emails a day." Answer slot: if you checked your own replies or someone checked them, say how. If nobody did, say so plainly. Concede what you do not know. Do not name a score or a measure you cannot show | The pressure version of D1. EXP because it tests how you account for your own work |

### Bank F: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Your material carries no story for this, so use selection criteria. Pick a time when a customer's need and a target or rule pulled apart. It needs a stake you can name, what you did, and what you told whoever owned the target. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Customer-first behaviour is the likeliest values theme in support, and the stem comes from the Values persona. VAL because it scores behaviour, not slogans |
| F2 | "Tell me about a time you handled an escalation." | JD | [generic] | Your material carries no story for this, so use selection criteria. Pick a case that went beyond what you could resolve. Say what made it an escalation, what you did, who took it on, and what you would repeat or change. Use "I" for what you did and "we" for context. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle one | F4 is `none given`, and the ad names escalations. JD because it scores a stated requirement; delivered as an open prompt |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" (F1) | C1, E1 |
| "experience with Zendesk or a similar ticketing tool" (F2) | A4 |
| "clear written communication" (F3) | D3, D1, E2 |
| "confidence handling escalations" (F4) | F2, B1, B3 |
| Working at a software company (F5, not in the ad as you described it) | A1, A2, A3, E1 |
| Supporting colleagues (F6, not in the ad as you described it) | C3, D2, B4 |
| No requirement names these: practice for live problems | B2, none of the four requirements names it; included as role-family practice |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What do the first 30 days look like for a new Customer Support Specialist, and how do new starters learn the product?" | It meets the software gap (F5) head-on and sounds like interest in doing the job well |
| R2 | "What kinds of cases usually escalate, and who takes them on?" | It shows you take the ad's escalation line seriously and tells you the real shape of the job |
| R3 | "How are written replies reviewed here?" | It ties to the written-communication requirement and shows you care about reply quality |
| R4 | "Which ticketing tool does the team use?" | It settles the Zendesk and Freshdesk question honestly instead of leaving it implied |
| R5 | "What would make someone clearly successful in this role by month three?" | It asks for the interviewer's own yardstick, which also tells you what they will weigh |
| R6 | "Before onboarding, could we have a voice or video call, and could I see the offer and contract from a company email address?" | A genuine employer can answer this easily, and the way they answer helps you check who you are dealing with |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Experience with Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material names Freshdesk, not Zendesk. A4's slot lets you say whether you have used Zendesk |
| Has worked in the software industry | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |
| Resolved or handled 60 tickets a day | Inflated form of F3's quote | The quote at its own scope: "answering around 60 calls and emails a day", with "around" kept and calls and emails not converted to tickets. D1's slots stay inside the sentence |
| Designed or ran the refunds training programme | Inflated form of F6 | F6's quote at its own scope: you trained four new starters on the refunds process, last year. D2's slot asks only which part was yours |

## Sources

**Provided documents:** the invite you pasted and your message, with the four ad requirements and the five sentences about your background. No dossier was in hand.

**Searches sent (all refused, so nothing from the web is in this pack):**
- `Lumenvale Software company values`: refused
- `Lumenvale Software interview process customer support specialist`: refused
- `Lumenvale Software news customer support`: refused

Research tier: L1, searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Would have fed a values cheat sheet and VAL questions by value name. Without it, no values are named |
| 2. `Lumenvale Software interview process customer support specialist` | unavailable | Would have checked the loop against the invite's own account. The loop here rests on the invite's words alone |
| 3. `Lumenvale Software strategy` / recent news | unavailable | Would have fed a CO question. None is included |
| 4. Interviewer name and company | n/a | No name was given for the interviewer, so there is no query and no interviewer read |
| 5. Representative Customer Support Specialist JD | skipped | The four requirements you quoted fix the fit snapshot |

Nothing in this pack verifies that Lumenvale Software, its team or its process are as the invite describes.

## Upgrade menu

- The full text of the ad: F1 to F4 become exact quotes, and any mid-list requirement gets its own JD question
- Your CV: your evidence moves beyond five sentences, and more rows gain story-mapped answers instead of selection scaffolds
- Something inspectable from your current or last job, such as a manager's reference, a quality or customer-satisfaction summary, or a Freshdesk activity export with customer details removed: F1, F2 and F3 can move from medium or low toward high
- Lumenvale's values or careers page, found through its own website and pasted here, or permission for web search: values and CO questions become grounded
- The name of the support team lead: an interviewer read and a reverse question tied to their own path
- A tuesday-dossier.md, if you have one: verified evidence and a prohibited-claims list from an earlier evaluation, which this pack otherwise builds for itself
