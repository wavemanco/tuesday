# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Interviewer:** Hannah Lowther, Talent Partner. Recruiter screen, a 30-minute phone call on Thursday at 2pm, on the mobile number on your application.
**Built on:** Hannah's own agenda for the call, quoted from her message: "I'd like to cover your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move, and then I'll tell you about the team and the next steps."

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your own history survives follow-up questions |
| JD | Whether you meet what the advert asks, gaps included |
| CO | What you know about the company and its strategy |
| CASE | A live problem from the actual role |

Provenance labels: `[grounded]` traces to something you or the recruiter wrote, `[inferred]` is derived from adjacent material with the derivation named, `[generic]` is a pattern with no claim about you or Quillmoor. An answer slot is an instruction for the interview, not a question for you now.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — the advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap, but this is a line in your message with no CV or document inspected behind it, so expect a probe. Lead with it in its own terms: four years as a logistics coordinator at a building-supplies wholesaler |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | low | [inferred] | transferability | Derived from adjacent work: delivery scheduling set against production scheduling. Your material says deliveries for three depots, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who you work with likely. If your scheduling brought you into contact with other teams, say which and what you did, in your own words; if it did not, say so plainly and stay with the three depots |
| F3 | "track supplier deliveries" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | low | [inferred] | discovery | Derived from adjacent work: chasing when orders slip touches tracking without showing how deliveries are followed. Answer slot: the advert's tracking line makes a probe on how you follow supplier deliveries likely. If you follow them in a particular way, say what you look at and how often, in your own words; if you do not track them as such, say so plainly and stay with "chase suppliers when orders slip" |
| F4 | "chase late orders" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it. Lead with the behaviour in your own terms, "chase suppliers when orders slip", because a named behaviour beats an adjective |
| F5 | "keep stock records accurate" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap, but the figure is a magnet for probes (C1, C2, E1). Say what you rebuilt and what fell, as you said it, keeping "about a third over a year" and no firmer |
| F6 | "report weekly on on-time dispatch" — the advert | none given | none | [grounded] | discovery | Your material does not show reporting of any kind. Answer slot: the advert's weekly on-time dispatch line makes a probe on reporting you do now likely. If you produce any regular report, say what is in it and how often, in your own words; if you do not, say so plainly and say what you would want to measure first, as a plan |
| F7 | "confident with Excel" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | low | [inferred] | discovery | Derived from adjacent work: the quote says a spreadsheet, not which tool and not what you did in it beyond rebuilding it. Answer slot: the advert's Excel line makes a probe on your spreadsheet skills likely. Say which tool the spreadsheet was in and what you did in it, in your own words; if the tool was not Excel, or Excel was a small part of the work, say so plainly and stay with "I rebuilt our stock-count spreadsheet" |
| F8 | "ERP experience (SAP or similar) a plus" — the advert | "Never used SAP — we run our own in-house stock system" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used SAP." Then how you would learn a new system, said as a plan and never as a past. The advert lists it as a plus. B2 holds the question about the in-house system |
| F9 | "£38,000–£44,000" — the advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | Within the advertised band. Confidence is high because your own stated figure is the strongest evidence a pay figure has. Give it in your own words and keep "hoping for": it is a hope you stated, and this pack does not turn it into a floor |
| F10 | "two days a week at our Avonmouth site in Bristol" — the advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | The term is met by your own words. Keep both halves at their scope: two days is fine, and you wouldn't want more than three. "Wouldn't want" is a preference you stated, not "can't" and not "flexible" |
| F11 | "what's prompting a move" — Hannah Lowther's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | No gap: say it as you said it. The pack's observation is that the sentence gives a push and says nothing about what draws you to Quillmoor; B3 holds that |

## Persona table

Her message establishes this one call and names no later rounds. Weights rest on her stated agenda and the recruiter-screen prior, and are flat beyond this call. No values-style round is detected, so there is no values cheat sheet.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational (weight highest, 5 questions) | Friendly, unstructured; pay, notice, hybrid and reason for moving asked in a casual register | Highest: she listed exactly these four topics, and the recruiter-screen prior is conversational. Casual does not mean unscored | Short spoken arcs and a logistics answer for each topic, each in your own words; never wing the "what's prompting a move" answer |
| B. Skeptic (4) | Quiet probing of the gaps and of why here, why now | High: the recruiter prior includes a light Skeptic, her listed topic "what's prompting a move" invites why-here, and F2, F6 and F8 are the thinnest rows | Rehearse B1 until it is boring; bridge only from your own quotes and say the limit plainly |
| C. Data-Driven Prober (3) | Asks how a CV figure was counted | Medium-low: a recruiter may touch the figure lightly, a hiring manager would press it, and F5 is the one headline figure | Say how it was counted, or say plainly you do not know; name the assumption you would defend least before they do |
| D. Case / Strategist (3) | A short live problem from the role | Low on this call: she announced no case and said she will cover the team and next steps. Likely later if a hiring-manager round follows, which her message does not show | Clarify first, then structure, then answer; think aloud |
| E. Pressure (2) | Time-boxed challenge: why you, how much was you | Low on a recruiter call; kept because the SAP gap (F8) and the figure (F5) are natural pressure points later | Pause, restate, hold the position through two follow-ups, then concede only what you know you cannot back |
| F. Values / Behavioral (2) | "Tell me about a time" questions | Low: no loop source names a values round, and no values were researched | Pick one instance you can describe in detail; say so plainly if none comes to mind |
| G. Peer Evaluator | Not banked | Hannah is a recruiter, not a peer, and no peer round is named. Add a bank if a team meeting is scheduled | — |

## Question banks

**Highest-ROI prep: B1.** The advert's first duty is the one your material carries least (F2), and some version of this question is likely whenever someone reads the advert against your background.

### A. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background and where you are now." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Story-mapped on F1, F4 and F5, in about 90 seconds: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for your three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet and the fall in discrepancies, kept at "about a third over a year". Those are the beats the quotes state; tell them in your own words and add none. Stop there and let her move to why you are looking | F1 sets the experience floor and recruiter screens open on the biography. EXP because it tests whether your own account holds together; Conversational because the stem is "walk me through the journey" |
| A2 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say it as you said it, in your own words: the Bristol office is closing next year, and the only offer is relocating to Reading, which you don't want. Stay at those facts. Your material shows nothing about what draws you to Quillmoor, so add no pull you do not feel; B3 holds that. Keep it short, because a plain reason is a complete answer | F11 is the recruiter's own listed topic and the reason for leaving is a logistics question on every recruiter screen. EXP because it is your history; the pack's job is a steady, unembellished delivery |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Lead with the fit as you said it: you live in north Bristol, so two days at Avonmouth is fine. Whether to volunteer the limit is your call; if she raises more days, say it at its scope, that you wouldn't want more than three, and do not turn "wouldn't want" into "can't" or into "flexible". Keep the Reading relocation out of this answer | F10 is a term in the advert and a topic she named, and your own words show it met. JD because it scores a stated term of the listed job |
| A4 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" | Give your figure in your own words, as you said it: you're hoping for £42,000. It sits inside the advertised band (F9). Keep "hoping for" rather than a minimum or a range you did not state. This pack does not script salary history; if she asks about current pay, answer with your own facts | F9 is the advert's band and a topic she named. JD because pay is a term of the listed job; the figure is yours, so no defend-the-number slot is raised |
| A5 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, in your own words. If you are unsure of it, say so plainly and say when you can confirm it. The pack states no figure because your material gives none | She named notice as a topic and the advert states none, so there is no fit row; the answer is yours alone. JD because it is a term of the listed job |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role coordinates production schedules between planning, the warehouse and QA, and your background is deliveries at a wholesaler. How do you see that fitting?" | JD | [inferred] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip" | Deepest rehearsal, three levels. Level 1, hold only what the quotes carry: "I schedule deliveries for our three depots and chase suppliers when orders slip." Answer slot: if your scheduling brought you into contact with other teams, say which and what you did, in your own words; if it did not, say so plainly and stay with the three depots. Level 2, if she presses on the difference between the two kinds of scheduling: do not widen the quote; say the difference in your own words and say what you would do first to learn how those three teams' schedules connect, as a plan and never as a past. Level 3, if she asks why you should go forward: return to the two quotes and to the chasing line the advert shares, add nothing. Concede the limit before she asks for it; the wording of the concession is yours | F2 is the biggest gap on a requirement the advert does not mark as a plus. JD because it scores the advert's first duty; Skeptic because it is the quiet "help me understand" probe at the thinnest row |
| B2 | "Have you used SAP, or anything similar?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Plain acknowledgment from the negative you stated: "I haven't used SAP." Then, at its own scope: "we run our own in-house stock system." Answer slot: the advert's "or similar" makes a probe on what you do in that system likely. If you work in it yourself, say what for, in your own words; if you do not, say so plainly and leave it at "we run our own in-house stock system". Then how you would learn a new system, as a plan | F8 is a gap you stated, and the advert lists it as a plus. JD because it scores a stated requirement; the answer slot is needed because the quote says the organisation runs a system, not that you use it |
| B3 | "What draws you to Quillmoor, and why now?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Why now: the sentence above, in your own words. Why Quillmoor: your material carries nothing here, so give selection criteria. Answer slot: say what in the advert actually draws you, in your own words; if the main reason is the office closure, say so plainly rather than adding one. If the advert's "chase late orders" line appeals, you can say it matches the chasing you described, at that scope | F11 shows a push and no pull. EXP because it tests the consistency of your story; Skeptic because "why leave, why here, why now" is the persona's own stem |
| B4 | "The role reports weekly on on-time dispatch. What reporting do you do at the moment?" | JD | [grounded] | Answer slot: if you produce any regular report, say what is in it and how often, in your own words; if you do not, say so plainly and say what you would want to measure first, as a plan. The pack names no report, because your material shows none | F6 is a requirement your material is silent on. JD because it scores a stated duty; the premise lets the practice not exist, as the slot's second branch allows |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third over a year. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Defend-the-number, in your own words. Answer slot: say how the figure was counted; if you do not know how it was counted, say so plainly. Keep "about a third over a year" and no firmer, and name no method, baseline or period the quote does not give | F5 is your one headline figure, so it is the likeliest target for a prober. EXP because it tests whether the claim survives scrutiny |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Weakest-assumption move: name, in your own words, the assumption you would defend least before she does. Answer slot: if you know of one, say what it is; if you do not know of one, say so plainly and say what you would want to check | The persona stem for this prober, applied to F5. EXP because it scores your honesty about your own number |
| C3 | "How would you describe your Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Answer slot: say which tool the spreadsheet was in and what you did in it, in your own words; if the tool was not Excel, or Excel was a small part of the work, say so plainly and stay with "I rebuilt our stock-count spreadsheet". Give a named piece of work rather than an adjective | F7 is the advert's tool requirement and the quote touches it without showing it. JD because it scores a stated requirement |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you an order QA is waiting on will be four days late. What do you do first?" | CASE | [generic] | Structure it: what you need to know first, such as what is waiting on the order and how much slack the schedule has; who has to be told and when; what you would ask the supplier; what you would record and how you would follow up. The question needs no claim about your past, so the guidance makes none | A live problem built from the advert's supplier-delivery lines (F3, F4) and its planning, warehouse and QA seam (F2). CASE because it asks for structure; generic because it is a pattern, not a fact about this employer |
| D2 | "The system says a batch is in stock but the warehouse cannot find it, and QA needs it tomorrow. Walk me through it." | CASE | [generic] | Structure it: confirm what is physically there, find where the record and the shelf could have diverged, tell the people waiting what is known and what is not, and say what you would record so it is traceable. No claim about your past | Built from the advert's stock-record line (F5). CASE because it tests reasoning on a live problem; generic because no quote is needed |
| D3 | "You are asked to start a weekly on-time dispatch report from scratch. What do you ask first, and what goes in it?" | CASE | [generic] | Clarify before you structure: what counts as on time and against which date, which orders are in scope, who reads it and what they decide from it, and where the data comes from. Then propose one measure and say its limits. No claim about your past | Built from the advert's reporting duty (F6). CASE because it asks for structure; it also gives you a plan to quote if B4 finds no report in your history |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That fall in discrepancies. How much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold-then-concede. Hold what the quote carries as two statements: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. Answer slot: say which part of the fall you can tie to your rebuild and which you cannot; if you cannot separate them, say so plainly. Hold through two follow-ups by returning to "I rebuilt our stock-count spreadsheet", never by adding to it. Never say the rebuild alone caused the fall | F5 pairs a rebuild and a fall in one sentence without saying one caused the other. EXP because it tests attribution; Pressure because it is the persona's "how much was actually you" stem |
| E2 | "Sixty seconds: why should we pick you over someone who has used SAP?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip"; "Never used SAP — we run our own in-house stock system" | Concede first, from the negative you stated: "I haven't used SAP." Then hold what the other quote carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." Do not compare yourself to the other person, and say how you would learn the system as a plan, never as a past. Hold through two follow-ups by repeating the quote, never by widening it | F8 is the gap a time-boxed challenge would aim at, and F4 is the nearest row that carries your own work. JD because it scores a stated plus; Pressure because of the time box |

### F. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you had to chase a late order." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Your sentence states that you chase suppliers when orders slip; choose one instance you can describe in detail. Who you chased, what you said and what happened are yours to supply from memory, and this pack supplies none. If no single time comes to mind, say so plainly, then give the nearest thing your material carries: "I schedule deliveries for our three depots and chase suppliers when orders slip" | The theme is the advert's "chase late orders" line (F4). EXP because it asks for an instance from your history; it sits in this bank because it is a "tell me about a time" prompt |
| F2 | "Tell me about a time you had to give someone news they did not want to hear." | EXP | [generic] | Selection criteria: pick a time the news was yours to give, with a named stake and a working relationship still intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or say how you would handle it. The pack supplies no event | A persona stem, kept because behavioural prompts can arrive on any screen. Tagged EXP and generic because no published values were researched and no quote carries this |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in operations or logistics coordination" | A1 |
| "Coordinate production schedules between planning, the warehouse and QA" | B1, D1 |
| "track supplier deliveries" | D1, F1 |
| "chase late orders" | F1, D1, E2 |
| "keep stock records accurate" | C1, C2, D2, E1 |
| "report weekly on on-time dispatch" | B4, D3 |
| "confident with Excel" | C3 |
| "ERP experience (SAP or similar) a plus" | B2, E2 |
| "£38,000–£44,000" | A4 |
| "two days a week at our Avonmouth site in Bristol" | A3 |
| "what's prompting a move" (Hannah's message) | A2, B3 |
| Notice period (Hannah's message, no advert line) | A5 |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "Once you've described the team: how do planning, the warehouse and QA hand work to each other day to day?" | It follows the advert's first duty and tells you what your material cannot (F2) | [grounded] the advert's production-schedules line |
| R2 | "Which system does the team use for stock and production records, and what training would there be on it?" | It turns the SAP gap (F8) into a forward-looking question about how you would start | [grounded] the advert's ERP line |
| R3 | "How is on-time dispatch measured today, and who reads the weekly report?" | It shows you read the reporting duty and gives you the definition D3 asks you to clarify (F6) | [grounded] the advert's reporting line |
| R4 | "On the Avonmouth days: are the two days fixed for the team, or agreed individually?" | It follows your hybrid answer (F10) with a practical detail | [grounded] the advert's hybrid line |
| R5 | "What are the next stages, and roughly when would you expect a decision?" | She said she will cover next steps; this confirms the format and timing so you can plan | [generic] |
| R6 | "What would a good first three months look like in this role?" | It lets you hear how success is defined, which shapes everything you say in later rounds | [generic] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F2 | F2's quote at its own scope: "I schedule deliveries for our three depots and chase suppliers when orders slip." The limit is the pack's observation: the material says deliveries, not production schedules. B1's slot stays inside the three depots |
| Has used SAP | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't used SAP." No slot |
| The in-house stock system counts as ERP experience | Inflated form of F8's quote | F8's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation: the material says the organisation runs it, not that you use it or what it covers. B2's slot asks only what you do in it |
| Confident or advanced Excel skills | Inflated form of F7 | F7's quote at its own scope: "I rebuilt our stock-count spreadsheet." The limit is the pack's observation: the material says a spreadsheet, not which tool or what you did in it. C3's slot asks only those two things |
| The rebuild alone caused the fall in discrepancies | Inflated form of F5 | F5's quote at its own scope, as two statements. The limit is the pack's observation: the sentence joins a rebuild and a fall without saying one caused the other. C1 and E1 ask only how the figure was counted and which part was yours |
| Available for any number of office days | Contradicted by F10's quote | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" |

## Sources

Provided: the advert text; your description of your background and what you would tell her (quoted as "your message"); Hannah Lowther's LinkedIn message. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics company values` | unavailable | Search refused. Would have named published values for the cheat sheet and reverse questions; no values-style round is detected, so no section was built |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Search refused. Would have documented later rounds and moved persona weights beyond this call |
| 3. `Quillmoor Diagnostics Avonmouth news strategy` | unavailable | Search refused. Would have supplied a strategy-grounded CO question; the pack has none |
| 4. `Hannah Lowther Talent Partner Quillmoor Diagnostics` | unavailable | Search refused. Would have supplied an interviewer read and a reverse question tied to her path |
| 5. representative Operations Coordinator advert | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

Queries sent, each refused: `Quillmoor Diagnostics company values`; `Quillmoor Diagnostics interview process operations coordinator`; `Quillmoor Diagnostics Avonmouth news strategy`; `Hannah Lowther Talent Partner Quillmoor Diagnostics`. Nothing about Quillmoor in this pack comes from outside the advert and Hannah's message.

## Upgrade menu

- Search permission granted → the four L1 targets rerun: published values, later-round structure, current strategy and Hannah's public professional footprint, which would add a tailored reverse question and let the `[generic]` CASE rows draw on Quillmoor's own priorities
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, needing the same search permission) → a company strategy brief for sharper CO and CASE questions
- Your CV → F1, F4 and F5 move from a message line to a document; a stock-count discrepancy report or a delivery schedule you could describe would move F5 toward `high`
- Your answers on which tool the stock-count spreadsheet was in, whether you work in the in-house stock system yourself, whether you produce any regular report, your notice period, and any flexibility on £42,000 → F6, F7 and F8's slots, A4 and A5 filled in your own words
- Any prep email from Hannah on later rounds → coverage of a case or a presentation if one is announced
- A `tuesday-dossier.md` from an earlier evidence check → verified evidence and a dossier-named objection for B1 in place of this pack's inferred one
