# Interview prep pack — Fourth Grade Teacher, Halvering Elementary School

**Employer:** Orrinsford Community School District (invite signed Human Resources)
**Round:** one 45-minute panel on Thursday — Principal Dolores Vantongeren and two members of the fourth-grade team (names not given in the invite). Session mode; the panel is the whole loop the district's hiring page describes (see Sources).
**Highest-ROI prep in this pack:** A1, the fourth-grade-readiness question. The pack inferred this objection from the fit snapshot; no dossier named one.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Every question has a type tag, a provenance cell, answer guidance and a rationale.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs, not generic virtue |
| EXP | Whether your own account of your work holds up under follow-up questions |
| JD | The stated role requirements, including the gaps |
| CO | Homework on the district's published direction |
| CASE | A live problem from the actual role, scored on structure and reasoning |

- Guidance is scaffolding, not a script. Say it in your own words and rehearse it aloud.
- A question's provenance cell carries every sentence of yours its guidance rests on, quoted exactly. Where no sentence of yours carries a story, the guidance is a selection scaffold or an answer slot.
- An answer slot is an instruction for the interview, not a question for you here. It gives two honest branches: say how, in your own words, if it was yours; if there was no such step, or it was not yours, say so plainly and return to the sentence you can stand on.
- Bank letters skip F so they never collide with fit-snapshot rows F1 to F9.
- Your resume's license number and any other identifiers were not used anywhere in this pack.

## Fit snapshot

Requirements come from the invite, from the district's published pages, and from a representative listing for the role (not this school's posting, so those rows are `[inferred]`).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | No gap in your material, and it is a statement with nothing inspected behind it, so expect HR to check it against the license record. The pack has not checked that record; that is yours to do. Lead in the quote's own terms. The pack's observation: the range your quote states takes in fourth grade, and its stated expiry is later than Thursday |
| F2 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board listing, a representative posting | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | discovery | Your sentence gives the grade and the years and does not show which subjects you taught. Answer slot: a listing of this kind names five subjects, so expect a probe on which of them you taught. Say which, in your own words; if you taught only some, or others taught some, say so plainly and stay with the six years in third grade |
| F3 | "Fourth Grade Teacher position at Halvering Elementary School" — invite | "I've never taught fourth grade and I've never been a team lead." — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would learn it, said as a plan and never as a past. Never a claim to fourth-grade teaching, and nothing added to make the gap feel smaller |
| F4 | "work with the grade-level team" — K12 Jobs Board listing, a representative posting | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [inferred] | presentation | The sentence already reaches the requirement in other terms. Reworded, no more: "I led our grade level's move to a new reading curriculum in 2024." Its limits are the pack's observation: the scope is your grade level, not the school or district, and your same resume block says you have never been a team lead, so expect the seam between the two sentences (A3, H2) |
| F5 | "each teacher speaks with every family each term" — district Mission and Beliefs page, belief Families Are Partners | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | The sentence carries a weekly email, which is adjacent to the belief's speaking with every family. Words, at the quote's own scope: "I write a weekly email to families." Answer slot: the belief makes a probe on conversations as well as emails likely. If you spoke with families beyond the email, say how and how often, in your own words; if you did not, or it was not part of how your school works, say so plainly and stay with the email |
| F6 | "no student leaves third grade without a reading plan" — district Mission and Beliefs page, belief Every Child a Reader | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years." — your CV | medium | [grounded] | discovery | Your sentences carry a curriculum move and a club and do not show whether reading plans for individual students were part of your work. Answer slot: the belief names third grade, and your material says third grade, so expect a probe on reading plans. If they were part of your work, say how they were made and what part was yours; if there was no such plan, or it was not yours, say so plainly and stay with the curriculum move and the club at their own scope |
| F7 | "differentiate instruction using assessment data" — K12 Jobs Board listing, a representative posting | none given | none | [inferred] | discovery | Nothing in your material speaks to this. Strong evidence would be one instance, in your own words, of results changing what you taught next. Answer slot: a listing of this kind names it, so expect a probe. If results changed what you taught, say what you looked at and what you changed; if they did not, or it was not your call, say so plainly and say how you would start, as a plan |
| F8 | "assessments inform teaching and never replace it" — district Mission and Beliefs page, belief Teach for Tomorrow, Not for the Test | none given | none | [grounded] | discovery | Nothing in your material speaks to this. Answer slot: the belief is published, so expect a probe on how you use assessment results. If you used them to shape teaching, say how, in your own words; if you did not, or it was not your practice, say so plainly and say how you would work inside the district's own line, as a plan |
| F9 | "keep clear classroom routines" — K12 Jobs Board listing, a representative posting | none given | none | [inferred] | discovery | Nothing in your material speaks to this. Answer slot: a listing of this kind names it, so expect a probe. If you set up routines in your room, say which and how you taught them, in your own words; if routines were set by the school or by others, or you had none you would call routines, say so plainly and answer as a plan |

## Reading the interviewer

Public professional footprint only. Only the principal is named in the invite; nothing was searched for the two team members.

| # | Public fact | Source | Provenance | What it means for the panel |
|---|---|---|---|---|
| I1 | Principal of Halvering Elementary School since 2022 | ilprincipalsforum.example speaker page, search result | [grounded] | She chairs the panel the invite describes; the persona table gives her the hiring-manager weighting |
| I2 | Nine years as a reading specialist before becoming principal | ilprincipalsforum.example speaker page, search result | [grounded] | Reading instruction is her own field; expect probes on it to be informed, so use plain words and avoid jargon you cannot unpack |
| I3 | 2025 forum talk, Small Groups, Big Readers, covering weekly reading conferences in grades 3 to 5 | ilprincipalsforum.example speaker page, search result | [grounded] | Small-group reading and reading conferences are likely themes; see B1, E3 and reverse question R2 |
| I4 | No public information gathered on the two fourth-grade team members | Search 4 returned nothing on them; none was sent | [grounded] | Their weighting rests on the peer relationship prior alone; their names would let the pack read them too |

Mirror opportunity: her public path runs through reading instruction, and your reading material is the two sentences in F6's evidence cell: "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years." Offer them at their own scope. Do not borrow her vocabulary of small groups and conferences for your own practice unless it is true; R1 and R2 ask about her work instead.

## Persona table

Weights follow the relationship priors, then the interviewer signals, then the loop. The district's hiring page establishes the loop: one panel of the principal and two grade-level teachers, so no archetype fallback is used.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 5 questions) | Quiet probing of grade-level change and team experience | High. The principal's hiring-manager prior is Case plus Skeptic, and F3 is a gap you have stated | Rehearse the single most predictable objection (A1) until it is boring; plain acknowledgment plus a plan, never a bluff |
| Case / Strategist (bank B, 4 questions) | Live reading, routine and family scenarios; the district's literacy plan | High. The same hiring-manager prior; the hiring page lists reading instruction, classroom routines and families as panel topics; the principal's path is reading (I2, I3) | Clarify, then objective, approach, check and risk; think aloud; challenge one premise respectfully |
| Peer Evaluator (bank C, 3 questions) | The two fourth-grade teachers weighing what you add to their work | Medium. Peer prior for the two team members; F4 is where they will press | Reciprocity: what you bring as well as what you need; propose seam principles, not a pretended seam |
| Values / Behavioral (bank D, 3 questions) | Questions themed on the three published beliefs | Medium. The loop source names panel topics, not a values round, so none is detected; the three beliefs still map onto the topics the panel asks about | Map a story to each belief only where a sentence of yours carries one; otherwise a selection scaffold ending in its honest branch |
| Conversational (bank E, 3 questions) | Opening journey question, licensure confirmation, an easy reading question | Medium. Every panel opens somewhere friendly, and casual questions are still scored | A 90-second arc built only from your own sentences; treat the casual reading question as scored |
| Data-Driven Prober (bank G, 2 questions) | Attribution and detail on the curriculum move and the club | Low. Second peer prior, but F4 and F6 carry no figures to defend | Say plainly what you know and do not know about how each thing ran |
| Pressure (bank H, 2 questions) | Time-boxed or blunt versions of A1 and the F4 seam | Low. A three-person panel and a 45-minute slot leave little room for a stress style, but the blunt form of the gap is plausible | Pause, restate, hold through two follow-ups, concede specifically |

## Question banks

### Bank A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've spent six years in third grade. What makes you ready for fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I've never taught fourth grade and I've never been a team lead." | The highest-ROI rehearsal in this pack: expect this in some form. Say the plain sentence first: "I haven't taught fourth grade." Then what your material carries, at its own scope: six years teaching third grade at a public elementary school in Joliet. Then a plan, said as a plan: what you would ask the two fourth-grade teachers first and what you would want to learn before your first day. If pressed twice, on what will be hardest and why take the risk, return to the six years and the plan. Add no fourth-grade practice, pacing or curriculum knowledge you do not have, and do not claim the grades are the same. Name the limit yourself before they do | F3 is the stated gap that the role title makes unavoidable, so this objection arrives in some form; F2 is the nearest adjacent evidence. JD because it tests the stated role, in Skeptic delivery with hold-then-concede |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [generic] | Choose the weak area that is true for you and say it in one sentence, with no apology. Then say what you would do in your first month to close it; the plan must be yours. Criteria: a real gap, not a disguised strength, and a closing step you would actually take. If no such area comes to mind, say so plainly, then name what you would want to learn first from the two fourth-grade teachers | F3 states one gap and F7 to F9 are silent rows, so the honest choice exists. JD because it scores the whole listing rather than one item |
| A3 | "I see you haven't been a team lead. How would you contribute to our grade-level team?" | JD | [inferred] "I led our grade level's move to a new reading curriculum in 2024"; "I've never taught fourth grade and I've never been a team lead." | Plain acknowledgment first: "I haven't been a team lead." Then your own sentence at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Say both without bridging them with words you did not say. Answer slot: a listing of this kind names working with the grade-level team, so expect a probe on how you worked with colleagues during that move. If you took particular steps, say which and what part was yours, in your own words; if the move was set by others, or no particular step was yours, say so plainly and stay with the sentence. What you bring the team is in C2 | F4 is the row the team-experience probe lands on; JD because the requirement is read from a representative listing, framed as typical for the role and not as this team's practice |
| A4 | "Why leave third grade — and why here, why now?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Three parts, each true for you: why a change from third grade, why this school, why now. The pack has nothing on your reasons, so say them in your own words; if one part has no answer you can give honestly, say so plainly. For why here, the district's published three-year literacy plan, adopted August 2026, includes a new grades 3–5 reading curriculum from fall 2027 and a family reading night at every school each term. Mention it only if it is genuinely part of your reason. Keep to ninety seconds | Motivation consistency is what the Skeptic scores, and F3 is why the move reads as a question. EXP because it tests your own account of your path |
| A5 | "Which of reading, writing, math, science and social studies did you teach in third grade?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: a listing of this kind names five subjects, so expect a probe on which of them you taught. Say which, in your own words; if you taught only some, or others taught some, say so plainly and stay with the six years in third grade. Where something on the list is new to you, say so as a plan, and do not name fourth-grade content you have not taught | F2 is read from a representative listing, so this is a typical-role probe and not this school's. JD because it scores a stated requirement |

### Bank B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A student joins your class reading well below the others. What do you want to know first, and what do you do in the first two weeks?" | CASE | [generic] | No claim about your past is needed. Structure it aloud: clarify first, covering what information already exists about this reader and what the family and the previous teacher can tell you. Then the objective, two or three approaches and how you would choose between them, how you would check it is working, and one risk. Think aloud and challenge one premise respectfully, for example how "below" was measured. Plain words beat jargon you cannot unpack | The hiring page lists reading instruction as a panel topic and the principal's public path is reading (I2, I3); F6 and F7 are the related rows. CASE because it is a live problem from the role |
| B2 | "The board adopted a three-year literacy plan with a new grades 3–5 reading curriculum from fall 2027. How would you help a fourth-grade team through that change?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on one sentence, with only the beat it states: "I led our grade level's move to a new reading curriculum in 2024." Say it at that scope and stop. Answer slot: expect a probe on what the move involved. If you ran particular steps, say which and what part was yours, in your own words; if the move was set by others, or no particular step was yours, say so plainly and stay with the sentence. Then the forward part, as a plan: ask first which curriculum was adopted, on what timetable and what the team has already decided. The pack does not know, and you should not guess | The district's own plan is the strategy-grounded item and F6 holds the one reading-curriculum sentence. CO because it tests homework on the published direction, with CASE delivery |
| B3 | "It's the second week of school and transitions are chaotic. How do you reset?" | CASE | [grounded] | The hiring page lists classroom routines among panel topics. Structure it aloud: clarify what is chaotic, for whom and when; the objective; teach and practise versus fix; how you would check; one risk. Answer slot for your own room: if you set up routines yourself, say which and how you taught them, in your own words; if routines were set by the school or by others, or you had none you would call routines, say so plainly and answer as a plan | F9 is silent in your material, and routines are a named panel topic. CASE because it is a live problem; the slot is raised by the representative listing and framed as typical for the role |
| B4 | "At the first family conference of the term, a parent tells you their child hates reading. What do you say?" | CASE | [generic] | No claim about your past is needed. Structure it aloud: listen first and ask what the parent has seen at home; share what you see at school only as you would actually know it; agree one small next step and how you will follow up. Think aloud and challenge one premise respectfully, for example what "hates" covers | F5's belief makes families a panel topic and F6 ties it to reading. CASE because it is a live problem from the role; your own family practice is rehearsed in D2 |

### Bank C — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "We plan together as a team. Where's the line between what you'd decide on your own and what you'd bring to us, and what happens when we disagree?" | JD | [inferred] | Propose principles, not a pretended seam: ask how the team plans now before saying what you would change; classroom-level choices are yours and grade-level choices go to the team; disagree openly with reasons, then follow the team's decision once it is made. These are principles for how you would work, not claims about how you have worked. Keep to ninety seconds | F4 is the row the peer teachers will press; JD because the requirement is read from a representative listing and framed as typical for the role |
| C2 | "What would you need from us in your first month, and what would you bring us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years." | Needs, as questions about fourth grade that you would ask the team, not claims. What you bring, in two sentences of your own: "I led our grade level's move to a new reading curriculum in 2024." and "I've run the after-school reading club for the last two years." State them at that scope and stop. Add no results and no description of what the move or the club involved; if asked for more, answer from what you actually did, in your own words | Peers price what a hire adds to their load; F4 and F6 hold the two sentences you can offer. JD because it scores the working-with-the-team requirement; reciprocity framing |
| C3 | "Tell me about a time you disagreed with a colleague about how to teach something, and how it ended." | EXP | [generic] | Selection scaffold: pick a real disagreement about teaching; use "we" for context and "I" for your part; end with the working relationship intact and the decision as it truly landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The peer stem on what happens when teams disagree. EXP because it asks for a past instance; F4 is the related row |

### Bank D — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Every Child a Reader is one of our three beliefs. Tell me about a time you helped a student become a stronger reader." | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years."; "Six years teaching third grade at a public elementary school in Joliet." | No quoted sentence of yours carries a single-student story, so use selection criteria: one student or group, a before and after you can describe truthfully, and the one thing you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, each at its own scope: the curriculum move or the club. Answer slot: the belief says no student leaves third grade without a reading plan, and your six years are in third grade, so expect a probe on reading plans. If they were part of your work, say how they were made and what part was yours; if there was no such plan, or it was not yours, say so plainly and return to the nearest thing above | F6 holds your reading material and is where this belief presses. VAL because the theme is a published belief; the slot is raised by that belief |
| D2 | "Families Are Partners is another of our beliefs. Tell me about a time you worked with a family to help their child." | VAL | [grounded] "I write a weekly email to families." | Story-mapped on one sentence: "I write a weekly email to families." Say it at that scope. Answer slot: the belief is that each teacher speaks with every family each term, so expect a probe on conversations as well as emails. If you spoke with families beyond the email, say how and how often, in your own words; if you did not, or it was not part of how your school works, say so plainly and stay with the email. For a specific family story, choose a real instance with a named stake and an ending you can describe truthfully; if none comes to mind, say so plainly and use the email | F5 is the row for this belief. VAL because the theme is a published belief |
| D3 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it. How do you use assessment results with your own students?" | VAL | [grounded] | No sentence of yours speaks to assessment, so the pack gives you no story. Answer slot: if you used assessment results to change what you taught next, say what you looked at and what you changed, in your own words; if you did not, or it was not your call, say so plainly, and say how you would start, as a plan, inside the district's own line. Name no assessment tool or data practice you have not used | F7 and F8 are silent rows and the belief is published, so the probe is likely. VAL because the theme is a published belief, with JD content |

### Bank E — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through your journey. How did you get here?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years."; "I write a weekly email to families." | A 90-second arc whose beats are your sentences: six years teaching third grade at a public elementary school in Joliet, the curriculum move, the club, the weekly email, each at its own scope. Why you came to teaching, and why fourth grade now, are yours to say in your own words; the pack has nothing on either. End on why this school, not on a summary | The opening question is the one every panel asks, and F2, F4, F5 and F6 hold your sentences. EXP because it tests your own account of your path |
| E2 | "Tell us about your Illinois license — what's it endorsed for, and how long does it run?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it in the quote's own terms: Illinois Professional Educator License, Elementary Education endorsement for grades 1–6, registered and active through June 30, 2029. Keep it to that. Have your license record to hand in case HR asks, because the pack has not checked it | F1 is the invite's stated requirement and a panel can confirm it in one question. JD because it scores the stated requirement |
| E3 | "What are you working on in reading with your students right now?" | EXP | [grounded] "I've run the after-school reading club for the last two years." | If the club is what you want to talk about, say it at the sentence's scope. Answer slot: the principal's published talk covers weekly reading conferences in grades 3 to 5, so expect a probe on conferences or small groups. If you hold them, say how, in your own words; if you do not, or it is not part of how your school runs reading, say so plainly and return to the club. Do not borrow her vocabulary for practice that is not yours | The casual register still scores reading practice; I3 is the raising source for the slot and F6 holds your sentence. EXP because it asks about current practice |

### Bank G — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through your part in your grade level's curriculum move." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Start with the sentence: "I led our grade level's move to a new reading curriculum in 2024." Then attribution in your own words: which parts were yours and which were others', said specifically. Where you do not know how some part was decided, say that plainly rather than reconstructing it. Hold through two follow-ups by returning to what you actually did, and concede specifically where a part was not yours. No figure is in your material, so there is no number to defend | F4 and F6 both rest on this sentence, so it is the likeliest to be taken apart line by line. EXP because it tests attribution |
| G2 | "How many students are in the reading club, and how does a typical session run?" | EXP | [grounded] "I've run the after-school reading club for the last two years." | Answer slot: give a count and a session shape only as you actually know them. If the count varies or you do not know it, say so plainly; if there is no typical session, say that. Stay with the sentence at its own scope: "I've run the after-school reading club for the last two years." | F6 holds the club sentence, and a prober asks for the denominator. EXP because it tests whether the claim survives detail |

### Bank H — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over a teacher who's already taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years."; "I've never taught fourth grade and I've never been a team lead." | Pause and restate the question. Hold: the three sentences about your six years in third grade, the curriculum move and the club, each at its own scope. Concede: "I haven't taught fourth grade." Do not argue that you are better than someone who has; say what you offer and what you would do to learn the grade. Hold through two follow-ups by returning to those sentences, never by adding to them | A1 in its blunt form, drawn from F2, F3, F4 and F6. JD because it scores fit to the stated role, with Pressure delivery |
| H2 | "You say you led the move, but you've never been a team lead. Which is it?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never taught fourth grade and I've never been a team lead." | Pause and restate the question. Say both sentences exactly: "I led our grade level's move to a new reading curriculum in 2024." and "I haven't been a team lead." Do not bridge them with anything you did not say. If pressed, concede that your sentence says you led the move and does not say you held the role. Do not fold on either sentence to restore harmony | The seam in F4 between the two sentences, said bluntly. EXP because it tests attribution under pressure |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 license with elementary endorsement | E2 |
| F3 the Fourth Grade Teacher position itself | A1, H1, A4 |
| F2 plan and teach reading, writing, math, science and social studies | A5, E1 |
| F7 differentiate instruction using assessment data | D3, B1 |
| F9 keep clear classroom routines | B3 |
| F5 communicate regularly with families; each teacher speaks with every family each term | D2, B4 |
| F4 work with the grade-level team | A3, C1, C2, G1, H2 |
| F6 no student leaves third grade without a reading plan | D1, B1, B2, E3, G2 |
| F8 assessments inform teaching and never replace it | D3 |

## Reverse questions

Bring at least three of these; they are scored as preparation.

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You spent nine years as a reading specialist before becoming principal. What does that change about what you look for in how a fourth-grade teacher runs reading?" | Ties to her own path (I2) and turns the interrogation into a conversation between colleagues | [grounded] |
| R2 | "Your 2025 talk covered weekly reading conferences in grades 3 to 5. Is that something the fourth-grade team does here, and how does it fit into the week?" | Shows you read her public work (I3) and asks about the school's practice without claiming one of your own | [grounded] |
| R3 | "The board's literacy plan brings a new grades 3–5 reading curriculum from fall 2027. How is the fourth-grade team preparing, and where would a new teacher fit in?" | Shows homework on the district's published direction and asks where you would be useful | [grounded] |
| R4 | "What could a new member of the team do in their first month that would genuinely help you?" | The reciprocity question for the two peer teachers: it asks about their load, not only your needs | [generic] |
| R5 | "Each teacher here speaks with every family each term. How does the fourth-grade team do that in practice?" | Picks up a published belief and asks for the working detail you need before accepting | [grounded] |
| R6 | "What does the first term look like for a teacher who is new to the grade?" | Given F3, it is candid diligence that also tells you what support exists | [generic] |
| R7 | "What would a strong first year look like to you?" | Asks the panel to name the bar you will be judged on | [generic] |

## Prohibited claims

What this pack will not coach, and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated (F3) | The plain acknowledgment F3 gives: "I haven't taught fourth grade." Then a plan, said as a plan. No slot |
| Has been a team lead | Negative you stated (F3) | The plain acknowledgment: "I haven't been a team lead." Beside it, your sentence at its own scope: "I led our grade level's move to a new reading curriculum in 2024". No slot |
| Owned or set the school's or district's reading curriculum | Inflated form of F4 and F6 | The quote at its own scope. The limit is the pack's observation: your material says your grade level's move, not the school's or district's |
| Ran the school's reading program | Inflated form of F6 | The quote at its own scope: "I've run the after-school reading club for the last two years." The material says the club |

## Sources

**Provided documents:** the interview invite and your resume text (identifiers in it were not used). No dossier was present, so none was consumed and the pack was built from raw inputs.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District values` | yes | The three beliefs by name, from the official page; they are the raising sources for bank D and rows F5, F6 and F8 |
| 2. `Orrinsford Community School District interview process teacher` | yes | Loop structure: one 45-minute building panel of the principal and two grade-level teachers, with reading instruction, classroom routines and family work as panel topics. It establishes the loop, so no archetype fallback applies, and it names no values round, so no values cheat sheet is built |
| 3. `Orrinsford Community School District strategy` / recent news | yes | The Board's literacy plan, adopted August 2026: moved B2, A4 and reverse question R3 |
| 4. `Dolores Vantongeren Halvering Elementary School` | yes | The interviewer read (I1 to I3), the slots in B1 and E3, and reverse questions R1 and R2 |
| 5. representative `Fourth Grade Teacher` JD | yes | The requirements in F2, F4, F7 and F9, all `[inferred]`; no posting was supplied |

Searches sent, by query and what came back:

1. "Orrinsford Community School District mission values" — https://orrinsfordschools.example/about/mission-and-beliefs
2. "Orrinsford Community School District teacher interview process panel" — https://orrinsfordschools.example/careers/how-we-hire-teachers
3. "Orrinsford Community School District strategic plan news" — https://orrinsfordschools.example/news/board-adopts-literacy-plan (a search-result snippet, not fetched)
4. "Dolores Vantongeren principal Halvering Elementary School" — https://ilprincipalsforum.example/speakers/dolores-vantongeren (a third-party speaker page, snippet only, not fetched)
5. "Fourth Grade Teacher job description Illinois elementary school district" — https://k12jobsboard.example/listings/fourth-grade-teacher (a representative posting, snippet only, not fetched; its qualifications line was cut off and is not used)

Pages fetched: the district's Mission and Beliefs page and its How we hire teachers page. Both are undated; the literacy-plan item is dated August 2026.

## Upgrade menu

- The posting text for this opening → F2, F4, F7 and F9 move from `[inferred]` to `[grounded]` and the JD-tagged questions are re-keyed to the school's own wording
- The recruiter's or HR's prep email, covering focus areas and anything you were asked to prepare → a build section for any declared deliverable and a re-weighting of the banks
- The names of the two fourth-grade team members → the interviewer read and persona assignments extend to them, with a reverse question tied to each public path
- Your own answers to the answer slots in F2, F5, F6, F7, F8 and F9, stated outside a drill → each row quotes them, and the matching questions move from slots to story-mapped guidance
- A copy of your license record from the state's educator licensing system → F1 confidence moves from medium to high, since a license record is the inspectable artifact in a regulated trade
- How many days you have to prepare → a prioritized schedule sized to your time
- A tuesday-dossier.md from an earlier underwriting run → verified evidence upgrades story-mapping, an evidence-derived highest-ROI objection, and binding prohibited claims; an enhancer, never a requirement
