I'm reading the skill's remaining reference files before I build your prep pack. Your invite also has a warning sign, so I'll flag that first.
Before the prep, one thing in the invite: it says your process is "carried out entirely on Telegram" and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern. It asks only for a time so far. But if offer and onboarding stay in the chat, any later request for documents, payment or bank details would arrive there too. Until you've checked who sent it, hold off on paying anything, depositing a cheque, or sending documents or bank details. Check with the employer using contact details you find yourself on its own website or careers page, since you applied there, and never through this chat. The invite may not come from who it names. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/alone/part-5/rooms/case-10-denied-e6681057/lumenvale-software_customer-support-specialist_interview_pack.md`. It assumes one text chat with the support team lead. Web search was refused here, so it holds nothing about Lumenvale beyond your invite; the Sources section lists the three refused calls. The question to rehearse first is A1, about moving from energy into software. A3, on escalations, comes second.

- **Drill:** I can play the support team lead and run any question live, with feedback against the pack's guidance, if you want a rehearsal.
- **Dossier:** I can write a `tuesday-dossier.md` from this pack's findings, if you want one.
- **Word version:** I can convert the pack to .docx whenever you're ready.

Can you paste the full job ad text, or say skip and I'll leave the pack as it is?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

**Interviewer:** the support team lead, unnamed. **Format and relationship:** one text chat on Telegram, as the invite describes it. The pack treats the lead as a manager-type interviewer.

**Assumption this pack is built on:** a single session with the support team lead, with no further rounds known. If there are more rounds, or the lead is a peer rather than your future manager, the persona weights change.

## How to use this pack

Personas are how a question is asked. Types are what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your CV and message claims survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you did homework on the company |
| CASE | How you structure a live problem from the role |

An answer slot is an instruction for the interview. It asks nothing of you here.

## Fit snapshot

The requirements are the job ad as you relayed it in your message. The full ad text was not supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as you relayed it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe on what the job involved. Lead in the quote's own terms: three years as a customer service advisor at an energy supplier. The ad says customer support and your line says customer service advisor, so give the title you held |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as you relayed it | "I use Freshdesk every day" — your message | medium | [grounded] | none | The quote already reaches the requirement in its "similar ticketing tool" form. Say Freshdesk by name and keep its scope, every day. The ad's named tool is another one and your material says Freshdesk, so the pack makes no claim about the other. Expect a probe on what you do in Freshdesk. Answer slot: name what you actually do in it, in your own words; if you use it more narrowly than the interviewer's tool, say so plainly and return to Freshdesk every day |
| F3 | "clear written communication" — job ad, as you relayed it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Answering calls and emails is not by itself clear writing, and the bridge should not be stretched. The words stay at the quote's scope: "I was answering around 60 calls and emails a day", with the 60 covering calls and emails together. Answer slot: the ad's written-communication line makes a probe on your emails likely. If you have a way of checking that a reply is clear, or if anyone reviewed your emails, say what, in your own words; if there was no such step, say so plainly and stay with the calls and emails you answered. The interview is itself a text chat, which makes your typed answers a live sample of this requirement |
| F4 | "confidence handling escalations" — job ad, as you relayed it | none given | none | [grounded] | discovery | Your material does not show escalations either way. Answer slot: if you have handled an escalation, say what happened, who it went to and what part was yours, in your own words; if your role had no escalation step, or it was not yours, say so plainly and return to the calls and emails you answered. The pack supplies no escalation story |
| F5 | Familiarity with a software company's product and customers — role-family requirement, not stated in the ad as you relayed it | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. Never a claim to software-company experience, and nothing added to make the gap feel smaller |
| F6 | No requirement in the ad as you relayed it; you offered this | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | Usable for open prompts about teaching and teamwork. Keep its scope: four new starters, the refunds process, last year. A CV-style line with nothing inspected behind it, so expect a probe on how the training went |

## Persona table

The weights rest on the invite's account of one session and on this skill's manager-type prior, not on any documented Lumenvale process, because the research calls were refused (see Sources). Depth follows weight.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of F5 and F4: the energy-to-software move and the escalations you have not described | High. A manager-type interviewer buys capability and derisks gaps, and F4 and F5 are the thin rows. 5 questions | Rehearse the A1 objection until it is boring. Acknowledge the limit first, then give a plan, never a past |
| B. Case / Strategist | Live support problems: an angry customer, an unknown product answer, a threat to cancel | High. Same prior, and a text chat lets the interviewer set a problem and read your typed reply. 5 questions | Clarify, state the objective, structure, then the reply and the handoff. Say your reasoning in the chat as you go |
| C. Conversational | Friendly opener, tools, teaching, why Lumenvale | Medium. Chat interviews often open loose, and casual questions are still scored. 4 questions | Prepare a 90-second arc built only from your quoted sentences; treat casual questions about the JD's topics as scored |
| D. Data-Driven Prober | Probing the 60-a-day figure and Freshdesk use | Medium. F3's figure is the only number in your material, and numbers draw follow-ups. 3 questions | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| E. Pressure | A short, time-boxed challenge on why you | Low. A typed chat gives an interviewer less room to interrupt, and the manager-type prior does not lead with pressure. 2 questions | Pause, then hold what your quotes carry through two follow-ups before conceding anything real |

Not weighted: Peer Evaluator (no peer is named; B5 touches handoffs) and Values (no values-style round is detected, since the invite names none and no company page was read).

## Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your background is energy, not software. How would you get up to speed on our product?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "I've never worked for a software company"; "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Name the limit before it is asked for: "I've never worked for a software company." Then give your first-weeks plan in your own words, as a plan: what you would learn first and how you would ask for help. Follow-up one, "what makes you think you'll cope", holds only what the quotes carry: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Follow-up two, "what if you can't find the answer", gets a concession: product knowledge is something you would be learning, and your plan says who you would ask. Hold the acknowledgment through both and add no past experience to it | F5 is the likeliest objection to this candidate and the one the candidate raised; F1 and F2 are what the hold rests on. EXP because it tests what the background actually is |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Pick the part that is actually true for you; do not choose a safe one. The material points to product knowledge (F5) and, as a slot, escalations (F4). Name it, then say how you would close it, as a plan. If no weakness comes to mind, say so plainly, then give the nearest thing your material carries: your daily Freshdesk use, in those words | The Skeptic stem, aimed at the rows where your material is thin; JD because it scores the whole listed job |
| A3 | "Tell me about a time you handled an escalation." | JD | [grounded] "answering around 60 calls and emails a day" | A selection scaffold, because no quote carries an escalation story. Pick a time something went beyond what you could resolve in the first contact. It needs a named stake, what you did and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "answering around 60 calls and emails a day", or how you would handle it. Second only to A1 in rehearsal value | The ad's escalation line is the one requirement with no evidence behind it (F4), so this arrives in some form; JD because it scores a stated requirement |
| A4 | "How do you make sure a written reply is clear?" | JD | [grounded] "answering around 60 calls and emails a day" | Answer slot: if you have a way of checking a reply before sending, say what, in your own words; if you have no set method, say so plainly and return to "answering around 60 calls and emails a day". Do not describe a checking step you do not use | F3's written-communication line, asked as a method; the guidance does not adopt the premise that you have one |
| A5 | "Why move from energy into software support?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "I've never worked for a software company" | Give your own actual reason, in your own words; the pack supplies none and any reason you did not give would be one you cannot stand behind. Keep it short, forward-looking and consistent with A1's acknowledgment | A motivation-consistency probe sits next to F5; EXP because it tests whether your story holds together |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes in furious: they were charged twice and want the money back now. Walk me through your reply." | CASE | [generic] | Structure it: what you would check or ask first, what the first two lines of your reply say, what you would do about the charge, what you would record, and when you would hand it on. The question needs no claim about your past, so the guidance makes none | A live billing problem for a written-support role (F3's requirement), asked as a decision; generic because it is a pattern for the problem, not a fact about this employer |
| B2 | "A customer asks something about the product and you don't know the answer. What do you do?" | CASE | [generic] | Say it aloud as steps: be honest with the customer that you are checking, find the answer through the team's own sources or a colleague, tell the customer when to expect it, follow up, and note the answer for next time. No claim about your past | Probes F5 without asking about your history; CASE because it scores reasoning under a knowledge gap |
| B3 | "A customer says they'll cancel and leave a bad review unless this is fixed today. What now?" | CASE | [generic] | Separate what is yours to decide from what is not. Give the customer a clear next step and a time, hand on with full context where it is not yours, and follow up. Hold your structure through one challenge and concede plainly what you could not promise. No claim about your past | The escalation requirement (F4) as a live decision, so it can be rehearsed without a story you do not have |
| B4 | "Write the first two lines of a reply to a customer who has been waiting three days." | CASE | [generic] | Acknowledge the wait plainly, say what you are doing next and by when, and do not blame another team. Keep it short enough to read on a phone. Expect to type it live, so practise writing it in one pass | F3's requirement tested directly; in a text chat, your typed reply is the sample |
| B5 | "When something is beyond what you can fix, what do you want a handoff to contain?" | CASE | [generic] | Principles, not a claimed practice: what the customer asked, what has been tried, what the customer has already been told, and what happens next. Add what a receiving colleague would need so they never ask the customer to repeat themselves | Covers escalation handoffs (F4) and the collegial seam a team lead cares about |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey. How did you get here?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "I trained four new starters on our refunds process last year" | A 90-second arc with only the beats the quotes state: three years as a customer service advisor at an energy supplier, then last year the four new starters on the refunds process. Why this role next is your own reason, in your own words | F1 and F6 are the only career beats in the material; EXP because it sets the story every later probe returns to |
| C2 | "What do you use day to day for tickets, and what do you like about it?" | JD | [grounded] "I use Freshdesk every day" | Say Freshdesk and "every day". What you like about it is your own view, in your own words. Answer slot: if you use particular parts of it, name them; if your use is narrower than that, say so plainly and return to "I use Freshdesk every day" | F2, asked casually; casual questions on the ad's named tool are scored |
| C3 | "Tell me about something you've taught someone at work." | VAL | [grounded] "I trained four new starters on our refunds process last year" | The beats the quote states: four new starters, the refunds process, last year. Answer slot: how you went about it is yours to say; if you did it, say how in your own words; if you took part in a different way, say so plainly and return to the four new starters and the refunds process | F6 is the only teaching evidence; an open prompt from a conversational interviewer is common, and VAL because teaching others is a behaviour question |
| C4 | "Why Lumenvale?" | CO | [generic] | A selection scaffold. This pack holds no facts about Lumenvale, because the research calls were refused. Read what the company publishes on its own website, then give one honest, specific reason in your own words. If no reason comes to mind, say so plainly and say what you hope to learn about the company | The company-knowledge slot; generic because nothing about Lumenvale was established |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You answer around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot for the four defend-the-number questions: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Say each in your own words; where you do not know how it was counted, say so plainly. Keep the 60 attached to calls and emails together | F3's figure is a magnet target; EXP because it tests attribution and counting |
| D2 | "How many of those were calls and how many emails?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot: if you know the split, say it in your own words; if you do not, say so plainly and keep to "around 60 calls and emails a day". Do not estimate a split you cannot repeat under a second question | A natural second-level follow-up on F3; the pack supplies no split |
| D3 | "What do you actually do in Freshdesk?" | JD | [grounded] "I use Freshdesk every day" | Answer slot: name what you actually do in it, in your own words; if you use it more narrowly than the question assumes, say so plainly and return to "I use Freshdesk every day". Do not borrow feature names you have not used | F2's depth probe; JD because it scores the ticketing-tool requirement |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I've never worked for a software company" | Hold-then-concede. Pause, restate the question, and hold on what the quotes carry: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Hold through two follow-ups, then concede one thing plainly: "I've never worked for a software company." Do not claim an advantage you have not shown | F5 under time pressure; the held position is only what F1 and F2 carry |
| E2 | "That 60-a-day figure. How much of it was actually you?" | EXP | [grounded] "answering around 60 calls and emails a day" | Hold the sentence as written: "I was answering around 60 calls and emails a day." Answer slot: if any share of those was not yours, or the figure was a team average, say so plainly and keep to your own part | The attribution stem on F3; EXP because it tests what was actually the candidate's |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| "2+ years in customer support" | C1, A5, E1 |
| "experience with Zendesk or a similar ticketing tool" | C2, D3 |
| "clear written communication" | A4, B1, B4 |
| "confidence handling escalations" | A3, B3, B5 |
| Software company familiarity (role-family, not in the ad as relayed) | A1, A2, B2, E1 |
| Your offered teaching evidence | C3 |
| Company knowledge | C4 — generic; no company facts were established |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| 1 | "What does a good first 30 days look like for someone coming from outside software?" | Names your gap yourself and asks for the ramp, which turns A1 into a plan |
| 2 | "Which tools does the team use for tickets and chat, and how is product training handled?" | Shows you are thinking about the tool requirement and about learning the product |
| 3 | "How does the team decide what gets escalated, and who it goes to?" | Shows you treat escalation as a process, which answers the F4 requirement without a claim about your past |
| 4 | "How does the team judge a good written reply?" | Ties to the written-communication requirement and tells you what the bar is |
| 5 | "What makes someone struggle in this role in the first three months?" | Invites candour and signals you want to avoid those failure points |
| 6 | "Is there a company email address or a contact on the careers page I can use to confirm the next steps and how offers and onboarding are handled?" | A legitimate employer can answer this easily, and it gets you a verification route that does not run through the chat |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has software-company or SaaS support experience | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |
| Has used the ad's named ticketing tool | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day". The limit is the pack's observation: your material says Freshdesk |
| Answered 60 tickets or 60 emails a day | Inflated form of F3 | F3's quote at its own scope: "answering around 60 calls and emails a day", with calls and emails together. D1 and D2 stay inside it |
| Designed or led the refunds training | Inflated form of F6 | F6's quote at its own scope: four new starters, the refunds process, last year. C3's slot asks only how you went about it |

## Sources

Provided documents: your message, containing the pasted Telegram invite and your background. No dossier was present. The full job ad text was not supplied.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Query sent | What came back |
|---|---|
| `Lumenvale Software values` | refused |
| `Lumenvale Software interview process customer support specialist` | refused |
| `Lumenvale Software strategy news` | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Would have named any published values for VAL questions. No values-style round is detected without it, so section 10 is dropped |
| 2. `Lumenvale Software interview process customer support specialist` | unavailable | Would have documented the loop. Persona weights rest on the invite's one session instead |
| 3. `Lumenvale Software strategy` / recent news | unavailable | Would have fed the CO bank; C4 is generic |
| 4. Interviewer name and company | n/a | The support team lead is unnamed, so there was no query to form; the interviewer read is absent |
| 5. Representative `Customer Support Specialist` JD | skipped | The requirements you relayed fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full job ad text → the four requirement rows, now quoted from your summary, become quoted from the ad itself, and any requirement you did not relay gets a row and a question
- Time zone, hours, pay and right-to-work terms from the ad or the recruiter → gate rows in the fit snapshot, which this pack could not build from your material
- The support team lead's name and public professional profile → an interviewer read, persona weights adjusted to their career pattern, and a reverse question tied to their path
- Your own answers to the slots in F2, F3, F4 and C3, written outside a drill → those rows become story-mapped answers instead of scaffolds
- Any other ticketing tools you have used, named exactly as you would say them → F2
- An appraisal, quality-score summary or similar record from your employer → F1 and F3 can rise from medium and low confidence, because something inspectable stands behind them
- The company's own published values or principles page, pasted → a values cheat sheet and VAL questions mapped to your quoted sentences
- Web search allowed in this session → a research pass over values, loop and strategy; a deeper one adds up to 6 more searches and 2 more fetches, several more minutes
- How much prep time you have → a prioritized schedule built from this pack
- A tuesday-dossier.md → verified evidence and a prohibited-claims list from a prior evaluation, never a precondition for this pack
