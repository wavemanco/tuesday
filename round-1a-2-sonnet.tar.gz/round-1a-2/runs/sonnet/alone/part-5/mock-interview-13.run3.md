Your prep pack is saved as `quillmoor-diagnostics_operations-coordinator_interview_pack.md`. I built it for the recruiter screen with Hannah Lowther, using her message, the advert and your notes. Search permission was refused on all four lookups, so it has no company research, no values section and no read on Hannah. The upgrade menu at the end of the pack lists what each of those would add.

The question to rehearse most is B1, "Which part of this job would you be weakest at on day one?" Your material shows delivery scheduling and supplier chasing, but not production scheduling or SAP.

Say the word and I'll play Hannah on B1, starting friendly and tightening into the Skeptic.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What is your notice period? It's the one term your material doesn't settle, and it fills the answer for A3.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, Thursday 2pm, 30-minute phone call. Hannah Lowther (Talent Partner) rings the mobile number on your application.
**Her stated agenda:** salary expectations, notice period, how the hybrid pattern would work for you, and what is prompting a move. Then she tells you about the team and next steps.
**Built for:** Sam.

## How to use this pack

- Personas describe how a question is asked. Types describe what it is scored on.
- Type key: **VAL** is behaviour against the company's published values. **EXP** is whether your experience survives scrutiny. **JD** is a stated requirement of the job. **CO** is company and strategy knowledge. **CASE** is a live problem from the role.
- Guidance is scaffolding, not a script. Say it in your own words.
- An answer slot is an instruction for the interview, not a question for you now. Answer it from what is true, and use the plain branch when the practice was not yours or did not exist.
- **The highest-ROI prep in this pack is B1**, the weakest-part-on-day-one question. Rehearse it until it is boring.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says deliveries to three depots and chasing suppliers, not production schedules, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert puts planning, the warehouse and QA at the centre of the role, so expect a probe on which teams you worked with. If any of those teams were ones you worked with, say how, in your own words; if none were, or the scheduling was not yours to coordinate across them, say so plainly and stay with the deliveries |
| F2 | "track supplier deliveries and chase late orders" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | presentation | Lead with the chasing in the quote's own terms: "I chase suppliers when orders slip." The quote carries scheduling and chasing, and shows no tracking method, so none is described |
| F3 | "keep stock records accurate" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | presentation | Say it as you said it: "I rebuilt our stock-count spreadsheet, and discrepancies fell by about a third over a year." Keep "about" and keep "over a year". The figure draws the defend-the-number probe in C1: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours |
| F4 | "report weekly on on-time dispatch" — the advert | none given | none | [grounded] | discovery | Your material does not show weekly reporting. Answer slot: the advert's weekly dispatch line makes a probe likely. If you report on deliveries or dispatch, say what and how often, in your own words; if you do not, say so plainly and say how you would start |
| F5 | "2+ years in operations or logistics coordination" — the advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on it. Lead with the title and employer in the quote's own terms, because a named role beats an adjective |
| F6 | "confident with Excel" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The quote says a spreadsheet, and your material does not say which tool. Answer slot: the advert asks for confidence with Excel, so expect a probe on what you do in it. If the stock-count spreadsheet was in Excel, say what you did in it; if it was another tool, or your Excel use is more limited than the advert reads, say so plainly and stay with the rebuild |
| F7 | "ERP experience (SAP or similar) a plus" — the advert, the SAP half | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used SAP." Then how you would learn it, said as a plan and never as a past. The advert lists ERP experience as "a plus" |
| F8 | "ERP experience (SAP or similar) a plus" — the advert, the "or similar" half | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | discovery | Your material says an in-house stock system and does not show whether it does what an ERP does. Answer slot: the advert's "or similar" makes a probe likely. If you work in the in-house system directly, say what you do in it; if it differs from an ERP, or your use of it is limited, say so plainly and stay with the system as you described it |
| F9 | "£38,000–£44,000" — the advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | No gap: your own number, in your own words, and it sits inside the advert's range. The quote says hoping, not a minimum, and the words stay at that |
| F10 | "two days a week at our Avonmouth site in Bristol" — the advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | No gap on the advert's two days, and your limit is stated: "I wouldn't want more than three." Keep both halves together, as you said them |
| F11 | "your notice period" — Hannah Lowther's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. Surfaced here and not bridged |
| F12 | "what's prompting a move" — Hannah Lowther's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | No gap: say it in the quote's own terms, the office closing, the only offer being Reading, which you don't want. The quote gives no reason beyond that, and none is added |

### Requirement coverage

| Requirement | Questions |
|---|---|
| Production schedules across planning, warehouse and QA (F1) | B1, E1 |
| Track supplier deliveries and chase late orders (F2) | C2, E1 |
| Keep stock records accurate (F3) | C3, C1, E2 |
| Weekly on-time dispatch reporting (F4) | B4, E3 |
| 2+ years in operations or logistics coordination (F5) | B3, A1 |
| Confident with Excel (F6) | C4 |
| ERP experience, SAP or similar (F7, F8) | B2, B1 |
| Salary (F9) | A2 |
| Hybrid pattern (F10) | A4 |
| Notice period (F11) | A3 |
| What is prompting a move (F12) | A5, B5 |

## Persona table

The loop beyond this call is not established by any source: Hannah's message describes only this call. The fallback is the Generic archetype, so weights beyond this call are flat. The weights below are for Thursday's call.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport | Friendly, structured around her four topics, then the team and next steps | high: the recruiter-screen prior is conversational with logistics, and her message lists four logistics topics | A 90-second arc built only from your quoted sentences (A1). Treat each casual logistics question as scored. Give your own figures and reasons |
| B. Skeptic | Quiet probing of gaps and motive, in a friendly register | high: the recruiter prior is a light skeptic, and this material's gaps (F1, F4, F7) sit against lines the advert states | Rehearse B1 until it is boring. Concede the stated limit plainly and return to what you said |
| C. Data-Driven Prober | Reads the application closely and asks how the figure was counted | medium: a recruiter may touch the one-third figure lightly, and a hiring manager is likelier to press it | Know what you can and cannot say about how it was counted, and say plainly when you do not know |
| D. Pressure | Time-boxed, devil's advocate | low: nothing in Hannah's stated agenda suggests it, so this is insurance | Pause, restate, hold the position through two follow-ups, concede only what is specific |
| E. Case / Strategist | A live problem from the role | medium: Hannah's agenda has no problem-solving item, but the advert's tasks are practical enough that a later round may use one | Clarify first, then structure, then answer. Think aloud |

## Question banks

### A. Conversational / Rapport (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey so far." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Story-mapped on F5, F1 and F3, three beats, each the quoted sentence's own and no more: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies down by about a third over a year. Tell them in your own words in about 90 seconds, then close on why you are looking, as A5 has it | The biography question opens most recruiter calls and is scored; F5, F1 and F3 are the evidence it draws on. EXP because it tests whether the application's claims hold in your own voice |
| A2 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot, filled by your own figure: say "I'm hoping for £42,000", the number first. The advert's range is £38,000–£44,000, so you are inside it. If asked what you earn now, give your own answer or say you would rather talk about this role's range. The pack supplies no figure and no history | Hannah listed salary expectations first; F9 is your own stated figure at its own scope. JD because the advert states the range |
| A3 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, in your own words. If you do not know the exact figure, say so plainly and say you will confirm it | Hannah named notice period; F11 is a term your material does not establish, so the row carries no words for you. JD because it is a term of the offer |
| A4 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot, filled by your own words: two days at Avonmouth is fine, and your limit is three, "I wouldn't want more than three." Keep both halves together and do not fold them into "flexible". The reason you gave is living in north Bristol, which is as far as the quote goes. Answer slot: if she asks how you would get to Avonmouth, answer from your own arrangements, or say plainly you have not worked that out | Hannah named the hybrid pattern; F10 carries your stated limit. JD because the advert states two days at Avonmouth |
| A5 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Logistics slot, filled by your own reason at its own scope: the Bristol office is closing next year, the only offer is relocating to Reading, and you don't want that. Say it plainly, about the circumstance, and stop. Add no reason beyond the ones you gave me. If asked why not Reading, "which I don't want" is what you have said; add more in your own words only if it is true | Hannah named it; F12 is the evidence. EXP because it scores whether the motive story is consistent across the call |

### B. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." "Never used SAP — we run our own in-house stock system." | Highest-ROI rehearsal in the pack. Name your weakest area first, before you are pushed. Your material carries delivery scheduling and supplier chasing, and does not carry production schedules (F1) or SAP (F7), so pick one. If SAP: "I've never used SAP", then how you would learn it, said as a plan in your own words and never as a past. If production schedules: start from what the quote carries, "I schedule deliveries for our three depots." Answer slot: if you have worked with planning, warehouse or QA teams, say how; if not, or the scheduling was not yours across them, say so plainly and stay with the deliveries. Follow-up 1, likely: "And how would you close that?" Answer as a plan, never as past work. Follow-up 2, likely: "What if that takes longer than you expect?" Hold by returning to what you said, never by adding to it, and concede only the specific limit | F1 and F7 are where the advert presses hardest on this material, so this question arrives in some form. JD because it scores the advert's own list; this is the deepest rehearsal for that reason |
| B2 | "What experience do you have with SAP or a similar ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Open with the stated negative: "I've never used SAP." Then describe the in-house stock system as you described it to me, "we run our own in-house stock system." Answer slot: if you work in it directly, say what you do in it; if it differs from an ERP, or your use of it is limited, say so plainly. Do not call it an ERP | F7 is the stated gap and F8 is the open half of "or similar". JD because the advert lists it as a plus |
| B3 | "The advert asks for 2+ years in operations or logistics coordination. How does your background line up?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." | State it in the quote's terms, then stop: four years as a logistics coordinator at a building-supplies wholesaler. The advert says operations or logistics coordination and the quote says logistics coordinator, so say the title you held and let her draw the match | F5 is the row that meets the advert's years requirement. JD because it scores a stated requirement |
| B4 | "The role reports weekly on on-time dispatch. What's your experience with that kind of reporting?" | JD | [grounded] | No quote of yours speaks to reporting, so this is an answer slot: if you report on deliveries or dispatch, say what and how often, in your own words; if you do not, say so plainly and say how you would start. Do not borrow the spreadsheet figure for it | F4 has no evidence behind it, so the honest form is a slot. JD because it scores a stated responsibility |
| B5 | "Why Quillmoor, and why this role?" | CO | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Two parts. "Why now" is covered by A5. "Why here" is an answer slot: what in the advert drew you, which describes a "diagnostic-test manufacturer, about 400 staff" and a role coordinating between planning, the warehouse and QA, in your own words. If the honest answer is that the role fits what you do today, say that plainly. Look at the company's own site before Thursday so you can say something current, because this pack could not search | F12 covers why you are leaving and nothing covers why this employer. CO because it scores homework; this row stays at the advert's facts because research was not available |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've described discrepancies falling by about a third over a year. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Defend-the-number slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part of it was yours. Keep "about" and keep "over a year". Where you do not know how it was counted, say so plainly, and name the weakest assumption before she does | F3 holds the only figure in your material, and a figure is where a prober starts. EXP because it tests attribution and honesty about the number |
| C2 | "Tell me about a time you had to chase a late order." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Selection scaffold: your sentence carries the practice, not one occasion, so pick one order. It needs a named order, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I chase suppliers when orders slip", or how you would handle it | F2 is the evidence for the advert's chasing line. EXP because it asks for one instance of work you described in general terms |
| C3 | "What's your experience keeping stock records accurate?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Lead with the rebuild in the quote's own terms: "I rebuilt our stock-count spreadsheet." Answer slot: the advert asks for keeping records accurate, so expect a probe on upkeep. If upkeep was part of your role, say what you did, in your own words; if the rebuild was a one-off, or someone else kept the records, say so plainly and stay with the rebuild | F3 is the evidence for the requirement. JD because it scores a stated responsibility |
| C4 | "How confident are you with Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: say what you did in the stock-count spreadsheet, in your own words. If it was built in Excel, say so; if it was built in another tool, or your Excel use is more limited than the advert reads, say so plainly and stay with the rebuild | F6 is low confidence because the quote names a spreadsheet and not the tool; the label is `[inferred]` for that derivation. JD because it scores a stated requirement |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold-then-concede. Pause, restate the question, then hold only what the quotes carry: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies down by about a third over a year. Hold through two follow-ups by returning to those sentences, never by adding to them. Concede specifically: "I've never used SAP." Do not fold on the rest | F5, F1 and F3 are the evidence a time-boxed answer can use. EXP because it tests composure over the stated record |
| D2 | "That result. How much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold what the quote says is yours: "I rebuilt our stock-count spreadsheet." Answer slot: which part of the fall was yours, in your own words; if others contributed to it, or you do not know how it came about, say so plainly and return to the rebuild. Hold through two follow-ups and concede the specific you do not know, never the whole claim | F3 holds the figure, so the attribution probe is aimed here. EXP because it scores attribution under pressure |

### E. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "On Monday a supplier tells you a delivery that production needs on Friday will be a week late. What do you do first?" | CASE | [generic] | Structure it aloud. Clarify first: what the late delivery holds up, what stock is on hand, and what the supplier can offer, such as a part delivery. Then who needs to know, the advert's three being planning, the warehouse and QA. Then your options, and what you would record. Challenge one premise, such as whether Friday is fixed. The question needs no claim about your past, so the guidance makes none | A live problem built from the advert's supplier-chasing and scheduling lines (F1, F2). CASE because it scores structure; `[generic]` because it is a pattern for the problem and not a fact about this employer |
| E2 | "The system says there are more units of an item than are on the shelf. How do you work out what happened?" | CASE | [generic] | Structure it aloud. Clarify scope: one item or several, and how the count was taken. Check recent movements and the count itself before assuming a loss. Decide what to adjust and who should agree it, and record the cause. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's stock-records line (F3). CASE because it scores reasoning from a discrepancy; `[generic]` because it is a pattern |
| E3 | "We want a weekly report on on-time dispatch. What would you want to know before building it?" | CASE | [generic] | Structure it aloud. Ask what counts as on time and measured against which date, where the data comes from, who reads the report and what they decide from it, and how often. Then propose a shape. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's reporting line (F4), asked as a design question. CASE because it scores clarifying before building; `[generic]` because it is a pattern |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which teams does the Operations Coordinator work with most day to day, and how is the work split between planning, the warehouse and QA?" | It follows the advert's own line and shows you read it; the answer tells you what F1 will mean in practice |
| R2 | "Which stock or ERP system does the team use, and how is someone new to it trained?" | It raises the ramp-up on the system without reopening F7, and it is a practical question about the job |
| R3 | "What does the weekly on-time dispatch report look like today, and who reads it?" | It ties to F4 and treats the report as something you would pick up, which is the stance B4 rehearses |
| R4 | "Are the two Avonmouth days fixed days or agreed with the team?" | It follows A4 and checks the pattern against the limit you stated in F10 |
| R5 | "What would a good first three months look like in this role?" | It asks for the measure of success in the interviewer's terms, and the answer feeds B1 |
| R6 | "What are the next steps after this call, and who would I meet next?" | It confirms what Hannah said she would cover and tells you which persona weights to change for the next round |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says deliveries to three depots and chasing suppliers, not production schedules. B1's slot stays inside the deliveries |
| Has used SAP | Negative you stated, F7 | The plain acknowledgment F7 gives: "I've never used SAP." No slot |
| Has ERP experience through the in-house stock system | Inflated form of F8 | F8's quote at its own scope. The limit is the pack's observation: the material says an in-house stock system and does not show whether it works as an ERP |
| Advanced Excel skills | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: the material says a stock-count spreadsheet, not the tool or what was done in it |
| The rebuild alone produced the fall in discrepancies | Inflated form of F3 | F3's quote at its own scope: the rebuild, and a fall of about a third over a year, as two statements you made. D2's slot asks only which part was yours |
| Reports weekly on dispatch today | Inflated form of F4 | There is no quote, so no words are given. B4 is a slot, and either branch is honest |
| £42,000 is my minimum | Inflated form of F9 | F9's quote at its own scope: "I'm hoping for £42,000." |
| Happy with any number of office days | Claim your quote contradicts, F10 | F10's quote alone: "I wouldn't want more than three." |
| A reason for leaving beyond the office closing | Inflated form of F12 | F12's quote at its own scope. The pack's observation is that no other reason was given |

## Sources

**Provided documents:** Hannah Lowther's LinkedIn message (her words on format and topics); the advert as pasted; your notes about your background, quoted as "your message". No dossier was present, so none was consumed.

**Searches sent, all refused (permission to search was not granted):**

- "Quillmoor Diagnostics values" — refused
- "Quillmoor Diagnostics interview process operations coordinator" — refused
- "Quillmoor Diagnostics Avonmouth news strategy" — refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Every search was refused. It would have supplied the official value names for VAL-style questions and a values cheat sheet if a values round is documented. No values section is in this pack |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Every search was refused. It would have named the rounds after this call; persona weights beyond this call fall back to the Generic archetype |
| 3. `Quillmoor Diagnostics` strategy and recent news | unavailable | Every search was refused. It would have grounded a CO or CASE question in current strategy; B5 stays at the advert's facts |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Every search was refused. It would have supported an interviewer read and a reverse question tied to her path; both are absent |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → F11 stops being a gate row with nothing behind it, and A3 carries your own words
- Your answers to the slots in F1, F4, F6 and F8 → those rows become quoted stories in place of slots, and B1, B2, B4, C3 and C4 get stronger holds
- Permission to search → the four research targets above run, adding the company's published values, the loop after this call, current strategy for B5 and a Hannah Lowther read if a public profile is attributable
- A deeper research pass (L2) → up to 6 more searches and 2 more fetches, several more minutes, adding a strategy brief and recent organisation context for CO and CASE rows; offered once, run only if you say yes
- Hannah's next-steps description after the call → the Generic fallback weights are replaced by the real loop
- Prep time before Thursday → a prioritised triage tied to question IDs
- A `tuesday-dossier.md` from an earlier evidence review → verified evidence and per-gap strategy for F1, F4, F6 and F8; not needed to use this pack
