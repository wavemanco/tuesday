I'll read the reference files the skill points to before building the pack.
Your prep pack is saved and I'm sending you the summary now.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/alone/part-5/rooms/case-9-canned-b113ab86/Halvering-Elementary_fourth-grade-teacher_interview_pack.md`. I built it for one 45-minute panel with Principal Vantongeren and two fourth-grade teammates, using your invite and résumé text. I didn't have the job posting.

Your licence matches the invite's one stated requirement, so it isn't a gap. The pack's most likely question is "You've taught third grade for six years. What changes for you in fourth?" (A1). Your résumé says you've never taught fourth grade, so rehearse the plain fact, then your third-grade years, then a plan. The second likely probe is what "led" meant when you've never been a team lead (A2).

You pasted a Social Security number. Prep doesn't need it, so I didn't use it, and I'd leave it out of future messages like this. I also kept your licence number out of every search.

Say the word and I'll play the principal on A1, the question the pack names as your highest-ROI prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Do you have the full text of the posting? It would turn two of the fit rows from inferred to grounded, and I've proceeded without it.
2. Did HR or the principal mention focus areas, or ask you to prepare something like a sample lesson? That would add a build section.
3. Do you want a deeper research pass? It's up to 6 more searches and 2 more fetches, and takes several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering-Elementary_fourth-grade-teacher_interview_pack.md -----
# Interview pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Panel interview on Thursday, 45 minutes: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given). Built from your invite and your résumé text; no job posting was supplied.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

| Type | What it scores |
|---|---|
| VAL | Whether your past behavior shows the district's published beliefs |
| EXP | Whether what you have said about your work holds up under follow-up |
| JD | The job's stated or typical requirements, gaps included |
| CO | Whether you know the district's current direction |
| CASE | How you reason through a live classroom problem |

An answer slot is an instruction for the interview, not a question for you now. It names a probe that is likely, then gives two honest branches: say what you did, or say plainly that there was no such step or it was not yours.

## Fit snapshot

No posting was supplied. Requirements come from your invite, from the district's published beliefs, and from one representative fourth-grade listing found by search (not this district's posting). Rows built from that listing are `[inferred]` and written as plain prose.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate your material shows met, on a CV line with nothing inspected behind it. Say it as written: the licence, the endorsement, the expiry year. The record that would settle it is the state's own licence lookup, which is yours to run; the licence number stays out of this pack |
| F2 | Plan and teach reading, writing, math, science and social studies at fourth grade — a representative fourth-grade listing, not this district's posting | "Six years teaching third grade at a public elementary school in Joliet." — your CV; "I've never taught fourth grade" — your message | medium | [inferred] | transferability | The words: "I've never taught fourth grade." Then the other sentence at its own scope: six years teaching third grade at a public elementary school in Joliet. Your material does not say which subjects you taught, so the pack claims none. Answer slot: if you taught particular subjects to your third graders, say which, in your own words; if some belonged to another teacher, say so plainly and stay with the six years. What changes in fourth grade is a plan, not a past: say what you would learn first |
| F3 | "assessments inform teaching and never replace it" — Orrinsford Mission and Beliefs page | none given | none | [grounded] | discovery | Your material does not show whether or how you used assessments. Answer slot: the district's belief makes a probe on assessment likely. If assessment results ever changed what you taught, say what the results were and what changed, in your own words; if they did not, or it was not yours to decide, say so plainly and say what you would look at first |
| F4 | "no student leaves third grade without a reading plan" — Orrinsford Mission and Beliefs page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years." — your CV | medium | [grounded] | transferability | Both sentences are reading work, and the pack's observation is that they say a curriculum move and a club, not plans for individual students. Words: those two sentences at their own scope. Answer slot: the belief makes a probe on reading plans likely. If you wrote or kept reading plans for students, say what they held and who set them; if there were none, or they were not yours, say so plainly and stay with the move and the club |
| F5 | "each teacher speaks with every family each term" — Orrinsford Mission and Beliefs page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | The sentence says an email, and the pack's observation is that it does not say conversations. Words: "I write a weekly email to families." Answer slot: expect a probe on what happens after the email goes out. If any family wrote back or asked for more, say what you did next, in your own words; if none did, or nothing followed, say so plainly and stay with the weekly email |
| F6 | Work with the grade-level team — a representative fourth-grade listing, not this district's posting | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead." — your message | medium | [inferred] | presentation | The first sentence is the whole of it, said at its own scope, with the second beside it as your own plain limit: "I've never been a team lead." The pack adds nothing about what the move involved |

## Reading the interviewer

Public professional footprint only. Only Principal Vantongeren has a footprint in the material; the two team members have none here.

| Fact | Source | Provenance | What it means for you |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | Illinois principals forum speaker page | [grounded] | Reading instruction is her native ground; expect depth on reading, not only fit |
| 2025 forum talk "Small Groups, Big Readers" on weekly reading conferences in grades 3 to 5 | Same page | [grounded] | Her recurring theme is reading conferences in your grade band; C3 rehearses it as a live problem |
| Shared vocabulary: reading | Her path above, beside F4's evidence | [grounded] | Use your own words for your own work: "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years." Let her draw the connection; do not claim a shared path |

## Persona table

The invite documents one 45-minute panel, so persona weights follow the three people named rather than an archetype. Principal: hiring-manager priors (Case/Strategist plus Skeptic), adjusted toward reading by her public talk. Two fourth-grade teammates: peer priors (Peer Evaluator plus Data-Driven Prober). The blend puts the Skeptic first.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the two limits in your own material | High. You stated "I've never taught fourth grade" and "I've never been a team lead", and the role is fourth grade | Rehearse the first objection until it is boring: the plain fact, your one sentence of adjacent work at its own scope, then a plan |
| B. Peer Evaluator | The two teammates: what you add to their team, where the seams are, credit | High. The invite names two members of the fourth-grade team | Reciprocity: what you bring and what you would ask; offer seam principles, not claims to know their seam |
| C. Case/Strategist | A live classroom problem set in the district's current direction | Medium. Principal's reading background and the board's literacy plan make reading scenarios likely | Clarify first, structure aloud, and flag where you would defer to the team |
| D. Values/Behavioral | Open prompts keyed to the district's three published beliefs | Medium. The beliefs page says they "guide every hire", but the invite names a panel and no values round, so none is detected; the beliefs still theme these questions | Choose real moments; where none comes to mind, say so plainly and give the nearest thing your material carries |
| E. Conversational | A friendly opener such as the biography question | Medium. Panels commonly open conversationally, and it is still scored | A 90-second arc built only from your own sentences |
| Prober | Defend-the-number follow-ups | Low. Your material holds dates and durations, no headline figures | Know exactly what each date and duration covers; no separate bank |
| Pressure | Interruptions, time-boxing | Low. Nothing in the invite or the profile signals it | A pause before answering covers it; no separate bank |

## Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade for six years. What changes for you in fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I've never taught fourth grade"; "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | The highest-ROI rehearsal in this pack. Open with the plain fact in your own words: "I've never taught fourth grade." Then the other sentence at its own scope: six years teaching third grade at a public elementary school in Joliet. If eligibility comes up, the endorsement covers grades 1–6, as written. Then a plan, not a past: the first two things you would ask the fourth-grade team and the first thing you would read before day one. Follow-up 1, likely: "How would you know in October it is going well?" Answer with what you would look at, as a plan. Follow-up 2, likely: "What if it is harder than you expect?" Concede only what you stated, that you have not taught the grade, and return to the plan. Do not say third grade prepared you for fourth; let them draw it. Answer slot: if you have already looked at fourth-grade standards or materials, say which; if you have not, say so plainly and say where you would start | F2 is the largest stated gap and this question is aimed at it, so some form of it will arrive. JD because it scores the role's grade level; the guidance holds the limit before the question asks for it |
| A2 | "You led your grade level's move to a new reading curriculum, but you haven't been a team lead. What did leading mean there?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead." | Hold the sentence at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Keep your own limit beside it: "I've never been a team lead." Answer slot: expect a probe on what the move involved. Say what was yours to do, in your own words; if it was assigned, shared, or the decisions were others', say so plainly and stay with the sentence. Hold through two follow-ups by returning to the sentence, never by adding to it | F6 holds both sentences, and the interviewer will see them side by side. EXP because it tests attribution |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade"; "I've never been a team lead." | Calibrated candor beats bluffing. Your material states two limits; choose the one that is truer for you, say it plainly, then name the first thing you would do about it. A plan, not a past | F2 and F6 are the two stated limits, so this stem lands on one of them. JD because it scores honest self-assessment against the role |
| A4 | "You've been at your school six years. Why leave, and why here?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | The pack has no reason for you and supplies none. Answer slot: give your actual reason for leaving, in your own words; if it is mostly about what draws you here, say that plainly. For why here, the district put three beliefs in writing: Every Child a Reader, Families Are Partners, Teach for Tomorrow, Not for the Test. Choose one only if it is true for you, and say why. Keep the Joliet years at the sentence's scope | Motivation consistency is the Skeptic's standard probe. EXP because it checks the story against your record |
| A5 | "Our belief is that each teacher speaks with every family each term. Your résumé shows a weekly email. How does that compare?" | JD | [grounded] "I write a weekly email to families." | Say the sentence in its own terms: "I write a weekly email to families." Do not say the email is the same as speaking with families; let them judge the comparison. Answer slot: expect a probe on what happens after the email goes out. If any family wrote back or asked for more, say what you did next, in your own words; if none did, or nothing followed, say so plainly and stay with the weekly email | F5 sits on the district's own published belief, so the comparison is a natural probe. JD because the belief works as a stated requirement |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our fourth-grade team plans together. What would you bring to that, and what would you need from us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years." | Reciprocity first. What you bring is those two sentences at their own scope, in your own words. What you need is yours to say, framed as what you would ask the team, not what you assume. Say plainly that you would learn their routines before suggesting changes. No claim about how you would run their planning | F6 is the team-work evidence and F4 the reading evidence. JD because the team's load is what a peer prices |
| B2 | "Where is the seam between a new teacher and the team's existing routines, and what happens when we disagree about how to teach something?" | CASE | [generic] | Offer principles, not a claim to know their seam: ask what is settled and what is open; follow established practice at first and raise differences as questions with reasons; keep the disagreement about the children's learning. The guidance makes no claim about your past | A live collaboration problem from the invite's panel structure. It is a pattern for the problem, not a fact about this team |
| B3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Use "we" for context and "I" for what was yours. Answer slot: expect a follow-up on who else did what. Say plainly which parts were yours and which were others', in your own words; if there was nothing to share credit for, say so and stay with the sentence | F6 is the only evidence of work that crossed a grade level, so the credit probe will aim at it. EXP because it tests attribution |
| B4 | "Tell us about the after-school reading club. What do the kids do there?" | EXP | [grounded] "I've run the after-school reading club for the last two years." | Say the sentence in its own words. Answer slot: describe what students do at the club, in your own words; the pack supplies no activities and names none. If parts were set by the school or a program, say so plainly | F4 holds the club, and teammates who teach reading will be curious. EXP because it checks a CV line by description |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The board's plan brings a new grades 3–5 reading curriculum in fall 2027. A fourth grader arrives who read well in third grade but struggles with the new materials. What do you want to know first?" | CASE | [grounded] | Clarify, then structure, aloud: what the struggle looks like (decoding, fluency, comprehension, stamina), what the new materials expect, what the earlier teacher and the family have seen. Then the approach and how you would check it is working. Flag where you would defer to the team's routines. Reasoning only; no claim about your past | The board adopted a 2026–2029 literacy plan with a new grades 3–5 curriculum from fall 2027 (Sources). CASE with CO content: it tests the district's own vocabulary |
| C2 | "Sketch your first six weeks with a class you have never taught." | CASE | [generic] | Think aloud: what you would want to learn about each reader, what routines you would set up, what you would ask the team, how families hear from you early. A plan; no claim about what you have done | F2's gap rehearsed as a live problem. The honest answer is a plan |
| C3 | "How would you fit reading conferences into a week with fourth graders?" | CASE | [grounded] | Clarify first: how much time the week allows, how groups form, what you would record. Say aloud what you would adjust to the team's routine. Reasoning only; do not claim you have run reading conferences | Section 7's principal footprint makes this theme likely. CASE because it is a live problem with no premise about your past |
| C4 | "The plan asks for a family reading night at every school each term. How would you use it?" | CO | [grounded] "I write a weekly email to families." | Structure it: what the night is for, who comes, what families do while there, how you follow up. The sentence is your one stated family contact, at its own scope; any further claim is a plan | The plan (Sources) names a family reading night each term, and F5 is the nearest evidence. CO because it tests current district direction |

### D. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Every Child a Reader. Tell me about a time a student in your class was not reading the way you hoped, and what you did." | VAL | [grounded] "I've run the after-school reading club for the last two years." | Selection scaffold: pick one moment with a named kind of difficulty (no names), what you did yourself, and where it ended up. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the club sentence, or how you would handle it | F4's belief is the raising source. VAL because it asks for a behavior that shows the belief |
| D2 | "Families Are Partners. Tell me about a time you brought a family into a child's learning." | VAL | [grounded] "I write a weekly email to families." | Selection scaffold: one moment, what you did, what the family did next. If none comes to mind, say so plainly, then give the weekly email at its scope, or how you would handle it | F5's belief is the raising source. VAL because it scores the belief by a specific moment |
| D3 | "Teach for Tomorrow, Not for the Test. Tell me about a time assessment results changed what you taught." | VAL | [grounded] | Selection scaffold: pick one moment with a named result, what it told you, what you changed. Nothing in your material carries this, so there is no quoted story here; if no such time comes to mind, say so plainly and say what you would look at first | F3 is a blank, and this belief is where it will be asked. VAL because the belief names the behavior |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey that brought you here." | EXP | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029"; "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years." | A 90-second arc with four beats, each a sentence you wrote: the licence and endorsement, the six years in third grade, the curriculum move in 2024, the club. Tell them in order, in your own words. Answer slot: why fourth grade now is the beat your material does not carry; say your actual reason, or say plainly that you are still working it out | Panels open here, and the casual register is still scored. EXP because it is your record told aloud |
| E2 | "What are you reading with kids these days?" | EXP | [generic] | Your answer alone: name a book or strategy you actually use, and say why in a sentence. The pack names no title, and a title you do not use is the one that gets probed | Casual questions on the principal's home topic are scored. EXP because it checks present practice |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 licence and endorsement | none, and why: a gate your material shows met; it is a confirmation, and A1 and E1 carry it |
| F2 teach at fourth grade | A1, A3, A4, C2 |
| F3 assessments inform teaching | D3 |
| F4 reading plans and reading work | A2, B1, B4, C1, C3, D1, E2 |
| F5 family partnership | A5, C4, D2 |
| F6 work with the grade-level team | A2, B1, B2, B3 |

## Reverse questions

| # | Question to ask them | Why it lands |
|---|---|---|
| R1 | "You spent nine years as a reading specialist before becoming principal. How does that shape what you want from a fourth-grade reading block?" | Ties to her public path and shows you read about her, not only the school |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity for the two teammates: it asks what helps them, not what you need |
| R3 | "How will the new grades 3–5 reading curriculum change what the fourth-grade team does this year, and what is still undecided?" | Shows you read the board's plan and asks about the open part |
| R4 | "What does contact with every family each term look like in practice here?" | Uses the district's own belief and asks for real practice |
| R5 | "Where do new fourth-grade teachers usually need the most support?" | Names the gap the interview will press and asks for help early |
| R6 | "How do assessments get used in your team meetings?" | Reads the third belief as a working practice, and your F3 gap becomes a question you ask |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or knows fourth grade's demands from experience | Negative you stated: "I've never taught fourth grade" | The plain acknowledgment, "I've never taught fourth grade", beside the quote "Six years teaching third grade at a public elementary school in Joliet." |
| Has been a team lead or led the grade-level team | Negative you stated: "I've never been a team lead." | The plain acknowledgment, "I've never been a team lead.", beside "I led our grade level's move to a new reading curriculum in 2024" at its own scope |
| Chose, wrote or trained others on the new reading curriculum | Inflated form of F4 and F6 | The quote at its own scope. The limit is the pack's observation: your material says you led the move, not what the move involved. A2's slot stays inside the sentence |
| Ran the school's reading program | Inflated form of F4 | The quote at its own scope: "I've run the after-school reading club for the last two years." The pack's observation is that your material says a club |
| Speaks with every family each term | Inflated form of F5 | The quote at its own scope: "I write a weekly email to families." The pack's observation is that your material says an email |

## Sources

Provided: your invite and your résumé text. A government ID number appeared in your message; it is not needed, and it was not used. The licence number was not used in any search.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

Searches:

- `Orrinsford Community School District values mission` returned https://orrinsfordschools.example/about/mission-and-beliefs
- `Dolores Vantongeren Halvering Elementary School principal` returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
- `Orrinsford Community School District strategic plan news` returned https://orrinsfordschools.example/news/board-adopts-literacy-plan
- `Illinois fourth grade teacher job description elementary school responsibilities qualifications` returned https://k12jobsboard.example/listings/fourth-grade-teacher

Fetches: https://orrinsfordschools.example/about/mission-and-beliefs and https://orrinsfordschools.example/news/board-adopts-literacy-plan.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District values` | yes | Three beliefs by name: Every Child a Reader, Families Are Partners, Teach for Tomorrow, Not for the Test. Moved F3 to F5, bank D, A4 and A5, and reverse questions R4 and R6 |
| 2. `Orrinsford Community School District interview process fourth grade` | skipped | Your invite fixes the loop: one 45-minute panel with the principal and two fourth-grade team members. Persona weights follow from it |
| 3. `Orrinsford Community School District strategy` / recent news | yes | The board's August 2026 literacy plan: structured phonics from kindergarten to second grade, a new grades 3–5 reading curriculum from fall 2027, and a family reading night at every school each term. Moved C1, C4 and R3 |
| 4. `Dolores Vantongeren Halvering Elementary School` | yes | One speaker page, not fetched beyond its snippet: principal since 2022, nine years as a reading specialist before, a 2025 talk on reading conferences. Moved the interviewer read, the weight on C, C3 and R1 |
| 5. representative `fourth grade teacher` JD | yes | A listing from a jobs board, seen only as a snippet and cut off before its qualifications, so it is not this district's posting. Moved F2 and F6, both `[inferred]` and unquoted |

## Upgrade menu

- The posting's full text → F2 and F6 become `[grounded]`, and JD questions can be added for any requirement the posting lists that this pack could not see
- Anything HR or the principal told you about focus areas, or a request to prepare something such as a sample lesson → a build section for that deliverable and a focus-weighted bank
- Your answers to the slots in F2 to F5 → each row regenerates around the one quote you add, and the matching guidance stops being a slot
- A curriculum-adoption document or the reading club's schedule, which you hold → F4 can move from `medium` toward `high`
- The state's licence lookup, which only you can run → F1 can move from `medium` toward `high`
- The names of the two fourth-grade teammates → an interviewer read for each and a reverse question tied to their own path
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes → a grounding brief, the principal's other talks, and recent district context
- A saved `tuesday-dossier.md` would record the gaps this prep exposed, for use in later sessions
