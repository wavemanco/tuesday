I'm reading the skill's remaining reference files (personas, research rules, output discipline) so I can build the pack. The invite has serious scam signs, and I'll flag those at the top of my reply.
Before the prep, one thing in the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ...", to "reply with a photo of your passport and your bank details before the interview", and says "you deposit the cheque and send the balance on to the vendor". A fee before any offer, a cheque you deposit and then send money on from, and passport and bank details before an offer are all known scam patterns. The fee request and the cheque request are very likely a scam, and this job is very likely a scam. Hold all of it until you've checked the invite with the employer, using contact details you find on its own website or careers page, not the email address in the invite. The paying, the cheque deposit, and the passport and bank details all stay on hold. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/alone/part-5/rooms/case-12-denied-f726f815/Brennock-Facilities_remote-administrative-assistant_interview_pack.md`. It has 18 questions, a fit snapshot against the four duties, and six reverse questions. I built it for a hiring-manager-style round, since the invite doesn't say whether the office manager would be your line manager. Web search was refused here, so there's no company research. The invite fixes the format as one 30-minute video call.

Two things to know about your background:
- **Invoices:** you "chased unpaid invoices" at the clinic, but the ad says "processing supplier invoices". That gap is the most likely probe, so question B1 gets the deepest rehearsal.
- **Travel and Excel:** nothing in what you've told me shows travel booking, and "okay with Excel" is thin. Both come up as likely probes with honest answer slots.

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Will the office manager be the person you'd report to, or a colleague on the team? The answer reweights every bank.
Can you paste the ad's full text and your CV's wording? Either would turn several rows from your summary into exact lines, and I'll carry on without them if you'd rather not.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock-Facilities_remote-administrative-assistant_interview_pack.md -----
# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

- **Candidate:** Aoife
- **Interviewer:** "our office manager" — your invite's words; no name given. Format: "a 30-minute video call".
- **Built on this assumption:** your invite does not say whether the office manager would be your line manager, so this is built as a hiring-manager-style round. A reply on that reweights the persona table.

## How to use this pack

Personas are how a question is asked; types are what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behaviour shows the employer's published values. Not built here: no values page was read and no values round is documented |
| EXP | Whether your background survives scrutiny: what you actually did |
| JD | Whether you can do the listed duties, gaps included |
| CO | Company and strategy knowledge. Not built here: company research was refused (see Sources) |
| CASE | A live problem from the role, scored on structure and reasoning |

**Highest-ROI prep in this pack: B1**, the invoices question. It is where the ad's duty and your background sit furthest apart, so expect it in some form. Rehearse it until it is boring.

Answer slots are instructions for the interview itself. Where one says "say so plainly", that is a fully acceptable answer.

## Fit snapshot

The requirements are the ad as you described it in your message; the only evidence is your own message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "I ran the appointment book for four physios" — your message | medium | [grounded] | transferability | Your material says an appointment book for four physios, not a manager's meeting diary, and the words stay at the quote: "I ran the appointment book for four physios." Nothing inspected stands behind it, so expect a probe. Answer slot: if any of that book's work was calendar work in the sense the ad means, say which, in your own words; if none was, say so plainly and stay with the appointment book |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show travel booking either way. Answer slot: if you have booked travel for anyone, in the clinic or outside it, say what, for whom and how, in your own words; if you have not, say so plainly, then say how you would approach it as a plan, never as a past |
| F3 | "preparing documents in Word and Excel" — the ad, as you described it (Word) | "I'm good with Word, okay with Excel" — your message | medium | [grounded] | presentation | Say it at the quote's own strength: "I'm good with Word." It is a self-rating with nothing inspected behind it, so expect a probe on what you have used it for (D3 rehearses it) |
| F4 | "preparing documents in Word and Excel" — the ad, as you described it (Excel) | "I'm good with Word, okay with Excel" — your message | low | [grounded] | discovery | Your own rating is "okay with Excel", and the words stay there. Answer slot: if you have built or maintained a spreadsheet, say what it did, in your own words; if your Excel use has been light, or you have not used it for work, say so plainly and stay with "okay with Excel" |
| F5 | "processing supplier invoices" — the ad, as you described it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices, and the words stay at the quote: at the clinic you chased unpaid invoices. The pack's observation is that the material says chasing, not processing, and does not say whose invoices they were. Answer slot: if any of your invoice work went beyond chasing, say what, in your own words; if it did not, say so plainly and stay with the chasing |

The ad as you described it states no legal, credential, schedule or pay terms, so the snapshot has no gate row.

## Requirement coverage

| Requirement | Questions |
|---|---|
| "managing calendars" | A1, A5, B3, D1 |
| "booking travel" | A2, B2 |
| "preparing documents in Word and Excel" | A4, D3 |
| "processing supplier invoices" | A3, B1 |
| "Remote" in the role title | B4, C3 |

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live office problems: a clash in the diary, a trip to book, an odd invoice | High. Hiring-manager-style rounds weigh live problems, and a 30-minute call on a practical role is the place for them | Clarify first, then structure, then answer; think aloud; name what you would check before acting |
| Skeptic | Probes each duty against your background | High. The ad's four duties each sit some distance from the evidence in F1 to F5, so the probes write themselves | Rehearse B1 until it is boring; answer from the quotes and the slots; give a plan for the rest, said as a plan |
| Conversational / Rapport Builder | Friendly opener, biography, tools and routine | Medium. A short video call usually opens warm, and these questions are still scored | A 90-second arc built from your own sentences; treat casual questions about the duties as scored |
| Data-Driven Prober | Reads your background line by line; the figure "four" gets tested | Medium. You gave one figure, and a close reader tests it | Know what "four" counted and say plainly what you do not know |
| Pressure / Stress | Time-boxed "why you" and "how much was you" | Low. A short admin round rarely runs this style, but one challenge is plausible | Pause, restate, hold what the quote carries through two follow-ups, concede specifically |
| Values, Peer | Not built | No values round is documented, and no peer was named | Add a note if the call turns out to include either |

The loop is one 30-minute video call, in your invite's words, so no archetype fallback applies.

## Question banks

### A. Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's 8:40. The manager's 9:00 client call has just moved to 9:30, and that now clashes with a meeting already in the diary. What do you do?" | CASE | [generic] | Structure it: what is fixed and what can move, who needs to hear about the change and how, what you would propose rather than only report the clash, and what you would confirm in writing. The question needs no claim about your past, so the guidance makes none | Live version of the calendar duty behind F1; CASE because it asks for a decision, not a history |
| A2 | "Someone must be in Cork on Tuesday for a 10:00 meeting and back for a 4:00 call on Wednesday. How do you book it?" | CASE | [generic] | Ask before booking: who is travelling, the budget and any approval needed, preferences, and whether plans are firm. Then give options with the trade-offs, confirm, and send the itinerary. No claim about your past is made. If you have booked travel before, F2's slot is where that goes | The travel duty has no evidence in F2, so a live problem is the likeliest form it takes; CASE because it tests structure |
| A3 | "A supplier invoice arrives with a purchase order number we don't recognise, and the amount is higher than usual. What do you do before it goes any further?" | CASE | [generic] | Hold it before it goes any further. Check what it matches: the order, the delivery, the person who requested it. Ask that person, and tell whoever approves payments. If the supplier's details look changed, confirm them through a contact you already have, never the one on the invoice. No claim about your past is made | The invoice duty behind F5, asked as a decision; CASE because the right structure matters more than a right answer |
| A4 | "The manager wants a one-page summary of this quarter's travel and supplier spend in Excel by end of day. Where do you start?" | CASE | [grounded] "I'm good with Word, okay with Excel" | Clarify what counts as spend and where the figures live, then say how you would lay out the page and how you would check the totals. Answer slot: if you have built a summary sheet, say how, in your own words; if not, or not like this, say so plainly and stay with "okay with Excel" | F4 is the thinnest row, so the Excel duty is likeliest to be tested live; CASE with JD content |
| A5 | "Two requests arrive at once: the manager wants a document reformatted today, and travel must be confirmed by noon. How do you prioritise?" | CASE | [generic] | Ask each person for the real deadline, tell both what you can deliver and when, and put any trade-off to the manager rather than choosing silently. No claim about your past is made | Tests prioritisation across the four duties; CASE because it is a live conflict |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role includes processing supplier invoices. What have you done with invoices that's closest to that?" | JD | [grounded] "chased unpaid invoices" | **Highest-ROI prep.** Hold only the quote: at the clinic you chased unpaid invoices. Answer slot: expect a probe on what the chasing involved and whose invoices they were; say what you did, in your own words, and which parts were not yours. If there was no set routine, or it was not yours, say so plainly and stay with the chasing. Follow-up levels to rehearse: what the chasing involved; what you did not handle; how you would get up to speed on this employer's process, said as a plan and never as a past. Hold through two follow-ups by returning to the quote, never by adding to it | F5 is where the ad's duty and the quote are furthest apart, so this probe arrives in some form; JD because it scores a stated duty |
| B2 | "Booking travel is part of this role. Where does that sit in your experience so far?" | JD | [grounded] | Answer slot: if you have booked travel for anyone, say what, for whom and how, in your own words; if you have not, say so plainly, then say how you would approach it as a plan, never as a past. Keep the answer under a minute; a short honest answer scores better than a stretched one | F2 has no evidence, so the interviewer will ask it open; JD because it scores a stated duty |
| B3 | "You've run an appointment book for four physios. How does managing a manager's calendar compare?" | JD | [grounded] "I ran the appointment book for four physios" | Hold the quote at its own scope: "I ran the appointment book for four physios." Answer slot: if any of that book's work was calendar work in the sense the ad means, say which, in your own words; if none was, say so plainly and stay with the appointment book | F1 is the likeliest probe on the calendar duty; JD because the comparison is the ad's, EXP in delivery |
| B4 | "This role is remote. Tell me about a time you worked on your own, without someone next to you." | EXP | [grounded] | Selection scaffold: pick a stretch where you managed your own workload, with a named decision you made yourself, how you kept others informed, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle working alone | The word Remote is in the role title, which is the raising source; EXP because it asks for a past instance |
| B5 | "What's drawing you to this role?" | EXP | [generic] | Give your actual reason in your own words; it is the one answer nobody else can supply. Keep it to what is true, and tie it to the ad's duties only where it really is | A motivation probe that closes most skeptical rounds; EXP because it tests consistency with your history |

### C. Conversational / Rapport Builder (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey so far." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic", "I ran the appointment book for four physios", "chased unpaid invoices" | A 90-second arc with only those beats, in your own words: two years as a receptionist at a physiotherapy clinic; ran the appointment book for four physios; chased unpaid invoices. End with why this role, using B5's answer | The standard opener; the arc is built from your own sentences so nothing in it can be probed past what you said |
| C2 | "How do you keep on top of your own tasks and deadlines day to day?" | JD | [generic] | Selection scaffold: name the tools and routine you actually use. If none comes to mind as a system, say so plainly, then say how you would set one up for this role | Remote work leans on self-management, so it comes up casually; JD because it tests fit with the job's working mode |
| C3 | "How comfortable are you with video calls and working through online tools?" | JD | [grounded] | Name the tools you have actually used, and be plain about the ones you have not. Answer slot: if your use has been light, say so plainly and say how you learn new tools | The role is remote, so tools come up casually; JD because it scores the role's working mode |

### D. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You ran the appointment book for four physios. Walk me through a typical day of that." | EXP | [grounded] "I ran the appointment book for four physios" | Start from the quote and describe the day in your own words. Answer slot: if some of the day was set by someone else, or shared with others, say so plainly and say which part was yours | F1 is the only calendar-like evidence, so a prober goes straight into it; EXP because it tests what was actually yours |
| D2 | "Four physios. Roughly how many appointments would that be in a week?" | EXP | [grounded] "I ran the appointment book for four physios" | Defend-the-number slots, each in your own words: what "four" counted, what would change it, the part of that figure you would defend least, and which part was yours. If you do not know a weekly figure, say so plainly rather than estimate to please | The one figure you gave is the one a prober tests; EXP because it checks attribution |
| D3 | "What have you used Word and Excel for?" | JD | [grounded] "I'm good with Word, okay with Excel" | Say what you have actually used each for. "I'm good with Word, okay with Excel" is your own rating, so keep it at that strength. Answer slot: if your Excel use has been light, say so plainly and stay with "okay with Excel" | F3 and F4 are self-ratings with nothing inspected behind them; JD because it tests a stated tool requirement |

### E. Pressure / Stress (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you for this job?" | JD | [grounded] "I ran the appointment book for four physios", "chased unpaid invoices" | Pause, then hold only what the quotes carry: you ran the appointment book for four physios, and you chased unpaid invoices. Concede specifically where the duties go beyond that. Answer slot: for any duty you have no experience of, say so plainly and say how you would learn it | A time-boxed challenge on the whole fit; JD because it scores the duties against the evidence in F1 and F5 |
| E2 | "That appointment book: how much of it was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold the quote through two follow-ups: "I ran the appointment book for four physios." Concede only what is true, and specifically. Answer slot: if some of it was shared, or set by someone else, say so plainly and say which part was yours | The attribution probe aimed at F1; EXP because it tests ownership |

## Reverse questions

| # | Question to ask them | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like for someone in this role?" | It shows you are thinking about doing the job, and the answer tells you what they value |
| R2 | "Which tools do you use today for calendars, travel and invoices?" | It names the three duties where your material is thinnest and tells you what to learn |
| R3 | "What kinds of travel does the team book, and how far ahead?" | It turns the travel duty into specifics you can check against F2 |
| R4 | "How does a new remote hire get their equipment, and who sets it up?" | A practical question that any real employer can answer plainly; how they answer is useful to you |
| R5 | "After an offer, what does onboarding look like: what paperwork, and when?" | A practical question, and the answer shows what the process really is before you hand anything over |
| R6 | "Who checks and who approves supplier invoices here?" | It shows you think about controls on payments, which links to A3 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars or diaries | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation: the material says an appointment book, not a manager's diary |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: at the clinic you chased unpaid invoices. The limit is the pack's observation: the material says chasing, not processing |
| Advanced or expert Excel | Inflated form of F4 | F4's quote at its own scope: "okay with Excel" |
| Advanced or expert Word | Inflated form of F3 | F3's quote at its own scope: "I'm good with Word" |

## Sources

- **Provided:** the invite text, your description of the ad, and your account of your background, all in your message.
- **Searches sent, all refused:** `Brennock Facilities Ltd values` (refused); `Brennock Facilities Ltd interview process administrative assistant` (refused); `Brennock Facilities Ltd strategy news` (refused). Nothing from outside your message is used in this pack.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | The search was refused; it would have fed a values cheat sheet, which is not built |
| 2. `{company} interview process {role family}` | unavailable | The search was refused; it would have checked the loop structure. Your invite's own words fix the loop as one 30-minute call |
| 3. `{company} strategy` / recent news | unavailable | The search was refused; it would have fed CO questions, so none are built |
| 4. `{interviewer name} {company}` | n/a | No name was given, so the interviewer read is absent |
| 5. representative `{role title}` JD | skipped | Your description of the ad fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's full text → rows F1 to F5 are built on your summary of the ad, and its exact wording would sharpen the requirement column and may add duties
- Your CV's wording → every evidence cell is a fragment of your message, so CV lines could upgrade F1 to F5 and give C1 more beats
- The office manager's name and whether they would be your line manager → persona weights, and a reverse question tied to their path
- Approval for company research → C-type and CO questions, plus a values cheat sheet if a values page is found; a deeper pass would be up to 6 more searches and 2 more fetches, several more minutes
- An earlier-employer or other work example with travel booking or spreadsheets → F2 and F4 evidence, which could turn their slots into story-mapped answers
- A `tuesday-dossier.md` → verified evidence and a sourced list of claims to avoid, in place of the ones this pack inferred
