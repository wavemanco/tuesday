I'll read the reference files the skill points to before building the assessment.
## Decision snapshot

**Worth taking the call? Yes, on conditions. Legit? I can't confirm that from here (RR1), and nothing in what you pasted asks for money or personal details (RR2). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000 plus 0.5–1% equity)
- `must_have` — direct: R3, R4, R5, R6
- `important` — adjacent: R7 (own the booking flow end to end), R8 (research calls with school owners), R9 (first designer)

R7 — checkout is part of a booking flow, not the whole of it; R8 — usability sessions with travel customers sit near owner interviews, not on them; R9 — never the only designer, no solo-ownership evidence; R2 — your pay floor wasn't given.

**Opportunity ledger.** The employer isn't established, because my searches were refused (RR1). The WhatsApp contact is a scheduling message for a video call, with no request for money or details (RR2). The equity terms are unstated (RR3). Pay, hybrid terms and scope are stated openly in the posting (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 plus 0.5–1% equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies as a real company, with the posting live on its own site and the invite coming from its own domain (RR1); (2) the salary clears your floor, and the equity terms are explained (R2, RR3); (3) you frame R7 and R9 honestly as adjacent, never as sole ownership.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting; not independently verified |
| Mandate | First designer; own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Reporting line | Closest working relationship is co-founder Ronan Kehoe; the message names Saoirse as CTO | `[grounded]` posting and WhatsApp message |
| Working pattern | Hybrid: two office days a week in Galway, rest remote | `[grounded]` posting |
| Compensation | €52,000–€60,000 plus 0.5–1% equity; equity terms not given | `[grounded]` posting |
| Stage | You applied, and a 45-minute video call with Ronan and Saoirse is proposed | `[inferred]` from "thanks for applying" and the invite |
| Scope read | A coherent first-designer post for a six-person team: one product, one flow, direct work with engineers | `[inferred]` from the posting's scope against its team size |
| Market calibration | Not done: the salary search was refused and I won't quote market figures from memory | `[grounded]` search refused |
| Unknowns | Employer's online footprint; equity terms; first-90-days outcomes; how the other roles split (the posting names two engineers and two co-founders) | — |
| Contradictions | None between the posting and the message; both come from the same unverified source | `[grounded]` the two texts you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You live in Galway, so the office location is met. Whether two office days suit you was not stated as a constraint | `[grounded]` your background, moved back to Galway | confirm in the call |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity (your floor not given) | hard_gate | unclear | none | hard_gate | No floor from you, so fit against the pay can't be judged | `[grounded]` posting figure; no candidate statement | G1 question |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer, self-reported with nothing inspected yet | `[grounded]` your background | portfolio/case-study link would raise to high |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is confirmed but unproven by an artifact. The checkout case study they mention would be one | `[grounded]` your background | share the case-study link |
| R5 | You have run your own user research | must_have | direct | medium | none | Ran monthly usability sessions with customers. Evaluative testing is user research, but how much you planned and synthesised yourself isn't stated | `[grounded]` your background | be ready to say what was yours |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers, so the team shape is similar | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | important | adjacent | medium | transferability | You redesigned a checkout flow, which is part of a booking flow. Limit: not stated as the whole journey, and done within a squad | `[grounded]` your background; `[inferred]` that checkout is a part, not the whole | G2 |
| R8 | Run research calls with school owners | important | adjacent | medium | transferability | Usability sessions with travel customers are adjacent. Limit: owners are business operators, and owner interviews are a different kind of work from testing | `[grounded]` your background; `[inferred]` on the kind difference | be ready to say so plainly |
| R9 | Be the first designer | important | adjacent | medium | transferability | Four years in a design role with a squad. Limit: you've never been the only designer, so no evidence of setting process alone | `[inferred]` from "You would be our first designer"; `[grounded]` your statement | G3 question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor and equity terms (R2, hard_gate) | hard_gate | The posting gives a band; I have no floor from you and no equity terms | A gate the inputs don't settle; it could end the process | Your minimum salary; what equity percentage and vesting you'd accept | Your own number, and the written offer terms later | `[grounded]` posting; no candidate statement |
| G2 | Whole-journey ownership (R7, important) | transferability | Checkout redesign confirmed; nothing on the steps before or after it | Interviewers are likely to ask where your ownership started and stopped | Search and availability, basket, confirmation, or cancellation steps you touched | The case study or screens showing the scope | `[inferred]` bridge; `[generic]` that "end to end" gets probed |
| G3 | Solo-designer working (R9, important) | transferability | You've been in a team of designers or a squad, never alone | A first-designer post is a different job from a seat in a squad | Setting up a component library, a research habit, a review routine, or working without design review | Anything you set up that others kept using | `[grounded]` your statement; `[generic]` that first-designer roles usually involve this |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small to have a footprint, or the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and show me the product? | unresolved |
| RR2 | Co-founder contact by WhatsApp, invite by email | unknown | — | "I have emailed you a calendar invite with the video link. Just shout here if the time does not suit." | Scheduling by chat for a call held on video is not a request for money or details; the open point is whether the emailed invite comes from the company's own domain | `[generic]` pattern: small teams often schedule by message app; not a claim about this one | Could you send the invite from your company email address? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | The percentage may come without vesting, share class or dilution terms | `[inferred]` from the posting's silence on terms | What are the vesting schedule and share class behind the equity, and when would it be offered in writing? | unresolved |
| RR4 | Pay, hybrid terms and scope stated openly | positive_signal | — | "Salary €52,000–€60,000 … two days a week at our Galway office" | The posting is specific on the terms it states | `[grounded]` posting | What would the first 90 days look like, and what would success be? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, find Fernquay's own website, check the posting is on it, and compare the invite's sender domain and video-link domain with that site | RR1, RR2 | `[grounded]` register | pending your approval |
| A2 | Look the company up on the public company register and see whether it lists a Galway address | RR1; a registered company is normally listed there, but a very new or unincorporated one may not be | `[generic]` pattern, not a claim about this one | pending your approval |
| A3 | Ask RR1–RR4's questions verbatim in the call, and ask for the equity terms in writing | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | In the call, lead with the checkout redesign at the Dublin travel-booking company, the monthly usability sessions with customers, and working in a squad with four engineers, and say plainly that you've never been the only designer | Each claim traces to your own sentences; the limit is the honest answer to R7–R9 | `[grounded]` your background | pending your approval |
| A5 | Share nothing beyond the call details and your case study until there's a written offer | A standard precaution when a company can't yet be verified | `[generic]` practice | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused ("Fernquay booking software sea kayak surf schools Galway"; "Fernquay Product Designer Galway careers"). They would have moved RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | One search was refused ("Product Designer salary Ireland Galway startup 3-5 years experience equity"). It would have given the market calibration and tested R2 against the band |
| 3. Hiring manager's public footprint | unavailable | One search was refused ("Ronan Kehoe Fernquay co-founder"). It would have shaped the A4 positioning |

I can offer a dossier file, `tuesday-dossier.md`, if you'd like to keep this assessment.

## Upgrade menu

- Search permission, so I can run the three research targets above → RR1 and R2 get checked and the market calibration gets filled in.
- Your portfolio or case-study link → R3 and R4 rise from `medium` to `high`.
- Your pay floor → R2 and the decision settle.
- The invite's sender address, with the domain only → RR1 and RR2 tighten.
- Rehearsal for the call itself is mock-interview's job, which isn't done here.

## Questions

G1 — What's the lowest salary you'd accept, and is equity something you'd weigh at all?
G3 — Have you ever set up a design process, library or research habit on your own, or worked without other designers reviewing your work?
RR1 — Where did you find and submit this application, and which domain did the calendar invite come from?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.