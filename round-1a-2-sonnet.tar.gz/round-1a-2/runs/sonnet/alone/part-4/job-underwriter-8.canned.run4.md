I'm checking whether Velloway Logistics can be found online, and what this kind of role normally pays. Then I'll write up the assessment.
**Ciara, don't go ahead. Don't paste your IBAN, and don't send your PPS number, a passport photo or any money. `no_go`.** These messages are very likely a scam. Velloway Logistics doesn't turn up in my search either.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Income of at least €30,000 a year)
- `must_have` — direct: R2, R3
- `important` — direct: R4
- `preferred` — unclear: R5 (A quiet place to work)

R2, R3, R4 — your background matches the skills the posting names; R1 — a posting that says only "up to" and 15–30 hours cannot meet it.

**Opportunity ledger.** The messages ask you to pay for equipment (RR1), to deposit a cheque and forward part of it (RR2), and to hand over bank, tax and ID details before any written offer (RR3). The process runs only in chat (RR4), and the employer is not established (RR5). The pay is out of line with the market band (RR6) and the contact address is a free-mail one (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (Income of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** the demands for payment, the cheque and ID details would have to be absent, and a written offer would have to arrive from a domain that the employer's own website gives you.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics": a search for the name returned nothing, so I can't tell you what it is or whether it exists as described | `[grounded]` search returned no results; not established |
| Role | Remote order processing coordinator, 15–30 hours a week, "up to €26 an hour plus commission", no experience needed | `[grounded]` posting |
| Process | Hiring entirely on Telegram, "no calls or video interviews" | `[grounded]` posting |
| Pay arithmetic | €26 an hour is about €20,300 to €40,600 a year at 15 to 30 hours. It reaches €30,000 only at about 22 hours a week, every week, at the top rate. Commission is unquantified | `[inferred]` from the posting's figures |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland have a median base of €31,200 (middle range €28,400 to €34,100). €26 an hour would be about €54,000 a year at full-time hours, well above that range for a role needing no experience | `[generic]` Pennoral 2026 Ireland pay guide, salaried roles only; `[inferred]` annualisation |
| Unknowns | Who employs you, who "the equipment partner" is, what the commission is, what contract you would get | — |
| Contradictions | The posting says full training is provided and no experience is needed. The messages then ask you to buy your own kit | `[grounded]` posting against messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Your floor: at least €30,000 a year | hard_gate | unclear | high | hard_gate | The constraint is yours and confirmed. Fit is `unclear` because the posting gives only "up to €26", variable hours and unquantified commission | `[grounded]` your constraint; posting terms | Moot unless RR1–RR5 clear |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel; stated, with no artifact seen | `[grounded]` your account | none |
| R3 | Strong attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day for three years, and you trained two new starters; stated by you, not independently shown | `[grounded]` your account | none |
| R4 | Good written English | important | direct | medium | none | Written customer service is your daily work; stated, no sample seen | `[grounded]` your account | none |
| R5 | A quiet place to work | preferred | unclear | none | discovery | You haven't said | `[grounded]` your account is silent | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Real pay and hours (R1, hard_gate) | hard_gate | "Up to €26", 15 to 30 hours, commission unquantified | Your €30,000 floor can't be tested without a guaranteed rate and hours | Not applicable: this is about the offer's terms, not your experience | A written contract from the employer's own domain stating rate, hours and contract type | `[grounded]` posting; `[inferred]` that it can't be tested |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Asked to pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | Paying to get a job is a recognised advance-fee pattern. This request is very likely a scam. | `[generic]` known pattern | Ask the employer named in the posting, through contact details you find yourself on a website you found independently (not this chat or this email address): "Do you require new hires to buy equipment, and did @VellowayHiring send this request?" Hold any payment until they answer. | confirmed |
| RR2 | Asked to deposit a cheque and forward most of it | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A cheque can show in your account before the bank has finished checking it. If it later fails, the money you sent on is yours to cover. This request is very likely a scam. | `[generic]` known pattern | As RR1: "Did your company issue a cheque to a new hire, and for what?" | confirmed |
| RR3 | Bank, tax and ID details requested before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | It came before any written offer naming the role and pay, so it is not routine onboarding. | `[generic]` onboarding norms | As RR1: "Does your payroll collect these details by chat?" | confirmed |
| RR4 | Hiring and offer run wholly in chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | The "interview" and "offer" came only through chat, so there is no interviewer you can place. This sign alone does not show who is behind it. | `[inferred]` from the posting and messages | As RR1: "Who interviewed me, and under what name at your company?" | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or the messages may not come from who they name. | `[grounded]` search returned nothing; `[generic]` reasons | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Pay well above the market band for a no-experience role | risk_signal | medium | "Earn up to €26 an hour plus commission on every order you process" | Pay far above the band is a lure pattern; it could also be loose wording. | `[inferred]` posting figure against `[generic]` band | What is the guaranteed hourly rate, and what are the commission terms? | unresolved |
| RR7 | Contact address is a free-mail one | risk_signal | medium | "velloway.hr@postmail.example" | A hiring contact off the employer's own domain can't be checked against the employer. I can't tell from here whether the employer has a domain of its own. | `[inferred]` from the address | Which address on your own website does HR use? | unresolved |

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. Until then, pay nothing, lodge no cheque and send no personal details.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing: no IBAN, PPS number, passport photo or transfer, and don't lodge a cheque if one arrives | see RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | If you want to check further, look up any "Velloway" website yourself and use only contact details found there | see RR1, RR5 | `[grounded]` register | pending your approval |
| A3 | Report the posting to the jobs site, and consider telling the Gardaí; you haven't sent anything, so there is nothing to recover | Reporting is a common step after such messages | `[generic]` | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: everything about your background is stated by you and is a lead until backed by an artifact. You offered your IBAN, and I haven't used or repeated it; the passport and PPS number aren't needed for this assessment either.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics"; no result, so the employer is not established. Moved: RR5 and the role reality organization row |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland hourly rate"; it returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). Moved: market calibration and RR6 |
| 3. Hiring manager's public footprint | n/a | Only a chat handle was given, no name, so there was no query to form |

Offer beyond this assessment (built only on your approval): a short list of the kinds of roles that fit your courier customer-service and Excel background, with their usual pay band. It would earn its place because the €30,000 floor is realistic for those roles.

I can also write up this assessment as a `tuesday-dossier.md` if you'd like to keep it.

Upgrade menu:
- A link to the original posting and the name of the jobs site → RR5 and R1 could be checked against a live page.
- A website you find yourself for Velloway Logistics, if one exists → RR1 to RR5 could be put to the employer directly.
- A deeper research pass on the firm (up to 5 more searches and 2 more fetches) → RR5, though it is unlikely to change `no_go`.

RR5 — Which jobs site was the posting on, and does the listing link to any Velloway website? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.