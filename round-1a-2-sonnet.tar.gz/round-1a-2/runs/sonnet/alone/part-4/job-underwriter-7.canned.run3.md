I'll read the reference files the skill points to before building the assessment.
I've run four searches so far: the employer, the vacancy, the pay band, and the team lead. Next I'm checking the employer's careers page to see whether this posting is live and matches your copy.
Aoife, yes, it's worth applying for, on the conditions below. I searched for the employer, the pay band and the team lead, but the employer's careers page didn't load, so I couldn't confirm the posting is live. I've kept your NI number out of everything.

## Decision snapshot

**Yes, worth applying for, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R5, R7a, R8a, R10 · unclear: R4 (clear, timely written records, on an EPR), R9 (End-of-life visits)
- `important` — adjacent: R6 (Leg-ulcer care), R11 (Own caseload) · unclear: R7b (Continence care), R8b (Care planning)
- `preferred` — absent: R12 (Doppler assessment)

R11 — a credible bridge via the home-visiting secondment, its limit named; R6 — a wound-care bridge with no leg-ulcer evidence; R4, R9 — the CV is silent; R12 — a stated gap, and the posting calls it desirable.

**Opportunity ledger.** The duties, pay and support are plainly stated (RR2, RR4). The employer matches the posting's description, but the live listing is unconfirmed (RR1). Hours, rota, contract basis, pay placement and mileage are unstated (RR3, RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the live listing is confirmed on Calderbrook's own careers page or the platform it advertises on (RR1); (2) R11 and R6 are framed as adjacent and never as caseload or leg-ulcer experience; (3) R9 and R4 are answered, since they are the two must-have rows the CV doesn't speak to.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` search result, "About Calderbrook Community Health" (snippet) |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration, care planning, on an electronic patient record | `[grounded]` advert |
| Caseload and support | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Essential | Current NMC registration (Adult); full UK driving licence (pool cars provided); one year post-registration; clear, timely records | `[grounded]` advert |
| Desirable | Doppler assessment for leg ulcers | `[grounded]` advert |
| Pay | £31,050–£37,800 a year plus mileage | `[grounded]` advert |
| Scope read | An entry-level community post for an experienced ward nurse: a small caseload, senior support and a one-year threshold | `[inferred]` from those three stated terms |
| Market calibration | Band 5 community staff nurses in England: median basic pay £34,300, interquartile range £32,400–£36,600. The advert's range encloses that interquartile range; it is a pattern, not this employer's offer | `[generic]` search, "Wardround 2026 UK Community Nursing Pay Guide" (snippet); `[grounded]` advert for the figures |
| Team lead | Rhiannon Mabbott appears as Calderbrook's Halifax district nursing team lead, eleven years a district nurse. At a 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` search result, communitynursingforum.example speaker page (snippet) |
| Unknowns | Hours and rota; contract basis; where on the band you would start; whether mileage applies to pool-car journeys; whether the listing is live | `[grounded]` advert silence |
| Contradictions | None between the advert and the about page. The careers page could not be fetched, so the listing wasn't cross-checked | `[grounded]` fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult Nurse | hard_gate | direct | medium | none | You state active registration as an Adult Nurse, revalidation due March 2028. Nothing inspected; the register entry is public and the check is yours | `[grounded]` CV | You check your register entry; no action from me |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full UK licence, category B. Pool cars are provided. Checking it is yours | `[grounded]` CV | You check licence status; no action from me |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward, CV only | `[grounded]` CV | none |
| R4 | Clear, timely written records on an electronic patient record | must_have | unclear | low | discovery | The CV says nothing about documentation or record systems, so I can't attribute record-keeping practice to you | `[grounded]` CV silence | see G2 |
| R5 | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds, both stated | `[grounded]` CV | none |
| R6 | Leg-ulcer care | important | adjacent | medium | transferability | Carries over: wound care on a different wound type. Limit: leg ulcers are not mentioned, so no compression or venous-ulcer assessment is evidenced. Strengthener: any leg-ulcer dressing or compression work, or training | `[inferred]` from the pressure-ulcer and surgical wound claims | see G4 |
| R7a | Catheter care | must_have | direct | medium | none | Stated on the CV | `[grounded]` CV | none |
| R7b | Continence care | important | unclear | low | discovery | CV silent on continence care beyond catheters | `[grounded]` CV silence | see G5 |
| R8a | Insulin administration | must_have | direct | medium | none | Stated on the CV | `[grounded]` CV | none |
| R8b | Care planning | important | unclear | low | discovery | CV silent | `[grounded]` CV silence | see G6 |
| R9 | End-of-life visits | must_have | unclear | low | discovery | CV silent. I won't assume end-of-life work from an acute medical ward | `[grounded]` CV silence | see G1 |
| R10 | Visiting patients in their own homes | must_have | direct | medium | presentation | The last 18 months were on a discharge-to-assess secondment, visiting patients at home in their first week after discharge. This is your strongest match and sits mid-paragraph | `[grounded]` CV | E1, pending your approval |
| R11 | Holding a small caseload of your own | important | adjacent | medium | transferability | Carries over: home visits on the secondment. Limit: you say you have never held your own caseload. Strengthener: what you decided and planned on those visits | `[grounded]` your statement; `[inferred]` the bridge | see G3 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You say you have never done one. It is desirable, not essential. Closure path: Doppler training | `[grounded]` your statement and the advert | see G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-of-life visits (R9, must_have) | discovery | No end-of-life work on the CV | A must-have the advert names; an unanswered row stays `unclear` | Nursing dying patients on the ward; syringe-driver or anticipatory-medication work; supporting a family at the end of life; discharge to a preferred place of death | A competency record, training certificate or reference mention | `[grounded]` CV silence; `[inferred]` that an answer could move the row |
| G2 | Records on an EPR (R4, must_have) | discovery | No mention of documentation or record systems | The advert lists clear, timely records as essential | Using an electronic patient record on the ward or secondment; recording visit outcomes; handover notes; audits of your documentation | A record-keeping audit result, an appraisal comment, a systems-training record | `[grounded]` CV silence |
| G3 | Own caseload (R11, important) | transferability | Home visits on the secondment; no caseload | The advert gives you a small caseload from the start | Planning your own visit list; deciding when to escalate; reviewing patients over several visits | A service description of the discharge-to-assess role, a reference, an appraisal | `[grounded]` your statement; `[inferred]` the bridge |
| G4 | Leg-ulcer care and Doppler (R6, R12) | capability | R12 is absent; R6 is only a wound-care bridge | Desirable, and a duty the advert lists. The team lead has spoken on Doppler training for new-to-community staff | Compression bandaging; leg-ulcer clinic exposure; any tissue-viability training | A training certificate or competency sign-off. For R12, Doppler training is the closure path | `[inferred]` that the team lead's talk suggests training exists here; `[grounded]` your statement for R12 |
| G5 | Continence care (R7b, important) | discovery | Catheters only | Listed as a duty | Bladder and bowel care, continence assessments, pad and product reviews | A competency record | `[grounded]` CV silence |
| G6 | Care planning (R8b, important) | discovery | Not mentioned | Listed as a duty | Writing or updating care plans on the ward or secondment; discharge planning | A care-plan example with identifiers removed | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting live status unconfirmed | unknown | — | "Calderbrook Community Health CIC, Halifax" | The listing may sit on a jobs board or the NHS-wide site rather than the employer's own page, or the page may have moved | `[inferred]` from the careers fetch returning no page | Can you point me to this role on your own careers page, and what is the closing date? | unresolved |
| RR2 | Pay stated openly | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range encloses the survey's interquartile range for the grade, so it is not unusually low | `[grounded]` advert; `[generic]` survey band | Which part of the range applies to this appointment? | noted |
| RR3 | Pay placement and mileage unstated | unknown | — | "£31,050–£37,800 a year plus mileage" | The advert gives the full range; where you would start and the mileage rate are not said | `[inferred]` from the advert's silence | Where on the range would I start, and is mileage paid on pool-car journeys or only own-car ones? | unresolved |
| RR4 | Named support and an open invitation to talk | positive_signal | — | "supported by a senior community nurse"; "informal chat about the role" | A new-to-community nurse would get named support | `[grounded]` advert | How is the senior community nurse's support scheduled in the first months? | noted |
| RR5 | Hours, rota and contract basis unstated | unknown | — | "district nursing team caring for housebound adults" | End-of-life and insulin visits may involve weekends or evenings; the advert is silent | `[generic]` pattern for district nursing; `[grounded]` advert silence | What are the working pattern and rota, including weekends, and is the post permanent? | unresolved |

## Application plan

`resume_edits_pending_approval` — the edit below stays a proposal until you approve it.

| # | Current | Proposed | Source |
|---|---|---|---|
| E1 | "...the last 18 months seconded to its discharge-to-assess team, visiting patients at home in their first week after discharge." | "Seconded for 18 months from the acute medical ward to the discharge-to-assess team, visiting patients at home in their first week after discharge." | `[grounded]` your CV |

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead the CV and supporting statement with the home-visiting secondment, ahead of the ward role | R10, R11 | `[grounded]` CV | pending your approval |
| P2 | State the limits plainly: you have not held a caseload of your own and have not done Doppler assessment, both in your own words | R11, R12; the advert makes Doppler desirable, not essential | `[grounded]` your statement; `[generic]` pattern that stated limits read better in interviews | pending your approval |
| P3 | Do not add leg-ulcer, continence, end-of-life or caseload wording until G1–G6 confirm it | R6, R7b, R9, R11 | `[grounded]` evidence map | pending your approval |
| P4 | Take up the informal chat with Rhiannon Mabbott. Her public talks cover leg-ulcer clinics and Doppler training for new-to-community staff, so ask about training and induction, along with RR1, RR3 and RR5 | RR1–RR5 | `[grounded]` advert and speaker page; `[inferred]` that the training question suits her remit | pending your approval |
| P5 | Confirm the live listing before investing in an application | RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet. I have not repeated or used your National Insurance number anywhere, and no registration or licence number went into a search.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health CIC community staff nurse Band 5 district nursing vacancy"; both returned "About Calderbrook Community Health" (calderbrookhealth.example/about). The fetch of calderbrookhealth.example/careers returned no page. Moved: the organization row, and the live-listing check (RR1) is unresolved |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing Agenda for Change pay scale 2026", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned the speaker page at communitynursingforum.example/speakers/rhiannon-mabbott. Moved: the team lead row and plan row P4. Role and talk topics only |

I'll offer the dossier whenever you want it: say so and I'll produce `tuesday-dossier.md` from this assessment.

## Upgrade menu

- Your own check of your NMC register entry and driving licence status → R1 and R2 can go to `high`.
- Competency sign-offs for catheter care, insulin administration and wound care, or an appraisal that mentions them → R5, R7a and R8a to `high`.
- A service description or reference for the discharge-to-assess role → R10 and R11 firm up.
- A Doppler or leg-ulcer training record, if you have one → R6 and R12 move.
- Your pay floor, hours or rota limits, and any other non-negotiables → the hard-gate line can check you against them instead of flagging them as unknown.
- A link to the live listing, or Calderbrook's careers page → RR1 closes.
- A deeper research pass on Calderbrook (staffing churn, reports from current and former staff, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

G1 — Have you cared for dying patients on the ward or the secondment? What did you do, who else was involved, and what happened?
G2 — What record system did you use on the ward and the secondment, and how did you record each home visit?
G3 — On the secondment, who decided which patients you saw, in what order, and when to escalate? Did you do that yourself, or was it set for you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.