**Yes, this is normal, and nothing in the offer looks like a scam.** Your rule is a good one for unsolicited requests, but this isn't that. You've been interviewed in person twice, and you're being asked after an offer, not before.

I checked only the text you pasted. I did no web research, so I haven't confirmed that Marrowgate Housing or that email domain is real. Your own checks, below, cover that.

**Why each request is standard in Ireland**
- **Bank details:** they can't pay you without them. Every employer collects these at onboarding.
- **PPS number:** Revenue requires employers to report your pay and tax against your PPSN from your first payday. Without it, you could be put on emergency tax.
- **Passport:** employers have to check that you're entitled to work in Ireland. For non-EEA nationals this is a legal duty. For Irish and EU citizens it's still the most common way to prove identity. Bringing the original on day one so someone can see it in person is a good sign.

**Signs this is legitimate**
- You had two in-person interviews at their office.
- The offer matches the ad: same role, hybrid with two days in Limerick, and €40,000 inside the €38–42k band.
- The sensitive details come after acceptance, through a portal.
- Nobody has asked you for money, equipment purchases or an upfront fee.
- Five working days to accept is a normal window.

**Minor points that are normal but worth knowing**
- The offer is signed by "People Team" rather than a named person. That's common, but Declan Garvagh interviewed you or is your manager, so a quick confirmation from him is easy.
- A scan of your passport goes beyond what's strictly needed if you also show the original on day one. It's reasonable to ask how long they keep it and who can see it. A housing association that handles payroll should have a ready answer.

**Verify before you upload anything**
1. Check that the email really came from `@marrowgatehousing.ie` and not a lookalike domain. Look at the full sender address, not just the display name.
2. Check that the onboarding portal link goes to the same domain. If it doesn't, ring them before you click.
3. Look the organisation up on the Approved Housing Bodies Regulator register and the CRO.
4. Phone the office number from their official website, not from the email, and ask the People Team to confirm they sent the offer and the portal link.
5. Send the details only through the portal, never as an email attachment.

You can accept first. Acceptance doesn't require you to hand anything over, and the portal link only arrives afterwards. Do the checks above before you upload anything.

**On the role**
- You're a strong fit: 3 years of payroll, a Payroll Technician certificate, monthly ledger reconciliation, and daily Excel.
- The one gap is pension changes, which you haven't done yourself. It's learnable, but say so openly and ask what pension scheme and software they use.
- Also ask whether they'll support your qualification. That is a fair thing to raise before you sign.

If you tell me whether you're an Irish, EU or non-EEA national, I can say exactly what the right-to-work check requires of you.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.