I'll read the skill's reference files before building the assessment.
Reading is done. Now I'm running the research on Fernquay (site, role-family pay, Ronan Kehoe's public profile).
## Decision snapshot

**Yes, it looks worth applying to. The WhatsApp message asks nothing of you beyond a video call (RR3), but I couldn't verify the company from here, so the status is `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R8 (Research calls with school owners) · unclear: R9 (First designer, no design peer)

R7 — a checkout redesign is part of a booking flow, but ownership of the whole flow is unconfirmed; R9 (`low`) — no evidence either way on working without a design peer; R2 — your pay floor was not given.

**Opportunity ledger.** The company is plausible on its face but unverified. I couldn't check it (RR1), and "thanks for applying" sits oddly beside your asking whether to apply (RR2). The invite's sender domain, the equity terms, the pay benchmark and the design support are also open (RR3, RR4, RR5, RR6). The posting does state pay, hybrid terms and a named co-founder who matches the message sender (RR7).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and posting verify, and the invite comes from a Fernquay address (RR1, RR3); (2) the pay meets your floor (R2, RR5); (3) design authority and support are concrete, since you would be the first designer (R9, RR6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, a six-person Galway company making booking software for sea-kayak and surf schools. This is the posting's own description and is not independently verified (RR1) | `[grounded]` JD |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers, working most closely with co-founder Ronan Kehoe | `[grounded]` JD |
| Pay and terms | €52,000–€60,000 plus 0.5–1% equity. Hybrid: two days a week in the Galway office | `[grounded]` JD |
| Scope read | Design, research and shipping are combined in one person. That fits a first-designer post, and what to check is support and decision rights (RR6) | `[inferred]` from the JD's mandate against its silence on design support |
| First-90-days and first-year outcomes | Not stated in the posting | `[grounded]` JD silent |
| Market calibration | Not calibrated. No role-family sweep ran, so there is no band to set the stated pay against (RR5) | none, no search ran |
| Unknowns | Equity form and vesting, design decision rights, research budget, who reviews design work | `[grounded]` JD silent |
| Contradictions | The message thanks you "for applying" and cites "the checkout case study", while you describe the application as still a question (RR2). The JD and message otherwise agree on the co-founder's name | `[grounded]` JD and message, as you pasted them |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You say you moved back to Galway last year. Willingness to commute two days is not stated | `[grounded]` your message | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | The range is stated in the JD, but you have not given a floor, so I can't say whether it is met | `[grounded]` JD range; no candidate constraint supplied | Q2 in the closing questions |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company. Stated by you, with no portfolio inspected | `[grounded]` your background | A portfolio link would raise it to high |
| R4 | Strong Figma | must_have | direct | medium | none | Figma daily is your claim, and no file or case study has been inspected | `[grounded]` your background | Same portfolio link |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers | `[grounded]` your background | Same portfolio link |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned your employer's checkout flow, which is part of a booking flow. How much of the surrounding flow you owned is not stated, and the squad context suggests shared decisions. That is a limit to name, not a claim to make | `[grounded]` checkout redesign; `[inferred]` that it covers only part of the flow | See G1 |
| R8 | Run research calls with school owners | important | adjacent | medium | transferability | Usability sessions with customers carry over. The limit is that they are not discovery calls with business owners. Whether your customers were consumers or businesses is not stated | `[grounded]` usability sessions; `[inferred]` the discovery-call limit | See G3 |
| R9 | First designer, no design peer | important | unclear | low | discovery | You have never been the only designer, and nothing shows how you worked without a design lead. Carried as a real risk and not a verdict | `[grounded]` your statement | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ownership scope of the booking flow (R7, must_have) | discovery | A checkout redesign in a squad. Which decisions were yours is not established | R7 is a `must_have` row at `adjacent`, and the role says "end to end" | Deciding the scope of the redesign yourself; setting the flow's metrics; changes you shipped to steps before or after checkout | A case study, before/after screens, a handoff doc | `[grounded]` your background; `[inferred]` that ownership scope will be probed |
| G2 | Working without a design peer (R9, important) | discovery | No evidence either way | You would be the first designer, so the interviewers will want to know how you decide alone | Starting the monthly usability programme yourself; setting design standards or components others adopted; making calls without a design lead's review | Process notes, a research cadence doc | `[grounded]` your statement; `[generic]` that first-designer interviews probe this |
| G3 | Research with business owners (R8, important) | transferability | Usability sessions with customers. Who they were is not stated | The role's research is calls with school owners, a business-user audience | Any research with business or operator users; discovery calls rather than task testing | A research plan or findings summary | `[grounded]` your background; `[inferred]` the limit |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The company may be too new or small for a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. No search ran, so nothing was found either way | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who I would be interviewing with? | unresolved |
| RR2 | The message's wording does not match your stage | unknown | — | "thanks for applying, we loved the checkout case study" | You may already have applied, in which case this is consistent. If you did not send an application or a case study, the message may be a template | `[inferred]` from your question about whether to apply, set against the message's wording | Which of my materials were you referring to when you mentioned the checkout case study? | unresolved |
| RR3 | Contact moved to WhatsApp; invite sender not yet seen | unknown | — | "I have emailed you a calendar invite with the video link." | Arranging a video interview by chat is scheduling and not a signal in itself. What is unchecked is whether the emailed invite comes from an address matching the company's own | `[generic]` pattern for how scheduling works; `[grounded]` the message asks only for a 45-minute video call | Which email address will the invite come from, and is it on your website? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "0.5–1% equity" | A percentage tells you little without the form (options or shares), vesting schedule and share count | `[generic]` how equity offers are structured | Is the equity options or shares, on what vesting schedule, and out of how many fully diluted shares? | unresolved |
| RR5 | Pay not benchmarked | unknown | — | "Salary €52,000–€60,000" | Whether this range buys a first designer with 3+ years in Galway can't be judged, because no sweep ran | `[grounded]` the JD's figure; no market band exists in this session | Where in that range would this role land for my experience, and is it reviewed as the company grows? | unresolved |
| RR6 | Design authority and support unstated | unknown | — | "You would be our first designer: own the booking flow end to end" | Ownership may come with the co-founder deciding priorities, with no one to review design work and no research budget | `[inferred]` from the JD's scope against its silence on decision rights | Which product decisions would I make myself, and who reviews and challenges design work? | unresolved |
| RR7 | Pay, hybrid terms and named co-founder stated | positive_signal | — | "Ronan Kehoe" and "€52,000–€60,000" | The posting is specific on terms, and the message sender matches the co-founder it names | `[grounded]` JD and message | What does a good first six months look like for this role? | noted |

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, find Fernquay's own website and a careers page listing this role, with Ronan and Saoirse named. This is your own check, and it is the one thing that clears RR1 | See RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Open the invite from the email, not the chat, and confirm the sender address matches the company's site (RR3). If anyone asks you for payment, a cheque, or bank or ID details before an offer, stop and tell me | See RR3 | `[generic]` hiring-process norms | pending your approval |
| A3 | Lead with your own words: "redesigned our checkout flow" and "ran monthly usability sessions with customers", with "worked in a squad with four engineers" as the working-style line. Claim no ownership beyond what G1 confirms | See R5, R6, R7 | `[grounded]` your background | pending your approval |
| A4 | Ask RR4, RR5 and RR6 verbatim on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | The posting prefers "one messy real project". Pick a real piece of your own work you are allowed to share, and ask before spending unpaid time on a new exercise | See R3, R4, R7 | `[inferred]` from the JD's wording | pending your approval |

If you want to rehearse the call itself, mock-interview covers that.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for Fernquay's site and for its careers page were both refused. They would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | The pay search was refused. It would have moved role reality's market calibration and RR5 |
| 3. Hiring manager's public footprint | unavailable | A search on Ronan Kehoe's public professional profile was refused. It would have moved role reality's scope read and which story the plan leads with |

## Upgrade menu

- Search permission, so I can run the three declared targets above → RR1, RR5 and the role reality rows move.
- A link to the live posting on Fernquay's own careers page, or the invite's sender domain → RR1 and RR3 close.
- Your pay floor and any other non-negotiables → R2 resolves and the hard-gates line changes.
- A link to the checkout case study, which in design is the inspectable artifact → R3, R4, R5 and R7 can reach `high`.

I can also save this as `tuesday-dossier.md` to carry forward.

**Questions**

1. RR2 — Had you already applied and sent the checkout case study before Ronan's message?
2. R2 — What is your minimum salary, and is anything else about hybrid working non-negotiable?
3. G1 — In the checkout redesign, which decisions were yours, and which were set by a design lead, a product manager or the squad?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.