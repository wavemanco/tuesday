Yes, this is normal. Nothing in the offer looks like a scam to me, and your instinct is still right for other situations.

**Why the timing makes this normal**
- **When they ask:** They want these details after you accept, not at application stage. Scam jobs usually ask for them up front, before any interview or offer. You had two in-person interviews at their office, so you're past that stage.
- **PPS number:** An Irish employer needs it to register you with Revenue and run your payroll. You'll be asking the same of Marrowgate's new starters. `[generic]`
- **Bank details:** They need these to pay you. This is standard.
- **Passport:** They check right to work and ask for the original on day one, which is normal. It's a bit unusual to ask for a scan before you start. Employers often only need to see ID in person, so you could ask whether the scan can wait until your first day. If they do want it earlier, ask where it's stored and how long they keep it. `[generic]`

**Signs this is genuine**
- You met them in person twice.
- The offer matches the ad: same role, same salary range, same hybrid arrangement.
- It names a real reporting line, Declan Garvagh, Finance Manager.
- It comes from an email domain that matches the company name.
- It asks for nothing else from you. Be wary if they ever ask you to pay for equipment, training or background checks, or send you a cheque.

**Checks to make before you send anything**
1. Find the company's own website yourself and confirm the offer's email domain matches it exactly. I haven't searched for Marrowgate, so I can't confirm it exists. You can also check the housing association on the Approved Housing Bodies Regulatory Authority register.
2. Ring the office on the number from their official website, not one in the email, and ask them to confirm the offer and Declan's role. You were in the office, so you could also just message Declan.
3. When the onboarding portal link arrives, check it sits on `marrowgatehousing.ie` or a named payroll or HR provider they've told you about. Don't send these details by plain email.
4. Ask for the written contract before you accept, or accept subject to contract. Check probation, notice period, pension scheme, holiday and the exact start-date terms.

**On your fit**
You meet nearly all of it: three years of payroll, a 2024 qualification, reconciliation and Excel. The one gap is pension changes, which you've never done yourself. Mention it honestly when you accept or in your first week. Don't claim it. Pension changes are learnable on the job for someone with your background. This is my judgement from what you've told me. `[inferred]`

You have five working days to reply, so there's time to do the checks above first.

**Offer:** If you'd like, I can draft a short acceptance email that accepts subject to contract and asks about the passport timing and data handling. I'd write it only once you approve the wording.

**Questions**
1. Is there anything in the contract, pension scheme or start date you want checked before you accept? (You can answer, or skip.)

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.