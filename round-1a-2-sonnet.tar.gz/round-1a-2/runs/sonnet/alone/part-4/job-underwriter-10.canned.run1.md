**Yes, it's worth taking the call. On what I could check, the posting and the company are legit: `conditional_go`.** Three things need settling first, listed under "What would change this".

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5 · adjacent: R7 (Own the booking flow end to end)
- `important` — direct: R8 · adjacent: R6 (Research calls with school owners), R9 (You would be our first designer)

R7 — checkout is one part of a booking flow, and the limit is named; R6 — usability sessions with customers are a bridge to owner calls; R9 — a bridge, never solo before; R2 (`none`) — your pay floor wasn't given.

**Opportunity ledger.** The employer matches its own pages and the pay sits inside the market range (RR1, RR5). Open items are the WhatsApp channel (RR2), the equity terms (RR3) and who decides priorities for a sole designer (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this** (conditions for go):
  1. R2: the €52,000–€60,000 base works for you.
  2. RR2: the emailed invite comes from a Fernquay address and matches the careers page.
  3. RR3: the equity terms turn out to be real and reasonable.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. It has six people, is based in Galway, was founded in 2023 by Ronan Kehoe and Saoirse Doyle, and is funded by its customers | `[grounded]` fernquay.example/about, fetched |
| Posting | A live careers page lists the same role: first design hire, hybrid, two days a week in Galway, €52,000–€60,000 plus equity. It says to apply with one real project to a jobs@ address | `[grounded]` fernquay.example/careers/product-designer, fetched |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` your pasted posting |
| Hiring manager | Ronan Kehoe is listed as co-founder and CEO, and before Fernquay was a product lead at a Galway travel-software company for five years. I read a search snippet only, not the full profile | `[grounded]` LinkedIn result for his name |
| Scope read | A sole-designer role at a small, customer-funded company. The scope is real, and nothing in the posting states success measures or first-year outcomes | `[inferred]` from the posting's silence on outcomes |
| Market calibration | A 2026 Irish survey of product designers with 3 to 5 years' experience (n=520) gives a median base of €57,000, with the middle half between €51,500 and €62,000. The posted band sits inside that. It is a market band, not a promise about this employer | `[generic]` Tillerby 2026 survey; `[grounded]` posted band |
| Unknowns | Equity terms, who sets design priorities, the call's panel and format, and success measures | `[inferred]` from silence in the posting and pages |
| Contradictions | None between your pasted posting and the careers page. Saoirse is named as co-founder on the about page, and "CTO" is not on the pages I read | `[grounded]` both pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You said you moved back to Galway, so the term is met. You didn't state office days as a constraint, hence `medium` | `[grounded]` your message | none |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | No pay floor stated, so whether the band meets it is not established | `[grounded]` posting and careers page; no floor given | G1: state your floor |
| R3 | 3+ years of product design | must_have | direct | medium | none | 4 years at a Dublin travel-booking company, self-reported and not yet inspected. Length of experience is graded as a requirement, not a gate | `[grounded]` your background | A portfolio link would raise it |
| R4 | Strong Figma | must_have | direct | medium | none | Figma daily. Confirmed and plausible, with no artifact inspected | `[grounded]` your background | Portfolio or Figma file |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. That is user research you ran, on your own account | `[grounded]` your background | Session guide or findings note |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout in a travel-booking company, which is close domain work. Limit: checkout is one stage, and the posting's scope is the whole flow, owned alone. A booking flow for tour operators usually spans availability, selection, payment and changes | `[grounded]` your checkout redesign; `[generic]` how booking flows are typically divided | G2 |
| R6 | Run research calls with school owners | important | adjacent | medium | transferability | Your sessions were usability testing with travel customers. Limit: owner interviews at small businesses are a different audience and often a different method, and you haven't said whether you've run them | `[grounded]` your sessions; `[generic]` that discovery calls differ from usability tests | G3 |
| R8 | Work directly with engineers; ship alongside two | important | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R9 | You would be our first designer | important | adjacent | medium | transferability | You have owned a redesign and a research cadence. Limit: you have never been the only designer, so setting process and review without design peers is untested | `[grounded]` your message | Bridge case in G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R2, hard_gate) | hard_gate | The band is posted, but your floor isn't stated | A gate not yet settled keeps the decision at `conditional_go` | A base figure below which you'd decline, and how you weigh equity against cash | None needed | `[grounded]` floor not given |
| G2 | Scope of booking-flow ownership (R7, must_have) | transferability | Checkout redesign is confirmed. Other stages are not mentioned | This is the posting's headline responsibility, and a bridge with named limits reads stronger than a claim | Owning availability, search, basket, payment, confirmation emails or post-booking changes, even in part | Before/after screens, a case study, a flow diagram | `[inferred]` bridge from the checkout work; `[generic]` that this is the likeliest probe |
| G3 | Research with business owners (R6, important) | transferability | Customer usability sessions only | The calls are with owners, and a different audience changes the method | Calls with operators, agents or B2B customers at your last job | Interview guide, synthesis note | `[grounded]` your background; `[generic]` that the method differs |
| G4 | First and only designer (R9, important) | transferability | Squad work with engineers, with design peers implied by "never the only designer" | They will probe how you'd work unsupported | Setting up a design file, research cadence or review habit that others adopted | A file structure, a process note | `[inferred]` from your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer matches its own pages | positive_signal | — | "six people in Galway making booking software" | The company exists as described, with a live, consistent posting. Both pages are self-published, so this shows it exists, not that it is sound | `[grounded]` about and careers pages fetched; `[generic]` that self-published pages are weaker than independent ones | Could you name two schools using Kelproster that I can look at? | noted |
| RR2 | Recruiting contact arrived on WhatsApp | unknown | — | "I have emailed you a calendar invite with the video link. Just shout here if the time does not suit." | The careers page gives only an email route, so the number likely came from your application. The message asks for nothing but a call: no money, documents or details. A WhatsApp scheduling note is common at small companies | `[inferred]` from the message and the careers page; `[generic]` that small firms often schedule by chat | Could you send the invite from your Fernquay address and confirm who'll be on the call? | unresolved |
| RR3 | Equity terms not stated | unknown | — | "plus 0.5–1% equity" | The value depends on vesting, share class or option strike, and dilution. A customer-funded company has no outside valuation to anchor it | `[generic]` how equity terms work; `[grounded]` "funded by its customers" | What is the vesting schedule, the share class or strike price, and the fully diluted share count? | unresolved |
| RR4 | Decision rights for a sole designer | unknown | — | "own the booking flow end to end" | "Own" may mean final say or may mean delivery. With no design lead, priorities probably sit with the co-founder | `[inferred]` from the posting's single named collaborator | Who decides priorities for the booking flow, and who reviews design work? | unresolved |
| RR5 | Pay inside market range, stated openly | positive_signal | — | "Salary €52,000–€60,000" | A published band and a named co-worker show some transparency. The band is the posting's, the survey figure is the market's | `[grounded]` posting and careers page; `[generic]` Tillerby 2026 survey | Is the base negotiable within the band by experience? | noted |

## Application plan

Everything here is proposed, and nothing is final until you approve it, including the prose advice.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the invite's sender address before joining. If it isn't a Fernquay address, write to the jobs@ address on their careers page, not the chat | See RR2 | `[grounded]` careers page lists that route | pending your approval |
| A2 | Lead with the checkout redesign and the monthly sessions. Say plainly that checkout was one stage and that you always had design peers | See R7, R9 | `[grounded]` your background | pending your approval |
| A3 | Prepare one real, unpolished project to show, since they've said they prefer that to a polished deck | They state it themselves | `[grounded]` the posting | pending your approval |
| A4 | Expect product questions about booking flows, since Ronan's last role was in travel software | His background | `[inferred]` from the LinkedIn snippet | pending your approval |
| A5 | Ask RR1 to RR5's questions verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A6 | Decide your base floor and how you value equity before the call | See R2 | `[grounded]` R2 | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea-kayak surf schools Galway" and "Fernquay careers product designer". Fetched "About Fernquay" (fernquay.example/about) and "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Moved role reality's organization, posting and contradictions rows, and RR1 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup 2026 equity", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration row and RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe), snippet only. Moved role reality's hiring-manager row and A4 |

## Dossier offer and upgrade menu

I can save all this as `tuesday-dossier.md` if you'd like to keep or reuse it.

- Your pay floor → R2 and G1 close, and the decision likely moves to `go`.
- The invite's sender address, or an answer to RR2's question → RR2 closes.
- A portfolio link or your checkout case study → R3, R4, R5 and R7 can reach `high`.
- Fernquay's answers on equity and decision rights → RR3 and RR4 close.
- A deeper diligence pass on Fernquay (customers, funding, staff and candidate reports, recent news; up to 5 more searches and 2 more fetches) would add independent evidence beyond their own pages. Say the word and it runs.
- Rehearsing for the call is mock-interview's job.

## Questions

G1 — What's the lowest base salary you'd accept, and how much would 0.5–1% equity in a customer-funded company move that for you?

G2 — At your Dublin company, which stages of the booking journey besides checkout did you own, even partly? What was the outcome, and is there a screen or case study you can share?

G3 — Have you run research calls with business customers, such as operators or agents, as opposed to consumer usability sessions? What did you own in them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.