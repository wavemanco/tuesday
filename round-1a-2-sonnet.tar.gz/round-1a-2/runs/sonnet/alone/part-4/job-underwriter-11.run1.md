I'll read the reference files the skill requires before building the assessment.
Femi, the first role is worth applying to, with conditions. The second isn't worth your time as a priority.

## Decision snapshot

**Duinvaart Cold Chain, Operations Analyst — yes, worth applying. R2, R3 and R4 (your matches on the must-have tier) are `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Hybrid, three days a week in Rotterdam office)
- `must_have` — direct: R2, R3, R4
- `important` — direct: R5a · adjacent: R6 (Work with depot managers on route changes) · unclear: R5b (Temperature compliance)
- `preferred` — adjacent: R7 (Dutch a plus)

R5b — temperature compliance is not established either way; R1 — the Rotterdam days depend on where you live, which I don't know.

**Opportunity ledger.** The employer is unchecked (RR1) and pay is not stated (RR2). The specific, measurable responsibilities run the other way (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, three days a week in Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) three Rotterdam days a week works for you (R1); (3) the salary is acceptable (RR2).

**Kroonhaven Foods, Supply Planner — no, not worth prioritising. R12, R14 and R16 are `absent` must-haves, and you've told me you have never worked in planning. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R11 (On-site in Utrecht)
- `must_have` — adjacent: R15 (Fluent Dutch) · unclear: R13 (Advanced Excel) · absent: R12 (3+ years supply or demand planning in FMCG), R14 (SAP IBP or a similar planning system), R16 (Own the 13-week supply plan)
- `important` — adjacent: R17 (Run the weekly S&OP meeting)

R12, R14, R16 — the planning core is not in your background, by your own account; R17 — the weekly route-performance review you ran is a real bridge, its limit named in the map.

**Opportunity ledger.** The role is concretely scoped (RR13). The employer is unchecked (RR11) and pay is not stated (RR12).

- **Hard gates:** none failed; unconfirmed: R11 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** planning work you did outside your title (forecasting, capacity or supply balancing) that you owned; exposure to a planning system; fluent Dutch. The decision is a recommendation, and it is yours to overrule.

## Role reality

**Duinvaart**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam. Existence and live posting not checked | `[grounded]` JD header |
| Mandate | Track on-time delivery and temperature compliance across the refrigerated fleet, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| Requirements | Must-have: 2+ years logistics or operations analysis, strong SQL, Power BI or Tableau. Preferred: Dutch | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| First-90-days and first-year outcomes | Not stated in the posting | `[grounded]` JD silent |
| Scope read | An analysis-and-liaison post with no stated team-management or budget duties | `[inferred]` from the responsibilities listed against the absence of either |
| Market calibration | Not run, so no band is given. The posting states no pay | `[grounded]` JD silent on pay; search refused |
| Unknowns | Salary, day-to-day working language, team size and reporting line, contract type | — |
| Contradictions | None inside the posting. No second source to compare against | `[grounded]` JD only |

**Kroonhaven**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht, chilled ready-meals range. Existence and live posting not checked | `[grounded]` JD header |
| Mandate | Own the 13-week supply plan, balance production capacity against the forecast, run the weekly S&OP meeting | `[grounded]` JD |
| Requirements | 3+ years supply or demand planning in FMCG, advanced Excel, SAP IBP or a similar planning system, fluent Dutch | `[grounded]` JD |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| First-90-days and first-year outcomes | Not stated in the posting | `[grounded]` JD silent |
| Scope read | A single-owner planning seat, since the plan is "owned" by this role | `[inferred]` from the JD's "own" and "run" verbs |
| Market calibration | Not run. The posting states no pay | `[grounded]` JD silent on pay; search refused |
| Unknowns | Salary, who owns the forecast the plan is balanced against, team size | — |
| Contradictions | None inside the posting. No second source to compare against | `[grounded]` JD only |

## Evidence map

Your background was typed into the chat, so it counts as self-report. That caps every claim at `medium` until an artifact is inspected.

**Duinvaart**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | none | hard_gate | You gave no constraints, so there is no statement of yours to grade. The posting's term is stated and whether it fits you is not settled | `[grounded]` JD term; no constraints given | G3: confirm the days work |
| R2 | 2+ years logistics or operations analysis | must_have | direct | medium | none | 4 years as an operations analyst at a parcel carrier in Amsterdam, confirmed and specific, no inspectable artifact yet | `[grounded]` your intake statement | none |
| R3 | Strong SQL | must_have | direct | medium | none | "SQL daily" is specific; the depth behind "strong" is not shown by anything inspected | `[grounded]` your intake statement | optional: a sanitized query sample would raise to high |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including the on-time delivery dashboard depot managers use. Which parts you built is not stated | `[grounded]` your intake statement | a sanitized dashboard screenshot would raise to high |
| R5a | Track on-time delivery across the fleet | important | direct | medium | none | On-time delivery is the dashboard you work with; the fleet here is refrigerated, which is a different operation | `[grounded]` your statement; `[inferred]` that the metric carries across | none |
| R5b | Track temperature compliance | important | unclear | none | discovery | Nothing you've said touches temperature-controlled freight or compliance against a threshold | `[grounded]` intake silent | G1 |
| R6 | Work with depot managers on route changes | important | adjacent | medium | discovery | You ran a weekly route-performance review and depot managers use your dashboard. Whether this led to route changes, and who owned them, is not stated, so I took the lower reading | `[grounded]` your statement; the limit is `[inferred]` from the absence of any stated route changes | G2 |
| R7 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch is real and short of fluent. As a "plus" it is a differentiator, not a screen | `[grounded]` your statement; `[inferred]` from the posting's "a plus" | state it as "conversational" |

**Kroonhaven**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R11 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | The posting's term is stated and you gave no constraints | `[grounded]` JD term; no constraints given | confirm whether Utrecht on-site works (G11) |
| R12 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | Your own statement that you have never worked in planning. A years requirement is graded on fit, not treated as a gate | `[grounded]` your statement; `[generic]` that a screen may apply a titled-years line literally | G12 closure path |
| R13 | Advanced Excel | must_have | unclear | low | discovery | SQL and Power BI daily is indirect context; Excel depth is not mentioned | `[grounded]` intake silent on Excel | carried, not asked this turn, because R12, R14 and R16 outweigh it |
| R14 | SAP IBP or a similar planning system | must_have | absent | none | capability | SQL and Power BI are analysis and reporting tools, not planning systems | `[inferred]` from the tools you named against the requirement | G12 closure path |
| R15 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational Dutch is the closest evidence. The limit is that "fluent" is the posting's bar, and running a meeting in Dutch probably tests it | `[grounded]` your statement; `[inferred]` about the meeting | G13 |
| R16 | Own the 13-week supply plan, balancing capacity against the forecast | must_have | absent | none | capability | Nothing you described involves owning a forward plan. A route-performance review looks at how routes performed | `[grounded]` your statement; `[inferred]` about what the review covers | G12 closure path |
| R17 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review. Limit: an S&OP meeting reconciles a forward demand, supply and finance plan, which the review did not | `[grounded]` your statement; `[generic]` what S&OP reconciles | G12 closure path |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R5b, important) | discovery | No mention of temperature-controlled freight or threshold compliance | It is the one cold-chain-specific duty in the title's first line, so it decides how the application is positioned | Temperature-sensitive parcels (food, pharma); compliance or breach reports against a threshold or SLA; an exceptions dashboard | A sanitized compliance or exceptions report | `[grounded]` intake silence; `[inferred]` about positioning |
| G2 | Route changes with depot managers (R6, important) | discovery | A weekly review and a dashboard depot managers use; no stated outcome | Separates "analysed routes" from "changed routes", and your CV line depends on which is true | A review that led to a route or schedule change; a depot manager asking you for a new view of the data | A review pack or a before-and-after metric, sanitized | `[grounded]` your statement; `[generic]` that interviews probe this line |
| G3 | Rotterdam three days a week (R1, hard_gate) | hard_gate | Your location and commute limits are not given | A gate the inputs don't settle stays open until you answer | Not a recall question — a fact about your situation | None needed | `[grounded]` no constraints given |
| G11 | On-site in Utrecht (R11, hard_gate) | hard_gate | Same, for the Utrecht office | Same | Same | None needed | `[grounded]` no constraints given |
| G12 | Planning core (R12, R14, R16, must_have; R17, important) | capability | Absent by your own statement; R17 has a bridge | The status rests on these rows | Closure path: an analyst seat inside a planning team, where SQL and Power BI are the entry skills and planning is learned on the job | The weekly review's agenda and outputs, if you ever want to make the R17 bridge | `[grounded]` your statement; `[generic]` that such seats exist |
| G13 | Fluent Dutch (R15, must_have) | transferability | Conversational, short of the posting's bar | It is the one must-have you partly meet | The bridge is real conversational Dutch; the limit is meetings and written Dutch | A Dutch-language reference, certificate or sample | `[grounded]` your statement |

## Opportunity risk register

**Duinvaart**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The entity and posting are unchecked because search was refused. The entity may be too new or small to have a footprint, or the posting may be stale or aggregated | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | The posting as pasted contains no pay figure | Pay may sit anywhere against market; no band was calibrated | `[grounded]` JD silent; band not run | What salary range is budgeted for this role? | unresolved |
| RR3 | Concrete, measurable responsibilities | positive_signal | — | "Track on-time delivery and temperature compliance … build weekly dashboards in Power BI" | The work is specified in terms you can check at interview | `[grounded]` JD | What does a good first quarter look like for this role? | noted |
| RR4 | Working language unstated | unknown | — | "Dutch a plus" | Day-to-day language with depot managers may be Dutch even if the posting is read in English | `[inferred]` from "a plus" against silence on working language | What language do the team and depot managers work in day to day? | unresolved |

**Kroonhaven**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR11 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Same as RR1: unchecked because search was refused | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR12 | Pay not stated | unknown | — | The posting as pasted contains no pay figure | No band was calibrated | `[grounded]` JD silent; band not run | What salary range is budgeted for this role? | unresolved |
| RR13 | Concretely scoped mandate | positive_signal | — | "Own the 13-week supply plan … run the weekly S&OP meeting" | The role's outputs are specific | `[grounded]` JD | Who owns the forecast the plan is balanced against? | noted |

## Application plan

Every row below is proposed. That includes the positioning rows and the resume line, and nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Duinvaart resume line, `resume_edits_pending_approval`: "Operations analyst, parcel carrier, Amsterdam (4 years). Ran the weekly route-performance review; Power BI on-time delivery dashboard used by depot managers; SQL and Power BI daily." I did not write "built", because your sentence does not say what you did on the dashboard | R2, R3, R4, R6 | `[grounded]` each clause traces to your own sentences | pending your approval |
| P1 | Duinvaart positioning: lead with R2, R3, R4 and the weekly review, and say plainly that temperature compliance is new to you (R5b) unless your answer to G1 changes that | R5b | `[grounded]` R5b row | pending your approval |
| P2 | State Dutch as "conversational" on the CV and in any message, never "fluent" | R7, R15 | `[grounded]` your statement | pending your approval |
| A1 | Before investing effort, confirm each employer and posting on its own careers site | RR1, RR11 | `[grounded]` the register entries | pending your approval |
| Q1 | Ask RR2, RR3 and RR4 verbatim in the Duinvaart loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| K1 | Kroonhaven, if you apply anyway: describe the review as a weekly route-performance review, not as S&OP, and claim no planning experience | R12, R16, R17 | `[grounded]` R12, R16, R17 rows | pending your approval |
| K2 | Look at analyst seats inside planning teams (demand or supply planning analyst, S&OP analyst, supply chain analytics) | G12 | `[generic]` role-family pattern, not a claim about any employer | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht chilled ready meals" were refused, so no page was read. It would have moved the employer-not-established entries RR1 and RR11 and each Contradictions row; all stay unresolved |
| 2. Role-family sweep | unavailable | Searches "operations analyst logistics Netherlands salary Rotterdam" and "supply planner FMCG Netherlands salary SAP IBP requirements" were refused. It would have moved the market calibration rows and the pay entries RR2 and RR12 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I haven't retried the searches.

I can write this up as `tuesday-dossier.md` if you'd like to keep it; just say so.

## Upgrade menu

- A link to each posting on its employer's own site, or the recruiter's email domain → RR1 and RR11 can be checked without search.
- Search permission → targets 1 and 2 would run: employer existence and a market pay band. A deeper pass after that (up to 5 more searches and 2 more fetches) is optional.
- Your CV, or a sanitized dashboard screenshot → R2, R3 and R4 can rise from `medium` to `high`.
- Where you live and any commute or pay limits → R1 and R11 settle, and RR2 and RR12 can be set against your floor.
- The hiring manager's name → role reality's scope read and which story to lead with.
- Detail on your Excel use → R13.

## Questions

**R1/G3** — Is three days a week in Rotterdam workable for you, and where would you be commuting from?
**R5b/G1** — At the parcel carrier, did you ever report on temperature-sensitive freight (food or pharma, say), or on compliance against a threshold rather than just on-time delivery? Even a small case counts.
**R6/G2** — Which parts of the on-time delivery dashboard and the weekly route-performance review were yours, and did either lead to route changes agreed with depot managers?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.