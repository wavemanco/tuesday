I'll read the skill's reference files before building the assessment.
**Duinvaart Cold Chain: yes, worth applying, once the posting checks out. Kroonhaven Foods: no, I wouldn't spend your time on it.**

Web search was refused in this session, so nothing about either employer has been checked. Everything below comes from the two postings and your typed background, which I'm treating as CV-equivalent.

## Decision snapshot

### Duinvaart Cold Chain, Operations Analyst: Yes, worth applying to, once the posting verifies. Status: `conditional_go`.

**Fit ledger.**

- `hard_gate`: unclear: D1 (Hybrid, three days a week in Rotterdam office)
- `must_have`: direct: D2, D3, D4
- `important`: direct: D5 · adjacent: D7 (Work with depot managers on route changes) · unclear: D6 (Track temperature compliance)
- `preferred`: adjacent: D8 (Dutch a plus)

D6: cold-chain temperature compliance isn't yet evidenced; D7 (`medium`): a review you ran, with route changes unconfirmed; D1: office days not yet checked against your situation.

**Opportunity ledger.** The employer isn't established (DR1) and the pay is withheld (DR2). The scope is bounded and matches your daily work (DR3).

- **Hard gates:** none failed; unconfirmed: D1 (Hybrid, three days a week in Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is live on Duinvaart's own careers page and the employer checks out (DR1); (2) three office days in Rotterdam work for you (D1); (3) temperature compliance turns out to be learnable or already in your history (D6).

### Kroonhaven Foods, Supply Planner: No. K2 and K5 are absent, and K3 is only adjacent. Status: `no_go`.

**Fit ledger.**

- `hard_gate`: unclear: K1 (On-site in Utrecht)
- `must_have`: adjacent: K3 (Fluent Dutch) · unclear: K4 (Advanced Excel) · absent: K2 (3+ years supply or demand planning in FMCG), K5 (SAP IBP or a similar planning system)
- `important`: adjacent: K6 (Run the weekly S&OP meeting)

K2, K5: no planning history, which you stated yourself; K3 (`medium`): conversational Dutch against a fluent requirement; K6 (`medium`): the weekly review you ran is the nearest match, its limit named.

**Opportunity ledger.** The employer isn't established (KR1) and the pay is withheld (KR2). The mandate is concrete (KR3).

- **Hard gates:** none failed; unconfirmed: K1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** K2 and K5 would need to be wrong, meaning real planning-system and forecast-ownership history exists that you haven't mentioned. K3 would also need to reach fluency. Neither is likely from what you've told me.

## Role reality

| Role | Element | What it is | Provenance |
|---|---|---|---|
| Duinvaart | Organization | Duinvaart Cold Chain, Rotterdam, a refrigerated fleet operator by its own description; not established beyond the posting | `[grounded]` JD header; research refused |
| Duinvaart | Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| Duinvaart | Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Duinvaart | Scope read | A bounded analyst post with reporting and a stakeholder loop, no stated ownership of budgets or headcount | `[inferred]` from the responsibilities listed against the absence of authority language |
| Duinvaart | Market calibration | Two or more years in logistics analysis with SQL and a BI tool is a standard mid-level analyst bar; no pay band, because no search ran | `[generic]` role-family pattern, no figures |
| Duinvaart | Unknowns | Salary; contract type; who the role reports to; whether Dutch is used day to day | `[grounded]` JD is silent |
| Kroonhaven | Organization | Kroonhaven Foods, Utrecht, a chilled ready-meals maker by its own description; not established beyond the posting | `[grounded]` JD header; research refused |
| Kroonhaven | Mandate | Own the 13-week supply plan, balance production capacity against forecast, run the weekly S&OP meeting | `[grounded]` JD |
| Kroonhaven | Working pattern | On-site in Utrecht | `[grounded]` JD |
| Kroonhaven | Scope read | A full planning post, where owning the plan and chairing S&OP is the job itself | `[inferred]` from the responsibilities as written |
| Kroonhaven | Market calibration | Three or more years of FMCG planning plus fluent Dutch is a typical bar for a planner who owns the plan and chairs S&OP; no pay band, because no search ran | `[generic]` role-family pattern, no figures |
| Kroonhaven | Unknowns | Salary; contract type; reporting line; planning system in use | `[grounded]` JD is silent |
| Both | Contradictions | None inside either posting | `[grounded]` JD text only; no careers pages could be compared |

## Evidence map

**Duinvaart**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | You haven't stated a location or commute constraint, so the gate is open | `[grounded]` JD term; no constraint from you | Gate question below |
| D2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier; typed, not yet inspected | `[grounded]` your background as typed | none |
| D3 | Strong SQL | must_have | direct | medium | none | SQL daily; "strong" is the posting's word, and you haven't described depth | `[grounded]` your background as typed | A sanitized query or schema sample would raise to high |
| D4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including the on-time delivery dashboard your depot managers use; whether you built it is unconfirmed | `[grounded]` your background as typed | A dashboard screenshot with figures removed would raise to high |
| D5 | Track on-time delivery | important | direct | medium | none | The dashboard above is on-time delivery reporting | `[grounded]` your background as typed | none |
| D6 | Track temperature compliance on a refrigerated fleet | important | unclear | low | discovery | Nothing you've said touches temperature data; an unconfirmed thread at most, and it may exist | `[grounded]` silence in your background | DG1 |
| D7 | Work with depot managers on route changes | important | adjacent | medium | discovery | You ran the weekly route-performance review and depot managers use your dashboard. Limit: whether the review led to route changes you worked on is unstated | `[grounded]` your background as typed | DG2 |
| D8 | Dutch a plus | preferred | adjacent | medium | none | Conversational Dutch against a "plus"; fully claimable as stated, never as fluent | `[grounded]` your statement | none |

**Kroonhaven**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No location or commute constraint stated | `[grounded]` JD term; no constraint from you | Gate question below |
| K2 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You stated you've never worked in planning, and a parcel carrier isn't FMCG | `[grounded]` your statement | KG1 |
| K3 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational Dutch is a real bridge. Limit: running a weekly cross-functional meeting in Dutch is a fluent-level task | `[grounded]` your statement; `[generic]` that chairing meetings sits at the fluent end | KG2 |
| K4 | Advanced Excel | must_have | unclear | none | discovery | Your SQL and Power BI work doesn't establish Excel depth | `[grounded]` silence in your background | KG3 |
| K5 | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning work, so no planning-system work | `[grounded]` your statement | KG1 |
| K6 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review. Limit: it looked back at performance, where S&OP agrees a forward plan across functions | `[grounded]` your background as typed; `[generic]` on what S&OP involves | KG1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| DG1 | Temperature compliance (D6, important) | discovery | Nothing in your background touches temperature data | The only domain-specific responsibility in the posting; it decides whether this reads as an easy move or a stretch | SLA or breach tracking on time-critical or sensitive parcels; any chilled, pharma or food flows at the carrier; exception reporting against a threshold | A dashboard screenshot with figures removed, or a metric definition | `[grounded]` background silent; `[generic]` that cold-chain roles weigh this domain term |
| DG2 | Route changes with depot managers (D7, important) | discovery | A weekly review you ran, and depot managers who use your dashboard; no confirmed route change | The posting's stakeholder loop is the part of the job beyond reporting | A review that ended in a re-sequenced route or a changed cut-off time; a depot manager acting on a finding of yours | A review pack, a change log, or a slide from the weekly review | `[grounded]` background as typed |
| KG1 | Planning, planning systems and S&OP (K2, K5, K6) | capability | You stated no planning experience | Two `must_have` rows are absent and this is the core of the post | A realistic path is a planning-adjacent analyst role first, and that is a pattern, not a promise | None to request now | `[grounded]` your statement; `[generic]` on how planners are usually hired |
| KG2 | Fluent Dutch (K3, must_have) | transferability | Conversational Dutch | Fluent Dutch is a must-have and the meeting runs in it | Any work done in Dutch, such as written reports or meetings you took part in | A Dutch-language document you wrote | `[grounded]` your statement |
| KG3 | Advanced Excel (K4, must_have) | discovery | Silent | Cheap to resolve, but it can't rescue the row set above | Models with lookups, pivots or macros you maintained | A sanitized workbook | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| DR1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| DR2 | Pay not stated | unknown | — | (no figure in the posting) | The pay may sit anywhere; the posting withholds it | `[grounded]` the posting's silence | What salary range is budgeted for this post? | unresolved |
| DR3 | Bounded, concrete responsibilities | positive_signal | — | "Track on-time delivery and temperature compliance across our refrigerated fleet" | The scope is defined and measurable | `[grounded]` JD | Which three metrics would I be judged on after six months? | noted |
| KR1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Same possibilities as DR1 | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| KR2 | Pay not stated | unknown | — | (no figure in the posting) | The posting withholds the figure | `[grounded]` the posting's silence | What salary range is budgeted for this post? | unresolved |
| KR3 | Concrete, owned mandate | positive_signal | — | "Own the 13-week supply plan for our chilled ready-meals range" | The role has clear ownership | `[grounded]` JD | Who chairs S&OP today, and what happens if the plan misses? | noted |

Both employers are unverified, so each decision is capped by the standing entry. That cap binds the Duinvaart `conditional_go` and doesn't change the Kroonhaven `no_go`.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Proposed CV line for Duinvaart: "Power BI and SQL daily, including the on-time delivery dashboard used by depot managers." If you built the dashboard, tell me and the line can say so. | D3, D4, D5 | `[grounded]` your own sentence | resume_edits_pending_approval |
| E2 | Proposed CV line for Duinvaart: "Ran the weekly route-performance review." Anything about route changes waits on DG2. | D7 | `[grounded]` your own sentence | resume_edits_pending_approval |
| E3 | Describe your Dutch as "conversational" everywhere; the Duinvaart posting only calls Dutch a plus, and a fluent claim would be checked in conversation | D8, K3 | `[grounded]` your statement | pending your approval |
| A1 | Check Duinvaart's own careers page for the posting before applying, then apply | DR1 | `[grounded]` register | pending your approval |
| A2 | Ask DR1, DR2 and DR3 verbatim in the first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Skip Kroonhaven. If you apply anyway, ask KR1 and KR2 verbatim first | K2, K5 | `[grounded]` map rows | pending your approval |

Nothing in this plan is applied until you approve it, and that covers the CV lines and the positioning notes alike.

## Evidence status

Verified: none yet. No CV was supplied; your typed background stands in as self-report.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam Operations Analyst" and "Kroonhaven Foods Utrecht Supply Planner chilled ready-meals"; both were refused. They would have settled DR1 and KR1 and checked the postings are live |
| 2. Role-family sweep | unavailable | Searched "operations analyst logistics Rotterdam salary Netherlands SQL Power BI" and "supply planner FMCG Netherlands salary S&OP SAP IBP"; both were refused. They would have put real pay bands in the market calibration rows and the pay entries DR2 and KR2 |
| 3. Hiring manager's public footprint | n/a | No name was given in either posting, so there was no query to form |

## Closing

I can turn this into a saved `tuesday-dossier.md` whenever you want it.

**Upgrade menu**
- A link to each live posting, or the company's own careers page, would settle DR1 and KR1 and could take Duinvaart from `conditional_go` to `go`.
- Your CV, or a sanitized dashboard screenshot and query sample, would raise D3 and D4 to `high` and show whether you built the dashboard.
- Your constraints (where you live, commute limits, pay floor) would settle D1 and K1.
- Search permission, or the salary figures from the recruiters, would let me put real bands against DR2 and KR2.
- A hiring manager's name would open research target 3.

**Questions**

D1, K1: Where are you based, and are three office days a week in Rotterdam (and five on-site in Utrecht, if you still wanted that one) workable for you?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

DG2: Did your weekly route-performance review ever lead to a route change you worked on with a depot manager, and what part was yours?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

DG1: Have you tracked anything time- or temperature-sensitive at the carrier, such as chilled, pharma or food parcels, or breaches of a strict delivery window?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.