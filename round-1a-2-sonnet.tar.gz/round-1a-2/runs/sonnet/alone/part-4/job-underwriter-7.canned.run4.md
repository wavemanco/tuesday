I'm reading the skill's output rules and the worked example so the assessment follows its format. I'll deliver it next.
**Yes, worth applying to.** R1 and R2, your two hard gates, are `direct`, and so is the one-year experience requirement (R3). Status: `conditional_go`.

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R4 (clear, timely written records on an EPR)
- `important` — direct: R6a, R7 · adjacent: R5 (wound and leg-ulcer care), R10 (care in patients' own homes), R11 (own caseload) · unclear: R6b (continence care), R8 (care planning), R9 (end-of-life visits)
- `preferred` — absent: R12 (Doppler assessment)

R11 — a credible bridge, its limit named; R4 (`low`) — waiting on a recall answer; R12 — your own statement that you haven't done it.

**Opportunity ledger.** The advert is sound on what it shows: pay is stated (RR2), and support and a named contact are offered (RR5). Open items are that the post isn't confirmed on the employer's own site (RR1), and that contract terms and working pattern are unstated (RR3, RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post is confirmed open on the employer's own channel (RR1); (2) you answer the records and end-of-life questions below truthfully, so the application speaks to R4 and R9; (3) the caseload bridge is framed as home visiting under discharge-to-assess, never as district nursing (R10, R11).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health is a community interest company. It runs adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. It was founded in 2015 and has 410 staff across four locality hubs | `[grounded]` About page fetched via search result |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, all on an EPR. A small own caseload with a senior community nurse supporting | `[grounded]` advert |
| Pay | £31,050–£37,800 plus mileage, with pool cars provided | `[grounded]` advert |
| First 90 days / first year | Not stated | `[grounded]` advert silent |
| Scope read | An entry-level community post. The caseload is small and supported, and only one year post-registration is required. Doppler is desirable, not essential | `[inferred]` from the essential and desirable lists |
| Market calibration | A 2026 survey of Band 5 community staff nurses in England puts median basic pay at £34,300, with an interquartile range of £32,400 to £36,600. The advert's range spans that band. This is a survey pattern, not this employer's offer | `[generic]` survey; `[grounded]` advert range |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. Publicly, she has spoken on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` speaker page |
| Unknowns | Contract basis and terms, caseload size, rota and weekend cover, the EPR system, how mileage works alongside pool cars | `[grounded]` advert silent |
| Contradictions | None between the advert and the About page. The posting itself couldn't be confirmed on the employer's own site (RR1) | `[grounded]` About page; careers address returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state it as Registered Nurse (Adult), active, revalidation due March 2028. Specific, but no artifact inspected | `[grounded]` CV | none; checking the register entry is yours |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full UK licence, category B. Pool cars are provided, so no vehicle is needed | `[grounded]` CV and advert | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as an acute medical ward staff nurse. This is a length-of-experience requirement, not a gate, and five years clears it | `[grounded]` CV | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | Your CV says nothing about records or an EPR. Ward nursing generally involves documentation, but I won't infer your practice | `[grounded]` CV silence; `[generic]` ward nursing involves records | G1 |
| R5 | Wound and leg-ulcer care | important | adjacent | medium | transferability | Wound care including pressure ulcers and surgical wounds is stated. Limit: leg ulcers and compression are not in your CV | `[grounded]` CV | G3 |
| R6a | Catheter care | important | direct | medium | none | Stated plainly in your CV | `[grounded]` CV | none |
| R6b | Continence care | important | unclear | low | discovery | Your CV states catheter care only. Whether you did wider continence work is unknown | `[grounded]` CV silence | G6 |
| R7 | Insulin administration | important | direct | medium | none | Stated in your CV | `[grounded]` CV | none |
| R8 | Care planning | important | unclear | low | discovery | Your CV doesn't mention care planning | `[grounded]` CV silence | G6 |
| R9 | End-of-life visits | important | unclear | low | discovery | Your CV is silent on end-of-life care, on the ward or at home | `[grounded]` CV silence | G2 |
| R10 | Caring for housebound adults in their own homes | important | adjacent | medium | transferability | 18 months seconded to discharge-to-assess, visiting patients at home in their first week after discharge. Limit: that is a short post-discharge window, not ongoing care of long-term housebound patients | `[grounded]` CV; limit `[inferred]` from the advert's wording | G4 |
| R11 | A small caseload of your own | important | adjacent | low | transferability | You confirm you've never held your own caseload. The nearest evidence is the discharge-to-assess visiting. Whether you planned your own visit list isn't stated | `[grounded]` your statement and CV | G4 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You confirm you've never done one. The advert marks it desirable, not essential | `[grounded]` your statement and advert | G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records on an EPR (R4, must_have) | discovery | Nothing about records or systems in your CV | It's the one essential row not yet evidenced, and it's cheap to close | Naming the EPR used on the ward or in discharge-to-assess; documenting home visits; record audits or documentation feedback | A system name, a record-keeping audit, a reference comment | `[grounded]` CV silence; `[inferred]` that it is cheap to close |
| G2 | End-of-life visits (R9, important) | discovery | No end-of-life work stated | End-of-life visits are named in the advert's duties | Caring for dying patients on the ward; anticipatory medicines or rapid discharge for end-of-life patients; supporting families | A competency record, a reference | `[grounded]` advert and CV silence |
| G3 | Leg-ulcer care (R5, important) | transferability | Pressure-ulcer and surgical wound care, no leg ulcers or compression | Leg-ulcer care leads the advert's duty list, and Doppler sits beside it | Compression bandaging; ulcer assessment on the ward or in discharge-to-assess patients; tissue viability link work | Competency sign-off, training record | `[grounded]` advert and CV; `[generic]` that this duty is central to district nursing |
| G4 | Own-caseload readiness (R10, R11) | transferability | Discharge-to-assess home visits, caseload never held | The advert says the caseload is small and supported, but the gap is real | Planning your own visit order; prioritising visits; handling a visit alone | A role description for the secondment | `[grounded]` CV and your statement |
| G5 | Doppler (R12, preferred) | capability | Never done, confirmed | Desirable, not essential. The hiring contact has spoken publicly on training staff new to community work | A closure path is the employer's training, which is a question for the informal chat | The employer's answer | `[grounded]` your statement; `[inferred]` that training may be offered |
| G6 | Continence and care planning (R6b, R8) | discovery | Catheter care stated, no wider continence or care-planning work | Both are named duties | Bladder and bowel assessments; contributing to discharge or care plans | A care-plan example, sanitized | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's own site | unknown | — | "Calderbrook Community Health CIC, Halifax" | The employer is established. My one fetch was a guessed careers address that returned no page, which doesn't show the post is closed | `[grounded]` About page, fetch result; `[inferred]` the address was a guess | Is this post currently open, and what is the closing date? | unresolved |
| RR2 | Pay stated and within the survey band | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range spans the role-family band, so pay doesn't look withheld or off-market | `[grounded]` advert; `[generic]` survey band | Where in the range would someone with five years' experience be placed? | noted |
| RR3 | Contract basis and terms unstated | unknown | — | "Band 5" | A CIC under an NHS contract may offer different terms from an NHS employer. Whether it uses NHS pay terms isn't stated | `[inferred]` from the advert's silence | Is the post permanent, and are NHS terms and pension applied? | unresolved |
| RR4 | Working pattern and mileage unstated | unknown | — | "pool cars are provided" and "plus mileage" | Caseload size, rota and weekend cover are unstated. When mileage is paid alongside pool cars is unclear | `[inferred]` from the advert's silence | What is the typical caseload and rota, and when is mileage paid? | unresolved |
| RR5 | Supported caseload and a named contact | positive_signal | — | "supported by a senior community nurse" | Support and an informal-chat contact suggest an employer expecting some newcomers | `[grounded]` advert; `[inferred]` the expectation | How does the senior nurse's support work in the first months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Proposed CV line: "Seconded for 18 months to the hospital's discharge-to-assess team, visiting patients at home in their first week after discharge." Every clause is yours, and no skill or caseload is added | see R10 | `[grounded]` your CV | resume_edits_pending_approval |
| P1 | Say plainly in any supporting statement that you haven't held your own caseload or done Doppler assessment. Add willingness to be trained only if that is true | see R11, R12 | `[grounded]` your statements | pending your approval |
| Q1 | Use the informal chat to ask RR1, RR3 and RR4 verbatim, and ask whether Doppler training is offered | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Contact Rhiannon Mabbott via the advert. Her public talks cover leg-ulcer clinics and Doppler training for newcomers, so those are natural topics | see R5, R12 | `[grounded]` speaker page | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health CIC Community Staff Nurse Band 5 district nursing Halifax". Page: "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, which returned no page. Moved: role reality's organization and contradictions rows, and RR1 |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing role expectations caseload Doppler leg ulcer pay Agenda for Change". Page: "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead". Page: "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: scope read and plan rows A1 and Q1. Professional footprint only |

You included a National Insurance number. I haven't used it. It isn't needed for this assessment, and I'd avoid pasting it into tools.

I can write all of this up as a `tuesday-dossier.md` if you'd like one.

## Upgrade menu

- Your full CV text would let me check each row against the actual wording instead of your summary.
- A check of your NMC register entry (yours to do) would turn R1 from `medium` toward `high`.
- The EPR name and a short record-keeping example would settle R4.
- A competency record or reference for wound, leg-ulcer or end-of-life care would raise R5 and R9.
- A link to the post on Calderbrook's own careers page, or the recruiter's email domain, would close RR1.
- The informal chat's answers would close RR3 and RR4.
- A deeper diligence and news pass on Calderbrook (up to 5 more searches and 2 more fetches) will run if you say the word.

G1 — Which electronic patient record have you used on the ward or in discharge-to-assess, and how did you keep your records clear and timely?
G2 — Have you cared for patients at the end of life, on the ward or on home visits? What did you personally do, and is there a record or reference?
G3 — Have you done any compression bandaging or leg-ulcer assessment? What was your part, and was it signed off?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.