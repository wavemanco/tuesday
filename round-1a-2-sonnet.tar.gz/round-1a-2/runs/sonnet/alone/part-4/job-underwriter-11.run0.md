I'll read the reference files the skill requires before building the assessment.
## Decision snapshots

**Duinvaart Cold Chain, Operations Analyst — yes, worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: D1 (Hybrid, three days a week in Rotterdam)
- `must_have` — direct: D2, D3, D4
- `important` — direct: D5 · adjacent: D7 (work with depot managers on route changes) · unclear: D6 (temperature compliance)
- `preferred` — adjacent: D8 (Dutch a plus)

D6 — the cold-chain half of the job, nothing in your background speaks to it yet; D8 — conversational Dutch, limit named.

**Opportunity ledger.** The role is concretely scoped (DRR3). The employer could not be checked from here (DRR1), the salary is withheld (DRR2), and the Rotterdam office days are unconfirmed against where you live (DRR4).

- **Hard gates:** none failed; unconfirmed: D1 (Hybrid, three days a week in Rotterdam); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the Rotterdam office days are workable for you (D1, DRR4); (2) the employer and live posting verify (DRR1); (3) any refrigerated or time-critical experience you have comes out (D6, DG1).

**Kroonhaven Foods, Supply Planner — no, not worth prioritizing. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: K1 (On-site in Utrecht)
- `must_have` — adjacent: K4 (Fluent Dutch) · unclear: K3a (Advanced Excel) · absent: K2 (3+ years planning in FMCG), K3b (SAP IBP or similar planning system)
- `important` — adjacent: K6 (Run the weekly S&OP meeting) · absent: K5 (Own the 13-week supply plan)

K4 and K6 — credible bridges, limits named; K2, K3b and K5 — you told me you have never worked in planning.

**Opportunity ledger.** The mandate is clearly stated (KRR3). The employer could not be checked from here (KRR1), and the salary is withheld (KRR2).

- **Hard gates:** none failed; unconfirmed: K1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** K2, K3b and K5 would each need real planning evidence, and K4 would need fluent Dutch. Nothing in what you've told me supplies either, so this one is a long shot at best.

## Role reality

**Duinvaart Cold Chain — Operations Analyst**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam, running a refrigerated fleet with depots | `[grounded]` JD. Not checked against any other source |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Scope read | An analyst post that serves operations, with depot managers as the main stakeholders | `[inferred]` from "work with depot managers on route changes" |
| First-90-days outcome | A weekly dashboard covering both on-time delivery and temperature compliance, in use by depot managers | `[inferred]` from the JD's first two duties; the JD states no outcomes |
| Market calibration | Not available: no role-family search ran, so there is no band for this title or pay | `[generic]` gap, see evidence status |
| Unknowns | Salary, team size, data stack, whether the office days are fixed | `[grounded]` JD silence |
| Contradictions | None inside the posting; it could not be checked against the company's own careers page | `[grounded]` JD text only |

**Kroonhaven Foods — Supply Planner**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht, chilled ready-meals range | `[grounded]` JD. Not checked against any other source |
| Mandate | Own the 13-week supply plan, balance production capacity against forecast, run the weekly S&OP meeting | `[grounded]` JD |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Scope read | A role that owns a plan end to end, not a support analyst post | `[inferred]` from "own" and "run" in the duties |
| Market calibration | Not available: no role-family search ran | `[generic]` gap, see evidence status |
| Unknowns | Salary, planning system in use, who attends S&OP, whether "SAP IBP or a similar planning system" is a screen or a preference | `[grounded]` JD silence |
| Contradictions | None inside the posting | `[grounded]` JD text only |

## Evidence map

Your background was typed in, so it counts as self-report: it caps at `medium` until there is an artifact to inspect.

**Duinvaart**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | You gave no home location or commute limit, so whether this works is not established. This is a term, so wording can't settle it | `[grounded]` JD; your message silent on location | Ask whether it works (closing question) |
| D2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | "4 years as an operations analyst at a parcel carrier in Amsterdam" is specific, with no artifact yet | `[grounded]` your background | none |
| D3 | Strong SQL | must_have | direct | medium | none | "SQL ... daily" is confirmed. "Strong" has no inspectable example yet | `[grounded]` your background | A sanitized query or report would raise it |
| D4 | Power BI or Tableau | must_have | direct | medium | none | "Power BI daily, including the on-time delivery dashboard our depot managers use" | `[grounded]` your background | A dashboard screenshot with data blurred would raise it |
| D5 | Track on-time delivery | important | direct | medium | none | The on-time delivery dashboard is the same metric the JD names | `[grounded]` your background | none |
| D6 | Temperature compliance across a refrigerated fleet | important | unclear | low | discovery | Nothing you wrote touches temperature or cold chain. Parcel carriers may or may not track temperature-sensitive parcels, so I can't tell | `[grounded]` your background silent; `[generic]` that parcel networks vary | See DG1 |
| D7 | Work with depot managers on route changes | important | adjacent | medium | discovery | Your dashboard serves depot managers and you ran the weekly route-performance review. Limit: you haven't said that the review led to route changes you proposed or made | `[grounded]` your background; limit `[inferred]` from what you left unsaid | See DG2 |
| D8 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch is real but short of fluent. As a stated "plus" it is a differentiator, not a screen | `[grounded]` your description; `[grounded]` JD tier | State it as conversational, no stretch |

**Kroonhaven**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No location or commute constraint given | `[grounded]` JD; your message silent | Ask whether it works (closing question) |
| K2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You said you have never worked in planning, and nothing suggests FMCG. The years are a length-of-experience requirement, so this is a major gap, not a gate | `[grounded]` your statement | Realistic path is a different role, not wording |
| K3a | Advanced Excel | must_have | unclear | low | discovery | You didn't mention Excel; SQL and Power BI work usually involves it, but that is my guess about your job | `[grounded]` your background silent; `[generic]` on typical analyst toolkits | Only worth asking if you proceed |
| K3b | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning-system use, per your statement that you've never worked in planning | `[grounded]` your statement | Realistic path is a course or an entry-level planning role |
| K4 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational Dutch is real. Limit: running a weekly meeting and owning plans with Dutch-speaking production and sales staff needs more than conversational | `[grounded]` your description; limit `[inferred]` from the JD's duties against "conversational" | none |
| K5 | Own the 13-week supply plan against forecast | important | absent | none | capability | Core duty, with no planning work in your history | `[grounded]` your statement | none |
| K6 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review, a recurring operational review. Limit: you haven't said it spanned demand, supply and finance, which is what S&OP is | `[grounded]` your background; limit `[generic]` on what S&OP covers | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| DG1 | Temperature compliance (D6, important) | discovery | A parcel-carrier background with no mention of temperature or time-critical freight | It is half of the JD's tracking duty, and with no cold-chain evidence the CV looks one-sided for this posting | Chilled or pharma parcel lanes, service-level or delivery-window compliance reporting, exception or claims analysis, any sensor or quality data you reported on | A sanitized exception report or SLA dashboard | `[grounded]` background silent; `[inferred]` that it affects how strong the application reads |
| DG2 | Route changes with depot managers (D7, important) | discovery | A dashboard used by depot managers and a weekly route-performance review; no stated route changes | The JD's third duty is working with depot managers on route changes | A route or round you proposed adjusting from the review; a depot manager acting on your analysis; a before-and-after on-time figure | A review deck or a note of a change made | `[grounded]` background; `[inferred]` the likely gap |
| DG3 | Location fit (D1 and K1, hard_gate) | hard_gate | Both jobs are office-based; your home location is unknown | A term, not experience. If it doesn't work, no CV wording helps | Not applicable | Not applicable | `[grounded]` JD terms; your message silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| DRR1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The entity may be too small to show up, the posting may be stale or aggregated, or it may not represent a real hiring employer. No search ran, so nothing was checked | `[generic]` pattern for unchecked employers, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| DRR2 | Salary not stated | unknown | — | (no figure in the posting) | The posting may be withholding pay, or the employer may not publish it | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |
| DRR3 | Duties are concrete and measurable | positive_signal | — | "Track on-time delivery and temperature compliance ... build weekly dashboards in Power BI" | The work is defined and checkable, so success should be assessable | `[grounded]` JD | Who uses the weekly dashboards today, and what decisions do they drive? | noted |
| DRR4 | Office days not specified against your location | unknown | — | "Hybrid, three days a week in our Rotterdam office" | The three days may be fixed or flexible; commute cost and time are unknown | `[inferred]` from the JD's silence on which days | Are the three office days set, or agreed with the team? | unresolved |
| KRR1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Same possibilities as DRR1; no search ran | `[generic]` pattern for unchecked employers, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| KRR2 | Salary not stated | unknown | — | (no figure in the posting) | As DRR2 | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |
| KRR3 | Mandate is clear | positive_signal | — | "Own the 13-week supply plan ... run the weekly S&OP meeting" | The accountability is defined | `[grounded]` JD | Which planning system and which data sources does the plan run on today? | noted |

## Application plan

**Duinvaart**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | `resume_edits_pending_approval`: move this to the top of your CV: "Four years as an operations analyst at a parcel carrier in Amsterdam; SQL and Power BI daily, including the on-time delivery dashboard depot managers use; ran the weekly route-performance review." Every clause is from your own description. It claims no building of the dashboard, because you didn't say you built it | see D2, D3, D4, D5, D7 | `[grounded]` your background | pending your approval |
| E2 | Describe your Dutch as conversational in the application, not as working-level | see D8 | `[grounded]` your description | pending your approval |
| A1 | Confirm on the employer's own careers page that the posting is live before spending effort | see DRR1 | `[grounded]` DRR1 | pending your approval |
| A2 | Ask DRR2, DRR3 and DRR4 as written in the interview | The register doubles as interview preparation | `[grounded]` register | pending your approval |

**Kroonhaven**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| B1 | Don't spend a full tailored application here | see K2, K3b, K5 | `[grounded]` evidence map | pending your approval |
| B2 | If you apply anyway, ask KRR3's question to learn how strictly planning experience is screened | see K2 | `[inferred]` from the JD's silence on how strict the screen is | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht chilled ready meals"; both were refused. It would have moved the employer rows (DRR1, KRR1) and role reality's contradictions row |
| 2. Role-family sweep | unavailable | Searched "operations analyst logistics Netherlands salary Rotterdam" and "supply planner FMCG Netherlands salary SAP IBP requirements"; both were refused. It would have moved role reality's market calibration rows and the salary entries (DRR2, KRR2) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

The postings are the only company source I had, so every employer statement above rests on what you pasted.

I'll copy the evidence into `tuesday-dossier.md` if you want it, so a later pass or interview prep can pick it up.

## Upgrade menu

- Search access in this session → DRR1 and KRR1 resolve, and market calibration and salary bands (DRR2, KRR2) can be filled.
- A sanitized dashboard screenshot or sample query → D3 and D4 rise to `high`.
- Your answer on temperature-controlled or SLA work → D6 and DG1 close or become a named gap.
- A hiring manager's name from either posting → role reality's scope read for that role.
- A deeper research pass on Duinvaart (leadership churn, news; up to 5 more searches and 2 more fetches) — say the word and it runs once search is allowed.

**Questions**

1. D1 and K1 — Where are you based, and is three days a week in Rotterdam (Duinvaart) or fully on-site in Utrecht (Kroonhaven) workable for you?
2. DG1 — Did your parcel-carrier work include any temperature-controlled, chilled or other time-critical freight, or delivery-window and SLA compliance reporting? If so, what did you report on?
3. DG2 — In your weekly route-performance review, did your analysis lead to a route or depot change? What was your part in it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.