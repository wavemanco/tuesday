I'm checking whether Marrowgate Housing exists as described and what Irish employers normally collect at onboarding. Then I'll write up the assessment.
# Job Underwriting Assessment: Payroll Administrator, Marrowgate Housing

## Decision snapshot

**Accept, once you've verified the employer and have the contract terms. Status: `conditional_go`.**

Asking for bank details, PPS number and passport after an offer is normal for an Irish employer. `[generic]` Salary needs the bank account, Revenue payroll reporting needs the PPS number, and a right-to-work check needs ID. Your "never hand those over" rule is right for unsolicited requests, before any offer, or through channels you can't check. Here you had two in-person interviews, a written offer, and the request comes only after you accept. `[grounded]` from what you told me.

**Fit ledger.**

- `hard_gate` — unclear: R10, R11
- `must_have` — direct: R1, R3, R4 · adjacent: R5 · unclear: R2
- `important` — direct: R6, R7 · unclear: R9 · absent: R8

R8 (pension changes) is the one real skill gap, and it is a learnable one.

**Opportunity ledger.** The sequence looks genuine, since you met them in person and the request comes after the offer (RR2). Two things are still unverified: the employer's existence has not been independently checked (RR1), and the offer says nothing about contract terms (RR4).

- **Hard gates:** none failed; unconfirmed: R10 (hybrid, two days in the Limerick office), R11 (€40,000 against your salary floor); your constraints weren't given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) verify the offer and the portal link by phone before uploading anything (RR1, RR3); (2) get the written terms before you hand over documents (RR4); (3) be straight about pension changes (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick. You visited the office twice, but I haven't independently confirmed the organisation | `[grounded]` the posting and your account |
| Mandate | Monthly payroll for 240 staff, starters, leavers and pension changes, monthly ledger reconciliation, staff queries | `[grounded]` JD |
| Working pattern | Hybrid, two days a week in Limerick; reports to Declan Garvagh, Finance Manager | `[grounded]` offer |
| Scope read | One administrator carrying a full monthly payroll for 240 staff, with a finance manager above | `[inferred]` from the JD's wording and the offer's reporting line |
| Market calibration | Not established: the market search was refused. €40,000 sits inside the posting's own €38,000–€42,000 range, so it is mid-band | `[grounded]` JD and offer for the range; no `[generic]` market band available |
| Unknowns | Contract terms, probation, notice period, pension scheme, leave, team size, first-year outcomes | `[grounded]` the offer is silent |
| Contradictions | None between the JD and the offer on title, hybrid pattern, location or salary range | `[grounded]` both texts compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll at a hotel group. Confirmed by you, no artifact seen | `[grounded]` your account | none |
| R2 | Working knowledge of Irish PAYE, PRSI, USC | must_have | unclear | low | discovery | You didn't say the hotel payroll was Irish. Likely, but I won't assume it | `[inferred]` from the Irish context | gap queue G1 |
| R3 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP | `[grounded]` your account | none |
| R4 | Payroll qualification, or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your account | none |
| R5 | Monthly payroll for 240 staff | must_have | adjacent | medium | transferability | Your payroll is 90 staff, fortnightly. The method carries over, but you haven't run this scale or cycle | `[inferred]` from the two scales | frame as adjacent, never as equal |
| R6 | Starters and leavers | important | direct | medium | none | Done at the hotel group | `[grounded]` your account | none |
| R7 | Monthly payroll-to-general-ledger reconciliation | important | direct | medium | none | Done monthly | `[grounded]` your account | none |
| R8 | Pension changes | important | absent | none | capability | You haven't done them yourself; your manager did | `[grounded]` your account | closure path in G2 |
| R9 | Answering staff payroll queries | important | unclear | low | discovery | You didn't mention staff queries. It is common in payroll work, so you may have done it | `[inferred]` | G3, no question asked |
| R10 | Hybrid, two days a week in Limerick | hard_gate | unclear | none | hard_gate | The role's term is clear. Whether it suits you is unknown, as no constraints were given | `[grounded]` offer; constraints not given | confirm it suits you |
| R11 | Salary €40,000 | hard_gate | unclear | none | hard_gate | Inside the stated band. Your floor is unknown | `[grounded]` offer; floor not given | confirm it meets your floor |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI, USC (R2) | discovery | Your payroll jurisdiction isn't stated | It's a must-have, and a probable yes is cheap to confirm | Revenue returns, P45s or P60s, USC and PRSI classes handled at the hotel group | A line confirming Irish payroll | `[inferred]` |
| G2 | Pension changes (R8) | capability | None done by you | The JD names it as a duty | Preparing the data for your manager's pension changes, or any contribution updates you processed | Anything showing you handled pension data | `[grounded]` your account |
| G3 | Staff queries (R9) | discovery | Not mentioned | A listed duty | Queries from hotel staff about payslips, tax credits or leave pay | Examples of queries you resolved | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not independently confirmed | unknown | — | "Marrowgate Housing People Team" | Probably genuine, given two in-person interviews, but no search reached the company, so the web side is unchecked | `[inferred]` from your in-person visits; no research result | Does the sender's domain match the website you reach by typing the company address yourself? | unresolved |
| RR2 | Personal data requested only after acceptance | positive_signal | — | "Once you accept, we will send you a link…" | The order follows normal practice: interviews, then offer, then onboarding data | `[generic]` hiring pattern | Which data-protection notice goes with the portal? | noted |
| RR3 | The portal link comes later by email | risk_signal | low | "we will send you a link to our onboarding portal" | An emailed link is the route a fraudster would imitate, though nothing here suggests one | `[generic]` fraud pattern | Does the link come from the marrowgatehousing.ie domain, and does the People Team confirm it when you ring the office on the number from the company's own website? | unresolved |
| RR4 | Offer silent on contract terms | unknown | — | "permanent post… at €40,000 a year" | Terms (probation, notice, pension scheme, leave) likely follow in a contract, but none are visible yet | `[inferred]` from the offer's silence | Can I see the written terms before I upload documents? | unresolved |
| RR5 | Five-working-day acceptance deadline | risk_signal | low | "reply to accept within five working days" | An ordinary deadline, but a signed-off written offer would make it easier to accept calmly | `[generic]` | Could I accept subject to contract? | unresolved |

## Application plan

Everything here, including the draft wording, is proposed and goes out only if you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ring the office on the number from the company's own website, not the one in the email, and confirm the offer, the sender address and the portal | see RR1, RR3 | `[generic]` standard verification | pending your approval |
| A2 | Reply accepting subject to contract, asking for the written terms: "I'm delighted to accept, subject to receiving my contract and terms of employment." | see RR4, RR5 | `[inferred]` from the offer's silence | pending your approval |
| A3 | Upload bank details, PPS number and passport only inside the verified portal, never by email or message. Bring the original passport on day one, as they ask | see RR3 | `[generic]` | pending your approval |
| A4 | Say plainly in week one that you haven't processed pension changes yourself, and ask what training or sign-off there is. Don't present the hotel group's pensions work as yours | see R8, G2 | `[grounded]` your account | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Marrowgate Housing Limerick housing association" and "Marrowgate Housing Payroll Administrator Limerick careers"; both refused, so nothing was read. It would have settled RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | Searched "payroll administrator Ireland salary 2026"; refused. It would have given the market calibration |
| 3. Hiring manager's public footprint | unavailable | Declan Garvagh was named, but search was refused, so no query could run. It would have informed scope and positioning |
| Outside declared targets | unavailable | Searched "Ireland employer new starter PPS number bank details passport right to work check employer obligations". It was outside the three targets, and it was refused. The `[generic]` points above on PPS numbers and right-to-work checks therefore rest on general knowledge. Please confirm them with Revenue or Citizens Information before relying on them |

## Dossier offer

If you want a saved `tuesday-dossier.md` of this assessment, I can write it.

## Upgrade menu

- Search permission → RR1 closes if the company and its careers page check out, and the market calibration gets a real salary band.
- Your confirmation of the contract terms → RR4 closes.
- A deeper diligence pass on Marrowgate Housing (up to 5 more searches and 2 more fetches) → this only becomes available if search is permitted. Say the word and it runs.
- A reference-able line on your pensions or staff-query experience → R8, R9 firm up.

## Questions

1. **G1 / R2:** Was your hotel-group payroll run under Irish PAYE, PRSI and USC?
2. **R10 / R11:** Do the two office days in Limerick and €40,000 work for you (commute, salary floor, notice period)?
3. **G2 / R8:** Did either interview cover pension changes, and what did they say about training?

Answer, skip, or say "not sure" for any of them. A skipped question isn't asked again.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.