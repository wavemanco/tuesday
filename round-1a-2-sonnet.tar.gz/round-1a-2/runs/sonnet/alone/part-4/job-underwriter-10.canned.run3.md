## Decision snapshot

**Yes, it's worth going ahead with, and nothing I found says Fernquay isn't legit (RR1). Status: `conditional_go`.** I assumed you're at the interviewing stage, since you've applied and they've asked for a call.

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Pay €52,000–€60,000 plus equity)
- `must_have`: direct: R3, R4, R5, R7 · adjacent: R6 (Own the booking flow end to end)
- `important`: adjacent: R8 (First designer, no design peers)

R6: checkout is a credible bridge, its limit named; R8: the gap you named yourself; R2: waiting on your pay floor.

**Opportunity ledger.** The employer, the live posting and the pay band line up (RR1, RR5). What's open is the equity terms, support as the only designer, how success is measured, and confirming the invite sender (RR2, RR3, RR4, RR6).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52,000–€60,000 plus equity); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The pay and equity clear your floor (R2, RR2).
  2. You present the checkout work as a bridge to owning the whole booking flow, not as having already owned one (R6, G1).
  3. You get a straight answer on support and success measures (RR3, RR4).
  4. The calendar invite checks out before you click anything (RR6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, a six-person Galway company making Kelproster booking software for sea-kayak, surf and sailing schools in Ireland and Scotland, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` About Fernquay page (fernquay.example/about) |
| Posting | The company's own careers page lists the same role as "our first design hire", hybrid with two days a week in Galway, €52,000–€60,000 plus equity | `[grounded]` careers page fetched |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship alongside two engineers, work most closely with Ronan | `[grounded]` posting |
| Hiring contact | Ronan Kehoe is co-founder and CEO, and was previously product lead at a Galway travel-software company for five years. That is a public professional footprint only | `[grounded]` LinkedIn profile result |
| Scope read | One person covering design, research and delivery for a single product is a bundled brief, but it is the usual shape of a first design hire at this size | `[generic]` role-family pattern, not a finding about Fernquay |
| Market calibration | For product designers with 3 to 5 years in Ireland, one 2026 survey (n=520) gives a median base of €57,000 and a middle range of €51,500–€62,000. The posted €52,000–€60,000 sits inside that range. This is a market band, not Fernquay's offer to you | `[generic]` Tillerby 2026 Ireland Design Salary Report; `[grounded]` posting for the figure |
| Unknowns | Equity instrument, vesting and dilution; who sets design priorities; first-year success measures; who gives design feedback | `[inferred]` from the posting's silence |
| Contradictions | None between your posting and the careers page. The careers page names jobs@fernquay.example as the application route, and the first contact to you came by WhatsApp, which fits a small team but is worth knowing (RR6) | `[grounded]` careers page against your WhatsApp message |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You live in Galway. Willingness to commute two days wasn't stated, so confidence is `medium` | `[grounded]` your statement | confirm in the call |
| R2 | Pay €52,000–€60,000 plus 0.5–1% equity, against your floor | hard_gate | unclear | none | hard_gate | You gave no pay constraint, so the check against the band can't be run | `[grounded]` constraint not given | the R2 question below |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company. A work-history claim with no document read yet | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use stated. Nothing inspected, since the case study wasn't read | `[grounded]` your statement | link the case study to raise to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers. The role's calls are with school owners, so evaluative sessions are what you have shown, not discovery interviews. Expect a probe | `[grounded]` your statement; `[inferred]` the difference between the two kinds of research | be ready with a specific example |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout, which is one stage of a booking flow, inside a squad. Limit: end-to-end ownership of the whole flow wasn't described | `[grounded]` your statement; `[inferred]` that checkout is one stage | see G1 |
| R7 | Happy working directly with engineers | must_have | direct | medium | none | Squad with four engineers | `[grounded]` your statement | none |
| R8 | First designer with no design peers (implied by "our first designer") | important | adjacent | medium | transferability | You have never been the only designer. Closest evidence is leading the checkout redesign and running the usability sessions yourself | `[inferred]` from "first designer" in the posting; `[grounded]` your statement | see G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own the booking flow end to end (R6, must_have) | transferability | Checkout redesign confirmed. Which stages you personally owned, and how the work reached engineers and customers, isn't stated | It is the role's main responsibility. A clear account of the limit reads more credibly than a stretched claim | Choosing the scope of the redesign; deciding what to research; defining the handoff; measuring the result after launch; touching steps before or after checkout | The checkout case study, or a before/after of the flow | `[grounded]` your statement; `[generic]` that interviewers probe end-to-end ownership for a first-designer role |
| G2 | Working as the only designer (R8, important) | transferability | Never the sole designer. Not stated whether you ever set standards, such as components, research routines or critique, without a design lead | A first hire has no one to review the work. Evidence of self-direction narrows the gap | Building or maintaining a component library; setting a research cadence; covering for an absent designer; making design calls with a PM and no design lead | A research schedule, a component file, a handoff note | `[grounded]` your statement; `[generic]` what first-hire roles demand |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting match their own pages | positive_signal | — | "We are six people in Galway making booking software for sea-kayak and surf schools" | The company exists as described and the role is live | `[grounded]` About page and careers page both match | Who besides Ronan and Saoirse would I work with day to day? | noted |
| RR2 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The instrument, vesting and dilution may change what the equity is worth. The company is customer-funded, so there may be no outside valuation | `[grounded]` About page says customer-funded; `[inferred]` from the posting's silence on terms | Is the equity options or shares, what is the vesting schedule, and what is the fully diluted base? | unresolved |
| RR3 | Only designer, support unclear | unknown | — | "You would be our first designer" | Design feedback and mentoring may come only from founders and engineers | `[inferred]` from "first designer" and the stated team of six | Who reviews design work, and how are product priorities set between you, Ronan and the engineers? | unresolved |
| RR4 | No stated success measures | unknown | — | "own the booking flow end to end" | The posting names responsibilities but no first-year outcome | `[inferred]` from the posting's silence | What should the booking flow look like in twelve months, and how will you measure it? | unresolved |
| RR5 | Pay inside the market band | positive_signal | — | "€52,000–€60,000" | Stated pay is within the typical range for 3 to 5 years in Ireland | `[grounded]` posting figure; `[generic]` band from the 2026 survey | Is the range fixed, or does it move with scope? | noted |
| RR6 | First contact by WhatsApp, invite by email | unknown | — | "I have emailed you a calendar invite with the video link" | A small team may simply work informally by chat. The invite is the thing to confirm, since the careers page uses a fernquay.example address | `[generic]` small teams often use chat for scheduling; `[grounded]` careers page domain | Could you send the invite from your Fernquay address and say which video platform you use? | unresolved |

## Application plan

Every row below is a proposal, and nothing here, including the advice in the rows and the questions, is final until you approve it. I'm proposing no CV wording.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Open the video link only from an invite sent from an address ending in fernquay.example. If it doesn't match, reply and ask before clicking | See RR6 | `[grounded]` careers page domain | pending your approval |
| A2 | Check what you sent with your application, including the checkout case study Ronan mentioned, and have it ready to share | See R4, R6 | `[grounded]` the WhatsApp message | pending your approval |
| A3 | Bring one real project, rough edges included, as the posting asks | The posting says they prefer one messy real project to a polished deck | `[grounded]` posting | pending your approval |
| A4 | Describe checkout as a bridge to owning the full flow, and say plainly what you haven't owned alone | See R6, R8 | `[grounded]` R6, R8 rows | pending your approval |
| Q1 | Ask the register questions for RR2, RR3, RR4 and RR5 verbatim in the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| Q2 | Ask about the equity terms before you accept any number as part of the pay | See RR2 | `[grounded]` RR2 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about), and "Fernquay product designer careers Galway", which returned "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer, fetched). Role reality: organization and contradictions rows, and RR1 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup first designer 3+ years equity", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Market calibration and RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). It gave title and prior role only. Role reality, hiring contact row |

The dossier is a file with the full report and its evidence data; say the word and I'll write `tuesday-dossier.md`.

## Upgrade menu

- Your pay floor → R2 resolves, and the decision likely moves from `conditional_go` to `go` or `no_go`.
- Your checkout case study or a link to it → R4 and R6 can reach `high`, and G1 narrows.
- Your answer on solo ownership → G2 narrows or closes.
- The equity terms from Ronan → RR2 closes.
- A deeper check on Fernquay, covering customers, funding and recent news (up to 5 more searches and 2 more fetches) → adds to the register. Say the word and it runs.

## Questions

1. **R2:** What's your pay floor, and does €52,000–€60,000 plus 0.5–1% equity clear it?
2. **G1:** In the checkout redesign, which parts did you personally decide and own, and what happened after launch?
3. **G2:** Have you ever set design standards or research routines yourself without a design lead? What did you set up?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.