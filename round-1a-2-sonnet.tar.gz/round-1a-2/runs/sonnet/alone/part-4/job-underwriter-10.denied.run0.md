I'll read the reference files the skill points to before building the assessment.
**Yes, it's worth taking the call. Status: `conditional_go`.** On the text you pasted, neither the posting nor the WhatsApp message asks you for money, documents or personal details. I couldn't check the company itself from here (RR1), so "legit" means nothing in the text is a warning sign, not that the firm is verified. You've already applied, so the live question is whether to take the call.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Pay €52,000–€60,000 plus equity)
- `must_have` — direct: R3, R4, R5a, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R5b (Research calls with school owners), R8 (First designer, no design peers)

R7 — checkout is one stage of a booking flow; R8 (`low`) — no sole-designer history.

**Opportunity ledger.** The posting is specific and transparent about pay, equity and hybrid terms (RR6). The employer is unverified (RR1), and the equity terms and funding are unstated (RR3, RR5). The WhatsApp channel and the invite's sender domain are unchecked (RR2).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52,000–€60,000 plus equity, against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the company verifies as a real, hiring employer — RR1; (2) the calendar invite comes from the company's own email domain — RR2; (3) the pay band clears your floor — R2; (4) the equity and runway answers are acceptable — RR3, RR5; (5) the checkout work is framed as adjacent to end-to-end ownership, never as it — R7, R8.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` JD; not confirmed against any outside source |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` JD |
| Reporting and panel | Works most closely with co-founder Ronan Kehoe; the call is with him and Saoirse, the CTO, for 45 minutes by video | `[grounded]` JD and the WhatsApp message |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` JD |
| Working pattern | Hybrid: two days a week in the Galway office, the rest flexible | `[grounded]` JD |
| Scope read | A broad first-hire mandate: design, research and delivery with no design peer, though the engineering partners are named | `[inferred]` from "first designer" beside the three listed duties |
| Market calibration | Not established: the role-family search was refused, so there is no band to set the stated pay against | `[grounded]` JD states the figure; sweep unavailable |
| Unknowns | Contract type, equity type and vesting, funding and runway, who has final say on product priorities, first-90-day outcomes | `[grounded]` the JD is silent on each |
| Contradictions | None between the posting and the message (both mention your application and the booking-flow work) | `[grounded]` the two texts you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week in the Galway office | hard_gate | direct | medium | none | You live in Galway, which meets the term. You haven't stated a limit on office days, so confidence grades your stated residence | `[grounded]` your background; JD | none |
| R2 | Pay €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | The JD states the figure. Your floor wasn't given, so whether the band clears it is unsettled | `[grounded]` JD figure; your floor absent | Q1 below |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company, stated by you; nothing inspected yet | `[grounded]` your background | A portfolio link would raise it to high |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use over those years, stated; no file inspected | `[grounded]` your background | A shareable Figma file or prototype would raise it to high |
| R5a | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers, stated. Whether you planned, recruited and synthesised them yourself isn't stated | `[grounded]` your background | Q2 below |
| R5b | Research calls with school owners (business operators) | important | adjacent | medium | transferability | Usability sessions with customers carry over. Limit: who the customers were isn't stated, and discovery calls with business owners exercise different skills from usability testing | `[grounded]` your background; `[generic]` on the difference between the two kinds of session | Q2 below |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers; the JD names two | `[grounded]` your background; JD | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow, which is one stage. Limit: ownership beyond checkout isn't stated, so don't call it end to end | `[grounded]` your background; JD quote "own the booking flow end to end" | Q3 below |
| R8 | Work as the first designer (inferred from "first designer") | important | adjacent | low | transferability | By your own account you've never been the only designer. The closest evidence is owning a checkout redesign and monthly sessions inside a squad. Limit: no record of setting up design process without design peers | `[inferred]` from "first designer" against your history | Prepare an honest answer (A3) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning more than checkout (R7, must_have) | transferability | A checkout redesign is confirmed; the surrounding journey isn't described | R7 is a `must_have` row at `adjacent`; the posting's headline duty is the whole flow | Work on steps before or after checkout, such as availability search, add-ons, payment, changes and cancellations; the handoff of a full journey to engineers; funnel metrics you used to prioritise | Your checkout case study (they've seen it), a flow map, a before-and-after funnel view | `[grounded]` background states checkout only; `[inferred]` that the whole-flow duty is the likeliest probe |
| G2 | Research with business owners (R5b, important) | discovery | Monthly usability sessions are stated; the participants and your role in planning them aren't | Research calls with school owners are one of three listed duties | Sessions with business partners, operators or merchants rather than end customers; recruiting participants yourself; turning findings into roadmap changes | A research plan, a synthesis deck or a findings note, sanitised | `[grounded]` background silent on participants; `[generic]` that B2B discovery differs from consumer testing |
| G3 | First-designer setup (R8, important) | transferability | Squad work with other design colleagues is implied; sole ownership isn't evidenced | The JD frames the hire as the first designer, so working without peers is the daily reality | Setting up a component library or shared Figma conventions; running your own critique with engineers; making design calls without a design lead | A Figma library or a documented working agreement | `[inferred]` from "first designer" and your statement; `[generic]` that first hires are probed on self-direction |
| G4 | Pay floor not stated (R2, hard_gate) | hard_gate | The JD's band is known; your floor isn't | A hard gate left unconfirmed can't be read as met | Not applicable: a term, not experience | Your own stated floor, and any other fixed terms | `[grounded]` floor absent from your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | First contact on WhatsApp; invite sender not yet checked | unknown | — | "I have emailed you a calendar invite with the video link." | Small teams may message candidates directly using the number on an application; the message may also not come from who it names, which the invite's sender domain would show | `[generic]` pattern for early-stage hiring; no claim about this sender | Could you resend the interview confirmation from your company email so I can match it to your website? | unresolved |
| RR3 | Equity terms unspecified | unknown | — | "0.5–1% equity" | The grant type, vesting schedule and dilution may materially change what the percentage is worth | `[generic]` pattern for early-stage equity offers | Is the equity options or shares, what are the vesting and cliff terms, and what is the current fully diluted share count? | unresolved |
| RR4 | Sole designer, decision rights unstated | risk_signal | low | "You would be our first designer: own the booking flow end to end" | Ownership of the flow may sit beside unclear authority over priorities, with no design mentor in reach | `[inferred]` from the ownership language against the JD's silence on decision rights | When you, Saoirse and the engineers disagree on a design call, who decides? | unresolved |
| RR5 | Funding and runway unstated | unknown | — | "We are six people in Galway" | A six-person company hiring a first designer may have limited runway, which matters more when part of the pay is equity | `[generic]` pattern for very small companies | How is Fernquay funded, and how many months of runway does the hiring plan assume? | unresolved |
| RR6 | Pay, equity, location and duties stated up front | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity. Hybrid: two days a week at our Galway office" | Transparent terms and a named working partner suggest a considered posting | `[grounded]` JD | Who owns product priorities between design, engineering and the co-founder day to day? | noted |

## Application plan

Every row is proposed and nothing is final until you approve it, the advice as well as the table (`resume_edits_pending_approval`).

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, find the company's website yourself (not via the WhatsApp message), check that the invite email comes from that domain, and look the company up in Ireland's Companies Registration Office | See RR1, RR2 | `[generic]` standard checks for any small employer | pending your approval |
| A2 | Ask the register's verification questions in the call: RR1 to RR5 verbatim, plus RR6's question | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Walk through the checkout case study as the part you owned, naming what the squad did, and say plainly that you have not been the sole designer | See R7, R8; the JD invites "one messy real project" over "a polished deck" | `[grounded]` JD quote; your background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search sent for "Fernquay booking software sea kayak surf schools Galway"; the host refused it. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Search sent for "first product designer startup Ireland salary equity 3+ years experience 2026"; the host refused it. It would have moved role reality's market calibration row and R2's comparison |
| 3. Hiring manager's public footprint | unavailable | Search sent for "Ronan Kehoe Fernquay co-founder"; the host refused it. It would have moved role reality's scope read and A3's positioning |

I did not retry the refused searches.

## Dossier offer

I can write this up as `tuesday-dossier.md` if you want to keep it.

## Upgrade menu

- Search permission for the three declared checks → RR1 closes or sharpens, R2 gets a market band, and role reality gains Ronan's public professional footprint. Say the word and a deeper pass can follow (up to 5 more searches and 2 more fetches).
- A shareable Figma file or portfolio link → R3 and R4 to `high`.
- A research plan or findings note, sanitised → R5a, R5b and G2 firm up.
- A flow map or funnel view covering more than checkout → R7's limit narrows.
- Your pay floor and any other fixed terms → R2 resolves and the hard-gates line stops flagging unconfirmed constraints.

## Questions

Q1 (G4, R2) — What's the lowest salary you'd accept, and are there other terms you wouldn't flex, such as office days or the weight you'd put on equity?

Q2 (G2, R5a and R5b) — Who were the customers in your monthly usability sessions (end bookers or business partners), and did you plan, recruit and synthesise them yourself?

Q3 (G1, R7) — Besides checkout, which other steps of the booking journey did you own or influence, and what changed as a result?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.