# Job Underwriting Assessment: Product Designer at Fernquay

## Decision snapshot

**Yes, worth applying, and the call is worth taking. I found the company and the live posting (RR2), and the WhatsApp contact on its own is not a red flag (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000 against your floor)
- `must_have`: direct: R3, R4, R5, R7 · adjacent: R6 (Discovery calls with school owners), R8 (Own the booking flow end to end)
- `important`: absent: R9 (Being the first and only designer)
- `preferred`: direct: R10

R8 — checkout is part of a booking flow, its limit named; R6 — usability sessions bridge to owner discovery calls; R9 — no sole-designer history. R3, R4, R5 and R7 each rest on your account alone, so each is `medium` and waiting on an artifact.

**Opportunity ledger.** The employer and the live posting were found, and the salary band sits inside the market range I found (RR2, RR5). Equity terms, stability and decision rights are unknowns to ask about (RR3, RR4, RR6), and the sender check on the invite is a cheap unknown (RR1).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the emailed invite comes from a fernquay.example address, per RR1; (2) the salary clears your own floor, and the equity terms are explained, per R2 and RR3; (3) the first-designer set-up and decision rights are concrete when you ask, per R9 and RR4.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland; six people in Galway; founded 2023 by Ronan Kehoe and Saoirse Doyle; "funded by its customers" | `[grounded]` About Fernquay page (search result) |
| Posting live and consistent | The careers page lists the Product Designer role as open, the first design hire, hybrid with two days a week in Galway, €52,000–€60,000 plus equity, and asks for one real project sent to jobs@fernquay.example. This matches your posting | `[grounded]` careers page fetched |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship alongside two engineers, work most closely with Ronan | `[grounded]` posting you pasted |
| Working pattern | Hybrid; two days a week in the Galway office. You moved back to Galway last year | `[grounded]` posting and your message |
| Hiring manager | Ronan Kehoe is listed as co-founder and CEO, previously product lead at a Galway travel-software company for five years. That is the whole of what I looked at (roles only) | `[grounded]` search result for his profile page, snippet only |
| Scope read | Product design, user research and shipping with engineers, all for the first designer. That is a broad remit, with a mild bundling of specialisms, priced inside the band below | `[inferred]` from the posting's three duties against its single design hire |
| Market calibration | Irish product designers with 3 to 5 years have a median base of €57,000, interquartile range €51,500 to €62,000. The posting's €52,000–€60,000 sits inside that range. The band is a pattern, not this employer's offer; it is a general design survey, not first-designer-at-a-startup roles | `[generic]` Tillerby 2026 Ireland survey (n=520), seen as a search snippet; `[grounded]` the posting's own figure |
| Unknowns | Equity type, vesting and dilution; runway; who has the last word on design; whether Saoirse's CTO title appears anywhere I checked (her co-founder role does) | — |
| Contradictions | None between your posting and the careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | high | none | You live in Galway; the posting's location term is met by your own stated circumstance | `[grounded]` posting and your message | none |
| R2 | Salary €52,000–€60,000 against your floor | hard_gate | unclear | none | hard_gate | You have not given a floor, so the check against the figure cannot be run. The figure sits inside the market band in role reality | `[grounded]` posting; your floor not given | your floor (question Q1) |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company, from your account; no artifact inspected | `[grounded]` your message | a CV or portfolio would raise it |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" across four years. Your claim is the only source; a Figma file or case study would raise it | `[grounded]` your message | share the case study they already liked |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers, which you ran. It covers usability research; the owner discovery calls are R6 | `[grounded]` your message | none |
| R6 | Research calls with school owners (discovery) | must_have | adjacent | medium | transferability | Usability sessions are a credible bridge to interviewing owners about how they work. Limit: you have not said you ran open discovery interviews, and the bridge must be stated that way | `[inferred]` adjacency derived from your usability sessions | see gap G1 |
| R7 | Happy working directly with engineers | must_have | direct | medium | none | Four years in a squad with four engineers | `[grounded]` your message | none |
| R8 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned a travel-booking checkout, which is close in domain. A booking flow runs wider than checkout (availability, schedules, changes), and the checkout is the stretch of it you have evidence for | `[inferred]` adjacency derived from the checkout redesign | see gap G2 |
| R9 | Being the first and only designer (implied by "our first designer") | important | absent | none | capability | You have never been the only designer anywhere, so no direct evidence exists. A four-year squad member may still have made independent design calls, but I have no evidence either way | `[inferred]` from "first designer"; `[grounded]` your statement | see gap G3 |
| R10 | One messy real project over a polished deck | preferred | direct | medium | none | Ronan says they liked your checkout case study. That is your report of his message, not an inspected document | `[grounded]` the WhatsApp message you pasted | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owner discovery calls (R6, must_have) | transferability | Monthly usability sessions; nothing yet on open discovery conversations | The posting names research calls with school owners as a duty, so expect a probe | Customer interviews you ran about workflow rather than a screen; calls with travel operators or sales partners | A sanitized research summary or interview guide | `[inferred]` bridge from usability sessions |
| G2 | Beyond checkout (R8, must_have) | transferability | One checkout redesign | "End to end" asks for more than one stage | Any work on search, availability, amendments or cancellations | The checkout case study's before-and-after, or a flow diagram | `[inferred]` from the checkout redesign |
| G3 | Sole-designer experience (R9, important) | capability | None stated; always part of a squad | The role has no design peers; the posting does not mention design leadership or process-building, so this is a gap to address, not a stated demand | Design decisions you made without a design lead; tooling or process you set up | One example of a call you made unreviewed | `[grounded]` your statement; `[inferred]` that it matters here |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Contact by WhatsApp, invite sent by email | unknown | — | "I have emailed you a calendar invite with the video link" | Scheduling by chat for a video interview held elsewhere is a common way small teams work; the check is whether the emailed invite comes from the employer's own domain, which the careers page gives as fernquay.example | `[generic]` pattern for small teams; `[grounded]` the careers page's domain | Could you confirm the invite is from your fernquay.example address, and who else is on the call? | unresolved |
| RR2 | Employer and live posting found | positive_signal | — | "Six people, based in Galway. Founded 2023 … funded by its customers" | The company is real as described. A thin footprint is what a six-person company founded in 2023 would leave. All three pages are the company's own or a profile page, with no independent customer or press source seen | `[grounded]` About page, careers page and profile snippet; `[generic]` that small firms leave thin footprints | Can you share a customer school or two I can speak to? | noted |
| RR3 | Equity terms unspecified | unknown | — | "0.5–1% equity" | The percentage may be options, shares or a promise, with vesting and strike unspecified; the value is unknowable until those are stated | `[inferred]` from the posting's silence on terms | What form is the equity, what vesting and strike apply, and what is the current share count? | unresolved |
| RR4 | Decision rights and support | unknown | — | "own the booking flow end to end … work most closely with our co-founder" | Ownership may sit beside a CEO with product experience who retains final design calls; resources for research access to owners are not stated | `[inferred]` from the posting's scope language against its silence on authority | Which design decisions are mine alone, and who reviews design work? | unresolved |
| RR5 | Stated pay inside the market band | positive_signal | — | "€52,000–€60,000" | The posting is open about pay, and it sits inside the interquartile range found | `[grounded]` posting; `[generic]` Tillerby survey band | Is the band fixed, or does experience move it? | noted |
| RR6 | Stability of a small, customer-funded company | unknown | — | "funded by its customers" | A self-funded team of six depends on revenue; runway and growth are not public | `[inferred]` from the About page's funding line; `[generic]` that self-funded firms rely on revenue | What is the runway, and how has revenue moved over the last year? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the emailed invite's sender domain before you click the video link; confirm the time on WhatsApp only | see RR1 | `[grounded]` careers page domain | pending your approval |
| Q1 | Ask the register's verification questions (RR1, RR3, RR4, RR6) in the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P1 | Lead with the checkout case study they already liked, and describe your research as usability sessions, with discovery named as the stretch | see R5, R6, R8 | `[grounded]` R5, R6, R8 rows | pending your approval |
| P2 | Prepare a short account of how you would work as the first designer, in your own words, covering where you would ask for support | see R9, RR4 | `[grounded]` R9 row | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about), and "Fernquay careers product designer", which returned "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer); fetched that careers page. Role reality: organization and contradictions rows (consistent); RR2 and RR1's domain |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland first designer startup 3+ years 2026", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Market calibration and RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Role reality's hiring-manager row; it moved the scope read and P1 |

## Dossier offer

I can write all of this into a `tuesday-dossier.md` you can keep, if you'd like it.

## Upgrade menu

- Your minimum salary and any schedule limits → R2 closes and the hard-gates line firms up.
- An answer on discovery interviews (G1) → R6 strengthens or the gap is named as a limit.
- The checkout case study, or a Figma file → R3, R4, R5 and R8 can rise from `medium`.
- Ronan's answers on equity, runway and design decision rights → RR3, RR4 and RR6 close.
- A deeper research pass on Fernquay (funding, leadership history, customer reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

1. What is the lowest base salary you would accept, and is there any limit on the days or hours in the office? (R2)
2. Have you ever run open interviews with customers about how they work, beyond usability sessions on a screen? (G1)
3. Have you ever made design decisions with no design lead reviewing them, even on one project? (G3)

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.