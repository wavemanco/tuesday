I'll read the reference files the skill requires before building the assessment.
**Worth taking the call, but check the company first. I couldn't verify Fernquay from here, and nothing in the posting or the WhatsApp message asks you for money or personal details (RR1, RR2). Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Two days a week at the Galway office), R2 (Salary €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R7 · adjacent: R6 (Own the booking flow end to end) · unclear: R8 (You would be our first designer)
- `important`: adjacent: R9 (research calls with school owners)

R8 is the real unknown, because you have never been the only designer; R6 (`medium`) is a credible bridge, since checkout is one stage of a booking flow; R2 is open because I don't have your pay floor.

**Opportunity ledger.** The employer isn't established (RR1) and several terms are unstated (RR3, RR4). The WhatsApp contact is scheduling only, and the invite's sender is the check on it (RR2). The posting is open about pay, equity, team size and hybrid terms (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Two days a week at the Galway office), R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies as a real, hiring company (RR1); (2) the invite comes from the company's own domain (RR2); (3) your pay floor and office-day limit fit R1 and R2; (4) the call shows how much design authority the role has without a design lead (R8, RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, a six-person Galway company making booking software for sea-kayak and surf schools. This is the company's own description, not independently established | `[grounded]` posting text you pasted |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Closest collaborator | Co-founder Ronan Kehoe | `[grounded]` posting and WhatsApp message |
| Terms | €52,000–€60,000 plus 0.5–1% equity; hybrid, two days a week in the Galway office | `[grounded]` posting |
| First-year outcomes | None stated; no success measures given | `[grounded]` posting silence |
| Scope read | One product surface covering flow design, research and shipping, so the mandate is broad for one person but coherent | `[inferred]` from the posting's three duties |
| Market calibration | Not run, because the role-family sweep was refused. No band is offered and €52,000–€60,000 is uncompared | `[grounded]` search permission refused |
| Unknowns | Whether the company exists as described; funding and customer base; equity terms; who sets product priorities; what design authority the role has | — |
| Contradictions | None between the posting and the WhatsApp message on names or role. The live posting itself could not be checked | `[grounded]` the two texts you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | unclear | medium | hard_gate | You live in Galway (moved back last year), but you haven't said two office days a week works. Confidence grades your residence statement, not whether the role meets it | `[grounded]` posting and your message | G1 |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | No pay floor from you, and no market band because the sweep did not run, so the figure can't be compared | `[grounded]` posting; floor not given | G1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, which is self-reported with no document inspected | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is a confirmed claim without an inspected artifact. Ronan says they saw your checkout case study, which I haven't seen | `[grounded]` your background; `[grounded]` Ronan's message | Share the case study or portfolio link to raise to high |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Usability sessions are one kind of research, and you haven't mentioned discovery interviews | `[grounded]` your background | Share a session plan or findings note to raise to high |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow. Limit: that is one stage of a booking flow, and whole-flow ownership isn't stated | `[grounded]` your background; `[inferred]` that checkout is one stage of booking | G3 |
| R7 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers; the posting has two | `[grounded]` your background | none |
| R8 | You would be our first designer | must_have | unclear | low | discovery | You have never been the only designer anywhere. Whether you set design direction on checkout without a design lead isn't established | `[grounded]` your statement; `[inferred]` that this is the role's central test | G2 |
| R9 | Research calls with school owners | important | adjacent | medium | transferability | Your sessions were with customers of a consumer travel-booking company. School owners run businesses, so these would be calls with operators, and that kind of call isn't in your background | `[grounded]` your background; `[inferred]` from "school owners" in the posting | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor and office days (R1, R2, hard_gate) | hard_gate | Posting terms are known; your limits on pay and office days are not | Hard-gate checks stay unconfirmed until your limits are known | Any minimum salary, equity preference or commuting limit you hold | Nothing to attach; your own statement | `[grounded]` neither limit stated |
| G2 | Design direction without a design lead (R8, must_have) | discovery | You have always had design peers or leads around you; the CV-level facts don't show who decided what on checkout | The posting makes sole ownership the core of the role, so this decides the positioning | Choosing the checkout approach yourself; deciding what to test and what to ship; saying no to a requested change | Checkout case study, a design-decision note | `[grounded]` your statement; `[inferred]` that the role tests it |
| G3 | Whole booking flow (R6, must_have) | transferability | Checkout is established; search, availability and confirmation stages are not | A bridge from checkout to the whole flow narrows the objection | Work on search or availability screens; owning flow-level metrics | A flow map, a before/after of more than checkout | `[inferred]` stages derived from "booking flow" |
| G4 | Research with small-business operators (R9, important) | transferability | Consumer usability sessions only | Different participants, different questions | Sessions with partners, suppliers or business customers | A discussion guide or findings note | `[inferred]` from "school owners" |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. I could not search at all, so nothing was found either way | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Contact by WhatsApp, with the invite sent separately by email | unknown | — | "I have emailed you a calendar invite with the video link" | The chat appears to be scheduling for a video call, not a hiring process run in chat. Your number may have been on your application | `[inferred]` from the message text; `[generic]` that small companies often schedule by chat | Will the invite come from a company email address, and who else is on the call? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | A percentage alone doesn't say vesting, cliff or share class, so its value is unknown | `[generic]` how equity offers are usually specified | What are the vesting schedule and share class behind the 0.5–1%? | unresolved |
| RR4 | Authority and design support unstated | unknown | — | "own the booking flow end to end" | A sole designer may be accountable for the flow while priorities sit with the co-founder and CTO | `[inferred]` from the posting's silence on decision rights | Which decisions on the booking flow would I make myself, and who sets priorities? | unresolved |
| RR5 | Terms and team size disclosed up front | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity. Hybrid: two days a week" | The posting is specific about pay, equity, hybrid pattern and team size | `[grounded]` posting | Who is on the call besides Ronan and Saoirse? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check that the invite comes from the same domain as Fernquay's own website, and look for the role on the company's own careers page | see RR1, RR2 | `[grounded]` register | pending your approval |
| A2 | Decide your pay floor and office-day limit before the call | see R1, R2 | `[grounded]` gate rows | pending your approval |
| A3 | Describe your work in your own terms: "redesigned our checkout flow" and "ran monthly usability sessions with customers". Say plainly that you worked in a squad with four engineers and have not been the only designer | see R5, R6, R8 | `[grounded]` your background | pending your approval |
| A4 | Ask RR1, RR3 and RR4's questions verbatim on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Have one real project ready to talk through, as the posting invites. Use only work you actually did | see R4 | `[grounded]` posting: "one messy real project" | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Fernquay booking software sea kayak surf schools Galway" and "Fernquay product designer careers" were refused. It would have settled whether Fernquay exists as described and whether the posting is live (RR1, role reality's contradictions row) |
| 2. Role-family sweep | unavailable | Search "product designer salary Ireland 2026 startup first designer" was refused. It would have given the market calibration line and the pay comparison for R2 |
| 3. Hiring manager's public footprint | unavailable | Search "Ronan Kehoe Fernquay co-founder" was refused. It would have informed the scope read and which story to lead with in the application plan |

Everything above is therefore built from your pasted text only.

I can save this as `tuesday-dossier.md` if you want to keep it.

## Upgrade menu

- Permission to run web search: I'd check whether Fernquay exists as described, find the live posting, set a salary band against €52,000–€60,000, and look at Ronan's published professional background. That would update RR1, R2 and the scope read.
- A deeper diligence pass, once search is allowed (up to 5 more searches and 2 more fetches): funding, hiring pattern and recent news. Say the word and it runs.
- A link to the live posting or the sender address of the calendar invite: this settles RR1 and RR2 directly.
- Your pay floor and office-day limit: this resolves R1 and R2 and completes the hard-gates line.
- The checkout case study or a portfolio link: raises R4, R5 and R6 toward `high`, since a portfolio is the inspectable artifact for a designer.
- A note on who decided what in the checkout redesign: closes G2 and R8.

Questions:

1. G1 — What is the lowest salary you would accept, and are two office days a week in Galway workable for you?
2. G2 — On the checkout redesign, did you choose the approach and decide what shipped, or was there a design lead or manager who set direction?
3. RR1 — Do you have a link to the live posting, or the sender address on Ronan's calendar invite?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.