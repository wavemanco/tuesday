I'm reading the skill's reference files so the assessment follows its required format. After that I'll run the company research and write it up.
**Worth applying to?** Yes, and the application is already in, so the question is whether to take the call. **Legit?** I couldn't check that from here, so I'm marking it **`conditional_go`**: take the call, but confirm Fernquay exists before you put in more effort. I assumed your stage is "interviewing", because Ronan thanked you for applying and offered a first call.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Hybrid, two days a week in Galway), R2 (Salary €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important`: unclear: R8 (Research calls with school owners) · absent: R9 (Working as the first designer)

R7 (`medium`): checkout is one stage of a booking flow, not the whole of it; R9: no sole-designer experience, by your own account.

**Opportunity ledger.** The employer can't be established from here (RR1). Nothing in the posting or the WhatsApp message asks for money, documents or a chat-only process, but the sender and the email invite are not yet checked (RR2). The posting states pay, equity and the working pattern (RR5), and says nothing about funding or equity terms (RR4), decision rights (RR3) or a work-sample stage (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days a week in Galway), R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the company and the role are verified as real, via RR1 and RR2; (2) the pay and the Galway days clear your own terms, R1 and R2; (3) R7 and R9 are framed honestly as adjacent and absent, never as end-to-end ownership or sole-designer experience; (4) the call settles decision rights and runway, via RR3 and RR4.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, a six-person team in Galway building booking software for sea-kayak and surf schools. Not checked against any company page or register | `[grounded]` pasted posting; existence unverified (RR1) |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Reporting and process | Works most closely with co-founder Ronan Kehoe. First step is a 45-minute video call with Ronan and the CTO, Saoirse, invited by email | `[grounded]` posting and WhatsApp message |
| Working pattern | Hybrid: two days a week in the Galway office, the rest flexible | `[grounded]` posting |
| Compensation | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Scope read | Broad scope with no design peer: research, flow design and delivery all sit with one person | `[inferred]` from "first designer", "end to end" and a six-person team |
| Market calibration | Not established. The role-family search was refused, so there is no market band for this title and no comparison with the posted pay | `[grounded]` search refused; nothing substituted from memory |
| Unknowns | Decision rights between the designer, Ronan and Saoirse; funding and runway; equity terms; whether a work sample is expected; first-90-day outcomes | `[grounded]` posting silent on each |
| Contradictions | None between the posting and the message: Ronan is the co-founder named in the posting and signs the message | `[grounded]` the two texts you pasted; neither checked against the company's own pages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | unclear | medium | hard_gate | You live in Galway, so the location probably works. You haven't said whether two fixed office days suit you | `[grounded]` your move back to Galway; willingness not stated | gate question in the closing block |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | low | hard_gate | Your minimum salary wasn't given, so I can't check it against the band | `[grounded]` posting; your floor not stated | gate question in the closing block |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company, on your account. Nothing here is inspectable yet; the company has seen your checkout case study | `[grounded]` your description | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use, stated by you | `[grounded]` your description | none |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. That is research you ran yourself | `[grounded]` your description | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your description | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned a travel-booking checkout, which is a core stage of a booking flow. The limit: nothing says you owned the stages before and after checkout, or any operator-side tools | `[inferred]` adjacency from the checkout redesign | see G1 |
| R8 | Run research calls with school owners | important | unclear | low | discovery | You ran customer sessions, but I can't tell whether those customers were travellers or the businesses listing on the platform | `[grounded]` your description, silent on who the customers were | see G2 |
| R9 | Work as the first (only) designer | important | absent | none | capability | You've never been the only designer, which is your own statement. This is implied by "first designer", not a listed requirement | `[inferred]` from the posting; `[grounded]` your statement | see G3; carried as a material risk |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking-flow ownership (R7, must_have) | transferability | A checkout redesign. Nothing on availability search, confirmation or notifications, or the business-side screens | R7 is a `must_have` at `adjacent`. Whether it reads as end to end decides how strong the story is | Changes you drove to date or availability selection, confirmation or cancellation flows, amend-booking screens, or anything an operator used | Before/after screens, a flow map, the checkout case study they already saw | `[inferred]` from the checkout redesign alone |
| G2 | Research with business owners (R8, important) | discovery | Monthly usability sessions, with no detail on who joined them | These calls would be the core of the job, so the gap is whether your research was with the right kind of user | Sessions with partners or suppliers, interviews with hosts or operators, or support-led calls | A research plan or findings summary, with names removed | `[grounded]` your description is silent on participants |
| G3 | Sole-designer experience (R9, important) | capability | Always part of a design team; no design-system, design-ops or solo-ownership work described | The role has no design peer to review or mentor you. This is the most likely objection from their side | None to recover, if the statement stands. The closest bridge is design decisions you made without a lead's sign-off | A design decision you made and defended on your own | `[grounded]` your statement; `[generic]` that a first-designer hire is usually probed on solo ownership |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` you couldn't find much online | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Contact came by WhatsApp, with the invite by email | unknown | — | "I have emailed you a calendar invite with the video link." | Small teams often message candidates on chat. It is only worth checking whether the invite email comes from the company's own domain | `[generic]` hiring practice, not a claim about this employer | Could you confirm which address the invite came from, and where Fernquay's own site lists the team? | unresolved |
| RR3 | Decision rights unspecified for a first designer | unknown | — | "own the booking flow end to end ... work most closely with our co-founder" | Ownership may be nominal, with product decisions resting with the co-founder | `[inferred]` from the posting's scope language against its silence on authority | Which booking-flow decisions does the designer make alone, and which go to you or Saoirse? | unresolved |
| RR4 | Funding, runway and equity terms unstated | unknown | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | Equity at this size is hard to value without vesting terms, strike price, funding and runway | `[generic]` pattern for early-stage equity | How long is the current runway, what are the vesting and exercise terms, and what share of the company does 0.5–1% represent? | unresolved |
| RR5 | Pay, equity and working pattern all stated | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | The posting is concrete about terms, which makes comparison and negotiation easier | `[grounded]` posting | Is the band fixed, or does it depend on experience? | noted |
| RR6 | Work-sample expectation unscoped | unknown | — | "we would rather see one messy real project than a polished deck" | This may signal a project or take-home stage, and its scope and pay are unstated | `[inferred]` from the sentence, against the posting's silence on the process | Is there a work-sample stage, how long should it take, and is it paid? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check that the invite email came from an address matching a Fernquay website, and look the company up in Ireland's Companies Registration Office public search. Open the video link from that email, not the WhatsApp | RR1, RR2 | `[generic]` standard checks | pending your approval |
| A2 | Ask RR1–RR4 and RR6 verbatim on the call, since they double as your interview questions | the register | `[grounded]` register | pending your approval |
| A3 | Lead with the checkout redesign and the monthly usability sessions. Describe R7 as adjacent: say what you owned and what you didn't. Be upfront about R9, since you've never been the only designer | R5, R7, R9 | `[grounded]` your own statements | pending your approval |
| A4 | If a project is requested, ask for its scope and time limit first, and keep it small | RR6 | `[generic]` common practice around unpaid exercises | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Fernquay booking software sea kayak surf schools Galway" was refused. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Search "product designer salary Ireland 2026 startup first designer" was refused. It would have moved the market calibration row and the pay comparison for R2 |
| 3. Hiring manager's public footprint | unavailable | Search "Ronan Kehoe Fernquay co-founder" was refused. It would have moved the scope read and A3's positioning |

## Upgrade menu

- Fernquay's website or careers link: I read it as an input, free of the search budget, and it moves RR1 and RR2. Companies Registration Office results, if you check them, help in the same way.
- Your minimum salary and your view on two Galway office days → R1 and R2 resolve.
- Details of your checkout project and who your usability participants were → R7 and R8 firm up, and G1 and G2 may close.
- Search permission → the company, market and Ronan lookups can run (2 searches left at this tier). A deeper pass on funding, hiring patterns and news would be up to 5 more searches and 2 more fetches, and runs only on your yes.
- Ronan's and Saoirse's public professional profiles, if you share links → the scope read and A3 sharpen.

I can also write this up as `tuesday-dossier.md` whenever you want it.

1. R1 and R2: do the pay band and two fixed Galway office days both clear your own minimums?
2. G1 (R7): beyond checkout, which parts of your company's booking flow did you design or own, such as search, availability, confirmation or anything operators used?
3. G2 (R8): who were the customers in your monthly usability sessions, travellers or the businesses listing on the platform?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.