I'll read the skill's reference files before building the assessment.
## Decision snapshot

**Duinvaart Cold Chain (Operations Analyst): yes, this one is worth your time. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Hybrid, three days a week in Rotterdam office)
- `must_have`: direct: R2, R3, R4
- `important`: direct: R5 · adjacent: R7 (Work with depot managers on route changes) · unclear: R6 (Temperature compliance across the refrigerated fleet)
- `preferred`: adjacent: R8 (Dutch a plus)

R6 — cold-chain specifics, background silent; R7 — a review you ran, route-change role unconfirmed.

**Opportunity ledger.** The scope and tools are concrete (RR5). The employer could not be checked because no search ran (RR1), and the pay is not stated (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, three days a week in Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) three office days in Rotterdam work from where you live (R1, G1); (3) your cold-chain exposure is stated as it is, adjacent at most (R6, G2).

**Kroonhaven Foods (Supply Planner): no, not worth tailored effort. Status: `no_go`.** R10 and R14, both `must_have` rows at `absent`, are capability gaps you confirmed yourself ("never worked in planning").

**Fit ledger.**

- `hard_gate`: unclear: R9 (On-site in Utrecht)
- `must_have`: adjacent: R11 (Fluent Dutch) · unclear: R12 (Advanced Excel), R13 (SAP IBP or a similar planning system) · absent: R10 (3+ years of supply or demand planning in FMCG), R14 (Own the 13-week supply plan)
- `important`: adjacent: R15 (Run the weekly S&OP meeting)

R10, R14 — no planning history by your own account; R11 (`medium`) — conversational against a stated fluent requirement; R15 — the review you run is the nearest evidence.

**Opportunity ledger.** The employer is unverified because no search ran (RR2), and the pay is not stated (RR4).

- **Hard gates:** none failed; unconfirmed: R9 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** supply or demand planning work in your history, which would have to exist for R10 and R14. Nothing in your background points to it, so no question is asked here.

## Role reality

| Element | Duinvaart Cold Chain | Provenance |
|---|---|---|
| Organization | Cold-chain operator in Rotterdam with a refrigerated fleet and depots; existence not checked | `[grounded]` JD text only |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Scope read | Reporting and depot liaison in one post; no team, reporting line or first-year outcomes named | `[inferred]` from the JD's silence on them |
| Market calibration | Not run, so no salary band is offered | `[grounded]` search calls were refused this session |
| Unknowns | Pay, reporting line, fleet and depot count, success measures | `[grounded]` absent from the JD |
| Contradictions | None inside the JD; not compared against a careers page | `[grounded]` JD only |

| Element | Kroonhaven Foods | Provenance |
|---|---|---|
| Organization | Chilled ready-meals maker in Utrecht; existence not checked | `[grounded]` JD text only |
| Mandate | Own the 13-week supply plan, balance capacity against forecast, run the weekly S&OP meeting | `[grounded]` JD |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Scope read | A single-owner planning seat with a named cadence (13 weeks, weekly S&OP); no team or system ownership stated | `[inferred]` from the JD wording |
| Market calibration | Not run, so no salary band is offered | `[grounded]` search calls were refused this session |
| Unknowns | Pay, reporting line, planning-system maturity, size of the ready-meals range | `[grounded]` absent from the JD |
| Contradictions | None inside the JD; not compared against a careers page | `[grounded]` JD only |

## Evidence map

**Duinvaart Cold Chain**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | none | hard_gate | You stated no location or schedule constraints, so the gate is not established. Confidence grades your statement of a constraint, and there is none yet | `[grounded]` JD quote; nothing from you on commute | G1: your realistic office days |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier, as you stated; specific, with no document inspected | `[grounded]` your background; `[inferred]` that parcel delivery counts as logistics here | none |
| R3 | Strong SQL | must_have | direct | medium | none | "SQL daily", stated; no artifact inspected | `[grounded]` your background | none |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including the on-time delivery dashboard your depot managers use; you did not say whether you built it or maintained it | `[grounded]` your background | W1: sanitized dashboard screenshot would raise to high |
| R5 | Track on-time delivery | important | direct | medium | none | The dashboard and the weekly route-performance review are on-time performance work at a carrier; limit: parcels, not a refrigerated fleet | `[grounded]` your background | none |
| R6 | Track temperature compliance across the refrigerated fleet | important | unclear | none | discovery | Nothing you wrote mentions temperature-controlled freight. Compliance tracking could exist in your parcel work, but the inputs do not show it | `[grounded]` background silent | G2 |
| R7 | Work with depot managers on route changes | important | adjacent | medium | discovery | You ran the weekly route-performance review and depot managers use your dashboard. Whether the review led to route changes you worked on is not stated | `[grounded]` your background; limit named, not widened | G3, lower rank, not asked now |
| R8 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch, by your account. It is a plus here and not a requirement, so the shortfall costs little | `[grounded]` your background and the JD's wording | G5: state the level plainly |

**Kroonhaven Foods**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R9 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No constraints given from you, so a full on-site schedule is not established as workable | `[grounded]` JD quote; nothing from you on commute | G1 |
| R10 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You confirmed you have never worked in planning, and nothing adjacent is stated for FMCG. Years of experience are not a gate, but postings of this kind are often screened on them literally | `[grounded]` your statement; `[generic]` the screening pattern | G4: closure path named |
| R11 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational Dutch is real, usable evidence. The limit is that it is not fluent, and no fluency level was shown | `[grounded]` your background | G5: bridge case, and the limit stays attached |
| R12 | Advanced Excel | must_have | unclear | none | discovery | SQL and Power BI are stated, Excel is not. Nothing contradicts it either | `[grounded]` background silent | none now; the decision rests on R10 and R14 |
| R13 | SAP IBP or a similar planning system | must_have | unclear | none | discovery | No planning-system use is stated, and you said you have not worked in planning. Left unclear because a similar system is a loose phrase | `[grounded]` background silent | none now; same reason as R12 |
| R14 | Own the 13-week supply plan, balancing production capacity against the forecast | must_have | absent | none | capability | Same ground as R10: no planning ownership, direct or adjacent, stated | `[grounded]` your statement | G4 |
| R15 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review, which is a recurring cross-team operating meeting. Limit: it was not an S&OP meeting and did not balance supply against a forecast | `[grounded]` your background; limit named | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Office days from where you live (R1, R9) | hard_gate | The postings need three days a week in Rotterdam and every day in Utrecht. Your constraints are not given | A failed gate caps the decision however strong the fit. R1 is the only thing standing between Duinvaart and a plain `go` once the employer verifies (RR1) | n/a, this is a term, not experience | Your own statement of what is workable | `[grounded]` JD terms; nothing from you |
| G2 | Temperature or cold-chain tracking (R6) | discovery | Parcel on-time work is established; temperature work is neither shown nor ruled out | An important row at `unclear` that is the role's most specific demand | Parcels with temperature requirements (food, pharma); excursion or exception reports; delivery-window SLAs for chilled customers; a depot cold-store audit | A sanitized report or dashboard screenshot showing the metric definition | `[grounded]` background silent; `[inferred]` that this is the requirement most likely probed |
| G3 | Route-change involvement (R7) | discovery | The review you ran is stated; route changes arising from it are not | Strengthens an adjacent row, but resolving it moves no decision | A depot route you recommended changing; a review finding that led to a rerouting | Review notes or a before-and-after performance chart | `[grounded]` background silent |
| G4 | Planning ownership (R10, R14, R15) | capability | No planning work stated; the weekly review is the only adjacent item | Two `must_have` rows at `absent` are what drive `no_go` | n/a on current evidence. The closure path is a role where planning is learned, such as demand or supply planning analyst, or a planning course plus a project | A small forecast-versus-capacity exercise using public data (a work sample) | `[grounded]` your statement; `[generic]` that analyst-to-planner moves are a common route |
| G5 | Dutch level (R8, R11) | transferability | Conversational Dutch, stated | Preferred at Duinvaart, must-have at Kroonhaven | Daily Dutch with depot colleagues; Dutch-language reports or meetings | An inspectable level result from a language test or course | `[grounded]` your statement; limit named in R11 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer (Duinvaart) not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The entity may be small or new, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Is this role listed on your own careers page, and who would I be interviewing with? | unresolved |
| RR2 | Employer (Kroonhaven) not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Same possibilities as RR1, side by side and none ranked as likely | `[generic]` pattern for companies of this size, not a claim about this one | Is this role listed on your own careers page, and who would I be interviewing with? | unresolved |
| RR3 | Pay not stated (Duinvaart) | unknown | — | the posting gives no figure | The figure may sit anywhere relative to market, or the company may not publish pay | `[grounded]` the posting withholds it; no band exists because the sweep did not run | What salary range is budgeted for this post? | unresolved |
| RR4 | Pay not stated (Kroonhaven) | unknown | — | the posting gives no figure | Same as RR3 | `[grounded]` the posting withholds it; no band exists because the sweep did not run | What salary range is budgeted for this post? | unresolved |
| RR5 | Concrete deliverables and named tools (Duinvaart) | positive_signal | — | "track on-time delivery and temperature compliance... build weekly dashboards in Power BI" | The work is defined and matches things you already do | `[grounded]` JD wording | What would a good first six months look like in this role? | noted |

## Application plan

All rows are proposals; nothing is final until you approve it. Each carries its own status.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Duinvaart: confirm the employer and live posting before tailoring anything | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Duinvaart: if it verifies, lead the CV with "Power BI and SQL, daily, including the on-time delivery dashboard used by our depot managers" and "ran the weekly route-performance review". Confirm whether you built or maintained the dashboard before any wording says "built" | see R2 to R5, R7. Every clause traces to your own sentences; the ownership verb is held at what you stated | `[grounded]` your background | resume_edits_pending_approval |
| W1 | Duinvaart: a sanitized screenshot of the on-time delivery dashboard as a work sample | see R4, R5 | `[grounded]` R4, R5 rows | pending your approval |
| A3 | Kroonhaven: if you apply at all, send the existing CV, make no planning claim and no fluency claim, and keep effort low | see R10, R11, R14 | `[grounded]` R10, R11, R14 rows | pending your approval |
| A4 | Spend the saved effort on analyst roles near logistics or planning, where R10 and R14 are not must-haves | see G4 | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam refrigerated transport" and "Kroonhaven Foods Utrecht chilled ready-meals"; every call was refused. Would have moved role reality's organization and contradictions rows and RR1, RR2 |
| 2. Role-family sweep | unavailable | Searched "operations analyst logistics salary Netherlands Rotterdam supply planner FMCG salary Utrecht"; the call was refused. Would have moved the market calibration row and RR3, RR4 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

---

If you want it, I can write all of this up as `tuesday-dossier.md`.

**Upgrade menu**

- Links to each live posting or careers page → RR1, RR2 close, and Duinvaart's status can move toward `go`.
- Your commute limits, the days you will work in an office, and a pay floor → R1 and R9 become met or failed, and RR3, RR4 get a figure to compare against.
- An answer to G2, or a sanitized report that shows temperature work → R6 moves off `unclear`.
- Search access for the company and salary checks (the three refused calls) → role reality's organization row, the market calibration row, and RR1 to RR4 get grounded.
- A hiring manager's name for either role → role reality's scope read, and which story the plan leads with.
- Your CV file, or the dashboard itself → R4 and R5 reach `high`.

**Questions**

G1 — How many days a week can you realistically be in an office in Rotterdam or Utrecht from where you live?

G2 — In your parcel work, did you ever track or report on shipments with temperature requirements, such as food or medical parcels, and what exactly was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.