**Yes, this is normal, and the sequence you describe is the legitimate one.** Your instinct is still right. The rule is never to hand these over *before* you've verified who is asking, and that's what to check here.

**Why each item is needed**
- **Bank details:** they can't pay you without them.
- **PPS number:** an Irish employer has to include your PPSN in its payroll submissions to Revenue. You'll know this from your own work.
- **Passport:** employers must check that you're entitled to work in Ireland. A passport scan plus the original on day one is a common way to do that.

**Why this looks legitimate**
- You had two in-person interviews at their office.
- The offer came from a company-domain email.
- They ask for the sensitive details only *after* you accept, through a portal, and not in the offer email.
- There was no upfront payment, no request to buy equipment, and no pressure to move to WhatsApp or Telegram.

I haven't checked the company online, so none of this verifies Marrowgate itself. Do these checks before you enter anything:
1. **Compare the email domain.** Check that `marrowgatehousing.ie` matches the domain on their real website and on the emails you got when arranging the interviews.
2. **Don't trust the link in the email.** When the portal link arrives, check that it sits on their own domain or a known HR/payroll provider. If in doubt, ring the office on a number from their website, or ask Declan or the interviewer to confirm the link.
3. **Send the passport only through the portal.** Never send it by plain email or messaging app.
4. **Ask two questions.** Ask who their data controller or contact is, and how long they keep the passport scan. A real employer will have an answer, and it's a fair question under GDPR.

**Before you accept**
- Ask for the **written contract or terms**: probation, notice period, pension scheme, annual leave and the hybrid arrangement. The offer email has none of these. A written statement of terms is a legal entitlement in Ireland.
- Nothing in the email suggests a problem. The five-working-day deadline is ordinary.

**On the job itself**
- You match the core requirements: PAYE/PRSI/USC payroll, reconciliation, Excel, and a qualification.
- The one gap is **pension changes**, which you haven't done yourself. You told them at interview or can tell them now.
- Ask whether you'll get a handover or training on pensions in the first few months.
- €40,000 sits in the middle of their advertised band.

If you'd like, paste the portal link or the sender's header details when they arrive and I'll help you sanity-check them. I can also draft a short reply accepting and asking for the contract.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.