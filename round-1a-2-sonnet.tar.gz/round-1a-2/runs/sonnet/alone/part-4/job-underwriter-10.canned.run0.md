I've read the skill's rules and run two searches on Fernquay. Next I'm checking their own site for the posting and sweeping typical pay for this role.
**Is it worth it, and is it legit?** Yes to both on what I could check, with conditions below. I found a real company with a matching careers listing, and your WhatsApp message asks nothing of you beyond a scheduled video call. From your message I'm assuming you've already applied and this is the first-call stage.

## Decision snapshot

**Yes, take the call. Fernquay exists as described and nothing in the message asks anything of you beyond a call (RR1, RR2). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Pay €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important`: adjacent: R9 (First designer, no design peers) · unclear: R8 (Research calls with school owners)

R7: checkout is one part of a booking flow, the rest is unevidenced; R9: you have never been the only designer, so it is adjacent at best; R8: who sat in your usability sessions is unconfirmed; R2: your pay floor is unknown.

**Opportunity ledger.** The employer and the role are consistent with each other and the pay is in a normal range (RR3). The open items are WhatsApp as the contact channel (RR1), equity terms (RR4), who decides what for a sole designer (RR5), and how a customer-funded six-person company sustains the hire (RR6).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52,000–€60,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) €52,000–€60,000 clears your own floor (R2); (2) the invite arrives from a Fernquay address matching the careers page (RR1); (3) equity terms are shown in writing before you weigh the equity (RR4); (4) the sole-designer remit is something you want, given you have always had design peers (R9, RR5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` About page, fernquay.example/about |
| Public footprint | I found an About page, a careers listing and one profile for Ronan, and nothing else; I did not look for customer reviews, funding or news | `[grounded]` the three pages found |
| Role | First product designer: own the booking flow end to end, run research calls with school owners, ship with two engineers, work most closely with Ronan | `[grounded]` posting |
| Terms | €52,000–€60,000 plus 0.5–1% equity; hybrid, two days a week in Galway | `[grounded]` posting; the careers listing shows the same salary and hybrid pattern, and shows equity only as "plus equity" |
| Scope read | A broad remit for one person (flow ownership, research and engineering collaboration), which is common for a first design hire at six people | `[inferred]` from the posting's three responsibilities against the stated headcount |
| Hiring manager | Ronan Kehoe, co-founder and CEO; earlier, product lead at a Galway travel-software company for five years | `[grounded]` profile snippet, linkedin.example/in/ronan-kehoe |
| Market calibration | Product designers with 3 to 5 years in Ireland: median base €57,000, interquartile range €51,500 to €62,000. The posting's band sits inside it. The survey says nothing about equity or first-designer remits, and a market band is never this employer's offer | `[generic]` Tillerby 2026 Ireland Design Salary Report; `[grounded]` posting figure |
| Unknowns | Whether the post is permanent, equity vesting and strike terms, decision rights, success measures, runway | `[grounded]` posting silent on each |
| Contradictions | None between the posting and the careers listing. The equity percentage is absent from the listing snippet | `[grounded]` listing snippet against the posting |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week in the Galway office | hard_gate | direct | medium | none | You live in Galway, so the location term is met. You haven't said whether two fixed office days suit you; that stays yours to confirm | `[grounded]` your message, moved back to Galway; constraint itself unstated | confirm the office days suit you |
| R2 | Pay €52,000–€60,000 | hard_gate | unclear | none | hard_gate | You haven't stated a floor, so nothing settles whether the band meets it | `[grounded]` posting figure; no stated floor | G4 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company, self-reported and not yet backed by an inspected artifact | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | Figma daily over four years; no portfolio inspected | `[grounded]` your background | offer: link your case study |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers. Whether you ran every stage yourself is unconfirmed | `[grounded]` your background | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout, which is part of a booking flow. Not evidenced: search, availability, post-booking, or the operator side. The limit stays named wherever the bridge is used | `[inferred]` from the checkout redesign against the posting's "end to end" | G2 |
| R8 | Research calls with school owners | important | unclear | low | discovery | Your sessions were with customers of a travel-booking company. Whether those were consumers or business operators, and whether you moderated them yourself, isn't stated | `[grounded]` your background; `[inferred]` that the posting's users are business owners, from its wording | G1 |
| R9 | First designer: no design peers or lead | important | adjacent | low | transferability | You have never been the only designer. The adjacent work is the process and flow ownership in your squad. Not exercised: setting design direction with no one to review it | `[inferred]` from the posting's "our first designer"; `[grounded]` your statement | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Research with school owners (R8) | discovery | Monthly usability sessions with customers; participants and your role in them unclear | Business operators are who the role will interview, so a match here narrows a likely objection | Interviews with operators or partners, not only end customers; recruiting, moderating and writing up your own sessions; a finding that changed a design | A session guide, a findings deck, an anonymised synthesis | `[grounded]` your background silent on participants; `[generic]` that operator-facing research is the usual probe in a B2B role |
| G2 | Whole-flow ownership (R7) | transferability | Checkout redesign confirmed; nothing on the steps before or after it | "End to end" is the posting's headline responsibility | Work on search, availability, basket, confirmation, rebooking or the cancellation flow | Your checkout case study, a flow map, before-and-after screens | `[inferred]` bridge from the checkout work; `[grounded]` posting wording |
| G3 | Sole-designer experience (R9) | transferability | Squad work with four engineers; no work without design peers | You would be setting direction with nobody to review it | Making calls without sign-off; briefing engineers on your own; defining a small pattern library | A decision log, a short example of a call you owned | `[grounded]` your statement; `[inferred]` limit |
| G4 | Pay floor (R2) | hard_gate | Band stated, floor unknown | A hard gate is unconfirmed until you answer | — | — | `[grounded]` posting; no stated floor |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | First contact came by WhatsApp, not email | unknown | — | "Hi Maeve, Ronan from Fernquay here" | A small team may simply schedule on the quickest channel. The careers page names an email address, so the invite email is the thing to check | `[generic]` pattern for small teams; `[grounded]` careers listing names jobs@fernquay.example | Could you send the invite from your Fernquay address so I can confirm the video link? | unresolved |
| RR2 | Nothing in the material asks you for payment, ID, bank details or a cheque; the call is by video, with the invite by email | positive_signal | — | "I have emailed you a calendar invite with the video link" | The process looks like an ordinary interview process on what you've shared | `[grounded]` the WhatsApp message | Who else will I meet after this call? | noted |
| RR3 | The stated pay is inside the market band | positive_signal | — | "Salary €52,000–€60,000" | The figure is plausible for 3 to 5 years' experience; it says nothing about the equity or the employer's finances | `[grounded]` posting figure; `[generic]` survey band | Is the band fixed, or does it move with the equity share? | noted |
| RR4 | Equity stated as a range with no terms | unknown | — | "0.5–1% equity" | The value depends on vesting, strike or grant terms, share class and company valuation, none of which is stated | `[inferred]` from the posting's silence on terms | What are the vesting schedule, cliff and exercise terms, and can I see them in writing? | unresolved |
| RR5 | Broad ownership with no stated decision rights or success measures | unknown | — | "own the booking flow end to end" | You may own outcomes while decisions on the flow sit with the co-founder | `[inferred]` from the posting's ownership language against its silence on authority and metrics | Which booking-flow decisions would I make alone, and what would success look like in year one? | unresolved |
| RR6 | Funded by its customers, with a new hire at this size | unknown | — | "funded by its customers" | A customer-funded company has no outside investor to cover a gap; how much runway the hire has is unknown | `[grounded]` About page; `[inferred]` that runway is the open question | How many months of runway does the company have, and is this role funded from current revenue? | unresolved |

## Application plan

Everything below is proposed and nothing is final until you say so. That covers the prose in this plan as well as the table.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take the call, after checking that the invite email comes from a Fernquay address | see RR1 | `[grounded]` careers listing | pending your approval |
| A2 | Lead with the checkout case study they already praised, described as checkout and not as the whole flow, plus your monthly sessions; say plainly you have always worked beside other designers | see R7, R9. Ronan's background is in travel software, so your travel-booking work is the closest match to his own | `[grounded]` your message and background; `[inferred]` from his profile | pending your approval |
| A3 | Ask the verification questions for RR4, RR5 and RR6 on the call | the register doubles as your question list | `[grounded]` register | pending your approval |
| A4 | Have one real, messy project ready, as the posting invites | see R4, R5 | `[grounded]` posting | pending your approval |
| A5 | If your answer to G1 shows operator-facing research, prepare a short story of a finding that changed a decision; if not, say it was customer research | see R8 | `[grounded]` G1 | pending your approval |

## Evidence status

Verified: none yet. Your background is self-report and no portfolio or case study has been inspected, so the claims in R3 to R6 stay at `medium`. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay careers Product Designer Galway"; fetched "About Fernquay" (fernquay.example/about); the careers listing "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer) was seen as a search result only. Moved: role reality's organization and contradictions rows; the employer is established, so no failed-attribution entry is needed |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup first designer equity 2026", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved: market calibration and RR3. It did not cover equity |
| 3. Hiring manager's public footprint | yes | Searched "Fernquay Ronan Kehoe", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Moved: role reality's hiring-manager row and A2's positioning |

If you'd like, I can write all this up as a `tuesday-dossier.md` to keep.

## Upgrade menu

- Your pay floor, and whether two fixed office days work for you: R2 and R1 close, and the hard-gates line settles.
- A link to your checkout case study or portfolio: R3, R4, R5 and R7 can rise toward `high`, since in design an inspected case study is the artifact that counts.
- A session guide or findings write-up from your usability sessions: R8 resolves.
- Equity terms in writing: RR4 closes.
- The invite email's sender address: RR1 closes.
- A deeper research pass on Fernquay (customer reviews, funding or news, hiring history; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

- G4 (R2): What is the lowest base salary you would accept for this role?
- G1 (R8): Who took part in your monthly usability sessions (consumers, or people running travel businesses), and which parts did you personally run?
- G2 (R7, R9): How far did your checkout redesign reach beyond checkout, and which decisions did you make without a design lead signing off?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.