I'll read the skill's reference files before building the assessment.
I've run 3 of my 5 searches: the employer, the pay band and the team lead. Next I'll fetch Calderbrook's careers page to check the posting is live and matches your copy.
**Aoife, yes, this one is worth applying for. Status: `conditional_go`.** R4 (written records on the electronic patient record) and R7 (leg-ulcer care) are `must_have` rows with `unclear` fit, because your CV says nothing either way. Both can be settled with your answers.

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R6, R8, R9 · adjacent: R5 (home visits to housebound adults) · unclear: R4 (clear, timely written records), R7 (leg-ulcer care)
- `important`: adjacent: R13 (own small caseload, supported) · unclear: R10 (continence care beyond catheters), R11 (care planning), R12 (end-of-life visits)
- `preferred`: absent: R14 (Doppler assessment)

R5 and R13 — the discharge-to-assess home visits are a bridge, with the limit named; R4, R7 — CV silent; R14 — Doppler, absent.

**Opportunity ledger.** The posting is clearly scoped and states a support structure (RR2). Open points are whether the posting is still live (RR1), the rota (RR3), where you would start in the pay range (RR4) and the contract terms (RR5). Doppler training looks available through the team lead's published interests (RR6).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R4 and R7 get answers from you, either confirmed experience or confirmed absence; (2) RR1 resolves, so the post is confirmed open; (3) R5 and R13 are framed as discharge-to-assess home visits, never as holding your own caseload.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff in four locality hubs | `[grounded]` About page, via search result |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration and care planning, recorded on an electronic patient record | `[grounded]` JD |
| Caseload and support | A small caseload of your own, supported by a senior community nurse | `[grounded]` JD |
| Essential | Current NMC registration as an Adult Nurse; full UK driving licence (pool cars provided); at least one year's post-registration experience; clear, timely written records | `[grounded]` JD |
| Desirable | Doppler assessment for leg ulcers | `[grounded]` JD |
| Scope read | Five care areas listed for one post, presented as one caseload and not as separate specialisms, so there is no sign of bundled roles | `[inferred]` from the JD's wording |
| Team lead | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. She spoke at a 2025 forum on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work. The posting names her only as the contact for an informal chat, so whether she is the hiring manager is not established | `[grounded]` speaker page, via search result; `[inferred]` that leg-ulcer care is a team priority |
| Pay and calibration | Posting: £31,050–£37,800 plus mileage, with pool cars. A 2026 pay survey of community staff nurses at Band 5 in England (n=1,240) reports median basic pay of £34,300 and an interquartile range of £32,400 to £36,600; 24% had a pool or lease car. The posting's range runs beyond both ends of that interquartile range. The band is what to expect, never this employer's offer to you | `[grounded]` JD for the posting's figures; `[generic]` survey, from the search snippet only |
| Unknowns | Whether the posting is live; rota and weekend working; where in the range a new-to-community nurse starts; whether terms mirror NHS terms; how lone working is phased in | — |
| Contradictions | None found between the JD and the About page. The careers page could not be read, so the posting itself is unchecked (RR1) | `[grounded]` About page; careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state Registered Nurse (Adult), registration active, revalidation due March 2028. Stated and not inspected; checking your own register entry is yours | `[grounded]` CV | Confirm your entry on the NMC online register shows active status |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | You state a full UK licence, category B. Stated as given | `[grounded]` CV | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | You state five years as a staff nurse on an acute medical ward at a district general hospital. The CV is the only source | `[grounded]` CV | none |
| R4 | Clear, timely written records (on an electronic patient record) | must_have | unclear | none | discovery | The CV does not mention records or any electronic patient record system. Records are part of ward nursing, but that is a pattern and not your claim | `[grounded]` CV silence; `[generic]` that ward nursing involves records | See G2 |
| R5 | Home-based care of housebound adults | must_have | adjacent | medium | transferability | You visited patients at home in their first week after discharge, over the last 18 months, on secondment to the discharge-to-assess team. Limit: short post-discharge visits, which is not stated to be ongoing care of long-term housebound adults | `[grounded]` CV; `[inferred]` adjacency | See G4 |
| R6 | Wound care | must_have | direct | medium | none | You state wound care including pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R7 | Leg-ulcer care | must_have | unclear | low | discovery | Pressure-ulcer and surgical wound care are stated; leg ulcers and compression are not. Whether they overlap is unknown | `[grounded]` CV | See G1 |
| R8 | Catheter care | must_have | direct | medium | none | You state catheter care | `[grounded]` CV | none |
| R9 | Insulin administration | must_have | direct | medium | none | You state insulin administration | `[grounded]` CV | none |
| R10 | Continence care beyond catheters | important | unclear | none | discovery | The CV covers catheter care only | `[grounded]` CV silence | See G3 |
| R11 | Care planning | important | unclear | none | discovery | The CV does not mention care planning | `[grounded]` CV silence | See G3 |
| R12 | End-of-life visits | important | unclear | none | discovery | The CV does not mention palliative or end-of-life care | `[grounded]` CV silence | See G3 |
| R13 | A small caseload of your own, supported by a senior community nurse | important | adjacent | medium | transferability | You say you have never held your own caseload. The home visits are adjacent. Whether they were made alone, or on a list you managed, is unstated | `[grounded]` your statement and CV | See G4 |
| R14 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You say you have never done a Doppler assessment. The team lead has spoken publicly on Doppler training for staff new to community work, which suggests it may be taught on the job | `[grounded]` your statement, speaker page; `[inferred]` that training may be offered | Ask about training (RR6) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R7, must_have) | discovery | Pressure-ulcer and surgical wound care only | A `must_have` named in the posting; the team lead's published interest makes it likely to be probed | Applying compression bandaging or hosiery; dressing leg wounds on venous or mixed ulcers; assessing a leg wound and referring on | A wound-care competency sign-off, a training certificate, a ward procedure you followed | `[grounded]` CV silence; `[inferred]` that it will be probed, from the speaker page |
| G2 | Written records on an electronic patient record (R4, must_have) | discovery | Silent on records and systems | A `must_have`; the posting calls out "clear, timely written records" | Which electronic records system you used on the ward or on the discharge-to-assess visits; writing visit notes after home visits; any audit of your documentation | A documentation audit result, a competency record | `[grounded]` CV silence and JD |
| G3 | Continence, care planning and end-of-life care (R10, R11, R12; important) | discovery | The CV names none of the three | Each is named in the advert's list of duties, but none is a `must_have` | Bladder or bowel care beyond catheters; writing or updating a care plan; caring for dying patients on the ward or in discharge planning | A training record, a care plan you wrote, a ward competency | `[grounded]` CV silence |
| G4 | Own caseload, and home-based care of housebound adults (R13, R5) | transferability | Home visits to patients in their first week after discharge; no own caseload by your account | The role is built on a caseload with support; the bridge needs its limit stated | The adjacent work is the discharge-to-assess visits, and the limit is that no own caseload was held. The strengthener is a short description of how visits were allocated and whether you made them alone | A description of the discharge-to-assess service, a reference from its lead | `[grounded]` your statement and CV; `[inferred]` bridge |
| G5 | Doppler assessment (R14, preferred) | capability | None by your own statement | Desirable only; no gate | None to recover. Closure path: ask whether training is provided to new starters | The employer's training offer | `[grounded]` your statement; `[inferred]` that training may exist |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The careers page I tried is an address I guessed, not one from the posting, so the failed read says nothing about the post. The vacancy may be listed elsewhere or may have closed | `[inferred]` from the failed fetch | Is this post still open, and what is the closing date? | unresolved |
| RR2 | Support structure stated | positive_signal | — | "supported by a senior community nurse" | The post appears to include named support for a first caseload | `[grounded]` JD | How does the support work in the first weeks, such as shadowing, joint visits or supervised lone working? | noted |
| RR3 | Rota unstated | unknown | — | "caring for housebound adults in their own homes" | The posting does not say whether weekends, evenings or on-call are part of the rota | `[inferred]` from the JD's silence | What does the rota look like, including weekends and evenings? | unresolved |
| RR4 | Pay placement within a wide range | unknown | — | "£31,050–£37,800 a year plus mileage" | The posting states a figure, so nothing is withheld. Where a new-to-community nurse would start is unstated, and the pool cars are a stated benefit | `[grounded]` JD; `[generic]` survey band (R-free comparison in role reality) | Where in the range would someone with my background be appointed? | unresolved |
| RR5 | Terms of a community interest company against NHS terms | unknown | — | "Calderbrook Community Health CIC" | A community interest company working under an NHS contract may or may not mirror NHS terms on pension, sick pay and leave | `[generic]` pattern, not a claim about this employer | Are pension, sick pay and annual leave equivalent to NHS terms? | unresolved |
| RR6 | Doppler training likely available | positive_signal | — | "Desirable: Doppler assessment for leg ulcers" | The team lead has spoken on Doppler training for staff new to community work, so the post may carry training for it | `[inferred]` from the speaker page | Is Doppler training provided to new starters, and when? | noted |

## Application plan

`resume_edits_pending_approval`, covering the table and the prose beneath it: none of this is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | In your experience entry, state that the last 18 months were on secondment to the discharge-to-assess team, visiting patients at home in their first week after discharge, and put it at the top of the entry | R5, R13 | `[grounded]` CV | pending your approval |
| E2 | Open with: "Registered Nurse (Adult), NMC registration active; full UK driving licence, category B; Halifax-based" | R1, R2 | `[grounded]` CV | pending your approval |
| A1 | Take up the offer of an informal chat with Rhiannon Mabbott and use RR1 to RR6 as your questions | The register doubles as interview preparation | `[grounded]` JD, register | pending your approval |
| A2 | Say plainly that you have not held your own caseload and have not done a Doppler assessment, and ask what support and training the post gives | R13, R14 | `[grounded]` your statement | pending your approval |
| A3 | Add leg-ulcer, records and end-of-life lines only after G1 to G3 are answered and confirmed | R4, R7, R12 | `[grounded]` gap queue | pending your approval |

## Evidence status

Verified: none yet. Your CV claims stand as self-report. Your National Insurance number is not needed for this and I have not used it. Your NMC PIN was not used in any search.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax community staff nurse", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, an address I guessed, which returned no page. Moved: the employer exists as described (role reality, Organization). The posting itself is unchecked (RR1) |
| 2. Role-family sweep | yes | Searched "community staff nurse district nursing Band 5 salary Agenda for Change 2026 scope", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: the pay calibration in role reality and RR4. It returned nothing on scope, so no scope norm is claimed |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: role reality's team lead row, RR6, and the weight on R7 and R14 |

I can write this up as `tuesday-dossier.md` if you want a file to keep.

**Upgrade menu**

- A short note that you have checked your own entry on the NMC online register (status and dates) would raise R1 toward `high`.
- A wound-care, catheter or insulin competency sign-off, or a revalidation portfolio extract, would raise R6, R8 and R9 toward `high` and may settle R7.
- A description of the discharge-to-assess service, or a reference from its lead, would strengthen R5 and R13.
- A link to the live posting or job pack would close RR1 and may add detail on rota and terms.
- Your own non-negotiables (pay floor, hours, weekends, part-time or full-time) would let the hard-gate checks run against them.
- A deeper research pass on Calderbrook (up to 5 more searches and 2 more fetches) will run if you say the word.

**Questions**

- G1 — Have you applied compression bandaging or hosiery, or dressed leg ulcers, on the ward or on discharge-to-assess visits? What did you do yourself, and is there a competency sign-off or training record?
- G2 — Which electronic records system did you use on the ward or on home visits? Did you write your own visit notes, and has your documentation ever been audited?
- Constraints — Do you have any non-negotiables for a role like this, such as a pay floor, weekends, or full-time against part-time?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.