I'll read the skill's reference files first.
## Decision snapshot

**FIRST, Duinvaart Cold Chain: worth your time, on conditions. Status: `conditional_go`. SECOND, Kroonhaven Foods: not worth your time. Status: `no_go`, because RB2, RB3 and RB6 are absent must-haves.**

**FIRST: fit ledger.**

- `hard_gate`: unclear: RA1 (Hybrid, three days in Rotterdam)
- `must_have`: direct: RA2, RA3, RA4, RA5a · unclear: RA5b (temperature compliance tracking)
- `important`: adjacent: RA6 (Depot managers on route changes)
- `preferred`: adjacent: RA7 (Dutch a plus)

RA5b (`none`): no cold-chain evidence yet; RA6: close, but route changes unconfirmed; RA1: commute unknown.

**FIRST: opportunity ledger.** Duties and tools are named concretely (RRA3). Pay is unstated (RRA1), and the employer is not yet verified (RRA2).

- **Hard gates:** none failed; unconfirmed: RA1 (Hybrid, three days in Rotterdam); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RA1 confirmed workable for you; (2) the employer and live posting verified, RRA2; (3) RA5b answered with any temperature-controlled or compliance work you have touched.

**SECOND: fit ledger.**

- `hard_gate`: unclear: RB1 (On-site in Utrecht)
- `must_have`: adjacent: RB4 (Run the weekly S&OP meeting), RB7 (Fluent Dutch) · unclear: RB5 (Advanced Excel) · absent: RB2 (3+ years supply or demand planning in FMCG), RB3 (Own the 13-week supply plan), RB6 (SAP IBP or similar planning system)

RB2, RB3, RB6: planning work is not in your history; RB4: a meeting-running bridge, limit named; RB7: conversational, not fluent.

**SECOND: opportunity ledger.** The posting is specific about its mandate (RRB3). Pay is unstated (RRB1), and the employer is not yet verified (RRB2).

- **Hard gates:** none failed; unconfirmed: RB1 (On-site in Utrecht); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would change this:** RB2, RB3 and RB6 would have to be met by planning work you have actually done. Nothing you've told me suggests that.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| FIRST: organization | Duinvaart Cold Chain, Rotterdam, a refrigerated-fleet operator | `[grounded]` JD header |
| FIRST: mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| FIRST: working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| FIRST: scope read | A 2+ year minimum sits below your 4 years, so the level looks like a step across or slightly down, not up | `[inferred]` JD minimum against your stated 4 years |
| FIRST: unknowns | Pay, team size and reporting line, whether route changes are yours to propose or only to support | `[grounded]` JD is silent on each |
| SECOND: organization | Kroonhaven Foods, Utrecht, a chilled ready-meals producer | `[grounded]` JD header |
| SECOND: mandate | Own the 13-week supply plan, balance capacity against forecast, run weekly S&OP | `[grounded]` JD |
| SECOND: working pattern | On-site in Utrecht | `[grounded]` JD |
| SECOND: scope read | A role that owns the plan and the S&OP meeting is a planner post, not an analyst post, and its experience bar is 3+ years of planning | `[inferred]` from the JD's own "own" and "run" verbs and its stated requirements |
| Market calibration (both) | Not established: the role-family searches did not run, so there is no pay band for either title. Both pay figures stay unknown, and the upgrade menu names what would close them | `[generic]` no band available; `[grounded]` JD states no pay |
| Contradictions | None found between the two postings and what you told me; the employers' own pages were not checked | `[grounded]` provided text only |

## Evidence map

Your background is typed prose, so it counts as CV-equivalent self-report. That caps confidence at `medium` until you show an artifact.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| RA1 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | none | hard_gate | You have not stated where you live or what commute you accept. Your last role was in Amsterdam, which says nothing about where you live now | `[grounded]` constraint not stated | GA1 |
| RA2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | 4 years as an operations analyst at a parcel carrier. Confirmed and specific, but nothing inspectable yet | `[grounded]` your background | none |
| RA3 | Strong SQL | must_have | direct | medium | none | SQL daily. "Strong" is not graded by the word daily, so expect a technical probe | `[grounded]` your background; `[generic]` that roles like this usually test SQL | offer: a sanitized query or schema description would raise to `high` |
| RA4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including the on-time delivery dashboard depot managers use | `[grounded]` your background | offer: a screenshot or redacted export of that dashboard would raise to `high` |
| RA5a | Track on-time delivery | must_have | direct | medium | none | You built the dashboard depot managers use for exactly this metric | `[grounded]` your background | none |
| RA5b | Track temperature compliance across a refrigerated fleet | must_have | unclear | none | discovery | Nothing you've said touches temperature or cold chain. A parcel carrier may have handled temperature-sensitive parcels, which is unconfirmed | `[grounded]` silence in your background | GA2 |
| RA6 | Work with depot managers on route changes | important | adjacent | medium | discovery | You ran a weekly route-performance review and depot managers use your dashboard. Whether the review led to route changes is not stated | `[grounded]` your background; limit named | GA3 |
| RA7 | Dutch a plus | preferred | adjacent | medium | none | Conversational Dutch fits a "plus", not a requirement. It should be stated as conversational | `[grounded]` your stated level | state it as conversational, never fluent |
| RB1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | You have not stated whether Utrecht works for you | `[grounded]` constraint not stated | GB3 |
| RB2 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You said you have never worked in planning, so nothing direct or adjacent supports it | `[grounded]` your statement | none: carried as a material risk |
| RB3 | Own the 13-week supply plan for chilled ready-meals | must_have | absent | none | capability | Owning a rolling supply plan is planning work, which you have not done | `[grounded]` your statement | none |
| RB4 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly route-performance review. It carried carrier data, not demand and supply trade-offs, which is the limit | `[grounded]` your background; limit named | none |
| RB5 | Advanced Excel | must_have | unclear | none | discovery | SQL and Power BI are the tools you named. Excel is not mentioned either way | `[grounded]` silence in your background | none: SECOND is `no_go` regardless |
| RB6 | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning system appears in your background | `[grounded]` your statement | none |
| RB7 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational is below fluent, and the posting does not say how fluent is measured. A requirement like this is likely screened literally | `[grounded]` your stated level; `[generic]` literal screening | GB1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GA1 | Rotterdam hybrid (RA1) | hard_gate | Your home location and the commute you accept are not stated | A failed term can't be fixed by wording, and it decides whether FIRST is worth the effort | Where you live; whether three office days in Rotterdam works | Nothing to attach | `[grounded]` constraint not given |
| GA2 | Temperature compliance (RA5b) | discovery | Silent on cold chain | A responsibility named in the posting's first sentence | Temperature-sensitive parcels such as pharma, food or flowers; any service-level report with a compliance threshold; exception reports that someone had to explain | A redacted compliance or exception report | `[grounded]` silence; `[generic]` that this is the posting's first-listed duty |
| GA3 | Route changes with depot managers (RA6) | discovery | The review and the dashboard are confirmed, and outcomes are not | Closes the difference between supporting a decision and driving one | A route you proposed changing and a depot manager acted on | A review pack or a before/after on-time chart | `[grounded]` your background |
| GB1 | Fluent Dutch (RB7) | transferability | Conversational Dutch | A language bar is screened early | Conducting meetings or writing in Dutch at work | Not applicable | `[grounded]` your stated level |
| GB2 | Planning experience (RB2, RB3, RB6) | capability | You have not worked in planning | Three absent must-haves | Closure path: a supply-chain analyst or demand-planning-analyst role first, then planning | Not applicable | `[generic]` a typical lateral route; `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RRA1 | Pay not stated | unknown | — | the posting names no pay | May sit below your current pay, or the employer may simply not publish it | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RRA2 | Employer not established | risk_signal | medium | "Operations Analyst — Duinvaart Cold Chain, Rotterdam" | May be too small or new for a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who I would be interviewing with? | unresolved |
| RRA3 | Duties and tools named concretely | positive_signal | — | "build weekly dashboards in Power BI" | Scope is defined and matches your tools | `[grounded]` JD | Which depots and how many routes feed these dashboards? | noted |
| RRB1 | Pay not stated | unknown | — | the posting names no pay | May sit below the market for a planner post | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RRB2 | Employer not established | risk_signal | medium | "Supply Planner — Kroonhaven Foods, Utrecht" | May be too small or new for a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who I would be interviewing with? | unresolved |
| RRB3 | Mandate stated clearly | positive_signal | — | "Own the 13-week supply plan" | Responsibility and ownership are both named | `[grounded]` JD | What authority does the planner hold over production changes? | noted |

## Application plan

Every row is proposed and pending your approval. Each draws only on your own words.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | FIRST: put the on-time delivery dashboard that depot managers use, and the weekly route-performance review you ran, in your CV's top lines, before the tools list | see RA4, RA5a, RA6 | `[grounded]` your background | pending your approval |
| E2 | FIRST: state your Dutch as conversational, never fluent | see RA7 | `[grounded]` your stated level | pending your approval |
| Q1 | FIRST: confirm the posting on Duinvaart's own careers page before applying | see RRA2 | `[grounded]` RRA2 | pending your approval |
| Q2 | FIRST: ask RRA1's pay question early, and RRA3's question in the interview | the register doubles as interview preparation | `[grounded]` register | pending your approval |
| S1 | SECOND: skip it, and put the time into analyst roles in supply chain or operations that use your SQL and Power BI | see RB2, RB3, RB6 | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht chilled ready meals" were refused. They would have settled whether each employer exists as described and the posting is live (RRA2, RRB2) |
| 2. Role-family sweep | unavailable | Searches on operations analyst and supply planner pay in the Netherlands were refused. They would have given the market-calibration band and checked the pay unknowns (RRA1, RRB1) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier and upgrade menu

I can write this up as `tuesday-dossier.md` if you want a copy to keep.

- Permission to search → RRA2 and RRB2 resolve, and the market band fills role reality's calibration row.
- Your location and commute limits → RA1 and RB1 resolve, and may move FIRST to `go` or `no_go`.
- A redacted on-time delivery dashboard screenshot or a sanitized SQL query → RA3 and RA4 rise to `high`.
- A redacted temperature or service-level compliance report, if any exists → RA5b resolves.
- Your CV → presentation gaps can be found, and the edits in E1 and E2 become exact wording.
- The recruiter's stated pay range → RRA1 and RRB1 close.
- A hiring manager's name for either role → role reality's scope read for that role.

## Questions

GA1: Where do you live, and is three days a week in Rotterdam workable for you?
GA2: At the parcel carrier, did you ever report on temperature-sensitive or time-critical parcels, or on any compliance threshold such as a service-level limit? What did you own?
GA3: Did your weekly route-performance review ever lead to a route change that a depot manager acted on? What was yours versus theirs?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.