I'll read the reference files the skill points to before building the assessment.
Now the L1 research: the company, a salary sweep, and the named co-founder's public professional footprint.
**Decision snapshot**

**Yes, worth continuing: take the call. The employer checks out on its own pages (RR1), and the WhatsApp contact is unresolved, not a red flag (RR6). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R7 · unclear: R8 (Pay €52,000–€60,000)
- `must_have`: direct: R1, R2, R3, R5 · adjacent: R4 (Own the booking flow end to end)
- `important`: adjacent: R6 (Being the first designer)

R4: checkout is a stage of the booking flow, not yet shown to be all of it; R6: a bridge, its limit named, because you have never been the only designer.

**Opportunity ledger.** The employer, posting, About page and careers page agree (RR1), and the pay sits inside the survey band (RR2). Open items are the sole-designer scope (RR3), equity terms (RR4), runway (RR5), the WhatsApp channel (RR6) and what the "real project" ask means (RR7).

- **Hard gates:** none failed (R7 `direct`); unconfirmed: R8 (Pay €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The salary band clears your floor (R8).
  2. The call makes the booking-flow scope and design support concrete (R4, R6, RR3).
  3. The equity terms are written out before you weigh them (RR4).
  4. The calendar invite arrives by email from Fernquay's own domain (RR6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, making Kelproster booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` About page, search result |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Pay and terms | €52,000–€60,000 plus 0.5–1% equity; hybrid, two days a week in the Galway office | `[grounded]` posting; careers page matches |
| Reporting line | Works most closely with co-founder Ronan Kehoe; no design lead or design peer named | `[grounded]` posting |
| Hiring manager | Ronan Kehoe is listed as co-founder and CEO, previously product lead at a Galway travel-software company for five years | `[grounded]` professional profile, search result |
| Scope read | You would be the whole design function of a six-person company. First-year outcomes are not stated | `[inferred]` from "first designer" and the absence of stated outcomes |
| Market calibration | A 2026 Ireland survey puts product designers with 3 to 5 years at a median base of €57,000 (interquartile range €51,500 to €62,000). The posting's band sits inside that range, below its upper quartile. This is a band, not Fernquay's offer | `[generic]` survey of 520 designers; `[grounded]` posting for its own figures |
| Unknowns | Equity terms; runway; whether the designer owns anything beyond the booking flow; first-year outcomes | — |
| Contradictions | None between the posting, careers page and About page. The About page adds sailing schools and Scotland. Saoirse's CTO title comes from the WhatsApp message only; the About result I saw names her as a founder | `[grounded]` search results |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company. Your statement is specific, but no document has been inspected | `[grounded]` your stated background | Have the checkout case study ready; inspected, it would raise this to `high` |
| R2 | Strong Figma | must_have | direct | medium | none | "Figma daily" is stated. Depth (component libraries, prototyping) is not | `[grounded]` your stated background | A Figma file walkthrough would raise it |
| R3 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers. The role's research calls are with school owners, who are business operators; a different participant group from travel customers | `[grounded]` your statement; `[inferred]` participant-group difference from the posting | Be ready to say plainly that your sessions were usability testing with customers |
| R4 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned the checkout flow of a booking product. Ownership of other stages, or of the flow as a whole, is not stated | `[grounded]` your statement, posting wording | See G1 |
| R5 | Work directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers; the posting names two engineers | `[grounded]` your statement, posting | none |
| R6 | Being the first designer, with no design peers (implied by "first designer") | important | adjacent | medium | transferability | Squad work and research carry over. Limit: you have never been the only designer, so setting priorities, critique and shared components without peers is not evidenced | `[grounded]` your statement, posting; `[inferred]` what "first designer" implies | See G2 |
| R7 | Hybrid: two days a week in the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year. Whether fixed office days suit you is not stated | `[grounded]` your statement; `[inferred]` that this meets the term | none |
| R8 | Pay €52,000–€60,000 | hard_gate | unclear | none | hard_gate | No pay floor from you yet, so the gate cannot be checked either way. The band itself is in market | `[grounded]` posting; `[generic]` survey band | Question R8 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking-flow ownership (R4, must_have) | discovery | A checkout redesign. Nothing on search, availability, confirmation, changes or refunds, or on who owned the flow | "End to end" is the posting's headline responsibility, so this decides whether R4 stays `adjacent` | Work upstream or downstream of checkout; owning a metric through the flow; deciding what to build, not just how it looked | Before/after screens, a flow map, a conversion or drop-off figure | `[grounded]` your statement; `[generic]` that first-designer interviews probe scope |
| G2 | Working without design peers (R6, important) | transferability | Adjacent evidence: a squad with four engineers and monthly usability sessions. Limit: never the only designer. Strengthener: something you set up yourself | An honest limit reads better in the call than an overclaim | A component library or pattern set you started; a side project or freelance piece where you were the only designer; a process you introduced to your squad | A file or screenshots showing the foundations you set | `[grounded]` your statement; `[inferred]` the strengthener |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting consistent across sources | positive_signal | — | "Six people, based in Galway. Founded 2023 by Ronan Kehoe and Saoirse Doyle" | The company exists as described and the role is live | `[grounded]` About page and careers page search results | Who else on the team will I work with day to day? | noted |
| RR2 | Pay stated and inside the market band | positive_signal | — | "€52,000–€60,000" | Pay is fair for 3 to 5 years' experience, not an outlier | `[grounded]` posting; `[generic]` survey band | Is the band fixed, or does it move with experience? | noted |
| RR3 | Sole designer, scope beyond the booking flow unstated | unknown | — | "You would be our first designer: own the booking flow end to end" | Brand, marketing pages or a design system may also land on the designer | `[inferred]` from "first designer" against the posting's silence on other duties | Beyond the booking flow, what else would the designer own, and who gives design feedback? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "0.5–1% equity" | Vesting, share type and company valuation are not given. The About page describes a customer-funded company, so there may be no priced round to value the shares | `[grounded]` posting and About page; `[inferred]` no priced round | What is the vesting schedule, what type of equity is it, and what share count is the percentage measured against? | unresolved |
| RR5 | Runway unstated | unknown | — | "funded by its customers" | Revenue for booking software sold to outdoor schools is probably seasonal, so cash cover for a seventh salary is worth asking about | `[inferred]` from the customer type | Is the company break-even today, and how many months of cash cover this hire? | unresolved |
| RR6 | First contact by WhatsApp | unknown | — | "I have emailed you a calendar invite with the video link" | Scheduling by chat for an interview held on video is not a warning sign by itself. The message names a co-founder the company's own pages list. The number may have come from your application; I can't tell | `[inferred]` from the message text; `[grounded]` About page lists Ronan | Can you confirm the invite will come from a Fernquay address, and who will be on the call? | unresolved |
| RR7 | "Real project" ask | unknown | — | "we would rather see one messy real project than a polished deck" | Probably means existing work, as the careers page says "Apply with one real project" | `[inferred]` from the posting and careers page | Is the project one I walk you through, or will there be a new exercise, and would it be paid? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check the invite email comes from the same domain as Fernquay's careers page address | see RR6 | `[grounded]` careers page | pending your approval |
| A2 | Lead the walkthrough with your checkout redesign and monthly usability sessions, e.g. "I redesigned the checkout flow at a Dublin travel-booking company and ran monthly usability sessions with customers." Say plainly you have not been the only designer, then point to working in a squad with four engineers | see R3, R4, R6 | `[grounded]` your own statements | pending your approval |
| A3 | Ask RR3, RR4, RR5 and RR7's questions verbatim in the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | Compare this offer on cash salary alone until the equity terms are written down | see RR4 | `[generic]` how early-stage equity is usually weighed | pending your approval |

`resume_edits_pending_approval`: none proposed, because no CV was provided.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" (returned "About Fernquay", fernquay.example/about) and "Fernquay product designer job Galway" (returned "Product Designer — Fernquay careers", fernquay.example/careers/product-designer). Only the search results were read, not the pages themselves. Role reality: organization and contradictions rows; RR1. The employer is established, so no failed-attribution entry |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup first designer equity 2026" (returned "Tillerby 2026 Ireland Design Salary Report", tillerby.example/2026-ireland-design-salary-report). Market calibration; RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder" (returned "Ronan Kehoe — Co-founder, Fernquay", linkedin.example/in/ronan-kehoe). Role reality: hiring manager row. Professional role and career pattern only |

I can offer to save this as `tuesday-dossier.md` if you'd like it for later.

## Upgrade menu

- Your CV, or the checkout case study as a link or PDF with its before/after screens → R1, R3 and R4 can move toward `high`, and CV edits can be proposed.
- A Figma file walkthrough or screenshots → R2 firms up.
- Your pay floor → R8 resolves.
- Answers to G1 and G2 → R4 and R6 can be re-rated.
- Fernquay's answers on equity and runway → RR4 and RR5 close.
- A deeper research pass on Fernquay (leadership and funding, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.
- Rehearsing the 45-minute call is the mock-interview skill's job; I have not attempted it here.

**Questions**

1. R8: What is the lowest salary you would accept for this role?
2. G1: Beyond the checkout redesign, which other parts of the booking journey did you personally own, and what changed as a result?
3. G2: Have you ever set something up without design peers, such as a component library, a process, or a project where you were the only designer, even informally?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.