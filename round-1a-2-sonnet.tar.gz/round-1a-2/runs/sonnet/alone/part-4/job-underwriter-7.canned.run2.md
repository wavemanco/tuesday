I've read the skill's reference files, and next I'm checking whether Calderbrook is a real employer and what the pay band should be. After that I'll write the assessment.
## Decision snapshot

**Yes, this one is worth applying for. Status: `conditional_go`.** R4 and R5 are `adjacent` rather than `direct`, and R9 is unverified.

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R6, R7, R8 · adjacent: R4 (home-based nursing of housebound adults), R5 (own caseload) · unclear: R9 (clear, timely records)
- `important` — unclear: R10 (leg-ulcer care), R11 (continence care beyond catheters), R12 (end-of-life visits), R13 (care planning)
- `preferred` — absent: R14 (Doppler assessment)

R4, R5 — the home-visiting bridge is real, its limit named; R9 — your CV is silent on records; R14 — desirable only.

**Opportunity ledger.** The employer is attributable (RR1), the posted pay sits in the surveyed band (RR3), and the caseload is small and supervised (RR4). Unknown: whether the posting is live on Calderbrook's own site (RR2), hours and out-of-hours cover (RR5), and whether Doppler training is provided (RR6).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed on Calderbrook's own channel (RR2); (2) the discharge-to-assess visiting is framed as adjacent and never as caseload experience (R4, R5); (3) R9 is answered, since the JD calls clear, timely records essential.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a CIC running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract, founded 2015, 410 staff, four locality hubs | `[grounded]` About page, via search result |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record | `[grounded]` JD |
| Caseload and support | A small caseload of your own, supported by a senior community nurse | `[grounded]` JD |
| Working pattern | Car-based home visits; pool cars provided. Hours, rota and out-of-hours cover are not stated | `[grounded]` JD; silence on hours is `[inferred]` from the JD text |
| Scope read | A first-step community post: one year of post-registration experience is the essential minimum and the caseload is supervised | `[inferred]` from those three JD terms |
| Market calibration | A 2026 survey puts Band 5 community staff nurses at a median of £34,300, interquartile range £32,400 to £36,600. The posted £31,050–£37,800 spans that range. Survey respondents are a sample, not this employer's offer | `[generic]` Wardround 2026 survey; `[grounded]` JD for the posted figure |
| Team lead footprint | Rhiannon Mabbott has led the Halifax district nursing team after eleven years as a district nurse, and spoke at a 2025 forum on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page |
| Unknowns | Caseload size, hours and on-call, induction and Doppler training, whether the posting is live on the employer's site | — |
| Contradictions | None between the JD and the About page. The careers page was not reached (RR2) | `[grounded]` About page; fetch of the careers address returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state active registration as a Registered Nurse (Adult), with revalidation due March 2028. That is self-reported and I have not checked it, so `medium` | `[grounded]` CV | You check your status on the NMC register before applying; none otherwise |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full UK licence, category B. Self-reported, `medium`. The JD says pool cars are provided | `[grounded]` CV, JD | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. A length requirement is graded as ordinary evidence, not a gate | `[grounded]` CV | none |
| R4 | Nursing housebound adults in their own homes | must_have | adjacent | medium | transferability | Credible bridge: 18 months seconded to a discharge-to-assess team, visiting patients at home in their first week after discharge. Limit: short post-discharge visits, not ongoing district nursing of housebound adults | `[grounded]` CV; the limit is `[inferred]` from the JD's housebound, ongoing-care wording | See G1 |
| R5 | Holding a small caseload of your own | must_have | adjacent | low | transferability | You state you have never held your own caseload. Nearest evidence is the home visiting in R4. Whether you planned your own visit list is unknown, so I take the lower band | `[grounded]` your statement; `[inferred]` that the D2A visits are the nearest evidence | See G1 |
| R6 | Wound care | must_have | direct | medium | none | CV states wound care including pressure ulcers and surgical wounds. Leg ulcers are a separate row (R10) | `[grounded]` CV | none |
| R7 | Catheter care | must_have | direct | medium | none | CV states catheter care. Wider continence care is a separate row (R11) | `[grounded]` CV | none |
| R8 | Insulin administration | must_have | direct | medium | none | CV states insulin administration. Care planning is a separate row (R13) | `[grounded]` CV | none |
| R9 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | The CV is silent on record-keeping and on which system you use. A ward role involves records, but that is a pattern and not evidence of yours | `[grounded]` CV silence; `[generic]` that ward roles involve records | See G4 |
| R10 | Leg-ulcer care | important | unclear | low | discovery | The CV names pressure ulcers and surgical wounds only; leg ulcers are not mentioned | `[grounded]` CV silence | See G2 |
| R11 | Continence care beyond catheters | important | unclear | low | discovery | The CV names catheter care only | `[grounded]` CV silence | Carried; not asked this turn |
| R12 | End-of-life visits | important | unclear | low | discovery | The CV does not mention end-of-life care | `[grounded]` CV silence | Carried; not asked this turn |
| R13 | Care planning | important | unclear | low | discovery | The CV does not mention care planning | `[grounded]` CV silence | Carried; not asked this turn |
| R14 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You state you have never done one. The JD marks it desirable. Closure path: the team lead's public talk on Doppler training for staff new to community work suggests it may be taught on the job, but that is unconfirmed (RR6) | `[grounded]` your statement, JD; `[inferred]` the training route | Ask about training at the informal chat |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own caseload and home-based care (R4 and R5, must_have) | transferability | Home visits in the first week after discharge are confirmed. Who set your visit list, and what you decided alone at the door, is not | These are the two `adjacent` must-haves, and the role is built around a caseload | Planning your own day's visits; making escalation or care-change decisions alone; reviewing the same patients across several visits | A discharge-to-assess role description, a rota or visit-list example (anonymised) | `[grounded]` CV and your statement; `[generic]` that these are the likeliest points an interviewer tests |
| G2 | Leg-ulcer care (R10, important) | discovery | Pressure-ulcer and surgical-wound care are stated; leg ulcers are not | The role names leg-ulcer care, and Doppler is desirable on top of it | Applying compression bandaging, even supervised; assessing a patient with a venous ulcer; a leg-ulcer clinic placement | A competency sign-off, a training record | `[grounded]` CV silence |
| G4 | Records and the electronic patient record (R9, must_have) | discovery | Nothing on record-keeping or systems | It is an essential requirement and the only `unclear` must-have | Which system you use; documenting a visit the same day; a record audit | An audit result or competency record (no patient information) | `[grounded]` CV silence |
| G5 | End-of-life, continence and care planning (R11, R12, R13, important) | discovery | The CV is silent on all three | Each is named in the JD's duties | Caring for dying patients on the ward; bladder or bowel care beyond catheters; writing or updating care plans | A training record or reflective account | `[grounded]` CV silence |
| G6 | Doppler assessment (R14, preferred) | capability | You have none and say so | Desirable only; carried as a minor gap | Training offered on appointment | None to attach | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer attributable | positive_signal | — | "Calderbrook Community Health CIC, Halifax" | A real community interest company with an NHS contract, matching the posting | `[grounded]` About page and the forum speaker page naming the Halifax team | Who would I be interviewing with, and is the team lead the hiring manager? | noted |
| RR2 | Posting not confirmed on the employer's own site | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The careers address I tried returned no page. That address was my guess, so it shows nothing about the posting | `[grounded]` fetch returned no page; the reading is `[inferred]` | Is this post currently open, and what is the closing date? | unresolved |
| RR3 | Posted pay is stated and sits within the surveyed band | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The offer is in line with what staff in this role family report | `[grounded]` JD; `[generic]` survey band | Where on the range would a nurse with my experience start? | noted |
| RR4 | Supported small caseload | positive_signal | — | "hold a small caseload of your own, supported by a senior community nurse" | Responsibility comes with named support | `[grounded]` JD | How much supervision is there in the first months, and how big is a typical caseload? | noted |
| RR5 | Hours, rota and out-of-hours cover not stated | unknown | — | "end-of-life visits" | End-of-life visits may involve evening or weekend work | `[inferred]` from the JD duty against its silence on hours | What is the working pattern, and is there an on-call or weekend rota? | unresolved |
| RR6 | Doppler training not stated | unknown | — | "Desirable: Doppler assessment for leg ulcers." | The team may train staff new to community work in Doppler | `[grounded]` the team lead's forum talk; `[inferred]` that it applies to this team | Is Doppler training provided to new starters, and when? | unresolved |

## Application plan

Everything below, the edits and the advice alike, is proposed and pending your approval. Nothing is final until you say so.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your experience entry with the secondment, in your own words: "Seconded for 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge" | See R4 | `[grounded]` CV | resume_edits_pending_approval |
| E2 | List wound care (pressure ulcers and surgical wounds), catheter care and insulin administration as you stated them, with nothing added | See R6, R7, R8 | `[grounded]` CV | resume_edits_pending_approval |
| A1 | Take the informal chat with Rhiannon Mabbott before applying. Ask the questions in RR2, RR5 and RR6 | The JD invites it | `[grounded]` JD | pending your approval |
| A2 | Say plainly that you have visited patients at home but have not held your own caseload, and that you want to build that with support | See R5 | `[grounded]` your statement | pending your approval |
| A3 | Confirm the posting is open on Calderbrook's own channel and note the closing date | See RR2 | `[grounded]` RR2 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). The fetch of calderbrookhealth.example/careers returned no page. Moved role reality's organization row and RR1, and added RR2 |
| 2. Role-family sweep | yes | Searched "Community Staff Nurse Band 5 district nursing salary £31,050 £37,800 Agenda for Change pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook Community Health", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved the team lead footprint row, R14 and RR6 |

You included your National Insurance number. It isn't needed for this assessment and I haven't used it. Your NMC and licence details are taken as you stated them and checked against nothing.

Say the word and I'll write this up as `tuesday-dossier.md`.

## Upgrade menu

- Your answer to G1 → R4 and R5 may firm up, and the framing in A2 gets concrete.
- Your answer to G4 → R9 closes or becomes a named gap.
- Your answer to G2 → R10 resolves, and R14's closure path gets clearer.
- A competency record or sanitised audit result → R6, R7, R8 or R9 could rise to `high`.
- Your minimum salary, hours and any non-negotiables → the hard-gate checks against you become real, since they are currently unknown.
- A link to the live posting on Calderbrook's own site → RR2 closes.
- A deeper research pass on Calderbrook (contract and service news, staff reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

G1 — In the discharge-to-assess role, who set your visit list, and what did you decide yourself at the patient's home, such as changing care or escalating, as against handing it on?
G4 — Which electronic patient record do you use, and do you write up your own visits on the day?
G2 — Have you applied compression bandaging or assessed a leg ulcer, supervised or not? What was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.