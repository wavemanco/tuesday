## Decision snapshot

**Decision: `no_go`. Don't send anything, and stop engaging with @VellowayHiring.** This is a scam, not a borderline posting. [inferred] from the pattern of the messages, since I ran no searches.

- **Hard gates:** the role's terms fail your stated need of €30,000 a year. At "up to" €26/hr and 15–30 hrs/week, the posting only reaches that figure at the top of both ranges. That is secondary, because the role itself is not real.
- **Candidate fit:** your background matches the posting's requirements well, so you are not unqualified.
  - Strong match: attention to detail (60 Zendesk tickets a day) and spreadsheets (your weekly Excel tracker).
  - Probable match: written English, in a customer-facing role.
  - Training others is a bonus the posting never asked for.
- **Opportunity quality:** fails. Fit and opportunity are separate ledgers, and a good fit doesn't rescue a fraudulent employer.

## Role reality [inferred]

The job is just the bait. The messages show three well-known fraud mechanisms stacked together:

1. **Identity theft.** They asked for your IBAN, PPS number and a passport photo before any interview. A real employer collects these after a signed contract, through a payroll system, never over Telegram chat. With those three items, someone can open accounts or take loans in your name.
2. **Advance-fee scam.** The €349 "equipment" payment is the fee. Real employers don't charge you for equipment, and the "refund with your first wages" never happens.
3. **Fake-cheque scam.** This is the most dangerous part. They will send you a cheque for €2,850, ask you to keep €350 and send on the rest, about €2,500. The cheque will bounce days or weeks later, after the bank has already let you spend the money. The bank then claws back the full amount from you. You would be out about €2,500 of your own money. You could also be investigated for laundering, because you moved money for strangers. The €350 "welcome bonus" exists to make you feel paid.

Other signs, each [grounded] in the text you pasted:
- No call or video interview, and the whole process runs on Telegram.
- You "passed screening" and then got the job without any real assessment.
- The "company" is only a Telegram handle, a free-looking email domain (`postmail.example`) and a cheque.
- Typical posting bait: no experience needed, work from home, set your own hours.

## Evidence map (summary)

| # | Priority | Fit | Requirement |
|---|---|---|---|
| 1 | must-have | strong | Attention to detail (60 tickets/day) |
| 2 | must-have | strong | Spreadsheets (weekly Excel tracker) |
| 3 | must-have | adjacent | Good written English (customer service role; not formally evidenced) |
| 4 | hard gate | gap | €30k/year (reached only at the top of "up to" figures) |
| 5 | hard gate | fail | Legitimate, verifiable employer (the evidence points against it) |

## What to do now

1. **Send nothing:** no IBAN, PPS number, passport photo, €349 or cheque proceeds. Don't paste your IBAN anywhere.
2. **Don't lodge or act on any cheque** they post. If one arrives, you can ignore it, or take it to your bank unlodged and tell them what it is.
3. **If you've already shared something,** tell me. You haven't, which is the best outcome. Keep it that way.
4. **Stop replying and block the handle,** after screenshotting the chat and the posting.
5. **Report it.**
   - Garda National Economic Crime Bureau, or your local Garda station.
   - Report the Telegram account inside Telegram.
   - Report the posting to the jobs site, so others don't get caught.
   - Your bank's fraud line, if you've shared anything.
6. **Consider** monitoring your credit record through the Central Credit Register if you ever do send ID details.

## Where you stand

You did the right thing by asking before sending. Your real profile (courier customer service, Zendesk, Excel tracking, training new starters) fits genuine roles such as order processing, customer operations, logistics coordinator or support team lead. Many pay €30k+ in Ireland. Look for postings that:
- name a verifiable company with a real website and a careers page,
- hold at least one live interview,
- never charge you money,
- never ask for ID before a signed contract.

## Evidence status

Research tier: L0 — no searches

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | skipped | The pattern is conclusive on its own. Searching was not needed to reach `no_go`. |
| 2 | Role-family sweep | skipped | Same reason. |
| 3 | Hiring manager footprint | n/a | No name was given. |

I'm happy to write you a full dossier (`tuesday-dossier.md`) of this assessment if you want one for your records.

**Upgrade menu:** a link to the original posting, or the jobs site's name, would let me check whether it appears in public scam reports. A real CV would let me map you to genuine roles properly.

**Questions:**
1. (Row 5) Did you already send anything, including your name, phone number or any document, to that handle?
2. (Row 4) Are you set on remote work, or open to hybrid and on-site roles in logistics? That changes which real roles I'd point you at.

You can answer briefly, say "skip", or ask me to start searching for genuine roles.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.