Checking what the searches found, then the full assessment.

## Decision snapshot

**Not worth applying to, and don't send anything. Status: `no_go`.** The reason is on the opportunity side: three severe red flags (RR2, RR3, RR4) that match a known fake-job fraud pattern. It isn't a fit problem. You're well qualified for the work as described.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Pay of at least €30,000 a year)
- `must_have`: direct: R2, R3, R4 (Attention to detail; Spreadsheets; Written English)
- `important`: unclear: R5 (A quiet place to work)

**Opportunity ledger.** The employer can't be found, and the process asks for money and identity documents instead of an interview. It has an advance fee (RR2), a cheque-then-transfer request (RR3) and an identity and bank-detail grab (RR4). One entry is unverified rather than damning: the pay is vague (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year). The role's terms don't settle it.
- **Severe red flags:** RR2, RR3, RR4.
- **Conditions for go:** none. The only route back is a verified employer that drops every payment and document request, and nothing here points that way.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics": no website, careers page or company record found | `[grounded]` two searches, nothing returned; employer not established |
| Role | Remote order processing, 15–30 hrs a week, up to €26/hr plus unspecified commission | `[grounded]` posting |
| Pay arithmetic | 15 hrs × €26 × 52 ≈ €20,300 a year; 30 hrs × €26 × 52 ≈ €40,600. This is the ceiling, since the posting says "up to" | `[inferred]` from the posting's figures |
| Process | Telegram only, no calls or video. A real interview isn't needed to be "hired" | `[grounded]` posting and messages |
| Market calibration | Genuine order-processing and customer-operations roles for someone with your background usually interview by phone or video, and pay by contract with a named employer. I couldn't confirm a pay band for this title | `[generic]` role-family pattern, not searched successfully |
| Unknowns | Who the company is, who "@VellowayHiring" is, who the "equipment partner" is | — |
| Contradictions | The posting says no calls. The messages then skip the chat interview you took and ask for passport, PPS number and IBAN first, and the "job" is offered before any real assessment | `[grounded]` posting against messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your constraint. The posting's range runs from about €20,300 to €40,600 a year depending on hours, so it may or may not meet the floor. It's moot given RR2–RR4 | `[grounded]` your constraint and the posting; `[inferred]` arithmetic | none: the role is `no_go` anyway |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day for three years is a sustained accuracy task. It's your own account and nothing is inspectable yet, hence `medium` | `[grounded]` your background | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. It's specific, but a self-report | `[grounded]` your background | none |
| R4 | Good written English | must_have | direct | medium | none | Daily written customer replies, plus training two new starters, is regular written-communication work | `[grounded]` your background | none |
| R5 | A quiet place to work | important | unclear | low | discovery | Your situation wasn't stated | `[grounded]` silence in your message | none: not worth chasing for this role |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor vs. a real role (R1) | discovery | Posting range straddles your €30,000 floor and the commission is unspecified | It would matter only for a verified employer; for real roles it becomes the first thing to check | Not applicable | A written offer or contract stating base pay | `[inferred]` arithmetic from the posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer can't be found | unknown | — | "Velloway Logistics" | The company may not exist as described. Two searches found nothing, which is weaker evidence than a positive match | `[grounded]` search returned nothing; `[inferred]` that this raises risk | Is there a registered company, website or careers page you can reach independently of Telegram? | unresolved |
| RR2 | You are asked to pay the employer | red_flag | severe | "Please pay €349 by bank transfer to our equipment partner" | An advance-fee scam: real employers don't charge candidates for equipment, and "refunded with first wages" never arrives | `[generic]` well-documented job-scam pattern | Why would an employer need payment before a contract exists? | resolved by your decision not to pay |
| RR3 | Cheque to lodge, then transfer most of it on | red_flag | severe | "We are posting you a cheque for €2,850… keep €350… transfer the rest" | A fake-cheque scheme. The cheque can be lodged and look fine, then be returned as fraudulent days or weeks later. The money you transferred is yours, not theirs, so the loss lands on you, and you may be pulled into laundering | `[generic]` fake-cheque pattern; `[inferred]` that this is its application here | Why would a payroll process route money through a new hire's account to a third party? | resolved by your decision not to lodge it |
| RR4 | Passport, PPS number and IBAN requested before any real interview | red_flag | severe | "send your IBAN, your PPS number and a clear photo of your passport" | Identity theft and mule-account recruitment. A passport photo, PPS number and bank details together are enough to open accounts or loans in your name | `[generic]` identity-harvesting pattern | Is this information collected only after a signed contract, through an HR system? | resolved by your decision not to send |
| RR5 | Telegram-only hiring, free-mail style contact address, a "pass" with no real interview | risk_signal | high | "Our whole hiring process runs on Telegram" | Consistent with RR2–RR4; legitimate employers can use messaging apps but not in place of any verifiable process | `[generic]` role-family pattern | Can the recruiter name a company contact on the company's own domain? | unresolved |
| RR6 | Pay vague: "up to €26", commission unspecified, "no experience needed" | unknown | — | "Earn up to €26 an hour plus commission" | The figure is a lure; real entry-level order-processing roles usually quote a fixed base | `[generic]` role-family pattern; `[grounded]` the posting's wording | What is the guaranteed hourly base and weekly hours in writing? | unresolved |

## Application plan

Every row is proposed and waits on your approval, and that covers the prose here as well as the table.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing further: no IBAN, no PPS, no passport photo, no €349 | RR2, RR4 | `[grounded]` register | pending your approval |
| A2 | If a cheque arrives, don't lodge it and don't transfer any money | RR3 | `[grounded]` register | pending your approval |
| A3 | Stop replying and block the account. Report the posting to the jobs site and the Telegram account to Telegram. Consider reporting to An Garda Síochána, and tell your bank if any of your details were shared beyond the IBAN | Protects other applicants and you | `[generic]` standard response to job fraud | pending your approval |
| A4 | Redirect to roles you do fit: customer-service team lead, support specialist, or logistics or courier operations coordinator, found through the employer's own careers page or an agency you can verify | Your background maps well to these, and they more often reach €30,000 | `[generic]` role-family pattern | pending your approval |
| E1 | For real applications, CV lines drawn only from what you told me: about 60 Zendesk tickets a day over three years, trained two new starters, keeps the team's weekly tracker in Excel. Anything added beyond that needs your sign-off | Evidence you stated, nothing inflated | `[grounded]` your background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics order processing coordinator careers": no results. Employer not established, which feeds RR1. No page was fetched because none was returned |
| 2. Role-family sweep | unavailable | Searched "remote order processing job Telegram cheque lodge transfer equipment fee scam Ireland": no results, so market calibration and the scam-pattern rows are `[generic]` only |
| 3. Hiring manager's public footprint | n/a | No hiring manager was named, only a Telegram handle, so there was nothing to research |

## Dossier offer

I can save all of this as a `tuesday-dossier.md` if you want it.

## Upgrade menu

- The jobs site's name and the posting's link: confirms whether the posting is live and consistent, and lets you report it.
- A company registration number or website from Velloway: RR1 would close or harden.
- A deeper research pass on the company and handle (public reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.
- Your region and target hours: lets me redirect you to real roles against your €30,000 floor.

## Questions

1. **RR2–RR4:** apart from the interview answers, have you given them anything personal: full name, address, date of birth, phone number, or any payment? If you've paid or sent anything, tell me what and when, and I'll adjust the steps.
2. **RR1:** which jobs site was it, and do you have the posting link?
3. **G1:** do you want me to underwrite a real role against your €30,000 floor? If so, paste one.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.