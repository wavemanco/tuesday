**Not worth applying to, and don't send anything. Status: `no_go`.** This has the shape of an advance-fee and fake-cheque scam, and it is also an identity-theft setup.

**Fit ledger.**

- `hard_gate`: unclear: R1 (income of at least €30,000 a year)
- `must_have`: direct: R2 (attention to detail), R3 (spreadsheets), R4 (written English)
- `important`: unclear: R5 (a quiet place to work)
- `preferred`: none stated

R2 to R4 rest on your CV and your own account, so they are leads and not yet verified evidence. The fit is real, but it is not what decides this.

**Opportunity ledger.** Three severe red flags: ID and bank details before any real interview (RR1), a payment demanded from you (RR2), and a cheque you would lodge and then forward money from (RR3). The employer cannot be verified, and every contact runs through Telegram and one webmail address (RR4). Nothing in the opportunity points the other way.

- **Hard gates:** none failed; unconfirmed: R1 (income of at least €30,000 a year).
- **Severe red flags:** RR1, RR2, RR3.
- **Conditions for go:** none. No wording or fit can fix a role that asks the candidate to pay.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics". Not checked. Nothing provided shows a company site, address or registration | `[grounded]` posting and messages give none |
| Role | Remote order processing, 15–30 h a week, "up to €26" an hour plus commission | `[grounded]` posting |
| Process | Telegram only, no calls or video. "Interview" in chat, then "passed" | `[grounded]` messages |
| Scope read | The duties are never described. The posting is a list of easy requirements with high, uncapped-sounding pay | `[inferred]` from the posting's silence on tasks |
| Market calibration | Not given. I ran no search, so I can't quote a pay band | `[generic]` |
| Unknowns | Legal entity, address, who "payroll" and the "equipment partner" are, what the job actually involves | n/a |
| Contradictions | The posting says no experience is needed, yet the "interview" tells you that you passed with no assessment. It promises training and "set your own hours", yet asks you to buy a laptop and headset first | `[grounded]` posting against messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Your floor: €30,000 a year or more | hard_gate | unclear | medium | hard_gate | At the top rate of €26, reaching €30k needs about 22 h a week. "Up to", the variable hours and the commission mean it isn't assured. The role may not exist at all, so the figure is moot | `[inferred]` arithmetic on the posting's own figures | Moot if the role is not pursued |
| R2 | Attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day and a team tracker you maintain | `[grounded]` your account | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep the weekly Excel tracker | `[grounded]` your account | none |
| R4 | Good written English | must_have | direct | medium | none | Three years of written ticket handling | `[grounded]` your account | none |
| R5 | A quiet place to work | important | unclear | low | discovery | You haven't said | `[grounded]` silence in your message | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Quiet workspace (R5) | discovery | Not stated | Only matters for a real remote role | Your current working setup | None needed now | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | IBAN, PPS number and passport photo requested straight after a "first screening" | red_flag | severe | "send your IBAN, your PPS number and a clear photo of your passport" | Collecting identity documents so they can be used to open accounts or take credit in your name. A genuine employer asks for these after a signed contract, through its own HR system | `[generic]` common pattern in job scams; `[inferred]` from the timing | Can they name a registered company, address and signed contract before asking for ID? | unresolved |
| RR2 | You pay €349 for equipment, to a third party | red_flag | severe | "Please pay €349 by bank transfer to our equipment partner" | A legitimate employer supplies equipment or reimburses against receipts. A refund promise is the usual bait in these scams | `[generic]` | Why can't the employer supply equipment or reimburse against a receipt? | unresolved |
| RR3 | Cheque of €2,850 to lodge, keep €350, send on the rest | red_flag | severe | "keep €350 as a welcome bonus and transfer the rest to our equipment partner" | The cheque is fake or will be recalled. The bank can reverse it weeks after the funds appear, and you would owe the money you sent. Forwarding funds can also make you an unwitting money mule | `[generic]` classic overpayment pattern | None worth asking. Payroll never sends an unrequested cheque and asks for part of it back | unresolved |
| RR4 | Entity unverifiable, Telegram-only contact, a generic webmail address for "HR" | risk_signal | high | "no calls or video interviews"; "velloway.hr@postmail.example" | The recruiter may not be tied to any real company. The address is a free mail domain, not a company domain | `[inferred]` from the contact details given; company existence not checked | Is there a company website, with a careers page that lists this post? | unresolved |
| RR5 | Pay and ease out of line with the work | risk_signal | medium | "up to €26 an hour… No experience needed" | High pay for a no-experience role is bait. I have no pay band to measure it against | `[inferred]` from the posting alone | What are the actual duties and the basic hourly rate, in a written contract? | unresolved |

## Application plan

Do not apply. The plan below is to protect yourself.

1. **Send nothing.** No passport photo, no PPS number, no further answers. Your IBAN is not a secret in itself, but don't give it to this contact. It is how a fraudster routes money through your account. `[generic]`
2. **Don't lodge the cheque** if it arrives, and don't transfer or pay anything. A cleared-looking balance is not a cleared cheque. `[generic]`
3. **Stop replying.** Block @VellowayHiring and keep the chat as it is. Screenshot the posting, the Telegram thread and the email address first.
4. **Report it.** Report it to the jobs site, to Telegram, and to An Garda Síochána. Tell your bank if any of your details were shared. `[generic]` These are the usual routes.
5. **If you already sent anything** beyond what you've described, tell your bank straight away. If your PPS number or passport went, ask your bank and the relevant agencies what protection they can put in place.
6. **No CV edits are proposed**, so nothing awaits your approval. Your background (courier customer service, ticket volume, Excel tracking, training starters) is a good base for real order-processing, dispatch or customer-operations roles, which pay at your level without charging you.

## Evidence status

Research tier: L0, no searches

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | skipped | No search was run. This assessment rests on your pasted posting and messages |
| 2 | Role-family sweep | skipped | No search was run, so there is no market calibration |
| 3 | Hiring manager's public footprint | n/a | No hiring manager was named, only a Telegram handle |

The decision doesn't depend on research, because the red flags are in the messages themselves.

I can write up the full assessment as `tuesday-dossier.md` if you want a record to keep or send to the bank.

**Upgrade menu.**

- A link to the original posting, and the site you found it on, would let me check whether the listing is still live and who posted it.
- Optional research, at up to 5 searches and 2 fetches: does a company called Velloway Logistics exist, and have others reported this approach? I'd treat it as confirming what we already know, not as a reason to reopen the offer.
- A copy of the cheque, if it arrives, would let you show your bank what you received.

**Questions.**

1. (RR1) Have you sent anything to this contact besides your answers in the chat? For example a document, a photo, or a transfer.
2. (RR4) Do you want me to run the research above, or leave it?
3. (G1) Would you like help finding real roles that fit your background and the €30,000 floor? I'd start from your Zendesk and Excel experience.

Answer as briefly as you like, or reply "skip" to any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.