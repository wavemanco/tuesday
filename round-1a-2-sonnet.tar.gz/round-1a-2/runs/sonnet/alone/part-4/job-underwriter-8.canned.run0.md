I'll read the skill's reference files before building the assessment.
Compound commands need approval, so I'll read the files directly.
**No, don't go ahead. I can't establish the firm from here, and three requests in these messages (RR1, RR2, RR3) are very likely a scam. Pay nothing, lodge nothing and send nothing. · `no_go`**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Pay of at least €30,000 a year)
- `must_have`: direct: R3, R4 · adjacent: R2 (Strong attention to detail)

R1: the posting's "up to" rate doesn't settle your pay floor; R2: adjacent, no artifact; R3 (`medium`): your Excel tracker, no inspectable file.

**Opportunity ledger.** The messages ask you to pay for equipment (RR1), lodge a cheque and pass money on (RR2), and hand over bank and ID details before any offer (RR3). The hiring process runs only on Telegram (RR4), the employer can't be established (RR5), and contact moves to a free-mail style address (RR6). Pay terms are thin (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** the payment, cheque and bank/ID requests would have to go. The employer would also have to be confirmed through its own website, with a written offer on its own domain and pay guaranteed at €30,000 or more (R1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics can't be established from here. Two searches returned no results ("Velloway Logistics"; "Velloway Logistics remote order processing coordinator careers"). That shows no web presence I could find, not that none exists | `[grounded]` searches, no results |
| Mandate | Remote order processing, 15–30 hours a week, "full training provided" | `[grounded]` posting |
| Pay | "Up to €26 an hour plus commission". No base rate, commission rate or contract type is stated | `[grounded]` posting |
| Hiring process | Telegram only, "no calls or video interviews" | `[grounded]` posting |
| Contradictions | The posting lists no equipment cost, but the chat adds a €349 laptop and headset payment. The messages ask for bank and ID details before any offer. The "offer" then arrives with a cheque | `[grounded]` posting against the messages you pasted |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median €31,200, interquartile range €28,400–€34,100. This is the pay guide's salaried-only figure, so it's a loose comparison for hourly-plus-commission work. It is never this employer's offer | `[generic]` role-family sweep, "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide) |
| Unknowns | Contract type, guaranteed hours, commission rate, who the hiring manager is, first-90-day outcomes | `[grounded]` posting silent on each |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your non-negotiable) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is unclear because the posting gives only an "up to" rate. At €26 an hour and 52 paid weeks, 15 hours is €20,280 and 30 hours is €40,560, and the second figure holds only if every hour is paid at the maximum | `[grounded]` your statement and the posting; `[inferred]` arithmetic | Written guaranteed rate and hours from an employer found independently |
| R2 | Strong attention to detail | must_have | adjacent | medium | discovery | You described about 60 tickets a day in Zendesk and a weekly team tracker. That suggests accuracy but doesn't show an error rate | `[grounded]` your background in your message; `[inferred]` the accuracy link | See G1 |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. It's your own account with no file to inspect, so it stays at `medium` | `[grounded]` your background in your message | none |
| R4 | Good written English | must_have | direct | medium | none | Your Zendesk ticket work and your training of two new starters point to everyday written use | `[grounded]` your background; `[inferred]` that ticket replies are written | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Attention to detail (R2, must_have) | discovery | Volume and tracker work, but no measure of accuracy | Matters for a real order-processing role, not for this one, which can't be verified | Ticket quality scores, error corrections you caught, checks you built into the tracker | A QA score, a manager comment, a tracker screenshot with customer data removed | `[grounded]` background silent on accuracy measures |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment for equipment demanded | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | This request is very likely a scam. Who sent it, and whether the named employer is involved, is unresolved | `[grounded]` the message asks it of you | Please confirm in writing, from an address on your company's own website, that new coordinators are asked to buy equipment before starting. (Ask through contact details you find yourself on that website or careers page, never the chat or the email in these messages.) | confirmed |
| RR2 | Cheque to deposit, with money passed on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | This request is very likely a scam. Don't deposit the cheque. The "rest" is €2,500 of your own money going out, and a cheque can be returned unpaid after it shows in your account | `[grounded]` the quote and its arithmetic; `[generic]` that cheques can be returned after the credit shows | Does your company ask new hires to lodge a company cheque and pass part of it to a third party? Route as RR1 | confirmed |
| RR3 | Bank, tax and ID details before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up." | This asks for the details before any written offer, naming role and pay. The sender's identity is unresolved | `[grounded]` the message and its timing | Which portal on your own website do new hires use for bank and identity details, and after which written offer? Route as RR1 | confirmed |
| RR4 | Hiring runs wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | Interview and offer happen only in chat. This is a sign and takes no verdict. It can be checked by asking for a live call | `[grounded]` the posting says so | Can I have a live video call with a named manager and a written offer from your company address? Route as RR1 | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Remote Order Processing Coordinator — Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or the message may not come from who it names. None of these is more likely than the others | `[generic]` pattern, not a claim about this firm | Can you point me at this role on your own careers site, and who I would interview with? | unresolved |
| RR6 | Contact moves to a free-mail style address | risk_signal | medium | "Any problems, email velloway.hr@postmail.example." | The address may not belong to the employer. This is a sign and takes no verdict | `[inferred]` from the domain being a mail service rather than a company site | Which address on your company's own domain can I confirm this with? | unresolved |
| RR7 | Pay terms thin | unknown | — | "Earn up to €26 an hour plus commission on every order you process" | Guaranteed hours, base rate and commission may fall well below the ceiling | `[inferred]` from "up to" with no floor | What is the guaranteed hourly rate, the commission rate and the contract type? | unresolved |

Hold: pay the €349 to no one, lodge no cheque, and send no IBAN, PPS number or passport photo until the employer is confirmed through its own website. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

Everything here is proposed. Nothing is applied until you approve it, including the advice in prose.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't paste your IBAN, PPS number or passport photo into the chat. I haven't repeated your IBAN here | RR3 | `[grounded]` RR3 | pending your approval |
| A2 | Don't pay €349 or make any transfer to a third party | RR1, RR2 | `[grounded]` RR1, RR2 | pending your approval |
| A3 | If a cheque arrives, don't lodge it. Show it to your bank first | RR2 | `[generic]` cheques can bounce after they credit | pending your approval |
| A4 | Look for the company's own website or careers page yourself and use only the contact details found there | RR5, RR6 | `[grounded]` RR5 | pending your approval |
| A5 | Report the posting to the jobs site, and consider your bank or An Garda Síochána | Others may see the same posting | `[generic]` usual reporting routes | pending your approval |
| A6 | Look for order-processing or customer-operations roles where employer, pay and process can be checked first. Lead with your Zendesk volume and Excel tracker as you've stated them | R2, R3, R4; your €30,000 floor sits close to the market median above | `[grounded]` R2–R4; `[generic]` salary calibration | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics remote order processing coordinator careers". Both returned no results, so the employer is not established. That created RR5 |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator job Ireland salary hourly", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). It moved the market calibration row and RR7 |
| 3. Hiring manager's public footprint | n/a | No name was given, only a chat handle, so there was no query to form |

I can also turn this into a `tuesday-dossier.md` file whenever you want one.

## Upgrade menu

- A link to the live posting, or the jobs site it was on, would let me check what the listing links to (RR5).
- The employer's own careers page, or a written offer from a company-domain address, would resolve RR5 and RR6.
- A written guaranteed rate, hours and contract type would settle R1 and RR7.
- A quality score or QA note would move R2.
- A deeper research pass on this firm (up to 5 more searches and 2 more fetches) will run if you say the word.

## Questions

- **RR5:** Which jobs site was the posting on, and does the listing link to a company website or careers page?
- **RR2:** Has a cheque or any payment details for the "equipment partner" arrived yet?
- **RR3:** Did their chat questions ask for anything personal beyond the IBAN, PPS number and passport photo?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.