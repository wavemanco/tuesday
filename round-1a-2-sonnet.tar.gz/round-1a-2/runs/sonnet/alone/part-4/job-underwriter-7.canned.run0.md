I've read the skill's reference files. Next I'll check the employer and the pay band with a few searches, then write up the assessment.
# Job Underwriting Assessment: Community Staff Nurse, Band 5, Calderbrook Community Health CIC, Halifax

## Decision snapshot

**Yes, this is worth applying for, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R5a, R6a, R7, R9 · adjacent: R5b (Leg-ulcer care) · unclear: R4 (Clear timely written records), R6b (Continence care), R8 (End-of-life visits)
- `important`: adjacent: R11 (Own small caseload) · unclear: R10 (Care planning)
- `preferred`: absent: R12 (Doppler assessment)

R5b: wound-care bridge to leg ulcers, its limit named; R11: ward and home-visit work bridges to a caseload, its limit named; R12: absent, and a preferred row.

**Opportunity ledger.** The employer matches its description (RR1), though the live posting is not confirmed. Pay is stated and sits inside the survey range (RR3), and the senior-nurse support and pool cars are stated (RR4). Caseload size, Doppler training and hours are not stated (RR2, RR5, RR6).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The vacancy is confirmed open (RR1).
  2. In the informal chat, caseload build-up and Doppler training are confirmed as supported (R11, R12, RR2, RR5).
  3. Your answer on end-of-life care shows direct or adjacent experience (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | A community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. Founded 2015, 410 staff, four locality hubs | `[grounded]` About page (calderbrookhealth.example/about) |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration, care planning, on an electronic patient record | `[grounded]` JD |
| Caseload and support | A small caseload of your own, supported by a senior community nurse | `[grounded]` JD |
| Essentials | NMC Adult Nurse registration, full UK driving licence (pool cars provided), at least one year post-registration, clear timely records. Doppler assessment is desirable | `[grounded]` JD |
| Pay | £31,050–£37,800 plus mileage | `[grounded]` JD |
| First 90 days / first year | Not stated | `[grounded]` JD silent |
| Scope read | A standard-scope community staff nurse post: the listed duties are the usual district-nursing mix, with a senior nurse behind the caseload | `[inferred]` from the JD's duty list and stated senior support |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. At the 2025 forum, they spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page (communitynursingforum.example/speakers/rhiannon-mabbott) |
| Market calibration | The posting's range brackets a 2026 survey's median (£34,300) and its interquartile range (£32,400–£36,600) for Band 5 community staff nurses. It is a market pattern, never this employer's offer. The sweep returned pay only, not scope norms | `[generic]` survey (wardround.example/2026-uk-community-nursing-pay-guide); `[grounded]` JD for the posting's figure |
| Unknowns | Caseload size at the start, hours and out-of-hours cover, contract basis, which electronic record system, Doppler training provision, closing date | `[grounded]` JD silent on each |
| Contradictions | None between the JD and the About page. The careers page could not be fetched, so the posting's liveness is unconfirmed | `[grounded]` About page read; careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states Registered Nurse (Adult), registration active, revalidation due March 2028. Self-reported, so `medium` until checked | `[grounded]` CV | none; the public register entry is yours to check before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states a full UK licence, category B. Self-reported | `[grounded]` CV | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. A length-of-experience requirement is not a gate | `[grounded]` CV | none |
| R4 | Clear, timely written records (electronic patient record) | must_have | unclear | low | discovery | CV is silent on documentation and on any electronic record system. Ward work implies records, but nothing here is stated | `[grounded]` CV silence; `[inferred]` ward work involves records | G3 |
| R5a | Wound care | must_have | direct | medium | none | CV states wound care including pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R5b | Leg-ulcer care | must_have | adjacent | medium | transferability | Pressure-ulcer and surgical-wound care carry over. Nothing stated on leg ulcers, compression or vascular assessment | `[grounded]` CV; `[generic]` leg-ulcer care is a distinct skill set from other wound types | G1 |
| R6a | Catheter care | must_have | direct | medium | none | CV states catheter care | `[grounded]` CV | none |
| R6b | Continence care | must_have | unclear | low | discovery | CV mentions catheters, not continence care more widely | `[grounded]` CV silence | G4 |
| R7 | Insulin administration | must_have | direct | medium | none | CV states insulin administration | `[grounded]` CV | none |
| R8 | End-of-life visits | must_have | unclear | low | discovery | CV is silent. An acute medical ward may have involved dying patients, but that is only a lead | `[grounded]` CV silence; `[inferred]` possible ward exposure | G2 |
| R9 | Caring for adults in their own homes | must_have | direct | medium | presentation | The last 18 months were on secondment to a discharge-to-assess team, visiting patients at home in their first week after discharge. The CV places this under the ward role | `[grounded]` CV | E1 |
| R10 | Care planning | important | unclear | low | discovery | CV is silent. The home-visit secondment may have included planning, which is unconfirmed | `[grounded]` CV silence | ask in the informal chat (A1) |
| R11 | A small caseload of your own | important | adjacent | medium | transferability | You state you have never held your own caseload. Carried over: ward patient allocation and home visits in the secondment. Limit: how independent those visits were is unstated | `[grounded]` your statement and CV | G5 |
| R12 | Doppler assessment (desirable) | preferred | absent | none | capability | You state you have never done one. The JD marks it desirable, and the team lead has spoken on Doppler training for staff new to community work, which suggests training may exist | `[grounded]` your statement; `[inferred]` from the forum page | A1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R5b, must_have) | transferability | Pressure-ulcer and surgical-wound care, nothing on leg ulcers | A named duty in the advert and a topic the team lead has spoken on | Dressing or compressing a venous leg ulcer, assessing a leg wound's cause, referring a leg ulcer, a ward leg-ulcer patient | A wound-care competency record, a training certificate | `[grounded]` CV; `[inferred]` this duty is likely to be probed |
| G2 | End-of-life visits (R8, must_have) | discovery | CV silent | A must-have at `unclear`, the most decision-relevant open row | Caring for dying patients on the ward, syringe-driver or anticipatory-medication work, supporting families, a discharge to die at home | A reflective note or competency record, kept free of patient detail | `[grounded]` CV silence |
| G3 | Records and electronic patient record (R4, must_have) | discovery | CV silent on documentation and systems | A listed essential | Which electronic record the ward or secondment used, home-visit entries made on the day | A system name, a records-audit result | `[grounded]` CV silence |
| G4 | Continence care (R6b, must_have) | discovery | CV mentions catheter care only | A named duty beyond catheters | Bladder and bowel care plans, continence assessments, catheter changes and troubleshooting | A competency record | `[grounded]` CV silence |
| G5 | Own caseload (R11, important) | transferability | You have not held your own caseload | A stated duty and your own flagged gap | Planning your own visit list in the secondment, deciding follow-up, escalating a deteriorating patient alone | A secondment service description | `[grounded]` your statement |
| G6 | Doppler assessment (R12, preferred) | capability | None, and you say so | Desirable only | A course, or on-the-job training once in post | An employer training offer | `[grounded]` your statement; `[inferred]` training may be offered |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | unknown | — | "Join our district nursing team caring for housebound adults in their own homes" | The vacancy may sit on a differently addressed careers page or have closed | `[inferred]` from the careers fetch returning nothing at a guessed address; `[grounded]` the About page does attribute the employer | Is this vacancy still open, and what is the closing date? | unresolved |
| RR2 | Caseload size and induction unstated | unknown | — | "You will hold a small caseload of your own, supported by a senior community nurse" | "Small" may mean a handful of patients or a full round | `[inferred]` from the JD's silence on numbers | How many patients does a new starter carry at the outset, and how is the senior nurse's support structured? | unresolved |
| RR3 | Pay stated, inside the market range | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Compensation is transparent and consistent with the Band 5 pattern | `[grounded]` JD; `[generic]` survey band | Where on the range would a new starter be placed, and at what mileage rate? | noted |
| RR4 | Support and tools stated | positive_signal | — | "supported by a senior community nurse"; "pool cars are provided" | The role is resourced, not a lone post | `[grounded]` JD | What does the senior nurse's supervision involve week to week? | noted |
| RR5 | Doppler training provision unknown | unknown | — | "Desirable: Doppler assessment for leg ulcers" | Training for staff new to community work may exist | `[inferred]` from the team lead's forum talk on Doppler training for staff new to community work | Is Doppler training provided to staff who join without it, and how long does sign-off take? | unresolved |
| RR6 | Hours, out-of-hours cover and contract basis unstated | unknown | — | "end-of-life visits" | End-of-life visits may bring weekend or evening work; the contract may be fixed-term | `[inferred]` from the JD's silence | What are the working pattern and out-of-hours expectations, and is the post permanent? | unresolved |

## Application plan

The status of every row, the prose advice here included, is pending your approval; nothing below is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | `resume_edits_pending_approval`: move the discharge-to-assess secondment to the top of your CV, in your own words (home visits in the first week after discharge), with no new facts and no "district nursing" or "caseload" label | see R9 | `[grounded]` CV | pending your approval |
| A1 | Use the informal chat with Rhiannon Mabbott to ask the RR2, RR5 and RR6 questions and about care planning (R10) | The JD invites the chat, and the team lead has spoken on Doppler training for staff new to community work | `[grounded]` JD and forum page | pending your approval |
| A2 | In your application, say plainly: "I haven't yet held my own caseload or performed Doppler assessment; my home visiting was in a discharge-to-assess team" | see R11, R12. Every clause traces to your own statements | `[grounded]` your statements | pending your approval |
| A3 | Confirm the vacancy is live through the employer's own site before applying | see RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet. Your National Insurance number isn't needed for this assessment, and I haven't used it.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "community staff nurse district nursing Band 5 Calderbrook Community Health CIC vacancy", which both returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, which returned no page. Role reality's organization and contradictions rows: the employer is established, the posting's liveness is not (RR1) |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing role scope salary Agenda for Change 2026", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration and RR3; it returned no scope norms |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Role reality's scope read, RR5, and the application plan's A1 |

I can save this as `tuesday-dossier.md` if you want a copy to keep or build on.

## Upgrade menu

- A link to the live posting or the employer's careers page: RR1 closes.
- Wound-care, insulin or catheter competency records, or training certificates: R5a, R6a and R7 move from `medium` toward `high`.
- A service description for your discharge-to-assess secondment: R9 and R11 firm up.
- Your non-negotiables (pay floor, days, hours): the hard-gate checks against your constraints stop being unknown.
- A deeper research pass on Calderbrook (inspection reports, contract changes, staff and candidate reports; up to 5 more searches and 2 more fetches): say the word and it runs.

G2 — Have you cared for dying patients on the ward or in the secondment? What did you personally do, such as symptom control, family support or a discharge to die at home, and when?
G1 — Have you dressed, compressed or assessed a leg ulcer, or referred one on? What was your part?
C1 — Are there any non-negotiables for a role like this: a pay floor, days or hours you can't work, no weekends?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.