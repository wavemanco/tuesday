Yes, this is normal, and the order it happens in is a good sign. I haven't checked anything outside your message, so what follows comes from what you pasted plus general Irish employment practice.

**Why each request is ordinary**
- **Bank details:** they need these to pay you.
- **PPS number:** an Irish employer needs it to register you as an employee with Revenue and report your pay and tax. You can't be put on payroll without it. You'd know this well as a payroll professional.
- **Passport:** employers do right-to-work checks, and a passport is the usual document. Asking to see the original on day one is standard. Whether they should also hold a scan is a data-minimisation question, so you can ask how long they keep it. It isn't a red flag.

Your "never hand those over" rule is a good one for the wrong moment. Scammers ask for these before there's a real offer. Here you've had two in-person interviews at their office, and the requests only come after you accept, through a portal.

**What matches a genuine employer**
- The offer's role, hybrid pattern and salary are consistent with the ad.
- The email comes from a company-domain address (@marrowgatehousing.ie).
- Nobody has asked you for money, equipment purchases or fees.

**Quick checks before you enter anything**
1. Confirm the domain `marrowgatehousing.ie` matches the website you'd find independently. I haven't verified this.
2. When the portal link arrives, check that it's `https` and on their own domain or a recognisable HR-software provider. If in doubt, phone the office on a number from their official site, or ask Declan, whom you met.
3. Never send these details by plain email or messaging. A portal is the safer route.

**Before you accept and resign**
- Ask for the full written contract. It should cover probation, pension, holidays and notice. By law you must receive a written statement of core terms within five days of starting, but you can ask for the contract first.
- Don't hand in notice at your current job until you have it signed.
- The offer is for €40,000, which is inside the advertised range. Reasonable asks are a start-date window and a probation period.

**One fit point**
Pension changes are listed in the duties, and you've not done them yourself. It's worth asking in your acceptance reply, or at onboarding, what training or handover they'd give you on that. Your other experience (payroll, starters and leavers, reconciliation, Excel, the Payroll Technician certificate) lines up well with the ad.

I can also do a fuller go/no-go assessment of the role against your background if you want one.