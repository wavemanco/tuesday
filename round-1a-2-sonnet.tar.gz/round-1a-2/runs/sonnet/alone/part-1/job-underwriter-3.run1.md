Pulling in the reference files and the search tool now. The no-go looks clear from the pay and location terms, but I want to check the employer and the market band before I write it up.
**No, not as posted: R1 and R2, both hard gates, fail. Status: `no_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (Compensation $70–85k base), R2 (On-site Austin five days a week)
- `must_have` — direct: R3a, R4, R5 · unclear: R3b (Growth leadership within those years), R6 (SEO and content ownership)
- `important` — unclear: R7 (Brand and PR), R8 (Partnerships and sales ops), R9 (Hands-on with no team)

R1, R2 — the terms conflict with your floor and your location, whatever the fit elsewhere; R3b, R6, R7, R8, R9 — unclear because your background doesn't say, which is different from absent.

**Opportunity ledger.** The feeling that something is off is borne out in the register. A long bundle of functions is aimed at a team of one with no stated budget (RR3, RR4), weekend work is built in and the metrics are open-ended (RR5, RR6), and the employer is not yet verified (RR7). RR8 runs the other way. RR1 and RR2 are the two confirmed conflicts with your constraints.

- **Hard gates:** failed: R1 (Compensation $70–85k base), R2 (On-site Austin five days a week)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`)
- **What would change this:** the employer would have to offer a base of at least $150k and a role that can be done remotely from Portland. Either one alone leaves a failed gate.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, described as an e-commerce enablement startup, Series A, "profitable since day one". Not independently confirmed (see Evidence status) | `[grounded]` JD header, as claimed by the posting |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Reporting line | CEO, with a dotted line to the board | `[grounded]` JD |
| Team and resources | "A team of one to start"; no budget or headcount plan stated | `[grounded]` JD, including its silence on budget |
| First-year outcomes | None stated; "success metrics will evolve as we learn" | `[grounded]` JD |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus equity of unstated size; the top of the band is $65k under your $150k floor | `[grounded]` JD figure and your stated floor |
| Scope read | Broad for one person: seven functions under one title, with no one reporting in | `[inferred]` from the list of functions against "team of one" |
| Market calibration | Not run, so no band is offered. The search was refused, and market values don't come from memory | no search ran |
| Unknowns | Budget, equity terms, decision rights, hiring manager, whether the posting is live on Novaline's own site | — |
| Contradictions | "8+ years growth leadership" sits beside a team of one, so there is no one to lead at the start. The JD was not checked against a careers page | `[inferred]` from the JD's own wording |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Compensation: $70–85k base (your floor: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated floor. The fit fails because the posted top of band, $85k, is under it | `[grounded]` JD figure and your confirmed constraint | none on your side; only the employer changing the offer resolves it |
| R2 | On-site in Austin 5 days a week, "no exceptions" (you: remote-only, Portland, not relocating) | hard_gate | hard_gate_fail | high | hard_gate | The posting's own wording rules out remote work, and you have confirmed you won't relocate | `[grounded]` JD quote and your confirmed constraint | none on your side; only the employer changing the term resolves it |
| R3a | 8+ years in growth | must_have | direct | medium | none | You state 9 years in growth. Confirmed in your message, but no inspectable artifact yet | `[grounded]` your message | none |
| R3b | Growth leadership across those 8+ years | must_have | unclear | medium | discovery | You state growth lead, then Head of Growth, teams of 3–7, and a three-year $8M to $40M ARR scale-up with a budget you controlled. How many of the nine years were in those two roles is not stated, so the lower reading is taken. Titled years are often read literally | `[grounded]` your message; `[generic]` that titled years are often read literally | confirm years in each role if the terms ever change |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid, with budget control during the scale-up. Confirmed, but nothing inspectable yet | `[grounded]` your message | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze. Confirmed, but nothing inspectable yet | `[grounded]` your message | none |
| R6 | SEO and content | must_have | unclear | none | discovery | Your message says nothing about SEO or content. That makes it unasked rather than absent | `[grounded]` silence in your message | see G3 |
| R7 | Brand and PR | important | unclear | none | discovery | Not mentioned in your background | `[grounded]` silence in your message | see G3 |
| R8 | Partnerships and sales ops | important | unclear | none | discovery | Not mentioned in your background | `[grounded]` silence in your message | see G3 |
| R9 | Working hands-on with no team | important | unclear | low | discovery | You led teams of 3–7 and owned paid and lifecycle, which is indirect context. Whether you have executed all of it yourself is not stated | `[inferred]` from "team of one to start" in the JD; `[grounded]` your team sizes | see G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay and location terms (R1, R2; hard_gate) | hard_gate | Both terms conflict with constraints you confirmed | A failed gate caps the status however strong the fit is. Wording cannot solve a term | None; experience does not change a term | A revised posting or written offer with base at least $150k and remote work from Portland | `[grounded]` R1 and R2 rows |
| G2 | Leadership years (R3b; must_have) | discovery | Titles and one three-year scale-up are stated; the years per role are not | Settles whether the 8+ years reads as met on a literal screen | Months or years as growth lead versus Head of Growth at each company | A dated role history | `[grounded]` your message; `[generic]` that screens read titled years literally |
| G3 | SEO/content, brand and PR, partnerships and sales ops (R6, R7, R8) | discovery | Your background is silent on all three | R6 is a must-have row, so the posting's breadth is the main fit question beyond the gates | Organic or content programs you owned or commissioned; press or launch work; partner deals or lead handoffs to a sales team | A traffic or content report, a press list, a partner agreement | `[grounded]` silence in your message |
| G4 | Hands-on execution with no team (R9) | discovery | Team leadership is stated; solo execution is not | A team of one means doing the work, not directing it | Stretches where you ran channels personally, before or between teams | A channel report you built yourself | `[inferred]` from the JD's "team of one to start" |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base pay below your floor (see R1) | red_flag | high | "$70–85k base plus meaningful equity upside" | Cash on offer is $65–80k under your floor, and equity of unstated size can't stand in for base. The band may also sit low for the mandate, but no market search ran to test that | `[grounded]` JD figure against your floor; `[inferred]` mandate against pay from the JD's scope | Is the base band fixed, and what are the equity percentage, strike price and vesting terms? | confirmed |
| RR2 | On-site five days with no exceptions (see R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The posting's own words exclude remote work from Portland | `[grounded]` JD quote and your confirmed constraint | Does "no exceptions" hold for someone working remotely from another city? | confirmed |
| RR3 | Seven functions folded into one title | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" | Several full roles bundled into one post | `[inferred]` from the list against "team of one"; `[generic]` that bundles like this are often priced below the combined roles | Which of these would this hire run personally, and which would be hired for or outsourced? | unresolved |
| RR4 | Accountability without stated resources | risk_signal | medium | "Own all revenue growth end to end … a team of one to start" | You may be accountable for revenue without budget, headcount or decision rights | `[inferred]` from the JD's silence on budget and authority | What budget, headcount timeline and decision rights come with owning growth? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be routine rather than occasional | `[inferred]` from the "just who we are" framing; `[generic]` pattern | What does "when it matters" look like in a typical month? | unresolved |
| RR6 | No stable success definition on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability with no fixed definition of success | `[inferred]` from the JD's wording | What does success look like at 90 days and at 12 months, and who decides? | unresolved |
| RR7 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR8 | Senior reporting line | positive_signal | — | "Report to the CEO with a dotted line to the board" | The role carries direct access to leadership | `[grounded]` JD states the reporting line | How often does this role present to the board? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't spend application effort on this posting as written | see R1, R2 | `[grounded]` R1 and R2 rows | pending your approval |
| A2 | If you want to test it anyway, ask the employer one thing before any effort: whether the base band and the on-site term are fixed (RR1, RR2) | A cheap way to find out whether the gates can resolve at all | `[grounded]` register | pending your approval |
| A3 | If you proceed regardless, carry the verification questions from RR3, RR4, RR5, RR6 and RR7 into the first conversation | The register travels with you | `[grounded]` register | pending your approval |

No resume edits are proposed.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Novaline e-commerce enablement startup Austin Series A" and "Novaline careers Head of Growth Austin") were refused because web search wasn't permitted. It would have moved role reality's organization and contradictions rows and RR7 |
| 2. Role-family sweep | unavailable | One search ("Head of Growth salary range startup Series A base compensation 2026") was refused. It would have moved role reality's market calibration row and RR1's comparison against market |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can save this as a `tuesday-dossier.md` if you want to keep it.

## Upgrade menu

- Permission to run web search, or a link to the live role on Novaline's own careers page, or the recruiter's email domain → RR7 and role reality's organization row, and the market band for RR1.
- A hiring manager's name → role reality's scope read.
- Years in each role, or any SEO, content, brand, PR, partnership or sales-ops work you have done → R3b and R6–R8 move off `unclear`. This matters only if the gates ever open.
- A revised posting or written offer with base at least $150k and remote work from Portland → R1 and R2 re-open.

No questions this turn: the status turns on the employer's terms, not on anything about your background.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.