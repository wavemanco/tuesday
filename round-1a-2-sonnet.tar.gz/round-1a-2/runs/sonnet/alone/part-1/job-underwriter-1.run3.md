I've read the underwriting rules. Next I'm running the budgeted research on whether the employer exists and what the role usually pays, then I'll write the assessment.
**Yes, apply. You are a fit on the core of this role, and the one thing holding me at `conditional_go` is that I couldn't confirm Harborlight Health exists as described. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4 · unclear: R6 (define and maintain the metrics layer)
- `important` — direct: R5, R7a · adjacent: R7b (clinicians) · unclear: R8 (mentor two junior analysts)
- `preferred` — adjacent: R9 (healthcare data experience, HIPAA)

R6 — the likeliest probe, since "governed dashboards" doesn't establish a metrics layer; R9 — consumer-PII work is a credible bridge with its limit named; R8 — mentoring is not in what you shared.

**Opportunity ledger.** The posting is clearly scoped, with named tools and duties (RR5). Pay, location and first-year success measures are all missing (RR1, RR2, RR3), and the employer is unverified (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, see RR4; (2) pay and location are acceptable to you, see RR1 and RR2; (3) the metrics-layer ownership claim is confirmed or framed honestly, see R6.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C, care-navigation app; none of this is independently verified | `[grounded]` JD header only |
| Mandate | Own product analytics: metrics layer, A/B tests, Looker self-serve dashboards, PM and clinician partnership, mentoring two junior analysts | `[grounded]` JD |
| First-year outcomes | Not stated in the posting | `[grounded]` JD silence |
| Scope read | A senior individual-contributor post with light lead duties: one product, one tool stack, two mentees | `[inferred]` from the duties listed against the absence of a team or budget |
| Market calibration | Not run, because the role-family sweep was refused; no band is offered | `[generic]` none available |
| Unknowns | Pay, location or remote policy, whether a metrics layer already exists, who the two juniors are, who sets experiment standards | `[grounded]` JD silence |
| Contradictions | None between your background and the JD; the posting was not checked against the company's careers page | `[grounded]` inputs only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years of product analytics, confirmed and specific. No document inspected, so `medium`. A years requirement is not a gate and is likely screened literally; you clear it. | `[grounded]` your statement | none |
| R2 | Expert SQL | must_have | direct | medium | none | SQL daily on Snowflake across about 2M subscribers. "Expert" is the employer's word, so expect a live SQL test. | `[grounded]` your statement | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program, with 30+ tests a year. Caveat: the 11% retention lift will be probed for what was your design versus a team effort, so know the split. | `[grounded]` your statement | offer: a sanitized test brief or readout would raise to high |
| R4 | Looker or similar BI | must_have | direct | medium | none | You built the Looker instance from scratch with 40+ governed dashboards. A screenshot or an anonymized dashboard list would be inspectable proof. | `[grounded]` your statement | offer: sanitized dashboard screenshots would raise to high |
| R5 | Written communication with non-technical stakeholders | important | direct | medium | none | You write the monthly metrics memo the exec team reads. A redacted memo would be the artifact. | `[grounded]` your statement | offer: a redacted memo would raise to high |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed dashboards" suggests semantic-layer work but does not say you defined metric definitions or owned them over time. Unconfirmed, so it is a question and not a claim. | `[inferred]` from "governed" against silence on metric definitions | see G1 |
| R7a | Partner with product managers on roadmap decisions | important | direct | medium | none | You present monthly to the VP Product, which is the same motion at a higher level. | `[grounded]` your statement | none |
| R7b | Partner with clinicians | important | adjacent | medium | transferability | Cross-functional partnership carries over. Limit: you have not worked with clinical experts, and clinical safety and evidence norms differ from retention and pricing. | `[inferred]` adjacency from PM and exec work; `[generic]` that clinical stakeholders raise different evidence standards | see G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Nothing in what you shared mentions mentoring or managing. This may be buried experience or a real absence. | `[grounded]` silence in your background | see G2 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | GDPR/CCPA PII handling and a consent-state model carry over. Limit: no PHI, no HIPAA minimum-necessary or BAA work, no clinical data standards. Never present this as HIPAA experience. | `[inferred]` from privacy work against HIPAA's scope; `[generic]` that HIPAA fluency is learnable on the job | see G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | Governed Looker dashboards; no statement of who defined and maintained the metric definitions | A must-have currently at `unclear`; resolving it could make the core fit uniformly direct | Writing LookML explores or views others reused; owning a single definition of "active subscriber" or "churn" across teams; running a metric-change review | LookML snippets (sanitized), a metrics glossary, a definition changelog | `[grounded]` silence on definitions; `[inferred]` that this is the likeliest probe |
| G2 | Mentoring (R8, important) | discovery | Nothing on mentoring or reviewing others' work | A named duty. If absent, it is a carried risk and not a blocker. | Reviewing a junior's SQL or experiment design; onboarding an analyst; running office hours or a style guide | Onboarding doc, review checklist | `[grounded]` silence |
| G3 | Clinician partnership and HIPAA (R7b, R9) | transferability | Adjacent stakeholder and privacy work, none in clinical or PHI settings | Preferred and important rows, so the bridge matters for framing, not for eligibility | Work with legal or compliance on data use; any de-identification or access-control design in the consent model | Consent-model design doc, data-access policy | `[inferred]` bridge; `[generic]` that digital-health analytics hiring probes privacy fluency |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Compensation not stated | unknown | — | none in the posting as pasted | The figure may be withheld or simply omitted from the paste | `[inferred]` from the JD's silence | What is the budgeted salary range for this level? | unresolved |
| RR2 | Location and remote policy not stated | unknown | — | none in the posting as pasted | The role may be on-site or hybrid, which could conflict with your constraints, not yet given | `[inferred]` from the JD's silence | Is the role remote, hybrid or on-site, and where? | unresolved |
| RR3 | No success measures for a broad mandate | unknown | — | "Own product analytics … define and maintain the metrics layer" | Accountability may exceed stated resources or decision rights | `[inferred]` from duty breadth against absent outcomes | What does success look like at 6 and 12 months, and what exists today in the metrics layer? | unresolved |
| RR4 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be real but unverified here: my searches were refused. It could also be new, small, or described loosely. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I interview with? | unresolved |
| RR5 | Clearly scoped duties and named tooling | positive_signal | — | "build self-serve dashboards in Looker" | Scope reads as concrete and matches your stack | `[grounded]` JD | Who are the two junior analysts and how long have they been on the team? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify Harborlight Health and the live posting on the company's own careers page before investing effort | see RR4 | `[grounded]` RR4 | pending your approval |
| E1 | Lead the resume with the experimentation program, 30+ tests a year, and the pricing test, stated as what you designed and ran; avoid "drove" language for the 11% lift unless you can show your part | see R3 | `[grounded]` your statement | pending your approval |
| E2 | Name the consent-state model and the GDPR/CCPA work as privacy-governed data work, with no HIPAA or healthcare wording | see R9 | `[grounded]` your statement | pending your approval |
| E3 | Add Looker governance specifics only if G1 confirms them | see R4, R6 | `[grounded]` R6 row | pending your approval |
| Q1 | Ask RR1 to RR3 verbatim with the recruiter before the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Nothing above is final CV or outreach language until you approve it, and that covers the prose advice here as well as the table.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app Series C careers"; the call was refused. It would have moved RR4 and the contradictions row in role reality |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range experimentation Looker"; the call was refused. It would have moved the market calibration row and RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'm offering one dossier file, `tuesday-dossier.md`, if you want the full record saved for later turns or for interview prep.

## Upgrade menu

- Permission to run web search → RR4 resolves or stays flagged, and a pay band lands against RR1.
- The recruiter's or hiring manager's name → role reality's scope read and which story to lead with.
- The salary range and location → RR1 and RR2 close, and I can check them against your constraints.
- A sanitized dashboard screenshot, test readout or metrics memo → R3, R4 and R5 move to `high`.
- LookML or a metrics glossary → R6 resolves.

**Questions**

1. G1 — Did you personally define and maintain metric definitions (for example what counts as an active subscriber or churn) in Looker, and did other teams rely on them? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. G2 — Have you onboarded, reviewed the work of, or informally mentored other analysts, and what did that look like? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. RR1 and RR2 — Do you have a pay floor, or location or remote requirements, that I should check this role against? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.