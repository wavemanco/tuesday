I'll read the reference files the skill requires before building the assessment.
**Decision snapshot**

**Yes, apply, but settle R1 first: the JD says fully remote and the company's own careers page says Leeds office four days a week. Status: `conditional_go`.**

**Fit ledger**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5a, R6, R7a, R8 · unclear: R5b (Monitor rating models), R7b (Recommendations to product)
- `important` — adjacent: R9 (Pet-insurance domain knowledge)
- `preferred` — direct: R10 (Insurance experience)

R5b — "maintained" is not yet "monitored"; R7b — a product audience is unevidenced; R9 — a credible bridge, its limit named.

**Opportunity ledger.** The role is real and on the employer's own careers page, with a pricing specialist as manager (RR3). The working pattern is contradictory (RR1), the pay is withheld (RR2), and team and scope are unstated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern turns out to be workable for you — R1, RR1; (2) the salary, once disclosed, clears your floor — RR2; (3) the pet-insurance bridge is framed as adjacent, never as pet experience — R9.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech. Its careers page is live and lists this role. Size, stage and funding are not established | `[grounded]` careers page fetched |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, and turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | The Director of Pricing. You named Odile Varga as hiring manager | `[grounded]` careers page, your message |
| Working pattern | The JD says fully remote (UK). The careers page says "Leeds office four days a week" | `[grounded]` JD against careers page |
| Seniority and scope | Senior individual-contributor analytics post. The JD states no line-management duty, so never having managed anyone is not a listed requirement | `[grounded]` JD silent on management; `[inferred]` individual-contributor read from "Own pricing analytics" |
| Hiring manager | Director of Pricing, previously head of pricing analytics at Calloway Re for six years. Spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors", about monitoring rating models in small books. The monitoring strand of the JD may therefore weigh heavily | `[grounded]` public profile (search result); `[inferred]` weighting of monitoring from the talk's topic |
| Market calibration | A 2026 survey of UK senior pricing analysts at insurers and insurtechs (n=612) gives median base £58,400, interquartile range £52,100 to £64,900. The posting states no salary, so this band is what to expect, never this employer's offer (RR2). I read the survey's search snippet and did not open the page | `[generic]` Pricewell 2026 pay survey; `[grounded]` JD withholds salary |
| First-90-days outcomes | Not stated | `[grounded]` JD silent |
| Unknowns | Salary; team size; who owns the rating models today; who the product counterpart is; tooling | `[grounded]` JD and careers page silent |
| Contradictions | The JD says remote and the careers page says Leeds four days a week. The careers page has one line of text, so it is not a full second source | `[grounded]` both texts |

**Evidence map**

Your background was typed into the conversation, so it counts as self-report like a CV. `medium` is the ceiling until something inspectable is seen.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | JD and careers page disagree, and you have not stated a location or working-pattern constraint. Confidence grades your statement of a constraint, and there is none yet. Whether the role meets it lives in fit | `[grounded]` JD against careers page; no candidate statement | One question (below) on whether this is a requirement for you; RR1 goes to the employer |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Specific, but self-reported | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily" is a plain statement of use. "Strong" is the JD's word, not yours, and nothing shows depth | `[grounded]` your background | A sanitized query or script sample would raise it to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. This is the closest match in the whole map | `[grounded]` your background | A sanitized model specification or documentation would raise it to `high` |
| R5a | Build rating models | must_have | direct | medium | none | Same evidence as R4: you built the young-driver GLM | `[grounded]` your background | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained". Whether that included performance tracking, drift checks or refit triggers is not stated. Ambiguity resolves downward, so I do not read it as monitoring | `[grounded]` your wording; the manager's published talk makes this strand likelier to be probed (`[inferred]`) | G1 |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. "Ran" is your word. Whether you designed them (structure, sample size, controls) is unconfirmed, so no draft line may say "designed" yet | `[grounded]` your background | Confirm your role in test design before the CV or interview uses "design" |
| R7a | Turn results into recommendations for underwriting | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting and ran tests with that team | `[grounded]` your background | none |
| R7b | Turn results into recommendations for product | must_have | unclear | low | discovery | Nothing you have said involves a product team or product decisions | `[grounded]` silence in your background | G2 |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your background | A sanitized review deck would raise it to `high` |
| R9 | Pet-insurance domain knowledge (inferred from "our pet-insurance product") | important | adjacent | low | transferability | You have no pet-insurance work. Motor and pet are both personal-lines GLM pricing, so the method carries over. Limit: you have not worked with pet-specific rating factors or claims patterns | `[inferred]` requirement from the product named in the JD; `[generic]` that personal-lines GLM method carries over | G3 |
| R10 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your background | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R5b, must_have) | discovery | You maintained the young-driver GLM, but nothing says what ongoing performance tracking you did | A must-have at `unclear`. The manager's public talk is about monitoring, so this is the likeliest place to be probed | Regular actual-versus-expected reviews; drift or lift checks after a rate change; a trigger for refitting; a dashboard others used | A sanitized monitoring pack, a model-review note or a dashboard screenshot | `[grounded]` your wording; `[inferred]` that the talk topic raises the odds of a probe |
| G2 | Recommendations to product (R7b, must_have) | discovery | Your audience so far is underwriting. No product contact is stated | The JD names product as a second audience | Test results that changed a product feature or rule; work with a product owner on a pricing change; a pricing-review item that went beyond underwriting | A review-deck slide, an email thread or a paper that reached a product owner | `[grounded]` silence in your background |
| G3 | Pet-insurance domain knowledge (R9, important) | transferability | Method carries over. No pet-specific work | The JD does not require it, but the role is entirely about this product | Any work on a non-motor line; any exposure to animal or health-claims data | Nothing to attach. Learning the product's main rating factors would narrow the limit | `[inferred]` bridge; `[generic]` that rating factors differ by line |
| G4 | Working pattern (R1, hard_gate) | hard_gate | JD and careers page disagree | The one thing that could make this a no | Not applicable; wording cannot solve a gate | Not applicable | `[grounded]` JD against careers page |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts across sources (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One source may be stale, the role may be hybrid with remote exceptions, or the post may exist in two versions. This is an incompatibility only if you need remote | `[inferred]` from the two texts | Is this role fully remote within the UK, or is it based in the Leeds office four days a week? | unresolved |
| RR2 | Salary withheld | unknown | — | The JD states no pay | The figure may sit anywhere in the band in role reality, or the company may not publish it | `[inferred]` from the missing figure against the `[generic]` survey band | What salary range is budgeted for this post? | unresolved |
| RR3 | Hiring manager is a pricing specialist with published work on monitoring | positive_signal | — | "Director of Pricing" (careers page); talk "Small Books, Loud Errors" | Your work would be read by someone who can judge it technically | `[grounded]` careers page and public profile | What does good rating-model monitoring look like in this team today? | noted |
| RR4 | Team, tooling and ownership unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Own" may mean the sole analyst or a lead within a team. Authority and support are not visible | `[inferred]` from the posting's silence on team and tooling | Who else sits in the pricing team, and who owns the rating models today? | unresolved |

**Application plan**

Everything here is a proposal. The approval status in the last column covers the prose advice as well as the table. Nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume edit: lead the experience section with three lines in your own terms: "Built and maintained the GLM rating model for the young-driver book"; "Ran 14 price tests last year with the underwriting team"; "Present the quarterly pricing review to the head of underwriting". Do not use "designed" or "monitored" until R6 and R5b are confirmed | R2, R4, R5a, R6, R7a, R8 | `[grounded]` your own sentences | `resume_edits_pending_approval` |
| P1 | Positioning: say plainly that this would be your first pet-insurance role, and lead with the GLM and price-testing evidence. Do not claim pet-specific knowledge | R9 | `[grounded]` your background; `[generic]` method carries over | pending your approval |
| P2 | If G1 turns up real monitoring work, make it the story you lead with for this hiring manager, whose public talk is about monitoring | R5b | `[inferred]` from the talk's topic | pending your approval |
| A1 | Before investing in the application, ask the recruiter or hiring manager the RR1 question verbatim | R1, RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the RR2, RR3 and RR4 questions in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers". Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). The posting is live and the company is real, but the page contradicts the JD on working pattern (R1, RR1) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK remote salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). I read the snippet only. It gave the market calibration band `[generic]` and the salary comparison in RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). I read the snippet only. It moved the scope read in role reality, RR3 and P2 |

I can write up the whole assessment as `tuesday-dossier.md` if you want to keep it.

**Upgrade menu**

- Your location, working-pattern and pay-floor constraints → R1 becomes met or failed and the hard-gates line stops flagging unknown checks.
- An answer to G1 → R5b closes, and P2 can become a real lead story.
- An answer to G2 → R7b closes.
- A sanitized model specification, query or script sample, price-test readout or review deck → R3, R4 and R8 go to `high`.
- The recruiter's answer to RR1 → R1 and the decision simplify.
- The budgeted salary → RR2 closes against the band in role reality.
- A deeper research pass on Brindlemoor (funding, leadership changes, public staff reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

R1 — Is working fully remotely a requirement for you, or could you do the Leeds office four days a week, and do you have a minimum salary?
G1 — Beyond maintaining the young-driver GLM, did you track its performance over time (for example actual-versus-expected, drift, or a refit trigger), and what was yours to do?
G2 — Have any of your price-test results or pricing-review items gone to a product owner or product decision, and what was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.