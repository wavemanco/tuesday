I'll read the reference files first.
**Yes, it's worth applying, on conditions. Status: `conditional_go`.** The caveat is R1 and R2, your location and your pay floor. You haven't told me either, so I can't check them. Your must-have fit is strong, and the one real technical gap is BigQuery (R9).

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or our Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery); unclear: R10 (ingestion from our app and CRM), R11 (data contracts our analysts depend on)

R9 — a credible bridge, its limit named; R10, R11 — not evidenced yet, recall questions below.

**Opportunity ledger.** Pay is stated, and I set it against your recruiter's report (RR3). The reporting line, team and breadth of scope are unknown (RR1, RR5), the equity terms are unstated (RR2), and I couldn't re-check the employer's own pages (RR4).

- **Hard gates:** none failed (R1, R2, neither settled by what you've told me); unconfirmed: R1 (Remote (US) or our Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 meet your own non-negotiables, which only you can confirm; (2) the posting and employer verify as live and as described, see RR4; (3) the BigQuery bridge is framed honestly as adjacent, never as BigQuery experience, see R9 and G1; (4) the reporting line, team size and equity terms get answered in the loop, see RR1, RR2 and RR5.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the company page text you pasted; not independently re-checked (see Evidence status) |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, and data contracts for analysts | `[grounded]` JD you pasted |
| Seniority | 5+ years of data engineering, titled Senior | `[grounded]` JD; the report's typical range for the title is 5–8 years |
| Compensation | $148,000–$166,000 plus equity (equity terms unstated); the band sits near the report's median, with its top above the report's upper quartile | `[grounded]` JD and the Datawright 2026 report you supplied (Series B–D, n=2,310: base median $151,000, interquartile range $139,000–$163,500); `[inferred]` that the posted figure is base salary |
| Location | Remote (US) or the Denver office | `[grounded]` JD |
| Scope read | The mandate runs from ingestion through modelling to contracts, which is wider than the report's "one domain's pipelines". Whether it is wider in practice depends on team size, which the posting doesn't give | `[inferred]` JD's three-part mandate against the report's typical scope |
| Market calibration | Title, tenure and pay all sit inside the report's norms for Series B–D. Scope is the one dimension that may stretch past "one domain, no direct reports" | `[grounded]` Datawright report you supplied; this is the report's pattern, not a claim about this employer |
| First 90 days / first year | Not stated | `[grounded]` JD silent |
| Unknowns | Hiring manager (none named), team size, reporting line, equity structure | `[grounded]` JD and your note that no manager is named |
| Contradictions | None between the JD and the company text you pasted. The live posting could not be checked | `[grounded]` both pasted texts compared |

## Evidence map

Your background is typed prose, so every claim about you sits at `medium` at most until you show an artifact.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or the Denver office | hard_gate | unclear | none | hard_gate | You haven't stated where you live or work from, so the posting's terms can't be checked against you. Confidence is `none` because there is no statement of yours to grade | `[grounded]` JD terms; your background is silent on location | Question asked below |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You haven't given a pay floor, so the band can't be checked against it. The equity terms are separately unstated (RR2) | `[grounded]` JD figure; no floor stated | Same question as R1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. A length-of-experience requirement, graded as a requirement and not a gate | `[grounded]` your background prose | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily" is specific on frequency but has no artifact behind it | `[grounded]` your background prose | none |
| R5 | dbt | must_have | direct | medium | none | You built your company's dbt project, about 180 models. Specific, with no inspectable artifact yet | `[grounded]` your background prose | A sanitized model-DAG screenshot would raise it to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. The JD's own stack is BigQuery, carried separately as R9 | `[grounded]` your background prose | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named in the JD and in your background | `[grounded]` your background prose | none |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up your company's Great Expectations test suite. Your role in that setup is stated; scope and outcomes are not | `[grounded]` your background prose | A sanitized suite listing or a test-coverage summary would raise it to `high` |
| R9 | BigQuery, the JD's named warehouse | important | adjacent | medium | transferability | The bridge is Snowflake plus about 180 dbt models. The limit is that you have never used BigQuery, so its cost model, partitioning and dialect differences are untested. The JD lists "a cloud warehouse", not BigQuery, as the requirement; BigQuery is named in the mandate | `[grounded]` JD's mandate wording and your stated lack of BigQuery use; `[generic]` that warehouse-specific details are normally learnable on the job, which the loop may probe | See G1 |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | Your background doesn't say what the sources of your pipelines were. Low and not none, because a payroll platform's pipelines plausibly had app and third-party sources | `[grounded]` background silent; `[inferred]` from the pipeline work you described | See G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | The 180-model dbt project and the test suite are adjacent, but nothing says whether you defined agreements with downstream consumers | `[grounded]` background silent | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Snowflake and dbt at scale; no BigQuery use. The bridge is the warehouse-modelling craft. The limit is BigQuery's cost model, partitioning and clustering, and SQL dialect. The strengthener is a small dbt-on-BigQuery project you build and can show | The one stack-specific gap on a mandate that names BigQuery | A dbt project run against BigQuery's free sandbox, with partitioned and clustered tables | A short repo or README you could link | `[grounded]` your stated lack of BigQuery use; `[generic]` that this is the likeliest probe |
| G2 | App and CRM ingestion (R10, important) | discovery | Nothing in your background says what fed your pipelines | The JD names both sources first in its mandate | Loading product event data; syncing a CRM or billing system; managing an API or CDC connector | An architecture sketch or a connector list | `[grounded]` background silent; `[inferred]` that resolving it could lift R10 to `direct` |
| G3 | Data contracts (R11, important) | discovery | Tests and models exist. Nothing says whether you agreed schemas or SLAs with the analysts | The JD names contracts as something analysts depend on | Agreeing column semantics with analysts; schema-change alerts; dbt model contracts or versioning; an SLA you set | A contract doc, a schema-change policy, or a dbt YAML excerpt | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | No hiring manager, team or reporting line | unknown | — | "The posting names no hiring manager" (your note) | The role may be the first or only data engineer, or part of an established team | `[inferred]` from the posting's silence on team and manager | Who does this role report to, and how many data engineers and analysts are on the team? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "plus equity" | Value is unknowable without type, amount, vesting and strike | `[grounded]` JD states "equity" and no terms | What is the equity grant: type, amount, vesting schedule, and current valuation basis? | unresolved |
| RR3 | Pay stated and in line with the market report | positive_signal | — | "$148,000–$166,000 plus equity" | The band's low end is $3,000 below the report's $151,000 median and its top is $2,500 above the report's $163,500 upper quartile. No seniority-pay mismatch | `[grounded]` JD figure and the Datawright report you supplied | Is the range firm, and where in it would someone with 6 years land? | noted |
| RR4 | Employer and posting not independently checked | risk_signal | medium | "Series C ($52M, February 2026)" | I couldn't re-read the posting or company pages, so I haven't confirmed the posting is live or that the facts are current. This is a gap in what I checked, not a finding against the company | `[generic]` pattern for any unchecked posting, not a claim about this one | Can you confirm the role is open on your careers page, and who would I interview with? | unresolved |
| RR5 | Breadth of scope against team size | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting: ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | Ingestion, modelling and contracts may be one person's remit, which is wider than the report's one-domain typical scope | `[inferred]` JD's mandate against the Datawright scope norm | Which of ingestion, warehouse modelling and contracts does this role own, and which belong to other people? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | `resume_edits_pending_approval`: lead the summary with your own facts, in your wording: 6 years of data engineering at a B2B payroll company; built the dbt project on Snowflake, about 180 models; Airflow orchestration; set up the Great Expectations test suite; Python and SQL daily. Add no BigQuery wording | See R3, R5, R7, R8; every clause traces to your background | `[grounded]` your background | pending your approval |
| E2 | Build a small dbt project on BigQuery and link it only if you finish it, framed as a learning project | See G1, R9 | `[grounded]` R9 row | pending your approval |
| Q1 | Ask the verification questions of RR1, RR2, RR4 and RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Say plainly that BigQuery is new to you and that you've worked in Snowflake with dbt. Don't claim BigQuery experience | See R9 | `[grounded]` your stated lack of BigQuery use | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two page fetches were refused: pellucidlearning.com/careers/senior-data-engineer and pellucidlearning.com/about, both aimed at checking that your pasted text is current. Nothing was read, and I didn't try another route. It would have moved role reality's contradictions row and RR4 |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes the band, seniority and scope. It fed market calibration and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I offer to write all of this up as `tuesday-dossier.md` for later turns, whenever you want it.

**Upgrade menu**

- Your location and pay floor → R1 and R2 move to `direct` or `hard_gate_fail`, and the decision settles.
- Answers to G2 and G3 → R10 and R11 move toward `direct`.
- A model-DAG screenshot or a test-suite listing, sanitized → R5 and R8 to `high`.
- A small dbt-on-BigQuery repo → R9's limit narrows.
- The hiring manager's name → role reality's scope read, and whom to lead with.
- Web access, which was refused this time → target 1 runs and RR4 can close. A deeper pass (up to 5 more searches and 2 more fetches) would cover funding, leadership changes and public employee reports; say the word and it runs, if the host grants web access.

**Questions**

1. R1, R2 — Do the role's location terms (remote anywhere in the US, or Denver) and its $148,000–$166,000 base meet your own non-negotiables?
2. G2 — What did your pipelines pull from: product events, a CRM or billing system, third-party APIs? What did you own, and how was it loaded?
3. G3 — Did you ever agree a schema, a freshness SLA or a column definition with the analysts who used your models? What did you personally set up, and did it change anything?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.