Loaded the web tools. Next I'm checking that the pasted posting and company page are live and match, using the careers page and one search.
## Decision snapshot

**Yes, it's worth applying, on conditions. R1 and R2, the two hard gates, are unconfirmed because you haven't stated your location or pay floor. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R8, R9
- `important`: adjacent: R7 (BigQuery) · unclear: R10 (ingestion from app and CRM), R11 (data contracts)

R7 is a credible bridge with its limit named; R10 and R11 are unconfirmed and waiting on your answers.

**Opportunity ledger.** The role is transparent on pay and checks out against the company's own pages (RR1, RR5). The open items are the equity terms (RR2), how much one person owns across three areas (RR3), and what success looks like in year one (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location and work eligibility fit "Remote (US) or our Denver office" — R1; (2) the posted range clears your pay floor — R2; (3) RR3's scope question gets a concrete answer in the loop; (4) the BigQuery gap is stated plainly as adjacent, never claimed as experience — R7.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the company's About page, which came back in a search result. The funding figure is the company's own statement and I did not corroborate it elsewhere |
| Mandate | Pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, and data contracts for analysts | `[grounded]` JD, matches the live careers page |
| Working pattern and pay | Remote (US) or the Denver office; $148,000–$166,000 plus equity, with equity terms unstated | `[grounded]` JD |
| Outcomes | No first-90-days or first-year outcomes stated | `[grounded]` JD silent |
| Scope read | The three named areas read as end-to-end ownership of the reporting pipeline, broader than one domain. Team size and reporting line are not stated | `[inferred]` from the JD's three areas against its silence on team |
| Market calibration | The report puts Senior Data Engineer base at a $151,000 median, interquartile range $139,000–$163,500, at Series B–D companies. "Senior" typically means 5–8 years, and typical scope is one domain's pipelines with no direct reports. The posted floor of $148,000 is below the median. The posted top of $166,000 is above the range's upper quartile. Pellucid is Series C, inside the report's stage band. This is a band to expect, not a Pellucid offer | `[generic]` Datawright 2026 pay report (n=2,310, supplied by your recruiter); `[grounded]` JD figures |
| Unknowns | Hiring manager (none named); team size; equity terms; success metrics; what "run" means operationally | `[grounded]` JD names none of these |
| Contradictions | None between the pasted posting and the live careers page | `[grounded]` page fetched |

## Evidence map

Your background was typed into the conversation. That makes it self-report at the same standing as a CV, so `medium` is the ceiling on a first pass.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | No location or work-eligibility statement from you, so the gate is unsettled. Confidence grades your statement of the constraint, and none exists yet | `[grounded]` JD term; nothing stated by you | Q1 in the closing questions |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor given, so whether the range clears it is unknown. The range itself is stated | `[grounded]` JD figure; no floor stated by you | State your floor; closes against the posted range |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You describe 6 years of data engineering at a B2B payroll company. Confirmed and specific, but no inspectable artifact. Expect a probe on scope | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. Specific, but "strong" has no inspectable proof yet | `[grounded]` your background | A repo, code sample or model file would raise it |
| R5 | dbt | must_have | direct | medium | none | You built the company's dbt project, about 180 models, on Snowflake. Specific, with no artifact inspected | `[grounded]` your background | A sanitized lineage graph or docs screenshot would raise it |
| R6 | A cloud warehouse | must_have | direct | medium | none | The JD asks for "a cloud warehouse", and Snowflake is one. The BigQuery-specific piece is split out as R7 | `[grounded]` JD wording and your background | none |
| R7 | BigQuery (the warehouse named in the JD's responsibilities) | important | adjacent | medium | transferability | Snowflake plus dbt is a genuine bridge. The limit is that you have not used BigQuery, so its cost model, partitioning and clustering, and IAM are unexercised. Warehouse differences in practice are an area interviewers can probe | `[grounded]` you said you never used BigQuery; `[generic]` the probe pattern | G3; optional small BigQuery project |
| R8 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named in your background as your orchestrator. Specific, unprobed | `[grounded]` your background | none |
| R9 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. Specific, with no artifact inspected | `[grounded]` your background | A suite config excerpt would raise it |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | Running Airflow pipelines implies ingestion work, but your sources are not stated. Carried as a lead only | `[inferred]` from the orchestration work you described | G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Your Great Expectations suite is indirect context. Nothing says you defined or enforced contracts with analysts | `[inferred]` from the test suite; nothing stated on contracts | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Data contracts (R11, important) | discovery | A test suite you set up, but no stated agreement with analysts on schema, freshness or ownership | It is named in the mandate, and resolving it could firm up the conditional go | Agreeing column or freshness expectations with analysts; failing a pipeline on a contract breach; schema-change notices; dbt model contracts | A sanitized contract doc, a dbt contract YAML, or a GE expectation list | `[grounded]` the JD names contracts; `[inferred]` the gap from your background's silence |
| G2 | Ingestion from app and CRM (R10, important) | discovery | Airflow pipelines, but no named source systems | It is the front half of the role's pipelines | Loading product-database or event data; syncing a CRM such as Salesforce or HubSpot; managed connectors or hand-built extractors | A DAG screenshot or ingestion diagram | `[grounded]` the JD names these sources; `[inferred]` the gap from background silence |
| G3 | BigQuery (R7, important) | transferability | Snowflake and dbt at scale; no BigQuery use | It is the JD's named warehouse. A bridge with its limit stated reads weaker and interviews stronger | Adjacent: Snowflake cost and performance tuning; dbt materialization choices. Limit: BigQuery's slot and bytes-scanned pricing, partitioning and clustering, IAM | A small dbt project run on BigQuery's free tier, built and shown as a learning project | `[inferred]` bridge from your Snowflake and dbt work; `[generic]` that this is the likeliest probe |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated, at or above the market median | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is transparent and in line with a senior band for a Series C company | `[grounded]` JD figure and pasted report; `[generic]` the band | Where in the range would someone with six years of experience land? | noted |
| RR2 | Equity named without terms | unknown | — | "plus equity" | The equity's value can't be judged without type, size and vesting | `[inferred]` from the JD naming equity and giving no terms | What is the equity: type, grant size range, vesting, and how is it valued? | unresolved |
| RR3 | Scope breadth against typical senior scope | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting: ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | Three areas may sit with one person, where the report describes one domain as typical | `[inferred]` from the JD's three areas against the `[generic]` report scope | How many data engineers and analysts are there, and which of ingestion, warehouse and contracts does this role own alone? | unresolved |
| RR4 | No stated success metrics or first-year outcomes | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The mandate is clear but its definition of success is not | `[inferred]` from the JD's silence on outcomes | What would a successful first year look like, and who would this role report to? | unresolved |
| RR5 | Employer and posting match the description | positive_signal | — | "Accepting applications" | The employer exists as described and the posting is live | `[grounded]` careers page fetched, About page returned in search | Who is the hiring manager for this role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your resume with the dbt project (about 180 models, Snowflake) and the Great Expectations suite you set up | see R5, R9 | `[grounded]` your background | pending your approval |
| E2 | Name the warehouse as Snowflake and do not list BigQuery as a skill. If asked, say "dbt on Snowflake; I haven't used BigQuery" | see R6, R7 | `[grounded]` R7 row | pending your approval |
| W1 | Optional: a small dbt project on BigQuery's free tier, described as a learning project and never as job experience | narrows R7's limit only if built | `[inferred]` from R7's adjacency | pending your approval |
| Q1 | Ask RR2, RR3 and RR4 verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | If your recruiter is on this role, ask for the team structure and equity details before the first call | see RR2, RR3 | `[grounded]` RR2, RR3 rows | pending your approval |

All plan rows, and the positioning advice in the reasoning cells above, are proposals pending your approval. Nothing is final until you say so.

## Evidence status

Verified: none yet. Stage is assumed to be evaluating, since you didn't state one.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | This was a quick check that your pasted text is live and genuine. Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). Searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about). It moved role reality's organization and contradictions rows: the text matches, so the employer-not-established entry is not raised (RR5) |
| 2. Role-family sweep | skipped | Your recruiter's pay report is in hand and fixes the market calibration line and the pay comparison (RR1) |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

I'm offering the dossier file (`tuesday-dossier.md`) if you want one to keep.

## Upgrade menu

- Your location, work eligibility and pay floor → R1 and R2 close against the posted terms.
- A sanitized dbt lineage graph, a GE suite excerpt or a code sample → R4, R5 and R9 can move to `high`.
- Your resume document → I can check which rows it buries and propose repositioning.
- An answer on contracts or ingestion (G1, G2) → R11 and R10 move from `unclear`.
- The hiring manager's name → scope read and which story to lead with.
- A deeper pass on Pellucid (funding corroboration, leadership changes, employee reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

1. R1 — Are you US-based with work authorization that needs no sponsorship, or able to work from Denver?
2. G1 — Have you agreed schema, freshness or ownership expectations with analysts, or failed a pipeline on a breach? What did you own, and is there a doc or config that shows it?
3. G3 — Have you had any hands-on contact with BigQuery, even a side project or a migration evaluation?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.