Checking that Pellucid Learning and the posting are real and match what you pasted, then I'll write the assessment.
**Pellucid Learning, Senior Data Engineer: assessment for Ines**

## Decision snapshot

**Yes, this looks worth applying to. Status: `conditional_go`.** R1 and R2, the location and pay gates, are unconfirmed against your own terms, and you haven't given me constraints to check them against.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R7, R8
- `important`: adjacent: R6 (BigQuery); unclear: R9 (App and CRM ingestion), R10 (Data contracts for analysts)

R6: a credible bridge, its limit named; R9, R10: your background is silent, so worth a question.

**Opportunity ledger.** The posting is live and the pay is stated (RR3), and the funding is recent per the company's own page (RR4). The scope, the equity terms and the success measures are all unstated (RR1, RR2, RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) location and your pay floor confirmed as workable, R1 and R2; (2) the role's scope verifies as one workable scope, RR1 and RR5; (3) BigQuery is presented as adjacent, never as experience you have, R6.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company About page, fetched via search result |
| Mandate | Build and run the reporting pipelines: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` posting, fetched |
| First-90-days and first-year outcomes | Not stated in the posting | `[grounded]` posting silent |
| Working pattern | Remote (US) or the Denver office | `[grounded]` posting |
| Scope read | Ingestion, warehouse modelling and contracts together run wider than the one-domain scope the pay report calls typical. The posting names no team size, so this could be a sole or near-sole owner | `[inferred]` from the posting's mandate against the report's stated scope |
| Market calibration | Stated pay is $148k–$166k. The recruiter's Datawright 2026 report (n=2,310, Series B–D) gives a base median of $151k and an interquartile range of $139k–$163.5k. The posted range starts just below the median and tops out above the range's upper end. The report calls 5–8 years typical for "Senior", and you have 6 | `[grounded]` posting and the report you supplied, which I did not independently check; `[inferred]` the comparison |
| Unknowns | Hiring manager (the posting names none), team size, equity amount, success measures | `[grounded]` posting silent |
| Contradictions | None between your pasted text and the live careers and About pages | `[grounded]` both pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't stated where you live or any location limit, so the term can't be checked | `[grounded]` posting term; you stated no constraint | Question G1 |
| R2 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | The pay is stated, but your floor isn't, so it can't be checked | `[grounded]` posting term; you stated no floor | Question G1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years at a B2B payroll company. That is your own account, with no CV or artifact inspected | `[grounded]` your statement | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. That shows use, not level, and the word "strong" is untested. Teams hiring for this title commonly probe both live | `[grounded]` your statement; `[generic]` interview pattern | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built your dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse | `[grounded]` your statement | A sanitized lineage graph or project overview would raise this to `high` |
| R6 | BigQuery as the warehouse | important | adjacent | medium | transferability | You haven't used BigQuery. Your dbt and warehouse modelling carries over. The limit is that you have no BigQuery operation, cost or tuning experience, and that limit stays named wherever the bridge is used | `[grounded]` your statement; `[inferred]` adjacency | A small personal BigQuery and dbt project would narrow the limit |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You use Airflow for orchestration. You haven't said whether you wrote or operated the DAGs, so I won't claim either | `[grounded]` your statement | Question about authoring is optional |
| R8 | Data quality testing | must_have | direct | medium | none | You set up your company's Great Expectations test suite | `[grounded]` your statement | A sanitized suite excerpt would raise this to `high` |
| R9 | Ingestion from the app and CRM | important | unclear | low | discovery | You haven't described ingestion work, source types or tooling | `[grounded]` your background silent | Question G3 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | You haven't mentioned contracts or schema agreements. The Great Expectations suite may be adjacent, but I can't tell | `[grounded]` your background silent | Question G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms (R1, R2; hard_gate) | hard_gate | The posting states both terms. Your constraints aren't given | These are the two gate rows, and the status stays `conditional_go` until both are confirmed | These are terms, not experience | Your own statement | `[grounded]` posting terms; you stated no constraints |
| G2 | BigQuery (R6; important) | transferability | Your dbt on Snowflake is confirmed. BigQuery isn't | The posting names BigQuery as the warehouse, so this is the most likely objection | A BigQuery sandbox project with dbt; a migration or cross-warehouse piece of work | A short repo or write-up | `[inferred]` bridge from your Snowflake work; `[generic]` that this is the likeliest objection |
| G3 | Ingestion from app and CRM (R9; important) | discovery | Nothing in your background describes ingestion | The posting lists it first among the pipelines | Loading product events or a CRM such as Salesforce or HubSpot; managed connectors or hand-built extracts; reconciling source systems | A pipeline diagram or a DAG excerpt | `[grounded]` your background silent |
| G4 | Data contracts (R10; important) | discovery | The Great Expectations suite is confirmed. Contracts aren't | The posting names contracts that analysts depend on | Schema or freshness agreements with analysts; tests that blocked a bad load; versioned model interfaces | A contract doc or a test excerpt | `[grounded]` your background silent; `[inferred]` that your test suite may be adjacent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Scope and team unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may be a sole or near-sole owner of ingestion, warehouse and contracts, wider than the typical one-domain scope | `[inferred]` from the posting against the pay report's stated scope | Who does this role report to, how many data engineers are there, and which domains does it own? | unresolved |
| RR2 | Equity unquantified | unknown | — | "plus equity" | The grant size and vesting may be modest or unspecified | `[inferred]` from the posting giving no figure | What is the equity range, the vesting schedule and the strike basis for this level? | unresolved |
| RR3 | Pay stated and at market | positive_signal | — | "Salary $148,000–$166,000" | Pay is transparent and sits at the median or above, so no seniority-compensation mismatch | `[grounded]` posting and the pay report you supplied | Is the top of the range reachable for 6 years of experience? | noted |
| RR4 | Recent funding | positive_signal | — | "Series C ($52M, February 2026)" | Hiring is likely backed by runway | `[grounded]` the company's own About page, not independently corroborated | What is the runway, and is this a new or a backfill role? | noted |
| RR5 | Success measures unstated | unknown | — | "Build and run the pipelines" | A broad mandate with no stated first-year outcomes could mean a vague definition of success | `[inferred]` from the posting's silence | What would success look like at 90 days and at one year? | unresolved |

## Application plan

All rows below are proposed language or actions, each pending your approval. Resume edits are `resume_edits_pending_approval`. Each clause traces to your own sentences.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Summary line: "Data engineer, 6 years at a B2B payroll company: dbt on Snowflake, Airflow, Great Expectations, Python and SQL." | See R3, R4, R5, R7, R8 | `[grounded]` your background | resume_edits_pending_approval |
| E2 | Bullet: "Built the dbt project on Snowflake, about 180 models." | See R5 | `[grounded]` your wording | resume_edits_pending_approval |
| E3 | Bullet: "Set up the Great Expectations test suite." | See R8 | `[grounded]` your wording | resume_edits_pending_approval |
| A1 | In the cover note or the interview, say plainly: "dbt modelling on Snowflake, no BigQuery use yet." | See R6, G2 | `[grounded]` your statement | pending your approval |
| A2 | Ask the register's questions RR1, RR2 and RR5 verbatim of the recruiter or hiring manager | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Confirm location and pay terms before investing in the loop | See R1, R2 | `[grounded]` the gate rows | pending your approval |

## Evidence status

Verified: none yet. Your background is prose I haven't tested, so its claims are leads, not proof.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer) and searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about). Both match your pasted text and the posting is accepting applications. This moved role reality's organization and contradictions rows. Both pages are the company's own, so funding is company-reported |
| 2. Role-family sweep | skipped | The recruiter's pay report is already in hand and fixes the market calibration and pay comparison, so a search would change neither |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

## Dossier offer

I can write all of this up as `tuesday-dossier.md` if you'd like to keep it. Say the word.

## Upgrade menu

- Your location, work authorization and pay floor → R1 and R2 resolve, and the decision likely becomes `go` or `no_go`.
- A sanitized dbt lineage graph or project overview → R5 to `high`.
- A sanitized Great Expectations suite excerpt → R8 to `high`.
- An Airflow DAG excerpt → R7 to `high`.
- A pipeline diagram or connector list for app or CRM ingestion → R9 resolves or firms up.
- A contract doc, schema agreement or blocking test → R10 resolves or firms up.
- The hiring manager's name → role reality's scope read and which story the plan leads with.
- A deeper research pass on Pellucid Learning (funding and leadership changes, hiring patterns, public employee reports, recent news; up to 5 more searches and 2 more fetches) → RR4 and the register firm up. Say the word and it runs.

## Questions

G1: Are you in the US (or able to work from Denver), and does $148,000–$166,000 clear your pay floor?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G3: Have you built or owned ingestion from product or CRM sources into your warehouse? What did you own, and what tools did you use?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G4: Did you agree schema, freshness or quality expectations with the analysts who used your models, and did any test ever block a load?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.