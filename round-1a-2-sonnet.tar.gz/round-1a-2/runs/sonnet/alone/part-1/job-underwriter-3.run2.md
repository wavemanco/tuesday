I'm writing up the assessment now. Both web searches were refused for lack of permission, so it runs on the posting and your background alone.

# Decision snapshot

**No, this posting isn't worth pursuing. R1 and R2, both hard gates, fail on the posting's own terms. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (Compensation: $70–85k base), R2 (On-site in our Austin office 5 days a week)
- `must_have`: direct: R3, R4, R5
- `important`: unclear: R6 (SEO/content), R7 (brand, PR, partnerships), R8 (sales ops), R9 (a team of one to start)

R1 and R2 — failed on the posting's own terms, nothing in the evidence moves them; R3 (`medium`) — 9 years against "8+", leadership split not yet dated; R6, R7, R8, R9 — unestablished, and moot while the gates stand.

**Opportunity ledger.** The role bundles seven functions into one title with no team (RR2), the base is low for that scope (RR3), and the evenings-and-weekends and "metrics will evolve" language leaves the load and the definition of success open (RR4, RR5). The employer is also unverified (RR6). Against that, the reporting line is explicit (RR7).

- **Hard gates:** failed: R1 (Compensation: $70–85k base), R2 (On-site in our Austin office 5 days a week).
- **Severe red flags:** none found.
- **What would change this:** a base of $150k or more (R1) and a remote arrangement (R2), both changed by the employer, or you revising either non-negotiable. Wording on your side can't close either gate. Without both, you would be spending effort on a role you can't take.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD header, as claimed by the posting; not verified (RR6) |
| Mandate | Own all revenue growth end to end: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Reporting | CEO, with a dotted line to the board | `[grounded]` JD |
| Resources | A team of one to start; no budget, headcount plan or tooling stated | `[grounded]` JD for team of one; `[inferred]` that the budget is unstated from the JD's silence |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside"; no equity figure | `[grounded]` JD |
| Scope read | Seven functions with a team of one is a bundle of several roles under one "Head of" title | `[inferred]` from the function list against the stated headcount |
| Market calibration | Roles that own this many channels at head level generally pay well above this band. No sweep ran, so no figure is given | `[generic]` pattern, unquantified because search was refused |
| First 90 days / first year | Not stated; "success metrics will evolve" | `[grounded]` JD |
| Unknowns | Equity size and vesting, budget, hiring plans, what "success" means, who the CEO is | `[grounded]` JD silence |
| Contradictions | "Head of" with no one to lead, and a Series A company paying a base well under what the seniority requirement implies | `[inferred]` from the title and pay against the stated scope |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Compensation: $70–85k base | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your floor, which is your own and specific. The fit fails because the top of the band is $65k below it | `[grounded]` JD figure against your stated floor | Surface only; the employer or you changing terms is the only resolution |
| R2 | On-site in our Austin office 5 days a week, no exceptions | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your remote-only, Portland, no-relocation constraint. The fit fails because the posting rules remote out in terms | `[grounded]` JD quote against your stated constraint | Surface only; the employer or you changing terms is the only resolution |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | 9 years in growth, rising from growth lead to Head of Growth. The leadership-only years aren't dated, so `medium`, and a screen may count only the titled years | `[grounded]` your background, self-reported; `[generic]` that titled years are often screened literally | Date the lead and Head titles |
| R4 | Paid acquisition | must_have | direct | medium | none | Owned paid at two B2C subscription companies, with a budget you controlled during the $8M to $40M ARR scale-up. Confirmed and specific, with no inspectable artifact yet | `[grounded]` your background | A channel P&L or spend and ROAS summary would raise it |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | Owned lifecycle, with Braze named | `[grounded]` your background | A sanitized lifecycle program summary would raise it |
| R6 | SEO/content | important | unclear | low | discovery | Your background says nothing on SEO or content ownership | `[grounded]` silence in your background | See G1 |
| R7 | Brand, PR, partnerships | important | unclear | low | discovery | Your background names none of the three | `[grounded]` silence in your background | See G1 |
| R8 | Sales ops | important | unclear | low | discovery | Your experience is B2C subscription, and sales ops implies a sales-led motion. No evidence either way | `[inferred]` from the B2C background against the role's function list | See G2 |
| R9 | A team of one to start | important | unclear | low | discovery | You have led teams of 3–7. Working solo across seven functions isn't evidenced, and it's the opposite of how you've worked | `[grounded]` your background | See G3 |

## Gap recovery queue

All four rows below are moot while R1 and R2 stand. They matter only if the gates move.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content, brand, PR, partnerships (R6, R7, important) | discovery | Nothing in your background establishes any of the four | At a team of one, these would sit with you rather than with specialists | Owning an SEO or content program, a partner or affiliate channel, a PR push or a brand launch, even at small scale | A traffic or ranking report, a partner agreement, a launch brief | `[grounded]` silence in your background |
| G2 | Sales ops (R8, important) | discovery | B2C subscription background, with no sales-led motion stated | The posting may assume a B2B or marketplace sales motion | Building a lead-routing or CRM pipeline, or sales reporting | A pipeline dashboard or an ops process doc | `[inferred]` from the B2C background against the JD's sales ops line |
| G3 | Solo execution across channels (R9, important) | discovery | Your record is leading teams of 3–7, with no early solo stretch stated | The role is described as one person to start | An early role where you ran several channels yourself | A dated early-role summary | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting terms conflict with your pay floor and remote-only constraint (R1, R2) | red_flag | medium | "$70–85k base" and "On-site in our Austin office 5 days a week — no exceptions" | A red flag for you specifically because both terms conflict with non-negotiables you stated. Severity is held at medium because this says nothing about the employer's conduct | `[grounded]` JD terms against your stated constraints | Is the base negotiable above $85k, and is any remote arrangement possible for this role? | confirmed |
| RR2 | Bundled specializations with no team | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" and "a team of one to start" | Several full roles folded into one title, with no stated support | `[inferred]` from the function list against the stated headcount | What budget, tools and hires are committed for the first year? | unresolved |
| RR3 | Seniority-compensation mismatch | risk_signal | medium | "8+ years growth leadership required" and "$70–85k base" | The base may sit well below what that seniority and mandate command; unquantified without a salary sweep | `[generic]` pattern; no sweep ran | What is the total compensation, and how is the equity sized and vested? | unresolved |
| RR4 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Open-ended after-hours load, paired with a low base | `[inferred]` from the JD's wording | What does a typical week look like, and how often do evenings and weekends come up? | unresolved |
| RR5 | Absent success metrics on a demanding mandate | risk_signal | low | "success metrics will evolve as we learn" | Accountability for all revenue growth with no stated definition of success | `[inferred]` from the JD's wording | What would success look like at 6 and 12 months, and who decides? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small for a footprint, the posting may be stale, or it may not represent a real hiring employer. The search was refused, so no attribution was attempted | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR7 | Clear reporting line | positive_signal | — | "Report to the CEO with a dotted line to the board" | The role has real seniority access | `[grounded]` JD | Who in the board does the dotted line reach, and how often? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply on the current terms | R1 and R2 fail; no CV edit changes that | `[grounded]` R1, R2 rows | pending your approval |
| A2 | Only if you want to test whether terms can move: one email to the recruiter or CEO asking RR1's question before any other effort | A move on pay and location would reopen the decision; silence or a refusal closes it | `[grounded]` RR1 | pending your approval |
| A3 | If A2 reopens the role, ask RR2, RR3, RR4 and RR6 verbatim before investing in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Series A Head of Growth"; refused for lack of permission. It would have moved role reality's organization and contradictions rows and RR6 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth startup salary range base compensation 2026 Series A"; refused for lack of permission. It would have moved the market calibration line and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

The posting stays a provided document, and the rows labeled `[generic]` mark where research would have replaced a pattern.

If you'd like a `tuesday-dossier.md` of this assessment to keep, I can write one.

**Upgrade menu**

- Permission to run the web searches → role reality's organization and market calibration, and RR3 and RR6, move from `[generic]` to sourced.
- A dated list of your lead and Head titles → R3 moves toward `high`.
- A channel P&L or spend summary, and a sanitized lifecycle program summary → R4 and R5 move to `high`.
- Any SEO, content, brand, partnership or sales ops work you've done → G1 and G2 close and R6, R7 and R8 get graded.
- The recruiter's answer on pay and remote → R1 and R2 close, and the decision moves from `no_go`.

No questions this turn: neither gate is uncertain, and nothing I could ask would change `no_go`.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.