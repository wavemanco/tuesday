I'll read the reference files the skill points to before building the assessment.
Web search wasn't permitted in this session, so this assessment uses only what you pasted, and the Evidence status table shows what that did to each research target.

## Decision snapshot

**Yes, apply, on the conditions below. Status: `conditional_go`.** Pet insurance is R8, a `preferred` row at `adjacent`. People management has no row in the map, because the JD names no line-management requirement.

**Fit ledger.**

- `hard_gate`: unclear: R9 (Fully remote (UK) role)
- `must_have`: direct: R1, R2, R3, R4b, R5 · unclear: R4a (Design price tests)
- `important`: adjacent: R6 (Recommendations for underwriting and product)
- `preferred`: direct: R7 · adjacent: R8 (Pet-insurance domain)

R4a: "ran" the tests doesn't say you designed them. R6: the underwriting audience is evidenced and the product audience isn't. R8: a credible bridge, its limit named.

**Opportunity ledger.** The scope is clearly stated (RR4). The employer is unverified (RR1), pay is withheld (RR2), and team and resources are unstated (RR3).

- **Hard gates:** none failed; unconfirmed: R9 (Fully remote (UK) role); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. You confirm you're UK-based and eligible to work there without sponsorship (R9).
  2. The employer and live posting verify on Brindlemoor's own careers site (RR1).
  3. The pet-insurance bridge is framed as adjacent, never as pet-insurance experience (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; its existence and the live posting are not yet checked | `[grounded]` JD header and your message |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing; public footprint not researched | `[grounded]` your message |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| People management | The JD lists no direct reports and no line-management requirement | `[grounded]` JD text |
| First-year outcomes | Not stated in the JD | `[grounded]` JD silence |
| Scope read | One product's pricing analytics under a Director; whether it is a sole-analyst seat or part of a team is not stated | `[inferred]` from "own pricing analytics for our pet-insurance product" against the JD's silence on team |
| Market calibration | Not available: the role-family sweep did not run, so there is no band for title, scope or pay | `[grounded]` the sweep target in Evidence status reads `unavailable` |
| Unknowns | Salary; team size and tooling; whether any reports sit under the role; employer verification | — |
| Contradictions | None between the JD and your account; nothing checked against the careers page | `[grounded]` the two inputs compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. A years requirement is graded on evidence, not treated as a gate. Typed prose with no artifact caps the band at `medium` | `[grounded]` your background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily"; confirmed but nothing inspectable yet | `[grounded]` your background | offer: a sanitized query or notebook would raise to high |
| R3 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. "Maintained" is not stated to include monitoring, which the JD names, so the claim stays at what you said | `[grounded]` your background | offer: a sanitized model-methodology note would raise to high |
| R4a | Design price tests | must_have | unclear | low | discovery | You "ran 14 price tests last year with the underwriting team". That does not say whether you set the hypotheses, sample and success metric, so the claim resolves downward | `[grounded]` your background; `[inferred]` that design ownership is unconfirmed | see G1 |
| R4b | Read price tests | must_have | direct | medium | none | Running 14 tests plausibly includes reading their results. The limit is that your own role in the readouts is unstated | `[inferred]` from "ran 14 price tests" | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R6 | Turn results into recommendations for underwriting and product | important | adjacent | low | discovery | The underwriting audience is evidenced through the quarterly review and the tests run with underwriting. No product-facing work is mentioned, and the content of your recommendations is not stated | `[grounded]` your background; `[inferred]` that product-facing work may exist but is unmentioned | see G2 |
| R7 | Insurance experience a plus | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background | none |
| R8 | Pet-insurance domain (the product the role owns; the JD asks only for "insurance experience") | preferred | adjacent | medium | transferability | Carries over: a GLM rating model on a segmented personal-lines book. Limit: none of your work touched pet rating. Pet rates are usually built on different factors from motor (species, breed, age, cover level), which has to be learned | `[grounded]` your statement that you have never worked on pet insurance; `[generic]` that pet and motor rating factors differ | see G3 |
| R9 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | Nothing in your message states where you are based or whether you need sponsorship. Confidence is `none` because there is no stated constraint to grade. Working at a UK insurer does not settle right to work | `[grounded]` JD quote and your message's silence | confirm UK location and right to work (question R9) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Design of price tests (R4a, must_have) | discovery | "Ran 14 price tests with the underwriting team", with no statement of which parts were yours | The JD pairs "design" with "read". Which one is true decides whether you lead with it or carry it as a probe | Choosing test and control cells or sample size; setting the success metric; deciding to stop or roll out; writing the readout | A sanitized test plan, a readout deck, or a results summary | `[grounded]` your wording; `[generic]` that interviews for this kind of seat probe test design |
| G2 | Recommendations to underwriting and product (R6, important) | discovery | The quarterly review to the head of underwriting is evidenced. A product audience is not | The JD names product as a recipient, and the gap is cheap to close if it exists | A test or model result you took to a product or proposition team; a pricing change you recommended that shaped a product decision | A sanitized recommendation note or review slide | `[grounded]` your background; `[inferred]` that product-facing work may exist |
| G3 | Pet-insurance domain (R8, preferred) | transferability | A motor GLM rating model, with no pet-specific work | A `preferred` row, so a minor risk rather than a blocker | Any pet, travel, home or other non-motor rating work; any reading you have done on how pet pricing differs | A one-page note listing which of your model's rating factors carry over to pet and which would be new. It is a work sample and needs your approval | `[inferred]` bridge derived from your GLM work; `[generic]` that pet rating uses different factors |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified: no check ran | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated, so nothing to set against your floor or a market band | unknown | — | JD gives no salary figure | The figure may be unpublished, or may sit below what a senior role in this family pays | `[inferred]` from the JD's silence; no band was available to compare | What is the salary range for this role? | unresolved |
| RR3 | Team, tooling and reporting line unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Own" may mean sole analyst without data-engineering or model-deployment support | `[inferred]` from the JD's scope wording against its silence on resources | Who else is on the pricing team, what data and deployment support does this role have, and does it carry any direct reports? | unresolved |
| RR4 | Responsibilities specific and ordered | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations for underwriting and product" | The scope reads as a defined remit | `[grounded]` JD states each activity | What would a successful first year look like? | noted |

## Application plan

All rows below are proposed language or actions, `pending your approval`; nothing is final until you approve it. Each line is traced to your own sentences.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume line: "Built and maintained the GLM rating model for the young-driver book at a UK motor insurer." | R3 | `[grounded]` your sentence on the GLM model | resume_edits_pending_approval |
| E2 | Resume line: "Ran 14 price tests with the underwriting team (add the year)." Do not write "designed" until G1 is answered | R4a, R4b | `[grounded]` "ran 14 price tests" | resume_edits_pending_approval |
| E3 | Resume line: "Present the quarterly pricing review to the head of underwriting." | R5 | `[grounded]` your sentence on the review | resume_edits_pending_approval |
| C1 | Cover-note framing: "My pricing work has been at a motor insurer; I haven't worked on pet insurance." Say it plainly rather than hide it | R8 | `[grounded]` your two statements | pending your approval |
| C2 | If asked about managing people, say you haven't line-managed anyone. Don't offer unprompted "mentoring" or "team leadership" language | the JD names no line-management requirement | `[grounded]` "I've never managed anyone"; JD text | pending your approval |
| Q1 | Ask the register's verification questions (RR1 to RR4) verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Verify the employer and posting on Brindlemoor's own careers site before investing in the loop | RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search for Brindlemoor's careers page was refused (permission not granted). It would have fed role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | The search for senior pricing analyst, pet insurance, UK pay and remote norms was refused. It would have fed the market calibration row and a pay comparison for RR2 |
| 3. Hiring manager's public footprint | unavailable | The search for Odile Varga's public professional footprint was refused. The name was given, so a query could be formed. It would have fed the scope read and which story the plan leads with |

## Closing

I can save all of this as `tuesday-dossier.md` if you want a file to keep.

**Upgrade menu**

- Search permission: the three targets above would run. That could clear RR1, add a pay band for RR2, and show what Odile Varga's public work suggests about positioning.
- A sanitized test write-up or readout: R4a and R4b rise, G1 closes.
- A sanitized SQL or Python sample, or a model-methodology note: R2 and R3 rise to `high`.
- A recommendation note that went to a product audience: G2 closes, R6 rises.
- Your pay floor, notice period and any other non-negotiables: the hard-gates line gets checked against your constraints and RR2 gets a comparison.
- The recruiter's email domain or a link to the live posting: RR1 can close.

**Questions**

1. R9: Are you UK-based and eligible to work for a UK employer without sponsorship?
2. G1: Of the 14 price tests, which parts did you personally own: the hypothesis and design, the sample and control choices, the readout? Who decided on rollout?
3. G2: Have you taken a test or model result to a product or proposition team, not just underwriting, and what changed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.