I'll read the reference files before building the assessment.
Research is done: the careers page, a pay survey and Odile Varga's public profile. The assessment is below.

# Job Underwriting Assessment: Senior Pricing Analyst, Brindlemoor

## Decision snapshot

**Yes, apply, with one condition on where the job is actually based. R1 (the working pattern) is unresolved. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5, R7, R8a, R9 · unclear: R6 (Monitor rating models), R8b (Recommendations to product)
- `important`: adjacent: R10 (Pet-insurance domain)
- `preferred`: direct: R11

R1: the posting and the careers page disagree on remote; R6 (`low`): "maintained" is not "monitored"; R8b (`none`): no product-facing evidence yet; R10: a bridge, its limit named.

**Opportunity ledger.** The role is live and consistent with the employer's own careers page on product and reporting line (RR4). Against that, the working-pattern terms contradict each other (RR1), pay is withheld (RR2), and whether the role has direct reports is unstated (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The working pattern is confirmed and acceptable to you (R1, RR1).
  2. You can say concretely what monitoring work sat behind "maintained" (R6).
  3. The pet-insurance bridge is framed as adjacent, never as pet experience (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. The careers page lists this role, so the employer and the posting are real. Stage and size are not established | `[grounded]` JD header; careers page fetched |
| Mandate | Own pricing analytics for the pet-insurance product: rating models, price tests, recommendations to underwriting and product | `[grounded]` JD; careers page |
| Reporting line | Reports to the Director of Pricing, Odile Varga, who is also the hiring manager | `[grounded]` careers page; JD |
| Working pattern | The JD says fully remote (UK). The careers page says "Leeds office four days a week". The two contradict each other | `[grounded]` JD and careers page fetched |
| Hiring manager | Odile Varga spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors", about monitoring rating models in small books. Previously head of pricing analytics at Calloway Re for six years | `[grounded]` search result for their public profile; page not opened |
| Scope read | One product with model, test and recommendation duties. Whether a team sits around it is unknown | `[inferred]` from the JD's single-product scope and its silence on reports |
| Market calibration | UK senior pricing analyst at insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900. The posting withholds pay, so this is a band to expect, never Brindlemoor's offer (RR2) | `[generic]` Pricewell 2026 pay survey, search result only, page not opened; `[grounded]` JD states no salary |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Unknowns | Salary; direct reports and team shape; stage and size; first-year outcomes | — |
| Contradictions | Remote versus Leeds office four days a week (RR1) | `[grounded]` JD against careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You have not stated a location or working-pattern constraint, so there is nothing to grade. The role's own terms conflict between the JD and the careers page | `[grounded]` JD against careers page; no candidate statement | Closing question G1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | "5 years pricing analytics at a UK motor insurer", self-reported, no inspectable artifact yet | `[grounded]` your background, prose intake | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily", self-reported | `[grounded]` your background | A sanitized query or notebook would raise it to `high` |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. It is motor, which does not change that it is GLM work | `[grounded]` your background | A model documentation excerpt would raise it to `high` |
| R5 | Build rating models | must_have | direct | medium | none | Same evidence as R4: you built the young-driver GLM. The JD says "rating models" and you named one model | `[grounded]` your background | none |
| R6 | Monitor rating models | must_have | unclear | low | discovery | You said "maintained". That is not monitoring, and ambiguity resolves downward. The hiring manager's public talk is about monitoring, so a probe is likely | `[grounded]` your wording; `[inferred]` that a probe follows from the talk topic | Closing question G2 |
| R7 | Design and read price tests | must_have | direct | medium | discovery | "Ran 14 price tests last year with the underwriting team." Reading results is plausible, but whether you designed them is not stated | `[grounded]` your background | Carried, not asked this turn (G5) |
| R8a | Turn results into recommendations for underwriting | must_have | direct | medium | none | Tests run with the underwriting team, and you present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R8b | Turn results into recommendations for product | must_have | unclear | none | discovery | Nothing in your background touches a product team | `[grounded]` background silent | Closing question G3 |
| R9 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. An actuarial audience is not mentioned | `[grounded]` your background | none |
| R10 | Pet-insurance product domain (implied by the role) | important | adjacent | medium | transferability | The JD does not demand pet experience, but the role is pet pricing. Your motor GLM work carries over. Limit: you have not worked on pet claims or pet-specific rating factors | `[grounded]` your background; `[generic]` that pet pricing commonly rates on different factors from motor | See G4 |
| R11 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | JD says fully remote; careers page says Leeds four days a week; your needs not given | A term, so wording cannot fix it. If you need fully remote and the job is office-based, the status becomes `no_go` | Not applicable | The recruiter's written confirmation of the working pattern | `[grounded]` JD and careers page; `[inferred]` that it could flip the status |
| G2 | Monitoring (R6, must_have) | discovery | CV language is "built and maintained"; nothing says what was checked or how often | A `must_have` row, and the hiring manager publicly speaks on monitoring | Regular actual-versus-expected checks on the live model; segment or drift tracking; a refit trigger; a report others read | A sanitized monitoring pack or dashboard screenshot | `[grounded]` your wording; `[generic]` examples |
| G3 | Product recommendations (R8b, must_have) | discovery | Underwriting-facing work only | A `must_have` row with no evidence at all | A test result taken to a product or proposition team; pricing input to a product or cover change | A deck or email excerpt, sanitized | `[grounded]` background silent; `[generic]` examples |
| G4 | Pet domain (R10, important) | transferability | Adjacent motor GLM work; limit as in R10 | Likely the first objection raised | A frequency and severity model structure you could map across | A one-page note on how your motor model structure would carry to pet | `[inferred]` bridge from your motor GLM; `[generic]` likeliest objection |
| G5 | Test design ownership (R7, must_have) | discovery | "Ran" is stated; designing is not | Distinguishes running tests from owning them | Choosing the split or sample, setting the success metric, deciding when to stop | A test design note | `[grounded]` your wording; `[generic]` examples |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts across sources (R1) | risk_signal | medium | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | One source may be out of date, or the role may have changed. Which is current is not established | `[inferred]` from two sources disagreeing | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Pay withheld | unknown | — | The JD states no salary | The offer may sit anywhere against the survey band in role reality | `[inferred]` from the withheld figure against the `[generic]` band | What is the salary range for this post? | unresolved |
| RR3 | Reports and team scope unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Own" could mean sole analyst on the product or lead of a team. The JD is silent | `[inferred]` from the JD's wording and silence | Does this role have direct reports, now or planned, and who else sits in the pricing team? | unresolved |
| RR4 | Posting is live and consistent on role, product and reporting line | positive_signal | — | "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing." | The role is a real, currently open post | `[grounded]` careers page fetched | What would a successful first year look like in this role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern with the recruiter or Odile Varga before investing in the loop | See R1, RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Surface three existing facts as top lines on your CV: the GLM build, the 14 price tests, the quarterly review. Drafts are in the block below | See R4, R5, R7, R9 | `[grounded]` your background | pending your approval |
| P1 | Prepare your honest account of what "maintained" involved on the young-driver model, since Odile Varga's public talk is on monitoring | See R6, G2 | `[inferred]` from the talk topic; `[grounded]` the talk | pending your approval |
| P2 | Frame pet insurance as adjacent: "I have built and maintained a GLM rating model on motor. I haven't worked on pet pricing" | See R10 | `[grounded]` your background | pending your approval |
| Q1 | Ask RR1 to RR4's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

`resume_edits_pending_approval`. These use your own words and add no outcome figures, since you gave none:

- "Built and maintained the GLM rating model for the young-driver book at a UK motor insurer."
- "Ran 14 price tests last year with the underwriting team." Swap "last year" for the calendar year.
- "Present the quarterly pricing review to the head of underwriting."

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst" and fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Confirmed the employer and the live post, and surfaced the Leeds contradiction (RR1, R1) |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Gave the market calibration `[generic]` band (RR2) |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). Moved role reality's hiring-manager row and plan row P1 |

If you'd like, I can write all of this to `tuesday-dossier.md`.

## Upgrade menu

- Your location and working-pattern needs, plus your pay floor → R1 and RR1 become a firm met or failed gate. A floor also lets RR2 be checked against the band.
- A sanitized monitoring pack or dashboard → R6 rises, and P1 becomes a concrete story.
- A model documentation excerpt or a sanitized query or notebook → R3 and R4 rise to `high`.
- A test design note → R7's gap closes (G5).
- The salary range → RR2 closes.
- Deeper company diligence and a news sweep on Brindlemoor (funding, leadership churn, stage and size; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

1. **G1 (R1):** Is working from the Leeds office four days a week acceptable to you, or do you need fully remote?
2. **G2 (R6):** What did "maintained" the young-driver GLM involve? Did you track actual against expected, watch drift, or decide when to refit, and was any of it written up?
3. **G3 (R8b):** Have you ever taken a price-test result to a product or proposition team? If so, what did you recommend and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.