Checking the pasted careers and about pages against the live site, then I'll write the assessment.
**Yes, it's worth applying, with conditions. Status: `conditional_go`.** Your core stack matches the JD on every tier-one requirement. The one thing I can't confirm is your location and US work authorization, because you haven't given me any constraints.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (US-based remote or Denver office)
- `must_have` — direct: R2, R3, R4, R5, R7, R8
- `important` — adjacent: R6 (BigQuery specifically); unclear: R9 (ingestion from app and CRM), R10 (data contracts for analysts)

R6 — a credible bridge, its limit named (no BigQuery use); R9, R10 — your account is silent on both.

**Opportunity ledger.** The employer matches its own pages and the pay is disclosed (RR1, RR2). Three things are open: equity terms (RR3), team size and reporting line (RR4), and who the manager is.

- **Hard gates:** none failed; unconfirmed: R1 (US-based remote or Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 is confirmed; (2) the BigQuery bridge is framed as adjacent and never as BigQuery experience (R6, G1); (3) team size and scope check out in the interviews (RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` About page fetched |
| Mandate | Build and run the reporting pipelines: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD, careers page fetched |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| First-year outcomes | Not stated in the posting | `[grounded]` JD silence |
| Scope read | Ownership of the reporting pipeline from ingestion to contracts. The JD names no team, no direct reports, and no hiring manager | `[inferred]` from the mandate wording against the JD's silence |
| Market calibration | Posted range $148,000–$166,000. The report's median is $151,000 with an interquartile range of $139,000–$163,500. The posted low end sits below that median and the top sits above the interquartile range. "Senior" there typically means 5–8 years and one domain's pipelines with no reports | `[grounded]` JD figures and the pay report you pasted (source not independently checked); `[generic]` that the report describes Series B–D companies, not this employer's offer |
| Unknowns | Equity terms, team size and reporting line, where in the range an offer lands, how BigQuery experience is weighted | — |
| Contradictions | None between your pasted text and the live pages | `[grounded]` both pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Based in the US (remote) or Denver office | hard_gate | unclear | none | hard_gate | You haven't stated your location or work authorization, so there is no claim to grade and the fit is unestablished | `[grounded]` JD; your constraints not given | Question R1 below |
| R2 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. Confirmed and specific, but no inspectable artifact | `[grounded]` your statement | A CV with dates would be enough |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated. Strength is shown by what you built, not by the claim | `[grounded]` your statement | A code or SQL sample you can share would raise it to `high` |
| R4 | dbt | must_have | direct | medium | none | You built the project, about 180 models, which is a specific and plausible scale | `[grounded]` your statement | A sanitized dbt docs or lineage page would raise it to `high` |
| R5 | A cloud warehouse | must_have | direct | medium | none | Snowflake satisfies "a cloud warehouse" as the JD words it | `[grounded]` your statement | None |
| R6 | BigQuery specifically | important | adjacent | medium | transferability | Snowflake plus dbt carries over: SQL, modelling, warehouse concepts. Limit: you have never used BigQuery, so its cost model, partitioning and clustering, and permission model are unexercised. The posting names BigQuery in the mandate but not in its requirements list | `[inferred]` from the mandate wording; `[generic]` that warehouse skills usually transfer, which is a pattern and not a claim about this team | G1 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow named directly | `[grounded]` your statement | None |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. That shows setup, and I haven't claimed ongoing ownership | `[grounded]` your statement | A sanitized test-suite summary would raise it to `high` |
| R9 | Ingestion from an app and a CRM | important | unclear | low | discovery | The mandate names these sources. Your account doesn't say which sources fed your payroll pipelines | `[inferred]` from the mandate, not a posted requirement | G2 |
| R10 | Data contracts analysts rely on | important | unclear | low | discovery | The mandate names contracts. Nothing you've said covers contracts or analyst-facing guarantees | `[inferred]` from the mandate, not a posted requirement | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6, important) | transferability | Snowflake and dbt experience, no BigQuery use | The role is built on BigQuery, so it is the likeliest objection | Any BigQuery use in a side project, a migration evaluation, a read-only analyst role, or a certification | A small dbt project running on BigQuery's free tier, or a short comparison note | `[inferred]` bridge from stated experience; `[generic]` that this is the likeliest objection |
| G2 | App and CRM ingestion (R9, important) | discovery | Your sources are not described | Fit with the pipeline mandate turns on this | Event or product data, CRM exports such as Salesforce or HubSpot, API ingestion, CDC or webhook feeds | A sanitized DAG screenshot or source list | `[grounded]` your account's silence; `[inferred]` that the mandate stresses it |
| G3 | Data contracts (R10, important) | discovery | Not covered | The JD names contracts as something analysts depend on | Schema or freshness guarantees to analysts, dbt contract or test enforcement, agreed SLAs, change notification | A contract doc, dbt model YAML, or an SLA note | `[grounded]` your account's silence; `[inferred]` that the mandate stresses it |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer matches its own pages | positive_signal | — | "Series C ($52M, February 2026)" | The company exists as described and the posting is live | `[grounded]` careers and About pages fetched. These are the company's own statements, so the funding figure is not independently verified | What is the current size of the data team and its roadmap for this year? | noted |
| RR2 | Pay disclosed and in range | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is transparent and in line with the pay report's band | `[grounded]` JD and the report you pasted | Where in the range does this role sit, and does the range differ by location? | noted |
| RR3 | Equity unspecified | unknown | — | "plus equity" | The grant size, vesting and valuation basis may vary widely or be thin | `[generic]` that a Series C company's equity terms can't be judged from a posting; no claim about this employer | What is the grant size, vesting schedule and latest valuation basis? | unresolved |
| RR4 | Team size and reporting line unstated | unknown | — | "Build and run the pipelines" | The role may be the sole data engineer, or part of a team. The JD gives no signal | `[inferred]` from the posting's silence, not from any observed pattern | How many data engineers are on the team, who would I report to, and who sets priorities? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with "built a dbt project of about 180 models on Snowflake" and "set up a Great Expectations test suite". Use no wording that implies BigQuery use, ownership of a team, or ongoing ownership of the suite | R4, R8 | `[grounded]` your statements | pending your approval |
| E2 | State the BigQuery gap openly and early, with the Snowflake bridge, instead of letting a screener find it | R6 | `[grounded]` your statement; `[inferred]` the framing | pending your approval |
| W1 | Optional: a small dbt-on-BigQuery project to narrow the gap | G1 | `[inferred]` | pending your approval |
| Q1 | Ask RR1, RR2, RR3 and RR4's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Everything above, the prose advice included, is proposed language and actions only, and none of it is final until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer) and "About Pellucid Learning" (pellucidlearning.com/about) to check your pasted text against the live pages. Both match word for word and the posting reads as live. This moved the contradictions row and RR1 |
| 2. Role-family sweep | skipped | The pay report you pasted already fixes the market calibration and the pay mismatch check, so no search could change them |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

## Upgrade menu

- A sanitized dbt docs or lineage page, a test-suite summary, or a code sample → R3, R4 and R8 to `high`.
- Your answers on G2 and G3 → R9 and R10 resolve, and the application plan gets sharper bullets.
- Your location and work authorization → R1 resolves. Your pay floor would then let me check the posted range against it.
- A hiring manager's name → role reality's scope read and which story the plan leads with.
- A deeper research pass on Pellucid Learning (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) → RR1 gets independent confirmation. Say the word and it runs.
- I can draft the application materials from E1 and E2 once you approve them. That goes beyond the assessment, so I haven't started it.

I'd like to dossier this into `tuesday-dossier.md` for later turns whenever you want it.

**Questions**

R1 — Are you based in the US, or able to work from Denver, and do you have US work authorization without sponsorship?

G2 — Which sources fed your payroll pipelines (app events, CRM, third-party APIs), and did you own ingesting any of them?

G3 — Have you set schema, freshness or quality guarantees that analysts relied on, and how were they enforced?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.