Loading the underwriting references is done; now I'm running the company and role-family research before writing the assessment.
## Decision snapshot

**Not a waste of time as a pivot, but this posting is a stretch on its lead requirement: R1 (3+ years product management experience) is `adjacent`, not met. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3, R4 · adjacent: R1 (3+ years product management experience), R2 (shipped API or platform products) · unclear: R5 (agile delivery)
- `important` — direct: R7 · adjacent: R6 (roadmap ownership), R8 (specs and delivery with two squads) · unclear: R9 (adoption metrics), R10 (launches with sales and support)

R1 — no PM title, and it is the posting's first must-have; R2 — you implemented APIs, and owning one is not yet evidenced; R5 — the résumé is silent on agile.

**Opportunity ledger.** Thin but legible. The employer could not be checked (RR1), pay is unstated (RR2), success measures are unstated (RR4), and whether the hiring bar flexes on PM tenure is unknown (RR5). One entry runs the other way: scope is concrete (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the hiring side confirms it considers candidates without a PM title (R1, RR5); (2) the employer verifies as described (RR1); (3) you can show at least one case where you decided what got built (R6, R9, G1), or the posting stays a long shot; (4) you frame the story as adjacent, never as PM tenure.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header as pasted; existence not verified (RR1) |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | One product surface with two squads: a bounded single-platform PM role, not a head-of-platform role | `[inferred]` from "two engineering squads" and one named platform |
| Market calibration | Not established. The role-family sweep did not run, so no pay or title band is offered | `[grounded]` search refused, see Evidence status |
| Unknowns | Pay; decision rights over pricing, deprecations and partner commitments; baseline adoption numbers; reporting line | — |
| Contradictions | None found within the pasted JD. The careers-page check did not run | `[grounded]` JD as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management experience | must_have | adjacent | medium | transferability | Seven years working beside PMs and feeding roadmap input is real adjacency. You hold no PM title, and nothing yet shows you decided what got built. Limit: a screen that reads "3+ years PM" literally would not count it | `[grounded]` your stated history, no PM title; `[generic]` that titled-tenure requirements are often screened literally | RR5 question first; G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ end-to-end integrations of your vendor's REST APIs and wrote the playbook the team uses, so you know the API from the consumer side. Limit: owning an API's roadmap, versioning or deprecation is not evidenced | `[grounded]` your stated work | G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI reading and integration architecture across 30+ integrations. The playbook has not been inspected, so `medium` | `[grounded]` your stated work | a sanitized playbook excerpt would raise to `high` |
| R4 | Stakeholder management across engineering and customers (sales is R10) | must_have | direct | medium | none | You coordinated your engineers, the client's engineers and PMs, and ran client workshops through UAT and go-live | `[grounded]` your stated work | none |
| R5 | Experience with agile delivery | must_have | unclear | low | discovery | The résumé names scoping, UAT and go-live but no delivery method, sprints or backlog work | `[grounded]` résumé silence | G2 |
| R6 | Own the roadmap | important | adjacent | medium | transferability | Quarterly roadmap-input sessions put client feedback in front of product. Collecting input is not setting priorities. Limit: prioritisation and saying no are not evidenced | `[grounded]` your stated work | G1 |
| R7 | Run discovery with integration partners | important | direct | medium | presentation | Scoping workshops and roadmap-input sessions with integrating clients are partner discovery in substance. The résumé likely files them under delivery | `[grounded]` your stated work | E1 pending your approval |
| R8 | Write specs and drive delivery with two engineering squads | important | adjacent | medium | transferability | Requirements documents and architecture for custom builds, coordinated with engineers. Limit: those served one client's build, not a standing squad's backlog | `[grounded]` your stated work | W1 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | No adoption metric appears in what you have stated. SQL ability is present. A prior-context lead (an internal tool support agents adopted) is unconfirmed | `[inferred]` from an unconfirmed `memory_lead`, not asserted | G3 |
| R10 | Coordinate launches with sales and support | important | unclear | low | discovery | Client go-lives are launch-shaped. Sales and support involvement is not stated | `[grounded]` résumé silence on sales and support | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ownership of what gets built (R1, R6, R2; must_have) | transferability | Strong adjacency; no instance where you chose between competing requests and owned the outcome | This is the objection R1 invites, and one real instance could shift the decision | An internal tool you scoped and shipped; deciding which client requests went to product and which didn't; a playbook change that altered how the team worked | A short write-up, usage numbers, a before and after, a spec | `[grounded]` the résumé shows inputs, not decisions; `[inferred]` from the unconfirmed triage-tool lead that an instance may exist |
| G2 | Agile delivery (R5, must_have) | discovery | Résumé silent on delivery method | A must-have row left at `unclear` | Working in sprints with client or vendor engineers; backlog grooming on custom builds; retros after go-lives | Any ticket board or sprint report you can sanitize | `[grounded]` résumé silence |
| G3 | Adoption metrics (R9, important) | discovery | SQL ability but no metric you defined or tracked | The role is partly measured on adoption | Usage or adoption figures for the playbook or an internal tool; client go-live success measures you defined | A dashboard screenshot, a query, a report | `[inferred]` from the unconfirmed lead; `[grounded]` the gap itself |
| G4 | Launches with sales and support (R10, important) | discovery | Client-facing go-lives, but no sales or support involvement stated | The JD names both as launch partners | Handoffs to support after go-live; enablement material for sales; escalation paths you set up | A handoff doc, runbook or training deck | `[grounded]` résumé silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | No pay figure appears in the posting as pasted | The posting may state pay elsewhere, or it may be withheld | `[inferred]` from absence in the pasted text | What is the budgeted range for this role? | unresolved |
| RR3 | Scope is concrete | positive_signal | — | "drive delivery with two engineering squads" | Two squads, one platform and named duties suggest a resourced, bounded role | `[grounded]` JD states it | Which decisions does this role make alone (pricing, deprecations, partner commitments) and which need approval? | noted |
| RR4 | Success measures left to the role | unknown | — | "define and track adoption metrics" | The PM may be asked to define success with no existing baseline | `[inferred]` from the JD asking the PM to define the metrics, not naming them | What does success look like at twelve months, and what adoption baseline exists today? | unresolved |
| RR5 | Whether the hiring bar flexes on PM tenure | unknown | — | "3+ years product management experience (must-have)" | The screen may be literal, or may flex for adjacent careers | `[generic]` hiring screens vary; not a claim about this employer | Have you hired into this role from solutions or implementation backgrounds, and what would you count as equivalent to three years of PM experience? | unresolved |

## Application plan

Everything below is proposed and pending your approval, the table and the advice around it alike. None of it is final résumé or outreach language, and any wording changes would be shown to you before use.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before a full application, ask the recruiter RR5's question. If titled tenure is strict, stop there | R1 is the lead must-have and carries the decision | `[grounded]` R1 and RR5 | pending your approval |
| A2 | Check the role on the company's own careers page and the recruiter's email domain | see RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Résumé: lead with the integration-platform outcomes, and give the roadmap-input sessions and PM coordination their own bullet in your existing wording. No PM title, and no "owned the roadmap" | see R6, R7 | `[grounded]` your stated work | pending your approval |
| W1 | A one-page sanitized brief: an API pain point seen across your integrations, the options, and what you'd prioritise. Draw it only from real work, and share it only if you approve it | see R2, R6, R8 | `[grounded]` R2, R6 and R8 rows | pending your approval |
| A3 | In parallel, consider PM or technical-product roles at your current vendor, where your integration record is already known | Internal moves are a common route for implementation staff | `[generic]` role-family pattern, not a claim about any employer | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: a prior-context mention of an internal request-triage tool that support agents adopted. It prompts G1 and G3 only and is not asserted anywhere above. Everything in the map comes from your own message. No artifact has been inspected.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Quartzline logistics technology company partner API platform" and "Quartzline Product Manager Platform APIs careers" were refused. It would have settled RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | The search "platform API product manager salary requirements transition from solutions engineer without PM title" was refused. It would have supplied market calibration, a pay band for RR2, and how often this title is hired from outside PM |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

I can write this up as `tuesday-dossier.md` if you want it saved. It is optional.

## Upgrade menu

- Search access, or the company's careers page link → RR1 resolves, and the market calibration and pay band come in.
- The recruiter's answer to RR5 → R1's weight becomes known, and the decision likely simplifies to `go` or `no_go`.
- An inspectable artifact: the playbook excerpt, a sanitized spec, or a usage report → R3 to `high`, and G1 or G3 narrow.
- The hiring manager's name → the scope read and which story to lead with.
- Your pay floor, location and other non-negotiables → the hard-gates line stops reading "unknown".

## Questions

G1, G3 — Did you build the internal request-triage tool I may have heard about, and if so, what did you personally decide, who used it, and how did you know it worked? If it isn't yours, is there another case where you chose what got built?

G2 — Did your integration or custom-build work run on sprints, boards or backlogs, and who prioritised them?

G4 — Did you hand go-lives to support or brief sales, and what did you produce for them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.