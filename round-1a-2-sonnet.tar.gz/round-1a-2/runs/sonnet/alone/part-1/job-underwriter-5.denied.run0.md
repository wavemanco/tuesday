I'll read the reference files the skill requires before building the assessment.
## Decision snapshot

**Yes, it's worth applying, on conditions · `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R7, R8
- `important`: adjacent: R6 (a dbt-modelled warehouse in BigQuery) · unclear: R9 (Ingestion from app and CRM), R10 (Data contracts analysts depend on)

R6 (`medium`): a credible bridge via Snowflake, with its limit named; R9, R10: your background says nothing either way yet.

**Opportunity ledger.** The stated pay sits across the report's median and above its interquartile top (RR3). The employer is not independently established from here (RR1). The reporting line is unnamed and the scope breadth is open (RR2, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The employer and the live posting are verified (RR1).
  2. You confirm you meet R1 and that R2's range clears your floor.
  3. BigQuery is framed as adjacent through Snowflake, never as BigQuery experience (R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; I could not check it independently (RR1) |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Stated requirements | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Terms | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` JD |
| Hiring manager | Not named in the posting | `[grounded]` JD |
| First-90-day and first-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | The JD lists three layers (ingestion, warehouse, contracts) and no direct reports. Whether that is one domain or a whole data platform depends on team size, which the posting doesn't give | `[inferred]` from the JD's three layers against its silence on team |
| Market calibration | For Senior Data Engineer at Series B–D companies, base median $151,000, interquartile range $139,000–$163,500. "Senior" typically means 5–8 years, with ownership of one domain's pipelines and no direct reports. The posting says "salary", and I have read it as base | `[grounded]` the Datawright 2026 report your recruiter sent (n=2,310); `[inferred]` that "salary" means base |
| Contradictions | None between the JD and the about text you pasted. I did not check either against the live site | `[grounded]` the two pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you live or whether you need sponsorship, and the JD says nothing on sponsorship. Confidence is `none` because no constraint of yours is on record | `[grounded]` JD text; your background states no location | Answer G4 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor wasn't given, so I can't say whether the range meets it | `[grounded]` JD text; your floor is unstated | Answer G5 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years of data engineering at a B2B payroll company. It is specific but unprobed, and I haven't seen a CV. Expect a probe on scope | `[grounded]` your prose background; `[generic]` that titled years are usually screened literally | Share your CV so I can check how it presents this |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You stated daily use of both. "Strong" is a level claim and nothing is inspectable yet | `[grounded]` your prose background | None for now |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built your company's dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse. Scale is stated, but there's no artifact | `[grounded]` your prose background | A sanitized model lineage graph or project structure would raise it to `high` |
| R6 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | The dbt work carries over. The limit: you have not used BigQuery, so its own cost model, partitioning and SQL dialect are unexercised. The JD does not list BigQuery in its requirements, only in the mandate | `[grounded]` your statement of no BigQuery use; `[generic]` that these are the areas a warehouse switch usually exposes | Bridge case in G1 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You stated Airflow for orchestration. What you personally authored versus inherited isn't stated | `[grounded]` your prose background | None for now |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up your company's Great Expectations test suite. No artifact yet | `[grounded]` your prose background | A sanitized expectation suite would raise it to `high` |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | The JD names these sources. Your background names no ingestion sources, and a payroll company's feeds may differ | `[grounded]` your background's silence on sources | Answer G2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | The JD names contracts as a deliverable. Your dbt models and Great Expectations suite are related, but you haven't said whether you agreed schemas or guarantees with analysts. I won't infer it | `[grounded]` your background's silence on contracts | Answer G3 when asked |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6, important) | transferability | Snowflake and dbt at about 180 models. No BigQuery use | It is the one named platform you haven't touched. The honest bridge is the dbt skill set, stated with its limit | Cost or performance tuning on Snowflake; partitioning-style design decisions; migrating or comparing warehouses | A small dbt project run against BigQuery's free tier would narrow the limit. Do it only if you want to | `[grounded]` your no-BigQuery statement; `[generic]` that a free tier exists and that small projects are a common bridge |
| G2 | Ingestion from app and CRM (R9, important) | discovery | The sources your pipelines pulled from are unstated | The JD's first-named responsibility | Pulling from a product database or event stream; syncing a third-party CRM or HR system by API; loading files or webhooks into the warehouse | An ingestion DAG, a connector config or an architecture sketch | `[grounded]` background silence; `[inferred]` that this is the first thing a screen will probe, from the JD listing it first |
| G3 | Data contracts (R10, important) | discovery | Nothing on analyst-facing guarantees | The JD frames contracts as a deliverable | Agreeing column definitions with analysts; tests that block a downstream model; freshness or schema-change rules | A `schema.yml` excerpt, a Great Expectations suite or a short contract doc | `[grounded]` background silence |
| G4 | Location and authorization (R1, hard_gate) | hard_gate | Not stated | The gate decides eligibility outright | n/a | Your answer alone | `[grounded]` JD text; your input is silent |
| G5 | Pay floor against the range (R2, hard_gate) | hard_gate | Not stated | The gate decides whether the range is acceptable | n/a | Your answer alone | `[grounded]` JD text; your input is silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The facts may be accurate and simply unchecked here. The posting could also be stale or aggregated | `[generic]` pattern for any employer I can't independently check, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Hiring manager and reporting line unnamed | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | Team shape and who sets priorities are unknown | `[inferred]` from the posting naming no manager | Who would this role report to, and which analysts depend on these data contracts? | unresolved |
| RR3 | Stated pay against market | positive_signal | — | "$148,000–$166,000 plus equity" | The range runs from just under the report's median ($151,000) to above its interquartile top ($163,500), so there is no seniority-pay mismatch. Equity terms are unknown | `[grounded]` the JD and the recruiter's Datawright report; `[inferred]` that "salary" is comparable to base | Where in the range would a candidate with six years land, and what are the equity type, vesting and strike? | noted |
| RR4 | Scope breadth against a typical senior remit | unknown | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The role could be a single owner of a whole reporting stack, wider than the report's typical one-domain remit. Or it could sit in a team. The posting doesn't say | `[inferred]` from the JD's three layers against the report's typical scope | How many data engineers are on the team, and who owns warehouse cost and infrastructure? | unresolved |

## Application plan

Everything in this plan is proposed, and each row waits on your approval. I have written no resume language, and each action below uses only your own words.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | In your CV, lead with your stated dbt-on-Snowflake build ("about 180 models"), Airflow orchestration and Great Expectations suite, in your own wording | R3, R5, R7 and R8 are the rows the JD lists first | `[grounded]` your stated background | `resume_edits_pending_approval` |
| A1 | Confirm the posting is live on the company's own careers page, at the address it gives, before investing in the application | RR1 | `[grounded]` register | pending your approval |
| F1 | If BigQuery comes up, say it plainly: you haven't used BigQuery, and you built the dbt project on Snowflake at about 180 models | R6, G1 | `[grounded]` your own statements | pending your approval |
| Q1 | Ask RR2, RR3 and RR4's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Pellucid Learning online tutoring K-12 Denver Series C" and "Pellucid Learning Senior Data Engineer careers") were refused because search permission wasn't granted. It would have confirmed the company exists as described and the posting is live, moving RR1 and the contradictions row. RR1 stands, which caps the decision at `conditional_go` |
| 2. Role-family sweep | skipped | The Datawright report's content is in hand and fixes the market calibration line and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form |

## Dossier offer

I can write all this up as `tuesday-dossier.md` if you want it.

## Upgrade menu

- Search permission would re-run target 1, and RR1 would close or harden. A deeper pass would cover funding and leadership churn, hiring patterns and recent news (up to 5 more searches and 2 more fetches). Say the word and it runs.
- Your CV would show whether the dbt, Airflow and Great Expectations lines are buried, since I've only seen your summary.
- A sanitized dbt lineage graph or Great Expectations suite would raise R5 and R8 to `high`.
- An ingestion DAG or connector config would move R9, and a `schema.yml` or a contract doc would move R10.
- The recruiter's answers on team size, reporting line and equity would close RR2, RR3 and RR4.
- The hiring manager's name would sharpen the scope read and which story to lead with.

## Questions

G4 (R1): Where are you based, and do you need visa sponsorship to work for a US employer, or could you work from Denver if needed?

G5 (R2): Is $148,000 at or above your pay floor?

G2 (R9): Which systems did your pipelines at the payroll company pull data from, and which of those did you personally build the ingestion for?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.