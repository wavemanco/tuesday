Use Read directly.
Quick status: I've read the posting and run three searches (company, salary band, hiring manager). I'm now checking whether Quillfield's own site lists this role, then I'll write up the assessment.
## Decision snapshot

**Yes, worth applying for, with a stretch on the forecast and billing sides (R6, R7, R8, R10). You aren't out of your depth on years of experience, Salesforce admin or pipeline and renewal reporting (R3a, R4, R9). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol office two days a week), R2 (pay £61,500–£67,000)
- `must_have`: direct: R3a, R4, R9 · adjacent: R8 (run the quarterly forecast with the CFO) · unclear: R3b (at a B2B software company), R5 (strong SQL and spreadsheet modelling), R6 (experience owning a forecast), R7 (working with finance on billing or revenue data)
- `important`: absent: R10 (own billing data)

R8: a bridge from the monthly pipeline review, its limit named; R6 (`low`) and R7 (`low`): recoverable if the work exists; R10: absent by your own account, closure path named.

**Opportunity ledger.** The employer is established and the pay is stated and mid-band (RR1). The title bundles four specializations (RR3), and the reporting line, option terms and success measures are unstated (RR2, RR4, RR7). The posting is not yet corroborated on Quillfield's own site (RR5), and the hiring-manager attribution checks out (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol office two days a week), R2 (pay £61,500–£67,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can do Bristol two days a week and the band clears your floor (R1, R2); (2) you can surface real forecast work, or frame the gap honestly as adjacent (R6, R8); (3) the finance-and-revenue-data question and the billing closure path are settled (R7, R10); (4) scope and reporting line hold up in conversation (RR3, RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` search result "About Quillfield" (quillfield.co.uk/about), snippet read |
| Mandate | Own CRM and billing data; build the pipeline and renewal reporting that sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Working pattern and pay | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` JD |
| Stated requirements | 4+ years in revenue operations, sales operations or similar analytics at a B2B software company; HubSpot or Salesforce administration; strong SQL and spreadsheet modelling; experience owning a forecast; experience working with finance on billing or revenue data | `[grounded]` JD |
| First-year outcomes | Not stated in the JD | `[grounded]` JD silence |
| Scope read | CRM, billing data, reporting and forecasting sit under one title with no team size or reports named | `[inferred]` from the JD's responsibility list against its silence on team |
| Hiring manager | Tamsin Achebe is listed as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. Whether you would report to her is not stated | `[grounded]` search result (linkedin.example/in/tamsin-achebe), snippet only |
| Market calibration | The posted band sits between the 25th and 75th percentiles of a UK revenue operations lead pay sample (median £64,200, range £57,800–£70,400, n=438). This calibrates pay only. Scope norms were not researched | `[generic]` Ledgerline 2026 UK pay guide, UK-wide not Bristol-specific; `[grounded]` JD for the posted figure |
| Unknowns | Team and reporting line; option terms; success measures; how much of the forecast the CFO versus this role drives | `[grounded]` JD silence |
| Contradictions | None found. The posting is also not confirmed on the company's own site: the careers address I tried returned no page, and it was a guessed address | `[grounded]` fetch result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You gave no location or schedule constraint, so this can't be checked. Confidence grades the missing statement | `[grounded]` JD; your constraints not given | Q3 |
| R2 | Pay £61,500–£67,000 plus options | hard_gate | unclear | none | hard_gate | No pay floor given, so the band can't be tested against one | `[grounded]` JD; your constraints not given | Q3 |
| R3a | 4+ years in revenue operations, sales operations or similar analytics | must_have | direct | medium | none | 5 years in sales operations, the last 2 running revenue operations for the UK team. Stated in conversation, CV not seen, so `medium` is the ceiling | `[grounded]` your background statement | CV would confirm |
| R3b | …at a B2B software company | must_have | unclear | low | discovery | Your employer is a B2B payments company. Whether its product was software is not stated, and payments firms vary | `[grounded]` your statement; `[generic]` that payments firms vary | One line on the product (upgrade menu) |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. The certificate isn't inspected. Org-wide CRM ownership, which the JD's "own our CRM" implies, isn't described | `[grounded]` your statement | Certification verification page would raise to `high` |
| R5 | Strong SQL and spreadsheet modelling | must_have | unclear | low | discovery | "SQL weekly, Excel daily" gives frequency of use, not depth. Modelling isn't described and is a different kind of work from reporting | `[grounded]` your statement | One sanitized query or model you built |
| R6 | Experience owning a forecast | must_have | unclear | low | discovery | You never owned the company forecast. The JD's wording isn't limited to company-level, so I read it downward until you say whether you owned any narrower one | `[grounded]` your statement and JD wording | Q1 |
| R7 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | You've never worked on billing data. The JD says "billing or revenue", and renewal dashboards touch revenue data, but whether finance was involved is unstated | `[grounded]` your statement and JD wording | Q2 |
| R8 | Run the quarterly revenue forecast with the CFO | must_have | adjacent | medium | transferability | Carries over: the monthly pipeline review with your sales director and the dashboards you rebuilt. Limit: finance owned the forecast and you haven't worked with a CFO on one. A pipeline review commonly feeds a forecast, but that doesn't show you contributed to it | `[grounded]` your statement; `[generic]` that pipeline reviews feed forecasts | Q1, or a sanitized work sample |
| R9 | Build pipeline and renewal reporting for sales and finance teams | must_have | direct | medium | none | You rebuilt the pipeline and renewal dashboards. Whether finance used them isn't stated | `[grounded]` your statement | Sanitized dashboard screenshot would raise to `high` |
| R10 | Own billing data | important | absent | none | capability | You've never worked on billing data. The JD's requirement list says "billing or revenue", which is why R7 is the `must_have` and this responsibility is `important`. Renewal dashboards are the nearest work, but renewals aren't billing records | `[grounded]` your statement and JD; `[inferred]` on the renewal comparison | Closure path G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R6, must_have) | discovery | "Never owned the company forecast"; nothing on narrower forecasts | A must-have and a headline duty, so resolving it could move the decision | A UK-team pipeline or renewal forecast you produced; a commit or best-case roll-up in the monthly review; numbers you supplied that finance folded in; tracking forecast against actual bookings | A sanitized roll-up sheet or review deck | `[grounded]` your statement; `[inferred]` that it could move the status |
| G2 | Forecast with the CFO (R8, must_have) | transferability | Adjacent: monthly review and dashboards. Limit: no CFO-level forecast work | The strongest bridge is the likeliest thing an interviewer probes | The same items as G1; any exec-facing revenue reporting | A work sample bridging pipeline data to a revenue number | `[inferred]` bridge; `[generic]` that interviewers probe the nearest gap |
| G3 | Finance on revenue data (R7, must_have) | discovery | Renewal dashboards, finance involvement unknown | The JD's "or" means revenue data can satisfy the requirement without billing | Reconciling renewal values with finance; checking closed-won against invoiced amounts; month-end revenue reports | A sanitized reconciliation or report | `[grounded]` JD wording and your statement |
| G4 | Billing data ownership (R10, important) | capability | No billing-data work, by your account | Quillfield sells invoicing software, so billing data is likely central to the role | Closure path: learn invoicing, credit-note and recognised-versus-billed revenue basics, then build a practice reconciliation of CRM closed-won against a sample invoice export, labeled as practice, never as experience | The practice workbook | `[inferred]` that billing is central; `[grounded]` company description |
| G5 | SQL and modelling depth (R5, must_have) | discovery | Frequency of use, no depth | "Strong" is the JD's word and nothing yet shows depth | A renewal or cohort query; a model others relied on | One sanitized query or workbook | `[grounded]` your statement |
| G6 | B2B software setting (R3b, must_have) | discovery | Employer described as a B2B payments company | The years requirement is tied to a software setting | Product was a platform or software you sold | One line on the product | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and mid-band | positive_signal | — | "£61,500–£67,000" | No seniority-pay mismatch is visible: the band sits inside the sample's middle range | `[grounded]` JD figure; `[generic]` Ledgerline sample, UK-wide | Where in the band would this role sit, and how is it set? | noted |
| RR2 | Option terms unstated | unknown | — | "plus share options" | Value can't be judged without grant size, vesting and strike basis | `[inferred]` from JD silence | What is the option grant for this role, and what are the vesting terms? | unresolved |
| RR3 | Four specializations under one title | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting… and run the quarterly revenue forecast with the CFO" | The role may be the whole revenue-ops function at a 96-person company. Severity is `low` because pay is not below the sample's middle range | `[inferred]` from the JD list; `[grounded]` headcount from the about page | Who handles revenue operations and finance data today, and what would this role take over? | unresolved |
| RR4 | Team and reporting line unstated | unknown | — | "Revenue Operations Lead" | May be an individual contributor with "lead" in the title, or may manage people | `[inferred]` from JD silence | Who does this role report to, and are there direct reports or a budget? | unresolved |
| RR5 | Posting not corroborated on the company site | unknown | — | Posted on jobs.tallyboard.example | The role may be listed elsewhere on Quillfield's site. My careers address was a guess | `[grounded]` fetch returned no page at that address; `[inferred]` the rest | Is this role on Quillfield's own careers page, and who is the contact there? | unresolved |
| RR6 | Hiring manager matches the recruiter's attribution | positive_signal | — | "the hiring manager is Tamsin Achebe" (recruiter, via you) | A listing shows that name as Head of Revenue Operations at Quillfield. Matched on name and company only | `[grounded]` search snippet | Would I report to Tamsin Achebe, and how often would I work directly with the CFO on the forecast? | noted |
| RR7 | No success measures | unknown | — | JD states no outcomes | A demanding mandate with no definition of success | `[grounded]` JD silence | What does success look like at 90 days and at one year? | unresolved |

## Application plan

Each row is a proposal and is pending your approval. Every proposed line below traces to your own sentences. I have not written forecast ownership or billing-data experience anywhere, because neither is in what you told me.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Summary line: "Ran revenue operations for the UK team; 5 years in sales operations at a B2B payments company." | R3a, from "5 years in sales operations at a B2B payments company, the last 2 running revenue operations for the UK team" | `[grounded]` your statement | `resume_edits_pending_approval` |
| E2 | Bullets: "Rebuilt the pipeline and renewal dashboards." "Run the monthly pipeline review with the sales director." "Salesforce admin certified." | R9, R8, R4, each a near-verbatim trace of your sentence | `[grounded]` your statement | `resume_edits_pending_approval` |
| A1 | Lead with the reporting-and-pipeline story. The JD lists it first among responsibilities, and the hiring manager's listed career runs through sales operations. This is not a claim about her preferences | R9 and RR6 | `[inferred]` from the JD order and her public career pattern | pending your approval |
| A2 | Hold any cover-note wording about forecasting until Q1 is answered; the honest framing depends on what you did | R6, R8 | `[grounded]` R6 and R8 rows | pending your approval |
| A3 | Confirm Bristol terms and band position with the recruiter before investing in the loop | R1, R2, RR1 | `[grounded]` R1 and R2 rows | pending your approval |
| A4 | Ask the register's questions RR2 to RR7 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| W1 | Build the G4 practice reconciliation as a learning project, labeled that way | R10 | `[inferred]` closure path | pending your approval |

## Evidence status

Verified: none yet. Your background is self-reported and I have no CV, so those claims are leads at `medium`. Stage is assumed to be evaluating.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol", which returned "About Quillfield" (quillfield.co.uk/about), and fetched quillfield.co.uk/careers, which returned no page. Role reality: the organization row (company exists as described, so no failed-attribution entry) and the contradictions row (no corroboration of the posting, RR5) |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK Bristol B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved: the market calibration row and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), snippet only. Moved: the hiring manager row, RR6 and A1 |

I can write this up as `tuesday-dossier.md` if you want a file to keep or carry forward.

## Upgrade menu

- Your CV or a prior résumé → R3a, R4 and R9 confirmed and any presentation edits grounded in the page.
- Salesforce certification verification page → R4 to `high`.
- A sanitized dashboard screenshot or query → R9 and R5 raised.
- A line on whether your employer's product was software → R3b closes.
- Recruiter answers on RR1 to RR7, or a link to Quillfield's own careers listing → RR5 and the register close.
- A deeper research pass on Quillfield (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

1. **R6, R8:** Did you ever produce or own any forecast yourself, such as the UK team's pipeline or renewals, or supply numbers into the one finance owned? What exactly did you do?
2. **R7:** Have you worked with finance on revenue figures, such as renewal values, bookings against invoices or a month-end report? What did you own in that?
3. **R1, R2:** Can you do Bristol two days a week, and is there a salary floor below which you wouldn't move?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.