I'll read the reference files the skill requires before building the assessment.
**Yes, apply, but confirm a few things first.** Your motor pricing work meets the `must_have` rows R2, R3, R4, R5, R6a and R7 at `direct`. R6b (designing price tests, `must_have`) is unconfirmed, and R1 (remote, UK) needs your confirmation. Never having managed anyone or worked on pet insurance doesn't block you, because the posting asks for neither of those. Status: `conditional_go`.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5, R6a, R7 · unclear: R6b (Design price tests)
- `important` — unclear: R10 (Own pricing analytics for the product)
- `preferred` — direct: R8 · adjacent: R9 (Pet-insurance domain)

R6b (`low`) — running the tests is confirmed, designing them isn't; R10 (`low`) — one book confirmed, the whole product not; R9 — a credible bridge, its limit named; R1 — your base isn't stated.

**Opportunity ledger.** The role is plainly scoped (RR4), but the employer is unverified (RR1), reporting lines and decision rights are unstated (RR2), and the pay is withheld (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. R1: you confirm you're UK-based and can work remotely from there.
  2. RR1: the posting is verified live on Brindlemoor's own careers page.
  3. R6b and R10: confirmed with specifics (G2, G3).
  4. R9: the pet bridge is framed as adjacent, never as pet experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. Not checked against any outside source. | `[grounded]` JD header; external check unavailable this session |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | Odile Varga, Director of Pricing | `[grounded]` JD, as you gave it |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| Stated requirements | 4+ years pricing or actuarial analytics; strong SQL and Python; GLM; presenting to underwriting or actuarial leads; insurance experience "a plus". No management requirement and no pet-insurance requirement are listed. | `[grounded]` JD |
| Scope read | An individual-contributor-shaped post: the JD lists no team, no reports and no decision rights, so whether it has any is open (RR2) | `[inferred]` from the responsibility list against the JD's silence on team |
| Market calibration | Not done. The salary sweep was unavailable and the JD states no pay, so nothing here says whether the level or pay fits the title | `[grounded]` JD silent on pay; sweep unavailable |
| Unknowns | Salary; team size and direct reports; whether pet rating models already exist or are to be built; which changes the role decides versus recommends; contract type | `[grounded]` JD silence on each |
| Contradictions | None inside the JD; not compared with Brindlemoor's careers page | `[grounded]` JD read; careers page unavailable |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You haven't stated where you're based. A UK motor insurer as employer points to a UK base but isn't your statement of it. Confidence grades your statement of the constraint, and there isn't one yet | `[grounded]` JD "Fully remote (UK)"; `[inferred]` UK base from UK employment | G1: confirm you're UK-based and can work remotely from there |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | "5 years pricing analytics at a UK motor insurer, the last 2 as senior analyst" exceeds the stated minimum. Confirmed and specific, with no inspectable artifact yet, so expect a reference or CV check | `[grounded]` your background text | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily" gives frequency, not depth, so "strong" will be probed | `[grounded]` your background text | A sanitized notebook or test-analysis script would raise it to `high` |
| R4 | GLM experience | must_have | direct | medium | none | "Built and maintained the GLM rating model for our young-driver book." Specific and confirmed, no artifact yet | `[grounded]` your background text | Model documentation (sanitized) would raise it to `high` |
| R5 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" covers building and upkeep. Whether you ran formal monitoring (drift, loss-ratio tracking) isn't stated, and I don't assume it | `[grounded]` your background text | Be ready to say how you monitored the model; G3 covers it |
| R6a | Run and read price tests with underwriting | must_have | direct | medium | none | "Ran 14 price tests last year with the underwriting team." Confirmed and specific | `[grounded]` your background text | A sanitized test read-out would raise it to `high` |
| R6b | Design price tests | must_have | unclear | low | discovery | "Ran" establishes running the tests, not who chose the design. Where a sentence admits two readings I take the one that claims less | `[grounded]` your wording "ran 14 price tests" | G2 |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | "I present the quarterly pricing review to the head of underwriting." Matches the requirement's audience | `[grounded]` your background text | A sanitized review pack would raise it to `high` |
| R8 | Insurance experience | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background text | none |
| R9 | Pet-insurance domain knowledge | preferred | adjacent | medium | transferability | Inferred from the product named in the JD, not stated as a requirement. Your motor GLM and price-test work is adjacent. Limit: you have no pet work, and pet rating factors and claims patterns differ from motor's, so that knowledge is new | `[inferred]` requirement from the JD's product scope; `[grounded]` your statement of no pet experience; `[generic]` that pet and motor rating differ | G4: bridge case, no question |
| R10 | Own pricing analytics for the product | important | unclear | low | discovery | You confirm one book's GLM and two years as senior analyst. Ownership of a whole product's pricing analytics isn't stated | `[grounded]` JD "Own pricing analytics"; `[grounded]` your background text on scope | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Remote, UK (R1, hard_gate) | hard_gate | No statement of where you're based | A gate that isn't met caps the decision at `no_go`, so I ask whether it holds | Not applicable: a term, not experience | Your own statement is enough | `[grounded]` no location in your message |
| G2 | Designing price tests (R6b, must_have) | discovery | Running 14 tests is confirmed; who set the design isn't | A `must_have`; confirming it moves R6b to `direct` and clears one condition | Choosing test cells or sample sizes; defining the success metric and decision threshold; writing the read-out for underwriting; recommending roll-out or stop | A sanitized test design note, read-out deck or notebook | `[grounded]` wording "ran"; `[inferred]` that it clears a condition |
| G3 | Owning pricing analytics beyond one book (R10, important) | discovery | Young-driver GLM built and maintained; scope beyond that book not stated | The JD says "own" for a whole product | Rating-model changes you proposed that went live; a monitoring dashboard you built and kept running; being the named analyst for a segment; choosing what to test next | Model change log, monitoring screenshot, model documentation | `[grounded]` your background text and the JD wording |
| G4 | Pet-insurance domain (R9, preferred) | transferability | Adjacent: GLM rating, price tests and underwriting recommendations. Limit: none of it touched pet products. Strengthener: a short note on how you would approach a pet rating model, labelled as your approach, not experience | A `preferred` row, so a ramp-up risk, not a blocker | Pricing on any non-motor line, or on a segment with thin claims history | The note above, if you want to write one | `[inferred]` bridge from your motor work; `[generic]` that pet-specific knowledge is a ramp-up |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Here, my checks didn't run | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Reporting line, team and decision rights unstated | unknown | — | "turn the results into recommendations for underwriting and product" | The role may recommend without deciding, and may be a sole analyst or have reports | `[inferred]` from the JD's recommend-only wording and its silence on team | Does this role have direct reports, and which pricing changes does it decide versus recommend? | unresolved |
| RR3 | Pay withheld | unknown | — | The posting states no salary | The figure may sit below what the title usually pays, or Brindlemoor may not publish pay in postings | `[grounded]` JD silent on pay; no band researched | What salary band is budgeted for this role? | unresolved |
| RR4 | Responsibilities stated concretely | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations for underwriting and product" | The work is defined, and each duty maps to a row in your evidence | `[grounded]` JD | What would the first pet rating-model deliverable be? | noted |

## Application plan

Everything in this table, including the positioning advice, is `pending your approval`. Nothing here is final until you say so.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 (`resume_edits_pending_approval`) | Lead the CV summary and first bullets with three facts in your own words: built and maintained the GLM rating model for the young-driver book; ran 14 price tests last year with the underwriting team; present the quarterly pricing review to the head of underwriting. Add nothing about designing tests, owning the whole product, or pet insurance until G2, G3 and G4 are answered | R4, R6a, R7 | `[grounded]` your background text, clause by clause | pending your approval |
| P1 | If pet comes up, say you haven't worked on pet insurance and that your motor GLM and price-test work is what you'd bring. Don't claim pet-specific knowledge | R9 | `[grounded]` your statement of no pet experience | pending your approval |
| P2 | If asked about managing people, say plainly that you haven't. The JD lists no management requirement, and RR2 will tell you whether the post has reports | RR2 | `[grounded]` your statement and the JD | pending your approval |
| A1 | Before investing in an application, confirm the role on Brindlemoor's own careers page | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the verification questions of RR2, RR3 and RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Stage assumed: evaluating. No CV was provided, so every claim above rests on your typed background and is `medium` at best.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech" and "Brindlemoor careers Senior Pricing Analyst"; both were refused for lack of search permission. It would have moved role reality's organization and contradictions rows, and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst pet insurance UK salary remote"; refused. It would have moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing"; refused. It would have moved role reality's scope read and which verified story the plan leads with for that reader |

I can save all of this as `tuesday-dossier.md` if you want to keep it.

**Upgrade menu**

- Search permission → the three rows above would run: Brindlemoor's careers page (RR1, contradictions), a salary band (RR3, market calibration) and Odile Varga's public professional footprint (scope read, plan positioning). A deeper pass on Brindlemoor (leadership and funding changes, recent news; up to 5 more searches and 2 more fetches) is also on offer, once.
- Your CV → line-level edit proposals in place of the E1 summary, and a check of the CV against your typed background.
- A sanitized test read-out, model document or review deck → R3, R4, R6a or R7 up to `high`.
- Your pay floor and any other non-negotiables → hard-gate rows checked against the posting, so the hard-gates line stops saying constraints weren't given.
- The posting link → compared with the careers page once search runs.
- A salary band from the recruiter → RR3 closes.

**Questions**

G1 — Are you based in the UK, and can you work remotely from there?

G2 — In the 14 price tests, which parts did you personally own: choosing the test cells or sample, defining the success metric, or writing the read-out?

G3 — Beyond the young-driver GLM, were you the named analyst for any wider part of the book, such as monitoring or model changes that went live?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.