Running the first research pass on Brindlemoor, the market band for this role, and Odile Varga's public footprint.
**Likely yes on the skills, but confirm the working pattern before you invest in an application: `hold_pending_answers`.** The JD says fully remote, and Brindlemoor's own careers page says something different.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5a, R6, R7 · unclear: R5b (monitor rating models)
- `important` — unclear: R8 (recommendations to product)
- `preferred` — direct: R9 · adjacent: R10 (pet-insurance product knowledge)

R1 — the one row the decision waits on; R5b (`low`) — monitoring is not yet evidenced; R10 (`medium`) — a credible bridge, its limit named.

**Opportunity ledger.** A clearly scoped role under a named, relevant hiring manager (RR3, RR5), with a working-pattern conflict (RR1), no stated salary (RR2) and no stated team scope (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a confirmed fully remote post, or a Leeds pattern you can accept, moves this to `conditional_go`. The conditions would be that R5b monitoring is evidenced and that R10 is framed as adjacent, never as pet-insurance experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. The role is live on its own careers page. Company size and funding were not established. | `[grounded]` careers page fetched; JD |
| Mandate | Own pricing analytics for pet insurance: build and monitor rating models, design and read price tests, make recommendations to underwriting and product. Reports to the Director of Pricing. | `[grounded]` JD and careers page |
| Working pattern | The JD says fully remote (UK). The careers page says "Leeds office four days a week". | `[grounded]` both sources |
| Salary | The JD states none. | `[grounded]` JD |
| Market calibration | UK senior pricing analyst at insurers and insurtechs: median base £58,400, interquartile range £52,100–£64,900. This is the expected band, never Brindlemoor's offer. | `[generic]` Pricewell 2026 survey (n=612); `[grounded]` JD for the withheld figure |
| Scope read | A senior individual-contributor post. The JD mentions no direct reports, and no management experience is requested. | `[inferred]` from the JD's silence on reports |
| Hiring manager | Odile Varga was head of pricing analytics at Calloway Re for six years. She spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors", about monitoring rating models in small books. | `[grounded]` search-result profile (snippet only) |
| Unknowns | First-year outcomes, team size, whether anyone reports in, salary, and which working pattern is real. | `[grounded]` JD silence |
| Contradictions | JD "fully remote" against careers page "Leeds office four days a week" (RR1). | `[grounded]` both sources |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You have given no location or pattern constraint, so there is no claim to grade. The JD and the careers page disagree on the term. | `[grounded]` JD; careers page | Ask the recruiter; Q1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You stated 5 years of pricing analytics, 2 of them as senior analyst. It is confirmed and specific, with no inspectable proof yet. A length requirement is not a gate. | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You stated daily use. There is no artifact, so expect a probe on depth. | `[grounded]` your message | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. | `[grounded]` your message | none |
| R5a | Build rating models | must_have | direct | medium | none | Same evidence as R4: you built the young-driver model. | `[grounded]` your message | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" suggests monitoring but does not establish it. Drift checks, actual-versus-expected tracking and model-refresh triggers are unstated. Odile's published talk is on monitoring, so this is a likely probe. | `[grounded]` your message; `[inferred]` that monitoring was part of maintaining the model; `[grounded]` talk topic from the profile snippet | G1 |
| R6 | Design and read price tests | must_have | direct | medium | presentation | You ran 14 tests last year with underwriting. The claim is strong but needs outcomes and your own role named on the CV. | `[grounded]` your message | E1 |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. | `[grounded]` your message | none |
| R8 | Turning results into recommendations for product | important | unclear | low | discovery | Your underwriting work is evidenced. Anything aimed at product or commercial teams is not. | `[grounded]` your message, silent on product | G3 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer. | `[grounded]` your message | none |
| R10 | Pet-insurance product knowledge (implied by the role; the JD asks only for insurance) | preferred | adjacent | medium | transferability | You confirmed no pet-insurance work. Motor pricing is the same discipline on a different risk. | `[inferred]` adjacency; `[generic]` that rating factors and claims drivers differ by line | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R5b, must_have) | discovery | "Built and maintained" the GLM, with no monitoring detail | A must-have, and the hiring manager has spoken publicly on this topic | Actual-versus-expected tracking, drift or stability checks, a refresh trigger, a dashboard others used, a post-launch review of a rate change | A sanitized monitoring pack, a dashboard screenshot, a model-review note | `[grounded]` CV-level silence; `[inferred]` the probe risk from the hiring manager's talk |
| G2 | Pet-insurance knowledge (R10, preferred) | transferability | Adjacent: you rated a young-driver motor book with GLMs and price tests. Limit: you have not rated a pet book (breed, age and vet-cost factors). | A preferred row, so it is a risk but not a blocker | Any thin-data segment work, claims-inflation handling, or renewal pricing on a small book | A short note on how you handled a thin segment | `[inferred]` bridge; `[generic]` that thin-data segments are the common link |
| G3 | Recommendations to product (R8, important) | discovery | Underwriting audience evidenced, product audience not | JD names both audiences | A test result that changed a product feature, a bundle or an add-on, or a commercial or distribution decision | A pricing-review slide that went beyond underwriting | `[grounded]` your message, silent on product |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern differs between the JD and the careers page | risk_signal | medium | JD "Fully remote (UK)"; careers page "Leeds office four days a week" | One source may be stale, or the role may be hybrid with remote as an exception. | `[inferred]` from the two quotes disagreeing | Is this post fully remote, or Leeds four days a week? | unresolved |
| RR2 | Salary not stated | unknown | — | JD contains no figure | The offer may sit inside the survey band in role reality, or the employer may not publish salaries. | `[inferred]` from the withheld figure against the `[generic]` band | What salary is budgeted for this post? | unresolved |
| RR3 | Clear mandate and a named hiring manager | positive_signal | — | "Own pricing analytics for our pet-insurance product" | The scope is defined, with a named leader of the function above it. | `[grounded]` JD and careers page | What does a successful first year look like? | noted |
| RR4 | Team scope unstated | unknown | — | JD mentions no reports or team | The post may be a solo analyst role, or sit inside a team. | `[inferred]` from JD silence | Who else is in pricing analytics, and does this role have reports? | unresolved |
| RR5 | Hiring manager has published on rating-model monitoring | positive_signal | — | "Small Books, Loud Errors" (profile snippet) | Monitoring is likely a core concern of this role. | `[inferred]` from the talk topic against the JD's "monitor rating models" | How do you monitor rating models on a book this size? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern with the recruiter before applying | R1, RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Turn "ran 14 price tests with underwriting" into an outcome bullet that names your own part and the results. Add nothing beyond your confirmed facts. | R6 | `[grounded]` your message | pending your approval |
| E2 | If G1 confirms it, add a monitoring bullet for the young-driver GLM | R5b | `[grounded]` R5b | pending your approval |
| P1 | Lead with R4, R5a and R6 for Odile Varga. Frame R10 as adjacent: same GLM and price-test discipline, no pet-book experience. | R10 | `[grounded]` R4, R5a, R6; `[inferred]` reader emphasis from her talk topic | pending your approval |
| P2 | Do not claim people management or product ownership. The JD asks for neither, and you have confirmed neither. | RR4, R8 | `[grounded]` your message | pending your approval |
| Q1 | Ask RR2, RR3 and RR4 verbatim in interviews. | Register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your claims came from your message with no CV or artifact attached, so they stay at `medium` or below.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers". Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It confirmed the post is live and surfaced the working-pattern contradiction (R1, RR1). Company size and funding were not established. |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). It moved the market calibration row and RR2. |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). Only the snippet was read. It moved the hiring-manager row, RR5 and P1. |

I can turn this into `tuesday-dossier.md` whenever you like.

## Upgrade menu

- Your CV, or a sanitized monitoring pack or model-review note → R5b, and R4 and R6 toward `high`.
- Your location and working-pattern constraint, and your pay floor → R1 and RR2 become checks against your constraints, not unknowns.
- The recruiter's answer on remote versus Leeds → R1 and RR1 close, and the decision likely simplifies.
- A deeper research pass on Brindlemoor (funding, leadership churn, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

1. **R1:** Could you work a Leeds-office four-days-a-week pattern if the post turns out not to be fully remote, or is remote a requirement for you?
2. **G1:** What did you actually monitor on the young-driver GLM after launch (for example actual versus expected, drift checks, refresh triggers), and who used the output?
3. **G3:** Did any of your 14 price tests lead to a recommendation outside underwriting, such as to a product, commercial or distribution team? If so, what did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.