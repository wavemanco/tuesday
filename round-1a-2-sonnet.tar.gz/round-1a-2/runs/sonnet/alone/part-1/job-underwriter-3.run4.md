I'll read the reference files the skill points to before building the assessment.
**No, this one isn't worth pursuing. R1 and R2 are hard gates and both fail · `no_go`.** The posted pay and the on-site rule each conflict with a constraint you stated, and the posting has its own problems on top of that.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (Compensation: $70–85k base), R2 (On-site in our Austin office 5 days a week)
- `must_have` — direct: R3, R4, R5
- `important` — unclear: R6 (SEO/content), R7 (brand, PR, partnerships), R8 (sales ops), R9 (team of one to start)

R1 — the posted base sits below your stated floor; R2 — five days on-site against remote-only; R3, R4, R5 — the match holds on your account, as prose intake; R6, R7, R8, R9 — nothing you shared speaks to them.

**Opportunity ledger.** The terms conflict with your pay floor and your remote-only requirement (RR1, RR2). Apart from that, the posting packs seven functions into a one-person team with no stated budget (RR4), pairs always-on language (RR5) with success metrics deferred (RR6), and has not been established as an employer (RR7). The posted base against 8+ years is unconfirmed without a market band (RR3). One entry runs the other way: the reporting line to the CEO (RR8).

- **Hard gates:** failed: R1 (Compensation: $70–85k base), R2 (On-site in our Austin office 5 days a week).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** a posted base at or above $150k (R1), and a role that can be done remotely from Portland (R2). The posting says "no exceptions" on location and states the pay range.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, "Series A, profitable since day one"; these are the posting's own claims and are not verified | `[grounded]` JD header; not independently checked |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team and reporting | "A team of one to start"; reports to the CEO with a dotted line to the board | `[grounded]` JD |
| Working pattern | On-site in Austin five days a week, "no exceptions"; "evenings and weekends when it matters is just who we are" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside"; the equity is not quantified | `[grounded]` JD |
| Success measures | "Success metrics will evolve as we learn"; no first-90-day or first-year outcomes stated | `[grounded]` JD silence |
| Scope read | The title says "Head of", but the scope is seven functions with no team; this reads as one person doing several roles | `[inferred]` from the function list against "team of one" |
| Market calibration | Not established. The role-family sweep did not run (see Evidence status), so no market band is stated. The posted figure is compared with your floor in R1 | `[grounded]` JD figure; no band available |
| Unknowns | Paid budget and spend authority; equity terms; revenue targets; whether Novaline sells to merchants or to consumers, which decides how close your B2C subscription background sits | `[grounded]` JD silence |
| Contradictions | "Head of" with no team, and "players who don't need a bench" | `[inferred]` from the JD's own wording |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Compensation: $70–85k base (your floor: $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your statement of the floor, which is specific and your own. The posted top of range is below your floor, so the gate fails | `[grounded]` JD figure and your stated constraint | Surface only; the employer would have to change the terms |
| R2 | On-site in our Austin office 5 days a week (you: remote-only, Portland, not relocating) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your statement, which is specific and your own. The JD says "no exceptions", so the gate fails | `[grounded]` JD quote and your stated constraint | Surface only; the employer would have to change the terms |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, as Growth lead then Head of Growth at two B2C subscription companies. This is a length-of-experience requirement, not a gate. It is intake prose with no inspectable artifact yet, so expect a probe | `[grounded]` your intake statement | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You say you owned paid and scaled one company from $8M to $40M ARR over three years with a budget you controlled. Confirmed and specific, but a growth report or dashboard export has not been inspected | `[grounded]` your intake statement | An inspectable artifact would raise this to `high` |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You say you owned lifecycle and are deep in Braze, SQL and GA4. The same caveat applies | `[grounded]` your intake statement | none |
| R6 | SEO/content | important | unclear | none | discovery | Nothing in what you shared mentions SEO or content | `[grounded]` silence in your intake | See G1 |
| R7 | Brand, PR, partnerships | important | unclear | none | discovery | Nothing in what you shared mentions these | `[grounded]` silence in your intake | See G2 |
| R8 | Sales ops | important | unclear | none | discovery | Nothing in what you shared mentions it | `[grounded]` silence in your intake | See G3 |
| R9 | Operating as a team of one to start | important | unclear | low | discovery | You built and managed teams of 3–7, but how much you executed hands-on, alone, is not stated | `[grounded]` your intake statement; solo execution not stated | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R6, important) | discovery | Nothing in the intake touches SEO or content | It is one of seven functions the posting says you would own; it matters only if you reopen the role | Content or organic programs you ran or commissioned; SEO inside lifecycle work | A traffic or organic-conversion report | `[grounded]` intake silence |
| G2 | Brand, PR, partnerships (R7, important) | discovery | Nothing in the intake touches these | They are folded into the mandate with no support | Partner or affiliate deals; launches with a PR component | A partnership summary or launch brief | `[grounded]` intake silence |
| G3 | Sales ops (R8, important) | discovery | Nothing in the intake touches sales operations | The posting lists it, and it could imply a B2B motion | CRM or pipeline reporting you owned | A pipeline dashboard export | `[grounded]` intake silence; `[inferred]` that it implies B2B |
| G4 | Team of one (R9, important) | discovery | Team management is stated, solo hands-on execution is not | The posting starts you with no bench | Periods you ran channels yourself | A prior-role summary | `[grounded]` intake |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base pay below your stated floor (see R1) | red_flag | high | "$70–85k base plus meaningful equity upside" | The posted range cannot meet a $150k base floor | `[grounded]` JD figure against your stated floor | Is $70–85k the full budgeted base range for this role, or is there a higher band for 8+ years of growth leadership? | confirmed |
| RR2 | Five-day on-site against remote-only (see R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | A Portland-based hire does not fit the stated terms | `[grounded]` JD quote against your stated constraint | Does "no exceptions" apply to a remote-based hire for this role? | confirmed |
| RR3 | Seniority-compensation mismatch | risk_signal | medium | "8+ years growth leadership required"; "$70–85k base plus meaningful equity upside" | The base may be low for the stated years and the seven-function mandate. The equity is unquantified. Without a market band this stays a signal | `[inferred]` from the JD's stated years and scope against its stated base | What is the equity grant in share count, percentage, strike price and vesting terms? | unresolved |
| RR4 | Seven functions, team of one, no stated budget | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops"; "a team of one to start" | You may be accountable for revenue without the staff, budget or authority to deliver it | `[inferred]` from the function list and team size against the JD's silence on budget | What paid budget and spend authority come with the role, and what contractor or agency support exists? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | The workload expectation may be unbounded | `[inferred]` from the JD's wording | In the last six months, how often did the team work evenings or weekends, and who decided when it "matters"? | unresolved |
| RR6 | Success metrics deferred on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You may be held to targets set after the fact | `[inferred]` from "own all revenue growth" against no stated measures | What revenue target defines success at 12 months, and who can change it? | unresolved |
| RR7 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR8 | Reporting line to the CEO with a dotted line to the board | positive_signal | — | "Report to the CEO with a dotted line to the board." | The role has leadership visibility | `[grounded]` JD | Who else is on the leadership team, and which of them does growth depend on? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't spend application effort unless the employer changes the terms behind R1 and R2 in writing | see R1, R2, RR1, RR2 | `[grounded]` R1 and R2 rows | pending your approval |
| Q1 | If you proceed anyway, put RR1 and RR2's questions to the employer first, before any interview time | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| Q2 | Before investing further, ask RR3 to RR7's questions verbatim and check the role on Novaline's own careers page | see RR3 to RR7 | `[grounded]` register | pending your approval |

I'm proposing no CV edits, since nothing needs repositioning for a role that fails R1 and R2.

## Evidence status

Verified: R1 and R2, which are your own stated constraints with nothing to inspect. The experience claims in R3, R4 and R5 come from prose you typed, so they are unverified leads. Unverified leads from memory: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused (permission not granted). It would have confirmed whether Novaline exists as described and whether the role is live, which feeds RR7 |
| 2. Role-family sweep | unavailable | The search was refused (permission not granted). It would have supplied the market-calibration band and settled RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I assumed your stage is "evaluating", since you didn't say.

I can write up the full assessment as a `tuesday-dossier.md` file whenever you want it.

## Upgrade menu

- Permission for the two searches that were refused → RR7 and RR3 resolve, and role reality gets a market band.
- A link to the live posting or Novaline's careers page → RR7 closes.
- A growth report or dashboard export for the $8M to $40M scale-up (the inspectable artifact in growth work) → R4 to `high`, and R3 and R5 firm up.
- Your CV → every experience row can be checked against it rather than your prose.
- Paid budget, equity terms or revenue targets from the employer → RR3, RR4 and RR6 close.
- The hiring manager's or CEO's name → role reality's scope read and the plan's positioning can be grounded.

Questions: none this turn. Nothing you could answer would move R1 or R2.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.