I'm reading the skill's remaining rules (research tiers, evidence-map rows, question selection) so the assessment follows its format. Then I'll write it up.
## Decision snapshot

**Yes, worth applying to, but check the working pattern first. The JD says fully remote and the company's careers page says Leeds four days a week (R1, RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5a, R6, R7 · adjacent: R5b (Monitor rating models)
- `important` — adjacent: R8a (Recommendations for underwriting) · unclear: R8b (Recommendations for product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance knowledge)

R5b and R8a — what you've told me points that way, but it doesn't use the JD's words; R10 — the pet-insurance gap you flagged, bridged from motor, its limit named.

**Opportunity ledger.** The scope is concrete and reports to a named director (RR3). The working pattern contradicts itself (RR1), pay is withheld (RR2), and team and decision rights are unknown (RR4). Company stage and size could not be established independently (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 resolves to a working pattern you can accept (R1); (2) your model-monitoring work is confirmed before it is claimed (R5b); (3) the pet-insurance bridge is framed as adjacent, never as pet experience (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, listed as an insurtech selling pet insurance. Its own careers page lists this role as accepting applications. The company-description search returned nothing, so stage and size are not established (RR5) | `[grounded]` JD header; careers page found by search and fetched |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing, Odile Varga | `[grounded]` JD and careers page |
| Working pattern | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week". The two sources contradict each other | `[grounded]` both texts quoted |
| Line management | The JD states no people-management requirement and no direct reports | `[grounded]` JD silent |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | Single-product analytics owner with no stated team, a normal shape for a senior individual-contributor post | `[inferred]` from the JD's scope wording and its silence on reports |
| Hiring manager | Director of Pricing. Public profile: spoke at the 2025 Insurance Pricing Forum ("Small Books, Loud Errors", on monitoring rating models in small books); previously head of pricing analytics at Calloway Re for six years | `[grounded]` search result, LinkedIn-style profile page |
| Market calibration | A pay survey of senior pricing analysts at UK insurers and insurtechs gives median base £58,400, interquartile range £52,100 to £64,900. The posting withholds salary, so this is the band to expect, never Brindlemoor's offer (RR2) | `[generic]` role-family search, 2026 survey snippet only; `[grounded]` JD for the missing salary |
| Unknowns | Pay; contract basis; team size; who decides rating changes; the working pattern | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | JD says fully remote and the careers page says Leeds four days a week. You haven't told me whether remote is a constraint for you, so the row can't be met or failed yet | `[grounded]` JD and careers page; your constraint not given | Ask recruiter (RR1); tell me if remote is a must |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You describe 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Self-reported, nothing inspectable yet | `[grounded]` your background, prose | CV would confirm dates |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. No artifact yet | `[grounded]` your background, prose | Optional: a sanitized script or notebook would raise to high |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book | `[grounded]` your background, prose | Model documentation, sanitized, would raise to high |
| R5a | Build rating models | must_have | direct | medium | none | Same GLM evidence as R4: you built the model | `[grounded]` your background, prose | none |
| R5b | Monitor rating models | must_have | adjacent | medium | discovery | You said "maintained", not "monitored". I'm resolving the ambiguity downward and not assuming monitoring happened | `[grounded]` your wording; `[inferred]` adjacency from maintaining a model | See G1 |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. Whether you designed them as well as ran them is not stated; the JD verb is "design" | `[grounded]` your background, prose | Confirm your role in design (G2) |
| R7 | Experience presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background, prose | none |
| R8a | Turn results into recommendations for underwriting | important | adjacent | medium | discovery | You run tests with underwriting and present the review. Whether recommendations were part of that isn't stated | `[grounded]` your background; `[inferred]` adjacency | See G2 |
| R8b | Turn results into recommendations for product | important | unclear | low | discovery | Nothing in your background mentions product teams | `[grounded]` your background silent | See G2 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background, prose | none |
| R10 | Pet-insurance product knowledge (my inference, from the role owning pet pricing; the JD does not ask for it) | preferred | adjacent | low | transferability | You have pricing experience on a different insurance line. A different line has different claim drivers and data, and I haven't researched pet specifics | `[inferred]` requirement from the role title; `[generic]` that lines differ | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Model monitoring (R5b, must_have) | discovery | "Maintained" the model, with no monitoring stated | The JD says "build and monitor", and the hiring manager has spoken publicly on monitoring rating models | Tracking model performance against actuals, drift checks, refresh triggers, reporting to underwriting | A sanitized monitoring report or dashboard screenshot | `[grounded]` JD wording; `[inferred]` from "maintained" |
| G2 | Test design and recommendations (R6, R8a, R8b) | discovery | Ran 14 tests and presents the review; no mention of design, recommendations or product | The JD pairs tests with recommendations to underwriting and product | Test design choices, recommendations to underwriting, any work with product or proposition teams | A sanitized test write-up or review deck | `[grounded]` your background, JD |
| G3 | Pet-insurance knowledge (R10, preferred) | transferability | Motor pricing only | Closing it narrows an obvious interview objection | Any pet, health or other low-frequency or small-book pricing work | Any such work sample or a short note | `[inferred]` bridge from motor to pet |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts across sources (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The JD copy may be out of date or from a different version of the post. Severity stays at medium until I know remote matters to you | `[inferred]` from two conflicting texts | Is this role fully remote, or based in Leeds four days a week? | unresolved |
| RR2 | Salary withheld | unknown | — | No figure in the JD | The posting may sit anywhere against the survey band in role reality | `[inferred]` from silence, against the `[generic]` band | What salary range is budgeted for this role? | unresolved |
| RR3 | Concrete scope and named reporting line | positive_signal | — | "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing" | Success criteria may be definable, and the manager has a published interest in model monitoring | `[grounded]` careers page and profile | What would a strong first year look like for this role? | noted |
| RR4 | Team and decision rights unknown | unknown | — | "Own pricing analytics" | The role may own analysis while rating changes are decided elsewhere | `[inferred]` from the JD's silence | Who decides rating changes, and is there a team around this role? | unresolved |
| RR5 | Employer's stage and size not independently established | unknown | — | "Brindlemoor (insurtech)" | The company may be new or small, with a thin public footprint. The role itself is confirmed on its own careers page | `[generic]` pattern for small companies, not a claim about this one | Can you tell me about the company's size, funding stage and the team I would join? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with "Built and maintained the GLM rating model for the young-driver book" (your wording, unchanged) | R4, R5a | `[grounded]` your sentence | `resume_edits_pending_approval` |
| E2 | Next bullet: "Ran 14 price tests last year with the underwriting team" (your wording, unchanged) | R6 | `[grounded]` your sentence | `resume_edits_pending_approval` |
| E3 | Then: "Present the quarterly pricing review to the head of underwriting" (your wording, unchanged) | R7, R8a | `[grounded]` your sentence | `resume_edits_pending_approval` |
| A1 | Confirm the working pattern with the recruiter before investing in the application | R1, RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Bring RR2 to RR4 into the interview as your own questions | The register doubles as preparation | `[grounded]` register | pending your approval |
| A3 | Have a concrete monitoring example ready only if G1 confirms it. Don't use "monitored" until then | R5b, and the JD says "monitor" | `[grounded]` JD; your wording | pending your approval |

Rows E1 to E3 add nothing you haven't said, and I've left out any claim about people management. The JD states no such requirement.

## Evidence status

Verified: none yet. Unverified leads: all candidate claims above are self-reported prose.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results, so the company description is not established) and "Brindlemoor careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved role reality's working-pattern contradiction and organization rows, R1 and RR1, RR5 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), seen as a snippet. Moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). Moved the hiring manager row, G1 and A3 |

I can produce `tuesday-dossier.md` of this analysis if you want one to keep.

## Upgrade menu

- Your CV or a prior resume → confirms dates and may raise R2 to R9 beyond `medium`.
- A sanitized model document, monitoring report or test write-up → R4, R5b, R6 to `high`.
- The recruiter's answer on working pattern → R1 and RR1 close; the decision likely becomes `go` or `no_go`.
- The budgeted salary → RR2 closes and is set against the survey band.
- An independent source on Brindlemoor's size and stage → RR5 closes.
- A deeper research pass on Brindlemoor (funding, leadership churn, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

Questions, answerable in a line each, or say "skip":

1. **R1/RR1:** Is working from home a must for you, or could you do four days a week in Leeds?
2. **G1/R5b:** Did maintaining the young-driver GLM include monitoring its performance against actuals, and what did you do with the results?
3. **G2/R8b:** Did any of your price-test recommendations go to product or proposition teams, as opposed to underwriting?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.