I'll read the reference files before building the assessment.
**Yes, apply.** Having no pet-insurance experience (R10, `adjacent`) and no management experience doesn't block you. The JD asks for neither. Status: `conditional_go`, once Brindlemoor verifies (RR1) and you confirm the location term (R1).

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5a, R6, R7 · unclear: R5b (Monitor rating models)
- `important` — direct: R8a · unclear: R8b (Recommendations to product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance domain knowledge)

R5b — "maintained" suggests monitoring but it isn't described; R8b — the product-side audience isn't evidenced; R10 — a motor-to-pet bridge, its limit named.

**Opportunity ledger.** The employer isn't established from the search (RR1), pay is withheld (RR2) and team and authority scope is unstated (RR3). One entry runs the other way: the duties are concrete (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor appears on its own careers page, or the recruiter writes from its own domain (RR1); (2) you are UK-based and fully remote works for you (R1); (3) pay and team scope are checked early (RR2, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header; not established by search (RR1) |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing. A profile page says she spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors" (monitoring rating models in small books). It also says she was previously head of pricing analytics at Calloway Re for six years | `[grounded]` one search result, profile page not fetched, single source |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| Management scope | The JD states no people-management duty. Whether the role has reports is unknown | `[grounded]` JD silence |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | "Own" for one product, with no team size or decision rights stated, reads like a lead-analyst scope | `[inferred]` from the JD's wording against its silence on team and authority |
| Market calibration | Senior pricing analyst at UK insurers and insurtechs: median base £58,400, interquartile range £52,100–£64,900. The posting withholds pay, so this is what to expect, never Brindlemoor's offer (RR2) | `[generic]` role-family search, 2026 survey, n=612, from the search snippet only; `[grounded]` JD for the withheld pay |
| Unknowns | Salary; team size and reporting line; decision rights; whether the pet product can run live price tests; the employer's standing | — |
| Contradictions | None found. No careers page was found to compare the JD against | `[grounded]` search returned nothing for the company |

## Evidence map

Your background was given in prose, which counts as self-report. `medium` is the ceiling on a first pass.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | The JD fixes the term. You haven't stated your location, right to work or remote preference. Your UK insurer role is indirect context only | `[grounded]` JD; `[grounded]` your background names a UK employer, nothing more | Gate question G1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years pricing analytics at a UK motor insurer, 2 as senior analyst. Specific, but no inspectable artifact yet | `[grounded]` your stated background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is stated. "Strong" is the JD's word and depth hasn't been probed, so expect a technical probe | `[grounded]` your stated background | offer: a redacted query or notebook would raise to high |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Specific, no artifact inspected | `[grounded]` your stated background | offer: a redacted model summary or factor review would raise to high |
| R5a | Build rating models | must_have | direct | medium | none | Same evidence as R4: you built the young-driver GLM | `[grounded]` your stated background | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" suggests monitoring, but what you tracked and what it triggered isn't described. Low rather than none, because there is a concrete thread | `[grounded]` the word "maintained"; `[inferred]` that it implies monitoring | G2 question |
| R6 | Design and read price tests | must_have | direct | medium | none | 14 price tests last year, run with the underwriting team. Specific, no artifact inspected | `[grounded]` your stated background | offer: a redacted test design and read-out |
| R7 | Present to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your stated background | none |
| R8a | Recommendations to underwriting | important | direct | medium | none | Price tests with underwriting plus the quarterly review to its head. Whether recommendations were adopted isn't stated | `[grounded]` your stated background | none |
| R8b | Recommendations to product | important | unclear | low | discovery | Nothing yet shows a product-side audience, though the evidence may exist | `[grounded]` background silent on product teams | G3 question |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | 5 years at a motor insurer | `[grounded]` your stated background | none |
| R10 | Pet-insurance domain knowledge (not required by the JD; derived from "pet-insurance product") | preferred | adjacent | medium | transferability | The GLM method and test discipline carry over from motor. Pet-specific rating factors, claims dynamics and product rules are untested. You have said you haven't worked on pet insurance | `[inferred]` adjacency derived from your motor GLM work; `[generic]` that pet and motor books differ in their rating factors | see G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and remote term (R1, hard_gate) | hard_gate | Nothing states where you are based or whether fully remote works for you | A gate the inputs don't settle is surfaced, not assumed met | — | none needed beyond your answer | `[grounded]` inputs silent |
| G2 | Monitoring rating models (R5b, must_have) | discovery | You built and maintained a GLM, but monitoring practice isn't described | A `must_have` row at `unclear`. Resolving it could raise it to `direct` | Tracking actual versus expected loss or frequency after launch; segment or drift checks; a refit or rate change triggered by what you saw; a monitoring pack others used | A redacted monitoring report, dashboard screenshot or review slide | `[grounded]` CV-style silence; `[generic]` that the role family treats monitoring as core, as the JD itself lists it |
| G3 | Product-side recommendations (R8b, important) | discovery | Audiences named so far are underwriting only | Closing it removes the one `unclear` row in the `important` tier | A pricing result taken to a product, marketing or commercial team; a rate change you recommended that a non-underwriting owner decided | A redacted recommendation paper or deck | `[grounded]` background silent on product teams |
| G4 | Pet-insurance knowledge (R10, preferred) | transferability | Motor GLM and price-test work that carries over; pet rating factors and claims behaviour are not exercised | A `preferred` row, so a minor risk rather than a blocker. The bridge has to be stated with its limit | The same frequency and severity modelling logic, tested in a different segment. Limit: no pet-specific rating factors or claims cost trends. Strengthener: a short note on what you would need to learn | A short, honest note on how your model's structure would carry over | `[inferred]` bridge from motor to pet; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` the company search returned no results | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary withheld | unknown | — | The JD states no pay figure | The figure may sit below, inside or above the band in role reality | `[inferred]` from the posting's missing figure against the `[generic]` band | What salary range is budgeted for this post? | unresolved |
| RR3 | Ownership asserted, team and authority unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Own" may mean sole analyst, or a lead with no stated reports or decision rights | `[inferred]` from the JD's scope wording against its silence on team and authority | Who else is on the pricing team, who does this role report to, and which pricing decisions does it make rather than recommend? | unresolved |
| RR4 | Concrete, measurable duties | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations for underwriting and product" | The scope is defined rather than vague | `[grounded]` JD | What would a successful first year look like for this role? | noted |

## Application plan

Every row below is proposed. Nothing, including the positioning advice, is final until you approve it. The proposals use only facts you gave, and no metrics or figures are added.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before investing effort, find the role on Brindlemoor's own careers page, or check that any recruiter email comes from its own domain | see RR1, R1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead the CV with the young-driver GLM you built and maintained, then the 14 price tests run with underwriting, then the quarterly review to the head of underwriting | R4, R5a, R6 and R7 are the `direct` `must_have` rows | `[grounded]` your stated background | pending your approval |
| E2 | If G2 confirms real monitoring work, add one monitoring bullet. Until then, don't claim it | see R5b. The hiring manager's published topic is monitoring rating models, but your own monitoring evidence is not yet confirmed | `[grounded]` search result for her topic; `[grounded]` R5b row | pending your approval |
| E3 | Say plainly that you come from motor and name the carry-over and its limit. Don't claim pet-insurance expertise | see R10, G4 | `[grounded]` your statement; `[inferred]` bridge | pending your approval |
| Q1 | Ask RR1, RR2 and RR3 verbatim with the recruiter or Odile Varga | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A2 | Don't present yourself as having managed people. If the role turns out to include reports, say so plainly and ask how it is supported | The JD is silent on reports (RR3) | `[grounded]` your statement; `[grounded]` JD silence | pending your approval |

## Evidence status

Verified: none yet. Your background is prose self-report, so the rows built on it stay at `medium` or lower until you confirm specifics or share artifacts. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" and got no results, so the employer is not established and no pages were read. It moved RR1 and caps the decision at `conditional_go` |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK remote salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), read from the snippet only. It moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), read from the snippet only. It moved the hiring manager row and E2. This result names the company but is a third-party profile, so it doesn't establish the employer |

I can also write this up as `tuesday-dossier.md` if you want to keep or reuse it.

**Upgrade menu**

- Your location, right to work and any pay floor or other must-haves → R1 gets checked against your terms, and a pay row can be added against the withheld salary.
- A link to Brindlemoor's own careers page, or the recruiter's email domain → RR1 closes, and the cap on the decision lifts.
- Redacted artifacts → R3, R4 and R6 can move from `medium` to `high`: a SQL or Python sample, a model factor review or summary, and a price-test design with its read-out. A monitoring report would settle R5b.
- Your current CV → any `presentation` gaps get checked against it. Only your prose was available.
- A deeper research pass on Brindlemoor (funding, leadership, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — Are you UK-based with the right to work there, and is fully remote fine for you?

G2 — After the young-driver model went live, what did you personally track to know it was still working, and did it ever trigger a refit or a rate change?

G3 — Have you taken a pricing result to a product, marketing or commercial team rather than underwriting, and if so what did you recommend and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.