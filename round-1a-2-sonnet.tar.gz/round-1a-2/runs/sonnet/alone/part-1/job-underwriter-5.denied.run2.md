## Decision snapshot

**Yes, it's worth applying, on conditions. R3, R4, R5, R6 and R7, the `must_have` rows, are all `direct` for you, so you aren't reaching. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (dbt-modelled warehouse in BigQuery) · unclear: R9 (ingestion from app and CRM), R10 (data contracts analysts depend on)

R8 (`medium`) — Snowflake bridge, limit named; R9 (`low`) and R10 (`low`) — the CV is silent, waiting on your answers.

**Opportunity ledger.** The posted pay brackets the market median (RR3) and the company's own page reports a recent raise (RR6). Against that, the employer is not established from attributable sources (RR1), and scope and team size (RR4) and the equity terms (RR5) are open. The hiring manager is unnamed (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on the company's own careers site, see RR1; (2) you are US-based or Denver-able and the range meets your floor, see R1 and R2; (3) scope and equity come back concrete, see RR4 and RR5; (4) BigQuery is framed as adjacent, never as experience, see R8.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted, not independently checked |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, and data contracts for analysts | `[grounded]` JD |
| Stated requirements | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Compensation and location | $148,000–$166,000 plus equity (equity terms unstated); remote (US) or Denver office | `[grounded]` JD |
| Scope read | Three areas (ingestion, warehouse, contracts) under one title, with no team size or reporting line stated, so it may be wider than one domain | `[inferred]` from the JD's three named areas against its silence on team |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, interquartile range $139,000–$163,500; "Senior" typically 5–8 years, one domain's pipelines, no direct reports. The posted range brackets that median and its top sits above the interquartile ceiling. This is the pattern for the title, never this employer's offer (RR3). | `[generic]` Datawright 2026 report you pasted, n=2,310; `[grounded]` JD for the posted range |
| Stage | Assumed evaluating; you did not state a stage | `[inferred]` from your wording |
| Unknowns | Hiring manager and reporting line; team size; whether the salary is base; equity terms; your location, authorization and pay floor | `[grounded]` JD silence and your message |
| Contradictions | None between the pasted JD and the pasted about page; the live site was not checked | `[grounded]` the two pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You have not said where you are or whether you can work in the US; confidence is `none` because no constraint statement exists to grade | `[grounded]` JD terms; your message silent | G1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor stated, so the range cannot be checked against one; equity terms are also unstated | `[grounded]` JD figure; your message silent on a floor | G1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years of data engineering at a B2B payroll company; self-reported, no inspectable artifact. This is a length-of-experience requirement, so it is graded as fit, not as a gate | `[grounded]` your background statement | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily", which is confirmed use with no artifact; "strong" is the JD's word and rests on your daily use | `[grounded]` your background statement | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models; Snowflake is a cloud warehouse, so the requirement as worded is met | `[grounded]` your background statement | none; a sanitized dbt docs or lineage screenshot would raise it to `high` |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration; what you owned in the DAGs is not stated, so the claim stays at that wording | `[grounded]` your background statement | none; a sanitized DAG file would raise it to `high` |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, which is owned, specific work in this area; dbt tests were not mentioned and are not claimed | `[grounded]` your background statement | none; a sanitized expectation suite would raise it to `high` |
| R8 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Carries over: dbt modelling and warehouse SQL on Snowflake. Limit: you have never used BigQuery, so nothing platform-specific is claimed; cost and tuning practice typically differs by platform | `[grounded]` your statement that you never used BigQuery; `[generic]` platform differences | G4 |
| R9 | Ingestion from the app and the CRM | important | unclear | low | discovery | The CV is silent on which sources you ingested; Airflow use is indirect context only | `[grounded]` your background, silent on sources | G3 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Nothing stated about agreements with analysts or upstream teams; the Great Expectations suite is the nearest indirect context | `[grounded]` your background, silent on contracts | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location, authorization and pay floor (R1, R2, hard_gate) | hard_gate | No location, work-authorization or pay-floor statement from you | Both are gates, and the status cannot move above `conditional_go` until they are settled | Nothing to recall; this is a fact about your situation | None needed | `[grounded]` your message silent on both |
| G2 | Data contracts (R10, important) | discovery | A Great Expectations suite, but no stated agreement with consumers | The JD names contracts as what analysts depend on, so this row decides how strong the application's second half reads | Agreeing table schemas or freshness with analysts; a versioned model layer others built on; alerts when an upstream schema changed; documented expectations you handed to a consuming team | Sanitized expectation suite, a schema-change doc, a model README | `[grounded]` CV silence; `[generic]` that roles describing contracts usually probe who consumed them |
| G3 | Ingestion from app and CRM (R9, important) | discovery | Airflow orchestration with no stated sources | Source ingestion is the first item in the JD's mandate | Syncing a product database into the warehouse; loading a CRM or a third-party API on a schedule; handling schema drift or backfills from an application source | A sanitized DAG, an architecture sketch, a README | `[grounded]` background silent on sources |
| G4 | BigQuery (R8, important) | transferability | dbt on Snowflake, no BigQuery | The JD's mandate names BigQuery, so a bridge with its limit stated is the honest position | Snowflake work that used warehouse-level cost or performance decisions you personally made | A small dbt project against BigQuery's public datasets, if you choose to build one | `[inferred]` bridge derived from your Snowflake and dbt work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The entity may be as described, but only the pasted about page backs it here; the posting may also be stale or aggregated | `[generic]` pattern for any unchecked posting, not a claim about this company | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Hiring manager unnamed | unknown | — | Your words: "The posting names no hiring manager." | Reporting line, and who judges the work, are unknown | `[grounded]` your statement | Who would this role report to, and what does that person's team look like? | unresolved |
| RR3 | Posted pay brackets the market median | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range is competitive for the title and level; whether it is base is unstated | `[grounded]` JD figure and the pasted report's median and interquartile range; `[generic]` the report is a market pattern, not this employer's offer | Is the range base salary, and how does equity add to it? | noted |
| RR4 | Scope and team size unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting: ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The role may be the main data engineer across three areas, wider than the one-domain scope the report calls typical | `[inferred]` from the JD's three areas against its silence on team; `[generic]` the report's typical scope | How many data engineers are on the team, and which of ingestion, warehouse and contracts does this role own? | unresolved |
| RR5 | Equity unspecified | unknown | — | "plus equity" | The grant's type, size, vesting and valuation are unknown, so total pay cannot be compared | `[grounded]` JD states equity with no terms | What is the equity grant: type, size, vesting and the latest valuation? | unresolved |
| RR6 | Recent Series C funding | positive_signal | — | "Series C ($52M, February 2026)" | The company reports funding for growth; this is its own statement, not independently checked | `[grounded]` the pasted about page, unchecked externally | What hiring plan for the data team does the Series C fund? | noted |

## Application plan

Nothing below is applied. Each row is a proposal, and its status says what approval it needs.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume summary line: "Data engineer, six years at a B2B payroll company: built the dbt project on Snowflake (about 180 models), used Airflow for orchestration, set up the Great Expectations test suite, and use Python and SQL daily." | see R3, R4, R5, R6, R7; every clause traces to your own sentences, and "used Airflow" keeps your wording without claiming ownership | `[grounded]` your background statement | resume_edits_pending_approval |
| E2 | Say plainly in the application: "I have built dbt on Snowflake; I have not used BigQuery yet." | see R8; states the adjacency and its limit | `[grounded]` your statement | pending your approval |
| W1 | Optional: a small dbt project on a public BigQuery dataset, so the limit in R8 narrows | see G4; not required to apply | `[inferred]` from the R8 limit | pending your approval |
| A1 | Confirm the posting is live on the company's own careers site before investing in the application | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | If your recruiter is involved with this role, ask for the hiring manager's name, the equity terms and whether the range is base | see RR2, RR3, RR5; your message does not say the recruiter represents this role | `[grounded]` your message, recruiter sent the pay report | pending your approval |
| Q1 | Ask the questions of RR2, RR4, RR5 and RR6 verbatim in the interview loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The fetch of pellucidlearning.com/careers/senior-data-engineer was refused (WebFetch permission not granted), so no page was read. It would have settled whether the posting is live and consistent, which feeds RR1 and role reality's contradictions row; RR1 stays unresolved |
| 2. Role-family sweep | skipped | The pasted Datawright 2026 report, in hand, already fixes the market calibration row, RR3 and RR4's comparison |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Closing

If you want it, I can save this as `tuesday-dossier.md`.

**Upgrade menu**

- Permission for the live-page fetch, or the live careers-page text → RR1 and the contradictions row close, and condition (1) clears.
- Your location, work authorization and pay floor → R1 and R2 settle; the decision likely moves to `go` or `no_go`.
- A sanitized dbt docs or lineage screenshot, a Great Expectations suite, or an Airflow DAG file → R5, R6 and R7 can rise from `medium` to `high`.
- A description of your ingestion sources and any data-contract work → R9 and R10 move off `unclear`.
- A small dbt project on BigQuery's public datasets → R8's limit narrows.
- The hiring manager's name → role reality's scope read and which story the plan leads with.
- A deeper research pass on Pellucid Learning (funding and leadership churn, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G1 — Are you based in the US with the right to work there, can you work remote or from Denver, and does $148,000–$166,000 meet your pay floor?

G2 — Have you set up or kept any agreement with analysts or upstream teams about table schemas, freshness or tests, and what did you own?

G3 — Which sources did your pipelines ingest from (app databases, a CRM, third-party APIs), and what did you build versus inherit?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.