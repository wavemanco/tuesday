I'll read the reference files the skill calls for before building the assessment.
**Yes, apply. You're a credible fit on the core requirements (R1, R2, R3, R4, R6), but I couldn't verify the employer, so the status is `conditional_go`.** Check that Harborlight and the posting are real before you put effort into the application (RR1).

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R6 · adjacent: R5 (define and maintain the metrics layer)
- `important` — adjacent: R7a (partner with PMs on roadmap decisions) · unclear: R7b (partner with clinicians), R8 (mentor two junior analysts)
- `preferred` — adjacent: R9b (HIPAA / regulated-data handling) · absent: R9a (healthcare data experience)

R5 — adjacent until you say who defined the metrics; R7b, R8 — nothing in what you wrote yet, so these are questions, not verdicts; R9a, R9b — the JD frames healthcare as a plus.

**Opportunity ledger.** The scope reads as concrete (RR4). The employer is unverified (RR1), pay is not stated (RR2), success measures are unstated (RR3), and the role bundles several specialties (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Harborlight and the live posting verify on its own careers site (RR1).
  2. Pay and level are checked against a floor you haven't given me yet (RR2).
  3. You can show you defined metrics and didn't only build dashboards on them (R5, G1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people, Series C, with a care-navigation app | `[grounded]` JD header; not independently verified (see Evidence status) |
| Mandate | Own product analytics for the app: metrics layer, A/B tests, self-serve Looker dashboards, PM and clinician partnership, mentoring two junior analysts | `[grounded]` JD |
| Requirements | 5+ years product analytics, expert SQL, experiment design at scale, Looker or similar, written communication; healthcare/HIPAA a plus | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD is silent |
| Scope read | Five duties on one product, including analytics-engineering-style work (the metrics layer) next to experimentation and BI. That is broad, and probably standard for a senior hire at a company this size | `[inferred]` from the duty list; `[generic]` for what is normal at this stage |
| Market calibration | Not established: no role-family sweep ran, so I give no pay band. The JD states no compensation | `[grounded]` JD silent on pay; no `[generic]` band offered |
| Unknowns | Compensation, reporting line, who owns the warehouse models under the metrics layer, what success looks like | `[grounded]` JD silence |
| Contradictions | None visible inside the JD; I couldn't check it against a careers page | `[grounded]` JD only |

## Evidence map

Your background was typed into the conversation, so it counts as self-report. That caps every row at `medium` until you add something I can inspect.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a ~2M-subscriber consumer-subscription company | `[grounded]` your intake message | none |
| R2 | Expert SQL | must_have | direct | medium | none | You state daily SQL on Snowflake across those years. "Expert" is a level you haven't evidenced beyond that, and a live SQL exercise is a common way to probe it | `[grounded]` your intake message; `[generic]` on how SQL is screened | offer: a sanitized complex query or model you wrote would raise to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | You state you designed and ran the program (30+ A/B tests a year), including the pricing test behind an 11% retention lift | `[grounded]` your intake message | offer: a sanitized write-up of the pricing test would raise to high |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | You state you built the Looker instance from scratch, with 40+ governed dashboards | `[grounded]` your intake message | offer: dashboard screenshots or an excerpt of the model code |
| R5 | Define and maintain the metrics layer | must_have | adjacent | medium | discovery | You built governed dashboards and a warehouse consent-state model. You haven't said you defined and owned the metric definitions others reuse. I won't assume it | `[grounded]` your intake message; `[inferred]` adjacency from "governed dashboards" | see G1 |
| R6 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You state you write the monthly metrics memo the exec team reads and present monthly to the VP Product | `[grounded]` your intake message | offer: a sanitized memo would raise to high |
| R7a | Partner with PMs to turn analysis into roadmap decisions | important | adjacent | medium | discovery | Monthly presentations to the VP Product show exposure. You haven't said an analysis changed a roadmap decision | `[grounded]` your intake message | see G5 |
| R7b | Partner with clinicians | important | unclear | low | discovery | Nothing in your background mentions subject-matter experts such as clinicians. A comparable partnership (operations, culinary, supply chain) may exist | `[grounded]` silence in your intake message | see G2 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | No evidence in what you wrote. Informal mentoring may exist | `[grounded]` silence in your intake message | see G3 |
| R9a | Healthcare data experience | preferred | absent | none | capability | You state you have never worked in healthcare. The JD calls it a plus | `[grounded]` your statement; `[grounded]` JD wording | see G6 |
| R9b | HIPAA / regulated-data handling | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the warehouse consent-state model. Limit: that is a different regime from HIPAA, and you haven't described PHI-specific practice | `[grounded]` your intake message; `[generic]` that HIPAA is a distinct regime | see G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R5, must_have) | discovery | Governed dashboards, but no statement that you defined the metrics | A must_have at `adjacent`, and the one most likely to move the decision | A shared metric dictionary or semantic-layer definitions others' dashboards reuse; resolving disagreeing numbers between teams; owning definitions of retention, churn or activation | A sanitized metric definition doc or an excerpt of the Looker model code | `[grounded]` CV-equivalent silence; `[inferred]` that this row weighs most |
| G2 | Clinician-style partnership (R7b, important) | discovery | No domain-expert partnership mentioned | The JD names clinicians as partners | Working with operations, culinary or nutrition staff to shape a test or a metric | A project brief or test write-up naming the partner | `[grounded]` silence in your intake message |
| G3 | Mentoring (R8, important) | discovery | Nothing mentioned | The JD names two direct mentees | Onboarding analysts, reviewing their queries or dashboards, running office hours, even without a title | A mentee's work you reviewed, or an onboarding doc | `[grounded]` silence in your intake message |
| G4 | HIPAA bridge (R9b, preferred) | transferability | GDPR/CCPA PII handling and a consent-state model. Limit: not PHI, and not the HIPAA rules. Strengthener: a short, honest summary of what the consent model enforced | Shows you handle regulated data carefully, without claiming a healthcare background | Access controls, retention and deletion rules, or data-minimization decisions you made | A consent-model diagram or spec | `[grounded]` your intake message; `[generic]` that this is a bridge, not equivalence |
| G5 | Roadmap influence (R7a, important) | discovery | Exposure to the VP Product, but not a decision your analysis changed | Roadmap decisions are the stated purpose of the work | A pricing or onboarding decision changed because of a test or analysis; a roadmap item cut or added on your evidence | The pricing test write-up | `[grounded]` your intake message |
| G6 | Healthcare domain (R9a, preferred) | capability | No healthcare experience, by your own statement | Preferred, so a minor risk, not a blocker | No credible closure on the CV side. Realistic path: learn care-navigation basics before interviews | None | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | (the JD gives no pay or level range) | The figure may sit anywhere relative to your expectations. I have no band to compare it with | `[grounded]` JD silence | What is the budgeted salary range for this post? | unresolved |
| RR3 | No success measures or first-year outcomes stated | unknown | — | "Own product analytics for our care-navigation app" | Accountability for a broad mandate without a stated definition of success | `[inferred]` from the JD's broad mandate against its silence on outcomes | What would a successful first year look like for this role? | unresolved |
| RR4 | Responsibilities are concrete and bounded | positive_signal | — | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker" | The duties are specific and the mentoring scope is named (two juniors) | `[grounded]` JD | Who owns the warehouse models the metrics layer sits on? | noted |
| RR5 | Several specialties bundled in one role | risk_signal | low | "define and maintain the metrics layer… design and analyze A/B tests… build self-serve dashboards… mentor two junior analysts" | The role may combine analytics engineering, experimentation, BI and people mentoring. That is a risk if no data-engineering support exists, though it is common at this stage | `[generic]` pattern, not a claim about this employer | Which of these duties do other teams (analytics engineering, data science) share with this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume line, in your words: "Built the company's Looker instance from scratch: 40+ governed dashboards" | R4 | `[grounded]` your intake message | pending your approval |
| E2 | Resume line, in your words: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift" | R3 | `[grounded]` your intake message | pending your approval |
| E3 | Resume line, in your words: "Write the monthly metrics memo read by the exec team; present monthly to the VP Product" | R6, R7a | `[grounded]` your intake message | pending your approval |
| E4 | Resume line, in your words: "Handled GDPR/CCPA consumer PII; built the consent-state model for the warehouse". Do not write HIPAA or healthcare | R9b | `[grounded]` your intake message | pending your approval |
| P1 | Positioning: lead with experimentation and Looker (R3, R4), then your memo-writing (R6) | These are the rows with strongest evidence | `[grounded]` the map | pending your approval |
| P2 | Positioning: if asked about healthcare, say plainly you haven't worked in it and point to the consent-state model as the nearest work. Don't call it HIPAA experience | R9a, R9b; the limit is part of the answer | `[grounded]` your statement | pending your approval |
| A1 | Confirm Harborlight and the live posting on its own careers site before applying | RR1 | `[grounded]` register | pending your approval |
| Q1 | Ask the verification questions of RR1, RR2, RR3 and RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Everything in this table, the positioning rows P1 and P2 included, is `resume_edits_pending_approval`. Nothing is final until you approve it.

## Evidence status

Verified: none yet. The research tier line below sits above the accounting table.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were sent ("Harborlight Health care navigation app careers Senior Product Analyst" and a role-family search); both were refused by the host, so nothing came back. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | The same refusal. It would have moved the market calibration row and a pay comparison for RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

I can save this as `tuesday-dossier.md` if you'd like.

## Upgrade menu

- Permission to run searches, or a link to the live posting on Harborlight's careers page → RR1 and role reality's organization row, and a pay band for RR2.
- The posted or recruiter-stated salary range → RR2 closes.
- Your actual CV file → bands can move off the intake ceiling.
- A sanitized metrics memo, dashboard screenshots or an excerpt of the Looker model code → R4, R5 and R6 toward `high`.
- A sanitized write-up of the pricing test → R3 and R7a toward `high`.
- Your pay floor, location and other non-negotiables → hard-gate rows appear in the map and the hard-gates line stops reading "checks unknown".
- The hiring manager's name → role reality's scope read and which story to lead with.

## Questions

**G1** — In your Looker work, did you personally define the metrics (such as retention or churn definitions, in a shared dictionary or in the model code) that other dashboards reused? Who settled it when two teams' numbers disagreed?

**G3** — Have you mentored, onboarded or managed analysts, formally or informally? What did you own?

**Constraints** — What are your non-negotiables for a role like this (pay floor, remote or location, schedule, work authorization)?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.