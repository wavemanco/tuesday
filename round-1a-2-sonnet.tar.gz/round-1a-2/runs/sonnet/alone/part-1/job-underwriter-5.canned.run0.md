I'm still reading the skill's reference files, mainly the snapshot format and the question rules. After that I'll write the assessment.
## Decision snapshot

**Yes, worth applying. R3, R4, R5, R7 and R8, your five `must_have` rows, are all `direct`, and the two open items are the R1 and R2 gates that only you can confirm. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R7, R8
- `important`: adjacent: R6 (BigQuery) · unclear: R9 (Ingestion from app and CRM), R10 (Data contracts analysts depend on)

R6 is a credible bridge through Snowflake, with its limit named (you have never used BigQuery). R9 and R10 are unclear because your background doesn't say either way.

**Opportunity ledger.** The role looks sound and pays at market. The salary is stated and sits around the market median (RR1), and the posting is live and matches the company's own pages (RR4). Equity terms, team and reporting line, and first-year success measures are unstated (RR2, RR3, RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 work for you, which only you can check; (2) the BigQuery gap is framed honestly as adjacent, never as BigQuery experience (R6); (3) the team and scope question gets a concrete answer in the loop (RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company About page, fetched via search; the company's own statement, not independently corroborated |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD, matches the live careers page |
| Stated requirements | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity; equity terms not stated | `[grounded]` JD |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| First-90-days and first-year outcomes | None stated | `[grounded]` JD silent |
| Scope read | The mandate spans two ingestion sources, warehouse modelling and contracts, with no team size or reporting line given. That may be broader than one domain's pipelines | `[inferred]` from the JD's scope language against the pay report's "typical scope" |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, interquartile range $139,000–$163,500, "Senior" typically 5–8 years, typically one domain's pipelines and no direct reports. The posting's range runs $3,000 below the median to $2,500 above the top of the interquartile range, and the title and seniority are ordinary against it | `[grounded]` your recruiter's Datawright 2026 report (n=2,310) for the band; `[grounded]` JD for the posting's figures; `[generic]` as a pattern, never this employer's offer |
| Unknowns | Equity terms, team and reporting line, hiring manager, success measures, how the Denver and remote options work in practice | `[grounded]` JD silent |
| Contradictions | None between the pasted JD, the live careers page and the About page | `[grounded]` both pages fetched |

## Evidence map

Your background was typed into the conversation. That counts as a self-report, so `medium` is the ceiling until something inspectable is attached.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you are or what you require, so the term is neither met nor failed | `[grounded]` JD term; candidate constraints not given | Ask whether it works for you (question Q1) |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor given, so I can't tell whether the range clears it. The band comparison is in role reality and RR1 | `[grounded]` JD figures; candidate constraints not given | Ask whether it clears your floor (question Q1) |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You have 6 years of data engineering. A years requirement is graded on fit, not treated as a gate | `[grounded]` your stated background | Raise to high with a dated role history if asked |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily" is specific. The level of "strong" has nothing inspectable behind it, so expect a probe | `[grounded]` your stated background | Sanitized code or model sample would raise to high |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built your company's dbt project on Snowflake, about 180 models, which meets "a cloud warehouse" as the JD's requirement list words it. BigQuery is R6 | `[grounded]` your stated background | Project docs or a lineage screenshot would raise to high |
| R6 | BigQuery as the warehouse | important | adjacent | medium | transferability | The responsibilities name BigQuery but the requirements list doesn't. Snowflake with dbt is a credible bridge. Limit: you have never used BigQuery. Whether switching is quick is a general expectation, not something your evidence shows | `[grounded]` your statement that you've never used BigQuery; `[inferred]` Snowflake bridge; `[generic]` warehouse switching expectation | See gap queue G1 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You use Airflow, which is the tool named. Scale and ownership are unstated | `[grounded]` your stated background | DAG overview would raise to high |
| R8 | Data quality testing | must_have | direct | medium | none | You set up your company's Great Expectations test suite. Coverage and results are unstated | `[grounded]` your stated background | Sanitized suite config would raise to high |
| R9 | Ingestion from the app and CRM | important | unclear | none | discovery | Your background is silent on ingestion or source systems | `[grounded]` background silence | See gap queue G2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Silent on contracts. Your Great Expectations suite is a plausible adjacent thread, but nothing says it worked as a contract with analysts | `[inferred]` from the GE suite against the JD's contract language | See gap queue G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6, important) | transferability | Confirmed dbt on Snowflake; confirmed no BigQuery use | The JD names BigQuery as the warehouse, so it is the likeliest point an interviewer presses | Any BigQuery use in a side project, course or sandbox; warehouse cost or performance tuning you did on Snowflake | A small sandbox project or a note on a Snowflake optimisation you did | `[inferred]` bridge from the Snowflake work; `[generic]` that this is the likeliest probe |
| G2 | Ingestion from the app and CRM (R9, important) | discovery | Nothing on how data reached your warehouse | The posting's first named responsibility | Loading from product databases or event streams; SaaS or CRM connectors; ownership of loads you monitored or fixed | An architecture diagram or source list, sanitized | `[grounded]` background silence |
| G3 | Data contracts (R10, important) | discovery | A GE suite exists, but no stated agreement with consumers | The JD says analysts depend on them | Schema or SLA agreements with analysts; breaking-change processes; documented column definitions | A sanitized contract, schema doc or change log | `[inferred]` from the GE suite; `[grounded]` JD language |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated, around the market median | positive_signal | — | "Salary $148,000–$166,000 plus equity." | Pay is disclosed and no seniority-compensation mismatch shows against the pasted report | `[grounded]` JD figures and the Datawright report | Where in the $148,000–$166,000 range would an offer for this role land, and what decides it? | noted |
| RR2 | Equity terms unstated | unknown | — | "plus equity" | Grant size, instrument, vesting and strike may be undefined or unpublished, so its value can't be weighed | `[inferred]` from the JD's silence | What is the equity grant for this level: instrument, size, vesting schedule and strike if options? | unresolved |
| RR3 | Team, reporting line and ownership unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may cover ingestion, modelling and contracts alone, broader than the "one domain, no reports" scope the report calls typical | `[inferred]` from the JD's scope against its silence; `[grounded]` pasted report for the typical scope | Who else is on the data team, who does this role report to, and which of ingestion, the warehouse and contracts does it own alone? | unresolved |
| RR4 | Posting live and consistent with company pages | positive_signal | — | "Accepting applications." | The employer and role exist as described on the company's own site | `[grounded]` careers and About pages fetched; own-site only | Who would I interview with, and what are the stages? | noted |
| RR5 | No first-year outcomes stated | unknown | — | JD states none | Success measures may be undefined, or just unpublished | `[inferred]` from the JD's silence | What would a successful first six months look like for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume line in your own words: "Built our dbt project on Snowflake — about 180 models." Keep "about" and don't add ownership or scale words | see R5 | `[grounded]` your stated background | pending your approval (`resume_edits_pending_approval`) |
| E2 | Resume line: "Set up our Great Expectations test suite." Don't add coverage figures or "program" language | see R8 | `[grounded]` your stated background | pending your approval (`resume_edits_pending_approval`) |
| E3 | Resume line: "Airflow for orchestration; Python and SQL daily." | see R4, R7 | `[grounded]` your stated background | pending your approval (`resume_edits_pending_approval`) |
| A1 | Say plainly that your warehouse work is Snowflake and BigQuery is new to you | see R6 | `[grounded]` your statement | pending your approval |
| A2 | Optionally do a small hands-on BigQuery exercise, so there's something true to say about it | see G1 | `[inferred]` from the R6 limit | pending your approval |
| A3 | Check R1 and R2 against your own constraints before investing in the loop | see R1, R2 | `[grounded]` the two gate rows | pending your approval |
| Q1 | Ask RR2, RR3 and RR5's questions verbatim in the interviews | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning tutoring Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about), and fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). Both match your pasted text and the posting reads "Accepting applications". Moved role reality's organization and contradictions rows and RR4. Both are the company's own pages, so funding and headcount are self-reported |
| 2. Role-family sweep | skipped | Your pasted Datawright report already fixes market calibration and RR1, and a further search would not change either |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

## Dossier and next steps

I can save this as `tuesday-dossier.md` if you'd like a record to keep or reuse.

**Upgrade menu**
- Where you're based and your pay floor and non-negotiables → R1 and R2 close, and the decision likely simplifies to `go`.
- A sanitized dbt project doc, DAG overview, or Great Expectations config → R3, R4, R5, R7 and R8 can reach `high`.
- Any BigQuery exposure, or a small sandbox project → R6's bridge strengthens (G1).
- A description of ingestion or data-contract work you did → R9 and R10 resolve (G2, G3).
- The hiring manager's name, if the recruiter has it → role reality's scope read sharpens.
- A deeper research pass on Pellucid Learning (funding and leadership changes, hiring patterns, public employee reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**
1. (R1, R2) Does the role work for you on both terms: are you in the US or willing to be in Denver, and does the $148,000–$166,000 base clear your floor?
2. (R9) Have you built or owned ingestion from product or CRM sources, and if so, what exactly was yours?
3. (R10) Did you ever agree schemas, SLAs or definitions with analysts or other consumers of your tables, and how?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.