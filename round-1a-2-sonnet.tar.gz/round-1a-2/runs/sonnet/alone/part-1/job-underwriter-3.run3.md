**Not worth pursuing as posted. R1 (pay) and R2 (location) are both hard gates, and both fail. Status: `no_go`.** What feels off is real. Even without those two, the posting stacks several risk signals (RR3, RR4, RR5, RR6).

I tried two web searches to check that Novaline exists and to calibrate pay. Both were refused, so this runs on the posting and what you told me.

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (Compensation: $70–85k base), R2 (On-site in Austin, 5 days a week)
- `must_have` — direct: R3, R4, R5, R6 · unclear: R7 (SEO/content)
- `important` — adjacent: R10 (Team of one to start) · unclear: R8 (Brand and PR), R9 (Partnerships and sales ops)

R1 — the posted base tops out at $85k, $65k under your floor; R2 — "no exceptions" on-site rules out remote-only; R4 (`medium`) — your strongest evidence, the $8M to $40M ARR scale-up.

**Opportunity ledger.** RR1 and RR2 are red flags for you specifically. RR3, RR4, RR5 and RR6 are risk signals that together read as a senior mandate priced and resourced like a junior one. RR8 leaves the employer unverified. RR9 is the one clear positive.

- **Hard gates:** failed: R1 (Compensation: $70–85k base), R2 (On-site in Austin, 5 days a week).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** Novaline would have to put in writing a base of at least $150k and a Portland-remote arrangement. Nothing in the posting suggests either is on offer.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement startup, Series A, "profitable since day one". The existence and these claims are not established | `[grounded]` JD header, self-described |
| Mandate | Own all revenue growth: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team and reporting | Team of one to start; reports to the CEO with a dotted line to the board | `[grounded]` JD |
| Working pattern | Evenings and weekends "when it matters"; Austin office 5 days a week, "no exceptions" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside", with no equity figure given | `[grounded]` JD |
| Success metrics | "Will evolve as we learn", so none stated | `[grounded]` JD |
| Scope read | Seven functions in one seat with no bench. That is several roles folded into one title | `[inferred]` from the function list against "team of one" |
| Market calibration | Not run. The role-family sweep was refused, so there is no band for this title and scope | `[grounded]` search refused |
| Unknowns | Equity size, budget, who the first hires are, what success is measured on, whether the posting is live | — |
| Contradictions | A "Head of" title and 8+ years required, with a team of one and a base far below your floor | `[inferred]` from the JD's own terms |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Compensation: $70–85k base (your floor: $150k) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor, which is specific and your own. The posted top of range is $65k below it | `[grounded]` JD and your stated constraint | Surface only; resolves only if Novaline changes the terms |
| R2 | On-site in Austin, 5 days a week, "no exceptions" (you: remote-only, Portland, no relocation) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated constraint. The posting rules out remote work explicitly | `[grounded]` JD and your stated constraint | Surface only; same as R1 |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You state 9 years, with Growth Lead then Head of Growth titles at two B2C subscription companies. This is self-report, with nothing inspectable yet | `[grounded]` your stated background | none |
| R4 | Own revenue growth end to end | must_have | direct | medium | none | You scaled one company from $8M to $40M ARR over three years with a budget you controlled. Self-report, with the company's own figures not yet inspected | `[grounded]` your stated background | none |
| R5 | Paid acquisition | must_have | direct | medium | none | You state you owned paid. The channels and spend are not given | `[grounded]` your stated background | none |
| R6 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze, GA4 and SQL | `[grounded]` your stated background | none |
| R7 | SEO/content | must_have | unclear | low | discovery | Your background says nothing about SEO or content. This is silence, not absence | `[grounded]` background silent on SEO | See G1 |
| R8 | Brand and PR | important | unclear | low | discovery | Not mentioned in your background | `[grounded]` background silent on brand and PR | See G2 |
| R9 | Partnerships and sales ops | important | unclear | low | discovery | Not mentioned in your background | `[grounded]` background silent on both | See G3 |
| R10 | Team of one to start | important | adjacent | medium | transferability | You built and managed teams of 3–7, which is the opposite shape. Limit: none of that shows you executing every channel yourself | `[grounded]` your team sizes; `[inferred]` that the contrast is the limit | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R7, must_have) | discovery | No SEO or content work in your stated background | R7 is a `must_have` row at `unclear`. It would not move the `no_go`, because R1 and R2 decide that | Owning organic traffic targets, directing a content calendar or writers, or an SEO-led experiment | A traffic dashboard screenshot or a content-program brief | `[grounded]` background silent; `[inferred]` it cannot move the decision |
| G2 | Brand and PR (R8, important) | discovery | Not in your background | Low decision impact while R1 and R2 stand | Launch announcements, press or agency work, brand-positioning projects | A launch brief or press coverage | `[grounded]` background silent |
| G3 | Partnerships and sales ops (R9, important) | discovery | Not in your background | Same as G2 | Affiliate or channel deals, CRM-to-sales handoffs, lead routing | A partner agreement or a routing-process doc | `[grounded]` background silent |
| G4 | Executing solo across channels (R10, important) | transferability | Team leadership is evidenced, solo execution is not | A bridge is credible but its limit is the point of the role | Stretches where you personally ran campaigns or builds hands-on | A campaign or experiment log you built yourself | `[inferred]` bridge from your team-building and hands-on SQL, GA4 and Braze depth |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay below your floor (R1) | red_flag | high | "$70–85k base plus meaningful equity upside" | The posted base cannot meet a $150k floor, and equity is unquantified | `[grounded]` the posted range against your stated floor | Is the base negotiable above $85k, and what is the equity grant and its terms? | confirmed |
| RR2 | On-site rule against remote-only (R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The posting rules out remote work and offers no flexibility | `[grounded]` JD terms against your stated constraint | Is any remote or Portland-based arrangement possible for this role? | confirmed |
| RR3 | Seniority-pay mismatch | risk_signal | medium | "8+ years growth leadership required… $70–85k base" | The mandate and years asked may be priced below what this seniority commands. The market sweep did not run, so this stays a risk signal | `[inferred]` from the title and years against the base | What is the budgeted compensation band for this seniority, and how was it set? | unresolved |
| RR4 | Seven functions, no bench | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops… a team of one" | Several full roles may be folded into one junior-priced seat | `[inferred]` from the function list against the stated team size | What budget and first hires are committed for the first year? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work may be the default rather than the exception | `[inferred]` from the posting's framing of overtime as identity | In the last quarter, how many evenings or weekends did the growth function actually work? | unresolved |
| RR6 | No success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You could be held accountable for outcomes that are never defined | `[inferred]` from the posting's silence on targets | What does success look like at 90 days and at 12 months, in numbers? | unresolved |
| RR7 | Equity undefined | unknown | — | "meaningful equity upside" | The size, vesting and strike price may be far from "meaningful" | `[generic]` pattern that vague equity language often hides small grants, not a claim about this employer | What percentage, vesting schedule and strike price are on offer? | unresolved |
| RR8 | Employer not established | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small for a public footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR9 | CEO reporting line with board access | positive_signal | — | "Report to the CEO with a dotted line to the board" | The role has senior visibility | `[grounded]` JD | Who on the board does the dotted line reach, and how often? | noted |

## Application plan

I'm proposing no CV language, since no edits are needed for a role that fails R1 and R2. Every row below is proposed, not decided, and needs your approval before anything goes out.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Skip the application as posted | R1 and R2 fail | `[grounded]` R1, R2 rows | pending your approval |
| A2 | If you want to test flexibility, ask Novaline for the pay band and remote terms before any application effort | R1, R2 and RR8: this settles whether the gates can move and whether the posting is real | `[grounded]` R1, R2 and RR8 rows | pending your approval |
| Q1 | If it proceeds, put RR1 to RR8's verification questions to them verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Head of Growth careers"; the call was refused, so nothing came back. It would have settled whether Novaline exists as described and whether the posting is live, which feeds role reality's organization row and RR8 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary Series A startup Austin base salary range"; the call was refused, so nothing came back. It would have supplied the market calibration line and confirmed or cleared RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you want a saved record of this assessment, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- The live posting link on Novaline's own careers page, or the recruiter's email domain → RR8 and the organization row can be checked.
- Permission to run the two refused searches again → market calibration for this title, and RR3 resolves.
- The hiring manager's name → role reality's scope read.
- Novaline's written answer on base pay and remote terms → R1, R2, RR1 and RR2 close, and the status could change.
- An SEO or content artifact, such as a traffic dashboard → R7 and G1.
- A brand, PR, partnership or sales-ops artifact → R8, R9, G2 and G3.
- A campaign log you executed hands-on → R10's bridge, G4.

R1/R2 — Do you want to ask Novaline whether the pay and the Portland-remote terms can move, or are both closed on your side? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.