Loaded the underwriting method and read the posting. Next I'm running the budgeted research on Quillfield, the salary band and the hiring manager, then I'll write the assessment.
**Should you go for it? Yes, apply, but on conditions. Status: `conditional_go`.** The stretch is R7 (owning a forecast) and R9 (billing data). R1 (Bristol hybrid) and R2 (£61,500–£67,000) still need your answer.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol, hybrid two days), R2 (Salary £61,500–£67,000)
- `must_have` — direct: R3, R4, R5 · adjacent: R6 (spreadsheet modelling), R7 (owning a forecast) · unclear: R8 (finance on revenue data) · absent: R9 (billing data)
- `important` — direct: R10

R7 — a credible bridge, its limit named; R9 — no billing-data evidence, a real gap; R1, R2 — your answers settle them.

**Opportunity ledger.** Pay and location are stated (RR4) at a funded Bristol company (RR6). Against that, the posting is not yet seen on Quillfield's own site (RR1), forecast ownership is unclear (RR2), share-option terms are withheld (RR3), and success measures are absent for a multi-part mandate (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, hybrid two days), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 meet your own constraints; (2) the posting is confirmed on Quillfield's own careers page or from the recruiter's company address — RR1; (3) you apply framing R7 as adjacent and R9 as a gap you will own, not hide — R7, R9, RR2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` About Quillfield page (the company's own account) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| First-year outcomes | Not stated | `[grounded]` posting silent |
| Reporting line | Tamsin Achebe is listed as Head of Revenue Operations at Quillfield, so this role likely sits under a dedicated RevOps head | `[inferred]` from her profile title and the recruiter's naming her as hiring manager |
| Hiring manager's path | Four years in sales operations at a payments company before Quillfield | `[grounded]` public profile snippet |
| Scope read | CRM, billing data, reporting and forecast in one role is broad for one title, and it sits beside a stated RevOps head | `[inferred]` from the mandate against the reporting line; RR5 |
| Market calibration | The posted range sits around the median of a UK-wide survey of RevOps leads at B2B software firms (median £64,200, interquartile range £57,800–£70,400, n=438). It is not Bristol-specific, and it says nothing of title or scope norms | `[generic]` pay survey; `[grounded]` posted range |
| Unknowns | Posting live on Quillfield's own site; who owns the forecast number; share-option terms; team size | — |
| Contradictions | None between the posting and the About page; the careers address I tried returned no page | `[grounded]` fetch result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You gave no location or commuting limit, so there is no statement of yours to grade and the posting's term is unmatched | `[grounded]` posting term; your message silent | Ask whether this works (question below) |
| R2 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | No pay floor from you yet; the figure is stated, so only your floor is missing | `[grounded]` posting; your message silent | Ask your floor (question below) |
| R3 | 4+ years in RevOps, sales ops or similar analytics at a B2B software company | must_have | direct | medium | discovery | Five years in sales operations, two of them running RevOps, clears the years. Whether a B2B payments company counts as "B2B software" is not established; self-reported | `[grounded]` your background; years requirement is experience, not a gate | Confirm product type at your employer |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, stated specifically; certificate not yet inspected | `[grounded]` your background | Offer: certification record would raise to `high` |
| R5 | Strong SQL | must_have | direct | medium | none | SQL weekly, stated; "strong" is not yet evidenced beyond frequency | `[grounded]` your background | Offer: a sanitized query or report would raise it |
| R6 | Spreadsheet modelling | must_have | adjacent | low | discovery | Excel daily is stated; nothing says whether it includes building models as opposed to using spreadsheets | `[grounded]` your background; the gap between use and modelling is mine | See G4 |
| R7 | Experience owning a forecast (posting also: run the quarterly forecast with the CFO) | must_have | adjacent | medium | transferability | You never owned the forecast (finance did) but run the monthly pipeline review with your sales director. Limit: supplying the pipeline view is not owning the number. Postings phrased as "experience owning" are often read literally | `[grounded]` your statement; `[generic]` on literal reading | See G1; frame honestly as adjacent |
| R8 | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | Renewal dashboards suggest revenue-adjacent work, but nothing says finance used them or that you worked with them on the data | `[inferred]` from the renewal dashboards you rebuilt | See G3 |
| R9 | Billing data (own CRM and billing data) | must_have | absent | none | capability | You have not worked on billing data; no adjacent evidence stated | `[grounded]` your statement | Name the gap plainly; closure path in G2 |
| R10 | Build the pipeline and renewal reporting sales and finance run on | important | direct | medium | none | You rebuilt pipeline and renewal dashboards; whether finance used them is R8's question | `[grounded]` your background | Offer: a sanitized dashboard screenshot would raise it |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R7, must_have) | transferability | You ran the monthly pipeline review but finance owned the forecast | R7 is `must_have` at `adjacent`; the strength of the bridge decides how the application reads | Supplying coverage, conversion or commit views finance used; challenging a number in the review; rolling pipeline into a forecast sheet | A sanitized pipeline-to-forecast sheet or review pack | `[grounded]` your statement; `[generic]` that this is the likeliest objection |
| G2 | Billing data (R9, must_have) | capability | No evidence of billing-data work | R9 is a `must_have` at `absent`; the role owns billing data | Closure path: learn how billing data reaches the CRM and finance reports, and offer a small scoped example; consider asking in the process whether the role has support on it | None yet | `[grounded]` your statement; `[inferred]` closure path |
| G3 | Working with finance on revenue data (R8, must_have) | discovery | Renewal dashboards exist; finance's involvement is not stated | Could move R8 to `adjacent` or `direct` | Reconciling renewals against finance's figures; a dashboard finance asked for; agreeing definitions such as renewal or churn with finance | A dashboard screenshot, a metric-definition doc | `[grounded]` your background silent on finance; `[inferred]` that it may exist |
| G4 | Spreadsheet modelling (R6, must_have) | discovery | Excel daily, not modelling | Cheap to close and a screen target | A model with assumptions you built for pipeline or renewals | A sanitized model | `[grounded]` your background; `[generic]` that "modelling" is read as built models |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not yet seen on the company's own site | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | The role is likely live, but I could not confirm it on Quillfield's own careers page, so the board listing stands alone | `[grounded]` fetch of the guessed careers address returned no page; `[inferred]` the posting may sit elsewhere on their site | Can you point me to this role on Quillfield's own careers page? | unresolved |
| RR2 | Forecast ownership unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The forecast may be owned by the CFO or the RevOps head, with this role supporting | `[inferred]` from "with the CFO" and the stated Head of Revenue Operations | Who owns the forecast number, and what does "run with the CFO" mean day to day? | unresolved |
| RR3 | Share-option terms withheld | unknown | — | "plus share options" | Terms may be standard; value cannot be judged from the posting | `[grounded]` posting names options without terms | What are the option terms: number, strike price and vesting? | unresolved |
| RR4 | Pay and location stated | positive_signal | — | "£61,500–£67,000 plus share options" | The posting is transparent on the terms most often withheld | `[grounded]` posting; `[generic]` survey band, UK-wide | What drives where in the range an offer lands? | noted |
| RR5 | Broad mandate, no success measures | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting…, and run the quarterly revenue forecast" | Several jobs in one title with no stated first-year outcomes; low because the reporting line suggests support exists | `[inferred]` from the mandate and the stated RevOps head | What does success look like at six and twelve months, and who else is on the team? | unresolved |
| RR6 | Funded, established employer | positive_signal | — | "Series A (£11M) closed in April 2025" | The company exists as described and recently raised | `[grounded]` About page (company's own claim, unverified elsewhere) | How is the revenue team expected to grow? | noted |

## Application plan

These are proposals, including the prose advice: nothing below is final until you approve it, and no line goes on a CV or to the employer on its own.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with: "Ran revenue operations for the UK team (two years); rebuilt the pipeline and renewal dashboards; run the monthly pipeline review with the sales director" | R10, R3 — reorders your own claims, adds nothing | `[grounded]` your background | pending your approval |
| A1 | On forecasting say what was yours: you supplied the pipeline view in the review and finance owned the forecast; do not describe it as owning | R7's limit stays named | `[grounded]` R7 | pending your approval |
| A2 | Say plainly that billing data is new to you, and ask how the role is supported on it | R9 is absent; candour beats discovery in the loop | `[grounded]` R9 | pending your approval |
| A3 | Confirm R1 and R2 before investing in the application | Hard gates unconfirmed | `[grounded]` hard-gates line | pending your approval |
| Q1 | Ask RR1, RR2, RR3 and RR5's questions verbatim of the recruiter or Tamsin | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P1 | Her own path runs through sales operations, so a sales-ops-to-RevOps story is one she has walked herself | Positioning for this reader | `[inferred]` from her profile snippet | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company", which returned "About Quillfield" (quillfield.co.uk/about); fetched quillfield.co.uk/careers, which returned no page. Moved: organization row, and RR1 |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary Bristol B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved: market calibration and RR4; it gave pay only, not scope norms |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved: reporting-line row and P1; no talks or writing found |

I can write this up as `tuesday-dossier.md` if you want to keep it.

**Upgrade menu**

- Your location and pay floor, plus any other non-negotiables → R1 and R2 become met or failed, and the hard-gates line stops saying checks are unknown.
- Your answers to G1 and G3 → R7 and R8 move or are confirmed.
- Your CV, a Salesforce certification record and a sanitized dashboard screenshot → R3, R4 and R10 toward `high`, and edits proposed against your actual text.
- The recruiter's email domain or Quillfield's own listing → RR1 closes.
- A deeper research pass on Quillfield (funding, leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

R1, R2 — Does Bristol with two office days a week work for you, and is £61,500 the bottom of what you would accept?
G3 — Have you built or reconciled any reporting that finance used or checked, such as renewal revenue, and is your employer's product software?
G1 — In your monthly pipeline review, what did you supply that fed the forecast: coverage, conversion or commit views?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.