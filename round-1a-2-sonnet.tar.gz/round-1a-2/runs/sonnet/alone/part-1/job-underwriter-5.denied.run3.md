I'll read the reference files before building the assessment.
**Yes, it's worth applying, on three conditions: `conditional_go`.** Your direct evidence covers the whole must-have tier (R3, R4, R5a, R5b, R6, R7). BigQuery (R8) is a bridge from Snowflake, not a block.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver), R2 (Pay range)
- `must_have`: direct: R3, R4, R5a, R5b, R6, R7
- `important`: adjacent: R8 (BigQuery-modelled warehouse); unclear: R9 (Ingestion from app and CRM), R10 (Data contracts)

R8 (`medium`) — a credible bridge, its limit named; R9, R10 — unconfirmed, waiting on your answers.

**Opportunity ledger.** The pay is stated and sits against the market band (RR2). Team size, the "run" remit and the reporting line are unstated (RR1, RR5, RR4). The employer's own pages could not be checked from here (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Pay range); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the live posting check out (RR3); (2) you confirm US location and authorization, and that the pay range clears your floor (R1, R2); (3) the BigQuery bridge is framed as adjacent, never as BigQuery experience (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the About text you pasted; not checked against the live site |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Stated requirements | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity; equity terms not stated | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | The posting lists three areas (ingestion, warehouse, contracts) and names no team or direct reports, so scope may be broader than a single domain's pipelines | `[inferred]` from the JD's three areas against the pasted report's typical scope |
| Market calibration | Report band for Senior Data Engineer at Series B–D companies: median $151,000, interquartile range $139,000–$163,500, "Senior" typically 5–8 years, typical scope one domain's pipelines with no direct reports. The posting's low end is $3,000 below that median and its top is $2,500 above the 75th percentile. A band is a pattern, not this employer's offer. | `[generic]` Datawright 2026 Data Engineering Pay Report, US, n=2,310, supplied by your recruiter and not independently checked; `[grounded]` JD range |
| Unknowns | Team size; what "run" involves; reporting line; equity terms; first-year outcomes | `[grounded]` the posting is silent on each |
| Contradictions | The JD and the About text you pasted don't contradict each other. The live careers page was not checked. | `[grounded]` the two pasted texts |

## Evidence map

Your background is typed prose, so it counts like a CV: leads, not proof, and `medium` is the ceiling.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't stated where you are or your work authorization, so nothing settles whether the term is met | `[grounded]` JD term; no candidate statement given | Question G1 |
| R2 | Pay $148,000–$166,000 | hard_gate | unclear | none | hard_gate | No pay floor was given, so the range can't be checked against it | `[grounded]` JD figure; no floor stated | Upgrade menu: your pay floor |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. Confirmed prose with no inspectable artifact yet. | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. "Strong" is the JD's word and rests on your say-so until something inspectable backs it. | `[grounded]` your background | none |
| R5a | dbt | must_have | direct | medium | none | You built the company's dbt project, about 180 models. Specific, no artifact inspected. | `[grounded]` your background | Offer: sanitized dbt docs or lineage page would raise to high |
| R5b | A cloud warehouse | must_have | direct | medium | none | That project ran on Snowflake, a cloud warehouse. The JD asks for "a cloud warehouse"; its own warehouse is BigQuery (see R8). | `[grounded]` your background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow for orchestration. Confirmed but unspecific on scale. | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. Specific, no artifact inspected. | `[grounded]` your background | Offer: a sanitized list of the suite's checks would raise to high |
| R8 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Adjacent: dbt modelling on Snowflake carries over. Limit: you've never used BigQuery, so its cost model, partitioning and access setup are unexercised. Taken at `medium` as the lower of two plausible bands. | `[grounded]` your background; `[generic]` that warehouse specifics are what get probed when a named warehouse is new to a candidate | Gap G4: bridge case |
| R9 | Ingestion from the app and the CRM | important | unclear | low | discovery | You describe Airflow pipelines, which is indirect context, but not which source systems you brought in or how | `[grounded]` background silent on sources | Question G2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Your Great Expectations suite is indirect context. Whether analysts relied on agreed definitions or checks is not stated. | `[grounded]` background silent on consumers | Question G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms (R1, R2, hard_gate) | hard_gate | No location, authorization or pay floor given | A failed gate would end the application however strong the fit | Not applicable: these are terms you meet or don't | Nothing to attach; your own statement settles it | `[grounded]` inputs silent; `[generic]` that gates settle before fit does |
| G2 | Ingestion from app and CRM (R9, important) | discovery | Airflow pipelines stated; source systems not | It is half of the posting's first-named responsibility; an answer could move R9 to `direct` or `adjacent` | Loading from an application database, an event stream, or a SaaS API like a CRM; building a backfill or incremental load; handling a source's schema change | A DAG screenshot, an ingestion README, or a source list | `[grounded]` background silent; `[inferred]` that it bears on the decision |
| G3 | Data contracts (R10, important) | discovery | Great Expectations tests stated; downstream consumers not | The posting names the contracts analysts depend on as a deliverable | Agreeing column definitions with analysts; schema or freshness tests that blocked bad loads; a written spec for a shared table | A sanitized spec, test list, or a message thread with analysts | `[grounded]` background silent; `[inferred]` from the JD's wording |
| G4 | BigQuery (R8, important) | transferability | dbt on Snowflake, no BigQuery | The only named-stack element you haven't touched | Bridge: dbt modelling, SQL, and warehouse work carry over. Limit: BigQuery-specific cost and layout choices were never exercised. Strengthener: a small dbt project run against BigQuery, if you choose to build one. | A public repo of that project | `[inferred]` adjacency derived from your Snowflake and dbt work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Scope and team size unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You could be one of few engineers covering ingestion, warehouse and contracts, wider than the report's typical one-domain scope | `[inferred]` from the JD's three areas against its silence on team; `[generic]` the report's typical scope | How many data engineers are on the team, and which of ingestion, warehouse modelling and contracts would this role own alone? | unresolved |
| RR2 | Pay stated and in the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Range runs from $3,000 below the report median to $2,500 above its 75th percentile, so competitive for the level; equity terms are unstated | `[grounded]` JD range; `[generic]` band from the pasted report | What are the equity terms: grant size, vesting, and valuation basis? | noted |
| RR3 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The About text is the company's own statement and was not checked here. The posting could be stale, or differ from the live careers page. | `[generic]` pattern for any posting not yet checked, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR4 | No hiring manager named | unknown | — | "The posting names no hiring manager" (your note) | The reporting line, data-led or engineering-led, is unknown and shapes scope | `[grounded]` posting names no one | Who would this role report to, and which analysts depend on these pipelines? | unresolved |
| RR5 | What "run" involves | unknown | — | "Build and run the pipelines" | "Run" may include on-call or incident response; the JD doesn't say | `[inferred]` from the verb "run" against the JD's silence | Is there an on-call rotation, and how often do pipelines page? | unresolved |

## Application plan

Everything in this section is proposed, pending your approval, including the prose positioning lines.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume line, `resume_edits_pending_approval`: "Built the dbt project (about 180 models) on Snowflake; used Airflow for orchestration; set up the Great Expectations test suite." Every clause traces to your sentences; I haven't seen your CV, so this is a starting point. | See R5a, R6, R7 | `[grounded]` your background | pending your approval |
| E2 | Positioning sentence for the letter or recruiter: "My warehouse experience is on Snowflake; I haven't used BigQuery." It states the limit before they find it. | See R8 | `[grounded]` your background | pending your approval |
| W1 | Optional: a small public dbt project on BigQuery as a work sample | See G4 | `[inferred]` strengthener for the adjacency | pending your approval |
| Q1 | Ask the register's questions (RR1, RR2, RR4, RR5) verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Open the role on the careers page and confirm it is live before investing effort | See RR3 | `[grounded]` RR3 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One search was sent ("Pellucid Learning Senior Data Engineer careers online tutoring K-12") and refused, so no pages were fetched. It would have moved role reality's contradictions row and the employer-not-established entry RR3. |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes the market calibration row and the pay comparison in RR2. |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form. |

I can write all of this up as `tuesday-dossier.md` if you want a copy to keep.

**Upgrade menu**

- Your CV: I could check whether the dbt scale and Great Expectations work are visible, and tighten E1 against your actual text.
- A sanitized dbt docs or lineage page, or a list of the test suite's checks: R5a and R7 could move to `high`.
- Your pay floor: it closes R2.
- The hiring manager's name, if you learn it: it sharpens the scope read and which story the plan leads with.
- Search access: I could check the live careers page and company facts, which would move RR3. A deeper pass on funding, hiring patterns and recent news would be up to 5 more searches and 2 more fetches, and runs only if you say so.

**Questions**

G1 — Are you based in the US and authorized to work there without sponsorship?

G2 — Which source systems did you personally bring into Snowflake at the payroll company, and what did you build to do it?

G3 — Did analysts or other teams depend on tables you owned, and was there an agreed definition or check behind them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.