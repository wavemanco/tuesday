I'll read the reference files the skill requires before building the assessment.
# Job Underwriting Assessment: Senior Pricing Analyst, Brindlemoor

## Decision snapshot

**Yes, worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK)
- `must_have`: direct: R2, R3, R4, R5, R6a, R7a · adjacent: R8a (Recommendations to underwriting) · unclear: R6b (Monitor rating models), R7b (Design price tests)
- `important`: unclear: R8b (Recommendations to product)
- `preferred`: direct: R9 · adjacent: R10 (Pet-insurance product knowledge)

R4 (`medium`): the GLM work, named in the JD's own terms; R6b and R7b: the "monitor" and "design" halves are not yet stated; R10: a bridge, its limit named in the map.

**Opportunity ledger.** The employer could not be established from here (RR1), pay and contract terms are unstated (RR2), and decision rights, team and first-year outcomes are unstated (RR3, RR4). The posting's duties are specific and coherent (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, see RR1; (2) you confirm you are UK-based with the right to work there, see R1; (3) the "monitor" and "design" halves are confirmed before they appear in anything you send, see R6b and R7b.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech, with a pet-insurance product | `[grounded]` JD header; existence not established, see RR1 |
| Role and manager | Senior Pricing Analyst, reporting to Odile Varga, Director of Pricing | `[grounded]` JD and your message |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| People management | Not listed among the requirements or duties; the posting is silent on direct reports | `[grounded]` JD silence |
| Scope read | One product, with the analyst "owning" its pricing analytics; whether that means sole analyst or lead of a small function is not stated | `[inferred]` from "Own" against the JD's silence on team |
| Domain difference | Pet rating typically turns on different factors from motor, such as species, breed and age, with vet-cost trends in the mix; the GLM method carries over but the factors do not | `[generic]` role-family pattern, not a claim about this employer |
| Market calibration | Not established. The role-family search was not run (see Evidence status), so no pay band is given | `[grounded]` JD states no salary; no band offered |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Unknowns | Pay; contract type; decision rights; team size; rating and price-testing tooling | `[grounded]` JD silence |
| Contradictions | None visible inside the JD; not checked against a careers page | `[grounded]` JD only |

## Evidence map

Your background was typed in, so it counts as a self-reported lead at intake, and `medium` is the ceiling for it.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | Your location and right to work are not stated; a UK employer suggests UK-based but that is a lead, not a statement | `[grounded]` JD term; `[inferred]` from "a UK motor insurer" | Ask R1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics, the last 2 as senior analyst. A years requirement is graded as experience, not a gate | `[grounded]` your background | Offer: a CV with dates would raise it |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily" is specific; "strong" has no inspectable proof yet, so expect a probe | `[grounded]` your background | Offer: a sanitised query or notebook would raise it |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book; specific, with limited inspectable proof | `[grounded]` your background | Offer: a sanitised model summary or review paper would raise it |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting. The audience is underwriting, which the JD names | `[grounded]` your background | Offer: a sanitised review deck would raise it |
| R6a | Build rating models | must_have | direct | medium | none | "Built and maintained the GLM rating model" covers the build half | `[grounded]` your background | none |
| R6b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" does not say what was tracked or how often, and I will not read monitoring into it | `[grounded]` your wording; the monitoring practice itself is unconfirmed | Ask G1 below |
| R7a | Read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your background | Offer: a sanitised test readout would raise it |
| R7b | Design price tests | must_have | unclear | low | discovery | "Ran" does not say who set the cells, duration or success measure | `[grounded]` your wording | Ask G2 below |
| R8a | Turn results into recommendations for underwriting | must_have | adjacent | low | discovery | Tests were run with underwriting and results are presented to its head, but recommending is not stated; taking the lower band | `[grounded]` your background | See G3; not asked this turn |
| R8b | Recommendations to product | important | unclear | none | discovery | Nothing in your background touches a product team | `[grounded]` silence | See G3; not asked this turn |
| R9 | Insurance experience a plus | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance product knowledge | preferred | adjacent | medium | transferability | Motor GLM rating work is credible adjacent method. Limit: no pet-specific factors or claims patterns exercised. Not a stated JD requirement; it is included because you raised it | `[inferred]` bridge from your GLM work; `[generic]` that pet and motor rating factors differ | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R6b, must_have) | discovery | "Built and maintained" a GLM; nothing on tracking, cadence or triggers for a refresh | The JD pairs "build" with "monitor", so this decides whether the mandate is covered or only half of it | Tracking actual versus expected by rating factor; a scheduled refresh; a monitoring pack someone else read; a review that led to a rebuild | A sanitised monitoring pack, model review paper or dashboard screenshot | `[grounded]` CV-equivalent silence; `[inferred]` that it could move R6b |
| G2 | Designing price tests (R7b, must_have) | discovery | 14 tests "ran" with underwriting; your role in setting them up is not stated | The JD pairs "design" with "read"; test design is a likely interview probe | Choosing test and control cells; setting duration or sample size; defining the success measure; writing the test brief | A sanitised test brief or readout | `[grounded]` wording; `[generic]` that roles like this probe design versus execution |
| G3 | Recommendations to underwriting and product (R8a, must_have; R8b, important) | discovery | Presents a quarterly review; no recommendation or product-team work stated | The JD's last duty is this one; underwriting is partly covered, product not at all | A rate change you proposed that underwriting acted on; a test result that changed a product feature | A sanitised recommendation memo or review slide | `[grounded]` background silence |
| G4 | Pet-insurance knowledge (R10, preferred) | transferability | Adjacent: GLM rating for a young-driver motor book. Limit: no pet-specific factors, claims patterns or breed and age effects exercised. Strengthener: a short note on how your approach would carry over | A preferred row, so a minor risk, but the most obvious question you will get | Any exposure to non-motor lines, animal or health-cost data, or segment-specific rating | A one-page adaptation note (proposed in the plan below) | `[inferred]` bridge; `[generic]` that this is the likely objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who I would be interviewing with? | unresolved |
| RR2 | Pay and contract terms unstated | unknown | — | (the posting as pasted states no salary or contract type) | The figure may sit outside the usual range for the title, or the firm may publish pay only at interview | `[grounded]` absence in the pasted JD; no market band available to compare | What is the salary range, and is the post permanent? | unresolved |
| RR3 | Decision rights unstated | unknown | — | "turn the results into recommendations for underwriting and product" | The role may carry accountability for pricing outcomes while rate decisions sit with underwriting or product | `[inferred]` from "recommendations" against the JD's silence on authority | Which pricing decisions does this role make itself, and which does it only recommend? | unresolved |
| RR4 | Team, tooling and first-year outcomes unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Own" may mean sole analyst, with testing and rating infrastructure still to build | `[inferred]` from "Own" against the JD's silence on team | Who else is on the pricing team, what tooling is in place, and what should this role deliver in its first year? | unresolved |
| RR5 | Duties are specific and coherent | positive_signal | — | "build and monitor rating models, design and read price tests" | The duties map onto the stated requirements, and the hiring manager's title is named | `[grounded]` JD | What does your current price-testing cadence look like? | noted |

## Application plan

Everything in this table is proposed, `resume_edits_pending_approval`, and finalized only when you say so. Each proposed line uses your own wording and adds no verb, scope or outcome you did not state.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the employer and that the posting is live (careers site, recruiter's email domain) before writing the application | RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead with: "Built and maintained the GLM rating model for our young-driver book" and "Ran 14 price tests last year with the underwriting team" | R4, R6a, R7a | `[grounded]` your wording | pending your approval |
| E2 | State the domain limit plainly if asked: "My rating experience is in motor; I haven't worked on pet insurance" | R10 | `[grounded]` your statement | pending your approval |
| E3 | If asked about management: "I haven't managed anyone" | The JD lists no people-management requirement, so this is an answer to give if asked, not something to volunteer | `[grounded]` JD silence, your statement | pending your approval |
| E4 | Do not write "designed" for the tests, "monitored" for the model, or "recommended to product" until G2, G1 and G3 are confirmed | R6b, R7b, R8a, R8b | `[grounded]` the map | pending your approval |
| W1 | Optional one-page note on how your GLM approach would adapt to pet rating factors | G4 | `[inferred]` bridge | pending your approval |
| Q1 | Ask RR2, RR3 and RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech careers"; the call was refused, so nothing was read. It would have moved role reality's organization and contradictions rows, and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst UK insurance salary remote pet insurance"; the call was refused. It would have moved the market-calibration row and RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; the call was refused. It would have moved the scope read and which of your verified stories the plan leads with |

I can save all of this as `tuesday-dossier.md` if you'd like a copy to keep.

## Upgrade menu

- Permission to run web search, then rows 1–3 re-run. That would settle RR1, give a pay band for RR2, and add Odile Varga's public professional footprint to the scope read.
- A link to the live posting or Brindlemoor's careers page, which clears RR1 on its own.
- Your CV with dates: R2 and R3 firm up, and any presentation gaps become concrete edits in a table.
- A sanitised monitoring pack or model review paper: R6b and R4 move up.
- A sanitised test brief or readout: R7b and R7a move up.
- A sanitised recommendation memo or review slide: R8a and R8b move up.
- Any terms you won't trade (pay floor, permanent or fixed-term, hours): hard-gate rows for each are added and RR2 is compared against them.

R1 — Are you based in the UK, with the right to work there?

G2 — Which parts of your 14 price tests did you personally set up (the test and control cells, the duration or sample size, the success measure), and who decided the result?

G1 — After you built the young-driver GLM, how did you monitor it: what did you track, how often, and did it ever lead to a change?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.