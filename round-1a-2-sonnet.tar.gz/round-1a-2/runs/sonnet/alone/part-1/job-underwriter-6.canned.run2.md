Still working: I've fetched the posting and read the skill's output rules. I'm now checking its evidence conventions, then I'll write the assessment.
**Yes, apply, on conditions (`conditional_go`).** The core of the job matches what you do: R3, R4, R5a and R8 are `direct`. Two requirements the posting lists are real gaps: owning a forecast (R6, `adjacent`) and billing data (R7b, `absent`). Neither looks like a reason to hold back, but you shouldn't hide either.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000)
- `must_have` — direct: R3, R4, R5a, R8 · adjacent: R6 (Experience owning a forecast) · unclear: R5b (Spreadsheet modelling), R7a (Working with finance on revenue data) · absent: R7b (Billing data experience)

R6 — a credible bridge through your monthly pipeline review, its limit named; R7b — the widest gap, no billing exposure; R5b — modelling unconfirmed beyond daily Excel use.

**Opportunity ledger.** A sound, well-paid role with scope still to pin down. Reports and first-year outcomes are unstated (RR1, RR3), the scope bundles CRM, billing data, reporting and forecasting (RR2), and I haven't seen the posting on Quillfield's own careers page (RR5). The salary is stated and within the pay-guide range (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location and pay floor are confirmed against R1 and R2; (2) the interview pins down what "run the quarterly revenue forecast with the CFO" means for a new hire, and how much billing ramp-up is expected — R6, R7b, RR1, RR3; (3) the posting is confirmed on Quillfield's own site — RR5; (4) your forecast and billing story is framed as adjacent, never as ownership you haven't held.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` "About Quillfield" page, seen as a search snippet |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Working pattern and pay | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` JD |
| Hiring manager | Tamsin Achebe's public profile reads Head of Revenue Operations at Quillfield, previously sales operations manager at a payments company | `[grounded]` one search snippet; the page itself was not opened |
| Scope read | Broad for a "Lead": CRM, billing data, reporting and an exec-facing forecast in one post. Reporting into a Head of RevOps rather than the CFO is likely | `[inferred]` from the JD's four duties and the hiring manager's title |
| Market calibration | The pay guide gives a median base of £64,200 and an interquartile range of £57,800–£70,400 for UK B2B software RevOps leads. The posting's range sits inside that range, so pay is not a mismatch (RR4). The band is UK-wide, not Bristol-specific, and is not this employer's offer | `[generic]` 2026 pay guide, n=438 |
| Unknowns | Direct reports; first-year outcomes; which CRM is in use (the JD says HubSpot or Salesforce); share option terms | `[grounded]` JD silence |
| Contradictions | None between the JD and the About page. The posting is hosted on Tallyboard, and no Quillfield careers page surfaced | `[grounded]` search results |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You haven't said where you live or what working pattern you will accept, so nothing settles it | `[grounded]` JD term, no candidate constraint given | Q1 below |
| R2 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | No pay floor given, so the range can't be tested against it | `[grounded]` JD figure, no candidate constraint given | Q1 below |
| R3 | 4+ years in RevOps, sales ops or similar analytics at a B2B software company | must_have | direct | medium | none | 5 years in sales ops, the last 2 running RevOps for the UK team. A length-of-experience requirement is not a gate. Limit: "B2B payments company" is not confirmed as a software business | `[grounded]` your account in this chat; no CV yet | Confirm employer type; a CV would raise it |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. The certificate has not been inspected | `[grounded]` your account | A certification link would raise to high |
| R5a | Strong SQL | must_have | direct | medium | none | SQL weekly. "Strong" is not yet shown by an artifact | `[grounded]` your account | A sanitised query or schema would raise it |
| R5b | Spreadsheet modelling | must_have | unclear | low | discovery | Excel daily is use, not necessarily modelling. Nothing says what models you built or what they drove | `[grounded]` your account; `[inferred]` that daily use is not the same as modelling | G4 |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with the sales director, but finance owned the company forecast. Limit: you haven't owned forecast methodology or the number | `[grounded]` your account; `[generic]` that a first-time owner is the usual probe | G1 |
| R7a | Working with finance on billing or revenue data | must_have | unclear | low | discovery | Renewal dashboards touch revenue data, but whether you worked with finance on them is not stated | `[grounded]` your account; silence on finance contact | G2 |
| R7b | Billing data experience | must_have | absent | none | capability | You've said you have never worked on billing data. No adjacent evidence after discovery | `[grounded]` your statement | G3 |
| R8 | Build pipeline and renewal reporting for sales and finance | must_have | direct | medium | none | You rebuilt pipeline and renewal dashboards and run the monthly pipeline review. Inspectable proof not yet seen | `[grounded]` your account | A sanitised dashboard screenshot would raise to high |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R6, must_have) | transferability | A monthly pipeline review with the sales director; finance owned the company forecast | The JD names the CFO forecast as a duty, so this is the likeliest objection | Supplying pipeline coverage or commit numbers to finance; challenging finance's assumptions; building a pipeline-to-revenue or renewal-rate view they used | A sanitised pipeline review deck or forecast-input workbook | `[grounded]` your account; `[generic]` that this is the likeliest objection |
| G2 | Working with finance on revenue data (R7a, must_have) | discovery | Renewal dashboards, with no finance contact stated | Resolving it could turn R7a to `adjacent` or `direct`, and it shapes how you answer R7b | Reconciling renewal figures with finance; agreeing definitions such as ARR or renewal rate; a shared report finance relied on | A metric-definition doc or reconciliation note | `[grounded]` your account; silence on finance contact |
| G3 | Billing data (R7b, must_have) | capability | No billing exposure, in your words | The JD says you will own billing data, so there is a ramp-up | A closure path: before or during the process, ask a finance colleague to walk you through how invoices and billing records feed revenue reporting, so you can speak to it concretely. Otherwise carry it as a named risk | None to attach today | `[grounded]` your statement; `[generic]` on the closure path |
| G4 | Spreadsheet modelling (R5b, must_have) | discovery | Daily Excel, with no model described | Light to resolve, and it could move R5b to `direct` | A forecast, commission or capacity model others used; scenario or sensitivity tabs | A sanitised model | `[grounded]` your account |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | "Lead" with no stated reports or decision rights | unknown | — | "Revenue Operations Lead" | The post may be an individual-contributor lead, with CFO and Head of RevOps priorities to balance | `[inferred]` from the title against the JD's silence on team | Does this role have direct reports, and who sets the forecast methodology? | unresolved |
| RR2 | Four duties bundled into one post | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting… and run the quarterly revenue forecast with the CFO" | One hire covering sales ops, finance data and forecasting may be stretched. Severity stays low because the pay sits at the market median, which does not point to a junior-priced bundle (RR4) | `[inferred]` from the four duties in one sentence; `[generic]` that bundled posts of this kind are common | Who else works on revenue and billing data today, and what support does the role get? | unresolved |
| RR3 | No stated first-year outcomes | unknown | — | JD lists duties and requirements only | Success may be undefined on a demanding mandate | `[grounded]` JD silence | What would success look like at 90 days and at a year? | unresolved |
| RR4 | Pay stated and in range | positive_signal | — | "£61,500–£67,000 plus share options" | Transparent pay, near the median band in role reality | `[grounded]` JD figure; `[generic]` the band | What are the share option terms (vesting, strike, size of grant)? | noted |
| RR5 | Posting not seen on Quillfield's own site | unknown | — | Posting hosted at jobs.tallyboard.example | Likely a job-board listing of a real role. The employer itself is established | `[grounded]` About page found, no careers page surfaced | Can you point me to this role on your own careers page, and who would I interview with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle your location and pay floor against R1 and R2 before investing in the process | Both are hard-gate terms I couldn't test | `[grounded]` R1, R2 rows | pending your approval |
| E1 | Lead your CV and cover note with the dashboard rebuild and the monthly pipeline review you run with the sales director, in outcome terms. Don't use the word "forecast" for what you did | R8 and R6, and keeps it truthful | `[grounded]` your account | pending your approval |
| E2 | State the billing gap plainly in the process, and pair it with a concrete plan to close it (see G3). Don't imply billing experience | R7b, `capability` | `[grounded]` R7b row | pending your approval |
| W1 | A sanitised dashboard screenshot and a short SQL sample | Would raise R8, R5a and R4's evidence | `[grounded]` R4, R5a, R8 rows | pending your approval |
| Q1 | Ask the questions in RR1 to RR5 in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A2 | Tamsin Achebe's public title and background are in revenue operations and sales ops, so lead with your sales-ops-to-RevOps story | Positioning for this reader | `[inferred]` from one profile snippet | pending your approval |

## Evidence status

Verified: none yet. Everything about you comes from what you wrote in this chat; no CV has been seen.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers", which returned "About Quillfield" (quillfield.co.uk/about). It established the employer and moved role reality's organization row. No careers page surfaced, which is RR5. |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). It moved the market calibration and RR4. It covered pay only, not scope norms. |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), seen as a snippet only. It moved the scope read and A2. |

## Dossier offer

I can write all of this up as a `tuesday-dossier.md` file if you want it to keep or reuse.

## Upgrade menu

- Your CV or a LinkedIn export → R3, R4, R5a and R8 get sourced to a document instead of your chat account, and any buried evidence would surface as a repositioning edit.
- A Salesforce certification link, a sanitised dashboard screenshot, or a sanitised SQL sample → R4, R8 and R5a move toward `high`.
- Your answer on location and pay floor → R1 and R2 resolve.
- Whether your current company sells software or payments infrastructure → R3 firms up.
- The recruiter's answers on reports, first-year outcomes and share options → RR1, RR3 and RR4 resolve.
- A deeper research pass on Quillfield (funding and leadership news, hiring patterns, employee reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

1. **R1, R2** — Is Bristol with two office days a week workable for you, and what is your pay floor against £61,500–£67,000?
2. **G1, G2** — When finance built or reported revenue numbers, what did you supply or check (pipeline coverage, commit calls, renewal figures), and did you work through those numbers with them directly? What did you own?
3. **G4** — What spreadsheet models have you built, who used them, and what did they drive?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.