Searches weren't permitted, so this runs on the posting and your background alone. Findings about the world are labeled accordingly.

## Decision snapshot

**No, this isn't worth pursuing as posted: R1 and R2, both hard gates, fail. Status: `no_go`.** Your instinct that something is off is right, and the opportunity ledger below says why.

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site Austin, 5 days a week), R2 ($70–85k base)
- `must_have`: direct: R3, R4, R5, R6
- `important`: unclear: R7 (SEO/content), R8 (Brand and PR), R9 (Partnerships and sales ops), R10 (Operating as a team of one)

R1, R2 — each fails a stated non-negotiable, and no wording can fix a gate; R5 (`medium`) — paid experience confirmed in your own words, no artifact seen; R7, R8, R9 — your background is silent, so these are discovery gaps, not capability findings.

**Opportunity ledger.** The posting bundles eight functions into one person with no team (RR3), prices that bundle at $70–85k against 8+ years required (RR2), and attaches always-on language (RR4) and unfixed success metrics (RR5). The equity is unquantified (RR6), and the employer could not be checked from here (RR1). The CEO reporting line is the one positive entry (RR7).

- **Hard gates:** failed: R1 (On-site Austin, 5 days a week), R2 ($70–85k base against a $150k floor).
- **Severe red flags:** none found (no register entry carries `severity: high`).
- **What would change this:** the posting would need to allow remote work from Portland and a base of at least $150k, or you would need to revise one of your own non-negotiables. That call is yours, and the posting's own words ("no exceptions") point the other way.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD header; not verified (target 1 below) |
| Mandate | Own all revenue growth across paid, SEO/content, lifecycle/CRM, brand, PR, partnerships and sales ops | `[grounded]` JD |
| Resources and authority | Team of one "to start"; reports to the CEO with a dotted line to the board; no budget or decision rights stated | `[grounded]` JD for the reporting line and team size; the JD is silent on budget |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| Success metrics | "Will evolve as we learn"; no first-90-day or first-year outcomes stated | `[grounded]` JD |
| Scope read | Eight functions for one person reads as several roles folded into one title | `[inferred]` from the function list against "team of one" |
| Market calibration | Not calibrated. The role-family sweep did not run, so no market band is stated. The gap that matters is the posting's $70–85k against your $150k floor: $65k at the top of the range, $80k at the bottom | `[grounded]` JD figure and your stated floor; no `[generic]` band available |
| Unknowns | Budget, equity terms, whether metrics will ever be defined, whether the company is verifiable | `[grounded]` JD silence |
| Contradictions | "Profitable since day one" beside a Series A raise is not contradictory on its face, but I couldn't check it | `[inferred]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin 5 days a week, "no exceptions" (your hard constraint: remote-only, Portland, no relocation) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your statement of the constraint, which is your own and specific. Fit fails because the JD rules out remote work in its own words | `[grounded]` JD quote and your stated constraint | Surface it. Only the employer changing terms or you revising the constraint resolves it |
| R2 | Base of $70–85k (your hard constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your floor. Fit fails because the top of the posted range is $65k under it. The equity is unquantified and your floor is on base | `[grounded]` JD figure and your stated floor | Surface it. Nothing in the posting closes this gap |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You report 9 years in growth, as growth lead then Head of Growth. This is CV-equivalent prose, and how many of the 9 years were leadership isn't dated, so expect that probe | `[grounded]` your background in this conversation | None unless this ever matters |
| R4 | Owning revenue growth with budget and accountability for results | must_have | direct | medium | none | You scaled one company from $8M to $40M ARR over three years with a budget you controlled. The limit: both companies were B2C subscription, and I can't tell from the posting whether Novaline sells to merchants or consumers | `[grounded]` your background; `[inferred]` the B2B-or-B2C question from the JD's silence | None unless this ever matters |
| R5 | Paid acquisition | must_have | direct | medium | none | You own paid at both companies. No artifact has been inspected | `[grounded]` your background | None unless this ever matters |
| R6 | Lifecycle/CRM | must_have | direct | medium | none | You own lifecycle and are deep in Braze, SQL and GA4. No artifact has been inspected | `[grounded]` your background | None unless this ever matters |
| R7 | SEO/content | important | unclear | none | discovery | Your background doesn't mention it. It may exist, so this is a discovery gap and not a capability finding | `[grounded]` your background's silence | If it ever matters, ask about owned organic or content work |
| R8 | Brand and PR | important | unclear | none | discovery | Your background is silent on both | `[grounded]` your background's silence | If it ever matters, ask about brand or PR work |
| R9 | Partnerships and sales ops | important | unclear | none | discovery | Your background is silent. Partnerships and sales ops are more common in B2B settings than in B2C subscription | `[grounded]` your background's silence; `[generic]` the B2B pattern | If it ever matters, ask about partner or sales-support work |
| R10 | Operating as a team of one, from the "team of one to start" line | important | unclear | low | discovery | You have run teams of 3–7, which is indirect evidence. I can't tell how much hands-on execution you did yourself | `[inferred]` from the team sizes you gave against the JD's "team of one" | If it ever matters, ask which channels you executed personally |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | On-site Austin (R1) | hard_gate | You are remote-only in Portland and the posting says "no exceptions" | It fixes the decision. No wording or experience recovers it | None applies | Nothing you could supply | `[grounded]` JD and your constraint |
| G2 | Base pay (R2) | hard_gate | $70–85k posted against your $150k floor | It fixes the decision | None applies | Nothing you could supply | `[grounded]` JD and your constraint |
| G3 | SEO/content (R7) | discovery | No mention in your background | It would matter only if the gates were met | Owning an organic or content program; commissioning content that drove subscribers; technical SEO fixes | A traffic or conversion report you can share | `[grounded]` silence; `[inferred]` that it can't move the decision |
| G4 | Brand and PR (R8) | discovery | No mention in your background | It would matter only if the gates were met | A rebrand, launch PR, or earned-media push you led | A launch brief or coverage list | `[grounded]` silence; `[inferred]` that it can't move the decision |
| G5 | Partnerships and sales ops (R9) | discovery | No mention in your background | It would matter only if the gates were met | Affiliate or channel deals; sales or CRM-pipeline support | A partner agreement or pipeline report | `[grounded]` silence; `[inferred]` that it can't move the decision |
| G6 | Operating solo (R10) | discovery | Team leadership is evidenced; solo execution isn't | It would matter only if the gates were met | Periods you ran channels yourself before hiring | A channel dashboard from that period | `[grounded]` team sizes; `[inferred]` that it can't move the decision |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Seniority-compensation mismatch, and a conflict with your floor (R2) | red_flag | medium | "8+ years growth leadership required. Compensation: $70–85k base" | The pay may not match the seniority and scope asked for. Severity is held at medium because I couldn't calibrate against a market band | `[inferred]` from the JD's seniority and scope against its pay; no `[generic]` band, since the sweep didn't run | What is the budgeted base for this role, and is the range firm? | unresolved |
| RR3 | Bundled specializations with no authority or resources stated | risk_signal | medium | "Own all revenue growth end to end: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops. You will be a team of one to start" | Several full roles may be folded into one title, with accountability and no budget, headcount or decision rights stated | `[inferred]` from the function list against the JD's silence on resources | What budget and headcount are committed for the first year? | unresolved |
| RR4 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work may be routine, with no limit stated | `[inferred]` from the phrase "just who we are" | How often did the last person in this function work evenings or weekends? | unresolved |
| RR5 | Absent success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You may be accountable for all revenue growth with no fixed definition of success | `[inferred]` from the JD's own wording | What would count as success at 90 days and at 12 months? | unresolved |
| RR6 | Equity unquantified | unknown | — | "meaningful equity upside" | The equity may be too small or too uncertain to offset the pay gap. The JD gives no percentage, vesting or strike price | `[inferred]` from the JD's silence on terms | What percentage, vesting schedule and strike price does the equity carry? | unresolved |
| RR7 | Senior reporting line | positive_signal | — | "Report to the CEO with a dotted line to the board" | The role may carry real visibility and authority | `[grounded]` JD states it | Does this role hold budget sign-off, or does the CEO decide spend? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't spend application effort on this role as posted | see R1, R2 | `[grounded]` the two failed gate rows | pending your approval |
| A2 | If you'd consider revising either non-negotiable, that is your decision. RR1 through RR6's questions then become the first things to ask | see RR1–RR6 | `[grounded]` register | pending your approval |
| A3 | Filter further searches on your stated constraints: remote-eligible, base at least $150k | see R1, R2 | `[grounded]` your constraints | pending your approval |

I'm proposing no CV or outreach language, so there is nothing for the reframing audit to run over.

## Evidence status

Verified: R1 and R2 claims, which are your own stated constraints with nothing to inspect. Unverified leads: R3, R4, R5 and R6, which are CV-equivalent prose from this conversation, and I haven't seen the CV itself.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I sent one search ("Novaline e-commerce enablement startup Austin careers Head of Growth") and it was refused. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | I sent one search ("Head of Growth salary startup Series A 2026 base compensation range") and it was refused. It would have moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Closing

I can write this up as a `tuesday-dossier.md` if you want a copy to keep.

**Upgrade menu**

- Permission to search, or a link to Novaline's careers page → RR1 resolves, and role reality's organization row moves off the posting alone.
- A market band for this title and scope → RR2 gets calibrated. It can't change the `no_go`, because R2 fails on your floor regardless.
- A CV or portfolio link → R3 through R6 can rise toward `high`.
- The hiring manager's name → role reality's scope read, if you ever reopen this.

**Questions:** none this turn. The two failed gates settle the decision, and the unclear rows (R7, R8, R9, R10) can't move it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.