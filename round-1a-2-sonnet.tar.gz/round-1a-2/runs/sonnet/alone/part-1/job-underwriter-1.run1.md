I'll read the reference files the skill requires before building the assessment.
# Underwriting: Senior Product Analyst, Harborlight Health

## Decision snapshot

**Yes, apply, and you fit the core of this role: R1, R2, R3, R4 and R6, all `must_have`, are `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R6 · adjacent: R5 (Define and maintain the metrics layer)
- `important` — adjacent: R7a (Partner with product managers on roadmap decisions) · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA)

R5 — your work implies a metrics layer but you didn't state one; R8 — mentoring is absent from your account; R9 (`medium`) — a GDPR/CCPA bridge, its limit named.

**Opportunity ledger.** The employer is unverified because research was refused (RR1), and the pasted JD has no pay, location or work-arrangement terms (RR2). Year-one success and whether a metrics layer already exists are unstated (RR3). One entry runs the other way: the duties, tools and team are concrete (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The posting is confirmed live on Harborlight's own careers page (RR1).
  2. Pay, location and work arrangement are checked against your own non-negotiables (RR2).
  3. Metrics-layer ownership is confirmed in specifics before you claim it (R5, RR3).
  4. Healthcare is framed as adjacent, never as HIPAA experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C, with a care-navigation app. Not verified; the search was refused | `[grounded]` JD header, as stated by the JD only |
| Mandate | Own product analytics for the app: metrics layer, A/B tests, Looker self-serve dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Stated requirements | 5+ years product analytics; expert SQL; experiment design at scale; Looker or similar; written communication with non-technical stakeholders; healthcare data (HIPAA) "a plus" | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | Ordinary for a senior analyst: one product, one stack, two direct mentees. Whether the metrics layer exists or must be built decides how large the job is | `[inferred]` from the duty list against its silence on current state |
| Market calibration | Not calibrated. The role-family sweep was refused, so there is no band to set the title or pay against | `[grounded]` search refused |
| Unknowns | Pay, location, work arrangement, reporting line, state of the metrics layer, data stack beyond Looker, clinician partnership model | `[grounded]` JD silent |
| Contradictions | None between the JD and your background; the JD was not checked against a careers page | `[grounded]` the two texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a ~2M-subscriber meal-kit company. That clears the figure; the claim is self-reported | `[grounded]` your intake message | A CV with dates would raise it to high |
| R2 | Expert SQL | must_have | direct | medium | none | "SQL daily on a Snowflake warehouse" over 6 years. "Expert" is your own level; nothing inspectable yet | `[grounded]` your intake message | A sanitized query or model sample would raise it to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift. The JD doesn't define "at scale"; your base is ~2M subscribers, Harborlight's is unknown | `[grounded]` your intake message; `[inferred]` that scale is comparable, since Harborlight's user base is unknown | An experiment write-up with the pricing test's design and readout would raise it to high |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch with 40+ governed dashboards, which is the tool itself | `[grounded]` your intake message | Dashboard screenshots or a LookML sample would raise it to high |
| R5 | Define and maintain the metrics layer | must_have | adjacent | low | discovery | "Governed dashboards" and a monthly metrics memo sit near a metrics layer, but you never said you defined or maintained shared metric definitions. Confidence is low because the claim isn't made; the work nearby is real | `[inferred]` from "governed" and the memo, no stated definitions | See G1 |
| R6 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly | `[grounded]` your intake message | The memo, sanitized, would raise it to high |
| R7a | Partner with product managers on roadmap decisions | important | adjacent | medium | discovery | You present monthly to the VP Product and ran pricing-test work. You didn't say an analysis changed a roadmap, so partnership is evidenced and decision influence isn't | `[grounded]` your intake message | See G2 |
| R7b | Partner with clinicians | important | unclear | low | discovery | Nothing in your account involves clinical stakeholders. Your senior-stakeholder work is indirect context only | `[grounded]` your intake message silent | See G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Mentoring or managing is not mentioned. This is not the same as having none, so it stays unclear until you answer | `[grounded]` your intake message silent | See G4 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | You've handled GDPR/CCPA consumer PII and built the consent-state model for your warehouse. Limit: you've worked with no health data, so HIPAA and clinical data are not exercised | `[grounded]` your intake message; limit `[inferred]` from you stating no healthcare work | See G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R5, must_have) | discovery | Governed dashboards and a metrics memo, with no stated shared metric definitions | A `must_have` at `adjacent`; confirming it is the likeliest way to move this row to `direct` | Defining "active subscriber" or retention once for all dashboards; LookML models or a dbt-style layer; a metrics dictionary or change process | A metrics dictionary excerpt, LookML sample, or definition-change log | `[grounded]` your intake message; `[inferred]` that this row is the biggest swing |
| G2 | Roadmap influence with PMs (R7a, important) | discovery | Monthly VP Product presentations and test work, with no named roadmap decision | The JD's stated purpose is turning analysis into roadmap decisions | An analysis that stopped or changed a feature, or the pricing test's rollout decision | A readout, decision memo, or roadmap note | `[grounded]` the JD's purpose language; `[inferred]` from your account |
| G3 | Clinician partnership (R7b, important) | discovery | No clinical stakeholders mentioned | Clinicians are named in the JD; working with non-analyst domain experts could count as adjacent | Working with domain experts such as culinary, nutrition or ops staff on definitions or tests | A shared analysis or test brief | `[grounded]` the JD names clinicians; `[inferred]` that such work could count |
| G4 | Mentoring juniors (R8, important) | discovery | Silent | The JD names two juniors, so it is a stated duty | Onboarding analysts, reviewing their SQL or dashboards, running a team standard | A named mentee or review practice | `[grounded]` JD duty; CV silent |
| G5 | Healthcare data / HIPAA (R9, preferred) | transferability | GDPR/CCPA PII and a consent-state model, no health data | A preferred row, so a minor risk; the honest bridge is privacy-regulated data, never HIPAA | Access controls, retention or deletion rules, audit of PII use, consent enforcement in the warehouse | A consent-model doc, sanitized | `[grounded]` your intake message; limit `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources; research was refused | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay, location and work arrangement absent from the pasted JD | unknown | — | (none: the pasted text has no such terms) | The full posting may state them and the paste dropped them, or the posting withholds them | `[inferred]` from the pasted text's silence | What is the salary range, and is the role remote, hybrid or on-site? | unresolved |
| RR3 | Year-one outcomes and state of the metrics layer unstated | unknown | — | "Own product analytics for our care-navigation app" | The mandate may be maintaining an existing layer or building one from nothing, which are different jobs | `[inferred]` from the duty list against its silence on current state | Does a metrics layer exist today, and what would success look like in year one? | unresolved |
| RR4 | Concrete duties, stack and team named | positive_signal | — | "build self-serve dashboards in Looker … mentor two junior analysts" | The role is defined enough to evaluate, with a named tool and a two-person team | `[grounded]` JD | Who do the two junior analysts report to today? | noted |

## Application plan

`resume_edits_pending_approval` for E1 to E3: each line below is your own sentence, re-ordered and not reworded.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the Looker line with "Built the company's Looker instance from scratch — 40+ governed dashboards" | R4, R5 | `[grounded]` your intake message | pending your approval |
| E2 | Lead the experimentation line with "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift" | R3 | `[grounded]` your intake message | pending your approval |
| E3 | Place "handled GDPR/CCPA consumer PII and built the consent-state model for our warehouse" under data governance, with no HIPAA or healthcare wording | R9 | `[grounded]` your intake message | pending your approval |
| A1 | Confirm the role is live on Harborlight's own careers page before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the RR2 and RR3 questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Stage assumed: evaluating, since none was stated.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Harborlight Health care navigation app careers Senior Product Analyst" was refused. It would have confirmed the employer and the live posting, feeding role reality's Organization and Contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | The search "senior product analyst digital health salary range US experimentation Looker" was refused. It would have fed the market calibration row and RR2's pay check |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier and upgrade menu

I can also save this as a `tuesday-dossier.md` file whenever you want it.

- Search permission granted → targets 1 and 2 run; RR1 can close, and market calibration and the pay check appear.
- Your non-negotiables (pay floor, location, work authorization) → the hard-gates line gets real checks instead of "unknown".
- A metrics dictionary excerpt, LookML sample or definition-change log → R5 can reach `direct`.
- A sanitized experiment write-up of the pricing test → R3 to `high`.
- The recruiter's answers on pay, location and metrics-layer state → RR2 and RR3 close.
- The hiring manager's name → role reality's scope read and the positioning in the plan.

## Questions

1. **Non-negotiables:** do you have any (pay floor, location or remote, work authorization)? Those would become hard-gate checks.
2. **G1:** did you personally define or maintain shared metric definitions, such as one definition of retention or active subscriber used across dashboards? What did you own?
3. **G4:** have you mentored, onboarded or reviewed the work of other analysts, and if so, how many and in what way?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.