Loading the web search tool next. I'll check the posting and company page against the live site, then build the assessment.
**Yes, worth applying, on conditions: `conditional_go`.** R2, R3, R4, R5 and R6 land `direct`, R7 is a bridge to BigQuery, and R1 (location) is unconfirmed.

I couldn't check the posting or company page against the live site, because the web search was denied. The assessment runs on what you pasted plus the Datawright report.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office)
- `must_have` — direct: R2, R3, R4, R5, R6
- `important` — adjacent: R7 (BigQuery as the warehouse); unclear: R8 (Data contracts analysts depend on), R9 (Ingestion from app and CRM)

R7 (`medium`) — a credible bridge, its limit named; R8 and R9 — the stated work is silent on them, so they are discovery questions, not verdicts.

**Opportunity ledger.** The stated pay's low end and midpoint sit within the report's interquartile range (RR3), and the stack and responsibilities are named (RR5). The posting and company facts are unchecked (RR1), the team and scope are unstated (RR2), and the equity terms are withheld (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. R1 is confirmed workable for you. A factual miss there would make this `no_go`.
  2. The role is confirmed live and the company facts hold (RR1).
  3. The BigQuery bridge is framed as adjacent, never as BigQuery experience (R7).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016 in Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; not checked against the live site (RR1) |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Stated pay | $148,000–$166,000 plus equity; the equity terms are not stated | `[grounded]` JD |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Seniority and scope read | The JD's 5+ years sits inside the report's typical 5–8 years for Senior. The JD spans ingestion, warehouse modelling and contracts. The report's typical scope is one domain's pipelines with no direct reports, so this may be wider, and the JD is silent on team size | `[grounded]` JD and report as provided; `[inferred]` that the span may exceed one domain |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, interquartile range $139,000–$163,500. The posting's low end is $3,000 under the median and its top is $2,500 over the 75th percentile. This is a pattern, not this employer's offer | `[generic]` Datawright 2026 report as provided; `[grounded]` JD for the posting's figures and the about page for the Series C stage |
| Hiring manager | Not named in the posting | `[grounded]` JD |
| First-90-days outcomes | Not stated | `[grounded]` JD silence |
| Unknowns | Team size and reporting line; which of ingestion, modelling and contracts this role owns; equity terms; any on-call expectation behind "run" | `[inferred]` from the JD's silence |
| Contradictions | None between the pasted JD and the pasted about text; neither was checked live | `[grounded]` the two pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and constraints weren't given, so whether either option works is unknown | `[grounded]` JD terms; candidate silent | Q1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years of data engineering at a B2B payroll company. Confirmed in prose, no CV or artifact inspected. A titled-years line is usually screened literally | `[grounded]` your stated 6 years; `[generic]` on screening | CV lets me anchor the dates |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You stated daily use of both. "Strong" is the JD's word and a level only you can attest; no sample was inspected | `[grounded]` your stated daily use | a sanitized model or pipeline excerpt would raise it to `high` |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake. The requirement says "a cloud warehouse", not BigQuery by name; BigQuery is R7 | `[grounded]` your stated project and JD wording | a sanitized project structure or DAG view would raise it to `high` |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | You named Airflow for orchestration. How much of it you built versus used wasn't stated, so I claim only "used Airflow for orchestration" | `[grounded]` your statement | none |
| R6 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. Its coverage and what it caught weren't stated | `[grounded]` your statement | a sanitized suite summary would raise it to `high` |
| R7 | BigQuery as the warehouse | important | adjacent | medium | transferability | The requirements list says "a cloud warehouse"; BigQuery appears only in the role description, so it is tiered `important`, not `must_have`. Adjacent: dbt modelling at about 180 models on another cloud warehouse. Limit: you have never used BigQuery. Strengthener: a small dbt-on-BigQuery project you built yourself | `[grounded]` your statement and JD; `[inferred]` the adjacency; `[generic]` that dbt projects largely carry across warehouses, with adapter-specific differences | G1 |
| R8 | Data contracts analysts depend on | important | unclear | none | discovery | Your stated work doesn't say whether any agreed interface existed between your pipelines and downstream users | `[grounded]` your background's silence | G2 |
| R9 | Ingestion from the app and CRM | important | unclear | none | discovery | Your stated work covers dbt, Airflow and testing; it is silent on source ingestion | `[grounded]` your background's silence | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R7, important) | transferability | Carries over: dbt modelling at scale on Snowflake. Not exercised: any BigQuery use | The warehouse is named in the role description, so it is the likeliest objection | A short dbt project run on BigQuery, even on public datasets | A repo link or README | `[grounded]` your "never used BigQuery"; `[generic]` that it is the likeliest objection |
| G2 | Data contracts (R8, important) | discovery | Silent on agreed interfaces with downstream users | One of three named responsibilities, and it decides whether the row is `direct` or a gap | Tests or schema checks that analysts relied on; agreed column definitions or freshness expectations with a consuming team; a process for announcing schema changes | A sanitized model YAML with tests, or a definitions doc | `[grounded]` background's silence |
| G3 | Ingestion from app and CRM (R9, important) | discovery | Silent on how data entered the warehouse | The first named responsibility | Loading data from a SaaS tool or an app database into the warehouse; ingestion DAGs; managing a vendor connector | A sanitized DAG or design note | `[grounded]` background's silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting and company facts not checked against the live site | unknown | — | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The pasted text may be current and the posting live, but nothing was verified here | `[grounded]` pasted text; check unavailable | Is this role still open, and who would I report to? | unresolved |
| RR2 | Scope and team size unstated | unknown | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The role may be one of few data engineers covering several domains, against a report-typical scope of one domain | `[inferred]` from the JD's span against the report's typical scope and the JD's silence on team | How many data engineers are on the team, and which of ingestion, modelling and contracts does this role own? | unresolved |
| RR3 | Pay range stated, and mostly inside the market band | positive_signal | — | "$148,000–$166,000 plus equity" | The range is transparent; its low end and midpoint sit within the report's interquartile range | `[grounded]` JD against the report as provided | Where in the range would this level land? | noted |
| RR4 | Equity terms withheld | unknown | — | "plus equity" | The grant type, size and vesting may materially change the total pay | `[inferred]` from the JD's silence | What is the equity: type, amount and vesting? | unresolved |
| RR5 | Named stack and responsibilities | positive_signal | — | "dbt-modelled warehouse in BigQuery" | The role is concretely specified, and the company reports a Series C in February 2026 | `[grounded]` JD and pasted about text; unverified live (RR1) | What would a successful first year look like? | noted |

## Application plan

Every row is proposed and none is applied.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | `resume_edits_pending_approval` — summary line: "Data engineer, 6 years at a B2B payroll company: built the company's dbt project on Snowflake (about 180 models), set up its Great Expectations test suite, and used Airflow for orchestration; Python and SQL daily." Audited clause by clause against your sentences | R2–R6 lead the application, with the scope and numbers as you stated them | `[grounded]` your own sentences | pending your approval |
| P1 | If asked about BigQuery, say: "My warehouse experience is Snowflake; I haven't used BigQuery." | The bridge stays honest and the limit is named | `[grounded]` R7 | pending your approval |
| W1 | A small dbt project on BigQuery, done before interviews | Narrows the R7 limit | `[generic]` pattern | pending your approval |
| A1 | Confirm the role is live and R1 works for you before investing in the loop | RR1, R1 | `[grounded]` register and map | pending your approval |
| Q1 | Ask RR1, RR2, RR3, RR4 and RR5 verbatim in interviews | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Sent one search ("Pellucid Learning online tutoring K-12 Denver Series C careers Senior Data Engineer") to check your pasted JD and about text. It was refused, so nothing came back. It would have moved RR1 and the contradictions row in role reality |
| 2. Role-family sweep | skipped | The Datawright report is in hand and fixes the market calibration line, the seniority read and the pay comparison in RR3 |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there is no query to form |

## Dossier offer and upgrade menu

I can write this up as `tuesday-dossier.md` whenever you want it.

- **A link to the live posting or the company's careers page**: I can read a link you give me. It would close RR1.
- **Your CV**: it anchors E1 to your actual lines and shows any presentation gap.
- **A sanitized dbt project view, test config or Great Expectations suite summary**: it would raise R4 and R6 to `high`.
- **Your location and any pay floor**: R1 settles, and the floor is set against the $148,000–$166,000 range.
- **The hiring manager's name**: it feeds the scope read and which story to lead with.
- **A search on the company** (search was refused this session): it would add the company-side checks that RR1 leaves open.

## Questions

R1 — Are you in the US, and does Remote (US) or the Denver office work for you?
G2 — Did any analysts or other teams depend on your dbt models, with agreed definitions, tests or schema-change handling? Who set those, and what happened when something broke?
G3 — Did you bring data in from an application database, event stream or CRM-type tool into the warehouse? What did you own, and with what tooling?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.