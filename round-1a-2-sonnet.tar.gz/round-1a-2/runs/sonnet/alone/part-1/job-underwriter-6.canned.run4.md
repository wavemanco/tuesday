I've read the posting and the report format. Next I'm reading the decision and research rules, then I'll write the assessment.
**Yes, apply, but as a stretch. R7 (owning a forecast) and R9 (owning billing data) have no direct evidence in what you've told me, and both are must-haves. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, hybrid two days in office), R2 (Salary £61,500–£67,000)
- `must_have`: direct: R3, R4, R6 · adjacent: R5 (Strong SQL and spreadsheet modelling), R8 (Working with finance on billing or revenue data) · absent: R7 (Experience owning a forecast), R9 (Owning billing data)

R7 and R9: the stretch, with no direct evidence; R8 (`low`): a bridge through renewal data, if finance was involved; R5 (`medium`): how often you use SQL and Excel is stated, how deep you go is not.

**Opportunity ledger.** The employer matches the posting's description (RR6), and the pay sits in the market band (RR2). Open items are who owns the forecast number (RR1), the share-option terms (RR3), the breadth of scope (RR4) and whether the listing appears on Quillfield's own site (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, hybrid two days in office), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) forecast scope is concrete and you can frame your pipeline-review work honestly as adjacent (R7, RR1); (2) the billing-data gap is acknowledged and the role has support for it (R8, R9, RR4); (3) Bristol hybrid and the pay band fit your terms (R1, R2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` About Quillfield page, search result |
| Role | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| First-year outcomes | Not stated | `[grounded]` posting silent |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield, previously four years as sales operations manager at Corvane Payments. You were told by the recruiter she is the hiring manager. | `[grounded]` search-result snippet; recruiter claim from you |
| Scope read | CRM, billing data, reporting and forecasting in one post is broad for a 96-person company. A "Lead" title under a Head of RevOps probably means you'd report to her; no team is mentioned. | `[inferred]` from the posting's duty list against its silence on team, and from the two titles |
| Market calibration | UK B2B software revenue operations leads: median base £64,200, interquartile range £57,800–£70,400. The posted range straddles the median. This is the market band, not Quillfield's offer to you. | `[generic]` Ledgerline 2026 pay guide (n=438); `[grounded]` posting for the figure |
| Unknowns | Who owns the forecast number; share-option terms; team and reporting line; whether the listing is on Quillfield's own careers page | `[inferred]` from the posting's silence |
| Contradictions | None found between the posting and the About page on what they both cover | `[grounded]` both pages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two days a week in office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or what commute you'd accept, so nothing can be checked | `[grounded]` posting; your constraints not given | Orientation question Q3 |
| R2 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | The range is stated, but your floor isn't. Against the market band it looks ordinary (RR2). | `[grounded]` posting; `[generic]` band | Orientation question Q3 |
| R3 | 4+ years in RevOps, sales ops or similar analytics at a B2B software company | must_have | direct | medium | none | Five years in sales ops, two of them running RevOps. The employer is a B2B payments company; whether that counts as "software" is the posting's call. | `[grounded]` your account | Your CV or LinkedIn would raise this to high |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. This is your claim, not yet an inspectable document. | `[grounded]` your account | The certification record would raise this to high |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | SQL weekly and Excel daily show regular use. "Strong" and "modelling" need examples of what you built. | `[grounded]` your account | Gap G3 |
| R6 | Build pipeline and renewal reporting that sales and finance run on | must_have | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Whether finance used them is unstated. | `[grounded]` your account | A sanitized dashboard screenshot would raise this to high |
| R7 | Experience owning a forecast | must_have | absent | high | capability | You said finance owned the forecast, so ownership isn't evidenced. The monthly pipeline review is a possible bridge to forecast work, but nothing you've said ties it to the forecast. | `[grounded]` your statement | Gap G1 |
| R8 | Experience working with finance on billing or revenue data | must_have | adjacent | low | discovery | The posting says "billing or revenue", and renewal dashboards touch revenue data. Whether finance supplied or checked that data is unknown. | `[inferred]` from the renewal dashboards you described | Gap G2 |
| R9 | Owning billing data | must_have | absent | high | capability | You said you've never worked on billing data. | `[grounded]` your statement | Gap G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R7, must_have) | capability | Monthly pipeline review with the sales director; finance owned the forecast | The posting makes the quarterly forecast with the CFO a headline duty | Supplying pipeline or commit numbers to finance's forecast; tracking forecast accuracy; building forecast inputs or scenarios | A sanitized review deck or input workbook | `[grounded]` your account; `[generic]` that these activities are the usual bridge |
| G2 | Billing and revenue data with finance (R8, must_have; R9, must_have) | discovery | Renewal dashboards, but no invoicing, billing-system or reconciliation work | Half the posting's data-ownership claim is billing | Tying renewal values to invoiced revenue; resolving finance's questions about dashboard numbers | Sanitized definitions of the renewal metrics | `[inferred]` bridge from renewal reporting |
| G3 | Strong SQL and spreadsheet modelling (R5, must_have) | discovery | Frequency of use, not what you built | "Strong" is the posting's word and may be tested | Models you built, such as coverage or renewal-rate models; the most complex queries you wrote | One sanitized query or model | `[grounded]` your account |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast ownership is shared with the CFO | unknown | — | "run the quarterly revenue forecast with the CFO" | You might own the process while the CFO owns the number, or the reverse | `[inferred]` from the posting's wording | Who owns the forecast number today, and what would you expect this role to own in its first two quarters? | unresolved |
| RR2 | Pay sits within the market band | positive_signal | — | "£61,500–£67,000" | The range is stated openly and straddles the median for the title | `[grounded]` posting; `[generic]` Ledgerline band | Is the top of the range open to someone with a forecast gap? | noted |
| RR3 | Share option terms unstated | unknown | — | "plus share options" | The grant size and vesting could range from meaningful to negligible | `[generic]` pattern for options in early-stage pay packages | What is the option grant, vesting schedule and strike basis for this role? | unresolved |
| RR4 | Broad scope for one post | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting … run the quarterly revenue forecast" | Four functions in one role priced at the median, with no team mentioned. Low rather than medium because a Head of RevOps already exists. | `[inferred]` from the duty list against the pay and the titles | What is the RevOps team size, and who would I report to? | unresolved |
| RR5 | Listing seen only on a jobs board | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | I did not reach Quillfield's own careers page, so the listing's presence there is unconfirmed | `[grounded]` the pages I did and did not see | Is this role live on Quillfield's careers page, and is Tamsin Achebe the hiring manager? | unresolved |
| RR6 | Employer exists as described | positive_signal | — | "Quillfield, the invoicing software company" | The About page matches the posting on business, city and size | `[grounded]` About Quillfield page | Where does this role sit in the 96-person structure? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your CV with the pipeline and renewal dashboard rebuild and the monthly pipeline review, stated as you described them, with no forecast ownership implied | R6, R7 | `[grounded]` your account | resume_edits_pending_approval |
| E2 | Add nothing on billing data. Surface any renewal-to-revenue tie-out work only if you confirm it happened | R8, R9 | `[grounded]` your statements | pending your approval |
| W1 | A one-page sanitized sample, such as a renewal dashboard or a pipeline-review input | G1, G2, G3 | `[grounded]` gap queue | pending your approval |
| A1 | Confirm Bristol hybrid and your pay floor with the recruiter before investing in interviews | R1, R2 | `[grounded]` unconfirmed gates | pending your approval |
| A2 | With Tamsin, lead with the dashboard and pipeline-review story. Name your own sales-ops-to-RevOps path only as your own. | Her public path runs through payments sales operations. It may not be your employer, so don't assume it. | `[grounded]` search snippet | pending your approval |
| Q1 | Ask RR1, RR3, RR4 and RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers" and got "About Quillfield" (quillfield.co.uk/about). Role reality's organization row and RR6. The careers page was not reached, hence RR5. |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK Bristol B2B software" and got "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Market calibration and RR2. |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" and got "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Snippet only. Role reality's hiring-manager and scope rows, and plan row A2. |

The posting itself was the link you gave me.

I can write up this assessment as `tuesday-dossier.md` if you want a file to keep.

## Upgrade menu

- Your CV or LinkedIn → R3 and R6 move toward `high`.
- The Salesforce certification record → R4 to `high`.
- A sanitized dashboard, query or model → R5, R6 and G3.
- An answer on forecast or finance involvement → G1 and G2, and R7 and R8 may move.
- Your location and pay floor → R1 and R2 resolve, and the hard-gates line firms up.
- Quillfield's own careers page link → RR5 closes.
- A deeper research pass on Quillfield (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

1. **R1, R2:** Where are you based, could you do two office days a week in Bristol, and what is your pay floor?
2. **R7, G1:** Did your pipeline review feed numbers into finance's forecast, or track how accurate it was? If so, what did you supply?
3. **R8, G2:** Who owned the data behind your renewal dashboards, and did you ever check it against finance's revenue figures?

Answer in text, paste a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.