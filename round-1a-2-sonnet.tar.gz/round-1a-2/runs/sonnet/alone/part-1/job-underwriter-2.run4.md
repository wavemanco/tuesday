I'm reading the Quartzline posting against your resume, the web searches I tried were refused, so this runs on the documents alone. The assessment follows.

## Decision snapshot

**You're not wasting your time on the pivot, but this posting is a reach, not a match. R1a (titled PM years) is absent, while R3 and R4a are direct. Status: `conditional_go`, with the conditions below.**

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1b (PM work behind the years), R2 (Shipped API or platform products) · unclear: R4b (Sales and support stakeholders), R5 (Agile delivery) · absent: R1a (3+ years titled PM)
- `important` — adjacent: R6, R8, R10 · unclear: R7 (Roadmap ownership), R9 (Adoption metrics)

R1a — a screen risk, not a gate; R1b, R2 — real substance with named limits; R3, R4a — the strongest rows; R7 — your quarterly sessions fed product input, and ownership is not yet evidenced.

**Opportunity ledger.** The mandate is concrete (RR3), but the employer could not be checked from here (RR1), compensation is withheld (RR2), and adoption targets are unspecified (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify — RR1; (2) you apply through a human route and frame R1a candidly, since an ATS may screen on the title; (3) the triage-tool lead resolves into specifics, which could lift R2 and R7.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; not independently verified |
| Mandate | Own the partner-facing API platform roadmap, run partner discovery, write specs, drive two engineering squads, define and track adoption metrics, coordinate launches with sales and support | `[grounded]` JD |
| Scope read | A single-product, mid-level PM remit: ownership is real, and two squads is a manageable span | `[inferred]` from "two engineering squads" and the one-platform mandate |
| Must-have framing | The JD marks 3+ years of PM experience as a must-have; a title-and-years requirement is often applied as a literal screen before a human reads the substance | `[generic]` hiring pattern, not a claim about Quartzline |
| Market calibration | Not run: the role-family search was refused, so there is no salary band to compare against | — |
| Unknowns | Compensation; who the role reports to; existing adoption baselines; whether adjacent experience is accepted in place of titled years | `[grounded]` JD silence |
| Contradictions | None found within the pasted JD; not checked against a careers page | `[grounded]` JD text only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience, titled | must_have | absent | none | capability | You have never held a PM title, so the titled years do not exist. It is not a gate, because years of experience are graded like any requirement. | `[grounded]` your statement; `[generic]` that titled years are often screened literally | Carry as a risk; the closure path is in G1 |
| R1b | PM-type work behind those years | must_have | adjacent | medium | transferability | You worked alongside PMs on custom builds, ran quarterly roadmap-input sessions and wrote requirements documents. That is PM-adjacent work, but you did not own a roadmap or a prioritisation decision as stated. Limit: input, not decision. | `[grounded]` CV prose | Name the limit wherever the bridge is used |
| R2 | Shipped API or platform products | must_have | adjacent | low | discovery | You led 30+ end-to-end integrations of your employer's REST APIs, which is API work from the implementation side. Nothing confirms you shipped an API product. The triage tool is an unconfirmed lead (G2). | `[grounded]` CV prose; `[inferred]` adjacency from integration work | Ask G2 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI reading, plus 30+ REST integrations. It is confirmed and specific, but nothing inspectable has been seen yet. | `[grounded]` CV prose | Offer: the integration playbook, sanitized, would raise this to `high` |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your own engineers, the clients' engineers and PMs across scoping, UAT and go-live. | `[grounded]` CV prose | None |
| R4b | Stakeholder management with sales and support | must_have | unclear | low | discovery | The CV does not mention sales or support partners. | `[grounded]` CV silence | G4 |
| R5 | Experience with agile delivery | must_have | unclear | low | discovery | The CV describes UAT and go-live and does not say how delivery was run. | `[grounded]` CV silence | Ask G3 |
| R6 | Discovery with integration partners | important | adjacent | medium | transferability | You ran scoping workshops and quarterly client-input sessions. The limit is that you collected input and the roadmap decisions sat with product. | `[grounded]` CV prose | CV edit E1 |
| R7 | Own the roadmap and prioritise | important | unclear | low | discovery | Nothing states that you owned a roadmap. The triage tool, if confirmed, may be the nearest case. | `[grounded]` CV silence; memory lead is unconfirmed | Ask G2 |
| R8 | Write specs and drive delivery with engineering squads | important | adjacent | medium | transferability | You wrote requirements documents and integration architecture for client builds, and coordinated engineers. Limit: client-facing specs, not specs for an internal product backlog. | `[grounded]` CV prose | Work sample W1 |
| R9 | Define and track adoption metrics | important | unclear | none | discovery | Nothing in the CV mentions measuring adoption. | `[grounded]` CV silence | G5 |
| R10 | Coordinate launches with sales and support | important | adjacent | low | transferability | Go-live on client integrations is launch-like work. Nothing says sales or support were part of it, so the match is thin. | `[inferred]` from "go-live" in the CV | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Titled PM years (R1a, must_have) | capability | No PM title and no ownership of a product decision | It is the one requirement wording cannot fix; interviews will probe it | A PM-titled stretch elsewhere, or an internal move to a product role first | Not recoverable by an artifact for this posting | `[grounded]` your statement; `[generic]` that titled years are often applied literally |
| G2 | Request-triage tool and roadmap ownership (R2 and R7) | discovery | An unconfirmed memory lead says you built an internal request-triage tool that support agents adopted | If confirmed and owned, it is the closest thing to a shipped product with adoption, and could move R2 and R7 | Deciding what the tool did, handling requests to change it, measuring its use, shipping versions | A screenshot, a short write-up, usage numbers | `[grounded]` memory lead, unconfirmed; `[inferred]` that it could move R2 and R7 |
| G3 | Agile delivery (R5) | discovery | The CV is silent on delivery method | A named must-have, cheaply resolved if the experience exists | Working inside sprints with a squad, a Jira board, sprint reviews on custom builds | A board export or sprint notes | `[grounded]` CV silence |
| G4 | Sales and support partnership (R4b, R10) | discovery | The CV names engineers, clients and PMs, not sales or support | The JD asks you to coordinate launches with both | Joint go-live planning with sales, support handoffs, enablement for support | A launch checklist or handoff doc | `[grounded]` CV silence |
| G5 | Adoption metrics (R9) | discovery | No metric work stated | The role defines and tracks adoption | Tracking integration adoption or time-to-live across clients | A client dashboard or report | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The searches were refused, so nothing was checked. The company may be too new or small to have a footprint, or the posting may be stale. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your careers site, and who I'd be interviewing with? | unresolved |
| RR2 | Compensation withheld | unknown | — | The pasted JD states no figure | The range may sit below or above your target, and no band has been compared | `[inferred]` from the JD's silence | What is the budgeted range for this role? | unresolved |
| RR3 | Concrete mandate and ownership | positive_signal | — | "Own the roadmap for our partner-facing API platform … two engineering squads" | Scope and reporting lines look defined | `[grounded]` JD states the scope | Which roadmap decisions does this role make alone, and who arbitrates between the two squads? | noted |
| RR4 | Adoption targets unspecified | unknown | — | "define and track adoption metrics" | The role may own a metric with no baseline or target | `[inferred]` from the JD naming the work and no targets | What adoption baseline and targets exist today? | unresolved |

## Application plan

`resume_edits_pending_approval` — every row is a proposal, and none is applied until you approve it. Each line is built only from your own sentences.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move "Ran quarterly roadmap-input sessions collecting client feedback for product" up; proposed wording "Ran quarterly sessions collecting client feedback as input to the product roadmap". No outcome added. | see R6 | `[grounded]` CV | pending your approval |
| E2 | Lead with "Led 30+ client integrations of our REST APIs end to end", keeping your phrases "scoping workshops, requirements documents, integration architecture, UAT, go-live" | see R2, R3, R8 | `[grounded]` CV | pending your approval |
| P1 | In any cover note or conversation, say plainly you have not held a PM title, then name the PM work you did and where it stopped (input to the roadmap, not ownership) | see R1a, R1b | `[grounded]` your statement | pending your approval |
| A1 | Reach a person at Quartzline first; a referral or direct note to the hiring side before a cold submit | How hiring often works for stretch candidates; not a fact about Quartzline | `[generic]` role-family pattern | pending your approval |
| A2 | Confirm the employer and posting are live before investing effort | see RR1 | `[grounded]` RR1 | pending your approval |
| W1 | A one-page sample: how you would measure adoption for a partner API, using only what you know from your integrations | see R8, R9 | `[inferred]` from the gaps in those rows | pending your approval |
| Q1 | Ask RR1 to RR4's verification questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: a memory lead that you built an internal request-triage tool adopted by support agents — unconfirmed, and it prompts a question only.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Quartzline logistics technology partner API platform Series B", "Quartzline careers Product Manager Platform APIs") were refused. They would have settled RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | One search (API product manager salary and requirements) was refused. It would have given the market calibration line and the RR2 comparison |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

One more option beyond the standard assessment: a side-by-side of nearer-in PM-pivot routes for your profile, such as technical PM, product ops or solutions-to-product moves. This engagement earns it because R1a is the one row no wording fixes. Say so and I'll build it.

I can write the full report as `tuesday-dossier.md` if you want a file to keep.

**Upgrade menu**
- Permission to run web searches → RR1 and the contradictions row resolve, and a market band for RR2.
- An answer to G2, with a screenshot or short write-up → R2 and R7 could move from adjacent and unclear toward direct.
- A sanitized copy of your integration playbook → R3 to `high`.
- Your pay floor and location limits → the hard-gates line stops reading "checks unknown".
- A hiring manager's name → role reality's scope read and which story to lead with.

**Questions**

Constraints — what pay floor, location or schedule limits are non-negotiable for you?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Tell me about the request-triage tool: what did you personally own, who used it, and how did you know it worked?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G3 — On any of your custom builds, did you work inside sprints or a squad's board with PMs and engineers?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.