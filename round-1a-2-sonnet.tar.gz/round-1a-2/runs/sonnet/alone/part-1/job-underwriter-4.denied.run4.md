Still reading the skill's reference rules (research tiers, snapshot format, question selection) so the assessment follows them; then I'll write it.
**Yes, apply. Your fit is strong on the stated requirements, but the employer is unverified, so I'm calling it `conditional_go`.** Status: `conditional_go`.

**Fit ledger.**

- `hard_gate` — unclear: R10 (Fully remote, UK)
- `must_have` — direct: R1, R2, R3, R4, R5, R6
- `important` — adjacent: R7 (Recommendations to underwriting and product)
- `preferred` — direct: R8 · adjacent: R9 (Pet-insurance domain)

R9 — a credible bridge, its limit named; R7 — underwriting side evidenced, product side not.

**Opportunity ledger.** The deliverables are well specified (RR5). Against that, the employer is not yet established (RR1), the pay is not stated (RR2), and the remote terms (RR3) and any direct reports (RR4) are unstated.

- **Hard gates:** none failed (R10); unconfirmed: R10 (Fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and the live posting verify (RR1); (2) the remote and UK terms and the pay are confirmed (R10, RR2, RR3); (3) the pet bridge is framed as adjacent and never as pet-insurance experience (R9); (4) your role in designing the price tests is confirmed (R5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech selling pet insurance. Existence and posting not yet checked | `[grounded]` JD header; not established, see RR1 |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, and turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | An individual-contributor pricing post for one product, with no line management listed | `[inferred]` from the requirements list, which names no reports and no people-management duty |
| First-90-days outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not established. The role-family search was refused, so there is no salary band to set against the unstated pay | `[grounded]` search refused, see Evidence status |
| Unknowns | Pay; whether remote means employed in the UK with no office days; reports; who signs off rating changes; the current rating-model stack | `[grounded]` JD silent on each |
| Contradictions | None between your background and the JD. The JD could not be checked against the careers page | `[grounded]` provided inputs only |

## Evidence map

Your background is typed prose, so it counts as CV-equivalent self-report. That caps every candidate row at `medium` until you share something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Your stated 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst, clears the bar. The years are self-reported, with nothing inspectable yet | `[grounded]` your background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. No artifact has been seen, so expect a technical probe | `[grounded]` your background | A sanitised query or notebook would raise this to `high` |
| R3 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Limit: that is a motor book, not pet | `[grounded]` your background | A sanitised model-documentation excerpt would raise this to `high` |
| R4 | Build and monitor rating models | must_have | direct | medium | none | Your claim covers building and maintaining the young-driver GLM. How you monitored it (drift, lift, loss-ratio tracking) is not stated | `[grounded]` your background; monitoring detail not stated | G1 closes the detail |
| R5 | Design and read price tests | must_have | direct | medium | discovery | You ran 14 price tests last year with the underwriting team. "Ran" does not say whether you designed them (hypothesis, segmentation, sample size). The claim stays at "ran" until you confirm | `[grounded]` your background; design ownership unconfirmed | G1 |
| R6 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. That matches the audience type | `[grounded]` your background | A sanitised review deck would raise this to `high` |
| R7 | Turn results into recommendations for underwriting and product | important | adjacent | medium | discovery | The underwriting side is evidenced by the 14 tests and the quarterly review. Nothing you've said touches a product team | `[grounded]` your background; `[inferred]` that product-facing work may exist but is unstated | G2 |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background | none |
| R9 | Pet-insurance domain knowledge (not stated as a requirement; the JD only says insurance is a plus) | preferred | adjacent | medium | transferability | Your GLM, test and presentation work is personal-lines pricing. Limit: you've had no pet exposure. Pet-specific drivers such as breed, age and condition history do not appear in your background. Pet books usually differ from motor on these | `[inferred]` adjacency from your motor work; `[generic]` that pet rating drivers differ from motor | G3 |
| R10 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | The JD states the term. You haven't stated where you are based or your remote and pay constraints. Working at a UK insurer suggests, but doesn't establish, that you meet it | `[grounded]` JD; your location and constraints not given | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Test design and monitoring depth (R5, R4) | discovery | "Ran 14 price tests" and "built and maintained" the GLM | R5 is a `must_have` and the JD says "design and read" | Choosing test cells or holdouts, setting the success measure, writing the readout, owning the model's monitoring pack | A sanitised test readout or monitoring dashboard screenshot | `[grounded]` your wording; `[generic]` that design ownership is what a hiring manager probes |
| G2 | Product-facing recommendations (R7) | discovery | Underwriting audience only | The JD names product as a second recipient | A recommendation that went to a product or proposition owner, even once | A sanitised recommendation memo | `[grounded]` JD and your background |
| G3 | Pet domain (R9) | transferability | Motor GLM work only | A preferred row, but it is where interviewers will test you | Any contact with pet, home or other non-motor personal lines; personal interest is not evidence | None to chase. Frame it as adjacent, with the limit stated | `[inferred]` bridge from motor pricing; `[generic]` that the gap will be probed |
| G4 | Remote and UK terms (R10) | hard_gate | Not stated | A gate the inputs don't settle stays a gate | Not applicable. The only route is to confirm whether you meet it | Your stated location and any pay or working-pattern floor | `[grounded]` JD; your constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. I could not check, because the searches were refused | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | no pay figure in the JD | Pay may be withheld until a later stage, or may be below what your 2 years at senior level would expect. There is no calibrated band to compare against | `[inferred]` from the JD's silence | What salary band is budgeted for this post? | unresolved |
| RR3 | Remote terms thin | unknown | — | "Fully remote (UK)" | "UK" may mean UK-resident employment, with unstated limits on travel or hours | `[inferred]` from a three-word term | Is the post employed in the UK, and are there any required office or on-site days? | unresolved |
| RR4 | Reports and scope of authority unstated | unknown | — | "Own pricing analytics" | The post may be individual-contributor now, with team growth possible. You have not managed anyone, which matters only if reports are planned | `[inferred]` from the JD's silence on reports | Does this role have direct reports now, or is one planned? | unresolved |
| RR5 | Deliverables and tools are specific | positive_signal | — | "build and monitor rating models, design and read price tests" | The post has concrete outputs that line up with your own work | `[grounded]` JD | Who signs off rating changes, and how often do they ship? | noted |

## Application plan

`resume_edits_pending_approval`: every line below uses only your own words.

| # | Proposed CV line | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | "Built and maintained the GLM rating model for the young-driver book." | R3, R4 | `[grounded]` your background | pending your approval |
| E2 | "Ran 14 price tests last year with the underwriting team." Upgrade the verb only after you confirm you designed them (G1) | R5 | `[grounded]` your background | pending your approval |
| E3 | "Present the quarterly pricing review to the head of underwriting." | R6 | `[grounded]` your background | pending your approval |

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead the application with the GLM model, the test programme and the quarterly review, in that order. Mention pet insurance only as new to you, with your motor GLM and test experience as the bridge | R3, R5, R6, R9 | `[grounded]` your background; `[generic]` that a stated gap with a bridge reads better than silence | pending your approval |
| A2 | Verify the employer and the live posting before investing effort, using RR1's question | RR1 | `[grounded]` RR1 | pending your approval |
| A3 | Ask RR2, RR3 and RR4 verbatim in the first conversation with Odile Varga or the recruiter | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Never managing anyone is not a gap against any requirement here, because the JD lists no people-management requirement. If RR4 comes back "reports planned", it becomes a row.

## Evidence status

Verified: none yet. Every claim above is self-report from your typed background. Unverified leads: none from earlier context.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech careers"; the search was refused. It would have confirmed the entity, the live posting and any contradictions, feeding RR1 and the Organization and Contradictions rows |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst pet insurance UK salary remote"; refused. It would have given the market calibration and a salary band for RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; refused. It would have informed the scope read and which story to lead with for Odile Varga, from public professional footprint only |

I can offer to write this up as a `tuesday-dossier.md` file if you'd like to keep it.

## Upgrade menu

- Permission for web search, so the three targets above can run: RR1 can close, the market calibration appears, and the plan's lead story can be tuned to Odile Varga.
- A sanitised price-test readout or model-monitoring screenshot: R5 and R4 move toward `high`, and G1 closes.
- A sanitised query, notebook or model-documentation excerpt: R2 and R3 move toward `high`.
- Your CV file: it would let me check for buried evidence and tighten E1–E3.
- Your stated location and any pay or working-pattern floor: R10 moves off `unclear`.

Questions, each tagged to its row:

1. **(G1, R5)** Did you design the 14 price tests (hypothesis, segments, sample size, readout), or run tests someone else designed?
2. **(G2, R7)** Have you ever made a recommendation that went to a product or proposition owner rather than underwriting?
3. **(G4, R10)** Are you UK-based, and do you have a pay floor or any other non-negotiable for a remote role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.