I'll read the reference files the skill names before building the assessment.
Running the Quartzline company check and a role-family salary sweep, then I'll write up the assessment.
**Research status:** all three searches were refused, so nothing about Quartzline or the market is verified. This assessment runs on the JD and your resume text, and I've labeled it that way.

## Decision snapshot

**No, you're not wasting your time, but treat this as a stretch application and not a fit. R1b (3+ years in a PM role) is absent, and no resume wording can close it. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1a (3+ years PM experience), R7 (own the roadmap) · unclear: R2 (shipped API or platform products), R4b (sales and support), R5 (agile delivery) · absent: R1b (3+ years in a PM role)
- `important` — adjacent: R6 (discovery with integration partners), R9 (specs, two squads) · unclear: R8 (adoption metrics)

R1b — a real gap you can't reword away; R3, R4a — the technical and customer-side strengths carry your case; R2, R8 — one unconfirmed lead from earlier context may move both.

**Opportunity ledger.** The role is plausibly scoped (RR4), but the employer is unverified (RR1), pay and location are withheld (RR2), and decision rights over the roadmap are unstated (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:**
  1. The posting is confirmed live on Quartzline's own careers page (RR1).
  2. You apply as adjacent: no PM-equivalent claims, and the gap named up front (R1a, R1b, R7).
  3. Your answers on the triage tool and on prioritisation don't contradict the adjacent framing (R2, R8, R7).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B. Not independently verified | `[grounded]` JD header only |
| Mandate | Own the roadmap for a partner-facing API platform; run partner discovery; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | One platform, two squads, and a partner-facing audience read as a single-product mandate, not a bundle of roles | `[inferred]` from the responsibility list against the stated team count |
| Market calibration | Not run. The role-family sweep was refused, and pay is unstated | `[grounded]` search refused; JD silent on pay |
| Unknowns | Pay, location or remote, reporting line, decision rights vs. sales, whether the team is agile in practice | `[grounded]` JD silent on each |
| Contradictions | None visible inside the JD text. Cross-check against the careers page not possible | `[grounded]` JD text; search refused |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience: the work overlaps | must_have | adjacent | medium | transferability | You coordinated product managers on custom builds, wrote requirements documents, and ran quarterly roadmap-input sessions. Limit: you describe supplying input, not deciding what got built | `[grounded]` your resume text | G1 |
| R1b | 3+ years product management experience, read literally as years in a PM role | must_have | absent | none | capability | You wrote "I have never held a PM title". The JD marks the requirement a must-have. Employers often screen such lines literally, though this one's practice is unknown | `[grounded]` your statement and the JD; `[generic]` on literal screening | G2 |
| R2 | Shipped API or platform products | must_have | unclear | low | discovery | You integrated your vendor's REST APIs 30+ times. That is the implementer's side, not shipping the API. A prior-context lead about a triage tool is unconfirmed, so it sets the band at `low` and nothing more | `[grounded]` resume text; `[inferred]` that the lead may bear on this row | G3 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, reading OpenAPI specs, and integration architecture across 30+ integrations, all self-reported. No artifact inspected | `[grounded]` resume text | Offer: a sanitized Postman collection or architecture note would raise to `high` |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | Your own engineers, client engineers, and clients across scoping, UAT, and go-live. Self-reported | `[grounded]` resume text | none |
| R4b | Stakeholder management with sales and support, including launch coordination | must_have | unclear | none | discovery | Your resume is silent on sales and support | `[grounded]` resume silence | Carried, not asked this turn |
| R5 | Agile delivery | must_have | unclear | none | discovery | Your resume is silent on sprints, backlogs, or squads | `[grounded]` resume silence | Carried, not asked this turn |
| R6 | Run discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and roadmap-input sessions with clients. Limit: discovery to scope a client's implementation differs from discovery to decide what the platform builds | `[grounded]` resume text; `[inferred]` on the difference in kind | G1 |
| R7 | Own the roadmap | must_have | adjacent | medium | transferability | Roadmap-input sessions sent client feedback to product. Limit: no stated decision rights or prioritisation | `[grounded]` resume text | G1 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | Nothing in your resume text. The unconfirmed triage-tool lead involves adoption but is not evidence | `[grounded]` resume silence; `[inferred]` lead relevance | G3 |
| R9 | Write specs and drive delivery with two engineering squads | important | adjacent | medium | transferability | Requirements documents and engineer coordination on custom builds. Limit: no stated ownership of a squad's backlog | `[grounded]` resume text | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Prioritising, not supplying input (R7, R1a, R6, R9) | transferability | Adjacent: requirements documents, roadmap-input sessions, and PM coordination. Limit: nothing says you decided what was built or in what order. Strengthener: one concrete case of that | These rows decide whether the PM-experience objection can be answered with evidence or only with framing | Choosing among competing client requests for a custom build; deciding what the playbook covers; breaking a tie between engineering and a client; owning a backlog for an internal tool | The roadmap-input session summary or feedback template, a prioritisation doc, the playbook | `[grounded]` resume text; `[inferred]` that this is the likeliest probe |
| G2 | PM-role years (R1b) | capability | No credible evidence of PM-role years. You have said you hold no PM title | A literal screen on this must-have may end the application before a human reads the rest | Closure paths: apply as a stretch anyway, or target associate, technical, or product-adjacent PM titles, or an internal move | Nothing to attach; wording cannot supply the years | `[grounded]` your statement; `[generic]` on how screens treat titled-years lines |
| G3 | Shipped products and adoption (R2, R8) | discovery | Only an unconfirmed prior-context lead of a request-triage tool that support agents adopted | One confirmed, owned, adopted tool would move two rows at once | An internal tool you specced and rolled out; a workflow or playbook other teams adopted; usage you tracked | A README, screenshots, usage numbers, a rollout note | `[grounded]` memory lead, unconfirmed; `[inferred]` that it may bear on both rows |
| G4 | Sales and support launch work (R4b) | discovery | Resume silent | A JD responsibility with no evidence either way | Launch or go-live handoffs to support; enablement for sales or CS | A handoff doc or training deck | `[grounded]` resume silence |
| G5 | Agile delivery (R5) | discovery | Resume silent | A must-have with no evidence either way | Custom builds run in sprints; standups or backlog grooming with engineers | A sprint board export | `[grounded]` resume silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | Searches were refused, so I couldn't confirm the company or the posting. The company may be small, or the posting may be stale | `[generic]` standing pattern, not a claim about this company | Can you point me to this role on your careers site, and who would I interview with? | unresolved |
| RR2 | Pay, location, and level not stated | unknown | — | JD gives none | Pay may sit below or above the band for this scope, or the company may not publish it | `[inferred]` from JD silence | What is the salary range, and is the role remote, hybrid, or on-site? | unresolved |
| RR3 | Roadmap ownership vs. decision rights | unknown | — | "Own the roadmap for our partner-facing API platform" | Ownership of the roadmap alongside sales and partner requests may or may not come with authority to say no | `[inferred]` from the JD's scope language against its silence on authority | Which roadmap decisions does this role make alone, and which go to sales or leadership? | unresolved |
| RR4 | Defined scope: one platform, two squads, named partner discovery | positive_signal | — | "drive delivery with two engineering squads" | The mandate is concretely scoped | `[grounded]` JD states the squads and the platform | Who owns adoption metrics today? | noted |

## Application plan

**`resume_edits_pending_approval`** — each proposed line reuses your own sentences, and none adds a fact.

| # | Current | Proposed | Source quote | Status |
|---|---|---|---|---|
| E1 | (summary, if any) | "Seven years leading client integrations of REST APIs, from scoping through go-live, and collecting client feedback for product in quarterly roadmap-input sessions." | "7 years as a solutions engineer / implementation lead"; "collecting client feedback for product" | pending your approval |
| E2 | Roadmap-input bullet, lower on the page | Move it up beside the integration bullet, with the wording unchanged | "Ran quarterly roadmap-input sessions collecting client feedback for product" | pending your approval |

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Cover-note line: "I haven't held a PM title. For seven years I've led client integrations of our REST APIs and collected client feedback for product in quarterly roadmap-input sessions; I'd like to do that work from the product side." | Names the gap yourself, which a literal screen will find anyway | `[grounded]` your own sentences; `[generic]` on screening | pending your approval |
| A1 | Find the posting on Quartzline's own careers page before investing effort | Closes RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the RR1 to RR3 questions verbatim in any conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Seek a referral or hiring-manager conversation before a cold application | Referrals can bypass a literal screen at small companies | `[generic]` hiring pattern, not a fact about this employer | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: a prior-context mention of a request-triage tool that support agents adopted. It is unconfirmed and only prompts a question.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology company Series B partner API platform" and "Quartzline careers Product Manager Platform APIs"; both refused. Would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "platform API product manager salary Series B startup solutions engineer to product manager transition"; refused. Would have moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

If you'd like, I can write this up as a `tuesday-dossier.md` you can keep and update.

## Upgrade menu

- Your actual resume text or file → resume edits become exact diffs, and presentation rows can be confirmed.
- A sanitized playbook excerpt, a roadmap-session summary, or a Postman collection → R3, R7, R6 toward `high`.
- A README, screenshots, or usage numbers for the triage tool → R2 and R8.
- Search permission or a link to the live Quartzline posting → RR1 and role reality, plus the market band for RR2.
- Hiring manager's name → the scope read and which story to lead with.
- Your pay floor, location needs, and non-negotiables → hard-gate rows built and checked.

**Questions**

- **G3** — I have a note from an earlier conversation that you may have built an internal request-triage tool that support agents adopted. I haven't treated that as fact. Is it true, and if so, what did you own, who used it, and how did you know it was adopted?
- **G1** — On a custom build or in the roadmap-input sessions, was there a time you decided or materially shaped what got built or prioritised? What did you own, who made the final call, and what happened?
- **Constraints** — What is your salary floor, what location or remote setup do you need, and is anything non-negotiable?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.