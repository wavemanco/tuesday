I've read the posting and the underwriting rules. Next I'm running the company, salary-band and hiring-manager research checks, then I'll write the assessment.
**Decision snapshot**

**Yes, it's worth applying — R6 (forecast ownership) is only adjacent, R7a (billing data) is absent, and the gates R1 and R2 are unconfirmed. Status: `conditional_go`.**

**Fit ledger**

- `hard_gate` — unclear: R1 (Bristol, hybrid, two office days), R2 (£61,500–£67,000 pay)
- `must_have` — direct: R3, R4, R5a · adjacent: R6 (owning a forecast) · unclear: R5b (spreadsheet modelling), R7b (revenue data with finance) · absent: R7a (billing data with finance)
- `important` — direct: R8

R6 — adjacent, finance owned the forecast; R7a — absent, no billing data; R5b (`low`) — daily Excel use stated, modelling not shown.

**Opportunity ledger.** The pay range is stated and sits inside the market band (RR3). Reporting line and success measures are open (RR2), the posting isn't confirmed on Quillfield's own site (RR1), and the option terms are unknown (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, hybrid, two office days), R2 (£61,500–£67,000 pay); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location and pay floor are checked against R1 and R2; (2) you present R6 as adjacent and R7a as a stated gap, never as ownership; (3) the posting is confirmed live with the recruiter (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` "About Quillfield" (quillfield.co.uk/about), seen as a search result |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two office days a week | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options | `[grounded]` posting |
| Scope read | Three headline responsibilities (data ownership, reporting, forecast) cross RevOps and finance analytics. The posting states no team, reports or success measures | `[inferred]` from the posting's mandate against its silence on resources |
| Hiring manager | Tamsin Achebe is listed as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. This matches the recruiter's attribution | `[grounded]` search-result snippet for her profile; the profile page itself was not opened |
| Market calibration | The Ledgerline 2026 guide gives a UK B2B software revenue operations lead median base of £64,200 (n=438, interquartile range £57,800–£70,400). The posted range sits inside that range, close to the median. This is one national source, not Bristol-specific, and not a statement about Quillfield's offer | `[generic]` role-family search; `[grounded]` posting for the range |
| Unknowns | Reporting line, team size, who owns the forecast model today, success measures, option terms, billing system | — |
| Contradictions | The posting asks for experience at a "B2B software company". Your background is a B2B payments company, which the posting may or may not count as software. Quillfield's own site had no `/careers` page at the address tried, so the posting is unconfirmed there | `[grounded]` your background and the failed fetch; `[inferred]` that the sector wording is a screening risk |

## Evidence map

Your background is the only candidate evidence so far. It was typed in, so it is self-report and capped at `medium` until probed.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | The terms are stated. You gave no location or schedule constraint, so whether they are met isn't established | `[grounded]` posting; no candidate statement | Gate question in the closing block |
| R2 | Pay £61,500–£67,000 plus options | hard_gate | unclear | none | hard_gate | The terms are stated. You gave no pay floor, so the match isn't established | `[grounded]` posting; no candidate statement | Gate question in the closing block |
| R3 | 4+ years in RevOps, sales ops or similar analytics at a B2B software company | must_have | direct | medium | none | Five years in sales operations, two of them running RevOps for the UK team. The "software company" wording is the open edge, since yours was a payments company | `[grounded]` your background; `[inferred]` on the sector edge | State the company's product on the CV, truthfully |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, confirmed and specific. The certificate hasn't been inspected | `[grounded]` your background | Certificate or Trailhead record would raise it to `high` |
| R5a | Strong SQL | must_have | direct | medium | none | SQL weekly is confirmed. Depth beyond weekly use isn't evidenced; expect a practical test | `[grounded]` your background; `[generic]` that roles like this often test SQL | A sanitized query sample would raise it |
| R5b | Spreadsheet modelling | must_have | unclear | low | discovery | You use Excel daily, but daily use doesn't show models built. Nothing yet says what you modelled | `[grounded]` your background | Recall prompt G3 |
| R6 | Experience owning a forecast (the posting also has you run the quarterly forecast with the CFO) | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, which is adjacent. Limit: finance owned the company forecast, so you haven't owned one | `[grounded]` your background | Recall prompt G1; frame as adjacent only |
| R7a | Working with finance on billing data (the posting also has you own billing data) | must_have | absent | none | capability | You confirmed you've never worked on billing data. No adjacent evidence is in hand | `[grounded]` your statement | Closure path in G4; carry as a material risk |
| R7b | Working with finance on revenue data | must_have | unclear | low | discovery | You rebuilt renewal dashboards, which touch revenue. Whether finance used them or you reconciled them to invoiced revenue is unknown | `[grounded]` your background; `[inferred]` that renewals data may count | Recall prompt G2 |
| R8 | Build the pipeline and renewal reporting that sales and finance run on | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Which teams run on them isn't stated | `[grounded]` your background | A sanitized screenshot would raise it to `high` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6, must_have) | transferability | Monthly pipeline review with your sales director; finance owned the forecast | The posting has you running the forecast with the CFO, so this is the gap an interviewer is most likely to press | Building a commit and best-case roll-up; a renewals forecast; a quota or capacity model; supplying the pipeline inputs to finance's forecast | A sanitized pipeline review pack or forecast roll-up | `[grounded]` your statement; `[inferred]` that this is the likeliest objection |
| G2 | Revenue data with finance (R7b, must_have) | discovery | Renewal dashboards exist; finance involvement unknown | It could narrow R7a's distance from the role | Finance using your renewal numbers; reconciling renewals to invoices; month-end or board reporting inputs | A sanitized renewal dashboard, a reconciliation sheet | `[grounded]` your background; `[inferred]` on relevance |
| G3 | Spreadsheet modelling (R5b, must_have) | discovery | Excel daily, no model described | It decides whether R5b becomes `direct` | Scenario models, forecasting sheets, commission or territory models | A sanitized workbook | `[grounded]` your background |
| G4 | Billing data (R7a, must_have) | capability | You've never worked on billing data | It's part of the posting's headline ownership | A small SQL project reconciling invoices to closed-won deals on public or synthetic data | The finished sample, if you choose to make one | `[grounded]` your statement; `[inferred]` that a work sample is a realistic path |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on Quillfield's own site | unknown | — | "Revenue Operations Lead, Quillfield" on a third-party board | The role may be live but listed elsewhere, or stale | `[grounded]` `/careers` returned no page; `[generic]` that small firms often use job boards only | Can you point me to this role on Quillfield's own careers page? | unresolved |
| RR2 | Team, reporting line and success measures not stated | unknown | — | "You will own our CRM and billing data..." | The Lead may carry three functions without stated resources | `[inferred]` from the posting's scope against its silence | Does the Lead have reports, who owns the forecast model today, and what does success look like at 12 months? | unresolved |
| RR3 | Pay stated, inside the market band | positive_signal | — | "£61,500–£67,000" | A stated range suggests a defined budget | `[grounded]` posting; `[generic]` for the band | What determines where in the range an offer lands? | noted |
| RR4 | Share option terms unknown | unknown | — | "plus share options" | The options may be worth little or a lot depending on terms | `[generic]` pattern for early-stage equity | What are the option number, strike price and vesting terms? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check your location and pay floor against R1 and R2 before investing effort | Either could end the application | `[grounded]` R1, R2 | pending your approval |
| A2 | Ask the recruiter to confirm the role is live on Quillfield's careers page (RR1) | The fetch found no such page | `[grounded]` RR1 | pending your approval |
| E1 | Put the pipeline and renewal dashboard rebuild and the monthly pipeline review first on the CV, in your own facts, with no new claims | See R6, R8 | `[grounded]` your background | pending your approval |
| E2 | State the company's product plainly on the CV so a "B2B software" screen can read it | See R3 | `[grounded]` R3 | pending your approval |
| Q1 | Ask the verification questions in RR1, RR2 and RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P1 | Lead with the sales-ops-to-RevOps path you can evidence (R3, R8), since Tamsin Achebe's public profile shows that same career pattern | Her published footprint is the only reader information in hand | `[grounded]` search-result snippet; no inference about her preferences | pending your approval |
| W1 | Optional: a small SQL invoice-to-deal reconciliation sample on public or synthetic data | Narrows R7a, doesn't close it | `[inferred]` closure path | pending your approval |

None of these actions changes anything until you approve it. I haven't drafted CV wording, so no new claim has been added.

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers", which returned "About Quillfield" (quillfield.co.uk/about); fetched quillfield.co.uk/careers, which returned no page. Moved the organization row and the contradictions row, and added RR1 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the hiring manager row and P1 |

I can offer to write this up as a `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- Your CV or a prior résumé → R3, R4, R5a, R5b, R8 move off self-report and the CV edits become concrete.
- A sanitized pipeline or renewal dashboard, or a pipeline review pack → R8 to `high`, and G1 and G2 may narrow.
- Your Salesforce certificate or Trailhead record → R4 to `high`.
- Your location and pay floor → R1 and R2 resolve and the status can firm up.
- The recruiter's confirmation that the role is on Quillfield's careers page → RR1 closes.
- A deeper research pass on Quillfield (funding, leadership churn, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

R1, R2 — Can you do two office days a week in Bristol, and what is your pay floor against £61,500–£67,000?

G1 — Have you built or maintained any forecast, even one finance owned, such as a commit roll-up, a renewals forecast or a capacity model? What part was yours?

G2 — Did finance ever use your pipeline or renewal dashboards, or reconcile them to invoiced revenue? What did you own in that?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.