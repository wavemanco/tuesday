I'll read the reference files the skill points to before building the assessment.
**Decision snapshot**

**Yes, apply. Status: `conditional_go`.** Your motor-pricing work meets R2, R3, R4, R5, R6a and R7 directly. The conditions are below.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5, R6a, R7 · unclear: R6b (Designing the tests)
- `important` — adjacent: R10 (Pet-insurance domain) · unclear: R8 (Recommendations for product)
- `preferred` — direct: R9

R10 — a credible bridge, its limit named; R6b — you ran the tests, test design isn't stated; R8 — the product side is not evidenced; R1 — UK residence not stated.

**Opportunity ledger.** Under-specified on the facts that matter. The employer and posting are not established (RR1), the posting as pasted gives no salary (RR2), and whether the role leads people or has sign-off authority is unstated (RR3, RR4). The deliverables are explicit and the hiring manager is named (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting and Brindlemoor are confirmed live on its own careers site (RR1); (2) R1 is confirmed met; (3) R6b is closed or framed honestly as running tests, not designing them; (4) the pet bridge is framed as adjacent, never as pet-insurance experience (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD as pasted; existence not checked |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | Odile Varga, Director of Pricing | `[grounded]` your message |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | One product line and one named pricing director point to a focused post. Whether anyone reports to the role is not stated | `[inferred]` from the JD's single product and its silence on team size |
| Market calibration | Not produced: the role-family sweep did not run (see Evidence status) | — |
| Unknowns | Salary; contract basis; team structure; sign-off authority on rate changes; first-year outcomes; Brindlemoor's size and stage | `[grounded]` JD silence on each |
| Contradictions | None inside the JD as pasted; it has not been checked against a careers page | `[grounded]` JD text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You did not state where you live or your right to work. A UK motor-insurer role suggests UK, but that is a reading, not your statement. Confidence is low because there is no statement of yours to grade | `[inferred]` from your UK employer; `[grounded]` JD term | Ask G2 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics, the last 2 as senior analyst. Specific, but self-reported with no inspectable artifact yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is stated. "Strong" has not been probed; a model pipeline, query set or notebook would be the artifact | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. The limit is motor and a single book | `[grounded]` your background | Offer: sanitized model documentation or factor tables would raise to high |
| R5 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" is carried as you said it. The JD says models, plural; you described one book. How you monitored it (drift, loss-ratio tracking) is not stated, so the row does not assume it | `[grounded]` your background; `[generic]` that interviews for this role family probe monitoring practice | none |
| R6a | Price testing (JD: "design and read price tests") | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team, and "ran" is carried as your verb. Design is split out as R6b | `[grounded]` your background | Offer: a sanitized test readout would raise to high |
| R6b | Designing the tests: setup, sizing, success measures | must_have | unclear | low | discovery | "Ran" fits both designing and executing. Ambiguity resolves downward, so design is not asserted | `[grounded]` your wording; `[inferred]` that design is plausible but unconfirmed | Ask G1 |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. Underwriting is covered; actuarial leads are not mentioned | `[grounded]` your background | none |
| R8 | Turning results into recommendations for product | important | unclear | low | discovery | The underwriting side is evidenced through R7. Nothing you wrote touches product stakeholders | `[grounded]` your background silence on product | Ask G4 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance domain knowledge (not stated; implied by the product) | important | adjacent | medium | transferability | You confirmed you have never worked on pet insurance. The bridge is GLM pricing on a young-driver book. The limit is that none of it touched pet risk or claims | `[inferred]` from the JD's product focus; `[grounded]` your confirmation | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Test design (R6b, must_have) | discovery | 14 tests run with underwriting; your role in design is not stated | A must-have at `unclear`; resolving it could lift the row to `direct` | Choosing test and control segments; setting sample size or run length; defining success measures and guardrails; deciding when to roll out or stop | A test plan, a sanitized readout, a design note | `[grounded]` your wording; `[generic]` that roles like this probe design ownership |
| G2 | UK location and right to work (R1, hard_gate) | hard_gate | The JD says "Fully remote (UK)"; your message does not state your location | A gate the inputs do not settle stays open and caps the decision | Not applicable: this is a yes or no on whether the term is met | None needed | `[grounded]` JD term and your silence |
| G3 | Pet domain (R10, important) | transferability | Young-driver GLM work is the adjacent evidence; no pet exposure | The bridge is the likeliest objection to your application | Rating on age or breed-like banded factors; frequency-severity modelling; claims-cost trend work; analysis on a small-volume book | A short note on how you would approach the pet rating factors, written by you | `[inferred]` bridge from the young-driver model; `[generic]` that domain gaps are the usual objection in a switch like this |
| G4 | Product recommendations (R8, important) | discovery | Underwriting audience is evidenced; product audience is not | The JD names product as a recipient of the recommendations | A price change taken to a product or commercial owner; a test result that changed a product feature or tier | A sanitized recommendation paper or deck | `[grounded]` your silence on product |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary absent from the posting as pasted | unknown | — | Pasted JD gives no compensation | It may be advertised elsewhere, or withheld until interview | `[inferred]` from the pasted JD's silence | What salary range is budgeted for this post? | unresolved |
| RR3 | Team and people scope unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may be a sole analyst or may expect leadership; you have not managed anyone | `[inferred]` from "own" with no team described, against your stated history | Does this post have direct reports now, or expect them within the first year, and who else is in pricing? | unresolved |
| RR4 | Recommendations without stated decision rights | unknown | — | "turn the results into recommendations for underwriting and product" | The role may advise while rate changes are decided elsewhere | `[inferred]` from the JD's verb "recommendations" and silence on sign-off | Who signs off a rate change, and what has the last recommendation from this seat led to? | unresolved |
| RR5 | Deliverables and reporting line are specific | positive_signal | — | "build and monitor rating models, design and read price tests" | The scope is concrete and the manager is named | `[grounded]` JD | What would success in the first year look like for this seat? | noted |

## Application plan

Everything below is proposed. Nothing is final until you explicitly approve it, and that covers the advice rows as well as the edits table.

`resume_edits_pending_approval` — each line below is your own sentence, reordered and nothing added. I haven't seen your CV, so compare each against it.

| # | Proposed line | Source clause | Provenance |
|---|---|---|---|
| E1 | Built and maintained the GLM rating model for the young-driver book | "Built and maintained the GLM rating model for our young-driver book" | `[grounded]` your background |
| E2 | Ran 14 price tests with the underwriting team last year (state the calendar year) | "Ran 14 price tests last year with the underwriting team" | `[grounded]` your background |
| E3 | Present the quarterly pricing review to the head of underwriting | "I present the quarterly pricing review to the head of underwriting" | `[grounded]` your background |

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Open with E1, E2 and E3, naming motor and the young-driver book | R4, R6a and R7 are your `direct` rows | `[grounded]` the rows | pending your approval |
| P2 | Say plainly that pet insurance is new to you, and offer the young-driver GLM as the adjacent work, with its limit | See R10 | `[inferred]` the bridge | pending your approval |
| P3 | If asked about managing people, say you haven't; check RR3 first to learn whether it matters | See RR3 | `[grounded]` your statement | pending your approval |
| P4 | Confirm the posting and employer on Brindlemoor's own careers site before spending effort | See RR1 | `[grounded]` RR1 | pending your approval |
| P5 | Ask the RR2, RR3, RR4 and RR5 questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` the register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst"; the call was refused because search permission was not granted. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "Senior Pricing Analyst insurance UK salary remote"; refused for the same reason. It would have moved the market calibration line and RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; refused for the same reason. It would have moved the scope read and which story P1 leads with for that reader |

I'll write the whole assessment into `tuesday-dossier.md` if you'd like a file to keep.

**Upgrade menu**

- Granting web search lets the three L1 targets above run. They would settle RR1, add a market band for RR2, and read Odile Varga's public professional footprint. A deeper pass on Brindlemoor (funding, leadership churn, recent news; up to 5 more searches and 2 more fetches) is also available on your say-so.
- Your CV document would let me check E1–E3 against your actual wording and find evidence it buries.
- A sanitized test readout or test plan would take R6a to `high` and settle R6b.
- Sanitized GLM model documentation or factor tables would take R4 and R5 to `high`.
- The quarterly pricing review deck, sanitized, would take R7 to `high` and bear on R8.
- Your salary floor and any other must-haves would add constraint rows, so the hard-gates line checks against them.

G2 — Are you based in the UK with the right to work there, so the "Fully remote (UK)" term is met?

G1 — On the 14 price tests, which parts did you personally own: choosing the segments, sizing the test, defining success measures, or deciding the rollout?

G4 — Have you taken a price-test result or model finding to a product or commercial owner, and what changed as a result?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.