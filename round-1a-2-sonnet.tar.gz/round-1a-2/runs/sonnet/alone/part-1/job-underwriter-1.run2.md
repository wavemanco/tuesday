I'll read the reference files the skill points to before building the assessment.
**Yes, apply. You're a fit on every must-have (R1, R2, R3, R4, R5, all `direct`), as long as the posting turns out to be real. Status: `conditional_go`.** The condition comes from the employer being unverified (RR1), not from your fit.

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — adjacent: R7a (Partner with product managers), R7b (Partner with clinicians) · unclear: R6 (Define and maintain the metrics layer), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA)

R3 (`medium`) — your strongest evidence, waiting on an artifact; R6, R8 — nothing confirmed yet, both answerable from your history; R7b, R9 — credible bridges with their limits named.

**Opportunity ledger.** The role's scope is concrete and names a team beneath it (RR3). The employer is unverified (RR1), pay, location and work arrangement aren't in the text you pasted (RR2), and whether a metrics layer exists yet is unstated (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the role verifies on Harborlight's own careers page (RR1); (2) pay and work arrangement are acceptable to you (RR2); (3) the healthcare bridge is framed as adjacent, never as HIPAA experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people, Series C | `[grounded]` JD header; not independently verified (see RR1) |
| Mandate | Own product analytics for the care-navigation app | `[grounded]` JD |
| Responsibilities | Metrics layer, A/B test design and analysis, self-serve Looker dashboards, partnering with product managers and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Scope read | A senior individual-contributor post with a mentoring remit. The JD says "mentor", not manage | `[inferred]` from the JD's verb choice and its silence on line management |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not available for this role (see Evidence status), so no band is offered and none is guessed | `[grounded]` role-family sweep did not return |
| Unknowns | Pay, location and remote policy, reporting line, whether a metrics layer already exists, experimentation volume, how clinicians take part | `[grounded]` JD silent on each |
| Contradictions | None visible inside the JD text; not cross-checked against a careers page | `[grounded]` JD text only |

## Evidence map

Your background was typed into the conversation, so it counts as self-report at intake. That is why `medium` is the ceiling here.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years of product analytics at a consumer-subscription company, confirmed and specific. Years of experience is not a gate; no inspectable artifact yet | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake across six years. "Expert" is a level, and the level is unprobed, so expect a live SQL exercise | `[grounded]` your background; `[generic]` that analyst loops usually test SQL live | Optional: a sanitized query or model sample |
| R3 | Experiment design at scale | must_have | direct | medium | none | Designed and ran the program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift, at about 2M subscribers. Expect a probe on what was yours versus the team's | `[grounded]` your background | A sanitized readout of the pricing test would raise to high |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | Built the company's Looker instance from scratch, 40+ governed dashboards. Looker is named in the JD, so this is the same tool | `[grounded]` your background | A dashboard-inventory screenshot or export would raise to high |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | Writes the monthly metrics memo the exec team reads and presents monthly to the VP Product | `[grounded]` your background | A sanitized memo would raise to high |
| R6 | Define and maintain the metrics layer | important | unclear | low | discovery | The 40+ governed dashboards and the warehouse consent-state model suggest metric definitions work, but you didn't say who defined and maintained the metrics | `[inferred]` from the dashboards and consent model, derivation named; `[grounded]` your message is silent on metric ownership | G1 |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | adjacent | medium | discovery | Monthly VP Product presentations and a pricing test that moved retention are close. Day-to-day work with product managers, and roadmap changes that followed, weren't stated, so this takes the lower reading | `[grounded]` your background | G3 |
| R7b | Partner with clinicians | important | adjacent | medium | transferability | Cross-functional partnership with product leadership carries over. Limit: you haven't worked with clinical experts or in a clinical setting | `[grounded]` your background; `[generic]` that clinical stakeholders usually are not analytics-literate in the same way | G4 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Nothing in your background mentions mentoring or managing anyone | `[grounded]` background silent | G2 |
| R9 | Healthcare data experience (HIPAA) — a plus | preferred | adjacent | medium | transferability | You've handled GDPR/CCPA consumer PII and built the warehouse consent-state model. Limit: no healthcare work, and GDPR/CCPA are different regimes from HIPAA | `[grounded]` your background | G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, important) | discovery | Governed dashboards and a consent-state model, but no statement of who defined the metrics | The JD lists it first among responsibilities; an answer could lift R6 to `direct` | Writing LookML or equivalent definitions; owning a metric dictionary; settling a disputed KPI definition between teams | A metric dictionary page, a LookML excerpt, a definitions doc | `[grounded]` your message silent on ownership; `[inferred]` that it matters because the JD names it first |
| G2 | Mentoring (R8, important) | discovery | No mention of mentoring | The JD names two juniors, so some probe is likely | Onboarding a new analyst; reviewing others' queries or dashboards; informal coaching | A onboarding doc, review checklist, or a note from a mentee | `[grounded]` background silent; `[generic]` that a named team makes mentoring a likely interview topic |
| G3 | PM partnership (R7a, important) | discovery | A monthly VP Product presentation and one pricing test, but no named roadmap decision | Roadmap influence is the stated purpose of the analysis | A feature, pricing or retention decision that changed because of your analysis | A decision memo, roadmap change, or readout | `[grounded]` background; `[inferred]` that decisions exist beyond the pricing test |
| G4 | Clinician partnership (R7b, important) | transferability | Product-leadership partnership; no clinical stakeholders | The JD names clinicians as partners; you'd need to explain how you work with domain experts | Working with domain specialists (nutrition, culinary, food safety) to turn their questions into analysis | A sanitized example of analysis shaped by a domain expert | `[inferred]` bridge via domain-expert partnership, which you haven't confirmed |
| G5 | Healthcare/HIPAA (R9, preferred) | transferability | GDPR/CCPA PII handling and consent-state modelling, no healthcare | A "plus", so a minor risk, but it's the most visible difference from your history | The consent-state model's design, access controls, data minimization or audit work | A sanitized data-model diagram or consent-state spec | `[grounded]` your background; `[generic]` that GDPR/CCPA and HIPAA differ in scope and rules |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay, location and work arrangement not in the pasted posting | unknown | — | No compensation, location or work-arrangement line in the pasted text | The terms may be in the full posting or may be withheld | `[inferred]` from silence in the pasted text | What is the salary range, and is the role remote, hybrid or on-site? | unresolved |
| RR3 | Concrete scope with a named team | positive_signal | — | "mentor two junior analysts" | The role has defined responsibilities and an existing team beneath it | `[grounded]` JD states the team and the responsibilities | Who do the two junior analysts, and this role, report to? | noted |
| RR4 | Metrics-layer starting point unstated | unknown | — | "define and maintain the metrics layer" | The role may be inheriting a layer or building one from scratch | `[inferred]` from "define and maintain" against the JD's silence on current state | Does a metrics layer exist today, in what tooling, and is this role building it or inheriting it? | unresolved |

## Application plan

Everything below is proposed, the edits and the advice alike, and nothing is final until you approve it. Rows P1–P3 are `resume_edits_pending_approval` and use your own sentences as written.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with your own line: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift." | R3 | `[grounded]` your message | pending your approval |
| P2 | Looker line: "Built the company's Looker instance from scratch — 40+ governed dashboards." | R4 | `[grounded]` your message | pending your approval |
| P3 | Communication line: "Write the monthly metrics memo the exec team reads and present to the VP Product monthly." | R5, R7a | `[grounded]` your message | pending your approval |
| P4 | In the cover note, state the gap first, then the bridge: "I haven't worked in healthcare; I've handled GDPR/CCPA consumer PII and built the consent-state model for our warehouse." Don't describe it as HIPAA experience | R9 | `[grounded]` your message, limit named | pending your approval |
| P5 | Check the role on Harborlight's own careers page before investing in a tailored application | RR1 | `[grounded]` RR1 | pending your approval |
| P6 | Prepare for a live SQL exercise and an experiment-design walkthrough, with the pricing test ready and a clear account of what was yours versus the team's | R2, R3 | `[generic]` role-family pattern | pending your approval |
| P7 | In the first recruiter call, ask the verification questions of RR2 and RR4 verbatim | register | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers Senior Product Analyst"; the call was refused. It would have fed role reality's organization and contradictions rows and settled RR1 |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range scope experimentation Looker"; the call was refused. It would have fed the market calibration row and the pay check behind RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

I can write this up as a `tuesday-dossier.md` you can keep and update, if you'd like.

## Upgrade menu

- The live posting link, the careers page, or the recruiter's email domain → RR1 closes, and the decision likely moves toward `go`.
- Pay range, location or remote policy, and your own floor and non-negotiables → hard-gate rows are built and checked, and RR2 closes.
- A sanitized pricing-test readout → R3 to `high`; a sanitized metrics memo → R5 to `high`; a Looker dashboard inventory → R4 to `high`.
- Answers to G1–G5 → R6, R8, R7a, R7b and R9 firm up.
- Search access → role reality's market calibration, the careers-page check, and a pay band for RR2. A deeper pass on top (funding, leadership churn, candidate reports, recent news; up to 5 more searches and 2 more fetches) is also available on request.
- The hiring manager's name → role reality's scope read and which story the plan leads with for that reader.

## Questions

1. **RR1 —** Can you share the link to the live posting, or the email domain the recruiter wrote from?
2. **Constraints —** What are your must-haves on pay floor, location or remote policy, and work authorization, if any?
3. **G1 —** Did you personally define or maintain the metrics behind your dashboards (for example, in LookML or a metric dictionary), and what was yours versus another team's?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.