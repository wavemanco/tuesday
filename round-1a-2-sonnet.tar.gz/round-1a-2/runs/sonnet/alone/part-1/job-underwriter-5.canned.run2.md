Checking the posting and company page are live and match what you pasted, then I'll write up the assessment.
**Worth applying to — yes, on conditions. Status: `conditional_go`. R1 and R2, the location and pay gates, are still unconfirmed against what you need.**

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (BigQuery-modelled warehouse); unclear: R10 (Ingestion from app and CRM), R11 (Data contracts for analysts)

R9 — a credible bridge via dbt on Snowflake, its BigQuery limit named; R10, R11 — the JD's ingestion and contracts work, which your background doesn't yet speak to.

**Opportunity ledger.** Reading RR1–RR5: one positive signal, the stated pay (RR1). Four unknowns: team and scope (RR2), equity terms (RR3), manager and first-year outcomes (RR4), and funding and headcount (RR5). No risk signal or red flag was entered.

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location, work authorization and pay floor are checked against R1 and R2; (2) the BigQuery bridge (R9) is always framed as adjacent, never as BigQuery experience; (3) RR2 and RR4 get answered before you invest in a long interview loop.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the company's about page, fetched via search result; funding not corroborated outside the company's own pages (RR5) |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` posting, fetched |
| Stated requirements | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` posting |
| Terms | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` posting |
| Scope read | The mandate spans ingestion, warehouse, contracts and operations, and the posting states no team size | `[inferred]` from the mandate's four parts against the posting's silence on team |
| Market calibration | Datawright 2026, Series B–D Senior Data Engineers: base median $151,000, IQR $139,000–$163,500, "Senior" typically 5–8 years, typical scope one domain's pipelines with no direct reports. The posted range starts $3,000 under that median and tops the 75th percentile by $2,500. Your 6 years sits inside the report's typical seniority span | `[grounded]` figures from the report you supplied; `[inferred]` the comparison to this posting; `[generic]` the report describes role-family norms, not this employer's pay |
| First-90-days and first-year outcomes | Not stated | `[grounded]` posting silent |
| Contradictions | None between the pasted text and the live careers page, which shows "Accepting applications" | `[grounded]` careers page fetched |

## Evidence map

Your background was given in prose, so it has CV-equivalent standing and tops out at `medium` until something inspectable is seen.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You gave no location or work-authorization constraint, so the term is unsettled. Confidence grades your statement of a constraint, and none exists yet | `[grounded]` no constraint given | G1's question |
| R2 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | You gave no pay floor, so whether the range meets it is unknown. The range's place in the market is RR1's, not this row's | `[grounded]` no floor given | G1's question |
| R3 | 5+ years data engineering | must_have | direct | medium | none | "6 years of data engineering at a B2B payroll company": self-reported, specific, nothing inspectable seen. A years requirement is not a gate | `[grounded]` your background | A resume or LinkedIn history would let me inspect it |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily": daily use is stated; "strong" is the JD's word and you didn't claim it. Taking the lower reading | `[grounded]` your background | A code sample or repo excerpt would raise it |
| R5 | dbt | must_have | direct | medium | none | "Built our dbt project … about 180 models": "our" carries that it was a team project, and your share of it is not yet stated | `[grounded]` your background | An exported sanitized docs or lineage page would raise it |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is the warehouse you used; the posting asks for "a cloud warehouse", not BigQuery here (BigQuery is R9) | `[grounded]` your background and the posting's wording | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | "Airflow for orchestration": the tool is stated; what you personally built in it is not | `[grounded]` your background | State your own part when you next describe it |
| R8 | Data quality testing | must_have | direct | medium | none | "I set up our Great Expectations test suite": a first-person claim, the suite's coverage unstated | `[grounded]` your background | A sanitized suite config would raise it |
| R9 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Adjacent: the same dbt modelling discipline on Snowflake. Limit: you have never used BigQuery, so its specifics are untested by you. Medium because the Snowflake work is confirmed but uninspected. Hiring teams often weigh warehouse-specific familiarity less than modelling skill, but this is a pattern, not a statement about this team | `[grounded]` "Never used BigQuery" and the dbt work; `[generic]` how warehouse-specific familiarity is usually weighed | G2 |
| R10 | Ingestion from the app and CRM | important | unclear | none | discovery | Nothing you've said says what your sources were, or whether any were product events or a CRM | `[grounded]` background silent on sources | G3's question |
| R11 | Data contracts the analysts depend on | important | unclear | none | discovery | Nothing you've said speaks to agreed schemas or expectations between producers and analysts. Your dbt and Great Expectations work is nearby, but I won't assume it covers this | `[grounded]` background silent | G4's question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location, work authorization and pay (R1, R2; hard_gate) | hard_gate | No constraints given, so neither gate can be called met | An unsettled gate caps the status at `conditional_go`; a failed one would make it `no_go` | Nothing in experience settles a gate; only your own constraints do | Your own statement of your constraints | `[grounded]` no constraints in your message; `[inferred]` the decision effect |
| G2 | BigQuery warehouse (R9, important) | transferability | Confirmed dbt on Snowflake, about 180 models; no BigQuery use | The posting names BigQuery as the warehouse, so it is the likeliest "have you used it?" probe | Warehouse cost or performance tuning you did in Snowflake; a small dbt project you run against BigQuery | A small public repo or a sanitized write-up | `[inferred]` bridge from your Snowflake and dbt work; `[generic]` that a named tool draws a probe |
| G3 | App and CRM ingestion (R10, important) | discovery | Airflow stated; the sources it fed are not | Ingestion is the first item in the mandate, and resolving it could move R10 off `unclear` | Loading from a CRM or SaaS API; app event or application-database feeds; replacing a manual or file-based feed | A sanitized DAG excerpt or a source-system diagram | `[grounded]` background silent on sources; `[inferred]` that ingestion leads the mandate |
| G4 | Data contracts (R11, important) | discovery | dbt and Great Expectations in hand; nothing on agreements with producers or analysts | A named JD responsibility, and one a payroll-data background may or may not have touched | Agreed schemas with upstream teams; documented, tested expectations on models analysts query; a schema-change process | A sanitized schema file with its tests, or a change policy | `[grounded]` background silent; `[inferred]` that your tests are nearby, not a match |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and inside the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is transparent and realistic for the level | `[grounded]` posting figures and the Datawright figures you supplied; `[inferred]` the comparison; `[generic]` the report's band is not this employer's history | Where in the range would someone with six years' experience land, and what decides it? | noted |
| RR2 | Team and scope unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting: ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The role may be several jobs in one, perhaps as the sole data engineer, which is broader than the one-domain scope the report calls typical | `[inferred]` the mandate's four parts against the posting's silence on team; `[grounded]` the report's typical scope | How many data engineers are on the team, who owns ingestion, the warehouse and the contracts today, and what is the on-call expectation for "run"? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | The grant could be material or nominal; the posting does not say | `[grounded]` posting names no terms | What is the equity grant, its vesting schedule, and its share of fully diluted shares? | unresolved |
| RR4 | No manager or first-year outcomes | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The posting states a mandate and no definition of success | `[grounded]` posting and your note: no manager, no outcomes | Who would I report to, and what does success look like at 90 days and at one year? | unresolved |
| RR5 | Funding and headcount seen only on the company's own pages | unknown | — | "Series C ($52M, February 2026)" | The raise may fund this as new headcount or a backfill; I found no source outside the company's own pages | `[grounded]` the about page; `[inferred]` from one search returning only that page | Is this a new role or a backfill, and what data hiring does the raise fund? | unresolved |

## Application plan

Resume edits, proposed as `resume_edits_pending_approval`. These reorder and rename; none adds a fact beyond what you told me.

| # | Current (your words) | Proposed | Provenance | Status |
|---|---|---|---|---|
| E1 | "Built our dbt project on Snowflake — about 180 models" | Lead the experience section with: "Built our dbt project on Snowflake (about 180 models)" | `[grounded]` your sentence, wording kept | resume_edits_pending_approval |
| E2 | "I set up our Great Expectations test suite" | Place directly under E1: "Set up our Great Expectations test suite" | `[grounded]` your sentence, wording kept | resume_edits_pending_approval |
| E3 | "Airflow for orchestration" | Keep as "Airflow for orchestration" until you tell me what you built in it, then state that part | `[grounded]` your sentence | resume_edits_pending_approval |

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check your location, work authorization and pay floor against R1 and R2 before applying | Unsettled gates are the only things that could stop this | `[grounded]` R1, R2 | pending your approval |
| A2 | In a cover note or screen, say: "My warehouse experience is Snowflake with dbt; I haven't used BigQuery yet." | Names the R9 limit before a probe does | `[grounded]` your "never used BigQuery" | pending your approval |
| A3 | Ask RR2, RR3, RR4 and RR5's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | Optional: a small public dbt project run against BigQuery | Narrows R9's stated limit with something inspectable | `[inferred]` from R9's transferability gap | pending your approval |

Offer, beyond the standard assessment: a short plan for the BigQuery project in A4. The engagement earns it because R9 is the one named adjacent gap. I'd build it only on your approval.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning Series C $52M tutoring Denver", which returned "About Pellucid Learning" (pellucidlearning.com/about); fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). The posting is live ("Accepting applications") and matches your paste. The about page matches too. No failed-attribution entry. Both are the company's own pages, so the funding claim stays unconfirmed outside them (RR5) |
| 2. Role-family sweep | skipped | The Datawright figures you pasted fix the market calibration row and RR1, so a sweep could change neither |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

## Dossier offer and upgrade menu

I can write all of this to `tuesday-dossier.md` if you want it kept.

- Your CV, or a sanitized dbt docs page, Great Expectations config or DAG excerpt → R3–R8 can move from `medium` toward `high`.
- Your location, work authorization and pay floor → R1 and R2 close, and the decision becomes `go` or `no_go`.
- The recruiter's answers on team size, backfill and equity → RR2, RR3 and RR5 close.
- The hiring manager's name → role reality's scope read, and who the application plan is written to.
- A deeper research pass on Pellucid (funding corroboration, leadership changes, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

- **G1 (R1, R2):** What are your non-negotiables on location, work authorization and pay for a move to this role?
- **G4 (R11):** Have you ever owned an agreed schema or set of expectations between a data producer and the analysts or teams consuming your models? What did you own, who was involved, and what happened?
- **G3 (R10):** What were the source systems your Airflow pipelines loaded from (a CRM, product events, an application database, files), and which did you build yourself?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.