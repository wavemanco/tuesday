Loading is done. I'm now running the research the skill asks for by default. That means checking whether Quartzline exists as described, and getting a market band for API platform PM roles.
**Not wasting your time, but treat this as a stretch application, not a match. R1b (3+ years in a PM role, a title you haven't held) is absent. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1a (3+ years PM, adjacent work), R2 (shipped API or platform products) · unclear: R4b (stakeholders in sales) · absent: R1b (3+ years in a PM role, titled)
- `important` — adjacent: R6 (discovery with partners), R7 (specs, driving delivery), R9 (own the roadmap), R10 (launches with sales and support) · unclear: R5 (agile delivery), R8 (adoption metrics)

R1b — a real gap, named; R1a and R2 — credible bridges, limits named; R8 (`low`) — a memory lead waiting on your confirmation.

**Opportunity ledger.** The scope is concrete and success is measurable (RR4). The employer is not established from this session's sources (RR1), compensation is withheld (RR2), and the role's decision rights are unstated (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Quartzline and the live posting verify (RR1); (2) the internal triage tool in R8 is confirmed and you can show an artifact; (3) you apply through a person, not only the portal, because R1b is a literal must-have.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; existence not checked |
| Mandate | Own the roadmap of a partner-facing API platform, with two engineering squads | `[grounded]` JD |
| Stated duties | Partner discovery, specs, delivery, adoption metrics, launches with sales and support | `[grounded]` JD |
| Scope read | A single-product-area PM role. It mixes partner-facing discovery with delivery ownership, and no authority limits are stated | `[inferred]` from the JD's duties list and its silence on decision rights |
| Market calibration | Not run. Search access was not granted, so no band is offered and none is made up | — |
| First 90 days / first year | Not stated | `[grounded]` JD silent |
| Unknowns | Compensation; level (junior/mid/senior); who the role reports to; whether "3+ years" is screened literally | `[grounded]` JD silent on each |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years PM experience: the work, apart from the title | must_have | adjacent | medium | transferability | You wrote requirements documents, ran quarterly sessions collecting client feedback for product, and coordinated engineers and PMs on custom builds. Limit: that was input to product decisions, not ownership of them. Confirmed prose, nothing inspectable yet | `[grounded]` your stated background | G1 may add stronger evidence; the playbook or a sanitized requirements doc would raise this |
| R1b | 3+ years PM experience: the titled years | must_have | absent | none | capability | "I have never held a PM title." The JD marks this must-have. A years requirement is not a legal gate, but a screen may read it literally | `[grounded]` your statement; `[generic]` that screens often apply it literally | Closure paths in the plan (A2). No question |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your employer's REST APIs. That is deep use of an API product from the delivery side. Limit: you did not say you owned the API's roadmap or release | `[grounded]` your stated background | G1 (triage tool) and any input you gave the API's product team |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI reading, plus integration architecture work on 30+ integrations. Confirmed and specific; no inspectable artifact | `[grounded]` your stated background | none |
| R4a | Stakeholder management with engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and PMs, and ran client workshops, UAT and go-live | `[grounded]` your stated background | none |
| R4b | Stakeholder management with sales | must_have | unclear | low | discovery | Your background does not mention sales | `[grounded]` your background's silence | G2 |
| R5 | Agile delivery | important | unclear | low | discovery | Your background mentions UAT and go-live but not sprints, backlogs or squad ceremonies | `[grounded]` your background's silence | Ask in a later turn |
| R6 | Discovery with integration partners | important | adjacent | medium | presentation | Scoping workshops and quarterly client-feedback sessions are discovery work. Limit: your counterparts were enterprise clients, not partner developers building on a platform. The framing is solutions-side, not product discovery | `[grounded]` your stated background | Reposition (edit E2) |
| R7 | Write specs, drive delivery with engineering squads | important | adjacent | medium | transferability | Requirements documents and coordination with engineers are close. Limit: you drove client delivery, not a product squad's backlog | `[grounded]` your stated background | G1 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | The only lead is a recalled mention of an internal request-triage tool that support agents adopted. It is unconfirmed, so it can only prompt a question | `[inferred]` from a `memory_lead`, not yet confirmed | G1 |
| R9 | Own the roadmap | important | adjacent | medium | transferability | You ran roadmap-input sessions for product. Limit: input, not decision rights | `[grounded]` your stated background | Keep the "input" wording (E2) |
| R10 | Coordinate launches with sales and support | important | adjacent | medium | transferability | You led go-lives for client integrations. Limit: those were client go-lives, not product launches, and support or sales were not named | `[grounded]` your stated background | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product ownership evidence (R8, R2, R7) | discovery | A prior-context mention of an internal triage tool that support agents adopted; no detail confirmed | It could be your closest evidence of defining a need, shipping something and measuring adoption. That is the evidence R1a, R2, R7 and R8 all lack | Deciding what the tool did; writing its requirements; working with whoever built it; tracking whether agents used it | A one-page spec, usage numbers, a screenshot, a rollout note | `[grounded]` the lead is unconfirmed; `[inferred]` it could lift several rows |
| G2 | Sales and launch work (R4b, R10) | discovery | No mention of sales or support involvement in go-lives | R4b is a must-have still unclear | Joint calls with account executives; handing a customer to support after go-live; writing launch or release notes | A handoff doc or runbook from the playbook | `[grounded]` your background's silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too small for a clear footprint, the posting may be stale, or it may not represent a real hiring employer. Here it also means no check was run | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your careers site, and who would I interview with? | unresolved |
| RR2 | Compensation not stated | unknown | — | no figure in the JD | The posting withholds pay, so I can't tell whether it fits your needs | `[inferred]` from the JD's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Decision rights unstated | unknown | — | "Own the roadmap … drive delivery with two engineering squads" | The role may be accountable for outcomes without final say on priorities | `[inferred]` from the scope language against its silence on authority | Who sets squad priorities, and which roadmap decisions does this role make alone? | unresolved |
| RR4 | Clear scope and named metrics | positive_signal | — | "define and track adoption metrics" | The mandate looks defined and measurable | `[grounded]` JD | How is adoption measured today? | noted |

## Application plan

All rows are proposed and wait on your approval; none is final.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify Quartzline and the live posting before spending effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Apply, and in parallel look for hybrid roles (technical PM, API product owner, solutions-to-product moves) where "3+ years PM" is not literal, including an internal move at your current employer | see R1b | `[generic]` common pivot paths; not a claim about Quartzline | pending your approval |
| A3 | Try for a referral or a direct message to the hiring team rather than the portal alone | see R1b | `[generic]` role-family hiring pattern | pending your approval |
| A4 | Ask RR2 and RR3 verbatim at the first screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |

`resume_edits_pending_approval`

| # | Current | Proposed | Traces to | Status |
|---|---|---|---|---|
| E1 | Led 30+ client integrations of REST APIs end to end | Keep as is, and lead with it | your own sentence | pending your approval |
| E2 | Ran quarterly roadmap-input sessions collecting client feedback for product | Ran quarterly sessions collecting client feedback as roadmap input for product | your own sentence, reworded only for order; "input" kept on purpose | pending your approval |
| E3 | (triage tool) | Nothing proposed until G1 is confirmed | memory lead, unconfirmed | on hold |

## Evidence status

Verified: none yet. Unverified leads: a prior-context mention of an internal request-triage tool that support agents adopted; details unconfirmed.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused for permission: "Quartzline logistics technology Series B partner API platform" and "Quartzline careers Product Manager Platform APIs". They would have settled RR1 and whether the posting is live |
| 2. Role-family sweep | unavailable | One search, "platform API product manager salary requirements career transition from solutions engineer", was refused for permission. It would have set a pay band for RR2 and shown how often similar roles flex on titled years |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

The dossier is available as `tuesday-dossier.md` whenever you want it.

**Upgrade menu**
- A link to the live Quartzline posting or their careers page → closes RR1.
- The stated salary range → closes RR2.
- The hiring manager's name → sharpens the scope read and what to lead with.
- Search access granted → I can rerun targets 1 and 2 for a market band and a company check.
- A spec, screenshot or usage numbers for the triage tool → lifts R8 and may lift R2 and R7.
- Your full resume with titles and dates → lets me check how presentable R1a and R6 are.

**Questions**
1. G1 — Did you personally decide what the triage tool should do, did it reach real users, and how did you know support agents adopted it? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. G2 — On your go-lives, did you work with sales or support teams, and what did you hand over or launch together? Same response modes.
3. Constraints — Do you have a pay floor, location or remote requirement, or timing limit? Same response modes.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.