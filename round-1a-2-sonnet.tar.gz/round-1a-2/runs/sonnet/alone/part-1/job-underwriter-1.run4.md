I'll read the reference files the skill points to before building the assessment.
Yes, apply. You're a fit on the core of this role, with a few things to firm up first. R1, R2, R3, R4 and R8 land `direct`. The conditions turn on R5, R7 and a check that Harborlight is real (RR1). Status: `conditional_go`.

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R8 · adjacent: R5 (metrics layer)
- `important` — adjacent: R6a (partner with product managers) · unclear: R6b (partner with clinicians), R7 (mentor two junior analysts)
- `preferred` — adjacent: R9a (HIPAA) · absent: R9b (healthcare data experience)

R5 (`low`) — the bridge to a metrics layer is inferred from governed dashboards, not stated; R7 (`none`) — no mentoring evidence in what you gave me; R9a — privacy handling carries over, its limit named.

**Opportunity ledger.** Plausible but thin on detail. The employer is unverified from here (RR1), pay is not stated (RR2), the stack of responsibilities may outrun the support behind it (RR3), and success measures are not stated (RR4). One entry runs the other way: a named team of two juniors to mentor (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting verifies as live on Harborlight's own careers page (RR1); (2) R5 firms up from `low` if you have owned metric definitions (G1); (3) R7 gets a truthful example or is carried as a minor risk (G2); (4) your pay, location and authorization constraints are checked against the role.
- **What would change this:** a constraint of yours that the role fails would move it to `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C, care-navigation app | `[grounded]` JD header; not checked against any outside source |
| Mandate | Own product analytics for the app: metrics layer, A/B tests, self-serve Looker dashboards, partnering with product managers and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Stated requirements | 5+ years product analytics, expert SQL, experiment design at scale, Looker or similar, strong written communication with non-technical stakeholders; healthcare data (HIPAA) a plus | `[grounded]` JD |
| First-year outcomes | Not stated in the JD | `[grounded]` JD silence |
| Compensation | Not stated in the pasted JD; your floor is not known | `[grounded]` JD text provided |
| Scope read | A broad senior mandate that spans analytics engineering, experimentation, BI and mentoring | `[inferred]` from the JD's responsibility list |
| Market calibration | Not done. The role-family sweep did not run, so no band is offered | `[generic]` no search result in hand |
| Unknowns | Who the role reports to; what data-engineering support exists; who owns metric definitions today; pay | `[grounded]` JD silence |
| Contradictions | None visible inside the pasted JD; not compared against the careers page | `[grounded]` JD text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a consumer-subscription company (meal-kit delivery, ~2M subscribers). It is intake prose with nothing inspectable yet, so `medium`. | `[grounded]` your background text | none |
| R2 | Expert SQL | must_have | direct | medium | none | "SQL daily on a Snowflake warehouse" across those years. "Expert" is a level your text implies rather than states. An interviewer will likely test depth live. | `[grounded]` your background text; `[generic]` that a SQL-heavy analyst role usually tests live | A sanitized query or model sample would raise it to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift. Whether 11% is relative or in points, over what window, and the statistical methods are not stated. | `[grounded]` your background text | A sanitized readout of the pricing test would raise it to `high`; confirm the 11% basis |
| R4 | Looker or similar BI, self-serve dashboards | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards. How much of it was self-serve use by others is not stated. | `[grounded]` your background text | A dashboard screenshot or LookML excerpt, sanitized, would raise it to `high` |
| R5 | Define and maintain the metrics layer | must_have | adjacent | low | discovery | A governed Looker instance you built plausibly involved shared definitions, but you did not say you defined or maintained a metrics layer. Between `medium` and `low`, the lower band applies. | `[inferred]` from the Looker build against your silence on metric definitions | G1 |
| R6a | Partner with product managers to turn analysis into roadmap decisions | important | adjacent | medium | discovery | Confirmed: you present monthly to the VP Product and write the exec-read metrics memo. Working with product managers, and analyses changing roadmap decisions, are not stated. | `[grounded]` your background text | G4 |
| R6b | Partner with clinicians | important | unclear | none | discovery | Nothing in your text touches working with domain specialists, clinical or otherwise. | `[grounded]` silence in your background text | G4 |
| R7 | Mentor two junior analysts | important | unclear | none | discovery | Mentoring or managing is not mentioned. A summary's silence is not evidence it didn't happen. | `[grounded]` silence in your background text | G2 |
| R8 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present monthly to the VP Product. | `[grounded]` your background text | A redacted memo would raise it to `high` |
| R9a | Healthcare data (HIPAA): regulated-data handling | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the consent-state model for your warehouse. The limit: no healthcare data and no HIPAA work. Health-data rules are usually a separate regime from consumer privacy law. | `[grounded]` your background text; `[generic]` on regime differences | G3 |
| R9b | Healthcare data (HIPAA): healthcare domain experience | preferred | absent | none | capability | You state you have never worked in healthcare. The JD calls this a plus, so it is a minor risk, not a blocker. | `[grounded]` your own statement; `[grounded]` JD "a plus" | Learn the care-navigation metric vocabulary before interviews; carry as a minor risk |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R5, must_have) | discovery | A Looker instance with governed dashboards; no statement that you defined or maintained metric definitions | The JD lists the metrics layer first among its responsibilities, and resolving it could move R5 up from `low` | Writing LookML measures others reused; keeping a metric dictionary; settling what "retention" or "active subscriber" means; owning a definition change and its fallout | A sanitized LookML excerpt, metric dictionary, or definitions doc | `[grounded]` your silence on definitions; `[inferred]` that the JD's ordering signals its weight |
| G2 | Mentoring (R7, important) | discovery | No mentoring mentioned | The JD names two junior analysts, so a reviewer will look for it | Onboarding an analyst; reviewing their SQL or readouts; coaching a junior through a first experiment | A shared review doc, an onboarding guide, or a peer's name as a reference | `[grounded]` JD names the juniors; `[generic]` that such roles look for this |
| G3 | Healthcare data (R9a, R9b, preferred) | transferability | Adjacent: consent-state model and consumer PII handling. Limit: no healthcare or HIPAA work. Strengthener: a short note on how the consent model handled access and deletion | A preferred row; naming the limit upfront reads better than letting it surface | Access controls, audit trails, or data-retention rules you designed | A sanitized consent-state model description | `[grounded]` your background text; `[generic]` on how privacy work is read in health roles |
| G4 | PM and clinician partnership (R6a, R6b, important) | discovery | Monthly VP Product presentation; nothing on PMs or domain specialists | The JD frames the job as turning analysis into roadmap decisions | A test result that changed a roadmap call; working with nutrition, ops, or culinary specialists | A decision log, a roadmap doc, or a test readout showing the outcome | `[grounded]` your background text; `[inferred]` from the JD's wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small for a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. No check ran, so this is unresolved, not found false. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | The pasted JD gives no pay figure | The figure may be published elsewhere or withheld; your floor is not known either | `[grounded]` JD text as provided | What salary range is budgeted for this role? | unresolved |
| RR3 | Bundled responsibilities | risk_signal | low | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker … mentor two junior analysts" | Analytics engineering, experimentation, BI and mentoring are folded into one role, possibly without matching support | `[inferred]` from the JD's responsibility list against its silence on data-engineering support | What data-engineering support sits behind the metrics layer, and who owns it today? | unresolved |
| RR4 | Success measures not stated | unknown | — | "turn analysis into roadmap decisions" | A demanding mandate without a stated definition of success | `[inferred]` from the JD's silence on first-year outcomes | What would a strong first six months look like? | unresolved |
| RR5 | Mentoring scope is concrete | positive_signal | — | "mentor two junior analysts" | The team shape is named, which suggests the role's reach is defined | `[grounded]` JD | Who are the two juniors, and what are they working on now? | noted |

## Application plan

Everything in this table is proposed. Nothing is final until you approve it, and the resume lines use your own wording.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume line: "Built the company's Looker instance from scratch: 40+ governed dashboards." | See R4 | `[grounded]` your background text | resume_edits_pending_approval |
| E2 | Resume line: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift." Add the basis of the 11% once you confirm it. | See R3 | `[grounded]` your background text | resume_edits_pending_approval |
| E3 | Resume line: "Write the monthly metrics memo the exec team reads; present to the VP Product monthly." | See R8, R6a | `[grounded]` your background text | resume_edits_pending_approval |
| E4 | Resume line: "Built the consent-state model for our warehouse; handled GDPR/CCPA consumer PII." Say in the cover note that you have not worked with health data. | See R9a, R9b | `[grounded]` your background text and your own statement | resume_edits_pending_approval |
| A1 | Confirm the posting is live on Harborlight's own careers page before investing effort | See RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Hold any metrics-layer claim off the resume until G1 is answered | See R5 | `[grounded]` R5 row | pending your approval |
| A3 | Ask RR2, RR3 and RR4 verbatim in the recruiter screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers Senior Product Analyst"; the call was refused (permission not granted). It would have moved RR1 and role reality's contradictions row |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range Looker experimentation"; the call was refused (permission not granted). It would have moved the market calibration row and a pay-mismatch check on RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can write all of this up as `tuesday-dossier.md` if you'd like to keep it. Say the word.

## Upgrade menu

- Search permission, or a link to Harborlight's own careers page or the live posting → RR1 can close, and the market-calibration row and RR2's pay check can run.
- Your pay floor, location pattern and work authorization → the hard-gates line stops reading "checks unknown" and shows real checks.
- A sanitized LookML excerpt or metric dictionary → R5 moves up from `low`.
- A sanitized readout of the pricing test, including how the 11% was measured → R3 to `high`.
- A redacted monthly metrics memo → R8 to `high`.
- A mentoring example → R7 moves up from `none`.
- The hiring manager's name → role reality's scope read and which story to lead with for that reader.

G1 — Have you personally defined or maintained shared metric definitions, such as LookML measures, a metrics dictionary, or an agreed definition of "retention"? What did you own, who else relied on them, and what happened when one changed?

G2 — Have you mentored, onboarded, or reviewed the work of more junior analysts, formally or informally? Who, for how long, and what changed for them?

Hard gates — What are your non-negotiables for this role: a pay floor, a location or remote pattern, and work authorization for where Harborlight hires?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.