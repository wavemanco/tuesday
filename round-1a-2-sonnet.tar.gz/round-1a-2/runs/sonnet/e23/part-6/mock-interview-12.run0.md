**Please don't treat this as a real interview invitation. The email has the hallmarks of a fake-cheque job scam, so I haven't built a prep pack for it.**

**Why it looks like a scam**
- **Upfront fee:** A real employer never asks you to pay €95 to get an interview slot. The "equipment registration fee" is a way to get money from you.
- **Passport and bank details before an interview:** This is identity-theft material. No legitimate employer needs it until after a written offer, and then only for right-to-work checks and payroll.
- **The €1,850 cheque:** This is the core of the scam. They send a cheque, you deposit it, and you send "the balance" to the vendor. Days later the cheque bounces. The money you sent is gone, and your bank holds you responsible for it.
- **The interview:** It's only a 30-minute video call, yet the email asks for far more than that. The setup gets you to pay and hand over documents before anyone has assessed you.
- **The details that don't add up:** The pay-the-supplier account, the "approved vendor" and the "supplier invoice" processing are all part of the script. The ad also described a normal admin job, which makes the email's extra requests stand out.

**What to do now**
1. **Don't send money, your passport, bank details, or a receipt.** Don't deposit any cheque they send.
2. **Check the company independently.** Look up Brennock Facilities Ltd on the Companies Registration Office (cro.ie) and find a phone number from a source other than this email. Be suspicious of any reply that comes only from a `.example` or free-mail address.
3. **If you've already sent anything:**
   - If you paid, call your bank right away and ask whether the payment can be recalled.
   - If you sent your passport, contact the Passport Service and watch for identity-fraud signs.
   - Report it to An Garda Síochána and keep the emails.
4. **Report the job ad** to the site where you found it.

**How I can still help**
Your background is a good fit for real admin roles. You ran an appointment book for four physios and chased unpaid invoices, and you're good with Word and okay with Excel. I can build a full prep pack for a genuine interview. It would cover likely questions on calendars, travel, invoices and Excel, ways to present your clinic experience, and questions to ask the employer.

To do that I'd need:
1. A real role and company, ideally with the job ad.
2. Whether you've had an interview invitation from a verified employer, and who you'd be speaking with.
3. Whether you want me to treat your Excel level as a gap to prepare for. If so, tell me what you've actually done in Excel.