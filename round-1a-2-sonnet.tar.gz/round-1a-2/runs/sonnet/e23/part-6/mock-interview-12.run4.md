**Don't pay anything, and don't send your passport or bank details. This email has the hallmarks of a recruitment scam, so I haven't built the interview pack for it.**

## Why it looks like a scam

- **The €95 "registration fee".** Real employers never charge candidates to interview. The payment goes to an account you can't verify, and the receipt goes to a `.example` address.
- **The cheque for €1,850.** This is the classic overpayment scam. The cheque looks real and your bank may even credit it. You then send "the balance" to the "vendor", and days or weeks later the cheque bounces. The bank takes the money back from you, and the money you sent is gone.
- **Passport photo and bank details before any interview.** Real employers ask for these after an offer, through an HR system. Sending them risks identity theft and account takeover. I'm not using a passport in your prep either, since interview prep doesn't need one.
- **The rest of the email.** It's an interview "invitation" for a remote admin role, which is common in these scams. There's also pressure to move fast ("to speed up onboarding").

## What to do now

1. **Don't pay, reply with documents, or deposit any cheque.**
2. **Check the company.** Search "Brennock Facilities Ltd" on the Companies Registration Office (cro.ie). Compare any phone number or website against the registry, not the email. Then contact the real company, if it exists, through those details to ask whether this role is genuine.
3. **If you've already sent your passport or bank details,** call your bank's fraud line today, and report it to An Garda Síochána. Also watch your credit file and accounts.
4. **If you've already paid the €95,** tell your bank straight away. They may be able to recall the transfer.
5. **Report it** to the platform where you found the ad and to the Garda. The Banking & Payments Federation Ireland (bpfi.ie) has fraud guidance too.

## Prep for genuine admin interviews

Your background fits real admin-assistant interviews well, so you can prepare for them now.

- **Likely questions:** how you managed four physios' conflicting calendars, and how you handled a double-booking or a last-minute cancellation. Also expect how you chased unpaid invoices and how you prioritise when everything is urgent.
- **Excel:** you said you're "okay" with it. Practise basic formulas, sorting, filtering and a simple invoice tracker in Excel before any interview, and be honest about your level.
- **Questions to ask them:** which systems they use for invoicing and travel, who you'd support, and what a good first month looks like.

If you find a real role, whether this company turns out to be genuine or not, send me the job description and your CV. I'll build a full prep pack with sample questions and answer guidance based on what you've actually done.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.