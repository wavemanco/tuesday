Aoife, please don't pay anything or send anything yet. This email has the hallmarks of a well-known scam, and I'd treat it as one until you've proved otherwise.

## Why it looks like fraud

1. **You pay before the interview.** Real employers don't charge candidates a "registration fee", and they don't make a fee a condition of confirming an interview slot.
2. **The cheque scam.** This is the classic overpayment fraud. They send a cheque for €1,850, you deposit it and send the "balance" to a vendor, and days later the cheque bounces. The money you sent is real and gone, and the bank will hold you responsible for it. A cheque showing as credited doesn't mean it has cleared.
3. **Passport photo and bank details before any interview.** That is identity-theft material. A real employer asks for ID only after a written offer, through a proper onboarding process.
4. **The payment goes to a "supplier's account"** rather than the company's own. The email also asks you to send the receipt to an address on an `.example` domain.
5. **The interview is only a 30-minute video call.** The scam doesn't depend on the interview, so there's nothing real to prepare for.

I haven't searched for Brennock Facilities Ltd, so I can't tell you whether the company exists or whether someone is impersonating it. That doesn't change the advice, because a genuine employer wouldn't send this email.

## What to do now

- **Don't pay, and don't send your passport or bank details.** Don't reply with anything personal.
- **If you already sent anything**, tell me. If you sent bank details, call your bank today and ask them to watch the account. If you sent a passport photo, report it and ask about identity-theft protection.
- **Check independently.** Look up the company in the Irish Companies Registration Office (CRO) register. Find its real phone number from an official source, not from the email, and ask whether the vacancy exists.
- **Report it.** In Ireland, you can report it to An Garda Síochána and the National Cyber Security Centre (NCSC), and tell the job board where you saw the ad.
- **Keep the email**, with its headers, in case you need it later.

## Your real prep

Your background suits real remote admin roles well, and the ad's tasks (calendars, travel, Word and Excel, supplier invoices) are standard. When a genuine interview comes up, expect these themes.

| Theme | Your strongest material |
|---|---|
| Calendar management | Running the appointment book for four physios. Be ready to explain how you handled clashes, cancellations and double-bookings. |
| Invoices | Chasing unpaid invoices at the clinic. This is close to processing supplier invoices, although it is the receivables side rather than payables, so be clear about that. |
| Excel | Your weakest area. Decide now what you can honestly do, and spend a few evenings on SUMIF, VLOOKUP/XLOOKUP, pivot tables and basic formatting. |
| Travel booking | You haven't mentioned any. Be honest about that, and bridge it with how quickly you pick up new booking systems. |
| Remote working | They'll ask about self-management, communication and keeping to deadlines without supervision. |

I can build the full interview prep pack for a real, verified role. It would include question banks, answers grounded in your own experience, an Excel gap plan and questions to ask the employer. If you can verify this one, or have another application, send me the job ad and your CV and I'll start.