Please don't prepare for this interview yet. The email has the hallmarks of a scam, and I wouldn't send any money or documents.

**Why it looks like a scam**
- **Upfront fee:** Real employers don't charge a €95 "equipment registration fee" to confirm an interview slot. The payment goes to a "supplier's account", not the company's.
- **Cheque overpayment:** They send a €1,850 cheque, you deposit it, and you send "the balance" to a vendor. This is a well-known fraud. The cheque eventually bounces, often days or weeks later, and the bank takes the money back from you. The money you sent on is gone.
- **Passport photo and bank details:** These are asked for before any interview, "to speed up onboarding". Legitimate employers collect them only after a written offer, through a proper HR process. Together they allow identity theft and account takeover.
- **Other signs:** Nobody has looked at your application, and the email makes you pay before you've met anyone. It also uses a placeholder-style address (hr@brennock.example).

**What to do now**
1. Don't pay, and don't send the passport photo or bank details.
2. If you already sent anything, tell your bank today and ask them to flag or block the account. If you sent the passport, report it too.
3. Report it to An Garda Síochána (Fraud) or your local police, and to the platform where you saw the ad.
4. Check independently whether "Brennock Facilities Ltd" exists. Use the Companies Registration Office (CRO) and a phone number you find yourself, not one from the email.

**If the company turns out to be real**, a legitimate employer would be happy to do a video interview with no payment. They would send an offer letter and contract first, and only then ask for ID and bank details through a secure HR process. If they do that, tell me and I'll build you a full prep pack.

**Your background is good prep material for real admin roles.** Two years running a four-physio appointment book and chasing unpaid invoices maps well onto calendars, travel and invoice processing. Excel is the gap to prepare for. If you send me a genuine job ad, I'll build you a full mock-interview pack, with likely questions, answers drawn from your real experience, and a plan for the Excel gap. I'd need the company name, the role and, if you have it, the full ad.