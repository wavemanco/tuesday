Checking whether Velloway Logistics exists as described, then I'll give you the full assessment.
**Not legit as described, and I wouldn't go ahead.** Don't send the IBAN, PPS number or passport photo. Don't pay the €349, and don't lodge the cheque or forward any of it. I checked that Velloway Logistics exists as described and found nothing. The sequence of messages is what decides it. The job itself doesn't need to be fake for this to be a scam.

# Job underwriting: Remote Order Processing Coordinator, Velloway Logistics

## Decision snapshot

**No, don't go ahead. RR1, RR2 and RR3 are each severe red flags, and the posting does not hold up. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (€30,000 a year minimum)
- `must_have`: direct: R2, R3, R4
- `important`: adjacent: R5 (Order processing); unclear: R6 (A quiet place to work)

R2, R3, R4: the stated skills match your background; R1: the pay cannot be confirmed to reach your floor.

**Opportunity ledger.** The role asks you for money and documents before any real interview (RR1, RR2, RR3). The employer can't be established (RR5), and the hiring runs from a webmail-style address (RR6). The pay claim sits well above the market band (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (€30,000 a year minimum).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR5 (`severity: high`).
- **What would change this:** Velloway verifies as a registered employer on its own site, and you have a live call with a named manager. You receive a signed contract, and no money is asked of you or routed through you. Hiring email comes from a company domain.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics: searches returned nothing, so the company is not established | `[grounded]` three searches, no results |
| Mandate | Process orders remotely, 15–30 hours a week, up to €26 an hour plus commission | `[grounded]` posting |
| Hiring process | Entirely on Telegram, "no calls or video interviews" | `[grounded]` posting |
| Sequence you were given | IBAN, PPS number and passport photo asked for before a "chat interview"; then a €349 fee; then a €2,850 cheque with €2,500 to forward | `[grounded]` the messages; `[inferred]` €2,850 − €350 = €2,500 |
| Contact | HR email at postmail.example, not at a Velloway domain | `[grounded]` message |
| First-year outcomes | None stated | `[grounded]` posting silent |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median €31,200, middle range €28,400–€34,100. That is about €15 an hour at 2,080 hours a year, so €26 an hour is roughly 1.7 times it, for a role needing "no experience". The guide leaves out commission-only and freelance work | `[generic]` Pennoral 2026 pay guide (search snippet); `[inferred]` hourly conversion |
| Unknowns | Employing legal entity, employee or contractor status, commission rate, guaranteed hours | `[grounded]` posting silent |
| Contradictions | They ask you to pay €349 to an "equipment partner", then send you money to forward to the same partner | `[grounded]` the messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated constraint. Fit is unclear because "up to €26" with 15–30 hours has no guaranteed figure. Your floor needs just over 22 hours a week at the full €26, and commission is unquantified | `[grounded]` posting and your constraint; `[inferred]` 30,000 ÷ 26 ÷ 52 | Moot given RR1–RR3 |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day and training two new starters. Self-reported, no artifact | `[grounded]` your account | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep the team's weekly tracker in Excel. Self-reported | `[grounded]` your account | none |
| R4 | Good written English | must_have | direct | medium | none | Written ticket replies daily; your messages here are clear English | `[grounded]` your account and this chat | none |
| R5 | Order processing (training provided) | important | adjacent | medium | transferability | Parcel tickets touch orders and shipments, but entering and processing orders was not your stated work | `[inferred]` adjacency from your courier tickets | G2 |
| R6 | A quiet place to work | important | unclear | low | discovery | You haven't said | `[grounded]` no statement from you | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R1, hard_gate) | hard_gate | "Up to €26", variable hours, commission unspecified | The floor can't be tested against a figure that isn't guaranteed | A written contract naming minimum hours and the hourly rate | A signed contract from a verified employer | `[grounded]` posting wording |
| G2 | Order processing (R5, important) | transferability | Courier ticket handling; limit: entering and processing orders wasn't your stated work | Real order-processing roles will ask how close your work was | Refunds, redeliveries, address changes or order-status edits you made in Zendesk or a back office | None needed yet | `[inferred]` bridge from your tickets |
| G3 | Quiet place to work (R6, important) | discovery | Not stated | Remote roles commonly ask | A dedicated desk or room | None | `[generic]` remote-role norm |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Applicant asked to pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | The payment may be the purpose, and the refund may never come | `[generic]` advance-fee pattern | Why must a new hire pay for equipment, and can it be supplied before any payment from me? | confirmed |
| RR2 | Cheque sent with instruction to forward most of it | red_flag | high | "We are posting you a cheque for €2,850. Lodge it ... keep €350 ... transfer the rest to our equipment partner." | A credited cheque can be returned unpaid after the €2,500 has left your account, leaving the loss with you | `[generic]` fake-cheque pattern | Why is a new hire asked to forward part of a cheque to a third party, rather than being paid through payroll after a contract? | confirmed |
| RR3 | IBAN, PPS number and passport requested before any real interview | red_flag | high | "send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | The documents may be collected for identity or account misuse | `[generic]` pattern | Which registered company employs me, and why are these needed before a written offer? | confirmed |
| RR4 | Hired from a text chat; calls and video ruled out | risk_signal | medium | "no calls or video interviews" | The process may avoid anything that exposes who is hiring | `[generic]` pattern | Can I speak by phone or video with the person who would manage me? | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | high | "Velloway Logistics" | No footprint, combined with RR1–RR3 and RR6, points to an employer that may not exist as described. Rated high because it sits beside off-domain contact and fee demands | `[generic]` pattern; `[grounded]` searches empty | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | HR contact at a webmail-style domain | risk_signal | medium | "velloway.hr@postmail.example" | A real employer would normally write from its own domain | `[generic]` pattern | Can you write to me from a Velloway company address? | confirmed |
| RR7 | Pay far above market for "no experience needed" | risk_signal | medium | "Earn up to €26 an hour plus commission ... No experience needed" | The figure may be bait; severity held at medium because the band excludes commission-only work | `[grounded]` posting; `[generic]` Pennoral band | What is the guaranteed hourly rate and number of hours, and how is commission calculated, in writing? | unresolved |

## Application plan

All rows are proposed and pending your approval. No CV or outreach text is drafted here.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing, pay nothing and lodge no cheque. Keep your IBAN to yourself | see RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | Stop replying, and block the Telegram account once you've screenshotted the messages | Keeps evidence, ends contact | `[generic]` standard practice | pending your approval |
| A3 | Report to the jobs site, to Telegram, to your bank's fraud team and to the Gardaí. If a cheque arrives, don't lodge it | see RR2 | `[generic]` standard practice | pending your approval |
| A4 | Redirect to salaried order-processing or customer-operations roles on employers' own careers pages, leading with your 60 tickets a day, the two trainees and the Excel tracker | These are your own stated claims, and the band's median of €31,200 clears your €30,000 floor | `[grounded]` your account; `[generic]` Pennoral band | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics careers remote order processing coordinator": no results, so the employer is not established. Moved role reality's organization row and RR5 |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator entry level hourly pay Ireland", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide), read from its snippet only. Moved market calibration and RR7 |
| 3. Hiring manager's public footprint | n/a | Only a Telegram handle was given, no name |
| Un-numbered | yes | Searched "Velloway Logistics Telegram job scam cheque equipment", aimed at public reports, which is outside L1's targets. No results, and it moved nothing |

I would offer a dossier file of this assessment if you want to keep it or send it to your bank or the Gardaí.

## Upgrade menu

- The link to the live posting and the jobs site it was on → RR5 can be checked against the actual listing.
- Any company registration number, address or contract → RR5 resolves either way.
- The partner's bank details they promised → useful to your bank and the Gardaí.
- A deeper research pass on Velloway (public reports, news; up to 5 more searches and 2 more fetches) → say the word and it runs.

## Questions

1. **RR5:** Which jobs site was the posting on, and can you paste the link?
2. **RR3:** In the chat interview, did any answer include your address, date of birth or current employer's name?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.