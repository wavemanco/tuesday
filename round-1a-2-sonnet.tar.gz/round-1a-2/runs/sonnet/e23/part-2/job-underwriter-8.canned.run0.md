Still working on this. I've read the assessment format and I'm now checking whether Velloway Logistics can be verified. Short answer so far: please don't send anything yet.
**No, don't go ahead. This is almost certainly a scam, so don't send anything. Status: `no_go`.** RR1, RR2 and RR3 are each `severity: high`, and your own messages from the recruiter show all three. The job market has real remote order-processing roles, and I'd keep looking for those. This one isn't one of them.

I don't need your passport, PPS number or IBAN to assess a role, and I haven't used them. Please keep them out of this chat too.

# Job underwriting: Remote Order Processing Coordinator, Velloway Logistics

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (at least €30,000 a year)
- `must_have` — direct: R2, R3 · adjacent: R4 (Good written English)
- `important` — unclear: R5 (A quiet place to work)

R1 — the pay is "up to" with a 15–30 hour range, so the floor is unstated; R4 — ticket writing is close but unsampled.

**Opportunity ledger.** The role fails on its terms, whatever your fit: three payment-and-identity demands (RR1, RR2, RR3), a process that runs only through Telegram and an off-domain email (RR4), an employer I could not establish (RR5), and withheld pay terms (RR6). No positive signal turned up.

- **Hard gates:** none failed; unconfirmed: R1 (at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`).
- **What would change this:** the employer would have to be verifiable on its own careers site, with no payment or cheque step. Its offer would have to come from a named person at a company domain, with a written contract before any ID or bank details.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics" — a search for its official site and careers page returned nothing | `[grounded]` posting header; search returned no results |
| Mandate | Process orders remotely, 15–30 hours a week, self-set hours | `[grounded]` posting |
| Pay | "Up to €26 an hour plus commission"; commission rate not stated | `[grounded]` posting |
| Hiring process | Telegram only, "no calls or video interviews"; the recruiter's HR email is on postmail.example, not a company domain | `[grounded]` posting and messages |
| Market calibration | Not established: the role-family search returned nothing, so there is no band to compare the posting's pay or title against | `[grounded]` search returned nothing |
| Unknowns | Registered company, named people, contract, commission terms, who the "equipment partner" is | — |
| Contradictions | The posting says "no experience needed, full training provided", yet the recruiter says a laptop and headset must be bought first and the company is "posting you a cheque" | `[grounded]` posting against the messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Your constraint: at least €30,000 a year | hard_gate | unclear | high | hard_gate | Confidence grades your own stated constraint. At €26 an hour the posting's range is about €20,280 (15 hours a week) to €40,560 (30 hours a week) a year. €30,000 needs roughly 22 hours a week at the maximum rate, and "up to" means the rate may be lower | `[grounded]` posting figures and your constraint; `[inferred]` arithmetic | Moot unless the employer verifies |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day and a weekly team tracker are specific, but they are self-reported with no artifact | `[grounded]` your background | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep the team's weekly tracker in Excel; self-reported | `[grounded]` your background | none |
| R4 | Good written English | must_have | adjacent | low | discovery | Written ticket replies at a courier are close to the requirement, but no sample was read | `[inferred]` from ticket work | A short writing sample would raise it |
| R5 | A quiet place to work | important | unclear | none | discovery | Not mentioned in your background | `[grounded]` background silent | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor against your €30,000 (R1, hard_gate) | hard_gate | "Up to €26 an hour", commission unquantified, hours 15–30 | A gate that cannot be checked cannot be passed | None applies; this is a term the employer sets | A written contract stating rate and hours | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Hire asked to pay up front | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages" | A real employer supplies equipment at its own cost; an up-front fee that is "refunded" later is a common advance-fee pattern | `[generic]` pattern, not proof about this sender | Which registered company supplies the kit, and why can it not be sent to me at your cost? | confirmed |
| RR2 | Cheque to lodge, then forward the balance | red_flag | high | "We are posting you a cheque for €2,850. Lodge it ... keep €350 ... transfer the rest" | You would forward €2,500. In the fake-cheque pattern the cheque can show as credited and later be recalled, leaving you owing the money you sent, and your account may be used to move others' money | `[generic]` pattern, not proof about this sender | Why would payroll send an unsolicited cheque before a signed contract, and why must I send money back? | confirmed |
| RR3 | IBAN, PPS number and passport photo requested before any interview | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport" | These three together are enough for identity theft; a payroll team needs them only after a signed offer | `[generic]` pattern, not proof about this sender | Who is the named data controller, and why is this needed before a contract? | confirmed |
| RR4 | Telegram-only process, off-domain contact, "hired" after a chat | risk_signal | medium | "no calls or video interviews"; "velloway.hr@postmail.example" | No named person, company domain or contract appears anywhere; severity stays `medium` alone and is raised by RR1–RR3 | `[inferred]` from the messages' content against the posting | Who will I report to, and can I have a written contract from a company address? | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The company may be new, small, or not exist as a hiring employer | `[generic]` pattern for entities with no footprint; not a claim about this one | Can you show the role on your own careers site? | unresolved |
| RR6 | Pay terms stated loosely for a no-experience role | unknown | — | "Earn up to €26 an hour plus commission"; "No experience needed" | The posting gives a ceiling and no commission rate; no market band was established to judge it against | `[inferred]` from the posting's wording; research found no band | What is the guaranteed hourly rate and the commission rate? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send none of the IBAN, PPS number, passport photo or €349, and stop replying | see RR1, RR3 | `[grounded]` register | pending your approval |
| A2 | If a cheque arrives, do not lodge it, and tell your bank | see RR2 | `[generic]` fake-cheque pattern | pending your approval |
| A3 | Keep screenshots of the chat, then report the account to Telegram and to the Gardaí | Reports help others and give you a record | `[generic]` standard fraud response | pending your approval |
| A4 | Apply instead to roles you can confirm on an employer's own careers page; your Zendesk and Excel work match R2–R3 | see R2, R3 | `[grounded]` your background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics careers official site"; no pages returned. Employer is not established (RR5) |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator Telegram hiring cheque equipment fee job scam"; no pages returned. No market band, so RR6 stays unknown |
| 3. Hiring manager's public footprint | n/a | No hiring manager was named, so there was no query to form |

I can write up this assessment as `tuesday-dossier.md` if you want a record to keep.

**Upgrade menu.** The live posting's link and the jobs site's name would let me check it against what you were sent (RR5). If you want deeper diligence on the company and any reports of its recruiters, I can do up to 5 more searches and 2 more fetches.

**Questions** (answer, say "skip", or ask me something else):

1. (RR5) Which jobs site was the posting on, and can you paste the link?
2. (RR3) Beyond answering their interview questions, have you sent them anything, such as a CV, phone number, or any bank or ID details?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.