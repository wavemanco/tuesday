Quick status: I've been reading the vetting skill's reference files so the assessment follows its format. Next I'll load the web search tool and check whether Velloway Logistics exists as described.
**No, don't go ahead. This looks like a scam, not a job, so I'd stop replying. · `no_go`.** RR1, RR2 and RR3 (all `severity: high`) are the reasons.

**Fit ledger.**
- `hard_gate` — unclear: R1 (income of at least €30,000 a year)
- `must_have` — direct: R3, R4 · adjacent: R2 (attention to detail)
- `important` — adjacent: R6 (order processing itself) · unclear: R5 (a quiet place to work)

Your background matches the posting's stated requirements well. That doesn't help here, because the problem is the opportunity and not your fit.

**Opportunity ledger.** The company can't be found (RR4). They asked for money before pay, for ID before an interview, and for a cheque to be forwarded (RR1, RR2, RR3). The hiring process is Telegram-only (RR5) and the contact address isn't on a company domain (RR6). Pay and speed of offer don't fit "no experience needed" (RR7). I found no positive signals.

- **Hard gates:** none failed; unconfirmed: R1 (income of at least €30,000 a year)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`)
- **What would change this:** a registered company you can verify, a live posting on its own careers site, and a real phone or video interview. They would also have to drop every upfront payment, every ID request before a signed contract, and the cheque-forwarding.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics": a search for the name returned nothing, so the company isn't established | `[grounded]` search "Velloway Logistics", no results |
| Role as posted | Remote order processing, 15–30 hours a week, "up to €26 an hour plus commission", no experience needed | `[grounded]` posting |
| Pay against your floor | At €26 an hour, €30,000 a year needs about 22 hours a week all year. At 15 hours a week the ceiling is about €20,300. The commission has no stated rate, and "up to" guarantees nothing | `[inferred]` arithmetic from the posting's figures |
| Market calibration | Not established. The role-family search returned nothing, so there is no pay band to compare against | `[grounded]` search returned no results |
| Contradictions | The kit costs €349. They then asked you to forward about €2,500 of a €2,850 cheque to the same "equipment partner" | `[grounded]` their messages, €2,850 minus the €350 you may keep |
| Unknowns | Legal employer, contract, guaranteed rate, who the "equipment partner" is | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Income of at least €30,000 a year (your non-negotiable) | hard_gate | unclear | high | hard_gate | The confidence is in your stated floor. Fit is unclear because the posting gives only a ceiling and an unquantified commission | `[grounded]` your statement; posting | Moot unless the employer verifies |
| R2 | Strong attention to detail | must_have | adjacent | medium | discovery | You work 60 tickets a day and keep a weekly tracker. Nothing yet shows accuracy outcomes such as QA scores or error rates | `[grounded]` your background, self-reported | See G1 |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep the team's weekly tracker in Excel. It is self-reported with no artifact seen | `[grounded]` your background, self-reported | None |
| R4 | Good written English | must_have | direct | medium | none | Written ticket replies in Zendesk are the likely evidence. No writing sample has been seen | `[inferred]` from Zendesk work | None |
| R5 | A quiet place to work | important | unclear | none | discovery | You haven't said | `[grounded]` silence in your message | None; moot |
| R6 | Order processing | important | adjacent | medium | transferability | Parcel-courier ticket handling is close to order handling. The posting says no experience is needed | `[inferred]` from your courier work | None |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Attention to detail (R2, must_have) | discovery | Volume and tracker upkeep, but no accuracy measures | Genuine admin and operations roles screen for this. It is moot for Velloway | Ticket QA scores, error-rate or SLA reports, tracker corrections you caught, the checklist you used to train starters | A QA scorecard or a sanitized tracker extract | `[grounded]` your background; `[generic]` that real roles probe accuracy |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment demanded before starting | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | The refund may never come | `[generic]` advance-fee pattern | Why can't the company ship the kit or deduct it from wages? | unresolved |
| RR2 | IBAN, PPS number and passport requested before any interview | red_flag | high | "send your IBAN, your PPS number and a clear photo of your passport" | This is enough data to impersonate you or open accounts in your name | `[generic]` identity-theft pattern | Can these go to a named contact at your own domain after a signed contract? | unresolved |
| RR3 | Cheque to lodge, keep €350, forward the rest | red_flag | high | "transfer the rest to our equipment partner" | The cheque may be returned after your transfer has gone, leaving you out of pocket and exposed as the sender of the funds | `[generic]` fake-cheque pattern | Why is a new hire being sent a cheque to pass to a third party? | unresolved |
| RR4 | Employer not established | risk_signal | high | "Velloway Logistics" | Combined with RR1–RR3 and RR6, this suggests there is no real employer. Severity would be lower for a small company alone | `[grounded]` search found nothing; `[generic]` severity rule | Can you point me at this role on your own careers site, and who would I interview with? | unresolved |
| RR5 | Telegram-only hiring, no calls | risk_signal | medium | "no calls or video interviews" | It removes any chance to verify who you are dealing with | `[generic]` | Can I speak to a named manager by phone or video? | unresolved |
| RR6 | HR contact not on a company domain | risk_signal | medium | "velloway.hr@postmail.example" | It looks like a generic mail host rather than a company address | `[inferred]` from the address, with no company site found | Can you write from your company's own domain? | unresolved |
| RR7 | Offer with no real vetting, pay out of line with "no experience" | risk_signal | medium | "you passed the interview and the job is yours" | It is too good and too fast. I rate it medium because that part is judgment | `[inferred]` from the posting's terms; no market band established | What is the guaranteed hourly rate, how is commission calculated, and what contract do I sign? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't send your IBAN, PPS number or passport photo. Don't pay anything. Stop replying | See RR1, RR2 | `[grounded]` their messages | pending your approval |
| A2 | If a cheque arrives, don't lodge it or send money from it | See RR3. Banks can credit a cheque provisionally and reverse it later, and forwarding funds for strangers can expose you legally | `[generic]` fake-cheque pattern | pending your approval |
| A3 | Report and block the Telegram account, report the posting to the jobs site, and tell your bank's fraud team if a cheque turns up | Stops the next person | `[generic]` | pending your approval |
| A4 | Redirect to named employers hiring support or operations coordinators, and check each posted salary against your €30,000 floor | Your R3, R4 and R6 evidence suits such roles | `[inferred]` from your background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and got no results. Not established, which feeds RR4 and the organization row |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator Telegram cheque overpayment equipment fee job scam" and got no results. It moved nothing, and the market calibration stays unestablished |
| 3. Hiring manager's public footprint | n/a | No person's name was given, only a Telegram handle, so there was no query to form |

I can write this up as a `tuesday-dossier.md` file if you want to keep it.

**Upgrade menu**
- A link to the original posting on the jobs site would show whether it is live and word-for-word the same. That could resolve RR4.
- A company registration number or website from them would let RR4 be checked against a real entity.

No questions this turn, because nothing you could answer would change the decision.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.