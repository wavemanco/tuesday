## Decision snapshot

**Decision: `no_go`. Don't go ahead, and don't send anything.** This is a textbook advance-fee and identity-theft job scam. It is not a real job with a few quirks.

- **Fit ledger:**
  - Must-have: spreadsheets, direct evidence (your weekly Excel tracker).
  - Must-have: attention to detail, adjacent evidence (60 Zendesk tickets a day, training two starters).
  - Must-have: written English, adjacent evidence (written support work).
  - Must-have: a quiet place to work, unknown.
  - Your fit isn't the problem. The employer is.
- **Hard gates:**
  - Your €30,000 floor: unknown and unlikely to be met. At the posting's top rate of €26/hour you would need about 22 hours a week all year. The posting says "up to" and "15–30 hours".
  - Legitimacy of the employer: failed, per the risk register below.

## Role reality `[grounded]` from your pasted text unless marked

- The role is "Order Processing Coordinator" with no experience needed, high pay, flexible hours and Telegram-only hiring. That is the standard bait for this scam. `[generic]`
- There are no named people, no company address or registration number, and no video call. The HR email is `postmail.example`, a generic non-company address.
- Market calibration: real order-processing roles are usually fixed-hours and paid at a modest hourly rate, with no "commission on every order". `[generic]`

## Evidence map

| # | Requirement | Your evidence | Fit |
|---|---|---|---|
| 1 | Spreadsheets | Weekly team tracker in Excel | Direct |
| 2 | Attention to detail | ~60 tickets a day in Zendesk, training two new starters | Adjacent |
| 3 | Written English | Written customer-service work `[inferred]` | Adjacent |
| 4 | Quiet place to work | Not stated | Unknown |
| 5 | Pay of €30k or more (hard gate) | Posting says "up to €26/h", 15–30 hours | Unknown, at risk |

## Gap recovery queue

- **Row 4:** you would need to tell me whether you have a quiet place to work. It's minor, and moot if you walk away.
- **Row 5:** a written contract showing a guaranteed hourly rate and hours. A scammer can't provide one.

## Opportunity risk register `[grounded]` from the messages, unless marked

| Signal | Class | Severity |
|---|---|---|
| Asked for IBAN, PPS number and passport photo before any interview | Red flag | Critical. This is identity-theft material. |
| Asked you to pay €349 to an "equipment partner" | Red flag | Critical. Advance-fee scam. |
| Cheque for €2,850: keep €350, send the rest on | Red flag | Critical. Fake cheque scam. |
| Hired without a call or video interview | Red flag | High |
| Contact is a Telegram handle and a free-style email domain | Red flag | High |
| Employer existence not verified | Unknown | High. Standing entry. |

The cheque is the sharpest signal. A cheque can look as if it has cleared while the bank still hasn't received the money, because clearing takes weeks. The bank will reverse the cheque once it bounces. The transfer you made from the "bonus" is real money gone, and the bank will hold you responsible for the shortfall. No legitimate employer pays you first and then asks you to send most of it to a third party. `[generic]`

## Application plan

Don't apply, send documents, or pay.

1. **Stop replying** to @VellowayHiring. You don't have to answer or explain.
2. **Don't send** your IBAN, PPS number, passport photo, or any money. Don't lodge the cheque if it arrives.
3. **Report the account** on Telegram and to the jobs site, and keep screenshots of the chat.
4. **Report it to the Gardaí.** Fraud reports can go through your local station.
5. **If you've already shared anything**, tell your bank straight away. If it was your PPS number, tell Revenue/Intreo too.
6. **Your real search:** target Dublin or remote customer-support, operations or logistics-coordinator roles at named employers. Your courier experience, Zendesk volume and Excel tracker fit those roles well.

## Evidence status

Research tier: L0 — no searches. The pasted messages were enough to reach the decision, so I didn't search.

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | skipped | The pattern is conclusive, and any scam page would only look legitimate |
| 2 | Role-family sweep | skipped | Calibration lines are `[generic]` |
| 3 | Hiring manager footprint | n/a | No name was given |

I offer to turn this into a `tuesday-dossier.md` file you can keep, if you'd like one.

**Upgrade menu:**
- A live posting link would let me check whether the listing is still up and who posted it.
- A real employer page or registration number would let me check whether a "Velloway Logistics" exists.
- Your CV would let me map your experience against genuine roles.

**Questions:**
1. Have you sent anything yet, such as your PPS number, passport photo, money, or chat details beyond answering their questions?
2. Do you have a link to the original posting, and which jobs site was it on?
3. Do you want me to help with a search for genuine roles that meet your €30k floor?

You can answer in a few words, or skip any of these.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.