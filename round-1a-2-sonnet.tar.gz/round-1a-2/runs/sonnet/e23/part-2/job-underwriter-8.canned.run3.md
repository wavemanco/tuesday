# Job Underwriting: Remote Order Processing Coordinator, "Velloway Logistics"

## Decision snapshot

**Do not go ahead. Status: `no_go`. Do not send your IBAN, PPS number or passport photo, and do not pay anything.** The posting shows three severe red flags (RR2, RR3, RR4), and each one fits a known fraud pattern. The cheque request is the most dangerous. I can't prove anyone's intent from a chat, but the conduct matches advance-fee and cheque-overpayment fraud `[generic]`.

**Fit ledger.** This covers your fit only, and the decision doesn't rest on it.

- `hard_gate` — unclear: R1 (income of at least €30,000 a year)
- `must_have` — direct: R2, R3, R4
- `important` — unclear: R5 (a quiet place to work)
- `preferred` — adjacent: R6 (logistics or order-flow domain)

**Opportunity ledger.** The employer can't be established (RR1). The process asks for identity documents and bank details before any real interview (RR2). It asks you to pay up front (RR3) and then to forward the proceeds of a cheque (RR4). The hiring is Telegram-only (RR5). The pay is well above the market figure for this work (RR6), and the contact address isn't a company domain (RR7). I found no positive signals.

- **Hard gates:** none failed; unconfirmed: R1 (income of at least €30,000 a year).
- **Severe red flags:** RR2, RR3, RR4.
- **Conditions for go:** none that a chat can meet. Only a verified employer reached through its own website and a live call could reopen this. The money requests would still be disqualifying, because no real employer needs them.

**If a cheque arrives:**
- Don't lodge it.
- If you did lodge it, a cheque can show as cleared and still bounce later. The bank then takes the money back and you lose whatever you sent on.
- If it comes to that, tell your bank straight away.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics": no web presence found, so existence, size and product are not established | `[grounded]` search returned no results (see evidence status) |
| Mandate | Remote order processing, 15–30 hours a week, "up to €26 an hour plus commission", no experience needed | `[grounded]` posting |
| Hiring process | Telegram only, no calls or video, interview by chat | `[grounded]` posting and messages |
| Pay arithmetic | At the maximum rate, €390–780 a week, about €20,300–40,600 a year over 52 weeks. €30,000 needs about 22 hours a week at the full €26. The commission is unquantified | `[inferred]` arithmetic from the posting's figures |
| Market calibration | Salaried order processing and customer operations coordinators in Ireland have a median base of €31,200 (interquartile range €28,400–34,100). That is roughly €15 an hour on a 40-hour week. The guide excludes commission-only and freelance work, so it is a pattern and not a claim about this employer | `[generic]` role-family sweep, the Pennoral pay guide |
| Unknowns | Who the legal employer is, what "orders" are processed, who the "equipment partner" is, who pays wages | — |
| Contradictions | First, "pay €349, refunded with your first wages". Then, "we send you €2,850 and you forward €2,500". The ask changed. Also, the posting says "no experience needed", yet identity documents were requested at the first screening | `[grounded]` the messages you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Income of at least €30,000 a year (your non-negotiable) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. The posting says "up to" €26 an hour over a flexible 15–30 hours, so the floor is reachable only at roughly 22 or more hours at the top rate. Moot given RR1–RR4 | `[grounded]` your constraint; `[inferred]` arithmetic | none; the role is `no_go` |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 tickets a day in Zendesk is steady, accuracy-sensitive work. It is self-reported, with no artifact | `[grounded]` your account | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. Self-reported, with no sample | `[grounded]` your account | none |
| R4 | Good written English | must_have | direct | medium | none | Written ticket handling and training two new starters imply it. The link to the requirement is a reasonable reading | `[inferred]` from your described work | none |
| R5 | A quiet place to work | important | unclear | low | discovery | You haven't said, and it can't change the decision | `[grounded]` silence in your message | none |
| R6 | Order-flow or logistics context | preferred | adjacent | medium | transferability | Three years at a parcel courier is adjacent domain experience for order processing | `[grounded]` your account | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Income of at least €30,000 (R1, hard_gate) | hard_gate | An hourly "up to" figure with no guaranteed hours and no stated commission rate | Under a real offer, the floor would depend on guaranteed hours | Not applicable to this role | A written contract with guaranteed hours and pay (not obtainable here) | `[inferred]` from the posting's wording |
| G2 | A quiet place to work (R5, important) | discovery | Not stated | It would matter only for a genuine role | Not applicable | Your own confirmation | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "Velloway Logistics" | The company may not exist, or may use a different trading name. Absence alone is weak, but it compounds with RR2–RR5 | `[grounded]` no search results; `[inferred]` reading | Does a company-owned website, careers page or registered address exist that matches this posting? | unresolved |
| RR2 | Identity documents and bank details requested before an interview | red_flag | high | "send your IBAN, your PPS number and a clear photo of your passport" | These enable identity theft or fraudulent account use. Legitimate employers collect them after a signed offer, through their own HR system | `[generic]` common hiring practice and fraud pattern | Would they let you provide these only after a signed contract on company letterhead? | unresolved |
| RR3 | Candidate asked to pay up front | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | A classic advance-fee ask. The "refund with first wages" is the hook, and the money rarely returns | `[generic]` fraud pattern | Why can't the company ship equipment, or deduct a cost from wages? | unresolved |
| RR4 | Cheque to lodge, balance to forward | red_flag | high | "keep €350 as a welcome bonus and transfer the rest" | An overpayment scam: the cheque later bounces, the bank reverses it, and the €2,500 you sent is gone | `[generic]` fraud pattern | No question worth asking; no employer needs this | unresolved |
| RR5 | Telegram-only hiring with a handle and no named person | red_flag | medium | "no calls or video interviews" | It avoids traceability and any chance of checking who you are dealing with | `[inferred]` from the posting and messages | Who is the named hiring manager, and can you speak to them live? | unresolved |
| RR6 | Pay far above the market for the work | risk_signal | medium | "up to €26 an hour" | High pay for entry-level work with no experience is bait. Comparison is rough: the survey covers salaried roles only | `[grounded]` survey figure; `[inferred]` hourly conversion | What is the guaranteed base, in writing? | unresolved |
| RR7 | Contact address isn't a company domain | risk_signal | medium | "velloway.hr@postmail.example" | A generic mail host can be set up by anyone in minutes | `[inferred]` from the domain; no company site was found | Does mail come from an address on a domain the company owns? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing: no IBAN, PPS number, passport photo or payment. Stop replying and block @VellowayHiring | RR2, RR3, RR4 | `[grounded]` register | pending your approval |
| A2 | If a cheque arrives, don't lodge it and don't transfer anything | RR4 | `[grounded]` register | pending your approval |
| A3 | Screenshot the posting, the chat and the email, then report to An Garda Síochána, the jobs site and Telegram | Evidence helps the report and protects other applicants | `[generic]` standard practice | pending your approval |
| A4 | If you have already shared anything, tell your bank and watch your accounts and credit file | Limits the damage from RR2 | `[generic]` standard practice | pending your approval |
| A5 | Look for real roles by verifying the employer on its own website and by a phone call to a switchboard you found yourself | Your experience (R2–R4, R6) fits real customer operations roles in the €28–34k band | `[generic]` role-family pattern | pending your approval |

Extra offer, beyond this assessment: I can draft a short report message for the jobs site and Telegram, built only on your approval, since reports tend to get more traction with the facts laid out.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics", which returned no results. The employer is not established, which feeds RR1 and the failed-attribution entry |
| 2. Role-family sweep | yes | Searched "order processing coordinator remote hourly pay Ireland entry level", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). It fed the market calibration and RR6 |
| 3. Hiring manager's public footprint | n/a | No person's name was given, only a Telegram handle, so no query could be formed |
| Outside the declared targets | yes | Searched "remote order processing coordinator Telegram hiring cheque overpayment equipment fee scam", which returned no results. It moved nothing |

The dossier is yours if you want it: I can write all this up as `tuesday-dossier.md`, with no pressure either way.

**Upgrade menu**
- The jobs site's name and a link to the live posting would let you report it, and could show whether other listings use the same text.
- The sender's full email header would show whether the address matches any real company domain, which could close RR7.
- A deeper research pass (up to 5 more searches and 2 more fetches) covers public scam reports and recent news. I'm offering it once, and it runs only if you say the word.

**Questions**
1. (RR1) Which jobs site was the posting on? It matters because that site can remove the listing and warn other applicants.
2. (A5) Do you want me to shortlist what genuine roles for your background look like, and what to check before applying?

You can answer, say "skip", or tell me "not now".

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.