I'd hold off on prepping for this interview, because the message looks like a recruitment scam. The skill I'm using also needs a company and a role title, and this message gives neither. I haven't built a pack, because it would be rehearsal for an interview that may not exist.

**Why it looks like a scam**
- **No company or role.** A real recruiter names the employer, or at least the role, in the first message. This one gives neither.
- **Everything happens on WhatsApp.** The interview and the contract are both done there, with no calls or video. That keeps you away from anything that could be checked, and it's the standard setup for this scam.
- **"Found your profile online."** This is generic flattery that fits anyone. Having sent lots of applications makes it feel plausible, but scammers scrape job boards and CV sites precisely because of that.
- **Remote work, flexible hours, and an interview the very next day.** The pressure and the perks are both typical of these scams.
- **Unknown number.** Real agency recruiters usually email first from a company domain, or reach out through LinkedIn.

The usual aim is to collect your ID, bank details or a "training" or "equipment" fee. Sometimes it's to turn you into a money mule. The "contract" stage is often where it asks for those.

**What to do before tomorrow**
1. **Don't share anything sensitive.** That means ID, address, bank details, your National Insurance or Social Security number, and codes sent to your phone. Don't pay for anything either.
2. **Ask for verifiable details by reply.** Ask for the company name, the agency's website, the role, the hiring company, and an email from a company domain. A real recruiter will answer easily. A scammer will dodge or push you to hurry.
3. **Check them independently.** Search the agency and "Jess" yourself, and find the agency's number through its official site. Don't use any link or number from the chat.
4. **Match it to your applications.** See if any employer you applied to mentions an agency, or if the role appears on their careers page.
5. **Insist on a normal interview.** A legitimate employer will do a call or video interview, however remote the job is.
6. **If it's a scam, block and report the number.** Report it in WhatsApp, and to your national fraud service (Action Fraud in the UK, the FTC in the US).

**If it turns out to be real**
Send me the company, the role and ideally the job description. I'll then build a full prep pack: likely questions, answers grounded in your CV, and questions for you to ask them. It would help to know what you applied for and who the interviewer is, if they tell you.

If you'd like, I can draft a short reply that asks for the company and role details without giving anything away.