I haven't built an interview pack, because this message looks like a recruitment scam, and there's nothing real to prepare for yet. The skill also needs a company and a role title to run, and the message gives neither.

**Why it looks like a scam**
- **Nothing specific:** There's no company, role, salary or named client, only "a remote position with flexible hours".
- **Unsolicited WhatsApp contact:** Real recruiters usually reach you through email, LinkedIn or a job board first.
- **Everything over text, with no calls or video:** This is the most common tell. It means nobody can check who they are, and it's how these scams avoid being identified.
- **The contract is signed over WhatsApp too:** Scammers use this stage to collect your ID, bank details or a "training" fee.
- **Pressure to act:** You're asked to be free "tomorrow at 11am" for something you can't verify.
- **A vague claim about where they found you:** "Found your profile online" fits any of your applications, or none of them.

You've sent a lot of applications, so a real recruiter could be behind this. The message alone isn't proof either way.

**What to do**
1. **Don't share anything personal yet.** That includes ID, a passport, bank details, your address, and any "registration" or "equipment" fees. A real employer won't ask you to pay.
2. **Ask Jess for details that can be checked.** Ask for the agency's name and website, the employer and job title, and a link to the job advert. Ask for her work email and a LinkedIn profile, and for a phone or video call.
3. **Check what she sends.** Look up the agency on Companies House or the equivalent register. Find the agency's own phone number or email from their website, not from her, and ask them whether Jess works there. Search the job title together with "scam".
4. **Watch how she replies.** A real recruiter will be fine with a call. If she dodges, or pushes you to move to Telegram or to pay, treat it as a scam.
5. **If it is a scam,** don't reply any further. Block and report the number in WhatsApp. In the UK you can also report it to Action Fraud, and elsewhere to your national fraud agency.

**Once there's something real**
If Jess comes back with a named company, a role and a verifiable interview, send me the job description and your CV. I'll build you a full prep pack from them. If you tell me which application it might relate to, I can also prepare for that interview directly.

I can draft a short, polite message to Jess that asks for those verification details, if you'd like.