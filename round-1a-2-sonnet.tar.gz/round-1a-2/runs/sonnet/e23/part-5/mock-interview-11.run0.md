I'll load the skill. Before we prep, though, this message has several warning signs that I'll cover too.
I can't build an interview pack from this message, and I'd treat it as a probable scam until the sender proves otherwise.

**Why I can't build the pack:** the skill needs a company and a role title, and the message gives neither. "Jess" doesn't say who the employer is, and prep for an unnamed job would be guesswork.

**Red flags in the message:**
- **Unsolicited contact on WhatsApp.** Real recruiters usually reach out through email, LinkedIn or a job board, and they name the company.
- **No company, role or pay.** It uses vague hooks like "remote" and "flexible hours". Those are classic bait.
- **Everything happens over text.** The interview and the contract both happen on WhatsApp, with no calls or video. That avoids anything that could be traced or verified.
- **Short notice.** An interview "tomorrow at 11am" pressures you to act before you check anything.
- **"We found your profile online."** This is generic flattery, and it doesn't say which application or site it came from.

Your recent applications could have leaked your number, or a scammer could have scraped it from a job board. Fake "interviews" like this usually lead to one of these:
- Requests for your ID, bank details or National Insurance/SSN "for payroll".
- A fake cheque or equipment purchase.
- A request to pay for training or a background check.
- Tasks that make you an unwitting money mover.

**What to do before tomorrow:**
1. **Ask for specifics** by replying "Which company is this, what's the job title, and can you email me the job description from a company address?"
2. **Check the answer.** Look for the role on the company's own careers page. Look up the recruiter on LinkedIn. Search the agency's name plus "scam".
3. **Match it to your applications.** If you can't find a matching application, that's a strong sign it's not from one of them.
4. **Don't share** ID, bank details, your address or any payment, and don't click links they send.
5. **If it's a scam,** block and report the number in WhatsApp. In the UK you can also forward it to Action Fraud or 7726.

A real recruiter will answer those questions without trouble. A scammer will dodge them or push harder.

**If it turns out to be real:** send me the company name, the role title, the job description if you have it, and your CV. I'll build a full prep pack and can run a live mock interview. I'd also want to know whether the first interview is with a recruiter or the hiring manager. A legitimate process will usually offer a call or video as well.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.