I can't build a prep pack yet, and I'd check this message before you spend time on it. The skill needs a company and a role title, and this message gives neither. It also looks a lot like a known recruitment scam.

**Warning signs in the message**
- It comes from an unknown number and names no company, no role and no salary.
- "We found your profile online" is generic. A real recruiter usually says where they found you.
- The interview and the contract both happen only on WhatsApp, with no call or video. Legitimate employers almost always involve a video or phone conversation and an email from a company domain.
- It offers a remote role with flexible hours, which is the usual bait.
- It pushes you to commit to a time tomorrow.
- Scams like this typically move on to "onboarding" steps. Those include paying for equipment or training, sharing ID or bank details, or "processing payments" for the company.

You've sent a lot of applications, so a genuine reply is possible. Still, a real reply would normally name the company and the job you applied for.

**Before you reply, ask Jess for:**
1. The company name, the job title and a link to the listing.
2. A work email address, and the agency's website.
3. A phone or video call instead of a chat-only interview.

**Then check them:**
- Look the agency up on its own website, not through links Jess sends.
- Look for "Jess" on LinkedIn at that company.
- Check whether you actually applied to that company.

**If it goes ahead, don't share:**
- ID, a passport, your address, or bank details.
- Any payment, however small.

If they dodge these questions or get pushy, stop replying, block the number and report it in WhatsApp.

**What I need to start prep**
- Can you tell which application this relates to? If Jess gives you a company and role, send me those along with the job description and your CV.
- Do you know the round type, such as recruiter screen or hiring manager?

If it turns out to be genuine, I'll build the full pack from that. If you'd like, I can also draft a short reply to Jess asking for those details.