# Interview pack: Customer Support Specialist, Lumenvale Software

Interviewer: the support team lead (name not given). Round: a text chat on Telegram, which I've treated as a hiring-manager-style round because your message says "your interview will be a text chat here with our support team lead". Built from your message only; no research ran (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether the claims on your CV survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | How well you know the company and its strategy |
| CASE | A live problem from the actual role |

Because the interview is a text chat, the writing is itself scored. Short, complete replies; answer the question asked first; no walls of text.

## Fit snapshot

The ad's requirements are quoted as you relayed them. Evidence cells hold your words only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad, as you relayed it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: three years, customer service advisor, energy supplier |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad, as you relayed it | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Name Freshdesk as the ticketing tool and say you use it every day, exactly as the quote gives it. The material names Freshdesk and not Zendesk, and C3 rehearses that probe |
| F3 | "clear written communication" — the ad, as you relayed it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Derived from emails being part of your day, which touches written communication without showing how clear the writing was or how many of the 60 were emails. Answer slot: the ad asks for clear written communication, so expect a request for an example. If you have a written reply you can describe, say what it was and what you wrote, in your own words; if there is none to point to, say so plainly and return to answering emails as part of your day |
| F4 | "confidence handling escalations" — the ad, as you relayed it | none given | none | [grounded] | discovery | Your material does not show escalation work either way. Answer slot: the ad asks for confidence handling escalations, so expect a probe. If escalations reached you, say what you did, in your own words; if none did, or they were not yours to handle, say so plainly and say how you would handle one, as a plan and not as a past |
| F5 | Familiarity with how software companies support their customers (not in the ad) | "I've never worked for a software company." — your message | none | [generic] | capability | A gap you stated, so the words are yours: "I haven't worked for a software company." Then how you would learn the product, said as a plan. Nothing added to make the gap feel smaller |
| F6 | Onboarding or coaching colleagues (not in the ad) | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | A strength you offered, at its own scope: trained, four new starters, the refunds process, last year. The material does not say you led them or wrote the process |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| 2+ years in customer support (F1) | C1, D1, E1 |
| Zendesk or a similar ticketing tool (F2) | C3 |
| Clear written communication (F3) | A4, D3 |
| Confidence handling escalations (F4) | A3, B4, E2 |
| Software-company familiarity, not in the ad (F5) | B1, B2, B3, E1 |
| Coaching colleagues, not in the ad (F6) | C2 |

## Persona table

Your message states the format: "a text chat here with our support team lead". One round, run by the person who would lead the team, is a hiring-manager pattern, and nothing about the company's loop is documented beyond your message, so weights rest on that pattern and not on Lumenvale's process.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | Live support scenarios you answer in writing | High: a team lead hiring for a support seat tends to test real situations, and the whole interview is written, so a typed reply is the test | Clarify, then structure, then answer, in short typed replies; name one thing you would check before acting |
| Skeptic (B) | Quiet probing of the software-company gap | High: F5 is a gap you stated and the likeliest objection | Plain acknowledgment, then a plan, held through two follow-ups |
| Data-Driven Prober (C) | Digs into the 60 a day, the training, the tool | Medium: a team lead who read your application will test the figures on it | Say how each figure was counted, or say plainly you do not know |
| Conversational/Rapport (D) | Friendly opener, casual questions that are still scored | Medium: a chat format invites a conversational register | Prepare a 90-second arc; treat casual questions as scored |
| Pressure (E) | Short time-boxes, challenge to your fit | Low: nothing in the format suggests stress testing | Pause, restate, hold, then concede specifically |
| Values/Behavioral (F) | Tell-me-about-a-time prompts | Low: your message names no values round, and I could not check for published values | Use the selection scaffolds; if no time comes to mind, say so |

## Question banks

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in angry: they were charged twice for their subscription and say they will cancel. What do you reply first, and what do you need to know?" | CASE | [generic] | Structure it aloud: acknowledge the problem in a sentence, ask for what you need before promising anything (which account, which two charges, how they paid), say what you can fix yourself and what needs someone else, and give a clear next step and time. Make no claim about your past; the question needs none | The refunds theme is the likeliest live problem for a support seat; CASE because it asks for a decision, not a history |
| A2 | "A product bug is hitting many customers and the queue doubles in an hour. How do you prioritise, and what do you tell customers?" | CASE | [generic] | Clarify first (what is broken, who is affected, is there a workaround), then group similar tickets, give one honest holding message, flag the pattern to whoever owns the product, and say when you will update people. Think aloud and name one premise you would challenge | Tests structure under load, in the company's likely world of software incidents; `[generic]` because I could not confirm how Lumenvale handles incidents |
| A3 | "A customer refuses your answer and demands a manager. What do you do, and what do you pass on?" | CASE | [generic] | Say what you would try first, what makes you escalate, who you would hand to, and what you would hand over so the customer never repeats themselves. A plan, not a story about your past | F4's requirement, asked as a decision; the guidance claims nothing about your history because F4's evidence is silent |
| A4 | "Write the reply to a customer whose file export keeps failing. You have two minutes." | CASE | [generic] | Type it live: apology in one clause, one clarifying question or one concrete step, what happens next, no jargon. Keep it under six lines | F3's requirement tested directly, since a text chat has no other way to show writing |
| A5 | "A customer asks for something our product does not do. What do you say?" | CASE | [generic] | Say plainly it is not available, do not promise a date, offer the nearest workaround if you know one, and say you will pass the request on. Nothing here claims past experience | A software-support staple and a direct test of honesty over pleasing the customer |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked for a software company. Why should we expect you to pick up our product?" | JD | [grounded] "I've never worked for a software company." | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't worked for a software company." Then the limited holds your quotes carry: "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day". Then a plan, as a plan: how you would learn the product in your first weeks. Hold that position through two follow-ups by returning to those quotes, never by adding to them; concede plainly that you do not yet know their product | F5 is the gap you stated and the likeliest objection in some form; JD because it scores whether you can do the listed job with that gap |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company." | Choose the weakness that is actually true. Your material points to product knowledge, so name it plainly in one sentence, then say how you would close it. If another gap is the honest answer, give that one instead | Skeptic stem aimed at F5; JD because it asks about fit to the listed job |
| B3 | "What would you do in your first two weeks to get up to speed on our product?" | JD | [generic] | A plan, in order: learn the product as a customer would use it, read the help articles, read resolved tickets for patterns, ask the team what mistakes new people make. Say it as what you would do, not as what you have done | Closes the objection in B1 with a ramp plan; `[generic]` because it makes no claim about Lumenvale or your past |
| B4 | "Tell me about an escalation you handled." | EXP | [grounded] | The ad asks for confidence handling escalations, so this is an open prompt and none of your quotes carries it. Pick a case that went past what you could resolve alone: it needs what made it escalate, who you handed it to and what you passed on, and how it ended for the customer. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle one | F4 is a discovery row, so the honest answer is not yet known to this pack; EXP because it tests what you actually did |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said around 60 calls and emails a day. Walk me through how that number was counted." | EXP | [grounded] "answering around 60 calls and emails a day" | Say the figure as you gave it. Answer slot: how it was counted, in your own words, or say plainly you do not know how it was counted. Then what it moves with, the assumption behind it you would defend least, and which part was yours. None of these is supplied here; if you only have a rough sense, say so | F1 and F3 both lean on this figure, which makes it a magnet for probers; EXP because it tests attribution |
| C2 | "Tell me about training the four new starters on the refunds process." | EXP | [grounded] "I trained four new starters on our refunds process last year" | The beats are the quote's: four new starters, the refunds process, last year. Tell them in your own words. Answer slot: which part of the training was yours, and what was set by others; if the process or the materials came from someone else, say so plainly and return to the four new starters you trained | F6 is a strength that reads as seniority; EXP because the probe is how much was actually you |
| C3 | "Tell me how you use Freshdesk in a normal day, and how you would pick up a different ticketing tool." | JD | [grounded] "I use Freshdesk every day" | Start with the quote: "I use Freshdesk every day." Answer slot: what you actually do in it, in your own words, and any part you do not use, said plainly. If asked directly whether you have used another named tool, answer yes or no truthfully and return to Freshdesk. For the second half, a plan: how you would learn a new tool | F2's presentation row and the ad's named tool; JD because it scores the ticketing requirement |

### D. Conversational/Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey: how did you end up in customer service, and why software now?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | A 90-second arc anchored on the quote. Why you want to move is your own reason; your material says nothing about it, so say the real one and do not invent a tidy story | The standard opener, and the motivation half is where a gap gets probed |
| D2 | "What do you enjoy most about a day on the support queue?" | JD | [generic] | Answer in your own words with one concrete thing you actually like. The question makes no claim about your history | Casual but scored for genuine interest |
| D3 | "Our work is all in writing. How would you describe your written style?" | JD | [grounded] "answering around 60 calls and emails a day" | Describe the style you actually use. Emails are part of your day by your own words; whether you have a sample to point to is an answer slot: if you have one, say what it was, and if not, say so plainly and return to answering emails each day | F3's thin row, asked casually |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who already has software support experience?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" "I use Freshdesk every day" "I've never worked for a software company." | Hold on what the quotes carry: three years as a customer service advisor, and Freshdesk every day. Concede the specific gap plainly: "I haven't worked for a software company." Do not fold on the first, and do not stretch either quote | Pressure stem aimed at F5; hold-then-concede is the type's bar |
| E2 | "A customer says you're wrong, you're sure you're right, and they want it escalated now. Thirty seconds." | CASE | [generic] | Restate the issue, check your answer once against the facts, offer the escalation path calmly if they still want it, and say what you would pass on. Nothing claims past experience | Composure under time pressure on F4's requirement |

### F. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you put a customer ahead of a process." | VAL | [generic] | Selection scaffold: pick a time with a named customer problem, a rule that pointed the other way, what you did and who you told. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Stem from the persona model; I could not check for published Lumenvale values, so it is generic |
| F2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a real stake, the truth said plainly, and the relationship intact afterwards. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Same stem family; included because the persona is plausible even though a values round is not documented |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Could you share the team lead's name and job title before the chat, and send the invite from a Lumenvale email address?" | A real employer can answer it in a line, and it gives you something checkable before you share anything personal |
| R2 | "What does a good first 30 days look like for someone who hasn't worked in software before?" | Takes F5 head-on and shows you are already planning the ramp |
| R3 | "How does an escalation move between support, the team lead and the product team, and what does the specialist hand over?" | Shows you think about handoffs and tells you how escalation really works there |
| R4 | "Which ticketing tool does the team use, and how are new people trained on it?" | Closes the F2 question and signals you care about getting productive fast |
| R5 | "How is the quality of written replies reviewed here?" | F3 turned around: shows you value clear writing and learn how it is judged |
| R6 | "After this chat, what are the remaining steps, and will there be a video call or contract before an offer?" | Tests the process you were told about and gives you the shape of the rest |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked in a software or SaaS support environment | Negative you stated, F5 | The plain acknowledgment "I haven't worked for a software company." Then a plan for learning, as a plan |
| Is experienced with Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day". The pack's observation is that the material names Freshdesk and not Zendesk. C3's slot stays inside Freshdesk |
| Led, managed or designed the training or the refunds process | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year". The pack's observation is that the material says trained, not led or wrote. C2's slot stays inside the training |

## Sources

Provided documents: your message, including the Telegram text, your background and the ad's requirements as you summarised them. Searches sent, all refused by the host so nothing came back: `Lumenvale Software values`; `Lumenvale Software interview process customer support specialist`; `Lumenvale Software strategy news`; `Lumenvale Software recruiter Telegram interview scam`; `Customer Support Specialist remote job description Zendesk escalations 2+ years`. No page was fetched.

Research tier: L1 — searches 0 of 6 returned, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | The search was refused. It would have decided whether a values cheat sheet exists; none is included |
| 2. `Lumenvale Software interview process customer support specialist` | unavailable | The search was refused. The loop rests on your message and the generic archetype instead |
| 3. `Lumenvale Software strategy news` | unavailable | The search was refused. CO questions are absent; none could be grounded |
| 4. interviewer name and company | n/a | The support team lead is unnamed, so there was no query to form |
| 5. representative Customer Support Specialist JD | unavailable | The search was refused. The four requirements come from your summary of the ad |
| Un-numbered: `Lumenvale Software recruiter Telegram interview scam` | unavailable | The search was refused. It would have checked whether the company and the recruiter's contact route are verifiable |

## Upgrade menu

- The full ad text → F1 to F4 are quoted from your summary, and the full text would add any requirements and terms you did not relay, such as hours, location and right to work
- Your CV → F1 to F6 draw only on your message; CV lines would add rows, and a redacted sample reply or a quality-score report would be the artifact that could raise F1 and F3
- Your own answers to B4 and C3 (an escalation you handled, what you do in Freshdesk) → F4 and F2 move from discovery and presentation to evidence-backed rows
- The team lead's name → an interviewer read and a reverse question tied to their path
- Search access, or Lumenvale's published values and process pasted in → rows 1 to 3 and 5 of the target accounting, a values cheat sheet if a values round is documented, and CO questions
- The interview date and your prep time → a prioritised prep triage
- A tuesday-dossier.md from job-underwriter → verified evidence and an underwriter-chosen top objection; the pack does not need one
