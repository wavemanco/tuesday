# Interview prep pack: Customer Support Specialist, Lumenvale Software

**Candidate:** Imani. **Round:** a text chat on Telegram with the support team lead, whose name you don't have yet. Marcus Hale, from the talent team, set it up. **Relationship:** the person who would lead your team, so this is built as a hiring-manager-style round. That rests on Marcus's message alone, and no research on the company could be run (see Sources).

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the values a company publishes |
| EXP | Whether your CV claims survive follow-up questions, and what was actually yours |
| JD | Whether you can do the listed job, including its gaps |
| CO | How much you know about the company |
| CASE | How you reason through a live problem from the real job |

An answer slot is an instruction for the interview, not a question for you here. Answer it from your own experience. If the practice it names was not yours, or never existed, say so plainly and go back to what you did do.

## Fit snapshot

The requirements are the four the job ad asked for, as you gave them to me. I don't have the full ad text.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the job ad, as you gave it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | Your sentence already covers the requirement in its own terms. It is a self-reported line with nothing inspected behind it, so lead with it as written and expect a probe. |
| F2 | "experience with Zendesk or a similar ticketing tool" — the job ad, as you gave it | "I use Freshdesk every day" — your message | medium | [grounded] | none | Freshdesk is a ticketing tool, and your sentence names it and how often you use it. Your material names Freshdesk, not Zendesk. Answer slot: the ad names Zendesk, so expect to be asked about it. If you have used Zendesk, say where, in your own words. If you have not, say so plainly and stay with Freshdesk. |
| F3 | "clear written communication" — the job ad, as you gave it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails touch the requirement, but the sentence doesn't show how clear your writing is. This interview is a text chat, so your replies are themselves a writing sample. Answer slot: if you can point to anything about how your written replies were received, say what it was. If there is nothing, say so plainly and let the chat show it. |
| F4 | "confidence handling escalations" — the job ad, as you gave it | none given | none | [grounded] | discovery | Your material is silent on escalations, and silence is not a stated gap. Answer slot: expect a probe. If you passed on or took over difficult cases, say what happened and which part was yours. If you did not, or it was not yours, say so plainly and stay with the daily calls and emails. |

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A: Case / Strategist | Live ticket scenarios typed into the chat: an angry customer, a fix that needs engineering, a message to rewrite | High. A team lead hiring a support specialist usually tests live handling, and F3 and F4 can only be tested by doing. The chat is text, so every answer is also writing | Clarify first, structure second, keep replies short and plain |
| B: Skeptic | The software gap and the thin escalations row, probed quietly | High. Your note says you have never worked for a software company, and F4 has no evidence. A team lead de-risking a hire starts there | Rehearse B1 until it is boring: say the gap plainly, then return to your sentences |
| C: Data-Driven Prober | "Around 60 a day" and the training figure, taken apart | Medium. Both are figures, and a lead who read your CV will test them | Know how each figure was counted. Say plainly if you don't |
| D: Conversational | Friendly opener, "walk me through your journey", "why us" | Medium. Texting invites a casual register, and casual questions are still scored | Prepare a 90-second arc, and treat "why us" as scored |
| E: Pressure | Short challenges: "why you?", "how much was you?" | Low. Nothing in Marcus's message suggests a stress style. It stays in because a short text chat compresses questions | Hold your position through two follow-ups, then concede only what is true |
| F: Values / Behavioral | Customer-first and hard-truth stories | Low. No values round is documented, and your loop is one chat. No published values were available, so these are generic patterns | Pick a real instance from your own work, or say plainly none comes to mind |

A Peer Evaluator is left out because the interviewer is the team lead, not a peer.

## Question banks

### A: Case / Strategist (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in capital letters that they were charged twice and want to cancel today. Talk me through your first reply." | CASE | [generic] | Structure it in four beats: acknowledge the problem, say what you can check, say what happens next, and say when they will hear back. Ask one clarifying question if something is missing. Keep it short, because the chat is the sample. The question needs no claim about your past, so the guidance makes none | A live problem from the daily work, delivered in text, which is how F3 gets tested. CASE because it scores reasoning on a live problem |
| A2 | "A customer's problem needs a fix from engineering and you don't know how long it will take. What do you tell the customer, and what do you pass to the engineer?" | CASE | [generic] | Customer side: what you know, what you don't, no promised date, and when you will update them. Engineer side: what the customer reported, what they see, what has been checked. Think aloud, and challenge one premise politely, for example by asking how urgent it is | The escalations requirement in F4, asked as a decision rather than a record, so it needs no past. CASE because it scores structure |
| A3 | "Tell me about a time you had to escalate a case." | JD | [generic] | Selection scaffold: pick a case with a named stake, a handover you made, and a result you know. The interviewer will ask what part was yours. If no such case comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle one | The ad raises escalations and F4 holds no evidence, so this question is likely. JD because it scores the stated requirement |
| A4 | "Have you used Zendesk?" | JD | [grounded] "I use Freshdesk every day" | Answer slot: the ad names Zendesk. If you have used it, say where and how, in your own words. If you have not, say so plainly, then say "I use Freshdesk every day". You may add how you would learn Zendesk as a plan, never as something you have already done | F2 is the evidence for the tool requirement, and the ad's own wording makes this likely. JD because it scores the stated requirement |
| A5 | "Rewrite this for a customer: Your refund has been actioned per policy 4.2 and will be processed within the standard SLA." | CASE | [generic] | Plain words: what has happened, what happens next, and by when. Drop internal jargon and give no figure you don't have. Aim for two or three short sentences | A writing test you can do inside a text chat, from the clear-written-communication line in F3. CASE because it scores a live task |

### B: Skeptic (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You'd be moving into software from outside it. What would be hardest in your first month?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day" | **Highest-ROI prep in this pack.** Hold-then-concede. Concede first, in your own words: "I've never worked for a software company." Then hold what your sentences carry: 3 years as a customer service advisor at an energy supplier, and Freshdesk every day. Do not say what that proves. Follow-up 1 is likely to be "what would you do in week one?". Answer it as a plan, never as a past. Follow-up 2 is likely to be "what if you can't learn the product quickly?". Return to your sentences and don't add to them | This is the objection this chat is most likely to raise, and it points at exactly where the material is thin. A calm, specific answer changes how the rest of the chat reads. JD because it scores a gap in the role |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Pick the one that is true for you. F4 and F3 are the thinnest rows. If the honest answer is the industry, say "I've never worked for a software company", then say what you would do first. Name only a weakness you can talk about for two follow-ups | The Skeptic's standard stem, aimed at F3 and F4. JD because it scores the role's own list |
| B3 | "Why move into software, and why now?" | VAL | [generic] | Your reasons, in your own words, one about the work and one about this company, with nothing negative about your current employer. If your honest reason is mostly practical, such as remote work, say so plainly and add what else is true | Motivation consistency is what a Skeptic checks, and nothing in your material supplies your reasons. VAL because it scores what you value |
| B4 | "The ad says confidence handling escalations. What does that mean to you?" | JD | [generic] | Define it in your own words, as a view and not a claim about your past. Answer slot: if you have handled an escalated case, say what happened and which part was yours. If you have not, say so plainly and describe how you would handle one | F4 has no evidence, so the interviewer will ask what the word means to you before asking for an example |
| B5 | "Why should we pick you over someone who already works in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year"; "I've never worked for a software company" | Hold: three sentences, in order, in your words. Then stop and let the interviewer draw the inference. If pushed, concede only that you have never worked for a software company. Don't claim you are the better fit | The sharpest form of B1, so it comes up if B1 goes well. JD because it scores fit against the role |

### C: Data-Driven Prober (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Keep the word "around", and keep the unit as calls and emails. Answer slot: say how the figure was counted, what it moves with, and which assumption you would defend least. If you don't know how it was counted, say so plainly. Don't call them tickets unless that is what they were | F3 and F2 both rest on this figure. EXP because it tests whether the number survives a second question |
| C2 | "You trained four new starters. What was your part?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | The beats are the ones your sentence states: you trained four new starters, on the refunds process, last year. Answer slot: say which part was yours. If it was shared, or someone else built the process, say so plainly and stay with what you taught | The one quoted sentence that shows teaching. EXP because it tests attribution |
| C3 | "What do you actually do in Freshdesk every day?" | EXP | [grounded] "I use Freshdesk every day" | Start from your sentence: "I use Freshdesk every day". Answer slot: the ad asks for a ticketing tool, so expect this probe. Say what you actually do in it, in your own words. If there is something you don't use, say so plainly | F2 is the evidence for the tool requirement and sits on one sentence |

### D: Conversational (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey to customer support." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | A 90-second arc. Open with your sentence as written. Then say, in your own words, why you want the next step. Say nothing about earlier roles unless you can talk about them | Casual biography questions are scored for economy. F1 is the spine |
| D2 | "What do you enjoy most about support work?" | VAL | [generic] | One honest thing, and one example from your work if one comes to mind. If none does, say so plainly and keep to the one honest thing | A rapport question that still scores real interest in the work |
| D3 | "Why Lumenvale?" | CO | [generic] | No research on the company could be run, so this is a pattern, not a fact about them. Say what drew you from the ad and from Marcus's message. If you haven't looked at the product yet, say so plainly, and look at their site and help centre before the chat | This is the CO slot. It is generic because no company research ran |

### E: Pressure (weight low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year"; "I've never worked for a software company" | Three sentences, in your own words: the 3 years, Freshdesk every day, the four new starters. Then stop. If challenged, hold through two follow-ups. Concede only "I've never worked for a software company" | A shorter version of B5 for a chat where answers are kept short |
| E2 | "That training: how much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold: "I trained four new starters on our refunds process last year". Answer slot: if any part was shared or designed by someone else, say so plainly, and say what part you did | The standard attribution probe, aimed at the one quoted teaching sentence |

### F: Values / Behavioral (weight low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you put a customer ahead of an internal metric." | VAL | [generic] | Selection scaffold: pick a case with a named stake, a choice you made, and an outcome you know. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it | A standard stem. No published values were available, so it is a pattern |
| F2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time where the hard message actually landed, and say what you said. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it | The Values persona's standard stem, kept so the style is not new to you live |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" (F1) | B5, D1, E1 |
| "experience with Zendesk or a similar ticketing tool" (F2) | A4, C3 |
| "clear written communication" (F3) | A1, A5, C1 |
| "confidence handling escalations" (F4) | A2, A3, B4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "After this chat, what are the next steps, and will any of them be a video call or an email from a company address?" | It shows you are organised about process. A real hiring team can answer it easily, and how they answer is useful information |
| R2 | "Which ticketing tool does the team use, and how long does onboarding usually take?" | It answers the Zendesk question from F2 and shows you are planning ahead |
| R3 | "What does a strong first month look like for someone coming from outside software?" | It names the B1 gap without apologising and asks for the team's own standard |
| R4 | "How does the team handle cases that need to go to another team, and where does a specialist's ownership end?" | It speaks to F4 and tells you what the escalation path really is |
| R5 | "How does the team judge good written replies?" | It speaks to F3 and shows you care about the quality of your writing |
| R6 | "What would you most like the next hire to take off your plate?" | It turns the end of the chat into a conversation with the lead about their real problem |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has software-industry experience | A negative you stated | Your sentence: "I've never worked for a software company". The plain acknowledgment is in your own words |
| Has used Zendesk | Inflated form of F2, whose quote names Freshdesk | F2's quote at its own scope: "I use Freshdesk every day". The limit is the pack's own observation: your material names Freshdesk, not Zendesk. A4's slot stays inside that |
| Handled around 60 tickets a day | Inflated form of F3's figure, which counts calls and emails | The quote at its own scope: "answering around 60 calls and emails a day", with "around" kept |
| Led or ran a training programme | Inflated form of "I trained four new starters on our refunds process last year" | The quote at its own scope. C2's slot asks only which part was yours |

## Sources

**Provided:** your message, which contains Marcus's Telegram text, the four requirements from the ad, and your background. That message also establishes the loop: one text chat with the support team lead. The pack was built from it alone.

**Searches sent, all refused:**

- "Lumenvale Software company values": refused
- "Lumenvale Software interview process customer support specialist": refused
- "Lumenvale Software strategy news": refused
- "Telegram recruiter job interview scam offer onboarding in chat warning signs": refused. It sat outside every declared target

Nothing in this pack comes from outside what you gave me.

Research tier: L1 — searches 0 of 6 returned, 4 sent and refused; fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Would have fed a values cheat sheet. Not built, since no values round is documented in your loop |
| 2. Interview process | unavailable | Would have confirmed the loop. Persona weights rest on the relationship prior and Marcus's message |
| 3. Strategy and recent news | unavailable | Would have grounded D3 and a CO question. D3 is generic as a result |
| 4. Interviewer footprint | n/a | The support team lead is unnamed. Marcus is the recruiter, not the interviewer |
| 5. Representative JD | unavailable | Would have turned the four requirements into a fuller list. The snapshot uses the four you gave |

## Upgrade menu

- The full job ad text → the four requirement rows become the ad's own wording, and any further requirements get rows and questions
- The support team lead's name → an interviewer read and a reverse question tied to their own path
- Anything Marcus said about format, length or focus areas → the persona weights and the banks get reweighted
- Whether you have used Zendesk, and any example of handling an escalated case → rows F2 and F4 get quoted evidence, and A3, A4 and B4 become story-mapped answers
- Anything about how your written replies were received → F3 gets quoted evidence
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes, once search is permitted → the company's published values, loop and strategy, which would turn D3 into a grounded question
