# Interview pack: Customer Support Specialist (remote), Lumenvale Software

Interviewer: the support team lead (unnamed), by text chat on Telegram. Relationship: a future manager. Built for a hiring-manager-style round, because that is the closest match to a team-lead chat. Candidate: Imani.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and only say what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavior against the company's published values (none researched, so none appear here) |
| EXP | Whether your own experience claims survive follow-up questions |
| JD | The listed requirements of the role, including the gaps |
| CO | Company and strategy knowledge (not covered: research was unavailable) |
| CASE | A live problem from the actual job, answered in structure |

Because this is a text chat, written clarity is itself being scored. Short sentences, one point per message, and answer the question asked.

## Fit snapshot

The requirements come from the job ad as you relayed it in your message. The full ad text was not supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad as you relayed it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap. It is your own statement with nothing inspected behind it, so expect a follow-up on it. Lead with the quote in its own terms: three years, customer service advisor, an energy supplier |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad as you relayed it | "I use Freshdesk every day" — your message | medium | [grounded] | none | No gap against the "similar ticketing tool" wording. Say it as you said it: you use Freshdesk every day. Your material does not mention Zendesk, so do not imply it |
| F3 | "clear written communication" — job ad as you relayed it | "answering around 60 calls and emails a day" — your message | medium | [inferred] | transferability | Your material says emails were part of the work, and nothing about how clear they were or who judged them. The words stay there: emails were part of the day. Answer slot: if anyone reviewed, scored or praised your written replies, say what they said; if nobody did, say so plainly and show the quality live, in this chat |
| F4 | "confidence handling escalations" — job ad as you relayed it | none given | none | [grounded] | discovery | Your material does not show escalation work either way. Answer slot: if you handled escalations, say one real one and exactly what your part was; if you did not, or it was not yours, say so plainly and describe how you would decide when to escalate |
| F5 | Familiarity with supporting a software product — role-family expectation, no quoted source | "I've never worked for a software company." — your message | none | [generic] | capability | You stated this yourself, so the plain words are yours: "I haven't worked for a software company." Then a plan, said as a plan and never as a past: how you would learn the product. Nothing added to make the gap smaller |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 2+ years in customer support | D1, C1, B5 |
| F2 Zendesk or a similar ticketing tool | B4 |
| F3 Clear written communication | A5, D1 |
| F4 Escalations | A1, A3, A4, E2 |
| F5 Software-product familiarity (generic, not from the ad) | A2, B1, B2, D3, E1 |
| Unrelated to the ad: refunds training, daily volume | C1, C2, C3, E2 |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live support scenarios typed into the chat | Highest. A team lead hiring for a support seat tests handling, and a chat format favors scenario questions you can answer in a few messages | Clarify, then structure, then reply. Think aloud in short messages |
| B. Skeptic | Probes the move from energy to software, the missing escalation evidence, Zendesk | Highest. F5 and F4 are the visible gaps, and a hiring manager is derisking them | Rehearse B1 until it is boring. Say the limit plainly, then give a plan |
| C. Data-Driven Prober | "How was that counted" on your daily volume and the training | Medium. Your message carries two figures a careful lead will test | Know what you can and cannot say about how each was counted, and say so when you do not know |
| D. Conversational | Opening "tell me about yourself" and friendly motivation questions | Medium. Chat interviews open casually, and those answers are still scored | A 90-second arc built only from your own sentences |
| E. Pressure | Short, challenging "why you" and "how much was you" | Lower. Text chat softens stress tactics, but one challenge is likely | Hold through two follow-ups, concede specifically, never fold on what you said |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same unresolved problem and is clearly angry. What do you reply?" | CASE | [generic] | Structure it: acknowledge the repeat plainly, read the earlier messages before replying, say what you will do and when, and say who will follow up. The question needs no claim about your past, so the guidance makes none | Tests the escalation-adjacent handling in F4's requirement as a live decision, with no history required. CASE because it is a live problem |
| A2 | "A customer says a feature isn't working and you don't know the product well yet. What do you do first?" | CASE | [generic] | Structure it: ask what they expected and what happened, check the knowledge base, try to reproduce it, escalate with clear notes if you cannot fix it, and tell the customer honestly what happens next. Makes no claim about your past | F5 is the gap a software lead will press, and this lets you show method instead of product knowledge. CASE because it is a live problem |
| A3 | "A customer is asking for something outside policy and wants a manager. Walk me through it." | CASE | [generic] | Structure it: hear the request out, state what you can do, explain the limit once and clearly, offer the next step, and say what you would pass on and why. No claim about your past | Covers the escalation requirement from F4 as a decision. CASE because it is a live problem |
| A4 | "How do you decide when to escalate a ticket instead of solving it yourself?" | JD | [generic] | Give your criteria in a short list, such as what you can fix with the access you have, what needs another team, and what carries a risk to the customer. Answer slot: if you have escalated tickets in your role, name one real one and exactly what your part was; if you have not, or it was not yours, say so plainly and answer from how you would decide | JD because it scores the ad's escalation line. F4 holds no evidence either way, so the slot lets the honest answer be either branch |
| A5 | "Reply to this as you would in chat: 'I was charged twice and nobody has answered me.'" | CASE | [generic] | Type the reply live: apologise once, name the problem back in your own words, say what you will check and what you need from them, and give a time for the next update. Short lines, one point each. Makes no claim about your past | F3 is a written-communication requirement, and in a text interview the best evidence is the reply itself. CASE because it is a live task |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've come from an energy supplier. How will you cope supporting a software product?" | JD | [grounded] "I've never worked for a software company." | The highest-ROI rehearsal in this pack. Hold: "I haven't worked for a software company." Then, in order: your plan for learning the product, said as a plan (what you would read, ask and practice first); then the ticketing side you can speak to, in its own words: "I use Freshdesk every day." Hold through two follow-ups by returning to the plan and the Freshdesk sentence, never by adding product experience. Likely follow-ups: "what do you know about our product?" (say what you actually looked up, or that you have not yet) and "why not stay in energy?" (B2). Name the limit before they do | F5 is the most predictable objection, and it is aimed at the one thing your material says you lack. JD because it scores fit to a software role |
| B2 | "Why move from energy to software, and why now?" | JD | [generic] | Answer slot: give your real reason in your own words, one or two sentences, then one thing you want from this role. If your reason is partly about leaving something, say it neutrally. Do not invent a long-held interest in software if you do not have one | Motivation consistency is what a Skeptic scores. Nothing about your past is claimed, so the answer is yours alone |
| B3 | "This is fully remote. How do you stay on top of your queue without a team around you?" | JD | [generic] | Selection scaffold: pick a time you kept to a heavy workload without someone checking on you; it needs a named habit, a moment it was tested, and an outcome you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The role is remote, which you stated, so self-management is a likely probe. JD because it scores the working setup |
| B4 | "You use Freshdesk. How would that carry over to Zendesk?" | JD | [grounded] "I use Freshdesk every day" | Say it as stated: you use Freshdesk every day. Answer slot: if you have used Zendesk, say where and for what; if you have not, say so plainly and say what you would check first in a new ticketing tool, such as how tickets are assigned, tagged and escalated. Never describe Freshdesk features you do not use | F2 is the ad's tooling requirement and your quote reaches it through "similar". JD because it scores a listed requirement |
| B5 | "You've spent three years in one company. How do you handle a very different way of working?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Say the three years in those words. Answer slot: if you adapted to a change at your employer, say what changed and what you did; if there was none, say so plainly and say how you would learn a new team's way of working in the first weeks | A Skeptic reads single-employer tenure as an adaptability question. F1 is the evidence, and EXP because it tests what you actually did |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said around 60 calls and emails a day. How was that counted, and what was the split?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say it in your own words with its own hedge: around 60, calls and emails. Answer slot: how it was counted (a system report or your own sense), what moves it (busy and quiet days), the assumption you would defend least, and which part was yours. If you do not know the split, say so plainly | A headline figure from your message is a defend-the-number target. F1 and F3 both lean on it. EXP because it tests precise attribution |
| C2 | "Tell me about training the four new starters on your refunds process." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Beats are the ones the sentence states: four new starters, the refunds process, last year. Tell it in your own words and add nothing else. If a follow-up asks what you did or how it went, answer only from what actually happened, and say plainly where you do not know | A trained-others claim is attractive to a lead and easy to probe. EXP because it tests what was actually yours |
| C3 | "What numbers, if any, did your team track on your work?" | EXP | [generic] | Answer slot: if you know them, name them and say how they were measured; if you were not given numbers, say so plainly and say what you would want to track here. The pack does not supply a measure | Support leads think in response time, satisfaction and resolution. The premise is open ("if any"), so either branch is honest |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, tell me about yourself and why this job." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" and "answering around 60 calls and emails a day" and "I use Freshdesk every day" and "I trained four new starters on our refunds process last year" | A 90-second arc using only those sentences: three years as a customer service advisor at an energy supplier; around 60 calls and emails a day; Freshdesk every day; training four new starters on refunds last year. Close with the honest part: why this job, in your own words (B2) | Chat interviews open here and it is scored. F1, F2 and F3 are the rows it draws on. EXP because it frames the whole CV |
| D2 | "What do you like most about helping customers?" | VAL | [generic] | Answer slot: give a real reason in one or two sentences, in your own words. A specific moment is stronger than an adjective, only if you have one and can stand behind it | A casual question about the core of the job. VAL because it scores motivation, with no published company values in hand |
| D3 | "What have you looked at so far to get ready for supporting software?" | JD | [generic] | Answer slot: if you have looked at our product, help pages or similar tools, say exactly what; if you have not yet, say so plainly and say what you will look at first. Do not claim knowledge of the product that you do not have | A friendly way to test effort on F5. JD because it scores readiness for the role |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day" | Hold on what you said: three years as a customer service advisor at an energy supplier, and you use Freshdesk every day. Concede specifically when pushed: "I haven't worked for a software company." Hold through two follow-ups and never claim product experience you do not have | F1 and F2 are the material, F5 is the concession. JD because it scores fit, delivered under pressure |
| E2 | "On that training: how much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold at the sentence's scope: you trained four new starters on your refunds process last year. Answer slot: if someone else set the content or shared the training, say exactly which part was yours; if all of it was yours, say that plainly. Concede what you do not know and do not widen the claim | The standard attribution probe, aimed at F4's nearest neighbor. EXP because it tests ownership |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does the first month look like for someone new to supporting a software product?" | Turns your biggest gap, F5, into a question about their onboarding |
| R2 | "Which tickets do you most often see new team members struggle with, and what helps them?" | Shows you are thinking about your first weeks, and it is useful to hear |
| R3 | "How is the team set up across time zones, and what are the expected hours?" | A real remote-work question that also makes the logistics clear before an offer |
| R4 | "How are escalations handled here, and who would I escalate to?" | Responds to F4's requirement and shows you care about the process |
| R5 | "Could we move the next step to a video call, and will I get a written contract and a company email before any onboarding steps?" | A reasonable request from any serious employer. How they answer is useful information for you |
| R6 | "What does good look like for this role after six months?" | Shows ambition and gives you the real measure of success |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has handled escalations | Inflated form of F4, where the material is silent | Nothing is claimed. Your material does not show escalation work, so A4 holds a slot stated in your own words |
| Has used Zendesk | Inflated form of F2 | The quote at its own scope: "I use Freshdesk every day". The limit is the pack's observation: your material names Freshdesk, not Zendesk |
| Has software or SaaS support experience | Negative you stated, F5 | The plain acknowledgment: "I haven't worked for a software company." Followed by a plan, never a past |
| Managed, mentored or led a team | Inflated form of the training line | The quote at its own scope: "I trained four new starters on our refunds process last year" |
| Hit named targets such as satisfaction scores or resolution times | Silence in your material, so C3 holds a slot | Only what you know and can say how it was measured |

## Sources

Provided documents: your message, including the Telegram message and the ad requirements as you listed them. No full job description was provided.

Searches sent, all refused for lack of permission, so nothing came back:
- "Lumenvale Software company" — refused
- "Lumenvale Software Customer Support Specialist careers" — refused
- "fake job interview on Telegram recruiter text chat offer onboarding scam warning signs" — refused

Research tier: L1 attempted — searches 0 of 6 returned, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale values | unavailable | Would have fed a values cheat sheet, which is omitted. The company search was refused |
| 2. Lumenvale interview process, support roles | unavailable | Would have set persona weights from a documented loop. Weights here rest on round-type priors only |
| 3. Lumenvale strategy or recent news | unavailable | Would have grounded a CO question. No CO question is in this pack |
| 4. Interviewer name and company | n/a | The team lead is unnamed, so there was no query to form. The interviewer read is absent |
| 5. Representative Customer Support Specialist JD | unavailable | Would have turned the relayed requirements into quoted lines. The careers search was refused |
| Un-numbered: scam-pattern search | unavailable | Search refused. The scam notes in the accompanying message are general knowledge, not researched here |

## Upgrade menu

- The full job ad text → the four relayed requirements become quoted `[grounded]` rows and any further requirements get questions
- The company's published values page (paste it) → a values cheat sheet and VAL questions
- The team lead's name → an interviewer read and a tailored reverse question
- Search permission granted → company verification, documented interview loop, and current strategy for CO questions
- Any hours, location or work-authorization requirements in the ad → a gate row in the fit snapshot
- Anything about your escalation work, written-reply feedback or Zendesk use → F3, F4 and B4 move from answer slots to story-mapped rows
- A `tuesday-dossier.md` from a job-underwriting pass → a pack-specific objection and prohibited claims built from verified evidence
