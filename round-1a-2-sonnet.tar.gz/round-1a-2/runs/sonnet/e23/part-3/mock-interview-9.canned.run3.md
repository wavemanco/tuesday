I've read the skill's reference files and am now running the district research, up to five searches, before I build your prep pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/e23/part-3/rooms/case-9-canned-4428a930/Halvering-Elementary_fourth-grade-teacher_interview_pack.md`. It has 21 practice questions, a table matching your experience to what the district and role ask for, and six questions for you to ask the panel.

The pack assumes the panel is the whole interview, since the district's hiring page describes a single 45-minute panel like yours. It also assumes no job posting and no assigned deliverable, because neither was in your invite.

- **Your license:** it meets the invite's one hard requirement, so it needs no rehearsal, only your details on hand.
- **Fourth grade:** your biggest gap is that you've never taught fourth grade, and the job title names it. Question A1 is the one to rehearse most. It has you say plainly "I haven't taught fourth grade," then describe your third-grade years in your own words, then give a plan for learning fourth grade.
- **Curriculum and team lead:** your note that you led your grade level's move to a new reading curriculum sits next to "I've never been a team lead." Expect a question on how much of that move was yours (H1).
- **Principal's background:** Principal Vantongeren was a reading specialist for nine years, so expect depth on reading instruction.
- **Research:** the district's three published beliefs and the board's new reading plan shaped several questions. The principal's background, the board's plan and the sample job listing came from search snippets, not full pages, so read the board's plan yourself before Thursday.

Your résumé text included a Social Security number. You don't need it for interview prep, so I didn't use it and it isn't in the pack. Take it off anything you send to employers. I also left your license number out.

Say the word and I'll play the panel on A1, the question the pack names as your highest-value prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the job posting for this role? If you paste it, the requirement rows rebuild from its own wording.
Did HR say what the panel will focus on, or ask you to bring anything, such as a sample lesson? A declared deliverable would add a build section.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering-Elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
**Round:** One 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given)
**Built on this assumption:** the invite's panel is the whole loop, there is no job posting in hand, and no deliverable was announced.

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Question IDs are letter-by-persona. The letters skip F, so an F-number always means a fit-snapshot row. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs, not generic virtue |
| EXP | Whether what you have told them survives follow-up questions, and what was actually yours |
| JD | The role as stated, including its gaps |
| CO | How well you know the district and where it is heading |
| CASE | Structure and reasoning on a live problem from the actual job |

The highest-ROI rehearsal in this pack is **A1**, the fourth-grade question: it is the one gap you stated yourself, and the job title names it.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — interview invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The quote meets the invite's requirement in its own terms, and the endorsement range in it includes the fourth-grade level. It is a CV line with nothing inspected behind it, so a request to confirm it is plausible. Lead with the quote's own terms and have your license details to hand |
| F2 | "Fourth Grade Teacher position" — interview invite | "I've never taught fourth grade" — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then what you would learn first, said as a plan and never as a past. Never a claim to fourth-grade work, and nothing added to make the gap feel smaller |
| F3 | Plan and teach a full elementary classroom across subjects (typical for the role per a representative posting snippet, not this school's posting) | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | transferability | Your material gives the grade and the school type, with nothing about subjects taught. Words stay at that scope: "For six years I taught third grade at a public elementary school in Joliet." Nothing wider |
| F4 | "Every Child a Reader: no student leaves third grade without a reading plan" — Orrinsford mission page | "I've run the after-school reading club for the last two years" — your CV and "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | transferability | Both quotes are adjacent to a reading plan and neither says one existed. Words stay at their scope: you run the club, and you led your grade level's move. Answer slot: the belief's wording makes a probe on reading plans likely. If you made or used a plan for any student's reading, say what it was and what part was yours, in your own words; if there was no such plan, or it was not yours, say so plainly and stay with the club and the curriculum move |
| F5 | "Families Are Partners: each teacher speaks with every family each term" — Orrinsford mission page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | The quote is an email to families, which is adjacent to the belief's wording and does not say more. Words stay there: "I write a weekly email to families." Answer slot: if you have any account of how families responded to the emails, say it in your own words; if you have none, say so plainly and stay with the weekly email |
| F6 | Readiness for a new reading curriculum: the board's August 2026 literacy plan brings a new grades 3–5 reading curriculum from fall 2027 (search snippet, relevance to you is the pack's inference) | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [inferred] | none | The quote reaches the requirement in role-relevant terms. Lead with its words and keep its scope: your grade level, a move to a new reading curriculum, 2024. Expect a probe on what "led" covered, which H1 rehearses |
| F7 | Work as a member of a grade-level team (typical for the role) | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [generic] | none | The quote already speaks of grade-level work. Keep its scope. Nothing in it says what your team role was beyond "led", so the words stay the quote's |
| F8 | "Panels ask about reading instruction, classroom routines and how you work with families" — Orrinsford hiring page | none given | none | [grounded] | discovery | Your material says nothing about classroom routines, and that is the pack's observation, not a finding that you lack them. Answer slot: if you set routines for your own classroom, say what they were and how you taught them, in your own words; if you did not, or they were set for you, say so plainly and answer C2 as a live problem |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or knows its content from teaching it | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't taught fourth grade." No slot |
| Has been a team lead | Negative you stated: "I've never been a team lead" — your CV | The plain acknowledgment that quote gives: "I haven't been a team lead." No slot. H1 holds only what the curriculum quote carries |
| Chose, designed or selected the new reading curriculum | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: the material says you led your grade level's move, not who chose the curriculum. H1's slot stays inside the move |
| Led a school-wide or district-wide curriculum change | Inflated scope of F6 | F6's quote at its own scope: your grade level |
| Founded or designed the reading club | Inflated form of F4 | F4's quote: "I've run the after-school reading club for the last two years." The material says run, not founded |
| Speaks with every family each term | Inflated form of F5 | F5's quote at its own scope: a weekly email to families. The material says email, not conversations, and not every family |

## Reading the interviewer

Public professional footprint only. Both facts come from a search snippet of a speaker page; the page itself was not fetched.

| Public fact | Source | What it suggests for prep | Provenance |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | ilprincipalsforum.example speaker page | Reading instruction is her home ground, so expect depth on it: C3, D1, G1. Say what you did and stop; she will hear any stretch | [grounded] |
| 2025 forum talk "Small Groups, Big Readers", covering weekly reading conferences in grades 3 to 5 | same | Reading conferences are a stated focus of hers. R1 asks about them in fourth grade. Do not claim conference practice unless it is yours | [grounded] |
| Mirror opportunity: her talk's grade range and your quoted sentence "I've run the after-school reading club for the last two years" (F4) share the topic of reading, not a career jump | same, plus F4 | Offer the sentence at its scope when reading comes up. No shared career jump is claimed | [grounded] |
| The two fourth-grade team members | n/a | No names were given, so there is nothing to read. Names would unlock this section for them | n/a |

## Persona table

Weights rest on a loop source: the district's hiring page says "Teacher hiring at Orrinsford is one 45-minute building panel: the principal and two grade-level teachers", which matches your invite. No archetype fallback was needed. For a panel the starting point is the top two personas of each seat's relationship. I took the principal's seat as hiring-manager-like and the two team seats as peer-like; that is an assumption, so correct it if you know better.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Skeptic | The fourth-grade gap, motivation, "why now" | High: F2 is the one gap you stated, the title names it, and a hiring-manager-like seat probes it | Rehearse A1 until it is boring: the plain acknowledgment, then the quote at its own scope, then a plan |
| B Peer Evaluator | Collaboration, credit, "what would you need from us" | High: two fourth-grade team members sit on the panel, and the hire joins their team | Reciprocity first: what you would bring, then principles rather than claims about their seam |
| C Case/Strategist | Live reading and routines problems; the board's literacy plan | Medium: the hiring page says panels ask about reading instruction and classroom routines, and the principal's public background is in reading | Clarify, structure, then answer; say what you would ask the team |
| D Values/Behavioral | Stories keyed to the district's three beliefs | Medium: the beliefs are published, but no loop source names a values round, so the beliefs theme the questions and no separate values section is built | Map a story only where a sentence of yours carries one; otherwise pick by the criteria and use the honest branch |
| E Conversational | The opening "walk us through your journey" and a casual reading question | Medium: panels open with an easy question, and easy questions are still scored | A 90-second arc built only from your four sentences |
| G Data-Driven Prober | "How do you know it is working?" | Low: your material states no figures, so there is little to defend by number | Say what you track, or say plainly that you do not |
| H Pressure | "How much of that was actually you?", time-boxed answers | Low: no source suggests a stress style, but the curriculum quote and the team-lead negative sit close together | Hold the quote's scope through two follow-ups, then concede the specific limit |

## Question banks

### A. Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This is a fourth-grade position, and you've never taught fourth grade. What will be the hardest part for you in the first month?" | JD | [grounded] "I've never taught fourth grade" and "Six years teaching third grade at a public elementary school in Joliet" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't taught fourth grade." Then the only experience the second quote carries, at its scope: "For six years I taught third grade at a public elementary school in Joliet." Then name, in your own words, the one part of fourth grade you would most want to learn first and what you would do first about it, said as a plan and never as something already done. Hold that through two follow-ups by returning to the third-grade sentence, never by adding fourth-grade knowledge you have not used. When pressed, concede the specific limit: the fourth-grade classroom is new to you | F2 is the stated gap and the job title names the grade, so this arrives in some form. JD because it scores the stated role |
| A2 | "Walk us through how you would plan your first weeks with a fourth-grade class." | CASE | [generic] | Clarify first: what the team already has in place for the opening weeks, and what you can learn from them before you plan. Then structure it in the order you would act: the goal for the first week, what you would watch for in the class, the routines you would set, where reading fits, how families hear from you, and what you would check at the end. Think aloud and end with the one premise you would test with the team. The question asks about no past, so this guidance makes no claim about yours | F2 turned forward-looking: a candidate who cannot cite fourth-grade experience is judged on how they would structure the work. CASE because it is a live problem, labeled generic because it is a pattern, not a fact about this school |
| A3 | "Why fourth grade, and why now, after six years in third?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | None of your sentences answers a motivation question, so this is a selection scaffold. Give your real reason in your own words, one true thing about this school or district that draws you if one does, and what you would carry with you. If part of the honest reason is something other than the role itself, say so plainly. The only fact you can lean on from your material is the quote above, at its scope | F2 is where a skeptical seat asks "why leave, why here, why now". JD because it tests fit with the stated role; the pack supplies no reason because none is in your material |
| A4 | "What do you bring to a fourth-grade team that a teacher who has taught fourth grade might not?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years" and "I write a weekly email to families" | Use only these three sentences, each at its own scope, and say what each was in your own words. Let the panel draw the comparison; do not say what the work proves, and do not claim to know more than a fourth-grade teacher does. Say what you bring and stop | F2 plus F4, F5 and F6 are the only evidence you have for this; asking it as a comparison tests whether you stay inside what you did. EXP because it checks that your sentences hold |

### B. Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell us about a time you and a colleague wanted different things about how to teach something." | EXP | [generic] | A selection scaffold: pick a time that has what each of you wanted, what you did about it, and a working relationship that was intact afterwards. Say "I" for what you did and "we" for the context. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The peer stem on disagreement with equals; F7 is the row it tests. EXP because it asks for something you actually did, generic because no source raises this theme for this school |
| B2 | "A grade-level project goes well and the principal thanks only you. What do you do?" | CASE | [generic] | Say what you would do in the moment: name the colleagues who did the work, out loud and plainly, without turning the correction into a speech about yourself. Then what you would do afterwards so the team hears the same account. The question asks about no past, so this guidance makes no claim about yours | The peer stem on credit across teams. CASE because it is a live problem, labeled generic because it is a pattern |
| B3 | "What would you want to bring to our team's planning, and what would you need from us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years" | Reciprocity: what you bring is only what these two sentences carry, at their scope. What you need is a plan, so offer principles for working with a team rather than a claim to know how their team splits the work | F7 and F4 are the evidence; the question prices what the hire adds to their load. JD because it scores the stated team element of the role |
| B4 | "You write a weekly email to families. How would that fit with how our team already reaches families?" | EXP | [grounded] "I write a weekly email to families" | Tell it at its scope: "I write a weekly email to families." What would fit with the team's habits is a plan for this team, so say what you would ask them first and what you would keep or adjust. Answer slot: if you have any account of how families responded to the emails, say it in your own words; if you have none, say so plainly and stay with the weekly email | F5 is the evidence and the belief about families raises the probe. EXP because it tests a stated practice, with a team seam as the peer's angle |

### C. Case/Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The board adopted a literacy plan in August 2026 that includes a new grades 3–5 reading curriculum from fall 2027. What would you want to know about it before you taught under it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Clarify before you answer: what the plan covers for grade four, when materials and training arrive, and how the team expects to pilot it. Structure by what you would ask, then what you would do first as a teacher under it. If your 2024 move comes up, tell it at its own scope and stop there unless asked; do not present it as the same kind of change. Answer slot: if you are asked what part of the 2024 move was yours, say what "led" covered in your own words; if others decided or carried parts, say so plainly (H1). Read the board's plan page yourself before Thursday, because this question rests on a search snippet | F6 is the evidence and the board's plan is the strategy hook. CO because it tests district knowledge; the pack found the plan through a snippet and could not read the page |
| C2 | "It is the second week of school and transitions are eating ten minutes of every morning. What do you do?" | CASE | [generic] | Clarify what is happening and in which transitions, then structure: observe, pick one routine to change, teach it to the class, check whether it held, and ask the team what they already do. Think aloud. The question asks about no past, so this guidance makes no claim about yours | F8 is silent on routines and the hiring page names routines as a panel topic; a live problem presupposes nothing. CASE because it is a live problem, generic because it is a pattern |
| C3 | "A fourth grader is reading well below the class and the family is worried. Walk us through your first two weeks." | CASE | [grounded] | Clarify what "well below" means and what the school already uses to know it. Then structure: what you would find out, what you would tell the family and when, what support you would ask the team for, and what you would check at the end of two weeks. Use the district's own words, "Every Child a Reader", only where they fit. The question asks about no past, so this guidance makes no claim about yours | F4 is the row the belief raises; the principal's public reading background makes reading cases likely. CASE because it is a live problem, grounded in the published belief |

### D. Values/Behavioral (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell us about a time you helped a student who was struggling as a reader." | VAL | [grounded] "I've run the after-school reading club for the last two years" and "Six years teaching third grade at a public elementary school in Joliet" | Theme from the belief "Every Child a Reader". A selection scaffold: pick a time that has what you noticed, what you tried, what changed, and which part was yours. If it came from the club or your third-grade classroom, say which. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the club at its scope, or how you would handle it | F4 is where the belief presses and no sentence of yours describes a struggling reader. VAL because it scores a published belief |
| D2 | "Tell us about a time you worked with a family to support their child's learning." | VAL | [grounded] "I write a weekly email to families" | Theme from the belief "Families Are Partners". A selection scaffold: pick a time that has who the family was in general terms, what you did together, and what you learned. The one sentence you can lean on is the email, at its scope. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the weekly email, or how you would handle it | F5 is the evidence and the belief raises the theme. VAL because it scores a published belief |
| D3 | "Tell us about a time assessment results changed what you taught." | VAL | [grounded] | Theme from the belief "Teach for Tomorrow, Not for the Test". A selection scaffold: pick a time that has the information you looked at, what you changed, and what you saw afterwards. Your material carries no sentence for this question, so no story is mapped. If no such time comes to mind, say so plainly, then say how you would decide what to teach next from assessment information | No row carries assessment evidence, so this is a discovery gap. VAL because it scores a published belief; no candidate sentence is claimed |

### E. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk us through your journey to this point." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" and "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years" and "I write a weekly email to families" | A 90-second arc in this order: the third-grade years, the curriculum move, the reading club, the weekly email, each at its own scope in your own words. End with your own reason for this role, the answer to A3. Add no earlier steps that your material does not carry | The opening question is scored even when it feels casual; F3, F4, F5 and F6 are the sentences available. EXP because it is a CV walk-through |
| E2 | "What is a book you would want fourth graders to meet this year, and why?" | JD | [generic] | A selection scaffold: pick a book you know well and say why, in your own words. Do not imply you have used it with students unless you have. If none comes to mind, say so plainly and name how you would choose one | The casual-register reading question from the Conversational stem; F4's reading focus makes it likely. JD because it touches the role's reading element |
| E3 | "You run an after-school reading club. What is that like?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Tell it at its scope: "I've run the after-school reading club for the last two years." Say what happens when it meets, in your own words, not as a script. If part of it was set by someone else, or varies, say so plainly | F4 is the evidence; casual questions about hot topics are scored. EXP because it checks that the sentence holds |

### G. Data-Driven Prober (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "How do you know the reading club is working?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Theme from the belief that assessments inform teaching. Answer slot: if you track anything about the club, say what you track and what it cannot tell you; if you track nothing, say so plainly and say what you would look at first. Never describe a measure you did not use | F4 is the evidence and no figure is stated, so the prober asks how you know. EXP because it checks the sentence |
| G2 | "What would you want to measure in your first semester of fourth grade, and what would it not tell you?" | CASE | [generic] | Name one or two things you would look at and, for each, the assumption you would defend least. The question asks about no past, so this guidance makes no claim about yours | The weakest-assumption move rehearsed on a forward-looking question. CASE because it is a live problem, generic because it is a pattern |

### H. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "You say you led your grade level's move to a new reading curriculum, and you've never been a team lead. How much of that move was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" and "I've never been a team lead" | Hold the position the quote carries: "I led our grade level's move to a new reading curriculum in 2024." Concede the specific limit plainly: "I haven't been a team lead." Reconcile them in your own words. Answer slot: say what "led" covered and what stayed with others; if others decided or carried parts, or the word was informal, say so plainly and return to the quote. Hold through two follow-ups before conceding anything further | F6 and the stated team-lead negative sit close together, and this is where an attribution probe lands. EXP because it tests what was actually yours |
| H2 | "Convince us in sixty seconds that you are ready for fourth grade." | JD | [grounded] "I've never taught fourth grade" and "Six years teaching third grade at a public elementary school in Joliet" | Pause and restate the question. Open with the plain acknowledgment, then the third-grade quote at its scope, then your plan for the first month, in your own words. Do not argue that third grade equals fourth. Hold through two follow-ups by returning to the quote | F2 under time pressure. JD because it scores the stated role; the pressure style tests composure |

### Requirement coverage

| Requirement | Questions |
|---|---|
| License and endorsement (F1) | — none, and why: a gate your material shows met, so it needs a fact to hand, not an answer |
| Fourth Grade Teacher position (F2) | A1, A2, A3, A4, H2 |
| Elementary classroom teaching (F3) | A1, E1, E2 |
| Reading instruction belief (F4) | C3, D1, E2, E3, G1 |
| Families belief (F5) | B4, D2 |
| New reading curriculum (F6) | C1, H1 |
| Grade-level team (F7) | B1, B2, B3, B4 |
| Panel topics: reading instruction, classroom routines, working with families (F8) | C2, C3, D2 |
| Assessment belief (no fit row; evidence silent) | D3, G1, G2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How do reading conferences run in fourth grade here, and what would you want a new fourth-grade teacher to learn first about them?" | Ties to the principal's public talk on weekly reading conferences, and it asks for support in a collegial register |
| R2 | "What does support look like for a teacher who is new to fourth grade, in the first month and the first semester?" | Names the gap honestly and turns it into a plan |
| R3 | "What could a new member of the fourth-grade team do in the first month that would genuinely help the team?" | Reciprocity question for the two team members |
| R4 | "How is the new grades 3–5 reading curriculum expected to shape fourth grade this year?" | Shows you read the board's plan and asks where it lands for this grade |
| R5 | "What does it look like in practice for a fourth-grade teacher to be in touch with every family each term?" | Takes the district's own belief seriously without claiming you already meet it |
| R6 | "What would you want to see from the person in this seat by the end of the first semester?" | Gives the panel a closing note on what success is |

## Sources

Provided: the interview invite and your résumé text. The résumé text included a Social Security number and a license number; neither is used anywhere in this pack.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

Queries, with what came back:

- "Orrinsford Community School District mission values" → https://orrinsfordschools.example/about/mission-and-beliefs
- "Orrinsford Community School District teacher interview process panel" → https://orrinsfordschools.example/careers/how-we-hire-teachers
- "Orrinsford Community School District strategic plan news" → https://orrinsfordschools.example/news/board-adopts-literacy-plan (snippet only, not fetched)
- "Dolores Vantongeren Halvering Elementary School principal" → https://ilprincipalsforum.example/speakers/dolores-vantongeren (snippet only, not fetched)
- "Fourth Grade Teacher job description Illinois elementary school district posting" → https://k12jobsboard.example/listings/fourth-grade-teacher (snippet only, a generic listing, not this school's)

Fetches: the mission page and the hiring page.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | Three beliefs by name, used for F4, F5 and D1 to D3; no values cheat sheet, because no loop source names a values round |
| 2. Orrinsford interview process, teaching | yes | Loop structure: one 45-minute building panel; persona weights follow it |
| 3. Orrinsford strategy and recent news | yes | C1 and F6 from the board's literacy plan, via a snippet only |
| 4. Interviewer footprint | yes | The interviewer read, via a snippet only; no names for the two team members, so no query for them |
| 5. Representative fourth-grade JD | yes | Role-family wording of F3 and F7 only; nothing quoted, because only a snippet came back |

## Upgrade menu

- The job posting for this position → F3, F7 and the JD-typed questions move from `[inferred]` and `[generic]` to `[grounded]`, and F8-style requirements get quoted wording
- What HR said about the panel's focus, or whether to bring something such as a sample lesson → a build section for any declared deliverable, and persona weights keyed to named focus areas
- The two team members' names → the interviewer read for them and a reverse question tied to their paths
- Your own answers to the slots at F4, F5 and F8, in your own words → those rows upgrade, and A-to-D guidance can map a story
- A printout of your license record from the state's licensing system → F1 moves from `medium` to `high`
- A sample of the weekly family email, or the reading club's schedule → F5 and F4 move from `medium` to `high`
- The board's literacy plan page, pasted → C1 rests on the page, not a snippet
- A deeper research pass: the strategy brief, the principal's talks and writing, role-family loop reports and recent organization context, with up to 6 more searches and 2 more fetches, several more minutes → say so and I'll run it
- A `tuesday-dossier.md` from an earlier evidence review, if you have one → verified claims and prohibited claims arrive pre-checked; the pack never needs one
