# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
**Round:** 45-minute panel on Thursday. Principal Dolores Vantongeren and two members of the fourth-grade team, per the invitation. The two teachers are not named.
**Built on:** the invitation and your resume text. No job posting was supplied, so role requirements come from a typical posting and are labeled `[inferred]`.

## How to use this pack

- **Personas are how a question is asked. Types are what it scores.** Each bank is one persona, ordered by weight. Question IDs run A to E, then G and H (F is kept for the fit-snapshot rows).
- **Type key:** VAL = behavior against the district's published beliefs. EXP = whether your resume lines survive scrutiny. JD = the role's stated responsibilities. CO = knowledge of the district's current direction. CASE = a live problem set in the role.
- **Guidance is scaffolding, not a script.** Say it in your own words. Wherever an answer slot appears, answer from what really happened. Saying plainly that something was not yours, or did not exist, is a complete and honest answer.
- **Highest-ROI prep: A1.** It will be asked in some form. Rehearse it until it is boring.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — invitation | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Your CV shows the gate met. It is a CV line with nothing inspected behind it, so expect it to be checked. State it in the CV's own terms: the license, the elementary endorsement, the 2029 date. The license's registry record would be the inspectable artifact |
| F2 | "Fourth Grade Teacher position" — invitation | "I've never taught fourth grade and I've never been a team lead." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." Then how you would learn the grade, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "plan and teach reading, writing, math, science and social studies" — representative posting, K12 Jobs Board search result | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | discovery | Your CV says third grade, and the posting lists five subject areas. Spoken form at the CV's scope: "For six years I've taught third grade at a public elementary school in Joliet." Answer slot: a typical posting lists these subjects, so a probe on what you taught is likely. If you taught those subjects, say which, in your own words; if some were taught by someone else or not in your classroom, say so plainly and stay with the six years |
| F4 | "differentiate instruction using assessment data" — representative posting, K12 Jobs Board search result | none given | none | [inferred] | discovery | Your material says nothing either way. Answer slot: a typical posting asks for this, so a probe is likely. If you changed how or what you taught based on assessment results, say what the data was and what changed; if you did not, or it was not yours to do, say so plainly and say how you would start |
| F5 | "communicate regularly with families" — representative posting, K12 Jobs Board search result | "I write a weekly email to families." — your CV | medium | [inferred] | none | The quote already reaches the requirement. Lead with it in its own terms, because a named practice beats an adjective: you write a weekly email to families. Expect a probe on it, see G2 |
| F6 | "Families Are Partners: each teacher speaks with every family each term." — Orrinsford Mission and Beliefs page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | Your quote carries the email, and the belief names speaking with families. Your words stay at the email's scope: "I write a weekly email to families." Answer slot: the belief makes a probe on contact beyond the email likely. If you had other contact with families, say what and how often, in your own words; if the email was how you reached them, say so plainly and stay with the email |
| F7 | "work with the grade-level team" — representative posting, K12 Jobs Board search result | "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." — your CV; "I've never taught fourth grade and I've never been a team lead." — your message | medium | [inferred] | presentation | The CV sentence reaches team work in other terms: the move was your grade level's. Spoken form: "I led our grade level's move to a new reading curriculum in 2024." Your message also says you have never been a team lead. Interviewers can set those two side by side, which A2 rehearses |
| F8 | "Every Child a Reader: no student leaves third grade without a reading plan." — Orrinsford Mission and Beliefs page | "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." — your CV | medium | [grounded] | transferability | The curriculum move and the club sit next to the belief and do not reach it. Your words stay at the sentence's scope. Answer slot: the belief makes a probe on how individual readers are supported likely. If you wrote or used reading plans for individual students, say how, in your own words; if you did not, or it was not part of your role, say so plainly and stay with the move and the club |

## Reading the interviewer

Public professional footprint only. The two teachers are unnamed, so there is no read on them.

| Public fact | Source | Provenance | What it suggests for prep |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022 | Illinois Principals Forum speaker page | [grounded] | The panel's lead voice sits at the building level, so the fourth-grade gap in F2 will meet her directly. Weights Skeptic up |
| Nine years as a reading specialist before that | Illinois Principals Forum speaker page | [grounded] | Reading questions are likely to go deeper than usual. Banks C1, D2, E1 and G1 are the rehearsal |
| 2025 forum talk, Small Groups, Big Readers, on weekly reading conferences in grades 3 to 5 | Illinois Principals Forum speaker page | [grounded] | A probe on how reading time is structured is plausible. Your material says nothing about reading conferences or small groups, so claim neither; if asked, answer from what is true and say so plainly if it was not your practice |
| Mirror opportunity: reading is shared professional ground | Her path above; your sentence in F7: "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | [grounded] | Use your own sentence when reading comes up, at its own scope. There is no shared career jump here, since her move was from specialist to principal and yours is from third grade to fourth, so none is offered |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | The principal and teammates probe the fourth-grade gap and the team-lead gap | high: your own message names both limits (F2), and the principal fills the hiring-manager seat, whose prior is Case plus Skeptic | Rehearse A1 until it is boring. Say the limit in your own words first, then hold on what F3 and F7 quote, never adding to them |
| Peer Evaluator | The two fourth-grade teachers ask about working beside them, credit and disagreement | high: two peers on a 45-minute panel, and the peer prior is Peer Evaluator plus Prober | Reciprocity framing: what you offer their team as well as what you need. Offer working principles, not claims to know their seam. See B1 to B4 |
| Case/Strategist | Live classroom or reading-plan problems, framed in the district's own language | medium: the principal's hiring-manager prior, plus a reading-heavy public footprint and a published literacy plan | Clarify, then objective, approach, check-ins, risks. Think aloud. See C1 to C3 |
| Conversational/Rapport | Opening "walk us through your journey" and casual reading questions | medium: panels commonly open this way, and casual questions are still scored | A 90-second arc built only from your quoted lines. See D1 to D3 |
| Values/Behavioral | Prompts built on the three published beliefs | medium: the district page says its beliefs guide every hire, but no values round is documented, so it is not rated high | Story from your quoted lines where one carries it; a selection scaffold with an honest branch where none does. See E1 to E3 |
| Data-Driven Prober | Short resume lines examined for scope and how you know | low: second-ranked for the two teachers, but a short resume leaves little to probe | Know what each line does and does not say, and say plainly where you do not know. See G1 and G2 |
| Pressure/Stress | Time-boxed "why you" and "how much was you" | low: neither the invitation nor the principal's footprint signals it | Pause, restate, hold on your own sentences through two follow-ups, concede specifically. See H1 and H2 |

## Question banks

### A. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade for six years and you haven't taught fourth. What makes you ready for this classroom?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I've never taught fourth grade and I've never been a team lead." | The highest-ROI rehearsal in this pack. Pause, restate, then say the limit first in your own words: "I've never taught fourth grade." Then the six years, at the sentence's scope: "For six years I've taught third grade at a public elementary school in Joliet." Answer slot: say what you expect to carry over from third grade and what you expect to be new in fourth, in your own words; if you have not yet looked at fourth-grade expectations, say so plainly and say how you would learn them in your first weeks, as a plan. Hold through two follow-ups by returning to those two sentences, never by adding a claim of fourth-grade work. Concede specifically: you cannot speak from fourth-grade classroom experience | F2 is the biggest gap and the one this panel is built to test, so this objection arrives in some form; JD because it scores the stated role |
| A2 | "You led your grade level's move to a new reading curriculum, but you haven't been a team lead. What is the difference?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." "I've never taught fourth grade and I've never been a team lead." | Both sentences are yours, so use both at their own scope: "I led our grade level's move to a new reading curriculum in 2024," and "I've never been a team lead." Answer slot: say what your part of the move was, in your own words; if it was narrower than the word led suggests to someone hearing it cold, say so plainly and stay with what the move was. Do not define the difference by describing what a team lead does, because that is a role you have not held | F7 sets these two sentences side by side, so the seam is the likeliest follow-up; EXP because it tests attribution |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [inferred] "I've never taught fourth grade and I've never been a team lead." | Pick from what your own sentence names: "I've never taught fourth grade." Then give a first-weeks plan, as a plan. Answer slot: a typical posting lists reading, writing, math, science and social studies; if any of those is one you have taught less, say which, in your own words; if none, say so plainly | F2 and F3 are the weak spots; the question is a stock Skeptic stem, labeled inferred because the posting is typical, not this team's |
| A4 | "A typical posting for this role asks you to differentiate instruction using assessment data. What have you done with assessment data?" | JD | [inferred] | Answer slot: if you used assessment results to change how or what you taught, say what the data was and what changed; if you did not, or it was not yours to do, say so plainly and say how you would start. The guidance makes no claim about your past, because nothing in your material speaks to it | F4 is silent, so this is where a probe finds nothing to hold; the slot's second branch lets the premise be false |
| A5 | "Why fourth grade, and why Halvering, after six years in third grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: give your real reason in one or two sentences; your material does not contain it, and the pack will not write it for you. Name something about Halvering only if it is true for you | A motivation probe sits in every Skeptic's kit; JD is the closest type for why this role |

### B. Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You would join a team that has taught fourth grade longer than you have. How do you work with colleagues who know the grade better?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I've never taught fourth grade and I've never been a team lead." | Say it plainly, then turn to reciprocity: "I've never taught fourth grade," and what you offer is the six years, at its own scope. Propose working principles rather than pretending to know their seam, such as asking what they would want you to learn first. Answer slot: if there is anything specific about third grade you could share with them, say what, in your own words | F2 is what the peers will weigh; they are pricing what the hire adds to their load |
| B2 | "Tell us about a time you disagreed with a colleague about how to teach something and how it ended." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a position you held, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard peer stem on disagreement style; generic because it needs no claim about your past |
| B3 | "How do you handle credit when work spans the team?" | VAL | [generic] | Selection scaffold: a time work was shared, what you said about whose part was whose, and how the others heard it. If none comes to mind, say so plainly and say how you would handle it. Where the grade-level move comes up, keep its credit at the sentence's own scope, "our grade level's move" | Credit-sharing probes are the peer stem for attribution honesty, and F7 holds the word led |
| B4 | "What would you need from us in your first month, and what could you do that would help the team?" | JD | [generic] | Name two or three things you would ask about, such as pacing, shared materials or assessments, and offer to take on something small the team would pick. The reciprocity half matters as much as the ask | The reciprocity question, prepared so the slot is never answered with nothing to say |

### C. Case/Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "It is October. A fourth grader reads well below the rest of the class. Walk us through your first two weeks." | CASE | [generic] | Clarify first: what assessment information already exists, who else supports reading, what the school expects of a reading plan. Then structure: observe and listen, a small number of checks, a plan with a check-in date, and how the family hears about it. Think aloud and challenge one premise respectfully. The case needs no claim about your past, so the guidance makes none | F8 raises reading plans, and the principal's public background makes a reading case likely; CASE because it is a live problem |
| C2 | "A parent writes that their child says reading is boring. How do you respond, and what do you do next in class?" | CASE | [generic] | Reply promptly and warmly, ask what the child says boring means, plan one change and a follow-up date, and say what you will tell the parent next. No claim about your past | F6 raises families as partners; CASE because it is a decision, not a record |
| C3 | "The board adopted a literacy plan in August, with a new grades 3 to 5 reading curriculum from fall 2027. How would you approach being part of that change as a new member of this team?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | Clarify first: the timeline, who decides what, what the current curriculum is. Then structure the approach. If you bring in your own sentence, keep its scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if anything about how that move went would change how you would begin this one, say what, in your own words; if nothing would, say so plainly | The district's published plan is a current fact, and this question tests whether you can think at the district's altitude; CO with CASE delivery |

### D. Conversational/Rapport (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk us through your journey to this application." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." "I write a weekly email to families." | A 90-second arc with four beats, each a clause the quotes state: six years teaching third grade at a public elementary school in Joliet; the grade level's move to a new reading curriculum in 2024; the after-school reading club for two years; the weekly email to families. Answer slot: say your real reason for fourth grade now, in your own words; name something about Halvering only if true | The opening biography question is the one every panel asks; EXP because it is scored on whether the arc matches your lines |
| D2 | "Tell us about the reading club." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | Beats are the ones the sentence states: it is after school, you run it, for the last two years. Answer slot: the Every Child a Reader belief makes a probe on what happens in a session likely. If you have a structure for sessions, say it in your own words; if there is not one, say so plainly and describe what the club is | The club is F7's second clause and sits closest to the principal's reading background |
| D3 | "What are you reading these days that you would put in a fourth grader's hands?" | JD | [generic] | Choose a real title you know well. If none comes to mind, say so plainly and say how you would choose one. No claim about your past | A casual question on the role's central subject; casual questions are scored |

### E. Values/Behavioral (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Orrinsford's first belief is Every Child a Reader. Tell me about a time you helped a struggling reader move forward." | VAL | [grounded] | Selection scaffold: a situation with a named kind of student (no names), what you noticed, what you tried, and how you knew whether it worked. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The belief is published on the district page, a raising source; F8 is the row it draws on |
| E2 | "Orrinsford's belief is Families Are Partners. Tell me about your communication with families." | VAL | [grounded] "I write a weekly email to families." | Start at the sentence: "I write a weekly email to families." Answer slot: the belief makes a probe on contact beyond the email likely. If you had other contact with families, say what and how often, in your own words; if the email was how you reached them, say so plainly | F6 is where the belief outruns the evidence |
| E3 | "Orrinsford's belief is Teach for Tomorrow, Not for the Test. Tell me about a time assessment results and your own judgment about a student pointed different ways." | VAL | [grounded] | Selection scaffold: what the results said, what you saw yourself, which you followed and why. If no such time comes to mind, say so plainly, then give how you would handle it | F4 is silent on assessment, so the scaffold ends in its honest branch |

### G. Data-Driven Prober (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through the new reading curriculum move you led. How would you describe your part?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | Open with the sentence's own scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: say which parts of the move were yours, in your own words; if a decision came from the school or district rather than your grade level, or your part was smaller than led suggests, say so plainly and stay with what the move was | F7 and F8 draw on this sentence, and a prober examines scope line by line |
| G2 | "You write a weekly email to families. How do you know families read it?" | EXP | [grounded] "I write a weekly email to families." | Answer slot: if you have any sign families read it, such as replies or conversations, say what it is, in your own words; if you do not track it, say so plainly and say what you would do to find out, as a plan | F5's practice is named and checkable, which is where a prober goes |

### H. Pressure/Stress (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over a teacher who has already taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." "I've never taught fourth grade and I've never been a team lead." | Pause, restate. Hold on what you have: "For six years I've taught third grade at a public elementary school in Joliet," and "I led our grade level's move to a new reading curriculum in 2024." Concede plainly: "I've never taught fourth grade." Do not compare yourself with the other candidate. Close on what you would do first, as a plan | F2 under a stopwatch; hold-then-concede is the type's bar |
| H2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | Hold at the sentence: "I led our grade level's move to a new reading curriculum in 2024." Hold through two follow-ups by returning to it, not extending it. Answer slot: say which parts were yours, in your own words; if your part was smaller than led suggests, say so plainly and stay with the move | F7's word led, under pressure |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 license gate | none, and why: the CV shows the gate met, and there is nothing to rehearse beyond stating it in the CV's own terms |
| F2 fourth-grade role | A1, A3, A5, B1, H1 |
| F3 plan and teach the five subjects | A3, D3 |
| F4 differentiate using assessment data | A4, E3 |
| F5 communicate with families | G2, E2, C2 |
| F6 Families Are Partners | E2, C2 |
| F7 work with the grade-level team | A2, B1 to B4, G1, H2 |
| F8 Every Child a Reader | C1, D2, E1 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | To the principal: "You came to this role after nine years as a reading specialist. How does that shape what you look for in a fourth-grade reading block?" | Ties to her own path, from her public speaker page, and moves the conversation to reading practice |
| R2 | To the principal: "Your 2025 forum talk was on weekly reading conferences in grades 3 to 5. What does that look like in a fourth-grade day here?" | Shows you read her published work and turns the gap in F2 into a question about learning the grade |
| R3 | "The board's literacy plan brings a new grades 3 to 5 reading curriculum from fall 2027. How will fourth-grade teachers shape the rollout?" | Uses the district's own published plan and signals interest in the next stretch, not only the job |
| R4 | To the teachers: "What could a new fourth-grade teacher do in the first month that would genuinely help your team?" | The reciprocity question for peers; it shows you are asking what you owe them |
| R5 | "What would you want someone new to fourth grade to have learned by the end of the first term?" | Converts the F2 objection into a ramp conversation, and lets the panel say what the real bar is |
| R6 | "The district's belief says each teacher speaks with every family each term. How does the team do that in practice?" | Taken from the published belief, and invites them to describe the support behind it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having taught fourth grade, including implying it by speaking as if you know the grade from the classroom | Negative you stated, F2 | The plain acknowledgment F2 gives: "I've never taught fourth grade." No slot |
| Having been a team lead | Negative you stated, F2 | "I've never been a team lead." No slot |
| Having led the reading curriculum change beyond your grade level, such as for the school or district | Inflated form of F7 and F8 | F7's quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." The limit is the pack's observation: your material says a grade level's move. G1 and H2 keep the slot inside it |
| Speaking with every family each term | Inflated form of F6 | F6's quote at its own scope: "I write a weekly email to families." The limit is the pack's observation: your material says an email, and the belief says speaking with families. E2's slot stays inside the email |

## Sources

Provided: the invitation from Orrinsford Community School District Human Resources; your resume text and the two statements in your message. No dossier was present.

Searches and fetches, by query:

- Search "Orrinsford Community School District mission values": returned https://orrinsfordschools.example/about/mission-and-beliefs
- Search "Halvering Elementary School Orrinsford principal Dolores Vantongeren": returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
- Search "fourth grade teacher job description Illinois elementary school responsibilities qualifications": returned https://k12jobsboard.example/listings/fourth-grade-teacher (search-result text only, cut off mid-sentence, so only its listed responsibilities are quoted)
- Search "Orrinsford Community School District news strategic plan 2026": returned https://orrinsfordschools.example/news/board-adopts-literacy-plan (search-result text only)
- Fetch https://orrinsfordschools.example/about/mission-and-beliefs: returned the three beliefs
- Fetch https://ilprincipalsforum.example/speakers/dolores-vantongeren: returned the principal's public bio

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District values` | yes | The three beliefs by name; they raise questions in bank E and rows F6 and F8. No values round is documented in any source, so there is no values cheat sheet |
| 2. `Orrinsford interview process elementary teacher` | skipped | The invitation fixes the loop: one 45-minute panel, the principal and two fourth-grade team members. Persona weights follow that |
| 3. `Orrinsford Community School District strategy` / recent news | yes | The August 2026 literacy plan; it moved C3 and R3. Only the search-result text was read |
| 4. `Dolores Vantongeren Halvering Elementary` | yes | The interviewer read and R1 and R2. The two teachers are unnamed, so there was no query to form for them |
| 5. representative `Fourth Grade Teacher` JD | yes | Requirements for F3, F4, F5 and F7, labeled `[inferred]`. The page was not fetched, only its search-result text |

## Upgrade menu

- The full job posting → the `[inferred]` rows F3, F4, F5 and F7 become `[grounded]`, and the requirement-coverage table is re-checked against the posting's own list
- The names and roles of the two fourth-grade teachers → an interviewer read and persona weights for each, instead of round-type priors
- Anything HR said about the panel's focus or a task to prepare, such as a sample lesson → a build section if a deliverable was announced, and coverage weighted to the focus
- Your answers to the slots in F3, F4, F6, F8 and the club in D2, said outside a drill → those rows are regenerated with your own words as evidence
- Your license's registry record, if you can pull it up → F1 confidence rises from medium
- How much prep time you have before Thursday → a prioritized prep schedule
