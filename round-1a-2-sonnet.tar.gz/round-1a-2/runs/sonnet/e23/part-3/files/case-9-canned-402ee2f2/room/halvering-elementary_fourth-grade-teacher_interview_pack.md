# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Employer:** Orrinsford Community School District. **Round:** one 45-minute panel on Thursday. **Panel:** Principal Dolores Vantongeren and two members of the fourth-grade team (names not given). **Built on this assumption:** the principal sits in the hiring-manager seat and the two team members sit in the peer seat, because the invite does not say who will supervise the role.

## How to use this pack

Personas are how a question is asked. Types are what it is scored on. Every question carries both, so you can see coverage at a glance. The answer guidance is scaffolding for a spoken answer, not a script. Wherever it quotes you, the quote is what your own material says, and the guidance stays inside it.

| Type | What it is really testing |
|---|---|
| VAL | Whether your past behavior shows the district's published beliefs |
| EXP | Whether the claims on your résumé survive follow-up questions |
| JD | The stated requirements of the position |
| CO | Homework on Halvering, the district and its current plans |
| CASE | A live problem set in the role, answered aloud |

Question IDs run by persona: A (Skeptic), B (Peer Evaluator), C (Case/Strategist), D (Values/Behavioral), E (Conversational), G (Data-Driven Prober). The letter F is skipped so it cannot be confused with the fit-snapshot rows F1 to F7.

**Highest-ROI prep in this pack: A1.** The position title and your own statement that you have never taught fourth grade meet there, so it will be asked in some form. Rehearse it until it is boring, then do A3.

## Fit snapshot

Requirements are quoted only from the invite and from the district's published beliefs page. Where a requirement is plain prose with no quotation marks, it is a role-family pattern with no source, and it raises no answer slot.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | This is a gate, and your CV already states it in the invite's own terms. It is a CV line with nothing inspected behind it, so expect it to be checked. Say it as written: Illinois Professional Educator License, Elementary Education (grades 1–6) endorsement, active through June 30, 2029. The pack's observation: the quoted endorsement range, grades 1 to 6, includes fourth grade |
| F2 | "Fourth Grade Teacher position at Halvering Elementary School" — the invite | "Six years teaching third grade at a public elementary school in Joliet." — your CV; "I've never taught fourth grade and I've never been a team lead." — your CV | medium | [grounded] | transferability | Your material carries an adjacent grade at its own scope: six years of third grade at a public elementary school in Joliet. The gap is one you stated, so the plain acknowledgment is yours to say: "I've never taught fourth grade." Any step from third grade to fourth is an answer slot: the position is for fourth grade, so expect a probe on what differs between the two. If you know specific differences, name them in your own words; if you do not, say so plainly and say what you would ask the team in your first week |
| F3 | Works with the grade-level team (role-family pattern, no source) | "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." — your CV; "I've never taught fourth grade and I've never been a team lead." — your CV | medium | [generic] | transferability | Both sentences stay exactly as you wrote them: you led your grade level's move to a new reading curriculum in 2024, and you have never been a team lead. The pack's observation: a panel that includes two team members will hear those two lines side by side, so say them together and add no title to the first. The requirement is a pattern, so no slot is raised here; A3 and B3 hold the follow-ups |
| F4 | "each teacher speaks with every family each term" — the district's Mission and Beliefs page, under Families Are Partners | "I write a weekly email to families." — your CV | medium | [grounded] | discovery | An email to families touches the belief without showing whether it reaches speaking with families. Say the sentence at its scope: you write a weekly email to families. Answer slot: the belief says each teacher speaks with every family each term, so expect a probe on direct conversations. If you spoke with families directly, say when and how, in your own words; if you did not, or it was not part of your role, say so plainly and stay with the weekly email |
| F5 | "no student leaves third grade without a reading plan" — the district's Mission and Beliefs page, under Every Child a Reader | "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." — your CV; "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [grounded] | discovery | Your sentences touch reading and third grade without showing whether they reach a reading plan for each student. Keep the club and the six years of third grade at their own scope. Answer slot: the belief mentions reading plans, so expect a probe on them. If you wrote or used reading plans for students, say how, in your own words; if there were none, or they were not yours, say so plainly and stay with the club and the third-grade years |
| F6 | "assessments inform teaching and never replace it" — the district's Mission and Beliefs page, under Teach for Tomorrow, Not for the Test | none given | none | [grounded] | discovery | Your material does not establish this either way. Answer slot: the belief is the district's own words, so expect a probe on how you use assessment results. If you used results to change what you taught, say what changed and how you knew, in your own words; if you did not, or the choices were made elsewhere, say so plainly, then say what you would look at first in a new class |
| F7 | Teaches across the elementary subjects, not only reading (role-family pattern, no source) | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [generic] | discovery | Your sentence gives the grade, the years and the kind of school, and says nothing about which subjects you taught. The pack writes nothing further from it. The words stay: "Six years teaching third grade at a public elementary school in Joliet." Subjects taught go to the upgrade menu |

## Reading the interviewer

Public professional footprint only. The two team members were not named, so nothing was researched about them.

| Item | What is public | What it means for you | Provenance |
|---|---|---|---|
| Career path | Principal of Halvering Elementary since 2022, after nine years as a reading specialist | Reading is her home territory, so expect reading questions to go deeper than a general instruction question would | [grounded] |
| Published talk | 2025 forum talk "Small Groups, Big Readers", on weekly reading conferences in grades 3 to 5 | Small-group reading may come up; C3 rehearses it as a live problem. Do not assume she will ask, and do not claim anything about conferences you have not done | [grounded] |
| Shared vocabulary | Her path and talk are about teaching reading. Your F5 row carries "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | The shared ground is reading instruction. Offer it by saying that sentence, and let her ask where she wants to go. It is not a shared career jump, so it is not offered as one | [grounded] |
| Reverse-question hook | Her path and her talk | R1 and R2 are built on them | [grounded] |

## Persona table

The invite names one session, a 45-minute panel with three people, so the weights below rest on that session and on the relationship priors, not on a fallback pattern. Panels blend the top two personas of each member's relationship.

| Persona | How it shows up here | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 5 questions) | Quiet probing of the two things you stated: no fourth grade, no team lead | Highest. The principal is in the hiring-manager seat, a prior that favors Skeptic, and F2 and F3 are both gaps you stated yourself | Rehearse A1 and A3 until the honest answer is boring. Bridge only from sentences you wrote, and say plainly where they stop |
| Peer Evaluator (bank B, 4 questions) | The two fourth-grade teachers asking what you would bring and need, and where credit goes on shared work | High. Two panel seats are team members, which is the peer prior | Offer what you bring as things you do, ask for what you need as principles, and keep "we" for context and "I" for what you did |
| Case/Strategist (bank C, 3 questions) | Live reading problems from the principal, and the district's new reading curriculum | Medium. The hiring-manager prior includes it, the principal's public reading focus tilts toward it, and the board's literacy plan gives a current topic | Clarify first, then structure aloud, then name one assumption you would check |
| Values/Behavioral (bank D, 3 questions) | Stories tied to the district's three beliefs | Medium. The invite names no values round and no source documents one, so no values cheat sheet is built, but the published beliefs still raise questions | Pick a story only where a sentence of yours carries it; where none does, say so plainly and give the nearest true thing |
| Conversational (bank E, 3 questions) | The opening biography and the licence check, in a friendly register | Low to medium. No signal either way. It is included so the casual register is not met cold, and E3 checks a gate | Treat casual questions as scored; keep the arc to about 90 seconds |
| Data-Driven Prober (bank G, 2 questions) | Follow-up on how you know the club or the curriculum move worked | Low. The peer prior includes it, but your material has no figures to defend | Say plainly what you did and did not track |
| Pressure | Not banked | No signal in the invite or in the principal's public footprint, and neither seat's prior includes it | Not applicable |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your résumé shows third grade. What will be different about teaching fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I've never taught fourth grade and I've never been a team lead." | The highest-ROI rehearsal in this pack. Open with the plain version: "I've never taught fourth grade." Then the adjacent fact at its own scope: six years teaching third grade at a public elementary school in Joliet. Answer slot: expect a follow-up on what differs between the two grades. If you know specific differences, name them in your own words; if you do not, say so plainly and say what you would ask the team in your first week. Hold through two follow-ups by returning to those two sentences, not by adding to them. Concede specifically what you have not done, and do not offer third grade as proof that it transfers; let them draw that line | F2 is the position title meeting your own stated gap, so this arrives in some form. JD because it scores the stated position; Skeptic because it presses on the known gap |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." | Choose the weakness your own sentence already names, which is fourth grade, and say it plainly: "I've never taught fourth grade." Then give one first step as a plan in the future tense, such as what you would ask the team, with no claim about the past. Answer slot: if a second weakness comes to mind that your material does not show, say it in your own words; if none does, say so plainly and stay with the first | F2 supplies the honest answer. A candidate who names it first is not found out by it. JD tag because the stem scores self-assessment against the job; Skeptic stem |
| A3 | "You led your grade level's move to a new reading curriculum. Were you the team lead?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years."; "I've never taught fourth grade and I've never been a team lead." | Answer the question asked, in the sentences you wrote: you led your grade level's move to a new reading curriculum in 2024, and you have never been a team lead. Say both and stop; do not explain the difference with a practice you have not named. Answer slot: if they ask what leading the move covered, say in your own words what you did and what you did not; if a part of it was not yours to run, or there was nothing you would call a process, say so plainly and stay with the sentence. Hold through two follow-ups by repeating the two sentences, and concede any detail you do not remember | F3 puts both sentences side by side, which is where an attribution probe lands. EXP because it tests what was actually yours |
| A4 | "Why you for this position, given you haven't taught this grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years."; "I write a weekly email to families."; "I've never taught fourth grade and I've never been a team lead." | A 60-second answer. Lead with the plain acknowledgment, "I've never taught fourth grade", then three facts at their own scope: six years teaching third grade; you led your grade level's move to a new reading curriculum in 2024 and have run the after-school reading club for the last two years; you write a weekly email to families. Do not rank yourself against other candidates. Answer slot: your reasons for wanting fourth grade in particular are yours; say them in your own words, and if the main reason is simply that you want a new grade, say so plainly. Hold through two follow-ups and concede specifically what you do not yet know | F2 and F3 together are the case the panel will weigh; this is the 60-second form of the same objection. JD because it scores the position; the time box is Pressure-style delivery inside a Skeptic bank |
| A5 | "Why Halvering, and why now?" | CO | [grounded] | No claim about your past is made here. Build it from reasons that are true for you, and ground one in something published: the district's three beliefs by name (Every Child a Reader, Families Are Partners, Teach for Tomorrow, Not for the Test), or the board's adopted literacy plan (see Sources). Pick the one that is true for you rather than the one that sounds best. If no clear reason comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The invite does not say why you applied, so the pack cannot supply a reason; it supplies a structure. CO because it scores homework on Halvering; Skeptic stem on motivation |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You'd be joining our team. What could you bring us, and what would you need from us?" | JD | [grounded] "I've run the after-school reading club for the last two years."; "I write a weekly email to families."; "I've never taught fourth grade and I've never been a team lead." | Reciprocity first. What you bring, as things you do: you have run the after-school reading club for the last two years and you write a weekly email to families; offer them, and do not assume the team wants them. What you need, as principles: you have never taught fourth grade, so you would ask the team how they plan together and what they have found works for this grade. Keep the need short and specific | F3 is the team-working row; the peer prior makes this the opening peer question. JD because it scores the position's team fit |
| B2 | "When work spans our team, how do you handle credit?" | VAL | [generic] | No claim about your past is made here. Pick a time work was shared, and say who was involved, what each person did including you, and how credit was spoken aloud. Use "we" for the context and "I" for your own part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The peer persona's credit stem, offered as an open prompt because nothing in the invite or your material raises a specific occasion. VAL because it scores behavior, not a stated requirement |
| B3 | "Walk us through the move to a new reading curriculum at your grade level." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | The beats your sentence states: a new reading curriculum, your grade level's move to it, 2024, and that you led it. Tell those in your own words. Answer slot: expect follow-ups on how the move went from start to finish. Say what you did at each step you remember and which steps were not yours; if there was no particular sequence, or a step was not yours, say so plainly and stay with the sentence | F3 holds the sentence, and the move is the most concrete thing on your résumé, so it is the likeliest walk-through. EXP because it tests what was actually yours |
| B4 | "Tell us about the reading club you run." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | The beats your sentence states: you run it, it is after school, and you have run it for the last two years. Answer slot: expect probes on who comes and what they read. Say what you know in your own words; if you do not have that detail, or it was not tracked, say so plainly and stay with the sentence | F5 is where reading and your club meet the district's belief on reading. EXP because it tests what you actually do |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The board's literacy plan brings a new grades 3–5 reading curriculum from fall 2027. If you joined the fourth-grade team, what would you want to know first, and how would you plan your first term with it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | Structure it aloud: what you would ask first (what the curriculum is, what the team has already decided, the timeline), the objective for the first term, your approach, what could go wrong, and one assumption you would check. If you mention your own sentence, give it at its scope, that you led your grade level's move to a new reading curriculum in 2024, and do not present it as the same as the board's rollout. The plan's details come from a search snippet; if the panel describes it differently, go with theirs | A current-strategy question, sourced in Sources, row 3 of the research accounting. CO for the strategy hook, CASE in delivery; F3 holds the sentence you may mention |
| C2 | "A fourth grader is reading well below the rest of the class in the first month. Walk us through what you would do." | CASE | [generic] | No claim about your past is made here. Clarify first: what the student has read, what earlier teachers know, what the family has noticed. Then the objective, how you would look at the reading, how you would plan, how you would tell the family, and when you would check again. Think aloud and name one assumption you would test | A live problem set in the role. Every Child a Reader makes it plausible and Halvering's principal comes from reading, but the pack makes no claim about this panel beyond that |
| C3 | "How would you plan weekly small-group reading time for a class of fourth graders who read at different levels?" | CASE | [grounded] | No claim about your past is made here. Clarify first: how many groups, how long, what you already know about each reader. Then structure it: grouping, what each group reads, how you check progress, how groups change. Think aloud. Do not claim reading conferences you have not held | Built on the theme of the principal's published talk (Reading the interviewer). CASE because it is a live problem; the pack does not assume she will ask it |

### D. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you helped a student reach the reading level they needed." | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | Selection criteria, since none of your sentences carries a student story: pick a time with a named stake (a student and a reading need), what you personally did, how it ended, and what you would change. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is that you have run the after-school reading club for the last two years, at that scope and with no outcome added | Raised by the district belief Every Child a Reader. F5 holds what you have that touches it. VAL because it scores behavior against a published belief |
| D2 | "Tell me about a time you worked with a family to support their child." | VAL | [grounded] "I write a weekly email to families." | Say the sentence at its scope: you write a weekly email to families. Answer slot: the district says each teacher speaks with every family each term, so expect a probe on direct conversations. If you worked with a family directly, say what happened and which part was yours; if you did not, say so plainly and stay with the weekly email | Raised by Families Are Partners. F4 is the row. VAL because it scores behavior against a published belief |
| D3 | "Tell me about a time assessment information changed how you taught." | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Selection criteria, since none of your sentences speaks to assessment: pick a time with a named stake, what the information showed, what you changed, and how you knew it helped. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is six years teaching third grade at a public elementary school in Joliet, and say what you would look at first in a new class | Raised by Teach for Tomorrow, Not for the Test. F6 has no evidence, so the whole answer is a scaffold. VAL because it scores behavior against a published belief |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey: how did you get to teaching, and to this application?" | EXP | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029"; "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years."; "I write a weekly email to families." | A 90-second arc with beats from your own sentences: your Illinois Professional Educator License with the Elementary Education endorsement; six years teaching third grade at a public elementary school in Joliet; leading your grade level's move to a new reading curriculum in 2024 and running the after-school reading club for the last two years; writing a weekly email to families. Answer slot: the last beat, why fourth grade at Halvering, is yours; say it in your own words, and if the main reason is simply that you wanted a new grade, say so plainly | F1 to F4 are the arc. EXP because it is the biography question, which is scored like any other |
| E2 | "What are you excited about in teaching reading right now?" | JD | [generic] | No claim about your past is made here. Pick one specific thing you really care about and say why, in your own words, and tie it to something the panel has said. If nothing comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Treat it as scored | The conversational stem on a hot topic of the role, which is reading. JD because reading is the district's first belief |
| E3 | "Before we start, can you confirm your licence and endorsement?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Confirm it in the quote's own terms: Illinois Professional Educator License, Elementary Education (grades 1–6) endorsement, active through June 30, 2029. Have your licence details to hand and add nothing else | F1 is a gate your CV shows met; the invite states it as a requirement, so a quick confirmation is likely |

### G. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Your reading club has run for two years. How do you know it is working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | Say what the sentence says: you have run the after-school reading club for the last two years. Answer slot: the district's belief that assessments inform teaching raises this probe. If you looked at anything to judge how the club was going, say what and how it was counted, in your own words; if you did not track anything, say so plainly and stay with the sentence | F5 and F6 meet here. EXP because it tests whether the claim survives a follow-up |
| G2 | "The district says assessments inform teaching and never replace it. What does that look like in your classroom?" | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: if you used results to change what you taught, say what changed and how you knew, in your own words; if you did not, or the choices were made elsewhere, say so plainly, then stay with your six years teaching third grade at a public elementary school in Joliet and say what you would look at first in a new class | F6 has no evidence. VAL because the belief is published; the Prober delivery asks for the detail behind it |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1: licence with elementary endorsement | E3, E1 |
| F2: the Fourth Grade Teacher position | A1, A2, A4, C2, C3 |
| F3: works with the grade-level team (pattern) | A3, B1, B3 |
| F4: Families Are Partners | D2 |
| F5: Every Child a Reader | D1, B4, G1, C2 |
| F6: Teach for Tomorrow, Not for the Test | D3, G2 |
| F7: teaches across the elementary subjects (pattern) | none, and why: the pattern has no source and your material names no subjects, so a question would be written on nothing; the upgrade menu asks for the posting |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You spent nine years as a reading specialist before becoming principal. How does that shape what you want a fourth-grade reading block to look like?" | It asks about her own path and ties it to the job | [grounded] |
| R2 | "Your talk on small groups and weekly reading conferences covered grades 3 to 5. What does that look like in a fourth-grade room at Halvering today?" | It asks about the work in her talk, in her own vocabulary | [grounded] |
| R3 | "The board's literacy plan brings a new grades 3–5 reading curriculum from fall 2027. How is the fourth-grade team preparing, and where would a new teacher be most useful?" | It uses a current plan and asks where you can help, not only what you need | [grounded] |
| R4 | "What could a new fourth-grade teacher do in their first month that would genuinely help your team?" | The reciprocity question for the two team members: it asks what helps them | [generic] |
| R5 | "The district's Families Are Partners belief says each teacher speaks with every family each term. What does that look like in practice at Halvering?" | It uses the district's own words and asks for the practice behind them | [grounded] |
| R6 | "How does the fourth-grade team plan together week to week?" | It asks how the team works, which is the thing you would be joining | [generic] |
| R7 | "What would you want to see from me by the end of the first semester?" | It asks what success looks like, in a form that is easy to answer | [generic] |

## Prohibited claims

Claims this pack will not coach, and why. Each has its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated: "I've never taught fourth grade and I've never been a team lead." | The plain acknowledgment: "I've never taught fourth grade." A1 and A2 give it, and A1's slot stays on what you would ask the team |
| Has been a team lead | A negative you stated, in the same sentence | The plain acknowledgment: "I've never been a team lead." A3 holds it beside the sentence that you led your grade level's move |
| Led the school's or the district's reading curriculum adoption | Inflated form of "I led our grade level's move to a new reading curriculum in 2024" | That sentence at its own scope. The limit is the pack's observation: your material says your grade level's move, not a school-wide or district-wide one |
| The reading club raised students' reading | Inflated form of "I've run the after-school reading club for the last two years" | That sentence at its own scope. The pack's observation: your material says you run the club and for how long, and says nothing about outcomes. G1's slot asks only what you tracked |
| Speaks with every family every term | Inflated form of "I write a weekly email to families." | That sentence at its own scope. The pack's observation: your material says a weekly email, not conversations. D2's slot stays inside the email |

## Sources

Provided documents: the interview invite as pasted; your résumé text as pasted (the personal-details line at the end was not used, and the licence identifier was left out of the quotes).

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District Halvering Elementary School mission values` | yes | The three published beliefs by name, F4 to F6, and the VAL questions D1 to D3 and G2. No values cheat sheet, because no loop source documents a values round |
| 2. `{company} interview process {role family}` | skipped | The invite fixes the loop: one 45-minute panel with the principal and two fourth-grade team members. Persona weights follow from that |
| 3. `{company} strategy` / recent news | yes | One result: the board's literacy plan, which feeds C1, A5 and R3. It is a search snippet only; the page was not fetched |
| 4. `{interviewer name} {company}` | yes | Principal's path and talk theme, which feed Reading the interviewer, C3, R1 and R2 |
| 5. representative `{role title}` JD | yes | One truncated search snippet and nothing quoted from it; it moved nothing in the quoted rows. The two role-family requirements, F3 and F7, are plain prose labeled generic |

Searches and fetches, by query:

- `Orrinsford Community School District Halvering Elementary School mission values` returned https://orrinsfordschools.example/about/mission-and-beliefs
- `Dolores Vantongeren principal Halvering Elementary` returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
- `Orrinsford Community School District strategic plan news` returned https://orrinsfordschools.example/news/board-adopts-literacy-plan
- `fourth grade teacher job description Illinois elementary school district posting` returned https://k12jobsboard.example/listings/fourth-grade-teacher
- Fetch of https://orrinsfordschools.example/about/mission-and-beliefs returned the three beliefs and a one-line definition of each
- Fetch of https://ilprincipalsforum.example/speakers/dolores-vantongeren returned the principal's biography and the talk description

## Upgrade menu

- The full text of the posting → F3 and F7 become quoted, grounded rows, and every listed duty gets a covering question
- What HR said about the panel's focus, or any task you were asked to prepare, such as a sample lesson → a graded-deliverable build section if one was declared
- Your answers to the answer slots in F2, F4, F5 and F6 → those rows regenerate with your own quoted words, and the questions that draw on them tighten
- The subjects you taught in third grade → F7 gets a quoted evidence cell
- A printout of your licence record → F1 confidence moves from medium to high
- The names of the two team members → persona weights read per member and a tailored reverse question, from public professional footprint only
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on the district's literacy plan and a fuller read of the principal's talks
- A tuesday-dossier.md from an earlier evaluation of this job → a verified-evidence list and an evidence-derived top objection in place of the inferred one
