# Interview pack: Fourth Grade Teacher, Halvering Elementary School

**Employer:** Orrinsford Community School District
**Round:** 45-minute panel on Thursday with Principal Dolores Vantongeren and two members of the fourth-grade team (names not given)
**Built on:** the invite and your resume as pasted, plus L1 research (see Sources). No posting text was supplied, so rows about the role's duties rest on a representative listing and are labeled `[inferred]`.

## How to use this pack

- **Personas are how a question arrives; types are what it scores.** Rehearse the persona style as well as the content.
- **Types:** VAL = values or behavior, EXP = what your experience actually shows, JD = the role as posted, CO = knowledge of the district, CASE = a live problem.
- **Guidance is scaffolding, not a script.** Say it in your own words. Wherever a cell says answer slot, it is an instruction for the interview: answer from your real experience, or say plainly that the thing was not yours or did not exist.
- Question IDs skip the letter F so they never collide with the fit rows F1 to F7.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The gate is shown met in your CV's own words, with no license record inspected behind it. Say it in the quote's terms: the license, the elementary endorsement, active through June 30, 2029. A gate asks nothing, so there is no answer slot |
| F2 | "Fourth Grade Teacher position" — invite | "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [grounded] | transferability | Words: "I've never taught fourth grade." Then the six third-grade years at their own scope, never stretched into fourth-grade experience. Then a plan, said as a plan and never as a past: what you would ask the team and look at first. Answer slot: the invite puts two fourth-grade team members on the panel, so expect a probe on what changes between third and fourth grade. If you have already looked at what changes, say what you found and where you saw it; if you have not, say so plainly and name the first thing you would ask the team |
| F3 | Plan and teach the core subjects of a fourth-grade classroom — representative listing on k12jobsboard.example, seen as a search snippet, not this district's posting | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [inferred] | discovery | Your material says third grade, not which subjects you taught. A snippet for another employer raises no answer slot, so C1 and C3 test planning as live problems with no claim about your past. The upgrade menu says what would close this row |
| F4 | "assessments inform teaching and never replace it" — district Mission and Beliefs page | none given | none | [grounded] | discovery | Your material is silent on how assessment shaped your teaching. Answer slot: the district states this belief, so expect a probe on how results shaped your work. If results ever changed what you taught or how you taught it, say what and how, in your own words; if they did not, or that was not yours to decide, say so plainly and say what you would look at first in a new class |
| F5 | "each teacher speaks with every family each term" — district Mission and Beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | The belief names speaking; your sentence names a weekly email, and your material does not say you also speak with families. Words: "I write a weekly email to families." Answer slot, inside the email's scope: if families have responded to the email, say what you did with that; if none have, or it was not yours to act on, say so plainly and stay with the email |
| F6 | "no student leaves third grade without a reading plan" — district Mission and Beliefs page | "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Adjacent reading work, none of it reaching a plan for each student. Words: the three sentences at their own scope. Answer slot: the belief names a reading plan, so expect a probe. If students at your school had reading plans and you wrote or used them, say how, in your own words; if there was no such plan, or it was not yours, say so plainly and return to the curriculum move or the reading club |
| F7 | Work with the grade-level team — representative listing on k12jobsboard.example, seen as a search snippet; the invite also seats two fourth-grade team members on the panel | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [inferred] | transferability | Both sentences stand together, each at its own scope, and neither is reworded to fit the other. Answer slot, inside the move: the panel includes two fourth-grade teammates, so expect a probe on how the move worked across your grade level. If colleagues took part with you, say how you worked with them and which part was yours; if they did not, or the move was shared, say so plainly and return to the quote |

## Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| F1 license gate | — none, and why | The material shows the gate met, so a gate asks no rehearsed answer beyond saying it in the quote's terms |
| F2 Fourth Grade Teacher position | A1, A2, A4, A5, H1 | A1 is the highest-ROI rehearsal in the pack |
| F3 core subjects | C1, C3 | Both are live problems; no question covers math, science or social studies, because only a snippet of another employer's listing names them and the invite names no subject mix |
| F4 assessment informs teaching | C1, D2, G2 | |
| F5 families | E2 | |
| F6 reading plan | G1, C1 | |
| F7 grade-level team | A3, B1, B2, B3, D1, H2 | |

## Persona table

Weights follow a panel: the principal's relationship carries the hiring-manager prior (Case/Strategist and Skeptic) and the two fourth-grade teammates carry the peer prior (Peer Evaluator and Data-Driven Prober), then adjusted by what is public about the principal. If you know something that changes this, reweight it yourself.

| Persona | Bank (questions) | Likelihood | Reasoning shown | How it shows up | Counter-strategy | Provenance |
|---|---|---|---|---|---|---|
| Skeptic | A (5) | high | Your message states "I've never taught fourth grade" and the invite's title is "Fourth Grade Teacher position" (F2); the hiring-manager prior includes the Skeptic | Quiet, persistent questions on grade level, motive and the team-lead gap | Rehearse A1 until it is boring: concede in your own quoted words, hold the third-grade years at their scope, give a plan | [inferred] |
| Case/Strategist | C (3) | medium | Hiring-manager prior; the principal's public work centers on reading (see Reading the interviewer), which tilts the cases toward reading | A live classroom problem, then a question about the district's reading plans | Clarify, objective, approach, how you would check, risks; think aloud | [inferred] |
| Peer Evaluator | B (3) | medium | The invite seats two fourth-grade teammates on the panel: "two members of our fourth-grade team" | Collaboration scenarios, credit, what you would bring them | Reciprocity first; propose principles for the seam rather than pretending to know it | [inferred] |
| Data-Driven Prober | D (3) | medium | Peer prior; your resume carries no figures to defend, so the probing lands on your stories instead | Walk-throughs of the curriculum move, the club and how you knew things worked | Know what you can say about each sentence and say plainly where your knowledge stops | [inferred] |
| Conversational | E (3) | medium | Any panel opens somewhere friendly; casual questions are still scored | Biography, the weekly email, what you are reading about | A 90-second arc built from your own sentences | [generic] |
| Values/Behavioral | G (2) | low | The district page says three beliefs guide every hire, but no source read describes a values round, so no values cheat sheet is built; the beliefs only theme these two questions | A prompt using the district's belief names | Pick real moments, or say plainly that none comes to mind | [inferred] |
| Pressure | H (2) | low | No signal either way; the two questions rehearse the one place two of your sentences press on each other | Time-boxed challenge, "how much was you" | Pause, restate, hold the quoted facts through two follow-ups, concede specifically | [generic] |

## Reading the interviewer

Public professional footprint only. The two teammates have no name and no footprint in hand, so this section reads only the principal.

| Fact | Source | Provenance | What it implies |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | ilprincipalsforum.example speaker page | [grounded] | Any reading claim you make faces someone with a reading-specialist background; keep each claim at its quote's scope (inferred from this fact) |
| 2025 forum talk "Small Groups, Big Readers" covered weekly reading conferences in grades 3 to 5 | ilprincipalsforum.example speaker page | [grounded] | Structure questions about reading are likely, which is why C3 exists; R1 asks about it (inferred from this fact) |

| Her public path | Your side, quoted exactly | Row | How to use it |
|---|---|---|---|
| Reading is the subject of her career and talk | "I've run the after-school reading club for the last two years" — your CV | F6 | Shared subject, not a shared jump. Say the quote at its scope and let her draw the connection; claim nothing about what the club did beyond what you actually saw |

## Question banks

### A. Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I see six years in third grade and no fourth. What will be hardest for you in the first month?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | The highest-ROI rehearsal in this pack. Concede first, in your own words from the quote: "I've never taught fourth grade." Hold: "Six years teaching third grade at a public elementary school in Joliet," said at that scope and never as fourth-grade experience. Then a plan, said as a plan: the first thing you would ask the fourth-grade team and the first thing you would look at. Answer slot: if you have already looked at what changes between third and fourth grade, say what you found and where you saw it; if you have not, say so plainly. Hold through two follow-ups by returning to the third-grade years, never by adding to them | F2 is the stated gap and the invite's title makes it the default objection; JD because it scores the role as posted |
| A2 | "Why leave third grade, why Halvering, and why now?" | CO | [grounded] | Selection scaffold; no sentence of yours states your reason, so the pack supplies none. Give the real reason in one sentence, then one thing in the district's published beliefs that you want to be part of, in the district's own wording (Every Child a Reader, Families Are Partners, Teach for Tomorrow, Not for the Test, as listed in Sources). If no reason comes that you could say aloud twice, say so plainly and say what you are still trying to learn about the school | The Skeptic's why-leave, why-here, why-now stem; CO because it asks what you know of the district, grounded on the fetched beliefs page |
| A3 | "You led your grade level's move to a new reading curriculum, and you haven't been a team lead. Help me understand that." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Hold both sentences, each at its own scope, and do not reconcile them by adding anything: "I led our grade level's move to a new reading curriculum in 2024" and "I've never been a team lead." Answer slot: if colleagues took part with you, say how you worked with them and which part was yours; if they did not, or the move was shared, say so plainly and return to the quote. Hold through two follow-ups | F7 is where two of your own sentences press against each other, so the probe is near-certain; EXP because it tests attribution |
| A4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade"; "I've never been a team lead" | Name one real area, and where it is one of your two stated limits say it in the quote's words: "I've never taught fourth grade" or "I've never been a team lead." Then the plan, said as a plan: the first step. One limit, not a list. If a different area is weaker for you, say that instead, plainly, in your own words | The Skeptic's day-one stem; rewards calibrated candor over bluffing, drawing on F2 and F7 |
| A5 | "It's your first week in a fourth-grade classroom. What do you do before the students arrive?" | CASE | [generic] | Structure it: what you would ask the team, what you would read, what you would want to see, and what you would hold off deciding until you have seen the class. The question needs no claim about your past, so the guidance makes none | Rehearses the plan A1 promises, as a live problem; `[generic]` because it is a pattern, not a fact about this district |

### B. Peer Evaluator (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "If you joined our fourth-grade team and we disagreed about pacing, what would you do?" | CASE | [generic] | Propose principles for the seam rather than pretending to know it: ask first what each of you is seeing, say what you know and what you do not, and agree how you will check. No claim about your past is needed, so none is made | The peer prior is collegial seam-splitting; the two teammates are on the panel per the invite, and the question is a live scenario about their team, not a fact about it |
| B2 | "How do you handle credit when work spans a team?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Selection scaffold: pick an occasion; the curriculum move is the one your sentences carry, and you can say it in the quote's words and stop there. Use "we" for context and "I" for what was yours. Answer slot: if others took part, say what each did, in your own words; if you worked alone on a part, say so plainly. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The Peer Evaluator's credit stem; VAL because it scores behavior with colleagues, drawing on F7 |
| B3 | "You've run the after-school reading club for the last two years. What would you bring to our team?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Say the club in the quote's terms, then turn it outward to what you could do for this team's students, in your own words. The pack holds no sentence about what the club produced, so it supplies none. Close by asking what the team's fourth graders most need | Reciprocity framing is the peer counter-strategy; F6 holds the club sentence |

### C. Case/Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A fourth grader is reading well below the rest of the class in your first month. What are your first two weeks?" | CASE | [grounded] | Clarify first (what is known about the reader, what plans already exist), then the objective, the approach, how you would check progress, and the risks. Use the district's own wording where it fits: "assessments inform teaching and never replace it." Think aloud and challenge one premise respectfully. No claim about your past is needed | F4 and F6 meet in this live problem; CASE because it is a decision under uncertainty; grounded on the fetched beliefs page |
| C2 | "The district plans a new reading curriculum for grades 3 to 5 from fall 2027. What would you want to know about it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Ask before you answer: the timeline for fourth grade, the training, how families will hear about it. You may set your own sentence beside it and stop: "I led our grade level's move to a new reading curriculum in 2024." The panel can draw the comparison; if asked what that was like, answer only from what happened and say plainly where your memory ends. The date comes from a search snippet of a board news item, so check the district's page before saying it aloud | The differentiator question: current district strategy from research; CO because it tests homework depth |
| C3 | "How would you set up weekly small-group reading conferences for a class with a wide range of readers?" | CASE | [grounded] | Structure it: clarify what the school already uses, the goal, how you would group, what a conference holds, how you would note what you learn, and how that changes the next week. No claim about your past is needed. The principal's published talk covered this format for grades 3 to 5 | The principal's talk (see Reading the interviewer) makes a reading-structure problem likely; CASE because it is a design problem |

### D. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the move to a new reading curriculum that you led." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The beats the quote states: the move, your grade level's, a new reading curriculum, 2024, and that you led it, in your own words. The material shows nothing past those beats, so tell only what happened and stop where your memory stops. If asked which part was yours, say it in your own words and say plainly what was someone else's | F7's only substantive sentence will be walked line by line; EXP because it tests what was yours |
| D2 | "After the move to the new reading curriculum, what told you it was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: the district's belief that assessments inform teaching raises this probe. If something told you, say what it was and who saw it; if nothing did, or you were not in a position to see, say so plainly and return to the move as quoted | F4 and F7 meet here; the premise is carried only as a probe and the second branch allows that nothing told you |
| D3 | "Tell us about the reading club. What does a session look like?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Say what the club is in the quote's terms, run by you, after school, for the last two years, then describe a session only from memory. The pack holds no detail of a session, so it supplies none | F6 holds the one sentence about the club; the Prober goes one level deeper than the answer |

### E. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey to this point." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've run the after-school reading club for the last two years" | A 90-second arc. Where you are now: the six years, in the quote's words. What you run beyond the school day: the club, in the quote's words. Why fourth grade at Halvering: yours to say. Nothing earlier than the six years is in your material, so anything earlier comes from you | The casual opener is scored; F2 and F6 hold the two sentences the arc rests on |
| E2 | "Tell me about the weekly email to families." | EXP | [grounded] "I write a weekly email to families" | Say what it is: "I write a weekly email to families." Answer slot: if families have responded to the email, say what you did with that; if none have, or it was not yours to act on, say so plainly and stay with the email | F5 holds the sentence; the district's Families Are Partners belief makes this a likely friendly probe |
| E3 | "What are you trying out in reading these days?" | JD | [grounded] "I've run the after-school reading club for the last two years" | Selection scaffold: pick one real thing you are doing or reading about. The club sentence is where your material touches reading, and the pack holds no detail of what happens there. If nothing comes to mind, say so plainly, then name one thing you would like to understand better in reading instruction | The rapport stem on a hot JD topic, asked casually and still scored |

### G. Values/Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Every Child a Reader is the district's first belief. Tell me about a time a student's reading changed how you taught." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Selection scaffold: pick one child, with no name, and give what you noticed, what you did differently, and what happened to the reading afterward. No sentence of yours carries such a story, so the pack supplies none. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the club in the quote's words, or how you would handle it | The district's belief names reading plans for every child (F6); VAL because it scores behavior against a published belief |
| G2 | "Teach for Tomorrow, Not for the Test. What does that look like in a fourth-grade classroom?" | VAL | [grounded] | Give your view in the district's own frame: "assessments inform teaching and never replace it." This asks for a view and no past. If you are pressed for an example, F4's slot applies: answer from your real experience or say plainly that none comes to mind | F4's belief asked as a view; VAL because the question names a published belief |

### H. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you, when someone else has taught fourth grade?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | Pause, restate, concede in the quote's words: "I've never taught fourth grade." Hold on what the quotes carry, each at its own scope: the six years in third grade, the club, the weekly email. Make no claim about other candidates. Hold through two follow-ups; concede specifically, and never fold on the quoted facts | The pressure stem pointed at F2, so A1's concession gets rehearsed under time |
| H2 | "That curriculum move. How much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Hold "I led our grade level's move to a new reading curriculum in 2024" through two follow-ups. Concede specifically which parts were others', only if that is true, in your own words. If asked whether you lead teams, the plain answer is in your own words: "I've never been a team lead" | The pressure stem pointed at F7, the one place two of your sentences press together |

## Reverse questions

| # | Question | Aimed at | Why it lands |
|---|---|---|---|
| R1 | "You've spoken publicly about weekly reading conferences in grades 3 to 5. Where does that fit in a fourth-grade week at Halvering?" | Principal Vantongeren, tied to her public path | Asks about work she has spoken on herself and gets you the weekly shape of the job |
| R2 | "What could a new teammate do in the first month that would genuinely help your team?" | The two fourth-grade teachers (reciprocity) | Turns the exchange toward what you could do for them, and you hear their real first-month need |
| R3 | "What does the fourth-grade team plan together, and what is left to each teacher?" | The two fourth-grade teachers | Maps the seam you have not seen, from the people who work it |
| R4 | "I read that the district plans a new reading curriculum for grades 3 to 5 from fall 2027. What is the timeline for fourth grade, and what support comes with it?" | Principal | Draws on the board's plan and asks what you will actually face; check the date on the district's page first |
| R5 | "How do teachers here stay in touch with families each term, and what does the school expect?" | Principal | Tests F5's gap by asking what is expected, so you know what to be ready to answer |
| R6 | "What would success look like for a new fourth-grade teacher by the end of the first semester?" | All three | Gets the panel's own yardstick in their words |

## Prohibited claims

Not coached in any answer, slot, hold or reverse question.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or has fourth-grade classroom experience | Negative the candidate stated, F2 | The plain acknowledgment: "I've never taught fourth grade" — your message. No slot asks whether you did |
| Has been a team lead | Negative the candidate stated, F7 | The plain acknowledgment: "I've never been a team lead" — your message. The word "led" in "I led our grade level's move to a new reading curriculum in 2024" stays at that sentence's scope |
| Owned or decided the district's or school's curriculum choice or rollout | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation, not words for you: the material says your grade level's move, not who decided the choice or the rollout. A3 and D1 stay inside the move |
| Speaks with every family each term | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: the material says a weekly email, not conversations. E2's slot stays inside the email |

## Sources

**Provided documents:** the interview invite; your resume as pasted. A government ID number in the pasted material was not used and is not in this pack, because interview prep does not need it. No dossier was present.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Query or fetch | Returned |
|---|---|
| Search: Orrinsford Community School District mission values | https://orrinsfordschools.example/about/mission-and-beliefs |
| Fetch: https://orrinsfordschools.example/about/mission-and-beliefs | Page text: the three beliefs and their one-line definitions |
| Search: Halvering Elementary School Orrinsford | no results |
| Search: Dolores Vantongeren principal Halvering Elementary | https://ilprincipalsforum.example/speakers/dolores-vantongeren |
| Fetch: https://ilprincipalsforum.example/speakers/dolores-vantongeren | Page text: tenure, prior role, 2025 talk |
| Search: Illinois fourth grade teacher job posting elementary PEL requirements | https://k12jobsboard.example/listings/fourth-grade-teacher (snippet only, truncated; not fetched) |
| Search: Orrinsford Community School District strategic plan reading 2026 | https://orrinsfordschools.example/news/board-adopts-literacy-plan (snippet only; not fetched) |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | F4, F5, F6; questions A2, C1, G1, G2; no values cheat sheet, because no source read describes a values round, and a values page alone does not detect one |
| 2. Interview process | skipped | The invite fixes the loop: one 45-minute panel with the principal and two fourth-grade team members; persona weights follow it |
| 3. District strategy and recent news | yes | C2 and R4, from a board news snippet dated August 2026; the page itself was not fetched |
| 4. Interviewer: Dolores Vantongeren | yes | Reading the interviewer, C3, R1 |
| 5. Representative fourth-grade JD | yes | The requirement text of F3 and F7 only, `[inferred]`; a snippet raises no answer slot |
| Un-numbered: Halvering Elementary School Orrinsford | yes | No results; moved nothing |

## Upgrade menu

- The posting text → F3 and F7 become quoted `[grounded]` rows, JD-tagged questions are re-sourced, and the subject-coverage gap in the table above is checked against the real list
- Which subjects you taught in third grade → F3 stops being a discovery row
- Whether results ever changed what you taught or how → F4 gets a real evidence row and G2, D2 and C1 lose a slot
- Whether you also speak with families, in conferences or calls → F5 gets a real row and E2's slot narrows
- Your license's public registry entry, in hand → F1 moves from medium to high, since a license record is the inspectable artifact in this field
- The two fourth-grade teachers' names and roles → an interviewer read for each and a tailored reverse question
- Any note from HR on what the panel will focus on → coverage no longer assumed from relationship priors
- Hours you have before Thursday → a prep triage section sized to them
- A `tuesday-dossier.md` from an earlier evidence review, if you have one → verified evidence and a named top objection; the pack does not need it
