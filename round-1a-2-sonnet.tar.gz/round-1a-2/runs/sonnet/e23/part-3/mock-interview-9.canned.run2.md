I'm reading the district's beliefs page and its teacher-hiring page in full, so the pack rests on their own wording. Then I'll write it.
Your prep pack is saved as `halvering-elementary_fourth-grade-teacher_interview_pack.md`. I built it for one 45-minute panel: the principal plus two fourth-grade teachers. You hadn't sent the posting, so the role requirements come from the invitation and the district's own pages.

Your pasted résumé included a Social Security number. Interview prep doesn't need it, so I didn't use it, and I'd remove it from anything you send. I also left out the educator license ID number and quoted only the license, endorsement and expiry.

- **Highest-ROI prep:** C1, "taught third grade for six years and never fourth." Your résumé raises it, and two panelists teach fourth grade.
- **Your strongest material:** leading your grade level's reading-curriculum move (B4, F1). It lines up with the district's new grades 3–5 curriculum, due fall 2027.
- **What I couldn't verify:** the literacy plan and the principal's background come from search-result summaries, not full pages. Read the district's news item before Thursday.

Say the word and I'll play the principal on C1 and press you with follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the full text of the posting? It would turn the role-family rows into quoted ones.
Did HR or anyone at the school mention a sample lesson, writing task or particular topics for the panel? A declared task would get its own build section.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. One 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given). Built for Grace from the invitation, your résumé text and the research listed in Sources. No job description was supplied, so the role requirements come from the invitation and the district's own pages; that limit is stated again in the fit snapshot.

## How to use this pack

Personas are how a question arrives. Types are what is being scored. The guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Whether your past behavior shows the district's published beliefs |
| EXP | Whether what your résumé says survives follow-up, and exactly what was yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the district's current direction |
| CASE | A live problem from the role, answered aloud |

The highest-ROI prep in this pack is C1, the third-grade-to-fourth-grade question, because your own résumé raises it and the panel includes two fourth-grade teachers. Rehearse C1 until it is boring, then A4, C3 and F2, which are the same objection in other clothes.

Answer slots in the guidance are instructions for the interview, not questions for you now. Where your answer would improve the pack, it is named in the upgrade menu.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — HR invitation | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The CV states the license, the endorsement and the expiry, and the endorsement as quoted spans grades 1–6, which includes fourth grade. It is a CV line with nothing inspected behind it, so expect the panel to ask about it. Say it in the quote's own terms and add nothing |
| F2 | "reading instruction" — Orrinsford hiring page ("Panels ask about reading instruction, classroom routines and how you work with families.") | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | The material says the curriculum move and the club, and the words stay there: "I led our grade level's move to a new reading curriculum in 2024." It does not say how your own reading lessons run, and that is the pack's observation, not words for you. Answer slot: the district's first belief makes a probe on how you teach reading likely. If you can describe how your reading lessons run, do so in your own words; if the move and the club are what you have to offer, or the lessons were not yours to shape, say so plainly and stay with those two sentences |
| F3 | "classroom routines" — Orrinsford hiring page | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [inferred] | discovery | The sentence gives the years and the grade and does not show how your classroom ran. Answer slot: the hiring page lists routines among the panel's topics, so expect a probe on yours. If routines were yours to set, name one or two and why, in your own words; if they were set for you, or you had none you would call routines, say so plainly and stay with the six years |
| F4 | "how you work with families" and the belief "Families Are Partners" — Orrinsford hiring page and beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | Say it at its own scope: "I write a weekly email to families." The district's belief, as published, is about speaking with families, and your material shows the email. Answer slot: if the emails led to conversations with families, say how, in your own words; if they did not, say so plainly and stay with the email |
| F5 | "Fourth Grade Teacher" — HR invitation, the position title | "I've never taught fourth grade" — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so yourself. Words: "I've never taught fourth grade." Then what you would learn first and from whom, said as a plan and never as a past. Never a claim to fourth-grade work, and nothing added to make the gap feel smaller |
| F6 | "assessments inform teaching and never replace it" — Orrinsford beliefs page, "Teach for Tomorrow, Not for the Test" | none given | none | [grounded] | discovery | Strong evidence here is one named occasion when results from your own class changed what you taught next. Answer slot: the belief makes a probe likely. If results ever changed what or how you taught, say what and what you did next, in your own words; if that never happened, or it was not yours to decide, say so plainly and say what you would look at first |
| F7 | Works with a grade-level team (role-family pattern, no supplied source states it for this team) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your CV | medium | [generic] | transferability | Words: "I led our grade level's move to a new reading curriculum in 2024." The sentence says the move at grade level, and the material does not say what your teammates did. Plain acknowledgment, since you wrote it: "I've never been a team lead." The two sentences sit side by side, so expect a probe on how leading a move differs from leading a team, answered at each sentence's own scope |

The posting text was not supplied, so F7 is a role-family requirement written as plain prose and raises no answer slot.

## Reading the interviewer

Public professional footprint only. The two fourth-grade team members are unnamed, so nothing is read for them.

| Fact | Source | Provenance | What it means for you |
|---|---|---|---|
| "Dolores Vantongeren has been principal of Halvering Elementary School since 2022, after nine years as a reading specialist." | Illinois principals forum speaker page, search result | [grounded] | Reading instruction is the principal's native language, so expect exact follow-ups on B4 and F1. Answer inside what you did, and name no reading practice you did not run |
| "Her 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5." | Illinois principals forum speaker page, search result | [grounded] | Shared vocabulary: grades 3 to 5 reading. The mirror is your sentence "I led our grade level's move to a new reading curriculum in 2024" (F2), used as vocabulary and not as a claim that your approach matches hers. Your material does not say you ran small groups or reading conferences, so if they come up, answer from what you did or say plainly that you did not |

## Persona table

The loop is one 45-minute panel, established by the invitation ("a 45-minute panel interview on Thursday with Principal Dolores Vantongeren and two members of our fourth-grade team") and the district's hiring page ("one 45-minute building panel: the principal and two grade-level teachers"). Weights rest on those, not on an archetype. Method: the panel prior blends the top two personas of each member's relationship, the principal as hiring-manager (Case/Strategist and Skeptic) and the two teachers as peers (Peer Evaluator and Prober), then adjusts for the reading background in the interviewer read and for what your résumé says.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Two fourth-grade teachers asking how you would fit and what happens when you disagree | High. Two of three panelists are teammates by the invitation's own words, and the peer prior puts this persona first | Offer seam principles, not a map of their seam; say what you would give the team, not only what you need (A1 to A5) |
| Case/Strategist | The principal setting a reading or routines problem and listening for structure and the district's vocabulary | High. The hiring-manager prior, plus the hiring page's "Panels ask about reading instruction, classroom routines and how you work with families," plus the reading-specialist background | Clarify, then structure, then plan; think aloud; use the district's own words (B1 to B4) |
| Skeptic | Quiet, persistent probing of third grade to fourth grade and of team leadership | Mid. The hiring-manager prior, raised because your own résumé states "I've never taught fourth grade" and "I've never been a team lead" | Rehearse the single most predictable objection until it is boring: hold the quoted six years, concede the gap in one plain sentence, give a plan (C1 to C3) |
| Values/Behavioral | Questions themed on the three published beliefs | Mid. No values-style round is detected, because the hiring page names reading instruction, routines and families and no values round, so this persona is themed by the beliefs as published, not by a documented round | Map a story only where your own sentence carries one; otherwise pick by criteria and end on the honest branch (D1 to D3) |
| Conversational/Rapport | The opening "walk us through the journey" and a light license check | Low to mid. Panels open warmly, and the invitation makes the license a stated condition | A 90-second arc built only from your own sentences; treat the casual questions as scored (E1, E2) |
| Pressure/Stress | A time-boxed "why you over someone who has taught fourth grade" and "how much was actually you" | Low. No source describes this panel as adversarial; kept because the same objections can arrive sharply | Pause, restate, hold the quoted sentence through two follow-ups, concede specifically (F1, F2) |
| Data-Driven Prober | Defend-the-number questions | Low, and no bank. Your résumé text contains no headline figure for it to probe, so there is no defend-the-number question to write | If a number comes up in the room, say how it was counted or say plainly that you do not know |

## Question banks

### A. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our fourth-grade team plans together. Where would you expect us to disagree, and what happens when we do?" | CASE | [generic] | Offer principles, not a map of their seam: what you would ask the team before assuming anything, how you disagree in the open and still carry out what the team settled, and what you would put on the table rather than only what you would need. The question needs no claim about your past, so the guidance makes none | F7 is the team requirement; the peer prior makes seam questions likely with two teammates on the panel. CASE because it is a live hypothetical about team life |
| A2 | "Your grade level moved to a new reading curriculum in 2024. How do you handle credit when work spans teachers?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Start from the sentence: you led your grade level's move to a new reading curriculum in 2024. Say what was yours in plain terms. Name a teammate's part only if you know what it was, and leave it unnamed if you do not. The pack does not know who did what, so the split is yours to tell; if you cannot separate your part from the group's, say that plainly and stay with the sentence | F2 and F7 carry this sentence, and credit-sharing is a standard peer probe. EXP because it tests attribution |
| A3 | "What could you bring our fourth-grade team?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | Pick from what your material carries, each at its own scope: you led your grade level's move to a new reading curriculum in 2024; you have run the after-school reading club for the last two years; you write a weekly email to families. Say what each is and let the panel draw the inference; do not tell them what it shows about you. Then say what you would ask the team to teach you about fourth grade | The reciprocity question for a peer panel. F2 and F4 supply the material. JD because it scores fit with the listed work |
| A4 | "You haven't taught fourth grade yet. What would you want from our team to get up to speed?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | Open with the plain acknowledgment: "I've never taught fourth grade." Then the years in your words: "Six years teaching third grade at a public elementary school in Joliet." Answer slot: what you would want to learn first and whom on the team you would ask, in your own words; if you have not thought it through yet, say so plainly and say how you would find out | F5 is the biggest gap, and teammates ask it as a collegial question. JD because it scores the title's requirement; the guidance follows the C1 structure in a collegial register |
| A5 | "Would you want to lead a grade-level team here someday?" | JD | [grounded] "I've never been a team lead"; "I led our grade level's move to a new reading curriculum in 2024" | Plain acknowledgment first, because you wrote it: "I've never been a team lead." Then the sentence at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Whether you want the role later is your answer to give. If you do, say what you would want to learn first; if you do not, say so plainly and say what you would rather contribute | F7 sets the two sentences side by side, which invites exactly this probe. JD because it scores the team requirement |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "It is October and a fourth-grader is still reading well below grade level. What do you need to know first, and what is your plan?" | CASE | [grounded] | Clarify before you plan: how "well below" is being measured, what the student's reading plan already says, what the family has been told. Then an objective, an approach, how you would check it is working, and how you would involve the family and the team. Think aloud and use the district's phrase "Every Child a Reader." The guidance makes no claim about your past | The first belief on the beliefs page is the theme, and the principal's reading background in the interviewer read makes a reading problem the likeliest case. CASE because it is a live problem, VAL in theme |
| B2 | "In August the board adopted a three-year literacy plan. What does it mean for a fourth-grade teacher starting now?" | CO | [grounded] "I write a weekly email to families"; "I led our grade level's move to a new reading curriculum in 2024" | Show you have read it: structured phonics from kindergarten to second grade, a new grades 3 to 5 reading curriculum from fall 2027, and a family reading night at every school each term. That summary comes from a search result, not the full page, so read the district's news item before Thursday. Think aloud about what you would want to learn about the new curriculum before it arrives, who you would ask, and how a family reading night sits beside the weekly email you already write. One honest link at its own scope: you led your grade level's move to a new reading curriculum in 2024. Ask about the new curriculum rather than describing it | The strategy sweep found this plan under six months old, so it is the differentiator question most candidates will not touch. F2 and F4 supply the links. CO because it scores current-direction knowledge |
| B3 | "It is the first week of fourth grade. Which routines do you set up, and why those?" | CASE | [grounded] | Structure it aloud: what students need to know in the first days, which routines you would choose, why each, and how you would check they hold. Pick routines by the reason you can give for each. The question needs no claim about your past. If a routine from your own classroom comes to mind that you would keep, name it in your own words; if you would build them fresh for fourth grade, say so plainly | Routines are on the hiring page's list of panel topics, and F3 is thin, so a live question is likelier than a record question. CASE because it is hypothetical |
| B4 | "Walk us through your grade level's move to a new reading curriculum in 2024." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Tell it with what the sentence carries: it was your grade level's move, to a new reading curriculum, in 2024, and you led it. Everything between those beats is yours to tell in your own words; the pack does not know it. Expect follow-ups on what the move involved from someone with a reading background. If a follow-up asks about a part that was not yours, or did not happen, say so plainly and return to what you led | F2 is your strongest reading evidence and the likeliest place to be probed. EXP because it tests what was actually yours |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have taught third grade for six years and never fourth. What will be hardest for you?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | The highest-ROI rehearsal in this pack. Hold: "Six years teaching third grade at a public elementary school in Joliet." Concede in the same breath, specifically: "I've never taught fourth grade." Answer slot: the hardest part is yours to name, so say what you expect to find hardest and what you would do first about it; if you cannot name it yet, say so plainly and say how you would find out. Follow-up 1, "Is that not a big step?": return to those two sentences and add nothing. Follow-up 2, "Why should we take that risk?": the concession again, then what you would ask of the team (A4). Follow-up 3, "What if you are struggling by October?": say how you would tell and whom you would go to, as a plan, never as a fourth-grade past | F5 is the gap your own résumé states, and a panel with two fourth-grade teachers will ask it in some form. Deepest rehearsal means the most follow-up levels and the exact concession worded before it is asked for. JD because it scores the title's requirement |
| C2 | "Why fourth grade, and why here, and why now?" | JD | [generic] "I've run the after-school reading club for the last two years" | A selection scaffold, because your reasons are yours and the pack does not know them. Choose one or two real reasons and say them plainly, each tied to something you can say you did or want. If no such reason comes to mind, say so plainly, then give the nearest thing your material does carry, such as "I've run the after-school reading club for the last two years", or how you would approach it | Motivation consistency is what a Skeptic scores, and F5 makes "why fourth" the obvious opening. JD because it scores fit with the role |
| C3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade"; "I've never been a team lead" | You have written two limits yourself: "I've never taught fourth grade" and "I've never been a team lead." Pick the one you would honestly be weakest at, name it in one sentence, then say how you would start closing it, as a plan. Which one is yours to say. Do not choose a weakness that is a strength in disguise; the panel has your résumé | F5 and F7 hold the two stated limits, and this is the stock Skeptic stem. JD because it scores honest self-assessment against the listed work |

### D. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Every Child a Reader is our first belief. Tell us about a time a student's reading stalled and what you did." | VAL | [grounded] "I've run the after-school reading club for the last two years" | A selection scaffold: choose a situation you can describe without naming the child, say what you changed in how you taught or what you offered, and say what you saw afterwards, each only if it is real. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I've run the after-school reading club for the last two years", or how you would handle it (B1) | The beliefs page names this belief, and F2 holds only the club and the move, neither of which is a stalled-reader story. VAL because it scores a published belief |
| D2 | "Families Are Partners is another of our beliefs. How do you work with families?" | VAL | [grounded] "I write a weekly email to families" | Story-mapped on one sentence: "I write a weekly email to families." Say it at that scope. Answer slot: if the emails led to conversations with families, say how, in your own words; if they did not, say so plainly and stay with the email. Describe what families do with the emails only if you know | F4 is the evidence, and the hiring page lists families among the panel's topics. VAL because it scores a published belief; EXP in how it is probed |
| D3 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it. When have assessment results changed what you taught?" | VAL | [grounded] | A selection scaffold: pick one occasion that has a named group of students, a result you looked at, and a change you made afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or what you would look at first when results arrive | F6 has no evidence at all, so this is a worksheet row; the belief is the raising source. VAL because it scores a published belief |

### E. Conversational/Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through the journey." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc made only of those four sentences, in your own order. Then why fourth grade, which is yours to say; the pack does not know it. Stop at 90 seconds | The opener is scored even when it feels friendly, and F2, F3 and F4 supply the arc. EXP because it tests whether the story matches the résumé |
| E2 | "Tell us about your license and endorsement." | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it as written: the license, the Elementary Education endorsement for grades 1 to 6, active through June 30, 2029. Add nothing to it, and keep the license record where you can find it if asked | F1 is the one condition the invitation states outright. JD because it scores the stated qualification |

### F. Pressure/Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Pause and restate the question. Hold: "I led our grade level's move to a new reading curriculum in 2024." Hold it through two follow-ups by returning to the sentence. Concede specifically where you must. Answer slot: which parts were yours alone and which were shared, in your own words; if you cannot separate them, say that plainly | F2 and F7 carry this sentence, and the attribution probe is the pressure form of B4. EXP because it tests what was actually yours |
| F2 | "Sixty seconds: why you over a candidate who has already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | Concede first, in one clause: "I've never taught fourth grade." Then what you carry, each at its own scope: the six years, the move, the club, the weekly email. Do not run down the other candidate. End on what you would do first. Stay inside sixty seconds | F5 is the gap, and a time-boxed challenge is how a pressure interviewer would use it. JD because it scores fit against a stronger-looking rival |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 license and endorsement | E2 |
| F2 reading instruction | A2, A3, B1, B2, B4, D1, F1 |
| F3 classroom routines | B3 |
| F4 working with families | A3, B2, D2 |
| F5 Fourth Grade Teacher | A4, C1, C2, C3, F2 |
| F6 assessments inform teaching | D3 |
| F7 grade-level team | A1, A2, A3, A5, C3 |
| Planning and teaching across subjects (role-family pattern from a posting snippet, not quoted) | none, because no supplied source says the panel will ask about it and the snippet was cut off; the posting text would settle it |
| The three published beliefs | D1, D2, D3 |

## Reverse questions

| # | Question | Provenance | Why it lands |
|---|---|---|---|
| 1 | "You spent nine years as a reading specialist before becoming principal. How has that shaped what you look for in fourth-grade reading instruction?" | [grounded] | Ties to the principal's own path, and it asks for her view instead of offering yours |
| 2 | "Your 2025 forum talk was on weekly reading conferences in grades 3 to 5. What does that look like in fourth grade at Halvering?" | [grounded] | Shows you read her public work, and it invites the principal to describe the practice rather than you guessing at it |
| 3 | "The new grades 3 to 5 reading curriculum arrives in fall 2027. How is the fourth-grade team preparing, and where would someone new fit?" | [grounded] | Shows you read the August plan and turns the new-to-fourth-grade gap into a planning conversation |
| 4 | "What could a new fourth-grade teacher do in the first month that would genuinely help your team?" | [generic] | The reciprocity question for the two teammates; it asks what they need, not only what you do |
| 5 | "Which routines does the fourth-grade team keep common across classrooms, and which does each teacher own?" | [generic] | Shows you think in seam principles, and it answers F3's thin evidence with curiosity instead of a claim |
| 6 | "What would a good first year look like for someone new to fourth grade?" | [generic] | Converts the C1 objection into a shared definition of success |

## Prohibited claims

Built from the fit snapshot before the banks were written. This is what the pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or has fourth-grade experience | Negative you stated, F5 | The plain acknowledgment: "I've never taught fourth grade." Then the plan, said as a plan. No slot |
| Has been a team lead, or led the grade-level team | Negative you stated, F7 | The plain acknowledgment: "I've never been a team lead." The quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." No slot |
| Speaks with every family each term | Inflated form of F4 | The quote at its own scope: "I write a weekly email to families." The limit is the pack's observation: the material says the email, not conversations. The D2 slot stays inside the email |
| Improved reading achievement through the club or the curriculum move | Inflated form of F2 | The two quotes at their own scope. The limit is the pack's observation: the material says the move and the club, not what changed afterwards. The slots in B4, D1 and F1 ask only what you did and what was yours |

## Sources

Provided documents: the HR invitation and your résumé text, both pasted in your message. A Social Security number in the pasted text was not used and is not needed. The educator license number in the résumé was not used either; the license row quotes only the license, the endorsement and the expiry. No tuesday-dossier.md was present.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | Fetched the beliefs page: three beliefs by name drive D1 to D3, and F4 and F6 take their requirement text from it. No values cheat sheet, because no values-style round is detected |
| 2. `{company} interview process {role family}` | yes | Fetched the hiring page: one 45-minute panel of the principal and two grade-level teachers, matching the invitation; it fixes the persona weights and the topics for B3, F2, F3 and F4 |
| 3. `{company} strategy` / recent news | yes | Search result only, not fetched: the August literacy plan feeds B2 and reverse question 3. Verify it on the district's page |
| 4. `{interviewer name} {company}` | yes | Search result only, not fetched: feeds the interviewer read and reverse questions 1 and 2 |
| 5. representative `{role title}` JD | yes | Search result only, not fetched, so the posting text is not quoted: it informs the F7 and subject-breadth rows as plain role-family prose, and the posting text itself is in the upgrade menu |

Queries sent and what each returned:

- "Orrinsford Community School District mission values": https://orrinsfordschools.example/about/mission-and-beliefs
- "Halvering Elementary School Orrinsford interview process fourth grade teacher": https://orrinsfordschools.example/careers/how-we-hire-teachers
- "Orrinsford Community School District strategic plan news": https://orrinsfordschools.example/news/board-adopts-literacy-plan
- "Dolores Vantongeren principal Halvering Elementary": https://ilprincipalsforum.example/speakers/dolores-vantongeren
- "fourth grade teacher job posting Illinois elementary requirements responsibilities": https://k12jobsboard.example/listings/fourth-grade-teacher

Pages fetched: https://orrinsfordschools.example/about/mission-and-beliefs and https://orrinsfordschools.example/careers/how-we-hire-teachers.

## Upgrade menu

- The posting's full text → F7 and the subject-breadth requirement become grounded rows, and the coverage table gets checked against the posting's own list
- The names of the two fourth-grade teachers → an interviewer read for each, adjusted peer weights, and a reverse question tied to each one's path
- Anything HR or the school said about the panel, such as a sample lesson or a writing task → a build section for each announced deliverable
- The license record itself, the registry entry that shows the endorsement and expiry → F1 moves from medium to high
- Your own answers to the slots, outside a drill: how your reading lessons run (F2), how your classroom routines work (F3), whether the emails led to conversations (F4), and whether results ever changed what you taught (F6) → those rows are regenerated from your words and the guidance gets story-mapped where a sentence carries it
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes → a grounding brief on the district's literacy plan, the principal's talks and recent changes at the school
- How much prep time you have before Thursday → a prioritized schedule
- A prior evidence dossier, tuesday-dossier.md, if you have one → verified evidence and sharper constraints on the weak areas; never required
