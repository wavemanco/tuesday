I've read the skill's rules and I'm now running a few company searches. They cover Quillmoor's values, recent news and Hannah's public professional footprint. After that I'll write the prep pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/e23/part-7/rooms/case-13-denied-5692c2e2/quillmoor-diagnostics_operations-coordinator_interview_pack.md`. I built it for a 30-minute recruiter screen with Hannah, using her agenda, the advert and your note about your background. It has 18 practice questions, each with answer guidance, plus six questions for you to ask her.

- **The company searches were refused.** The pack has no Quillmoor research and no read on Hannah herself. The Sources section lists what each search would have fed.
- **The question to rehearse most is B2.** The advert's main duty is coordinating production schedules between planning, the warehouse and QA. Your note covers scheduling deliveries and chasing suppliers, not production scheduling, so expect a probe there.
- **Your pay, hybrid and reason for moving fit what she asked.** £42,000 is inside the £38,000–£44,000 band, and two days at Avonmouth is within your limit of three. The Reading story is a clear reason for looking.
- **SAP is a stated gap, and the advert only calls it a plus.** The pack coaches the plain answer, "Never used SAP."

Say the word and I'll play Hannah on B2, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What's your notice period? It's the one item on Hannah's list your material doesn't settle, so the pack gives no words for it yet.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, a 30-minute phone call on Thursday at 2pm with Hannah Lowther, Talent Partner, who will ring the mobile number on your application.
**Her stated agenda:** salary expectations, notice period, how the hybrid pattern would work for you, what is prompting a move; then the team and next steps.
**Built from:** the advert text, Hannah's LinkedIn message and your own note about your background (no CV). Company searches were refused, so nothing in this pack is company research.

## How to use this pack

Personas describe how a question is asked; types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your own history holds up, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | How well you know the company and its strategy |
| CASE | How you structure a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now: answer whichever branch is true, from your own experience.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap. Say it in the quote's own terms: four years as a logistics coordinator at a building-supplies wholesaler. It is your statement with nothing inspected behind it, so expect a probe on it |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says deliveries for three depots and chasing suppliers, not production schedules and not planning or QA, and the words stay at that scope: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who you coordinated with likely. If any of your scheduling involved working with a planning, warehouse or quality function, say which and how, in your own words; if not, or it was not yours, say so plainly and stay with the three depots |
| F3 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap in terms: "chase suppliers when orders slip" is the advert's chase-late-orders line in other words. Lead with the quote's own terms. Nothing has been inspected behind it, so expect a probe |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap: the quote states the rebuild and the fall. Keep "about a third" as "about", attached to discrepancies, over a year. A figure invites the defend-the-number probe, so C1 and D2 rehearse it |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material is silent on reporting. Answer slot: the advert's weekly on-time dispatch line makes a probe likely. If you reported on deliveries or stock in any regular way, say what and how often, in your own words; if not, say so plainly and stay with the three depots |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The quote says a spreadsheet and does not say which tool. Answer slot: if it was Excel, say so and say what you built in it, in your own words; if it was another tool, or only part of the rebuild was yours, say so plainly and stay with the rebuild |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | low | [grounded] | transferability | The advert calls it a plus. Your words: "Never used SAP." The in-house stock system is adjacent work at its own scope. Answer slot: if a probe asks what you did in that system, say what you used it for in your own words; if your use was limited, say so plainly and stay with the stock-count spreadsheet |
| F8 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | No gap: the figure sits inside the advertised band. Say it as stated. It is a hope, and your material gives no floor. Answer slot: if there is a figure below which you would decline, settle it before Thursday; if there is not, say £42,000 is what you are hoping for |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | No gap: two days is inside your stated limit. The limit stays as you wrote it: you would not want more than three |
| F10 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish it |
| F11 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | No gap: the quote gives a plain reason in your own words. Expect it to be probed for consistency, so say it the same way each time |

## Persona table

The loop is one call with Hannah, set by her own message, so no archetype fallback is used. Weights start from the recruiter-screen prior (Conversational plus a light Skeptic) and are adjusted by her stated agenda. Values and Peer personas are left out: her message names no values round and no peer.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport (A, 5 questions) | Friendly, unstructured; her four agenda items asked casually | High: it is the recruiter-screen prior, and her message lists logistics and motivation in a friendly register | Prepare a 90-second arc from the quotes in A1 and treat the casual questions as scored |
| Skeptic (B, 5 questions) | Quiet probing of the advert lines your material only brushes, and of the move | Medium-high: it is the prior's light skeptic, and F2, F5 and F7 are where the advert outruns the material | Rehearse B2 until it is boring; build bridges only from the quotes, and say the limit plainly where there is none |
| Data-Driven Prober (C, 4 questions) | Asks how the stock-count figure was counted and what you actually did | Medium-low: not a recruiter-screen prior, but F4 carries a figure and a probe on it is cheap to ask | Know what you can and cannot say about how the figure was counted, and say so when you do not know |
| Pressure (D, 2 questions) | Time-boxed "why you" and "how much was you" | Low: nothing in her message suggests a stress style | Pause, restate, hold the position the quote carries through two follow-ups, concede only what is true |
| Case / Strategist (E, 2 questions) | A small live problem from the role | Low: her agenda lists no problem-solving item; kept as insurance in case a later round is more case-led, which this pack cannot see | Clarify, then structure, think aloud, name who you would tell |

## Question banks

The highest-ROI prep in this pack is B2: the advert's central line is coordinating production schedules across planning, the warehouse and QA, and F2 holds adjacent work only.

### A. Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Story-mapped on F1, F3 and F4: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling by about a third over a year. Those are the only beats the quotes state. Tell them in your own words in about 90 seconds, in the advert's order, and stop so Hannah can steer | The usual opener, built from the three rows with no gap; EXP because it tests what your own account claims |
| A2 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Story-mapped on F11: the office closing next year, the only offer being Reading, and that you do not want it. Say those three in your own words, plainly. Answer slot: a follow-up on what draws you to this role is likely. If something specific about the role or Quillmoor draws you, say it in your own words; if the office closing is the whole reason, say so plainly rather than adding enthusiasm | Hannah named it in her message. EXP is the closest of the five types: it tests your own history and whether the story stays consistent |
| A3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Story-mapped on F8: "I'm hoping for £42,000", then stop. Answer slot: if there is a figure below which you would decline, settle it before Thursday; if there is not, say so to yourself and keep to the figure you are hoping for | F8 is a pay term your material shows met; JD because it scores a term in the advert |
| A4 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Story-mapped on F9: "I live in north Bristol, so two days at Avonmouth is fine." The advert asks for two, so whether to volunteer your limit is your call. If asked about flexibility, give the limit in your own words as you wrote it, not as "flexible" | Her second agenda item; JD because the advert states the pattern |
| A5 | "What's your notice period?" | JD | [grounded] | Your material does not establish it, so the pack gives no words. Say the notice period from your contract as written; if you are unsure, check it before Thursday | Her agenda names it, and F10 is the one gate row your material leaves open; JD because it scores a term of the role |

### B. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this advert would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Pick the advert line your material carries least. The pack's reading is that F2, F5 and F7 are the thin rows. Name one, say what you do have in the quote's own words, then say how you would start learning the rest as a plan, never as a past you do not have | F2, F5 and F7 are where the advert outruns the material; JD because it scores the listed job including its gaps |
| B2 | "The role coordinates production schedules between planning, the warehouse and QA. What part of that have you done?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The hold is only what the quote carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." Answer slot: if any of your scheduling involved working with a planning, warehouse or quality function, say which and how, in your own words; if not, or it was not yours, say so plainly and describe the depot scheduling. Hold through two follow-ups by returning to the quote, never by adding to it, and concede exactly what is true: your material says delivery scheduling, not production scheduling | The highest-ROI rehearsal: F2 is where the advert's central line presses hardest, so this objection arrives in some form; JD because it scores a stated requirement |
| B3 | "We list ERP experience, SAP or similar, as a plus. What have you used?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Say the plain part first: "Never used SAP." Then the in-house stock system, at that scope. Answer slot: if asked what you did in it, say what you used it for in your own words; if your use was limited, say so plainly and return to the stock-count spreadsheet | F7 is a stated negative plus adjacent work; JD because the advert raises it, as a plus |
| B4 | "Your office doesn't close until next year. Why start looking now?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | The quote gives the closing, the Reading offer and that you do not want it. Answer slot: if the timing was a deliberate choice, say why in your own words; if it was not, say so plainly and return to the quote | F11 supports the reason but not the timing, so the "why now" probe is likely; EXP because it tests consistency of your own story |
| B5 | "Would you be comfortable with three days on site if the team needed it?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Three is the most you said you would want, so the answer stays inside your sentence: two days is fine, and you would not want more than three. Say it in those terms and do not turn the limit into a preference or into open flexibility | F9's limit is the one thing here a recruiter can test; JD because it scores the hybrid term |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that discrepancy figure was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Defend the number in your own words on four points: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Keep "about a third" as "about". If you do not know how it was counted, say so plainly. The pack supplies no method or baseline | F4 carries the only figure in your material, which makes it the likeliest place to be probed; EXP because it tests what was actually yours |
| C2 | "The advert asks for confidence in Excel. What did you build in the stock-count spreadsheet?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if it was Excel, say so and say what you built in it, in your own words; if it was another tool, or only part of the rebuild was yours, say so plainly and stay with the rebuild | F6 is thin because the quote names a spreadsheet, not a tool; JD because it scores the Excel requirement |
| C3 | "Which weekly reports have you produced?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: the advert's weekly on-time dispatch line makes this probe likely. If you reported on deliveries or stock in any regular way, say what and how often, in your own words; if not, say so plainly and return to scheduling deliveries for the three depots | F5 is silent in the material; JD because it scores the advert's reporting line |
| C4 | "How do you chase a supplier whose order has slipped?" | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Story-mapped on F3: you chase suppliers when orders slip, the quote's own words. Answer slot: if you had a routine for chasing, say what it was in your own words; if there was not one, say so plainly and describe what you did | F3 is a clean match, so it is a likely follow-up; EXP because it tests how your own work was done |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you for this role?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Three sentences from the quotes, in the advert's order: the four years, the depot scheduling and chasing, the stock-count rebuild. If pressed on SAP, give the plain acknowledgment: "Never used SAP." Hold the position through two follow-ups and concede only that gap | F1, F3 and F4 are the rows with no gap; JD because it scores fit against the advert |
| D2 | "That discrepancy result: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold the clause the quote states: "I rebuilt our stock-count spreadsheet." Answer slot: if others contributed to the fall, say what they did; if the rebuild was the main change, say so plainly. Concede specifically that you cannot say more than you know about how the fall was measured | F4's quote gives the rebuild and the fall but does not say what caused the fall, which is exactly where this probe goes; EXP because it tests attribution |

### E. Case / Strategist (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you an order QA needs for Friday's run will arrive three days late. What do you do?" | CASE | [generic] | Structure it: what you would ask first (what is affected, who is waiting, how firm the new date is); the objective; the options (a partial delivery, another source, re-sequencing with planning); who you would tell (planning, the warehouse, QA); what you would record. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's chase-late-orders and planning, warehouse and QA lines; generic because it is a pattern for the problem |
| E2 | "The stock record says 40 units and the shelf shows 32. What do you do?" | CASE | [generic] | Structure it: check recent movements against the record, recount, find the cause, correct the record with a note, tell whoever depends on the number. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's stock-records line; generic because it is a pattern for the problem |

### Requirement coverage

| Requirement | Questions |
|---|---|
| 2+ years in operations or logistics coordination | A1, D1 |
| Coordinate production schedules between planning, the warehouse and QA | B1, B2, E1 |
| Track supplier deliveries and chase late orders | C4, E1 |
| Keep stock records accurate | C1, D2, E2 |
| Report weekly on on-time dispatch | C3 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar), a plus | B3 |
| Salary £38,000–£44,000 | A3 |
| Hybrid, two days a week at Avonmouth | A4, B5 |
| Notice period | A5 |
| What is prompting a move | A2, B4 |

## Reverse questions

No interviewer profile was found, so none is tied to Hannah's own path, and she is not a peer, so there is no reciprocity question.

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What does the handoff between planning, the warehouse and QA look like in a normal week, and where does it tend to slip?" | It goes to the advert's central line and lets her describe the job on her terms |
| R2 | "Which system does the team work in day to day, and how is training handled?" | It raises the ERP point on your terms, as a question about onboarding |
| R3 | "How is on-time dispatch measured today, and who reads the weekly report?" | It turns the reporting line from a probe into a conversation |
| R4 | "How does the two-days-at-Avonmouth pattern work in practice: fixed days, or agreed with the team?" | It confirms a detail you would otherwise assume |
| R5 | "Who would I meet next, and what does each stage cover?" | It gets the rest of the loop on the table, so the next pack can be built for it |
| R6 | "What would a good first three months look like for this role?" | It shows you are thinking about the work and gives you something to prepare against |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP | Negative you stated, F7 | The plain acknowledgment F7 gives: "Never used SAP." Nothing added to make it smaller |
| Has ERP experience, with the in-house system counting as one | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: your material says an in-house stock system, not that it is an ERP. B3's slot stays on what you used it for |
| Has coordinated production schedules between planning, the warehouse and QA | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says delivery scheduling and chasing, not production scheduling. B2's slot stays inside the depots |
| Cut stock discrepancies by a third through the spreadsheet rebuild | Inflated form of F4 | F4's quote at its own scope: the rebuild, and discrepancies falling by about a third over a year. The pack's observation is that the quote does not say what caused the fall |
| Is a confident Excel user | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: your material says a spreadsheet, not Excel. C2's slot asks only which tool |

## Sources

Provided documents: the advert text; Hannah Lowther's LinkedIn message; your own note about your background. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The search was refused, so nothing came back. It would have fed a company-specific answer to A2's follow-up; no values round is documented, so no values sheet was due either way |
| 2. `Quillmoor Diagnostics interview process operations` | skipped | Hannah's message already fixes the session: one 30-minute call, her, and its agenda, so persona weights follow from it |
| 3. `Quillmoor Diagnostics Avonmouth news` | unavailable | The search was refused, so nothing came back. It would have fed a strategy-grounded CO question; none is in the banks, so the CO type is absent from this pack |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | The search was refused, so nothing came back. It would have fed an interviewer read and a reverse question tied to her path; both are absent |
| 5. representative `Operations Coordinator` advert | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → F10 stops being a gap row and A5 gets your own words
- Your answers to the slots in F2, F5, F6 and F7 → those rows regenerate from your quoted words and the matching questions (B2, C2, C3, B3) gain real story beats
- The stock-count spreadsheet or the discrepancy figures behind F4 → F4 can move from medium toward high, since that is the inspectable artifact in this field; it also gives C1 your own account of how the figure was counted
- Search access, or Quillmoor's about page or values pasted in → a company-specific answer for A2's follow-up, a CO question, and an interviewer read for Hannah
- The next round's name and who runs it → persona weights and a bank for that round; per-round mini-packs once you have the schedule
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, and it needs search access → company strategy brief, interviewer footprint, role-family loop reports and recent org context
- A `tuesday-dossier.md` from an earlier evaluation → verified evidence and pre-agreed handling of the gaps, which would sharpen this pack but was not needed to build it
