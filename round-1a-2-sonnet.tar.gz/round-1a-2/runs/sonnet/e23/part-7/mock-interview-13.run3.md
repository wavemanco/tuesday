I've read the skill's rules and am now running a few quick public-web checks on Quillmoor and the recruiter. Then I'll build your prep pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/e23/part-7/rooms/case-13-denied-d55302de/Quillmoor_operations-coordinator_interview_pack.md`. I built it around Hannah's stated agenda, with 18 questions in five personas and reverse questions for you to ask her. Your notice period isn't in the material, so I couldn't prepare that answer, and it's marked as open.

- **Highest-ROI prep:** B2, where she may ask how scheduling deliveries to depots carries over to coordinating production schedules between planning, the warehouse and QA. Your material covers the deliveries and suppliers, not production or QA, so the pack has you hold that scope and not stretch it.
- **SAP:** you told me you've never used SAP, so the pack has you say so plainly and don't try to bridge it.
- **Company research:** my web searches were refused, so nothing in the pack comes from Quillmoor's own site. The "why Quillmoor" answer (A3) uses only the advert, and there's no read on Hannah.

Say the word and I'll play Hannah on B2 or the salary question. I can also save a tuesday-dossier.md recording the gaps this prep exposed, or convert the pack to a Word document.

What is your contractual notice period? It sets what A6 and the notice-period row say.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quillmoor_operations-coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter phone screen, 30 minutes, Thursday at 2pm. Hannah Lowther (Talent Partner) rings the mobile number on your application. Source: her LinkedIn message.
**Her stated agenda:** "I'd like to cover your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move, and then I'll tell you about the team and the next steps." Source: her LinkedIn message.
**Built on this assumption:** the call follows her stated agenda; your background is the note you wrote me, not a CV.
**Highest-ROI prep in this pack:** B2, the question about moving from scheduling deliveries to coordinating production schedules.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding for your own words, not a script. Wherever an answer slot appears, answer from your real experience, or say plainly that the practice was not yours or did not exist.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | How well you know the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | The quote carries delivery scheduling for depots, not production schedules, and the words stay at that scope: "I schedule deliveries for our three depots." Answer slot: the advert names planning, the warehouse and QA, so a probe on whether any of your scheduling involved them is likely. If it did, say which and what your part was, in your own words; if it did not, or no such step existed, say so plainly and stay with the deliveries and the depots |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms, that you chase suppliers when orders slip, because a named practice beats an adjective. Answer slot: the advert's "track supplier deliveries" makes a probe on how you find out an order has slipped likely. If a routine or system tells you, say what; if you find out another way, or there is no set way, say so plainly and stay with the chasing |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, but a figure with nothing inspected behind it, so expect a probe on the figure itself. Lead with the quote: you rebuilt the spreadsheet and discrepancies fell by about a third over a year. Answer slots: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words. "I don't know how it was counted" is an honest branch |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material says nothing about reporting, so the words are an answer slot. If you produce any regular figures, say what they cover and how often; if you do not, or no such report exists, say so plainly and say what you would track first for on-time dispatch |
| F5 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap on length, and length of experience is not a gate. Say it as the quote says it: four years as a logistics coordinator at a building-supplies wholesaler |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [grounded] | discovery | The quote says spreadsheet, not Excel, and the pack does not close that for you. Answer slot: if the stock-count spreadsheet was in Excel, say what you built in it; if it was another tool, or you used little of it, say so plainly and stay with the rebuild |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | low | [grounded] | transferability | Your own statement stands: "I've never used SAP." The in-house stock system stays at its own scope: your company runs one. Answer slot: "or similar" invites a probe on what that system covers; say what you use it for, in your own words, and if it is not an ERP in the usual sense, say so plainly |
| F8 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | medium | [grounded] | none | No gap: £42,000 sits inside the advertised range, in its upper part. Say the number plainly and stop. Decide beforehand whether it is firm, because the advert lists SAP as a plus and your own statement is that you have never used it |
| F9 | "two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | No gap: the advert's two days and your stated position line up. Say it in the quote's terms, that two days at Avonmouth is fine, and give the limit only if she asks about flexibility: "I wouldn't want more than three." |
| F10 | "your notice period" — Hannah's LinkedIn message | none given | none | [grounded] | hard_gate | Your material does not establish it. Surfaced here and not bridged; no wording closes it |
| F11 | "what's prompting a move" — Hannah's LinkedIn message | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | No gap. Say it as you stated it: the office is closing next year and the only offer is relocating to Reading, which you don't want. Answer slot: Hannah's question and the advert both invite what draws you here; say what in the advert appealed, in your own words, and if nothing beyond the role fit, say so plainly |

## Persona table

Weights rest on Hannah's stated agenda and the recruiter-screen prior (conversational plus light skeptic), not on a documented Quillmoor process.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly walk through her four agenda items, each still scored | High: her message lists the agenda in a friendly register, and the recruiter-screen prior is conversational. Its bank is the largest because all four agenda items sit in it | Pre-script a 90-second arc from "4 years as a logistics coordinator at a building-supplies wholesaler"; treat each casual question as scored |
| Skeptic | Quiet probing of the advert's first duty and its SAP plus against your background | Medium-high: the recruiter-screen prior adds a light skeptic, and F1 and F7 are where the advert and your material are furthest apart | Rehearse B2 until it is boring; hold only what "I schedule deliveries for our three depots and chase suppliers when orders slip." carries, state the limit before it is asked for, and answer the slots honestly |
| Data-Driven Prober | A quick "how was that counted?" on the one figure you gave | Medium: a figure is a magnet target; a recruiter may touch it lightly and the hiring manager more heavily later | Know what you can and cannot say about how "discrepancies fell by about a third over a year" was counted, and say plainly when you do not know |
| Pressure | Salary pushback or a sixty-second "why you" | Low: a booked 30-minute phone call with a stated agenda; salary pushback is its realistic form | Hold-then-concede on D1 and D2: hold two follow-ups on what your quotes carry, concede the SAP gap specifically |
| Case / Strategist | A short live problem from the role | Low: a recruiter screen rarely carries one, but the hiring manager's round may | Clarify first, then structure, then answer; E1 and E2 are generic rehearsal |

Values/Behavioral and Peer personas are not banked: no source in hand names a values round, and Hannah's message describes a one-to-one agenda call.

## Question banks

### A. Conversational / Rapport (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, tell me a bit about your background and what you do now." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip."; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Story-mapped on F5, F2 and F3, with only the beats the quotes state: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling by about a third over a year. Tell it in your own words in about ninety seconds, and end by pointing at the advert's own lines on chasing late orders and stock records | The opener of nearly every screen, and the arc the rest of the call is built on; F5 is the experience requirement, F2 and F3 the duties it most directly meets. EXP because it tests what you actually did |
| A2 | "What's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say it as stated: the office is closing next year, and the only offer is relocating to Reading, which you don't want. Then one sentence on what draws you here. Answer slot: if something in the advert appealed beyond the role fit, say what in your own words; if not, say so plainly and stay with the role fit. Keep it short and unapologetic | Named on her agenda, so it is certain; F11 holds the quote. EXP rather than VAL because it tests your own account of your situation, and the answer is a fact, not a values story |
| A3 | "Why Quillmoor, and why this role?" | CO | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip."; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | The company facts the pack holds are only the advert's: a diagnostic-test manufacturer, about 400 staff, and its list of duties. Map two of those lines to your quotes: the advert's "track supplier deliveries and chase late orders" beside your chasing of suppliers when orders slip, and "keep stock records accurate" beside your stock-count rebuild. Answer slot: add what interests you about making diagnostic tests, in your own words, and if nothing specific comes to mind, say so plainly and stay with the duties | The usual follow-on to the motivation question. CO because it tests homework depth, and it is thin here because the company research could not run; the F2 and F3 rows supply what can be said |
| A4 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Say it plainly: "I'm hoping for £42,000." The advert's range is £38,000–£44,000, so it sits inside, in the upper part. Then stop and let her respond. If she asks what you earn now, your material holds no figure; decide before Thursday whether you give it, and give only the true figure | Named on her agenda, so it is certain; F8 holds the quote. JD because it scores a stated term of the advert |
| A5 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Lead with the advert's pattern: "two days at Avonmouth is fine." You live in north Bristol, which you can say as stated. Give the limit only if she asks about flexibility: "I wouldn't want more than three." Anything about your journey to Avonmouth is outside your material, so answer from what you actually know | Named on her agenda; F9 holds the quote and is the pack's one `high` row because a constraint of your own has nothing to inspect. JD because the pattern is a stated term of the advert |
| A6 | "What's your notice period, and when could you start?" | JD | [grounded] | The pack does not hold your notice period, so say the contractual figure exactly, in weeks or months, and check your contract before Thursday. If you cannot say it exactly, say so plainly and that you will confirm in writing the same day. Give a start date only when it is one your employer would accept | Named on her agenda; F10 is the pack's gate row and stays open until you supply the figure. JD because it scores a stated term of the process |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this advert would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Pick the one you honestly believe it is, in one sentence, before she picks it. If it is SAP, the words are your own: "I've never used SAP", and your company runs its own in-house stock system. Then say how you would learn it, as a plan and never as a past. If you pick another part, the same shape applies: the limit first, then the plan | The standing skeptic question for any screen; F7 and F1 are the likeliest answers. JD because it scores the stated list |
| B2 | "You've been scheduling deliveries to depots. This role coordinates production schedules between planning, the warehouse and QA. How does one carry over to the other?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal in this pack, and the hold is only what the quote carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." Name the limit before she asks for it: your material says deliveries, depots and suppliers, not production, planning or QA. Answer slot: if any of your scheduling involved planning, a warehouse or quality checks, say which and what your part was; if none did, or no such step existed, say so plainly and return to the deliveries and suppliers. Follow-up 1: what is different between depot deliveries and production, which you answer from what you know of both, in your own words. Follow-up 2: what you would need from planning and QA on day one, answered as questions you would ask first. Follow-up 3: if she says it is a big step, hold by returning to the delivery work, never by adding to it | The advert's first duty is the likeliest place for the objection, and F1 is where your material is thinnest against it. JD because it scores the stated duty, with a CASE flavor in the follow-ups |
| B3 | "You haven't used SAP. Is that a problem?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Plain acknowledgment, which is your own statement: "I've never used SAP." Then the in-house stock system at its own scope: your company runs one. Answer slot: say what you use that system for, in your own words, and if it is not an ERP in the usual sense, say so plainly. Close with how you would learn a new system, as a plan | Premised on your own statement; F7 is the row. The advert marks ERP as a plus, so the probe is light but near certain. JD because it scores the stated plus |
| B4 | "Are you moving away from something, or towards something?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Hold on the stated facts: the office is closing next year, and the only offer is relocating to Reading, which you don't want. Answer slot: what you are moving towards is your own answer; say what in the advert appealed, and if the honest answer is the role fit and staying in Bristol, say so plainly. Never invent a longer-term plan | F11 is the evidence, and the skeptic's version of a motivation question tests whether the answer is consistent. EXP because it tests your account of your own situation |
| B5 | "What experience do you have working alongside a quality function?" | JD | [grounded] | An open prompt, so this is a selection scaffold. Pick a time your delivery or stock work involved checks on quality, wrong goods or damaged goods; it needs a named situation and what your part was. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." | The advert names QA in its first duty, and F1 carries no quote on it. JD because it scores the stated coordination duty |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | State the claim exactly as it stands: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. Answer slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part of it was yours. "I don't know how it was counted" is an honest branch | F3 holds the only figure in your material, and a figure is where probes land. EXP because it tests attribution and counting |
| C2 | "Tell me about the stock-count spreadsheet you rebuilt." | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Tell the beats the quote states: you rebuilt it, and discrepancies fell by about a third over a year. Answer slot: the advert asks for confidence with Excel, so expect a probe on the tool; if the spreadsheet was in Excel, say what you built in it, and if it was another tool, or you used little of it, say so plainly and stay with the rebuild | F6 is the row; the advert's Excel line has no quote that reaches it directly. JD because it scores the stated requirement |
| C3 | "The role reports weekly on on-time dispatch. What reporting do you do?" | JD | [grounded] | Answer slot: if you produce regular figures, say what they cover and how often; if you do not, or no such report exists, say so plainly and say what you would track first for on-time dispatch | F4 is the one advert duty with no quote against it. JD because it scores the stated duty |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've got sixty seconds. Why should we hire you over someone who's used SAP?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip."; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year."; "Never used SAP — we run our own in-house stock system." | Pause, restate the question, then hold on the quotes: you schedule deliveries for three depots and chase suppliers when orders slip, and you rebuilt the stock-count spreadsheet, with discrepancies falling by about a third over a year. Concede the gap specifically and once: "I've never used SAP." Hold through two follow-ups by returning to those two quotes; never claim you would beat the other candidate | F7 is the gap a pressure interviewer reaches for. JD because it scores the stated plus under pressure |
| D2 | "£42,000 is near the top of our range. What makes you worth it?" | JD | [grounded] "I'm hoping for £42,000."; "4 years as a logistics coordinator at a building-supplies wholesaler"; "Never used SAP — we run our own in-house stock system." | Hold the number you said: "I'm hoping for £42,000." Ground it in what you have: four years as a logistics coordinator at a building-supplies wholesaler, against the advert's two-plus. Concede the SAP gap in your own words, once: "I've never used SAP." Whether there is movement in the figure is your decision before Thursday; never invent a competing offer | F8 and F5 together; the advert's range is public, so a pushback on the upper end is the realistic form. JD because it scores a stated term of the advert |

### E. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "On Monday a supplier tells you a delivery that QA needs for Thursday's batch will be four days late. Walk me through what you do." | CASE | [generic] | Clarify first: what is affected, what alternatives exist, and what QA can and cannot accept. Then structure: who needs to know and by when, the options, what you would tell each party, and what you would record. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's supplier-chasing and QA lines; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| E2 | "The stock record says 120 units and the shelf holds 112. Where do you start?" | CASE | [generic] | Clarify first: when each figure was taken and what moved in between. Then check the timing differences before assuming a loss, find where the records diverged, correct the record, and note the cause. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's stock-records line; `[generic]` for the same reason as E1 |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B1, B2, B5, E1 |
| Track supplier deliveries and chase late orders | A1, A3, D1, E1 |
| Keep stock records accurate | A3, C1, C2, E2 |
| Report weekly on on-time dispatch | C3 |
| 2+ years in operations or logistics coordination | A1, D2 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B1, B3, D1 |
| £38,000–£44,000 | A4, D2 |
| Two days a week at Avonmouth | A5 |
| Her agenda: notice period | A6 |
| Her agenda: what's prompting a move | A2, B4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does the hiring manager find hardest about keeping planning, the warehouse and QA in step?" | Uses the advert's own three-way coordination line and asks about the real problem, not the job title |
| R2 | "Which system does the team use day to day, and how is training handled for someone new to it?" | Turns the SAP gap into a practical onboarding question without pretending you have used it |
| R3 | "Is there a practical exercise or an Excel task in the next stage?" | Ties to the advert's Excel line and lets you prepare for it |
| R4 | "How are the two days at Avonmouth set: fixed days, or agreed with the team?" | Confirms the pattern you said was fine and shows you are planning for it |
| R5 | "How is the weekly on-time dispatch report used, and who reads it?" | Shows you have read the reporting duty and care what it is for |
| R6 | "What's the timeline for a decision, and is there anything I haven't covered that you would want to know?" | Closes the call and invites a correction of any concern while you can still answer it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots and chase suppliers when orders slip." The limit is the pack's observation, not words for you: the material says deliveries, depots and suppliers, not production, planning or QA. B2's slot stays inside the deliveries |
| Kept the company's stock records accurate | Inflated form of F3 | F3's quote at its own scope: you rebuilt the stock-count spreadsheet and discrepancies fell by about a third over a year. The limit is the pack's observation: the material does not say who owned the stock records. C1's slots ask only about the figure |
| Advanced Excel skills such as pivot tables or macros | Inflated form of F6 | F6's quote at its own scope: you rebuilt a stock-count spreadsheet. The limit is the pack's observation: the material says spreadsheet, and does not name the tool. C2's slot asks only what the spreadsheet was built in |
| Has used SAP | Negative you stated, F7 | The plain acknowledgment F7 gives: "I've never used SAP." No slot on SAP itself |

## Sources

Provided documents: the advert text, Hannah Lowther's LinkedIn message, and your background note.

Searches sent:

- "Quillmoor Diagnostics values": refused
- "Quillmoor Diagnostics Avonmouth news strategy": refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Every call was refused. It would have given A3 the company's published values; nothing in the pack uses a Quillmoor value, and no values-style round is detected, so section 10 is absent |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | skipped | Hannah's message fixes the one session: who runs it, its length and its agenda, so persona weights follow it |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | Every call was refused. It would have given A3 a current strategy hook; A3 uses only the advert's facts |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Every call was refused. It would have supported an interviewer read and a reverse question tied to her path; both are absent |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → F10 and A6 become concrete words instead of an open gate
- The tool the stock-count spreadsheet was built in → F6 and C2 become `[grounded]` on a quote that reaches the Excel line
- Anything you produce regularly in the way of reports or figures → F4 and C3 get a story instead of a slot
- Any scheduling of yours that touched production, planning, a warehouse or quality checks → F1, B2 and B5 get a quote instead of a slot
- The before-and-after discrepancy figures or the spreadsheet itself → F3 can rise from `medium` toward `high`, and C1 gets exact counting answers
- A paste of Quillmoor's about or values page, or search access → A3 becomes company-specific and any published values can be mapped in a cheat sheet
- Hannah's public profile, or the hiring manager's name if she shares it → an interviewer read and a reverse question tied to their path
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes, and it needs search access to be granted → a company strategy brief and CO and CASE questions grounded in it
- A tuesday-dossier.md from an earlier engagement, if you have one → verified evidence and prohibited claims arrive pre-checked
