I'll read the reference files the skill points to before building the pack.
Your prep pack is saved as `quillmoor-diagnostics_operations-coordinator_interview_pack.md`. I built it for Hannah's recruiter screen, using only your message. The web searches were refused, so nothing in it about Quillmoor comes from outside the advert.

Say the word and I'll play Hannah on B3, the question the pack names as your highest-ROI prep: "what have you done that's close to coordinating production schedules between planning, the warehouse and QA?"
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What is your notice period? Your material doesn't settle it, so row F11 and question A5 stay open until you answer.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, a 30-minute phone call with Hannah Lowther (Talent Partner), Thursday at 2pm. She will ring the mobile number on your application.
**Built on:** your message only (the advert, your background, your intended answers, Hannah's LinkedIn message). Searches were refused, so nothing here about Quillmoor comes from outside the advert.
**Hannah's stated agenda:** "salary expectations", "notice period", "how the hybrid pattern would work for you" and "what's prompting a move", then she tells you about the team and next steps.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did. An answer slot is an instruction for the interview, not a question for you now: it names what an interviewer is likely to probe and gives two honest branches.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values (none read, so none used in this pack) |
| EXP | Whether your own account survives follow-up; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | What you know about the company and why you want it |
| CASE | A live problem from the role, reasoned aloud |

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — the advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | Say it in the quote's own terms: four years, logistics coordinator, a building-supplies wholesaler. It is a message line with nothing inspected behind it, so expect a probe on what the four years held, which the next rows answer |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says delivery scheduling across three depots, not production schedules and not a planning or QA function, and the words stay at that scope: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who you worked with likely. If any of that scheduling involved a planning team, a warehouse or a quality function, say how, in your own words; if it did not, or none of it was yours, say so plainly and stay with the deliveries |
| F3 | "track supplier deliveries and chase late orders" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap, with nothing inspected behind it. Lead with the quote's verbs: you schedule deliveries for three depots and chase suppliers when orders slip. The quote says scheduling and chasing, so the words stay on those verbs |
| F4 | "keep stock records accurate" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, but the figure raises the defend-the-number slots (C1): how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. The quote places the rebuild and the fall side by side and does not say one caused the other, so say it as written: "about a third over a year" |
| F5 | "report weekly on on-time dispatch" — the advert | none given | none | [grounded] | discovery | Your material does not show any reporting. Answer slot: the advert names a weekly dispatch report, so expect a probe. If reporting on deliveries or dispatch was part of your work, say what it covered, for whom and how often, in your own words; if there was none, or it was not yours, say so plainly and return to scheduling deliveries for three depots |
| F6 | "confident with Excel" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The quote says spreadsheet and does not say which tool. Answer slot: if it was an Excel workbook, say so and what you used in it, in your own words; if it was another tool, or you used little of what Excel offers, say so plainly and say which tool it was |
| F7 | "ERP experience (SAP or similar) a plus" — the advert, the SAP half | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I've never used SAP." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F8 | "ERP experience (SAP or similar) a plus" — the advert, the "or similar" half | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | discovery | The quote names an in-house stock system and does not say what it covers. Answer slot: if that system held orders, stock or supplier records of the kind an ERP does, say what you used it for, in your own words; if it was a narrower tool, or you used it little, say so plainly and stay with the stock-count spreadsheet |
| F9 | "£38,000–£44,000" — the advert; "your salary expectations" — Hannah's message | "I'm hoping for £42,000." — your message | high | [grounded] | none | Say the number once, as written. It sits inside the advertised range. The quote says hoping, not a floor, and the words stay there; whether any figure is firm is a decision to make before Thursday, because your material does not show it |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol." — the advert; "how the hybrid pattern would work for you" — Hannah's message | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Lead with what answers her: two days at Avonmouth is fine, and you live in north Bristol. The ceiling is a preference, "wouldn't want more than three", and the quote does not say three would suit you, so the words stay there |
| F11 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish it |
| F12 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | Say it in the quote's own terms, plainly. Your material says what you are moving from; it says nothing yet about what draws you to Quillmoor, which B1 handles as a scaffold |

## Reading the interviewer

Public footprint was not researched (search refused), so there is no career pattern here. What exists is how Hannah wrote to you.

| Signal in her message | What it implies for Thursday |
|---|---|
| "a 30-minute phone call with me" | Four topics plus her briefing on the team and next steps in thirty minutes: aim for answers of about a minute each, so her briefing is not squeezed |
| "salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move" | She has told you the questions. All four are in the banks (A2 to A5), so nothing on her list should be new on the call |
| "then I'll tell you about the team and the next steps" | Your reverse questions come after her briefing; cut any she has answered |
| "I'll ring the mobile number on your application" | Take the call somewhere quiet, with the advert and this pack in front of you |

## Persona table

Weights start from the recruiter-screen prior (conversational, with a light skeptic) and are adjusted by Hannah's own agenda. The loop beyond Thursday is not established by anything you gave me, so persona weights rest on this one call; bank E is carry-forward practice, not a prediction of later rounds.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / rapport (5 questions) | Friendly agenda run: salary, notice, hybrid, motivation, then "tell me about yourself" | High: her message sets exactly this register and these topics | A 90-second arc built only from the quotes in A1; treat the casual questions as scored |
| B. Skeptic (4 questions) | Quiet checks on the gaps: why leave, why here, why a manufacturer, SAP | High: "what's prompting a move" is on her list, and F2 and F7 are the advert's visible gaps for you | Rehearse the most predictable objection (B3) until it is boring; bridges only from your quotes, limits said plainly |
| C. Data-driven prober (3 questions) | Presses a figure or a tool: the one-third, Excel, reporting | Medium: she may only skim these, but the figure is the one number you have | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| D. Pressure (3 questions) | Salary and days pushed back on, or a sixty-second comparison | Medium: salary and hybrid are on her list, and a pushback is the natural next step | Pause, restate, hold through two follow-ups, concede only what you decided beforehand |
| E. Case (3 questions) | A live problem from the role | Low for Thursday: her agenda lists no live problem | Clarify, structure, think aloud; the cases claim nothing about your past |

Peer and values personas are left out: no peer is in this round, and no values-style round is detected, since nothing you gave me names one.

## Question banks

**Highest-ROI prep in this pack: B3.** The advert's production, planning and QA line is the widest gap between your material and the job, and it is where a recruiter checks first.

### A. Conversational (weight highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey: what do you do now, and what's led you here?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | A 90-second arc, three beats, each a clause the quotes state: where you are (four years as a logistics coordinator at a building-supplies wholesaler); what the work is (you schedule deliveries for three depots and chase suppliers when orders slip); why you are talking to Quillmoor (your Bristol office is closing next year). Tell them in your own words and stop; she will ask follow-ups | The biography question is the opener of most recruiter screens; F1, F3 and F12 carry it. EXP because it tests whether your own account holds |
| A2 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say it in the quote's own terms: the Bristol office is closing next year, the only offer is relocating to Reading, and you don't want that. One breath, then stop; add nothing about the closure or the offer that you have not already said here. Then move to what draws you to this role, which is B1 | Hannah named it in her agenda, and F12 is the evidence. EXP because it checks that the account matches your own history |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Lead with what answers her: two days at Avonmouth is fine, and you live in north Bristol. If she asks for your limit, say it as the quote does: you wouldn't want more than three. The quote does not say three would suit you, so decide before Thursday whether it would, and say only that | The advert states the two days and she listed it; F10 is the evidence. JD because it scores a stated term of the job |
| A4 | "What are you looking for, salary-wise?" | JD | [grounded] "I'm hoping for £42,000." | Say it once, as written: you are hoping for £42,000. Then stop and let her respond. Answer slot: the quote says hoping, not a floor, so decide before Thursday whether £42,000 is firm or whether there is a lower figure you would accept, and say only what you decided | The advert publishes a range and she listed salary first; F9 is the evidence. JD because the range is a stated term of the job |
| A5 | "And what's your notice period?" | JD | [grounded] | Answer slot: state the length your contract gives, in your own words, and say what, if anything, your employer has said is flexible; if you have not checked your contract, say so plainly and say you will confirm it | She listed it; F11 is the one term your material does not establish, and the answer is only yours to give. JD because it scores whether the start date fits the job |

### B. Skeptic (weight second)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What draws you to Quillmoor and this role, beyond the Reading move?" | CO | [grounded] | Selection scaffold, with nothing from outside the advert: pick one thing the advert actually says about the role or the employer (a diagnostic-test manufacturer, about 400 staff, scheduling between planning, the warehouse and QA, a Bristol site) and say in your own words why it appeals to you, using only what is true for you. If nothing specific comes to mind, say so plainly, then give the nearest thing your own account carries, or say how you would find out | F12 gives the push and nothing on the pull. CO because it tests homework depth, with the research limit honestly shown: the advert is the only source |
| B2 | "You've been in building supplies. Why a diagnostics manufacturer?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Hold on what the quotes carry: four years as a logistics coordinator at a building-supplies wholesaler, scheduling deliveries and chasing suppliers. Answer slot: if you have a reason for the sector, say it, in your own words; if the move is about the work and not the sector, say so plainly. Do not claim manufacturing experience your quotes do not hold | F1 and F2 show a wholesaler, and the job is at a manufacturer. JD because it scores the role's requirement across a sector change |
| B3 | "The job is coordinating production schedules between planning, the warehouse and QA. What have you done that's close to that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal. Hold the quote at its scope: you schedule deliveries for your three depots and chase suppliers when orders slip. Follow-up 1, "that's deliveries, not production": concede the distinction in the quote's own words: "What I schedule is deliveries across three depots." Follow-up 2, "how would you get up to speed": give a plan, never a past; say the first thing you would ask to see, in your own words. Follow-up 3, "have you worked with a planning or QA team": answer slot: if any of that scheduling involved them, say how; if it did not, say so plainly and return to the depots. Hold through all three by returning to the quote, never by adding to it | F2 is where the advert presses hardest, so this objection arrives in some form. JD because it scores the stated core of the job |
| B4 | "You've not used SAP. How would you feel about picking up an ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Acknowledge it plainly: you've never used SAP. Answer slot: if the in-house stock system held orders, stock or supplier records, say what you used it for, in your own words; if it was a narrower tool, or you used it little, say so plainly. Then a plan, said as a plan: how you would learn the system. Never claim you pick systems up fast; nothing in your material says so | F7 is a stated gap and F8 is the unknown beside it. The advert marks ERP as a plus, so the honest answer is short. JD because it scores a listed plus |

### C. Data-driven prober (weight third)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say the figure as written: about a third over a year. Answer slot, four parts, each in your own words: how it was counted; what it is sensitive to; which assumption behind it you would defend least; which part was yours. Where you do not know how something was counted, say so plainly; that is an honest answer. Do not say the rebuild caused the fall unless you can back it | F4 holds the only figure in your material, and a figure is a probe magnet. EXP because it tests attribution |
| C2 | "Which tools did you use in that spreadsheet?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: say which application it was and what you used in it, in your own words; if it was not Excel, say so plainly and say what it was. Name the features here only if you can describe how you used them | F6 is thin: the quote says spreadsheet. JD because the advert asks for Excel confidence |
| C3 | "What reporting do you do on deliveries or dispatch?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if reporting on deliveries or dispatch was part of your work, say what it covered, for whom and how often; if there was none, or it was not yours, say so plainly and return to scheduling deliveries for three depots | F5 is a requirement with no evidence behind it, and the advert names the weekly report. JD because it scores a stated responsibility |

### D. Pressure (weight fourth)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our range is £38,000 to £44,000. Could you do £40,000?" | JD | [grounded] "I'm hoping for £42,000." | Hold-then-concede. Pause, then restate: you are hoping for £42,000. Hold through two follow-ups by restating, not by arguing. Concede only what you decided beforehand; your material does not show whether £42,000 is firm. If you decided nothing, say you would like to hear more about the role before discussing a lower figure | F9 is the evidence. JD because the range is a stated term, with pressure delivery |
| D2 | "Hybrid is two days at Avonmouth. Could you do three if the team needed it?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Hold at the quote's scope: two days is fine; you wouldn't want more than three. Resolve downward: the quote does not say three would suit you. Decide beforehand whether it would, and answer only that. Do not turn a preference into "can't", and do not add reasons the quote does not hold | F10 states a ceiling as a preference and the question tests it. JD because it scores a stated term, with pressure delivery |
| D3 | "Sixty seconds: why you over someone who already knows SAP?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." "Never used SAP — we run our own in-house stock system." | Pause, restate the question, anchor in what you stated: you schedule deliveries for three depots, chase suppliers when orders slip, and rebuilt a stock-count spreadsheet where discrepancies fell by about a third over a year. Concede the SAP point in one clause: you've never used SAP. Do not claim you would learn faster than the other candidate; nothing in your material says so | F3, F4 and F7 are the three rows this answer stands on. JD because it scores the listed plus, with pressure delivery |

### E. Case (weight lowest, carry-forward practice)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you a delivery production needs on Monday will be five days late. Walk me through your first hour." | CASE | [generic] | Structure it aloud: what you would ask first (what is on the delivery, who needs it, how firm the new date is); what you protect (the dispatch date); the options; who you tell (planning, the warehouse and QA are the three functions the advert names); what you record. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's supplier-chasing line (F3's requirement). CASE because it asks for a decision, not a record; generic because it is a pattern, not a fact about Quillmoor |
| E2 | "The stock record says there is enough of a component for tomorrow's batch; the warehouse count says there isn't. What do you do?" | CASE | [generic] | Structure it: what you would check first (which is wrong, the record or the count), who needs to know today, what you do about the batch, how you correct the record, what you would look at so it does not recur. The guidance makes no claim about your past | A live problem from the advert's stock-records line (F4's requirement). CASE because it is a decision in the moment; generic for the same reason as E1 |
| E3 | "How would you structure a weekly on-time dispatch report so planning, the warehouse and QA could all act on it?" | CASE | [generic] | Clarify first: what counts as on time and against which date. Then structure: what is measured, how late orders are shown, who gets which cut, how often. The guidance makes no claim about your past | A live problem from the advert's reporting line (F5's requirement). CASE because it asks for design reasoning; generic because it is a pattern |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1 |
| Coordinate production schedules between planning, the warehouse and QA | B3, E1 |
| Track supplier deliveries and chase late orders | A1, E1 |
| Keep stock records accurate | C1, E2 |
| Report weekly on on-time dispatch | C3, E3 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B4, D3 |
| Hybrid, two days a week at Avonmouth | A3, D2 |
| £38,000–£44,000 | A4, D1 |
| Hannah's "your notice period" | A5 |
| Hannah's "what's prompting a move" | A2, B1 |
| Hannah's "how the hybrid pattern would work for you" | A3, D2 |
| Hannah's "your salary expectations" | A4, D1 |

## Reverse questions

Ask these after Hannah's briefing on the team and next steps; drop any she has answered.

| # | Question | Why it lands |
|---|---|---|
| R1 | "How does the role split its week between planning, the warehouse and QA?" | It follows the advert's own line and shows you read the coordination point, not only the title |
| R2 | "The advert lists ERP experience as a plus. Which system does the team use, and how is someone new brought onto it?" | It raises the SAP gap yourself, as a practical question, and turns it into a ramp-up conversation |
| R3 | "How is on-time dispatch measured at the moment, and who reads the weekly report?" | It ties to the advert's reporting line and shows you think about the report's reader |
| R4 | "What would you want the person in this role to have learned or changed by the end of three months?" | It asks what good looks like in her terms and gives you a target to repeat back |
| R5 | "On the two days at Avonmouth, are they fixed for the team or flexible?" | It checks the hybrid pattern in practice before you commit to it |
| R6 | "Where in the £38,000–£44,000 range does the budget sit for this role?" | It is a calm way to learn how your £42,000 lands, and it comes only after she has raised salary |
| R7 | "What are the next steps, and who would the next conversation be with?" | It closes the call with a clear next action and tells you who to prepare for |

## Prohibited claims

What this pack will not coach, and why. Each entry is built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Has SAP experience | Negative you stated, F7 | Your quote: "Never used SAP — we run our own in-house stock system." The plain acknowledgment: "I've never used SAP." The in-house system is F8's answer slot, and nothing more |
| Has ERP experience | Inflated form of F8 | F8's quote at its own scope. The limit is the pack's observation: your material says an in-house stock system, not an ERP. B4's slot stays inside what that system held |
| Coordinated production schedules | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says delivery scheduling for three depots, not production schedules or a planning or QA function. B3's slot stays inside the scheduling |
| Cut stock discrepancies by a third with the rebuild | Inflated form of F4 | F4's quote at its own scope: "about a third over a year", with the rebuild and the fall side by side. The limit is the pack's observation: the quote does not say one caused the other. C1's slots ask only how it was counted and what was yours |
| £42,000 is my minimum | Inflated form of F9 | F9's quote: "I'm hoping for £42,000." The limit is the pack's observation: your material says hoping, not a floor. A4 and D1 hold the quote and nothing firmer |
| Three days a week suits me | Inflated form of F10 | F10's quote: "I wouldn't want more than three." The limit is the pack's observation: the quote states a ceiling and does not say three would suit you. A3 and D2 stay at that scope |
| My role is being made redundant | Inflated form of F12 | F12's quote: "our Bristol office is closing next year and the only offer is relocating to Reading." The limit is the pack's observation: your material says the office is closing and what was offered, not the status of your role |

## Sources

**Provided documents:** your message (the advert, your background, your intended answers, Hannah's LinkedIn message). No dossier was present.

**Searches sent, each refused:**

- "Quillmoor Diagnostics company values": refused
- "Quillmoor Diagnostics Avonmouth news": refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Would have moved B1's guidance with the company's published value names. It does not affect the pack's structure, since no values-style round is detected |
| 2. Quillmoor Diagnostics interview process, operations | skipped | Your own words fix the one session this pack prepares for: a 30-minute phone call with the recruiter, with a stated agenda. They fix the persona weights |
| 3. Quillmoor Diagnostics strategy, recent news | unavailable | Would have moved B1 and added a current-strategy CO question |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | Would have moved the interviewer read with her career pattern and added a reverse question tied to her own path |
| 5. Representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot and every JD-tagged question |

## Upgrade menu

- Your notice period → F11 stops being a surfaced gate and A5 becomes a worked answer
- Your own answers to the slots in F2, F5, F6 and F8, written to me outside a drill → those rows gain your own quoted words and the matching bank guidance sharpens
- A copy of your application or CV, pasted → F1 to F4 become checkable against what Hannah has already seen, and C1's premise can be matched to it
- Hannah's LinkedIn headline or About text, pasted → a real interviewer read and a reverse question tied to her path
- Permission to search the web → target 1 (values), 3 (strategy) and 4 (Hannah) run, and B1 gains the company's current priorities in its own words
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief and a differentiator question; offered once, only if search is allowed
- What Hannah says about next steps on Thursday → per-round mini-packs for each scheduled round
- No tuesday-dossier.md was present → one would add verified evidence and objections to rank
