I'll read the reference files the skill requires before building the pack.
The pack is written and saved. These are the last steps: presenting it and asking what I still need.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/e23/part-7/rooms/case-13-denied-62095784/quillmoor_operations-coordinator_interview_pack.md`. I built it as a recruiter screen on Hannah's own agenda, from the advert and your notes, with no CV.

- **Highest-ROI prep:** B1, "Is it fair to say you're looking mainly because your office is closing?" Your reason is about leaving, not about Quillmoor, so expect a why-us follow-up. The pack has you hold your stated reason and name the limit before she asks.
- **Other likely probes:** SAP, production scheduling across planning, the warehouse and QA, and weekly on-time dispatch reporting. The pack marks each of these as an answer slot or a plain acknowledgment, not a claim.
- **Research:** my four web searches were refused, so there are no Quillmoor values, strategy or interviewer facts in the pack. The "why Quillmoor" question is generic, and the upgrade menu says what searching would add.

Say the word and I'll play Hannah on B1, so you can rehearse the follow-ups out loud.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What is your notice period? Your material doesn't say, Hannah has put it on her agenda, and your answer replaces A4's slot with your own words.
Would you like to paste your CV, or shall I go on without it? Your CV lines would replace your message as the quoted evidence and could settle the Excel question in F6.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Operations Coordinator, Quillmoor Diagnostics: recruiter screen pack

**Interviewer:** Hannah Lowther, Talent Partner. **Round:** recruiter screen, a 30-minute phone call on Thursday at 2pm, to the mobile number on your application. **Built for:** Sam.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the company's published values |
| EXP | Work-experience deep-dive: does what you claim survive scrutiny, and what was actually yours |
| JD | Role or advert-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge: how well you know Quillmoor |
| CASE | A live problem from the actual role, asked as a hypothetical |

An answer slot is an instruction for what to say in the interview. It asks nothing of you here. If one branch is true for you, say that branch. If neither fits, say so plainly and return to the fact your own sentence states.

The single highest-ROI rehearsal is **B1**, the "is this really about us, or about the office closing?" question. It is the likeliest probe aimed at where your material is thinnest. Rehearse it until it is boring.

## Fit snapshot

Requirements are quoted from the advert, or from Hannah's message where she named the topic. Evidence is your own words, quoted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap, but a self-described line with nothing inspected behind it, so expect a probe. Say it in the quote's own terms: four years as a logistics coordinator at a building-supplies wholesaler |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Words at the quote's scope: "I schedule deliveries for our three depots." The material shows deliveries, not production schedules, and says nothing of planning, warehouse or QA contact. Answer slot: the advert's line makes a probe on this likely. If any of your scheduling brought you into contact with planning, warehouse or QA teams, say how, in your own words; if it did not, or it was not yours, say so plainly and stay with the deliveries for the three depots |
| F3 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | The chasing half is in the quote's own terms: "I chase suppliers when orders slip." The word "track" is not in your sentence, so say chase, and describe tracking only if you can say in your own words what you tracked |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | Lead with the two facts as stated: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. The sentence sets them side by side and does not say how the fall was counted or that the rebuild caused it, so expect the probe on the figure (C1, C2, E1) |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show reporting of this kind. Answer slot: the advert's weekly-reporting line makes a probe likely. If you produce any regular report on deliveries or timeliness, say what it covers and how often, in your own words; if you do not, say so plainly and stay with scheduling deliveries and chasing suppliers |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | Derived from "spreadsheet" to Excel, which your sentence does not say, and it names no features. Answer slot: the advert lists Excel among the requirements, so expect a probe. If the spreadsheet was Excel, say so and what you did in it, in your own words; if it was another tool, say so plainly and stay with the rebuild as you stated it |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used SAP." Then how you would learn it, said as a plan and never as a past. The advert calls it "a plus" |
| F8 | "ERP experience (SAP or similar) a plus" — advert, the "or similar" half | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | discovery | Your sentence names an in-house stock system and does not say whether it is comparable to an ERP, and the pack does not call it one. Answer slot: if you would put the in-house system alongside an ERP, say what you used it for, in your own words; if you would not, say so plainly and stay with "we run our own in-house stock system" |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | medium | [grounded] | none | The figure sits inside the advertised band. Say it as you said it, a hope. Your message gives no floor, so the pack writes no minimum or walk-away number for you; decide yours before Thursday |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Both halves are stated: two days is fine, more than three is not wanted. Say both as you said them, the second as a plain limit and not an apology |
| F11 | "your notice period" — Hannah Lowther's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. It is a term she named in her agenda, so it is surfaced here and not bridged. A4 carries it |
| F12 | "what's prompting a move" — Hannah Lowther's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | The reason is stated and specific; say it in the quote's own terms. It says why you are looking, not why Quillmoor, and that second half is not in your material. B1 and B5 carry it as an answer slot |

## Persona table

Weights are a shown judgment, so recalibrate if you know something this pack does not. The loop is one session: Hannah's message says "a 30-minute phone call with me", then "I'll tell you about the team and the next steps." No source documents any later rounds, so nothing here assumes them.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder (bank A) | Friendly, logistics-first questions: pay, notice, hybrid, the journey | High. Hannah lists her agenda in order: "salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move". A recruiter screen's prior is a friendly register, and the risk is treating it as unscored | Have a short, plain answer ready for each of the four named topics, and treat the casual register as scored |
| Skeptic (bank B) | Quiet consistency checks on motive and on the advert's requirement list | High. "What's prompting a move" invites a why-us probe, and the advert's list has gaps the fit snapshot shows (F2, F5, F6, F7) | Rehearse B1 until boring; say the limit plainly before it is asked for, and give a plan, never a past, where your material is silent |
| Data-Driven Prober (bank C) | Digs into the one figure on your application | Medium. Her message names no CV deep-dive, but a headline figure (F4) is where any careful reader of the application goes next | Know what you can and cannot say about how the figure was counted, and say plainly if you do not know |
| Case / Strategist (bank D) | A small live problem from the duties | Medium. Her message names no scenario, but the advert's duties are scenario-shaped (late suppliers, stock accuracy, dispatch) | Clarify first, then structure, then answer; think aloud |
| Pressure (bank E) | A time-boxed or devil's-advocate challenge | Low. Nothing in her message signals it, so it is kept short as insurance | Pause, restate, hold the position your own sentence carries through two follow-ups, concede specifically |

No values-style round is detected: no source read documents one, and the only loop evidence is Hannah's own message. The values cheat sheet is therefore not part of this pack.

## Question banks

### Bank A: Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey: what are you doing now, and what's prompting a move?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Three beats, each one your sentences state: four years as a logistics coordinator at a building-supplies wholesaler; the Bristol office closing next year; the only offer being relocation to Reading, which you don't want. Tell them in your own words and stop there. Answer slot: why this role in particular. If something specific in the advert drew you, say what, in your own words; if the move is mainly about the closure, say that plainly | F1 and F12 are the evidence, and Hannah named the motive in her agenda, so this arrives early. EXP because it tests whether the story you tell matches your own account |
| A2 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." | Say it plainly, as stated: "I'm hoping for £42,000." The advert's band is £38,000–£44,000, and the figure is inside it. Your message gives a hope and no floor, so decide before Thursday what you would say if the number came back lower; the pack does not write that for you. If she asks what you earn now, decide beforehand whether to share it, since your material gives no figure | F9 is the evidence; pay is the first item she listed. JD because it scores your expectation against the advertised band |
| A3 | "How would the hybrid pattern work for you, with two days a week at Avonmouth?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Both halves as you said them: "I live in north Bristol, so two days at Avonmouth is fine." If she asks about the limit: "I wouldn't want more than three." Answer slot: if she asks about an occasional extra day, say what is true for you; if you would flex for a particular occasion, say so, and if you would not, say so plainly | F10 is stated with a limit, and her agenda names the pattern. JD because it scores a term of the role |
| A4 | "What's your notice period?" | JD | [generic] | The pack has no notice period for you, so this guidance makes no claim about your past. Answer slot: state your notice exactly as your contract gives it; if you have not checked it, check before Thursday. Do not promise flexibility you have not confirmed with your employer. If she asks how the office closing affects your timing, say what you know and what you do not | F11 is the one gate your material says nothing about, and she named it. JD because it scores availability against the role, not a competence |
| A5 | "So what's your day-to-day like at the moment?" | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Two beats, both in the sentence: you schedule deliveries for your three depots, and you chase suppliers when orders slip. Tell them in your own words and stop. Tools, volumes and reporting are not in your sentence, so the pack supplies none; if she follows up, answer from what is true | F2 and F3 are the evidence; the casual opener is the likeliest way into the duties. EXP because it tests what you actually do |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Is it fair to say you're looking mainly because your office is closing?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | **Highest-ROI prep.** Hold: the sentence is your reason, so say it as stated. The closure next year and the Reading-only offer, which you don't want, are why you are looking. Follow-up one, "so it's not really about us?": concede specifically that the closure is what started the search, then the slot. Answer slot: if something in the Quillmoor advert appeals, say what, in your own words; if nothing beyond staying in Bristol does yet, say so plainly and say what you hope to learn on this call. Follow-up two, "would you stay if Reading changed?": your sentence says only that the only offer is Reading, which you don't want, so answer from what is true for you and commit to nothing beyond it. Limit, named before she asks: your material shows no draw to Quillmoor or to manufacturing, so add none | F12 is the evidence, and it is the likeliest probe because the stated reason is about leaving, not arriving. EXP because it tests whether your account holds up under follow-ups; deepest rehearsal because it will be asked in some form |
| B2 | "The advert says SAP or a similar ERP. Where do you stand on that?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Plain acknowledgment from your own sentence: "I haven't used SAP." Then, at its own scope: "we run our own in-house stock system." Answer slot: if you would put the in-house system alongside an ERP, say what you used it for, in your own words; if you would not, say so plainly. Then a plan for learning it, said as a plan and never as a past. The advert lists it as "a plus", which you may note | F7 and F8 are the evidence; a stated gap against a listed item will be raised. JD because it scores a stated plus |
| B3 | "This role coordinates production schedules between planning, the warehouse and QA, and you've come from a building-supplies wholesaler. Which part of that would be new to you?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Hold at the sentence's scope: "I schedule deliveries for our three depots and chase suppliers when orders slip." Concede that your material shows deliveries, not production. Answer slot: if any of your scheduling touched planning, warehouse or QA teams, say how, in your own words; if it did not, or it was not yours, say so plainly and stay with the depots. Then how you would learn the production side, as a plan | F2 is the widest gap against the advert's lead duty. JD with a Skeptic delivery, because it asks you to name your own weakest area |
| B4 | "The role reports weekly on on-time dispatch. What reporting do you do now?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The question presupposes reporting, and your material does not show any. Answer slot: if you produce a regular report on deliveries or timeliness, say what it covers and how often, in your own words; if you do not, say so plainly and return to what your sentence does carry: scheduling deliveries for three depots and chasing suppliers when orders slip | F5 is silence in your material against a stated duty. JD because it scores the advert's reporting line |
| B5 | "Why Quillmoor, and why a manufacturer?" | CO | [generic] | Makes no claim about your past. Research could not run, so the pack holds no Quillmoor facts beyond the advert: "diagnostic-test manufacturer, about 400 staff". Answer slot: say what in the advert or the call draws you, in your own words; if the honest answer is that the role fits your search and you want to learn more, say that plainly | F12's second half is not in your material, so a why-us probe is likely. CO, but `[generic]` because strategy research was refused; it becomes `[grounded]` if research runs |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. Walk me through how that was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say the figure as you gave it, "about a third over a year", no rounder and no more precise. Answer slots, in your own words: how it was counted; what it is sensitive to; which part of the rebuild was yours. If you do not know how it was counted, say so plainly. Your sentence sets the rebuild and the fall side by side, so do not say the rebuild caused all of it | F4 is the one figure in your material, and a figure is where a careful reader goes. EXP because it tests attribution and counting |
| C2 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | The weakest-assumption move: name it before she does. Answer slot: if you know one, say it in your own words; if you do not know how the figure was counted, say that plainly. The pack names no assumption for you | F4 again; naming the weak point first converts a gotcha into credibility. EXP |
| C3 | "How comfortable are you with Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Your sentence says spreadsheet. Answer slot: if it was Excel, say so and what you did in it, in your own words; if it was another tool, say so plainly and stay with the rebuild as you stated it. The pack names no features for you | F6 is a derivation, not a quote; the advert lists Excel and nothing in your material confirms the tool. JD because it scores a stated requirement |

### Bank D: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you at 4pm that a key delivery will be a week late, and production is planned for Monday. What do you do first?" | CASE | [generic] | Makes no claim about your past. Clarify first: what is late, what depends on it, what the supplier can commit to. Then who needs to know, among planning, the warehouse and QA, the three teams the advert names. Then what you record and what you report. Think aloud | The advert's duties include chasing late orders and coordinating the three teams, so this is the duty set as a decision. CASE; `[generic]` because it is a pattern for the problem, not a fact about Quillmoor |
| D2 | "The weekly on-time dispatch figure drops two weeks running. Where do you look first?" | CASE | [generic] | Makes no claim about your past. Clarify how the figure is defined, then segment, then test the likeliest causes, then say what you would report and to whom | The advert's weekly dispatch line, asked as a diagnosis. CASE; `[generic]` |
| D3 | "The system says a high-value item is in stock and the shelf says otherwise. Walk me through it." | CASE | [generic] | Makes no claim about your past. What you check first, who you tell, how you correct the record, and how you stop it recurring | The advert's "keep stock records accurate", asked live. CASE; `[generic]` |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That result: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold the sentence through two follow-ups: "I rebuilt our stock-count spreadsheet." Concede specifically: the sentence does not say whether the rebuild accounts for all of the fall, and you can say that plainly. Answer slot: if others contributed, say who and what; if not, say so plainly | F4 is the attribution target. EXP delivered as pressure |
| E2 | "Sixty seconds: why you, rather than someone who already knows SAP and manufacturing?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "Never used SAP — we run our own in-house stock system." | Pause and restate the question. Anchor in your sentences: four years as a logistics coordinator at a building-supplies wholesaler; you schedule deliveries for three depots and chase suppliers when orders slip. Concede the one thing stated: "I haven't used SAP." Add no claim about manufacturing, since your material shows none | F1 and F7 pull in opposite directions here. JD delivered as pressure |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in operations or logistics coordination" | A1, A5, E2 |
| "Coordinate production schedules between planning, the warehouse and QA" | B3, D1 |
| "track supplier deliveries and chase late orders" | A5, D1 |
| "keep stock records accurate" | C1, C2, D3, E1 |
| "report weekly on on-time dispatch" | B4, D2 |
| "confident with Excel" | C3 |
| "ERP experience (SAP or similar) a plus" | B2, E2 |
| "£38,000–£44,000" | A2 |
| "Hybrid: two days a week at our Avonmouth site in Bristol" | A3 |
| Notice period (Hannah's agenda) | A4 |
| What's prompting a move (Hannah's agenda) | A1, B1 |
| Why Quillmoor | B5 |

## Reverse questions

Hannah has said she will cover the team and next steps, so these are for the slot after that.

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "What does a good first three months look like for this role?" | It points the conversation at the work, not the terms | [generic] |
| R2 | "Who would I work with most day to day across planning, the warehouse and QA?" | It uses the advert's own three teams and shows you read the duty | [generic] |
| R3 | "Which systems does the team use day to day, and how is onboarding handled for any I haven't used before?" | It raises the tooling gap yourself, as a practical question and not an apology | [generic] |
| R4 | "How are the two Avonmouth days set: fixed days, or agreed with the team?" | It tests the hybrid detail against the limit you stated | [generic] |
| R5 | "Is on-time dispatch the main number the role is measured on?" | It picks up the advert's weekly reporting line and asks what success is | [generic] |
| R6 | "What are the next steps and timing after today, and who would the next conversation be with?" | It clarifies the process and lets you line up your own timing | [generic] |

## Prohibited claims

What this pack will not coach, built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules across planning, the warehouse and QA | Inflated form of F2 | F2's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: the material says deliveries, not production schedules or QA contact. B3's slot stays inside the deliveries |
| Advanced Excel skills (formulas, pivots, macros) | Inflated form of F6 | F6's quote at its own scope: you rebuilt a stock-count spreadsheet. The limit is the pack's observation: the material says spreadsheet, not Excel and not features. C3's slot asks only which tool |
| Has used SAP | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I haven't used SAP." No slot |
| The in-house stock system is an ERP | Inflated form of F8 | F8's quote at its own scope: "we run our own in-house stock system." The pack's observation is that the material does not say whether it is comparable. B2's slot asks only what you used it for |
| Cut stock discrepancies by exactly a third, because of the rebuild | Inflated form of F4 | F4's quote at its own scope: "about a third over a year", with the rebuild stated beside it. The limit is the pack's observation: the material does not say how the fall was counted or that the rebuild caused it |
| £42,000 is my minimum | Inflated form of F9 | F9's quote at its own scope: "I'm hoping for £42,000." |
| I'm flexible on office days | Claim one of your quotes contradicts, F10 | The contradicting quote only: "I wouldn't want more than three." |
| I'm being made redundant | Inflated form of F12 | F12's quote at its own scope: the Bristol office is closing next year and the only offer is relocating to Reading, which you don't want |

## Sources

Provided documents: the Operations Coordinator advert as pasted; Hannah Lowther's LinkedIn message as pasted; your own notes in the message (the "about me" paragraph and the "what I'd tell her" paragraph). No CV was provided. No dossier was provided.

Searches sent, all refused because web search was not permitted in this session:

- "Quillmoor Diagnostics values": refused
- "Quillmoor Diagnostics interview process operations coordinator": refused
- "Quillmoor Diagnostics strategy news": refused
- "Hannah Lowther Quillmoor Diagnostics": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Would have named Quillmoor's published values for the reverse bank and B5; it moves no section 10 content, since no values-style round is detected |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Would have documented any later rounds. This session's one call rests on Hannah's own message, so persona weights are unaffected |
| 3. `Quillmoor Diagnostics strategy news` | unavailable | Would have grounded B5 in current strategy, so B5 is `[generic]` and no grounding brief is included |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Would have supported an interviewer read and one reverse question tied to her path; both are absent |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → A4 becomes your own words instead of a slot, and F11 stops being a surfaced gate
- Your CV, pasted → F1 to F6 evidence cells can quote CV lines, and F6's Excel question may close
- Your answers to the slots in F2, F5, F6 and F8 (any scheduling contact with planning, warehouse or QA; any regular dispatch or timeliness reporting; whether the spreadsheet was Excel; what the in-house system is used for) → each row is regenerated from your words, and B3, B4, B2 and C3 follow
- Web search permission, then a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → B5 and the reverse bank are grounded in Quillmoor's published values and strategy, a grounding brief is added, and Hannah's public professional footprint supports an interviewer read
- A tuesday-dossier.md from the job-underwriter → verified evidence and a named top objection in place of this pack's inferred one, plus explicit limits per weak area
- The schedule of any later rounds → per-round mini-packs with their own persona weights
