I'll read the reference files the skill points to before building the pack.
I've saved your prep pack, and what's left is to hand it over. I tried three web searches on Quillmoor and Hannah, but the host refused all three, so nothing in the pack comes from the web.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/sonnet/e23/part-7/rooms/case-13-denied-93e2af72/quillmoor-diagnostics_operations-coordinator_interview_pack.md`. I built it only from the advert, Hannah's message and your description of your background, as a recruiter screen. It has 18 practice questions, a fit table against the advert, and six questions for you to ask her.

- **Biggest gap:** the advert asks you to coordinate production schedules between planning, the warehouse and QA. What you described is delivery scheduling for three depots. Question B1 rehearses that, and it's the pack's highest-value prep.
- **SAP:** the advert calls it a plus, and you've said you haven't used it. The pack lets you say that plainly and rehearses how you'd get up to speed.
- **Your £42,000 and your hybrid limit:** both fit the advert. The pack keeps the exact wording you gave, including "I wouldn't want more than three", so it doesn't turn into "flexible".
- **Why Quillmoor:** your material gives a reason for leaving but not a reason for choosing them. Question B4 flags this, and it's worth reading their site before Thursday.

Say the word and I'll play Hannah on B1, so you can practise that answer out loud.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What is your notice period? It decides how the pack handles that question (A4), which Hannah has said she'll ask and which your material doesn't cover.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, 30-minute phone call, Thursday at 2pm
**Interviewer:** Hannah Lowther, Talent Partner. Relationship: recruiter. She said she will cover salary expectations, notice period, how the hybrid pattern would work for you and what is prompting a move, then tell you about the team and next steps.
**Built from:** the advert, Hannah's message and your own description of your background, all as you pasted them. No CV, no web research (see Sources).

## 1. How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding for your own words, not a script.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny and what was actually yours |
| JD | The advert's stated duties and requirements, gaps included |
| CO | Homework on the company and why this employer |
| CASE | A live problem from the actual role, reasoned aloud |

Provenance labels: `[grounded]` traces to something you or the advert or Hannah wrote; `[inferred]` is derived from an adjacent source; `[generic]` is a pattern with no claim about you or Quillmoor.

An **answer slot** is an instruction for the interview, not a question to you now. It names what an interviewer is likely to probe and gives two honest branches: say what you did in your own words, or say plainly that the step was not yours or did not exist, then return to what your own sentences carry.

The question the pack names as the highest-ROI prep is **B1**.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — JD | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | transferability | Your material says deliveries for three depots and chasing suppliers, not production schedules, and the words stay at the depots: "I schedule deliveries for our three depots." Answer slot: the JD's line on coordinating between functions makes a probe on who else was involved in your scheduling likely. If others were, say who and which part was yours, in your own words; if none were, or you set the schedules alone, say so plainly and describe how you scheduled the depots |
| F2 | "chase late orders" — JD | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with the sentence's own terms: you chase suppliers when orders slip |
| F3 | "track supplier deliveries" — JD | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | low | [grounded] | discovery | Scheduling deliveries and chasing suppliers touches tracking without showing how orders were followed. Answer slot: the JD's tracking line makes a probe on how you knew an order was slipping likely. If you followed orders in a particular way, say how, in your own words; if there was no set way, or it was not yours, say so plainly and describe what you do |
| F4 | "keep stock records accurate" — JD | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap, but a figure with nothing inspected behind it, so expect the defend-the-number probe. Keep "about a third" as "about a third". Answer slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours; "I don't know how it was counted" is an honest branch |
| F5 | "report weekly on on-time dispatch" — JD | none given | none | [grounded] | discovery | Your material is silent on reporting. Answer slot: the JD's line makes a probe on what you report likely. If you report on deliveries or dispatch to anyone, say what and how often; if you do not, or no such reporting exists, say so plainly and describe what you do keep track of |
| F6 | "2+ years in operations or logistics coordination" — JD | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap. Say it in the sentence's terms: four years, logistics coordinator, building-supplies wholesaler. A years requirement is confirmed by the number, so expect confirmation and little more |
| F7 | "confident with Excel" — JD | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | low | [grounded] | discovery | Your sentence says a spreadsheet, not which tool. Answer slot: the JD's Excel line makes a probe likely. If the spreadsheet was in Excel, say what you did in it, in your own words; if it was in another tool, say so plainly and describe the spreadsheet as you built it |
| F8 | "ERP experience (SAP or similar) a plus" — JD | "Never used SAP — we run our own in-house stock system" — your message | low | [grounded] | discovery | The JD marks this a plus. Your own words for SAP stay yours: "Never used SAP." Your material says an in-house stock system and nothing about what it covers. Answer slot: the JD's "or similar" makes a probe on that system likely. Say what you use it for, in your own words; if you have not used it for much, say so plainly |
| F9 | "£38,000–£44,000" — JD | "I'm hoping for £42,000" — your message | medium | [grounded] | none | Met on your statement: the figure sits inside the advertised range. Your material gives a hope, not a floor, and the words stay "I'm hoping for £42,000". Decide before Thursday what you would say to a lower number (E2) |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — JD | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | Met on your own statement. Keep both halves together: two days at Avonmouth is fine, and you wouldn't want more than three. Do not shorten it to "flexible" |
| F11 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish it |
| F12 | "what's prompting a move" — Hannah's message | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | No gap: the reason is plain and stated. Say it in the sentence's terms. Expect a follow-up on timing. Answer slot: if you know when the office closes, say so; if you do not, say so plainly |

## 3. Persona table

Weights rest on the recruiter-screen prior (Conversational plus a light Skeptic, from the persona model) and on Hannah's own message. Only this one call is established; nothing is claimed about later rounds.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured; the four agenda items arrive as chat | Highest. The recruiter-screen prior puts it first, and Hannah's message announces a conversational agenda and says she will tell you about the team afterwards. Depth: 5 | A 90-second arc for the biography question; treat casual questions as scored; never answer "I think you've covered everything" at the reverse-question slot |
| Skeptic | Quiet probing of gaps and of "why leave, why us, why now" | High. The prior adds a light Skeptic, her agenda includes what is prompting a move, and the advert asks for more than F1 and F8 show. Depth: 5 | Rehearse B1 until it is boring; bridge only from your own sentences; say a concrete ramp plan as a plan |
| Data-Driven Prober | Asks how a number was counted | Lower. The prior does not put it in a recruiter screen, but F4 is your one headline figure and figures attract it. Depth: 3 | Know what you can and cannot say about how the figure was counted; say plainly when you do not know |
| Case / Strategist | A live scheduling or stock problem | Low for this call. The hiring-manager prior leans this way, and Hannah's agenda names no case. Included so you meet the style once. Depth: 3 | Clarify, then structure, then answer; think aloud |
| Pressure | Pushback on salary or days on site | Low. Two of Hannah's four agenda items are terms that invite negotiation. Depth: 2 | Hold the position through two follow-ups, then concede only what you can name |

Values and Peer personas are not weighted: no round that assesses values is established for this call, and no peer is named.

## 4. Question banks

### A. Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey: where you are now and what's prompting a move." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Three beats, each in your own words: four years as a logistics coordinator at a building-supplies wholesaler; you schedule deliveries for three depots and chase suppliers when orders slip; you're looking because the Bristol office is closing next year and the only offer is relocating to Reading, which you don't want. Give the facts as facts and stop | F6 and F12 are the two rows this question draws on, and both are things Hannah named she would ask. EXP because it tests whether your account of your own history is consistent |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" | Say the figure and let it stand: "I'm hoping for £42,000." Answer slot: if she asks how you arrived at it, say the basis in your own words; if it is a preference with no further basis, say so plainly | F9 is inside the advertised range. JD because the advert states the range and Hannah put salary first on her agenda |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Say both halves in the order you said them: two days at Avonmouth is fine, and you wouldn't want more than three. Do not trade the second half for "flexible" | F10 is a term the advert states and Hannah put on her agenda. JD because it scores the advert's stated pattern |
| A4 | "What's your notice period?" | JD | [grounded] | Your material does not state it, so the pack writes nothing for you. Answer slot: say your notice period exactly as your contract gives it, in your own words; if you are not sure, say you will confirm by message after the call | F11 is a hard gate the material does not settle, so the pack surfaces it and does not bridge it. JD because it is a term of the hire, asked casually |
| A5 | "What are you actually using day to day to keep track of stock?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year"; "Never used SAP — we run our own in-house stock system" | Name the two things your sentences name: the stock-count spreadsheet you rebuilt and the in-house stock system. If SAP comes up, your words are "Never used SAP." Answer slots: if the spreadsheet was in Excel, say what you did in it; if it was another tool, say so plainly. Say what you use the in-house system for; if you have not used it for much, say so plainly | F7 and F8 are the two plus-skills in the advert, asked here in the casual register where they are still scored. JD because it scores the advert's stated tools |

### B. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role coordinates production schedules between planning, the warehouse and QA. What have you done that's like that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | The highest-ROI prep in this pack. Hold only what the quote carries: "I schedule deliveries for our three depots." Hold through two follow-ups by returning to the depots, never by adding to them. The concession, in your words: what you've done is scheduling deliveries and chasing suppliers, and production scheduling is what you would be learning. Answer slot: if others were involved in your scheduling, say who and which part was yours; if none were, or you set the schedules alone, say so plainly and describe how you scheduled the depots | F1 is the widest gap between the advert's headline duty and your own sentences, so this objection arrives in some form. JD because it scores a stated duty; the Skeptic delivery is the "what have you actually done" probe |
| B2 | "You've told us you haven't used SAP. How would you get up to speed on a new system like that?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Start with your own words: "Never used SAP." Then say the plan as a plan, in your own words: what you would learn first, who you would ask, how you would practise. Answer slot: say what you use the in-house system for; if you have not used it for much, say so plainly | F8 is the stated negative, and the advert marks ERP as a plus, so the probe is likely and low-stakes if the answer is calm. JD because it scores a listed requirement |
| B3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip"; "Never used SAP — we run our own in-house stock system" | Choose honestly from where your own sentences stop: the pack's observation is that the advert goes further than them on production scheduling across functions (F1) and on ERP (F8). Name one, say how you would close it, and do not invent a weakness to sound modest | F1 and F8 are the two largest gaps, so a true answer is available. JD because the weakness is measured against the advert's own list |
| B4 | "Why now, and why Quillmoor?" | CO | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | The first half is the sentence, in your own words. The second half: your material gives a reason for leaving, not a reason for choosing Quillmoor. Answer slot: if something about the role or the company drew you, say what; if the office closing is the main reason you're looking, say so plainly and stay with the advert's own duties as you read them. Read Quillmoor's own site before Thursday and take one fact you can actually speak to; this pack could not read company pages | F12 is the reason for leaving, and "why us" is the part the material is silent on. CO because it tests homework; the Skeptic delivery tests consistency |
| B5 | "What if the pattern moved to three days on site?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Hold your sentence: two days is fine, and you wouldn't want more than three. Answer slot: if you have a view on exactly three days, say it in your own words; if you have not decided, say so plainly and say two is what the advert gives | F10 holds a ceiling, and a push on it tests whether you keep both halves. JD because the pattern is stated in the advert |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say the sentence at its own scope and keep "about a third". Answer slots, in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours. "I don't know how it was counted" is an honest branch. Name the weakest assumption before they do if you know it | F4 is your only headline figure. EXP because it tests attribution and whether you know your own number |
| C2 | "Walk me through how you schedule deliveries for your three depots, and what happens when an order slips." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | The beats the sentence states: deliveries scheduled for three depots; suppliers chased when orders slip. Tell them in your own words. Answer slots: if others were involved in the scheduling, say who and which part was yours; if you followed orders in a particular way, say how; if neither applies, say so plainly | F2 and F3 are the rows the JD's tracking and chasing lines press on, and F1 sits behind them. EXP because it tests whether the sentence survives a walk-through |
| C3 | "What do you report on, and how often?" | JD | [grounded] | Your material is silent on reporting, so the pack writes nothing. Answer slot: if you report on deliveries or dispatch to anyone, say what and how often, in your own words; if you do not, or no such reporting exists, say so plainly and describe what you do keep track of | F5 has no evidence, so the JD's weekly-reporting line is an open probe. JD because it scores a stated duty |

### D. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you an order that QA is waiting on will arrive three days late. What do you do?" | CASE | [generic] | Structure it: what you would ask first (what is waiting on the order, what waiting costs), who needs to know (planning, the warehouse, QA, the advert's three), the options you would put on the table, what you would tell the supplier, and what you would record. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's supplier-chasing and cross-function lines (F1, F2). CASE because it is a decision, not a history; `[generic]` because it is a pattern for the problem |
| D2 | "Weekly on-time dispatch has dropped ten points. How would you work out why?" | CASE | [generic] | Structure it: define on time first (against what date), segment the drop (by product, destination, supplier lateness), check the data itself including stock records, then name the metric you would watch. No claim about your past | The JD's weekly-reporting line (F5) as a diagnosis. CASE because it scores structure; `[generic]` because no claim is made |
| D3 | "The system says forty units; the shelf holds thirty-two. What do you do?" | CASE | [generic] | Structure it: recount, check recent movements, hold anything that depends on the stock, correct the record with a note, then look for the cause. No claim about your past | The JD's stock-records line (F4) as a live problem. CASE because it is a decision; `[generic]` because it carries no fact about you |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That fall in discrepancies. How much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold what the sentence says through two follow-ups: you rebuilt the spreadsheet and discrepancies fell by about a third. Answer slot: say which part was yours, in your own words; if you cannot separate your part, say so plainly and return to the sentence. Concede only what you can name | F4 again, in the stress register. EXP because it tests attribution; the pressure is in the delivery |
| E2 | "Is there any flexibility on £42,000?" | JD | [grounded] "I'm hoping for £42,000" | Hold the figure once: "I'm hoping for £42,000." Your material gives a hope, not a floor. Answer slot: if you have a figure below which you would decline, say it; if you have not decided, say so plainly. Decide before Thursday | F9 is a hope, so the push is where it softens by accident. JD because pay is the advert's stated range |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "Coordinate production schedules between planning, the warehouse and QA" | B1, B3, C2, D1 |
| "track supplier deliveries" | C2, D1 |
| "chase late orders" | C2, D1 |
| "keep stock records accurate" | C1, E1, D3 |
| "report weekly on on-time dispatch" | C3, D2 |
| "2+ years in operations or logistics coordination" | A1 |
| "confident with Excel" | A5 |
| "ERP experience (SAP or similar) a plus" | A5, B2, B3 |
| "£38,000–£44,000" | A2, E2 |
| "Hybrid: two days a week at our Avonmouth site in Bristol" | A3, B5 |
| "your notice period" | A4 |
| "what's prompting a move" | A1, B4 |

## 5. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which two days are the Avonmouth days, and is that set for the team or arranged person by person?" | It shows you have planned the pattern, and the answer tells you whether your ceiling of three ever comes into play |
| R2 | "Which system does the team use day to day, and how is training handled for someone new to it?" | It turns the SAP gap into a ramp question and shows you read the advert's plus |
| R3 | "Who would I work with most closely across planning, the warehouse and QA?" | It uses the advert's own three functions and tells you where the work sits |
| R4 | "How is on-time dispatch measured today, and what does the weekly report look like?" | It picks up the advert's reporting line and shows interest in the measure, not only the duty |
| R5 | "What would the hiring manager want the first three months to achieve?" | It asks for the next round's agenda in the recruiter's terms, which she can answer even if she is not the manager |
| R6 | "After this call, what are the next steps and roughly how long does each take?" | She said she would cover next steps, so ask it only if the timeline is not covered; it shows you are planning around your own notice and the office closing |

## 6. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says deliveries for three depots, not production schedules. B1's slot stays inside the depots |
| ERP experience | Inflated form of F8's second clause | F8's quote at its own scope: "we run our own in-house stock system". The limit is the pack's observation: the material says an in-house stock system, not an ERP |
| Used SAP | Negative you stated, F8 | The plain acknowledgment F8 gives: "Never used SAP." No slot on SAP itself, only a plan said as a plan |
| Your rebuild caused the fall in discrepancies | Inflated form of F4 | F4's quote at its own scope: you rebuilt the spreadsheet and discrepancies fell by about a third over a year. The limit is the pack's observation: the sentence pairs the two and does not say how the fall was measured. C1 and E1 ask only how it was counted and which part was yours |
| Cut discrepancies by a third, stated as an exact figure | Inflated form of F4's figure | "About a third", exactly as you said it |

## 7. Sources

**Provided documents:** the advert text you pasted; Hannah Lowther's LinkedIn message as you pasted it; your own description of your background. No dossier was present.

**Searches sent, all refused by the host (nothing came back and nothing in this pack comes from the web):**

- `Quillmoor Diagnostics values` — refused
- `Quillmoor Diagnostics Avonmouth Bristol news strategy` — refused
- `Hannah Lowther Talent Partner Quillmoor Diagnostics` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The host refused the search. It would have themed VAL-style questions and sharpened B4. No values cheat sheet was due either way, since no round assessing values is established for this call |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | skipped | Hannah's message fixes the one session this pack prepares for: a 30-minute phone call with her, and its agenda. No call was sent |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | The host refused the search. It would have grounded B4's company half and added a CO question; B4 is therefore built on your own reason and a read-the-site instruction |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | The host refused the search. It would have added an interviewer read and a reverse question tied to her path; both are absent |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and every JD-tagged question |

## 8. Upgrade menu

- Your notice period → A4 and F11 stop being an open gate, and the row carries your own words
- Your CV → fit rows draw on your own CV sentences as well as this message; the stock-count spreadsheet or a before-and-after discrepancy report is the kind of inspectable proof that could raise F4 above medium
- Your answers to the slots (whether others were involved in your scheduling, whether you report on dispatch, whether the spreadsheet was Excel, what the in-house system covers) → F1, F3, F5, F7 and F8 become stories from your own words
- Search permission, or Quillmoor's own pages pasted in → a grounded B4, a CO question, any published values, and an interviewer read for Hannah with a reverse question tied to her path
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, needs search permission) → a strategy brief and recent organisational context
- Hours available before Thursday → a short prep schedule built on B1, A4 and A2
- A tuesday-dossier.md from an earlier evidence-recovery session → verified evidence and a sourced prohibited-claims list in place of the locally built one
