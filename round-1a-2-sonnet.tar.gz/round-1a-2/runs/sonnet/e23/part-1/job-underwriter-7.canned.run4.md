I'll read the reference files the skill requires before building the assessment.
## Decision snapshot

**Yes, worth applying. R1 and R2, the two gates, are `direct`, and R9 and R11 are the two things you've told me you haven't done, neither of them a gate. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R5a, R6a, R8a · unclear: R4 (Clear, timely records), R5b (Leg-ulcer care), R6b (Continence care), R7 (End-of-life visits), R8b (Care planning)
- `important`: adjacent: R10 (Housebound adults at home) · absent: R9 (Own small caseload)
- `preferred`: absent: R11 (Doppler assessment)

R3 (`medium`): five years against a one-year minimum; R4, R5b, R6b, R7, R8b: the CV is silent, so they are questions rather than gaps in capability; R9, R11: stated by you as never done.

**Opportunity ledger.** The posting is concrete about pay, pool cars and who to call (RR3), and the employer and team lead appear in public sources (RR4). It has not yet been seen on the employer's own site (RR1), and caseload size, induction and rota are unstated (RR2, RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed open with a closing date (RR1); (2) the unclear must-haves R4, R5b, R6b, R7 and R8b are answered truthfully before any CV wording is finalized; (3) R9 and R11 are stated plainly as not yet held, never implied.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff in four locality hubs | `[grounded]` search result from the employer's About page (snippet read, page not fetched) |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin and care planning, on an electronic patient record | `[grounded]` JD |
| Caseload and support | A small caseload of your own, supported by a senior community nurse | `[grounded]` JD |
| Working pattern | Halifax-based team, pool cars provided, mileage paid | `[grounded]` JD |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. At the 2025 community nursing forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work. | `[grounded]` community nursing forum speaker page (search snippet) |
| Scope read | An entry-level community post with a supported caseload, not a senior one | `[inferred]` from "Band 5", "small caseload" and "supported by a senior community nurse" in the JD |
| Market calibration | Band 5 community staff nurse in England: median basic pay £34,300, interquartile range £32,400 to £36,600. 61% of respondents were paid mileage and 24% had a pool or lease car. The posting's £31,050–£37,800 brackets that median. This is a survey band, never this employer's offer. | `[generic]` Wardround 2026 pay guide, this month's single pay search; `[grounded]` JD for the posting's range |
| Unknowns | Caseload size, induction for nurses new to community work, shift and out-of-hours pattern, closing date, whether Doppler training is provided | `[grounded]` JD silent on each |
| Contradictions | None found between the JD and the employer's About page. The posting itself was not located on the employer's site. | `[grounded]` About page snippet; careers address returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states Registered Nurse (Adult), registration active, revalidation due March 2028. This is self-report with no register entry inspected, so `medium`. | `[grounded]` CV | A link or screenshot of your NMC register entry would raise it to high |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | CV states a full UK licence, category B. Self-report, nothing to inspect. A licence document is not needed for this assessment. | `[grounded]` CV | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward, stated in the CV. A length-of-experience requirement is not a gate. | `[grounded]` CV | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | The CV says nothing about record-keeping or electronic systems. Ward and home-visit work involve records, but that is context, not a claim you have made. | `[grounded]` CV silence | G3 |
| R5a | Wound care | must_have | direct | medium | none | CV: wound care including pressure ulcers and surgical wounds. | `[grounded]` CV | none |
| R5b | Leg-ulcer care | must_have | unclear | low | discovery | Leg ulcers are not mentioned. The wound-care claim is nearby but does not establish compression or leg-ulcer work. | `[grounded]` CV silence | G2 |
| R6a | Catheter care | must_have | direct | medium | none | CV: catheter care. | `[grounded]` CV | none |
| R6b | Continence care | must_have | unclear | low | discovery | The CV names catheters only. Wider continence work is not stated. | `[grounded]` CV silence | G4 |
| R7 | End-of-life visits | must_have | unclear | low | discovery | The CV is silent. An acute medical ward and discharge-to-assess visits may have included end-of-life care, but that is not claimed. | `[grounded]` CV silence | G1 |
| R8a | Insulin administration | must_have | direct | medium | none | CV: insulin administration. | `[grounded]` CV | none |
| R8b | Care planning | must_have | unclear | low | discovery | The CV does not mention care planning. | `[grounded]` CV silence | G4 |
| R9 | Holding a small caseload of your own | important | absent | none | capability | You have said you've never held your own caseload. The posting itself says a senior community nurse supports the caseload. | `[grounded]` your intake statement; `[grounded]` JD | Carry as a stated gap; ask RR2's question |
| R10 | Caring for housebound adults in their own homes | important | adjacent | medium | transferability | 18 months visiting patients at home in their first week after discharge. Limit: short post-discharge episodes, not ongoing care of long-term housebound patients. | `[grounded]` CV | Make the bridge and its limit explicit (E1) |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have said you've never done one. It is only desirable in the posting. | `[grounded]` your intake statement; `[grounded]` JD | Say so plainly and ask what training exists (A2) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-of-life visits (R7, must_have) | discovery | The CV does not mention end-of-life care on the ward or in discharge-to-assess | A named core duty. Answering it either closes a must-have or puts it on the risk list | Caring for dying patients on the ward; supporting families at the bedside; visits to people discharged home for end-of-life care | An end-of-life training record or a reflective account from your revalidation portfolio | `[grounded]` CV silence; `[inferred]` that it is a core duty from the JD's duty list |
| G2 | Leg-ulcer care (R5b, must_have) | discovery | Pressure-ulcer and surgical-wound care are stated; leg ulcers are not | Leg-ulcer care is the first-named wound type in the duties, and Doppler (R11) builds on it | Applying compression bandaging; dressing venous ulcers; assessing a leg wound for a cause | A compression training certificate or competency sign-off | `[grounded]` CV; `[grounded]` JD ordering |
| G3 | Written records on an electronic record (R4, must_have) | discovery | Silent on record-keeping systems and habits | Listed as essential, and the whole role is recorded electronically | Which electronic record system you used on the ward; same-day entries after home visits; any documentation audit result | A documentation audit, competency sign-off or appraisal comment | `[grounded]` JD "clear, timely written records"; `[grounded]` CV silence |
| G4 | Continence care and care planning (R6b, R8b, must_have) | discovery | Catheters are stated; continence beyond catheters and care planning are not | Both are named duties. Not asked this turn, because G1 to G3 could move the decision more | Bladder and bowel care plans; writing or updating a discharge or care plan | A sanitized care plan, if you hold one that is not identifiable | `[grounded]` CV silence |
| G5 | Own caseload (R9) and Doppler (R11) | capability | You've confirmed neither has been done | Neither is a gate. The posting offers support for the caseload and lists Doppler as desirable only. | No recovery is needed. Don't claim either. | None | `[grounded]` your statement and JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | The posting is not seen on the employer's own site | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The careers page may sit at another address, or the post may be advertised elsewhere only | `[inferred]` from the careers address returning no page while the employer itself is confirmed | Is this post currently open, and what are the closing and interview dates? | unresolved |
| RR2 | Caseload size and induction unstated | unknown | — | "hold a small caseload of your own, supported by a senior community nurse" | A new Band 5 with no prior caseload may start with more or less protected time than the wording suggests | `[inferred]` from the JD's silence on size and induction | How many patients is a new starter's caseload, and how much supervised time do they get at first? | unresolved |
| RR3 | Pay and car terms stated, and in line with the survey band | positive_signal | — | "£31,050–£37,800 a year plus mileage"; "pool cars are provided" | The posted range brackets the survey median, and a pool car is a benefit only some survey respondents had | `[grounded]` JD; `[generic]` survey band | Which point on the range is offered to a nurse with no community experience? | noted |
| RR4 | Employer and team lead corroborated; the lead has spoken on Doppler training for staff new to community work | positive_signal | — | "For an informal chat about the role, contact Rhiannon Mabbott, Community Nursing Team Lead" | The team may offer Doppler and leg-ulcer training to new starters | `[inferred]` from the lead's published talk topics; the posting does not say training is provided | Does the team provide Doppler training, and how soon after starting? | noted |
| RR5 | Shift and out-of-hours pattern unstated | unknown | — | "district nursing team caring for housebound adults in their own homes" | Weekend or evening visiting may be part of the post | `[generic]` community nursing rotas commonly cover more than weekday daytime; not a claim about this employer | What are the shift hours, and is there a weekend or evening rota? | unresolved |

## Application plan

All rows are proposed. Nothing is applied or sent until you approve it, and that covers the CV edits, the call wording and the order of emphasis alike.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV: lead the experience section with "Seconded for 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge", your own sentence moved to the top | R10: your closest evidence for home-based work | `[grounded]` CV | pending your approval |
| E2 | CV: keep the clinical skills line as you wrote it ("wound care including pressure ulcers and surgical wounds; catheter care; insulin administration"). Add leg ulcers, records, end-of-life or continence only after you confirm them. | R5a, R6a, R8a are `direct`; adding anything else now would outrun the evidence | `[grounded]` CV | pending your approval |
| A1 | Phone Rhiannon Mabbott for the informal chat the advert offers, and put RR1, RR2, RR4 and RR5's questions to her verbatim | The posting invites it, and the questions double as your verification list | `[grounded]` JD | pending your approval |
| A2 | On Doppler and the caseload say plainly: "I haven't done Doppler assessment yet. What training does the team provide?" and "I haven't held my own caseload; how is a new starter supported?" | R11, R9: stated as never done, so the honest framing is the strong one | `[grounded]` your statements | pending your approval |

## Evidence status

Verified: none yet. Your National Insurance number isn't needed to assess a role. I haven't used it, and it doesn't belong on a CV or in a first application.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health CIC community staff nurse Band 5 district nursing vacancy". Both returned "About Calderbrook Community Health" (calderbrookhealth.example/about). The fetch of calderbrookhealth.example/careers found no page. Moved: role reality's organization and contradictions rows, and RR1 |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing requirements experience Doppler training salary Agenda for Change 2026". It returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: the market calibration row and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead". It returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: the hiring contact row, RR4 and A1 |

I can offer to write up all of this as a `tuesday-dossier.md` file, if you want one.

**Upgrade menu**

- A link or screenshot of your NMC register entry → R1 to `high`.
- Answers to G1, G2 and G3, plus a training record or sign-off for each → R7, R5b and R4 move off `unclear`.
- Your own non-negotiables (pay floor, hours, days, travel limits) → the hard-gate line stops reading "candidate constraints not given".
- The live posting link and closing date → RR1 closes.
- Rhiannon's answers on caseload, rota and Doppler training → RR2, RR4, RR5.
- A deeper pass on Calderbrook (leadership and trading history, hiring patterns, staff and regulator reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

G1 — On the ward or on discharge-to-assess visits, have you personally cared for someone who was dying, and what did you do for them or their family?

G2 — Have you ever dressed or bandaged a leg ulcer, or applied compression, even once or under supervision?

G3 — Which electronic record system did you use on the ward and on home visits, and did you write your own entries the same day?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.