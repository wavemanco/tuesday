Reading is done. Now running the research: I'm checking that the employer and posting exist, then the pay band, then the team lead's public professional footprint.
**Yes, this one is worth applying for, on the conditions below. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R4 (Clear, timely written records)
- `important` — direct: R6, R8, R11 · adjacent: R5 (Visiting housebound adults), R7 (Leg-ulcer care), R13 (Own small caseload) · unclear: R9 (Continence care), R10 (End-of-life visits), R12 (Care planning)
- `preferred` — absent: R14 (Doppler assessment)

What matters: R4, R9, R10, R12 — your CV is silent, so asking can recover them; R5, R7, R13 — real bridges with their limits named; R14 — absent, and preferred tier.

**Opportunity ledger.** The employer is established, pay is stated and the support is named (RR2, RR4, RR5). Two items are open: whether the posting is still live (RR1), and caseload size and rota (RR3).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The posting is confirmed live (RR1).
  2. You can evidence your record-keeping (R4, G1).
  3. The caseload and Doppler gaps are stated honestly, as adjacent and absent (R13, R14).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. Founded 2015, 410 staff, four locality hubs | `[grounded]` "About Calderbrook Community Health" page, from search snippet |
| Role | Community Staff Nurse, Band 5, district nursing team, Halifax. Housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin and care planning, on an electronic patient record | `[grounded]` JD |
| Caseload and support | A small caseload of your own, supported by a senior community nurse; pool cars provided | `[grounded]` JD |
| Pay | £31,050–£37,800 plus mileage | `[grounded]` JD |
| Market calibration | Survey of Band 5 community staff nurses in England: median £34,300, interquartile range £32,400–£36,600, so the posted range spans it. 61% were paid mileage and 24% had a pool or lease car, so a pool car is the less common arrangement. This is a pattern, not this employer's offer | `[generic]` Wardround 2026 pay guide, snippet only, page not opened |
| Scope read | An entry-level community post with stated supervision, not a stretch-scoped one. First-90-days outcomes are not stated | `[inferred]` from the JD's supervision wording and its silence on outcomes |
| Team lead | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. They spoke at a 2025 forum on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page, snippet only |
| Unknowns | Caseload size and visit volume; weekend or on-call rota; which patient record system; induction arrangements; closing date | — |
| Contradictions | None between the JD and the about page. The careers page was not opened, so liveness is unconfirmed (RR1) | `[grounded]` about page; careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV gives a PIN and says registration is active, revalidation due March 2028. The NMC register could confirm it, but no check has been made | `[grounded]` CV | none; a register check would raise to high |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states a full UK licence, category B. Nothing inspected | `[grounded]` CV | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as an acute medical ward staff nurse. Self-reported, so expect a probe on dates | `[grounded]` CV | none |
| R4 | Clear, timely written records (the JD names an electronic patient record) | must_have | unclear | low | discovery | CV is silent on record-keeping and on any record system. Ward and home-visit nursing involve documentation, but that is not evidence of its quality | `[grounded]` CV silence; `[generic]` that nursing roles involve documenting care | Question G1 |
| R5 | Caring for housebound adults in their own homes | important | adjacent | medium | transferability | 18 months visiting patients at home in their first week after discharge. Limit: a short post-discharge episode, not a long-term housebound caseload | `[grounded]` CV; limit `[inferred]` from the CV's description | State the bridge and limit in the application |
| R6 | Wound care | important | direct | medium | none | CV names pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R7 | Leg-ulcer care | important | adjacent | medium | transferability | Wound care carries over. Limit: leg ulcers and compression are not claimed anywhere | `[grounded]` CV; limit `[inferred]` | Bridge case in G5 |
| R8 | Catheter care | important | direct | medium | none | CV names catheter care | `[grounded]` CV | none |
| R9 | Continence care | important | unclear | low | discovery | CV names catheter care but nothing on bladder or bowel continence assessment or management | `[grounded]` CV silence | Question held back; see G4 |
| R10 | End-of-life visits | important | unclear | low | discovery | CV silent. An acute medical ward may have given relevant experience, but that is not a claim you have made | `[grounded]` CV silence; `[generic]` that medical wards often include end-of-life care | Question G2 |
| R11 | Insulin administration | important | direct | medium | none | CV names insulin administration | `[grounded]` CV | none |
| R12 | Care planning | important | unclear | low | discovery | CV silent | `[grounded]` CV silence | Question held back; see G3 |
| R13 | Holding a small caseload of your own | important | adjacent | medium | transferability | You told me you have never held your own caseload. Bridge: independent home visits on the secondment. Limit: prioritising and owning a caseload is unexercised. The JD offers senior-nurse support | `[grounded]` your statement and JD; bridge `[inferred]` | Say plainly it would be new |
| R14 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You confirmed you have never done one. Preferred, not essential | `[grounded]` your statement; JD marks it desirable | Closure path in G7 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Records and EPR (R4, must_have) | discovery | No record-keeping evidence at all | A must-have row at `unclear`; resolving it is the likeliest move toward `go` | Using an electronic patient record on the ward or in the discharge team; writing visit notes or discharge summaries; record-keeping audits | An audit result, a feedback note, a reference mentioning documentation | `[grounded]` CV silence; `[inferred]` that this row moves the status |
| G2 | End-of-life care (R10, important) | discovery | CV silent | The JD lists end-of-life visits as a duty | Ward patients at end of life; anticipatory medicines; family conversations; a care plan for the dying | Thank-you cards are not needed; a service note or reference would do | `[grounded]` CV silence |
| G3 | Care planning (R12, important) | discovery | CV silent | Care planning is a named duty | Writing or updating care plans on the ward; plans for discharge-to-assess patients | A sanitized plan template you used | `[grounded]` CV silence |
| G4 | Continence care (R9, important) | discovery | Catheters only | A named duty | Bladder and bowel assessments; continence products; catheter reviews | A procedure or competency record | `[grounded]` CV silence |
| G5 | Leg-ulcer bridge (R7, important) | transferability | General wound care | Adjacent evidence plus its limit is the honest case | Compression bandaging; leg-wound assessments on the ward | A competency record | `[inferred]` bridge from wound care |
| G6 | Caseload (R13, important) | transferability | Independent home visits, no owned caseload | The JD offers support, so the limit is manageable | Planning your own visit order on the secondment; handing over complex patients | Secondment job description | `[grounded]` your statement and JD |
| G7 | Doppler (R14, preferred) | capability | None | Desirable only. The team lead has spoken on Doppler training for staff new to community work, so ask whether it is offered in post | A taught Doppler or ABPI course; a ward leg-ulcer clinic placement | A training record when done | `[grounded]` forum page; reading that training may be available is `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting liveness unconfirmed | unknown | — | "Current vacancies are listed on our careers page." | The careers page may sit at another address, or the post may have closed. My fetch used a guessed address, so its failure is weak evidence | `[inferred]` from the failed fetch | Is this vacancy still open, and what is the closing date? | unresolved |
| RR2 | Support and resources named | positive_signal | — | "supported by a senior community nurse"; "pool cars are provided" | The role has a defined support path and a vehicle | `[grounded]` JD | How is the senior nurse's support structured: joint visits, supervision frequency, an induction period? | noted |
| RR3 | Caseload, rota and on-call unstated | unknown | — | "a small caseload of your own" | "Small" is undefined, and community posts commonly include weekend work | `[generic]` role-family pattern | What is the typical caseload and daily visit count, and is there weekend or on-call work? | unresolved |
| RR4 | Pay stated and in line with the survey | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range spans the survey's interquartile range, so no mismatch signal | `[grounded]` JD; `[generic]` survey band | Where in the range would my experience place me at appointment? | noted |
| RR5 | Employer established | positive_signal | — | "district nursing team" | An entity matching the posting exists, with a named Halifax team lead | `[grounded]` about page and forum page | Who would be my line manager and senior community nurse? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the discharge-to-assess secondment, in the posting's terms: visits at home, wound care, catheter care, insulin. Add nothing about caseloads or housebound patients | R5, R6, R8, R11 | `[grounded]` CV | pending your approval |
| E2 | Add a record-keeping line only after G1 is answered | R4 | `[grounded]` row R4 | pending your approval |
| A1 | Take up the informal chat with Rhiannon Mabbott before applying. Ask RR1 and RR3, and whether Doppler training is offered | The advert invites it. The speaker page shows the team lead has spoken on Doppler training | `[grounded]` JD; `[grounded]` forum page | pending your approval |
| A2 | State plainly that you have not held your own caseload, and name the secondment visits as the nearest experience | R13 | `[grounded]` your statement | pending your approval |
| A3 | Say Doppler is new to you and ask about training; do not imply any experience | R14 | `[grounded]` your statement | pending your approval |

## Evidence status

Verified: none yet. Your National Insurance number isn't needed to assess a role, so I haven't used it or sent it anywhere.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health CIC Community Staff Nurse Band 5 district nursing Halifax vacancy". Both returned "About Calderbrook Community Health" (calderbrookhealth.example/about). A fetch of calderbrookhealth.example/careers returned no page. Moved: the organization row, and RR1 stays open. The employer is established, so no failed-attribution entry |
| 2. Role-family sweep | yes | Searched "community staff nurse district nursing Band 5 salary Agenda for Change pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide), snippet only. Moved: the market calibration row and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott), snippet only. Moved: the team lead row, G7 and A1 |

Should I save this as `tuesday-dossier.md`? Say the word and I will.

## Upgrade menu

- The live careers page or a closing date → RR1 closes.
- An NMC register check or a screenshot → R1 to `high`.
- An answer to G1, G2 or G3 → the matching row moves from `unclear`.
- Your pay floor, hours limits, or your current band → hard-gate checks against your constraints become possible.
- A deeper research pass on Calderbrook (public staff reports, recent news, leadership changes; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

G1 — Which electronic patient record systems have you used on the ward and in the discharge-to-assess team, and what did you personally write in them? Has anyone ever audited or commented on your record-keeping?

G2 — Have you cared for patients at the end of life? What did you personally do, and what was the team's?

Constraints — Do you have a pay floor, rota or hours limits, or a current band this role would need to match?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.