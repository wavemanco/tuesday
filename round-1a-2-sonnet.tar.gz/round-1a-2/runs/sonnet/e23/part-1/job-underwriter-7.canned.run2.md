Checking the employer and the pay band online before I write the assessment.
## Decision snapshot

**Yes, this one is worth applying for. R1 and R2 are met on your CV, R4 needs one confirmation, and R6b, R10 and R11 are gaps with their limits named. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · adjacent: R5 (Housebound adults in their own homes) · unclear: R4 (Clear, timely written records)
- `important`: direct: R6a, R7a, R8a · adjacent: R6b (Leg-ulcer care), R10 (Own small caseload) · unclear: R7b (Continence care), R8b (Care planning), R9 (End-of-life visits)
- `preferred`: absent: R11 (Doppler assessment)

R4 (`low`): one confirmation closes it; R5, R6b, R10: credible bridges, limits named; R7b, R8b, R9: CV silence, not a failure; R11: a real gap, preferred and not essential.

**Opportunity ledger.** The role reads as supported and sound: a supervised caseload (RR4) and a named Team Lead who has spoken on Doppler training for staff new to community work (RR5) sit beside a pay range that spans the survey's middle band (RR3). The rota is unstated (RR2) and the live vacancy is unconfirmed (RR1).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) your records answer confirms R4 (see G1); (2) the vacancy is confirmed open (RR1); (3) the rota and hours fit your own constraints, once you state them (RR2, C1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff in four locality hubs | `[grounded]` employer's About page, seen as a search result |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin and care planning, on an electronic patient record | `[grounded]` JD |
| Caseload and support | A small caseload of your own, supported by a senior community nurse | `[grounded]` JD |
| Essential and desirable | Essential: NMC Adult registration, full UK licence, one year's post-registration experience, clear timely records. Desirable: Doppler for leg ulcers | `[grounded]` JD |
| Pay | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` JD |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse; at the 2025 community nursing forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` speaker page, seen as a search result; professional footprint only |
| Scope read | Looks built for a nurse new to community work: one year's experience, a supervised caseload, Doppler desirable rather than essential | `[inferred]` from the essential list, the supervision line and the Team Lead's talk topics |
| Market calibration | Band 5 community staff nurse, England: median £34,300, interquartile range £32,400 to £36,600; 61% were paid mileage and 24% had a pool or lease car. The posting's range spans that interquartile range. This is the survey's band, never this employer's offer | `[generic]` Wardround 2026 pay guide (n=1,240), from one search; `[grounded]` JD for the posting's figures |
| First 90 days | Not stated | `[grounded]` JD silent |
| Unknowns | Rota and weekend or on-call pattern; supervision structure; closing date; which record system | `[grounded]` JD silent |
| Contradictions | None found between the ad and the employer's About page. The careers listing could not be opened, so the vacancy itself is unconfirmed (RR1) | `[grounded]` About page seen; careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | Your CV states Adult registration, active, revalidation due March 2028. This is specific but self-reported, and the register entry has not been inspected | `[grounded]` CV | Check your register entry shows active; that would raise this to `high` |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states a full UK licence, category B. Pool cars are provided, so the car itself is not a barrier | `[grounded]` CV; `[grounded]` JD on pool cars | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. Experience length is graded as fit, not as a gate | `[grounded]` CV; `[inferred]` that the staff-nurse years fall after registration | none |
| R4 | Clear, timely written records (electronic patient record) | must_have | unclear | low | discovery | CV is silent on record-keeping or record systems. Ward work and home visiting are indirect context, so there is a thread; low, not none | `[grounded]` CV silence | G1 |
| R5 | Caring for housebound adults in their own homes | must_have | adjacent | medium | transferability | You visited patients at home in their first week after discharge for 18 months. Limit: nothing says whether they were housebound or what your visits covered | `[grounded]` CV; limit `[grounded]` CV silence | G2 |
| R6a | Wound care: pressure ulcers and surgical wounds | important | direct | medium | none | Named in your CV in those terms | `[grounded]` CV | none |
| R6b | Leg-ulcer care | important | adjacent | medium | transferability | Pressure-ulcer and surgical wound care is credible adjacent work. Limit: leg ulcers and compression are not stated | `[grounded]` CV; limit `[grounded]` CV silence | G5 |
| R7a | Catheter care | important | direct | medium | none | Named in your CV | `[grounded]` CV | none |
| R7b | Continence care | important | unclear | low | discovery | CV mentions catheter care only; continence care beyond catheters is not stated | `[grounded]` CV silence | G4 |
| R8a | Insulin administration | important | direct | medium | none | Named in your CV | `[grounded]` CV | none |
| R8b | Care planning | important | unclear | low | discovery | CV is silent. The discharge-to-assess secondment is indirect context for it, but nothing confirms what you planned | `[grounded]` CV silence | G4 |
| R9 | End-of-life visits | important | unclear | low | discovery | CV is silent. An acute medical ward is indirect context, so a thread may exist | `[grounded]` CV silence; `[generic]` medical wards often care for dying patients | G3 |
| R10 | A small caseload of your own, supported by a senior community nurse | important | adjacent | medium | transferability | You have confirmed you have never held your own caseload, so the bridge is the secondment's home visiting. Limit: whether you planned your own visit list is not stated | `[grounded]` your statement and CV | G2 |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have confirmed you have never done one. Closure path: the Team Lead has spoken on Doppler training for staff new to community work | `[grounded]` your statement; `[grounded]` speaker page | G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Records and record system (R4, must_have) | discovery | The CV says nothing about documentation | R4 is the one `must_have` row at `unclear`; closing it moves the decision from `conditional_go` toward `go` | Documenting discharge-to-assess home visits; entering notes on a hospital electronic record; audits of your notes; handovers you wrote | Name of the system you used; a sanitized audit result | `[grounded]` CV silence; `[inferred]` the movement toward `go` |
| G2 | Scope of the home visiting (R5, must_have; R10, important) | transferability | Eighteen months of first-week home visits; patient mix, visit planning and independence are not stated | Two rows rest on this one secondment | Choosing your own visit order; managing a day's visits alone; wound, catheter or insulin visits; housebound patients | A sanitized job description for the secondment; a rota or visit list format | `[grounded]` CV; `[inferred]` that this decides the strength of both bridges |
| G3 | End-of-life care (R9, important) | discovery | CV silent | Named in the ad's duties | Anticipatory medicines, last-days care planning, supporting families, rapid discharges to die at home | A sanitized care-plan note; end-of-life training certificate | `[grounded]` CV silence; `[grounded]` JD lists it |
| G4 | Continence care and care planning (R7b, R8b, important) | discovery | Only catheter care and discharge-related work are visible | Both are named duties | Bladder and bowel assessment; containment products; writing or updating a discharge or home care plan | Training certificates; a sanitized plan template | `[grounded]` CV silence |
| G5 | Leg-ulcer care (R6b, important) | transferability | Adjacent wound care; no leg-ulcer or compression work stated | Leg-ulcer care is the first duty-type the ad names after wounds, and the Team Lead has spoken on it | Venous or mixed ulcers on the ward; applying compression; reviewing a leg-ulcer patient | Wound-care training record; a ward leg-ulcer protocol you used | `[grounded]` CV; `[grounded]` JD and speaker page |
| G6 | Doppler assessment (R11, preferred) | capability | Never done, per your own statement | Desirable only; a training route appears to exist | A course, or shadowing a Doppler clinic if the service offers one | A course booking or certificate | `[grounded]` your statement; `[inferred]` the training route from the speaker page |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Vacancy not confirmed on the employer's own site | unknown | — | "Calderbrook Community Health CIC, Halifax" | The employer is real as described, but the careers listing did not open, so the posting may be stale or the page moved | `[grounded]` About page found, careers fetch returned no page; `[generic]` stale-posting pattern | Is this post currently open, and what is the closing date? | unresolved |
| RR2 | Rota and hours not stated | unknown | — | "end-of-life visits" | The ad is silent on weekdays, weekends, evenings or on-call, so the hours may not suit you | `[inferred]` from the ad's silence against its mention of end-of-life visits | What is the rota: weekdays only, or weekends and evenings, and is there on-call? | unresolved |
| RR3 | Pay range sits across the survey's middle band | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range is in line with the survey; your starting point within it is unknown | `[grounded]` JD figures; `[generic]` Wardround 2026 band | Where on the range would a nurse new to community work start, and how is mileage set? | noted |
| RR4 | Supported caseload with a named senior nurse | positive_signal | — | "supported by a senior community nurse" | Suggests a managed ramp-up rather than a sudden solo caseload | `[inferred]` from the JD's supervision wording | How many visits alongside a senior nurse before you carry your own? | noted |
| RR5 | Doppler is trained, not demanded | positive_signal | — | "Desirable: Doppler assessment for leg ulcers" | The Team Lead has spoken publicly on Doppler training for new community staff, so training may be offered | `[grounded]` JD and speaker page; `[inferred]` that this applies to new hires here | Is Doppler training provided to new starters, and on what timescale? | unresolved |

## Application plan

Everything below is proposed, table and advice alike, and is pending your approval; nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | resume_edits_pending_approval: lead the secondment entry with "Discharge-to-assess team, 18-month secondment: visiting patients at home in their first week after discharge" | R5, R10; this is your CV's own sentence, reordered | `[grounded]` CV | pending your approval |
| E2 | resume_edits_pending_approval: a skills line in your own words: "Wound care including pressure ulcers and surgical wounds; catheter care; insulin administration" | R6a, R7a, R8a; adds no leg-ulcer or caseload claim | `[grounded]` CV | pending your approval |
| A1 | Take up the informal chat with Rhiannon Mabbott first, and use it to ask RR1, RR2, RR4 and RR5 verbatim | The ad invites contact and the register questions are addressed to the employer | `[grounded]` JD and register | pending your approval |
| A2 | In any supporting statement, say plainly that you have not held your own caseload or done Doppler, beside the home-visiting secondment | R10, R11; keeps the bridge to what your own sentences hold | `[grounded]` your statement and CV | pending your approval |
| A3 | Confirm the vacancy is open on Calderbrook's careers page or with the contact before writing anything | RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none. You included a National Insurance number; it isn't needed to assess a role, so I haven't used it.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about); fetched calderbrookhealth.example/careers, which returned no page. Moved role reality's organization row; left the vacancy unconfirmed (RR1) |
| 2. Role-family sweep | yes | Searched "Community Staff Nurse Band 5 district nursing salary Agenda for Change 2026/27 pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved the scope read, R11's closure path, RR5 and plan row A1 |

I can save this as `tuesday-dossier.md` if you'd like a file to keep; say so and I'll write it.

## Upgrade menu

- Your NMC register entry showing Adult nurse, active → R1 to `high`.
- An answer to G1 → R4 resolves.
- An answer to G2, or a sanitized secondment job description → R5 and R10 bridges firm up.
- A sanitized care plan or end-of-life training record → R9 and R8b.
- A wound-care or leg-ulcer training record → R6b.
- The live careers link, or the contact's confirmation → RR1 closes.
- The rota from the chat with the contact → RR2 closes and the hard-gates line can be checked against your constraints.
- A deeper pass on Calderbrook (leadership and staffing changes, public staff reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

Three questions, each tagged to its row:

G1 — Where did you document your care on the discharge-to-assess secondment and on the ward, which record system was it, and did anyone review your notes?

G2 — On the secondment, who decided which patients you saw each day, what were they like (housebound? wounds, catheters, insulin?), and did you work through a day's visits alone?

C1 — Do you have any non-negotiables for a role like this, such as a pay floor, days or hours you can't work, or a limit on weekends and on-call?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.