I'll read the reference files the skill requires before building the assessment.
I've finished the research and I'm writing up the assessment now.

## Decision snapshot

**Yes, this one is worth applying for, on three conditions. Status: `conditional_go`.** No hard gate fails (R1, R2).

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R5 · unclear: R4 (Clear, timely written records)
- `important`: direct: R7, R9, R13 · adjacent: R6 (Leg-ulcer care), R12 (Small caseload of your own) · unclear: R8 (Continence care beyond catheters), R10 (Care planning), R11 (End-of-life visits)
- `preferred`: absent: R14 (Doppler assessment)

What matters: R4 is a must-have your CV doesn't evidence yet; R6 and R12 are credible bridges with their limits named; R8, R10 and R11 are CV silences, not shown gaps; R14 is a preferred skill you confirmed you lack.

**Opportunity ledger.** The advert looks sound as far as it goes. It names supervision and a contact (RR5), states its pay openly (RR2), and its contact has spoken on Doppler training for new community staff (RR6). Three things are unknown: whether the post is live (RR1), how mileage works alongside pool cars (RR3), and the working pattern and contract basis (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The post is confirmed live (RR1).
  2. Evidence of your record-keeping, in your own words, reaches the CV (R4, G1).
  3. The advert's unstated terms are checked against your non-negotiables once you give them (RR3, RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation under an NHS contract. Founded 2015, 410 staff, four locality hubs. This matches how the posting describes it | `[grounded]` "About Calderbrook Community Health" page, fetched |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration and care planning, recorded on an electronic patient record | `[grounded]` advert |
| Caseload and support | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| First-year outcomes | Not stated in the advert | `[grounded]` advert silent |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. She spoke at a 2025 forum on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` speaker page, from the search result's text only (not fetched) |
| Scope read | An entry-level community post open to hospital-experienced nurses, since the stated floor is one year post-registration | `[inferred]` from the advert's essential criteria |
| Market calibration | A survey of English community Band 5 nurses reports median basic pay of £34,300 and an interquartile range of £32,400 to £36,600. Of respondents, 61% were paid mileage and 24% had a pool or lease car. The posting's own range is £31,050–£37,800, and the comparison is in RR2 | `[generic]` Wardround 2026 pay guide, from the search result's text only; `[grounded]` advert for the posting's range |
| Unknowns | Hours and weekend or on-call pattern, contract basis, starting caseload size, training on joining, how mileage applies alongside pool cars | `[grounded]` advert silent on each |
| Contradictions | No contradiction between the advert and the organization's about page. The posting itself could not be located on the careers page (RR1) | `[grounded]` about page fetched; careers address tried returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state active Adult registration with revalidation due March 2028. That is self-report, and the public register entry is the inspectable artifact, which I did not look up | `[grounded]` your CV | none; checking the public register entry yourself would raise this to `high` |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | You state a full UK licence, category B. The advert provides pool cars, so no car of your own is required | `[grounded]` your CV; advert | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. A staff nurse post is a registered one, so that time is post-registration | `[grounded]` your CV; `[inferred]` that the five years post-date registration | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | Your CV is silent on documentation or record systems. I won't assume the practice, and the advert says records go on an electronic patient record | `[grounded]` CV silence | Q1 below (G1) |
| R5 | Wound care | must_have | direct | medium | none | "Wound care including pressure ulcers and surgical wounds" | `[grounded]` your CV | none |
| R6 | Leg-ulcer care | important | adjacent | medium | transferability | Your wound care carries over. Leg ulcers are not named in your CV, and you have no Doppler exposure. Leg-ulcer management normally differs from pressure-ulcer and surgical-wound care | `[grounded]` CV; `[generic]` that the clinical work differs by cause | see G4 |
| R7 | Catheter care | important | direct | medium | none | "Catheter care" is stated | `[grounded]` your CV | none |
| R8 | Continence care beyond catheters | important | unclear | low | discovery | The advert pairs catheter and continence care. Your CV covers catheters only | `[grounded]` CV and advert | see G3 |
| R9 | Insulin administration | important | direct | medium | none | "Insulin administration" is stated | `[grounded]` your CV | none |
| R10 | Care planning | important | unclear | low | discovery | Your CV is silent on care planning | `[grounded]` CV silence | see G3 |
| R11 | End-of-life visits | important | unclear | low | discovery | Your CV is silent on end-of-life care. Acute ward work may have included it, but I won't assume that | `[grounded]` CV silence | Q2 below (G2) |
| R12 | Holding a small caseload of your own, with senior support | important | adjacent | medium | transferability | Your 18 months of first-week home visits after discharge is the nearest work. Limit: you said you have never held your own caseload | `[grounded]` your CV and your statement | see G5 |
| R13 | Visiting housebound adults in their own homes | important | direct | medium | none | The last 18 months seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge. Your CV already says this plainly | `[grounded]` your CV | none |
| R14 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You confirmed you have never done one | `[grounded]` your statement | see G6; minor risk because it is preferred |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records (R4, must_have) | discovery | Your CV says nothing about documentation or record systems | A must-have, and the one row that could stop the status moving to `go` | Notes made at the point of care; discharge-to-assess handover or referral notes; wound or care-plan documentation; any electronic patient record or ward system you used; a notes audit | A sanitised template or form with no patient data, an audit summary, or a reference from your secondment lead | `[grounded]` CV silence; `[inferred]` that resolving it would remove a condition |
| G2 | End-of-life visits (R11, important) | discovery | The CV is silent on end-of-life or palliative care | A named duty in the advert; the interview is likely to probe it | Caring for dying patients on the ward; family conversations; symptom review; discharge of a patient to die at home | A sanitised care-pathway document or a reference | `[grounded]` CV silence; `[generic]` that interviews for community nursing probe end-of-life work |
| G3 | Continence care and care planning (R8, R10; important) | discovery | The CV covers catheters only and says nothing on care planning | Both are named duties; you may already have done them under other labels | Bladder and bowel assessment; continence products; writing or reviewing a care plan; setting follow-up on a home visit | A care-plan template or competency record, sanitised | `[grounded]` CV silence |
| G4 | Leg-ulcer care (R6, important) | transferability | Pressure-ulcer and surgical-wound care. No leg-ulcer work stated | The advert names leg-ulcer care first among its duties; the bridge needs its limit stated whenever it is used | Dressing leg wounds on the ward or on home visits; compression applied under supervision; any patient with a leg ulcer seen on the secondment | A competency sign-off or a sanitised wound-assessment chart | `[grounded]` CV and advert; `[inferred]` the bridge |
| G5 | Own caseload (R12, important) | transferability | First-week home visits after discharge. You have never held your own caseload | The advert gives a small caseload of your own from the start, with senior support | Deciding your own visit order; escalating to a GP or onward referral on your own judgement; following the same patients across visits | A sanitised visit schedule or a reference from the discharge-to-assess lead | `[grounded]` your statement; `[inferred]` the bridge |
| G6 | Doppler assessment (R14, preferred) | capability | No Doppler experience and no adjacent work stated | It is only a preferred criterion. The realistic closure is training after joining or a course | Not applicable: no credible direct or adjacent evidence exists | None. Ask whether the employer trains staff in it (RR6) | `[grounded]` your statement; `[inferred]` the closure path from RR6 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not located on the careers page | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The address I tried may simply be wrong, or vacancies may be listed elsewhere. I can't tell if the post is live or when it closes | `[inferred]` from one failed fetch of a guessed address | Can you confirm the post is open and when applications close? | unresolved |
| RR2 | Pay stated openly | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range's lower end sits below the survey's interquartile range and its upper end above it, so it isn't out of line with that survey. Where you would land in it is not stated | `[grounded]` advert's figures; `[generic]` survey band | Where in the £31,050–£37,800 range would my experience place me? | noted |
| RR3 | Mileage alongside pool cars | unknown | — | "pool cars are provided" and "£31,050–£37,800 a year plus mileage" | Mileage may apply to own-car use or to journeys from home, but the advert doesn't say | `[inferred]` from the two phrases side by side | When is mileage paid, given that pool cars are provided? | unresolved |
| RR4 | Hours, rota and contract basis unstated | unknown | — | "district nursing team caring for housebound adults in their own homes… end-of-life visits" | Home visiting, and end-of-life visits in particular, may involve weekend or out-of-hours cover. The advert is silent on contract basis and starting caseload size | `[generic]` pattern for community nursing posts; `[grounded]` advert silent | What are the hours, the weekend and on-call expectations, the contract basis, and the size of a starting caseload? | unresolved |
| RR5 | Supervision and a named contact | positive_signal | — | "supported by a senior community nurse… contact Rhiannon Mabbott, Community Nursing Team Lead" | The post is built for someone new to holding a caseload, and the contact is open to an informal chat | `[grounded]` advert | How is a new nurse supported in the first weeks, and who is the senior nurse? | noted |
| RR6 | Doppler training signalled | positive_signal | — | "Desirable: Doppler assessment for leg ulcers" | Because the contact has spoken on Doppler training for staff new to community work, the team may train new starters. That is not confirmed | `[grounded]` speaker page; `[inferred]` that this team trains new starters | Do you train new starters in Doppler assessment, and how soon after joining? | unresolved |

## Application plan

Every row is proposed and nothing is finalised until you approve it. That covers the edits table and the advice rows alike. Each line is built only from your own sentences.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV line for the secondment: "The last 18 months seconded from an acute medical ward to its discharge-to-assess team, visiting patients at home in their first week after discharge." | R13, R12 | `[grounded]` your CV prose | resume_edits_pending_approval |
| E2 | Keep your clinical skills together in your own words: "Wound care including pressure ulcers and surgical wounds; catheter care; insulin administration." Leave out leg-ulcer care and Doppler, which you haven't evidenced | R5, R7, R9 | `[grounded]` your CV prose | resume_edits_pending_approval |
| E3 | No records line is drafted, because nothing in your words supports one yet | R4, G1 | `[grounded]` CV silence | held until you answer Q1 |
| P1 | In the supporting statement and at interview, say plainly that you have not held your own caseload and have not done a Doppler assessment, and lead with the home visiting | R12, R14, R13 | `[grounded]` your own statement | pending your approval |
| A1 | Take up the informal chat with Rhiannon Mabbott that the advert offers, before applying. Ask the register's questions for RR1, RR3, RR4 and RR6 | RR1, RR3, RR4, RR6 | `[grounded]` advert invites the chat | pending your approval |

## Evidence status

Verified: none yet. Your CV claims are self-report and stand at `medium` at most. I didn't look up your NMC entry or send your PIN anywhere. Your National Insurance number came with your message. It isn't needed to evaluate a role, so I haven't used it or repeated it.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Community Staff Nurse Band 5 district nursing salary Calderbrook Community Health CIC Halifax vacancy". Fetched "About Calderbrook Community Health" (calderbrookhealth.example/about). Also tried calderbrookhealth.example/careers, which returned no page. The organization row now matches the posting; the posting itself is unlocated (RR1) |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing Agenda for Change pay scale 2026/27 Doppler caseload". It returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). I read only the result's text, because the fetches were spent. It moved market calibration and RR2. It returned nothing on typical scope |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead". It returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott), from the result's text only. It moved role reality's hiring-contact row, RR6 and plan row A1. Professional footprint only |

I can put the whole assessment into `tuesday-dossier.md` if you'd like a file to keep.

## Upgrade menu

- Your answer to Q1 on records moves R4 and may remove condition 2.
- Your non-negotiables (pay floor, hours, contract basis) turn the hard-gate checks from unknown to settled. They also let me judge RR2, RR3 and RR4 against what you need.
- A look at the public NMC register entry (you can do it yourself) raises R1 to `high`. A sanitised competency sign-off or a reference from your secondment lead would do the same for R5, R7 and R9.
- A link to the live posting, or the recruiter's answer on whether it is open, closes RR1.
- A deeper research pass on Calderbrook (leadership and staffing changes, staff reports, recent news; up to 5 more searches and 2 more fetches) will run if you say the word.

**Q1 (G1, R4).** How did you record your care on the ward and in the discharge-to-assess role? Which record systems did you use, and did anyone audit or use your notes, such as a handover or a community team?

**Q2 (G2, R11).** Have you been involved in end-of-life or palliative care on the ward or during the secondment? If so, what was your part?

**Q3 (non-negotiables).** What are your non-negotiables for a move into community nursing? For example, a pay floor, limits on hours, weekends or on-call, or permanent versus fixed-term.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.