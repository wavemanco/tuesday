I've run three searches: the employer, the pay band, and the team lead. Next I'm fetching the employer's careers page to check that the posting is live and matches your advert.
## Decision snapshot

**Yes, worth applying to: R1 and R2, both hard gates, are met, and R3 (one year's post-registration experience) is `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R4a, R5a, R6, R11 · adjacent: R8 (Own small caseload) · unclear: R4b (Leg-ulcer care), R7 (End-of-life visits), R10 (Clear, timely written records)
- `important`: unclear: R5b (Continence care), R9 (Care planning)
- `preferred`: absent: R12 (Doppler assessment)

R8: an adjacent bridge from the discharge team's home visits; R4b, R7, R10: unclear, answerable from your own history; R12: a preferred row, absent.

**Opportunity ledger.** The employer is established and the pay is stated (RR1, RR5). The support structure and the team lead's public work look favourable (RR4, RR6). Whether the post is still open, and its contract basis and rota, are unconfirmed (RR2, RR3).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. R4b, R7 and R10 get confirmed evidence from your history, or are left out of your application rather than implied.
  2. The post is confirmed open (RR2).
  3. The caseload point (R8) is framed as adjacent experience, never as having held a caseload.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff in four locality hubs | `[grounded]` About page, via search result |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record | `[grounded]` advert |
| Caseload and support | A small caseload of your own, supported by a senior community nurse; pool cars provided | `[grounded]` advert |
| Hours, contract basis, rota | Not stated | `[grounded]` advert silent |
| First-90-days outcomes | Not stated | `[grounded]` advert silent |
| Scope read | A conventionally scoped entry-level community post: duties are clinical and the caseload is explicitly small and supported | `[inferred]` from the duty list against the stated support |
| Market calibration | Band 5 community staff nurses in England: median basic pay £34,300, interquartile range £32,400 to £36,600 (n=1,240); 61% were paid mileage and 24% had a pool or lease car. The advert's £31,050–£37,800 spans that interquartile range. This is a survey pattern, not this employer's offer | `[generic]` Wardround 2026 survey, read as a search snippet; `[grounded]` advert for its own figures |
| Unknowns | Whether the post is open; permanent or fixed-term; hours and weekend rota; induction for nurses new to community work; where in the range new starters sit | `[grounded]` advert silent |
| Contradictions | None found between the advert and the About page. The advert was not checked against the careers page, because the fetch returned no page | `[grounded]` About page; careers fetch returned nothing |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states active registration as Registered Nurse (Adult), revalidation due March 2028. Self-reported and not checked against the register | `[grounded]` CV | none; an employer will check the register |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states a full UK licence, category B. Self-reported | `[grounded]` CV | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | CV gives five years as a staff nurse on an acute medical ward, which is more than the minimum stated. Self-reported | `[grounded]` CV | none |
| R4a | Wound care | must_have | direct | medium | none | CV: "wound care including pressure ulcers and surgical wounds". Specific, but nothing inspectable | `[grounded]` CV | none |
| R4b | Leg-ulcer care | must_have | unclear | low | discovery | The CV does not mention leg ulcers or compression therapy. Wound care on a medical ward may have included them, so the evidence may exist | `[grounded]` CV silence; `[generic]` that wound care on acute medical wards can include leg ulcers | ask G1 |
| R5a | Catheter care | must_have | direct | medium | none | CV lists catheter care | `[grounded]` CV | none |
| R5b | Continence care | important | unclear | low | discovery | CV names catheter care only. Continence care is wider (bladder and bowel), and the CV does not claim it | `[grounded]` CV | recall prompt in G5; no question spent |
| R6 | Insulin administration | must_have | direct | medium | none | CV lists insulin administration | `[grounded]` CV | none |
| R7 | End-of-life visits | must_have | unclear | low | discovery | CV is silent on end-of-life care. Acute medical wards commonly care for dying patients, so there may be history to recover | `[grounded]` CV silence; `[generic]` about acute medical wards | ask G2 |
| R8 | Hold a small caseload of your own, supported by a senior community nurse | must_have | adjacent | medium | transferability | Adjacent: 18 months on the discharge-to-assess team visiting patients at home in their first week after discharge. Limit: you say you have never held your own caseload, and the CV does not show ongoing responsibility for patients beyond that first week | `[grounded]` CV and your statement | bridge case in G6 |
| R9 | Care planning | important | unclear | low | discovery | The CV does not say whether you wrote or updated care plans, on the ward or in the discharge team | `[grounded]` CV silence | ask G3, with R10 |
| R10 | Clear, timely written records on an electronic patient record | must_have | unclear | low | discovery | The CV does not name a record system or describe your documentation | `[grounded]` CV silence | ask G3 |
| R11 | Home-based care of adults (implied by the role) | must_have | direct | medium | none | 18 months visiting patients at home on discharge-to-assess is first-hand home visiting | `[inferred]` requirement from the role's setting; `[grounded]` CV for the evidence | none |
| R12 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You have confirmed you have never done one. Desirable, not essential, so a minor risk | `[grounded]` your statement | closure path in G7 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R4b, must_have) | discovery | The CV establishes wound care, pressure ulcers and surgical wounds, with no mention of leg ulcers | A named duty in the advert and the clinical basis for the desirable Doppler skill; a direct answer lifts this row and may move the status towards `go` | Applying compression bandaging; dressing venous leg ulcers on the ward or at a home visit; being signed off in a competency | A competency record or training certificate | `[grounded]` CV silence; `[inferred]` that resolving it could move the status |
| G2 | End-of-life visits (R7, must_have) | discovery | The CV is silent on end-of-life care | A named duty; the advert lists it among the core visits | Caring for patients in their last days on the ward; home visits to patients nearing end of life on the discharge team; supporting families | A training record or a reflective account for revalidation | `[grounded]` CV silence |
| G3 | Records and care planning (R10 must_have, R9 important) | discovery | No record system and no care-planning work appear in the CV | Records are an essential criterion and care planning a stated duty | Documenting on an electronic record; writing or updating discharge or care plans; audits of your documentation | A redacted sample entry or an audit result | `[grounded]` CV silence |
| G4 | (reserved) | n/a | n/a | n/a | n/a | n/a | n/a |

I'll replace that placeholder row with the correct remaining rows rather than leave it empty:

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G5 | Continence care (R5b, important) | discovery | The CV names catheter care only | A named duty, but at `important` tier | Bladder or bowel care plans; continence products; supporting patients with continence problems | A training record | `[grounded]` CV silence |
| G6 | Own small caseload (R8, must_have) | transferability | Home visits on discharge-to-assess are adjacent; you have never held a caseload | The central step-up in this role | The adjacent evidence is real home visiting. The limit is no ongoing responsibility. The strengthener is saying so plainly and asking how a new caseload is built up with support | Not applicable | `[grounded]` CV and your statement; `[generic]` that supported caseloads are the usual entry route to community posts |
| G7 | Doppler assessment (R12, preferred) | capability | No evidence of any; you confirmed you have never done one | A desirable item, so a minor risk | Closure path: the team lead has publicly spoken on Doppler training for staff new to community work, so ask whether it is offered | Not applicable | `[grounded]` your statement and forum page; `[inferred]` that training may be offered here |

*(G4 above is an error on my part: ignore that row. The queue is G1, G2, G3, G5, G6, G7.)*

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer established | positive_signal | — | "Calderbrook Community Health CIC, Halifax" | A real community nursing provider under an NHS contract | `[grounded]` About page, via search result | Which NHS body commissions the district nursing service, and for how long is the contract? | noted |
| RR2 | Posting live status not confirmed | unknown | — | "Join our district nursing team" | The post may be filled or closed; careers page returned no page at the address tried | `[grounded]` fetch returned no page; `[inferred]` that the post may not be live | Is this post still open, and what is the closing date? | unresolved |
| RR3 | Contract basis, hours and rota unstated | unknown | — | "£31,050–£37,800 a year plus mileage" | Permanence, full or part time, and weekend or on-call duties are not given | `[grounded]` advert silent | Is the post permanent, what are the hours, and is there a weekend or on-call rota? | unresolved |
| RR4 | Support structure stated | positive_signal | — | "supported by a senior community nurse" | The caseload is small and supported rather than unsupervised | `[grounded]` advert | How is the senior nurse's support structured in your first months, and how large is the caseload at the start? | noted |
| RR5 | Pay stated, in line with survey range | positive_signal | — | "£31,050–£37,800 a year plus mileage" | No mismatch between the stated range and the survey's interquartile range | `[grounded]` advert; `[generic]` Wardround survey | Where in the range do nurses new to community work start, and what is the mileage rate? | noted |
| RR6 | Team lead's public work matches the role | positive_signal | — | "informal chat about the role, contact Rhiannon Mabbott" | The team lead has publicly spoken on nurse-led leg-ulcer clinics and Doppler training for staff new to community work, so the team may train new starters | `[grounded]` forum speaker page; `[inferred]` that training may be offered | Is Doppler and leg-ulcer training offered to nurses new to community work here? | noted |

## Application plan

Everything in this section, the edits block, the table and the advice around them, is pending your approval.

`resume_edits_pending_approval`

| Current | Proposed (every clause traces to your own wording) |
|---|---|
| Five years as a staff nurse on an acute medical ward; last 18 months seconded to the discharge-to-assess team | Staff nurse, acute medical ward, five years; for the last 18 months seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge |

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the discharge-to-assess home visits, as proposed above | R11 is your strongest evidence and R8's bridge | `[grounded]` CV | pending your approval |
| A1 | Take up the informal chat with Rhiannon Mabbott and use the questions in RR2, RR3, RR4 and RR6 | The advert invites it, and it answers the unknowns | `[grounded]` advert | pending your approval |
| A2 | State plainly that you have not held your own caseload and have not done Doppler, then say what you have done | Keeps R8 adjacent and R12 a named gap, so nothing is implied | `[grounded]` your statements | pending your approval |
| A3 | Leave leg-ulcer, end-of-life and records claims out until G1, G2 and G3 are answered | R4b, R7 and R10 are unconfirmed | `[grounded]` map rows | pending your approval |

## Evidence status

Verified: none yet. Your National Insurance number is not needed to evaluate a role and I have not used it. Don't include it in an application until an employer asks for it at offer stage.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about); fetched calderbrookhealth.example/careers, which returned no page. Moved: RR1 (employer established) and RR2 (posting not confirmed) |
| 2. Role-family sweep | yes | Searched "community staff nurse district nursing Band 5 salary Agenda for Change pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: market calibration and RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: RR6 and action A1 |

I can write this up as `tuesday-dossier.md` if you want a file to keep or reuse.

**Upgrade menu**

- A link to the live posting on the employer's own careers page, or a reply from Rhiannon: closes RR2 and RR3.
- Answers to G1, G2 and G3: R4b, R7, R9 and R10 may move from `unclear` to `direct`, and the status could move to `go`.
- A competency record or training certificate: raises the matching row's confidence from `medium` or `low` towards `high`.
- A deeper research pass on Calderbrook (leadership and staffing changes, staff and candidate reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

G1: Have you personally managed leg ulcers, including compression bandaging, on the ward or on discharge visits? What was yours to do, and was it under a competency sign-off?

G2: Have you cared for patients in their last days or weeks, on the ward or at home? What did you personally do?

G3: Which electronic record systems have you documented on? On the discharge team, did you write or update care plans, and who relied on them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.