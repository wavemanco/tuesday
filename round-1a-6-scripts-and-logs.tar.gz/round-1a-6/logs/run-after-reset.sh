#!/bin/bash
# Round 1a-6, as the owner re-ordered it (owner-note-25nov.txt): after the meter's reset (26 November 06:00 UTC), from
# the frozen kit, Sonnet, the explicit panel, Opus and Haiku, one after another, each skipped if its status already
# ends "done" (the explicit panel and Haiku may have run before the reset). The preflight runs first unless one passed
# today. The stop rule reads the meter before each step. Each step's seal is packed after it.
M=/var/tmp/tuesday-measure/1a6; K=$M/frozen/kit; L=$M/logs; ST=$L/status
GO="If Haiky doesn;t work fully well so be it. Sonnet and Opus should work reasonably well and I am fine with that."
log() { echo "$(date -u +%FT%TZ) $*" | tee -a "$L/run-after-reset.log"; }
pack() { for s in "$M"/sealed/$1-*; do [ -d "$s" ] && python3 -I -B "$L/archive_sealed.py" "$s" >> "$L/run-after-reset.log" 2>&1; done; log "$1 seal packed"; }
done_() { tail -1 "$ST/$1.status" 2>/dev/null | grep -q " done$"; }
until [ "$(date -u +%s)" -ge "$(date -u -d '2026-11-26T06:05:00Z' +%s)" ]; do sleep 60; done
while pgrep -f run-before-reset.sh > /dev/null; do log "waiting for run-before-reset.sh to end"; sleep 300; done
if ! grep -q "^PREFLIGHT PASSED" "$L/preflight.console.txt" 2>/dev/null; then
  log "running the preflight"; cd /var/tmp && bash "$K/preflight.sh" > "$L/preflight.console.txt" 2>&1
  grep -q "^PREFLIGHT PASSED" "$L/preflight.console.txt" || { log "preflight did not pass; nothing started"; exit 0; }
fi
for step in "sonnet quality" "all explicit" "opus quality" "haiku quality"; do
  set -- $step; label="$1-$2"
  if done_ "$label"; then log "$label already done; skipped"; continue; fi
  log "starting $label"
  if [ "$1" = all ] || [ "$1" = opus ]; then
    cd /var/tmp && bash "$K/run_step.sh" $1 $2 --owner-go "$GO" > "$L/$1-$2-step.after-reset.console.txt" 2>&1
  else
    cd /var/tmp && bash "$K/run_step.sh" $1 $2 > "$L/$1-$2-step.after-reset.console.txt" 2>&1
  fi
  log "$label run_step rc=$?"; pack "$label"
done
log "all steps tried"
