#!/bin/bash
# Round 1a-6's chain (owner, 25 November: "yes"; manifest section 26): Sonnet starts only after Haiku's step status
# ends "done"; any other end (stopped, refused, crashed) leaves Sonnet unstarted. Sonnet runs from the frozen kit.
# After its step, its sealed copy is packed into a verified, lossless archive beside it (disk space only).
M=/var/tmp/tuesday-measure/1a6; K=$M/frozen/kit; ST=$M/logs/status; C=$M/logs
while :; do
  last=$(tail -1 "$ST/haiku-quality.status" 2>/dev/null)
  case "$last" in
    *" done") break;;
    *stopped*|*STOPPED*|*REFUSED*|*CRASHED*) echo "$(date -u +%FT%TZ) haiku ended '$last'; Sonnet not started"; exit 0;;
  esac
  sleep 60
done
echo "$(date -u +%FT%TZ) haiku done; starting sonnet"
"$K/run_step.sh" sonnet quality > "$C/sonnet-step.console.txt" 2>&1; rc=$?
echo "$(date -u +%FT%TZ) sonnet run_step rc=$rc"
for s in "$M"/sealed/sonnet-quality-*; do
  [ -d "$s" ] && python3 -I -B "$C/archive_sealed.py" "$s"
done
echo "$(date -u +%FT%TZ) sonnet seal packed"
