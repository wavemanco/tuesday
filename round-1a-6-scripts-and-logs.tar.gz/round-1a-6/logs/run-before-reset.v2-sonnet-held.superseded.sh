#!/bin/bash
# Round 1a-6 before the reset (owner, 26 November: "then proceed with the explicit panel, haiku information only and
# then once they are done, start Sonnet"; owner-note-25nov.txt). From kit-owner-26nov/: the preflight, the explicit
# panel, Haiku, then Sonnet. Sonnet's start is held until it cannot reach the 95% guard before the 06:00 UTC reset.
# Each step's seal is packed after it.
M=/var/tmp/tuesday-measure/1a6; KO=$M/logs/kit-owner-26nov; L=$M/logs
GO="If Haiky doesn;t work fully well so be it. Sonnet and Opus should work reasonably well and I am fine with that."
log() { echo "$(date -u +%FT%TZ) $*" | tee -a "$L/run-before-reset.log"; }
pack() { for s in "$M"/sealed/$1-*; do [ -d "$s" ] && python3 -I -B "$L/archive_sealed.py" "$s" >> "$L/run-before-reset.log" 2>&1; done; log "$1 seal packed"; }
source "$KO/kit.env"
reading() { $METER "$1" 2>/dev/null | grep -o "seven-day [0-9.]*" | awk '{print $2}'; }
log "running the preflight"
cd /var/tmp && bash "$KO/preflight.sh" > "$L/preflight.console.txt" 2>&1
if ! grep -q "^PREFLIGHT PASSED" "$L/preflight.console.txt"; then
  log "preflight did not pass; nothing started (see preflight.console.txt)"; exit 0
fi
log "preflight passed; starting the explicit panel"
cd /var/tmp && bash "$KO/run_step.sh" all explicit --owner-go "$GO" > "$L/explicit-step.console.txt" 2>&1; log "explicit run_step rc=$?"; pack all-explicit
cd /var/tmp && bash "$KO/run_step.sh" haiku quality > "$L/haiku-step.console.txt" 2>&1; log "haiku run_step rc=$?"; pack haiku-quality
reset=$(date -u -d '2026-11-26T06:00:00Z' +%s)
while :; do
  now=$(date -u +%s); r=$(reading "hold-sonnet")
  [ "$now" -ge "$reset" ] && { log "the reset has passed (reading $r); starting sonnet"; break; }
  ok=$(python3 -I -c "import sys; r=float(sys.argv[1])*100; h=(int(sys.argv[2])-int(sys.argv[3]))/3600; print(1 if r+3.5*h<=94 else 0)" "${r:-1}" "$reset" "$now")
  [ "$ok" = 1 ] && { log "reading $r with $(( (reset-now)/60 )) min to the reset: starting sonnet"; break; }
  log "holding sonnet: reading $r, $(( (reset-now)/60 )) min to the reset"; sleep 600
done
cd /var/tmp && bash "$KO/run_step.sh" sonnet quality > "$L/sonnet-step.console.txt" 2>&1; log "sonnet run_step rc=$?"; pack sonnet-quality
log "before-reset steps tried"
