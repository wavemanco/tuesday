"""archive_sealed.py SEALED_DIR...: pack each sealed step copy into SEALED_DIR.tar.gz, verify, then remove the folder.

Lossless: every file's sha256 in the archive is compared with the file on disk before anything is removed, and the
member count must equal the folder's file count. A README beside the archive says how to unpack it. Frees disk for
the next round without deleting any measurement record.
"""
import hashlib
import os
import shutil
import stat
import sys
import tarfile
from pathlib import Path


def sha(fh):
    h = hashlib.sha256()
    for b in iter(lambda: fh.read(1 << 20), b""):
        h.update(b)
    return h.hexdigest()


for d in map(Path, sys.argv[1:]):
    assert d.is_dir(), d
    out = d.with_name(d.name + ".tar.gz")
    assert not out.exists(), out
    files = sorted(p for p in d.rglob("*") if p.is_file())
    with tarfile.open(out, "w:gz", compresslevel=6) as tf:
        tf.add(d, arcname=d.name)
    n = 0
    with tarfile.open(out, "r:gz") as tf:
        for m in tf:
            if not m.isfile():
                continue
            n += 1
            disk = d.parent / m.name
            with tf.extractfile(m) as a, open(disk, "rb") as b:
                assert sha(a) == sha(b), f"mismatch {m.name}"
    assert n == len(files), (n, len(files))
    (d.parent / (d.name + ".README.txt")).write_text(
        f"{d.name} was packed into {out.name} on 2026-11-25 to free disk for round 1a-5.\n"
        f"{n} files, each verified by sha256 against the folder before it was removed.\n"
        f"Unpack in this folder with: tar -xzf {out.name}\n")
    for root, dirs, fs in os.walk(d):
        os.chmod(root, os.stat(root).st_mode | stat.S_IWUSR)
    shutil.rmtree(d)
    print(f"{d}: {n} files -> {out} ({out.stat().st_size / 1e6:.0f} MB), folder removed")
