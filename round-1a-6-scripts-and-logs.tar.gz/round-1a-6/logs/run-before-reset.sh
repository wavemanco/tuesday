#!/bin/bash
# Round 1a-6 before the reset (owner, 26 November: "then proceed with the explicit panel, haiku information only and
# then once they are done, start Sonnet", then "pull the 95% guard down and begin in the sequence I mentioned";
# owner-note-25nov.txt). From kit-owner-26nov/ (guard at 100%): the explicit panel (already started by the previous
# copy of this script; this one waits for it), then Haiku, then Sonnet straight after. Each seal is packed after it.
M=/var/tmp/tuesday-measure/1a6; KO=$M/logs/kit-owner-26nov; L=$M/logs; ST=$L/status
log() { echo "$(date -u +%FT%TZ) $*" | tee -a "$L/run-before-reset.log"; }
pack() { for s in "$M"/sealed/$1-*; do [ -d "$s" ] && python3 -I -B "$L/archive_sealed.py" "$s" >> "$L/run-before-reset.log" 2>&1; done; log "$1 seal packed"; }
log "this copy takes over from the one that started the explicit panel; waiting for the panel to end"
while pgrep -f "kit-owner-26nov/run_step.sh all explicit" > /dev/null; do sleep 30; done
log "explicit panel ended: $(tail -1 "$ST/all-explicit.status")"; pack all-explicit
cd /var/tmp && bash "$KO/run_step.sh" haiku quality > "$L/haiku-step.console.txt" 2>&1; log "haiku run_step rc=$?"; pack haiku-quality
log "starting sonnet"
cd /var/tmp && bash "$KO/run_step.sh" sonnet quality > "$L/sonnet-step.console.txt" 2>&1; log "sonnet run_step rc=$?"; pack sonnet-quality
log "before-reset steps tried"
