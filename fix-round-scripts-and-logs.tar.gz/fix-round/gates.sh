#!/bin/bash
# Run every CI gate in one worktree and write one summary: gates.sh <worktree> <summary file>
set -u
W=$1; OUT=$2; LOG=${OUT%.txt}-logs; mkdir -p "$LOG"; cd "$W"
{
echo "gates in $W at $(git rev-parse HEAD), $(date -u +%Y-%m-%dT%H:%M:%SZ)"
python3 ci/package.py > "$LOG/package.log" 2>&1; echo "package.py exit $?; tree after rebuild: $(git status --short | wc -l) changed path(s)"
for g in "ci/sync.py --check" "ci/check_skills.py" "ci/test_checks.py" "evals/test_harness.py" "evals/routing_variants.py --check"; do
  f="$LOG/$(echo $g | tr '/ ' '__').log"; python3 $g > "$f" 2>&1; code=$?
  echo "$g exit $code :: $(grep -v '^\s*$' "$f" | tail -1)"
  [ "$g" = "ci/check_skills.py" ] && grep -E '^\s+\[' "$f" | cut -c1-160
done
} > "$OUT" 2>&1
