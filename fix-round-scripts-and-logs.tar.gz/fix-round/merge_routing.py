"""Merge a routing arm cut short by the usage limit with the re-runs of its killed runs (plan section 5).

Usage: merge_routing.py <model> <arm> [--root DIR] [--repo DIR] [--expect HUB FRONTDOOR] [--out FILE] [--check]

A copy of round 3's merge script (m17/merge.py), made strict. It reads <root>/<model>/<arm>.limit.json (the
arm as it ran) and every <root>/<model>/<arm>.gap-*.json (re-runs of the killed cases, same commit), with the
runner's own functions from <repo>/evals/run_routing.py (default: the round's pinned worktree, wt-text).

A results file holds no session id, and all runs of a case share one case folder and one run suffix, so an
`error` run cannot be tied to its own transcript. The merge therefore counts, per case: the `error` runs, and
the case's transcripts (~/.claude/projects/-tmp-*-case-<id>/*.jsonl) that carry the file's one run suffix
(from init_skills) and the usage-limit message. A case is filled only when every one of its error runs is
matched by such a transcript and by exactly one re-run; a case whose errors carry no limit message keeps
them (they count toward the 10% limit) and may have no re-runs. Anything else is refused: a mix of killed
and real errors, re-runs that do not match the killed count, re-runs for a case with none killed, or hashes
that differ between the files or from the measured commit's (`--expect`, default sync.digests() of <repo>).

Every summary is recomputed with run_routing's functions, never edited by hand. Writes <out> (default
<root>/<model>/<arm>.json), and never over an existing file; --check only prints whether the limit file's
recomputed summaries equal its own.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROJECTS = Path.home() / ".claude" / "projects"
FROZEN = ("hub_sha256", "frontdoor_sha256")
LIMIT = re.compile(r"You've hit your (?:weekly |session |usage )?limit", re.I)
FAMILY = r"(?:tuesday|job-underwriter|mock-interview|resume-tailor)"


def run_suffix(data: dict, name: str) -> str:
    """The one run suffix every run of a results file was installed under (init_skills)."""
    found = set()
    for res in data["results"]:
        for run in res["runs"]:
            for skill in run.get("init_skills") or []:
                m = re.fullmatch(FAMILY + r"-([0-9a-f]{8})", skill.split(":")[-1])
                if m:
                    found.add(m.group(1))
    if len(found) != 1:
        raise SystemExit(f"{name}: expected one run suffix in init_skills, found {sorted(found) or 'none'}")
    return found.pop()


def limit_transcripts(case_id: int, suffix: str, projects: Path = PROJECTS) -> list[Path]:
    """The case's session transcripts that carry this run suffix and the usage-limit message."""
    mark = re.compile(FAMILY + "-" + suffix + r"\b")
    hits = []
    for path in sorted(projects.glob(f"-tmp-*-case-{case_id}/*.jsonl")):
        text = path.read_text(encoding="utf-8", errors="replace")
        if mark.search(text) and LIMIT.search(text):
            hits.append(path)
    return hits


def merge(model: str, arm: str, root: Path, repo: Path, expect: tuple[str, str] | None,
          out: Path | None = None, check: bool = False, projects: Path = PROJECTS) -> dict:
    sys.path.insert(0, str(repo / "evals"))
    import run_routing as rr  # noqa: E402
    assert Path(rr.__file__).resolve().is_relative_to(repo.resolve()), rr.__file__

    base_path = root / model / f"{arm}.limit.json"
    base = json.loads(base_path.read_text())
    if expect is not None and base.get("hub_sha256") is not None:
        got = (base.get("hub_sha256"), base.get("frontdoor_sha256"))
        if got != expect:
            raise SystemExit(f"{base_path.name}: Tuesday's hashes {got} are not the measured commit's {expect}")
    gap_paths = [] if check else sorted((root / model).glob(f"{arm}.gap-*.json"))
    fills: dict[int, list[dict]] = {}
    for g in gap_paths:
        d = json.loads(g.read_text())
        for key in FROZEN + ("arm", "layout", "model"):
            if d.get(key) != base.get(key):
                raise SystemExit(f"{g.name}: {key} differs from the arm it fills ({d.get(key)} vs {base.get(key)})")
        if Path(d["cases_file"]).name != Path(base["cases_file"]).name:
            raise SystemExit(f"{g.name}: cases file {d['cases_file']} is not the arm's {base['cases_file']}")
        for r in d["results"]:
            fills.setdefault(r["id"], []).extend(r["runs"])

    cases_file = Path(base["cases_file"])
    if not cases_file.is_absolute():
        cases_file = repo / cases_file
    cases = rr.load_cases(cases_file, [r["id"] for r in base["results"]])
    suffix = run_suffix(base, base_path.name)

    runs_by_case, results, passed, filled, killed_by_case, kept_errors = {}, [], 0, 0, {}, {}
    for case, old in zip(cases, base["results"]):
        assert case["id"] == old["id"]
        errors = [k for k, run in enumerate(old["runs"]) if run["outcome"] == "error"]
        queue = list(fills.pop(case["id"], []))
        killed = len(limit_transcripts(case["id"], suffix, projects)) if errors else 0
        if errors and killed == 0:
            if queue:
                raise SystemExit(f"case {case['id']}: {len(queue)} re-run(s) for {len(errors)} error run(s) that carry "
                                 f"no usage-limit message: those are real errors, never re-run")
            kept_errors[case["id"]] = len(errors)
        elif errors:
            if killed != len(errors):
                raise SystemExit(f"case {case['id']}: {len(errors)} error run(s) but {killed} transcript(s) with run suffix "
                                 f"{suffix} and the usage-limit message: a killed run cannot be told from a real error")
            if len(queue) != len(errors):
                raise SystemExit(f"case {case['id']}: {len(errors)} killed run(s) but {len(queue)} re-run(s)")
            killed_by_case[case["id"]] = killed
        elif queue:
            raise SystemExit(f"case {case['id']}: {len(queue)} re-run(s) for a case with no error run")
        runs = []
        for k, run in enumerate(old["runs"]):
            if k in errors and case["id"] in killed_by_case:
                runs.append(queue.pop(0))
                filled += 1
            else:
                runs.append(run)
        runs_by_case[case["id"]] = runs
        fired = [r["outcome"] for r in runs]
        ok, note = rr.verdict(old["expected"], fired, case.get("siblings"))
        passed += ok
        results.append({**old, "fired": fired, "runs": runs, "passed": ok, "note": note})
    if fills:
        raise SystemExit(f"re-runs for cases the arm does not hold: {sorted(fills)}")

    summary = rr.reach(cases, runs_by_case)
    explicit = rr.explicit_summary(cases, runs_by_case)
    measures = rr.reported(cases, runs_by_case) if base.get("layout") != "project" else None
    unscored = rr.set_aside_problem({k: summary[k] + explicit[k] for k in ("decided", "set_aside")})
    if check:
        same = (summary == base["reach"] and measures == base.get("reported")
                and (explicit == base.get("explicit") or "explicit" not in base))
        print(f"{model} {arm}: recomputed summaries equal the file's own: {same}")
        return base
    merged = {k: v for k, v in base.items() if k not in ("unscored", "passed", "reach", "explicit", "reported", "results")}
    merged.update(unscored=unscored, passed=passed, reach=summary,
                  **({"explicit": explicit} if explicit["decided"] or explicit["set_aside"] else {}),
                  **({"reported": measures} if measures is not None else {}),
                  results=results,
                  merged={"base": base_path.name, "gaps": [g.name for g in gap_paths], "runs_filled": filled,
                          "run_suffix": suffix, "killed_by_case": killed_by_case, "errors_kept_by_case": kept_errors,
                          "note": "runs killed by the usage limit, each matched by a transcript with the limit "
                                  "message, replaced by re-runs on the same commit (docs/fix-round-plan-detail.md, "
                                  "section 5)"})
    out = out or root / model / f"{arm}.json"
    if out.exists():
        raise SystemExit(f"{out} exists: a merge never overwrites a results file")
    out.write_text(json.dumps(merged, indent=2) + "\n")
    print(f"{model} {arm}: filled {filled} runs from {len(gap_paths)} re-run file(s); killed by case {killed_by_case}; "
          f"real errors kept {kept_errors or 'none'}; passed {passed}/{len(cases)}; "
          f"set aside {summary['set_aside'] + explicit['set_aside']}; unscored: {unscored}")
    return merged


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("model")
    ap.add_argument("arm")
    ap.add_argument("--root", type=Path, default=HERE)
    ap.add_argument("--repo", type=Path, default=HERE / "wt-text")
    ap.add_argument("--expect", nargs=2, metavar=("HUB", "FRONTDOOR"))
    ap.add_argument("--out", type=Path)
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    expect = tuple(a.expect) if a.expect else None
    if expect is None:
        sys.path.insert(0, str(a.repo / "ci"))
        import sync  # noqa: E402
        assert Path(sync.__file__).resolve().is_relative_to(a.repo.resolve()), sync.__file__
        digests = sync.digests()
        expect = (digests["hub_sha256"], digests["frontdoor_sha256"])
    merge(a.model, a.arm, a.root, a.repo, expect, a.out, a.check)


if __name__ == "__main__":
    main()
