"""versions.py [ROOT]: per routing results file and run suffix, the CLI versions and served models its session
transcripts record (killed sessions counted apart). A copy of round 3's (m17/verify/versions.py) for the round
folder (plan section 4.3: the CLI version and date of each arm); ROOT defaults to the round folder, laid out
as <ROOT>/<model>/<results file>. The dates are the transcripts' first and last timestamps."""
import json, re, sys, glob
from pathlib import Path
from collections import Counter, defaultdict
M17 = Path(sys.argv[1]) if sys.argv[1:] else Path(__file__).resolve().parent; P = "/root/.claude/projects"
idx = defaultdict(list)
for f in glob.glob(P + "/-tmp-*/*.jsonl"):
    t = open(f, encoding="utf-8", errors="replace").read()
    for s in set(re.findall(r"(?:tuesday|job-underwriter|mock-interview|resume-tailor)-([0-9a-f]{8})\b", t)):
        idx[s].append((f, t))
for m in ("claude-haiku-5-5", "claude-sonnet-5-5", "claude-opus-5-5"):
    for p in sorted((M17 / m).glob("*.json")):
        d = json.loads(p.read_text())
        sufs = Counter()
        for r in d["results"]:
            for run in r["runs"]:
                for s in run.get("init_skills") or []:
                    mm = re.search(r"-([0-9a-f]{8})$", s.split(":")[-1])
                    if mm: sufs[mm.group(1)] += 1; break
        for suf in sufs:
            ver, mod, killed, stamps = Counter(), Counter(), 0, []
            for f, t in idx[suf]:
                if "hit your weekly limit" in t:
                    killed += 1
                for line in t.splitlines():
                    try: e = json.loads(line)
                    except Exception: continue
                    if e.get("version"): ver[e["version"]] += 1
                    if e.get("timestamp"): stamps.append(e["timestamp"])
                    mm = (e.get("message") or {}).get("model") if e.get("type") == "assistant" else None
                    if mm: mod[mm] += 1
            print(f"{m}/{p.name} {suf}: versions {dict(ver)} models {dict(mod)} killed-sessions {killed} dates {min(stamps)[:10] if stamps else None}..{max(stamps)[:10] if stamps else None}")
