"""recheck.py <repo> <src> <out>: re-run <repo>'s deterministic checks on the saved runs of one set and
arm in <src>, writing each run's checks.json into <out> through run_fixtures.check_run.

Adapted from m18/prep/rescore/recheck.py (kept beside this as recheck.orig.py): it takes a source and an
output folder rather than a step, so it reads the quality check's per-arm folders and the smoke's
per-module folders alike. check_run reads a run's meta.json and response .md from the folder it writes
to, so each is linked into <out> for the call and the link removed after: only checks files are written.
No grade file is read or written, no model is called."""
import os
import sys
from pathlib import Path

repo, src, out = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve(), Path(sys.argv[3]).resolve()
sys.path.insert(0, str(repo / "evals"))
import run_fixtures as rf  # noqa: E402
from fixture_clauses import load_cases  # noqa: E402

assert Path(rf.__file__).resolve().parent.parent == repo, rf.__file__
out.mkdir(parents=True, exist_ok=True)
n = invalid = 0
for skill in rf.SKILLS:
    for case in load_cases(repo / "skills" / skill / "evals" / "evals.json"):
        for mode in rf.modes_of(case):
            for run in range(50):
                stem = rf.stem_for(skill, case, mode, run)
                if not (src / f"{stem}.meta.json").exists():
                    continue
                links = []
                for suffix in (".meta.json", ".md"):
                    if (src / f"{stem}{suffix}").exists():
                        link = out / f"{stem}{suffix}"
                        if link.is_symlink() or link.exists():
                            link.unlink()
                        os.symlink(src / f"{stem}{suffix}", link)
                        links.append(link)
                try:
                    record = rf.check_run(skill, case, out, run, mode)
                finally:
                    for link in links:
                        link.unlink()
                n += 1
                invalid += record.get("status") == "harness-invalid"
seen = len(list(src.glob("*.meta.json")))
print(f"{src} -> {out}: {n} runs re-checked ({invalid} harness-invalid) of {seen} meta files")
