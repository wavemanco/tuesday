"""baselines.py <repo>: section 4.2's baselines from the re-checked saved runs, per model and arm, read
with <repo>'s compare_arms (load, text_change_measures), and compared with the figures the plan states.
Reads meta.json and grade files from the saved sets and checks files from this folder; writes nothing."""
import sys
from pathlib import Path

repo = Path(sys.argv[1]).resolve()
SP = Path("/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad")
RC = Path(__file__).resolve().parent
sys.path.insert(0, str(repo / "evals"))
import compare_arms as ca  # noqa: E402

cases = ca.fixture_cases()
MEASURES = {   # short name -> the text-change block's label
    "H1 sentences above one": "ledger_sentence: sentences after the ledger above one",
    "set claims": "ledger_sentence: failed for a set claim (any reason but a second sentence)",
    "ledger_present": "ledger_present: passing, of job-underwriter's valid runs",
    "list form (reported)": "ledger_sentence_form: passing, the list form or no sentence (reported)",
    "eval 5 beyond a quick check": "zero_calls: failing, job-underwriter eval 5",
    "eval 5 with a quick check": "zero_calls: a quick check, job-underwriter eval 5",
    "eval 8 beyond a quick check": "zero_calls: failing, mock-interview eval 8",
    "eval 8 with a quick check": "zero_calls: a quick check, mock-interview eval 8",
    "every call reported": "every call reported (the checks below), of the runs that sent a call",
    "calls per run": "calls per run",
}
# The plan's stated baselines (docs/fix-round-plan-detail.md sections 2.1 H1, 2.2 c and 4.2), pooled per model,
# and the per-arm H1 counts section 2.1 gives (alone, then through Tuesday).
PLAN = {
    "sonnet": {"H1 sentences above one": (31, 80), "set claims": (2, 80), "ledger_present": (80, 80),
               "eval 5 beyond a quick check": (2, 20), "eval 8 beyond a quick check": (0, 20),
               "every call reported": (19, 19), "calls per run": "0.98"},
    "haiku": {"H1 sentences above one": (35, 47), "set claims": (9, 47), "ledger_present": (48, 80),
              "eval 5 beyond a quick check": (12, 20), "eval 8 beyond a quick check": (0, 20),
              "every call reported": (17, 20), "calls per run": "1.43"},
    "opus": {"H1 sentences above one": (65, 80), "set claims": (2, 80), "ledger_present": (80, 80),
             "eval 5 beyond a quick check": (2, 20), "eval 8 beyond a quick check": (0, 20),
             "every call reported": (14, 14), "calls per run": "0.43"},
}
PLAN_H1_ARMS = {"sonnet": {"alone": (19, 40), "tuesday": (12, 40)}, "haiku": {"alone": (15, 20), "tuesday": (20, 27)},
                "opus": {"alone": (33, 40), "tuesday": (32, 40)}}
PLAN_SMOKE_H1 = {"sonnet": (1, 4), "opus": (4, 4)}   # section 2.1: "on the matched install ... Opus 4 of 4, Sonnet 1 of 4"


def measures(runs):
    return {short: dict(ca.text_change_measures(runs))[label] for short, label in MEASURES.items()}


def cell(v):
    if len(v) == 3:
        return f"{v[0]}/{v[1]} ({rate(v)})" if v[1] else f"{v[0]}/0"   # rounded half up, as compare_arms prints
    return f"{v[0]}/{v[1]}"


def rate(v):
    return str((ca.Decimal(v[0]) / ca.Decimal(v[1])).quantize(ca.Decimal("0.01"), ca.ROUND_HALF_UP)) if v[1] else None


def table(title, sets):
    cols = list(sets)
    got = {c: measures(sets[c]) for c in cols}
    print(f"\n{title}")
    print(f"  {'':<30}" + "".join(f"{c:>16}" for c in cols))
    for short in MEASURES:
        print(f"  {short:<30}" + "".join(f"{cell(got[c][short]):>16}" for c in cols))
    return got


mismatches = []
print("Section 4.2 baselines: the quality check's saved runs, re-checked under the text commit's checks")
for model in ("sonnet", "haiku", "opus"):
    arms = {arm: ca.load(SP / "m18" / model / arm, RC / "m18" / model / arm, cases) for arm in ("tuesday", "alone")}
    got = table(f"{model} (quality check, m18 sets)", {"pooled": arms["tuesday"] + arms["alone"], **arms})
    for short, want in PLAN[model].items():
        have = got["pooled"][short]
        ok = (rate(have) == want) if isinstance(want, str) else (tuple(have[:2]) == want)
        print(f"    plan {short}: {want if isinstance(want, str) else f'{want[0]}/{want[1]}'}, "
              f"re-check {rate(have) if isinstance(want, str) else cell(have)}: {'match' if ok else 'MISMATCH'}")
        if not ok:
            mismatches.append(f"{model} {short}: plan {want}, re-check {have}")
    for arm, want in PLAN_H1_ARMS[model].items():
        have = tuple(got[arm]["H1 sentences above one"][:2])
        print(f"    plan H1 {arm}: {want[0]}/{want[1]}, re-check {have[0]}/{have[1]}: "
              f"{'match' if have == want else 'MISMATCH'}")
        if have != want:
            mismatches.append(f"{model} H1 {arm}: plan {want}, re-check {have}")

print("\n\nThe smoke's runs (smoke-so), re-checked the same way: per model and arm, every module pooled")
for model in ("sonnet", "opus"):
    arms = {}
    for arm in ("plugin", "project", "tuesday"):
        arms[arm] = [r for mod in sorted((SP / "smoke-so" / model / arm).iterdir()) if mod.is_dir()
                     for r in ca.load(mod, RC / "smoke" / model / arm / mod.name, cases)]
    got = table(f"{model} (smoke)", {"matched (plugin+tuesday)": arms["plugin"] + arms["tuesday"], **arms})
    have = tuple(got["matched (plugin+tuesday)"]["H1 sentences above one"][:2])
    want = PLAN_SMOKE_H1[model]
    print(f"    plan H1 on the matched install: {want[0]}/{want[1]}, re-check {have[0]}/{have[1]}: "
          f"{'match' if have == want else 'MISMATCH'}")
    if have != want:
        mismatches.append(f"smoke {model} H1: plan {want}, re-check {have}")

print("\n" + ("No mismatch with the plan's stated baselines." if not mismatches
              else f"{len(mismatches)} mismatch(es):\n  " + "\n  ".join(mismatches)))
