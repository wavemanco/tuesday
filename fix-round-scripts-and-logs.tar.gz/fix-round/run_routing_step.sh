#!/bin/bash
# run_routing_step.sh <model-folder> <model-id> [<extra-case-id>]: one model's routing step (plan section 3,
# "The routing runs" and "The extra case runs"). The three arms run one after another, each wrapped in
# logged.sh, into <round>/<model>/<arm>.json with a .log beside it. Then, for Haiku (case 3) and Opus
# (case 10), the two arms of the extra case start together at 45 runs each. Progress goes to
# <model>/routing-status, kept apart from the quality step's status file.
set -u
R=/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round
export ROUND=$R
MF=$1; MODEL=$2; EXTRA=${3:-}
S="$R/$MF/routing-status"
cd "$R/wt-text" || exit 9
[ "$(git rev-parse HEAD)" = b8702ac80f8f026d2ba38dea4d7e30704ba5aac1 ] || { echo "wt-text is not at b8702ac" >> "$S"; exit 9; }
run() {
  local label=$1 out=$2; shift 2
  [ -e "$out" ] && { echo "$(date -u +%H:%M:%S) $label: $out exists, not overwritten" >> "$S"; return; }
  "$R/logged.sh" "$MF-$label" python3 evals/run_routing.py --model "$MODEL" --workers 3 "$@" --json-out "$out" \
    > "${out%.json}.log" 2>&1
  echo "$(date -u +%H:%M:%S) $label exit $?" >> "$S"
}
mkdir -p "$R/$MF"
echo "$(date -u +%H:%M:%S) start routing $MODEL" >> "$S"
run e0-personal "$R/$MF/e0-personal.json" --runs 5 --arm skills --layout personal
run e1-plugin "$R/$MF/e1-plugin.json" --runs 5 --arm frontdoor --layout plugin
run e2-plugin "$R/$MF/e2-plugin.json" --runs 5 --arm frontdoor --layout plugin --cases evals/suite-explicit.json
if [ -n "$EXTRA" ]; then
  run e0-personal.case$EXTRA "$R/$MF/e0-personal.case$EXTRA.json" --runs 45 --arm skills --layout personal --case "$EXTRA" &
  run e1-plugin.case$EXTRA "$R/$MF/e1-plugin.case$EXTRA.json" --runs 45 --arm frontdoor --layout plugin --case "$EXTRA" &
  wait
fi
python3 "$R/meter.py" "after-$MF-routing" >> "$S" 2>&1
echo "$(date -u +%H:%M:%S) done" >> "$S"
