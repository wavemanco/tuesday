"""recheck.py <repo> <step> <out>: re-run <repo>'s deterministic checks on the saved m18 runs of one
step (both arms), writing each run's checks.json into <out>/<arm>/ through run_fixtures.check_run.
Only meta.json and the response .md are copied; no grade file is read or written, no model is called."""
import json, shutil, sys
from pathlib import Path
repo, step, out = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3])
M18 = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(repo / "evals"))
import run_fixtures as rf
from fixture_clauses import load_cases
n = 0
for arm in ("alone", "tuesday"):
    src, dst = M18 / step / arm, out / arm
    dst.mkdir(parents=True, exist_ok=True)
    for skill in rf.SKILLS:
        for case in load_cases(repo / "skills" / skill / "evals" / "evals.json"):
            for mode in rf.modes_of(case):
                for run in range(10):
                    stem = rf.stem_for(skill, case, mode, run)
                    if not (src / f"{stem}.meta.json").exists():
                        continue
                    for suffix in (".meta.json", ".md"):
                        if (src / f"{stem}{suffix}").exists():
                            shutil.copy2(src / f"{stem}{suffix}", dst / f"{stem}{suffix}")
                    rf.check_run(skill, case, dst, run, mode)
                    n += 1
print(step, n, "runs re-checked into", out)
