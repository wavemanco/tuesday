"""layout_check.py <layout-personal.json> <layout-plugin.json>: score the pre-flight's two layout checks (plan section 3).

The plan's criterion is that "the session's skill list holds only that run's skills and its outcome is not
void". The CLI lists its own bundled skills in every session (21 to 22 of them in round 3's runs), so the
list is read for the Tuesday family alone, as the runner's own foreign_tuesday rule reads it: every entry
whose run_routing.tuesday_base is tuesday or a module carries the file's one run suffix, and the run's own
skills are all there (the three modules in today's skills; Tuesday and the three modules in the plugin).
The outcome must be decided (not void, timeout or error). The plugin file's Tuesday hashes must equal the
measured commit's (sync.digests() of the pinned worktree). Writes nothing.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
WT = HERE / "wt-text"
sys.path[:0] = [str(WT / "evals"), str(WT / "ci")]
import run_routing as rr  # noqa: E402
import sync  # noqa: E402

assert Path(rr.__file__).resolve().is_relative_to(WT.resolve()) and Path(sync.__file__).resolve().is_relative_to(WT.resolve())
FAMILY = set(rr.SKILLS) | {rr.HUB}
WANT = {("skills", "personal"): set(rr.SKILLS), ("frontdoor", "plugin"): FAMILY}


def score(path: Path) -> tuple[bool, list[str]]:
    d = json.loads(path.read_text())
    notes, ok = [], True
    key = (d.get("arm"), d.get("layout"))
    if key not in WANT:
        return False, [f"arm {key[0]} with layout {key[1]} is neither of the two layout checks"]
    runs = [run for res in d["results"] for run in res["runs"]]
    if len(runs) != 1:
        ok = False
        notes.append(f"{len(runs)} runs, not one")
    if key == ("frontdoor", "plugin"):
        want = sync.digests()
        got = {k: d.get(k) for k in ("hub_sha256", "frontdoor_sha256")}
        if got != {k: want[k] for k in got}:
            ok = False
            notes.append(f"Tuesday's hashes {got} are not the measured commit's")
    for run in runs:
        listed = [s for s in run.get("init_skills") or [] if isinstance(s, str)]
        family = [s for s in listed if rr.tuesday_base(s) in FAMILY]
        suffixes = {m.group(1) for s in family for m in [re.search(r"-([0-9a-f]{8})$", rr.local_name(s))] if m}
        bases = {rr.tuesday_base(s) for s in family}
        notes.append(f"outcome {run['outcome']}; {len(listed)} skills listed, {len(family)} of the Tuesday family "
                     f"{sorted(family)}, {len(listed) - len(family)} the CLI's own")
        if run["outcome"] in rr.SET_ASIDE:
            ok = False
            notes.append(f"outcome {run['outcome']} is not decided")
        if len(suffixes) != 1 or any(not re.search(r"-[0-9a-f]{8}$", rr.local_name(s)) for s in family):
            ok = False
            notes.append(f"the Tuesday-family entries carry {len(suffixes)} run suffixes, or one carries none: "
                         f"a skill this run did not install is listed")
        if bases != WANT[key] or len(family) != len(WANT[key]):
            ok = False
            notes.append(f"the run's own skills are {sorted(bases)} ({len(family)} entries), not {sorted(WANT[key])}")
    return ok, notes


def main() -> int:
    if len(sys.argv) != 3:
        print(__doc__)
        return 2
    verdicts = []
    for arg in sys.argv[1:]:
        ok, notes = score(Path(arg))
        verdicts.append(ok)
        print(f"{Path(arg).name}: {'PASS' if ok else 'FAIL'}")
        for n in notes:
            print(f"  {n}")
    print("layout checks:", "PASS" if all(verdicts) else "FAIL")
    return 0 if all(verdicts) else 1


if __name__ == "__main__":
    raise SystemExit(main())
