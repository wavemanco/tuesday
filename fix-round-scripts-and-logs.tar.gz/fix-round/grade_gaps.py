"""grade_gaps.py <out> [--graders N] [--move]: the finished runs of one --out folder whose grading was cut off.

Plan section 5, killed runs: "Runs that finished but were not graded when the process died are graded in place
with --stems ... --skip-execute." That pass grades only a run that holds no grade file, and a grader stopped by
the usage limit still writes one, holding only the error; a restart during grading leaves a run with fewer
grade files than --graders. So before the pass, every grade file of such a run moves to <out>/killed/ (kept,
never deleted), and the pass grades the run afresh with every grader.

A finished run is one with its response (<stem>.md) saved and no execution error in its meta. It is listed
when it holds fewer than --graders grade files that carry verdicts:
  - cut by the usage limit: a grade file whose error carries the limit message;
  - cut by a restart: grade files missing;
  - otherwise: a grade with no verdicts for another reason (a grader timeout, a malformed reply). These are
    listed apart and never moved: whether to regrade them is the owner's decision, not this step's.
With --move, the limit- and restart-cut runs' grade files move to killed/ and their stems are written to
killed/regrade-<UTC time>.txt, for:
    python evals/run_fixtures.py <the invocation's own flags> --stems <that file> --skip-execute --out <out>
Without --move it only lists. Writes nothing else and starts nothing.
"""
from __future__ import annotations

import argparse
import datetime
import json
import re
import shutil
from pathlib import Path

LIMIT = re.compile(r"hit your (?:weekly |session |usage )?limit|\busage limit\b|\bsession limit\b", re.I)


def survey(out: Path, graders: int) -> dict[str, list]:
    found = {"limit": [], "restart": [], "other": []}
    for meta_path in sorted(out.glob("*.meta.json")):
        stem = meta_path.name[: -len(".meta.json")]
        try:
            meta = json.loads(meta_path.read_text())
        except (OSError, json.JSONDecodeError):
            continue
        if meta.get("error") or not (out / f"{stem}.md").exists():
            continue        # not finished: a killed or set-aside execution, handled apart
        grades = sorted(out.glob(f"{stem}.grade-*.json"))
        good, errors = 0, []
        for g in grades:
            try:
                data = json.loads(g.read_text())
            except (OSError, json.JSONDecodeError):
                errors.append((g.name, "unreadable"))
                continue
            if data.get("verdicts") and not data.get("harness_invalid"):
                good += 1
            else:
                errors.append((g.name, str(data.get("error") or "no verdicts")))
        if good >= graders:
            continue
        entry = {"stem": stem, "grade_files": [g.name for g in grades], "with_verdicts": good, "errors": errors}
        if errors and not all(LIMIT.search(why) for _, why in errors):
            found["other"].append(entry)
        elif errors:
            found["limit"].append(entry)
        else:
            found["restart"].append(entry)
    return found


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("out", type=Path)
    ap.add_argument("--graders", type=int, default=2)
    ap.add_argument("--move", action="store_true")
    a = ap.parse_args()
    found = survey(a.out, a.graders)
    for kind, label in (("limit", "grading cut by the usage limit"), ("restart", "grading cut by a restart"),
                        ("other", "no verdicts for another reason: not moved, for the owner")):
        for e in found[kind]:
            print(f"  {label}: {e['stem']} ({e['with_verdicts']} of {a.graders} grades with verdicts; "
                  f"{'; '.join(f'{n}: {w[:80]}' for n, w in e['errors']) or 'grade files missing'})")
    regrade = found["limit"] + found["restart"]
    print(f"{len(regrade)} run(s) to grade in place, {len(found['other'])} for the owner")
    if a.move and regrade:
        killed = a.out / "killed"
        killed.mkdir(exist_ok=True)
        for e in regrade:
            for name in e["grade_files"]:
                if (killed / name).exists():
                    raise SystemExit(f"{killed / name} exists: nothing is overwritten")
                shutil.move(str(a.out / name), str(killed / name))
        stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        stems = killed / f"regrade-{stamp}.txt"
        stems.write_text("".join(f"{e['stem']}\n" for e in regrade))
        print(f"moved their grade files to {killed}; stems for --stems ... --skip-execute: {stems}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
