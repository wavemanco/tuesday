#!/bin/bash
# logged.sh <label> <command...>: run one step's command with its start and end in the run log
# (plan section 3: each run records its CLI version; section 4.3: the CLI version and date of each arm).
# The routing results files record neither, so the log does: UTC time and `claude --version` before
# and after, and the exit code. The command's own output goes where the command sends it.
set -u
R=${ROUND:-/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round}
label=$1; shift
echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) start $label: CLI $(claude --version 2>&1 | head -1): $*" >> "$R/run-log.txt"
"$@"; code=$?
echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) end $label: exit $code; CLI $(claude --version 2>&1 | head -1)" >> "$R/run-log.txt"
exit $code
