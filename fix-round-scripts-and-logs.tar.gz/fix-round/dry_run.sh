#!/bin/bash
# Dry run of the record commit (plan section 2.3 item 2), on a worktree of the text commit that is
# never committed: MEASURED_FRONTDOOR set to the text commit's three hashes, plugin 0.2.0, rebuilt.
set -u
R=/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round
cd "$R/dry-run"
# The hash edit keeps check_skills.py's size, and can land in the second its bytecode was cached,
# so Python would load the old module: write no bytecode, and clear any left from earlier runs.
export PYTHONDONTWRITEBYTECODE=1
find . -name __pycache__ -type d -prune -exec rm -rf {} +
echo "dry run of the record commit, $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "worktree $R/dry-run at $(git rev-parse HEAD) (detached, never committed)"
python3 - <<'PY'
import sys, json
from pathlib import Path
sys.path.insert(0, "ci")
import check_skills as cs
now = cs.frontdoor_digests()
p = Path("ci/check_skills.py"); t = p.read_text()
for key in cs.MEASURED_HASHES:
    old = cs.MEASURED_FRONTDOOR[key]
    assert t.count(old) == 1
    t = t.replace(old, now[key])
old = '"plugin_version": "0.1.0"'
assert t.count(old) == 1
t = t.replace(old, '"plugin_version": "0.2.0"')
p.write_text(t)
print("MEASURED_FRONTDOOR set to the text commit's hashes:")
for key in cs.MEASURED_HASHES:
    print(f"  {key} {now[key]}")
print("  plugin_version 0.2.0")
PY
echo; echo "== python3 ci/package.py"; python3 ci/package.py 2>&1 | tail -3; echo "exit ${PIPESTATUS[0]}"
echo; echo "== git status after the rebuild (what the record commit would change)"; git status --short
for g in "ci/sync.py --check" "ci/check_skills.py" "ci/test_checks.py" "evals/test_harness.py" "evals/routing_variants.py --check"; do
  echo; echo "== python3 $g"
  python3 $g > "$R/dry-run-$(echo $g | tr '/ ' '__').log" 2>&1; code=$?
  case "$g" in
    ci/check_skills.py) grep -E '^\S.*:$|problem|All checks' "$R/dry-run-$(echo $g | tr '/ ' '__').log" | grep -v ':$' ; tail -1 "$R/dry-run-$(echo $g | tr '/ ' '__').log";;
    ci/test_checks.py) grep -cE '^  ok ' "$R/dry-run-$(echo $g | tr '/ ' '__').log" | sed 's/^/ok lines: /'; grep -E 'FAIL' "$R/dry-run-$(echo $g | tr '/ ' '__').log"; tail -1 "$R/dry-run-$(echo $g | tr '/ ' '__').log";;
    *) tail -1 "$R/dry-run-$(echo $g | tr '/ ' '__').log";;
  esac
  echo "exit $code"
done
