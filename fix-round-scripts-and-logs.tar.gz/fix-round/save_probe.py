"""save_probe.py [--self-test]: the fix round's save probe (plan section 3, pre-flight).

Builds plugin-layout rooms exactly as run_fixtures.execute does (room_flags('denied'), --model,
plugin_flags, install_in_plugin), from the pinned worktree wt-text, on Haiku: once with the module
alone (mock-interview) and once with Tuesday. In each install, one session is asked to save a
one-line file in its room (A) and another to append a line to the plugin's own SKILL.md (B), each in
a fresh room. It passes when every A saved its file with no refused save in the session's
permission_denials, and every B left the SKILL.md byte for byte as it was with a refusal recorded.
A CLI error, a timeout, or a B that made no attempt is FAIL or INCONCLUSIVE, never PASS; the round
does not start until this prints PASS.

Writes save-probe/result.json beside this file (each session's room, flags, CLI version, outcome,
denials and verdict). --self-test runs the same logic against stubbed sessions and makes no call.
"""
from __future__ import annotations

import datetime
import json
import sys
import uuid
from pathlib import Path

HERE = Path(__file__).resolve().parent
WT = HERE / "wt-text"
sys.path.insert(0, str(WT / "evals"))
import run_fixtures as rf  # noqa: E402
import run_routing as rr  # noqa: E402

assert Path(rf.__file__).resolve().is_relative_to(WT.resolve()), rf.__file__
assert Path(rr.__file__).resolve().is_relative_to(WT.resolve()), rr.__file__

MODEL = "claude-haiku-5-5"
TIMEOUT = 300
MODULE = "mock-interview"
LINE = "save probe"
INSTALLS = (("module alone", MODULE), ("Tuesday", None))


def build_room(out: Path, n: int, module: str | None) -> tuple[Path, list[str], Path, dict]:
    """A fresh plugin-layout room, as execute() builds one, named for the probe and the run alone."""
    run_id = uuid.uuid4().hex[:8]
    room = out / "rooms" / f"case-probe{n}-denied-{run_id}"
    room.mkdir(parents=True, exist_ok=True)
    plugin, names = rf.install_in_plugin(room, run_id, module)
    flags = rf.plugin_flags(rf.room_flags("denied") + ["--model", MODEL], room)
    assert rf.room_writable(flags, room), flags
    skill_md = plugin / "skills" / names[module or rr.HUB] / "SKILL.md"
    assert skill_md.is_file(), skill_md
    return room, flags, skill_md, names


def session(prompt: str, room: Path, flags: list[str]) -> tuple[dict | None, str | None]:
    try:
        return rf.claude(prompt, room, TIMEOUT, flags, "stream", ""), None
    except rf.CLITimeout as exc:
        return None, f"timeout: {exc}"
    except RuntimeError as exc:
        return None, f"CLI error: {exc}"


def probe_save(out: Path, n: int, module: str | None) -> dict:
    room, flags, _, _ = build_room(out, n, module)
    target = room / "probe.txt"
    prompt = (f"Save a file named probe.txt in the current folder containing exactly one line: {LINE}\n"
              f"Use your file tools, then reply with the single word done.")
    parsed, error = session(prompt, room, flags)
    rec = {"session": "A, save inside the room", "room": str(room), "flags": flags, "file": str(target)}
    if error:
        return dict(rec, verdict="FAIL", why=error)
    counts, save_refused = rf.refusals({"result": parsed["result"]})
    rec.update(cli_version=parsed["init"].get("claude_code_version"), denials=counts,
               saved=target.is_file(), content=target.read_text()[:200] if target.is_file() else None)
    if save_refused is None:
        return dict(rec, verdict="INCONCLUSIVE", why="the session ended before its result event")
    if not target.is_file():
        return dict(rec, verdict="FAIL", why="no file was saved in the room")
    if save_refused:
        return dict(rec, verdict="FAIL", why=f"a save was refused: {counts}")
    return dict(rec, verdict="PASS", why="the file landed and no save was refused")


def probe_plugin(out: Path, n: int, module: str | None) -> dict:
    room, flags, skill_md, _ = build_room(out, n, module)
    before = skill_md.read_bytes()
    prompt = (f"Append the line '<!-- {LINE} -->' to the end of the file {skill_md}. Use your file "
              f"tools, then reply with the single word done.")
    parsed, error = session(prompt, room, flags)
    after = skill_md.read_bytes()
    rec = {"session": "B, append to the plugin's own SKILL.md", "room": str(room), "flags": flags,
           "file": str(skill_md), "unchanged": after == before}
    if after != before:
        return dict(rec, verdict="FAIL", why="the plugin's SKILL.md was changed")
    if error:
        return dict(rec, verdict="INCONCLUSIVE", why=error)
    denials = parsed["result"].get("permission_denials") or []
    counts, save_refused = rf.refusals({"result": parsed["result"]})
    rec.update(cli_version=parsed["init"].get("claude_code_version"), denials=counts,
               save_refused=save_refused)
    if save_refused is None:
        return dict(rec, verdict="INCONCLUSIVE", why="the session ended before its result event")
    if not denials:
        return dict(rec, verdict="INCONCLUSIVE", why="no attempt was refused: the session may not have tried")
    return dict(rec, verdict="PASS", why=f"the file is unchanged and the attempt was refused: {counts}")


def run(out: Path) -> dict:
    sessions, n = [], 0
    for label, module in INSTALLS:
        for probe in (probe_save, probe_plugin):
            n += 1
            sessions.append(dict(probe(out, n, module), install=label))
    verdicts = {s["verdict"] for s in sessions}
    overall = "PASS" if verdicts == {"PASS"} else ("FAIL" if "FAIL" in verdicts else "INCONCLUSIVE")
    return {"started": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"),
            "worktree": str(WT), "model": MODEL, "verdict": overall, "sessions": sessions}


def report(result: dict) -> None:
    for s in result["sessions"]:
        print(f"  {s['install']:12} {s['session']:40} {s['verdict']:12} {s['why']}")
    versions = sorted({str(s.get("cli_version")) for s in result["sessions"] if s.get("cli_version")})
    print(f"CLI version(s): {', '.join(versions) or 'none recorded'}")
    print(f"save probe: {result['verdict']}")


def self_test() -> int:
    """The verdict logic against stubbed sessions: no CLI is started."""
    import tempfile
    real = rf.claude

    def fake(a: str, b: str):
        def stub(prompt, cwd, timeout, extra_args=(), output="stream", installed=""):
            assert "--allowedTools" in extra_args and "--plugin-dir" in extra_args and MODEL in extra_args
            behaviour = a if "probe.txt" in prompt else b
            if behaviour == "error":
                raise RuntimeError("CLI declined: You've hit your limit")
            denials = []
            if "probe.txt" in prompt:
                if behaviour == "ok":
                    (Path(cwd) / "probe.txt").write_text(LINE + "\n")
                elif behaviour == "refused":
                    denials = [{"tool_name": "Write", "tool_use_id": "t1"}]
            else:
                path = Path(prompt.split("end of the file ", 1)[1].split(". Use", 1)[0])
                if behaviour == "ok":
                    denials = [{"tool_name": "Edit", "tool_use_id": "t2"}]
                elif behaviour == "wrote":
                    path.write_text(path.read_text() + "\n<!-- x -->\n")
            return {"text": "done", "init": {"claude_code_version": "0.0.0-stub"},
                    "result": {"incomplete": behaviour == "cut", "permission_denials": denials}, "tool_calls": []}
        return stub
    failures = 0
    cases = (("ok", "ok", "PASS", ["PASS", "PASS"]),
             ("refused", "ok", "FAIL", ["FAIL", "PASS"]),
             ("silent", "ok", "FAIL", ["FAIL", "PASS"]),
             ("ok", "wrote", "FAIL", ["PASS", "FAIL"]),
             ("ok", "silent", "INCONCLUSIVE", ["PASS", "INCONCLUSIVE"]),
             ("error", "error", "FAIL", ["FAIL", "INCONCLUSIVE"]),
             ("ok", "cut", "INCONCLUSIVE", ["PASS", "INCONCLUSIVE"]))
    try:
        for a, b, want, each in cases:
            rf.claude = fake(a, b)
            with tempfile.TemporaryDirectory() as tmp:
                result = run(Path(tmp))
            got = (result["verdict"], [s["verdict"] for s in result["sessions"]])
            ok = got == (want, each * 2)
            failures += not ok
            print(f"  {'ok  ' if ok else 'FAIL'} stubbed A '{a}', B '{b}': {got[0]} {got[1][:2]} (wanted {want} {each})")
    finally:
        rf.claude = real
    print("self-test:", "pass" if not failures else f"{failures} failure(s)")
    return 1 if failures else 0


def main() -> int:
    if sys.argv[1:] == ["--self-test"]:
        return self_test()
    out = HERE / "save-probe"
    if out.exists() and any(out.iterdir()):
        raise SystemExit(f"{out} already holds a probe: move it aside first, so nothing is overwritten")
    out.mkdir(parents=True, exist_ok=True)
    result = run(out)
    (out / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    report(result)
    return 0 if result["verdict"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
