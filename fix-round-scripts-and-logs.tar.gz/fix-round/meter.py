"""meter.py <label>: one meter reading for the run log (plan section 3, stop rule; section 6).

A copy of the smoke's meter reader (smoke-so/meter/read.py): one tiny Haiku call, started clean
(child_env, from the pinned worktree). It saves the session's rate_limit_event to
meter/<UTC time>-<label>.json and appends one line to run-log.txt: the time, the label, the CLI
version the session's own init event reports, and the seven-day utilization.
"""
import datetime
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "wt-text" / "evals"))
from child_env import child_env  # noqa: E402

label = "-".join(sys.argv[1:]) or "reading"
(HERE / "meter").mkdir(exist_ok=True)
now = datetime.datetime.now(datetime.timezone.utc)
p = subprocess.run(["claude", "-p", "Reply with OK.", "--model", "claude-haiku-5-5", "--output-format", "stream-json",
                    "--verbose"], capture_output=True, text=True, timeout=120, env=child_env(), cwd=HERE / "meter")
version, info = None, None
for line in p.stdout.splitlines():
    try:
        e = json.loads(line)
    except ValueError:
        continue
    if e.get("type") == "system" and e.get("subtype") == "init":
        version = e.get("claude_code_version")
    if e.get("type") == "rate_limit_event":
        info = e.get("rate_limit_info") or e
stamp = now.strftime("%Y-%m-%dT%H:%M:%SZ")
if info is None:
    line = f"{stamp} meter {label}: NO READING (exit {p.returncode}; {(p.stdout or p.stderr).strip()[:160]!r}); CLI {version}"
else:
    (HERE / "meter" / f"{now.strftime('%Y%m%dT%H%M%SZ')}-{label}.json").write_text(json.dumps(info) + "\n")
    line = f"{stamp} meter {label}: seven-day {info['unifiedWindows']['seven_day']['utilization']}; CLI {version}"
with open(HERE / "run-log.txt", "a") as log:
    log.write(line + "\n")
print(line)
