#!/bin/bash
# run_quality.sh <model-folder> <model-id> <runs-job-underwriter> <runs-mock-interview> <runs-resume-tailor>
# One model's quality step (plan section 3): both arms start together; in each arm the three modules run
# one after another into neutral folders (part-1 job-underwriter, part-2 mock-interview, part-3
# resume-tailor; owner's decision, 11 November). Every command is wrapped in logged.sh. Exit codes 0, 1
# and 3 are normal ends under --retry-runs 0.
set -u
R=/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round
export ROUND=$R
MF=$1; MODEL=$2; RUNS=("$3" "$4" "$5")
MODULES=(job-underwriter mock-interview resume-tailor)
cd "$R/wt-text" || exit 9
[ "$(git rev-parse HEAD)" = b8702ac80f8f026d2ba38dea4d7e30704ba5aac1 ] || { echo "wt-text is not at b8702ac"; exit 9; }
arm() {
  local name=$1; shift
  for i in 0 1 2; do
    local out="$R/$MF/$name/part-$((i+1))"
    mkdir -p "$out"
    "$R/logged.sh" "$MF-$name-part-$((i+1))" python3 evals/run_fixtures.py "$@" --skill "${MODULES[$i]}" \
      --runs "${RUNS[$i]}" --model "$MODEL" --grader-model claude-sonnet-5-5 --graders 2 --retry-runs 0 \
      --workers 3 --out "$out" > "$out.log" 2>&1
    local code=$?
    echo "$(date -u +%H:%M:%S) $name part-$((i+1)) (${MODULES[$i]}) exit $code" >> "$R/$MF/status"
  done
}
mkdir -p "$R/$MF"
echo "$(date -u +%H:%M:%S) start $MODEL" >> "$R/$MF/status"
arm alone --via skill --layout plugin &
arm tuesday --via frontdoor &
wait
python3 "$R/meter.py" "after-$MF-quality" >> "$R/$MF/status" 2>&1
echo "$(date -u +%H:%M:%S) done" >> "$R/$MF/status"
