#!/bin/bash
# guard.sh <model-folder> <driver-pgid> <threshold, e.g. 0.95>: read the meter every 20 minutes while a quality step
# runs; at the threshold, stop the step's whole process group so the owner is not locked out of Claude.
# Stopped runs are handled as killed runs under plan section 5. Owner's decision, 11 November evening.
set -u
R=/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round
MF=$1; PG=$2; TH=$3; n=0
while kill -0 -- "-$PG" 2>/dev/null && ! grep -q ' done$' "$R/$MF/status"; do
  sleep 1200
  kill -0 -- "-$PG" 2>/dev/null || break
  n=$((n+1))
  line=$(python3 "$R/meter.py" "guard-$MF-$n" 2>&1 | tail -1)
  echo "$(date -u +%H:%M:%S) guard: $line" >> "$R/$MF/status"
  u=$(echo "$line" | sed -n 's/.*seven-day \([0-9.]*\).*/\1/p')
  if [ -n "$u" ] && python3 -c "import sys; sys.exit(0 if float('$u') >= float('$TH') else 1)"; then
    echo "$(date -u +%H:%M:%S) guard: meter $u >= $TH, stopping the step (process group $PG)" >> "$R/$MF/status"
    echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) guard stopped $MF at meter $u (process group $PG)" >> "$R/run-log.txt"
    kill -TERM -- "-$PG"
    echo "$(date -u +%H:%M:%S) stopped" >> "$R/$MF/status"
    exit 0
  fi
done
