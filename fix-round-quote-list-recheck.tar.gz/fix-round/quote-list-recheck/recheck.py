"""Re-check the fix round's saved runs with this checkout's checks, writing checks files to a separate folder.
No model is called; the saved checks files are not touched."""
import sys, json, glob, os, collections
REPO = '/home/user/tuesday'
R = '/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round'
OUT = sys.argv[1]
sys.path.insert(0, REPO + '/evals')
import run_fixtures as rf, output_checks as oc
from fixture_clauses import dated
assert os.path.dirname(os.path.dirname(os.path.abspath(rf.__file__))) == REPO
SK = {1: 'job-underwriter', 2: 'mock-interview', 3: 'resume-tailor'}
cases = {s: {c['id']: c for c in rf.cases_for(s, [])} for s in SK.values()}
same = diff = 0; changed = collections.Counter(); ex = []
for m in ['haiku', 'sonnet', 'opus']:
    for a in ['tuesday', 'alone']:
        for p, s in SK.items():
            d = f'{R}/{m}/{a}/part-{p}'; o = f'{OUT}/{m}/{a}/part-{p}'; os.makedirs(o, exist_ok=True)
            line = oc.declared_watch_out((rf.REPO / 'skills' / s / 'SKILL.md').read_text())
            for mf in sorted(glob.glob(d + '/*.meta.json')):
                meta = json.load(open(mf)); stem = meta['stem']
                case = dated(cases[s][meta['id']], rf.run_date(meta))
                status, reasons = rf.harness_status(meta)
                body = open(f'{d}/{stem}.md').read()
                rec = oc.run_checks(case, meta['mode'], body, meta.get('research_log'), status, reasons, watch_out=line or '')
                rec = {'skill': s, 'id': case['id'], 'run': meta['run'], 'stem': stem, **rec}
                json.dump(rec, open(f'{o}/{stem}.checks.json', 'w'), indent=1)
                saved = json.load(open(f'{d}/{stem}.checks.json'))
                if rec == saved: same += 1; continue
                diff += 1
                key = lambda x: json.dumps(x, sort_keys=True)
                old = {key(c) for c in saved.get('checks', [])}; new = {key(c) for c in rec.get('checks', [])}
                for c in old - new: changed[(m, a, s, json.loads(c)['check'], 'removed', json.loads(c)['verdict'])] += 1
                for c in new - old: changed[(m, a, s, json.loads(c)['check'], 'added', json.loads(c)['verdict'])] += 1
                others = [k for k in rec if k != 'checks' and rec.get(k) != saved.get(k)]
                if others: ex.append((m, a, stem, others))
print('runs identical:', same, 'changed:', diff)
for k, v in sorted(changed.items()): print('  ', k, v)
print('non-finding fields changed:', ex[:5])
