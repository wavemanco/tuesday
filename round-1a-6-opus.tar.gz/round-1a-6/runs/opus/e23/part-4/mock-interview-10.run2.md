I can help you prep, but first: **that Telegram message looks like a recruitment scam.** Please check it before you reply.

## Why it's suspicious

- **The whole process happens on Telegram.** Real software companies interview on video or phone and send offers by email from their company domain. Job scams almost always move to Telegram or WhatsApp.
- **The interview is a text chat.** Anyone can type as a "support team lead." It also means nobody ever has to show their face or voice.
- **The offer and onboarding happen in the chat.** This is usually where the scam starts. "Onboarding" often turns into a request for your ID, bank details or tax form, or a "check" you're asked to deposit to buy equipment, with you sending some money back.
- **They found you on Telegram,** but you applied through a careers page. Ask yourself how they got your Telegram handle.
- **Scammers really do pull names from job boards.** Using your name and the right job title doesn't prove the message is real.

## How to check it

1. **Don't reply on Telegram, and don't click any links in it.**
2. Find Lumenvale's contact details yourself, from their official website and not from the message. Email their careers or HR address and ask: "I received an interview invitation from someone named Marcus Hale via Telegram. Can you confirm this is legitimate?"
3. Check whether a Marcus Hale works on their talent team, for example on LinkedIn, and contact him there or by company email.
4. Look at your application portal or email for any message from Lumenvale's own domain.
5. Never send ID documents, bank details or money, and never buy equipment, before you've had a real interview and a written offer from a company email address.
6. If it turns out to be fake, report the account in Telegram and tell Lumenvale. They'll want to know someone is pretending to be them.

## Prep for the real interview

Your background fits the job ad well, so this prep will be useful whenever the real interview comes:

| They asked for | What you can point to | How to talk about it |
|---|---|---|
| 2+ years in customer support | 3 years as a customer service advisor at an energy supplier | You have more than they asked for. Lead with it. |
| Zendesk or a similar ticketing tool | You use Freshdesk every day | It's the same kind of tool. Say you'd pick up Zendesk quickly and name the parts you use (queues, macros, tags, SLAs). Only mention the parts you really use. |
| Clear written communication | About 60 calls and emails a day | Prepare one example of an email to an unhappy customer that worked well. |
| Confidence handling escalations | Not shown yet | **Have a real story ready.** Think of a time an upset customer pushed back on a refund or billing issue and how you handled it. |
| Training others (a bonus) | You trained four new starters on the refunds process | This is a strong point. Use it when they ask about teamwork or ownership. |

**The question to practice most:** "You've never worked at a software company. Why should we hire you?" A good answer: support is support. You've handled high volume, billing disputes and process training somewhere that customers get stressed about money. Then show you're learning the product side, for example by reading Lumenvale's help docs before the interview.

**Other likely questions:**
- "Tell me about a time you handled an angry customer."
- "How do you prioritise when the queue is full?"
- "Tell me about a time you didn't know the answer."
- "Why Lumenvale?" Read their website first.

**Questions you could ask them:**
- "What do your most common tickets look like?"
- "How are escalations handed off to engineering?"
- "How do you measure success in this role in the first 90 days?"

Once Lumenvale confirms the interview through an official channel, I can turn this into a full practice pack and run a live mock interview with you.