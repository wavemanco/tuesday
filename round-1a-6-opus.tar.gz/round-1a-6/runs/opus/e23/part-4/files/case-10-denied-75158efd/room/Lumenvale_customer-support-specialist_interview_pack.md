# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

**Interviewer:** the support team lead (name not given), in a text chat, as described in the invitation from Marcus Hale, talent team.
**Built on:** your summary of the job ad and the four facts about yourself in your message. Web research was not available in this session (see Sources).

---

## How to use this pack

- **Personas** describe *how* a question is asked (friendly, sceptical, under pressure). **Types** describe *what* is being scored.
- **Type key:**
  - **VAL**: values and behaviour (how you act, shown through past examples)
  - **EXP**: a deep dive on your experience (what you actually did)
  - **JD**: the job ad's stated requirements
  - **CO**: knowledge of the company and its strategy
  - **CASE**: a live problem from the role, solved in the moment
- **Provenance labels:**
  - **[grounded]**: traceable to your message or the job ad as you summarised it
  - **[inferred]**: a reasonable derivation, with the reasoning named
  - **[generic]**: a common pattern for support roles, with no claim about Lumenvale
- **This is a text interview.** Your written replies *are* the work sample for "clear written communication". Keep each reply to a few short paragraphs, don't send walls of text, and re-read before you hit send.
- **Answer slots:** an answer slot marks a point where only you know the answer. Answer it from your own experience. If you have nothing for it, say so plainly.
- Guidance is scaffolding, not a script. Put it in your own words.
- Question IDs go A–E, then G. There is no F bank, so that question IDs can't be confused with fit-snapshot rows (F1–F6).

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as you summarised it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap: three years against the two asked for. Expect a probe on what those days looked like. Use the quote's own terms: three years, an energy supplier, around 60 calls and emails a day, all of them combined |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as you summarised it | "I use Freshdesk every day" — your message | medium | [grounded] | none | No gap. The ad itself allows "or a similar ticketing tool". Your words: "I use Freshdesk every day." Never let it slide into Zendesk experience |
| F3 | "clear written communication" — job ad, as you summarised it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote shows that emails are part of the volume. It doesn't show how big a part, or what the writing involves. Answer slot: the ad's written-communication line makes a probe on your written work likely. If email or written replies are a regular part of your day, say what kind, in your own words. If most of your volume is calls, say so plainly and stay with what the quote carries. In this interview, the chat itself is your strongest evidence |
| F4 | "confidence handling escalations" — job ad, as you summarised it | none given | none | [grounded] | discovery | Your material doesn't show escalations either way. Answer slot: if you have handled a customer who escalated, or passed on or received an escalated case, pick one and say what you did, in your own words. If not, say so plainly and describe how you would handle one |
| F5 | Familiarity with a software product and its customers, which is typical of support roles at software companies | "I've never worked for a software company" — your message | none | [generic] | capability | You have stated this gap, and wording can't close it. Your words: "I haven't worked for a software company." Then describe how you would learn the product, said as a plan and never as past experience. Add nothing to make the gap sound smaller |
| F6 | Sharing process knowledge with colleagues, which is common in support teams | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | No gap. Use the quote's own terms: four new starters, the refunds process, last year |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| 2+ years in customer support (F1) | C1, C2, D1 |
| Zendesk or a similar ticketing tool (F2) | A5, B2 |
| Clear written communication (F3) | A1, C3, plus every reply you type |
| Confidence handling escalations (F4) | A2, B3 |
| Software-product familiarity (F5, generic) | B1, A4, E1 |

---

## Persona table

The weights below rest on one loop source: the invitation's own description of a single text-chat interview with the support team lead. A team lead is usually the person who would manage you, so the hiring-manager prior applies. If they turn out to be a peer, the weights change (see the upgrade menu).

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "A customer writes in saying…, what do you reply?" Live ticket scenarios typed out in the chat | **High.** A team lead hiring for their own queue is buying the ability to handle tickets, and a text chat makes it easy to hand you one | Clarify, then decide what the customer needs, then act, then follow up. Type it in plain, short paragraphs, as you would to a real customer |
| Skeptic | Quiet probes on the gap: no software company, Freshdesk rather than Zendesk | **High.** F5 is the most visible gap between your background and a software company | Say the gap plainly, stay with what you did (F1, F2, F6), then give a concrete plan for learning the product |
| Conversational | "Tell me about yourself", "what's a normal day like?" | **Medium.** Most chats open this way. The casual register is still scored, and here it is scored on your writing | A pre-written short arc built only on F1, F2 and F6 |
| Data-Driven Prober | "Around 60 a day: what's the split?" "What did training four people involve?" | **Medium.** Your two numbers are the obvious things to probe | Know what you can and can't say about how each number was counted, and say "around" when it's around |
| Pressure | "In two lines, why you over someone with software support experience?" | **Low to medium.** A text chat makes time-boxing awkward, but short-answer challenges still happen | Pause, then hold on what you did and concede the software gap plainly |
| Values / Behavioural | "Tell me about a time you put a customer first…" | **Low.** No values round is documented, and Lumenvale's published values weren't available to this pack | Choose a real story using the selection scaffold. If none comes to mind, say so |
| Peer Evaluator | Not included | **Not plausible for this session.** The interviewer is the team lead, not a peer | If the relationship turns out to be peer, see the upgrade menu |

---

## Question banks

### A — Case / Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in, angry: they've been charged twice and want a refund today. Type your first reply to them." | CASE, JD | [generic] | Write the actual reply in the chat. Acknowledge the problem in one line, without blame. Say what you will do next, and what you need from them, if anything. Give only a timeline you could really promise. End with when they'll hear from you. Keep it short enough to read on a phone. The question asks nothing about your past, so the guidance makes no claim about it | A text-chat interview is the cheapest place to test the ad's written-communication line live. CASE delivery, JD content |
| A2 | "After your second reply, the customer says 'I want to speak to a manager.' What do you do?" | CASE, JD | [generic] | Structure it: acknowledge the request rather than resist it, check whether there's one thing you can still resolve right now, then follow the escalation route. Hand over with a clear summary so the customer doesn't have to repeat themselves, and tell the customer what happens next. Don't say how you've done this before unless you have, which is B3's territory | Tests the ad's escalations line as a decision rather than a record, which matters because F4 has no evidence yet |
| A3 | "You've got 40 tickets in the queue. Three are marked urgent, and one is from a customer threatening to cancel. How do you prioritise?" | CASE | [generic] | Clarify first: what does "urgent" mean in this team's queue? Then give your order and the reason for it: impact on the customer, risk, time-sensitivity. Say what you'd send the waiting customers so they aren't left in silence. Say when you'd flag the load to your lead | Queue judgement is core to the job, and team leads ask about it. CASE because it is reasoning on a live problem |
| A4 | "A customer reports a bug you can't reproduce. How do you handle it, with them and internally?" | CASE | [generic] | Thank them, then ask for the specifics you'd need (what they did, what they saw, when). Tell them honestly what happens next. Pass it on internally with everything you gathered, then follow up with the customer either way. Don't claim technical experience you haven't stated (see F5) | Bug reports are typical of software support, so this is where F5's gap meets a real task. `[generic]` because it describes the pattern, not Lumenvale's process |
| A5 | "How would you use a ticketing tool to stop a multi-day issue falling through the cracks?" | JD, CASE | [grounded] "I use Freshdesk every day" | Speak from the tool you use: "I use Freshdesk every day." Answer slot: the ad's ticketing-tool line makes a probe on how you use it likely. If you track ongoing issues in Freshdesk, say how, in your own words. If your work there doesn't involve multi-day issues, say so plainly and describe how you would do it | Turns F2 into something the team lead can picture. JD because it scores the tool requirement |

### B — Skeptic (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked at a software company. Why should we expect you to support customers on a product you don't know?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day" | **The highest-ROI rehearsal in this pack.** Concede first, plainly: "I haven't worked for a software company." Then hold only what your quotes carry: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day, and using Freshdesk every day. Then give a plan, said as a plan: how you would learn the product in your first weeks (for example, using it yourself, reading the help documentation, reading resolved tickets, asking the team). If they push twice, return to the same two facts and the plan. Don't add technical claims to soften the gap | F5 is the most visible gap between your background and this employer, so some version of this question is close to certain. JD content, asked in the Skeptic's register |
| B2 | "The ad mentioned Zendesk. You've used Freshdesk. How long until you're up to speed?" | JD | [grounded] "I use Freshdesk every day" | "I use Freshdesk every day." Leave it there: never say or imply you've used Zendesk. How quickly you'd get up to speed is a plan, not a past fact, so give your honest estimate and how you'd get there | F2's quote already meets the requirement, but the tool name invites a probe. Rehearsing it stops the answer stretching into a claim |
| B3 | "Tell me about a time you handled an escalation." | JD, EXP | [grounded] | Selection scaffold: pick a time a customer's issue went beyond a normal reply, whether they asked for someone senior, or you passed the case up, or you took one over. It needs what the customer wanted, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or walk through how you would handle one (see A2) | F4 has no evidence yet, and the ad names escalations directly. This is the slot where an invented story is most tempting |
| B4 | "Why move from energy to software support, and why us?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Start from where you are: three years as a customer service advisor at an energy supplier. Answer slot: the reasons for the move are yours, so give them in your own words. For "why us", say only what you actually know about Lumenvale; this pack couldn't research them. If what drew you was the role as advertised, say that | Motivation consistency is what the Skeptic scores. The "why us" half is thin until research or the full ad is available (see the upgrade menu) |

### C — Conversational (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me a bit about yourself and your current role." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | Pre-write three or four sentences built only on these: three years as an advisor at an energy supplier, around 60 calls and emails a day, Freshdesk every day, and training four new starters on the refunds process last year. Finish with one line on why this role, in your own words | The opening question almost always comes. In text, a tight first reply sets the tone for the whole chat |
| C2 | "What does a typical day look like for you?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day" | Around 60 calls and emails a day, worked in Freshdesk every day. Answer slot: the kind of contacts you handle is yours to describe, in your own words. Keep "around" | A casual question that is still scored for clarity, and the easiest place to inflate a number by accident |
| C3 | "How do you get your tone right in writing when a customer is upset?" | JD | [inferred] "answering around 60 calls and emails a day" | The quote shows that emails are part of your volume. Answer slot: if you write to upset customers regularly, say how you approach it, in your own words. If most of that happens on calls, say so plainly and describe how you would carry the same approach into writing. Then show it: the reply itself should read calmly | F3's thin bridge, rehearsed so the honest answer is ready. `[inferred]` because the quote touches the requirement without showing it |

### D — Data-Driven Prober (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around 60 calls and emails a day. What's the split, and how do you know?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Keep it as one combined figure and keep "around". Answer slots, in your own words: how the number is counted (a system report, or your own estimate); what makes it go up or down; the part of it you'd defend least; and that these contacts are yours. If you don't know how it's counted, say so: "it's my own estimate" is an honest answer | The only headline number in your background, so it gets the defend-the-number rehearsal |
| D2 | "You trained four new starters on refunds. What did that involve, and what told you whether it had landed?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Use the beats the quote states: four new starters, the refunds process, last year. Answer slot: what the training consisted of is yours to describe, in your own words. If something showed you whether it worked, say what. If nothing did, say so plainly and stay with the training itself | F6 is your strongest evidence beyond the basic requirements, and probers ask what sits behind a line like this |
| D3 | "Are you measured on anything in your current role, and how have you done?" | EXP | [generic] | Answer slot: if your work is measured, say on what and how you've done, in your own words, with a figure only if you know it. If it isn't, or you don't know your numbers, say so plainly and return to the work itself | A common probe in support interviews. `[generic]` because none of your sentences mentions a metric |

### E — Pressure (low to medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "In two lines: why you over someone who's already done software support?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day" | Hold, then concede. Hold on what you did: three years, around 60 calls and emails a day, Freshdesk every day. Concede the gap in one clause: "I haven't worked for a software company." If they push, hold the same ground once more before saying anything else. Don't fold, and don't inflate | B1 in a compressed, high-pressure form. Rehearsing both stops the short version from coming out defensive |
| E2 | "That training: how much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Your sentence says you trained them, so hold on that. Answer slot: if others shared the training or wrote the materials, say what was yours and what wasn't, in your own words. Being precise here earns credibility | An attribution check on F6. Pressure stems like this exist to test honesty |

### G — Values / Behavioural (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When did you put a customer ahead of an internal target?" | VAL | [generic] | Selection scaffold: pick a real time you chose what was right for a customer over speed, volume or a script. It needs the customer's situation, the choice you made, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it | Lumenvale's published values weren't available, so this uses a generic persona stem. It becomes a VAL question mapped to their values once research runs |
| G2 | "Tell me about a time you told a manager something they didn't want to hear." | VAL | [generic] | Selection scaffold: a time you raised a problem upward, such as a process issue or a customer pattern. It needs what you said, how you said it, and how the relationship held. If none comes to mind, say so plainly and describe how you would raise one | Team leads value people who flag problems early. A generic stem, low weight |

---

## Reverse questions

| Question | Why it lands |
|---|---|
| "Which ticketing tool does the team use day to day, and what does onboarding on it look like?" | It ties back to F2 and shows you're already thinking about ramp-up |
| "What does the escalation path look like here, from a specialist to you and beyond?" | It shows you take the ad's escalations line seriously, and the answer helps you with A2 |
| "What do new specialists find hardest about the product in their first month?" | It faces F5 head-on and turns the gap into a learning conversation |
| "How do support and the product or engineering team work together on bug reports?" | It shows you understand software support is a loop, not just replies (A4) |
| "How is quality measured for support specialists on your team?" | It tells you what you'd be scored on, and it reads as accountable |
| "Could you send the role details and the next steps by email from your company address, and will there be a video or voice call at any stage?" | A reasonable process question for a fully remote role. It also gives you something you can check independently |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The ad's "or similar" does the rest |
| Answers around 60 emails a day | Inflated form of F1: the number moved from "calls and emails" to emails alone | F1's quote at its own scope: around 60 calls and emails a day, combined |
| Ran or designed a training or onboarding programme | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year." D2's slot stays inside that training |
| Has software, SaaS or technical support experience | A negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't worked for a software company." Then a plan, said as a plan. No slot |

Escalations (F4) and the email share of your volume (F3) aren't on this list. Your material says nothing about them either way, so they are answer slots, not claims to avoid.

---

## Sources

- **Provided:** your message (the job ad's requirements as you summarised them, your four facts about yourself, and the text of the Telegram invitation).
- **Searches sent:**
  - `Lumenvale Software`: refused (search permission not granted in this session)
  - `job scam interview conducted on Telegram text chat offer onboarding`: refused (search permission not granted in this session)
- **Fetches:** none.

Research tier: L1 — searches 2 of 6 (both refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Search wasn't permitted in this session. It would have given VAL questions mapped to Lumenvale's own values, and possibly a values cheat sheet |
| 2. `Lumenvale Software interview process customer support` | unavailable | Search wasn't permitted. It would have checked the described process against any documented one and adjusted the persona weights |
| 3. `Lumenvale Software` strategy and recent news | unavailable | The one call sent was refused. It would have given CO questions about Lumenvale's product and customers, and a real answer for B4's "why us" |
| 4. Interviewer name + Lumenvale | n/a | The team lead wasn't named, so no query could be formed. There is no interviewer read |
| 5. Representative Customer Support Specialist JD | skipped | Your summary of the ad's four requirements already fixes the fit snapshot and the JD-tagged questions |
| Search outside the declared targets: Telegram-only hiring process | unavailable | Refused. It would have informed nothing in the pack itself; it was a check on the invitation |

---

## Upgrade menu

- **The full job-ad text, pasted** → F1–F4 quote the ad itself rather than your summary, and any requirements further down the ad get their own questions
- **Permission to search the web** → Lumenvale's values, its documented interview process and recent news. That adds CO questions, a real "why us" for B4, and possibly a values cheat sheet
- **The team lead's name** → a short read of their public professional background, persona weights tuned to it, and a reverse question tied to their path
- **Whether the team lead would be your manager or a peer** → the weights are recomputed, and a peer bank is added if needed
- **Your own answers to the F3 and F4 slots** (how much of your day is written, and any escalation you've handled), told to me outside a drill → F3, F4, B3 and C3 are rebuilt on your real examples
- **How much prep time you have** → a prioritised prep schedule
- **A tuesday-dossier.md from an earlier fit review, if you have one** → verified evidence and an evidence-based main objection, in place of the one this pack inferred
