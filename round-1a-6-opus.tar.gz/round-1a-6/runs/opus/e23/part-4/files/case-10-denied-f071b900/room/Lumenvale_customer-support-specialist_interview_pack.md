# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

**Round:** a text-chat interview with the support team lead, as the invitation describes it. That makes the team lead your likely future manager. The pack treats this as a hiring-manager round held in writing.
**Before you prepare:** the invitation came on Telegram and says the interview, offer and onboarding all happen in that chat. Check that it really comes from Lumenvale before you share anything personal (see the message this pack came with).

---

## How to use this pack

- **Personas** describe how a question gets asked. **Types** describe what is being scored.
- **Type key:** `VAL` checks whether your behaviour fits the company's values. `EXP` checks whether your past experience holds up under questioning. `JD` tests the job ad's requirements directly. `CO` tests what you know about the company. `CASE` is a live problem you work through on the spot.
- **Provenance:** `[grounded]` means it comes from what you told me. `[inferred]` means I derived it from your words. `[generic]` means it's a common pattern for this kind of role, with no claim about you or Lumenvale.
- **This interview is written, so every answer is also a writing sample.** "Clear written communication" is scored the whole time, not only in the questions about it. Use short paragraphs, answer the question first, then add detail.
- The guidance is scaffolding, not a script. Put it in your own words.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as quoted in your message | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap. Lead with the plain fact: three years as a customer service advisor at an energy supplier. Nothing has been checked behind it yet, so expect follow-up questions on what a day looked like |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as quoted in your message | "I use Freshdesk every day" — your message | medium | [grounded] | none | Freshdesk is a ticketing tool, so this meets "or a similar" as written. Say it as you said it: "I use Freshdesk every day." Answer slot: the ad names Zendesk, so you may be asked about it directly. If you have used Zendesk, say where. If you haven't, say so plainly and stay with Freshdesk |
| F3 | "clear written communication" — job ad, as quoted in your message | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails are written work, but your material doesn't show whether anyone ever judged them clear. Answer slot: if anything reviewed or measured your written replies, say what, in your own words. If nothing did, say so plainly and let the way you write in this chat show it |
| F4 | "confidence handling escalations" — job ad, as quoted in your message | none given | none | [grounded] | discovery | Your material says nothing about escalations either way. Answer slot: the ad names escalations, so expect a direct question. If you have handled them, describe one real case, what you did and what was yours to decide. If escalations went to someone else, say so plainly and explain what you did before handing over |
| F5 | Familiarity with software products. Not in the ad as you quoted it, but it's implied by the employer | "I've never worked for a software company" — your message | none | [grounded] | capability | No wording closes this gap, and you have already said so. Words: "I haven't worked for a software company." Then describe how you would learn the product, said as a plan and never as something you've done. Never claim software support experience, and add nothing to make the gap look smaller |

You also gave me this, which is useful evidence but doesn't map to a listed requirement: "I trained four new starters on our refunds process last year" — your message. It appears in D2, E2 and the reverse questions.

---

## Persona weights

No company source describes the interview. The invitation names one session, a text chat with the support team lead. Weights start from the hiring-manager pattern.

| Persona | How it shows up in a text chat | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Calm, persistent questions about the energy-to-software move and the tools you haven't used | High. F5 is the obvious gap, and a team lead hiring someone without software experience has to test it | Rehearse A1 until it's boring. State the limit before they find it, then give a concrete plan to learn |
| Case / Strategist | "Here's a ticket, what do you do?" Written scenarios, possibly asking you to draft a reply | High. A support team lead is buying someone who can handle tickets, and a text format makes it easy to ask for a draft reply | Clarify, then structure, then answer. In writing: acknowledge, state what you'll do, set an expectation |
| Conversational | Friendly openers: "tell me about yourself", "why us" | Medium. Usual in any first interview, and still scored | Write a short background answer ahead of time (C1). Treat casual questions as scored |
| Data-Driven Prober | Asks about "around 60 a day", the four starters, how you know you're good | Medium. Your only figures are the ones a lead will check | Know what you can and can't say about each number, and say "around" when you mean around |
| Pressure | "Why you over someone with SaaS experience?" | Low to medium. Less common in support hiring, but the F5 gap invites it | Pause, restate, hold on what you actually did, and concede the software gap cleanly without folding on your support record |
| Values / Behavioural | "Tell me about a time…" questions | Low to medium. No published Lumenvale values were available to me, so expect generic behavioural questions | Pick real instances. If none comes to mind, say so and give the nearest real example |
| Peer | Questions about teamwork, handovers, asking for help | Low. One interviewer, but a lead cares how you fit the team | Show what you'd bring to the team, not only what you'd need from it |

---

## Question banks

IDs: A Skeptic, B Case, C Conversational, D Prober, E Pressure, G Values, H Peer. The F IDs are the fit-snapshot rows.

**Highest-ROI prep in this pack: A1.** Some version of "you've never worked in software" will come up. A calm, prepared answer changes how the rest of the interview goes.

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I don't see software in your background. How would you handle supporting a product you don't know yet?" | JD | [grounded] "I've never worked for a software company" "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | The deepest rehearsal in the pack. 1) Name the limit before they press: "I haven't worked for a software company." 2) Say what you have done at its real size: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day. 3) Give a plan for learning the product, phrased in the future tense ("I would…"), never as a past habit. Hold through two follow-ups by going back to the support work you did, never by adding software experience. If pushed, the concession stays the same and is specific: you'd need time to learn the product | F5 is the biggest gap and you stated it yourself. JD because it tests whether you can do the listed job for this kind of employer |
| A2 | "Why move from energy to software?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Give your real reason in your own words. Keep it pointed forward, toward what draws you to this role, not away from your current job. Mention the three years at the energy supplier once, as context. Don't make up an interest in tech you don't have | Motivation consistency is the Skeptic's main test, and F5 makes this question very likely |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Pick a real weakness, not a disguised strength. F5 is the honest and obvious candidate: "I haven't worked for a software company, so learning the product would come first." Then the learning plan from A1. One weakness, said cleanly, is enough | A standard Skeptic stem. Answering it with F5 shows self-awareness instead of leaving them to find the gap |
| A4 | "Have you used Zendesk?" | JD | [grounded] "I use Freshdesk every day" | Words: "I use Freshdesk every day." Answer slot: if you have used Zendesk, say where and how much. If you haven't, say so plainly and stay with Freshdesk. Don't claim the two tools are the same; you haven't told me how they compare | The ad names Zendesk, so it may be asked as a yes-or-no question. F2 already meets "or a similar", so honesty costs you nothing here |

### B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer says a bug cost them a day's work. They're angry and want a manager. What do you do?" | CASE | [generic] | Structure: acknowledge the impact in plain words; get the facts (what happened, when, account details); say what you can do now and what you're passing on; escalate with a clear summary so the customer doesn't have to repeat themselves; give a timeframe and follow up. Make clear when you escalate and why, not as a way to get rid of the customer. The question asks nothing about your past, so the guidance claims nothing | The ad names escalations (F4's requirement). Asked as a live problem, it scores judgment rather than history |
| B2 | "Write me the reply you'd send a customer whose refund request we can't approve." | CASE | [generic] | Actually write it, in the chat. Shape: thanks plus acknowledgment; the decision stated clearly in the first few lines; the reason in one or two plain sentences; what they can do instead; how to come back to you. No jargon, no hiding the "no" | In a text interview, a request to draft a reply is very likely. It tests F3's requirement directly. `[generic]` because Lumenvale's refund policy is unknown |
| B3 | "You come back from a system outage to 40 open tickets. How do you prioritise?" | CASE | [generic] | Clarify first: are there SLAs or priority tags? Then sort by impact and urgency; group duplicates about the same issue; send a holding reply to the affected customers; flag anything that looks like a new problem. State your assumptions out loud | Prioritising a queue is the core of a ticketing role (F2's requirement). It tests structure, not tool knowledge |
| B4 | "A customer reports a problem you can't reproduce, and you're still new to the product. What do you do?" | CASE | [generic] | Ask for steps, screenshots, device or browser, and the time it happened; check internal docs and known issues; tell the customer honestly what happens next; ask a colleague or escalate with everything you've gathered. Being new is a reason to gather more detail, not to guess | The F5 gap turned into a scenario. A good answer shows how you would close the gap in practice |
| B5 | "When should support solve a ticket, and when should it go to engineering?" | CASE | [generic] | Give a principle, not a guess at their process: solve what's covered by known answers and settings; escalate suspected bugs, data problems or anything you can't explain, with reproduction details. Then ask how they draw the line. That's a fair question back | Tests understanding of software-support handoffs. Asking how they do it avoids pretending to know their setup |

### C — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about yourself." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" "I use Freshdesk every day" "I trained four new starters on our refunds process last year" | Write it ahead of time, about 80 to 120 words: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day; you use Freshdesk every day; last year you trained four new starters on the refunds process; why this role is next. Each clause stays at the size you told me | Almost certain to come up. In writing, a tight answer is itself evidence for F3's requirement |
| C2 | "What does a typical day look like for you now?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Start with the volume: around 60 calls and emails a day. Then describe the shape of the day in your own words. Keep "around" if that's what it is | Gets at F1 and invites a follow-up on the number (D1) |
| C3 | "Why Lumenvale?" | CO | [generic] | Say only what you actually know: what you read in the ad and on their careers page. If you know little about the product, say what draws you to the role and that you want to learn the product. Never invent facts about the company. Read their website before the interview so you have something real to say | Research didn't run, so I have no company facts to give you. `[generic]` until you add some |

### D — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Around 60 a day. How's that split between calls and emails?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot, in your own words: how you know the figure (a report, your own estimate, a rough average), what makes it vary (season, billing cycles, outages, whatever is actually true), and that the contacts were yours. If you don't know the split, say "I'd estimate…" or "I don't have the exact split". Don't make up a precise ratio | Your one figure is the one a Prober tests. Knowing how far it goes is worth more than the number itself |
| D2 | "Tell me about training those four new starters." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Story beats from your own sentence: four new starters, the refunds process, last year, and you trained them. Tell how in your own words. Don't call it leading a team or designing the process; you told me you trained people on an existing process | Your only evidence beyond volume. A lead will want to know what you did. It also connects to written clarity and knowing a process well |
| D3 | "How do you know your written replies are clear?" | JD | [inferred] "answering around 60 calls and emails a day" | Answer slot: the ad asks for clear written communication. If anything reviewed or measured your emails, say what, in your own words. If nothing did, say so plainly and describe how you check a reply before sending it. Then let your chat answers show it | F3 is thin. This rehearses an honest answer before the question arrives |

### E — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's already done SaaS support?" | JD | [grounded] "I've never worked for a software company" "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" "I use Freshdesk every day" | Pause, then hold your position: three years in customer service at around 60 calls and emails a day, and you use Freshdesk every day. Concede cleanly and specifically: "I haven't worked for a software company, so I'd be learning the product." Hold through two follow-ups. Don't fold on your support record, and don't claim software knowledge | A pressure version of A1. Rehearsing the hold-then-concede shape matters more than the exact words |
| E2 | "The training: how much of that was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold on your sentence: you trained four new starters on the refunds process. Answer slot: if others shared the training or wrote the materials, say who did what; if it was all yours, say so plainly. Keep "we" for context and "I" for what was yours | A standard attribution probe on your strongest non-volume claim |

### G — Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you handled an escalation." | JD | [grounded] | Choosing a story: you need a real case with an upset customer, something you did, and an outcome you can describe honestly. Short form: situation, what you did, what happened. If no such time comes to mind, say so plainly, then give the nearest real example from your support work, or how you'd handle one (B1) | F4 has no evidence yet, so this is a scaffold, not a mapped story. Expect it, since the ad names escalations. `[grounded]` on the ad's requirement, with no claim about you |
| G2 | "When did you put a customer ahead of an internal metric or process?" | VAL | [generic] | Choosing a story: a real customer, a real target or rule, a choice you made, and an outcome. If no such time comes to mind, say so plainly, then give the nearest thing you can stand behind | A common behavioural question. Lumenvale's values were not available to me |

### H — Peer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "When you're stuck on a ticket, how do you get help?" | CASE | [generic] | Principle: try what you can first, then ask with the context already gathered so a colleague can help quickly, and record the answer so the next person doesn't have to ask. Describe your actual habit in your own words if you have one | A lead cares whether a new hire adds load or removes it, especially one still learning the product (F5) |
| H2 | "How would you hand a ticket over to a colleague?" | CASE | [generic] | Summary of the issue, what's been tried, what the customer has been told, the next step, and any deadline. The customer should never have to repeat themselves | Remote teams depend on written handovers, so this tests F3's requirement in a team setting |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| 2+ years in customer support (F1) | C1, C2, D1 |
| Zendesk or similar ticketing tool (F2) | A4, B3 |
| Clear written communication (F3) | B2, D3, H2, and every written answer |
| Confidence handling escalations (F4) | B1, G1, B5 |
| Software context (F5, implied) | A1, A3, B4, E1 |

---

## Reverse questions

| Question | Why it lands |
|---|---|
| "How long does it usually take a new specialist to feel confident with the product, and what does onboarding look like?" | Takes on F5 directly and shows you're planning how to learn |
| "What kinds of tickets make up most of the queue, and which ones get escalated most?" | Shows you think about the real work, and tells you where the escalations come from |
| "How do support and engineering work together when a bug comes in?" | Shows you understand software support. The answer covers B5 for real |
| "How is quality measured on the team, and how do new people get feedback on their replies?" | Shows you care about written quality (F3) and want to improve |
| "What would a strong first month look like for someone in this role?" | Shows you're thinking about contributing, and gives you a target |
| "What's the next step after this conversation, and who else would I meet?" | Practical. If the answer is "nothing, the offer comes in this chat", treat that as a warning sign |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Software or SaaS support experience | A negative you stated, F5 | "I haven't worked for a software company." No slot |
| Zendesk experience | An inflated form of F2. You named Freshdesk, not Zendesk | F2's quote at its own scope: "I use Freshdesk every day." A4's slot asks only whether you have used Zendesk |
| Led a team, managed new starters, or designed the refunds process | An inflated form of the training quote | That quote at its own scope: you trained four new starters on the refunds process last year. E2's slot asks only what part was yours |
| A precise calls-versus-emails split or other performance figures | An inflated form of F1's "around 60" | "Around 60 calls and emails a day." D1's slot keeps it an estimate unless you know more |

---

## Sources

- Provided: your message (your background and the job-ad requirements as you summarised them) and the Telegram invitation text you pasted.
- Search "Lumenvale Software values": refused (search permission not granted).
- Search "Lumenvale Software interview process customer support": refused.
- Search "job offer interview conducted entirely on Telegram recruitment scam warning": refused.

Research tier: L1. Searches: 3 of 6 sent, all refused. Fetches: 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | Would have provided named values and a values cheat sheet. G2 stays `[generic]` |
| 2. Lumenvale Software interview process | unavailable | Would have confirmed or contradicted the Telegram-only process, which matters for both the weights and the legitimacy check |
| 3. Lumenvale strategy or recent news | unavailable | No call sent after the first refusals. Would have given C3 and a CO question real content |
| 4. Interviewer name | n/a | The team lead is unnamed. Marcus Hale is the talent contact, not the interviewer |
| 5. Representative JD | skipped | You supplied the ad's requirements |
| Telegram recruitment-scam pattern (outside the declared targets) | unavailable | Refused. The legitimacy advice in the covering message comes from general knowledge, not a fetched source |

---

## Upgrade menu

- Full job-ad text → the snapshot quotes the ad itself, and any requirements I'm missing get questions
- Allow web search → Lumenvale's values, interview process and product: C3 becomes grounded, a values cheat sheet, and a real check on whether Telegram-only hiring is how they operate
- Deeper research, up to 6 more searches and 2 more fetches, several more minutes → product and strategy questions instead of generic ones
- An escalation you've actually handled, in your own words → F4, B1 and G1 become story-mapped instead of scaffolds
- Any feedback or QA on your written replies → F3 and D3 become grounded
- Whether you've ever used Zendesk → A4 closes
- The team lead's name → a tailored reverse question and weights based on their public profile
- A dossier of your verified evidence → the main objection comes from evidence rather than my inference, and claims you've ruled out are held as limits
