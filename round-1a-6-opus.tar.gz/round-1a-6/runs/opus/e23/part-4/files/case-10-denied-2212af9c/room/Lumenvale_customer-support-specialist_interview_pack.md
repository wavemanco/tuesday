# Interview prep pack — Customer Support Specialist, Lumenvale Software

**Round:** one text-chat interview with the "support team lead" (the invite's words). No interviewer name. This pack assumes the team lead is your likely future manager.
**Format note:** a text-chat interview tests the ad's "clear written communication" in every message you send. Write each answer the way you would write to a customer: short paragraphs, a clear first line, no walls of text.

---

## How to use this pack

- **Personas** describe *how* a question arrives: who is asking and in what style. **Types** describe *what* is being scored.
- Type key:
  - **VAL**: behavioural or values. Does past behaviour show what they care about?
  - **EXP**: experience deep-dive. Does your account of your work hold up when they dig?
  - **JD**: role-driven. Can you do the job in the ad, gaps included?
  - **CO**: company knowledge. Have you done your homework on them?
  - **CASE**: live problem. How you structure and reason through a support scenario.
- **Provenance labels:** a [grounded] row rests on your own words or the ad as you relayed it. An [inferred] row is this pack's own reasoning. A [generic] row is a standard pattern for the role, not a fact about Lumenvale.
- The guidance is scaffolding, not a script. Rehearse the beats, then answer in your own words.
- Question IDs skip the letter F so they don't clash with the fit-snapshot rows (F1–F6).

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the job ad, as relayed in your message | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap: you have three years against the two asked for. Say it in the quote's own terms: three years as a customer service advisor at an energy supplier |
| F2 | "experience with Zendesk or a similar ticketing tool" — the job ad, as relayed in your message | "I use Freshdesk every day" — your message | medium | [grounded] | none | The ad's "or a similar" covers this. Name the tool and the frequency, "I use Freshdesk every day", and never let it drift into a claim that you've used Zendesk |
| F3 | "clear written communication" — the job ad, as relayed in your message | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails are written work, but the quote shows volume, not how clear the writing is, and calls are not written at all. In a text-chat interview your replies are the evidence. Answer slot: if you have something that shows the quality of your written replies, say what it shows, in your own words. If you don't, say so plainly and let your answers in the chat do the work |
| F4 | "confidence handling escalations" — the job ad, as relayed in your message | none given | none | [grounded] | discovery | Your material doesn't show escalations either way. Answer slot: the ad names escalations, so expect a probe. If you've dealt with customers who escalated, or passed cases up, say what happened and what part was yours, in your own words. If not, say so plainly and walk through how you would handle one |
| F5 | Supporting a software product (implied by the employer, "Lumenvale Software", in the recruiter's message) | "I've never worked for a software company" — your message | none | [grounded] | capability | You've stated this gap, and wording can't close it. Words: "I haven't worked for a software company." Then say how you would learn the product, as a plan and never as a past. Don't add anything to make the gap feel smaller |
| F6 | Sharing process knowledge with teammates (role-family, not in the ad) | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | Not asked for in the ad, but useful for a team. Keep it at the quote's scope: four new starters, the refunds process, last year |

**Requirement coverage**

| Requirement | Covered by |
|---|---|
| 2+ years in customer support (F1) | C1, E1 |
| Zendesk or similar ticketing tool (F2) | B2, A3 |
| Clear written communication (F3) | C3, A1, G2, plus every reply you send in the chat |
| Confidence handling escalations (F4) | A4, D1, G1, H1 |
| Software-company context (F5, implied) | B1, B4, A5 |

---

## Persona table

| Persona | How it shows up in a text chat | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "A customer writes in saying… what do you do?" They may ask you to draft the actual reply | Highest. A team lead hiring for their own queue is buying capability, and the hiring-manager prior puts live problems first. The text format makes "draft the reply" easy to ask | Clarify, then structure, then answer. For draft-a-reply questions, write the reply itself, then one line on why you wrote it that way |
| Skeptic | Quiet probing of F5 (no software company) and F2 (Freshdesk, not Zendesk) | High. These are the two visible gaps, and a hiring manager is there to reduce risk | Acknowledge plainly, bridge only from your quoted evidence, give a concrete ramp-up plan |
| Conversational | Friendly openers: "Tell me about yourself", "Why Lumenvale?" | Medium. Chats usually open warm, and those answers are still scored on how clear and economical your writing is | Have a short written arc ready. Treat casual questions as scored |
| Data-Driven Prober | "60 a day — how was that split?" | Lower. One headline number (F1) and one specific claim (F6) | Say only what you know about how the figure was counted; say plainly what you don't |
| Pressure | Rapid follow-ups, "that's a textbook answer", short time limits | Lower. Interrupting is harder in text, but time-boxing isn't | Hold your position through two follow-ups, then concede something specific |
| Values / Behavioral | "Tell me about a time…" | Lower. No values page was retrieved and no values round is documented, so this appears only as behavioural questions within the chat | Pick a real instance, or say plainly that none comes to mind |
| Peer Evaluator | "How would you work with engineering?" | Lower. The interviewer leads the team, but collaboration questions can still come up | Frame around what you bring the team, not just what you need |

Weights rest on the invite's description of one text chat with a support team lead, read as a hiring-manager round.

---

## Question banks

### A — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes: 'You've charged me twice this month and I want it fixed today.' Write your first reply." | CASE | [generic] | Write the reply itself. Open by acknowledging the problem in one line. Say what you will do next and what you need from them, if anything. Give a realistic timeframe and promise nothing you can't control. Close with what happens next. Then add one line on why you wrote it that way. The question makes no claim about your past, so neither does the guidance | The text format makes draft-a-reply the natural case. JD+CASE because it scores written communication live |
| A2 | "A user says a feature stopped working after an update, and you can't reproduce it. What do you do?" | CASE | [generic] | Structure it in four steps. First, collect what you need: what they did, what they saw, when it started, screenshots, device or browser. Second, check whether it's a known issue. Third, if it's still unresolved, escalate with a clean summary so nobody has to re-ask the customer. Fourth, tell the customer what happens next and when. Say the steps in order | Tests structured troubleshooting where F5 is the gap. CASE because it is a live problem from the role |
| A3 | "Your queue has 40 tickets, three marked urgent and one from a customer who's emailed four times. How do you prioritise?" | JD, CASE | [generic] | State your rule out loud, for example impact plus time-sensitivity first, then age. Say what you would do with the repeat emailer, because a fourth email is a signal. Finish with how you would keep everyone else informed while you work | The ad's ticketing line (F2) in live form. JD content, CASE delivery |
| A4 | "A customer is demanding to speak to a manager. Walk me through how you handle it." | JD, CASE | [generic] | Structure it: acknowledge, find out what they actually need, fix what you can yourself, and escalate when it's warranted, not just to end the conversation. If you do escalate, hand over a summary so the customer doesn't repeat themselves, and tell them what happens next. Asked about how you'd handle it, not about your past | The ad's escalation line (F4). Answering as a process keeps you honest where your material is silent |
| A5 | "How would you get up to speed on our product in your first month?" | JD, CASE | [generic] | A plan, said as a plan: use the product as a customer would, read the help centre and past tickets, shadow teammates, keep notes on recurring issues, ask questions early. Don't describe a past you don't have | Usually how the F5 gap comes up. A specific plan is the bridge F5 allows |

### B — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked for a software company. Why should we believe you can support our users?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day" | **The highest-ROI rehearsal in this pack.** Start with the plain acknowledgment: "I haven't worked for a software company." Then name what you do have, at the quotes' own scope: three years as a customer service advisor, around 60 calls and emails a day, Freshdesk every day. Then the A5 plan. Follow-up 1, "But software support is different": hold. You aren't claiming software experience. You're describing the support work you have done, and you'd learn the product. Follow-up 2, "What will be hardest?": concede something specific, namely product knowledge at the start, and point back to the plan. Never claim technical experience your material doesn't show | F5 is the most predictable objection to you for this role, and you've already said it is a real gap. A rehearsed, non-defensive answer turns it into a credibility gain |
| B2 | "Our team uses Zendesk. How long until you're productive in it?" | JD | [grounded] "I use Freshdesk every day" | Say it at the quote's scope: you use Freshdesk every day. Don't claim Zendesk. Answer slot: if there are parts of your daily Freshdesk work you'd expect to carry over, name them in your own words. If you aren't sure what the two tools share, say so plainly and say how you'd learn it | F2. JD because it scores the stated tool requirement |
| B3 | "Why move from energy into software support?" | EXP | [generic] | Selection scaffold: give your real reason, in your own words, about what you want next, not what you're escaping. If you don't have a crisp reason yet, write one before the interview rather than improvising it in the chat | A motivation check every career-switch candidate gets. EXP because it tests whether your story holds together |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Answer with the gap you've already stated: product knowledge, because you haven't worked for a software company. Pair it with the A5 plan. Don't pick a fake weakness, since that reads as evasive | A standard Skeptic question with the same root as B1. Rehearsing both keeps your answers consistent |

### C — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me a bit about yourself and your background." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | Three or four short lines: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day, Freshdesk every day, and last year you trained four new starters on the refunds process. Close with one line on why this role, in your own words | Almost certainly the opener. It sets the tone of your writing, and it covers F1, F2 and F6 |
| C2 | "What drew you to Lumenvale?" | CO | [generic] | No company research was retrieved for this pack, so the content has to come from you. Answer slot: say what you actually know from the ad or their careers page, in your own words. If you know little, say what in the role attracted you and ask a reverse question about the product | Rapport-style, but scored on homework. Generic because no research ran |
| C3 | "How do you keep your written replies clear when you're handling a lot at once?" | JD | [inferred] "answering around 60 calls and emails a day" | You can describe the volume as your quote gives it: around 60 calls and emails a day. Answer slot: if you have your own habits for keeping emails clear, describe them in your own words. If you haven't thought about it as a method, say so and describe how you'd approach it | F3, the gap a text chat tests directly |

### D — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you handled an escalation with an upset customer." | VAL, JD | [generic] | Selection scaffold: pick a real case with an upset customer, a clear action you took, and an outcome, and say which parts were yours. If no such time comes to mind, say so plainly, then walk through how you would handle one (see A4) | The ad's escalation line (F4), asked behaviourally. Your material is silent here, so pick your story before the interview |

### E — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Around 60 calls and emails a day — how was that split, and was it typical?" | EXP | [grounded] "answering around 60 calls and emails a day" | Defend the number in your own words: how it was counted, what made it go up or down, the part you'd defend least, and whether it was your own volume. If you don't know the split, say so plainly. "Around" is your own word, so keep it | The one figure in your material. Probers ask for its denominator |
| E2 | "Tell me about training the four new starters on refunds." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Keep the beats your sentence states: four new starters, the refunds process, last year, and that you trained them. Anything about how you did it, tell in your own words. This pack supplies no method. Don't upgrade it to designing or leading a programme | F6 is your most distinctive line, so expect a probe on it. EXP because it tests attribution |

### G — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "That's a textbook answer. The policy says no refund and the customer says they'll cancel. What do you actually do?" | CASE | [generic] | Hold, then concede. Don't abandon the policy just to calm things down. Say what you can offer within the rules, and when you'd take the case to someone who can make an exception. If they push twice, concede something specific, such as not knowing Lumenvale's exception process yet, without folding on the principle | Tests composure, and touches escalations (F4) |
| G2 | "Two minutes: reply to 'Your app deleted my data. This is unacceptable.'" | CASE | [generic] | Short and calm: acknowledge, don't argue, don't promise the data back, say what you'll check and what you need from them, and give a time. Accuracy matters more than speed. A short reply sent on time beats a polished one sent late | A time-boxed written test of F3, and easy to do in a text chat |

### H — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "A bug is hurting customers but engineering says it's not a priority. What do you do?" | CASE, JD | [generic] | Bring evidence, not volume: how many tickets, what the customer impact is, and examples. Escalate through the agreed route. Keep customers updated honestly in the meantime. Respect that engineering sets its own priorities | Escalation (F4) across team boundaries. CASE because it is a live problem |
| H2 | "What could you bring to the team in your first month?" | VAL | [grounded] "I trained four new starters on our refunds process last year"; "I use Freshdesk every day" | Reciprocity framing at the quotes' scope: daily ticketing habits from Freshdesk, and having trained four new starters on a process last year, so you're used to explaining things clearly. Then a plan for learning the product. Don't claim anything you haven't done | A team lead weighs whether you add to the team or take time from it. It covers F2 and F6 |

---

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does a typical day look like for the team — which channels, and roughly what volume?" | Shows you're thinking about the actual job, and lets you connect it to F1 |
| "How do escalations work between support and engineering?" | Picks up the ad's escalation line, and the answer tells you a lot about the role |
| "How does onboarding work for someone who's new to the product?" | Addresses F5 head-on and shows you're planning to ramp up |
| "What would a strong first 90 days look like to you?" | Gives you their scorecard for the job |
| "Will the written offer and contract come from a Lumenvale email address, and who in HR will I be dealing with?" | Any real employer answers this instantly, and it protects you |
| "Will I get to meet the team on a video call at any stage?" | A normal question about team fit, and also a useful check on whether the process is genuine |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked for a software company, or has software support experience | A gap you stated yourself (F5) | "I haven't worked for a software company." Then the learning plan, said as a plan |
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." Your material names Freshdesk, not Zendesk |
| Designed or led a training programme | Inflated form of F6 | F6's quote at its own scope: four new starters, the refunds process, last year. Your material says you trained them, not that you built a programme |
| Handled around 60 written tickets a day | Inflated form of F1 | The quote at its own scope: "around 60 calls and emails a day". Your material gives calls and emails together, not written tickets alone |

---

## Sources

- **Provided:** your message (the job ad's requirements as you relayed them, your background) and the Telegram invite text.
- **Searches sent:**
  - `Lumenvale Software values` — refused (search permission not granted)
  - `Lumenvale Software interview process customer support` — refused
  - `job offer interview conducted entirely on Telegram recruitment scam warning` — refused
- **Fetches:** none.

Research tier: L1. Three of six searches were sent, all refused. No fetches.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Would have supplied the published values for VAL questions. The values cheat sheet is dropped and D1 stays generic |
| 2. `Lumenvale Software interview process` | unavailable | Would have checked the invite's description of the process against the company's own careers material. The loop rests on the invite's words alone |
| 3. `Lumenvale Software` strategy and recent news | unavailable | Would have grounded C2 and a CO question. Not sent because search was refused |
| 4. Interviewer name | n/a | No interviewer name was given, so the interviewer read is absent |
| 5. Representative JD | skipped | Your relayed ad fixes the fit snapshot |
| Search on Telegram-only recruitment | unavailable | Outside the declared targets. Would have sourced the process-verification advice. Refused |

---

## Upgrade menu

- **The full job ad text** → the fit-snapshot requirements quote the ad directly instead of your summary, and any mid-list requirements get their own questions
- **Search permission** → Lumenvale's published values (a values cheat sheet and grounded D questions), a check of their real hiring process, and current company context for C2
- **The team lead's name** → a tailored reverse question and persona weights based on their public profile
- **Your answers to the F3 and F4 answer slots** (written-reply quality, escalations you've handled) → D1, C3 and A4 become story-mapped instead of scaffolds
- **Prep time available** → a prioritised prep schedule
- **A tuesday-dossier.md** → an evidence-checked list of objections and the claims to avoid, carried in from an earlier job assessment. Useful, not required
