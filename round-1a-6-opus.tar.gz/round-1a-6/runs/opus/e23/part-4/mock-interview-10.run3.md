I'm reading the prep skill's rules before building your pack. One thing first, though: the Telegram message has the hallmarks of a recruitment scam. I'll explain in full once the pack is done.
The invite reads like a recruitment scam, so check it before you reply or share anything.

| Red flag in the message | Why it matters | Provenance |
|---|---|---|
| The whole process, offer and onboarding included, happens in Telegram | Real employers use their own email domain, applicant tracking system or video calls for offers and onboarding. A chat-only offer is a common job-scam pattern | [generic] |
| A text-only "interview" with a team lead | Makes it easy to pose as a company with no face or voice to check | [generic] |
| First contact on Telegram after you applied on a careers page | Scammers scrape job listings and contact applicants on messaging apps | [generic] |
| What usually comes next | Requests for ID, bank details or a "training" or equipment payment, or a cheque to deposit | [generic] |

What to do:
- Don't send personal documents, bank details or money.
- Find a contact on Lumenvale's official site (the careers page you applied through), not one from the Telegram message. Ask them whether Marcus Hale works on their talent team and whether this invite is real.
- If they say it isn't, report the account in Telegram.

I tried to look up Lumenvale's values, interview process and recent news, but the web searches weren't permitted, so the pack has no company-specific facts.

I've saved your prep pack as `Lumenvale_customer-support-specialist_interview_pack.md`. I built it for a single interview with a support team lead, since that's how the invite describes it. It also works for a genuine interview in any format.

- **Your strongest material:** the three years, the volume figure, Freshdesk every day, and training four new starters on refunds.
- **Main thing to rehearse:** B1, the question about never having worked at a software company. It's very likely to come up, and the answer is to concede it plainly, stick to what you've actually done, and give a learning plan.
- **Ticketing tool:** your Freshdesk experience covers the ad's "Zendesk or similar". Don't present it as Zendesk experience.
- **Escalations:** your message doesn't mention any. B4 and A2 give you an honest way to answer either way.

Say the word and I'll play the sceptical team lead on B1, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Once Lumenvale confirms through official channels, who will the real interview be with, and in what format? That changes how the question banks are weighted.
Could you paste the full job ad? It would replace my summary-based requirements with the ad's exact wording.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Lumenvale_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

Interviewer: a support team lead, as the Telegram invite describes. Check that the invite is genuine before you rely on it. This pack works for any real Lumenvale interview with a support lead, whether it happens by video, phone or written chat.

## How to use this pack

Personas describe how a question gets asked: who is asking and in what style. Types describe what the answer is scored on. Every answer guidance cell is scaffolding, not a script. Say it in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the values the company publishes |
| EXP | Whether what you say about your experience holds up when probed |
| JD | Whether you can do the listed job, gaps included |
| CO | How much homework you've done on the company and its product |
| CASE | How you structure and reason through a live problem from the role |

Provenance labels: `[grounded]` means traceable to something you told me. `[inferred]` means derived by this pack, with the derivation named. `[generic]` means a common pattern for this kind of role with no claim about Lumenvale.

## Fit snapshot

The requirements are quoted from your description of the job ad. Your evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — your message, describing the ad | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap. It clears the bar by a year. Say it in the quote's own terms: three years, customer service advisor, energy supplier, around 60 calls and emails a day. Keep "around" in the figure. Expect a probe on the number (C1) |
| F2 | "experience with Zendesk or a similar ticketing tool" — your message, describing the ad | "I use Freshdesk every day" — your message | medium | [grounded] | none | No gap: the ad says "or similar" and Freshdesk is the tool you use. Name it plainly ("I use Freshdesk every day") rather than calling it Zendesk experience. Answer slot: the ad names Zendesk, so expect "have you used Zendesk?" If you have, say where, in your own words. If you haven't, say so plainly and come back to Freshdesk every day |
| F3 | "clear written communication" — your message, describing the ad | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Answering emails is written work, but your material doesn't show how clear that writing is, and the interviewer will judge clarity from how you write in the interview itself. Answer slot: if you have a way of structuring replies, or your emails were quality-checked, describe it in your own words. If not, say so and show clarity in the reply you write live (A1) |
| F4 | "confidence handling escalations" — your message, describing the ad | none given | none | [grounded] | discovery | Your material doesn't mention escalations either way. Answer slot: if you've handled an escalated customer, or passed one up, tell that story in your own words: what happened, what you did, how it ended. If you haven't, say so plainly and walk through how you would handle one (A2) |
| F5 | Supporting a software product. This is not in the ad. It's an expectation that comes with joining a software company | "I've never worked for a software company" — your message | none | [grounded] | capability | You've said this yourself, and wording can't close it. Words: "I've never worked for a software company." Then how you'd learn the product, given as a plan, never as something you've done (A4). Add nothing to make the gap feel smaller |
| F6 | Helping teammates learn processes. This is not in the ad. It's a common expectation in support teams | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | Not a stated requirement, but a real, specific story. Tell it at its own scope: four new starters, the refunds process, last year. Say "trained", not "led training" or "ran onboarding" |

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | "Here's a ticket, reply to it." Live customer scenarios | High. A support team lead is effectively the hiring manager, and for that relationship case-style questions are the norm. In a text-chat format the live written reply becomes the main test | Clarify, structure, then answer. In writing: short paragraphs, one clear next step |
| Skeptic | Quiet probing of the software-company gap and the Zendesk point | High. F5 is the most visible gap, and hiring managers are trying to rule out risk | Concede F5 plainly, return to F1 and F2's quotes, give the learning plan |
| Data-Driven Prober | "How was 60 a day counted?" | Medium. One headline figure (F1) and one training story (F6) are natural targets | Know what you can say about the figure. Say plainly what you don't know |
| Conversational | "Walk me through your background", "why us?" | Medium. Every interview opens this way, and the casual questions are still scored | A rehearsed 90-second arc built only from your quotes |
| Pressure | Role-playing an angry customer, "why you over someone with SaaS experience?" | Low to medium. Support leads often test composure by playing the customer | Pause, restate, hold on what you actually said, concede only what's real |
| Values/Behavioral | "When did you put a customer first?" | Low. No published Lumenvale values were found (searches were refused), so these are generic support-values prompts | A selection scaffold with an honest branch |
| Peer Evaluator | Handoffs to engineering, helping teammates | Low. The lead will be working alongside you, so collaboration questions may come up | Talk about working principles, not claims about a team you don't know yet |

These weights assume the invite's description: one session with a support team lead. If the genuine process looks different, the weights change.

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes: 'I've been charged twice this month and I want it fixed today.' Write your first reply." | CASE | [generic] | Write it as you would send it. Acknowledge the problem in one line. Say what you'll do next and by when. Ask for the one detail you need. Promise nothing you can't control, such as an instant refund. Keep it short, plain and warm. The question needs no claim about your past, so the guidance makes none | Tests the ad's "clear written communication" (F3) directly, and in a text-chat format it is the interview. CASE because it's a live problem |
| A2 | "A customer says our app lost a day of their work and demands to speak to a manager. What do you do?" | CASE | [generic] | Structure: calm acknowledgment, then the facts (account, what they did, when, any error), then a check for a known issue, then a decision on whether it meets the escalation criteria, then a handoff with a summary so the customer never repeats themselves, then a follow-up. Ask what Lumenvale's escalation path is: clarifying first scores well | The ad's escalation line (F4) asked as a live problem, so it needs no past story. JD content with CASE delivery |
| A3 | "There are 40 tickets in the queue and three customers say they can't log in at all. How do you prioritise?" | CASE | [generic] | Impact and urgency first. Several customers locked out could be one incident, so check for a pattern and flag it to the lead early rather than answering each one alone. Then work the rest of the queue by urgency, using saved replies for repeat issues | A common triage case for a support lead. Generic because no Lumenvale process is known |
| A4 | "How would you get up to speed on our product in your first month?" | JD | [grounded] "I've never worked for a software company" | Give it as a plan, not a past: use the product the way a customer does, read the help centre and past tickets, shadow teammates, keep a running list of questions, and ask who to go to when you're stuck. You can acknowledge in one line, "I've never worked for a software company," then move to the plan | F5's gap turned into a forward plan. Rehearsing it here gives B1 and B5 something concrete to point to. JD because it's about doing the role |
| A5 | "A customer asks for a refund our policy doesn't allow. How do you reply?" | CASE | [grounded] "I trained four new starters on our refunds process last year" | You can open with context the quote carries, "I trained four new starters on our refunds process last year," without claiming you set the policy. Then the structure: explain the policy plainly and without blame, say what you can offer, and say when you'd ask a lead about an exception | Refunds are where F6's story naturally fits. CASE because the answer is scored on handling, not history |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see a software company in your background. Why should I believe you can support a software product?" | JD | [grounded] "I've never worked for a software company" "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" "I use Freshdesk every day" | **The highest-ROI rehearsal in this pack.** Concede first and plainly: "I've never worked for a software company." Then hold on what the quotes carry: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day, and Freshdesk every day. Describe the work and let them draw the conclusion. Don't say "it's the same thing". Then point to your learning plan (A4). If they push twice ("but billing isn't bugs"), come back to the same facts and the plan. Don't add technical experience you haven't described | F5 is the most visible gap, so some version of this question is close to certain. JD because it scores fit to the role |
| B2 | "Have you used Zendesk?" | JD | [grounded] "I use Freshdesk every day" | Answer slot: if you have, say where, in your own words. If not, say so plainly and then: "I use Freshdesk every day." Never let Freshdesk turn into Zendesk | F2. A quick knockout-style check that's easy to fumble. Rehearse it so the answer is clean |
| B3 | "Why move from energy to software support, and why now?" | JD | [generic] | Give your real reason in a sentence or two, in your own words. Point toward something about the role or the company, not away from your current employer. If you aren't sure yet, say what draws you to the ad. Don't make up a passion story | The Skeptic's standard motivation probe. Scored on whether your answer stays consistent |
| B4 | "Tell me about a time you handled an escalation." | JD | [grounded] | Pick a time a customer's issue went beyond a normal reply. A strong story has a clear problem, what you did, what you passed on and to whom, and how it ended. If no such time comes to mind, say so plainly, then walk through how you'd handle one (A2) | F4 is the requirement your material says nothing about. An open prompt themed on the ad's escalation line |
| B5 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Pick a real one. The honest, obvious one is product knowledge: "I've never worked for a software company." Follow it immediately with the plan (A4). A real weakness plus a plan beats a humblebrag | F5 again, asked as self-assessment. Rehearsed alongside B1 so both answers match |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said around 60 calls and emails a day. How is that counted?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Keep "around" and keep the figure attached to calls and emails. Answer slots, each in your own words: how the number is known (a system report or your own estimate), what makes it go up or down, the part you'd defend least, and that the volume is your own. If you don't know how it was counted, say "that's my own estimate" plainly | The only headline figure (F1). Probers always ask about numbers |
| C2 | "Walk me through how you trained the four new starters on refunds." | EXP | [grounded] "I trained four new starters on our refunds process last year" | The beats the quote states: four new starters, the refunds process, last year, and you trained them. Answer slot: the ad's focus on clear writing makes a question about written materials likely. If you wrote guides or notes for them, say what they were. If not, say so and describe how you trained them | F6 is your most distinctive story, and the first follow-up will ask what you actually did |
| C3 | "What makes a written reply to a customer good, in your current job?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Answer slot: if you have a way of structuring email replies, or they were quality-checked, describe it in your own words. If not, say so and describe what you aim for: clear first line, one next step, plain language | F3's discovery gap, rehearsed so the honest answer is ready |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, tell me about yourself." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" "I use Freshdesk every day" "I trained four new starters on our refunds process last year" | A 90-second arc built only from these: the three years and the volume, Freshdesk every day, training four new starters on refunds last year. End with one line on why this role, in your own words | It opens almost every interview, and the casual tone hides that it's scored. Draws on F1, F2 and F6 |
| D2 | "What do you know about Lumenvale?" | CO | [generic] | Say only what you've actually read: the ad, the company's own site, the product pages. No research was possible here, so this pack supplies no company facts. Don't fill the gap from guesses | CO homework check. Generic because the web searches were refused |
| D3 | "What do you enjoy most about support work?" | EXP | [generic] | Pick something true and specific to you, give one short example, and keep it brief. If nothing comes to mind, say what you find satisfying about a resolved ticket | Rapport question that also checks motivation. An open prompt, answered from your own experience |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's already done software support?" | JD | [grounded] "I've never worked for a software company" "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" "I use Freshdesk every day" | Hold, then concede. Pause. Hold on the quotes: three years, around 60 calls and emails a day, Freshdesk every day. Concede the real point, "I've never worked for a software company," and give the plan in one line. Don't fold, and don't oversell | F5 under time pressure. Rehearse until it fits in 60 seconds |
| E2 | "I'm the customer. This is the third time I've told you this is unacceptable. Fix it now." | CASE | [generic] | Don't rush. Acknowledge the frustration specifically. Restate what you understand the problem to be. Say exactly what you'll do and when. If it's beyond you, say who you're bringing in. Stay calm through two more pushes | Composure test on the ad's escalation line (F4). Role-play is common in support interviews |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time you chose the customer's outcome over speed or a target. It needs a clear choice and a result. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or how you'd handle it | A persona-stem prompt. Generic because Lumenvale's values weren't found |
| G2 | "Tell me about a time you had to tell a customer something they didn't want to hear." | VAL | [generic] | Pick a real one: what you had to say, how you said it, how they took it. If no such time comes to mind, say so plainly and describe how you'd approach it | Common support-values prompt about honesty under friction |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "How would you pass a bug report to our engineers so it doesn't bounce back?" | CASE | [generic] | Principles: steps to reproduce, what the customer expected versus what happened, account or browser details, screenshots, how many customers are affected, urgency. Ask how the team prefers to receive them | Handoffs are where support and engineering meet. Generic because Lumenvale's setup is unknown |
| H2 | "How do you help a teammate who's stuck?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Story map from F6: you trained four new starters on the refunds process last year. Tell it in your own words at that scope. Don't add mentoring or coaching beyond it | F6 is the natural evidence for teamwork. An open prompt with a real story behind it |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 "2+ years in customer support" | D1, C1, E1 |
| F2 "experience with Zendesk or a similar ticketing tool" | B2, D1 |
| F3 "clear written communication" | A1, C3, C2 |
| F4 "confidence handling escalations" | A2, B4, E2 |
| F5 supporting a software product | B1, B5, A4, E1 |
| F6 helping teammates learn | C2, H2, A5 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does a great first 90 days look like for someone in this role?" | Shows you're thinking about delivering, and tells you what you'll be measured on |
| "What are the most common reasons customers contact support today?" | Shows real interest in the product, and the answer helps your ramp-up plan (A4) |
| "How do escalations work here: who picks them up, and what does a good handoff look like?" | Ties straight to the ad's escalation line and shows you care about the process |
| "How does the support team work with engineering on bugs?" | Signals you understand the seam that matters most in software support (H1) |
| "What tools does the team use day to day?" | A natural way to discuss Zendesk and Freshdesk honestly (B2) |
| "What are the next steps in the process, and who else will I speak with?" | Normal to ask at any company, and the answer is easy to check against what the company says officially |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked in software or SaaS support | A negative you stated, F5 | "I've never worked for a software company." Then the plan (A4). No slot |
| Has Zendesk experience | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." B2's slot covers whether you've used Zendesk |
| Handles 60 tickets, or 60 calls, a day | Inflated form of F1 | F1's quote at its own scope: "around 60 calls and emails a day". Keep "around", and keep calls and emails together |
| Led training or ran onboarding | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year." The material says you trained four starters on one process, not that you ran a programme |

## Sources

Provided documents: your message (the ad's requirements as you described them, your background, and the Telegram invite's text).

Searches sent:
- `Lumenvale Software values`: refused (permission not granted)
- `Lumenvale Software interview process customer support`: refused (permission not granted)
- `Lumenvale Software news`: refused (permission not granted)

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Refused. It would have themed the G bank on Lumenvale's own published values and enabled a values cheat sheet if a values round turned out to be documented |
| 2. `Lumenvale Software interview process customer support` | unavailable | Refused. It would have shown whether the company's official careers material describes its process, which you could compare with the Telegram invite, and it would have set the persona weights |
| 3. `Lumenvale Software` strategy and recent news | unavailable | Refused. It would have supplied a CO question grounded in the product and recent moves, and real material for D2 |
| 4. `{interviewer name} Lumenvale Software` | n/a | The support team lead wasn't named, so there was no query to form |
| 5. representative Customer Support Specialist JD | skipped | Your description of the ad's four requirements already fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Confirmation from Lumenvale's official recruiting contact of the real interview format and the interviewer's name → reweighted personas, an interviewer read, and a reverse question tailored to their background
- The full job ad text → exact requirement quotes, any requirements your summary left out turned into new JD questions, and checks on gates such as hours or time zone
- Permission for web searches → Lumenvale's values, process and product turned from `[generic]` into sourced rows, a CO question, and real material for D2. A deeper pass is also available: up to 6 more searches and 2 more fetches, a few extra minutes
- Your answers to the answer slots in F3 and F4 (written-reply habits, any escalation you've handled) → B4, C3 and A2 rebuilt as stories from your own experience
- A tuesday-dossier.md from an earlier evaluation of this role, if you have one → the main objection taken from verified evidence instead of inferred here, plus a guardrail list of claims not to make
