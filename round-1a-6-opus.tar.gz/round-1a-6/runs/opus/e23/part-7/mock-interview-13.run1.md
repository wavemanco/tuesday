I'm reading the prep-pack rules now, and next I'll run a few quick searches on Quillmoor and the recruiter before I write your pack.
I've built your prep pack for Thursday's call with Hannah. I couldn't research Quillmoor or Hannah because web search wasn't allowed in this session, so the pack uses only the advert, her message and what you told me.

The main points:
- **Her four topics:** your answers are mostly ready.
  - **Salary:** £42,000 sits inside their £38,000–£44,000 range. Say it as one figure.
  - **Hybrid:** two days at Avonmouth works for you. Only mention your "no more than three" limit if she raises more days.
  - **Why you're moving:** the office closing is a clean reason. Say it plainly, then add one line on why this role.
  - **Notice period:** this is the one gap, because you haven't told me yours. Check your contract before Thursday.
- **The question most worth rehearsing:** "Your background is scheduling deliveries. How does that translate to coordinating production with planning, the warehouse and QA?" Talk about scheduling deliveries for your three depots, point out yourself that it isn't production work, and don't stretch it to cover production.
- **SAP:** say "I haven't used SAP" and describe your in-house stock system as just that, not as an ERP. The advert lists SAP as a plus, not a requirement.
- **Your stock-count result:** keep it as "about a third, over a year", not "33%", and be ready to say how it was measured and how much of it was down to you.

The pack also has six questions to ask her at the end and a list of claims to avoid.

Your pack is saved at /var/tmp/tuesday-measure/1a6/runs/opus/e23/part-7/rooms/case-13-denied-99313611/quillmoor-diagnostics_operations-coordinator_interview_pack.md

If you'd like to practise, I can play Hannah and ask you that production-scheduling question, with follow-ups.
I can also save a tuesday-dossier.md that records the gaps this prep found, for you to use in later rounds.
If you'd like the pack as a Word document, I can convert it.

What's your notice period, and does the office closure change when you could start? Your answer settles the notice-period question in the pack.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Recruiter screen prep pack: Operations Coordinator, Quillmoor Diagnostics

**Interviewer:** Hannah Lowther, Talent Partner (recruiter)
**Format:** Thursday at 2pm, a 30-minute phone call. Hannah will ring the mobile number on your application.
**Her stated agenda:** your salary expectations, your notice period, how the hybrid pattern would work for you, what's prompting a move. Then she'll tell you about the team and the next steps.

---

## How to use this pack

- **Personas** describe *how* a question is asked (friendly chat, quiet probing, time pressure). **Types** describe *what* is being scored.
- Type key:
  - **VAL**: behaviour against the company's published values
  - **EXP**: whether what you say about your experience holds up when someone asks more
  - **JD**: the advert's stated duties, requirements and terms, gaps included
  - **CO**: what you know about the company and its context
  - **CASE**: a live "what would you do" problem from the role
- **Provenance labels:** `[grounded]` means the guidance traces to your words, the advert or Hannah's message. `[inferred]` means it is this pack's reasoning from those. `[generic]` means a common pattern for this kind of role, with no claim about Quillmoor.
- **Answer slots** are places where only you know the answer. Each one gives you two honest ways to fill it. Don't invent a third.
- The guidance is scaffolding, not a script. Say it in your own words.
- Bank IDs go A, B, C, D, E, G. There is no bank F, because fit-snapshot rows are numbered F1, F2 and so on.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | medium | [grounded] | transferability | Your material covers scheduling deliveries across three depots. It doesn't mention production schedules or QA, so keep your words at that scope: "I schedule deliveries for our three depots." Answer slot: the advert's planning/warehouse/QA line makes a question about working across teams likely. If your scheduling means agreeing timings with other people or teams, say who and how, in your own words. If it doesn't, say so plainly and stay with the depot scheduling. This is the highest-ROI rehearsal: see B1 |
| F2 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | medium | [grounded] | none | This is the closest match in the advert. Lead with it in the quote's own words: you chase suppliers when orders slip. It's still unsupported by any document, so expect "give me an example" (G1) |
| F3 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | none | This is your strongest line, and it has a number, so it will be probed. Keep "about a third" and "over a year" exactly as they are. Don't round it to 33% and don't make it "I cut". C1 and D2 rehearse how to defend it |
| F4 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Strong evidence would be a regular report you produced on delivery or dispatch performance. Answer slot: if you've produced any regular delivery or on-time reporting, say what it covered, how often and who read it, in your own words. If you haven't, say so plainly and use E3 to show how you'd build one |
| F5 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler." (your message) | medium | [grounded] | none | Above the bar as stated. Say the title and the four years plainly |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | low | [inferred] | discovery | Your material says "spreadsheet" but doesn't name Excel. Answer slot: if it was built in Excel, say so and name the features you actually used, in your own words. If it was another tool, name it, and say plainly how much Excel you've used |
| F7 | "ERP experience (SAP or similar) a plus" (advert). This row covers SAP | "Never used SAP — we run our own in-house stock system." (your message) | none | [grounded] | capability | You stated this gap yourself, so wording can't close it. Words: "I haven't used SAP." After that, how you'd learn it, said as a plan and never as a past. The advert calls it "a plus", not a requirement |
| F8 | "ERP experience (SAP or similar) a plus" (advert). This row covers "or similar" | "Never used SAP — we run our own in-house stock system." (your message) | medium | [grounded] | transferability | Keep the words at their own scope: "We run our own in-house stock system." Don't call it an ERP. Answer slot: if you use it for stock records, orders or deliveries, say which, in your own words. If your use of it is narrower, say so plainly |
| F9 | "your salary expectations" (Hannah's message). Advert: "£38,000–£44,000" | "I'm hoping for £42,000." (your message) | high | [grounded] | none | £42,000 sits inside the advertised range. Say the figure as a figure: £42,000 |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert). Also "how the hybrid pattern would work for you" (Hannah's message) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | Two days fits what you said. Keep your ceiling exactly as you stated it, "I wouldn't want more than three", without softening it to a preference or hardening it into a refusal |
| F11 | "your notice period" (Hannah's message) | none given | none | [grounded] | hard_gate | Your material doesn't say what your notice period is. It's a term, so the answer is a fact, not a form of words. See A3 |
| F12 | "what's prompting a move" (Hannah's message) | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." (your message) | high | [grounded] | none | A clean reason that recruiters hear often. Say it as you wrote it, with no complaint about your employer. A5 and B4 rehearse the follow-ups |

---

## Persona table

Hannah's own message sets out this session: one 30-minute phone call with her, on four named topics, followed by her briefing. So the weights below rest on her words, not on a guessed pattern for how Quillmoor interviews.

| Persona | How it shows up on Thursday | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly openers, then her four topics asked casually | High. It's a recruiter screen, and she has already named her agenda. The risk is treating a chatty call as unscored | Have a 60–90 second "about me" ready, plus a one-line answer to each of her four topics (bank A). Treat every casual question as scored |
| Skeptic | Gentle follow-ups: "why diagnostics?", "no SAP?", "how does depot scheduling translate?" | Medium. Recruiters check the hiring manager's must-haves and whether your motivation hangs together. F1, F7 and F12 are where she'd press | Rehearse B1 until it's boring. Build bridges only from what you actually said, and name the limit before she does |
| Data-Driven Prober | "How was that third measured?", "What do you use in Excel?" | Low to medium. F3 is the only figure in your material, and figures attract follow-ups. She may also be relaying screening questions from the hiring manager | Know what you can and can't say about how "about a third" was counted, and say plainly when you don't know |
| Case / Strategist | A light "what would you do if a supplier's late?" | Low. More typical of a hiring-manager round, but cheap to rehearse, and it covers advert lines your material doesn't (F4) | Clarify, act, communicate, record. Think aloud |
| Pressure | A time-boxed "why should I put you forward?" | Low. Pressure isn't the style of a screen, but a short pitch question is common | Pause, then give three beats from your own words |
| Values / Behavioral | One "tell me about a time" question | Low. No values-style round is detected, and Quillmoor's values couldn't be checked (Sources) | Choose a real occasion. If none comes to mind, say so and describe what you usually do |

---

## Question banks

### A. Conversational: Hannah's agenda (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, tell me a bit about yourself and what you're doing at the moment." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Three beats in 60–90 seconds, in your own words: (1) four years as a logistics coordinator at a building-supplies wholesaler; (2) you schedule deliveries for three depots and chase suppliers when orders slip; (3) you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. Finish by naming the advert lines you recognise from that work, supplier chasing and stock records, and stop there. Don't describe the work as proof of anything. Let her draw the conclusion | Almost every screen opens this way, and it sets up all four of her topics. EXP, because it is the first test of whether F5, F2 and F3 hold up when said aloud |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Give one figure, plainly: £42,000. Don't open with a range below it. Answer slot: if she asks whether there's flexibility, decide your real floor before Thursday. If you'd accept less, say what, in your own words. If £42,000 is your floor, say so plainly. Asking what else is in the package is fair (reverse question R6) | Her first named topic. JD, because it tests you against the advertised term (F9) |
| A3 | "What's your notice period?" | JD | [grounded] | Check your contract before Thursday and give the exact figure. Answer slot: if the office closure affects when you could start, say how, in your own words. If it doesn't, give the contractual notice on its own. If you're unsure on the day, say you'll confirm by message that afternoon rather than guess | Her second named topic, and the only one your material doesn't answer (F11). JD, because it is a term she will record for the hiring manager |
| A4 | "The role's two days a week at Avonmouth. How would that work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Open with "Two days at Avonmouth is fine. I live in north Bristol." If she raises flexibility or more days, give your ceiling in your own words exactly: "I wouldn't want more than three." Don't add claims about travel time or commute | Her third named topic (F10). JD, because it is the advertised working pattern |
| A5 | "And what's prompting the move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Say it straight: the Bristol office closes next year, and the only option offered is relocating to Reading, which you don't want. No complaint about your employer. Then one line about this role. Answer slot: if something in this advert or about Quillmoor drew you, say what, in your own words. If it was mainly that it's the right kind of role in Bristol, say so plainly, and point to the advert's supplier-chasing line as work you do now | Her fourth named topic (F12). EXP, because she is checking that your reason for moving fits your history. The forward-looking line is what B4 tests |

### B. Skeptic: the gaps and the motive (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background's delivery scheduling at a wholesaler. This role coordinates production schedules between planning, the warehouse and QA. How do you see that translating?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | **Highest-ROI rehearsal in this pack.** Keep your claim to what the quote carries: "I schedule deliveries for our three depots, and I chase suppliers when orders slip." Name the limit yourself before she does: the work you described is deliveries, not production. Answer slot: if your scheduling means agreeing timings with other people or teams, say who and how, in your own words. If it doesn't, say so plainly and stay with the depot scheduling. Then give a plan, said as a plan: what you'd want to learn first about how planning, the warehouse and QA hand over to each other. **Follow-up 1:** "Have you worked with a QA team?" Answer slot: if you have, say what that involved. If not, say so plainly. **Follow-up 2:** "So you haven't done production scheduling?" Hold calmly through both. Answer slot: if you've done any, say what. If not, say so plainly and return to the depot scheduling. Don't fold into apology, and don't stretch the depot work to cover it | F1 is the widest gap on a headline duty, so some version of this will reach you, from Hannah or from the hiring manager she briefs. JD, because it scores the advert's first listed duty. It is placed under Skeptic because it arrives as a polite "help me understand" |
| B2 | "What draws you to diagnostics, coming from building supplies?" | CO | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if something about diagnostics, manufacturing or Quillmoor itself interests you, say what, in your own words. If it's mainly the role and the location, say so plainly. Then say that the advert's supplier-chasing and stock-records lines are the kind of work you described: chasing suppliers when orders slip, and the stock-count spreadsheet. Before Thursday, spend five minutes on Quillmoor's own website so you can say one true thing about what they make | A switch of sector invites this question. CO, because it tests homework. It is generic until the company research runs (upgrade menu) |
| B3 | "You haven't used SAP. Would that be a problem?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | "I haven't used SAP. We run our own in-house stock system." Don't call that system an ERP. Answer slot: if you use it for stock records, orders or deliveries, say which, in your own words. If your use is narrower, say so plainly. Then a plan for learning SAP, said as a plan, never as a past. Let her note for herself that the advert calls it "a plus" | F7 and F8: a gap you stated yourself, on a named plus. JD, because it is the advert's tool line. You are best served by answering it cleanly once |
| B4 | "If the office weren't closing, would you be looking at all?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Hold on to the honest trigger: the closure is what prompted you to look. Don't invent a long-standing plan to leave. Answer slot: if there's more to it, say what, briefly, in your own words. If the closure is the whole reason, say so plainly. That's a fine answer, and the forward-looking line from A5 carries the rest | F12, tested for consistency. EXP, because it checks your story against itself. A clear "yes, the closure prompted it" usually reads better than a manufactured ambition |

### C. Data-Driven Prober (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You mentioned discrepancies fell by about a third. How was that measured?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Keep the figure as you gave it: "about a third, over a year." Answer slots, each in your own words: how the fall was counted. What it's sensitive to. The assumption behind it you'd defend least: name it before she does. Which part was yours (you rebuilt the spreadsheet). If you don't know how it was counted, say so plainly. That's an honest answer, and a guessed method isn't | F3 is your only figure, and figures attract this question. EXP, because it checks the claim holds up under questions |
| C2 | "Do you do any reporting on delivery performance now, like on-time rates?" | JD | [grounded] | Answer slot: if you produce any regular delivery or on-time reporting, say what it covers, how often and who reads it, in your own words. If you don't, say so plainly and offer the outline from E3 | F4: the advert names weekly on-time dispatch reporting, and your material is silent on it. JD, because it scores a stated duty |
| C3 | "How confident are you in Excel? What do you use it for?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if the stock-count spreadsheet was in Excel, say so, and name the features you actually used to rebuild it. If it was another tool, name it, and say plainly how much Excel you use. Don't list functions you don't use | F6: a stated requirement your material touches without naming. JD, because "confident with Excel" is likely a literal screening question |

### D. Case / Strategist (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A key supplier says a delivery will be a week late, and production needs it on Monday. What do you do?" | CASE | [generic] | Structure: (1) clarify what the delivery holds up and what stock is on hand; (2) tell planning and the warehouse early, with QA if incoming checks are affected; (3) look at options: a part delivery, another supplier, changing the order of work; (4) agree a new date in writing and follow it up; (5) record it so it shows in the weekly reporting. If a real occasion of yours fits, you can tell that instead, as it happened, in your own words | The advert's "chase late orders" line, asked as a live problem. CASE, because it scores structure, not a claim about your past |
| D2 | "The system says 200 units, the warehouse count says 170. Where do you start?" | CASE | [generic] | Structure: recount or confirm the count first; check recent movements (receipts, dispatches, returns, transfers) for anything unbooked; check for unit-of-measure or location errors; correct the record with a note of why; look for a pattern before it repeats. Thinking aloud is the point | The advert's stock-accuracy line (F3's requirement), asked as a decision. CASE, for the same reason as D1 |
| D3 | "How would you put together a weekly on-time dispatch report?" | CASE | [generic] | Structure: agree what counts as "on time" (against which date), where the data comes from, the cadence, a headline rate plus the late orders with reasons, who reads it, and what changes as a result. Ask what the hiring manager currently uses before proposing anything | F4 has no evidence behind it, so this gives you a way to show reasoning without claiming a past. CASE, because it's a live design question |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "In thirty seconds: why should I put you forward to the hiring manager?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Pause. Then three beats, nothing more: four years as a logistics coordinator; you schedule deliveries for three depots and chase suppliers when orders slip; you rebuilt the stock-count spreadsheet and discrepancies fell by about a third over a year. Stop when the beats are done. No adjectives about yourself | A common recruiter close. JD, because it scores you against the advert's experience lines (F5, F2, F3) |
| E2 | "That stock improvement. How much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold what the quote says: you rebuilt the spreadsheet, and discrepancies fell over the year. Answer slot: if other people or other changes contributed that year, say so and say what was yours. If you don't know what else drove it, say that plainly. Concede that uncertainty in specific terms, without retreating from the fact that you did the rebuild. Hold through two follow-ups | F3, tested for attribution. EXP, because "how much was you" is the standard check for inflated claims |

### G. Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you had to sort out a supplier who was letting you down." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Story-mapped on F2: an order that slipped, and you chasing the supplier. Answer slot: if a particular occasion comes to mind, tell it as it happened: what slipped, what you did, how it ended, in your own words. If none does, say so plainly and describe how you usually chase | The advert's "chase late orders" line asked as an open prompt. EXP, because it asks for a real instance behind F2 |
| G2 | "Tell me about a time you had to give someone bad news about a late order." | EXP | [generic] | Pick a time you had to tell someone something they didn't want to hear. It needs a named person, what you told them and how the relationship stood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The advert's late-orders line combined with a common behavioural stem. `[generic]` because Quillmoor's values couldn't be checked (Sources) |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Coordinate production schedules between planning, the warehouse and QA | B1 |
| F2 Track supplier deliveries and chase late orders | G1, D1, A1 |
| F3 Keep stock records accurate | C1, E2, D2 |
| F4 Report weekly on on-time dispatch | C2, D3 |
| F5 2+ years in operations or logistics coordination | A1, E1 |
| F6 Confident with Excel | C3 |
| F7 and F8 ERP experience (SAP or similar) a plus | B3 |
| F9 Salary expectations | A2 |
| F10 Hybrid, two days at Avonmouth | A4 |
| F11 Notice period | A3 |
| F12 What's prompting a move | A5, B4 |

---

## Reverse questions

Hannah has said she'll tell you about the team and the next steps, so have these ready for when she asks "any questions for me?". Never answer "I think you've covered everything."

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who would I work with most day to day across planning, the warehouse and QA?" | It shows you've read the first duty, and the answer helps you prepare for B1 with the hiring manager |
| R2 | "What does the weekly on-time dispatch report look like now, and who reads it?" | It turns F4, your silent spot, into curiosity, and tells you what the hiring manager will measure you on |
| R3 | "Which system does the site run on, and how do new starters usually get trained on it?" | It raises the SAP point (F7) on your own terms, as a question about getting up to speed |
| R4 | "Are the two Avonmouth days fixed, or do they move week to week?" | It's practical, it confirms the pattern you'd be agreeing to (F10), and it reads as someone already planning their week |
| R5 | "What would a good first three months look like in this role?" | It invites her to tell you the hiring manager's priorities, which is the best possible prep for the next round |
| R6 | "Is the £38,000–£44,000 range base salary, and what else is in the package?" | It's fair to ask at screen stage, and it puts your £42,000 in context |

---

## Prohibited claims

What this pack won't coach, and why. These are the claims that are easiest to reach for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Has coordinated production schedules | Inflated form of F1 | F1's quote at its own scope. This pack's observation: your material says deliveries across depots, not production. B1's slots stay inside the depot scheduling |
| Managed three depots | Inflated form of F1 | "I schedule deliveries for our three depots." |
| Has used SAP | A negative you stated, F7 | "I haven't used SAP." |
| Has ERP experience, or the in-house system is an ERP | Inflated form of F8 | "We run our own in-house stock system." This pack's observation: your material doesn't say what kind of system it is. B3's slot asks only what you use it for |
| Cut stock discrepancies by 33%, or the spreadsheet alone caused the fall | Inflated form of F3 | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." C1 and E2 keep attribution open |
| Moving for career growth rather than because of the closure | Contradicted by F12's quote | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." |

---

## Sources

**Provided material:** the advert text and Hannah Lowther's LinkedIn message, both pasted, and your background as written in your message.

**Searches sent (all refused, because web search permission was not granted in this session):**

- `Quillmoor Diagnostics values`: refused
- `Quillmoor Diagnostics Avonmouth news`: refused
- `Hannah Lowther Quillmoor Diagnostics Talent Partner`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The search was refused. It would have themed bank G with Quillmoor's published values. A cheat sheet wouldn't appear either way, because no values-style round is detected for this call |
| 2. `Quillmoor Diagnostics interview process` | skipped | Hannah's message fixes this session (a 30-minute call with her, four named topics), and the persona weights follow it |
| 3. Quillmoor strategy or recent news | unavailable | The search was refused. It would have grounded B2 and added a company-knowledge question and a reverse question |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | The search was refused. A public professional profile would have added a section on reading the interviewer and a reverse question tied to her career path |
| 5. Representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Your notice period** → F11 and A3 become a settled fact instead of a gap
- **Allowing web search** → Quillmoor's published values can theme bank G, a news check can ground B2 and add a company-knowledge question, and Hannah's public professional profile can add a section on reading the interviewer plus a reverse question tied to her career path
- **A deeper research pass, once search is allowed** (up to 6 more searches and 2 more fetches, several more minutes) → company context for the hiring-manager round rather than this call
- **Your answers to the slots in F1, F4 and F6** (cross-team scheduling, any on-time reporting, whether the spreadsheet is Excel) → B1, C2, C3 and D3 can move from slots to stories built on your own words
- **The CV you applied with** → a check that it says what your message says, since Hannah will have it in front of her. Any extra lines would become new fit-snapshot evidence
- **The next rounds, once Hannah tells you them** → per-round mini-packs with their own persona weights
- **A `tuesday-dossier.md` from job-underwriter** → verified evidence and an independent prohibited-claims list, in place of the one this pack built locally. Not needed for this call
