# Recruiter screen prep: Operations Coordinator, Quillmoor Diagnostics

**Who:** Hannah Lowther, Talent Partner (recruiter). **Format:** 30-minute phone call; she rings the mobile number on your application, Thursday at 2pm.
**Her stated agenda, in her words:** "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move, and then I'll tell you about the team and the next steps."

## How to use this pack

- **Personas** are how a question is asked (friendly, sceptical, pushy). **Types** are what is being scored. The same question can come in any style.
- Type key: **VAL** values and behaviour · **EXP** your work history, and whether it holds up · **JD** the advert's requirements, and the recruiter's own agenda items · **CO** knowing the company · **CASE** a live problem from the job.
- Provenance labels: **[grounded]** traces to the advert, Hannah's message or your own words. **[inferred]** is this pack's own reasoning from those. **[generic]** is a common pattern for calls like this, with nothing claimed about Quillmoor.
- Every quote of yours below is copied exactly from your message. The guidance is a scaffold, not a script. Say it in your own words, and say only what you actually did.
- Hannah's agenda sets the structure of the call. Her four topics are banks A and D, and they are the bulk of the call. The rest is insurance for the few minutes she may spend testing your background before she hands you on.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler." (your message) | medium | [grounded] | none | No gap. Your four years clear the two the advert asks for. Say it plainly: four years as a logistics coordinator at a building-supplies wholesaler. Nothing has been inspected behind it, so she may ask what the role involves |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | medium | [grounded] | transferability | Your material says delivery scheduling across three depots. It does not mention production schedules, a planning team or QA, and the words stay inside what it does say: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a question about working across teams likely. If your scheduling meant agreeing times with other people or teams, say who and how, in your own words. If it didn't, or that part wasn't yours, say so plainly and stay with the depots |
| F3 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | medium | [grounded] | none | No gap. Your words already match the advert's: you chase suppliers when orders slip. Lead with that sentence |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | none | No gap, and it's your strongest line. Keep "about a third" and "over a year" exactly as you wrote them. The number will draw a "how was that counted?" question (C1) |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material doesn't say whether you report on deliveries. Answer slot: if you produce any regular delivery or dispatch reporting, say what it covers, how often and who reads it, in your own words. If you don't, say so plainly, and say how you would set up a weekly on-time figure as a plan |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | low | [inferred] | discovery | Your sentence says "spreadsheet". It doesn't say which tool or what you built in it. Answer slot: if the spreadsheet was in Excel, say so and name what you actually used in it, in your own words. If it was another tool, say which, and don't call it Excel |
| F7 | "ERP experience (SAP or similar) a plus": the SAP part (advert) | "Never used SAP — we run our own in-house stock system." (your message) | none | [grounded] | capability | A gap you've stated yourself, and you can say it as it is: "I've never used SAP." Any learning plan is said as a plan, never as past experience. The advert calls it "a plus", not a requirement |
| F8 | "ERP experience (SAP or similar) a plus": the "or similar" part (advert) | "Never used SAP — we run our own in-house stock system." (your message) | medium | [grounded] | transferability | You run an in-house stock system. Your material doesn't say whether it does what an ERP does, so don't call it an ERP. Answer slot: if she asks what the system covers, describe what you do in it day to day, in your own words, and let her make the comparison |
| F9 | "£38,000–£44,000" (advert) and "your salary expectations" (Hannah) | "I'm hoping for £42,000." (your message) | high | [grounded] | none | Your figure sits inside the advertised range. Say the number as you wrote it: £42,000 |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol." (advert) and "how the hybrid pattern would work for you" (Hannah) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | The advertised pattern is within your limit. Two days is fine. Your ceiling is three, and that's yours to state |
| F11 | "your notice period" (Hannah) | none given | none | [grounded] | hard_gate | Your material doesn't establish your notice period |
| F12 | "what's prompting a move" (Hannah) | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." (your message) | medium | [grounded] | none | No gap. The reason is concrete and easy to check, so give it straight: the Bristol office is closing next year, the only offer is relocating to Reading, and you don't want to move. Then go to the role (A2) |

## Persona table

Starting point: in a recruiter screen, a friendly conversational style is most likely, with light scepticism. Hannah's own agenda then pushes the logistics topics (salary, notice, hybrid, motive) to the top. Peer Evaluator is left out: a one-to-one call with a recruiter has no peer in it.

| Persona | How it shows up on this call | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly run through her four topics, plus "tell me about yourself" | Highest. Her message lists the four topics and a recruiter screen leans conversational. Casual questions are still scored | Have short, ready answers for each of her four topics (A2 to A5). Keep each under a minute and stop when you've answered |
| Skeptic | "We're a manufacturer, you're wholesale"; "SAP?"; "would you be looking if the office weren't closing?" | Medium. The advert's production-scheduling and SAP lines set this up (F2, F7), and the reason for moving invites a "push or pull?" check (F12) | Rehearse B1 until it's boring. Describe only what your sentences carry, say the limits plainly, and give a learning plan as a plan |
| Pressure | Pushback on £42,000; "what if it's three days?" | Medium-low. Recruiters often test whether a figure or limit holds. Nothing suggests Hannah's style is pushy | Pause, hold your figure and your limit through two follow-ups, and concede only what's actually true |
| Data-Driven Prober | "How was the one-third counted?" | Low-medium. A number on a call draws a follow-up even from a recruiter (F4) | Know what you can and can't say about how the figure was counted, and say plainly if you don't know |
| Case / Strategist | A quick "what would you do if…" about a late supplier | Low. More typical of the hiring-manager stage, but cheap to rehearse | Clarify, then prioritise, then act, then communicate. Think aloud |
| Values / Behavioural | "Tell me about a time…" | Low. Nothing in her agenda points to it, and no values page could be read (see Sources) | Pick a real instance in advance. If none fits, say so and give the nearest thing you do have |

## Question banks

### A. Conversational (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, tell me a bit about yourself and what you do now." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | A 60–90 second arc from your own sentences: four years as a logistics coordinator at a building-supplies wholesaler. You schedule deliveries for three depots and chase suppliers when orders slip. You rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. Then say you're looking because of the office move (A2), and stop. Don't explain what any of it proves. Let her connect it to the advert | Almost every screen opens with this. EXP because it puts F1, F3 and F4 on the record in your words, and anything said here gets referred back to later |
| A2 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | One or two sentences, in your own words: the Bristol office is closing next year, the only offer is relocating to Reading, and you don't want to move. Say it flatly, without complaint. Answer slot: she'll probably follow with why this role. If something specific in the advert drew you, name it in your own words. If it was mainly a Bristol logistics role close to your current work, say that plainly. That's an honest answer, not a weak one | One of Hannah's four named topics (F12). EXP because it's about your work history. Your reason checks out, and the only risk is padding it |
| A3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Say the number: "I'm hoping for £42,000." It's inside the advertised £38,000–£44,000, so you don't need to justify it. Answer slot: if she asks for flexibility or a minimum, decide before the call whether you have a lower figure you'd accept. If you do, you can give it. If you don't, say £42,000 is your figure. If she asks your current salary, either give the true figure or say you'd rather talk about the £42,000. Don't give a number you haven't decided on | Hannah named it first (F9). JD because the advert states the range |
| A4 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | "I live in north Bristol, so two days at Avonmouth is fine." Whether to mention your three-day ceiling now or only if she asks is your call. Either way it's true, and it's above what the advert asks for | Named topic (F10). JD because the advert sets the pattern. It's a quick yes as long as the limit stays as you stated it |
| A5 | "What's your notice period, and when could you start?" | JD | [grounded] | Your material doesn't give your notice period, so check your contract before the call. Answer slot: give the period your contract actually states, in plain words. If you're unsure, say you'll confirm it by message. Don't guess a number | Named topic, and a gate row (F11). JD because it's on the recruiter's own agenda. A guessed notice period is the one answer here that could go wrong later |

### B. Skeptic (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background's in wholesale distribution, and this role coordinates production schedules between planning, the warehouse and QA. How would that translate?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | **The highest-value rehearsal in this pack.** Hold on what your sentence carries: you schedule deliveries for three depots and chase suppliers when orders slip. State the limit before she does. Your work has been delivery scheduling, not production, and the pack can't say more than that. Answer slot: if your scheduling meant agreeing times with other teams or people, say who and how, in your own words. If it didn't, or it wasn't yours, say so plainly and stay with the depots. Then a plan, said as a plan: what you'd want to learn first about how planning, the warehouse and QA work together. Follow-up 1, "So you haven't worked with production?": same slot, both answers honest, no added detail. Follow-up 2, "Then why should we see you?": return to F3 and F4 in your own sentences. Hold through both, and never stretch "depots" into "production" | F2 is the widest gap between the advert and your material, so some form of this question is likely. JD because it scores the advert's first duty. This is also where you'll be most tempted to stretch your experience |
| B2 | "Have you used SAP, or a similar ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | "I've never used SAP. We run our own in-house stock system." Answer slot: if she asks what that system does, describe what you actually do in it, in your own words. Don't call it an ERP, and let her decide whether it counts as "similar". A plan to learn SAP is fine if it's said as a plan. Remember the advert calls it a plus | F7 and F8. A recruiter checks "nice to have" items quickly, and a clean answer takes ten seconds. JD because it's an advert line |
| B3 | "If your office weren't closing, would you still be looking?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | A hypothetical, so answer it honestly from where you actually stand. Answer slot: if you'd been thinking about moving anyway, say why, in your own words. If you wouldn't have been looking, say that plainly. The closure is a fair reason, and you can say why this role interests you now (A2's slot). Don't invent a reason you weren't feeling | Recruiters test whether a push-only reason also has a pull (F12). EXP because it's about your work history. An answer you've thought through beats one you make up on the spot |
| B4 | "What do you know about us, and why us?" | CO | [grounded] | Stick to what the advert states: Quillmoor is a diagnostic-test manufacturer of about 400 staff, the site is in Avonmouth, and the duties cover scheduling, chasing suppliers, stock accuracy and dispatch reporting. Answer slot: if you've read about Quillmoor anywhere else, say what you read. If not, say you've read the advert and would like to hear more about the team. That's a good bridge into your own questions | CO, though without research it's limited to the advert (see Sources). Claiming knowledge you don't have is the risk here |

### C. Data-Driven Prober (low-medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Discrepancies fell by about a third. How was that measured?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Keep "about a third" and "over a year". Answer slot, in your own words: how the discrepancies were counted. What else could have moved the figure over that year. The assumption behind it you'd defend least, and name it before she does. Which part was yours. If you don't know how it was counted, say so plainly. Don't turn "about a third" into a precise percentage, and don't claim the spreadsheet alone caused the drop unless you know it did | Your only number (F4), so it's the one a follow-up targets. EXP because it tests whether the claim holds up |
| C2 | "What did you change when you rebuilt the stock-count spreadsheet?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: say what you actually changed, in your own words, and which tool it's in. If it's Excel, say so and name what you used. If it's not Excel, name the tool. This answer is also your evidence for the advert's Excel line (F6) | Covers F4's story and F6's "confident with Excel", which no other question reaches |
| C3 | "Do you do any regular reporting on deliveries, like on-time rates or anything weekly?" | JD | [grounded] | Your material doesn't say. Answer slot: if you produce any regular delivery reporting, say what it covers, how often and who reads it, in your own words. If you don't, say so plainly, then say how you'd approach a weekly on-time dispatch figure as a plan | F5 is the advert's reporting line with no evidence either way. JD because it's a stated duty |

### D. Pressure (medium-low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "£42,000 is towards the upper end, and SAP is on our wish list. Would you come in at £38,000?" | JD | [grounded] "I'm hoping for £42,000." "Never used SAP — we run our own in-house stock system." | Pause, then hold: you're hoping for £42,000, and it's within the advertised range. Don't argue about SAP. You've already said you haven't used it. Hold through two follow-ups. Concede only what's real. Answer slot: if you've decided on a lower figure you'd accept, you can say it. If you haven't, say £42,000 is your expectation and you're happy to discuss the whole package at offer stage. Never agree to a number on the call that you haven't already decided on | Tests whether F9 holds under a light push. JD because the range is the advert's |
| D2 | "Some weeks the team might need you on site three days. Is that a problem?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Three is inside your own limit, so the honest answer follows your words: you wouldn't want more than three. If she pushes further, "and four?", hold the limit as you stated it, calmly and without apologising. Don't loosen it to keep the call friendly | Tests whether F10's limit holds. JD because the advert sets the pattern. Your stated limit is the thing to protect |
| D3 | "Thirty seconds: why should I put you forward to the hiring manager?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Three facts, in your own words, then stop: four years as a logistics coordinator; you schedule deliveries for three depots and chase suppliers when orders slip; you rebuilt the stock-count spreadsheet and discrepancies fell by about a third over a year. No "proves that I…". The facts are enough | A time-boxed pitch is a common recruiter close. EXP because it compresses F1, F3 and F4 |

### E. Case / Strategist (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier rings on Monday: a delivery due Wednesday will be two days late, and production is counting on it. What do you do?" | CASE | [generic] | Structure it out loud: what you'd confirm first (the new date, whether part of the order can come sooner), who needs to know today (planning, the warehouse), what options exist (another supplier, re-sequencing work), and how you'd follow up and record it. The question is about the future, so the answer needs no claims about your past | A live version of the advert's "chase late orders" line (F3). [generic] because it's a pattern for the problem, not a fact about Quillmoor |
| E2 | "Our weekly on-time dispatch number dropped this week. How would you work out why?" | CASE | [generic] | Clarify what counts as "on time", split the late orders by cause (stock, picking, carrier, supplier), check whether it's one big order or many, and say what you'd report and to whom. Answer as a plan | The advert's reporting duty (F5) asked as a problem. It lets you show reasoning even though C3's evidence is open |

### F. Values / Behavioural (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1q | "Tell me about a time an order slipped and you had to chase it." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Your sentence gives the pattern, not a particular occasion. Pick one real instance in advance: what slipped, what you did, how it ended, all in your own words. If no single instance comes to mind, say so plainly and describe how you usually chase a slipping order | The advert's "chase late orders" line (F3) as an open prompt. EXP first, since it tests your actual practice. ID is F1q to avoid clashing with fit row F1 |
| F2q | "Tell me about a time you had to give someone senior news they didn't want to hear." | VAL | [generic] | Selection scaffold: pick a time where something was at stake, you said it clearly, and the working relationship survived. If no such time comes to mind, say so plainly and give the nearest thing you do have, or how you would handle it | A common behavioural question. [generic] because Quillmoor's values couldn't be read (see Sources) |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Coordinate production schedules between planning, warehouse and QA | B1, A1 |
| Track supplier deliveries and chase late orders | F1q, E1, A1 |
| Keep stock records accurate | C1, C2, A1 |
| Report weekly on on-time dispatch | C3, E2 |
| 2+ years in operations or logistics coordination | A1, D3 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B2, D1 |
| Salary (advert range; Hannah's topic) | A3, D1 |
| Hybrid two days at Avonmouth (advert; Hannah's topic) | A4, D2 |
| Notice period (Hannah's topic) | A5 |
| What's prompting a move (Hannah's topic) | A2, B3 |

## Reverse questions

Hannah said she'll tell you about the team and the next steps. Have these ready for the "any questions?" slot, and drop any she has already answered.

| Question | Why it lands |
|---|---|
| "Who would I report to, and how big is the operations team?" | Builds on what she says about the team. Shows you're picturing the actual job |
| "Which systems does the team use day to day? Is it SAP?" | Raises the ERP line (B2) on your own terms, as genuine interest rather than a defence |
| "How does the two-day pattern work in practice? Are the site days fixed or flexible?" | Practical, and tells you whether the pattern fits your three-day limit |
| "What would a good first three months look like in this role?" | Shows you're thinking about delivering, and the answer helps you prepare for the next round |
| "Is this a new role or a replacement?" | Helps you understand what the role is for, and the answer is useful context for the hiring-manager stage |
| "What are the next steps, and what's the timeline?" | Practical. Only ask it if she hasn't already covered it, since she said she would |

## Prohibited claims

What this pack won't coach you to say, and why:

| Not coached | Basis | Honest form |
|---|---|---|
| Has coordinated production schedules or worked with QA | Stretched version of F2 | F2's quote as it stands: "I schedule deliveries for our three depots." Pack's note: your material says depot deliveries, not production. B1's answer slot stays inside the depots |
| Has used SAP | A gap you stated yourself, F7 | "I've never used SAP." No answer slot |
| Has ERP experience | Stretched version of F8 | F8's quote as it stands: "we run our own in-house stock system." Pack's note: your material doesn't say it's an ERP. B2's answer slot asks only what you do in it |
| Cut stock discrepancies by 33% | Stretched version of F4: drops "about" and claims the spreadsheet caused the drop | F4's quote as it stands: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." C1's answer slot covers how it was counted |
| Built the spreadsheet in Excel, or is an Excel expert | Stretched version of F6: "spreadsheet" upgraded to a named tool and skill level | F6's quote as it stands. Pack's note: your sentence says "spreadsheet". C2's answer slot asks which tool |

## Sources

- **Provided:** the advert text; Hannah Lowther's LinkedIn message; your own notes (all pasted).
- **Searches sent:** "Quillmoor Diagnostics values" (refused); "Quillmoor Diagnostics Avonmouth Bristol news" (refused); "Hannah Lowther Talent Partner Quillmoor Diagnostics" (refused). No page fetches. Nothing in this pack comes from research.
- No dossier was available.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Search refused. Would have given F2q Quillmoor's own values by name. The values cheat sheet stays dropped regardless, since Hannah's message names no values round |
| 2. Quillmoor Diagnostics interview process | skipped | Hannah's message already fixes this session: a 30-minute phone call with her, covering salary, notice period, hybrid and reason for moving, then the team and next steps. The persona weights follow it |
| 3. Quillmoor Diagnostics strategy and recent news | unavailable | Search refused. Would have moved B4 and a company-strategy question. B4 stays limited to the advert |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | Search refused. Would have moved a section on reading the interviewer and a reverse question tied to her path. Both are absent |
| 5. Representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the advert-based questions |

## Upgrade menu

- Your notice period → F11 and A5 become a settled answer instead of "check your contract"
- Your answers to the slots in B1, C1, C2 and C3 (cross-team scheduling, how the one-third was counted, the spreadsheet tool, any delivery reporting) → F2, F4, F5 and F6 carry your own words, and those rows' guidance becomes story-mapped
- Permission for web search → targets 1, 3 and 4 run: Quillmoor's values by name for F2q, company context for B4, and Hannah's public professional profile for the reverse questions
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a company briefing for the hiring-manager round that follows this one
- An earlier tuesday-dossier.md → verified evidence and a list of claims you've already ruled out, both carried into every row
