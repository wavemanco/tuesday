# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** a recruiter screen, a 30-minute phone call with Hannah Lowther (Talent Partner), Thursday at 2pm. She'll ring the mobile number on your application.
**Her stated agenda:** "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move, and then I'll tell you about the team and the next steps."

---

## How to use this pack

- **Personas** describe *how* a question gets asked: friendly, sceptical, probing, time-pressured. **Types** describe *what* is being scored.
- Type key:
  - **VAL**: behaviour against the company's published values
  - **EXP**: whether what you say about your past holds up when someone asks follow-ups
  - **JD**: the advert's stated duties and terms, including the gaps
  - **CO**: homework on the company: why here, what you know about them
  - **CASE**: a live problem from the role, solved out loud
- Provenance labels: `[grounded]` comes from something you, the advert or Hannah wrote; `[inferred]` is this pack's own working-out; `[generic]` is a standard pattern for this kind of role, not a fact about Quillmoor.
- Guidance is scaffolding, not a script. Use your own words. Wherever the guidance quotes you, that quote is the limit of what to claim.
- An **answer slot** is a spot where only you know the answer. It gives you two honest options, and both are fine to say in the interview.
- A recruiter screen sounds casual, but you're still being assessed. Hannah is checking terms, motivation and whether to pass you to the hiring manager.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material describes delivery scheduling across three depots. It doesn't describe production scheduling with planning or QA teams, so the words stay where yours are: you schedule deliveries for three depots. Answer slot: the advert's planning, warehouse and QA line makes a question about working across other teams likely. If your scheduling meant agreeing timings with other teams or sites, say which and how, in your own words. If it didn't, say so plainly and stay with the three depots |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap. This is a line from your own account with nothing to show behind it, so expect a follow-up. Lead with your own phrase, "chase suppliers when orders slip", because it already matches what the advert asks for |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, and this is your headline number, so expect probing (C1, D1). Keep "about a third" and "over a year" exactly as they are, and keep the number attached to discrepancies |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material doesn't mention reporting. Answer slot: if you produce any regular report or figures, say what's in it, how often and who gets it, in your own words. If you don't, say so plainly and say how you would approach a weekly on-time dispatch report |
| F5 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap. Four years against "2+" in the same job family. Say it plainly and don't add to it |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | Your material says spreadsheet. It doesn't say Excel, or what the rebuild involved. Answer slot: if the spreadsheet was in Excel, say so and describe what you built in it, in your own words. If it was another tool, name it and describe what you did |
| F7 | "ERP experience (SAP ...) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap you've stated yourself, and the advert lists it as a plus, not a requirement. Words: "I haven't used SAP." Then say how you'd learn it, as a plan for the future, never as something you've done. Nothing added to make the gap feel smaller |
| F8 | "ERP experience (... or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | medium | [grounded] | transferability | Words at their own scope: "we run our own in-house stock system." Don't call it an ERP. Answer slot: if asked what the system does, describe what you use it for, in your own words. If you're not sure how it compares to an ERP, say so plainly |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your figure sits inside the advertised band. State it as one number, not as a range |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | The advertised pattern meets your constraint. Your sentence has two halves: two days is fine, and you wouldn't want more than three. Don't let the second half turn into "I'm flexible" |
| F11 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material doesn't state your notice period. It's a term, not a skill, so no wording can stand in for it. Know the exact figure from your contract before Thursday |
| F12 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | No gap. It's a clear, neutral reason she will have heard many times. Say it as it is, without complaining about your current employer |
| F13 | "Quillmoor Diagnostics (diagnostic-test manufacturer, about 400 staff)" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | transferability | Your material shows logistics at a wholesaler. It doesn't show work at a manufacturer, so don't imply you've worked in manufacturing. The words stay at wholesaler scope. B3 rehearses the sector-change question |

---

## Persona table

The format of this session comes from Hannah's own message: one 30-minute call with her, and a stated agenda. The weights below rest on that, not on any documented Quillmoor interview process. That couldn't be checked, because the searches were refused (see Sources).

| Persona | How it shows up on Thursday | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport | Friendly, chatty, runs through her list | High: recruiter screens run in this register, and her four agenda items read as a checklist | A 90-second version of your background (A1), plus one-line answers ready for each agenda item |
| B. Skeptic | A quiet follow-up after you answer: "and why us specifically?", "no SAP?" | Medium-high: a reason for moving that is entirely a push (the office closing) invites "why here?", and the advert names SAP | Rehearse B1 until it bores you. Keep every bridge inside your quoted sentences |
| C. Data-Driven Prober | "How did you measure that third?" | Medium: recruiters do pick up numbers, though less deeply than hiring managers | Know what you can and can't say about how the figure was counted, and say plainly if you don't know |
| D. Pressure | "Thirty seconds: why should I put you forward?" | Low-medium: possible as a closing check before she decides on next steps | Pause, answer in three beats from your quotes, then stop |
| E. Case / Strategist | "What would you do if a supplier told you an order would be late?" | Low: more typical of a hiring-manager round, but recruiters sometimes ask one scenario | Clarify, then decide, then communicate, then record. Think out loud |
| G. Values / Behavioural | "Tell me about a time..." | Low: no values-style round is detected for this call (see Sources) | Pick a real instance from your own work. If none comes to mind, say so |
| Peer Evaluator | — | Not plausible in a one-to-one recruiter call, so no bank | — |

(Bank letters skip F so they don't clash with the fit-snapshot rows F1–F13.)

---

## Question banks

### A. Conversational / Rapport (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through what you do at the moment." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | A 90-second version in three beats, each one a sentence you've already written. First: four years as a logistics coordinator at a building-supplies wholesaler. Second: you schedule deliveries for three depots and chase suppliers when orders slip. Third: you rebuilt the stock-count spreadsheet and discrepancies fell by about a third over a year. Keep "about". Answer slot: close on what made this advert worth applying for. If specific lines in it caught your eye, name them in your own words. If it was mainly the fit with what you do now, say that plainly | Almost every recruiter call opens here. F2, F3 and F5 are your strongest rows, so they lead. EXP because she's hearing what you actually do |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | One number, said once: "I'm hoping for £42,000." Don't offer a range that starts lower, and don't apologise for it. Answer slot: if she asks whether there's flexibility, say in your own words what, if anything, would change your figure. If nothing would, say so plainly and stay at £42,000 | Her first stated topic. F9 sits inside the band, so this should be a short exchange. JD because it's a stated term of the role |
| A3 | "What's your notice period?" | JD | [grounded] | Give the exact figure from your contract. Read it before Thursday rather than guessing. Answer slot: if she asks when you could start, give the date your notice allows. If anything about the office closing affects when you'd want to leave, say only what you actually know | Her second stated topic. F11 is the one gate your material doesn't settle. JD because it's a stated screening term |
| A4 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Lead with your own words: "I live in north Bristol, so two days at Avonmouth is fine." Decide beforehand whether to volunteer your upper limit. If she asks about more days, keep both halves of your sentence: two is fine, and you wouldn't want more than three. Don't swap that for "I'm flexible", because it quietly drops the limit you set. Answer slot: if she mentions busy periods needing extra days, say honestly whether that fits within your three | Her third stated topic. F10 meets the advert, and the risk is softening your own limit to sound agreeable. JD because it's a stated term |
| A5 | "And what's prompting the move?" | JD | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say it as you wrote it: the Bristol office is closing next year, the only offer is relocating to Reading, and you don't want to. Two sentences, a neutral tone, nothing negative about your employer. Then go straight to B1's answer slot, the reason for this role rather than just any role | Her fourth stated topic. F12 is a clean, credible reason. Tagged JD, not CO, because she named it as a screening item. The real test is the follow-up in B1 |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "So is this about Quillmoor, or mainly about not going to Reading?" | CO | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | **The highest-ROI rehearsal in this pack.** Hold first: the closure is why you're looking, and you say that without apologising. Concede the specific point: yes, the closure started the search. Answer slot: why *this* role rather than any Bristol logistics job. If particular parts of the advert drew you, name which ones and why, in your own words. If it was mainly that the role matches what you do now and the location works, say so plainly; that's an ordinary, honest answer. Follow-up 1, "would you stay if they let you work remotely?": say what's true for you, and don't invent an answer you haven't thought about. Follow-up 2, "what do you know about us?": say what you know from the advert (a diagnostic-test manufacturer, about 400 staff, the Avonmouth site), and say plainly if that's all you know so far. Never claim research you haven't done | F12 is a reason that pushes you away from your current job, with nothing yet pulling you towards this one, and F13 is a sector change. So the "why here" question will come in some form. CO because it tests whether you've thought about the company |
| B2 | "I notice you haven't used SAP. How would you get on with our system?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Say it plainly first: "I haven't used SAP." Then your own scope: "we run our own in-house stock system." Then a plan, described as a plan: how you'd learn their system, for example by asking what training they offer. Don't call your in-house system an ERP or "basically the same". Answer slot: if she asks what you use the in-house system for, describe it in your own words. If you don't know how it compares, say so | F7 is a gap you stated yourself, and F8 is adjacent. The advert lists ERP only as a plus, so a calm, plain answer settles it. JD because it scores a listed requirement |
| B3 | "Your background's building supplies, and we make diagnostic tests. How would you adjust?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." | Don't claim manufacturing experience. Your words stay at wholesaler scope: four years as a logistics coordinator at a building-supplies wholesaler. Answer slot: the advert's QA line makes a question about working with quality likely. If your work involved any checks or holds before stock went out, say what, in your own words. If it didn't, say so plainly and say how you'd go about learning what QA needs from scheduling | F13 is transferability, and the sector switch is the obvious difference a recruiter will notice. JD because QA coordination is in the advert |
| B4 | "You schedule deliveries. This role coordinates production schedules with planning, the warehouse and QA. That's quite different, isn't it?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Hold at your own scope: you schedule deliveries for three depots and chase suppliers when orders slip. Concede the difference plainly: delivery scheduling isn't the same as production scheduling. Answer slot: if your scheduling meant agreeing timings with other teams or sites, describe it in your own words. If it didn't, say so and stay with the three depots. Don't borrow the advert's word "production" for your own work | F1 is the biggest stretch between the advert and your material. JD because it scores the first listed duty |
| B5 | "The role reports weekly on on-time dispatch. What reporting do you do now?" | JD | [grounded] | Answer slot: if you produce any regular figures or reports, say what's in them, how often and who gets them, in your own words. If you don't, say so plainly and say how you'd put together a weekly on-time dispatch report. Never describe a report you don't produce | F4: your material doesn't mention reporting, and the advert lists it as a duty. The question allows that you don't report now. JD because it's a listed duty |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that measured?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Keep your exact wording: about a third, over a year, and it's discrepancies that fell. Answer slots, each in your own words: how the figure was counted; what it's sensitive to; the assumption behind it you'd defend least; and which part of the fall was yours. If you don't know how it was counted, say "I don't know exactly how it was counted", which is better than a method you can't defend. Name your weakest assumption before she does | F3's figure is your only number, so it will draw questions. EXP because it tests whether the figure holds up |
| C2 | "What did you actually change when you rebuilt the spreadsheet?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Start from your words: you rebuilt the stock-count spreadsheet. Answer slot: say what you changed, in your own words. The pack doesn't know, so it doesn't suggest anything. If someone else contributed, say which part was yours | F3 is first-person ("I rebuilt") and worth telling well. The details are yours to supply. EXP because it tests what was actually yours |
| C3 | "How confident are you with Excel? What's the most involved thing you've built in it?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if the stock-count spreadsheet was in Excel, say so and describe what you built, in your own words. If it was another tool, name it, and say honestly where your Excel confidence stands. Don't list functions or features you haven't used | F6: the advert says Excel, and your material says spreadsheet. `[inferred]` because the link between the two is this pack's guess. JD because it's a listed requirement |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That third: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold what your sentence says in the first person: you rebuilt the spreadsheet. Through two follow-ups, keep going back to that. Answer slot: if other things also changed over that year, say what you know, plainly. If you don't know what else contributed, say so. Concede uncertainty about how much of the fall came from the rebuild, but never drop the rebuild itself | F3's figure is what an attribution question goes after. EXP because it tests honesty about what was yours, under pressure |
| D2 | "Thirty seconds: why should I put you through to the hiring manager?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Three beats, all from your own sentences, then stop. First: four years as a logistics coordinator. Second: you chase suppliers when orders slip, which is in the advert's own list. Third: you rebuilt the stock-count spreadsheet and discrepancies fell by about a third over a year. Don't add claims to fill the thirty seconds | F2, F3 and F5 are your rows with no gap. JD because it's a summary against the advert |

### E. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you a delivery will be late, and production needs it sooner. What do you do?" | CASE | [generic] | Structure it out loud: find out the facts first (how late, how much, whether part of the order can come early); check what production actually needs and when; tell planning and the warehouse early; look at options (part delivery, an alternative supplier, re-sequencing the schedule); then record and follow up. This is about a hypothetical, so the guidance makes no claims about your past | A live problem drawn from the advert's "chase late orders" line and its planning/warehouse/QA line. `[generic]` because it's a standard pattern for the problem, not a fact about Quillmoor |
| E2 | "The stock record and the shelf count don't match. Walk me through what you'd do." | CASE | [generic] | Recount before acting; check recent movements and paperwork; look for the cause (timing, mis-picks, a booking error); correct the record and note why; then decide whether it's a one-off or a pattern worth fixing at source. No claims about your past | A live problem from "keep stock records accurate". `[generic]` for the same reason |

### G. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time an order slipped and you had to chase it." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Your sentence says you do this, but not which time, so choose one. A good pick has a named order, who you chased, what you did, and how it ended. Use "we" for context and "I" for your part. If no single time comes to mind, say so plainly, then describe how you usually handle slipped orders | F2 is a strength, but the sentence describes a habit rather than one event. The theme comes from the advert's "chase late orders". EXP because it's a behavioural deep-dive |
| G2 | "Tell me about a time you held a position under pressure to keep a schedule on track." | EXP | [generic] | Selection scaffold: pick a time you held firm with someone, such as a supplier, a depot or a manager. It needs a clear stake, a moment you didn't give way, and a working relationship that was still intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your work does include, or how you would handle it | A persona-stem question, and none of your sentences covers it, so this is a scaffold rather than a mapped story |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Coordinate production schedules with planning, warehouse, QA | B4, B3, E1 |
| Track supplier deliveries and chase late orders | A1, G1, E1 |
| Keep stock records accurate | C1, C2, D1, E2 |
| Weekly on-time dispatch reporting | B5 |
| 2+ years in operations or logistics coordination | A1, D2 |
| Confident with Excel | C3, C2 |
| ERP (SAP or similar) a plus | B2 |
| Salary band | A2 |
| Hybrid, two days at Avonmouth | A4 |
| Notice period (Hannah's agenda) | A3 |
| What's prompting a move (Hannah's agenda) | A5, B1 |
| Diagnostic-test manufacturer context | B3, B1 |

---

## Reverse questions

When Hannah says "Any questions for me?", don't say you think she's covered everything. Pick two or three of these.

| Question | Why it lands |
|---|---|
| "Who would this role report to, and how big is the team around it?" | She said she'd tell you about the team, so this builds on her own agenda. It also tells you who the next interview is likely to be with |
| "Which ERP or stock system does the site use, and how do new starters usually get trained on it?" | Brings up your SAP gap (F7) on your terms, as a plan rather than an apology |
| "Are the two office days fixed, or does it depend on the week?" | Shows you're serious about the practical side, and tests your three-day limit (F10) without you having to raise it |
| "What does the weekly on-time dispatch report get used for, and who sees it?" | Shows you read the advert closely and tells you what that duty really involves (F4) |
| "What would a good first three months look like in this role?" | Gives you the hiring manager's likely priorities to prepare for the next round |
| "What are the next steps, and roughly what's the timeline?" | Your notice period and the office closure date make the timing matter to you, and she said she'd cover it, so this lets her |

---

## Prohibited claims

What this pack won't coach you to say, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP | A negative you stated, F7 | Your plain acknowledgment: "I haven't used SAP." Then your sentence at its own scope: "we run our own in-house stock system." No answer slot needed |
| Has ERP experience (the in-house system described as an ERP) | Inflated form of F8 | F8's words at their own scope: "we run our own in-house stock system." The limit is this pack's observation, not a line for you: your material says in-house stock system, not ERP |
| Coordinated production schedules with planning and QA | Inflated form of F1 | F1's words at their own scope: you schedule deliveries for three depots. The limit is the pack's observation: your material says deliveries and depots, not production with planning and QA. B4's answer slot stays within your depot scheduling |
| Cut stock errors by a third / made stock records accurate | Inflated form of F3 | F3's sentence exactly: discrepancies fell by about a third over a year, after you rebuilt the stock-count spreadsheet. Keep "about", keep "over a year", and keep the figure attached to discrepancies |
| Manufacturing or production experience | Inflated form of F13 | F13's words at their own scope: four years as a logistics coordinator at a building-supplies wholesaler |
| Fully flexible on office days | Contradicted by F10 | F10's sentence: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." |

---

## Sources

**Provided documents:** Hannah Lowther's LinkedIn message (as you quoted it); the Quillmoor Diagnostics advert (as pasted); your notes about yourself.

**Searches sent:**
- `Quillmoor Diagnostics values`: refused (permission not granted)
- `Quillmoor Diagnostics Avonmouth Bristol news`: refused (permission not granted)
- `Hannah Lowther Talent Partner Quillmoor Diagnostics`: refused (permission not granted)

No dossier was provided.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The search was refused. A values page would have given B1's "why here" follow-up and the reverse questions something real to refer to, and could have themed VAL questions |
| 2. `Quillmoor Diagnostics interview process` operations | skipped | Hannah's message already establishes this session: a 30-minute phone call with her and a stated agenda, which fixes the persona weights. It names no values-style round, so none is detected |
| 3. `Quillmoor Diagnostics` strategy / recent news | unavailable | The search was refused. It would have given B1 and the reverse questions a current company fact. Without it, there's no CO question grounded in strategy, and E1 and E2 stay `[generic]` |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | The search was refused. Her public professional profile would have added a section on reading the interviewer and a reverse question tied to her own career path |
| 5. representative Operations Coordinator JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Your notice period → F11's gate settled, and A3's guidance becomes a ready one-line answer
- Approving web search → a researched values page and recent news for B1's "why here" follow-up, a CO question grounded in the company's strategy, and Hannah's public professional profile for a tailored reverse question. A deeper pass is also available (up to 6 more searches and 2 more fetches, several more minutes) for a strategy brief before the hiring-manager round
- Your CV → checks whether it says anything your notes don't, which would turn F4 and F6 from answer slots into mapped stories, and lets you make sure what you say on the call matches what Hannah has in front of her
- Your answers to the answer slots in A1, B1, B4, B5, C1 and C3 (said outside a drill) → upgrades F1, F4, F6 and F3's defend-the-number rows from slots to quoted evidence
- How long you have to prepare before Thursday → a short prioritised prep schedule tied to question IDs
- A `tuesday-dossier.md` from an earlier job-evaluation session → the main objection taken from verified evidence rather than inferred, and a ready-made list of claims to avoid
