# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** Recruiter screen. A 30-minute phone call, Thursday at 2pm.
**Interviewer:** Hannah Lowther, Talent Partner (recruiter). She will ring the mobile number on your application.
**Her stated agenda:** your salary expectations, your notice period, how the hybrid pattern would work for you, and what's prompting a move. Then she tells you about the team and the next steps.

---

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what it is scored on.
- Type key:
  - **VAL**: behavioural. Do your past actions show how you work?
  - **EXP**: work-experience deep-dive. Does what you said survive a follow-up, and what part was actually yours?
  - **JD**: role-driven. Can you do the job in the advert, gaps included?
  - **CO**: company knowledge. This pack has none, because the company search could not run (see Sources).
  - **CASE**: a live problem from the role, answered on the spot.
- Provenance labels: `[grounded]` comes from what you or the advert said. `[inferred]` is this pack's own derivation, and the derivation is named. `[generic]` is a pattern for roles like this one and makes no claim about Quillmoor.
- The guidance is scaffolding, not a script. Wherever it quotes you, those are your own words. Wherever it says **Answer slot**, the pack does not know the answer, so you supply it from your own experience, or say plainly that it doesn't apply.
- On a recruiter call, the first five questions (bank A) are close to certain because Hannah listed them. Rehearse those out loud first, then B1.

---

## Fit snapshot

Requirements are quoted from the advert and from Hannah's message. Evidence is quoted from your message, word for word.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material shows delivery scheduling for three depots, not production schedules across planning, a warehouse and QA. The words stay at that scope: "I schedule deliveries for our three depots." Answer slot: the advert's planning/warehouse/QA line makes a probe on who you coordinate with likely. If your scheduling means working across other teams or people, say which and how, in your own words. If it doesn't, say so plainly and stay with the three depots |
| F2 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap. This is an example you gave yourself, so expect a follow-up asking for one. Lead with your own words: "I chase suppliers when orders slip" |
| F3 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | Chasing slipped orders touches tracking, but your material doesn't say how you know an order has slipped. Answer slot: if you keep track of supplier deliveries in some way, say how, in your own words. If you don't, say so plainly and return to chasing suppliers when orders slip |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, and your strongest line. Keep its exact form: "about a third", "over a year", and "discrepancies fell" after you rebuilt the spreadsheet. The figure raises the defend-the-number slots (C2) |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material says nothing about reporting. Answer slot: if you report on deliveries or dispatch in any form, say what, how often and to whom, in your own words. If you don't, say so plainly and say how you would approach a weekly report |
| F6 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap. Say it as it is: four years as a logistics coordinator at a building-supplies wholesaler |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | Your material says spreadsheet, not Excel, so the pack doesn't assume Excel. Answer slot: if the spreadsheet was in Excel, say so and describe what the rebuild involved, in your own words. If it was a different tool, name it |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | You stated this gap yourself, and no wording closes it. Words: "I haven't used SAP." Anything after that is a plan for learning it, said as a plan and never as past experience. It is listed as "a plus", not a requirement |
| F9 | "or similar" (the ERP line) — advert | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | discovery | Your material says your firm runs an in-house stock system. It doesn't say what you do in it, or whether it works like an ERP. Answer slot: if you use that system day to day, describe what you do in it, in your own words, and let Hannah decide whether that counts as "similar". If your use is light, say so plainly |
| F10 | "£38,000–£44,000" — advert; "your salary expectations" — Hannah's message | "What I'd tell her: I'm hoping for £42,000." — your message | high | [grounded] | none | Your figure sits inside the advertised range. Keep it as you stated it: a figure you're hoping for. The pack doesn't raise it, lower it, or turn it into a floor |
| F11 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert; "how the hybrid pattern would work for you" — Hannah's message | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | The advertised pattern fits what you said. Keep both halves of your sentence intact: two days is fine, and more than three is not something you'd want |
| F12 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material doesn't establish your notice period, and Hannah named it on her agenda |
| F13 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | high | [grounded] | none | No gap. It is a clear, neutral reason. Say it as you said it. The only follow-up risk is the "why us" half, which your material doesn't cover (B1) |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B3, E1, F2 |
| Track supplier deliveries | C4, E1 |
| Chase late orders | C4, E1, F1 |
| Keep stock records accurate | C1, C2 |
| Report weekly on on-time dispatch | E2, B4 |
| 2+ years in operations or logistics coordination | A1 |
| Confident with Excel | C3 |
| ERP experience (SAP or similar) a plus | B2, D1 |
| Salary | A3 |
| Hybrid pattern | A5, D2 |
| Notice period | A4 |
| What's prompting a move | A2, B1, D2 |

---

## Reading the interviewer

Built only from Hannah's own message. The search for her public profile could not run (see Sources), so the pack says nothing about her background.

- **Her agenda is mostly terms and motivation.** Three of her four items (salary, notice, hybrid) are terms with a single clear answer, and the fourth is your reason for moving. Know each answer cold so the call doesn't stall on any of them.
- **It's a phone call, so your voice carries everything.** She can't see notes, so keep them in front of you: your four agenda answers, plus F4's line.
- **She'll tell you about the team and next steps afterwards.** Use your reverse questions on things her overview is unlikely to cover in detail: the ERP, how dispatch is measured, which office days.
- **She gave you a channel.** "If anything changes, message me here." If you can't confirm your notice period on the call, that's where you follow up.

## Persona table

| Persona | How it shows up on this call | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly run through her four agenda items, plus "tell me about yourself" | High. A recruiter screen leans conversational, and Hannah listed her topics in advance | Have a short, crisp answer ready for each of her four items. Treat every casual question as scored |
| Skeptic | Gentle "why us, not just why leave", and SAP and production-scheduling checks | Medium. Recruiter screens include a light skeptic check, and the gaps in F1 and F8 are what she can test from the advert | Rehearse B1 until it's boring. Say the SAP gap plainly, then give a plan |
| Data-Driven Prober | "About a third of what?" on the spreadsheet figure, plus Excel confidence | Low-medium. A recruiter may ask lightly, and a hiring manager later will ask hard. F4 is your only figure | Know what you can and can't say about how the figure was counted. Say plainly what you don't know |
| Pressure | "Why you over someone with SAP?" or a hypothetical on Reading | Low. Unusual on a recruiter screen, but cheap to rehearse | Pause, keep to your own words, concede the real gap, and don't fold on the rest |
| Case / Strategist | A quick "what would you do if…" on a late delivery | Low. More likely in a hiring-manager round, but the advert makes it easy to ask | Clarify first, then the steps, then who you'd tell |
| Values / Behavioural | "Tell me about a time…" questions themed on the advert | Low. No published values were found, and Hannah's agenda doesn't mention them | Pick a real example, or say plainly that none comes to mind |

---

## Question banks

### A. Conversational / Rapport Builder (highest weight: her agenda)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through what you do now." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | About 60 to 90 seconds, in your own words. Four years as a logistics coordinator at a building-supplies wholesaler. You schedule deliveries for your three depots and chase suppliers when orders slip. Then the spreadsheet: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. End there and let her steer | The usual opener, and the place to land F2, F4 and F6 early. EXP because it sets up everything she might follow up on |
| A2 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | On her agenda, so it's nearly certain. Say it plainly, close to your own words: the Bristol office is closing next year, the only offer is relocating to Reading, and you don't want to relocate. Keep it neutral about your current employer. Answer slot: she may follow with what draws you to this role. If something about the role or Quillmoor drew you, say what, in your own words. If it was mainly that it's in Bristol and matches the work you do, say that plainly. B1 is the deeper rehearsal | F13 is a clean reason, and she named it. EXP because it checks that your reason holds together |
| A3 | "What are your salary expectations?" | JD | [grounded] "What I'd tell her: I'm hoping for £42,000." | Give the number you stated: "I'm hoping for £42,000." Then stop. It sits inside the advertised £38,000 to £44,000, so you don't need to justify it. Answer slot: if she asks about your current salary, share it if you're comfortable. If you'd rather not, say you'd prefer to focus on what you're looking for in this role. If she asks whether you're flexible, answer as you actually feel. This pack doesn't move your figure | F10. On her agenda, and the advert range is public. JD because pay is a stated term of the role |
| A4 | "What's your notice period?" | JD | [grounded] | Your material doesn't establish this (F12). Answer slot: give your contractual notice as your contract states it. If you're not sure, say so, and tell her you'll confirm and message her on LinkedIn the same day. If the office closure date or anything around it affects when you could start, say what you actually know. If nothing is settled, say so plainly | F12 is the one agenda item the pack can't fill. JD because it's a term the role needs settled |
| A5 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Say it as you said it: you live in north Bristol, so two days at Avonmouth is fine. If she asks whether you could do more, give your limit in your own words: you wouldn't want more than three. Keep both halves; don't soften the limit into "I'm flexible" | F11. On her agenda. JD because it's a stated term. The risk is trading away your limit on a friendly call |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "So is this about us, or would any job in Bristol do?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | **Highest-ROI prep in this pack.** Hold on what's true: the closure is what started your search, and you say so plainly, in your own words. Don't dress it up as a long-planned career move. Answer slot for the "why us" half: if something specific about this role or Quillmoor appeals, say what, in your own words. If you don't yet know much about them, say so and name what you'd want to find out. Follow-up 1, "Would you have stayed if the office weren't closing?": answer as it actually is. If probably yes, say so and say the closure is what changed. If no, say why in your own words. Follow-up 2, "Why a manufacturer rather than another wholesaler?": answer slot, your own reason or a plain "I'm open to either; this one matched what I do". Concede only what's real, and never fake enthusiasm for details you don't have | A move triggered by a closure invites a push-versus-pull check, and Hannah has already put "what's prompting a move" on the agenda (F13). F13 shows the push, and your material shows no pull, which is where the pack would be most tempted to write one for you. EXP because it tests whether your story holds together |
| B2 | "You haven't used SAP. How would you get up to speed?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Plain acknowledgment first: "I haven't used SAP. We run our own in-house stock system." Answer slot: if you use that system day to day, say what you do in it, in your own words. If your use is light, say so. Then a plan, said as a plan: ask which system Quillmoor runs, and how new starters are trained on it. Don't call yourself a fast learner as if it were evidence | F8 is a gap you stated, and F9 is the possible bridge. It's "a plus", so a calm answer neutralises it. JD because it's scored against the advert line |
| B3 | "Your scheduling is deliveries for depots. Here it's production schedules between planning, the warehouse and QA. How does that translate?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Hold only what the quote carries: "I schedule deliveries for our three depots, and I chase suppliers when orders slip." Answer slot: if your scheduling involves working across other teams or people, say which and how, in your own words. If it doesn't, say so plainly, and say what you'd want to learn first about how planning, the warehouse and QA hand work to each other | F1 is the biggest gap between your material and the advert's first line. JD because it scores the headline responsibility |
| B4 | "Which part of this job would be newest to you on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Name one honestly; it's a credibility question. The pack can see SAP (F8), production scheduling with QA (F1) and weekly dispatch reporting (F5) as possible answers. On SAP: "I haven't used SAP." On scheduling: "I schedule deliveries for our three depots." Answer slot on reporting: if you already report on deliveries in some form, say what; if not, say so. Pick the one that's truly newest, and say how you'd get on top of it, as a plan | A standard skeptic opener, and it covers F5, which nothing else in your material touches. JD because the answer is measured against the advert |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about the stock-count spreadsheet you rebuilt." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Beats from your sentence: you rebuilt the stock-count spreadsheet, and over a year discrepancies fell by about a third. Answer slot: say what the rebuild involved, in your own words. If others worked on it with you, or other changes happened that year, say so plainly. Describe what you did and let her draw the conclusion; don't tell her what it proves | F4 is your headline result and the advert's stock-accuracy line points straight at it. EXP because it checks what was actually yours |
| C2 | "About a third: about a third of what, and how was it counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Defend-the-number slots, all in your own words. How it was counted: say what was compared with what, if you know. What it's sensitive to: anything that could have moved it. The assumption behind it you'd defend least: name it before she does. Which part was yours. "I don't know exactly how it was counted" is an honest answer. Keep "about" and "over a year"; never round it to an exact percentage | Every figure on a CV gets this probe sooner or later, and F4 is your only one. EXP because it tests the precision of the claim |
| C3 | "How confident are you with Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if the stock-count spreadsheet was in Excel, say so, then describe what you built or changed, in your own words, and rate your confidence honestly. If it was a different tool, name it, and say what you've done in Excel, if anything. Don't name functions or features you haven't used | F7. "Confident with Excel" is a stated requirement, and the pack can't tell whether your spreadsheet was Excel. JD because it's scored against the advert |
| C4 | "How do you keep track of supplier deliveries day to day?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Start from what's stated: you chase suppliers when orders slip. Answer slot: if you track deliveries in some way, say how you know an order has slipped, in your own words. If you don't track them as such, say so plainly and describe how slipped orders come to your attention. If she asks how many orders or suppliers, give a rough figure only if you know one, and call it approximate | F2 and F3. The advert pairs tracking with chasing, and your material shows only the chasing. JD because it maps to a listed duty |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who's already used SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." "4 years as a logistics coordinator at a building-supplies wholesaler." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Pause, then hold on what you said: four years as a logistics coordinator, and you rebuilt the stock-count spreadsheet, after which discrepancies fell by about a third over a year. Concede plainly: "I haven't used SAP." Point out it's listed as a plus, then leave the comparison to her. If she pushes a second time, stay calm and restate. Don't fold on the four years or the spreadsheet | F8 under pressure. Hold-then-concede practice on your one stated gap. JD because the comparison is against the advert's ERP line |
| D2 | "If your firm offered you more money to go to Reading, would you go?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | A hypothetical, so answer as you actually feel. Your stated position is that relocating to Reading is something you don't want. If that holds whatever the money, say so in a sentence and move on. If the truthful answer is different, give it. It's your answer, and the pack won't script it | Tests whether F13 is a firm reason or a negotiating position. EXP because it checks your motivation |

### E. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you a delivery will be three days late, and production is scheduled around it. What do you do?" | CASE | [generic] | Structure: confirm the facts and the new date. Work out what it affects on the schedule, and tell planning. Look at the options: is there anything to bring forward, a partial delivery, another source. Tell the warehouse, and QA if their checks are affected. Record it and follow up with the supplier. This is a live problem, so the guidance makes no claim about your past. If you'd like to add how you handle slipped orders now, use your own words: "I chase suppliers when orders slip" | The advert pairs chasing late orders with production schedules across planning, the warehouse and QA. `[generic]` because it's a pattern for the problem, not a fact about Quillmoor's process |
| E2 | "Our weekly on-time dispatch figure dropped. How would you find out why?" | JD | [generic] | Clarify first: what counts as on time, and against which date. Then split it: which orders were late, and where they slipped (supplier, production, QA release, the warehouse, the carrier). Find the biggest bucket first, then report what you found and what you'd change. No claim about your past is needed | Covers the "report weekly on on-time dispatch" line (F5). JD because the content is that duty; asked as a case because your material has no reporting example |

### F. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time a supplier order slipped and you had to tell someone it would be late." | VAL | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Your sentence says you chase suppliers when orders slip, but it doesn't name a specific occasion, so choose one. It needs a real order, who you had to tell, and what happened next. If no particular time comes to mind, say so plainly, then describe how you chase suppliers when orders slip, or how you would handle telling someone | Themed on the advert's "chase late orders". VAL because it scores how you behave, though no published Quillmoor values were found |
| F2 | "Tell me about a time two people or teams wanted different things from a schedule." | VAL | [generic] | Selection scaffold: pick a time you scheduled around competing needs. It needs the two sides, the decision, and how you kept both working with you. If no such time comes to mind, say so plainly, then say how you would handle it between planning, the warehouse and QA | Themed on the advert's coordination line (F1). `[generic]` because your material carries no such story, so the guidance is a selection scaffold |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which ERP or stock system does the team use, and how do new starters usually learn it?" | Raises F8 on your terms, as a learning plan, and gets you a fact you need |
| R2 | "How is on-time dispatch measured at the moment, and who sees the weekly report?" | Shows you read the advert closely, and tells you what F5 really involves |
| R3 | "Are the two Avonmouth days fixed, or chosen week to week?" | Practical, and it checks the pattern against your limit in F11 without reopening it |
| R4 | "Is this a new role or a replacement, and what would a good first three months look like?" | Tells you why the job exists and what you'd be judged on |
| R5 | "How do planning, the warehouse and QA work together day to day, and where does this role sit between them?" | Goes straight at F1, the part of the job most different from your current role |
| R6 | "What are the next stages, and roughly what's the timeline?" | She'll cover next steps, so ask this only if she doesn't. You need it to line up with your notice period (F12) |

Never answer "any questions for me?" with "I think you've covered everything."

---

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP, or has ERP experience | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't used SAP." What you do in the in-house system stays an answer slot (B2) |
| Coordinates production schedules with planning, a warehouse and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation, not words for you to say: your material says delivery scheduling, not production scheduling. B3's slot stays inside the depots |
| Cut stock discrepancies by 33% single-handedly | Inflated form of F4 | F4's quote as stated: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. Keep "about", keep "fell", and keep "over a year" |
| Leaving purely for career growth | Contradicted by F13 | F13's quote: "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." |
| Happy with any office pattern | Contradicted by F11 | F11's quote: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." |

---

## Sources

**Provided documents:** the Quillmoor Diagnostics Operations Coordinator advert (pasted), Hannah Lowther's LinkedIn message (pasted), and your own background notes (your message).

**Searches sent:**

- `Quillmoor Diagnostics values`: refused (permission not granted)
- `Quillmoor Diagnostics Avonmouth Bristol news`: refused (permission not granted)
- `Hannah Lowther Talent Partner Quillmoor Diagnostics`: refused (permission not granted)

**Fetches sent:** none.

No dossier was used.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Refused. Would have supplied published values to theme the VAL questions by name. Bank F stays advert-themed |
| 2. `Quillmoor Diagnostics interview process operations` | skipped | Hannah's message already fixes this session: one 30-minute phone call with her, with her agenda stated. Persona weights follow that |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | Refused. Would have supplied a CO question and current context for B1's "why us" half. The pack has no CO bank |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Refused. Would have supplied her public career pattern for the interviewer read and a reverse question tied to her path |
| 5. Representative Operations Coordinator JD | skipped | You supplied the advert, which fixes the fit snapshot and the JD questions |

---

## Upgrade menu

- Your notice period → F12 and A4 become a settled answer, and R6 can be checked against it
- Allow web search, so the three refused searches can run → company values for bank F, current news for a CO question and B1's "why us" half, and Hannah's public profile for the interviewer read and a tailored reverse question
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a short Quillmoor grounding brief and a "why Quillmoor" answer built on real facts. Only useful once search is allowed
- What draws you to Quillmoor or this role, in your own words → B1 and A2 get a quoted "why us" half instead of an answer slot
- Whether the stock-count spreadsheet is in Excel, and what the rebuild involved → F7 and C3 become grounded, and C1 gets more beats
- Whether and how you track supplier deliveries, and whether you report on dispatch → F3 and F5 move from discovery to a stated answer, upgrading C4, B4 and E2
- What you do in the in-house stock system → F9 becomes a bridge for B2 and D1
- The spreadsheet itself, or its before-and-after discrepancy counts, to have in hand → F4 rises from medium to high for the later hiring-manager round
- A tuesday-dossier.md from job-underwriter → the main objection and the prohibited list would come from verified evidence rather than being built here; this pack is complete without it
