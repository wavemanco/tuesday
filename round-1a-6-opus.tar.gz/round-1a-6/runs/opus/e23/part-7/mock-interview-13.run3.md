Reading the last few rule files from the prep skill, then I'll build your pack.
I've written your prep pack for Thursday's call with Hannah. It's built from her message, the advert and your notes. Web searches about Quillmoor and Hannah were declined, so the "why Quillmoor?" answer and your questions for her are general rather than company-specific.

The pack covers her four topics:

- **Salary:** "I'm hoping for £42,000." It's inside their £38,000–£44,000 range, so say it once and stop. Decide before the call whether there's a lower figure you'd accept.
- **Hybrid:** "Two days at Avonmouth is fine — I live in north Bristol." If she asks about more, give your limit as you said it: no more than three. Don't let it slide into "I'm flexible".
- **Notice period:** your notes don't give it, so check your contract before Thursday.
- **Why you're moving:** say it plainly and early. The office is closing, the only offer is Reading, and you don't want to relocate.

**What to rehearse most:** "If your office weren't closing, would you still be looking?" Your reason for leaving is real but it was forced on you. Don't make up a career-growth story to cover it. Answer honestly, then point to what you already do that matches the advert: chasing late orders and keeping stock records.

**The other likely probes:**
- **SAP:** say plainly that you haven't used it, and don't call your in-house system an ERP.
- **Manufacturing:** you schedule deliveries for depots, not production with planning and QA, so describe it that way.
- **The "about a third" figure:** keep "about", and know how it was counted, or say that you don't know.

There are 18 practice questions in all, plus six questions for you to ask her.

If "Thursday" means today (26 November), rehearse the four topics and the moving question first.

Files are in /var/tmp/tuesday-measure/1a6/runs/opus/e23/part-7/rooms/case-13-denied-db689337:
- quillmoor-diagnostics_operations-coordinator_interview_pack.md

I can play Hannah and run the "would you still be looking?" question with live follow-ups.
I can also save a tuesday-dossier.md recording the gaps this prep found, for you to use in later rounds.
If you'd like the pack as a Word document, I can convert it.

What's your notice period, and does the office closure change when you could start? Your answer fills in the one agenda item your notes don't cover.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Recruiter screen prep: Operations Coordinator, Quillmoor Diagnostics

- **Call:** Thursday, 2pm. A 30-minute phone call with Hannah Lowther, Talent Partner (recruiter). She will ring the mobile number on your application.
- **Her agenda, in her words:** "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move", then "the team and the next steps".
- **Date check:** this pack was written on Thursday 26 November 2026. If the call is today, rehearse A2 to A5 and B1 first. Everything else is insurance.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. On a recruiter call the tone is friendly, but every answer is still noted and passed to the hiring manager.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour matches the company's published values |
| EXP | Whether what you say about your experience holds up when probed, and what was actually yours |
| JD | Whether you can do the job in the advert, gaps included |
| CO | How much you know about the company and what it's doing |
| CASE | How you structure a live problem from the role |

The guidance is scaffolding, not a script. Say it in your own words. Where a cell gives an **answer slot**, only you know the answer. Give whichever branch is true.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material describes delivery scheduling for depots. It doesn't mention production schedules, planning or QA, and the words should stay at that scope: "I schedule deliveries for our three depots." Answer slot: the advert's planning/warehouse/QA line makes a probe on cross-team coordination likely. If your scheduling involves agreeing timings with other teams, say which teams and how, in your own words. If it doesn't, say so plainly and stay with the depot scheduling |
| F2 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap. It's in your own words, with nothing to inspect behind it, so expect a "tell me about that" probe. Lead with the plain verb: you chase suppliers when orders slip |
| F3 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | Chasing a slipped order touches tracking, but your material doesn't show how you know an order has slipped. Answer slot: if you keep a log, a sheet or a system view of what's due, say what it is and how you use it. If you don't, say so plainly and describe how slips reach you |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, and it's your one figure, so expect a probe on it (D1). Keep "about" and keep the sentence's "and". It says you rebuilt the sheet and discrepancies fell. It doesn't say how much of the fall the sheet caused, so leave that to D1's slot |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material says nothing about reporting. Answer slot: if you report on whether deliveries go out on time, say what, how often and to whom. If you don't, say so plainly and say what you would track first |
| F6 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap. Four years against two, in the same job family. State it and move on |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | A rebuilt spreadsheet touches Excel, but your material doesn't name the tool or what you built in it. Answer slot: if it was Excel, say so and name what you used in it, in your own words. If it was another tool, name it plainly |
| F8 | "ERP experience (SAP or similar) a plus" — advert, the SAP half | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | You stated this gap, and no wording can close it. Words: "I haven't used SAP." Then how you would learn it, said as a plan and never as a past. The advert calls it a plus, not a requirement, so there's no need to apologise for it |
| F9 | "ERP experience (SAP or similar) a plus" — advert, the "or similar" half | "Never used SAP — we run our own in-house stock system." — your message | medium | [grounded] | transferability | Your material says an in-house stock system. It doesn't say ERP, and the words stay there: "We run our own in-house stock system." Answer slot: if asked what you do in it, describe the tasks you actually use it for, in your own words. If your use is limited to stock, say so |
| F10 | "£38,000–£44,000" — advert; "your salary expectations" — Hannah | "I'm hoping for £42,000." — your message | high | [grounded] | none | Gate met: £42,000 sits inside the advertised range. Words: "I'm hoping for £42,000." Say it once, then stop talking |
| F11 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert; "how the hybrid pattern would work for you" — Hannah | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Gate met. Words: "Two days at Avonmouth is fine — I live in north Bristol." Keep your limit as you stated it if more days come up: "I wouldn't want more than three." Don't turn it into "I'm flexible" |
| F12 | "your notice period" — Hannah | none given | none | [grounded] | hard_gate | Your material does not establish your notice period |
| F13 | "what's prompting a move" — Hannah | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | high | [grounded] | none | No gap. It's a clear, unembarrassing reason. Words: "Our Bristol office is closing next year, and the only offer is relocating to Reading, which I don't want." Say it early and plainly |
| F14 | A reason for wanting this company and role, beyond leaving the current one | none given | none | [generic] | discovery | What strong looks like: one true, specific thing about this role or company, such as a line of the advert that matches your work, the site or the sector. Pick one that's true for you. If nothing beyond the fit and the location comes to mind, say that plainly and give those two |

## Persona table

The loop for this session is set by Hannah's own message: one 30-minute phone call with her, covering the agenda quoted above. The weights below come from that message and the recruiter-screen prior. They aren't based on research into Quillmoor's process, because research couldn't run (see Sources).

| Persona | How it shows up on this call | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly openers, her four logistics items, "tell me about yourself" | High. A recruiter screen's dominant register, and her agenda is mostly logistics and motive | A 90-second arc built only from your sentences (A1). Treat every casual question as scored |
| Skeptic | Quiet follow-ups on why you're moving, SAP, wholesale against manufacturing | High. The prior pairs light Skeptic with Conversational, and she named "what's prompting a move" herself | Rehearse B1 until it's boring. Bridge only from adjacent things you actually said, and name limits plainly |
| Pressure | A push on salary or office days | Mid. Your number and day limit are both inside what the advert states, so a recruiter may test how firm they are | Hold your stated line through two follow-ups. Decide any concession before the call, not during it |
| Data-Driven Prober | "How was that counted?" on your one figure | Mid. Recruiters rarely probe deeply, but F4's figure is the line she's most likely to repeat to the hiring manager | Know what you can and can't say about how "about a third" was counted, and say so if you don't know |
| Case / Strategist | A quick "what would you do if…" | Low. Uncommon on a recruiter screen, more likely with the hiring manager | Clarify, then prioritise, then act, then communicate. Think aloud |

Not included: Values/Behavioral, because no source names a values round and her agenda has none; and Peer Evaluator, because this isn't a peer conversation.

## Question banks

**Highest-ROI prep in this pack: B1.** Hannah named your reason for moving as a topic, and your reason is something done to you, not something you chose. The follow-up "would you still be looking?" is the most predictable objection, and a calm answer to it settles the rest of the call.

### A. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, tell me a bit about yourself and what you do now." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | 90 seconds, three beats, each one straight from your sentences. Who you are: four years as a logistics coordinator at a building-supplies wholesaler. What you do: schedule deliveries for three depots and chase suppliers when orders slip. One result: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. Keep "about". Stop there and let her pick what to follow | The opener on almost every recruiter call. It sets up F2, F4 and F6, the three rows with no gap. EXP because she's checking that the summary matches your application |
| A2 | "And what's prompting the move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say it straight, in one breath, with no apology and nothing against your employer: the Bristol office closes next year, the only offer is Reading, and you don't want to relocate. Then one bridge sentence. Answer slot: if something in this advert drew you beyond location, name it in your own words. If location and the overlap with your current work are the reason, say that plainly | Hannah named it. F13 is a reason recruiters hear often and accept, provided it's said without drama. EXP because it tests whether the motive holds together |
| A3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | "I'm hoping for £42,000." Then stop. It's inside the advertised range, so it needs no justifying. Answer slot: if she asks whether there's room, decide before Thursday whether you have a lower figure you'd accept. If you do, you can say you're happy to talk about the whole package. If £42,000 is your floor, say so plainly. If she asks your current salary, answer only as far as you've decided to | A gate she named. F10 is met, so the only risk is wavering. JD because pay is a stated term of the advert |
| A4 | "How would the hybrid pattern work for you, two days at Avonmouth?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | "Two days at Avonmouth is fine — I live in north Bristol." That answers the question asked. If she asks about more days, give your limit in your own words as you stated it: you wouldn't want more than three | A gate she named. F11 is met. JD because it's the advert's stated pattern |
| A5 | "What's your notice period?" | JD | [grounded] | Answer slot: check your contract before Thursday and give the notice period as it stands. If the office closure affects when you could leave, say what you know, plainly. If you don't know yet, say you'll confirm by message, and then do | A gate she named, and F12 is the one row your material can't answer yet. JD because start date is a hiring term |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "If your office weren't closing, would you still be looking?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | The deepest rehearsal here. Name the limit first, before she does: your reason is the closure. Don't invent a career-growth story to cover it. Answer slot: if you were already thinking about moving, say so and why, in your own words. If you weren't, say so plainly. Then return to the role: the advert's late-order chasing and stock-records lines are things you already do (F2, F4). Follow-up 1, "so this is about staying local?": hold. Staying in Bristol is a reason, not an apology. Follow-up 2, "what if a closer job comes up?": answer slot. Say honestly how you're approaching your search. Never promise exclusivity you don't mean | F13 is honest but entirely push, with no pull. A recruiter is checking whether you'll accept and then stay. EXP because it tests whether your motive survives a second question |
| B2 | "Have you used SAP, or another ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Say the gap plainly: "I haven't used SAP." Then the quote's second half: "We run our own in-house stock system." Answer slot: if she asks what you do in it, describe the tasks you actually use it for. If it's mostly stock, say so. Then a plan, not a past: how you'd get up to speed, and that you'd ask what training is usual (R2). Don't call the in-house system an ERP | The advert names it, so a recruiter checklist will too. F8 is a stated gap and F9 is adjacent. JD because it scores a stated plus |
| B3 | "Your background's in wholesale, and we're a manufacturer. Have you worked with production planning or QA?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Stay at your sentences' scope: four years at a building-supplies wholesaler, scheduling deliveries for three depots and chasing suppliers. Answer slot: if your scheduling involves agreeing timings with other teams, say which teams and how. If it doesn't, or if planning and QA are new to you, say so plainly and stay with the depot scheduling. Don't describe depot deliveries as "production schedules" | F1 is the widest gap between your sentences and the advert's first line. JD because it scores the headline responsibility |
| B4 | "Why Quillmoor, and why diagnostics?" | CO | [generic] | Selection scaffold: pick one true, specific reason, such as an advert line that matches your work, the Avonmouth site from north Bristol, or the work itself. If nothing beyond the fit and the location comes to mind, say that plainly and give those two. Don't fake enthusiasm for diagnostics. If you've read something about the company yourself, use it only if you can repeat it accurately | F14. CO, but generic, because the company research couldn't run (Sources), so this pack holds no facts about Quillmoor |
| B5 | "Which part of this job would be newest to you?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Pick the one that's true for you and name it before you soften it. The pack's reading is that SAP (F8), and planning and QA (F1), sit furthest from your sentences, with weekly dispatch reporting (F5) unshown. If SAP is it, you can say "I haven't used SAP." Then one line of plan. Calibrated candour beats "nothing, really" | A stock Skeptic question. F1, F5 and F8 are where an honest answer is ready-made. JD because it scores self-assessment against the advert |

### C. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "£42,000 is towards the top of our range. Would you consider £38,000?" | JD | [grounded] "I'm hoping for £42,000." | Hold, then concede only what you decided beforehand. Pause, then repeat your number: you're hoping for £42,000, and it's within the advertised range. Hold through two follow-ups. Answer slot: if you've decided on a lower figure you'd accept, you can say you're open to talking about the full package. If not, say plainly that £42,000 is what you're looking for. "I'd want to think about that" is always an acceptable answer | F10. Recruiters sometimes test how firm a number is. JD because pay is a stated term |
| C2 | "There'll be weeks we need you on site more than two days. Is that a problem?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Hold your stated line. Two is fine, and you wouldn't want more than three. Answer slot: if occasional extra days are fine with you, say so and how often. If they aren't, say so plainly. Don't trade away the limit on the call to sound easy-going | F11. The limit is a constraint you stated, so the risk is softening it under friendly pressure. JD because it's the stated work pattern |
| C3 | "So really, you're applying because you don't want to go to Reading?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | B1 asked sharply. Pause and don't defend. Concede the true part in the quote's words: the office is closing, and you don't want Reading. Then hold the second half: you're applying for this role because its lines match what you do (F2, F4, F6). Don't overclaim keenness to compensate | F13 under pressure. EXP because it tests whether your motive stays calm under a challenge |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You mention discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Keep "about a third" and "over a year". Answer slot, four parts, each in your own words: how the fall was counted. What it's sensitive to. The assumption behind it you'd defend least, named before she asks. Which part was yours, and whether other changes happened that year. If you don't know how it was counted, say so: "I don't know how it was counted" is an honest answer. Don't say the spreadsheet "cut" discrepancies unless you know it did | F4 is your only figure, and the one a hiring manager will ask about. EXP because a number is where precise attribution is tested |
| D2 | "What did you actually change when you rebuilt the spreadsheet?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | You rebuilt it. Say what changed, in your own words. Answer slot: if it was Excel, say so and name what you used in it that you're confident with. If it was another tool, name it plainly. Keep it concrete: a recruiter is checking "confident with Excel" | F4 backs the stock-records line, and F7 is the Excel line it touches. EXP because it tests what was yours |
| D3 | "How do you keep track of supplier deliveries now, and do you report on whether things go out on time?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Start with what the quote carries: you schedule deliveries and chase suppliers when orders slip. Answer slot on tracking: if you keep a log, sheet or system view, say what it is. If not, say how slips reach you. Answer slot on reporting: if you report on-time performance, say what, how often and to whom. If you don't, say so plainly and what you'd measure first. Don't describe a weekly report you don't produce | F3 and F5, the two advert lines your material is silent on. JD because they're stated duties |

### E. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you a delivery QA needs will be three days late. What do you do?" | CASE | [generic] | Structure it aloud. First clarify: what it holds up and what can move. Then contact the supplier to firm up the date and ask for options. Then tell planning, the warehouse and QA early, with what's known and when you'll update them. Then re-sequence if possible. Then record it for the supplier's on-time record. The question makes no claim about your past, so neither does the answer | A live problem from the advert's late-orders and coordination lines (F1, F2). Generic because it's a pattern, not a Quillmoor fact |
| E2 | "The stock record says 200 units, but the count says 170. Where do you start?" | CASE | [generic] | Clarify first: one item or many, and since when. Recount before you adjust. Check receipts, dispatches and returns since the last good count, and timing gaps between the record and the movement. Fix the cause, correct the record, and note it. Think aloud | A live problem from the "keep stock records accurate" line (F4). Generic for the same reason as E1 |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA (F1) | B3, B5, E1 |
| Chase late orders (F2) | A1, B1, E1 |
| Track supplier deliveries (F3) | D3 |
| Keep stock records accurate (F4) | A1, D1, D2, E2 |
| Report weekly on on-time dispatch (F5) | D3, B5 |
| 2+ years in operations or logistics coordination (F6) | A1, B3 |
| Confident with Excel (F7) | D2 |
| ERP experience, SAP or similar, a plus (F8, F9) | B2, B5 |
| Salary (F10) | A3, C1 |
| Hybrid, two days at Avonmouth (F11) | A4, C2 |
| Notice period (F12) | A5 |
| What's prompting a move (F13) | A2, B1, C3 |
| Why this company (F14) | B4 |

## Reverse questions

Hannah said she'll cover the team and next steps herself, so these go beyond that. Have two ready and never say "I think you've covered everything."

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would the hiring manager see as the hardest part of this role in the first few months?" | It tells you what the next round will probe, and recruiters usually know |
| R2 | "What system do you run stock and scheduling on, and how do new starters usually get up to speed on it?" | It meets your SAP gap (F8) head-on as a learning question, not a weakness |
| R3 | "Are the two Avonmouth days fixed, or set by the team week to week?" | It sounds practical and settled, and it tells you whether your day limit (F11) is likely to come up |
| R4 | "How is on-time dispatch reported at the moment? Would this role take that over or build it?" | It shows you read the advert closely, and the answer prepares you for F5 |
| R5 | "Is this a new role or a replacement?" | It tells you why the role exists, which shapes your hiring-manager prep |
| R6 | "Is there anything in my background you'd want me to be ready to talk about with the hiring manager?" | It invites her objections while you can still answer them, and recruiters often answer it frankly |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP | Negative you stated, F8 | "I haven't used SAP." No slot |
| Has ERP experience | Inflated form of F9 | F9's quote at its own scope: "we run our own in-house stock system." The pack's observation is that your material says an in-house stock system, not an ERP. B2's slot stays inside what you do in that system |
| Has coordinated production schedules with planning and QA | Inflated form of F1 | F1's quote at its own scope. The pack's observation is that your material says depot deliveries, not production. B3's slot stays inside your scheduling |
| The new spreadsheet cut discrepancies by a third | Inflated form of F4: drops "about" and turns "and" into cause | F4's quote exactly. D1's slot is where you say how much was the sheet |
| Already planning to leave, or leaving for career growth | Contradicted by F13's quote | F13's quote: the office is closing and you don't want to relocate to Reading |
| Flexible on office days without limit | Contradicted by F11's quote | F11's quote: two days is fine, and you wouldn't want more than three |

## Sources

Provided documents:
- Hannah Lowther's LinkedIn message (as pasted)
- The Operations Coordinator advert (as pasted)
- Your notes about yourself (as pasted)

Searches sent:
- `Quillmoor Diagnostics values`: refused (web search permission not granted)
- `Quillmoor Diagnostics interview process operations`: refused
- `Quillmoor Diagnostics Avonmouth Bristol news`: refused
- `Hannah Lowther Quillmoor Diagnostics Talent Partner`: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Every call was refused. It would have given B4 and the reverse questions company-specific material. A values cheat sheet applies only if a later round is a values round |
| 2. `Quillmoor Diagnostics interview process operations` | unavailable | Every call was refused. It would have told you what follows this call. This call's weights are set by Hannah's message either way |
| 3. `Quillmoor Diagnostics` recent news | unavailable | Every call was refused. It would have turned B4 from generic into a question grounded in current company context |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Every call was refused. Her public professional profile would have added a section on reading the interviewer and a reverse question tied to her path |
| 5. Representative Operations Coordinator advert | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → F12 resolves, and A5's slot becomes words you can say
- Allow web search, or paste Quillmoor's About or values page → B4, R2 and R5 become company-specific and targets 1 to 3 run
- A deeper research pass on Quillmoor: up to 6 more searches and 2 more fetches, several more minutes, run only if you want it → a grounding brief on the company and sharper CO questions for later rounds
- Hannah's LinkedIn headline and About section, pasted → a section on reading the interviewer and a reverse question tied to her path
- How the "about a third" was counted, and the before and after counts or the spreadsheet itself → D1's slot becomes words, and F4 can rise to high confidence on an inspectable record
- What tool the spreadsheet is in, how you track supplier deliveries, whether you report on-time performance, and whether your scheduling involves other teams → F7, F3, F5 and F1 upgrade, and D2, D3 and B3 become story-mapped
- Your CV → more rows grounded in your own wording, and checks that the pack matches what Hannah has in front of her
- A tuesday-dossier.md from an evaluation of this role, if you have one → an evidence-derived highest-ROI objection and a verified prohibited-claims list
- When the hiring-manager round is booked → a separate pack for that round, where F1 and F8 will press hardest
