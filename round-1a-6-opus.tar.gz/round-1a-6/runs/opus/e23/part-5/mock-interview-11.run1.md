I don't think you should prep for this one yet, because the message looks like a job scam. I also can't build a prep pack from it: there's no company and no job title, and those are the minimum I need. That gap is itself a warning sign.

**Why it looks like a scam:**

- **The whole process stays on WhatsApp, with no calls or video.** Real employers want to see or hear who they're hiring. Text-only "interviews" are a common scam pattern, because the scammer can stay anonymous and a script can do the talking.
- **"We found your profile online."** That doesn't connect it to any application you sent. If it were from one of them, they'd name the company and the role you applied for.
- **No company, job title, pay or surname.** "Jess, a recruitment consultant" with a remote, flexible-hours role is the standard opening line.
- **An unknown number and an interview booked for tomorrow.** The rush gives you less time to check.

**What usually happens next:** the "interview" turns into an instant job offer. Then they ask for something like your bank details, a copy of your ID, a payment for "training" or "equipment", or for you to receive and forward money. That last one can make you an unknowing money mule, which has legal consequences for you.

**What I'd do:**

1. Reply asking for the company name, the job title and which application this relates to. Then check it yourself: find the company's official website or LinkedIn and contact them through those, not through anything Jess sends you.
2. Don't send ID, bank details or money, and don't click links or install apps they send.
3. If they dodge the questions or push you, block and report the number in WhatsApp (open the chat, tap the contact name, then Report).

If it turns out to be real, they'll be able to name the company and role and set up a proper call. Send me those details, and ideally the job description and your CV, and I'll put together a full prep pack with likely questions and answer guidance based on your actual experience. I'm also happy to help prep for any of your other applications now.