I'd hold off on preparing for this one. That message has most of the signs of a common job scam, and there's nothing in it to prepare from yet anyway.

**Why it looks like a scam:**
- **"We found your profile online."** If this came from one of your applications, they'd name the company and the job you applied for. "Found your profile" is a stock opening for unsolicited scam messages.
- **No company, no job title, no pay.** A real recruiter leads with these.
- **Everything happens over WhatsApp text, "no calls or video needed."** This is the biggest warning sign. Real employers want to hear or see you before hiring you. Text-only "interviews" are common in task scams and fake-cheque scams, because nobody has to show who they are.
- **The contract is also done over WhatsApp.** Real offers come by email from a company domain, usually through HR software.
- **An unknown number, a vague "remote, flexible hours" pitch, and an interview tomorrow.** The quick deadline is meant to stop you checking.

These scams usually move on to one of three things: asking for your ID or bank details "for payroll", sending you a cheque to buy "equipment", or getting you to do paid "tasks" that later need a deposit.

**Before you reply, you could:**
1. Ask Jess for the company name, the job title, the job you applied for, and an email from a company address. If they dodge any of that, you have your answer.
2. If they do name a company, look up its careers page or contact details yourself (don't use links Jess sends) and ask the company whether the role is real.
3. Check your sent applications and inbox for that company.
4. Until it's verified, don't send ID, bank details, your address or any money, and don't install anything they send.
5. If it turns out to be a scam, report the number and block it in WhatsApp.

I'd ask those questions and see how they respond before giving any time to interview prep.

**If it turns out to be real:** send me the company name and job title, and the job description and your CV if you have them. I'll put together a full prep pack: likely questions with answers based on your actual experience, a list of where you match the job and where you don't, and questions for you to ask them. I can also run a practice interview with you.