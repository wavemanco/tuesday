I don't think you should prepare for this one yet. That message has the classic signs of a WhatsApp job scam, and the prep tool also can't work without a company name and a role title, which it doesn't give.

**Why it looks like a scam:**

- **No company and no job.** A recruiter contacting you about something you applied for would say which application. "Your profile online" is deliberately vague. It's meant to make you think it's one of your many applications.
- **Everything happens over WhatsApp text, "no calls or video needed."** This is the strongest warning sign. Real employers want to see or hear the person they hire. Text-only lets the sender pretend to be anyone.
- **Interview tomorrow, nothing about the job itself.** The rush to book a time before you know anything is pressure, not a real process.
- **"Remote, flexible hours, great match."** This is the standard bait in task scams and fake-cheque scams. The "interview" usually ends with a "job" that has you paying for training or equipment, sharing bank or ID details, or doing "tasks" that you have to fund yourself.

**What to do:**

1. **Don't send any personal details**: no ID, bank details or address, and no money for anything.
2. **Ask for proof, if you want to test them.** Ask for the company name, the job title and a work email address. Then find the company yourself through its own website and contact it there to check. Scammers usually go quiet or dodge the question.
3. **Check your sent applications.** If Jess does name a company, see whether you actually applied there. Real recruiters will happily move to email or a call.
4. **Block and report** the number in WhatsApp if it doesn't hold up.

If it does turn out to be real, send me the company, the role, and the job ad or your CV if you have them. I'll put together a full prep pack with likely questions, answer guidance based on your actual experience, and a practice run with me playing the interviewer. I'd also be glad to prep you for any of your other applications now.