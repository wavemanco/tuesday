I'd hold off on preparing for this one. The message has the classic signs of a recruitment scam, and on top of that it doesn't name a company or a role, so there's nothing real to prepare for yet.

**Why it looks like a scam:**

- **Nobody legitimate hires entirely over WhatsApp text.** "Interview through to contract, no calls or video" is the biggest warning sign here. Real employers want to see or hear you before they hire you. Scammers avoid calls because calls expose them.
- **It contradicts itself.** It says they "found your profile online," which means they're not replying to anything you sent. So your recent applications don't explain it.
- **No company, no role, no surname.** A real recruiter leads with who the client is and what the job is.
- **The job is vague and appealing.** "Remote, flexible hours, great match" with no actual duties is typical bait.
- **Unknown number, rushed timing.** Booking the interview for tomorrow gives you little time to check anything.

These "interviews" usually end with one of three asks: copies of your ID or bank details "for the contract," a fee for training or equipment, or a "task" job where you deposit money to unlock earnings. Each one leads to identity theft or losing money.

**What to do:**

1. **Don't share your ID, bank details or address, don't pay anything, and don't click any links they send.**
2. If you want to test them, reply with: *"Which company and role is this for, and which of my applications does it relate to? Please send the job description from your company email address."* A real recruiter can answer that easily. A scammer will dodge the question, stay vague or push harder.
3. If they do name a company, look it up yourself. Find its official website or LinkedIn page and contact it through those to confirm the job and the recruiter are real. Don't use any contact details "Jess" gives you.
4. If they won't give you real details, block and report the number in WhatsApp. You can also report it to your country's fraud reporting service.

**If it turns out to be real:** send me the company name and job title, plus the job description and your CV if you have them. I'll build you a full interview prep pack with likely questions, answer guidance based on your actual experience, and questions for you to ask them. We can also do a live practice run.