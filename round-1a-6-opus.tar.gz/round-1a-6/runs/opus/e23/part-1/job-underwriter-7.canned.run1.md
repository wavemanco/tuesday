I've read the skill's rules and am now doing a short web check on the employer and Band 5 pay before writing up your assessment.
# Should you apply? Community Staff Nurse, Band 5, Calderbrook Community Health

## Decision snapshot

**Yes, it's worth applying for, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (Clear, timely written records)
- `important`: direct: R7a, R8a, R10a · adjacent: R5 (Caring for housebound adults in their own homes) · unclear: R7b (Leg-ulcer care), R8b (Continence care), R9 (End-of-life visits), R10b (Care planning) · absent: R6 (A small caseload of your own)
- `preferred`: absent: R11 (Doppler assessment for leg ulcers)

R4: missing from the CV, probably fixed by adding a line; R5: your discharge-to-assess (D2A) home visits, a real bridge with limits; R6, R11: the two gaps you named yourself; R7b, R8b, R9, R10b: the CV doesn't say either way yet.

**Opportunity ledger.** The advert is open about its terms. Pay is stated and sits across the market range (RR1), mileage and pool cars cover the driving (RR2), and your caseload would come with a named senior nurse supporting you (RR3). Three things are still unknown: whether the vacancy is still open (RR4), whether "Band 5" means NHS Agenda for Change terms (RR5), and the shift pattern (RR6).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R4 is shown in your application: your record-keeping, ideally on an electronic record (G1); (2) the terms in RR5 and RR6 are acceptable to you; (3) R6 and R11 are presented as honest gaps, never papered over.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | A community interest company running adult community nursing, therapy and rehab across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` the company's own About page, fetched |
| Mandate | District nursing for housebound adults: wounds and leg ulcers, catheter and continence care, end-of-life visits, insulin, care planning, all on an electronic patient record | `[grounded]` the advert |
| Scope | A small caseload of your own, supported by a senior community nurse | `[grounded]` the advert |
| Scope read | A Band 5 post pitched at nurses who are new to holding a caseload, not one that expects you to arrive running one | `[inferred]` from "small caseload" plus the named senior support |
| Market calibration | Band 5 community staff nurses in England: median basic pay £34,300, middle half £32,400–£36,600 (n=1,240). The advert's £31,050–£37,800 spans that range | `[generic]` Wardround 2026 community nursing pay guide; `[grounded]` the advert for the figure |
| Unknowns | Whether the vacancy is live; Agenda for Change terms and pension; hours, weekends and full- or part-time | — |
| Contradictions | None found. The company exists as the advert describes it, but the vacancy itself didn't show up in search | `[grounded]` About page; vacancy not found |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult Nurse | hard_gate | direct | medium | none | Your CV gives an active Adult registration, revalidation due March 2028. Not yet checked against the public register | `[grounded]` CV | Optional: check your entry on the NMC register (upgrade menu) |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Full licence, category B, as stated in your CV | `[grounded]` CV | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse | `[grounded]` CV | none |
| R4 | Clear, timely written records (on an electronic patient record) | must_have | unclear | low | discovery | The CV says nothing about documentation or electronic records. Five years on a ward is indirect context, not a claim | `[grounded]` CV silent | G1 |
| R5 | Caring for housebound adults in their own homes | important | adjacent | medium | transferability | 18 months of D2A home visits is real home-based care. Its limit: short-term, first week after discharge, not ongoing care of housebound patients | `[grounded]` CV; `[inferred]` the limit, from "first week after discharge" | G2 |
| R6 | A small caseload of your own | important | absent | none | capability | You've said you've never held one. The advert's own support offer is the route to closing it | `[grounded]` your statement; the advert | G5 |
| R7a | Wound care | important | direct | medium | none | Pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R7b | Leg-ulcer care | important | unclear | low | discovery | Leg ulcers aren't named in your wound care | `[grounded]` CV silent | G3 |
| R8a | Catheter care | important | direct | medium | none | Stated in your CV | `[grounded]` CV | none |
| R8b | Continence care | important | unclear | low | discovery | The CV names catheter care only | `[grounded]` CV silent | G4 |
| R9 | End-of-life visits | important | unclear | low | discovery | Not mentioned | `[grounded]` CV silent | G4 |
| R10a | Insulin administration | important | direct | medium | none | Stated in your CV | `[grounded]` CV | none |
| R10b | Care planning | important | unclear | low | discovery | Not mentioned | `[grounded]` CV silent | G4 |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You've said you've never done one. It's listed as desirable, not essential | `[grounded]` your statement; the advert | G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records (R4, must_have) | discovery | Nothing on documentation | It's an essential criterion, and the only `must_have` row that isn't settled | Records kept on a hospital electronic system; D2A visit notes written in the patient's home or straight after; audit or documentation training | Name the system you used; a documentation audit result or training record | `[grounded]` CV silent; `[inferred]` that closing it moves the status to `go` |
| G2 | Home-based care (R5) | transferability | D2A home visits for 18 months | Your closest match to the actual job | Carries over: assessing and treating people in their own homes, working alone, travelling between visits. Doesn't carry over: ongoing long-term care of the same patients. Strengthened by: concrete D2A examples | A reference from your D2A team lead | `[grounded]` CV; `[inferred]` what carries over and what doesn't |
| G3 | Leg-ulcer care (R7b) | discovery | Wound care listed, leg ulcers not | It's one of the core duties and ties into R11 | Venous ulcer dressings; compression bandaging; leg-ulcer patients seen on the ward or during D2A | A tissue viability or compression training certificate | `[grounded]` CV silent |
| G4 | Continence, end-of-life care, care planning (R8b, R9, R10b) | discovery | Not mentioned | Three of the advert's listed duties | Writing care plans at D2A visits; continence assessments; palliative patients on the ward or at home | Training records; a reference | `[grounded]` CV silent |
| G5 | Own caseload (R6) | capability | You've never held one | The main gap between ward work and district nursing | Closure path: the senior support the advert promises; carry this as a known gap | — | `[grounded]` your statement; the advert |
| G6 | Doppler (R11) | capability | You've never done one | Desirable only | Closure path: Doppler training once in post (see A2) | — | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay is stated and spans the market range | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Pay transparency; the range brackets the typical Band 5 figure | `[grounded]` the advert; `[generic]` Wardround survey | Where in the range would someone with five years' experience start? | noted |
| RR2 | Pool cars plus mileage | positive_signal | — | "pool cars are provided" | Driving costs fall on the employer, not you | `[grounded]` the advert | Is a pool car guaranteed every shift, or do I sometimes use my own? | noted |
| RR3 | A caseload with named support | positive_signal | — | "supported by a senior community nurse" | The post is set up for someone new to holding a caseload | `[inferred]` from the advert's wording | How many visits a day is a typical small caseload, and how is the support arranged? | noted |
| RR4 | Vacancy not found on the careers site | unknown | — | "Calderbrook Community Health CIC, Halifax" | The listing may have closed, or may just not be indexed | `[generic]` search engines often miss careers pages | Is the post still open, and what's the closing date? | unresolved |
| RR5 | Employment terms behind "Band 5" unstated | unknown | — | "Community Staff Nurse, Band 5" | Community interest companies on NHS contracts don't always use Agenda for Change terms or offer the NHS Pension | `[generic]` pattern, not a claim about this employer | Are terms Agenda for Change, including NHS Pension, annual leave and sick pay? | unresolved |
| RR6 | Hours and shift pattern unstated | unknown | — | (not stated in the advert) | District nursing rotas often include weekends and late shifts | `[generic]` pattern | What's the rota: weekends, lates, and is part-time possible? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take up the informal chat with Rhiannon Mabbott and ask the RR3–RR6 questions word for word | It answers the register's open items before you invest more time | `[grounded]` the advert names her for informal chats | pending your approval |
| A2 | In that chat, say plainly that you haven't done Doppler, and ask whether training is provided for nurses new to community work | Her public talks cover nurse-led leg-ulcer clinics and Doppler training for staff new to community work, so it's a natural topic, not a weakness to hide | `[grounded]` community nursing forum speaker page | pending your approval |
| E1 | Move the D2A secondment up your CV, worded as it actually happened: "Seconded for 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge" | It's your evidence for R5 | `[grounded]` your CV wording | resume_edits_pending_approval |
| E2 | Add a records line, and any of R7b, R8b, R9 or R10b, only once your answers to G1, G3 and G4 confirm them | Records are an essential criterion; nothing goes on the CV unconfirmed | `[grounded]` R4 row | resume_edits_pending_approval |
| N1 | Don't describe the D2A work as district nursing or as holding a caseload | You've said you never held one, and the interview will test it | `[grounded]` your statement | pending your approval |

The approval markers cover the advice in A1, A2 and N1 as well as the CV wording in E1 and E2. Nothing goes on your CV until you approve it.

## Evidence status

Verified: none yet. Not used: your National Insurance number. It isn't needed to judge a role, and I've kept it out of everything here. Employers ask for it at pre-employment checks, not on the CV.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health careers Community Staff Nurse Band 5"; fetched "About Calderbrook Community Health" (calderbrookhealth.example/about). Confirmed the organization row in role reality; the vacancy wasn't found (RR4) |
| 2. Role-family sweep | yes | Searched "Agenda for Change Band 5 pay 2026/27 community staff nurse", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Gave the market calibration figures and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott community nursing team lead", which returned her speaker page (communitynursingforum.example/speakers/rhiannon-mabbott). Fed A2 |

I can turn all of this into a saved `tuesday-dossier.md` file whenever you'd like one.

## Upgrade menu

- Your entry on the public NMC register (the inspectable proof for a registered nurse) → R1 rises to `high`.
- Answers to G1, G3 and G4 → R4, R7b, R8b, R9 and R10b resolve; if R4 confirms, the status likely moves to `go`.
- A reference from your D2A team lead → R5's bridge gets stronger.
- Answers from the informal chat → RR4, RR5 and RR6 close.
- Your own constraints (pay floor, hours, start date) → the hard-gate checks against them can run.
- A deeper research pass on Calderbrook (staff reviews, leadership changes, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

G1: On the ward or in D2A, which record system did you use, and is there anything (an audit, training, feedback) that shows your record-keeping?

G4: In a typical D2A week, did you write care plans, assess continence, or visit patients at the end of life? What did you personally do?

Constraints: Do you have a pay floor, hours you can or can't work (weekends, part-time), or a start date that would rule this out?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.