I'm going through the assessment framework's reference rules, then I'll run a few quick searches on the employer and the pay band before writing up.
## Decision snapshot

**Yes, it's worth applying for, provided the conditions below hold. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (Clear, timely written records)
- `important`: direct: R5, R7a, R8a, R10 · adjacent: R6 (Hold a small caseload of your own) · unclear: R7b (Leg-ulcer care), R8b (Continence care), R9 (End-of-life visits), R11 (Care planning)
- `preferred`: absent: R12 (Doppler assessment for leg ulcers)

R6: your discharge-to-assess home visits are a real bridge to holding a caseload, with its limit named; R4, R7b, R8b, R9, R11: your CV doesn't mention them, so they're open questions rather than gaps; R12: only desirable, and there's a training route (RR3).

**Opportunity ledger.** The employer looks sound and open. The pay is published and sits within the survey band (RR2). The caseload is supported, and the team lead has spoken publicly about Doppler training for staff new to community work (RR3). Still open: the advert wasn't found on the employer's own site (RR1), the caseload size and support aren't defined (RR4), and the rota isn't stated (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); you haven't given me your own constraints, so I couldn't check the role against them.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your record-keeping experience is confirmed (R4, G1); (2) the vacancy is confirmed open (RR1); (3) you present the discharge-to-assess work as adjacent experience, never as holding a caseload (R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehab across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` employer's About page |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, all recorded on an electronic patient record | `[grounded]` advert |
| Scope | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Scope read | Built for someone new to holding a caseload: "small" and "supported" are both in the advert's wording | `[inferred]` from the advert's wording |
| Team lead | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. In 2025 she spoke on nurse-led leg-ulcer clinics and Doppler training for staff new to community work | `[grounded]` forum speaker page |
| Market calibration | Band 5 community staff nurses in England: median £34,300, middle half £32,400–£36,600. 61% were paid mileage and 24% had a pool or lease car. The advert's £31,050–£37,800 range covers that band. The survey is self-reported (1,240 respondents, 2026) and isn't this employer's offer | `[generic]` Wardround 2026 survey; `[grounded]` advert for the range |
| Unknowns | Caseload size; length of induction or preceptorship; rota (weekends, evenings); whether the vacancy is still open | — |
| Contradictions | None found between the advert and the About page | `[grounded]` About page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | Your CV gives a PIN, says registration is active and revalidation is due March 2028. That's self-reported; the employer will check the NMC register | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Your CV says full UK licence, category B; it's self-reported | `[grounded]` CV | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse is well over the minimum | `[grounded]` CV | none |
| R4 | Clear, timely written records (on an electronic patient record) | must_have | unclear | low | discovery | Your CV doesn't mention documentation, record systems or care-plan writing | `[grounded]` CV is silent | G1 |
| R5 | Caring for housebound adults in their own homes | important | direct | medium | none | 18 months on the discharge-to-assess team "visiting patients at home in their first week after discharge" | `[grounded]` CV | none |
| R6 | Hold a small caseload of your own | important | adjacent | medium | transferability | What carries over: home visiting, including assessing patients at home. What doesn't: you say you've never held your own caseload, so planning visits and being accountable for an ongoing list are new | `[grounded]` CV and your own statement | see G6 |
| R7a | Wound care | important | direct | medium | none | Pressure ulcers and surgical wounds are named | `[grounded]` CV | none |
| R7b | Leg-ulcer care | important | unclear | low | discovery | Your CV doesn't mention leg ulcers. Pressure-ulcer care isn't the same thing, so it doesn't count here | `[grounded]` CV is silent | G2 |
| R8a | Catheter care | important | direct | medium | none | Named on your CV | `[grounded]` CV | none |
| R8b | Continence care | important | unclear | low | discovery | Your CV doesn't mention continence assessment or management | `[grounded]` CV is silent | G3 |
| R9 | End-of-life visits | important | unclear | low | discovery | Your CV doesn't mention end-of-life care | `[grounded]` CV is silent | G4 |
| R10 | Insulin administration | important | direct | medium | none | Named on your CV | `[grounded]` CV | none |
| R11 | Care planning | important | unclear | low | discovery | Your CV doesn't mention writing or reviewing care plans | `[grounded]` CV is silent | G5 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You confirm you've never done one. It's desirable, not essential, so it's a small risk and won't block you | `[grounded]` your own statement | Closure path: ask about training (RR3) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Clear, timely written records (R4, must_have) | discovery | Nothing on documentation | It's the only essential criterion your CV doesn't show | The ward's electronic record or e-obs system; discharge-to-assess visit notes written at or after a home visit; nursing assessments, risk assessments or handover records | The names of the systems you've used; any audit or record-keeping feedback | `[grounded]` CV is silent |
| G2 | Leg-ulcer care (R7b, important) | discovery | Pressure ulcers and surgical wounds only | Leg ulcers are a core part of this team's work | Leg-ulcer dressings or compression bandaging on the ward or during discharge-to-assess visits; a tissue viability link-nurse role; wound-care study days | Training certificates, competency sign-offs | `[grounded]` CV is silent |
| G3 | Continence care (R8b, important) | discovery | Catheter care only | Named in the advert | Continence assessments, managing pads or products, bowel care, trial without catheter | Competency records | `[grounded]` CV is silent |
| G4 | End-of-life visits (R9, important) | discovery | Nothing on end-of-life care | Named in the advert | End-of-life care on an acute medical ward; syringe drivers; anticipatory medicines; supporting families; patients discharged home to die | Syringe-driver competency, palliative care training | `[grounded]` CV is silent |
| G5 | Care planning (R11, important) | discovery | Nothing on care planning | Named in the advert alongside insulin | Writing or reviewing care plans on the ward; discharge-to-assess goal plans; diabetes care plans | Anonymised template or description | `[grounded]` CV is silent |
| G6 | Own caseload (R6, important) | transferability | Home visiting without caseload ownership | The advert expects ownership, with support | How your discharge-to-assess visits were planned and prioritised, and what you decided on your own | A description of a typical discharge-to-assess day | `[grounded]` your own statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | The advert wasn't found on the employer's careers page | unknown | — | "Current vacancies are listed on our careers page" (About page) | The careers page may live at a different address, or the role may be advertised on NHS Jobs instead. It could also have closed | `[inferred]` from a failed fetch of /careers | Is this vacancy still open, and where is it formally advertised? | unresolved |
| RR2 | Published pay in line with the survey band, plus mileage and pool cars | positive_signal | — | "£31,050–£37,800 a year plus mileage"; "pool cars are provided" | The pay is transparent and fair for the band | `[grounded]` advert; `[generic]` survey band | Where on the range would someone with five years' post-registration experience start? | noted |
| RR3 | A supported caseload, and a team lead who has spoken publicly about Doppler training for staff new to community work | positive_signal | — | "supported by a senior community nurse" | Doppler training may be available to new starters | `[grounded]` advert and speaker page; `[inferred]` that it applies to this post | Is Doppler and leg-ulcer training offered to new community starters, and how soon? | noted |
| RR4 | Caseload size and support not defined | unknown | — | "a small caseload of your own" | How much caseload new community nurses carry varies widely between teams | `[generic]` pattern across community nursing | How many patients would my caseload start at, and what does the senior nurse's support look like in the first three months? | unresolved |
| RR5 | Rota not stated | unknown | — | The advert is silent on hours | District nursing teams often work weekends and evenings on a rota | `[generic]` pattern across community nursing | What's the rota: weekends, evenings, bank holidays? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take up the informal chat with Rhiannon Mabbott, and ask the questions from RR1, RR3, RR4 and RR5 | The advert invites the chat, and her public talks match the gap you'd most want to raise (R12) | `[grounded]` advert, speaker page | pending your approval |
| E1 | Lead your supporting statement with your own line: "seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge" | see R5, R6 | `[grounded]` CV wording | resume_edits_pending_approval |
| E2 | List the clinical skills in the advert's order using your words: "wound care including pressure ulcers and surgical wounds; catheter care; insulin administration". Don't add leg ulcers, continence, end-of-life or care planning until G2–G5 are answered | see R7a, R8a, R10 | `[grounded]` CV wording | resume_edits_pending_approval |
| E3 | State the gaps plainly in your own words: you haven't held your own caseload and haven't done a Doppler assessment. Pair them with your interest in the supported caseload and in Doppler training | see R6, R12 | `[grounded]` your statement | pending your approval |

## Evidence status

Verified: none yet. Your National Insurance number isn't needed to evaluate a role, so I haven't used it.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health community staff nurse Band 5 vacancy". Both returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, which had no page there. This moved the Organization row in role reality and RR1 |
| 2. Role-family sweep | yes | Searched "Agenda for Change Band 5 pay 2026/27 community staff nurse", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). This moved market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott community nursing team lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). This moved the Team lead row, RR3 and A1 |

I can also put all of this into a `tuesday-dossier.md` file for you to keep or reuse later.

**Upgrade menu**
- Your answers to G1–G5 would move R4, R7b, R8b, R9 and R11 off `unclear`. Once G1 is answered, the decision should simplify to `go` or `hold`.
- Training certificates or competency sign-offs (tissue viability, syringe driver, catheterisation) would lift the matching rows to `high`.
- Your constraints (pay floor, hours, weekends) would let me check the role against them; right now that check is unknown.
- The live advert's link, or where you found it, would close RR1.
- A deeper research pass on Calderbrook (inspection reports, staff reviews, recent news; up to 5 more searches and 2 more fetches), whenever you want it.
- If you get an interview, the mock-interview skill can rehearse it with you.

**Questions**

G1: When you write records now, what system do you use (an electronic record, paper notes, or both)? And were your discharge-to-assess visit notes written in it?

G2, G3, G4, G5: Which of these have you actually done, on the ward or in discharge-to-assess: leg-ulcer care or compression bandaging, continence assessment, end-of-life care (syringe drivers, anticipatory medicines), writing or reviewing care plans?

Constraints: Is there anything you won't trade, such as a pay floor, no weekends, or set hours?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.