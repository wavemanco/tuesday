I've read the skill's rules. Next I'll check that the employer is real and look up market pay, then write the assessment.
**Yes, it's worth applying for. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (Clear, timely written records)
- `important`: direct: R5a, R6a, R8a, R9 · adjacent: R10 (Hold a small caseload of your own) · unclear: R5b (Leg-ulcer care), R6b (Continence care), R7 (End-of-life visits), R8b (Care planning)
- `preferred`: absent: R11 (Doppler assessment for leg ulcers)

R4: probably one answer away from closing; R10: home visits but no caseload of your own, so present it as adjacent and nothing more; R11: desirable, not essential.

**Opportunity ledger.** The posting looks sound. The pay sits inside the market band (RR2), mileage and pool cars are provided (RR3), and support for a first caseload is stated (RR4). Against that, the posting couldn't be found on the employer's own site (RR1), and the working pattern isn't stated (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm your record-keeping experience, R4; (2) the posting is confirmed live, RR1; (3) the caseload gap is presented as adjacent, never as caseload experience, R10, and Doppler is stated honestly as not yet done, R11.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehab across Calderdale under an NHS contract. Founded 2015, about 410 staff in four hubs | `[grounded]` employer's About page |
| Mandate | District nursing for housebound adults at home: wounds and leg ulcers, catheter and continence care, end-of-life visits, insulin and care planning, all recorded on an electronic patient record | `[grounded]` advert |
| Scope | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Scope read | A normal Band 5 community post. "Small caseload" plus named senior support matches how district nursing teams usually bring in newer staff | `[inferred]` from the advert's support wording; `[generic]` role-family pattern |
| Pay | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` advert |
| Market calibration | Band 5 community staff nurse in England, 2026 (n=1,240): median £34,300, middle half £32,400–£36,600. The advertised range straddles that, so it's market-normal, not a low offer | `[generic]` Wardround 2026 pay guide; `[grounded]` advert figure |
| Unknowns | Hours, weekend and evening rota; how big "small" is; whether Doppler training is provided; whether the posting is currently live | — |
| Contradictions | None between the advert and the employer's About page | `[grounded]` About page snippet |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV gives Registered Nurse (Adult), active, revalidation March 2028. Specific, but nothing inspected yet | `[grounded]` CV | Employer will check the NMC register; nothing for you to do |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV: full UK licence, category B | `[grounded]` CV | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as an acute medical staff nurse is well past one year | `[grounded]` CV | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | The CV doesn't mention records or EPR systems. Five years of ward nursing is indirect context only, so the claim can't be asserted until you confirm it | `[grounded]` CV silence | G1 |
| R5a | Wound care | important | direct | medium | none | CV: wound care including pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R5b | Leg-ulcer care | important | unclear | low | discovery | Your wound care is listed as pressure ulcers and surgical wounds. Leg ulcers aren't named | `[grounded]` CV | G2 |
| R6a | Catheter care | important | direct | medium | none | CV: catheter care | `[grounded]` CV | none |
| R6b | Continence care | important | unclear | low | discovery | Catheter care is related, but the CV doesn't name continence care more broadly | `[grounded]` CV | G2 |
| R7 | End-of-life visits | important | unclear | none | discovery | CV is silent | `[grounded]` CV silence | G2 |
| R8a | Insulin administration | important | direct | medium | none | CV: insulin administration | `[grounded]` CV | none |
| R8b | Care planning | important | unclear | none | discovery | CV is silent on writing or owning care plans | `[grounded]` CV silence | G2 |
| R9 | Caring for housebound adults in their own homes | important | direct | medium | presentation | Eighteen months on the discharge-to-assess team visiting patients at home in their first week after discharge. This is your closest match to the role, and it sits at the end of the CV line | `[grounded]` CV | E1 |
| R10 | Hold a small caseload of your own, with senior support | important | adjacent | medium | transferability | What carries over: home visits. The limit: you say you've never held a caseload. What narrows it: the advert offers senior support | `[grounded]` your own statement plus the advert's support wording | Frame as adjacent (E1); ask about caseload size (RR4) |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You say you've never done one. Desirable only, so a minor risk | `[grounded]` your own statement | Possible route in: the team lead has spoken publicly on Doppler training for staff new to community work (`[grounded]` forum speaker page). Ask whether this post includes it (RR4) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records on an EPR (R4, must_have) | discovery | No mention of documentation or electronic record systems | The only must-have below `direct`. Confirming it removes condition (1) | Documenting assessments and wound reviews on the hospital's electronic record; discharge-to-assess visit notes; handover records; any audit of your notes | Name of the record system you used; any documentation audit result or training certificate | `[grounded]` CV silence; `[inferred]` that confirming it settles the condition |
| G2 | Leg ulcers, continence, end-of-life, care planning (R5b, R6b, R7, R8b, important) | discovery | Related skills are listed, but none of these four is named | Four important duties. Each one you confirm is something you can say in the application and at interview | Dressing a venous leg ulcer on the ward or on a discharge-to-assess visit; continence assessments or pad and product reviews; caring for dying patients or verifying a death; writing or updating care plans for patients at home | Competency sign-offs, training certificates, a sanitized care-plan template | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's own site | unknown | — | "Calderbrook Community Health CIC, Halifax" | The employer exists as described. Its careers page wasn't at the address tried, so whether the posting is live is unconfirmed. Most likely it's listed through NHS Jobs or another page | `[grounded]` About page found, careers fetch returned no page; `[inferred]` the likely explanation | Is this post still open, and where should I apply? | unresolved |
| RR2 | Pay in line with the market | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range brackets the market median | `[grounded]` advert; `[generic]` Wardround band | Where in the range would I start with five years' post-registration experience? | noted |
| RR3 | Pool cars plus mileage | positive_signal | — | "pool cars are provided" | Less cost and wear on your own car | `[grounded]` advert | How are pool cars booked, and what happens when none is free? | noted |
| RR4 | Named support for a first caseload | positive_signal | — | "supported by a senior community nurse" | Suits someone new to holding a caseload | `[grounded]` advert | How many patients is a "small" caseload, and is Doppler training part of the induction? | noted |
| RR5 | Working pattern unstated | unknown | — | (advert silent on hours) | Community nursing rotas often include weekends and late shifts. This is a pattern, not a claim about this team | `[generic]` role-family pattern | What are the hours, and how often would I work weekends or evenings? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move the discharge-to-assess secondment up front, in your own words: "seconded to the discharge-to-assess team for 18 months, visiting patients at home in their first week after discharge". Don't call it community nursing or caseload experience | See R9, R10 | `[grounded]` CV wording | resume_edits_pending_approval |
| E2 | List wound care exactly as you have it (pressure ulcers, surgical wounds), plus catheter care and insulin. Add leg ulcers, continence, end-of-life or care planning only if you confirm them in G2 | See R5a, R5b, R6a, R8a | `[grounded]` CV | resume_edits_pending_approval |
| A1 | Take up the informal chat with Rhiannon Mabbott before applying, through the contact route the advert gives, and ask the questions from RR1, RR4 and RR5 | The advert invites it, and it settles the unknowns | `[grounded]` advert | pending your approval |
| A2 | Say plainly that you haven't done Doppler yet and would like to learn it | See R11. The team lead's public talks cover Doppler training for staff new to community work | `[grounded]` forum speaker page | pending your approval |

## Evidence status

Verified: none yet. You included your National Insurance number. It isn't needed to evaluate a role, so I haven't used it, and you don't need to share it at this stage.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers: no page there. Moved role reality's organization row and RR1 |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary 2026 Agenda for Change", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott community nursing team lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved R11's next action and A2 |

I can write all of this up as a `tuesday-dossier.md` file you keep and build on, if you'd like.

**Upgrade menu**
- Your NMC register entry or revalidation record: R1 rises to `high`.
- An answer to G1: R4 resolves and condition (1) clears.
- Answers to G2: R5b, R6b, R7 and R8b each resolve, and E2 gains lines you can truthfully use.
- A link to the live posting, or what the informal chat tells you: RR1, RR4 and RR5 close.
- Your non-negotiables (hours, weekends, pay floor): the hard-gates check runs against your constraints, not just the advert's.
- A deeper research pass on Calderbrook (staff reviews, recent news, leadership changes; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

G1: Which electronic patient record system have you documented on, and has your record-keeping ever been audited or praised?

G2: Of leg-ulcer care, continence care, end-of-life care and writing care plans, which have you actually done, on the ward or on discharge-to-assess visits?

Constraints: Is there anything you won't compromise on, such as weekends, hours or a minimum salary?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.