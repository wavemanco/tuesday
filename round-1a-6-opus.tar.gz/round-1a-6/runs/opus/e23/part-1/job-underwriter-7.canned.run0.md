Quick update: I've checked the employer, the pay band and the team lead's public profile, and I'm now checking whether the post is live on the employer's careers page.
**Yes, it's worth applying for, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (Clear, timely written records)
- `important`: direct: R5a, R6a, R8, R10 · adjacent: R11 (Hold a small caseload of your own) · unclear: R5b (Leg-ulcer care), R6b (Continence care), R7 (End-of-life visits), R9 (Care planning)
- `preferred`: absent: R12 (Doppler assessment)

R4: your CV doesn't mention it yet, and one question could settle it; R11: your discharge-to-assess home visits bridge to it, with a stated limit; R5b, R6b, R7, R9: possibly in your ward history but not on the CV; R12: preferred only.

**Opportunity ledger.** The role looks sound. Pay is stated and in line with the market (RR3), cars and mileage are provided (RR4), and the team lead has spoken publicly on Doppler training for staff new to community work (RR5). Two things are still open: the post wasn't on the employer's careers page (RR1), and the caseload size and level of support aren't stated (RR2).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R4 confirmed from your own record-keeping practice; (2) the post confirmed as open, RR1; (3) R11 presented as home-visiting experience, never as caseload holding.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | A community interest company running adult community nursing, therapy and rehab across Calderdale under an NHS contract. Founded 2015, 410 staff, four locality hubs | `[grounded]` advert; employer's About page |
| Mandate | District nursing for housebound adults: wounds and leg ulcers, catheters and continence, end-of-life visits, insulin, care planning, all on an electronic record | `[grounded]` advert |
| Scope | Your own small caseload, supported by a senior community nurse | `[grounded]` advert |
| First 90 days | Probably building up to that caseload under supervision, and learning the electronic record and the leg-ulcer pathway | `[inferred]` from "small caseload… supported by a senior community nurse" |
| Market calibration | Wardround 2026 survey of Band 5 community staff nurses in England (n=1,240): median £34,300, middle half £32,400–£36,600. The advertised £31,050–£37,800 covers that range, so it is a normal Band 5 offer | `[generic]` survey band; `[grounded]` advert figure |
| Unknowns | Caseload size; how often the senior nurse supports you; which electronic record system; Doppler training; whether the post is still open | n/a |
| Contradictions | None found between the advert and the employer's About page | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult | hard_gate | direct | medium | none | CV gives the PIN, active, revalidation March 2028. Self-reported and not yet inspected | `[grounded]` CV | none; the employer will check the NMC register |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV: full licence, category B | `[grounded]` CV | none |
| R3 | At least one year post-registration experience | must_have | direct | medium | none | Five years as a staff nurse, well over the minimum | `[grounded]` CV | none |
| R4 | Clear, timely written records (electronic record) | must_have | unclear | low | discovery | CV says nothing about documentation or electronic record systems. Five years of ward work makes it likely, but that is not evidence | `[grounded]` CV silent; `[inferred]` likelihood from ward tenure | G1 |
| R5a | Wound care | important | direct | medium | none | Pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R5b | Leg-ulcer care | important | unclear | low | discovery | Leg ulcers aren't named. Wound care is near this work but isn't the same thing | `[grounded]` CV | G3 |
| R6a | Catheter care | important | direct | medium | none | Stated | `[grounded]` CV | none |
| R6b | Continence care | important | unclear | low | discovery | Not named beyond catheters | `[grounded]` CV | G3 |
| R7 | End-of-life visits | important | unclear | low | discovery | Not stated, though an acute medical ward and discharge-to-assess work may have included it | `[grounded]` CV silent; `[inferred]` from setting | G2 |
| R8 | Insulin administration | important | direct | medium | none | Stated | `[grounded]` CV | none |
| R9 | Care planning | important | unclear | low | discovery | Not stated | `[grounded]` CV silent | G2 |
| R10 | Caring for adults in their own homes | important | direct | medium | presentation | 18 months on the discharge-to-assess team, "visiting patients at home in their first week after discharge". This is your strongest link to the role, and the CV currently lists it as a secondment line | `[grounded]` CV | E1 |
| R11 | Hold a small caseload of your own | important | adjacent | medium | transferability | Home visits carry over. The limit: you have "never held my own caseload", and the advert says you'd be supported | `[grounded]` CV and your own statement | G4 |
| R12 | Doppler assessment | preferred | absent | medium | capability | You've never done one. Preferred only | `[grounded]` your statement; `[inferred]` from RR5 that it may be trainable here | Ask RR5's question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Records (R4, must_have) | discovery | No mention of documentation or electronic record systems | The only must-have not yet shown; confirming it removes condition (1) | Charting on an electronic record or electronic prescribing system; discharge summaries; documenting at home on discharge-to-assess visits; audits you passed | Name of the system you used; a records-audit result | `[grounded]` CV silence |
| G2 | End-of-life and care planning (R7, R9) | discovery | Neither is named | Two of the role's core duties | Anticipatory medicines and syringe drivers; care plans written on discharge-to-assess; fast-track discharges home to die | None needed; specifics are enough | `[grounded]` CV silence; `[inferred]` setting |
| G3 | Leg ulcers and continence (R5b, R6b) | discovery | Wound care and catheters only | Leg-ulcer care is listed first in the duties | Compression bandaging; venous ulcer dressings; continence assessments; pad provision | Training certificates | `[grounded]` CV |
| G4 | Caseload (R11) | transferability | Home visiting, no caseload of your own | Expect a probe on prioritising and autonomy | Planning your own day of discharge-to-assess visits; escalating on your own judgement in a patient's home | Limit: say plainly that you haven't held a caseload | `[grounded]` CV and your statement; `[generic]` that interviews for this kind of role probe it |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Post not found on careers page | unknown | — | "Current vacancies are listed on our careers page" | The page may have moved, or the post may be advertised only on a jobs board | `[grounded]` the careers page fetch returned no page | Is this post still open, and where is it advertised? | unresolved |
| RR2 | Caseload size and support unstated | unknown | — | "a small caseload of your own, supported by a senior community nurse" | "Small" and "supported" may mean little in practice | `[inferred]` from the advert's silence | How many patients would I start with, and how often would I work alongside the senior nurse? | unresolved |
| RR3 | Pay stated and in line with the market | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Transparent and fair | `[grounded]` advert; `[generic]` survey band | Where on the range would five years' experience start? | noted |
| RR4 | Pool cars plus mileage | positive_signal | — | "pool cars are provided… plus mileage" | Mileage may mean you sometimes use your own car | `[inferred]` from the two together | Is a pool car always available, or do staff sometimes drive their own? | noted |
| RR5 | Team lead's public interest in Doppler training | positive_signal | — | Forum page: spoke on "Doppler training for staff new to community work" | Doppler may be taught to new starters here | `[grounded]` forum speaker page; `[inferred]` for this team | Is Doppler training offered to new starters, and when? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move the secondment up to its own bullet, in your own words: "Seconded for 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge." Don't call it community or district nursing experience | see R10, R11 | `[grounded]` CV wording | resume_edits_pending_approval |
| E2 | Add records, leg-ulcer, continence and end-of-life lines only once G1–G3 are confirmed | see R4–R9 | `[grounded]` gap rows | pending your approval |
| A1 | Take up the informal chat with Rhiannon Mabbott, asking RR1, RR2 and RR5's questions | The advert invites it, and her public talks cover the Doppler gap | `[grounded]` advert; forum page | pending your approval |
| A2 | Say "never held my own caseload" plainly, and lead with planning your own home visits | see R11 | `[grounded]` your statement | pending your approval |

## Evidence status

Verified: none yet. Your National Insurance number isn't needed to judge this role, and I haven't used it.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and got "About Calderbrook Community Health" (calderbrookhealth.example/about), which confirms the organization row. Fetched calderbrookhealth.example/careers, which returned no page, giving RR1 |
| 2. Role-family sweep | yes | Searched "Agenda for Change Band 5 pay scale 2026 community staff nurse" and got the "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide), which gives the market calibration and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott community nursing team lead" and got her forum speaker page (communitynursingforum.example/speakers/rhiannon-mabbott), which gives RR5 and A1 |

I can write all of this up as a `tuesday-dossier.md` file if you'd like to keep it.

## Upgrade menu

- Your answers to G1–G3 → R4, R5b, R6b, R7 and R9 move to known; G1 alone clears condition (1).
- The live posting link or job reference → RR1 closes.
- Your NMC register entry → R1 reaches `high`.
- A deeper research pass on Calderbrook (inspection reports, staff reviews, recent news; up to 5 more searches and 2 more fetches) → just say the word and it runs.

## Questions

**G1:** Which patient record systems have you documented on, and have any of your records been audited?
**G2:** Have you cared for patients at end of life (syringe drivers, anticipatory medicines, fast-track discharges), and have you written care plans, on the ward or on discharge-to-assess visits?
**G3:** Any leg-ulcer work (compression bandaging, venous ulcer dressings) or continence assessments beyond catheter care?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.