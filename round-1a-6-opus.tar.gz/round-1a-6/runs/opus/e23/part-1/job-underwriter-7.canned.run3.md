I've done a first-pass check of the role against your CV. I didn't use your National Insurance number. It isn't needed to judge fit, and I'd leave it off your CV. It only matters after an offer.

## Decision snapshot

**Yes, it's worth applying for, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (Clear, timely written records)
- `important`: direct: R5a, R6a, R8 · adjacent: R10 (Caring for housebound adults in their own homes), R11 (A small caseload of your own) · unclear: R5b (Leg-ulcer care), R6b (Continence care), R7 (End-of-life visits), R9 (Care planning)
- `preferred`: absent: R12 (Doppler assessment for leg ulcers)

R4 is the one must-have your CV doesn't mention. R10 and R11 (both `medium`) are credible bridges with their limits named. R12 is desirable only.

**Opportunity ledger.** What I can see looks sound. The employer exists as the advert describes (RR2), the pay sits within the role-family band (RR1), and there's visible support for nurses new to community work (RR4). Still open: whether the posting is live (RR3), how big the caseload is (RR5), the working pattern (RR6) and the employment terms (RR7).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) your record-keeping is confirmed, ideally including an electronic patient record (R4, G1); (2) you present R10 and R11 honestly as home-visit experience from discharge-to-assess (D2A), never as having held a caseload; (3) the caseload size and the working pattern hold up at the informal chat (RR5, RR6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehab across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` employer's About page |
| Mandate | District nursing for housebound adults: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, all recorded on an electronic patient record | `[grounded]` advert |
| Structure | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Terms stated | Band 5, £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` advert |
| Scope read | Reads as an entry-level community post for nurses new to the setting | `[inferred]` from the supported small caseload and Doppler being desirable only |
| Market calibration | Community staff nurse, Band 5, England: median basic pay £34,300, middle half £32,400–£36,600. The advert's range brackets this. It's a market band, not this employer's offer | `[generic]` Wardround 2026 UK Community Nursing Pay Guide (n=1,240); `[grounded]` advert |
| Unknowns | Hours and rota; caseload size; Agenda for Change (AfC) terms and pension; start date; whether the posting is live | — |
| Contradictions | None between the advert and the About page. The careers page address returned no page | `[grounded]` search result and fetch |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult | hard_gate | direct | medium | none | CV gives PIN, Adult, active, revalidation March 2028. Not yet checked against the register | `[grounded]` CV | Optional: NMC register check raises it to high |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV: full UK licence, category B | `[grounded]` CV | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse | `[grounded]` CV | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | CV is silent on documentation and on any electronic record system | `[grounded]` CV silence | G1 |
| R5a | Wound care | important | direct | medium | none | CV: pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R5b | Leg-ulcer care | important | unclear | low | discovery | Leg ulcers are not named among your wound types | `[grounded]` CV silence | G2 |
| R6a | Catheter care | important | direct | medium | none | CV: catheter care | `[grounded]` CV | none |
| R6b | Continence care (beyond catheters) | important | unclear | low | discovery | CV names catheters only | `[grounded]` CV silence | G3 |
| R7 | End-of-life visits | important | unclear | low | discovery | CV silent; an acute medical ward and D2A could plausibly include it, but nothing says so | `[inferred]` from the settings named | G4 |
| R8 | Insulin administration | important | direct | medium | none | CV: insulin administration | `[grounded]` CV | none |
| R9 | Care planning | important | unclear | low | discovery | CV silent | `[grounded]` CV silence | G5 |
| R10 | Caring for housebound adults in their own homes | important | adjacent | medium | transferability | 18 months visiting patients at home in their first week after discharge. Limit: short-term post-discharge visits, not ongoing care of housebound patients | `[grounded]` CV | G6 |
| R11 | A small caseload of your own | important | adjacent | medium | transferability | You've never held your own caseload (your words); the D2A home visits are the nearest work. Limit: no caseload ownership. The advert pairs this with senior support | `[grounded]` your statement; `[grounded]` advert | G6 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You've never done one (your words). Closure path: training. The team lead has spoken on Doppler training for staff new to community work | `[grounded]` your statement; `[grounded]` forum speaker page | Raise at the informal chat (A1) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records (R4, must_have) | discovery | Nothing on documentation or record systems | The one must-have at `unclear`. Resolving it likely moves the status to `go` | Typing notes into the hospital's electronic system; D2A visit notes written in patients' homes; documentation audits; handover notes | An appraisal comment or audit result (never a patient record) | `[grounded]` CV silence; `[inferred]` that it moves the status |
| G2 | Leg-ulcer care (R5b) | discovery | Pressure ulcers and surgical wounds only | Core work for this team and the area the team lead has spoken on | Dressing venous leg ulcers on the ward or on D2A visits; compression bandaging; tissue-viability referrals | A wound-care course certificate | `[grounded]` CV; `[grounded]` forum speaker page |
| G3 | Continence care (R6b) | discovery | Catheters only | A named duty | Continence assessments, product reviews, bowel care | A training record | `[grounded]` CV silence |
| G4 | End-of-life visits (R7) | discovery | Nothing stated | A named duty | Caring for dying patients on the ward; just-in-case medicines; syringe drivers; family conversations | A syringe-driver competency | `[grounded]` CV silence |
| G5 | Care planning (R9) | discovery | Nothing stated | A named duty | Writing or updating care plans on the ward or in D2A | An appraisal note | `[grounded]` CV silence |
| G6 | Home visits and caseload (R10, R11) | transferability | D2A home visits; no caseload of your own | The bridge has to be told with its limit | Planning your own visit list in D2A; deciding when to escalate or discharge | — | `[grounded]` CV and your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay at or around market | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range brackets the market's middle half | `[grounded]` advert; `[generic]` Wardround 2026 survey | Where on the range would someone with five years post-registration start? | noted |
| RR2 | Employer exists as described | positive_signal | — | "Calderbrook Community Health CIC, Halifax" | An established NHS-contracted provider | `[grounded]` About page | Which NHS contract funds the service, and how long does it run? | noted |
| RR3 | Posting not found on the employer's site | unknown | — | (careers address returned no page) | It may simply be listed elsewhere | `[inferred]` from one failed fetch | Where is this vacancy advertised, and what's the closing date? | unresolved |
| RR4 | Support for nurses new to community work | positive_signal | — | "supported by a senior community nurse" | The team lead has spoken publicly on Doppler training for this group | `[grounded]` advert; `[grounded]` forum speaker page | What does support look like in the first months, and is Doppler training offered? | noted |
| RR5 | Caseload size undefined | unknown | — | "a small caseload of your own" | "Small" could mean anything | `[inferred]` from the advert's silence | How many patients, and roughly how many visits a day? | unresolved |
| RR6 | Working pattern unstated | unknown | — | (no hours stated) | District nursing services often run evening or weekend rotas | `[generic]` role-family pattern | What are the hours, and is there a weekend or evening rota? | unresolved |
| RR7 | Terms beyond the band unstated | unknown | — | "Band 5" | A CIC may pay on the AfC bands without all NHS terms | `[generic]` pattern for non-NHS providers | Are the terms AfC, including the NHS Pension? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Give the D2A secondment its own bullet in your own words: "visiting patients at home in their first week after discharge". Don't call it community nursing or a caseload | see R10, R11 | `[grounded]` CV | pending your approval |
| E2 | Add leg-ulcer, continence, end-of-life and care-planning experience only once you confirm it | see R5b, R6b, R7, R9 | `[grounded]` gap queue | pending your approval |
| A1 | Take up the informal chat with Rhiannon Mabbott, and ask the RR3, RR5, RR6 and RR7 questions there | The advert invites contact | `[grounded]` advert | pending your approval |
| A2 | Lead with wound care and D2A home visits. Say plainly that you haven't done Doppler or held a caseload | Her public work centres on leg ulcers and Doppler training | `[grounded]` forum speaker page | pending your approval |

## Evidence status

Verified: none yet. Not used: your National Insurance number.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, which returned no page. Moved the organization row, RR2 and RR3 |
| 2. Role-family sweep | yes | Searched "Agenda for Change Band 5 pay scale 2025/26 community staff nurse district nursing", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott community nursing team lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved R12, RR4 and A2 |

If you'd like a `tuesday-dossier.md` of this assessment to keep and build on, just say so.

**Upgrade menu**
- A screenshot of your NMC register entry would raise R1 to `high`.
- Answers to G1–G5 would resolve R4, R5b, R6b, R7 and R9, and could move the status to `go`.
- Your constraints (hours, weekends, on-call, pay floor) would let me check the hard gates against them.
- A link to the live advert, such as an NHS Jobs listing, would close RR3.
- A deeper research pass would cover the service's CQC reports, staff reviews and recent news, using up to 5 more searches and 2 more fetches. Say the word and it runs.

**Questions**

G1: On the ward or in D2A, how did you keep records? Was it an electronic system, and did you write notes in patients' homes?

G2, G3, G4, G5: In your ward or D2A work, have you done any of these: leg-ulcer dressings or compression, continence assessments, end-of-life care, or writing care plans?

Constraints: Is there anything you can't work, such as weekends, evenings or on-call, or a pay floor you won't go below?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.