I've written a full prep pack for Thursday's panel. It's built from the invite, your résumé, and some research on the district and Principal Vantongeren. One thing first: your résumé included your Social Security number and your educator ID number. I didn't use either and they aren't in the pack. You don't need them for interview prep, and it's safest to give your SSN only to HR once there's an offer.

**What the pack covers:**

- **Your fit against the role.** Your license fully meets the one stated requirement: the grades 1–6 elementary endorsement includes fourth grade.
- **Your biggest weak spot.** The panel will see six years of third grade and no fourth grade, so that question will come up. The pack gives you an honest answer to rehearse: say plainly that you haven't taught fourth grade, then point to your six years of third grade, then explain how you'd get up to speed.
- **A line to be careful with.** Your résumé says you led your grade level's move to a new reading curriculum, and you've also told me you've never been a team lead. Both are true, and the pack shows you how to say both without letting "led the move" turn into "led the team."
- **What the district cares about:**
  - The district's hiring page says panels ask about reading instruction, classroom routines and how you work with families.
  - The district has three published beliefs: Every Child a Reader, Families Are Partners, and Teach for Tomorrow, Not for the Test.
  - A new grades 3–5 reading curriculum starts in fall 2027. Your 2024 curriculum work fits that directly.
- **The principal.** She was a reading specialist for nine years before becoming principal, and she gave a 2025 talk on small-group reading. Expect her reading questions to go deep.
- **Practice questions.** There are 22, each with answer guidance, plus 7 questions for you to ask the panel and a short list of claims to avoid making.

Several answers have blanks only you can fill in honestly, like how you teach reading day to day or a routine you rely on. The pack marks these and gives you two honest ways to answer each.

The job posting I used is a typical fourth-grade posting from a job board, not Halvering's own, so rows based on it are marked as inferred.

If you'd like, I can play the principal and run the "never taught fourth grade" question with live follow-ups. I can also save a tuesday-dossier.md file recording the gaps this prep found, for future sessions, or convert the pack to a Word document.

Do you have Halvering's actual job posting? If you paste it, I'll swap out the borrowed job-board posting. I can also do a deeper research pass (up to 6 more searches, several more minutes) on the district's priorities and the principal's talk, if you want it.

Files are in /var/tmp/tuesday-measure/1a6/runs/opus/e23/part-3/rooms/case-9-canned-7af8b07b:
- Halvering_fourth-grade-teacher_interview_pack.md

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**District:** Orrinsford Community School District
**Format:** 45-minute panel with Principal Dolores Vantongeren (who acts as the hiring manager) and two fourth-grade teachers (who act as peers)
**Built from:** the HR invitation, the résumé text you pasted, and L1 research (see Sources). Halvering's own job posting wasn't provided, so rows that depend on it use a representative fourth-grade posting and are labeled `[inferred]`.

---

## How to use this pack

- **Personas** describe *how* a question is asked: who asks it and in what tone. **Types** describe *what is being scored*. Every question has both.
- **Type key:**
  - **VAL**: values. Does your past behavior show the district's *published* beliefs?
  - **EXP**: experience deep-dive. Do your résumé lines hold up under follow-up questions, and which part was actually yours?
  - **JD**: role-driven. Can you do the listed job, including the parts you haven't done yet?
  - **CO**: district knowledge. Do you know what Orrinsford is working on right now?
  - **CASE**: a live problem. Can you think through a classroom situation out loud?
- **Provenance labels:** `[grounded]` means it traces to your words, the invite, or a cited source. `[inferred]` means it comes from a representative posting or is the pack's own derivation. `[generic]` means a common pattern for this kind of role, with no claim about Halvering or about you.
- **Answer slots** are spots where the pack doesn't know the answer. Each slot gives two honest branches. Fill one in, in your own words, from what actually happened.
- Guidance is scaffolding, not a script. Every guidance cell should be speakable in about two minutes.
- Question IDs go by persona (A, B, C, D, E, G, H). The letter F is skipped because the fit-snapshot rows use F1–F9.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — HR invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The gate is met as your CV states it, and grades 1–6 includes fourth grade. It's medium only because nothing has been inspected yet: bring a printed copy of your license record. You don't need to say ID numbers aloud in the panel |
| F2 | "experience in grades 3 to 5 preferred" — representative fourth-grade posting, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | none | Third grade falls inside the 3–5 range that posting names. Words: "I've taught third grade for six years, at a public elementary school in Joliet." Halvering's own posting isn't in hand, so treat this as typical of the role, not as Halvering's stated preference |
| F3 | The role itself: "Fourth Grade Teacher position" — HR invite | "I've never taught fourth grade and I've never been a team lead." — your message | none | [grounded] | capability | Wording can't close this gap, and you've said so yourself. Words: "I haven't taught fourth grade." Then F2's quote at its own scope. Then how you would learn the fourth-grade curriculum and pacing, said as a plan and never as a past. Add nothing to make the gap feel smaller |
| F4 | "plan and teach reading, writing, math, science and social studies" — representative posting | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [inferred] | discovery | Your material says third grade but not which subjects. Answer slot: if you taught all five, say so and say which you're strongest in, in your own words. If some weren't yours to teach, say so plainly and stay with the ones you did teach |
| F5 | "reading instruction" — Orrinsford's teacher-hiring page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years." — your CV | medium | [grounded] | discovery | Both quotes are reading work. Neither shows how you teach reading in your own classroom day to day, and that's the district's named panel topic. Answer slot: describe how you actually teach reading in your classroom, in your own words. If a curriculum set most of it, say so plainly and say which choices were yours |
| F6 | "work with the grade-level team" — representative posting | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never taught fourth grade and I've never been a team lead." — your message | medium | [inferred] | none | Leading your grade level's move to a new curriculum is grade-level teamwork, in the quote's own terms. Keep both the verb and its object: you led the *move*. Your message says you've never been a team lead, so "led the move" must never turn into "led the team" |
| F7 | "how you work with families" — Orrinsford's teacher-hiring page | "I write a weekly email to families." — your CV | medium | [grounded] | none | A weekly email to families is family communication, in your own words. The district's Families Are Partners belief says each teacher *speaks* with every family each term. An email is writing, not speaking, so expect D2 to press on it |
| F8 | "differentiate instruction using assessment data" — representative posting | none given | none | [inferred] | discovery | Strong evidence here would be a specific case where an assessment result changed what you taught next. Answer slot: if you've adjusted groups or lessons based on assessment results, say how, in your own words. If you haven't, say so plainly and say how you would |
| F9 | "classroom routines" — Orrinsford's teacher-hiring page | none given | none | [grounded] | discovery | Strong evidence here would be a routine you can name and the reason it works for eight- and nine-year-olds. Answer slot: if you have a routine you rely on, name it and say why, in your own words. If none comes to mind, say so plainly and describe how you would set one up in the first week |

**Highest-ROI prep in this pack: B1.** The panel can see six years of third grade and no fourth grade (F3). That objection will come up in some form, so rehearse it until it's boring. **B2** is a close second. "Led our grade level's move" sitting next to "never been a team lead" is exactly the line a careful panel will pull on.

---

## Reading the interviewer: Principal Dolores Vantongeren

| Public fact | Source | What it means for Thursday |
|---|---|---|
| Principal of Halvering Elementary since 2022 | Illinois principals' forum speaker page (Sources) | She has led this building for four years, so expect questions in Halvering's own terms |
| Nine years as a reading specialist before becoming principal | Same page | Reading questions from her are likely to go a level deeper, into *how* and not just *what*. Rehearse A2, A4 and the F5 slot |
| Gave a 2025 forum talk, "Small Groups, Big Readers", on weekly reading conferences in grades 3 to 5 | Same page | Small-group reading is a topic she has spoken about publicly. A2 rehearses it as a live problem. Don't claim the practice unless it's actually yours; describe what you do, or what you would do |

Mirror opportunity: none offered. Her path runs from reading specialist to principal, and nothing in your fit snapshot carries a matching move, so the pack doesn't invent one. Reverse question R1 engages her path honestly instead.

The two fourth-grade teachers aren't named, so they're read as peers from the round's structure alone.

---

## Persona weights

The format is set by the invite: one 45-minute panel. Orrinsford's hiring page describes the same format, a principal plus two grade-level teachers, asking about "reading instruction, classroom routines and how you work with families". For a panel, the pack blends the top two personas of each member's role. That's Case/Strategist and Skeptic for the principal, and Peer Evaluator and Prober for the teachers. Neither the hiring page nor the invite names a values round, so there's no values cheat sheet. The D bank is still themed on the district's three published beliefs, because the beliefs page says they "guide every hire".

| Persona | Most likely from | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| A. Case / Strategist | Principal | Classroom scenarios: a struggling reader, routines falling apart, data after a unit | High. She's in the hiring-manager seat, the district names reading and routines as panel topics, and her background is in reading | Clarify, then say what you'd look at first, then what you'd do this week, then how you'd know it worked. Think aloud |
| B. Skeptic | Principal | Quiet "help me understand" probes on the fourth-grade gap and the team-lead line | High. F3 is the most visible gap, and F6 next to F3 is the easiest inconsistency to spot | Plain acknowledgment first, then your evidence at its own scope, then a concrete ramp-up plan said as a plan |
| C. Peer Evaluator | Fourth-grade teachers | "What would you bring us, what would you need from us, how do you handle disagreement" | High. They will share planning and families with whoever is hired | Reciprocity. Say what you need as plainly as what you bring |
| D. Values / Behavioral | Any member | Questions shaped by Every Child a Reader, Families Are Partners, and Teach for Tomorrow, Not for the Test | Medium. The beliefs "guide every hire", but no round is dedicated to them | Pick a real moment for each belief. If none comes to mind, say so and say how you'd act on it |
| E. Data-Driven Prober | Fourth-grade teachers | "How many kids, how did you know it worked" | Medium. Peers weigh what you'd add, and the club and the curriculum move invite outcome questions | Know what you did and didn't track, and say plainly when something wasn't measured |
| G. Conversational | Principal, at the opening | "Tell us about yourself", casual reading talk | Medium. Every panel opens this way, and the casual tone still gets scored | A 90-second arc built only from your four résumé lines |
| H. Pressure | Principal | Time-boxed "why you" and "how much was you" | Low to medium. A school panel is rarely hostile, but both questions are cheap to ask | Pause, hold what your quote carries through two follow-ups, then concede the specific limit |

---

## Question banks

### A. Case / Strategist (principal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The district adopts a new grades 3–5 reading curriculum in fall 2027. As part of our fourth-grade team, how would you help us get ready?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Show you know the plan: the Board adopted it in August 2026, and the new 3–5 curriculum starts fall 2027. Then bring your own experience at its exact scope: in 2024 you led your grade level's move to a new reading curriculum. Answer slot: the posting's "work with the grade-level team" line makes a probe on how that move ran likely. If there were steps that were yours, say which and what you'd repeat or change, in your own words. If a step wasn't yours, say so plainly and stay with the fact that you led the move. Close with what you'd want to learn about Halvering first. Don't claim you know their materials | A researched district priority (Sources), and the clearest place where F5/F6 meet Halvering's next two years. CO because it tests homework, with CASE delivery |
| A2 | "Walk me through how you'd run small-group reading in a fourth-grade class." | CASE | [grounded] | Structure it: how you'd form the groups and from what evidence, what one group session holds, what the rest of the class is doing meanwhile, and how you'd track progress week to week. This is a live problem, so the answer needs no claim about your past. If small groups *are* how you teach now, you can say so and describe it in your own words. If not, describe the plan without implying you've run it | The district names reading instruction as a panel topic, and small-group reading is the principal's published theme. CASE because it scores reasoning, not record |
| A3 | "It's week three and transitions keep eating your mornings. What do you do?" | CASE | [generic] | Clarify which transitions and when. Name the routine you'd teach or reteach, how you'd practice it with the class, how you'd signal it, and how you'd check by Friday that it's working. Keep it concrete and age-appropriate. No claim about your past is needed | "classroom routines" is a named panel topic (F9). `[generic]` because it's a pattern for the problem, not a fact about Halvering |
| A4 | "A new fourth grader is reading about two years below grade level. What does your first month with them look like?" | CASE | [grounded] | What you'd find out first (the reading plan from last year, if one exists, plus your own check), what support looks like inside your reading block, how you'd involve the family, and what progress you'd look for by the end of the month. The district's belief that no student leaves third grade without a reading plan is worth naming here: say you'd start from that plan | Ties Every Child a Reader (Sources) to a fourth-grade problem. CASE delivery, VAL theme |
| A5 | "On a unit check, about a third of your class misses the same math skill. What happens next week?" | CASE | [inferred] | Look at what the wrong answers have in common. Regroup: reteach a small group while the rest extend. Recheck quickly. Adjust the pacing calendar. Name the district's line, "assessments inform teaching and never replace it", only if it fits naturally. No claim about your past; if you've done this, describe what you actually did | Covers the posting's "differentiate instruction using assessment data" (F8) and a non-reading subject (F4). `[inferred]` because it rests on the representative posting |

### B. Skeptic (principal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've taught third grade for six years, but never fourth. What makes you ready for this class?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead."; "Six years teaching third grade at a public elementary school in Joliet." | **Highest-ROI rehearsal.** Lead with the limit before they press: "I haven't taught fourth grade." Then hold only what your quote carries: "I've taught third grade for six years, at a public elementary school in Joliet." Then the ramp-up, said as a plan: how you'd learn the fourth-grade standards and pacing before and during the first weeks, and what you'd ask of the team. Answer slot: if any of your work has touched fourth-grade material or the third-to-fourth handoff, say how, in your own words. If none has, say so plainly and stay with the six years. Follow-up 1, "What will be hardest?": name one real thing. Follow-up 2, "How will you know you're behind?": name the check you'd use. Never say third and fourth grade are basically the same | F3 is the gap the panel can see from the résumé alone, so it will be asked in some form. JD because it scores the role itself. Deepest rehearsal because a calm, specific answer here changes how the rest of the panel reads you |
| B2 | "Your résumé says you led your grade level's move to a new curriculum, but you've never been a team lead. What exactly did you lead?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never taught fourth grade and I've never been a team lead." | Both statements are true, and say so straight: "I haven't been a team lead. In 2024 I led our grade level's move to a new reading curriculum." Answer slot: say which parts of that move were yours to decide or do, in your own words. Where someone else decided something, say so plainly and stay with what you led. Hold through two follow-ups by returning to the move, never by enlarging it | F6 next to F3 is the inconsistency a careful panel spots. EXP because it tests attribution |
| B3 | "What part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." | Name a real weakness, not a disguised strength. The one you've already stated is fourth grade itself: "I haven't taught fourth grade." Then say what you'd do about it in the first month, as a plan | A standard Skeptic stem. JD because it asks for honest self-assessment against the role |
| B4 | "Why this move, and why Halvering?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: your actual reasons, in your own words. The pack doesn't know them, and invented motives fall apart under one follow-up. You can connect your reasons to something you learned in research: the 2026–2029 literacy plan, the three beliefs, or the principal's focus on reading. Do that only if it's genuinely part of your reason | A motivation-consistency probe the Skeptic always asks. JD because it tests fit with this role |

### C. Peer Evaluator (fourth-grade teachers)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "If you joined our grade-level team, what would you bring, and what would you need from us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years."; "I've never taught fourth grade and I've never been a team lead." | Bring: what your quotes carry. You led a grade level's move to a new reading curriculum in 2024, and you've run an after-school reading club for two years. Both matter with a new 3–5 curriculum coming. Need: be plain about it. "I haven't taught fourth grade, so I'd lean on you for pacing and what fourth graders find hardest." Asking for help reads as a strength in front of peers | Peers price what a hire adds to and takes from their load. JD because of the posting's grade-level team line (F6) |
| C2 | "Tell us about a time you disagreed with a colleague on your grade level. How did it end?" | EXP | [inferred] | Selection scaffold: pick a real disagreement with a named stake, show how you raised it, and say how it ended, including whether the working relationship stayed intact. If the 2024 curriculum move included such a moment, you can use it, in your own words. If no such time comes to mind, say so plainly, then say how you'd handle one | A standard peer probe on disagreement style. `[inferred]` because the theme comes from the representative posting's team line |
| C3 | "Say your weekly family email and a teammate's newsletter tell families different things about the same event. What do you do?" | CASE | [grounded] "I write a weekly email to families." | Live problem: fix it with the teammate first, send one correction to families, and agree on how to stay aligned going forward. You can mention that you write a weekly email to families. Don't describe a coordination system you haven't used | The seam between teammates who talk to the same families (F7). CASE because it asks for a decision |

### D. Values / Behavioral (themed on the district's three beliefs)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Every Child a Reader is one of our beliefs. Tell me about a student who wasn't reading on track, and what you did." | VAL | [grounded] "I've run the after-school reading club for the last two years." | Selection scaffold: pick one real student (no names), the moment you noticed, what you did, and what changed or didn't. The reading club can be the setting if the story actually happened there. If no single student comes to mind, say so plainly, then give the nearest thing you do have, or how you'd handle it | Uses the published belief's exact name (Sources). VAL because it scores past behavior against that belief |
| D2 | "Families Are Partners here: we expect every teacher to speak with every family each term. How do you reach the families who don't reply?" | VAL | [grounded] "I write a weekly email to families." | Start with what you do: you write a weekly email to families. Answer slot: the belief is about *speaking* with every family each term. If you already do that, say how, in your own words. If your contact has mainly been the email, say so plainly and say how you'd meet the each-term standard at Halvering | The published belief says "speaks with every family each term", and F7's evidence is an email, so this is the gap on that line. VAL because it tests the belief directly |
| D3 | "Tell me about a time a test result changed what you taught." | VAL | [grounded] | Selection scaffold: one assessment, what it showed, what you changed the next week, and what happened. That's the district's "assessments inform teaching and never replace it" in practice. If no such time comes to mind, say so plainly, then say how you would use results that way | Themed on Teach for Tomorrow, Not for the Test (Sources). Also covers F8 |

### E. Data-Driven Prober (fourth-grade teachers)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You've run the after-school reading club for two years. How do you know it helps?" | EXP | [grounded] "I've run the after-school reading club for the last two years." | The beats your quote carries: you run it, and you have for two years. Answer slot: if you tracked anything, such as attendance or reading progress, say what and how, in your own words. If nothing was measured, say so plainly ("I haven't measured it formally") and describe what the club is. Don't give attendance numbers or results you can't back up | The club is a résumé line peers will ask about. EXP because it tests whether the line holds up. The posting's assessment-data line (F8) makes the "how do you know" follow-up likely |
| E2 | "On the 2024 curriculum move: what changed for students, and how could you tell?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if you saw changes and know how they showed up (work, assessments, engagement), say what, in your own words. If you don't know, or it wasn't measured, say so plainly and stay with what the move involved for you. The weakest-assumption move: if you cite any change, say what else could explain it before they do | The outcome question on F5/F6. EXP because it probes whether the move's results are yours to claim |

### G. Conversational (principal, at the opening)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, tell us a bit about yourself." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years."; "I write a weekly email to families." | A 90-second arc built only from these four lines: six years teaching third grade in Joliet; in 2024 you led your grade level's move to a new reading curriculum; you've run the after-school reading club for two years; and you write a weekly email to families. Answer slot: end with why fourth grade at Halvering, in your own words | Every panel opens this way, and the casual tone still gets scored. EXP because it sets up everything they'll probe later |
| G2 | "Just to confirm: is your license current, and does it cover fourth grade?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | "Yes. My Professional Educator License carries an Elementary Education endorsement for grades 1–6, and it's active through June 30, 2029." Have a printed copy ready. Give identifying numbers only to HR, and only if they ask | The invite names this as the one hard requirement (F1). JD because it's the stated qualification |

### H. Pressure (principal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you, over someone who's already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead."; "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024" | Pause. Then keep it short: "I haven't taught fourth grade. What I bring is six years teaching third grade, and in 2024 I led our grade level's move to a new reading curriculum." Hold that through two follow-ups. Concede the specific limit, the fourth-grade curriculum, and nothing more | F3 under time pressure. JD because it scores the role gap. Hold-then-concede on what the quotes carry |
| H2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold the quote without shrinking it: "I led our grade level's move." Answer slot: say which parts were yours and which were others', in your own words. If the curriculum was chosen above your grade level, say so plainly. Don't give away the "led" your résumé honestly states, and don't stretch it either | The attribution probe on F5/F6. EXP because it checks the verb |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 License with elementary endorsement | G2 |
| F2 Grades 3–5 experience | B1, H1 |
| F3 Fourth grade itself | B1, B3, H1, C1 |
| F4 All five subjects | A5. The math scenario is the only non-reading subject covered, because no source raises science or social studies specifically. The F4 slot covers the rest |
| F5 Reading instruction | A1, A2, A4, D1, E2 |
| F6 Grade-level team | A1, B2, C1, C2, H2 |
| F7 Working with families | C3, D2 |
| F8 Differentiating with assessment data | A5, D3, E1 |
| F9 Classroom routines | A3 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | (To the principal) "You came to this role after years as a reading specialist. How does that shape what you hope to see in fourth-grade reading at Halvering?" | It engages her public path, not flattery, and it hands her a topic she has spoken on |
| R2 | "Every Child a Reader says no student leaves third grade without a reading plan. How do those plans carry into fourth grade here?" | It uses your third-grade vantage point to ask a fourth-grade question, and it shows you read the beliefs closely |
| R3 | "With the new grades 3–5 curriculum arriving in fall 2027, what part will the fourth-grade team play in getting ready?" | It shows you know the literacy plan, and it invites them to picture you in that work |
| R4 | (To the teachers) "What could a new person do in the first month that would genuinely help your team?" | A reciprocity question. It signals you're thinking about their workload, not just your own ramp-up |
| R5 | "What does speaking with every family each term look like here in practice?" | It shows you take Families Are Partners seriously, and the answer tells you what the job really asks |
| R6 | "What do your students find hardest about the step up from third grade?" | It plays to your strength, and their answer gives you a ready-made ramp-up plan |
| R7 | "How does the fourth-grade team take part in the family reading nights each term?" | It ties the literacy plan's family reading night to your weekly family email and reading club |

---

## Prohibited claims: what this pack will not coach

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or "has basically taught fourth-grade content" | A negative you stated, F3 | "I haven't taught fourth grade." No slot |
| Has been a team lead or grade-level lead | A negative you stated, F3/F6 | "I haven't been a team lead." Alongside it, F6's quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024" |
| Led the grade-level team | Inflated form of F6's quote | F6's quote at its own scope. Your material says you led the move, not the team. B2's and H2's slots stay inside the move |
| Chose or designed the new reading curriculum | Inflated form of F5's quote | F5's quote at its own scope. Your material says the move to a new curriculum, not selecting or writing it. H2's slot asks only which parts of the move were yours |
| The reading club raised students' reading levels | Inflated form of F5's club quote | "I've run the after-school reading club for the last two years." E1's slot asks only what, if anything, was tracked |
| Speaks with every family each term | Inflated form of F7's quote (an email is writing, not speaking) | "I write a weekly email to families." D2's slot asks whether you also speak with families, and allows that the email has been the main channel |

---

## Sources

**Provided documents**

- The HR invitation from Orrinsford Community School District (as pasted)
- Your résumé text (as pasted). A Social Security number and an educator ID number were also included. Neither was used or needed for this prep, and neither appears in this pack.

**Searches and fetches**

| Query or URL | What came back |
|---|---|
| Search: Orrinsford Community School District mission values | orrinsfordschools.example/about/mission-and-beliefs |
| Search: Orrinsford Community School District teacher interview process | orrinsfordschools.example/careers/how-we-hire-teachers |
| Search: Halvering Elementary School Orrinsford news 2026 | orrinsfordschools.example/news/board-adopts-literacy-plan |
| Search: Dolores Vantongeren principal Halvering Elementary | ilprincipalsforum.example/speakers/dolores-vantongeren |
| Search: fourth grade teacher job description Illinois school district posting | k12jobsboard.example/listings/fourth-grade-teacher |
| Fetch: orrinsfordschools.example/about/mission-and-beliefs | The three beliefs, with their definitions |
| Fetch: k12jobsboard.example/listings/fourth-grade-teacher | The full responsibilities and qualifications of the representative posting |

**Target accounting**

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | The three beliefs by name and definition. They theme D1–D3, A4 and R2/R5. No cheat sheet, because no values round is documented |
| 2. Orrinsford teacher interview process | yes | Confirms one 45-minute panel of the principal and two grade-level teachers, and the topics "reading instruction, classroom routines and how you work with families". Sets the persona weights and the requirements for F5, F7 and F9 |
| 3. District strategy and recent news | yes | The 2026–2029 literacy plan, with a new grades 3–5 curriculum from fall 2027 and a family reading night each term. Feeds A1, R3 and R7 |
| 4. Dolores Vantongeren, Halvering | yes | Principal since 2022, previously a reading specialist, and the 2025 talk on small-group reading. Feeds the interviewer read, A2 and R1 |
| 5. Representative fourth-grade posting | yes | No Halvering posting was supplied. This posting supplies F2, F4, F6 and F8, all labeled `[inferred]` |

---

## Upgrade menu

- **Halvering's actual job posting** → rows F2, F4, F6 and F8 become `[grounded]` or get replaced, and the JD-tagged questions are retuned to Halvering's own wording
- **The two fourth-grade teachers' names** → a persona assignment for each member and a reverse question tailored to each
- **A printed copy of your license record** → F1 rises from medium to high. Bring it Thursday either way
- **Your answers to the slots in F4, F5, F8 and F9** (subjects taught, how you teach reading, using assessment results, a routine you rely on) → A2, A3, A5, D1 and D3 become story-mapped on your own words instead of scaffolds
- **How much prep time you have before Thursday** → a prioritized prep schedule sized to it
- **A tuesday-dossier.md from an earlier evaluation of this role** → verified evidence and an underwriter-built prohibited list, so the highest-ROI objection comes from checked evidence rather than the pack's inference
