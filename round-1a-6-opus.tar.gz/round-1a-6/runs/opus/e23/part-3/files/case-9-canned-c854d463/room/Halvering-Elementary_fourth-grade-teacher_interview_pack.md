# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**District:** Orrinsford Community School District
**Format:** 45-minute panel interview, Thursday
**Panel:** Principal Dolores Vantongeren (would be your principal, so she's the hiring manager) and two members of the fourth-grade team (would be your peers)
**Built from:** your invitation email, the résumé lines you sent, and research at the default tier (Sources, section 14). You didn't send the posting text, so the requirements below come from a typical fourth-grade posting and are marked `[inferred]`.

---

## 2. How to use this pack

- **Personas** describe *how* a question gets asked: who is asking, and in what style.
- **Types** describe *what* is being scored:
  - **VAL**: behavior that fits the district's published beliefs
  - **EXP**: a deep dive on your experience. What you actually did.
  - **JD**: the role's stated requirements, including your gaps
  - **CO**: homework on the district and school, such as the literacy plan
  - **CASE**: a live classroom problem, worked out loud
- **Provenance labels:**
  - `[grounded]`: traceable to your words, the invite, or research listed in Sources
  - `[inferred]`: derived from a representative posting, not Halvering's own
  - `[generic]`: a common pattern for this kind of role, with no claim about this school
- **Answer slots** mark places where the honest answer depends on something your material doesn't say. Each one gives two branches. Both are fine to use, and the second (saying it plainly) is never a confession.
- The guidance is scaffolding, not a script. Say it in your own words.

---

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — HR invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Your material shows this gate is met. If it comes up, one sentence in the quote's own terms: a PEL with an Elementary Education endorsement for grades 1–6, active through June 2029. Fourth grade falls inside the range the quote names. You don't need to quote your license number or any personal ID numbers in the room |
| F2 | "experience in grades 3 to 5 preferred" — representative JD | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | none | Your quote already meets a typical posting's preference: six years, third grade, a public elementary school. Say it in that order. The label is `[inferred]` because the requirement comes from a representative posting, not from Halvering's |
| F3 | "Fourth Grade Teacher position" — HR invite | "I've never taught fourth grade" — your CV | none | [grounded] | capability | No wording closes this gap, and you've said so yourself. Your words: "I haven't taught fourth grade yet." Follow with F2's quote at its own scope, then how you'd get ready, said as a plan and never as past experience. Don't add anything to make the gap sound smaller |
| F4 | "plan and teach reading, writing, math, science and social studies" — representative JD | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [inferred] | discovery | Your material says third grade but not which subjects. Answer slot: the panel will likely ask how you plan across subjects. If you taught all of them, say so and describe how you planned your week, in your own words. If your school split subjects or some weren't yours, say so plainly and stay with what you did teach |
| F5 | "plan and teach reading" (same line as F4) — representative JD | "I led our grade level's move to a new reading curriculum in 2024", "I've run the after-school reading club for the last two years" — your CV | medium | [inferred] | transferability | Both quotes are reading work next to classroom instruction, and your words stay at their scope: "In 2024 I led our grade level's move to a new reading curriculum, and for the last two years I've run the after-school reading club." Answer slot: expect a probe on how you teach reading day to day. If you can describe it, do, in your own words. If there's a part you don't have a routine for, say so plainly and come back to the curriculum move |
| F6 | "differentiate instruction using assessment data" — representative JD | none given | none | [inferred] | discovery | Your material doesn't show this either way. Answer slot: if you've changed how you grouped or taught based on assessment results, describe one time in your own words, including what the data was. If you haven't, say so plainly and describe how you'd start |
| F7 | "keep clear classroom routines" — representative JD | none given | none | [inferred] | discovery | Your material is silent here. Answer slot: if you have routines you set up every year, name them and how you teach them, in your own words. If you don't have a set approach, say so plainly and describe what you'd build in the first week |
| F8 | "communicate regularly with families" — representative JD | "I write a weekly email to families" — your CV | medium | [inferred] | none | Lead with the quote's own terms: weekly, an email, to families. Don't stretch it into phone calls or conferences your material doesn't mention |
| F9 | "work with the grade-level team" — representative JD | "I led our grade level's move to a new reading curriculum in 2024", "I've never been a team lead" — your CV | medium | [inferred] | none | Both sentences, together and at their own scope: "In 2024 I led our grade level's move to a new reading curriculum. I've never been a team lead." Answer slot: your future teammates will likely ask what leading the move meant. If you can say what you did, do, in your own words. If much of it was set by others, say so plainly and stay with the fact that you led it |

---

## 7. Reading the interviewer

**Principal Dolores Vantongeren** (public professional footprint only: a principals' forum speaker page, listed in Sources)

| What's public | Provenance | What it means for Thursday |
|---|---|---|
| Principal of Halvering since 2022, after nine years as a reading specialist | [grounded] | Reading is her home ground. Expect reading questions that go deeper than a generalist would push, and expect her to notice vague reading talk. Be concrete or say plainly what you don't know |
| Gave a 2025 forum talk, "Small Groups, Big Readers", on weekly reading conferences in grades 3 to 5 | [grounded] | Small-group reading and conferences are a likely theme (B3). Don't borrow her vocabulary for your own past. If you haven't run conferences, B3's honest branch is the answer |
| Mirror opportunity: a shared domain, not a shared career jump | [grounded] | Your F5 quote, "I led our grade level's move to a new reading curriculum in 2024", sits right in her area, and the district is moving grades 3–5 to a new reading curriculum in fall 2027 (B1). Reverse question R1 lets her talk about her own path |

**The two fourth-grade team members:** you don't have their names, so there's no read on them. The persona table treats them with peer priors.

---

## 8. Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | The principal, probing the move from third to fourth grade | High. The hiring-manager prior makes this a dominant persona, and F3 is the clearest gap in your material, in your own words | Concede F3 plainly and early, hold on F2's quote, then give a concrete plan for getting ready. Rehearse A1 until it's boring |
| B. Case/Strategist | The principal, posing live classroom and literacy problems | High. Also part of the hiring-manager prior. Her reading-specialist background and the district's August 2026 literacy plan make reading cases likely | Clarify first, then structure out loud: goal, students, approach, how you'd know it's working, risks |
| C. Peer Evaluator | The two fourth-grade teachers asking what working with you would be like | High. The peer prior, and they're pricing what you add to their planning and their load | Frame it as reciprocity: what you'd bring and what you'd need. Disagreement stories should show spine and tact together |
| D. Data-Driven Prober | Team members or the principal unpacking résumé lines like "led the move" | Medium. The peer prior's second persona. Each of your résumé lines is short, which invites "what did you actually do?" | Know exactly what each line covers. Where your material stops, say so |
| E. Conversational | The whole panel, at the opener and close | Medium. Casual questions are still scored | Use a 90-second arc built from your own lines (E1). Never say "I think you've covered everything" when they ask for your questions |
| F. Values/Behavioral | Any panelist, drawing on the district's three published beliefs | Medium. The invite names no values round, but the district says its three beliefs "guide every hire" | Answer with real instances or say plainly that you don't have one. Don't recite the slogans |
| G. Pressure | Unlikely as a style, but A1 could come back time-boxed | Low. Nothing in the invite signals a stress format. It's included so your A1 answer survives sixty seconds | Pause, restate, hold through two follow-ups, then concede only what's real |

---

## 9. Question banks

**Highest-ROI prep in this pack: A1.** "Why you, when you've never taught fourth grade?" is the most predictable objection to your candidacy. It will come up in some form, so rehearse it until it's boring. G1 is the same objection under time pressure.

### A. Skeptic (Principal Vantongeren)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade for six years but never fourth. Why should we hire you over someone who has?" | JD | [grounded] "I've never taught fourth grade" "Six years teaching third grade at a public elementary school in Joliet" | Concede first, in your own words: "I haven't taught fourth grade yet." Then hold with only what the quote carries: six years teaching third grade at a public elementary school. Then give your plan, as a plan: for example, learning the fourth-grade standards and units with the two teachers on this panel before the year starts. Follow-up 1, "What will be hardest?": name the part of fourth grade you expect to need the most help with, in your own words. If you don't know yet, say so and say how you'd find out. Follow-up 2, "So you'd be learning on the job?": hold by returning to the six years. Never suggest the grades are basically the same, and never hint at fourth-grade work you haven't done | F3 is the biggest gap and comes from your own words, so this is the objection most likely to arrive. Typed JD because it scores you against the role itself. Deepest rehearsal, per the coverage rule |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Pick the real one rather than a disguised strength. F3 is the honest candidate: "I haven't taught fourth grade yet, so the content and the pacing will be new to me." Then one concrete step from your A1 plan. Keep it to about 45 seconds | A standard Skeptic stem. With F3 stated, a dodge here would undercut A1 |
| A3 | "You led a curriculum move, but you've never been a team lead. What does leadership look like for you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've never been a team lead" | Both, at their own scope: "In 2024 I led our grade level's move to a new reading curriculum. I've never been a team lead." Answer slot: she'll likely ask what leading the move involved. Say what you did, in your own words. If much of it was set by others, say so plainly and stay with the move you led. Don't widen it beyond your grade level | F9 holds both quotes. Under pressure, this is the line most likely to get inflated. Typed EXP because it tests what was actually yours |
| A4 | "What's drawing you to Halvering, and to fourth grade?" | CO | [grounded] | Your own real reasons, in your own words. Answer slot: if one of the district's published beliefs ("Every Child a Reader", "Families Are Partners", "Teach for Tomorrow, Not for the Test") or its new literacy plan is part of why you applied, name it and say why. If none is, don't pretend. Give your actual reasons | Motivation consistency is the Skeptic's core check. Typed CO because a good answer shows you've done homework on the district. Grounded in the beliefs page and literacy-plan news in Sources |
| A5 | "Moving up a grade, what support would you need from us in your first year?" | JD | [grounded] "I've never taught fourth grade" | Treat it as a planning question, not a trap. Make two or three specific asks, phrased as asks: time with the team's unit plans, a planning partner on the team, a check-in point with the principal. Then one thing you'd give back (see C1). The guidance makes no claim about your past beyond F3 | It's a softer version of A1 that a principal can use to see whether you've planned your own ramp-up. Typed JD because it's about doing the role |

### B. Case/Strategist (Principal Vantongeren)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The district is bringing in a new grades 3–5 reading curriculum in fall 2027. How would you help the fourth-grade team get ready?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Start by clarifying what's already decided and what the timeline is. Then structure it: learning the materials, planning together, students in transition, telling families, checking how it's going. Story-mapped on F5: you led your grade level's move to a new reading curriculum in 2024. Tell it in your own words. Answer slot: expect "what did you learn from that?" Say what you'd repeat and what you'd change, in your own words. If you can't point to a specific lesson, say so plainly and stay with the fact that you led it | The literacy plan adopted in August 2026 is the district's most current priority, and your F5 quote sits right in it. Typed CO (homework) with CASE delivery |
| B2 | "A student arrives in your fourth-grade class in September reading well below grade level. Walk us through your first two weeks." | CASE | [grounded] | Structure: what you'd check first, who you'd talk to (the family, last year's teacher, any specialist), what you'd change in class, and how you'd know it's working. One sharp move from published material: the district's "Every Child a Reader" belief says no student leaves third grade without a reading plan, so ask for that plan first. The question needs no claim about your past, so the guidance makes none | This is the district's first published belief, turned into a live problem, in front of a former reading specialist. Grounded on the beliefs page |
| B3 | "How would you run small-group reading in a fourth-grade classroom?" | CASE | [grounded] | Structure: how groups are formed, how often they meet, what the rest of the class does meanwhile, how you track progress. Answer slot: if you've run small groups or reading conferences, describe them in your own words. If you haven't, say so plainly and describe how you'd set them up. Don't borrow the principal's talk vocabulary for your own past | This mirrors the principal's 2025 talk on weekly reading conferences in grades 3–5 (section 7). Typed CASE because it's a live design problem |
| B4 | "It's the first week of school. How do you set up your classroom routines?" | CASE | [inferred] "I write a weekly email to families" | Structure: which routines, how you teach and practice them, what you do when they slip, and how families hear about them. You can mention the weekly family email at its own scope, as one way families stay in the loop. Answer slot: if you have routines you set up every year, name them in your own words. If you don't have a set approach, say so plainly and describe what you'd build | This is F7's discovery gap rehearsed as a live problem. `[inferred]` because the requirement comes from a representative posting |

### C. Peer Evaluator (the two fourth-grade teachers)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "We plan together as a team. What would you bring to our planning, and what would you need from us?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" "I led our grade level's move to a new reading curriculum in 2024" "I've never taught fourth grade" | Two halves. What you'd bring, at the quotes' scope: six years teaching third grade, and leading your grade level's move to a new reading curriculum in 2024. What you'd need, said plainly because you haven't taught fourth grade yet: their units and pacing, and one person to ask quick questions. End by asking what would actually help them | This is the reciprocity question peers always ask in some form. F2, F5 and F3 together. Typed JD because it's the representative posting's teamwork line |
| C2 | "Tell us about a time you disagreed with a colleague on your grade level. How did it go?" | JD | [generic] | Selection scaffold: pick a real disagreement with a named stake, where you held a position, stayed respectful, and the working relationship survived. Use "we" for the team and "I" for your part. If no such time comes to mind, say so plainly, then describe how you'd handle one | A peer stem. Your material carries no disagreement story, so this is a scaffold rather than a story map |
| C3 | "You've run an after-school reading club. Would you want to do something like that here, and how would it fit with the team?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Lead with the quote: you've run the after-school reading club for the last two years. Then talk about the future: whether you'd want to continue something similar, and that you'd fit it to what the team already does. The district plans a family reading night at every school each term, and a club could connect to that if the team wants it. Answer slot: if they ask what running the club involved, say what you did, in your own words. Don't say you started it unless you did | F5's club quote is a likely conversation-starter with peers. Typed EXP because they'll test what "run" meant. The family reading night comes from the literacy-plan news |
| C4 | "When you led your grade level's move to a new reading curriculum, how was the work split, and how did credit work?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Use "we" for the team and "I" for your part. Answer slot: say which parts were yours, in your own words. If there wasn't a real split, or most of it was decided elsewhere, say so plainly and stay with the fact that you led the move | This is the credit-sharing probe peers use. F9's quote is exactly the line it targets |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your résumé says you led the move to a new reading curriculum. What did you actually do?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: describe what you did, step by step, in your own words. If parts were set for you or done by others, say so plainly and keep "I" for your own part. Name the limit before they find it. Don't add steps that didn't happen | Your strongest résumé line, so it's the one most likely to be unpacked. Typed EXP because it's about attribution |
| D2 | "How do you know the reading club is helping?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Answer slot: if you've looked at any evidence of how club members are doing, say what it was and how you read it, in your own words. If you haven't measured it, say so plainly and describe the club as you ran it. Don't make up a number | The district's "assessments inform teaching" belief makes evidence questions likely. Typed EXP because it probes a résumé claim |
| D3 | "Tell us about a time you used assessment data to change how you taught." | JD | [inferred] | Selection scaffold: pick one time with a specific assessment, what it showed, what you changed, and what happened next. If no such time comes to mind, say so plainly, then describe how you'd use assessment results in a fourth-grade room | This covers F6's discovery gap and echoes "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." `[inferred]` because the requirement comes from a representative posting |
| D4 | "What does planning across subjects look like for you in a typical week?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: if you planned all the core subjects, walk through your week in your own words. If your school split subjects or some weren't yours, say so plainly and stay with what you taught | This covers F4's discovery gap. `[inferred]` because the five-subject line comes from a representative posting |

### E. Conversational (whole panel)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, tell us a bit about yourself." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years" "I write a weekly email to families" | A 90-second arc made only of these lines: six years teaching third grade at a public elementary school in Joliet. In 2024 you led your grade level's move to a new reading curriculum. You've run the after-school reading club for two years. You write a weekly email to families. Close with one honest sentence on why fourth grade at Halvering (see A4). Add nothing the lines don't say | Nearly every panel opens this way, and casual openers are still scored. Built only from your own sentences |
| E2 | "What's a book you've seen students get really excited about?" | EXP | [generic] | Selection scaffold: one real title, the students it worked for, and what you noticed. If none comes to mind, say so plainly and name one you'd use with fourth graders and why | A warm question in front of a former reading specialist. Light, but it's scored on genuine interest |
| E3 | "Just to confirm, you hold an Illinois license with an elementary endorsement?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | One sentence in the quote's terms: a PEL with an Elementary Education endorsement for grades 1–6, active through June 2029. No ID numbers are needed in the room | This is the one gate HR named, so it gets a JD question. It's settled on paper, so keep it quick |

### F. Values/Behavioral (the district's published beliefs)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our district expects each teacher to speak with every family each term. How would you make that happen?" | VAL | [grounded] "I write a weekly email to families" | Start from the quote's own terms: you write a weekly email to families. Then the plan: how you'd reach every family in conversation each term, how you'd schedule it, and what you'd do about families who are hard to reach. Answer slot: if you've already talked with every family each term, say how, in your own words. If your contact has mostly been the email, say so plainly and present the conversations as what you'd add | "Families Are Partners" is a published belief, and the email is a different kind of contact from talking, so don't let it stand in for one. Typed VAL with CASE delivery |
| F2 | "Tell us about a student who struggled with reading and what you did." | VAL | [generic] | Selection scaffold: one real student (no names), what you noticed, what you tried, who else you involved, and what changed. Use "I" for your own part. If no such time comes to mind, say so plainly and describe how you'd handle it | The theme comes from "Every Child a Reader". Your material carries no specific student story, so this is a scaffold |
| F3 | "How do you keep testing from taking over your teaching?" | VAL | [grounded] | Answer in the spirit of the published belief without reciting it: assessments tell you what to teach next, and they aren't the lesson. Answer slot: if you have a practice that shows this, describe it in your own words. If you don't, say so plainly and describe what you'd do | This comes from the third belief, "Teach for Tomorrow, Not for the Test". Grounded on the beliefs page |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over someone who's taught fourth grade for years?" | JD | [grounded] "I've never taught fourth grade" "Six years teaching third grade at a public elementary school in Joliet" | A1, compressed. Pause, then: "I haven't taught fourth grade yet. I've taught third grade for six years at a public elementary school." Then one plan sentence. If they push twice, hold on the six years, then concede the real point specifically: fourth-grade content will be new to you. Don't fold into apology, and don't inflate | The same objection as A1, time-boxed. Hold-then-concede practice |
| G2 | "You keep coming back to that curriculum move. What else have you got?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" "I've run the after-school reading club for the last two years" "I write a weekly email to families" | Stay calm and widen only to what your lines carry: six years teaching third grade, two years running the after-school reading club, a weekly email to families. Then stop. A short, true list beats a padded one | This tests composure when one story gets challenged. It's built only on the quotes |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 license with elementary endorsement | E3 |
| F2 grades 3–5 experience | A1, G1 |
| F3 fourth-grade position | A1, A2, A5, C1, G1 |
| F4 teaching across subjects | D4 |
| F5 teaching reading | B1, B2, B3, C3, D2, F2 |
| F6 differentiating with assessment data | D3, F3, B2 |
| F7 classroom routines | B4 |
| F8 family communication | F1, B4 |
| F9 working with the grade-level team | A3, C1, C2, C4, D1 |

---

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | (To Principal Vantongeren) "Coming from reading-specialist work, what does strong reading instruction look like to you in a fourth-grade room here?" | It's tied to her own path. It invites her to talk about the thing she knows best, and her answer tells you what she'll judge you on |
| R2 | "With the new grades 3–5 reading curriculum coming in fall 2027, how is the fourth-grade team preparing, and where could a new teacher help?" | It shows you know the district's current plan and puts your F5 experience on the table without any boasting |
| R3 | (To the two teachers) "What could a new person do in their first month that would genuinely help your team?" | A reciprocity question for peers. It frames you as adding to their work, not just needing from it |
| R4 | "How does the fourth-grade team plan together week to week?" | It's practical, it signals that you plan to collaborate, and it answers your own biggest ramp-up question |
| R5 | "What does 'speak with every family each term' look like in practice at Halvering?" | It shows you read the district's beliefs and takes "Families Are Partners" seriously |
| R6 | "A year from now, what would make you say this hire was the right one?" | It gets their real success criteria in their own words, and it's a strong final question |

---

## 13. Prohibited claims

What this pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated (F3) | "I haven't taught fourth grade yet." No slot |
| Has been a grade-level team lead | A negative you stated (F9) | "I've never been a team lead." Paired with F9's quote at its own scope |
| Led a school-wide or district-wide curriculum adoption | Inflated form of the F5/F9 quote (scope) | The quote at its own scope: your grade level's move, in 2024. The pack's observation: your material says your grade level, not the school or district |
| Chose or designed the new reading curriculum | Inflated form of the same quote (verb) | The quote at its own scope: you led the move. The pack's observation: your material doesn't say who chose it. The D1 and C4 slots stay inside the move |
| Founded the after-school reading club | Inflated form of "I've run the after-school reading club for the last two years" (verb) | The quote at its own scope: you've run it for two years |
| Talks with every family each term | Inflated form of "I write a weekly email to families" (kind) | The quote at its own scope: a weekly email. F1's slot puts conversations forward as a plan |

---

## 14. Sources

**Provided documents:** the HR invitation email and the résumé lines from your message. I didn't use your SSN or IEIN. Neither is needed for interview prep, and neither appears anywhere in this pack.

**Searches and fetches sent:**

- Search: `Orrinsford Community School District mission values` → https://orrinsfordschools.example/about/mission-and-beliefs
- Fetch: https://orrinsfordschools.example/about/mission-and-beliefs → three beliefs with definitions
- Search: `Dolores Vantongeren Halvering Elementary principal` → https://ilprincipalsforum.example/speakers/dolores-vantongeren (search snippet only, not fetched)
- Search: `Orrinsford Community School District news strategic plan` → https://orrinsfordschools.example/news/board-adopts-literacy-plan (search snippet, August 2026)
- Search: `Fourth Grade Teacher job description Illinois elementary school district posting` → https://k12jobsboard.example/listings/fourth-grade-teacher
- Fetch: https://k12jobsboard.example/listings/fourth-grade-teacher → full representative posting

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford values` | yes | Three published beliefs, by name and definition. These theme bank F, B2, D2, D3 and R5. No values cheat sheet, because the invite names no values-style round |
| 2. `Orrinsford interview process` | skipped | The invite already sets the session: one 45-minute panel with the principal and two fourth-grade team members. That fixes the persona weights |
| 3. `Orrinsford strategy` / recent news | yes | The August 2026 literacy plan, including the grades 3–5 curriculum from fall 2027 and a family reading night each term. It moved B1, C3 and R2 |
| 4. `Dolores Vantongeren Halvering` | yes | Her public role, her reading-specialist background and her 2025 talk. It moved section 7, B3 and R1 |
| 5. Representative `Fourth Grade Teacher` JD | yes | No posting was supplied, so this sets requirements F2 and F4–F9 and every `[inferred]` JD-tagged question |

---

## 15. Upgrade menu

- **Halvering's actual posting text** → F2 and F4–F9 change from `[inferred]` to `[grounded]`, and the JD-tagged questions get retargeted to Halvering's real list
- **One email to HR** asking whether the panel expects a sample lesson or anything to bring → a build section for that deliverable, if there is one
- **The two fourth-grade teachers' names** → a read on each, based on public professional footprint only, plus persona weights per member
- **Your answers to the answer slots** (subjects you taught, assessment data, routines, what leading the move involved) → F4, F6, F7 and F9 get upgraded, and A3, B1, B4, C4, D1, D3 and D4 change from scaffolds to story-mapped guidance
- **A copy of your license record** to have on hand → F1 confidence goes from `medium` to `high`
- **How much prep time you have before Thursday** → a prioritized prep schedule sized to it
- **A tuesday-dossier.md from job-underwriter** → evidence-verified objections and a binding prohibited-claims list. This pack is complete without one
