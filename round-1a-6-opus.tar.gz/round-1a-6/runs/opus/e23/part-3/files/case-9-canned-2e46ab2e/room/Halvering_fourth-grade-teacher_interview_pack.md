# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**District:** Orrinsford Community School District
**Format:** 45-minute panel, Thursday
**Panel:** Principal Dolores Vantongeren (treated here as the hiring manager) and two members of the fourth-grade team (peers)
**Built from:** the HR invite, your résumé summary, the district's published beliefs, district news, the principal's public speaker profile, and a *sample* fourth-grade job description. The Halvering posting itself wasn't provided, so every row that comes from the sample posting is marked `[inferred]`.

---

## How to use this pack

- **Personas** describe *how* a question gets asked: who is asking and in what style. **Types** describe *what* is being scored.
- A 45-minute panel won't get through all 24 questions. Rehearse A1 until it bores you, then work down the banks in order.
- Guidance is scaffolding, not a script. Say it in your own words.
- **Answer slots** mark the places where your material doesn't say what happened. Each one gives two honest branches. Use whichever one is true.
- Bank letters skip **F** so that "F1" always means a fit-snapshot row.

| Type | What it scores |
|---|---|
| VAL | Whether what you've done matches the district's *published* beliefs |
| EXP | Whether your résumé lines hold up under questions: what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the district and school: its plans and recent moves |
| CASE | How you structure and reason through a live classroom problem |

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "a valid Illinois Professional Educator License with an elementary endorsement" — HR invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | This is the gate, and your material shows it met: fourth grade falls inside the grades 1–6 your endorsement names. No bridge is needed. Say it in the license's own terms: "I hold an Illinois PEL with an Elementary Education endorsement, grades 1 to 6, active through June 2029." It's medium only because nothing has been inspected. Bring a copy of your license record |
| F2 | "experience in grades 3 to 5 preferred" — sample JD (K12 Jobs Board) | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | none | The quote meets the sample posting's range in its own terms. Say it as written: "I've taught third grade for six years." It's inferred because the line comes from a sample posting, not from Halvering's |
| F3 | "Fourth Grade Teacher position" — HR invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | Wording can't close this gap, and you've said so yourself. Words: "I haven't taught fourth grade." Then say how you'd get ready, as a plan and never as a past. Add nothing to make the gap feel smaller. The third-grade years (F2) stand beside it, not over it |
| F4 | "plan and teach reading, writing, math, science and social studies" — sample JD | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [inferred] | discovery | Your material says third grade, not which subjects. Answer slot: the posting lists five subjects, so expect a question on which ones you taught. Name the ones you did teach, in your own words. If some were taught by someone else, or not at all, say so plainly and stay with what you did teach |
| F5 | "differentiate instruction using assessment data" — sample JD | none given | none | [inferred] | discovery | Your material doesn't show this either way. Answer slot: if you've used assessment results to group students or adjust your teaching, say how, in your own words. If you haven't, say so plainly and say how you would start |
| F6 | "keep clear classroom routines" — sample JD | none given | none | [inferred] | discovery | Answer slot: if you set up particular routines each year, describe them in your own words. If nothing set comes to mind, say so plainly and say what you would set up first |
| F7 | "communicate regularly with families" — sample JD | "I write a weekly email to families." — your CV | medium | [inferred] | none | The quote reaches this directly. Say it as written: "I write a weekly email to families." Expect a follow-up, since nothing has been inspected. A sample email with names removed is the thing that would show it |
| F8 | "work with the grade-level team" — sample JD | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [inferred] | none | The quote reaches this in its own terms. Keep it at its own scope: you led your grade level's move to a curriculum, in 2024. Your material says you led the move, not the team, and you've said "I've never been a team lead." Answer slot: the posting's team line makes a question on how the move ran likely. Say which parts were yours, in your own words. If a part was someone else's, say so |
| F9 | "Every Child a Reader: no student leaves third grade without a reading plan" — district beliefs page | "Six years teaching third grade at a public elementary school in Joliet." — your CV; "I've run the after-school reading club for the last two years." — your CV | low | [grounded] | discovery | Both quotes touch this belief, but neither shows reading plans. Answer slot: the belief names a reading plan for every third grader, and you taught third grade, so expect that question. If your students had reading plans, say what they held and what part was yours. If there were no such plans, or they weren't yours, say so plainly and return to the reading club you ran |
| F10 | "Families Are Partners: each teacher speaks with every family each term" — district beliefs page | "I write a weekly email to families." — your CV | low | [grounded] | discovery | An email is writing, not speaking, and the quote doesn't show whether you spoke with every family. Answer slot: if you speak with each family each term, whether at a conference, by phone or some other way, say how. If you don't reach every family, say so plainly and stay with the weekly email |
| F11 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it" — district beliefs page | none given | none | [grounded] | discovery | Answer slot: if an assessment result has changed what you taught next, say when and what, in your own words. If no example comes to mind, say so, then say how you'd want assessments to work in your classroom |

---

## Reading the interviewer

All of this comes from one search-result snippet of a speaker page. The page itself wasn't read in full.

| What's public | Provenance | What it means for Thursday |
|---|---|---|
| Principal of Halvering Elementary since 2022 | [grounded] | She knows the school and its families well, so specific questions about Halvering (reverse questions R2 and R4) will land better than general ones |
| Nine years as a reading specialist before becoming principal | [grounded] | Expect the reading questions to go deeper than average. B2 and B3 are the likely shape |
| Her 2025 forum talk, "Small Groups, Big Readers," covered weekly reading conferences in grades 3 to 5 | [grounded] | Her recurring theme may come up as a question (B3) and makes a strong reverse question (R1). Your material doesn't mention reading conferences, so the pack offers no shared-practice line for you to use with her. Treat it as a planning question |

---

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | The principal, quietly testing the third-to-fourth jump | High. A principal-as-hiring-manager prior, plus F3, the one gap you stated yourself | Rehearse A1 until it's boring. Name the limit before you're asked, then give a concrete ramp plan |
| Case / Strategist (bank B) | "Walk us through…" classroom problems | High. A hiring-manager prior, plus a principal with a reading-specialist background and a district rolling out a new reading curriculum | Clarify, then state the goal, then the approach, how you'd check it, and the risks. Think aloud |
| Peer Evaluator (bank C) | The two fourth-grade teachers asking what you'd be like to plan with | Mid-high. Two of the three panelists are peers | Lead with what you'd bring them. Ask for what you'd need plainly |
| Data-Driven Prober (bank D) | "How do you know?" follow-ups on your résumé lines | Mid. The second persona of a peer panelist. Your résumé has no figures, so the probing lands on the reading club and the 2024 curriculum move | Know what you can and can't say about results. "I didn't track that" is a valid answer |
| Values / Behavioral (bank E) | Questions built on the district's three beliefs | Mid. The district says these beliefs "guide every hire," though no separate values round was announced | Use each belief's name. Answer from what you did, and use answer slots where your material is silent |
| Pressure (bank G) | A time-boxed "why you?" or a contradiction pushed at you | Low. Nothing in the invite signals a stress style | Pause, restate, hold through two follow-ups, then concede only what's true |
| Conversational (bank H) | The opener and casual asides | Low as a style, but the opener is near-certain | Have a 90-second arc ready, and treat casual questions as scored |

---

## Question banks

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your résumé shows third grade, and this is a fourth-grade job. Why should we trust you with fourth graders?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I've never taught fourth grade" "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | **The highest-ROI rehearsal in this pack.** Name the limit before they push: "I've taught third grade for six years. I haven't taught fourth grade." You can add that your endorsement covers grades 1 to 6. Then stop defending and give a ramp plan, said as a plan: what you'd learn first about the fourth-grade curriculum, and from whom. The team in the room is the obvious answer. Follow-up 1 ("So you'd be learning on our kids?"): hold. The six years are real and the plan is specific. Concede only what's true: the grade's content is new to you. Follow-up 2 ("How long until you're up to speed?"): give an honest estimate as a plan, never a promise you can't back. Don't call third grade "basically the same." Describe what you did and let them draw the conclusion | F3 is the gap you stated yourself, and it's the first thing every panelist sees on the résumé. This objection will come in some form, so it gets the deepest rehearsal. Tagged JD because it scores fit for the posted grade |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Pick a real weakness, not a disguised strength. The option your own words support is the grade itself: "I haven't taught fourth grade," followed by the ramp plan from A1. Answer slot: if a different part of the job feels newer to you, such as one of the subjects in F4, name it in your own words. If not, stay with fourth-grade content. Give one weakness and one plan | A Skeptic stem aimed at F3 and F4. JD because it measures you against the job's own list |
| A3 | "You led your grade level's move to a new reading curriculum. Were you the team lead?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've never been a team lead" | Both are true, and you can say them back to back: "I led our grade level's move to a new reading curriculum in 2024. I haven't been a team lead." Answer slot: expect "So what did leading it mean?" The posting's team line raises it. Say which parts of the move were yours, in your own words. If a part was someone else's, say so plainly and stay with what was yours. Never let "led the move" become "led the team" | F8 and the prohibited list meet here. EXP because it tests who did what behind a résumé line |
| A4 | "What brings you from third grade in Joliet to fourth grade at Halvering?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Your reasons are yours, and the pack can't supply them. Give the real one in a sentence or two. If one of the district's three beliefs is genuinely part of why, name it. If it isn't, don't borrow it. Don't criticize any school you've worked at | The Skeptic's core probe is whether your motivation story holds together, and panels often ask it early. JD because it scores fit for this posting rather than a past claim |
| A5 | "This job covers reading, writing, math, science and social studies. Which have you taught, and which would be newest?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: name the subjects you taught in third grade, in your own words. If some were taught by another teacher, or not at all, say so plainly. For the newest one, give a plan for how you'd prepare. A straight list beats a reassuring blur | F4 is a thin row. The subject list comes from a sample posting, hence `[inferred]`, so the real posting may differ |

### Bank B: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The district brings in a new grades 3–5 reading curriculum in fall 2027. How would you help the fourth-grade team get ready?" | CASE | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Clarify first: what training and materials are planned, and when. Then structure your answer: what the team needs to learn and in what order, how you'd check it's working with students, and what could go wrong. Name your experience at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if there's something from that move you'd repeat or do differently, say what, in your own words. If nothing specific comes to mind, stay with the plan. Offer to help; don't cast yourself as the leader | The board's literacy plan (Sources) makes this a live issue for the whole team, and F8 is your closest experience. CASE in delivery, with company homework (CO) in the content. It's the best place to show you've read the district's news |
| B2 | "A third of your class arrives in September reading below grade level. Walk us through your first six weeks." | CASE | [grounded] | Clarify what information comes with the students. The district's belief says no student leaves third grade without a reading plan, so ask whether those plans move up to fourth grade. Then: find out where each student is, group by need, set a schedule for small-group time, tell families what you're doing, and check progress at a set point. The question asks for a plan, so the answer needs no claim about your past | The principal's reading-specialist background (interviewer read) makes a reading case likely. `[grounded]` because the reading-plan detail comes from the beliefs page. It assumes nothing about you |
| B3 | "How would you fit small-group reading conferences into a fourth-grade week?" | CASE | [grounded] | Clarify the schedule first. Then work it out live: how often you'd meet each student and for how long, what the rest of the class does meanwhile, what you'd write down, and how it would change your teaching. The question asks for a plan, so the answer needs no claim about your past | The principal's 2025 talk was about weekly reading conferences in grades 3–5 (interviewer read), so her recurring theme may come up. CASE because it asks for a plan |
| B4 | "It's the first week of school. Which routines do you set up first, and how?" | CASE | [inferred] | Pick three or four routines and say why each one comes first. Arrival, transitions, how students get help and how work gets turned in are possibilities; the choice and the reasons are yours. Answer slot: the sample posting's routines line makes "What do you do now?" likely. If you set up particular routines each year, describe them in your own words. If nothing set comes to mind, say so plainly and stay with the plan | F6 has no evidence yet. A JD requirement asked as a live case. `[inferred]` because the requirement comes from a sample posting |
| B5 | "Your math unit check shows three groups: ready to move on, nearly there, and missing earlier skills. Plan tomorrow." | CASE | [inferred] | Structure it: what each group does, where you spend your own time and why, how the ready group gets stretched rather than handed busywork, and how you'll check that tomorrow worked. Answer slot: if you've grouped students this way from assessment results, say how, in your own words. If you haven't, say so plainly and stay with the plan | F5's requirement, rehearsed as a live problem. It also touches the third belief (F11): assessments inform teaching |

### Bank C: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "If you joined our team, what would you bring to our planning, and what would you need from us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." | Lead with what you'd bring, in your quotes' own terms: you led your grade level's move to a new reading curriculum in 2024, and you've run the after-school reading club for the last two years. Then what you'd need: their fourth-grade pacing and materials. Say it plainly, because F3 is real. Keep the ask short and specific | Peers are weighing whether you'll add to their workload or lighten it. JD because it scores the team requirement (F8) |
| C2 | "Tell us about a time you disagreed with a colleague about how to teach something." | EXP | [generic] | Selection scaffold: pick a time with a real difference of view. Say what you did about it, and choose one where the working relationship was intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Don't tell it as a story about someone else being wrong | A Peer stem about disagreeing with equals. EXP because it asks for a real instance. `[generic]` because no quote of yours covers it |
| C3 | "When you led the move to the new reading curriculum, how did you bring the rest of the grade level along?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Built on F8, using only what the quote states: the move, in 2024, led by you. Answer slot: the sample posting's team line makes this question likely. If bringing colleagues along was part of it, say how, in your own words. If it wasn't needed, or that part wasn't yours, say so plainly and describe what you did do | F8 through a teammate's eyes: will this person be easy to work alongside? EXP because it asks about the part of the résumé line the line itself doesn't describe |
| C4 | "How do you handle credit when work is shared across the team?" | JD | [generic] | Say what you believe, and name what others did as readily as what you did. Selection scaffold: a time you shared credit or had to sort it out. If no such time comes to mind, say so plainly and say how you would handle it | A Peer stem. Teammates test whether you'd add to the team or take from it. JD because it scores the team requirement (F8) |

### Bank D: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How do you know the reading club made a difference?" | EXP | [grounded] "I've run the after-school reading club for the last two years." | Answer slot: the district's belief that assessments inform teaching makes this question likely. If you tracked anything about club members, say what you counted and how, in your own words. If you didn't track anything, say so plainly and say what you'd look at. Don't offer a result you didn't measure | Probers ask what's behind a résumé line, and F9 rests on this one. EXP because it tests how much the claim can carry |
| D2 | "What did the 2024 curriculum change look like in your own classroom, week to week?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: the sample posting's "plan and teach reading" line raises this. Describe it in your own words, keeping to what you saw and did. If you don't remember week-by-week detail, say so and give the part you do remember | This is F8's middle: the part a written line skips and a prober asks about. EXP |
| D3 | "Walk me through how you use assessment data to decide who needs what." | JD | [inferred] | Answer slot: the sample posting's "differentiate instruction using assessment data" line raises this. If you do this, say how, in your own words. If you haven't, say so plainly and describe how you would start. Don't make up tools or schedules | F5 has no evidence yet, so this is where an unrehearsed answer would wobble. JD because it scores a stated requirement. `[inferred]` because the line comes from a sample posting |

### Bank E: Values / Behavioral (the district's three beliefs)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our belief is that no student leaves third grade without a reading plan. You taught third grade. Tell us about reading plans in your classroom." | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I've run the after-school reading club for the last two years." | Use the belief's name: Every Child a Reader. Answer slot: the belief itself raises this. If your students had reading plans, say what the plans held and what part was yours, in your own words. If there were no such plans, or they weren't yours to write, say so plainly and say you'd want to learn how Halvering does them. Then return to the reading club you ran | This is F9. The beliefs page says three beliefs "guide every hire," so expect each one in some form. VAL |
| E2 | "We expect every teacher to speak with every family each term. How do you stay in touch with families?" | VAL | [grounded] "I write a weekly email to families." | Use the belief's name: Families Are Partners. Start with what you do: "I write a weekly email to families." Answer slot: the belief says *speaks*, and an email is writing. If you speak with each family each term, say how. If you don't reach every family, say so plainly and say how you'd meet the expectation | Covers F7 and F10. VAL because it tests a published belief |
| E3 | "Tell us about a time an assessment result changed what you taught next." | VAL | [grounded] | Selection scaffold for Teach for Tomorrow, Not for the Test: pick a time a result changed your plan. Say what the result showed, what you changed and what happened. If no such time comes to mind, say so plainly, then say how you'd want assessments to work in your classroom | F11 has no evidence yet. The theme comes from the third belief, so it's `[grounded]` on the beliefs page while making no claim about you |

### Bank G: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over someone who's already taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I've never taught fourth grade" "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." "I write a weekly email to families." | Pause, then hold on what you've stated: six years teaching third grade, the 2024 curriculum move you led, the reading club you've run for the last two years, and a weekly email to families. Concede the real point once: "I haven't taught fourth grade." Don't argue that grade-level experience doesn't matter. Keep it under 60 seconds and end on what you'd do in your first month | F3 under time pressure. The hold rests on F2, F7, F8 and F9; the concession is F3. JD |
| G2 | "You say you led a curriculum change, but you've never been a team lead. Which is it?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've never been a team lead" | Hold calmly, because both are true: "I led our grade level's move to a new reading curriculum in 2024, and I haven't been a team lead." If pushed again, don't upgrade the move into a title, and don't shrink it either. Then stop talking | A pressure point from the prohibited list: does the candidate inflate under challenge? EXP |

### Bank H: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So, tell us a little about yourself." | EXP | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." "I write a weekly email to families." | A 90-second arc built from your own lines: licensed for grades 1–6; six years teaching third grade in Joliet; led your grade level's 2024 move to a new reading curriculum; ran the after-school reading club for the last two years; write a weekly email to families. End on why fourth grade at Halvering, in your words (A4). It's scored even though it sounds casual | Panels usually open this way, and it sets up A1. EXP because it summarizes the résumé |
| H2 | "Tell us about the reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years." | Keep it at its own scope: you've run it for the last two years. Answer slot: the Every Child a Reader belief makes "Who comes, and what do you do?" likely. Describe it in your own words: who it's for and what a session looks like. Leave out any detail that isn't yours to claim. Treat it as scored | The other half of F9. Casual register, scored content. EXP |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 License with elementary endorsement | A1, H1 |
| F2 Grades 3–5 experience | A1, G1 |
| F3 Fourth grade | A1, A2, G1 |
| F4 Five subjects | A5, A2 |
| F5 Differentiating with assessment data | D3, B5 |
| F6 Classroom routines | B4 |
| F7 Communicating with families | E2 |
| F8 Working with the grade-level team | C1, C3, C4, A3, D2, G2 |
| F9 Every Child a Reader | E1, D1, H2, B2 |
| F10 Families Are Partners | E2 |
| F11 Teach for Tomorrow, Not for the Test | E3, B5 |
| District literacy plan (news) | B1 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | (To the principal) "Your talk on small-group reading covered weekly reading conferences in grades 3 to 5. How do those work in fourth grade here?" | It's tied to her own published work, which shows you researched *her* and not just the district |
| R2 | "How is the fourth-grade team preparing for the new grades 3–5 reading curriculum in fall 2027?" | It shows you've read the board's plan and points at real work you'd share |
| R3 | (To the teachers) "What could a new person do in their first month that would genuinely help your team?" | A reciprocity question: it tells peers you're thinking about their load, not just your own |
| R4 | "What does speaking with every family each term look like in practice here?" | It turns a published belief into a concrete question and shows you want to meet it |
| R5 | "How do third-grade reading plans travel with students into fourth grade?" | It connects Every Child a Reader to the grade you'd teach, and it's a question someone coming from third grade would naturally ask |
| R6 | "What would make someone successful in this role by the end of the first year?" | It gets their actual bar on the table and gives you a frame for a follow-up note |

---

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated, F3 | "I haven't taught fourth grade." No answer slot |
| Has been a grade-level team lead | A negative you stated, F8 | "I haven't been a team lead." No answer slot |
| Led the grade-level team | Inflated form of F8's quote | F8's quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." The pack's observation: your material says you led the move, not the team. A3 and C3 keep their answer slots inside the move |
| Chose or designed the reading curriculum | Inflated form of F8's quote | F8's quote at its own scope. D2's slot asks only what the move looked like in your classroom |
| Speaks with every family each term | Inflated form of F7 and F10's quote | "I write a weekly email to families." E2's slot asks how you stay in touch beyond it |
| Founded the reading club | Inflated form of F9's quote | "I've run the after-school reading club for the last two years." |
| The reading club raised reading results | Inflated form of F9's quote | The quote at its own scope. D1's slot asks only what, if anything, you tracked |

---

## Sources

**Provided:** the HR interview invite; your résumé summary. Your Social Security number and IEIN were not used.

**Searches and fetches sent:**

- Search "Orrinsford Community School District mission values" → https://orrinsfordschools.example/about/mission-and-beliefs
- Fetch https://orrinsfordschools.example/about/mission-and-beliefs → the three beliefs and their definitions
- Search "Halvering Elementary School Orrinsford news" → https://orrinsfordschools.example/news/board-adopts-literacy-plan (snippet: the August 2026 three-year literacy plan, including a new grades 3–5 reading curriculum from fall 2027)
- Search "Dolores Vantongeren principal Halvering Elementary" → https://ilprincipalsforum.example/speakers/dolores-vantongeren (snippet only)
- Search "Illinois fourth grade teacher job description elementary school district posting" → https://k12jobsboard.example/listings/fourth-grade-teacher
- Fetch https://k12jobsboard.example/listings/fourth-grade-teacher → the sample posting's responsibilities and qualifications

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | The three beliefs by name, used in rows F9 to F11 and bank E. No values cheat sheet section: the invite announces one panel and names no values round |
| 2. Orrinsford interview process (teaching) | skipped | The HR invite already sets the session: one 45-minute panel with the principal and two fourth-grade team members, which fixes the persona weights |
| 3. District strategy and recent news | yes | The 2026–2029 literacy plan, used in B1 and R2 |
| 4. Dolores Vantongeren, Halvering | yes | Interviewer read, B2, B3 and R1, from a search snippet only |
| 5. Representative Fourth Grade Teacher JD | yes | Rows F2 and F4 to F8, all `[inferred]`, since no Halvering posting was supplied |

---

## Upgrade menu

- The Halvering posting text → rows F2 and F4 to F8 become `[grounded]`, and any requirement the sample posting missed gets its own question
- Anything HR said beyond the invite, such as a sample lesson or materials to bring → a dedicated build section for that deliverable
- The names of the two fourth-grade team members → per-member persona weights and a reverse question for each
- How much prep time you have before Thursday → a prioritized prep schedule sized to it
- Your answers to the answer slots: the subjects you taught (F4), using assessment data (F5, F11), routines (F6), what was yours in the 2024 move (F8), reading plans (F9) and speaking with families (F10) → those rows move from `discovery` to story-mapped guidance
- A copy of your license record, to bring on Thursday rather than to send here → F1 becomes `high`
- A tuesday-dossier.md from job-underwriter → verified evidence and an underwriter-built prohibited-claims list. This pack doesn't need one
