Reading done — now running a few web searches on the school and district before I write your prep pack.
I've written your prep pack: `Halvering-Elementary_fourth-grade-teacher_interview_pack.md`. I didn't have Halvering's own job posting, so it's built from the HR invite, your resume, the district's public pages and a typical fourth-grade posting. Questions that come from the typical posting are labeled `[inferred]` in the pack.

I left out your SSN and license number. You don't need either to prepare for an interview, and neither appears in the pack. I'd avoid pasting your SSN into chats like this one.

**Your license:** your grades 1–6 endorsement covers fourth grade, so you meet the requirement HR named. Bring a printout of your license record on Thursday.

**What I found online:**
- **The panel's topics:** the district's hiring page says it asks about reading instruction, classroom routines and how you work with families.
- **The principal:** Principal Vantongeren was a reading specialist for nine years before becoming principal, and in 2025 she gave a talk on reading conferences in grades 3 to 5. Expect detailed follow-up questions on how you teach reading.
- **The district's reading plan:** in August 2026 the district adopted a new literacy plan, which brings a new grades 3–5 reading curriculum in fall 2027. Your 2024 curriculum move is the closest match in your resume, and question A3 shows you how to use it.

**The question to practice most** is B1: "You've taught third grade, but never fourth." The pack has you say that first, then point to your six years of third grade, then give a concrete plan for getting ready.

The pack also includes:
- A list of claims not to make, such as having led a school-wide adoption or having been a team lead.
- Six questions you can ask the panel.

Say the word and I'll play the skeptical interviewer on B1, with live follow-up questions.
I can also save a tuesday-dossier.md that records the gaps this prep found, so you can bring it into later sessions.
If you'd like the pack as a Word document, I can convert it.

1. Can you paste Halvering's actual job posting? It would replace the typical posting and change the `[inferred]` questions. I'm fine continuing without it.
2. Do you want a deeper research pass? It's up to 6 more searches and 2 more page reads, and takes several more minutes. It would cover Halvering itself, more on the principal's talk, and reports from other candidates' district interviews.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering-Elementary_fourth-grade-teacher_interview_pack.md -----
# Interview Prep Pack: Fourth Grade Teacher, Halvering Elementary School

**District:** Orrinsford Community School District
**Format:** 45-minute panel on Thursday
**Panel:** Principal Dolores Vantongeren (the hiring decision-maker) and two members of the fourth-grade team (your future peers, names not given)

---

## How to use this pack

Two labels sit on every question:

- **Persona** is the style of the person asking: a friendly opener, a skeptic, a peer.
- **Type** is what is being scored.

| Type | What it scores |
|---|---|
| VAL | Whether your past behavior matches the district's published beliefs |
| EXP | Whether what you say about your own work holds up when they dig into it |
| JD | Whether you can do the job as posted, gaps included |
| CO | Whether you know the district's current plans |
| CASE | How you think through a live classroom problem |

**Provenance labels:** `[grounded]` means it traces to your resume, the HR invite or a source listed under Sources. `[inferred]` means it comes from a representative fourth-grade posting, because I don't have Halvering's own posting. `[generic]` means it's a common pattern with no claim about this school.

The guidance is scaffolding, not a script. Wherever it says **answer slot**, the pack doesn't know the answer and won't guess. Answer from what you actually did. If you didn't do it, say so plainly.

Question IDs skip the letter F, so they never get mixed up with fit-snapshot rows (F1, F2…).

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "valid Illinois Professional Educator License with an elementary endorsement" — HR invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The gate is met: grade 4 falls within your grades 1–6 endorsement. Medium only because I haven't inspected the license itself. Bring a printout of your license record. Say it in your resume's own words |
| F2 | "experience in grades 3 to 5 preferred" — representative posting | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | none | Six years of third grade is inside the 3–5 range. Say it as written: six years, third grade, a public school in Joliet |
| F3 | The role itself, "the Fourth Grade Teacher position" — HR invite | "I've never taught fourth grade and I've never been a team lead." — your message. "Six years teaching third grade at a public elementary school in Joliet." — your CV | none | [grounded] | capability | No wording closes this gap, and you've said so yourself. Words: "I haven't taught fourth grade." Then the six years of third grade, as written. Then how you'll get ready, said as a plan and never as past experience. Don't add anything to make the gap feel smaller |
| F4 | "plan and teach reading, writing, math, science and social studies" — representative posting | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | discovery | Your resume says third grade but not which subjects. Answer slot: if you taught all five, say so and name the one you're strongest in. If some were taught by someone else, say so plainly |
| F5 | "differentiate instruction using assessment data" — representative posting | none given | none | [inferred] | discovery | Your material doesn't show this either way. Answer slot: if you've grouped or adjusted teaching from assessment results, describe one instance in your own words. If not, say so and say how you would |
| F6 | "keep clear classroom routines" — representative posting | none given | none | [inferred] | discovery | Not in your material. Answer slot: if you have routines you'd bring from your third-grade room, name them in your own words. If none stand out, say how you would set them up |
| F7 | "Every Child a Reader: no student leaves third grade without a reading plan." — district beliefs page | "I led our grade level's move to a new reading curriculum in 2024" — your CV. "I've run the after-school reading club for the last two years." — your CV | medium | [grounded] | discovery | Both lines touch reading. Neither shows whether you wrote or used individual reading plans. Answer slot: if you did, say how. If your school had no such plans, say so plainly and stay with the curriculum move and the club |
| F8 | "communicate regularly with families" — representative posting | "I write a weekly email to families." — your CV | medium | [inferred] | none | A weekly email is regular family communication. Say it in those words, and expect a question about what goes in it |
| F9 | "Families Are Partners: each teacher speaks with every family each term." — district beliefs page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | The email is written and weekly. The district asks for a conversation with every family each term. Keep the email at its own scope: "I write a weekly email to families." Answer slot: if you've also spoken with every family, say how. If the email was your main channel, say so plainly and say how you'd add a conversation each term |
| F10 | "work with the grade-level team" — representative posting | "I led our grade level's move to a new reading curriculum in 2024" — your CV. "I've never taught fourth grade and I've never been a team lead." — your message | medium | [inferred] | none | Leading your grade level's curriculum move is grade-level teamwork. Say "led" because that's your word, and say "grade level", not "school". You've said you were never a team lead, so the curriculum move stays a project you led, not a role you held |
| F11 | "a new grades 3–5 reading curriculum from fall 2027" — district news, August 2026 literacy plan | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | transferability | Your move was at grade-level scope. The district's is grades 3–5. Words: "In 2024 I led our grade level's move to a new reading curriculum." Answer slot: describe what leading the move involved, in your own words. If parts of it were done by others, say so |
| F12 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." — district beliefs page | none given | none | [grounded] | discovery | Not in your material. Answer slot: if you've changed your teaching because of what an assessment showed, give one instance. If none comes to mind, say so and say how you'd use assessments |

---

## Reading the interviewer

**Principal Dolores Vantongeren** [grounded, from a public speaker page; see Sources]

- **Career:** principal of Halvering since 2022, after nine years as a reading specialist.
- **Published talk:** her 2025 forum talk, *Small Groups, Big Readers*, covered weekly reading conferences in grades 3 to 5.

What this means for you:

- **Reading questions will go deep.** A former reading specialist will follow up on any reading answer. The Prober bank (D) is weighted up for that reason.
- **Use her vocabulary only for what you've done.** Small groups and reading conferences are her terms. Use them only for things you actually did. Using them for practices you didn't do is the easiest way to get caught out by this interviewer.
- **No shared-career angle.** Your material doesn't show a similar career move, so the pack doesn't suggest one. The reverse question about her talk (R1) shows you looked her up.

**The two fourth-grade teachers:** no names given. Treat them as peers who will be working beside you.

---

## Persona table

**Where the loop comes from:** the district's hiring page describes "one 45-minute building panel: the principal and two grade-level teachers," asking about "reading instruction, classroom routines and how you work with families". That matches your invite, so the weights below follow it rather than a generic pattern.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | "What would you do if…" classroom scenarios | High. The principal is the hiring manager, and the district's page lists routines and reading instruction as panel topics | Clarify, then structure (first step, then how you'll know it's working), then adjust. Think out loud |
| Skeptic (bank B) | Quiet probing of the third-to-fourth jump | High. F3 is the most visible gap in your file, and both the principal and the team will want it answered | Say the gap first, in your own words (B1). Offer only the bridges your resume states, plus a concrete plan for getting ready |
| Peer Evaluator (bank C) | "How would you work with us?" | High. Two of the three panelists are future teammates | Reciprocity: what you bring and what you'd need from them. Disagreement stories that show you hold a view and stay collegial |
| Data-Driven Prober (bank D) | "Walk me through exactly how…" on reading | Medium, raised by the principal's reading-specialist background | Describe what you actually did, step by step. Where you don't know a number or method, say so |
| Values / Behavioral (bank E) | Questions themed on the district's three beliefs | Medium. The beliefs page says they "guide every hire", but the hiring page names no values round | Map your real stories to the beliefs where they fit. Say plainly where they don't |
| Conversational (bank G) | Friendly opener and closer | Medium-low, though nearly certain to happen at the start | A prepared 90-second introduction. Casual questions are still scored |
| Pressure (bank H) | Time-boxed "why you?" | Low. Not the district's described style | Pause, hold your position through two follow-ups, concede specifically |

---

## Question banks

**Highest-ROI prep in this pack: B1** ("never taught fourth grade"). It will come up in some form, and a calm, rehearsed answer changes how the rest of the interview goes.

### A — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's the first week of fourth grade. How do you set up your classroom routines?" | CASE | [inferred] | Structure: which routines come first (arrival, transitions, materials, getting help), how you teach and practice them, how you'll know they're working, and what you'd do in week three if one isn't. Answer slot: if a routine from your third-grade room would carry over, name it in your own words. If none would, build from the structure | Routines are a named panel topic on the district's hiring page and in the posting (F6). CASE because it is a live plan, not a record |
| A2 | "Your fall reading data shows about a third of the class reading below grade level. What do you do in the first month?" | CASE | [inferred] | Clarify first: which assessment, and how far below. Then grouping, protected small-group time, how you'll check progress and when, and how you'll bring in families. The question needs no claim about your past, so the guidance makes none | Tests F5 and F7 live. Very likely with a reading-specialist principal. CASE, with JD content |
| A3 | "The district is bringing in a new grades 3–5 reading curriculum in fall 2027. How would you help our team get ready?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Show you know the plan: the August 2026 literacy plan brings structured phonics for K–2, the new 3–5 curriculum from fall 2027 and a family reading night each term. Then your move, at its own scope: "In 2024 I led our grade level's move to a new reading curriculum." Answer slot: describe what leading it involved, in your own words. If others shared the work, say so. Then offer to help, framed as a teammate offering, not someone taking charge | F11 is your strongest match to current district plans, and most candidates won't know the plan exists. CO first, then CASE |
| A4 | "A student is reading well above grade level and finishes everything early. How do you plan for them?" | CASE | [inferred] | Structure: what you'd find out about the student first, how you'd stretch the work in depth rather than just giving more of it, and how you'd keep them part of the class community. No claim about your past | Differentiation runs in both directions (F5). Including the advanced reader shows range |
| A5 | "How would you plan a week that covers reading, writing, math, science and social studies?" | CASE | [inferred] "Six years teaching third grade at a public elementary school in Joliet." | Structure: fixed blocks, where subjects can be combined, and where reading and writing time is protected. Answer slot: if you planned all five subjects in third grade, say so and say how you balanced them. If not, say what you did plan | Checks F4. Planning across all subjects is the first line of the posting |

### B — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've taught third grade, but never fourth. What makes you ready for fourth graders?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." "Six years teaching third grade at a public elementary school in Joliet." | **The deepest rehearsal in this pack.** Say the limit before they press: "I haven't taught fourth grade." Then: "I've taught third grade for six years at a public elementary school in Joliet." Describe what you did and let them make the connection; don't argue that third grade proves anything about fourth. Then your preparation, said as a plan: what you'll study and who you'll learn from before August. Follow-up 1, "What will be different?": answer slot. If you've looked at the fourth-grade standards or curriculum, say what you noticed. If you haven't yet, say so and say when you will. Follow-up 2, "So it's a learning curve?": hold, then concede: "Yes, in" whatever you name, "and here is how I'll get ready." Don't fold into apologizing, and don't claim fourth-grade knowledge you don't have | F3 is the one gap you've stated yourself and the most predictable objection. JD because it scores fitness for the posted role |
| B2 | "Which part of a fourth-grade job do you expect to be hardest in your first year?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." | Pick one real thing, say why, and say what you'll do about it. Selection criteria: something specific to fourth grade (content, pacing, students' expectations) rather than a fake weakness. If nothing specific comes to mind yet, say so plainly and name what you'll look at first | Skeptic stem aimed at F3. A specific, honest answer reads as self-awareness |
| B3 | "You led your grade level's curriculum move. How much of that was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Keep "led" because it's your word. Keep "grade level", not "school". Say what the grade level did and what you did, in your own words. Answer slot: if others shared the leading, say who and how. If it was yours, say so plainly. Hold the claim through a second probe by returning to the sentence, never by adding to it | F10 and F11 rest on this one line, so it will be tested. EXP because it scores attribution |
| B4 | "Why leave Joliet after six years, and why Orrinsford?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot for "why leave": your real reason, in one or two sentences, said positively. For "why here", use what the district has published: the three beliefs and the 2026–2029 literacy plan. Connect only the parts that match your own lines: the curriculum move to the new 3–5 curriculum, and the reading club and weekly email to the belief in families and readers | A standard check on motivation. JD because fit with the posted role is what's being judged |

### C — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How do you work with a grade-level team?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on F10: your grade level's move to a new reading curriculum in 2024, which you led. Tell it in your own words. Answer slot: what working with that team looked like day to day. If there was a routine for team planning, describe it. If there wasn't, say so | "Work with the grade-level team" is in the posting, and peers are scoring it directly |
| C2 | "What would you bring to our team, and what would you need from us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." "I write a weekly email to families." | Bring: the curriculum move, the reading club and the weekly email, each in its own words. Need: be honest, since you're new to fourth grade. Ask for their pacing and curriculum know-how. Asking a peer for help, with something concrete you can give back, reads as easy to work with | Reciprocity is what peers score. Draws on F3, F8 and F10 |
| C3 | "Tell us about a time you disagreed with a colleague. What happened?" | JD | [generic] | Selection criteria: a real disagreement about students or teaching, a moment where you stated your view, and a working relationship still intact afterward. "We" for the context, "I" for your part. If no such time comes to mind, say so plainly, then say how you'd handle it | Persona stem. Peers want to see how you disagree |
| C4 | "You haven't been a team lead. If the team needed someone to take on a project, how would you handle it?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." "I led our grade level's move to a new reading curriculum in 2024" | "I haven't been a team lead." Then the curriculum move at its own scope: you led your grade level's move. Then how you'd approach a team project here, as a plan: ask first, divide the work, check in | You've stated F10's limit yourself. This rehearses keeping the project and the title separate |

### D — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about the reading club. Who comes, and what do you do with them?" | EXP | [grounded] "I've run the after-school reading club for the last two years." | Beats your sentence states: after school, two years, you run it. Answer slot: who attends and what a session looks like, in your own words. If you track how members' reading changes, say what you track. If you don't, say so plainly. Don't give numbers you haven't counted | F7. A reading specialist will dig into this line first |
| D2 | "How do you use assessment data to group students for reading?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: if you grouped from assessment data, name the assessment and walk through how a group was formed and changed. If you didn't, say so plainly and describe how you would. Name the part of your approach you'd defend least before they ask | F5 and the posting's data line. The weakest-assumption move turns a probe into credibility |
| D3 | "The district says no student leaves third grade without a reading plan. You've taught third grade. What's your experience with reading plans?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: if you wrote or used individual reading plans, describe one: what was in it and how it changed your teaching. If your school didn't use them, say so plainly, then say how you'd use the plans fourth graders arrive with | F7. The belief is about the grade you've taught, so it's likely aimed straight at you |

### E — Values / Behavioral (district beliefs)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Families Are Partners. How do you work with families?" | VAL | [grounded] "I write a weekly email to families." | Story-mapped on F8 and F9: the weekly email to families. Answer slot: what goes in it and whether families reply. If you've also spoken with every family each term, say how. If not, say so plainly and say how you'd add that conversation here. Don't stretch the email into conversations | One of three published beliefs, and families are a named panel topic |
| E2 | "Teach for Tomorrow, Not for the Test. How do you use assessments without teaching to them?" | VAL | [grounded] | Answer slot: if you've changed your teaching because of what an assessment showed, give that instance. If none comes to mind, say so plainly, then give your approach: assessments tell you what to teach next, not what to drill | F12. Published belief, no evidence in your material, so rehearse the honest version |
| E3 | "Tell us about a time a student was struggling to read. What did you do?" | VAL | [generic] | Selection criteria: one student, what you noticed, what you changed, and what happened. Use "I" for your actions. If no single case comes to mind, say so plainly, then give the nearest thing: the reading club or the curriculum move, in their own words, or how you'd handle it | Themed by Every Child a Reader. A former reading specialist will value a specific student story over a general philosophy |

### G — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell us a bit about yourself." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." "I write a weekly email to families." | A 90-second arc made only from these lines: six years of third grade in Joliet, the curriculum move you led in 2024, the reading club you've run for two years, and the weekly email. Close with one sentence on why fourth grade at Halvering (B4) | Nearly certain opener. Being casual doesn't mean it isn't scored |
| G2 | "What got you started with the after-school reading club?" | EXP | [grounded] "I've run the after-school reading club for the last two years." | Answer slot: your real reason, briefly and warmly. If you took it over from someone else, say so | A rapport question about a reading line, asked by a reading-focused panel |

### H — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over a candidate who's already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" | Pause. Don't argue the premise. "I haven't taught fourth grade. I've taught third grade for six years, and in 2024 I led our grade level's move to a new reading curriculum." Then the 2027 curriculum change. If pushed twice, concede the gap plainly and hold on what you did | A time-boxed version of B1 (F3). Low likelihood, but having rehearsed it keeps B1 steady |
| H2 | "A weekly email is one-way. That isn't really partnership, is it?" | VAL | [grounded] "I write a weekly email to families." | Hold: it's weekly and goes to families. Concede what's true: an email isn't a conversation. Answer slot: if families respond or you follow up, say how. If not, say so and say how you'd meet the district's each-term conversation | Pressure version of E1 (F9). Practices conceding without folding |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 License with elementary endorsement | — none. The gate is met on paper; bring a printout of your license record |
| F2 Grades 3–5 experience | G1, H1 |
| F3 Fourth grade | B1, B2, H1 |
| F4 Teaching all five subjects | A5 |
| F5 Differentiating with assessment data | A2, A4, D2 |
| F6 Classroom routines | A1 |
| F7 Every Child a Reader | A2, D1, D3, E3 |
| F8 Regular family communication | E1, C2 |
| F9 Families Are Partners | E1, H2 |
| F10 Grade-level team | C1, C2, C4, B3 |
| F11 New grades 3–5 curriculum | A3, B3 |
| F12 Teach for Tomorrow | E2 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | To Principal Vantongeren: "Your 2025 talk, *Small Groups, Big Readers*, was about weekly reading conferences in grades 3 to 5. How does that look in Halvering's fourth-grade rooms now?" | It's tied to her own published work and shows you researched her, not just the district |
| R2 | To the teachers: "What could a new person do in their first month that would genuinely help your team?" | A reciprocity question. It turns the peer evaluation into a conversation between teammates |
| R3 | "How is the team getting ready for the new grades 3–5 curriculum in fall 2027, and where would a new fourth-grade teacher fit in?" | Shows you know the district's literacy plan, and leads naturally to your 2024 curriculum move |
| R4 | "The district asks each teacher to speak with every family each term. How do fourth-grade teachers here usually make that happen?" | Takes the published belief seriously and asks about practice, not slogans |
| R5 | "How do the reading plans from third grade come over to fourth grade here?" | Connects your third-grade experience to their students' path |
| R6 | "What does a strong first year look like for a new fourth-grade teacher at Halvering?" | Gives you their success criteria to plan against |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated (F3) | "I haven't taught fourth grade." |
| Has been a grade-level team lead | A negative you stated (F10) | "I haven't been a team lead." Then the curriculum move at its own scope |
| Led a school- or district-wide curriculum adoption | Inflated form of F11 | The quote at its own scope. The pack's observation, not words for you: your material says the grade level's move, not the school's |
| Wrote or designed the reading curriculum | Inflated form of F11 | The quote at its own scope: you led the move to a new curriculum. A3's and B3's slots stay inside the move |
| Speaks with every family every term | Inflated form of F9 | "I write a weekly email to families." The pack's observation: the email is not a conversation. E1's slot stays inside the email |
| Raised students' reading levels through the reading club | Inflated form of F7 | "I've run the after-school reading club for the last two years." D1's slot asks only what you track, if anything |
| Has taught fourth-grade content or standards | Inflated form of F3 and F4 | Third-grade quote at its own scope. B1's slot asks only what you've looked at so far |

---

## Sources

**Provided:** HR interview invite (pasted); your resume (pasted).

**Not used:** the SSN and IEIN in your message. Neither is needed for interview prep, and neither appears anywhere in this pack.

**Searches and fetches:**

- Search "Orrinsford Community School District mission values" → orrinsfordschools.example/about/mission-and-beliefs
- Fetch orrinsfordschools.example/about/mission-and-beliefs → the three beliefs and their definitions
- Search "Halvering Elementary School Orrinsford" → no results
- Search "Dolores Vantongeren principal Halvering Elementary" → ilprincipalsforum.example/speakers/dolores-vantongeren
- Search "Illinois fourth grade teacher job description elementary school district posting" → k12jobsboard.example/listings/fourth-grade-teacher
- Fetch k12jobsboard.example/listings/fourth-grade-teacher → representative responsibilities and qualifications
- Search "Orrinsford Community School District teacher interview process panel" → orrinsfordschools.example/careers/how-we-hire-teachers
- Search "Orrinsford Community School District news 2026" → orrinsfordschools.example/news/board-adopts-literacy-plan

Research tier: L1 — searches 6 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford values` | yes | The three beliefs: F7, F9, F12, bank E, R4. No values cheat sheet, because the hiring page names no values round |
| 2. `Orrinsford interview process` | yes | One 45-minute panel (principal and two grade-level teachers) asking about reading, routines and families. Sets the persona weights and A1 |
| 3. `Orrinsford strategy` / recent news | yes | August 2026 literacy plan: F11, A3, R3 |
| 4. `Dolores Vantongeren Halvering` | yes | Interviewer read, Prober weight, R1 |
| 5. representative `Fourth Grade Teacher` JD | yes | F2, F4, F5, F6, F8, F10 and their questions, all `[inferred]` |
| Search for "Halvering Elementary School Orrinsford" (outside the declared targets) | yes | No results. Moved nothing |

---

## Upgrade menu

- **Halvering's actual posting text:** rows F2, F4, F5, F6, F8 and F10 change from `[inferred]` to `[grounded]`, and the JD questions get checked against the real list.
- **The two fourth-grade teachers' names:** questions assigned to each panelist, and a reverse question tailored to each.
- **A printout of your license record:** F1 goes from medium to high. Bring it Thursday.
- **Your answers to the answer slots:** reading plans (D3), assessment grouping (D2), routines (A1), family conversations (E1), and what leading the 2024 move involved (A3, B3). These upgrade F5, F6, F7, F9 and F11 from slots to stories you can tell.
- **How much prep time you have before Thursday:** a prioritized prep schedule.
- **Deeper research (L2), up to 6 more searches and 2 more fetches, several more minutes:** more on Halvering itself, more on the principal's published talk, candidate reports on district interviews, and recent changes in the district's staff or leadership.
- **A tuesday-dossier.md from job-underwriter:** objections drawn from verified evidence and an underwriter-checked list of claims not to make. It isn't needed for this pack.
