Quick update: I've read through the prep-pack method. Next I'll run a few quick searches on the school, the district and the principal, then write your pack.
I've saved your prep pack to `Halvering_fourth-grade-teacher_interview_pack.md`. Halvering's own job posting wasn't available, so I used a typical fourth-grade posting in its place and marked the parts that rely on it.

- **Main thing to practise:** the question "You've never taught fourth grade. Why should we believe you're ready?" (question A1). Say plainly that you haven't taught fourth grade. Then talk about your six years of third grade, and finish with a short plan for learning the new grade.
- **Your best talking point:** the district adopted a new literacy plan in August 2026. It brings in a new reading curriculum for grades 3–5 from fall 2027. That fits well with your 2024 work leading your grade level's move to a new reading curriculum (question B2).
- **The principal:** Principal Vantongeren was a reading specialist for nine years before she became principal. In 2025 she gave a talk on weekly reading conferences in grades 3 to 5, so expect detailed questions about how you teach reading.
- **Your license:** you meet the license requirement as your resume states it, and fourth grade falls inside your grades 1–6 endorsement. I've added a list of claims the pack won't help you make. Two examples are saying you've been a team lead, or that you chose the new curriculum.
- **Your private details:** you don't need your Social Security number or your license ID number to prepare for an interview. I left both out of everything, so there's no need to share them here again.

If you'd like a practice run, I can play the sceptical interviewer on question A1 and ask real follow-ups.
I can also save a tuesday-dossier.md file listing the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, I can convert it.

1. Can you paste Halvering's actual job posting? It would replace the typical posting I used and sharpen the role-specific questions.
2. Would you like a deeper research pass? It means up to 6 more searches and 2 more page reads, and takes several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Interview Prep Pack — Fourth Grade Teacher, Halvering Elementary School

**District:** Orrinsford Community School District
**Format:** 45-minute panel, Thursday
**Panel:** Principal Dolores Vantongeren (the hiring decision-maker) and two members of the fourth-grade team (your future peers, not named)

---

## How to use this pack

- **Personas** describe *how* a question is asked: who's asking and in what style. **Types** describe *what's being scored*.
- Type key:
  - **VAL**: values alignment, here the district's three published beliefs
  - **EXP**: experience deep-dive, whether what you list holds up under follow-up questions
  - **JD**: role requirements, whether you can do the listed job, gaps included
  - **CO**: district knowledge, your homework on Orrinsford's current plans
  - **CASE**: live problem, solved out loud in front of the panel
- **Provenance labels:** `[grounded]` = traceable to your resume, the invite, or a cited source. `[inferred]` = derived from a representative fourth-grade posting, standing in for Halvering's own. `[generic]` = a common pattern for this kind of question, with no claim about this school.
- **Answer slot** = a place where only you know the truth. It gives you two honest options and leaves the choice to you.
- The guidance is scaffolding, not a script. Say it in your own words.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "valid Illinois Professional Educator License with an elementary endorsement" — HR invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Met as your resume states it, and fourth grade falls inside grades 1–6. If asked, say it plainly in the resume's own words. Medium only because nothing has been inspected yet; bring a printout of your license record |
| F2 | "Fourth Grade Teacher position" — HR invite | "I've never taught fourth grade" — your CV and "Six years teaching third grade at a public elementary school in Joliet." — your CV | none | [grounded] | capability | A gap that wording can't close, and you've said so yourself. Words: "I haven't taught fourth grade." Then the adjacent fact at its own scope: "I've spent six years teaching third grade, at a public elementary school in Joliet." Then how you would get up to speed, said as a plan and never as a past. Never add anything that makes the gap sound smaller than it is |
| F3 | "experience in grades 3 to 5 preferred" — representative JD | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | none | Your third-grade years meet this as written. Lead with them in the resume's terms: six years, third grade, public elementary school |
| F4 | "plan and teach reading" — representative JD | "Six years teaching third grade at a public elementary school in Joliet." — your CV and "I led our grade level's move to a new reading curriculum in 2024" — your CV and "I've run the after-school reading club for the last two years" — your CV | medium | [inferred] | presentation | Your reading evidence is your strongest material. Say it in the resume's own terms: "In 2024 I led our grade level's move to a new reading curriculum, and for the last two years I've run the after-school reading club." Add nothing it doesn't say |
| F5 | "plan and teach … writing, math, science and social studies" — representative JD | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | discovery | Your resume doesn't say which subjects you taught. Answer slot: the posting's subject list makes a question about non-reading subjects likely. If you taught these in third grade, say which ones and how, in your own words. If any weren't yours to teach, say so plainly and stay with the ones you taught |
| F6 | "differentiate instruction using assessment data" — representative JD | none given | none | [inferred] | discovery | Strong evidence here would be a specific case of grouping or adjusting instruction from assessment results. Answer slot: if you've done this, describe a real case in your own words. If you haven't, say so plainly and say how you'd approach it |
| F7 | "keep clear classroom routines" — representative JD | none given | none | [inferred] | discovery | Strong evidence here would be named routines and how you taught them in the first weeks. Answer slot: if you have routines you rely on, name them in your own words. If none come to mind, say so and describe how you'd set them up |
| F8 | "communicate regularly with families" — representative JD | "I write a weekly email to families." — your CV | medium | [inferred] | none | No gap. Lead with the weekly email, in exactly those terms, because a named habit beats an adjective |
| F9 | "work with the grade-level team" — representative JD | "I led our grade level's move to a new reading curriculum in 2024" — your CV and "I've never been a team lead" — your CV | medium | [inferred] | presentation | Say the move in its own words: "In 2024 I led our grade level's move to a new reading curriculum." If the panel asks about titles: "I haven't been a team lead." Leading the move and holding a team-lead title are two different things, so keep them separate |

---

## Reading the interviewer

| What's known | Source | Provenance | What it means for you |
|---|---|---|---|
| Principal of Halvering Elementary since 2022, after nine years as a reading specialist | Illinois principals' forum speaker page | [grounded] | Expect reading questions with real depth. She knows reading instruction from the inside, so precise and modest answers will land better than broad ones |
| Gave a 2025 forum talk, *Small Groups, Big Readers*, on weekly reading conferences in grades 3 to 5 | Same page | [grounded] | Small-group reading and conferences may come up; D3 rehearses this as a live problem. Only the talk's title and topic are known, so don't claim you've seen it |
| The two fourth-grade team members | Not named | — | Treat them as peers: they're weighing whether you would make their planning lighter or heavier |

No shared career moves are offered as talking points. Her path went from reading specialist to principal, and nothing in your material matches that path.

---

## Persona table

| Persona | How it shows up here | Likelihood (reasoning) | Counter-strategy |
|---|---|---|---|
| Skeptic | Principal or teammates press on fourth grade | **High.** F2 is the most visible gap, and a panel prior for the principal puts Skeptic near the top | Rehearse A1 until it bores you. Say the plain acknowledgment, then your adjacent evidence, then a concrete plan |
| Case/Strategist | "What would you do with…" scenarios on readers, routines, groups | **High.** The principal is the hiring manager, and the district's careers page says panels ask about reading instruction and classroom routines | Ask a clarifying question, then lay out a structure, then answer. Think out loud |
| Peer Evaluator | Teammates ask about planning together, disagreements, what you'd bring | **Medium-high.** Two of the three panelists are grade-level teachers | Talk about what you'd bring them as well as what you'd need from them |
| Data-Driven Prober | Follow-ups on the reading club and the curriculum move: "what did that look like?" | **Medium.** The principal's reading-specialist background raises it | Say only what you did. Where you don't know, say so |
| Values/Behavioral | Questions framed around the district's three beliefs | **Medium.** The district says the beliefs "guide every hire", but the careers page names no separate values round | Map a real story to each belief, or say plainly when you don't have one |
| Conversational | The opener and the license check | **Medium.** Nearly every panel opens this way | A 90-second journey arc built only from your resume lines |
| Pressure | A time-boxed "why you?" | **Low.** Nothing in the sources signals it, but it's a common panel move | Pause, stay with what you've actually stated, hold your position, and concede only what's real |

The loop is established by the invite and the district's careers page: one 45-minute building panel with the principal and two grade-level teachers. References are taken after the panel.

---

## Question banks

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never taught fourth grade. Why should we believe you're ready?" | JD | [grounded] "I've never taught fourth grade" "Six years teaching third grade at a public elementary school in Joliet." | **Highest-ROI prep in this pack.** Open with the plain acknowledgment: "I haven't taught fourth grade." Then the adjacent fact at its own scope: six years teaching third grade, at a public elementary school in Joliet. Then two or three concrete steps you would take to learn the fourth-grade curriculum and standards, said as a plan. Follow-up 1 ("fourth graders are different"): agree that you'd be learning, and don't claim to know them already. Follow-up 2 ("like what, specifically?"): name the steps you'd actually take, your own choice. Concession, ready to say: "You're right that my first year in fourth grade would include learning the grade." Never suggest third and fourth grade are the same job | F2 is the gap a panel can't miss, so this will come in some form. A rehearsed, non-defensive answer turns it from a weakness into a sign of candor. JD because the role is defined by its grade |
| A2 | "Which part of teaching fourth grade would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Pick one area you genuinely expect to learn. It needs a name, a reason, and your plan for learning it. If nothing more specific comes to mind, the fourth-grade curriculum itself is an honest answer, since you haven't taught it. Don't pick a fake weakness | The Skeptic's standard question, made sharper by F2. JD because it scores self-assessment against the role |
| A3 | "Why fourth grade, and why Orrinsford, now?" | JD | [generic] | Your resume doesn't give your reasons, so use your real ones, in your own words. If one of the district's beliefs is genuinely part of it, name it by its official name. If none is, don't reach for one | A Skeptic tests whether your motivation holds up under questioning. `[generic]` because the guidance makes no claim about your past |
| A4 | "You led your grade level's move to a new reading curriculum. What was your role on the team?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've never been a team lead" | Say what the resume says: in 2024 you led your grade level's move to a new reading curriculum. If asked about titles: "I haven't been a team lead." Answer slot: the posting's grade-level-team line makes "what did leading it involve?" likely. If there were specific things you did, name them in your own words. If you can't point to specifics, say so plainly and stay with the move itself | F9 is where "led" can get stretched into "lead," so rehearse keeping the two apart. EXP because it tests what was actually yours |

### B — Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "It's October and one of your fourth graders is reading two grade levels below. Walk us through your first month." | CASE | [generic] | Clarify first: what data you already have and what support the building offers. Then structure it: assess, set a goal, plan instruction, bring in the family, check progress. The question asks nothing about your past, so the guidance claims nothing | A live reading problem sits squarely in the careers page's "reading instruction" focus and in front of a reading-specialist principal. CASE because it's scored on structure |
| B2 | "Our district starts a new grades 3–5 reading curriculum in fall 2027. What would you bring to that?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The beats are what the quote states: you led your grade level's move, to a new reading curriculum, in 2024. Answer slot: the posting's grade-level-team line makes "how did you work with colleagues on it?" likely. If you did specific things, say which, in your own words. If you can't point to specifics, say so and stay with the move. Then say what you'd offer in 2027, as a plan. Never say you chose or designed the curriculum | This is where your strongest material (F4, F9) meets the district's newest plan (see Sources), which makes it your best differentiator. CO because it shows you've done your homework |
| B3 | "Plan the first two weeks of routines for a new fourth-grade class." | CASE | [generic] | Name the routines (arrival, transitions, materials, independent reading time), how you'd teach and practice them, and how you'd know they're working. Keep it a plan, and don't say you've done it before unless you have (F7's slot) | The careers page names "classroom routines" as a panel topic, and F7 has no evidence yet. CASE because it's a live plan |
| B4 | "How would you differentiate a math lesson for a class with a wide spread of readiness?" | CASE | [generic] | Clarify which unit and what data you have. Then: a quick pre-check, flexible groups, tiered tasks, and an exit check. Any past examples belong to F5's and F6's slots | Covers the posting's differentiation and non-reading-subject lines (F5, F6). CASE because it's scored on reasoning |

### C — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "We plan together as a team. What would you bring us, and what would you need from us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years" "I write a weekly email to families." "I've never taught fourth grade" | Bring: the three things your resume states, in its own words. Need: honestly, their fourth-grade knowledge, since you haven't taught fourth grade. Asking for that comes across as reciprocity, not weakness | The peers' core question. JD because the posting's team line scores it (F9) |
| C2 | "Tell us about a time you disagreed with a colleague on your team." | JD | [generic] | Pick a real disagreement with a named stake, a point where you held your view, and a working relationship that stayed intact. "We" for the context, "I" for what you did. If no such time comes to mind, say so plainly, then describe how you'd handle one | A Peer Evaluator's standard question, themed by the team line. `[generic]` because your resume carries no such story |
| C3 | "When you led the curriculum move, how did you bring colleagues along?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if you did specific things to bring colleagues along, describe them in your own words. If there was no such step, or it wasn't yours, say so plainly and return to the fact that you led the move | The question assumes a practice your resume doesn't state. Rehearse the honest answer before the probe comes (F9) |

### D — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk us through how you ran the after-school reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" | The beats are what the quote states: you ran it, for the last two years. Tell it in your own words. Answer slot: the posting's assessment-data line makes "how did you know it helped?" likely. If you tracked anything, say what. If you didn't, say so plainly and describe what the club was | F4's evidence, and a reading-specialist principal will want to hear more. EXP because it tests what you did |
| D2 | "How do you use assessment data to group readers?" | JD | [generic] | Answer slot: if you've done this, walk through one real case in your own words. If you haven't, say so plainly and describe how you would do it: what data, how you'd group, how often you'd regroup. Never describe a system you didn't use | F6 has no evidence. JD because it's a listed responsibility |
| D3 | "Suppose you held a weekly one-on-one reading conference with each fourth grader. What would one look like?" | CASE | [generic] | Structure: what you'd listen for, the one teaching point, the note you'd record, the goal you'd leave the student with, and how it would feed your small groups. It's a live problem, not a claim about your past | Directly on the principal's published topic (see Reading the interviewer). CASE because it's asked as a scenario |

### E — Values/Behavioral (district beliefs)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Families Are Partners: each teacher here speaks with every family each term. How do you work with families?" | VAL | [grounded] "I write a weekly email to families." | Lead with the weekly email, in those words. Answer slot: the district's belief raises speaking with every family each term. If you've done that, say how, in your own words. If you haven't, say so plainly and say how you'd do it here | F8 is solid. The belief sets a higher bar than email, so rehearse the honest answer ahead of time. VAL because it's a published belief |
| E2 | "Every Child a Reader: tell us about a student you made sure didn't fall behind in reading." | VAL | [generic] | Pick a real student story with a specific need, what you did, and what changed. Keep it anonymous. If no such time comes to mind, say so plainly, then give the nearest thing your material carries (the reading club) or how you'd handle it | Belief-themed open question. `[generic]` because your resume carries no single-student story |
| E3 | "Teach for Tomorrow, Not for the Test: how do you keep assessment from taking over your teaching?" | VAL | [generic] | Say your real view, then a real example if you have one. If no example comes to mind, say so plainly and describe how you would balance the two | Belief-themed question. Also touches F6 |

### G — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell us a little about yourself." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years" "I write a weekly email to families." | A 90-second arc using only these four facts, in your own words, ending with why fourth grade at Halvering (your real reason, see A3) | It's almost certainly the opener, and casual questions are still scored. Built on F3, F4 and F8 |
| G2 | "Can you confirm your licensure and endorsement?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it exactly as your resume does, in one sentence | F1 is the invite's only stated requirement. Have the answer ready and short |

### H — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over a candidate who's already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade" "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" | Pause, then concede first: "I haven't taught fourth grade." Then hold on what you've stated: six years teaching third grade, and leading your grade level's move to a new reading curriculum in 2024. Let the panel draw their own conclusion. Keep this position through two follow-ups, and concede only the fourth-grade point, which you already said up front | F2 delivered under time pressure. JD because it scores fit |
| H2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold on the word "led." Answer slot: if there were specific parts you did, name them. If others did parts of it, say so plainly and stay with the fact that you led the move. Never widen it into choosing or designing the curriculum | Probes the attribution behind F4 and F9 |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 License | G2 |
| F2 Fourth grade | A1, A2, H1 |
| F3 Grades 3–5 experience | G1, A1 |
| F4 Reading | B1, B2, D1, D3, E2 |
| F5 Writing, math, science, social studies | B4 covers math. Writing, science and social studies get no question of their own, because they come from one representative-posting line and the district's careers page names reading, routines and families as panel topics; F5's answer slot rehearses them |
| F6 Assessment data | D2, B4, E3 |
| F7 Routines | B3 |
| F8 Families | E1, C1 |
| F9 Grade-level team | A4, C1, C2, C3, H2 |

---

## Reverse questions

| Question | Why it lands | Provenance |
|---|---|---|
| (To the principal) "Your 2025 forum talk was on weekly reading conferences in grades 3 to 5. How do those look in fourth grade here?" | Ties to her own published work and opens the conversation on her home ground. Only the talk's title and topic are known, so ask rather than comment | [grounded] speaker page |
| "How is the fourth-grade team preparing for the new grades 3–5 reading curriculum in fall 2027?" | Shows current homework, and it connects naturally to your 2024 curriculum move | [grounded] district news |
| "Each teacher here speaks with every family each term. How do fourth-grade teachers make that work in practice?" | Uses the district's own words, and invites the peers to tell you how they actually work | [grounded] district beliefs page |
| (To the teachers) "What could a new teammate do in the first month that would genuinely help your team?" | Reciprocity: it's about what you'd bring them | [generic] |
| "What do your students find hardest about the move from third grade to fourth?" | Puts your third-grade experience to work as something useful to them | [generic] |
| "What does a typical week of team planning look like for fourth grade?" | Shows you're picturing yourself on the team | [generic] |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated, F2 | "I haven't taught fourth grade." Then the third-grade fact at its own scope |
| Has been a grade-level or team lead | A negative you stated, F9 | "I haven't been a team lead." The curriculum move stays in its own words |
| Chose, selected or designed the new reading curriculum | Inflated form of F4/F9's curriculum line | The quote at its own scope. Your material says you led the move, not that you picked the curriculum. A4, B2, C3 and H2 slots stay inside the move |
| Founded or created the after-school reading club | Inflated form of F4's reading-club line | The quote at its own scope: you've run it for the last two years. D1's slot stays inside running it |

---

## Sources

Provided: interview invite (HR, Orrinsford Community School District); your resume as pasted. Your SSN and license ID number were not used anywhere in this pack.

Searches and fetches:
- Search "Orrinsford Community School District mission values" → https://orrinsfordschools.example/about/mission-and-beliefs
- Fetch https://orrinsfordschools.example/about/mission-and-beliefs → three beliefs: Every Child a Reader, Families Are Partners, Teach for Tomorrow, Not for the Test
- Search "Halvering Elementary School Orrinsford" → no results
- Search "Dolores Vantongeren principal Halvering Elementary" → https://ilprincipalsforum.example/speakers/dolores-vantongeren
- Search "fourth grade teacher job description Illinois elementary school district posting" → https://k12jobsboard.example/listings/fourth-grade-teacher
- Fetch https://k12jobsboard.example/listings/fourth-grade-teacher → responsibilities and qualifications quoted in F3–F9
- Search "Orrinsford Community School District teacher interview process panel" → https://orrinsfordschools.example/careers/how-we-hire-teachers
- Search "Orrinsford Community School District news 2026" → https://orrinsfordschools.example/news/board-adopts-literacy-plan (August 2026: three-year literacy plan, new grades 3–5 reading curriculum from fall 2027, a family reading night at every school each term)

Research tier: L1 — searches 6 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. district values | yes | The three beliefs theme bank E and two reverse questions. No values cheat sheet, because the careers page names no values round |
| 2. district interview process | yes | Confirmed one 45-minute panel (principal and two grade-level teachers) and its topics: reading, routines, families. Persona weights follow from this |
| 3. district strategy / recent news | yes | The 2026–2029 literacy plan, used in B2 and a reverse question |
| 4. Dolores Vantongeren | yes | Interviewer read, D3, and the first reverse question |
| 5. representative fourth-grade JD | yes | Requirements F3–F9, labeled `[inferred]` |
| School-name search (outside the declared targets) | yes | No results. Moved nothing |

---

## Upgrade menu

- Halvering's own posting text → F3–F9 move from `[inferred]` to `[grounded]`, and the JD-tagged questions retune to its exact lines
- Your answers to F5, F6 and F7's slots (which subjects you taught, how you've used assessment data, the routines you rely on) → those rows gain evidence, and B3, B4 and D2 become story-mapped
- A printout of your license record from the Illinois State Board of Education's licensure system → F1 moves from medium to high, ready to hand over if asked
- Names of the two fourth-grade teachers → a per-member read and tailored reverse questions
- How much prep time you have → a prioritized prep schedule
- Deeper research (up to 6 more searches and 2 more fetches, several more minutes) → a fuller picture of the district's plans, Halvering's school context, and more of the principal's published work
- A tuesday-dossier.md from a job-underwriter run → an evidence-checked version of the main objection and per-gap strategy limits (optional, never required)
