I'm checking the skill's rules for research and hard gates, then I'll give you the assessment.
**No, this isn't a real job. It shows the standard signs of a job scam: don't send your IBAN, PPS number or passport, don't pay the €349, and don't lodge any cheque. Status: `no_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (€30,000 a year minimum)
- `must_have`: direct: R3 · adjacent: R2 (Strong attention to detail) · unclear: R4 (Good written English)
- `important`: unclear: R5 (A quiet place to work)

R2 and R3: your background suits genuine order-processing work; R1: the posting's pay can't be checked against your floor.

**Opportunity ledger.** The recruiter's own messages confirm the decision: they asked for your IBAN, PPS number and passport before any interview (RR2), asked for a €349 upfront fee (RR3), and offered a cheque where you keep part and send the rest on (RR4). On top of that, hiring happens only on Telegram (RR1), the employer can't be found (RR5), the contact email isn't on a company domain (RR6), and the pay is an "up to" figure (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (€30,000 a year minimum).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`), RR5 (`severity: high`).
- **What would change this:** the messages behind RR2, RR3 and RR4 would have to be different, and nothing an employer could explain now changes them.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics." A search for the exact name found nothing (RR5) | `[grounded]` posting header; search returned no results |
| Mandate | "Remote Order Processing Coordinator." Processing orders, paid hourly plus commission per order | `[grounded]` posting |
| Hours and pay | 15–30 hours a week, "up to €26 an hour plus commission" | `[grounded]` posting |
| Pay reading | At the full €26, that's about €20,280 a year at 15 hours and €40,560 at 30 hours. Reaching €30,000 takes about 22 hours a week at the top rate, and "up to" guarantees no rate at all | `[inferred]` arithmetic on the posting's own figures, 52 weeks |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median €31,200, middle range €28,400–€34,100. This is a market band, not this employer's offer | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide, n=1,140 |
| Hiring process | Telegram only, "no calls or video interviews"; payroll documents requested before the interview; equipment fee; cheque to lodge and forward | `[grounded]` posting and @VellowayHiring messages |
| Unknowns | Legal entity, company registration, address, real website, who the "equipment partner" is | — |
| Contradictions | The process changed partway: "before your chat interview" became "the job is yours" with no interview of substance. The fee went from "we will refund it with your first wages" to being paid out of a cheque they send you | `[grounded]` the three messages you quoted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | €30,000 a year minimum (your hard constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your stated floor. Fit is unclear because the posting gives only an "up to" hourly rate over variable hours | `[grounded]` your message; posting | Moot for this posting. Use it as a screen for genuine roles |
| R2 | Strong attention to detail | must_have | adjacent | medium | transferability | 3 years at about 60 Zendesk tickets a day at a parcel courier is close to order handling, but accuracy itself is self-reported | `[grounded]` your background; `[inferred]` closeness to order processing | Gap queue G1 |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep the team's weekly tracker in Excel. Medium because it's self-report with nothing to inspect yet | `[grounded]` your background | none |
| R4 | Good written English | must_have | unclear | low | discovery | Ticket work often means written replies, but your background doesn't say yours were written | `[inferred]` from Zendesk ticket work | Gap queue G2 |
| R5 | A quiet place to work | important | unclear | low | discovery | Not stated | `[grounded]` background silent | Matters only for genuine remote roles |

## Gap recovery queue

These gaps matter only for genuine roles you apply to next. They change nothing about this one.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Attention to detail (R2, must_have) | transferability | High ticket volume; training two new starters | Real order-processing roles usually test accuracy | Error or QA scores, catching wrong addresses or duplicate orders, checklists you wrote for new starters | A QA score or a performance review excerpt | `[inferred]` from your stated duties; `[generic]` that accuracy gets tested |
| G2 | Written English (R4, must_have) | discovery | Zendesk tickets, channel not stated | Written customer replies would make this row direct | Email or chat replies, macros or templates you wrote | A sanitized sample reply | `[inferred]` from your stated duties |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Hiring only through Telegram, no calls or video | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | Keeps the recruiter anonymous and untraceable. Genuine employers interview through traceable channels | `[generic]` common job-scam pattern | Can I speak with the hiring manager on a video call from a company email account? | confirmed |
| RR2 | IBAN, PPS number and passport requested before any interview | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | Identity theft: these together are enough to open accounts or commit fraud in your name. Payroll details are normally collected after a signed contract | `[generic]` identity-fraud and onboarding pattern | Can you send a written contract on company letterhead with a registered company number before I share any documents? | confirmed |
| RR3 | Upfront fee for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages" | Advance-fee fraud. Genuine employers supply equipment or reimburse it, and don't route your money to a third party | `[generic]` advance-fee scam pattern | Can the company ship the equipment directly at its own cost? | confirmed |
| RR4 | Cheque to lodge, keep part, forward the rest | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest" | Fake-cheque or overpayment scam: the cheque bounces after your transfer clears, you lose the €2,500 you sent, and your account may be used to move stolen money | `[generic]` overpayment and money-mule pattern | Why would an employer send money through my personal account to pay a supplier? | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | high | "Velloway Logistics" | No web presence under the exact name. High because it comes with off-domain contact, ID requests and money handling | `[grounded]` search returned no results; `[generic]` that a thin footprint alone isn't proof | What is your registered company number and the address on your website? | confirmed |
| RR6 | Contact email not on a company domain | risk_signal | medium | "email velloway.hr@postmail.example" | A generic mail provider instead of a company domain fits a recruiter with no real company behind them | `[inferred]` from the address itself | Why doesn't HR use a company-domain email? | confirmed |
| RR7 | Pay stated as "up to" plus commission | risk_signal | medium | "Earn up to €26 an hour plus commission on every order you process" | "Up to" plus commission doesn't guarantee your €30,000 floor (R1). The band in Role reality is salaried | `[inferred]` from the posting's wording; `[generic]` band | What is the guaranteed hourly rate, and how many hours are guaranteed? | unresolved |

## Application plan

These are recommendations, and each one is your decision.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing: no IBAN, PPS number, passport photo or money. Also avoid pasting your IBAN into chats like this one; I haven't used it and don't need it | See RR2, RR3 | `[grounded]` register | recommended |
| A2 | If a cheque arrives, don't lodge it. Keep it as evidence for the Gardaí | See RR4 | `[generic]` overpayment-scam pattern | recommended |
| A3 | Report the listing to the jobs site, report @VellowayHiring in Telegram, and report it to the Gardaí. Screenshot the chat first | Protects other applicants and creates a record | `[generic]` standard reporting route | recommended |
| A4 | Stop replying. If they keep pushing, block them after taking the screenshots | See RR1 | `[generic]` scam-handling pattern | recommended |
| A5 | Apply to genuine order-processing or customer-operations coordinator roles. Your Zendesk volume, Excel tracker and training of new starters match R2 and R3, and the band in Role reality sits around your €30,000 floor | See R2, R3, market calibration | `[grounded]` your background; `[generic]` band | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" (exact match) and got no results, so the employer is not established. Feeds RR5 and the organization row in Role reality |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator Ireland salary", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). Feeds the market calibration row and RR7 |
| 3. Hiring manager's public footprint | n/a | No name was given, only a Telegram handle |

I can put all of this into a `tuesday-dossier.md` file if you'd like a copy to keep.

**Upgrade menu**
- A genuine posting you're considering: I'd run the same check on it, and your background rows would carry over.
- Answers on G1 and G2: R2 and R4 could move up, which strengthens applications to real roles.
- A deeper research pass on Velloway: public scam reports and any company registration (up to 5 more searches and 2 more fetches). It wouldn't change the `no_go`, but it could add detail for your report.

**Questions**
1. (RR2) Have you already given them anything besides your answers in the chat, such as your phone number, email, home address or CV? That decides whether A3 should include warning your bank.
2. (G2) In your Zendesk work, were most tickets answered in writing, by email or chat?

You can answer in text, paste a transcript, attach a document, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.