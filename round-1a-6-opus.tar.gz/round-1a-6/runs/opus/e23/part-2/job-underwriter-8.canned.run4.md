Quick update: I'm going through the job-check steps and about to look up whether "Velloway Logistics" exists. Then I'll write up the verdict.
**No, this isn't a real job, and you shouldn't go ahead.** Don't send your IBAN, PPS number or passport, don't pay the €349, and don't lodge the cheque. Status: `no_go`.

## Decision snapshot

**Fit ledger.**
- `hard_gate`: unclear: R1 (at least €30,000 a year)
- `must_have`: direct: R3, R4 · adjacent: R2 (strong attention to detail) · unclear: R5 (a quiet place to work)
- `important`: adjacent: R6 (order processing)

R2, R3, R4 and R6 show you'd be a credible candidate for a real version of this role; R5 is minor.

**Opportunity ledger.** The fit doesn't matter here, because the opportunity is the problem:
- **RR2:** they asked for your ID and bank details before any interview.
- **RR3:** they want you to pay an upfront fee.
- **RR4:** they're sending a cheque and asking you to pass most of it on. This is the classic fake-cheque overpayment scam.
- **RR1:** no company called Velloway Logistics could be found anywhere.
- **RR5, RR6 and RR7:** these support it: Telegram only, an email that isn't on a company domain, and a "job offer" straight after a chat.
- **Positive signals:** none found.

- **Hard gates:** none failed; unconfirmed: R1 (at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would have to be different:** a registered employer you can verify, a real interview with a named person, and no request for money, ID or banking details before a written contract. None of that is true here.

I'm not using the passport or PPS details. Nobody needs them to judge a job, and a real employer only asks for them after you've signed a contract. I also didn't use your IBAN in any search.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics": two searches turned up nothing | `[grounded]` posting; searches returned no results |
| Mandate | "Remote Order Processing Coordinator", processing orders, 15–30 hours a week, hours you choose | `[grounded]` posting |
| Pay as stated | "Up to €26 an hour plus commission." At 15–30 hours a week that's about €20,280–€40,560 a year, and only if €26 really is the rate | `[grounded]` posting; `[inferred]` arithmetic (hours × €26 × 52) |
| Market calibration | Order processing and customer operations coordinators in Ireland: median €31,200, typical range €28,400–€34,100, salaried roles only | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide, not this employer's offer |
| Hiring process | Telegram only, "no calls or video interviews"; the job was "offered" after a text chat | `[grounded]` posting and messages |
| Unknowns | Legal entity, registered address, real people, contract type, what "commission" means | — |
| Contradictions | Payroll wants your ID "before your chat interview", yet the posting promises "full training" and a normal job | `[grounded]` messages against posting |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | At least €30,000 a year (your hard constraint) | hard_gate | unclear | high | hard_gate | The constraint is yours and confirmed. The posting's "up to" rate with variable hours could land above or below it | `[grounded]` your statement; `[inferred]` pay arithmetic | Moot for this posting; check it in real ones |
| R2 | Strong attention to detail | must_have | adjacent | medium | transferability | Around 60 Zendesk tickets a day for 3 years implies accuracy at volume. It's a trait, so this is evidence for it rather than proof | `[grounded]` your stated background | Use for real applications |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly Excel tracker. You stated it but there's nothing to inspect yet | `[grounded]` your stated background | Use for real applications |
| R4 | Good written English | must_have | direct | medium | none | Ticket work in Zendesk is mostly writing, and you trained two new starters | `[grounded]` your stated background | Use for real applications |
| R5 | A quiet place to work | must_have | unclear | low | discovery | Not mentioned | `[grounded]` nothing stated | see G1 |
| R6 | Order processing (implied by the title) | important | adjacent | medium | transferability | Courier customer service touches orders and deliveries, but processing orders yourself isn't stated | `[inferred]` from the title against your courier work | see G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Quiet place to work (R5, must_have) | discovery | Nothing either way | Only matters for genuine remote roles | A home office or spare room; any past remote shifts | None needed | `[grounded]` nothing stated |
| G2 | Order processing (R6, important) | transferability | Courier customer service, tickets, a tracker | It's the bridge into real order or operations coordinator jobs | Fixing addresses or orders, rebooking deliveries, handling claims or refunds | Your tracker layout, or ticket volume figures | `[inferred]` bridge from your courier work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | red_flag | high | "Velloway Logistics" | The company probably doesn't exist. Combined with RR2–RR4 this is impersonation, not a small firm with a thin web presence | `[grounded]` two searches with no results; `[generic]` scam pattern | What is your Companies Registration Office (CRO) number and registered address? | confirmed |
| RR2 | ID and bank details asked for before any interview | red_flag | high | "send your IBAN, your PPS number and a clear photo of your passport" | Identity theft, or using your identity and account to open accounts or move money | `[grounded]` message; `[generic]` identity-fraud pattern | Why does payroll need my passport before an interview or a contract? | confirmed |
| RR3 | Upfront payment for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | Advance-fee fraud: the money goes and no refund comes | `[grounded]` message; `[generic]` advance-fee pattern | Can you deduct the kit from my wages, or ship company-owned equipment, instead of me paying? | confirmed |
| RR4 | Cheque overpayment and forwarding | red_flag | high | "Lodge it… keep €350… transfer the rest to our equipment partner" | Fake-cheque scam. The cheque can look like it has cleared and then bounce days later, leaving you owing your bank the full amount. Forwarding money may also make you a money mule | `[grounded]` message; `[generic]` how cheque fraud works | Why would an employer send a cheque for me to forward to a supplier instead of paying them directly? | confirmed |
| RR5 | Hiring only on Telegram, no calls or video | risk_signal | medium | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | Hides who you're dealing with | `[generic]` job-scam pattern | Can I have a video call with my future manager, and what's their name? | confirmed |
| RR6 | Email address that isn't on a company domain | risk_signal | medium | "velloway.hr@postmail.example" | No company domain, so the sender can't be traced to an employer | `[grounded]` message | Why isn't HR emailing from a company domain? | confirmed |
| RR7 | Job offered straight after a text chat | risk_signal | medium | "you passed the interview and the job is yours" | Real hiring is rarely this fast. The speed pushes you on to the payment step | `[generic]` scam pattern | Can I have a written contract with the employer's legal name before I start? | confirmed |
| RR8 | Pay stated as "up to" plus commission | risk_signal | low | "Earn up to €26 an hour plus commission" | A ceiling with no floor, and no definition of commission | `[inferred]` from the wording | What's the guaranteed hourly rate, and how is commission calculated? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't paste the IBAN, PPS number or passport photo. Clear the IBAN from your clipboard or drafts | RR2 | `[grounded]` RR2 | your call |
| A2 | Don't pay the €349 | RR3 | `[grounded]` RR3 | your call |
| A3 | If a cheque arrives, don't lodge it. Keep it, tell your bank, and report it | RR4 | `[generic]` fake-cheque pattern | your call |
| A4 | Stop replying. Report @VellowayHiring in Telegram, and report the posting to the jobs site | RR1, RR5 | `[generic]` standard reporting routes | your call |
| A5 | Report it to An Garda Síochána (Irish police), especially if they already have your address | RR2, RR4 | `[generic]` Irish fraud reporting | your call |
| A6 | Use your real background for genuine order or customer operations coordinator jobs. The usual pay range sits around your €30,000 floor | R2, R3, R4, R6 | `[generic]` Pennoral band | your call |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "\"Velloway\" logistics careers order processing". Both returned nothing, so the employer is not established. Moved RR1 and the Organization row |
| 2. Role-family sweep | yes | Searched "order processing coordinator salary Ireland remote", which returned the Pennoral 2026 Ireland Customer Operations Pay Guide (pennoral.example/2026-ireland-customer-operations-pay-guide). Moved the market calibration row and A6 |
| 3. Hiring manager's public footprint | n/a | No name was given. @VellowayHiring is a handle, not a name |

I can save all of this as a `tuesday-dossier.md` file if you want a record.

## Upgrade menu
- **A real posting you're considering:** a full fit check against your €30,000 floor (R1).
- **Your tracker, or numbers on your ticket volume:** R3 and R2 move to `high`.
- **A deeper research pass on Velloway** (up to 5 more searches and 2 more fetches): it won't change this decision and only makes sense if you want more for a report.

## Question

RR4 — They say they're posting you a cheque. Have you given them your home address, and has the cheque arrived? If so, A3 and A5 become more urgent. You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.