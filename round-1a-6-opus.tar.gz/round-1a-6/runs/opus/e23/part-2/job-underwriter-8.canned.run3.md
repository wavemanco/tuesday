I'm working through the job-vetting checklist now. Next I'll run a few quick web checks on "Velloway Logistics", then write up the assessment.
## Decision snapshot

**No, this isn't legit and you shouldn't go ahead. Their own messages contain three severe red flags: RR2, RR3 and RR4. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R5 (At least €30,000 a year)
- `must_have`: direct: R2 · adjacent: R1 (Strong attention to detail) · unclear: R3 (Good written English)
- `important`: unclear: R4 (A quiet place to work)

R1, R2: your courier work speaks to them; R5: the posting never commits to a pay figure.

**Opportunity ledger.** On the evidence this is not a genuine opportunity. The employer can't be found (RR1). They asked for your ID and bank details before any interview (RR2), then for an upfront fee (RR3), then told you to lodge a cheque and pay most of it onward (RR4). All contact is on Telegram only (RR5) and is now moving to an off-domain email (RR6). The pay is above market for a role needing no experience (RR7).

- **Hard gates:** none failed; unconfirmed: R5 (At least €30,000 a year)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`)
- **What would have to be different:** an employer you can verify yourself; contact through its own company domain and a real interview; no fees; no cheque to pass on; ID and bank details collected only after a written contract. RR2, RR3 and RR4 have already happened, so no answer from them can undo this.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics." Nothing came up for it in searches (RR1) | `[grounded]` posting; searches returned no results |
| Mandate | "Remote Order Processing Coordinator." The posting never says what orders, for whom, or in which system | `[grounded]` posting; `[inferred]` from what it leaves out |
| Pay and hours | "up to €26 an hour plus commission", "15–30 a week" | `[grounded]` posting |
| Hiring process | "runs on Telegram, so there are no calls or video interviews"; the "interview" was a chat | `[grounded]` posting and messages |
| Scope read | No product, customer, manager or tools are named. There is no real job description to measure against | `[inferred]` from what the posting leaves out |
| Market calibration | Order-processing and customer-ops coordinators in Ireland: median €31,200, middle range €28,400–€34,100 (salaried only). €26/hr at full-time hours would sit far above that, with no experience required (RR7). This band is what real roles pay, not this employer's offer | `[generic]` Pennoral 2026 Ireland pay guide, found this session; `[inferred]` the full-time arithmetic |
| Unknowns | Registered company, address, manager, contract type, the hourly rate actually promised | — |
| Contradictions | The equipment fee was €349 to be "refunded with your first wages." The cheque instead has you forward €2,500 (€2,850 − €350) to the same "equipment partner." The amounts and the story don't match | `[grounded]` the messages; arithmetic |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Strong attention to detail | must_have | adjacent | medium | transferability | Three years at about 60 tickets a day, plus keeping the team tracker, point to sustained accuracy work. Nothing shows an accuracy or QA figure | `[grounded]` your background; `[inferred]` that volume implies accuracy | For genuine roles: a QA score or an error-rate figure would strengthen it |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | "I keep our team's weekly tracker in Excel." Specific, self-reported, nothing inspected yet | `[grounded]` your background | none |
| R3 | Good written English | must_have | unclear | low | discovery | Zendesk ticket work is named, but you don't say whether your replies were written | `[grounded]` your background is silent on it | See G2 |
| R4 | A quiet place to work | important | unclear | none | discovery | Not mentioned | `[grounded]` not stated | See G3 |
| R5 | At least €30,000 a year (your hard constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is unclear: €26 × 30 hrs × 52 weeks = €40,560, and × 15 hrs = €20,280, and "up to" commits to neither the rate nor the hours | `[grounded]` the posting and your floor; `[inferred]` the arithmetic | Moot here (no_go) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Attention to detail (R1, must_have) | transferability | High ticket volume, tracker ownership | Doesn't matter for this posting. Worth having ready for genuine order-processing roles | Catching wrong addresses or duplicate orders; fixing tracker errors; QA reviews | A QA scorecard or a performance review line | `[grounded]` your background; `[inferred]` its relevance to real roles |
| G2 | Written English (R3, must_have) | discovery | Zendesk named; whether you wrote the replies isn't stated | As G1 | Email or chat replies to customers; macros or templates you wrote; how-to notes for new starters | A sanitized reply or a template | `[grounded]` your background is silent on it |
| G3 | Quiet workspace (R4, important) | discovery | Not stated | As G1 | — | — | `[grounded]` not stated |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | high | "Velloway Logistics" | No trace of the company. Combined with the flags below, it is unlikely to be a real hiring employer | `[grounded]` the searches returned nothing; `[generic]` pattern: an employer that can't be found is a risk signal, raised to high when other flags combine | What is your registered company number and registered address? | confirmed |
| RR2 | ID, PPS number and bank details asked for before any interview | red_flag | high | "send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | That combination is enough to open accounts or commit fraud in your name. Genuine payroll setup happens after an offer and a contract | `[generic]` pattern for identity-theft job scams | Why does payroll need my passport and PPS number before an interview or a contract? | confirmed |
| RR3 | Upfront payment to a third party | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it" | Classic advance-fee pattern: the fee is the scam and the refund never comes | `[generic]` pattern for job scams | Why can't the equipment cost be deducted from wages instead of being paid by me up front? | confirmed |
| RR4 | Cheque to lodge with most of it forwarded onward | red_flag | high | "Lodge it to your account, keep €350 as a welcome bonus and transfer the rest" | Fake-cheque or overpayment scam: the cheque can bounce after you've sent the €2,500, leaving you out of pocket. Passing money through your account can also make you a money mule | `[generic]` pattern for overpayment and money-mule scams | Why can't your company pay the equipment supplier directly? | confirmed |
| RR5 | Telegram-only hiring with no voice or video | risk_signal | medium | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | It prevents you from ever confirming who you are dealing with | `[generic]` pattern | Can I speak to the hiring manager on a video call from a company account? | confirmed |
| RR6 | Contact moves to a free-mail address, not a company domain | risk_signal | medium | "velloway.hr@postmail.example" | No company domain stands behind the contact | `[inferred]` from the address against the claimed company | Why isn't HR emailing from a company domain? | confirmed |
| RR7 | Pay above market for no experience | risk_signal | medium | "up to €26 an hour plus commission … No experience needed" | Bait pay. "Up to" commits to nothing | `[grounded]` the posting's figure; `[generic]` Pennoral band (role reality) | What hourly rate is guaranteed in the contract? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't send your IBAN, PPS number, passport photo or any money. You pasted your IBAN here. I haven't used it, and it isn't needed to judge a job. Don't paste it to them | RR2, RR3 | `[grounded]` the messages | pending your approval |
| A2 | If a cheque arrives, don't lodge it and don't transfer anything | RR4 | `[grounded]` RR4 | pending your approval |
| A3 | Stop replying. Report @VellowayHiring to Telegram and the listing to the jobs site, with screenshots | RR1–RR7 | `[generic]` standard scam response | pending your approval |
| A4 | Report it to An Garda Síochána. If any detail or money ever does go out, call your bank's fraud line straight away | RR2, RR4 | `[generic]` standard scam response | pending your approval |
| A5 | Look for genuine salaried order-processing and customer-ops roles. The band's median of €31,200 sits above your €30k floor, and your Zendesk, training and Excel experience fits that family | R1, R2; role reality | `[generic]` Pennoral band; `[inferred]` that your experience fits that family | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "\"Velloway\" careers order processing": no results, so the company isn't established. Moved RR1 and the Organization row in role reality |
| 2. Role-family sweep | yes | Searched "order processing coordinator salary Ireland". It returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). Moved the market calibration row and RR7 |
| 3. Hiring manager's public footprint | n/a | No name was given, only a Telegram handle, so there was no query to run |

Beyond this assessment: I can run the same check on a genuine order-processing or customer-ops posting you find. That would give you a real fit read, and your background earns one.

If it's useful, I can save this as a `tuesday-dossier.md` file so you have a record to show the jobs site or the Gardaí.

**Upgrade menu**
- The link to the original listing → I can check whether it's still live, which is useful for your report. It won't change the decision.
- A company number they give you → RR1 can be checked. The decision stays the same because of RR2, RR3 and RR4.
- A deeper research pass on "Velloway" (public scam reports, related handles; up to 5 more searches and 2 more fetches) → it would add detail to the register, not change the decision. Say the word and it runs.
- A genuine posting you're weighing → a full fit read against R1–R4 and your €30k floor.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.