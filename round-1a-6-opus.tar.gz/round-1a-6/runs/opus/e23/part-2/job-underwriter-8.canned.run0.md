I'm checking this posting against the skill's checklist. Next I'll look up whether Velloway Logistics is a real company, then write up the assessment.
**No, this isn't a legitimate job, and you shouldn't go ahead. Status: `no_go`.** Three of the things they've asked for, RR2, RR3 and RR4 below (each `severity: high`), are in their own messages, so this isn't a guess.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (€30,000 a year minimum)
- `must_have`: direct: R2 · adjacent: R3 (strong attention to detail), R4 (good written English) · unclear: R5 (a quiet place to work)
- `important`: adjacent: R6 (order processing)

R2 is backed by your Excel tracker; R3, R4 and R6 are reasonable links from your courier support work; neither ledger changes the outcome, because the problem is the employer, not you.

**Opportunity ledger.** The employer couldn't be found (RR1). They want your bank, PPS and passport details before any interview (RR2), a €349 upfront fee (RR3), and for you to lodge their cheque and forward €2,500 (RR4). Hiring is Telegram-only (RR5) with an outside email address (RR6), and the pay terms are vague (RR7). Nothing in the register counts in their favour.

- **Hard gates:** none failed; unconfirmed: R1 (€30,000 a year minimum).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** a real company registered under this name, with a reachable office and a named person; a phone or video interview; no money from you at any stage; and no cheque to lodge. RR2, RR3 and RR4 have already happened, so only finding out you'd misread those messages would change the decision.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics" | `[grounded]` posting; no trace found (RR1) |
| Mandate | "Order processing", undefined; no products, systems or customers named | `[grounded]` posting |
| Pay as stated | "Up to €26 an hour plus commission", 15–30 hours a week | `[grounded]` posting |
| Pay as annual | About €20,280 at 15 hrs to €40,560 at 30 hrs, at the top rate with no unpaid weeks | `[inferred]` arithmetic on the posting's figures |
| Process | Telegram only; "no calls or video interviews"; offer made after a text chat | `[grounded]` posting and messages |
| Market calibration | Order processing and customer operations coordinators in Ireland: median €31,200 a year, middle half €28,400–€34,100, salaried roles only. This is the normal range, not an offer from this employer | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide, n=1,140 |
| Unknowns | Employment type (employee or contractor), guaranteed hours, what "commission" is paid on, the company's registered identity | — |
| Contradictions | "We will refund it with your first wages" (the €349), then a cheque that already covers the kit. The two payment stories don't fit together | `[grounded]` messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | €30,000 a year minimum (your hard constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own clearly stated floor. Fit is unclear because "up to €26/hr" across 15–30 hours could land either side of €30k, and nothing guarantees the hours or the rate | `[grounded]` your message, posting's figures | None: the decision doesn't depend on it |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep the team's weekly tracker in Excel. That's your own account and hasn't been checked, so `medium` | `[grounded]` your background | none |
| R3 | Strong attention to detail | must_have | adjacent | medium | transferability | About 60 Zendesk tickets a day for 3 years means accuracy at volume. It's a good link but isn't proof on its own | `[inferred]` from your ticket volume | none |
| R4 | Good written English | must_have | adjacent | medium | transferability | Ticket work is largely written replies to customers. Your own account, unchecked | `[inferred]` from Zendesk support work | none |
| R5 | A quiet place to work | must_have | unclear | low | discovery | You didn't mention your home setup | `[grounded]` your background is silent on it | none: doesn't affect the decision |
| R6 | Order processing (implied by the title) | important | adjacent | medium | transferability | Parcel courier support sits close to order handling. You also trained two new starters, which no requirement here asks for | `[inferred]` from courier CS role; requirement `[inferred]` from the title | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | €30k floor (R1, hard_gate) | hard_gate | Hourly "up to" rate, flexible hours, no guaranteed income | It would matter for a real role; here it changes nothing | — | A written contract with a fixed rate and guaranteed hours | `[grounded]` posting terms |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | red_flag | high | "Velloway Logistics" | No company of this name shows up online at all. With the other entries, this is most likely a made-up name | `[grounded]` search returned nothing; `[generic]` fake employer names are common in job scams | What is your Companies Registration Office number and registered address? | confirmed |
| RR2 | Bank, PPS and passport details asked for before any interview | red_flag | high | "send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | Together these are enough for identity theft or to open accounts in your name. A real employer collects payroll details after a signed offer | `[generic]` identity-fraud pattern; `[grounded]` their message | Why would payroll need my passport before I've had an interview? | confirmed |
| RR3 | Upfront fee for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | An advance-fee scam: the "refund" never comes | `[generic]` advance-fee job scam pattern | Can the €349 be taken out of my first wages instead of paid upfront? | confirmed |
| RR4 | Cheque overpayment, forward the rest | red_flag | high | "Lodge it to your account, keep €350 … transfer the rest to our equipment partner" | The cheque is fake or stolen. It can look cleared, then bounce days later, after your €2,500 transfer has gone and can't be recalled. You'd owe the bank, and passing money on like this can get you treated as a money mule | `[generic]` cheque overpayment scam pattern | Why can't the company pay the equipment supplier directly? | confirmed |
| RR5 | Telegram-only hiring, no voice or video, job offered after text chat | risk_signal | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | This lets them avoid being identified. It's a common setting for the scams in RR2–RR4 | `[generic]` remote-job scam pattern | Can I have a video interview with the person I'd report to? | confirmed |
| RR6 | Contact email not on a company domain | risk_signal | medium | "email velloway.hr@postmail.example" | A free or throwaway mailbox, not a company domain | `[inferred]` from the address domain | What is your company's own website and email domain? | confirmed |
| RR7 | Pay vague and open-ended | unknown | — | "Earn up to €26 an hour plus commission … No experience needed" | High pay for no experience and no set hours is a common lure | `[generic]` job-lure pattern, set against the band in Role reality | Is this employment or contracting, and how many hours are guaranteed? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't send your IBAN, PPS number or passport photo, and don't paste that IBAN into Telegram | see RR2 | `[grounded]` their message | your call |
| A2 | Don't pay the €349 | see RR3 | `[grounded]` their message | your call |
| A3 | If the cheque arrives, don't lodge it. If it's somehow been lodged, don't transfer anything and ring your bank's fraud line | see RR4 | `[generic]` cheque overpayment pattern | your call |
| A4 | Stop replying. Report @VellowayHiring in Telegram and report the listing to the jobs site | see RR1, RR5 | `[generic]` platform reporting | your call |
| A5 | Report it to An Garda Síochána. Keep screenshots of the posting and every message | see RR2–RR4 | `[generic]` fraud reporting in Ireland | your call |
| A6 | If any of those details ever does reach them, tell your bank and contact the passport and PPS authorities at once | see RR2 | `[generic]` identity-theft response | your call |
| A7 | For real roles: your 3 years of courier support, the Zendesk volume, training two starters and the Excel tracker suit order processing or customer operations jobs that pay around the band in Role reality | see R2, R3, R6 | `[generic]` Pennoral band; `[grounded]` your background | your call |

## Evidence status

Verified: none yet. You put your IBAN in your message to me; I haven't used it or repeated it anywhere.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics": no results. Employer not established; this is RR1 |
| 2. Role-family sweep | yes | Searched "order processing coordinator salary Ireland", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). This gave the market calibration row and RR7 |
| 3. Hiring manager's public footprint | n/a | No person was named, only a Telegram handle, so there was nothing to search for |

I can also put all of this into a `tuesday-dossier.md` file you can keep if you want one.

## Upgrade menu

- A link to a real job ad you're considering → a full assessment of that role against your €30k floor and your background.
- Your CV → R2, R3, R4 and R6 get checked against what it actually says, ready for real applications.
- Deeper research on "Velloway" (company registry, scam-report forums, recent warnings; up to 5 more searches and 2 more fetches) → stronger evidence for your Garda or bank report. Just say if you want it.

## Questions

RR4: Has the €2,850 cheque arrived, and has anything gone to them since you wrote to me?

A7: Would you like me to assess a real order-processing or customer-operations job you've seen, using the background you gave me?

Answer in text, paste a transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.