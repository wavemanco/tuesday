I've read the vetting checklist I use for job postings, and next I'm checking whether "Velloway Logistics" shows up anywhere online.
# Velloway Logistics: should you go ahead?

## Decision snapshot

**No. This isn't a legitimate job, and you shouldn't send them anything: not your IBAN, not your PPS number, not your passport photo, and not the €349. If a cheque arrives, don't lodge it. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Pay of at least €30,000 a year)
- `must_have`: direct: R3 · adjacent: R2 (Strong attention to detail), R4 (Good written English)
- `important`: adjacent: R5 (Order processing)

R2, R4, R5: real experience that carries over to genuine roles. R1: not settled, and it no longer matters given RR1.

**Opportunity ledger.** Your fit isn't the problem. The "employer" is. The messages contain a fake-cheque scheme (RR1), an upfront fee (RR2) and a demand for identity documents before any interview (RR3). I also couldn't find any trace of the company (RR5). RR4, RR6 and RR7 back that up.

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR5 (`severity: high`)
- **What would have to be different:** a company you can check on the Irish Companies Registration Office (CRO) register and on its own website, with this role on its own careers page; a recruiter writing from the company's email domain; a real interview with a named person; a written contract before anyone asks for your PPS number or bank details. On top of that, no fees and no cheques to forward.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics." Searching found nothing at all: no website, no careers page, no listing | `[grounded]` posting header; searches returned no results |
| Mandate | "Remote Order Processing Coordinator," 15–30 hours a week, hours you choose | `[grounded]` posting |
| Pay as stated | "Up to €26 an hour plus commission on every order you process." If every hour paid the top rate, that's €20,280 a year at 15 hours a week and €40,560 at 30 | `[grounded]` posting; `[inferred]` my arithmetic (rate × hours × 52) |
| Hiring process | Telegram only, "no calls or video interviews." The job was "yours" after a text chat | `[grounded]` posting and messages |
| Market calibration | Order processing and customer operations coordinators in Ireland earn a median of €31,200 a year (middle half €28,400–€34,100), salaried roles only. Over a full-time year that's roughly €15.40 an hour, so a no-experience role advertising €26 an hour sits far above the norm (RR7) | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide, from this session's search; `[inferred]` hourly figure from €31,200 ÷ 2,028 hours |
| Unknowns | Legal entity, address, who any employment contract would be with, what "processing orders" actually involves | — |
| Contradictions | "Full training provided" against a process with no call or video at any point. "Payroll" wants your bank and ID details before you've even had an interview | `[grounded]` posting against messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your hard constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own floor, which you stated clearly. Fit is unclear because "up to" an hourly rate with flexible hours guarantees nothing: €20,280–€40,560 is only a best case | `[grounded]` your message; `[inferred]` the range | For any real role: a written base salary or guaranteed hours |
| R2 | Strong attention to detail | must_have | adjacent | medium | transferability | About 60 Zendesk tickets a day for 3 years at a parcel courier is sustained, accurate case handling. It's close to the requirement but isn't direct proof of error rates | `[grounded]` your background | Quantify it for real applications, for example accuracy or reopen rates if you know them |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. That's self-reported for now, so `medium` is the ceiling until you show an example | `[grounded]` your background | none |
| R4 | Good written English | must_have | adjacent | medium | transferability | Zendesk ticket work is usually written replies to customers. You didn't say yours were written rather than phone | `[inferred]` from Zendesk ticket handling | Confirm the share of written replies when applying elsewhere |
| R5 | Order processing (the role's core work) | important | adjacent | medium | transferability | Parcel-courier customer service sits right next to order and shipment handling. Training two new starters adds credibility | `[grounded]` your background | Lead with this in genuine logistics or customer-ops applications |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R1, hard_gate) | hard_gate | Only an "up to" rate with variable hours | Your €30,000 floor needs a guaranteed figure | — | A written contract stating salary or guaranteed hours | `[grounded]` posting wording |
| G2 | Order processing (R5, important) | transferability | Courier customer service, about 60 tickets a day, trainer of new starters | It's your strongest bridge to genuine coordinator roles | Handling delivery exceptions, address changes, claims, returns | Ticket volume, satisfaction scores (CSAT), the tracker you maintain (anonymized) | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | A cheque to lodge, with most of it forwarded on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it… keep €350… transfer the rest to our equipment partner" | This is the classic overpayment scam. The cheque looks like it has cleared, you send €2,500 from your own money, then the cheque bounces and your bank takes back the full €2,850. You end up out of pocket, and possibly flagged for handling fraudulent funds | `[generic]` well-known fake-cheque pattern; `[grounded]` the message text | Why can't the company pay its equipment supplier directly instead of routing money through a new hire's personal account? | confirmed |
| RR2 | Upfront fee for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages" | Genuine employers supply equipment or pay suppliers themselves. They don't charge candidates. The "refund" never comes | `[generic]` advance-fee pattern; `[grounded]` the message text | Will you ship the equipment at company expense, with no payment from me? | confirmed |
| RR3 | IBAN, PPS number and passport photo demanded before any interview | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport" | Together these are enough for identity theft. They could be used to open accounts or loans in your name, or to use you as a "money mule" for laundered money | `[generic]` identity-fraud pattern; `[grounded]` the message text | Can I see a signed contract naming the legal employer before I give any payroll details? | confirmed |
| RR4 | Telegram-only hiring, no voice or video, job offered after a text chat | red_flag | medium | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | It keeps the "recruiter" anonymous and untraceable. Taken alone it would be a risk signal, but it sits with RR1–RR3, so it's a red flag. I've rated it medium because on its own it proves nothing | `[generic]` scam-recruitment pattern | Can I have a video call with my future manager, using their name and company email? | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | high | "Velloway Logistics" | No website, careers page or listing came up in any search. Combined with RR1–RR3, this most likely isn't a real hiring employer | `[grounded]` this session's searches returned nothing; `[generic]` that a real employer leaves some trace | What is your company registration number, and where is this role on your own careers page? | unresolved |
| RR6 | Contact email off any company domain | risk_signal | medium | "email velloway.hr@postmail.example" | A real HR team uses the company's own domain. A generic mail service means nobody is accountable | `[generic]` pattern | Why is HR writing from a general mail service rather than a company domain? | unresolved |
| RR7 | Pay well above the market rate, plus commission "on every order you process" | risk_signal | medium | "Earn up to €26 an hour plus commission on every order you process. No experience needed" | €26 an hour for no-experience work sits far above the €31,200 median (about €15.40 an hour). "Processing orders" in jobs like this often means receiving and forwarding money or parcels for criminals, which is money-mule or reshipping work | `[generic]` Pennoral band and mule-recruitment pattern; `[inferred]` from the posting text | What exactly does processing an order involve, and does any money or parcel pass through my hands? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing more. Don't paste your IBAN, PPS number or passport into that chat, and don't pay the €349 | See RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | If a cheque arrives, don't lodge it. Keep it as evidence | See RR1 | `[generic]` fake-cheque pattern | pending your approval |
| A3 | Report the listing to the jobs site and the @VellowayHiring account to Telegram. Then report it to An Garda Síochána, and mention it to your bank so they can watch your account | Stops it reaching others and creates a record | `[generic]` standard reporting routes | pending your approval |
| A4 | Stop replying to @VellowayHiring. Expect pressure or "urgent" follow-ups, and ignore them | See RR4 | `[generic]` pattern | pending your approval |
| A5 | Apply to genuine order-processing and customer-ops coordinator roles. They pay €28,400–€34,100, and your background fits them (R3 directly; R2, R4 and R5 as close experience) | Your €30,000 floor sits inside the real market band | `[generic]` Pennoral band; `[grounded]` map rows | pending your approval |

Your IBAN, which you pasted here, hasn't been used or sent anywhere. Your passport hasn't been uploaded, and it isn't needed to judge a role.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway logistics careers order processing coordinator". Both returned no results, so the employer is not established, which became RR5 |
| 2. Role-family sweep | yes | Searched "order processing coordinator remote Ireland salary", which returned the "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). It set the market calibration and RR7 |
| 3. Hiring manager's public footprint | n/a | No name was given, only the Telegram handle @VellowayHiring, so there was nothing to search for |

I can save all of this as a `tuesday-dossier.md` file if you want a record to keep or attach to a report.

## Upgrade menu

- A company registration number or website link, if the listing showed one → RR5 can be checked directly against the CRO register.
- A screenshot or link of the original listing → it can go into your reports to the jobs site and the Gardaí.
- A deeper research pass (scam reports naming Velloway, recent warnings; up to 5 more searches and 2 more fetches) → it would add evidence for your reports, though it won't change the `no_go`. Say the word and it runs.
- One optional extra, if you want it: a short list of what genuine coordinator postings look like (and how to spot a fake), built on your R3 and R5 experience. You've already been targeted once, so it's worth having.

## Questions

1. (RR1) Has a cheque or a tracking number for one already arrived?
2. (RR3) Have you shared anything with them besides your answers, such as your name, phone number, address or email?

You can answer in text, attach a screenshot, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.