I started building your prep pack, but I have to stop and tell you something first: **this email is almost certainly a job scam, not a real interview invitation.** Please don't send any money, documents or bank details.

## Why it's a scam

Each of these is a well-known fraud pattern:

1. **The €95 "equipment registration fee."** Real employers don't charge you to get an interview. Paying to "confirm your slot" is an advance-fee scam.
2. **A photo of your passport plus your bank details before the interview.** Real employers ask for ID and bank details after you've accepted an offer, as part of onboarding. Asking for them up front sets you up for identity theft and for your account being used to move stolen money.
3. **The €1,850 cheque where you "send the balance on to the vendor."** This is the classic fake-cheque scam. The cheque shows in your account, you send the money on, and days later the cheque bounces. Your bank takes back the €1,850, and the money you sent is gone and is still owed by you. If the funds were stolen, you could also be caught up in money laundering.
4. **Pressure to pay "before your slot can be confirmed"** is meant to rush you before you think it through.

## What to do

- **Don't pay, don't send your passport or bank details, and don't deposit any cheque they post you.**
- **If you've already sent money or documents:** call your bank's fraud line straight away, report it to An Garda Síochána, and if your passport photo went out, contact the Passport Office about possible misuse.
- **If you want to be sure,** look the company up on the Companies Registration Office (CRO) search. Then contact them using a phone number or email you find yourself, not one from this email. Also go back to where you saw the ad and report it to that job site.

## The good news: your background suits this kind of job

The duties in the ad match what genuine admin jobs ask for, and your experience covers much of it. Here's how to prepare for a **real** interview:

| Typical requirement | Your evidence | How to talk about it |
|---|---|---|
| Managing calendars | You ran the appointment book for four physios | Running four people's schedules is calendar management. Have a story about a clash or a last-minute cancellation you sorted out. |
| Processing invoices | You chased unpaid invoices | Talk about how you tracked what was owed and followed up. Be honest that chasing what clients owe is different from processing invoices from suppliers. |
| Word and Excel | Good at Word, okay at Excel | Say "okay with Excel" plainly. Before interviews, practise sorting and filtering, SUM and basic formulas, and a simple tracking sheet. |
| Booking travel | Nothing in what you've told me | Say you haven't done it, and point to the same skills: organising, attention to detail, handling changes. |

**Questions you're likely to get:**
- "Tell me about a time you juggled several people's priorities." Use the four physios.
- "How do you handle a difficult or overdue client?" Use the invoice chasing.
- "Rate your Excel skills." Give an honest rating and say what you're doing to improve.
- "How do you stay organised working remotely?"

**One question to ask them:** "What would a typical day look like, and whose calendars would I be managing?"

In a real interview process, you'll never be asked to pay anything or send your passport before you get an offer.

I'm happy to build a full prep pack or run a live practice interview with you once you have a genuine interview lined up. Send me that job ad and I'll tailor it.