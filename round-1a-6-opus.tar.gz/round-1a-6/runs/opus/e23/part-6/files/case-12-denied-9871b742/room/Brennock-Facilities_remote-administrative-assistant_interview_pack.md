# Interview prep pack: Remote Administrative Assistant

**Role:** Remote Administrative Assistant, as described in the ad you relayed (managing calendars, booking travel, Word and Excel documents, supplier invoices)
**Company:** Brennock Facilities Ltd. Its identity is **unverified**, and the invitation email shows strong signs of a scam (see the message this pack came with). The prep below is built from the ad's duties and your background, so it carries over to any genuine admin interview.
**Interviewer:** "our office manager", 30-minute video call. Treated as a hiring-manager round.

---

## How to use this pack

- **Personas** describe *how* a question is asked. **Types** describe *what* is being scored.
- **Type key:**
  - **VAL**: values and behaviour (how you act with people)
  - **EXP**: work-experience deep-dive (what you actually did)
  - **JD**: the duties in the ad (can you do the listed job)
  - **CO**: company knowledge (left out here, because the company is unverified)
  - **CASE**: a live problem from the role
- **Provenance:** `[grounded]` = built on your own words or the ad's words. `[inferred]` = derived by this pack. `[generic]` = a standard pattern for admin interviews.
- The guidance is scaffolding, not a script. Say things in your own words, and only say what you actually did.
- A 30-minute call fits about 8 to 10 questions. Rehearse S1 first, then C1, then the CASE bank.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as relayed in your message | "I ran the appointment book for four physios" — your message | medium | [grounded] | transferability | Your material shows one clinic's appointment book, not wider calendar management, and your words should stay there: "I ran the appointment book for four physios." Answer slot: the ad's calendar line makes a question on how you kept the book in order likely. If you handled clashes, cancellations or rebooking, say how, in your own words. If you didn't, say so plainly and stay with running the book |
| F2 | "booking travel" — the ad, as relayed in your message | none given | none | [grounded] | discovery | Your material doesn't show travel booking. Answer slot: if you have booked travel for anyone, at work or otherwise, say what and how. If you haven't, say so plainly, then walk through how you would approach it (K2) |
| F3 | "preparing documents in Word" — the ad, as relayed in your message | "I'm good with Word" — your message | medium | [grounded] | none | No gap, but this is a self-rating with nothing behind it yet, so expect "what kind of documents?" Answer slot: name the documents you actually produced in Word, if any. If it's mostly personal or general use, say that |
| F4 | "preparing documents in … Excel" — the ad, as relayed in your message | "okay with Excel" — your message | low | [grounded] | discovery | "Okay" is your own honest level, so keep it. Answer slot: say which Excel tasks you can do today, in your own words. For anything you can't do, say so plainly and name what you would learn first. Never describe a skill you haven't used |
| F5 | "processing supplier invoices" — the ad, as relayed in your message | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Chasing money owed *to* the clinic is adjacent to supplier invoices, which is money *owed by* the company, but it is not the same work. Words: "I chased unpaid invoices." Answer slot: if any of your invoice work went beyond chasing, say what, in your own words. If it didn't, say so plainly and stay with the chasing |
| F6 | Background fit for an admin role — inferred from the ad's duties | "two years as a receptionist at a physiotherapy clinic" — your message | medium | [inferred] | transferability | Two years of front-desk work is relevant experience, but the title is receptionist, not administrator. Say it as it is: "two years as a receptionist at a physiotherapy clinic." Let the interviewer connect it to the role |

---

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "How would you handle…" questions about calendars, travel, invoices | **High.** An office manager hiring an assistant is buying day-one usefulness, and live scenarios are the cheapest way to test it | Clarify, then prioritise, then act, then follow up. Think aloud |
| Skeptic | "Reception isn't admin, so how does it translate?" | **High.** F5 and F4 are visible gaps against the ad | Bridge only from what you stated. Name the limit before they do. Give a short plan for learning |
| Conversational | Friendly opener: "Tell me about yourself" | **Medium-high.** It's a short video call, so it usually opens this way, and the opener is still scored | A pre-practised 90-second arc built from your own sentences |
| Data-Driven Prober | "How many appointments a week?" | **Low-medium.** Admin managers sometimes test scale | Give numbers you actually know. If you don't have an exact figure, say so |
| Pressure | "Why you over someone with office experience?" | **Low-medium.** Possible, but a 30-minute screen rarely pushes hard | Pause, hold your real position, and concede only the specific gap |
| Values / Behavioural | "Tell me about a time…" | **Medium.** Common in admin hiring | Tell stories only from things you actually lived. If nothing fits, say so |
| Peer | "What would you need from me?" | **Low.** The manager may slip it in about remote working | Reciprocity: what you'd bring, and what you'd ask for |

---

## Question banks

### Case / Strategist (K)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Two people both want the director's 10am slot. How do you handle it?" | CASE | [generic] | Clarify which meeting is more urgent and whether the director has a preference. Offer the next-best slot to the other person quickly and politely. Confirm both in writing and update the calendar straight away. This makes no claim about your past | The ad's calendar line (F1's requirement), asked as a live decision. CASE because it scores how you reason, not your history |
| K2 | "Book a two-day trip for three staff. What do you need to know first?" | CASE | [generic] | First ask: dates, times, budget and travel policy, who approves, and preferences or accessibility needs. Then compare options, get approval, book, and send one itinerary with confirmations. Keep receipts for expenses | F2 has no evidence, so this is where you can show method without claiming experience. CASE |
| K3 | "A supplier invoice doesn't match the purchase order. What do you do?" | CASE | [generic] | Don't pay or approve it. Check it against the order and any delivery note. Flag the mismatch to the person who ordered and to the supplier, in writing. Note it as on hold until it's resolved. Ask how the company normally handles disputes | The ad's invoice line (F5's requirement). It tests judgement on payables without asking you to claim payables experience |
| K4 | "Three urgent requests land at once from different people. How do you prioritise?" | CASE | [generic] | Clarify actual deadlines. Rank by impact and time-sensitivity. Tell each person when they'll get theirs. Escalate to your manager if the priorities truly conflict | Remote assistants juggle competing requests, so prioritisation is near-certain to come up. CASE |

### Skeptic (S)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "This role processes supplier invoices. What have you done with invoices?" | JD | [grounded] "chased unpaid invoices" | **Highest-ROI rehearsal in this pack.** Open with exactly what you did: "I chased unpaid invoices." Answer slot: if your invoice work included anything beyond chasing, say what, in your own words. If it didn't, say so plainly. Then name the limit yourself: chasing money owed to the clinic isn't the same as handling invoices the company owes, and you'd want to learn their process. Hold through two follow-ups by returning to the chasing, never by adding to it | F5 is the biggest visible gap against the ad, so this objection will arrive in some form. JD because it scores a listed duty |
| S2 | "You ran one clinic's appointment book. How is that like managing calendars here?" | JD | [grounded] "I ran the appointment book for four physios" | Say the quote's facts: four physios, one book. Answer slot: if you handled clashes, cancellations or rebooking, describe how. If not, say so. Let them draw the comparison rather than claiming it's "the same as executive calendar management" | F1 is your strongest bridge, and an office manager will test how far it stretches. JD |
| S3 | "You said you're okay with Excel. What can you actually do in it?" | EXP | [grounded] "okay with Excel" | Keep your own level: "okay." Answer slot: list only the Excel tasks you have done. Where you haven't, say so and name one thing you'd learn first. A candid "okay" beats a bluffed "advanced" that breaks on the next question | F4 is low-confidence, and Excel is easy to test live. EXP because it checks a self-rating |
| S4 | "I don't see travel booking in your background. How would you handle that part?" | JD | [grounded] | Answer slot: if you have booked travel for anyone, say so in your own words. If you haven't, say so plainly, then give K2's method. Never invent past bookings | F2 is a discovery gap. The question is worded as the interviewer's observation, not a claim you'd make |

### Conversational (C)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me about yourself." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios"; "chased unpaid invoices"; "I'm good with Word, okay with Excel" | A 90-second arc with three beats, all from your own sentences: two years as a receptionist at a physio clinic; you ran the appointment book for four physios and chased unpaid invoices; you're good with Word and okay with Excel. End with why this role, using C2's answer | The near-certain opener on a short call. Practise until it's smooth |
| C2 | "Why do you want to move into a remote admin role?" | VAL | [generic] | Selection scaffold: give your real reason (the kind of work, remote working, growth) in one or two sentences, and tie it to a duty in the ad. If your reasons are practical, say so honestly. That's fine | Motivation is scored even in a friendly register. None of your sentences states a reason yet, so this is a scaffold |
| C3 | "What does a typical day at the clinic look like?" | EXP | [grounded] "I ran the appointment book for four physios"; "chased unpaid invoices" | Start from the two things you've told me: running the book and chasing invoices. Answer slot: add any other tasks that were genuinely yours, in your own words. Don't pad the list | A casual question that is really a skills inventory |

### Data-Driven Prober (P)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Four physios: roughly how many appointments a week went through the book?" | EXP | [grounded] "I ran the appointment book for four physios" | Answer slot: give a figure only if you know it, and say how you know it. If you don't, say "I don't have an exact number" rather than guessing | F1 is your headline claim, and a number makes it concrete. It must be real |
| P2 | "When you chased unpaid invoices, how did you keep track of who owed what?" | EXP | [grounded] "chased unpaid invoices" | Answer slot: if you kept a list, spreadsheet or system note, say which, in your own words. If there was no tracking method, or someone else kept it, say so plainly and describe how you did the chasing | Connects F5 to the ad's invoice line, and the honest answer is ready before the probe |

### Pressure (X)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| X1 | "Sixty seconds: why you over someone with office-admin experience?" | JD | [grounded] "I ran the appointment book for four physios"; "chased unpaid invoices" | Pause, then hold: you ran the appointment book for four physios and chased unpaid invoices, both close to this role's calendar and invoice duties. If pushed twice, concede specifically ("I haven't worked in an office-admin title") without folding on what you did | Hold-then-concede on F6, the title gap |
| X2 | "How do we know you'll be productive working remotely, with no one watching?" | VAL | [generic] | Selection scaffold: pick something from your own work that shows self-direction, and say what you'd do (daily task list, clear check-ins, quick replies). If you've never worked remotely, say so and describe your plan | The job title is "Remote". Expect the reliability question |

### Values / Behavioural (V)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you had to chase someone for money they owed. How did you keep it polite?" | VAL | [grounded] "chased unpaid invoices" | Story-mapped on F5: pick one real instance of chasing. Answer slot: say what you said or did and how it ended, in your own words. If no single instance stands out, say so and describe how you usually approached it | F5 shows tact under awkwardness, which is a core admin trait |
| V2 | "Tell me about a mistake you made at work and what you did." | VAL | [generic] | Selection scaffold: a real, small mistake, owned quickly, fixed, and with what you changed afterwards. If none comes to mind, say so plainly and describe how you'd handle one | A standard question that checks honesty and ownership |

### Peer (R)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Working remotely, what would you need from me in the first month?" | CASE | [generic] | Access to the calendars and systems, the invoice and travel process written down or walked through, one regular check-in, and who to ask when you're stuck. Offer something back: a weekly summary of what's done | Shows you'll reduce the manager's load |
| R2 | "Two colleagues give you conflicting instructions. What do you do?" | CASE | [generic] | Don't pick silently. Clarify with both, and if it's still unresolved, ask your manager to set the priority. Confirm the outcome in writing | Common admin friction |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Managing calendars (F1) | K1, S2, P1 |
| Booking travel (F2) | K2, S4 |
| Word documents (F3) | C1 (no dedicated question, because F3 has no gap; be ready to name the documents) |
| Excel (F4) | S3 |
| Supplier invoices (F5) | S1, K3, P2, V1 |
| Remote working (job title) | X2, R1 |

---

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does a typical week look like for this role?" | Shows you're picturing the actual work |
| "Which systems do you use for calendars and invoices?" | Shows practical readiness. It also tells you what to brush up on |
| "How will I be onboarded remotely? Who sets up my laptop and accounts?" | A real priority for remote hires. It also checks legitimacy: genuine employers supply equipment directly |
| "When would I receive a written contract, and how is payroll set up?" | Professional and reasonable. A legitimate employer answers it easily |
| "What would a great first three months look like to you?" | Invites the manager to define success, and gives you a target |
| "How does the team keep in touch day to day?" | Shows you're thinking about working well remotely |

---

## Prohibited claims (what this pack will not coach)

| Not coached | Basis | Honest form |
|---|---|---|
| "Managed executive calendars" | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." Your material says the appointment book, not executive calendars |
| "Processed supplier invoices" or "handled accounts payable" | Inflated form of F5 | F5's quote: "chased unpaid invoices." Your material says chasing, not processing. S1's answer slot stays inside your invoice work |
| "Advanced in Excel" | Contradicted by your own words, F4 | "okay with Excel." No upgrade |
| "Administrator" as a past job title | Inflated form of F6 | "two years as a receptionist at a physiotherapy clinic" |

---

## Sources

- **Provided:** your message (the ad's duties as you relayed them, your background, and the invitation email text)
- **Search sent:** `"Brennock Facilities" Ltd` — refused (permission not granted)

Research tier: L1, searches 1 of 6 (refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Would have fed a values cheat sheet. The only search was refused, and the company's existence is unverified |
| 2. Interview process | unavailable | Would have confirmed the round structure. Your message says a 30-minute video call with the office manager |
| 3. Strategy / recent news | unavailable | Would have fed CO questions, and could have shown whether the company exists |
| 4. Interviewer name | n/a | No name was given |
| 5. Representative JD | skipped | The ad's duties, as you relayed them, fix the fit snapshot |

---

## Upgrade menu

- The full ad text → exact requirements; S and K questions tightened to its wording
- Answers to the answer slots in F1, F2, F4 and F5 → S1 to S4, P1, P2 and V1 rebuilt around what you actually did
- A **verified, legitimate** employer's name → company research, values questions and tailored reverse questions
- The interviewer's name → a tailored reverse question and adjusted persona weights
- A tuesday-dossier.md from job-underwriter → an evidence-checked objection list and guardrails (optional)
