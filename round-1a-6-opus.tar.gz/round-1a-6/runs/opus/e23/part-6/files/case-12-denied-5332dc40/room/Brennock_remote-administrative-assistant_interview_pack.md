# Interview prep: Remote Administrative Assistant ("Brennock Facilities Ltd")

30-minute video call with the office manager. Built from your message only (no research run).

> **Read this first.** The invitation email shows four classic signs of a job scam: a fee before the interview, a request for your passport and bank details before you've even spoken to anyone, a "deposit our cheque and send the balance on" arrangement, and an IBAN that can't be valid (Irish IBANs never have "00" as their check digits). **Don't pay, don't send documents, and don't deposit any cheque.** Everything below will help you in any genuine admin interview, and the reverse questions in section 6 also work as legitimacy checks if you do take the call.

---

## 1. How to use this pack

- **Personas** describe *how* a question gets asked. **Types** describe *what* is being scored:
  - **EXP**: what you actually did in past jobs
  - **JD**: whether you can do the duties listed in the ad
  - **CASE**: a live "what would you do" problem from the job
  - **VAL**: how you behave at work (usually matched to company values; generic here)
  - **CO**: company knowledge (not used, since there's no verified company to research)
- Use the guidance as scaffolding, not a script. Say it in your own words.

## 2. Fit snapshot

Requirements are the ad's duties as you quoted them. Evidence is your own words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (the ad, via your message) | "I ran the appointment book for four physios" (your message) | medium | [grounded] | transferability | Close match, and you can say it at its own size: "I ran the appointment book for four physios." Answer slot: a remote admin role makes questions about clashes and changes likely. If you handled double-bookings, cancellations or rescheduling, describe what you did in your own words. If you didn't, say so and stay with running the book |
| F2 | "booking travel" (the ad, via your message) | none given | none | [grounded] | discovery | Your material says nothing about booking travel. Answer slot: if you've ever booked travel for anyone, work or personal, say what and how. If you haven't, say so plainly and describe how you'd approach it (compare options, confirm budget and preferences, send one clear itinerary) |
| F3 | "preparing documents in Word" (the ad, via your message) | "I'm good with Word" (your message) | medium | [grounded] | none | No gap. Expect "give me an example." Lead with a real document you made at the clinic, if there is one |
| F4 | "preparing documents in … Excel" (the ad, via your message) | "okay with Excel" (your message) | low | [grounded] | discovery | You've stated your level as okay, so keep it there. Answer slot: name the Excel tasks you've actually done (lists, sums, filters, whatever's true). For anything you haven't done, say you haven't and say how you'd learn it |
| F5 | "processing supplier invoices" (the ad, via your message) | "chased unpaid invoices" (your message) | medium | [grounded] | transferability | Chasing money owed *to* the clinic is the opposite direction from paying suppliers. Stay at your own scope: "I chased unpaid invoices." Answer slot: if you also checked invoice details, logged payments or flagged problems, say so. If you didn't, say so and explain what chasing invoices taught you about accuracy and follow-up |

**Highest-ROI prep in this pack: A1** (supplier invoices vs. chasing unpaid ones). It's your nearest gap to a core duty and the most likely objection.

## 3. Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | "Your experience is reception. This is admin." | High. An office manager hiring for a different job title will test whether the skills transfer | Lead with F1 and F5 at their true size, then show how the skill transfers. Don't stretch the claim |
| Case / Strategist | "Two meetings clash and the CEO is flying tomorrow. What do you do?" | High. A hiring manager wants to see how you'd handle the actual work | Use a structure: clarify, prioritise, act, confirm in writing |
| Conversational | "Tell me about yourself. Why remote?" | Medium. Thirty minutes is short, so expect a friendly opener | A 60-second story: clinic, the appointment book, invoices, why admin next |

## 4. Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Have you processed supplier invoices before?" | JD | [grounded] "chased unpaid invoices" | Hold to what your quote says: "I chased unpaid invoices." Answer slot: if you also checked amounts, matched invoices to records or logged payments, say which. If you didn't, say "Not supplier invoices, no," then name what carries over (care with figures, following up until it's resolved) and how you'd learn their process | F5 is the nearest gap to a core duty, so this question is likely. JD because it scores a listed duty |
| A2 | "How is running a clinic's appointment book like managing someone's calendar?" | EXP | [grounded] "I ran the appointment book for four physios" | Story-mapped on F1: four people's schedules in one book. Answer slot: if juggling their availability, changes or clashes was part of it, describe a real example. If not, say so and stay with running the book | Your strongest transfer, so make it land precisely |
| A3 | "How good is your Excel, honestly?" | JD | [grounded] "okay with Excel" | Keep the level you stated. Name only the tasks you've really done (answer slot), then say what you'd do to get faster, e.g. a specific free course you'd actually take | An honest "okay plus a plan" beats an inflated "advanced" that one test would expose |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two people want the same slot in your manager's diary. What do you do?" | CASE | [generic] | Check priorities with your manager (or follow their standing rules), offer the other person alternatives quickly, confirm everything in writing | Tests calendar judgment (F1's requirement) |
| B2 | "Book a two-day trip to Dublin for a visitor with a tight budget." | CASE | [generic] | Confirm dates, budget and preferences. Compare two or three options. Send one itinerary with times, addresses and booking references. Keep the receipts for expenses | Covers F2 without needing a past claim |
| B3 | "A supplier invoice doesn't match the order. What do you do?" | CASE | [generic] | Don't pay it yet. Check it against the order and the delivery, query the supplier in writing, flag it to whoever approves payments, and record the outcome | A natural follow-up to A1 |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about yourself." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | About 60 seconds: the clinic, the book, the invoices, and why you want admin work next (in your own words) | The opener sets the frame for every later question |
| C2 | "Why remote?" | JD | [generic] | Your real reason, plus how you stay organised and reachable working alone. If you haven't worked remotely before, say so plainly | Any remote role asks this |
| C3 | "Tell me about a time you handled a difficult person." | VAL | [generic] | Pick a real moment from reception: a named situation, what you did, and how it ended. If none comes to mind, say so and describe how you'd handle one | Common in short screens |

**Coverage:** calendars → A2, B1 · travel → B2 · Word → C1 (follow up with F3's example) · Excel → A3 · supplier invoices → A1, B3

## 5. Prohibited claims (not coached here)

| Not coached | Basis | Honest form |
|---|---|---|
| "I processed supplier invoices / accounts payable" | Stretched version of F5 | "I chased unpaid invoices" |
| "I managed executive calendars" | Stretched version of F1 | "I ran the appointment book for four physios" |
| "I'm advanced in Excel" | Contradicts your "okay with Excel" | Your stated level, plus what you're doing to improve |
| "I've booked business travel" | F2: no evidence | Only if it's true (A2/B2 slots) |

## 6. Reverse questions (these double as legitimacy checks)

| Question | Why it lands |
|---|---|
| "Who would I report to day to day, and what does a typical week look like?" | A real employer answers specifically. A scammer stays vague |
| "Which invoicing or accounts software do you use?" | Shows you're thinking about A1's duty. A real team names one |
| "How does equipment work? Do you supply it or reimburse it?" | Legitimate employers ship equipment or reimburse it. They never ask you to pay a fee or forward money |
| "What's the company's registered address and CRO number for my contract?" | A normal onboarding question. You can check the answer on the Companies Registration Office site |
| "What would success look like in the first three months?" | Shows you're focused on doing the job well |

## 7. Sources

- Provided: your message, including your summary of the ad and the invitation email.
- Research tier: L0. No searches or fetches were run.
- Targets: official values n/a · loop structure skipped · strategy skipped · interviewer n/a (unnamed) · representative JD skipped (ad duties given).

## 8. Upgrade menu

- Full ad text → `[generic]` rows become ad-grounded, plus coverage of any duties you didn't mention
- Your CV → story-mapped answers in place of answer slots for travel and Excel
- Interviewer's name → tailored reverse questions and persona weights
- A genuine role you've verified → company-specific research at L1
- A tuesday-dossier.md → evidence-graded gaps and a prohibited list checked against your own past answers
